﻿# ДЛЯ ТЕСТОВ. Собирает отдельную книгу из закреплённых рабочих исходников; релиз не заменяет.
param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference='Stop'
Push-Location -LiteralPath $Root
$previousTemp=$env:TEMP; $previousTmp=$env:TMP
try {
    . './Guard-IsolatedOffice.ps1'
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    foreach($pin in $prep.inputs.psobject.Properties) {
        if((Get-FileHash -LiteralPath $pin.Name).Hash -cne $pin.Value){throw ('Changed build input '+$pin.Name)}
    }
    Assert-IsolatedOfficeReady 'BuildSelectableMaterialBook'
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path; $env:TMP=$env:TEMP
    & './tools/build_workbook/Build-Workbook.ps1' -OutputPath 'workbook/output/SelectableLaws.xlsm' -UseFormattedLayout |
        Tee-Object -FilePath 'Build.log'
    $owner=Get-Content -LiteralPath 'workbook/output/BuildOwnership.json' -Raw | ConvertFrom-Json
    $deadline=[DateTime]::UtcNow.AddSeconds(20)
    do {
        $worker=Get-Process -Id $owner.PID -ErrorAction SilentlyContinue
        if(!$worker){break}
        if($worker.ProcessName -ine 'EXCEL' -or $worker.StartTime.ToUniversalTime().Ticks -ne [long]$owner.StartTicksUTC){throw 'Build process identity changed'}
        Start-Sleep -Milliseconds 200
    } while([DateTime]::UtcNow -lt $deadline)
    if($worker){throw 'Own build process has not closed'}
    [ordered]@{State='Absent';PID=$owner.PID;StartTicksUTC=$owner.StartTicksUTC;SavedWorkbookSHA256=(Get-FileHash -LiteralPath 'workbook/output/SelectableLaws.xlsm').Hash} |
        ConvertTo-Json | Set-Content -LiteralPath 'BuildClosure.json' -Encoding UTF8
} finally {
    $env:TEMP=$previousTemp; $env:TMP=$previousTmp
    Pop-Location
}
