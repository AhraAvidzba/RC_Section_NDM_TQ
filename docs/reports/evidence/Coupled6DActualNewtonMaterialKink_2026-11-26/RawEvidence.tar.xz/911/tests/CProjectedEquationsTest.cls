VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CProjectedEquationsTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: точная запись отображения рабочего адаптера уравнений
' ==========================================================================
' Повторное читающее отображение служит только записи, без принятия материала.
Implements ICoupledEquationSystem
Private mAdapter As CCoupledConstraintEquations, mOwner As CCoupledNewtonSolver
Private mCalls As Long

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Принимает рабочий адаптер и владельца исходной системы для записи физического поля.
Friend Sub InitializeTest(ByVal adapter As CCoupledConstraintEquations, ByVal owner As CCoupledNewtonSolver)
    Set mAdapter = adapter: Set mOwner = owner: mCalls = 0
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает фактическое число запросов полной невязки независимо от внутренних скалярных итераций.
Friend Property Get EvaluationCallsTest() As Long
    EvaluationCallsTest = mCalls
End Property

' Реализация численного интерфейса сохраняет точное отображение каждой успешной пробы рабочего адаптера.
Private Function ICoupledEquationSystem_TryEvaluate(ByRef coordinates() As Double, ByVal withJacobian As Boolean, _
        ByRef residual() As Double, ByRef jacobian() As Double) As Boolean
    mCalls = mCalls + 1
    Dim equations As ICoupledEquationSystem: Set equations = mAdapter
    If Not equations.TryEvaluate(coordinates, withJacobian, residual, jacobian) Then Exit Function
    Dim mapped() As Double, field() As Double, factor As Double
    If Not mAdapter.TryMap(coordinates, mapped) Then Err.Raise 5, , "Повторное читающее отображение пробы изменилось."
    mOwner.ReadNewtonLineFieldTest mapped, field, factor
    modTestCoupledElasticState.TestRecordYieldProjection coordinates, field, mAdapter.Pivot, _
        modTestCoupledElasticState.TestReadNewtonYieldEvent(field)
    ICoupledEquationSystem_TryEvaluate = True
End Function
