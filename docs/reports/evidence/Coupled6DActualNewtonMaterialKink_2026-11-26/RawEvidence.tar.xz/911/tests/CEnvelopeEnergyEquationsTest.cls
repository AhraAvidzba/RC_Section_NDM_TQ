VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CEnvelopeEnergyEquationsTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ. Управление потреблённой энергией одноосных огибающих CDP
' ==========================================================================
' Сумма энергий огибающих — численная монотонная координата, а не заявленная
' полная термодинамическая диссипация пространственного закона. Силовые строки
' берутся из рабочего ядра без изменений. Пригоден только для CDP и полной
' численной касательной изолированной книги. ASD, приёмка истории и поиск предела здесь отсутствуют.
Implements ICoupledEquationSystem

Private mOwner As CCoupledNewtonSolver, mOperators As CCoupledElasticState
Private mRaw As ICoupledEquationSystem
Private mCentral As CCoupledConcreteResponse, mMinus As CCoupledConcreteResponse, mPlus As CCoupledConcreteResponse
Private mContext As Long, mRevision As Long, mTarget As Double, mRowScale As Double
Private mTensionDensity As Double, mCompressionDensity As Double, mArea() As Double, mTotalArea As Double

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует неизменный контекст и численные веса сформированной бетонной квадратуры.
Friend Sub InitializeTest(ByVal owner As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal central As CCoupledConcreteResponse, ByVal minus As CCoupledConcreteResponse, ByVal plus As CCoupledConcreteResponse, _
        ByVal tensionDensity As Double, ByVal compressionDensity As Double, ByVal rowScale As Double)
    If owner Is Nothing Or operators Is Nothing Or central Is Nothing Or minus Is Nothing Or plus Is Nothing Then _
        Err.Raise 5, "CEnvelopeEnergyEquationsTest", "Передайте ядро, квадратуру и три материальные истории."
    If tensionDensity <= 0# Or compressionDensity <= 0# Or rowScale <= 0# Then _
        Err.Raise 5, "CEnvelopeEnergyEquationsTest", "Плотности энергии и масштаб управляющей строки должны быть положительными."
    Set mOwner = owner: Set mRaw = owner: Set mOperators = operators
    Set mCentral = central: Set mMinus = minus: Set mPlus = plus
    mContext = owner.EquationContext: mRevision = owner.AcceptedRevision
    mTensionDensity = tensionDensity: mCompressionDensity = compressionDensity: mRowScale = rowScale
    ReDim mArea(1 To operators.ConcretePointCount)
    Dim point As Long, x As Double, y As Double
    For point = 1 To UBound(mArea)
        operators.Point point, x, y, mArea(point): mTotalArea = mTotalArea + mArea(point)
    Next point
    If mTotalArea <= 0# Then Err.Raise 5, "CEnvelopeEnergyEquationsTest", "Бетонная квадратура имеет нулевую площадь."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Задаёт абсолютный уровень средней потреблённой энергии огибающих, МПа.
Friend Sub SetTargetTest(ByVal target As Double)
    RequireContextTest
    If target < 0# Then Err.Raise 5, "CEnvelopeEnergyEquationsTest", "Уровень энергии не может быть отрицательным."
    mTarget = target
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Суммирует принятые доли энергии трёх станций, без повторного интегрирования материала.
Friend Function AcceptedEnergyTest() As Double
    RequireContextTest
    Dim point As Long, side As Long, tension As Double, compression As Double, response As CCoupledConcreteResponse
    For point = 1 To UBound(mArea)
        For side = -1 To 1
            Set response = ResponseAtTest(side)
            response.AcceptedPointDamage point, tension, compression
            AcceptedEnergyTest = AcceptedEnergyTest + mArea(point) * _
                (mTensionDensity * tension + mCompressionDensity * compression)
        Next side
    Next point
    AcceptedEnergyTest = AcceptedEnergyTest / (3# * mTotalArea)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает пробные энергии от тех же принятых состояний; ни одна материальная история не записывается.
Friend Function TrialEnergyTest(ByRef field() As Double, ByRef energy As Double) As Boolean
    RequireContextTest
    Dim point As Long, side As Long, component As Long, tension As Double, compression As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double, response As CCoupledConcreteResponse
    energy = 0#
    For point = 1 To UBound(mArea)
        mOperators.PointStrain point, field, strain: mOperators.AxialGradientAtPoint point, field, slope
        For side = -1 To 1
            For component = 1 To 6: station(component) = strain(component) + CDbl(side) * 0.001 * slope(component): Next component
            Set response = ResponseAtTest(side)
            If Not response.TryReadTrialEnvelopeEnergyTest(point, station, tension, compression) Then Exit Function
            energy = energy + mArea(point) * (mTensionDensity * tension + mCompressionDensity * compression)
        Next side
    Next point
    energy = energy / (3# * mTotalArea): TrialEnergyTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет все рабочие уравнения, заменяя лишь управляющую строку монотонной координатой.
Private Function ICoupledEquationSystem_TryEvaluate(ByRef coordinates() As Double, ByVal withJacobian As Boolean, _
        ByRef residual() As Double, ByRef jacobian() As Double) As Boolean
    RequireContextTest
    If withJacobian Then Err.Raise 5, "CEnvelopeEnergyEquationsTest", "Для тестового энергетического управления используйте полную численную касательную."
    If Not mRaw.TryEvaluate(coordinates, False, residual, jacobian) Then Exit Function
    Dim field() As Double, factor As Double, energy As Double
    mOwner.ReadNewtonLineFieldTest coordinates, field, factor
    If Not TrialEnergyTest(field, energy) Then Exit Function
    residual(UBound(residual)) = (energy - mTarget) * mRowScale
    ICoupledEquationSystem_TryEvaluate = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает действующий отклик станции; её знак совпадает с геометрическим полушагом рабочего ядра.
Private Function ResponseAtTest(ByVal side As Long) As CCoupledConcreteResponse
    If side < 0 Then
        Set ResponseAtTest = mMinus
    ElseIf side > 0 Then
        Set ResponseAtTest = mPlus
    Else
        Set ResponseAtTest = mCentral
    End If
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запрещает использование после закрытия контекста или принятия другой материальной истории.
Private Sub RequireContextTest()
    If mOwner Is Nothing Then Err.Raise 5, "CEnvelopeEnergyEquationsTest", "Энергетическая система не подготовлена."
    If Not mOwner.MatchesEquationContext(mContext, mRevision) Then _
        Err.Raise 5, "CEnvelopeEnergyEquationsTest", "Контекст или принятая история энергетической системы изменились."
End Sub
