"""ДЛЯ ТЕСТОВ. Отделяет математическое равновесие трёх проб арматуры от подтверждённого продолжения исходной положительной ветви."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestEnergyChange(root, phase, before=103, after=104):
    """Сравнивает опубликованные доли энергий CDP по тем же точкам и станциям; равенство относится к точности CSV."""
    rows=run_path(str(Path(__file__).resolve().parent/'Validate-TestHardPrepared.py'))['TestRows'](root/('Native/'+phase+'.csv'))
    states={index:{(row[2],row[3]):np.asarray(row[10:12],float) for row in rows
        if row[0]=='S' and int(row[1])==index} for index in (before,after)}
    assert states[before] and states[before].keys()==states[after].keys()
    delta=np.asarray([states[after][key]-value for key,value in states[before].items()])
    return dict(comparison='CDP TensionEnergy/CompressionEnergy ratios, not damage factors',
        stations_times_points=len(delta),maximum_absolute_change=float(np.max(abs(delta))),
        positive_components=int(np.sum(delta>0)),negative_components=int(np.sum(delta<0)),
        unchanged_at_exported_precision=bool(np.all(delta==0)),
        exact_internal_state_equality_claimed=False,physical_failure_criterion=False)


def TestCheck(root,parent):
    """Сохраняет развороты и отрицательные множители как результат опыта; не превращает PASS записи данных в PASS прочности."""
    here=Path(__file__).resolve().parent
    native,_=run_path(str(here/'Check-TestPersistentHEvidence.py'))['TestNative'](root,'PersistentHController')
    assert native['passed']==native['macros']==1 and native['failed']==0 and native['own_process_closed']
    source=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](root/'Input/Reverse1.bin')
    assert len(source['fields'])==103
    assert (root/'Input/Reverse1.bin').read_bytes()==(parent/'Input/Reverse1.bin').read_bytes()
    for name in ('src/Materials/CCoupledReinforcedResponse.cls','src/Solver/CCoupledNewtonSolver.cls'):
        old=(parent/name).read_text('utf-8-sig');new=(root/name).read_text('utf-8-sig')
        assert new.startswith(old),(name,'An existing method was changed')
    read=run_path(str(here/'Check-TestCold86HRecoveryEvidence.py'))['TestVectors']
    validate=run_path(str(here/'Validate-TestHardPrepared.py'))['TestValidate']
    accepted,base_fields=validate(root,'EnvelopeEnergy.Accepted')
    np.testing.assert_allclose(base_fields,source['fields'],rtol=1e-14,atol=1e-300)
    cases=[]
    for index in range(3):
        info,effort,projection,before,field,forces=read(root/('Native/SteelStrain.Case%d.bin'%index),b'NDMSTEELCTRL0001',6)
        assert len(info)==17 and info[0]==index and info[16]==30 and effort[0]<=30
        assert np.array_equal(before,source['fields'][-1]) and info[9]==source['lambdas'][-1]
        assert projection.shape==before.shape and np.all(np.isfinite(projection))
        assert 0<info[5]<info[8]<info[6] and info[7]>0
        roundoff=128*np.finfo(float).eps*(np.sum(abs(projection*before))+abs(info[5]))
        assert abs(projection@before-info[5])<=roundoff
        if index:
            assert info[3]==cases[0]['info'][3] and info[4]==cases[0]['info'][4]
            assert info[5:8].tolist()==cases[0]['info'][5:8]
            np.testing.assert_allclose(info[8]-info[5],(2**index)*(cases[0]['info'][8]-info[5]),rtol=1e-14)
        item=dict(index=index,info=info.tolist(),effort=effort.tolist(),
            solved=bool(info[1]),positive_multiplier=bool(info[10]>0),
            native_forward_geometry=bool(info[11]),physical_capacity_certified=False)
        if info[1]:
            assert len(field)==60 and len(forces)==6
            mechanics,all_fields=validate(root,'SteelStrain.Case%d.Sequence'%index)
            assert len(all_fields)==104
            np.testing.assert_allclose(all_fields[:103],source['fields'],rtol=1e-14,atol=1e-300)
            np.testing.assert_allclose(all_fields[-1],field,rtol=1e-14,atol=1e-300)
            assert all(x['residual_MPa']<=x['bound_MPa'] and x['force_residual_MPa']<=x['bound_MPa'] for x in mechanics['states'])
            actual_control=float(projection@field)
            assert abs(actual_control-info[8])<=mechanics['states'][-1]['bound_MPa']/mechanics['material'][0]+roundoff
            assert abs(actual_control-info[12])<=roundoff
            forward=mechanics['orientation'][-1]
            assert bool(forward['signed_advance']>0)==bool(info[11])
            np.testing.assert_allclose(forward['signed_advance'],info[13],rtol=1e-7,atol=1e-14)
            item.update(independent_equilibrium_104_fields=mechanics,
                cdp_energy_ratio_change=TestEnergyChange(root,'SteelStrain.Case%d.Sequence'%index),
                original_control_and_force_bounds_verified=True,
                continuation_classification=('NonPositiveLambda' if info[10]<=0 else
                    ('UnverifiedSpatialTurn' if not info[11] else 'ForwardCandidateNeedsStepRefinement')))
        else:
            assert field.tolist()==forces.tolist()==[0.]
            item['continuation_classification']='NoVerifiedEquilibrium'
        item['continuation_step_certified']=False
        cases.append(item)
    return dict(native=native,cases=cases,accepted_prefix_independent_equilibrium=accepted,
        mathematical_equilibria=sum(case['solved'] for case in cases),
        positive_forward_candidates=sum(case['solved'] and case['positive_multiplier'] and case['native_forward_geometry'] for case in cases),
        certified_continuation_steps=0,material_laws_and_existing_methods_unchanged=True,
        load_path_unchanged=True,constant_accepted_field_seed=True,
        turning_half_step_validation_not_done=True,full_cold_from_zero=False,
        working_algorithm_not_promoted=True,physical_capacity_certified=False,entire_goal_completed=False)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('root','parent'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();root=args.root.resolve();proof=TestCheck(root,args.parent.resolve())
    (root/'SteelStrainLocalProof.json').write_bytes((json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('STEEL STRAIN LOCAL EQUILIBRIA',proof['mathematical_equilibria'],'FORWARD POSITIVE CANDIDATES',proof['positive_forward_candidates'],
        'CERTIFIED CONTINUATION STEPS0; PHYSICAL CAPACITY OPEN')
