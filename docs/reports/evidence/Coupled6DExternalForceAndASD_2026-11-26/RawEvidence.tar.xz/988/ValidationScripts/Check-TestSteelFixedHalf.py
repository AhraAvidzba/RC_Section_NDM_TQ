"""ДЛЯ ТЕСТОВ. Проверяет реальную104-историю, фиксированную меру второго полушага и отличие конечного корня от прямой пробы."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestCompareStrains(root,phase,coarse,coarse_phase,field,direct,origin):
    """Сравнивает полные деформационные тензоры в согласованной метрике трёх станций; смешанные координаты поля не выдаёт за деформации."""
    read=run_path(str(Path(__file__).resolve().parent/'Validate-TestHardPrepared.py'))['TestRows']
    operators=root/('Native/'+phase+'.Operators.csv')
    assert operators.read_bytes()==(coarse/('Native/'+coarse_phase+'.Operators.csv')).read_bytes()
    records=read(root/('Native/'+phase+'.csv'))
    dimensions=next(row for row in records if row[0]=='DIM')
    dofs,_,points,_=map(int,dimensions[1:5]);half=float(dimensions[5])
    b=np.zeros((points,6,dofs));slope=b.copy();areas=np.zeros(points)
    for kind,*row in read(operators):
        if kind=='P':areas[int(row[0])-1]=float(row[3])
        elif kind=='B':
            p,d=int(row[0])-1,int(row[1])-1
            b[p,:,d]=np.asarray(row[2:8],float);slope[p,:,d]=np.asarray(row[8:],float)
    tensor_weight=np.asarray((1.,1.,1.,.5,.5,.5))
    def TestTensor(values):
        """Инженерные сдвиги получают вес1/2 при двойном свёртывании симметричного тензора."""
        return np.asarray([np.einsum('pcd,d->pc',b+side*half*slope,values) for side in (-1,0,1)])
    def TestLength(values):
        """Повторяет физическую метрику ориентации, независимо суммируя сохранённые геометрические операторы."""
        return float(np.sqrt(np.einsum('spc,spc,p,c->',values,values,areas,tensor_weight)/(3*sum(areas))))
    difference=TestTensor(field-direct);increment=TestTensor(direct-origin)
    length=TestLength(increment);error=TestLength(difference)
    return dict(RMS_tensor_strain_difference=error,maximum_engineering_strain_difference=float(np.max(abs(difference))),
        direct_full_increment_RMS_tensor_strain=length,relative_to_full_increment=error/length if length else None,
        same_operators_verified_exactly=True,auxiliary_constraint_multipliers_excluded=True)


def TestCheck(root,coarse):
    """Независимые уравнения не подменяют интегратор материала; линейная оценка погрешности lambda остаётся нативной диагностикой."""
    here=Path(__file__).resolve().parent
    read=run_path(str(here/'Check-TestCold86HRecoveryEvidence.py'))['TestVectors']
    binary=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary']
    validate=run_path(str(here/'Validate-TestHardPrepared.py'))['TestValidate']
    native,_=run_path(str(here/'Check-TestPersistentHEvidence.py'))['TestNative'](root,'PersistentHController')
    assert native['passed']==native['macros']==1 and native['failed']==0 and native['own_process_closed']
    source=binary(root/'Input/Reverse1.bin');original=binary(root/'Input/Original103Prefix.bin')
    first=read(root/'Input/ActualFirstHalf.bin',b'NDMSTEELCTRL0002',7)
    full=read(root/'Input/DirectCoarseEnd.bin',b'NDMSTEELCTRL0002',7)
    first_proof=json.loads((root/'Input/FirstHalfProof.json').read_bytes())
    assert first_proof['cases'][3]['forward_positive_resolved_candidate']
    assert first_proof['cases'][3]['info']==first[0].tolist()
    assert len(source['fields'])==104 and len(original['fields'])==103
    for name in ('calibration','options','offset','direction'):
        assert np.array_equal(source[name],original[name]),name
    assert np.array_equal(source['fields'][:103],original['fields'])
    assert np.array_equal(source['lambdas'][:103],original['lambdas'])
    assert np.array_equal(source['fractions'][:103],original['fractions'])
    assert np.array_equal(source['fields'][-1],first[5]) and source['lambdas'][-1]==first[0][10]
    assert np.array_equal(source['projection'],first[2]) and np.array_equal(first[2],full[2])
    assert (root/'Input/DirectCoarseEnd.bin').read_bytes()==(coarse/'Native/SteelSeed.Case5.bin').read_bytes()
    prep=json.loads((root/'Preparation.json').read_bytes())
    for name,expected in prep['inputs'].items():
        assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name
    compiled=json.loads((root/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
    assert compiled['Compiled'] and compiled['Modules']==['modTestCoupledElasticState'] and not compiled['ProductionChanged']
    assert sha256((root/'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper()==compiled['WorkbookSHA256']
    assert json.loads((root/'CompileClosure.json').read_bytes())['State']=='Absent'
    accepted,accepted_fields=validate(root,'EnvelopeEnergy.Accepted')
    np.testing.assert_allclose(accepted_fields,source['fields'],rtol=1e-14,atol=1e-300)
    coarse_state,coarse_fields=validate(coarse,'SteelSeed.Case5.Sequence')
    np.testing.assert_allclose(coarse_fields[-1],full[5],rtol=1e-14,atol=1e-300)
    raw=(root/'Input/SteelSeedOptions.bin').read_bytes();n,=struct.unpack('<i',raw[:4])
    assert n==12 and len(raw)==4+8*n
    options=np.asarray(struct.unpack('<12d',raw[4:])).reshape(6,2)
    utilities=run_path(str(here/'Check-TestSteelStrainSeed.py'))
    energies=run_path(str(here/'Check-TestSteelStrainLocal.py'))['TestEnergyChange']
    cases=[];comparison=None
    for index,(target,mode) in enumerate(options):
        info,effort,projection,before,seed,field,forces,solve_effort=read(root/('Native/SteelSeed.Case%d.bin'%index),b'NDMSTEELCTRL0003',8)
        assert len(info)==31 and info[0]==index and info[16]==30 and info[18]==mode and mode in (0,1)
        assert effort[0]==solve_effort[0] and effort[0]<=30 and effort[1]>=solve_effort[1]
        assert np.array_equal(before,source['fields'][-1]) and np.array_equal(projection,source['projection'])
        assert info[3]==full[0][3] and info[4]==full[0][4] and info[6]==full[0][6]
        assert info[8]==target and info[9]==source['lambdas'][-1] and info[30]>=0
        assert np.all(projection[56:]==0) and before.shape==seed.shape==(60,)
        roundoff=128*np.finfo(float).eps*(np.sum(abs(projection*before))+abs(info[5]))
        assert abs(projection@before-info[5])<=roundoff and 0<info[5]<target<info[6]
        step=min(max(info[7],.001*(info[6]-info[5])),.25*(info[6]-info[5]))
        np.testing.assert_allclose(info[17],(target-info[5])/step,rtol=1e-13)
        if mode==0:
            assert np.array_equal(seed,before) and info[19]==0 and info[20]==info[9] and info[25]==0
        else:
            assert info[19]==103
            anchor=source['fields'][-2];old=float(projection@anchor)
            assert abs(info[26]-old)<=roundoff and info[27]==source['lambdas'][-2]
            ratio=(target-info[5])/(info[5]-old)
            np.testing.assert_allclose(info[25],ratio,rtol=1e-9)
            expected=before.copy();expected[:56]+=ratio*(before[:56]-anchor[:56])
            np.testing.assert_allclose(seed,expected,rtol=1e-9,atol=1e-16)
            assert np.array_equal(seed[56:],before[56:])
            np.testing.assert_allclose(info[20],info[9]+ratio*(info[9]-source['lambdas'][-2]),rtol=1e-13)
        item=dict(index=index,info=info.tolist(),effort_after_sensitivity=effort.tolist(),solve_effort_before_sensitivity=solve_effort.tolist(),
            solved=bool(info[1]),native_linearized_lambda_uncertainty_available=bool(info[28]),
            native_linearized_lambda_uncertainty=float(info[29]) if info[28] else None,
            lambda_uncertainty_independently_recomputed=False,fixed_original_control_and_actual_past_seed_verified=True,
            physical_capacity_certified=False,continuation_admission_certified=False)
        if info[1]:
            phase='SteelSeed.Case%d.Sequence'%index
            mechanics,fields=validate(root,phase)
            assert len(fields)==105
            np.testing.assert_allclose(fields[:104],source['fields'],rtol=1e-14,atol=1e-300)
            np.testing.assert_allclose(fields[-1],field,rtol=1e-14,atol=1e-300)
            bound=mechanics['states'][-1]['bound_MPa']/mechanics['material'][0]
            actual=float(projection@field)
            assert abs(actual-target)<=bound+roundoff and abs(actual-info[12])<=roundoff
            direction=mechanics['orientation'][-1]
            assert bool(direction['signed_advance']>0)==bool(info[11])
            np.testing.assert_allclose(direction['signed_advance'],info[13],rtol=1e-7,atol=1e-14)
            assert info[23]==info[24]==1
            h0=utilities['TestEnvelopeFromCSV'](root,phase,104);h1=utilities['TestEnvelopeFromCSV'](root,phase,105)
            np.testing.assert_allclose([info[21],info[22]],[h0,h1],rtol=1e-10,atol=1e-15)
            resolved=actual-info[5]>2*bound+roundoff
            forward=bool(info[10]>0 and info[11] and resolved)
            energy_roundoff=128*np.finfo(float).eps*(abs(h0)+abs(h1))
            material_growth=bool(h1-h0>energy_roundoff)
            item.update(independent_equilibrium_105_fields=mechanics,
                cdp_energy_ratio_change=energies(root,phase,104,105),
                actual_control_growth_resolved_above_two_bounds=bool(resolved),positive_forward_candidate=forward,
                H_growth_resolved_above_floating_roundoff=material_growth,
                positive_forward_with_H_growth=bool(forward and material_growth),
                native_utilization_is_post_sensitivity_diagnostic=True)
            if mode==1 and target==full[0][8]:
                comparison=dict(same_original_control_target=True,
                    full_lambda=float(full[0][10]),two_half_lambda=float(info[10]),
                    lambda_difference=float(info[10]-full[0][10]),
                    maximum_field_difference=float(np.max(abs(field-full[5]))),
                    two_half_endpoint_forward_candidate=forward,
                    two_half_endpoint_H_growth_resolved=material_growth,
                    coarse_lambda_uncertainty_not_measured=True,
                    discretization_accuracy_acceptance_not_yet_defined_or_passed=True,
                    first_half_material_history_really_replayed=True,
                    strain_comparison=TestCompareStrains(root,phase,coarse,'SteelSeed.Case5.Sequence',field,full[5],full[3]),
                    H_difference_MPa=h1-utilities['TestEnvelopeFromCSV'](coarse,'SteelSeed.Case5.Sequence',104),
                    physical_capacity_certified=False)
        else:
            assert field.tolist()==forces.tolist()==[0.]
            item['positive_forward_candidate']=False
            item['positive_forward_with_H_growth']=False
        if info[28]:assert info[29]>=0
        cases.append(item)
    return dict(native=native,cases=cases,accepted_prefix_independent_equilibrium=accepted,
        mathematical_equilibria=sum(case['solved'] for case in cases),
        positive_forward_candidates=sum(case['positive_forward_candidate'] for case in cases),
        positive_forward_with_H_growth=sum(case['positive_forward_with_H_growth'] for case in cases),
        full_vs_two_half=comparison,
        original103_prefix_preserved_exactly=True,first_half104_native_field_preserved_exactly=True,
        fixed_control_from_actual_original_selector=True,material_laws_and_limits_unchanged=True,
        primary_iterations_unchanged=30,working_algorithm_not_promoted=True,certified_continuation_steps=0,
        physical_capacity_certified=False,entire_goal_completed=False,
        option_input_sha256=sha256(raw).hexdigest().upper())


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','coarse'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();root=a.root.resolve();proof=TestCheck(root,a.coarse.resolve())
    (root/'SteelFixedHalfProof.json').write_bytes((json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('FIXED SECOND-HALF EQUILIBRIA',proof['mathematical_equilibria'],'FORWARD CANDIDATES',proof['positive_forward_candidates'],
        'COMPARISON',proof['full_vs_two_half'],'NO CAPACITY CLAIM')
