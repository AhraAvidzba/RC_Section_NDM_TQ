"""ДЛЯ ТЕСТОВ. Независимо проверяет уравнения, реальные прогнозы и направления шести парных проб; максимум прочности не подставляет."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestEnvelopeFromCSV(root,phase,index):
    """Собирает H из опубликованных долей энергий CDP и реальных площадей трёх станций, без вызова VBA."""
    read=run_path(str(Path(__file__).resolve().parent/'Validate-TestHardPrepared.py'))['TestRows']
    rows=read(root/('Native/'+phase+'.csv'))
    law=np.asarray(next(row[1:] for row in rows if row[0]=='LAW'),float)
    concrete=int(next(row[4] for row in rows if row[0]=='DIM'))
    areas={int(row[1]):float(row[4]) for row in read(root/('Native/'+phase+'.Operators.csv'))
        if row[0]=='P' and int(row[1])<=concrete}
    terms=[areas[int(row[3])]*(law[6]*float(row[10])+law[7]*float(row[11]))/law[8]
        for row in rows if row[0]=='S' and int(row[1])==index and int(row[3])<=concrete]
    assert len(terms)==3*concrete
    return sum(terms)/(3*sum(areas.values()))


def TestCheck(root,parent):
    """Различает принятый префикс, математические корни и кандидатов продолжения; направление ещё требует сгущения шага."""
    here=Path(__file__).resolve().parent
    native,_=run_path(str(here/'Check-TestPersistentHEvidence.py'))['TestNative'](root,'PersistentHController')
    assert native['passed']==native['macros']==1 and native['failed']==0 and native['own_process_closed']
    source=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](root/'Input/Reverse1.bin')
    assert len(source['fields'])==103
    assert (root/'Input/Reverse1.bin').read_bytes()==(parent/'Input/Reverse1.bin').read_bytes()
    for name in ('src/Materials/CCoupledReinforcedResponse.cls','src/Solver/CCoupledNewtonSolver.cls'):
        assert (root/name).read_bytes()==(parent/name).read_bytes(),name
    options_raw=(root/'Input/SteelSeedOptions.bin').read_bytes()
    count,=struct.unpack('<i',options_raw[:4]);assert len(options_raw)==4+8*count and count%2==0
    options=np.asarray(struct.unpack('<%dd'%count,options_raw[4:])).reshape(-1,2)
    assert options.shape==(6,2)
    read=run_path(str(here/'Check-TestCold86HRecoveryEvidence.py'))['TestVectors']
    validate=run_path(str(here/'Validate-TestHardPrepared.py'))['TestValidate']
    energies=run_path(str(here/'Check-TestSteelStrainLocal.py'))['TestEnergyChange']
    accepted,base_fields=validate(root,'EnvelopeEnergy.Accepted')
    np.testing.assert_allclose(base_fields,source['fields'],rtol=1e-14,atol=1e-300)
    cases=[];fields_by_case={}
    for index,(target_fraction,mode) in enumerate(options):
        info,effort,projection,before,seed,field,forces=read(root/('Native/SteelSeed.Case%d.bin'%index),b'NDMSTEELCTRL0002',7)
        assert len(info)==28 and info[0]==index and info[16]==30 and effort[0]<=30
        assert info[17]==target_fraction and info[18]==mode
        assert np.array_equal(before,source['fields'][-1]) and info[9]==source['lambdas'][-1]
        assert projection.shape==before.shape==seed.shape==(60,)
        assert np.all(projection[56:]==0) and np.all(np.isfinite(seed))
        assert 0<info[5]<info[8]<info[6] and info[7]>0
        roundoff=128*np.finfo(float).eps*(np.sum(abs(projection*before))+abs(info[5]))
        assert abs(projection@before-info[5])<=roundoff
        step=min(max(info[7],.001*(info[6]-info[5])),.25*(info[6]-info[5]))
        np.testing.assert_allclose(info[8],info[5]+step*target_fraction,rtol=1e-15)
        if mode==0:
            assert np.array_equal(seed,before) and info[19]==0 and info[20]==info[9] and info[25]==0
        else:
            expected_anchor=102
            for anchor in range(102,0,-1):
                if (source['fractions'][anchor-1]==1 and info[9]-source['lambdas'][anchor-1]>
                    64*source['options'][4]*(1+abs(info[9])) and projection@source['fields'][anchor-1]<info[5]):
                    expected_anchor=anchor;break
            assert info[19]==expected_anchor
            anchor_field=source['fields'][expected_anchor-1]
            old=float(projection@anchor_field);old_factor=float(source['lambdas'][expected_anchor-1])
            assert abs(info[26]-old)<=roundoff and info[27]==old_factor
            ratio=(info[8]-info[5])/(info[5]-old)
            np.testing.assert_allclose(info[25],ratio,rtol=1e-9)
            expected=before.copy();expected[:56]+=ratio*(before[:56]-anchor_field[:56])
            np.testing.assert_allclose(seed,expected,rtol=1e-9,atol=1e-16)
            assert np.array_equal(seed[56:],before[56:])
            np.testing.assert_allclose(info[20],info[9]+ratio*(info[9]-old_factor),rtol=1e-13)
        item=dict(index=index,info=info.tolist(),effort=effort.tolist(),solved=bool(info[1]),
            target_fraction=float(target_fraction),seed_mode=int(mode),actual_accepted_seed_verified=True,
            physical_capacity_certified=False,continuation_step_certified=False)
        if info[1]:
            phase='SteelSeed.Case%d.Sequence'%index
            mechanics,all_fields=validate(root,phase)
            assert len(all_fields)==104 and len(forces)==6
            np.testing.assert_allclose(all_fields[:103],source['fields'],rtol=1e-14,atol=1e-300)
            np.testing.assert_allclose(all_fields[-1],field,rtol=1e-14,atol=1e-300)
            actual_control=float(projection@field)
            bound=mechanics['states'][-1]['bound_MPa']/mechanics['material'][0]
            assert abs(actual_control-info[8])<=bound+roundoff and abs(actual_control-info[12])<=roundoff
            orientation=mechanics['orientation'][-1]
            assert bool(orientation['signed_advance']>0)==bool(info[11])
            np.testing.assert_allclose(orientation['signed_advance'],info[13],rtol=1e-7,atol=1e-14)
            assert info[23]==info[24]==1
            h0=TestEnvelopeFromCSV(root,phase,103);h1=TestEnvelopeFromCSV(root,phase,104)
            np.testing.assert_allclose([info[21],info[22]],[h0,h1],rtol=1e-10,atol=1e-15)
            resolved_growth=actual_control-info[5]>2*bound+roundoff
            candidate=bool(info[10]>0 and info[11] and resolved_growth and info[22]>=info[21])
            item.update(independent_equilibrium_104_fields=mechanics,
                original_control_and_force_bounds_verified=True,
                actual_control_growth_resolved_above_two_bounds=bool(resolved_growth),
                cdp_energy_ratio_change=energies(root,phase),independent_H_before=h0,independent_H_after=h1,
                forward_positive_resolved_candidate=candidate,
                continuation_classification=('NonPositiveLambda' if info[10]<=0 else
                    'UnverifiedSpatialTurn' if not info[11] else
                    'UnresolvedControlGrowth' if not resolved_growth else 'ForwardCandidateNeedsStepRefinement'))
            fields_by_case[index]=field
        else:
            assert field.tolist()==forces.tolist()==[0.]
            item.update(continuation_classification='NoVerifiedEquilibrium',forward_positive_resolved_candidate=False)
        cases.append(item)
    pairs=[]
    for index in range(0,len(cases),2):
        item=dict(indices=[index,index+1],target_fraction=cases[index]['target_fraction'],
            both_solved=cases[index]['solved'] and cases[index+1]['solved'])
        if item['both_solved']:
            item.update(lambda_difference=cases[index+1]['info'][10]-cases[index]['info'][10],
                maximum_field_difference=float(np.max(abs(fields_by_case[index+1]-fields_by_case[index]))))
        pairs.append(item)
    return dict(native=native,cases=cases,pairs=pairs,accepted_prefix_independent_equilibrium=accepted,
        mathematical_equilibria=sum(case['solved'] for case in cases),
        forward_positive_resolved_candidates=sum(case['forward_positive_resolved_candidate'] for case in cases),
        certified_continuation_steps=0,material_laws_and_limits_unchanged=True,primary_iterations_unchanged=30,
        turning_step_refinement_not_done=True,working_algorithm_not_promoted=True,
        full_cold_from_zero=False,physical_capacity_certified=False,entire_goal_completed=False,
        option_input_sha256=sha256(options_raw).hexdigest().upper())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('root','parent'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();root=args.root.resolve();proof=TestCheck(root,args.parent.resolve())
    (root/'SteelStrainSeedProof.json').write_bytes((json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('PAIRED SEED EQUILIBRIA',proof['mathematical_equilibria'],'FORWARD RESOLVED CANDIDATES',proof['forward_positive_resolved_candidates'],
        'CERTIFIED CONTINUATION STEPS0; PHYSICAL CAPACITY OPEN')
