"""ДЛЯ ТЕСТОВ. Независимо собирает штатную пространственную меру и отличает влияние прогноза от изменения физики."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestMetric(root):
    """Готовит тензорную метрику по опубликованным B, продольным градиентам и реальным площадям всех точек трёх станций."""
    rows=run_path(str(Path(__file__).resolve().parent/'Validate-TestHardPrepared.py'))['TestRows']
    dims=next(row for row in rows(root/'Native/EnvelopeEnergy.Accepted.csv') if row[0]=='DIM')
    dofs,physical,points,_=map(int,dims[1:5]);half=float(dims[5])
    b=np.zeros((points,6,dofs));slope=b.copy();area=np.zeros(points)
    for kind,*row in rows(root/'Native/EnvelopeEnergy.Accepted.Operators.csv'):
        if kind=='P':area[int(row[0])-1]=float(row[3])
        elif kind=='B':
            p,d=int(row[0])-1,int(row[1])-1
            b[p,:,d]=np.asarray(row[2:8],float);slope[p,:,d]=np.asarray(row[8:],float)
    operators=np.asarray([b+side*half*slope for side in (-1,0,1)])
    weight=np.asarray((1.,1.,1.,.5,.5,.5))
    def TestStrain(field):
        """Служебные множители связей не входят в деформационный прогноз."""
        values=np.asarray(field).copy();values[physical:]=0
        return np.einsum('spcd,d->spc',operators,values)
    def TestLength(field):
        """Среднее двойное свёртывание полного симметричного тензора по трём станциям."""
        values=TestStrain(field)
        return float(np.sqrt(np.einsum('spc,spc,p,c->',values,values,area,weight)/(3*sum(area))))
    def TestProjection(field):
        """Сопряжённая линейная форма берётся непосредственно из тензоров; рабочая девятикомпонентная свёртка не вызывается."""
        strain=TestStrain(field);length=TestLength(field)
        assert length>0
        result=np.einsum('spc,spcd,p,c->d',strain,operators,area,weight)/(3*sum(area)*length)
        result[physical:]=0
        return result
    return physical,TestLength,TestProjection


def TestCheck(root):
    """Проверяет фактические корни без ожидания успеха; прямое приращение геометрической меры отдельно от развития H."""
    here=Path(__file__).resolve().parent
    binary=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary']
    vectors=run_path(str(here/'Check-TestCold86HRecoveryEvidence.py'))['TestVectors']
    validate=run_path(str(here/'Validate-TestHardPrepared.py'))['TestValidate']
    native,_=run_path(str(here/'Check-TestPersistentHEvidence.py'))['TestNative'](root,'PersistentHController')
    assert native['passed']==native['macros']==1 and native['failed']==0 and native['own_process_closed']
    source=binary(root/'Input/Reverse1.bin');original=binary(root/'Input/Original103Prefix.bin')
    assert len(source['fields'])==103 and source['context'][3]==0
    for name in ('fields','fractions','lambdas','calibration','options','offset','direction'):
        assert np.array_equal(source[name],original[name]),name
    prep=json.loads((root/'Preparation.json').read_bytes())
    assert prep['directed_scope']['steel_selector_not_used'] and prep['directed_scope']['stock_spatial_measure_and_nominal_scale']
    for name,expected in prep['inputs'].items():assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name
    accepted,accepted_fields=validate(root,'EnvelopeEnergy.Accepted')
    np.testing.assert_allclose(accepted_fields,source['fields'],rtol=1e-14,atol=1e-300)
    physical,length,project=TestMetric(root)
    before=source['fields'][-1];previous=source['fields'][-2];expected_projection=project(before-previous)
    spacing=length(before-previous);current=source['lambdas'][-1]
    scale_index=None;nominal=spacing
    for i in range(101,-1,-1):
        if source['fractions'][i]!=1:break
        if abs(current-source['lambdas'][i])>64*source['options'][4]*(1+abs(current)):
            scale_index=i+1;nominal=max(nominal,length(before-source['fields'][i]));break
    raw=(root/'Input/SteelSeedOptions.bin').read_bytes();n,=struct.unpack('<i',raw[:4]);assert n==12 and len(raw)==100
    options=np.asarray(struct.unpack('<12d',raw[4:])).reshape(6,2)
    utilities=run_path(str(here/'Check-TestSteelStrainSeed.py'))
    energies=run_path(str(here/'Check-TestSteelStrainLocal.py'))['TestEnergyChange']
    cases=[]
    for index,(fraction,mode) in enumerate(options):
        info,effort,projection,actual_before,seed,field,forces,solve_effort=vectors(root/('Native/SteelSeed.Case%d.bin'%index),b'NDMGEOMCTRL00001',8)
        assert len(info)==33 and info[0]==index and info[18]==mode and mode in (0,2) and info[16]==30 and info[32]==0
        assert effort[0]==solve_effort[0] and effort[0]<=30 and effort[1]>=solve_effort[1]
        assert np.array_equal(actual_before,before) and info[9]==current
        assert np.all(projection[physical:]==0) and projection.shape==before.shape==seed.shape
        pscale=max(float(np.max(abs(expected_projection))),float(np.max(abs(projection))))
        projection_error=float(np.max(abs(expected_projection-projection)))
        assert projection_error<=1e-10*pscale,projection_error/pscale
        np.testing.assert_allclose(info[7],spacing,rtol=1e-10)
        np.testing.assert_allclose(info[31],nominal,rtol=1e-10)
        np.testing.assert_allclose(info[17],fraction,rtol=1e-9)
        roundoff=128*np.finfo(float).eps*(np.sum(abs(projection*before))+abs(info[5]))
        assert abs(projection@before-info[5])<=roundoff and info[8]>info[5]
        assert abs(info[8]-(info[5]+info[31]*fraction))<=roundoff
        if mode==0:
            assert np.array_equal(seed,before) and info[19]==0 and info[20]==current and info[25]==0
        else:
            anchor_index=102
            for i in range(101,-1,-1):
                if (source['fractions'][i]==1 and current-source['lambdas'][i]>64*source['options'][4]*(1+abs(current)) and
                    projection@source['fields'][i]<info[5]):anchor_index=i+1;break
            assert info[19]==anchor_index
            anchor=source['fields'][anchor_index-1];anchor_value=float(projection@anchor)
            ratio=(info[8]-info[5])/(info[5]-anchor_value)
            assert abs(info[26]-anchor_value)<=roundoff and info[27]==source['lambdas'][anchor_index-1]
            np.testing.assert_allclose(info[25],ratio,rtol=1e-9)
            expected=before.copy();expected[:physical]+=ratio*(before[:physical]-anchor[:physical])
            np.testing.assert_allclose(seed,expected,rtol=1e-9,atol=1e-16)
            assert np.array_equal(seed[physical:],before[physical:])
            np.testing.assert_allclose(info[20],current+ratio*(current-info[27]),rtol=1e-13)
        item=dict(index=index,info=info.tolist(),effort_after_sensitivity=effort.tolist(),solve_effort_before_sensitivity=solve_effort.tolist(),
            solved=bool(info[1]),projection_relative_error=projection_error/pscale,
            native_linearized_lambda_uncertainty_available=bool(info[28]),
            native_linearized_lambda_uncertainty=float(info[29]) if info[28] else None,
            geometric_control_has_no_material_failure_limit=True,physical_capacity_certified=False,
            positive_forward_with_H_growth=False)
        if info[1]:
            phase='SteelSeed.Case%d.Sequence'%index
            mechanics,fields=validate(root,phase);assert len(fields)==104
            np.testing.assert_allclose(fields[:103],source['fields'],rtol=1e-14,atol=1e-300)
            np.testing.assert_allclose(fields[-1],field,rtol=1e-14,atol=1e-300)
            actual=float(projection@field);bound=mechanics['states'][-1]['bound_MPa']/mechanics['material'][0]
            assert abs(actual-info[8])<=bound+roundoff and abs(actual-info[12])<=roundoff
            direction=mechanics['orientation'][-1]
            assert bool(direction['signed_advance']>0)==bool(info[11])
            np.testing.assert_allclose(direction['signed_advance'],info[13],rtol=1e-7,atol=1e-14)
            assert info[23]==info[24]==1
            h0=utilities['TestEnvelopeFromCSV'](root,phase,103);h1=utilities['TestEnvelopeFromCSV'](root,phase,104)
            np.testing.assert_allclose([info[21],info[22]],[h0,h1],rtol=1e-10,atol=1e-15)
            h_growth=h1-h0>128*np.finfo(float).eps*(abs(h0)+abs(h1))
            resolved=actual-info[5]>2*bound+roundoff
            item.update(independent_equilibrium_104_fields=mechanics,
                cdp_energy_ratio_change=energies(root,phase),control_growth_resolved_above_two_bounds=bool(resolved),
                H_growth_resolved_above_roundoff=bool(h_growth),
                positive_forward_with_H_growth=bool(info[10]>0 and info[11] and resolved and h_growth))
        else:assert field.tolist()==forces.tolist()==[0.]
        if info[28]:assert info[29]>=0
        cases.append(item)
    return dict(native=native,cases=cases,accepted_prefix_independent_equilibrium=accepted,
        mathematical_equilibria=sum(case['solved'] for case in cases),
        positive_forward_with_H_growth=sum(case['positive_forward_with_H_growth'] for case in cases),
        stock_spatial_projection_verified_independently=True,stock_nominal_scale_anchor=scale_index,
        four_working_methods_exact=json.loads((root/'WorkingSpatialMethods.json').read_bytes()),
        steel_control_not_used=True,working_controller_not_changed=True,
        material_laws_limits_tolerances_and_iterations_unchanged=True,
        certified_continuation_steps=0,physical_capacity_certified=False,entire_goal_completed=False,
        option_input_sha256=sha256(raw).hexdigest().upper())


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True)
    root=p.parse_args().root.resolve();proof=TestCheck(root)
    (root/'SpatialSeedProof.json').write_bytes((json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('STOCK SPATIAL EQUILIBRIA',proof['mathematical_equilibria'],'FORWARD WITH H GROWTH',proof['positive_forward_with_H_growth'],'PHYSICAL CAPACITY OPEN')
