"""ДЛЯ ТЕСТОВ. Проверяет исходные остановки H86, исследовательские методы и строгое87-е равновесие без утверждения предела."""
from argparse import ArgumentParser
from hashlib import sha256
import csv
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestSources(repo, root):
    """Сверяет все255 компонентов и только объявленные изменения каждой фактической частной компиляции."""
    source = Path(__file__).resolve().parent / 'Check-TestGSpatialEvidence.py'
    code = source.read_text('utf-8-sig')
    begin, end = code.index('def TestSources('), code.index('\ndef TestProof(')
    body = code[begin:end]
    begin, end = body.index('    test = '), body.index('    return namespace[')
    test = ['modTestCoupledElasticState']
    expected = dict(Derivatives=[], TRF=[], Native=test, Force=test, Nonmonotone=[], WarmTRF=[],
        NativeNonmonotone=['CCoupledHybridSolver'] + test, Retention=['CCoupledNewtonSolver'] + test, WarmNative=test)
    body = body[:begin] + '    expected = ' + repr(expected) + '\n' + body[end:]
    namespace = run_path(str(source))
    exec(compile(body, str(source), 'exec'), namespace)
    return namespace['TestSources'](repo, root)


def TestVectors(file, signature, count):
    """Читает закрытые Double-векторы, не заменяя их десятичными полями журнала."""
    raw = file.read_bytes()
    assert raw[:16] == signature
    position, values = 16, []
    while position < len(raw):
        n, = struct.unpack_from('<i', raw, position)
        position += 4
        assert 0 < n < 10000
        values.append(np.frombuffer(raw, dtype='<f8', count=n, offset=position).copy())
        position += 8 * n
    assert position == len(raw) and len(values) == count
    assert all(np.all(np.isfinite(v)) for v in values)
    return values


def TestNativeH(root):
    """Статус завершения сценария отделяет от решения каждой цели; изменённая силовой доводкой точка не считается исходным H-корнем."""
    here = Path(__file__).resolve().parent
    native, _ = run_path(str(here / 'Check-TestPersistentHEvidence.py'))['TestNative'](root, 'PersistentHController')
    assert native['failed'] == 0 and native['macros'] == 1
    result, vectors = {}, []
    for i in range(1, 5):
        value = TestVectors(root / ('Native/Cold86HNative.Case%d.bin' % i), b'NDMCOLDHNATIVE01', 8)
        info, scales, initial, x, residual, own, difference, verification = value
        assert len(info) == 16 and len(scales) == len(initial) == len(x) == len(residual) == 61
        assert max(abs(residual)) == info[9] and info[4] == 1.2171338378125574e-6
        assert info[6] <= 30 and info[7] <= 3843 and info[15] == 123
        assert len(verification) == 72 and verification[11] == info[12]
        result[str(i)] = dict(solved=bool(info[5]), iterations=int(info[6]), interface_calls=int(info[7]),
            jacobians=int(info[8]), best_residual_MPa=float(info[9]), tolerance_MPa=float(info[4]),
            stop_code=int(info[10]), seconds=float(info[11]), native_force_verified=bool(verification[0]),
            native_force_field_unchanged=bool(verification[1]), candidate_lambda=float(verification[4]),
            readback_matrix_relative_difference=(float(np.linalg.norm(own - difference) / np.linalg.norm(difference))
                if info[13] == info[14] == 1 else None))
        vectors.append(value)
    return result, vectors


def TestProof(repo, root):
    """Подтверждает локальное продвижение; вычислительный, материальный и полный нормативный предел остаются открытыми."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Check-TestPersistentHEvidence.py'))['TestRestoreAliases'](root)
    sources, _ = TestSources(repo, root)
    cases = root / 'Cases'
    external = run_path(str(here / 'Check-TestEnvelopeFailureEvidence.py'))['TestExternal']
    outcomes = {name: external(cases / name) for name in ('Derivatives', 'TRF', 'Nonmonotone', 'WarmTRF')}
    assert all(not outcomes[name]['native_force_verified'] for name in ('Derivatives', 'TRF', 'Nonmonotone'))
    assert outcomes['WarmTRF']['native_force_verified']
    for name in outcomes:
        assert outcomes[name]['accepted_history_independent_equilibrium']['maximum_lambda'] == 1.10923047413951
    native, original_vectors = TestNativeH(cases / 'Native')
    new_native, new_vectors = TestNativeH(cases / 'NativeNonmonotone')
    assert not any(v['solved'] for v in native.values())
    assert all(np.array_equal(a, b) for a, b in zip(original_vectors[0][1:], new_vectors[0][1:]))
    a, b = original_vectors[0][0].copy(), new_vectors[0][0].copy()
    a[11] = b[11] = 0
    assert np.array_equal(a, b)
    force_state, _ = run_path(str(here / 'Check-TestPersistentHEvidence.py'))['TestNative'](cases / 'Force', 'PersistentHController')
    assert force_state['failed'] == 0
    force = []
    for i in range(1, 5):
        value = TestVectors(cases / 'Force' / ('Native/Cold86ForceGuide.Case%d.bin' % i), b'NDMCOLDFORCE0001', 3)
        info = value[0]
        assert len(info) == 19 and info[5] == 0 and value[1].tolist() == value[2].tolist() == [0.]
        force.append(dict(ratio=float(info[1]), target_lambda=float(info[4]), solved=False,
            iterations=int(info[7]), calls=int(info[8]), best_residual_MPa=float(info[9]), seconds=float(info[6])))
    study = json.loads((cases / 'Nonmonotone/Native/Cold86Nonmonotone.json').read_bytes())
    assert [v['mode'] for v in study['cases']] == ['monotone', 'maximum10', 'average085']
    assert not any(v['strict_residual_reached'] for v in study['cases'])
    assert study['cases'][1]['merit_increases'] > 0 and study['cases'][2]['merit_increases'] > 0
    for entry in study['cases']:
        assert entry['function_calls'] <= 3843 and entry['accepted_iterations'] <= 30
        for row in entry['iterations']:
            assert row['next_merit'] <= row['reference'] + 1e-4 * row['alpha'] * row['directional_derivative']
    derivative = []
    raw = (cases / 'Derivatives/Native/ExternalFTrace.bin').read_bytes()
    dtype = np.dtype([('seq', '<u8'), ('seconds', '<f8'), ('x', '<f8', (61,)), ('f', '<f8', (61,))])
    trace = np.frombuffer(raw, dtype=dtype, offset=20)
    first, position = trace['f'][0], 2
    for step in (1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9):
        plus, minus = trace[position:position + 122:2], trace[position + 1:position + 122:2]
        matrix = ((plus['f'] - minus['f']) / (2 * step)).T
        stored = np.load(cases / 'Derivatives' / ('Native/Cold86H.InitialJacobian.%0.0e.npz' % step))
        assert np.array_equal(matrix, stored['matrix'])
        even = .5 * (plus['f'] + minus['f']) - first
        derivative.append(dict(step=step, rank=int(np.linalg.matrix_rank(matrix)), condition=float(np.linalg.cond(matrix)),
            maximum_even_force_part_MPa=float(max(abs(even[:, :60]).ravel())),
            maximum_even_H_part_MPa=float(max(abs(even[:, -1])))))
        position += 134
    warm = json.loads((cases / 'WarmTRF/Native/ExternalResult.json').read_bytes())
    assert warm['native_warm_initial_residual_bits_exact'] and warm['nds_verified_on_local_forward_energy_step']
    assert np.array_equal(np.asarray(warm['native_verification'])[:3], [1, 1, 1])
    validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
    prefix, prior = validate(cases / 'WarmTRF', 'EnvelopeEnergy.Accepted')
    full, fields = validate(cases / 'WarmTRF', 'ExternalEnvelope.Sequence')
    assert len(fields) == 87 and np.array_equal(fields[:86], prior)
    assert full['orientation'][-1]['signed_advance'] > 0
    assert max(v['residual_MPa'] / v['bound_MPa'] for v in full['states']) < 1
    assert max(v['force_residual_MPa'] / v['bound_MPa'] for v in full['states']) < 1
    origin = np.fromfile(cases / 'WarmTRF/Input/ExpectedInitialResidual.bin', dtype='<f8')
    assert np.array_equal(origin, new_vectors[3][4])
    warm_native, warm_vectors = TestNativeH(cases / 'WarmNative')
    for i, value in enumerate(warm_vectors, 1):
        assert np.array_equal(value[2], origin)
        if value[7][0] == value[7][1] == 1:
            proof, accepted = validate(cases / 'WarmNative', 'Cold86HNative.Case%d.Sequence' % i)
            assert len(accepted) == 87 and np.array_equal(accepted[:86], prior)
            warm_native[str(i)]['independent_equilibrium'] = proof
    retention_native, _ = run_path(str(here / 'Check-TestPersistentHEvidence.py'))['TestNative'](cases / 'Retention', 'PersistentHController')
    assert retention_native['failed'] == 0
    retention = []
    for i in range(1, 3):
        value = TestVectors(cases / 'Retention' / ('Native/Cold86WarmRetention.Case%d.bin' % i), b'NDMCOLDWARMH0001', 4)
        info, effort = value[:2]
        assert len(info) == 14 and effort[0] <= 30
        entry = dict(case=i, solved=bool(info[1]), seconds=float(info[2]), probes=int(info[3]),
            lambda_value=float(info[4]), iterations=float(effort[0]))
        if info[1]:
            proof, accepted = validate(cases / 'Retention', 'Cold86WarmRetention.Case%d.Sequence' % i)
            assert len(accepted) == 87 and np.array_equal(accepted[:86], prior)
            assert info[8] == info[9] == 1 and info[12] <= 1
            assert abs(info[7] - info[6]) * 10000 < proof['states'][-1]['bound_MPa']
            entry['independent_equilibrium'] = proof
        retention.append(entry)
    paper = (root / 'PrimaryLiterature/Zhang-Hager-2004-Nonmonotone.pdf').read_bytes()
    assert sha256(paper).hexdigest().upper() == '765CB81030CE25D5EBB9C4211EE7B74707044CAAFCF4C7AD62BCE0131F46072A'
    return dict(study='cold86-H-recovery', sources=sources, external=outcomes, native=native,
        force_guides=force, nonmonotone=study, native_nonmonotone=new_native,
        default_native_control_vectors_bits_exact=True, derivative_sensitivity=derivative,
        exact_warm_initial_residual=True, warm87_independent_equilibrium=full,
        warm87_original86_prefix_exact=True, native_best_retention=retention, warm_native=warm_native,
        root_existence_demonstrated_on_frozen86_history=True, full_stock_capacity_certified=False,
        historical_peak_reproduced_from_zero=False, numerical_failure_is_physical_failure=False,
        independent_material_integration_completed=False, official_workbook_changed=False,
        working_source_changed=False, entire_goal_completed=False, entire_capacity_certified=False,
        all_loadpaths_verified=False, full_acceptance_completed=False, target10seconds_met=False)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    proof = TestProof(args.repo.resolve(), args.root.resolve())
    (args.root / 'Cold86HRecoveryProof.json').write_bytes((json.dumps(proof, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode())
    print('COLD86 H ROOT EXISTS; EXACT87 EQUILIBRIUM VERIFIED; NATIVE RETENTION CHECKED; CAPACITY OPEN')
