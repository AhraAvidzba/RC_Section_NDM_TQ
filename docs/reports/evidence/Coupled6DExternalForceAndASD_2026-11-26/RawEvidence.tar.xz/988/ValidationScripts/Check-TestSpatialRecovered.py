"""ДЛЯ ТЕСТОВ. Проверяет контракт: возвращённый корень удовлетворяет исходной мере либо явно опубликованной восстановленной мере."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path


def TestCheck(root):
    """Переиспользует независимые уравнения и метрику; исходный контроль не объявляет пройденным после смены меры."""
    source=Path(__file__).resolve().parent/'Check-TestSpatialSeed.py'
    code=source.read_text('utf-8-sig');start=code.index('def TestCheck(root):');end=code.index("\n\nif __name__==",start)
    body=code[start:end].replace('def TestCheck(root):','def TestCheckRecovered(root):',1)
    def TestReplace(before,after):
        """Сохраняет строгие исходные проверки, меняя только известный формат наблюдения и учёт штатного результата восстановления."""
        nonlocal body
        assert body.count(before)==1,before
        body=body.replace(before,after,1)
    TestReplace("assert n==12 and len(raw)==100","assert n>=2 and n%2==0 and len(raw)==4+8*n")
    TestReplace("struct.unpack('<12d',raw[4:])).reshape(6,2)","struct.unpack('<%dd'%n,raw[4:])).reshape(n//2,2)")
    TestReplace('info,effort,projection,actual_before,seed,field,forces,solve_effort=vectors',
        'info,effort,projection,actual_before,seed,field,forces,solve_effort,recovered=vectors')
    TestReplace("b'NDMGEOMCTRL00001',8)","b'NDMGEOMCTRL00002',9)")
    TestReplace('assert len(info)==33','assert len(info)==36')
    TestReplace('        if info[1]:\n            phase=',
        '''        assert info[33] in (0,1) and info[34]>=0 and info[35] in (0,1)
        if info[33]:
            assert info[1] and recovered.shape==before.shape and np.all(recovered[physical:]==0) and np.any(recovered[:physical]!=0)
        else:
            assert recovered.tolist()==[0.]
        item.update(recovered_control_reported=bool(info[33]),recovered_control_uncertainty=float(info[34]) if info[33] else None,
            recovered_control_requires_branch_tangent=bool(info[35]),original_control_target_satisfied=False,
            controller_admission_not_executed=True)
        if info[1]:
            phase=''')
    TestReplace('            assert abs(actual-info[8])<=bound+roundoff and abs(actual-info[12])<=roundoff',
        '''            original_satisfied=abs(actual-info[8])<=bound+roundoff
            assert abs(actual-info[12])<=roundoff
            if not original_satisfied:
                assert info[33], 'Returned candidate misses requested control without declared recovered projection'
            item.update(original_control_target_satisfied=bool(original_satisfied),
                original_control_error=float(abs(actual-info[8])),original_control_bound=float(bound+roundoff),
                classification='RecoveredControlPoint' if info[33] else 'DirectRequestedControl')
            if info[33]:
                prior=float(recovered@previous);old=float(recovered@before);new=float(recovered@field)
                delta=new-old;incoming=old-prior
                item['recovered_measure_coordinates']=dict(previous=prior,accepted=old,candidate=new,
                    incoming_difference=incoming,outgoing_difference=delta)
                item['observed_controller_predicates']=dict(positive_lambda=bool(info[10]>0),
                    lambda_growth_exceeds_existing_resolution=bool(info[10]>current+8*source['options'][4]*(1+abs(current))),
                    lambda_growth_exceeds_reported_recovery_uncertainty=bool(info[10]>current+8*source['options'][4]*(1+abs(current))+info[34]),
                    steel_strain_ratio_within_limit=bool(mechanics['states'][-1]['steel_utilization']<=1),
                    recovered_coordinate_increment_exceeds_1e12_inverse=bool(abs(delta)>1e-12),
                    recovered_measure_retains_incoming_sign=bool(incoming*delta>0))
                item['controller_predicates_not_checked']=['Capacity.MaxLambda bound in current controller',
                    'controller flags and actual ReadSpatialReference selection', 'native TryAdoptRecoveredControl execution']''')
    TestReplace("four_working_methods_exact=json.loads", "key_working_methods_exact=json.loads")
    TestReplace('        mathematical_equilibria=sum(case[\'solved\'] for case in cases),',
        '''        mathematical_equilibria=sum(case['solved'] for case in cases),
        original_requested_control_equilibria=sum(case['solved'] and case['original_control_target_satisfied'] for case in cases),
        recovered_control_equilibria=sum(case['solved'] and case['recovered_control_reported'] for case in cases),
        working_return_contract_observed=True,original_target_not_relabelled_as_satisfied=True,''')
    namespace=run_path(str(source));exec(compile(body,str(source),'exec'),namespace)
    return namespace['TestCheckRecovered'](root)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True)
    root=p.parse_args().root.resolve();proof=TestCheck(root)
    (root/'SpatialSeedProof.json').write_bytes((json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING API CONTRACT OBSERVED; MATHEMATICAL EQUILIBRIA',proof['mathematical_equilibria'],
        'ORIGINAL REQUESTED CONTROL',proof['original_requested_control_equilibria'],
        'RECOVERED CONTROL',proof['recovered_control_equilibria'],'CAPACITY OPEN')
