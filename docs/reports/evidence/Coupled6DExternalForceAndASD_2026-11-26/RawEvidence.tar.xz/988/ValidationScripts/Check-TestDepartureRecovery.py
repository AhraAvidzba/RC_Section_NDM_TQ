"""ДЛЯ ТЕСТОВ. Проверяет настоящий резерв рабочего контроллера, запрет повтора и приёмку104-го состояния по независимым уравнениям."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestCheck(repo,root,reference):
    """Не объявляет узкую инъекцию состояния полноценным холодным Trace или доказанным физическим пределом."""
    here=Path(__file__).resolve().parent
    native,_=run_path(str(here/'Check-TestPersistentHEvidence.py'))['TestNative'](root,'PersistentHController')
    assert native['passed']==native['macros']==1 and native['failed']==0 and native['own_process_closed']
    read=run_path(str(here/'Check-TestCold86HRecoveryEvidence.py'))['TestVectors']
    source=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](root/'Input/Reverse1.bin')
    assert len(source['fields'])==103
    metrics,effort,field,forces,projection=read(root/'Native/DepartureRecovery.bin',b'NDMDEPARTCTL0001',5)
    assert metrics.shape==(15,) and effort.shape==(8,) and field.shape==projection.shape==(60,) and forces.shape==(6,)
    assert all(bool(metrics[index]) for index in (0,2,3,4,5,10,11)) and not bool(metrics[1])
    assert metrics[7]==metrics[8]==1 and metrics[9]==104 and metrics[14]==metrics[13]+1
    assert effort[0]<=30 and metrics[6]>source['lambdas'][-1] and metrics[6]<=source['options'][6]
    assert metrics[12]>=0 and np.all(projection[56:]==0) and np.any(projection[:56]!=0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    assert prep['directed_scope']['main_Trace_loop_not_executed'] and prep['directed_scope']['global_probe_limit_unchanged']==96
    for name,expected in prep['inputs'].items():assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name
    working=(root/'Input/WorkingDepartureController.cls').read_text('utf-8-sig')
    assert working==(repo/'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')
    wrapper=(root/'TestDepartureRecoveryController.cls.txt').read_text('utf-8-sig')
    assert (root/'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')==working+'\n'+wrapper
    compilation=json.loads((root/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
    assert compilation['Compiled'] and not compilation['ProductionChanged']
    assert compilation['Modules']==['CCoupledDeformationContinuation','modTestCoupledElasticState']
    assert sha256((root/'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper()==compilation['WorkbookSHA256']
    assert json.loads((root/'CompileClosure.json').read_bytes())['State']=='Absent'
    validate=run_path(str(here/'Validate-TestHardPrepared.py'))['TestValidate']
    baseline,base_fields=validate(root,'EnvelopeEnergy.Accepted')
    mechanics,fields=validate(root,'DepartureRecovery.Sequence')
    assert len(base_fields)==103 and len(fields)==104
    np.testing.assert_allclose(base_fields,source['fields'],rtol=1e-14,atol=1e-300)
    np.testing.assert_allclose(fields[:103],source['fields'],rtol=1e-14,atol=1e-300)
    np.testing.assert_allclose(fields[-1],field,rtol=1e-14,atol=1e-300)
    assert mechanics['states'][-1]['lambda']==metrics[6]
    rows=run_path(str(here/'Validate-TestHardPrepared.py'))['TestRows']
    matrix=np.zeros((60,6))
    for kind,*row in rows(root/'Native/DepartureRecovery.Sequence.Operators.csv'):
        if kind=='L':matrix[:,int(row[0])-1]=np.asarray(row[1:],float)
    assert np.linalg.matrix_rank(matrix)==6
    force_error=float(np.max(abs((matrix@(forces-source['offset']-metrics[6]*source['direction']))[:56])))
    assert force_error<=mechanics['states'][-1]['bound_MPa']
    utilities=run_path(str(here/'Check-TestSteelStrainSeed.py'))
    h0=utilities['TestEnvelopeFromCSV'](root,'DepartureRecovery.Sequence',103)
    h1=utilities['TestEnvelopeFromCSV'](root,'DepartureRecovery.Sequence',104)
    assert h1>h0 and mechanics['orientation'][-1]['signed_advance']>0
    incoming=float(projection@(source['fields'][-1]-source['fields'][-2]))
    outgoing=float(projection@(field-source['fields'][-1]))
    assert incoming*outgoing>0 and abs(outgoing)>1e-12
    old=read(reference/'Native/SteelSeed.Case0.bin',b'NDMGEOMCTRL00002',9)
    assert np.array_equal(old[3],source['fields'][-1])
    comparison=dict(lambda_difference=float(metrics[6]-old[0][10]),
        field_byte_equal=bool(np.array_equal(field,old[5])),
        maximum_field_difference=float(np.max(abs(field-old[5]))),
        projection_byte_equal=bool(np.array_equal(projection,old[8])))
    return dict(native=native,metrics=metrics.tolist(),effort=effort.tolist(),
        initial103_independent_equilibrium=baseline,accepted104_independent_equilibrium=mechanics,
        copied_resultants_equation_error_MPa=force_error,
        working_source_and_private_wrapper_checked_separately=True,
        one_probe_only=True,repeated_attempt_rejected=True,repeated_attempt_left_candidate_exactly_unchanged=True,
        revision_changed_only_on_acceptance=True,ordinary_adoption_and_spatial_checks_executed=True,
        accepted_H_before=h0,accepted_H_after=h1,incoming_recovered_coordinate=incoming,outgoing_recovered_coordinate=outgoing,
        comparison_with_direct_recovered_API_probe=comparison,
        injected_post_H_state=True,main_Trace_loop_executed=False,
        main_loop_accepted_recovery_counter_not_exercised=True,
        original_global96_and_primary30_preserved=True,
        cold_from_zero_not_verified=True,full_regressions_not_run=True,release_book_unchanged=True,
        physical_capacity_certified=False,entire_goal_completed=False)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','reference'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();root=a.root.resolve();proof=TestCheck(a.repo.resolve(),root,a.reference.resolve())
    (root/'DepartureRecoveryProof.json').write_bytes((json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING RESERVE/ADOPTION VERIFIED; ONE PROBE; REPEAT GUARD/REVISION/104EQUILIBRIA VERIFIED; FULL TRACE/CAPACITY OPEN')
