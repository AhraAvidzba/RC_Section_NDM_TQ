"""ДЛЯ ТЕСТОВ. Добавляет уменьшение шага внутри одного прохода с неизменной историей и общим бюджетом30, включая отвергнутые попытки."""
from pathlib import Path
from runpy import run_path
from hashlib import sha256
import json

here=Path(__file__).resolve().parent;base=Path('D:/CodexScratch/RC_Section_NDM_TQ')
parent=base/'Cold985GrowingLoadingHistory_20261126';root=base/'Cold986AdaptiveLoadingHistory_20261126'
proof=json.loads((parent/'AcceptedLoadingHistoryProof.json').read_bytes())
assert proof['accepted_steps']==5 and proof['all_accepted_states_idempotent']
assert proof['stages'][-1]['independent_acceptance_checks']['equilibria'] and not proof['stages'][-1]['independent_acceptance_checks']['field_pair_error']
run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
ancestor=root/'AdaptiveHistoryCompilationAncestor';ancestor.mkdir()
for name in ('CompilePoint.log','CompilePointClosure.json'):(root/name).rename(ancestor/name)
name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
begin=code.index('Public Function TestRunAcceptedLoadingHistory()');end=code.index('\nEnd Function',begin)
body=code[begin:end]
changes={
    'не более 16 шагов с удвоением при расходе не более половины бюджета':'не более 64 шагов с ростом и уменьшением шага в общем бюджете30',
    '    For stage = 1 To 16':'''    Dim retryHandle As Integer: retryHandle = FreeFile
    Open savedRoot & "\\Native\\LoadingRetries.bin" For Binary Access Write As #retryHandle
    magic = "NDMLOADRETRY0001": Put #retryHandle, , magic
    TestWriteReverseBinaryVector retryHandle, Array(30#, 8#, 64#)
    Dim pathsHandle As Integer: pathsHandle = FreeFile
    Open savedRoot & "\\Native\\LoadingPairPaths.txt" For Output As #pathsHandle
    Dim retries As Long, allRetries As Long, carried As Long, relativeFolder As String
    For stage = 1 To 64
        retries = 0: carried = 0''',
    '        TestWriteLoadingStateTest savedRoot & "\\Native\\HistoryStateBefore." & CStr(stage) & ".bin"':'''        TestWriteLoadingStateTest savedRoot & "\\Native\\HistoryStateBefore." & CStr(stage) & ".bin"
TestReadAdaptivePair:
        relativeFolder = "."
        If mPolishRootTest <> savedRoot Then relativeFolder = Mid$(mPolishRootTest, Len(savedRoot) + 2)
        Print #pathsHandle, CStr(stage) & ";" & CStr(retries) & ";" & relativeFolder''',
    '        TestWriteReverseBinaryVector handle, Array(1#, stage, revision, reference, Abs(CLng(pairReady)), total, length, shapeError, _':'''        If Not gate And pairReady And shapeError > 0.005 And total <= CLng(meta(8)) - 2 And retries < 8 Then
            TestWriteReverseBinaryVector retryHandle, Array(stage, retries, carried, total, reference, fullInfo(7), halfInfo(7), _
                length, shapeError, lambdaError, noise, baseline, coordinate, resolution, advance, oldLength)
            TestWriteReverseBinaryVector retryHandle, accepted: TestWriteReverseBinaryVector retryHandle, full
            TestWriteReverseBinaryVector retryHandle, half
            carried = total: retries = retries + 1: allRetries = allRetries + 1
            child = savedRoot & "\\Native\\Retry" & Format$(stage, "00") & "." & Format$(retries, "00")
            TestPrepareLoadingRetryTest meta, accepted, projection, half, halfInfo, reference, carried, child
            mPolishRootTest = child: report = TestRunHistoryMaterialPair()
            GoTo TestReadAdaptivePair
        End If
        TestWriteReverseBinaryVector handle, Array(1#, stage, revision, reference, Abs(CLng(pairReady)), total, length, shapeError, _''',
    'Or stage = 16 Then Exit For':'Or stage = 64 Then Exit For',
    '        predictionScale = 1#: If total <= CLng(meta(8)) \\ 2 Then predictionScale = 2#':
        '        predictionScale = 1#: If retries = 0 And total <= CLng(meta(8)) \\ 2 Then predictionScale = 2#',
    '    Close #handle: handle = 0\n    mPolishRootTest = savedRoot: mReverseSolverTest.DiscardStep':'''    Close #handle: handle = 0
    TestWriteReverseBinaryVector retryHandle, Array(0#, allRetries, mReverseSolverTest.AcceptedRevision)
    Close #retryHandle: retryHandle = 0: Close #pathsHandle: pathsHandle = 0
    mPolishRootTest = savedRoot: mReverseSolverTest.DiscardStep''',
    '    If handle <> 0 Then Close #handle':'''    If handle <> 0 Then Close #handle
    If retryHandle <> 0 Then Close #retryHandle
    If pathsHandle <> 0 Then Close #pathsHandle''',
}
for old,new in changes.items():assert body.count(old)==1,old;body=body.replace(old,new,1)
code=code[:begin]+body+code[end:]
begin=code.index('Public Function TestRunHistoryMaterialPair()');end=code.index('\nEnd Function',begin)
body=code[begin:end];anchor='    Dim total As Long, budget As Long, startFactor As Double, fullFactor As Double, fullField() As Double, fullReady As Boolean'
assert body.count(anchor)==1
body=body.replace(anchor,anchor+'''
    If Len(Dir$(mPolishRootTest & "\\Input\\MaterialPairSpent.bin")) > 0 Then
        Dim spentHandle As Integer: spentHandle = FreeFile
        Open mPolishRootTest & "\\Input\\MaterialPairSpent.bin" For Binary Access Read As #spentHandle
        Dim spent As Variant: spent = TestReadPolishVector(spentHandle)
        If Seek(spentHandle) <> LOF(spentHandle) + 1 Or UBound(spent) <> 1 Then Err.Raise 5, , "Неверный учёт потраченных итераций."
        Close #spentHandle
        If spent(1) < 0# Or spent(1) >= meta(8) Or spent(1) <> Fix(spent(1)) Then Err.Raise 5, , "Некорректный остаток общего бюджета."
        total = CLng(spent(1))
    End If''',1)
code=code[:begin]+body+code[end:]
helper=(here/'TestPrepareLoadingRetry.bas.txt').read_text('utf-8-sig').rstrip()
anchor='Public Function TestRunMaterialDirectionAudit() As String';assert code.count(anchor)==1
code=code.replace(anchor,helper+'\n\n'+anchor,1)
updates={name:code.replace('\n','\r\n').encode('utf-8-sig'),
    'Compile-TestExternalPoint.ps1':(here/'Compile-TestExternalPoint.ps1').read_bytes(),
    'ParentCodeUpdate.json':(parent/'docs/regression/CodeUpdate.json').read_bytes(),
    'ParentCompileClosure.json':(parent/'CompilePointClosure.json').read_bytes(),Path(__file__).name:Path(__file__).read_bytes(),
    'TestPrepareLoadingRetry.bas.txt':(helper+'\n').replace('\n','\r\n').encode('utf-8-sig')}
prep=json.loads((root/'Preparation.json').read_bytes())
for name,data in updates.items():
    if name.endswith('.bas'):assert max(map(len,data.decode('utf-8-sig').splitlines()))<1024
    (root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
prep['directed_scope']=dict(case='AdaptiveGrowingAndReducingLoadingHistory',actual_import_this_pass=['modTestCoupledElasticState'],actual_component_count=257,
    all256_numerical_components_exact985=True,only_test_adaptive_step_driver_and_shared_budget_input=True,
    original_materials_load_path_tolerances_and_half_gate_preserved=True,rejected_attempt_iterations_counted_inside_original30=True,
    maximum64_accepted_steps_and8_reductions_per_step=True,no_future_equilibrium_field_input=True,physical_capacity_certified=False)
(root/'Preparation.json').write_text(json.dumps(prep,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(root,'ADAPTIVE STEP;ALL REJECTIONS SHARE30;UNCHANGED MATERIAL/EQUILIBRIUM/HALF/H/COMMIT GATES')
