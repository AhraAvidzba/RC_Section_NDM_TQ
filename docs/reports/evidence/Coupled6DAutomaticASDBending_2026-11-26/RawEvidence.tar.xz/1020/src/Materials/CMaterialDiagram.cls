VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CMaterialDiagram"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ==========================================================================
' Универсальная кусочно-линейная диаграмма материала
' ==========================================================================
' Хранит точки зависимости напряжения от деформации во внутренних единицах:
' деформация безразмерная, напряжение в МПа. Вычисляет напряжение,
' касательный и секущий модули по заданной деформации.
' Нормативный выбор сопротивлений, типа диаграммы и растянутой ветви бетона
' выполняет CMaterialModelProvider до передачи диаграммы решателю равновесия.

Private mStrains() As Double ' Узлы диаграммы по деформации, отсортированные от сжатия к растяжению.
Private mStresses() As Double ' Напряжения в узлах диаграммы, МПа во внутренней системе.
Private mSegmentTangent() As Double ' Заранее рассчитанный наклон каждого линейного участка диаграммы, МПа.
Private mSegmentIntercept() As Double ' Свободный член sigma = E_t * epsilon + b для быстрого расчета stress.
Private mTransitionStrains() As Double, mTransitionCount As Long ' Деформации изменения наклона и их число; опорные точки прямого продолжения не создают переломов.
Private mPointCount As Long ' Количество активных точек диаграммы.
Private mInitialized As Boolean ' Защита от вызова расчетных методов до загрузки точек.
Private mFrozen As Boolean ' Признак завершённой общей диаграммы; её точки и пределы после передачи в расчёт изменять нельзя.
Private mPhysicalCompressionStrain As Double ' Физический сжатый предел; extension-точки его не меняют.
Private mPhysicalTensionStrain As Double ' Физический растянутый предел, если у диаграммы есть растянутая ветвь.
Private mHasPhysicalTensionLimit As Boolean ' False для диаграмм, где растянутый бетон принят с нулевым сопротивлением без eps-лимита.
Private mHasCompressionExtension As Boolean ' True, если слева от физического сжатого предела добавлена техническая область.
Private mHasTensionExtension As Boolean ' True, если справа от физического растянутого предела добавлена техническая область.
Private mCompressionExtensionStartStrain As Double ' Деформация, за которой сжатая ветвь переходит на вспомогательное численное продолжение.
Private mTensionExtensionStartStrain As Double ' Деформация, за которой растянутая ветвь переходит на вспомогательное численное продолжение.
Private Const RANGE_TOLERANCE As Double = 0.000000000001 ' Малый допуск для сравнения деформаций с границами диаграммы.

' ------------------------------
' Инициализация
' ------------------------------
' Загружает готовые массивы точек диаграммы. Provider передает сюда уже
' рассчитанные и знаково оформленные координаты: сжатие в проекте имеет
' отрицательную деформацию и отрицательное напряжение, растяжение - положительное.
Public Sub InitializeFromArrays(ByRef strains() As Double, ByRef stresses() As Double, ByVal pointCount As Long, _
        Optional ByVal physicalCompressionStrain As Variant, Optional ByVal physicalTensionStrain As Variant, _
        Optional ByVal hasCompressionExtension As Boolean = False, Optional ByVal hasTensionExtension As Boolean = False, _
        Optional ByVal compressionExtensionStartStrain As Variant, Optional ByVal tensionExtensionStartStrain As Variant)
    If mFrozen Then Err.Raise vbObjectError + 3114, "CMaterialDiagram.InitializeFromArrays", _
        "Опубликованная диаграмма материала не может быть изменена. Для другой модели создайте новую диаграмму через CMaterialModelProvider."
    On Error GoTo Failed
    mInitialized = False ' Ошибочная повторная загрузка не оставляет доступным материал из другой инициализации.
    mPointCount = 0
    If pointCount < 2 Then Err.Raise vbObjectError + 3100, "CMaterialDiagram", "Диаграмма материала должна содержать не менее двух точек."
    ValidateInputArray strains, pointCount, "деформаций"
    ValidateInputArray stresses, pointCount, "напряжений"

    ReDim mStrains(1 To pointCount)
    ReDim mStresses(1 To pointCount)

    Dim i As Long
    For i = 1 To pointCount
        mStrains(i) = strains(i)
        mStresses(i) = stresses(i)
    Next i

    SortPointsByStrain
    ValidatePointOrder
    mPointCount = pointCount
    If IsMissing(physicalCompressionStrain) Then
        mPhysicalCompressionStrain = mStrains(1)
    Else
        mPhysicalCompressionStrain = CDbl(physicalCompressionStrain)
    End If
    If IsMissing(physicalTensionStrain) Then
        mPhysicalTensionStrain = IIf(mStrains(mPointCount) > 0#, mStrains(mPointCount), 0#)
    Else
        mPhysicalTensionStrain = CDbl(physicalTensionStrain)
    End If
    mHasPhysicalTensionLimit = (mPhysicalTensionStrain > 0#)
    mHasCompressionExtension = hasCompressionExtension
    mHasTensionExtension = hasTensionExtension
    If IsMissing(compressionExtensionStartStrain) Then
        mCompressionExtensionStartStrain = mPhysicalCompressionStrain
    Else
        mCompressionExtensionStartStrain = CDbl(compressionExtensionStartStrain)
    End If
    If IsMissing(tensionExtensionStartStrain) Then
        mTensionExtensionStartStrain = mPhysicalTensionStrain
    Else
        mTensionExtensionStartStrain = CDbl(tensionExtensionStartStrain)
    End If
    BuildSegmentCache
    mInitialized = True
    Exit Sub
Failed:
    Dim errorNumber As Long, errorSource As String, errorDescription As String
    errorNumber = Err.Number
    errorSource = Err.Source
    errorDescription = Err.Description
    mInitialized = False
    mPointCount = 0
    Erase mStrains
    Erase mStresses
    Erase mSegmentTangent
    Erase mSegmentIntercept
    Err.Raise errorNumber, errorSource, errorDescription
End Sub

' Завершает диаграмму и запрещает изменение её точек и пределов. До этого
' самостоятельный объект можно заполнить заново; подготовка материалов
' для нового набора параметров создаёт отдельный объект диаграммы.
Friend Sub Freeze()
    EnsureInitialized
    mFrozen = True
End Sub

' Подтверждает, что точки и пределы этой диаграммы больше не меняются.
' Решатель может использовать сохранённую оценку при точно тех же исходных данных.
Friend Property Get IsFrozen() As Boolean
    IsFrozen = mFrozen
End Property

' Проверяет наличие всех используемых индексов до копирования точек.
' Дополнительные индексы за пределами 1..pointCount допустимы и не читаются.
Private Sub ValidateInputArray(ByRef values() As Double, ByVal pointCount As Long, ByVal valueName As String)
    On Error GoTo InvalidArray
    If LBound(values) > 1 Then GoTo InvalidArray
    If UBound(values) < pointCount Then GoTo InvalidArray
    Exit Sub
InvalidArray:
    On Error GoTo 0
    Err.Raise vbObjectError + 3113, "CMaterialDiagram", _
        "Массив " & valueName & " диаграммы не содержит все точки с индексами от 1 до " & CStr(pointCount) & "."
End Sub

' ------------------------------
' Доступ к расчетным пределам диаграммы
' ------------------------------
' Возвращает физическую предельную деформацию сжатия для инженерных
' проверок. Техническая крайняя точка продолжения диаграммы ее не изменяет.
Public Property Get UltimateCompressionStrain() As Double
    EnsureInitialized
    UltimateCompressionStrain = mPhysicalCompressionStrain
End Property

' Возвращает физическую предельную деформацию растяжения, без технического
' продолжения. Если растянутая ветвь не работает, предел равен нулю и не
' участвует в инженерной проверке.
Public Property Get UltimateTensionStrain() As Double
    EnsureInitialized
    If mHasPhysicalTensionLimit Then UltimateTensionStrain = mPhysicalTensionStrain
End Property

' Возвращает физический сжатый предел диаграммы. Если provider добавил
' техническую extension-точку, это свойство все равно остается на реальном eps_ult.
Public Property Get PhysicalCompressionStrain() As Double
    EnsureInitialized
    PhysicalCompressionStrain = mPhysicalCompressionStrain
End Property

' Возвращает физический растянутый предел, если он есть. Для бетона с
' отключенным растяжением предела нет: положительная деформация означает
' неработающую растянутую зону, а не автоматический выход в extension.
Public Property Get PhysicalTensionStrain() As Double
    EnsureInitialized
    PhysicalTensionStrain = mPhysicalTensionStrain
End Property

' False для диаграмм, где растянутый бетон принят с нулевым сопротивлением без eps-лимита.
Public Property Get HasPhysicalTensionLimit() As Boolean
    EnsureInitialized
    HasPhysicalTensionLimit = mHasPhysicalTensionLimit
End Property

' True, если слева от физического сжатого предела добавлена техническая область.
Public Property Get HasCompressionExtension() As Boolean
    EnsureInitialized
    HasCompressionExtension = mHasCompressionExtension
End Property

' True, если справа от физического растянутого предела добавлена техническая область.
Public Property Get HasTensionExtension() As Boolean
    EnsureInitialized
    HasTensionExtension = mHasTensionExtension
End Property

' Проверяет, остается ли деформация в физической области диаграммы.
' Отсутствие растянутого предела трактуется как неработающая растянутая зона
' с нулевым сопротивлением, поэтому положительные eps в этом случае допустимы.
Public Function IsInPhysicalRange(ByVal strain As Double) As Boolean
    EnsureInitialized
    If strain < mPhysicalCompressionStrain - RANGE_TOLERANCE Then Exit Function
    If mHasPhysicalTensionLimit Then
        If strain > mPhysicalTensionStrain + RANGE_TOLERANCE Then Exit Function
    End If
    IsInPhysicalRange = True
End Function

' True означает, что деформация вышла за физический eps_ult именно в ту
' техническую область, которую provider добавил для равновесного solve.
' Горизонтальное физическое плато до eps_ult не считается extension: оно
' остается допустимой частью диаграммы материала и не должно давать FAIL.
Public Function IsInExtensionRange(ByVal strain As Double) As Boolean
    EnsureInitialized
    If mHasCompressionExtension And strain < mPhysicalCompressionStrain - RANGE_TOLERANCE Then
        IsInExtensionRange = True
    ElseIf mHasTensionExtension And mHasPhysicalTensionLimit And _
            strain > mPhysicalTensionStrain + RANGE_TOLERANCE Then
        IsInExtensionRange = True
    End If
End Function

' ------------------------------
' Напряжения по деформациям
' ------------------------------
' Возвращает напряжение при заданной деформации. Разрешённое численное
' продолжение сохраняет наклон крайнего участка при любой конечной деформации.
' Без продолжения за крайними точками остаётся постоянное напряжение.
Public Function StressAtStrain(ByVal strain As Double) As Double
    EnsureInitialized

    If strain <= mStrains(1) Then
        StressAtStrain = mStresses(1)
        If mHasCompressionExtension Then StressAtStrain = mStresses(1) + (strain - mStrains(1)) * mSegmentTangent(1)
    ElseIf strain >= mStrains(mPointCount) Then
        StressAtStrain = mStresses(mPointCount)
        If mHasTensionExtension Then StressAtStrain = mStresses(mPointCount) + _
            (strain - mStrains(mPointCount)) * mSegmentTangent(mPointCount - 1)
    Else
        Dim segmentIndex As Long
        segmentIndex = FindSegmentIndex(strain)
        If segmentIndex > 0 Then StressAtStrain = mSegmentTangent(segmentIndex) * strain + mSegmentIntercept(segmentIndex)
    End If
End Function

' Подтверждает единственную аффинную ветвь во всём интервале деформаций.
' Использует фактические подготовленные коэффициенты; переходы и граничные узлы не сглаживает.
Friend Function TryLinearStressRange(ByVal low As Double, ByVal high As Double, ByRef slope As Double, ByRef intercept As Double) As Boolean
    EnsureInitialized
    If low > high Then Exit Function
    If high < mStrains(1) Then
        slope = 0#: If mHasCompressionExtension Then slope = mSegmentTangent(1)
        intercept = mStresses(1) - slope * mStrains(1)
    ElseIf low > mStrains(mPointCount) Then
        slope = 0#: If mHasTensionExtension Then slope = mSegmentTangent(mPointCount - 1)
        intercept = mStresses(mPointCount) - slope * mStrains(mPointCount)
    Else
        If low <= mStrains(1) Or high >= mStrains(mPointCount) Then Exit Function
        Dim first As Long, last As Long
        first = FindSegmentIndex(low): last = FindSegmentIndex(high)
        If first < 1 Or first <> last Then Exit Function
        slope = mSegmentTangent(first): intercept = mSegmentIntercept(first)
    End If
    TryLinearStressRange = True
End Function

' Возвращает напряжение по деформации через общий material API решателей.
Public Function GetStress(ByVal strain As Double) As Double
    GetStress = StressAtStrain(strain)
End Function

' Возвращает наклон текущего участка. За опорной точкой численное продолжение
' сохраняет свой наклон; у диаграммы без продолжения там нулевой модуль.
Public Function GetTangentModulus(ByVal strain As Double) As Double
    EnsureInitialized
    If strain < mStrains(1) Then
        If mHasCompressionExtension Then GetTangentModulus = mSegmentTangent(1)
        Exit Function
    ElseIf strain > mStrains(mPointCount) Then
        If mHasTensionExtension Then GetTangentModulus = mSegmentTangent(mPointCount - 1)
        Exit Function
    End If
    Dim segmentIndex As Long
    segmentIndex = FindSegmentIndex(strain)
    If segmentIndex > 0 Then GetTangentModulus = mSegmentTangent(segmentIndex)
End Function

' Возвращает напряжение и касательный модуль за один проход по отрезкам.
' В горячих циклах CSectionSolver это убирает два независимых поиска одного
' и того же участка диаграммы для каждого бетонного волокна и стержня.
Public Sub EvaluateAtStrain(ByVal strain As Double, ByRef stress As Double, ByRef tangent As Double)
    EnsureInitialized

    If strain < mStrains(1) Then
        stress = mStresses(1)
        tangent = 0#
        If mHasCompressionExtension Then
            tangent = mSegmentTangent(1)
            stress = mStresses(1) + (strain - mStrains(1)) * tangent
        End If
    ElseIf strain > mStrains(mPointCount) Then
        stress = mStresses(mPointCount)
        tangent = 0#
        If mHasTensionExtension Then
            tangent = mSegmentTangent(mPointCount - 1)
            stress = mStresses(mPointCount) + (strain - mStrains(mPointCount)) * tangent
        End If
    Else
        Dim segmentIndex As Long
        segmentIndex = FindSegmentIndex(strain)
        If segmentIndex > 0 Then
            tangent = mSegmentTangent(segmentIndex)
            stress = mSegmentTangent(segmentIndex) * strain + mSegmentIntercept(segmentIndex)
        End If
    End If
End Sub

' Возвращает секущий модуль stress/strain; около нуля используется касательный
' модуль, чтобы не делить на почти нулевую деформацию.
Public Function GetSecantModulus(ByVal strain As Double) As Double
    EnsureInitialized
    If Abs(strain) <= 0.000000000001 Then
        GetSecantModulus = GetTangentModulus(strain)
    Else
        GetSecantModulus = StressAtStrain(strain) / strain
    End If
End Function

' Подготавливает быстрые коэффициенты линейных участков диаграммы.
Private Sub BuildSegmentCache()
    Dim i As Long
    ReDim mSegmentTangent(1 To mPointCount - 1)
    ReDim mSegmentIntercept(1 To mPointCount - 1)

    For i = 1 To mPointCount - 1 ' Для каждого участка диаграммы заранее вычисляем наклон и свободный член. При многократной проверке бетонных элементов и стержней решатель использует эти значения без повторного вычисления.
        mSegmentTangent(i) = (mStresses(i + 1) - mStresses(i)) / (mStrains(i + 1) - mStrains(i))
        mSegmentIntercept(i) = mStresses(i) - mSegmentTangent(i) * mStrains(i)
    Next i
    ReDim mTransitionStrains(1 To mPointCount)
    mTransitionCount = 0
    Dim leftSlope As Double, rightSlope As Double
    For i = 1 To mPointCount
        leftSlope = 0#: rightSlope = 0#
        If i > 1 Then leftSlope = mSegmentTangent(i - 1)
        If i < mPointCount Then rightSlope = mSegmentTangent(i)
        If i = 1 And mHasCompressionExtension Then leftSlope = rightSlope
        If i = mPointCount And mHasTensionExtension Then rightSlope = leftSlope
        If leftSlope <> rightSlope Then ' Продолжение с тем же наклоном не создаёт нового перехода между участками диаграммы.
            mTransitionCount = mTransitionCount + 1
            mTransitionStrains(mTransitionCount) = mStrains(i)
        End If
    Next i
End Sub

' Находит два ближайших перехода между участками диаграммы при заданном
' приращении деформации. Использует подготовленные наклоны, сохраняя
' порядок узлов и правила вычисления расстояний до перехода.
Friend Sub CollectStrainTransitions(ByVal strain As Double, ByVal delta As Double, _
        ByRef first As Double, ByRef second As Double)
    EnsureInitialized
    If delta = 0# Then Exit Sub
    Dim i As Long, distance As Double
    For i = 1 To mTransitionCount
        distance = (mTransitionStrains(i) - strain) / delta ' Безразмерная доля заданного приращения, на которой поле достигнет перелома диаграммы.
        If distance > 0# And strain + distance * delta <> strain Then
            If first = 0# Or distance < first Then
                second = first: first = distance
            ElseIf distance > first Then
                If second = 0# Or distance < second Then second = distance
            End If
        End If
    Next i
End Sub

' Находит участок диаграммы, которому принадлежит заданная деформация.
Private Function FindSegmentIndex(ByVal strain As Double) As Long
    Dim i As Long
    For i = 1 To mPointCount - 1
        If strain >= mStrains(i) And strain <= mStrains(i + 1) Then
            If mHasCompressionExtension And strain = mCompressionExtensionStartStrain Then ' В исходном первом физическом узле действовал правый участок. Новая техническая точка слева не меняет этот выбор касательной.
                If strain = mStrains(i + 1) And i + 1 < mPointCount Then
                    FindSegmentIndex = i + 1
                    Exit Function
                End If
            End If
            FindSegmentIndex = i
            Exit Function
        End If
    Next i
End Function

' Сортирует точки по деформации, чтобы provider мог добавлять их в удобном
' инженерном порядке, а расчет всегда шел по монотонной оси strain.
Private Sub SortPointsByStrain()
    Dim i As Long
    Dim j As Long
    For i = 1 To UBound(mStrains) - 1
        For j = i + 1 To UBound(mStrains)
            If mStrains(j) < mStrains(i) Then SwapPoints i, j
        Next j
    Next i
End Sub

' Меняет местами две точки при сортировке.
Private Sub SwapPoints(ByVal firstIndex As Long, ByVal secondIndex As Long)
    Dim tmp As Double
    tmp = mStrains(firstIndex)
    mStrains(firstIndex) = mStrains(secondIndex)
    mStrains(secondIndex) = tmp
    tmp = mStresses(firstIndex)
    mStresses(firstIndex) = mStresses(secondIndex)
    mStresses(secondIndex) = tmp
End Sub

' Проверяет, что после сортировки нет повторяющихся деформаций. Две разные
' точки с одинаковым strain дали бы вертикальный участок и бесконечный модуль.
Private Sub ValidatePointOrder()
    Dim i As Long
    For i = 1 To UBound(mStrains) - 1
        If mStrains(i + 1) <= mStrains(i) Then
            Err.Raise vbObjectError + 3111, "CMaterialDiagram", "Деформации в диаграмме материала не должны повторяться."
        End If
    Next i
End Sub

' Проверяет, что диаграмма уже получила точки.
Private Sub EnsureInitialized()
    If Not mInitialized Then Err.Raise vbObjectError + 3112, "CMaterialDiagram", "Диаграмма материала не инициализирована."
End Sub

' Количество активных точек диаграммы.
Public Property Get PointCount() As Long
    PointCount = mPointCount
End Property

' Копирует использованные точки и физические пределы для сохранённого НДС.
' physicalOnly исключает только явно добавленные точки численного продолжения;
' физические точки и напряжения не пересчитываются.
Public Function Clone(Optional ByVal physicalOnly As Boolean = False) As CMaterialDiagram
    EnsureInitialized
    Dim strains() As Double, stresses() As Double, first As Long, last As Long, i As Long, count As Long
    first = 1: last = mPointCount
    If physicalOnly And mHasCompressionExtension Then first = first + 1
    If physicalOnly And mHasTensionExtension Then last = last - 1
    count = last - first + 1
    ReDim strains(1 To count): ReDim stresses(1 To count)
    For i = 1 To count
        strains(i) = mStrains(first + i - 1): stresses(i) = mStresses(first + i - 1)
    Next i
    Dim result As CMaterialDiagram: Set result = New CMaterialDiagram
    result.InitializeFromArrays strains, stresses, count, mPhysicalCompressionStrain, mPhysicalTensionStrain, _
        mHasCompressionExtension And Not physicalOnly, mHasTensionExtension And Not physicalOnly, _
        mCompressionExtensionStartStrain, mTensionExtensionStartStrain
    result.Freeze
    Set Clone = result
End Function

' Возвращает деформацию точки диаграммы по номеру для записи Results и построения моделей
' материалов.
Public Function PointStrain(ByVal index As Long) As Double
    EnsureInitialized
    If index < 1 Or index > mPointCount Then Err.Raise vbObjectError + 3109, "CMaterialDiagram", "Индекс точки диаграммы вне диапазона." & " Запрошен номер " & CStr(index) & "; доступно элементов: " & CStr(mPointCount) & "."
    PointStrain = mStrains(index)
End Function

' Возвращает напряжение точки диаграммы по номеру для записи Results и построения моделей
' материалов.
Public Function PointStress(ByVal index As Long) As Double
    EnsureInitialized
    If index < 1 Or index > mPointCount Then Err.Raise vbObjectError + 3110, "CMaterialDiagram", "Индекс точки диаграммы вне диапазона." & " Запрошен номер " & CStr(index) & "; доступно элементов: " & CStr(mPointCount) & "."
    PointStress = mStresses(index)
End Function

' ==========================================================================
' ДЛЯ ТЕСТОВ
' ==========================================================================

' -------------------- ДЛЯ ТЕСТОВ --------------------
' короткие способы задания диаграммы для проверок интерполяции без Excel и Config.
' В рабочем расчёте CMaterialModelProvider создаёт диаграмму через InitializeFromArrays.
Public Sub TestInitializeFromTwoCompressionPoints(ByVal eps1 As Double, ByVal stress1 As Double, _
        ByVal eps2 As Double, ByVal stress2 As Double)
    Dim strains(1 To 3) As Double
    Dim stresses(1 To 3) As Double

    If eps1 >= 0# Or eps2 >= 0# Then Err.Raise vbObjectError + 3101, "CMaterialDiagram", "Сжатые деформации должны быть отрицательными."
    If stress1 >= 0# Or stress2 >= 0# Then Err.Raise vbObjectError + 3102, "CMaterialDiagram", "Сжатые напряжения должны быть отрицательными."

    strains(1) = eps2: stresses(1) = stress2
    strains(2) = eps1: stresses(2) = stress1
    strains(3) = 0#: stresses(3) = 0#
    InitializeFromArrays strains, stresses, 3
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' создает сжатую трехучастковую диаграмму с нулевой точкой.
Public Sub TestInitializeFromThreeCompressionPoints(ByVal eps1 As Double, ByVal stress1 As Double, _
        ByVal eps2 As Double, ByVal stress2 As Double, ByVal eps3 As Double, ByVal stress3 As Double)
    Dim strains(1 To 4) As Double
    Dim stresses(1 To 4) As Double

    If eps1 >= 0# Or eps2 >= 0# Or eps3 >= 0# Then Err.Raise vbObjectError + 3103, "CMaterialDiagram", "Сжатые деформации должны быть отрицательными."
    If stress1 >= 0# Or stress2 >= 0# Or stress3 >= 0# Then Err.Raise vbObjectError + 3104, "CMaterialDiagram", "Сжатые напряжения должны быть отрицательными."

    strains(1) = eps3: stresses(1) = stress3
    strains(2) = eps2: stresses(2) = stress2
    strains(3) = eps1: stresses(3) = stress1
    strains(4) = 0#: stresses(4) = 0#
    InitializeFromArrays strains, stresses, 4
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' создает симметричную растянутую двухточечную диаграмму.
Public Sub TestInitializeFromTwoTensionPoints(ByVal eps1 As Double, ByVal stress1 As Double, _
        ByVal eps2 As Double, ByVal stress2 As Double)
    Dim strains(1 To 5) As Double
    Dim stresses(1 To 5) As Double

    If eps1 <= 0# Or eps2 <= eps1 Then Err.Raise vbObjectError + 3105, "CMaterialDiagram", "Растянутые деформации должны возрастать и быть положительными."
    If stress1 <= 0# Or stress2 <= 0# Then Err.Raise vbObjectError + 3106, "CMaterialDiagram", "Растянутые напряжения должны быть положительными."

    strains(1) = -eps2: stresses(1) = -stress2
    strains(2) = -eps1: stresses(2) = -stress1
    strains(3) = 0#: stresses(3) = 0#
    strains(4) = eps1: stresses(4) = stress1
    strains(5) = eps2: stresses(5) = stress2
    InitializeFromArrays strains, stresses, 5
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' создает симметричную растянутую трехточечную диаграмму.
Public Sub TestInitializeFromThreeTensionPoints(ByVal eps1 As Double, ByVal stress1 As Double, _
        ByVal eps2 As Double, ByVal stress2 As Double, ByVal eps3 As Double, ByVal stress3 As Double)
    Dim strains(1 To 7) As Double
    Dim stresses(1 To 7) As Double

    If eps1 <= 0# Or eps2 <= eps1 Or eps3 <= eps2 Then Err.Raise vbObjectError + 3107, "CMaterialDiagram", "Растянутые деформации должны возрастать и быть положительными."
    If stress1 <= 0# Or stress2 <= 0# Or stress3 <= 0# Then Err.Raise vbObjectError + 3108, "CMaterialDiagram", "Растянутые напряжения должны быть положительными."

    strains(1) = -eps3: stresses(1) = -stress3
    strains(2) = -eps2: stresses(2) = -stress2
    strains(3) = -eps1: stresses(3) = -stress1
    strains(4) = 0#: stresses(4) = 0#
    strains(5) = eps1: stresses(5) = stress1
    strains(6) = eps2: stresses(6) = stress2
    strains(7) = eps3: stresses(7) = stress3
    InitializeFromArrays strains, stresses, 7
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' задаёт простую диаграмму сжатия или растяжения.
' Если передано stress2, строится сжатая ветвь. Иначе stress1 задаёт плато растяжения.
Public Sub TestInitialize(ByVal eps1 As Double, ByVal stress1 As Double, ByVal eps2 As Double, _
        Optional ByVal stress2 As Variant)
    If IsMissing(stress2) Then
        TestInitializeFromTwoTensionPoints eps1, stress1, eps2, stress1
    Else
        TestInitializeFromTwoCompressionPoints eps1, stress1, eps2, CDbl(stress2)
    End If
End Sub
