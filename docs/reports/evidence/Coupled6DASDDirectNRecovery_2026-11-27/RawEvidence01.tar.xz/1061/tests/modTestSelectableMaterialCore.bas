﻿Attribute VB_Name = "modTestSelectableMaterialCore"
Option Explicit

Private mMainCapacityFolderTest As String
Private mMainCapacityLoadTest(1 To 6) As Double
Private mMainCapacityPathTest As Long

' ==========================================================================
' ДЛЯ ТЕСТОВ: выбор пространственного закона и общая калибровка в рабочем ядре
' ==========================================================================
' Проверяет переключение CDP/ASD, разные наборы характеристик и материальную
' историю ASD. Малые нагрузки проверяют подключение, а не предельную прочность.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает фактический выбор из сохранённой книги через штатный reader.
Public Function TestReadSelectableConcreteLaw() As String
    Dim reader As New CSystemSettingsReader
    reader.LoadFromWorkbook ThisWorkbook: reader.LoadCoupledSettings ThisWorkbook
    TestReadSelectableConcreteLaw = reader.GetString("Coupled.ConcreteLaw", "CDP")
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выполняет восемь направленных НДС и сохраняет материальные тензоры для внешнего повторения.
Public Function TestRunSelectableMaterialCore(ByVal folder As String) As String
    On Error GoTo Failed
    Dim handle As Integer: handle = FreeFile
    Open folder & "\Native\SelectableCore.bin" For Binary Access Write As #handle
    Dim magic As String * 16: magic = "NDMLAWSEL0000001": Put #handle, , magic
    Dim calibration As New CCoupledConcreteCalibration, flow As CCoupledASDFlow
    calibration.Initialize 30000#, 16#, 30#, 3#, 0.002, 0.12, 80#, 125#
    Set flow = calibration.CreateASDFlow(0.2, True)
    If flow.LawIdentifier <> "ASD-NativeStep-Cdf0" Then Err.Raise 5, , "Не выбран однократный ASD."
    TestWriteVector handle, Array(30000#, 0.2, 16#, 30#, 3#)
    TestWriteBranch handle, calibration.TensionEnvelope, 0#
    TestWriteBranch handle, calibration.CompressionEnvelope, 1#
    Dim concrete As New CCoupledConcreteResponse, response As ICoupledPointResponse
    concrete.InitializeASD 1, flow: Set response = concrete
    Dim strain(1 To 6) As Double, stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim value As Variant
    TestWriteVector handle, Array(9#)
    For Each value In Array(0.00002, 0.00005, 0.0001, 0.0002, 0.0005, 0.001, 0.002, 0.004, 0.01)
        strain(3) = CDbl(value): strain(1) = -0.2 * strain(3): strain(2) = strain(1)
        strain(4) = 0.03 * strain(3): strain(5) = 0.1 * strain(3): strain(6) = -0.05 * strain(3)
        If response.EvaluatePoint(1, strain, stress, tangent, ctmStressOnly) <> sfcNone Then _
            Err.Raise 5, , "Отказ материальной пробы рабочего ASD."
        TestWriteVector handle, strain: TestWriteVector handle, stress
        response.AcceptTrial
    Next value
    Dim geometry As CGeometryRegion, mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder
    Set geometry = TestFixtureBox(180#, 120#): mesh.BuildMesh geometry, 18#, 12#, cellGeometry:="Contour"
    Dim section As CSectionModel: Set section = builder.BuildFromGenerated(mesh, Nothing): geometry.BuildContours section.Contours
    section.AddRebarElement 0#, -30#, 12#, GEOM_PI * 36#, "A400"
    section.AddRebarElement 0#, 30#, 12#, GEOM_PI * 36#, "A400"
    Dim layout As New CTransverseRebarLayout: layout.AddContourGroup section, "TestLawHoop", "", 8#, 100#, 10#, "A240"
    Dim c As New CConcreteMaterialParameters, s As New CSteelMaterialParameters, provider As New CMaterialModelProvider
    c.Initialize 30#, 3#, 40#, 4#, 30000#, 35000#, rbMc2:=15#
    s.Initialize 350#, 400#, 350#, 400#, 200000#, 200000#: provider.TestInitializeFromParameters c, s
    Dim hoop As New CCoupledSteelModel, grades As Object, supplementary As Object
    hoop.Initialize 200000#, 240#, 240#, 500#, 500#, 0.02, 0.02
    Set grades = CreateObject("Scripting.Dictionary"): grades.Add "A240", hoop
    Set supplementary = CreateObject("Scripting.Dictionary"): supplementary.Add "ULS(I)", grades: supplementary.Add "SLS(II)", grades
    Dim law As Variant, model As Long, caseIndex As Long, analysis As New CCoupledSectionAnalysis
    Dim spec As New CMaterialModelSpec, loads As New CSectionLoadState, meta As CResultMeta, state As CSectionStateResult
    Dim field() As Double, actual() As Double, target(1 To 6) As Double, started As Double, elapsed As Double, j As Long
    TestWriteVector handle, Array(8#)
    For Each law In Array("CDP", "ASD")
        model = model + 1
        analysis.Initialize section, layout, provider, 0.2, 0.12, 80#, 125#, 16# / 30#, 0.002, "A400", 30, supplementary, concreteLaw:=CStr(law)
        For caseIndex = 1 To 4
            Erase target
            If caseIndex = 1 Or caseIndex = 4 Then target(2) = 500000#
            If caseIndex = 2 Then target(4) = 100000#
            If caseIndex = 3 Then
                target(1) = 1000#: target(2) = 500000#: target(3) = 100000#
                target(4) = 100000#: target(5) = 200#: target(6) = -100#
            End If
            If caseIndex = 4 Then spec.Initialize "SLS(II)", "ThreeLine", "UseDiagram", "TwoLine" Else spec.Initialize "ULS(I)", "ThreeLine", "UseDiagram", "TwoLine"
            loads.Initialize target(1), target(2), target(3), 0#, 0#: loads.SetSpatialComponents target(4), target(5), target(6)
            started = Timer
            Set meta = analysis.SolveTarget(loads, "Auto", spec, field, actual, True, state)
            elapsed = Timer - started: If elapsed < 0# Then elapsed = elapsed + 86400#
            If meta.InternalStatus <> rsSuccess And meta.InternalStatus <> rsSuccessWithWarning Then _
                Err.Raise 5, , CStr(law) & ", случай " & CStr(caseIndex) & ": " & meta.ResultComment & " " & meta.DiagnosticDetails
            If state Is Nothing Then Err.Raise 5, , "Не сохранено подтверждённое НДС выбранного закона."
            If (law = "CDP" And state.CoupledMaterialCurves.ConcreteLawIdentifier <> "Barcelona-CDP") Or _
                    (law = "ASD" And state.CoupledMaterialCurves.ConcreteLawIdentifier <> "ASD-NativeStep-Cdf0") Then _
                Err.Raise 5, , "Диаграммы не соответствуют выбранному закону."
            For j = 1 To 6
                If Abs(actual(j) - target(j)) > IIf(j >= 2 And j <= 4, 0.1 * 180#, 0.1) Then _
                    Err.Raise 5, , "Неверная результирующая выбранного закона."
            Next j
            TestWriteVector handle, Array(model, caseIndex, elapsed)
            TestWriteVector handle, target: TestWriteVector handle, actual: TestWriteVector handle, field
        Next caseIndex
    Next law
    Dim invalidNumber As Long
    On Error Resume Next
    analysis.Initialize section, layout, provider, 0.2, 0.12, 80#, 125#, 16# / 30#, 0.002, "A400", 30, supplementary, concreteLaw:="UnknownLaw"
    invalidNumber = Err.Number: Err.Clear
    On Error GoTo Failed
    If invalidNumber <> 5 Then Err.Raise 5, , "Не отклонён неизвестный закон бетона."
    Close #handle: handle = 0
    TestRunSelectableMaterialCore = "SELECTABLE_CORE: both laws; pure bending, torsion, mild all6 and alternate value set; physical capacity not tested" & vbCrLf & _
        "TOTAL_SELECTABLE_MATERIAL_CORE: passed=1; failed=0"
    Exit Function
Failed:
    Dim reason As String: reason = Err.Source & " " & Err.Description
    If handle <> 0 Then Close #handle
    TestRunSelectableMaterialCore = "RUNTIME ERROR: " & reason
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает полную подготовленную ветвь, включая фактический нижний уровень интерполяции.
Private Sub TestWriteBranch(ByVal handle As Integer, ByVal envelope As CCoupledConcreteEnvelope, ByVal code As Double)
    Dim branch As CCoupledConcreteBackbone: Set branch = envelope.PrepareASDBackbone(30000#)
    Dim strain() As Double, stress() As Double, nominal As Double, effective As Double, i As Long
    branch.CopyCurve 1#, strain, stress
    TestWriteVector handle, Array(code, UBound(strain), branch.StressFloor)
    For i = 1 To UBound(strain)
        branch.Stresses strain(i), nominal, effective
        TestWriteVector handle, Array(strain(i), nominal, effective)
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет число и точные Double без форматирования и округления.
Private Sub TestWriteVector(ByVal handle As Integer, ByVal values As Variant)
    Dim count As Long: count = UBound(values) - LBound(values) + 1
    Put #handle, , count
    Dim i As Long, value As Double
    For i = LBound(values) To UBound(values)
        value = CDbl(values(i)): Put #handle, , value
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прослеживает шесть усилий по выбранной траектории; успешное исполнение макроса не заменяет физическую проверку.
Public Function TestRunASDSpatialMainCapacity(ByVal folder As String) As String
    On Error GoTo Failed
    mMainCapacityFolderTest = folder
    Dim testInput As Integer, testCount As Long, testIndex As Long: testInput = FreeFile
    Open folder & "\Input\CapacityLoad.bin" For Binary Access Read As #testInput
    Get #testInput, , testCount
    If testCount <> 6 Then Err.Raise 5, , "Для контроля передайте шесть внутренних усилий."
    For testIndex = 1 To 6: Get #testInput, , mMainCapacityLoadTest(testIndex): Next testIndex
    Get #testInput, , mMainCapacityPathTest: Close #testInput
    Dim geometry As CGeometryRegion, mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    Set geometry = TestFixtureBox(180#, 120#): mesh.BuildMesh geometry, 18#, 12#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing): geometry.BuildContours section.Contours
    section.AddRebarElement 0#, -30#, 12#, GEOM_PI * 36#, "A400"
    section.AddRebarElement 0#, 30#, 12#, GEOM_PI * 36#, "A400"
    Dim layout As New CTransverseRebarLayout: layout.AddContourGroup section, "TestASDCapacityHoop", "", 8#, 100#, 10#, "A240"
    Dim c As New CConcreteMaterialParameters, s As New CSteelMaterialParameters, provider As New CMaterialModelProvider
    c.Initialize 30#, 3#, 30#, 3#, 30000#, 30000#, rbMc2:=15#
    s.Initialize 350#, 400#, 350#, 400#, 200000#, 200000#, 0.018, 0.025
    provider.TestInitializeFromParameters c, s, "ThreeLine", "UseDiagram", "TwoLine", diagramExtensionEnabled:=False, plateauSlopeFactor:=0.0075
    Dim hoop As New CCoupledSteelModel, grades As Object, supplementary As Object
    hoop.Initialize 200000#, 240#, 240#, 1500#, 1500#, 0.02, 0.02
    Set grades = CreateObject("Scripting.Dictionary"): grades.Add "A240", hoop
    Set supplementary = CreateObject("Scripting.Dictionary"): supplementary.Add "ULS(I)", grades
    Dim analysis As New CCoupledSectionAnalysis, spec As New CMaterialModelSpec, loads As New CSectionLoadState
    analysis.Initialize section, layout, provider, 0.2, 0.12, 80#, 125#, 16# / 30#, 0.002, "A400", 30, supplementary, concreteLaw:="ASD"
    spec.Initialize "ULS(I)", "ThreeLine", "UseDiagram", "TwoLine"
    loads.Initialize mMainCapacityLoadTest(1), mMainCapacityLoadTest(2), mMainCapacityLoadTest(3), 0#, 0#
    loads.SetSpatialComponents mMainCapacityLoadTest(4), mMainCapacityLoadTest(5), mMainCapacityLoadTest(6)
    Dim pathKey As String, pathNames As Variant
    pathNames = Array("Auto", "N", "Mx", "My", "T", "Qx", "Qy", "All6")
    If mMainCapacityPathTest < 0 Or mMainCapacityPathTest > 7 Then Err.Raise 5, , "Неизвестная траектория контрольного расчёта."
    If mMainCapacityPathTest = 0 Then pathKey = "Auto" Else pathKey = ChrW$(&H3BB) & "*" & pathNames(mMainCapacityPathTest)
    Dim capacity As CCapacityResult, trace As CCoupledLoadTrace, started As Double, elapsed As Double
    started = Timer
    Set capacity = analysis.SolveCapacity(loads, pathKey, spec, 1#, 100#, 0.001, 30, trace)
    elapsed = Timer - started: If elapsed < 0# Then elapsed = elapsed + 86400#
    Dim handle As Integer: handle = FreeFile
    Open folder & "\Native\MainCapacity.bin" For Binary Access Write As #handle
    Dim magic As String * 16: magic = "NDMMAINCAP000001": Put #handle, , magic
    TestWriteVector handle, Array(elapsed, Abs(CLng(capacity.HasUltimatePoint)), capacity.LambdaCapacity, _
        Abs(CLng(capacity.HasSteelLimitPoint)), capacity.CoupledLimitLambda, capacity.PeakLambda, capacity.PeakAccuracy, _
        Abs(CLng(capacity.HasConfirmedLowerBound)), capacity.ConfirmedLowerLambda, capacity.MxUltimate)
    Dim index As Long, offset As Double, factor As Double
    If trace Is Nothing Then
        TestWriteVector handle, Array(0#)
    Else
        TestWriteVector handle, Array(trace.Count)
        For index = 1 To trace.Count
            trace.ReadPoint index, offset, factor: TestWriteVector handle, Array(offset, factor)
        Next index
    End If
    Close #handle: handle = 0
    Dim diagnostic As String
    diagnostic = "Status=" & capacity.Status & "; LimitState=" & capacity.LimitState & "; Method=" & capacity.SolutionMethod & vbCrLf & _
        "Comment=" & capacity.ResultMeta.ResultComment & vbCrLf & "Details=" & capacity.ResultMeta.DiagnosticDetails & vbCrLf & _
        "DiagnosticLog=" & capacity.DiagnosticLog & vbCrLf & "LastSolver=" & capacity.LastSolverDiagnosticLog
    Dim stream As Object: Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2: stream.Charset = "utf-8": stream.Open
    stream.WriteText diagnostic: stream.SaveToFile folder & "\Native\MainCapacity.txt", 2: stream.Close
    TestRunASDSpatialMainCapacity = "MAIN_ASD_CAPACITY: seconds=" & CStr(elapsed) & "; status=" & capacity.Status & _
        "; lambda=" & CStr(capacity.LambdaCapacity) & "; steel_lambda=" & CStr(capacity.CoupledLimitLambda) & _
        "; physical_acceptance_not_implied_by_test_execution=True" & vbCrLf & "TOTAL_MAIN_ASD_CAPACITY_EXECUTION: passed=1; failed=0"
    Exit Function
Failed:
    Dim reason As String: reason = Err.Source & " " & Err.Description
    If handle <> 0 Then Close #handle
    TestRunASDSpatialMainCapacity = "RUNTIME ERROR: " & reason
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет точные принятые поля и операторы без проб материалов и без изменения истории решателя.
Public Sub TestCaptureMainCapacity(ByVal controlled As CCoupledDeformationContinuation, ByVal operators As CCoupledElasticState, ByVal loadPath As CLoadPathVector)
    Dim history As Collection, trace As CCoupledLoadTrace
    Set history = controlled.AcceptedFields: Set trace = controlled.SavedTrace
    If history Is Nothing Or trace Is Nothing Then Err.Raise 5, , "Не сохранена история контрольного продолжения."
    If history.Count <> trace.Count Then Err.Raise 5, , "История полей и трасса множителей имеют разную длину."
    TestWriteHardPreparedOperators operators, mMainCapacityFolderTest & "\Native\MainCapacity.Operators.csv"
    Dim handle As Integer: handle = FreeFile
    Open mMainCapacityFolderTest & "\Native\MainCapacityHistory.bin" For Binary Access Write As #handle
    Dim magic As String * 16: magic = "NDMMAINHIST00003": Put #handle, , magic
    Dim area As Double, length As Double: operators.CopyResultantResidualScales area, length
    TestWriteVector handle, Array(operators.DegreeCount, operators.PointCount, operators.ConcretePointCount, area, length, 0.001, 0.0000005, 0.0000005)
    Dim offset() As Double, direction() As Double: loadPath.Components offset, direction
    TestWriteVector handle, offset: TestWriteVector handle, direction
    TestWriteVector handle, Array(history.Count)
    Dim index As Long, fraction As Double, factor As Double, field() As Double
    For index = 1 To history.Count
        trace.ReadPoint index, fraction, factor: field = history.Item(index)
        TestWriteVector handle, Array(fraction, factor): TestWriteVector handle, field
    Next index
    Close #handle
End Sub


' -------------------- ДЛЯ ТЕСТОВ --------------------
Private Sub TestWriteHardPreparedOperators(ByVal operators As CCoupledElasticState, ByVal path As String)
    Dim handle As Integer: handle = FreeFile
    Open path For Output As #handle
    Dim size As Long: size = operators.DegreeCount
    Dim field() As Double, zeroLoad() As Double, residual() As Double, matrix() As Double, vector() As Double
    Dim strain(1 To 6) As Double, gradient(1 To 6) As Double, projection(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, resultants(1 To 6) As Double
    Dim point As Long, degree As Long, component As Long, x As Double, y As Double, weight As Double
    ReDim field(1 To size): ReDim zeroLoad(1 To size)
    For degree = 1 To size
        field(degree) = 1#: operators.StartEquations field, zeroLoad, residual, matrix, False
        Print #handle, "G;" & CStr(degree) & TestHardPreparedVector(residual)
        For point = 1 To operators.PointCount
            operators.PointStrain point, field, strain: operators.AxialGradientAtPoint point, field, gradient
            Print #handle, "B;" & CStr(point) & ";" & CStr(degree) & TestHardPreparedVector(strain) & TestHardPreparedVector(gradient)
        Next point
        field(degree) = 0#
    Next degree
    For component = 1 To 6
        ReDim vector(1 To 6): vector(component) = 1#
        operators.LoadEquations vector(1), vector(2), vector(3), vector(4), vector(5), vector(6), residual
        Print #handle, "L;" & CStr(component) & TestHardPreparedVector(residual)
    Next component
    For point = 1 To operators.PointCount
        operators.Point point, x, y, weight
        Print #handle, "P;" & CStr(point) & ";" & TestOnsetNumber(x) & ";" & TestOnsetNumber(y) & ";" & TestOnsetNumber(weight)
        If point > operators.ConcretePointCount Then
            operators.SteelProjection point, projection
            Print #handle, "A;" & CStr(point) & TestHardPreparedVector(projection)
        End If
        For component = 1 To 6: gradient(component) = 0#: Next component
        For component = 1 To 6
            ReDim residual(1 To size): stress(component) = 1#
            operators.AddSpatialPointEquilibrium point, stress, tangent, gradient, tangent, tangent, residual, matrix, False, resultants
            Print #handle, "W;" & CStr(point) & ";" & CStr(component) & TestHardPreparedVector(residual)
            stress(component) = 0#: gradient(component) = 1#: ReDim residual(1 To size)
            operators.AddSpatialPointEquilibrium point, stress, tangent, gradient, tangent, tangent, residual, matrix, False, resultants
            Print #handle, "V;" & CStr(point) & ";" & CStr(component) & TestHardPreparedVector(residual)
            gradient(component) = 0#
        Next component
    Next point
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
Private Function TestHardPreparedVector(ByVal values As Variant) As String
    Dim i As Long
    For i = LBound(values) To UBound(values): TestHardPreparedVector = TestHardPreparedVector & ";" & TestOnsetNumber(CDbl(values(i))): Next i
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
Private Function TestOnsetNumber(ByVal value As Double) As String
    TestOnsetNumber = Trim$(Str$(value))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет составляющие ошибки пика; значения переданы копиями и не управляют решателем.
Public Sub TestCapturePeakRefinement(ByVal stage As String, ByVal values As Variant, ByVal diagnostic As String)
    If Len(mMainCapacityFolderTest) = 0 Then Err.Raise 5, , "Не задана папка наблюдения максимума."
    Dim line As String, value As Variant: line = stage
    For Each value In values: line = line & ";" & Trim$(Str$(CDbl(value))): Next value
    line = line & ";" & Replace(Replace(diagnostic, vbCrLf, " | "), vbLf, " | ") & vbCrLf
    Dim file As String: file = mMainCapacityFolderTest & "\Native\PeakRefinement.Values.csv"
    Dim stream As Object: Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2: stream.Charset = "utf-8": stream.Open
    If Len(Dir$(file)) > 0 Then stream.LoadFromFile file: stream.Position = stream.Size
    stream.WriteText line: stream.SaveToFile file, 2: stream.Close
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет весь допустимый путь до ограничения стали; запись не коммитит и не изменяет материальную историю.
Public Sub TestCaptureFullBranch(ByVal fields As Collection, ByVal trace As CCoupledLoadTrace)
    If fields Is Nothing Or trace Is Nothing Then Err.Raise 5, , "Для проверки максимума отсутствует полный путь."
    If fields.Count <> trace.Count Then Err.Raise 5, , "Количество полей полного пути не совпадает с журналом нагрузок."
    Dim handle As Integer: handle = FreeFile
    Open mMainCapacityFolderTest & "\Native\FullFollowedHistory.bin" For Binary Access Write As #handle
    Dim magic As String * 16: magic = "NDMFULLTRACE0001": Put #handle, , magic
    TestWriteVector handle, Array(fields.Count)
    Dim index As Long, fraction As Double, factor As Double, field() As Double
    For index = 1 To fields.Count
        trace.ReadPoint index, fraction, factor: field = fields(index)
        TestWriteVector handle, Array(fraction, factor): TestWriteVector handle, field
    Next index
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет холодный прямой расчёт чистого N; успешное выполнение макроса не означает сходимости каждого сочетания.
Public Function TestRunASDDirectPureN(ByVal folder As String) As String
    On Error GoTo Failed
    Dim handle As Integer: handle = FreeFile
    Open folder & "\Input\DirectLoads.bin" For Binary Access Read As #handle
    Dim count As Long, index As Long, target As Double, report As String
    Get #handle, , count
    If count <> 6 Or LOF(handle) <> 52 Then Err.Raise 5, , "Для осевого контроля нужны шесть заданных нагрузок."
    For index = 1 To count
        Get #handle, , target
        TestRunASDDirectPureNCase folder & "\Case" & Format$(index, "00"), target, report
    Next index
    Close #handle: handle = 0
    TestRunASDDirectPureN = report & "TOTAL_ASD_DIRECT_N_EXECUTION: passed=6; failed=0"
    Exit Function
Failed:
    Dim reason As String: reason = Err.Source & " " & Err.Description
    If handle <> 0 Then Close #handle
    TestRunASDDirectPureN = "RUNTIME ERROR: " & reason
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создаёт независимый набор объектов и нулевую материальную историю для одной нагрузки; сохраняет только фактически возвращённое НДС.
Private Sub TestRunASDDirectPureNCase(ByVal folder As String, ByVal target As Double, ByRef report As String)
    mMainCapacityFolderTest = folder
    Dim geometry As CGeometryRegion, mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    Set geometry = TestFixtureBox(180#, 120#): mesh.BuildMesh geometry, 18#, 12#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing): geometry.BuildContours section.Contours
    section.AddRebarElement 0#, -30#, 12#, GEOM_PI * 36#, "A400"
    section.AddRebarElement 0#, 30#, 12#, GEOM_PI * 36#, "A400"
    Dim layout As New CTransverseRebarLayout: layout.AddContourGroup section, "TestASDCapacityHoop", "", 8#, 100#, 10#, "A240"
    Dim c As New CConcreteMaterialParameters, s As New CSteelMaterialParameters, provider As New CMaterialModelProvider
    c.Initialize 30#, 3#, 30#, 3#, 30000#, 30000#, rbMc2:=15#
    s.Initialize 350#, 400#, 350#, 400#, 200000#, 200000#, 0.018, 0.025
    provider.TestInitializeFromParameters c, s, "ThreeLine", "UseDiagram", "TwoLine", diagramExtensionEnabled:=False, plateauSlopeFactor:=0.0075
    Dim hoop As New CCoupledSteelModel, grades As Object, supplementary As Object
    hoop.Initialize 200000#, 240#, 240#, 1500#, 1500#, 0.02, 0.02
    Set grades = CreateObject("Scripting.Dictionary"): grades.Add "A240", hoop
    Set supplementary = CreateObject("Scripting.Dictionary"): supplementary.Add "ULS(I)", grades
    Dim analysis As New CCoupledSectionAnalysis, spec As New CMaterialModelSpec, loads As New CSectionLoadState
    analysis.Initialize section, layout, provider, 0.2, 0.12, 80#, 125#, 16# / 30#, 0.002, "A400", 30, supplementary, concreteLaw:="ASD"
    spec.Initialize "ULS(I)", "ThreeLine", "UseDiagram", "TwoLine"
    loads.Initialize target, 0#, 0#, 0#, 0#: loads.SetSpatialComponents 0#, 0#, 0#
    Dim field() As Double, resultants() As Double, state As CSectionStateResult, trace As CCoupledLoadTrace, meta As CResultMeta
    Dim started As Double: started = Timer
    Set meta = analysis.SolveTarget(loads, ChrW$(&H3BB) & "*N", spec, field, resultants, True, state, trace)
    Dim elapsed As Double: elapsed = Timer - started
    If elapsed < 0# Then elapsed = elapsed + 86400#
    Dim fieldCount As Long, resultantCount As Long
    On Error Resume Next
    fieldCount = UBound(field) - LBound(field) + 1: Err.Clear
    resultantCount = UBound(resultants) - LBound(resultants) + 1: Err.Clear
    On Error GoTo 0
    Dim traceCount As Long, hasState As Long, actualLaw As String
    If Not trace Is Nothing Then traceCount = trace.Count
    If Not state Is Nothing Then
        hasState = 1
        If Not state.CoupledMaterialCurves Is Nothing Then actualLaw = state.CoupledMaterialCurves.ConcreteLawIdentifier
    End If
    Dim handle As Integer: handle = FreeFile
    Open folder & "\Native\DirectState.bin" For Binary Access Write As #handle
    Dim magic As String * 16: magic = "NDMASDDIRECT0001": Put #handle, , magic
    TestWriteVector handle, Array(target, elapsed, meta.InternalStatus, meta.ResultCode, fieldCount, resultantCount, traceCount, hasState)
    Dim emptyCount As Long
    If fieldCount > 0 Then TestWriteVector handle, field Else Put #handle, , emptyCount
    If resultantCount > 0 Then TestWriteVector handle, resultants Else Put #handle, , emptyCount
    Close #handle
    Dim diagnostic As String, policy As New CResultStatusPolicy, status As String
    status = policy.ExternalStatus(meta)
    diagnostic = "Status=" & status & "; returned_state=" & CStr(hasState) & "; law=" & actualLaw & vbCrLf & _
        "Comment=" & meta.ResultComment & vbCrLf & "Details=" & meta.DiagnosticDetails
    Dim stream As Object: Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2: stream.Charset = "utf-8": stream.Open
    stream.WriteText diagnostic: stream.SaveToFile folder & "\Native\DirectState.txt", 2: stream.Close
    report = report & "ASD_DIRECT_N: N=" & CStr(target) & "; seconds=" & CStr(elapsed) & "; status=" & status & _
        "; returned_state=" & CStr(hasState) & "; physical_acceptance_not_implied_by_test_execution=True" & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает все принятые поля прямого расчёта без коммита, повторных материальных проб и изменения численного пути.
Public Sub TestCaptureDirectHistory(ByVal continuation As CCoupledLoadContinuation, ByVal operators As CCoupledElasticState, ByVal loadPath As CLoadPathVector)
    Dim history As Collection, trace As CCoupledLoadTrace
    Set history = continuation.AcceptedFields: Set trace = continuation.SavedTrace
    If history Is Nothing Or trace Is Nothing Then Err.Raise 5, , "Не сохранена история контрольного продолжения."
    If history.Count <> trace.Count Then Err.Raise 5, , "История полей и трасса множителей имеют разную длину."
    TestWriteHardPreparedOperators operators, mMainCapacityFolderTest & "\Native\MainCapacity.Operators.csv"
    Dim handle As Integer: handle = FreeFile
    Open mMainCapacityFolderTest & "\Native\MainCapacityHistory.bin" For Binary Access Write As #handle
    Dim magic As String * 16: magic = "NDMMAINHIST00003": Put #handle, , magic
    Dim area As Double, length As Double: operators.CopyResultantResidualScales area, length
    TestWriteVector handle, Array(operators.DegreeCount, operators.PointCount, operators.ConcretePointCount, area, length, 0.001, 0.0000005, 0.0000005)
    Dim offset() As Double, direction() As Double: loadPath.Components offset, direction
    TestWriteVector handle, offset: TestWriteVector handle, direction
    TestWriteVector handle, Array(history.Count)
    Dim index As Long, fraction As Double, factor As Double, field() As Double
    For index = 1 To history.Count
        trace.ReadPoint index, fraction, factor: field = history.Item(index)
        TestWriteVector handle, Array(fraction, factor): TestWriteVector handle, field
    Next index
    Close #handle
End Sub
