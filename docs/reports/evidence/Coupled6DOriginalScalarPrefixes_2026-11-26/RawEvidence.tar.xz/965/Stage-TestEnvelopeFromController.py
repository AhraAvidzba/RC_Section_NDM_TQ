"""ДЛЯ ТЕСТОВ. Проверяет рабочий материальный шаг от конечного состояния штатного контроллера."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestStage(root, parent, controller):
    """Переносит первые 147 полей точно; последующие десятичные поля требуют холодного нативного повторения."""
    here = Path(__file__).resolve().parent
    read = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original = read(controller / 'Input/Reverse1.bin')
    validate = run_path(str(here / 'Validate-TestHardPrepared.py'))
    proof, fields = validate['TestValidate'](controller, 'IntegratedEvent.Sequence')
    assert len(original['fields']) == 147 and 147 < len(fields) < 1000
    frames = [r for r in validate['TestRows'](controller / 'Native/IntegratedEvent.Sequence.csv') if r[0] == 'F']
    fractions = np.asarray([r[2] for r in frames], float)
    factors = np.asarray([r[3] for r in frames], float)
    np.testing.assert_allclose(fields[:147], original['fields'], rtol=1e-14, atol=1e-300)
    fields[:147], fractions[:147], factors[:147] = original['fields'], original['fractions'], original['lambdas']
    vector = run_path(str(here / 'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    raw = b'NDMREVTEST000001' + struct.pack('<i', 60)
    for key in ('calibration', 'options', 'offset', 'direction'):
        raw += vector(original[key])
    raw += struct.pack('<i', len(fields))
    for fraction, factor, field in zip(fractions, factors, fields):
        raw += struct.pack('<dd', fraction, factor) + vector(field)
    for values in (fields[-2], fields[-1], fields[-1], original['offset'] + factors[-1] * original['direction'],
                   original['projection'], [factors[-1], 0., factors[-1], 0.], np.zeros(4)):
        raw += vector(values)
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'Input/Reverse1.bin'
    (root / name).write_bytes(raw)
    prep['inputs'][name] = sha256(raw).hexdigest().upper()
    for name, source in ((Path(__file__).name, Path(__file__)),
                         ('Input/ControllerSequence.csv', controller / 'Native/IntegratedEvent.Sequence.csv')):
        (root / name).parent.mkdir(parents=True, exist_ok=True)
        (root / name).write_bytes(source.read_bytes())
        prep['inputs'][name] = sha256(source.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingEnvelopeAfterController', initial_history_states=len(fields),
        first_147_input_Double_exact=True, later_fields_decimal_reconstructed=True,
        every_replayed_equilibrium_requires_independent_validation=True,
        actual_import_this_pass=[], compiled_code_reused_without_mutable_state=True,
        source_controller=controller.name, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING ENVELOPE AFTER CONTROLLER READY;', len(fields), 'STATES; COLD REPLAY REQUIRED')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    for name in ('root', 'parent', 'controller'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    TestStage(a.root.resolve(), a.parent.resolve(), a.controller.resolve())
