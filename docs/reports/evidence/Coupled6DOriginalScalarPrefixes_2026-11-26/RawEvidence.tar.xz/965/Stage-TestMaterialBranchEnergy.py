"""ДЛЯ ТЕСТОВ. Проверяет материальную координату на участке перед разгрузкой из подтверждённой общей истории."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import struct
import numpy as np


def TestVector(values):
    """Сохраняет явно восстановленные Double; текстовый экспорт не выдаёт за исходные машинные биты."""
    values = np.asarray(values, dtype='<f8').ravel()
    assert 0 < len(values) <= 10000 and np.all(np.isfinite(values))
    return struct.pack('<i', len(values)) + values.tobytes()


def TestStage(root, parent, count, ratio):
    """Исходные 147 полей сохраняет точно; последующие десятичные поля требуют холодной нативной проверки каждого равновесия."""
    assert 150 <= count <= 205 and ratio in (.5, 1., 2.)
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    original = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](parent / 'Input/Reverse1.bin')
    rows = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestRows'](parent / 'Native/IntegratedEvent.Sequence.csv')
    frames = [r for r in rows if r[0] == 'F'][:count]
    fields = np.asarray([r[4:] for r in frames], float)
    fractions = np.asarray([r[2] for r in frames], float)
    factors = np.asarray([r[3] for r in frames], float)
    assert len(original['fields']) == 147 and fields.shape == (count, 60)
    np.testing.assert_allclose(fields[:147], original['fields'], rtol=1e-14, atol=1e-300)
    fields[:147] = original['fields']
    fractions[:147] = original['fractions']
    factors[:147] = original['lambdas']
    snapshot = b'NDMREVTEST000001' + struct.pack('<i', 60)
    for key in ('calibration', 'options', 'offset', 'direction'):
        snapshot += TestVector(original[key])
    snapshot += struct.pack('<i', count)
    for fraction, factor, field in zip(fractions, factors, fields):
        snapshot += struct.pack('<dd', fraction, factor) + TestVector(field)
    for values in (fields[-2], fields[-1], fields[-1], original['offset'] + factors[-1] * original['direction'],
        original['projection'], [factors[-1], 0., factors[-1], 0.], np.zeros(4)):
        snapshot += TestVector(values)
    name = 'Input/Reverse1.bin'
    (root / name).write_bytes(snapshot)
    prep['inputs'][name] = sha256(snapshot).hexdigest().upper()
    for name, raw in {'Input/MaterialProbeRatio.bin': TestVector([ratio, 8.]),
        'Input/Original147.bin': (parent / 'Input/Reverse1.bin').read_bytes(),
        'Input/OriginalSequence.csv': (parent / 'Native/IntegratedEvent.Sequence.csv').read_bytes(),
        'Input/OriginalSequence.Operators.csv': (parent / 'Native/IntegratedEvent.Sequence.Operators.csv').read_bytes()}.items():
        (root / name).write_bytes(raw)
        prep['inputs'][name] = sha256(raw).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestMaterialBranchEnergy.bas.txt').read_text('utf-8-sig')
    code, replaced = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body, code)
    assert replaced == 1 and 'fractionNameTest' not in code
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name, 'TestMaterialBranchEnergy.bas.txt'):
        (root / name).write_bytes((here / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='MaterialEnvelopeBranchCoordinate', initial_history_states=count,
        material_increment_ratio=ratio, first_147_input_Double_exact=True,
        later_fields_decimal_reconstructed=True, every_replayed_equilibrium_requires_independent_validation=True,
        current_compiled_working_classes_unchanged=True, actual_import_this_pass=['modTestCoupledElasticState'],
        numerical_reference_is_SciPy=False, actual_working_Trace_API=False,
        total_thermodynamic_dissipation_claimed=False, original_force_and_material_precision=True,
        physical_capacity_certified=False, actual_full_stock_claimed=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('MATERIAL COORDINATE BRANCH READY; history=', count, 'ratio=', ratio, 'NO MATERIAL POINT PRESCRIBED')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    p.add_argument('--count', type=int, default=181)
    p.add_argument('--ratio', type=float, default=1.)
    a = p.parse_args()
    TestStage(a.root.resolve(), a.parent.resolve(), a.count, a.ratio)
