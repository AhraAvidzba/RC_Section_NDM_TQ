"""ДЛЯ ТЕСТОВ. Собирает рабочую перестановку CDP-порога в регрессионной или штатной книге одним импортом Newton."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent,frozen):
    """Сохраняет подготовленные данные и читающие дополнения родителя, меняя только точный рабочий префикс класса."""
    here=Path(__file__).resolve().parent
    before=(frozen/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    working=(repo/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    patch=run_path(str(here/'Stage-TestH96CDPGate.py'))['TestPatch'];assert patch(before)==working
    old=(parent/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig');assert old.startswith(before)
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    for earlier,later in [('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')]:
        (root/later).write_bytes((parent/earlier).read_bytes());prep['inputs'][later]=sha256((root/later).read_bytes()).hexdigest().upper()
    ancestor=root/('WorkingGateAncestor_'+root.name);ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    if (root/'NoNewCompilation.json').exists():(root/'NoNewCompilation.json').rename(root/'GateParentNoNewCompilation.json')
    inputs={'src/Solver/CCoupledNewtonSolver.cls':(working+old[len(before):]).replace('\n','\r\n').encode('utf-8-sig'),
        'Input/WorkingGateOriginalNewton.cls':(frozen/'src/Solver/CCoupledNewtonSolver.cls').read_bytes(),
        'Input/WorkingGateNewton.cls':(repo/'src/Solver/CCoupledNewtonSolver.cls').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace("-ModuleNames 'modTestCoupledElasticState'","-ModuleNames 'CCoupledNewtonSolver'")
    inputs['Compile-TestWorkingCDPGate.ps1']=compiler.encode('utf-8-sig')
    for name,raw in inputs.items():
        (root/name).write_bytes(raw);prep['inputs'][name]=sha256(raw).hexdigest().upper()
    file=root/'AllCoupledSources.json'
    if file.exists():
        hashes=json.loads(file.read_bytes());name='src/Solver/CCoupledNewtonSolver.cls'
        if name in hashes:hashes[name]=prep['inputs'][name]
        file.write_bytes((json.dumps(hashes,indent=2,sort_keys=True)+'\n').encode())
        if file.name in prep['inputs']:prep['inputs'][file.name]=sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingCDPGate',actual_import_this_pass=['CCoupledNewtonSolver'],
        exact_working_guard_reorder=True,only_Newton_import=True,materials_and_tolerances_unchanged=True,
        no_half_guard_or_step_size_change=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING CDP GUARD READY; ONE NEWTON IMPORT; ORIGINAL MATERIALS, TOLERANCES AND DATA')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent','frozen'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestStage(args.repo.resolve(),args.root.resolve(),args.parent.resolve(),args.frozen.resolve())
