"""ДЛЯ ТЕСТОВ. Проверяет событие точки 6 после действительного принятия ранее найденного половинного H-шага."""
from argparse import ArgumentParser
from hashlib import sha256
import json,struct
from pathlib import Path
from runpy import run_path
import numpy as np


def TestStage(root,parent,face,trace):
    """Добавляет половинное поле в реальную входную историю; номер события остаётся только диагностическим заданием."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestPoint6YieldControl.py'))['TestStage'](root,parent,face,0.)
    prep=json.loads((root/'Preparation.json').read_bytes())
    original=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](root/'Input/Reverse1.bin')
    assert len(original['fields'])==200
    raw=(trace/'Input/PointTraceFields.bin').read_bytes();count,size=struct.unpack_from('<ii',raw)
    names=json.loads((trace/'Input/PointTraceNames.json').read_bytes());assert size==61
    half=np.frombuffer(raw,dtype='<f8',offset=8).reshape(count,size)[names.index('HalfH')]
    vector=run_path(str(here/'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    data=b'NDMREVTEST000001'+struct.pack('<i',60)
    for key in ('calibration','options','offset','direction'):data+=vector(original[key])
    data+=struct.pack('<i',201)
    for fraction,factor,field in zip(original['fractions'],original['lambdas'],original['fields']):data+=struct.pack('<dd',fraction,factor)+vector(field)
    data+=struct.pack('<dd',1.,half[-1])+vector(half[:-1])
    for values in (original['fields'][-1],half[:-1],half[:-1],original['offset']+half[-1]*original['direction'],
        original['projection'],[half[-1],0.,half[-1],0.],np.zeros(4)):data+=vector(values)
    name='Input/Reverse1.bin';(root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
    name='Input/ActualHalfHistoryOrigin.json'
    (root/name).write_bytes((json.dumps(dict(accepted_prefix200_unchanged=True,half_field_decimal_reconstructed=True,
        intermediate_material_history_really_accepted_by_cold_replay=True,half_lambda=float(half[-1]),
        source=trace.name,physical_capacity_certified=False),sort_keys=True,indent=2)+'\n').encode())
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='Point6EventAfterActualHalfStep',initial_history_states=201,
        intermediate_history_actually_committed=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,sort_keys=True,indent=2)+'\n').encode())
    print('POINT6 AFTER ACTUAL HALF HISTORY READY; 201 ACCEPTED INPUT STATES')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent','face','trace'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve(),a.face.resolve(),a.trace.resolve())
