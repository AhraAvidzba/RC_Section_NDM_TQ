"""ДЛЯ ТЕСТОВ. Строит прогноз по двум принятым полям, а не по решению внешнего оптимизатора."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestStage(root,parent,target_override=None):
    """Находит на положительной пространственной секущей заданную материальную координату; истинное равновесие проверяет VBA."""
    here=Path(__file__).resolve().parent
    report=run_path(str(here/'Analyze-TestMaterialPredictor.py'))['TestAnalyze'](parent,target_override)
    ratio=report['positive_secant_ray_target_ratio'];assert ratio is not None and ratio>0
    data=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](parent/'Input/Reverse1.bin')
    result=json.loads((parent/'Native/ExternalResult.json').read_bytes())
    origin=(parent/'Input/ProjectionOrigin.bin').read_bytes() if (parent/'Input/ProjectionOrigin.bin').exists() else (parent/'Input/InitialCoordinates.bin').read_bytes()
    original=np.frombuffer(origin,dtype='<f8',offset=4);n=len(original)
    raw=(parent/'Input/ExternalSeed.bin').read_bytes();seed=np.frombuffer(raw,dtype='<f8',offset=4,count=n)
    field=data['fields'][-1]+ratio*(data['fields'][-1]-data['fields'][-2])
    factor=data['lambdas'][-1]+ratio*(data['lambdas'][-1]-data['lambdas'][-2])
    coordinates=(np.r_[field,factor]-seed)/np.asarray(result['unknown_scales'])
    pivot=int(result['native_projection_metadata'][0])-1
    coordinates[pivot]=original[pivot] # Исключаемая численная координата не меняет физическое отображение адаптера.
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    contents={'Input/InitialCoordinates.bin':struct.pack('<i',n)+coordinates.astype('<f8').tobytes(),
        'Input/ProjectionOrigin.bin':origin,
        'Input/ChangedInitialCondition.json':(json.dumps(dict(kind='PositiveAcceptedSecantAtMaterialTarget',
            report=report,external_solver_field_used_as_initial=False,final_original_force_proof_required=True),indent=2,sort_keys=True)+'\n').encode(),
        'Run-TestExternalEnvelope.py':(here/'Run-TestExternalEnvelope.py').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    if target_override is not None:
        control=json.loads((root/'Input/MaterialControl.json').read_bytes())
        control['target_MPa']=float(target_override)
        control['observed_accepted_trial_yield_MPa']=report['current_phi_MPa']
        control['numerical_increment_MPa']=float(target_override)-report['current_phi_MPa']
        control['target_is_exact_yield_event_not_strength_limit']=bool(target_override==0)
        contents['Input/MaterialControl.json']=(json.dumps(control,indent=2,sort_keys=True)+'\n').encode()
    prep=json.loads((root/'Preparation.json').read_bytes())
    for name,content in contents.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='OwnVBAWithAcceptedSecantPredictor',
        initial_external_failed_energy_field_replaced=True,
        initial_field_from_two_actual_accepted_states=True,secant_ratio=ratio,
        scalar_coordinate_computed_by_independent_trial_predictor_only=True,
        all_true_material_stresses_and_force_proof_native_VBA=True,
        physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('ACCEPTED SECANT RAY PREDICTOR READY',ratio)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--parent',type=Path,required=True);parser.add_argument('--target',type=float)
    args=parser.parse_args();TestStage(args.root.resolve(),args.parent.resolve(),args.target)
