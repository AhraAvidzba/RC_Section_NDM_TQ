﻿# ДЛЯ ТЕСТОВ: запускает только побитно переиспользованную книгу со свежим восстановлением материалов; не выдаёт исторический импорт за новую компиляцию.
param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference='Stop'
$taskTemp=$env:TEMP;$taskTmp=$env:TMP
Push-Location -LiteralPath $Root
try {
    . './Guard-IsolatedOffice.ps1'
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    foreach($pin in $prep.inputs.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $pin.Name).Hash -cne $pin.Value) {throw ('Changed input '+$pin.Name)}
    }
    $reuse=Get-Content -LiteralPath 'ImmutableSpatialReuseProof.json' -Raw | ConvertFrom-Json
    if ($reuse.format -cne 'NDM_SPATIAL_SEED_EXACT_REUSE_01' -or $reuse.fresh_compilation_claimed -or
        @($reuse.actual_import_this_pass).Count -or @($prep.directed_scope.actual_import_this_pass).Count -or
        !$prep.directed_scope.actual_current_compilation_reused_without_import -or $reuse.material_history_reused -or
        !$reuse.fresh_replay_required -or $reuse.source_component_count -ne 255) {throw 'Invalid immutable source reuse contract'}
    foreach($pin in $reuse.immutable_parent_files_verified.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $pin.Name).Hash -cne $pin.Value) {throw ('Changed parent source '+$pin.Name)}
    }
    $book='docs/regression/Diagnostic.xlsm'
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closed=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $closed.State -cne 'Absent' -or
        (Get-FileHash -LiteralPath $book).Hash -cne $reuse.compiled_workbook_sha256 -or
        $compiled.WorkbookSHA256 -cne $reuse.compiled_workbook_sha256) {throw 'Exact parent compilation not verified'}
    Assert-IsolatedOfficeReady 'ImmutableSpatialStepHalves'
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path;$env:TMP=$env:TEMP
    & './tools/build_workbook/Run-FocusedKaniWatchdog.ps1' -SourceWorkbook $book -ReportPath 'Native/PersistentHController.txt' `
        -Macro 'modTestCoupledElasticState.RunTestReversePolish' -MacroArgument1 $Root -TimeoutSeconds 600 -Mode No -FailFast
    if ($LASTEXITCODE -ne 0) {throw ('Immutable spatial probes exited '+$LASTEXITCODE)}
} finally {
    $env:TEMP=$taskTemp;$env:TMP=$taskTmp
    Pop-Location
}
