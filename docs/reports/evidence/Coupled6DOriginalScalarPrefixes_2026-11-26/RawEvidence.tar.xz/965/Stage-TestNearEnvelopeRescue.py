"""ДЛЯ ТЕСТОВ. Проверяет малую деформационную поправку из лучшего близкого H-приближения, не завершившего внутренние итерации."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestCandidate(code):
    """Сохраняет исходные допуски, бюджет и три основных способа; корректор использует собственную читающую касательную."""
    pattern = r'(?ms)^Private Function SolveEnvelopeTarget\(.*?^End Function'
    before, = re.findall(pattern, code)
    start = before.index('        If solved And solver.HasBestPoint Then')
    end = before.index('\n    Next pass', start)
    replacement = '''        If solver.HasBestPoint Then
            usedCalls = usedCalls + 1: mHybridEvaluations = mHybridEvaluations + 1
            If equations.TryEvaluate(solution, False, residual, matrix) Then
                maximum = 0#
                For i = 1 To size: maximum = GeomMax(maximum, Abs(residual(i))): Next i
                ReadEquationField solution, field, lambda
                Dim load(1 To COMPONENT_COUNT) As Double, forceNorm As Double
                SetControlledLoad lambda, load
                forceNorm = mSection.ResultantResidualNorm(mTrialResultants, load)
                mLastNorm = GeomMax(maximum, forceNorm)
                solved = (mLastNorm <= tolerance)
                If Not solved And mLastNorm <= SMALL_STRAIN_MAX_NORM * tolerance Then
                    mEnvelopeDetails = mEnvelopeDetails & "; близкое H-приближение требует уточнения: " & CStr(mLastNorm) & " МПа"
                    Dim correctionWrapper As CCoupledEnvelopeEquations, correctionEquations As ICoupledEquationSystem
                    Set correctionWrapper = mEnvelope.AtTarget(Me, target, True): Set correctionEquations = correctionWrapper
                    solved = TryEnvelopeResultantCorrection(correctionEquations, solution, tolerance, remaining, maximumCalls, usedSteps, usedCalls)
                End If
                If solved Then
                    ReadEquationField solution, field, lambda
                    SolveEnvelopeTarget = True
                    Exit For
                End If
            End If
        End If'''
    after = before[:start] + replacement + before[end:]
    return code.replace(before, after, 1)


def TestStage(root, parent):
    """Меняет один частный Newton; точные98 состояний и все параметры неудавшегося H-запроса остаются исходными."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for source, target in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / target).write_bytes((parent / source).read_bytes())
        prep['inputs'][target] = sha256((root / target).read_bytes()).hexdigest().upper()
    ancestor = root / ('NearEnvelopeAncestor_' + root.name)
    ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists():
            (root / name).rename(ancestor / name)
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = TestCandidate((root / name).read_text('utf-8-sig'))
    values = {name: code.replace('\n', '\r\n').encode('utf-8-sig'), Path(__file__).name: Path(__file__).read_bytes()}
    compiler = (here / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace(
        "-ModuleNames 'modTestCoupledElasticState'", "-ModuleNames 'CCoupledNewtonSolver'")
    values['Compile-TestExternalPoint.ps1'] = compiler.encode('utf-8-sig')
    for name, data in values.items():
        (root / name).write_bytes(data)
        prep['inputs'][name] = sha256(data).hexdigest().upper()
    file = root / 'AllCoupledSources.json'
    if file.is_file():
        hashes = json.loads(file.read_bytes())
        name = 'src/Solver/CCoupledNewtonSolver.cls'
        if name in hashes:
            hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']:
            prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='NearHBestPointSmallCorrection', actual_import_this_pass=['CCoupledNewtonSolver'],
        original_force_tolerance_and_shared30=True, best_point_not_committed=True, correction_own_J_wrapper=True,
        accepted_material_history_and_H_target_unchanged=True, working_source_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('PRIVATE NEAR H CORRECTION READY; ONE NEWTON IMPORT; ORIGINAL TOLERANCE AND SHARED30')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve())
