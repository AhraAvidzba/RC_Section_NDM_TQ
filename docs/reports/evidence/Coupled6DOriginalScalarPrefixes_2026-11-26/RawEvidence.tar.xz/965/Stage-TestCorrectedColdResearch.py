"""ДЛЯ ТЕСТОВ. Повторяет полный холодный384-поиск с проверенной приёмкой H по шести усилиям."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent):
    """Повторно использует точную компиляцию; исходные поля локального теста не становятся начальной историей холодного запуска."""
    here = Path(__file__).resolve().parent
    proof = json.loads((parent / 'ColdResultantProof.json').read_bytes())
    assert proof['full_states'] == proof['target_prefix'] == 97
    assert all(v['info'][1] == 1 and v['effort'][0] == 1 for v in proof['cases'])
    private = (parent / 'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    working = (repo / 'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    for name in ('SolveEnvelopeTarget', 'PrepareSmallStrainSystem', 'BuildSmallStrainSystem', 'TryEnvelopeResultantCorrection'):
        pattern = r'(?ms)^Private Function ' + name + r'\(.*?^End Function'
        expected, = re.findall(pattern, working)
        actual, = re.findall(pattern, private)
        assert expected == actual, name
    for name in ('CCoupledHybridSolver.cls', 'CCoupledHybridFactorization.cls'):
        assert (parent / 'src/Solver' / name).read_bytes() == (repo / 'src/Solver' / name).read_bytes()
    controller = (parent / 'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')
    hook = '    modTestCoupledElasticState.TestCaptureStockContinuation Me, Details()\n'
    assert controller.count(hook) == 1
    assert controller.replace(hook, '', 1) == (repo / 'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig').replace(
        'Private Const PROBE_LIMIT As Long = 96 ', 'Private Const PROBE_LIMIT As Long = 384 ', 1)
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    prep['directed_scope'].update(case='Corrected665ColdResearch384', working_core_checkpoint=665,
        actual_current_compilation_reused_without_import=True, historical_compilation_modules=prep['directed_scope']['actual_import_this_pass'],
        cold_native_starts_from_zero=True, current_input_history_not_used_for_cold_run=True,
        research_probe_limit=384, unchanged_production_probe_limit=96, original_shared_H_iterations=30,
        physical_capacity_certified=False, fresh_native_results_required=True)
    inherited = {}
    for name in ('ColdResultantProof.json', 'ColdResearch384StockProof.json', 'WorkingTrustStockProof.json',
        'WorkingTrustActualSavedWorkbook.xlsm', 'ColdResearch384ActualSavedWorkbook.xlsm'):
        if (root / name).is_file():
            inherited[name] = sha256((root / name).read_bytes()).hexdigest().upper()
    record = dict(parent=str(parent), compiled_book_reused=True, no_new_compilation=True, no_new_import=True,
        four_working_methods_exact=True, Hybrid_and_QR_exact=True, only_controller_limit_is_research384=True,
        inherited_noncurrent_outcomes=inherited, required_new_saved_book='CorrectedColdResearch384ActualSavedWorkbook.xlsm')
    values = {Path(__file__).name: Path(__file__).read_bytes(),
        'CorrectedColdResearchOrigin.json': (json.dumps(record, indent=2, sort_keys=True) + '\n').encode()}
    for name, content in values.items():
        (root / name).write_bytes(content)
        prep['inputs'][name] = sha256(content).hexdigest().upper()
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('CORRECTED665 COLD384 READY; EXACT VERIFIED COMPILATION; FRESH NATIVE STATE; ORIGINAL SHARED30')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
