"""ДЛЯ ТЕСТОВ. Готовит холодный96-проход нового H-ядра с рабочим неизменённым контроллером продолжения."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestStage(repo,root,parent):
    """Убирает частное расширение глубины H-восстановления; исходные96 проб и30 поправок не увеличиваются."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    ancestor=root/'Cold96CompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).replace(ancestor/name)
    name='src/Solver/CCoupledDeformationContinuation.cls'
    code=(repo/name).read_text('utf-8-sig')
    assert 'Private Const PROBE_LIMIT As Long = 96' in code and 'TestCaptureStockContinuation' not in code
    anchor='Private Sub NotifyProgress()\n'
    assert code.count(anchor)==1
    code=code.replace(anchor,anchor+'    modTestCoupledElasticState.TestCaptureStockContinuation Me, Details()\n',1)
    assert code.replace('    modTestCoupledElasticState.TestCaptureStockContinuation Me, Details()\n','',1)==(repo/name).read_text('utf-8-sig')
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace(
        "-ModuleNames 'modTestCoupledElasticState'","-ModuleNames 'CCoupledDeformationContinuation'")
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),'Compile-TestExternalPoint.ps1':compiler.encode('utf-8-sig'),
        'ParentCodeUpdate.json':(parent/'docs/regression/CodeUpdate.json').read_bytes(),
        'ParentCompileClosure.json':(parent/'CompileClosure.json').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes(),
        'Run-TestHMixedStock.ps1':(here/'Run-TestHMixedStock.ps1').read_text('utf-8-sig').encode('utf-8-sig')}
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    with ZipFile(parent/'docs/regression/Diagnostic.xlsm') as book:
        (root/'ParentCompiledVBA.bin').write_bytes(book.read('xl/vbaProject.bin'))
    prep['directed_scope'].update(case='FullMeritCold96WorkingController',actual_import_this_pass=['CCoupledDeformationContinuation'],
        working_controller_exact_except_readonly_observer=True, private_resolution_depth_extension_removed=True,
        full_cold_from_zero=True,current_input_history_not_used_for_cold_run=True,
        original_production_probe_limit=96,maximum_shared_iterations_each=30,
        fresh_compilation_claimed=True,source_compilation_reused_exactly=False,
        working_source_changed=False,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('COLD96 READY; WORKING CONTROLLER RESTORED; NO H-DEPTH EXTENSION; NATIVE HISTORY FROM ZERO')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestStage(args.repo.resolve(),args.root.resolve(),args.parent.resolve())
