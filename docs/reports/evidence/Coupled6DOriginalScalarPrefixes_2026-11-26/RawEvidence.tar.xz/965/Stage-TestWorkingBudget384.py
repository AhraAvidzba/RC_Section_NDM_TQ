"""ДЛЯ ТЕСТОВ. Проверяет дальнейший холодный путь ядра660 с исследовательским бюджетом384, не меняя рабочий лимит96."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestStage(root, parent):
    """Меняет только частную константу общего бюджета; допуски, материал и бюджет отдельного решения точны."""
    here = Path(__file__).resolve().parent; source = here / 'Stage-TestProbeBudget.py'
    code = source.read_text('utf-8-sig'); before = 'assert budget in (120, 144, 192)'
    assert code.count(before) == 1; code = code.replace(before, 'assert budget == 384', 1)
    namespace = {'__file__': str(Path(__file__).resolve()), '__name__': 'working_budget384_stage_test'}
    exec(compile(code, str(source), 'exec'), namespace); namespace['TestStage'](root, parent, 384)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    if (root / 'NoNewCompilation.json').exists():
        (root / 'NoNewCompilation.json').rename(root / 'InheritedNoNewCompilationBeforeBudget384.json')
    runner = (here / 'Run-TestHMixedStock.ps1').read_text('utf-8-sig')
    before = '-VerifyResultsReopen -TimeoutSeconds 600 -Mode No -FailFast'
    assert runner.count(before) == 1
    runner = runner.replace(before, '-VerifyResultsReopen -TimeoutSeconds 1800 -Mode No -FailFast', 1)
    name = 'Run-TestWorkingBudget384.ps1'; raw = runner.encode('utf-8-sig')
    (root / name).write_bytes(raw); prep['inputs'][name] = sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='Working660ResearchBudget384', working_core_checkpoint=660,
        no_new_compilation=False, new_compilation_required=True, watchdog_seconds=1800,
        research_purpose='Reach the corrected late events from zero; not a performance improvement or a production cap change.',
        installed_workbook_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING660 RESEARCH384 READY; ONE CONTROLLER CONSTANT; WATCHDOG1800; PRODUCTION96')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    for name in ('root', 'parent'): parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args(); TestStage(args.root.resolve(), args.parent.resolve())
