"""ДЛЯ ТЕСТОВ. Включает явный резерв16 только после отказа исходных трёх H-методов в холодном пути96."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent):
    """Сохраняет прочие бюджеты30 и96, материалы и допуски; два вызова H получают отдельно учтённый дополнительный предел16."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestFullMeritCold96.py'))['TestStage'](repo,root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='src/Solver/CCoupledDeformationContinuation.cls'
    code=(root/name).read_text('utf-8-sig');before='mMaxIterations, probes, True)'
    assert code.count(before)==2
    code=code.replace(before,'mMaxIterations, probes, True, residualRecoverySteps:=16)')
    assert code.count('residualRecoverySteps:=16')==2
    content=code.replace('\n','\r\n').encode('utf-8-sig');(root/name).write_bytes(content)
    prep['inputs'][name]=sha256(content).hexdigest().upper()
    name=Path(__file__).name;content=Path(__file__).read_bytes();(root/name).write_bytes(content)
    prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='RetainedNearPostFailureCold96',
        working_controller_exact_except_readonly_observer=False,
        working_controller_except_observer_and_two_explicit_H_recovery_calls=True,
        original_first_three_budget=30,explicit_additional_H_recovery_budget=16,
        maximum_shared_iterations_each=46,all_other_solver_budgets_unchanged=True,
        original_production_probe_limit=96,physical_tolerance_unchanged=True,
        numerical_failure_not_physical_failure=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('POST-FAILURE COLD96 READY; H ONLY EXPLICIT30+16; OTHER SOLVES30; NO WORKING SOURCE CHANGE')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestStage(args.repo.resolve(),args.root.resolve(),args.parent.resolve())
