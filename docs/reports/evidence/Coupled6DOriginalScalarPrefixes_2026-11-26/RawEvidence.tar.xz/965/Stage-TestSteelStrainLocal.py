"""ДЛЯ ТЕСТОВ. Собирает отдельную книгу трёх проб линейного управления арматурой от проверенного103-префикса."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root,parent,candidate):
    """Меняет два частных численных класса и тестовый модуль; использует прежние пределы и30итераций, без продолжения холодного384-поиска."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'CurrentColdHistoryProof.json').read_bytes())
    assert proof['complete_states']==103 and proof['all_current_accepted_states_verified'] and proof['partial_accepted_prefix_only']
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    ancestor=root/'SteelControlCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    payload=(here/'TestSteelStrainLocal.bas.txt').read_text('utf-8-sig')
    body,=re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',payload)
    code,count=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert count==1
    imports=['CCoupledReinforcedResponse','CCoupledNewtonSolver','modTestCoupledElasticState']
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace(
        "-ModuleNames 'modTestCoupledElasticState'",'-ModuleNames @('+','.join(repr(value) for value in imports)+')')
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),
        'src/Materials/CCoupledReinforcedResponse.cls':(candidate/'CCoupledReinforcedResponse.cls').read_bytes(),
        'src/Solver/CCoupledNewtonSolver.cls':(candidate/'CCoupledNewtonSolver.cls').read_bytes(),
        'Compile-TestExternalPoint.ps1':compiler.encode('utf-8-sig'),
        'Input/Verified103PrefixProof.json':(parent/'CurrentColdHistoryProof.json').read_bytes()}
    for name in (Path(__file__).name,'Build-TestSteelStrainControlCandidate.py','TestSteelStrainLocal.bas.txt'):
        values[name]=(here/name).read_bytes()
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    file=root/'AllCoupledSources.json'
    if file.exists():
        hashes=json.loads(file.read_bytes())
        for name in values:
            if name in hashes:hashes[name]=prep['inputs'][name]
        file.write_bytes((json.dumps(hashes,indent=2,sort_keys=True)+'\n').encode())
        if file.name in prep['inputs']:prep['inputs'][file.name]=sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='SteelStrainLocal103',actual_import_this_pass=imports,
        original_accepted_prefix=103,partial_accepted_prefix_only=False,
        bootstrap_from_verified_partial_prefix=True,no_new_equilibrium_solution_requested=False,
        three_independent_strain_targets=True,primary_iteration_budget=30,
        explicit_H_recovery_not_used=True,governing_bar_selected_from_actual_increment=True,
        fixed_point_or_future_field_not_supplied=True,only_final_accepted_path_replayed=False,
        only_last_complete_accepted_prefix_replayed=False,
        control_step_policy='max(last actual strain increment,0.001 of remaining bar strain margin), capped at0.25 of margin; target fractions0.25,0.5,1',
        material_laws_and_limits_unchanged=True,working_source_changed=False,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('STEEL STRAIN LOCAL103 READY; THREE ACTUAL BAR TARGETS, SAME MATERIALS/LIMITS, ORIGINAL30; NO CAPACITY CLAIM')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('root','parent','candidate'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestStage(args.root.resolve(),args.parent.resolve(),args.candidate.resolve())
