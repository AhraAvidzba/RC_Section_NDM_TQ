"""ДЛЯ ТЕСТОВ. Обновляет только ещё не скомпилированную частную подготовку постоянного H."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestRefresh(repo, root):
    """Сохраняет тестовые суффиксы и входную историю; после любого нативного запуска обновление запрещено."""
    assert not (root / 'CompilePoint.log').exists() and not any((root / 'Native').iterdir())
    prep = json.loads((root / 'Preparation.json').read_bytes())
    parent = json.loads((root / 'ParentCodeUpdate.json').read_bytes())
    assert sha256((root / 'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper() == parent['WorkbookSHA256']
    paths = ['src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledDeformationContinuation.cls']
    for name in paths:
        previous = (root / name).read_text('utf-8-sig')
        code = (repo / name).read_text('utf-8-sig')
        if name.endswith('CCoupledNewtonSolver.cls'):
            marker = 'Friend Function ReadReverseControlTest() As Variant'
            assert previous.count(marker) == 1
            cut = previous.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, previous.index(marker))
            assert cut > 0
            code += '\n' + previous[cut:]
        (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    anchor = '    Dim controller As New CCoupledDeformationContinuation, observer As New CCoupledProgressObserverTest'
    assert code.count(anchor) == 1
    checks = '''    If Not mReverseSolverTest.TryReadAcceptedEnvelopeAt(fields.Count, fields.Count, readH) Then Err.Raise 5, , "Нет последней записи пути H."
    If readH <> afterH Then Err.Raise 5, , "Последняя запись пути H не совпала с буфером."
    If Not mReverseSolverTest.TryReadAcceptedEnvelopeAt(fields.Count - 1, fields.Count, readH) Then Err.Raise 5, , "Нет предыдущей записи пути H."
    If readH <> beforeH Then Err.Raise 5, , "Предыдущая запись пути H не совпала с парой."
    If mReverseSolverTest.TryReadAcceptedEnvelopeAt(0, fields.Count, readH) Then Err.Raise 5, , "Принят нулевой индекс пути H."
    If mReverseSolverTest.TryReadAcceptedEnvelopeAt(1, fields.Count + 1, readH) Then Err.Raise 5, , "Принята чужая длина пути H."
    Dim guardHandle As Integer: guardHandle = FreeFile
    Open mPolishRootTest & "\\Native\\EnvelopePairGuards.csv" For Output As #guardHandle
    Print #guardHandle, "GUARDS;Passed;PairAndPathEqualToNativeReplay;InvalidIndexAndCountRejected"
    Close #guardHandle
'''
    assert 'EnvelopePairGuards.csv' not in code
    code = code.replace(anchor, checks + anchor, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    file = root / 'AllCoupledSources.json'
    if file.exists():
        hashes = json.loads(file.read_bytes())
        for name in paths:
            if name in hashes: hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']: prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(initial_H_when_distinguishable=True, iterative_H_step_adaptation=True,
        plateau_peak_anchor_uses_accepted_history=True, accepted_H_path_guards=True,
        original_force_and_material_criteria=True, original_common_probe_limit=96)
    own = Path(__file__).resolve()
    (root / own.name).write_bytes(own.read_bytes()); prep['inputs'][own.name] = sha256(own.read_bytes()).hexdigest().upper()
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('UNCOMPILED H PREPARATION REFRESHED; ORIGINAL HISTORY AND ACCEPTANCE CRITERIA')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args(); TestRefresh(args.repo.resolve(), args.root.resolve())
