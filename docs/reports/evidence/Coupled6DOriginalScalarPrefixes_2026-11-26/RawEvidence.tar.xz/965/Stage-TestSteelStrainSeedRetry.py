"""ДЛЯ ТЕСТОВ. Повторяет подготовку после фактического RPC-отказа Save/Close; устраняет блокировку GC только в частном драйвере."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root,parent,failed):
    """Не меняет численный VBA и не скрывает отказ: он сохранён отдельно, новая книга снова собирается из проверенного родителя."""
    here=Path(__file__).resolve().parent
    failure=json.loads((failed/'CompilePointFailure.json').read_text('utf-8-sig'))
    closure=json.loads((failed/'CompilePointClosure.json').read_text('utf-8-sig'))
    gc=json.loads((failed/'OwnGCWaitBefore.json').read_text('utf-8-sig'))
    assert closure['State']=='Absent' and closure['PID']==28624
    assert '0x80010100' in failure['Message'] and 'line 189' in failure['ScriptStackTrace']
    assert any('WaitForPendingFinalizers' in line for line in gc['Stack'])
    run_path(str(here/'Stage-TestSteelStrainSeed.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='tools/build_workbook/Update-IsolatedOptimizerCode.ps1';code=(root/name).read_text('utf-8-sig')
    anchor='    $book.Save();$book.Close($false);$book=$null'
    assert code.count(anchor)==1
    code=code.replace(anchor,"    Write-Output 'COMPILE_BEFORE_SAVE'\n    $book.Save()\n    Write-Output 'COMPILE_AFTER_SAVE_BEFORE_CLOSE'\n    $book.Close($false);$book=$null\n    Write-Output 'COMPILE_AFTER_CLOSE'",1)
    anchor='    Restore-WorkbookPrintAreas $path $printAreas';assert code.count(anchor)==1
    code=code.replace(anchor,anchor+"\n    Write-Output 'COMPILE_PRINT_AREAS_RESTORED'",1)
    anchor=code.index('} finally {\n    if ($book)')
    assert code[anchor:].count('WaitForPendingFinalizers')==1
    code=code[:anchor]+'''\n} finally {
    # ДЛЯ ТЕСТОВ: первичная ошибка остаётся ошибкой сборки; очистка не блокируется ожиданием COM-финализаторов перед остановкой собственного PID.
    if ($book) {try {$book.Close($false)} catch {Write-Output ('OWN_CLOSE_WARNING: '+$_.Exception.Message)}}
    if ($excel -and $ownedPid) {try {$excel.Quit()} catch {Write-Output ('OWN_QUIT_WARNING: '+$_.Exception.Message)}}
    if ($ownedPid) {
        $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
        if ($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ownedTicks) {Stop-Process -Id $ownedPid -Force}
    }
    $book=$null;$compile=$null;$module=$null;$component=$null;$components=$null;$project=$null
    if ($excel) {try {[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)} catch {Write-Output ('OWN_RELEASE_WARNING: '+$_.Exception.Message)}}
    $excel=$null
    [GC]::Collect()
}
'''
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),Path(__file__).name:Path(__file__).read_bytes()}
    for item in ('CompilePointFailure.json','CompilePointClosure.json','OwnGCWaitBefore.json','OwnGCWaitCleanupRequested.json'):
        values['Input/FailedSeedCompiler.'+item]=(failed/item).read_bytes()
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(actual_terminal_RPC_compile_failure_preserved=True,
        retry_from_verified_parent_not_partial_saved_book=True,
        compiler_cleanup_wait_removed_only_in_private_test_driver=True,
        save_close_errors_not_ignored=True,source_255_component_check_required=True)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('ACTUAL RPC FAILURE PRESERVED; FRESH SINGLE-MODULE RETRY READY; PRIVATE CLEANUP CORRECTED; NUMERICAL CODE UNCHANGED')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent','failed'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve(),a.failed.resolve())
