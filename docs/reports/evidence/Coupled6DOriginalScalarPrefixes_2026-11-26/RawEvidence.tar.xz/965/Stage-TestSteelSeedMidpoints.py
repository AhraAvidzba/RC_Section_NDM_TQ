"""ДЛЯ ТЕСТОВ. Проверяет промежуточные уровни той же меры, переиспользуя только точную неизменяемую скомпилированную книгу."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct


def TestStage(root,parent):
    """Три промежуточных уровня по два начальных поля; нет нового импорта, повышения бюджета или принятия предполагаемой ветви."""
    here=Path(__file__).resolve().parent
    checked=json.loads((parent/'SteelStrainSeedProof.json').read_bytes())
    assert checked['mathematical_equilibria']==6 and checked['forward_positive_resolved_candidates']==1
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    parent_prep=json.loads((parent/'Preparation.json').read_bytes())
    options=[value for fraction in (.00025,.0005,.00075) for mode in (0,2) for value in (fraction,float(mode))]
    values={'Input/SteelSeedOptions.bin':struct.pack('<i%dd'%len(options),len(options),*options),
        'Input/ParentSteelSeedProof.json':(parent/'SteelStrainSeedProof.json').read_bytes(),
        'Input/ParentSourceComposition.json':(parent/'PointTraceSourceComposition.json').read_bytes(),
        'Run-TestImmutableSteelSeed.ps1':(here/'Run-TestImmutableSteelSeed.ps1').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    compilation=json.loads((parent/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
    exact_files={}
    for name,expected in parent_prep['inputs'].items():
        assert sha256((parent/name).read_bytes()).hexdigest().upper()==expected,name
        if name!='Input/SteelSeedOptions.bin':
            assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name
            exact_files[name]=expected
    for name in ('docs/regression/Diagnostic.xlsm','docs/regression/CodeUpdate.json','CompileClosure.json','PointTraceSourceComposition.json'):
        assert (root/name).read_bytes()==(parent/name).read_bytes(),name
        exact_files[name]=sha256((root/name).read_bytes()).hexdigest().upper()
    assert exact_files['docs/regression/Diagnostic.xlsm']==compilation['WorkbookSHA256']
    reuse=dict(format='NDM_STEEL_SEED_EXACT_REUSE_01',parent=str(parent),
        compiled_workbook_sha256=compilation['WorkbookSHA256'],fresh_compilation_claimed=False,
        actual_import_this_pass=[],immutable_parent_files_verified=exact_files,
        source_component_count=255,parent_other_components_checked=254,
        material_history_reused=False,fresh_replay_required=True,
        only_numerical_trial_options_changed=True,material_laws_limits_tolerances_and_iterations_unchanged=True,
        physical_capacity_certified=False)
    name='CompiledSourceReuseProof.json';raw=(json.dumps(reuse,indent=2,sort_keys=True)+'\n').encode()
    (root/name).write_bytes(raw);prep['inputs'][name]=sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='SteelStrainMidpoints103',actual_import_this_pass=[],
        actual_current_compilation_reused_without_import=True,single_test_module_compiled=False,
        only_numerical_trial_options_changed=True,intermediate_levels_only_not_sequential_halves=True,
        full_candidate_fraction=.001,intermediate_fractions=[.00025,.0005,.00075],
        physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('EXACT COMPILED BOOK REUSED; NO IMPORTS; THREE INTERMEDIATE LEVELS, TWO SEEDS EACH; HISTORY WILL REPLAY FRESH')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve())
