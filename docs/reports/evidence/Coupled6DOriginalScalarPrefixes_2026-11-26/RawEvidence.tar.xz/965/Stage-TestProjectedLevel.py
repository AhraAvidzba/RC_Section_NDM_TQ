"""ДЛЯ ТЕСТОВ. Уменьшает размер материального шага, сохраняя исходные силовые допуски и закон материала."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root,parent,multiplier):
    """Шаг остаётся больше двух исходных допусков управляющей строки; изменение допуска не выполняется."""
    assert 2<multiplier<=10
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    assert not (root/'Input/InitialProjectedResidual.bin').exists(),'Use unchanged initial coordinates for the changed target'
    control=json.loads((root/'Input/MaterialControl.json').read_bytes());assert control['mode']=='projected'
    control['numerical_increment_MPa']=multiplier*control['original_force_tolerance_MPa']
    control['target_MPa']=control['observed_initial_trial_yield_MPa']+control['numerical_increment_MPa']
    control['step_multiplier_to_original_force_tolerance']=multiplier
    name='Input/MaterialControl.json';(root/name).write_bytes((json.dumps(control,indent=2,sort_keys=True)+'\n').encode())
    prep=json.loads((root/'Preparation.json').read_bytes())
    for name in ('Run-TestExternalEnvelope.py',Path(__file__).name):
        (root/name).write_bytes((here/name).read_bytes())
    for name in ('Input/MaterialControl.json','Run-TestExternalEnvelope.py',Path(__file__).name):
        prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='MaterialStepCutbackOriginalForceTolerance',
        material_step_reduced=True,original_force_tolerance_unchanged=True,
        target_is_numerical_control_not_material_strength_limit=True,
        physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('MATERIAL STEP CUT BACK; FORCE TOLERANCE UNCHANGED',control['target_MPa'])


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--parent',type=Path,required=True)
    parser.add_argument('--multiplier',type=float,default=3);args=parser.parse_args()
    TestStage(args.root.resolve(),args.parent.resolve(),args.multiplier)
