"""ДЛЯ ТЕСТОВ. Готовит несколько численных стратегий на одном H-шаге без изменения рабочего ядра."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root, parent):
    """Меняет один тестовый вызов; четыре варианта используют одинаковые физические данные и принятую историю."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root/'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root/name).read_text('utf-8-sig')
    body = (here/'TestEnvelopeDifferenceBatch.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body, code)
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root/name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root/name).read_bytes()).hexdigest().upper()
    cases = [(1e-6, 1., .01), (1e-5, 1., .01), (1e-4, 1., .01), (1e-5, 0., .01)]
    name = 'Input/EnvelopeDifferenceOptions.bin'
    (root/name).write_bytes(run_path(str(here/'Stage-TestMaterialBranchEnergy.py'))['TestVector']([v for case in cases for v in case]))
    prep['inputs'][name] = sha256((root/name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name, 'TestEnvelopeDifferenceBatch.bas.txt'):
        (root/name).write_bytes((here/name).read_bytes())
        prep['inputs'][name] = sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingEnvelopeDifferenceBatch', numeric_variants=cases,
        source_classes_unchanged=True, actual_import_this_pass=['modTestCoupledElasticState'],
        same_accepted_history_for_all_variants=True, original_force_acceptance_criteria=True,
        prepared_working_H_adapter=True, material_parameters_unchanged=True,
        physical_capacity_certified=False, actual_working_Trace_API=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('WORKING H DIFFERENCE BATCH READY; FOUR VARIANTS; ONLY TEST CALLBACK TO IMPORT')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    a = p.parse_args()
    TestStage(a.root.resolve(), a.parent.resolve())
