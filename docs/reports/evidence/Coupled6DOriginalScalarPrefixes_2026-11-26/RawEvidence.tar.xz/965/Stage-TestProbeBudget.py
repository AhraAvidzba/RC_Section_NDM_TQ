"""ДЛЯ ТЕСТОВ. Отделяет действие общего лимита проб от срыва численного шага; рабочий лимит не меняет."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root, parent, budget):
    """Подготавливает единственный исследовательский импорт контроллера; материал, допуски и остальные операции точны."""
    assert budget in (120, 144, 192)
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for before, after in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / after).write_bytes((parent / before).read_bytes())
        prep['inputs'][after] = sha256((root / after).read_bytes()).hexdigest().upper()
    ancestor = root / ('ProbeBudgetAncestor_' + root.name); ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists():
            (root / name).rename(ancestor / name)
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    anchor = 'Private Const PROBE_LIMIT As Long = 96 '
    assert code.count(anchor) == 1
    code = code.replace(anchor, f'Private Const PROBE_LIMIT As Long = {budget} ', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    compiler = (here / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace(
        "-ModuleNames 'modTestCoupledElasticState'", "-ModuleNames 'CCoupledDeformationContinuation'")
    for name, content in {'Compile-TestProbeBudget.ps1': compiler.encode('utf-8-sig'), Path(__file__).name: Path(__file__).read_bytes()}.items():
        (root / name).write_bytes(content); prep['inputs'][name] = sha256(content).hexdigest().upper()
    file = root / 'AllCoupledSources.json'
    if file.exists():
        hashes = json.loads(file.read_bytes())
        name = 'src/Solver/CCoupledDeformationContinuation.cls'
        if name in hashes:
            hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']:
            prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ResearchTotalProbeBudget', actual_import_this_pass=['CCoupledDeformationContinuation'],
        original_core_except_total_probe_cap=True, original_total_probe_cap=96, research_total_probe_cap=budget,
        production_probe_limit_changed=False, material_model_changed=False, equilibrium_tolerance_changed=False,
        per_trial_iteration_budget_unchanged=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('RESEARCH TOTAL PROBE BUDGET READY', budget, '; ONLY PRIVATE CONTROLLER CAP CHANGED; PRODUCTION REMAINS 96')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    parser.add_argument('--budget', type=int, default=120)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve(), args.budget)
