"""ДЛЯ ТЕСТОВ. Отделяет остановку рабочего пути664 по96 пробам от следующего численного препятствия, сохраняя исходные Double."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestStage(root, parent):
    """Меняет только частный общий лимит384; рабочие исходники96, бюджет30 и физика сохраняются."""
    here = Path(__file__).resolve().parent
    source = here / 'Stage-TestProbeBudget.py'
    code = source.read_text('utf-8-sig').replace('assert budget in (120, 144, 192)', 'assert budget == 384', 1)
    namespace = {'__file__': str(source), '__name__': 'cold664_budget_capture_test'}
    exec(compile(code, str(source), 'exec'), namespace)
    namespace['TestStage'](root, parent, 384)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    runner = (here / 'Run-TestHMixedStock.ps1').read_text('utf-8-sig')
    assert runner.count('-TimeoutSeconds 600') == 1
    values = {'Run-TestColdTrustBudget.ps1': runner.replace('-TimeoutSeconds 600', '-TimeoutSeconds 1800', 1).replace('\n', '\r\n').encode('utf-8-sig'),
        Path(__file__).name: Path(__file__).read_bytes()}
    for name, raw in values.items():
        (root / name).write_bytes(raw)
        prep['inputs'][name] = sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='Cold664RawResearch384', working_core_checkpoint=664,
        original_production_probe_limit=96, research_total_probe_cap=384, original_per_trial_iterations=30,
        test_readonly_binary_capture_inherited_exact=True, watchdog_seconds=1800,
        research_probe_cap_not_promoted=True, native_Double_fields_and_load_factors=True,
        physical_capacity_certified=False, entire_goal_completed=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('COLD664 RAW RESEARCH384 READY; ONLY PRIVATE TOTAL CAP CHANGED; PRODUCTION96')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve())
