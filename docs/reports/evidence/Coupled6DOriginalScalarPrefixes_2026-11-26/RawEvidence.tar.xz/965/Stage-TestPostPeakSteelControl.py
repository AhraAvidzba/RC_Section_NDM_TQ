"""ДЛЯ ТЕСТОВ. Проверяет фактическую деформацию стали как меру продолжения после локального максимума146-состоянийной ветви."""
from argparse import ArgumentParser
from hashlib import sha256
import json,re,struct
from pathlib import Path
from runpy import run_path
import numpy as np


def TestStage(repo,root,parent):
    """Сохраняет исходные103 машинных поля;43 последующих переносятся с явно указанной точностью CSV, без будущих корней."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'ContinuedMaterialBudgetProof.json').read_bytes())
    assert proof['final_states']==146 and proof['global_probes']==95 and not proof['physical_capacity_certified']
    read=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original=read(parent/'Input/Reverse1.bin');assert len(original['fields'])==103
    helper=run_path(str(here/'Validate-TestHardPrepared.py'))
    mechanics,fields=helper['TestValidate'](parent,'IntegratedEvent.Sequence')
    records=helper['TestRows'](parent/'Native/IntegratedEvent.Sequence.csv')
    frames=[row for row in records if row[0]=='F'];assert len(frames)==146
    factors=np.asarray([float(row[3]) for row in frames]);fractions=np.asarray([float(row[2]) for row in frames])
    np.testing.assert_allclose(fields[:103],original['fields'],rtol=1e-14,atol=1e-300)
    fields[:103]=original['fields'];factors[:103]=original['lambdas'];fractions[:103]=original['fractions']
    frame=dict(fields=fields,fractions=fractions,lambdas=factors)
    raw=run_path(str(here/'Stage-TestColdRawReplay.py'))['TestTrajectoryBytes'](original,frame)
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    (root/'ContinuedMaterialBudgetProof.json').rename(root/'Inherited.Parent146Proof.json')
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'PostPeakCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    payload=(here/'TestSteelStrainSeed.bas.txt').read_text('utf-8-sig')
    body,=re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',payload)
    def TestReplace(before,after):
        """Точные якоря запрещают случайную правку другого тестового метода."""
        nonlocal body
        assert body.count(before)==1,before
        body=body.replace(before,after,1)
    TestReplace('    Dim originH As Double, trialH As Double, hasOriginH As Boolean, hasTrialH As Boolean',
        '    Dim originH As Double, trialH As Double, hasOriginH As Boolean, hasTrialH As Boolean\n'+
        '    Dim hasRecovered As Boolean, recoveredProjection() As Double')
    TestReplace('        hasOriginH = mReverseSolverTest.TryReadEnvelopeCoordinate(True, originH)',
        '        hasRecovered = False: ReDim recoveredProjection(1 To 1)\n'+
        '        hasOriginH = mReverseSolverTest.TryReadEnvelopeCoordinate(True, originH)')
    TestReplace('            mReverseSolverTest.CopyTrial candidate, actual',
        '            mReverseSolverTest.CopyTrial candidate, actual\n'+
        '            hasRecovered = mReverseSolverTest.CopyRecoveredControl(recoveredProjection)')
    TestReplace('signature = "NDMSTEELCTRL0002"','signature = "NDMSTEELPOST0001"')
    TestReplace('originH, trialH, Abs(CLng(hasTrialH)), Abs(CLng(hasOriginH)), ratio, anchorCoordinate, anchorFactor)',
        'originH, trialH, Abs(CLng(hasTrialH)), Abs(CLng(hasOriginH)), ratio, anchorCoordinate, anchorFactor, Abs(CLng(hasRecovered)))')
    TestReplace('        Close #handle\n        handle = FreeFile',
        '        TestWriteReverseBinaryVector handle, recoveredProjection\n        Close #handle\n        handle = FreeFile')
    code,count=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert count==1
    helper_method,=re.findall(r'(?ms)^Private Function TestSteelSeedCoordinate\(.*?^End Function',payload)
    existing=re.findall(r'(?ms)^Private Function TestSteelSeedCoordinate\(.*?^End Function',code)
    if existing:assert existing==[helper_method]
    else:code+="\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Читает линейную меру выбранной стали.\n"+helper_method+'\n'
    options=[value for fraction,mode in ((.25,1),(.5,0),(.5,1),(1.,1)) for value in (fraction,float(mode))]
    origin=dict(source=str(parent),input_states=146,original103_Double_fields_and_loads_exact=True,
        additional43_fields_and_loads_from15_significant_digit_CSV=True,
        original_full146_Double_bits_not_available=True,full_cold_start=False,
        no_prescribed_future_field_or_material_point=True,new_states_not_accepted=True)
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Input/Reverse1.bin':raw,'Input/SteelSeedOptions.bin':struct.pack('<i8d',8,*options),
        'Input/PostPeakOrigin.json':(json.dumps(origin,indent=2,sort_keys=True)+'\n').encode(),
        'Input/Parent146Proof.json':(parent/'ContinuedMaterialBudgetProof.json').read_bytes(),
        'Compile-TestExternalPoint.ps1':(here/'Compile-TestExternalPoint.ps1').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    for item,content in values.items():
        (root/item).write_bytes(content);prep['inputs'][item]=sha256(content).hexdigest().upper()
    prep['directed_scope']=dict(case='PostPeakActualSteelControl146',actual_import_this_pass=['modTestCoupledElasticState'],
        initial_states=146,independent_trials=4,seed_modes=[1,0,1,1],target_fractions=[.25,.5,.5,1.],
        source_prefix_precision=origin,existing_selector_not_promoted_to_working_code=True,
        original_materials_limits_and_primary30=True,returned_recovered_projection_recorded=True,
        no_future_field_or_steel_point_prescribed=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    checked=read(root/'Input/Reverse1.bin');assert np.array_equal(checked['fields'][:103],original['fields'])
    assert max(map(len,code.splitlines()))<1024
    print('POSTPEAK146 FOUR ACTUAL STEEL-CONTROL PROBES READY; ORIGINAL103 BITS;43CSV TAIL; PRIMARY30; NOT CAPACITY')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
