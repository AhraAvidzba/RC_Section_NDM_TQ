﻿Attribute VB_Name = "modTestColdNewtonCapture"
Option Explicit

' ==========================================================================
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запись уже вычисленных систем и отклонённых направлений Newton.
' Папка независима от остальных исследовательских режимов; материал повторно не вызывается.
' ==========================================================================
Private mCaptureFolderTest As String

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Однократно задаёт существующую папку записи; не меняет исходные поля, материалы и режимы решателя.
Public Sub TestSetCaptureRoot(ByVal folder As String)
    If Len(folder) = 0 Or Len(mCaptureFolderTest) > 0 Then Err.Raise 5, , "Папка записи Newton должна задаваться один раз."
    If Len(Dir$(folder & "\Native", vbDirectory)) = 0 Then Err.Raise 5, , "Не найдена папка нативной записи Newton."
    mCaptureFolderTest = folder
End Sub

Public Sub TestCapture(ByVal phase As Long, ByRef matrix() As Double, ByRef rhs() As Double, _
        ByRef field() As Double, ByRef history() As Double, ByRef residual() As Double, ByVal meta As Variant)
    ' -------------------- ДЛЯ ТЕСТОВ --------------------
    ' Копирует действительную систему до исключения и пробы отклонённого направления.
    ' Материалы повторно не вызываются; сохраняются только уже вычисленные значения.
    Static savedMatrix() As Double, savedRhs() As Double, savedField() As Double, savedHistory() As Double
    Static savedResidual() As Double, savedMeta As Variant, probes As Collection, serial As Long
    If Len(mCaptureFolderTest) = 0 Then Exit Sub
    If phase = 1 Then
        savedMatrix = matrix: savedRhs = rhs: savedField = field: savedHistory = history
        savedResidual = residual: savedMeta = meta: Set probes = New Collection
    ElseIf phase = 2 Then
        If probes Is Nothing Then Err.Raise 5, , "Не сохранена исходная система теста Newton."
        probes.Add Array(meta, field, residual) ' Копии не используют изменяемые массивы решателя после возврата.
    ElseIf phase = 3 Then
        If probes Is Nothing Then Err.Raise 5, , "Нет проб отклонённого направления Newton."
        serial = serial + 1
        If serial > 8192 Then Err.Raise 5, , "Превышен явный лимит записей теста Newton."
        Dim handle As Integer: handle = FreeFile
        Open mCaptureFolderTest & "\Native\NewtonRejected." & Format$(serial, "00000") & ".bin" For Binary Access Write As #handle
        TestWriteBinaryVector handle, savedMeta
        TestWriteBinaryVector handle, savedField
        TestWriteBinaryVector handle, savedHistory
        TestWriteBinaryVector handle, savedResidual
        TestWriteBinaryVector handle, savedRhs
        TestWriteBinaryVector handle, rhs ' Поправка после фактического решения линейной системы.
        Dim column As Long, row As Long, vector() As Double
        ReDim vector(1 To UBound(savedMatrix, 1))
        For row = 1 To UBound(savedMatrix, 2)
            For column = 1 To UBound(vector): vector(column) = savedMatrix(column, row): Next column
            TestWriteBinaryVector handle, vector
        Next row
        TestWriteBinaryVector handle, meta
        TestWriteBinaryVector handle, Array(probes.Count)
        Dim probe As Variant
        For Each probe In probes
            TestWriteBinaryVector handle, probe(0)
            TestWriteBinaryVector handle, probe(1)
            TestWriteBinaryVector handle, probe(2)
        Next probe
        Close #handle
        Set probes = Nothing
    Else
        Err.Raise 5, , "Неизвестная фаза записи Newton."
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает длину и исходные Double без округления в текст; протокол совпадает с ранее проверенной записью вектора.
Private Sub TestWriteBinaryVector(ByVal handle As Integer, ByVal values As Variant)
    Dim count As Long: count = UBound(values) - LBound(values) + 1
    Put #handle, , count
    Dim i As Long, value As Double
    For i = LBound(values) To UBound(values)
        value = CDbl(values(i)): Put #handle, , value
    Next i
End Sub
