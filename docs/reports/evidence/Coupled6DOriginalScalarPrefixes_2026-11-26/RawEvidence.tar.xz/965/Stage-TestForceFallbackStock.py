"""ДЛЯ ТЕСТОВ. Готовит штатный HardShear с рабочим силовым резервом и неизменным читающим наблюдателем."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, parent):
    """Меняет только Newton; родительский контроллер содержит единственный проверенный читающий перехват."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root/'Preparation.json').read_bytes())
    if (root/'NoNewCompilation.json').exists(): (root/'NoNewCompilation.json').rename(root/'StockParentNoNewCompilation.json')
    for before, after in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root/after).write_bytes((parent/before).read_bytes()); prep['inputs'][after] = sha256((root/after).read_bytes()).hexdigest().upper()
    ancestor = root/('ForceStockAncestor_'+root.name); ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root/name).exists(): (root/name).rename(ancestor/name)
    name = 'src/Solver/CCoupledNewtonSolver.cls'; original = (parent/name).read_text('utf-8-sig')
    code = run_path(str(here/'Stage-TestHForceWorking.py'))['TestPatch'](original)
    assert code.startswith((repo/name).read_text('utf-8-sig').rstrip())
    (root/name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig')); prep['inputs'][name] = sha256((root/name).read_bytes()).hexdigest().upper()
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    hook = '    modTestCoupledElasticState.TestCaptureStockContinuation Me, Details()\n'
    controller = (root/name).read_text('utf-8-sig'); assert controller.count(hook) == 1
    assert controller.replace(hook, '', 1) == (repo/name).read_text('utf-8-sig')
    compiler = (here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace("-ModuleNames 'modTestCoupledElasticState'", "-ModuleNames 'CCoupledNewtonSolver'")
    for name, content in {'Compile-TestForceStock.ps1': compiler.encode('utf-8-sig'), Path(__file__).name: Path(__file__).read_bytes()}.items():
        (root/name).write_bytes(content); prep['inputs'][name] = sha256(content).hexdigest().upper()
    path = root/'AllCoupledSources.json'
    if path.exists():
        hashes = json.loads(path.read_bytes()); name = 'src/Solver/CCoupledNewtonSolver.cls'
        if name in hashes: hashes[name] = prep['inputs'][name]
        path.write_bytes((json.dumps(hashes, indent=2, sort_keys=True)+'\n').encode())
        if path.name in prep['inputs']: prep['inputs'][path.name] = sha256(path.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ForceFallbackStock', actual_import_this_pass=['CCoupledNewtonSolver'],
        working_force_fallback_exact=True, only_readonly_controller_hook=True, stock_observer_export_only=True,
        original_force_and_material_criteria=True, entire_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('WORKING FORCE FALLBACK STOCK READY; ONLY NEWTON IMPORT; READONLY OBSERVER')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--parent', type=Path, required=True); args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
