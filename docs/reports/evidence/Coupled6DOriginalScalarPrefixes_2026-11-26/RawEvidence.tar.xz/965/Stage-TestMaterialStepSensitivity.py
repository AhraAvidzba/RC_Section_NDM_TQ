"""ДЛЯ ТЕСТОВ. Меняет только коэффициент увеличения шага CDP при той же истории и материале."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, parent, growth):
    """Повторно использует неизменяемую сборку ядра; контроллер компилируется заново, материалы восстанавливаются холодно."""
    assert growth in (1.15, 1.25, 1.5)
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestStockYieldEvent.py'))['TestStage'](repo, root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    anchor = 'Private Const MATERIAL_STEP_GROWTH As Double = 1.25'
    assert code.count(anchor) == 1
    code = code.replace(anchor, 'Private Const MATERIAL_STEP_GROWTH As Double = ' + str(growth), 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for name in ('Stage-TestMaterialStepSensitivity.py',):
        (root / name).write_bytes((here / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingCDPMaterialGrowthSensitivity',
        material_step_growth=growth, initial_history_states=147,
        actual_import_this_pass=['CCoupledDeformationContinuation'],
        actual_working_Trace_API=True, fresh_native_history_from_zero=False,
        initial_history_replayed_from_zero=True, unchanged_force_material_tolerances=True,
        numerical_reference_is_SciPy=False, actual_full_stock_claimed=False,
        physical_capacity_certified=False,
        controller_working_source_exact_except_material_growth_constant=True,
        all_other_compiled_components_inherited_from_audited_parent=True)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('MATERIAL GROWTH SENSITIVITY READY; growth=', growth)


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=Path.cwd())
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    p.add_argument('--growth', type=float, required=True)
    a = p.parse_args()
    TestStage(a.repo.resolve(), a.root.resolve(), a.parent.resolve(), a.growth)
