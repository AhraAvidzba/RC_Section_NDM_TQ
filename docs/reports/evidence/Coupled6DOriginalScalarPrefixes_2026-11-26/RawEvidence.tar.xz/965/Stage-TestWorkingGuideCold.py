"""ДЛЯ ТЕСТОВ. Готовит настоящий холодный Both/Excel текущего рабочего решателя с читающими снимками истории."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent):
    """Не использует прежние146 полей при расчёте; оставляет рабочие30/96 и добавляет только читающий наблюдатель."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'WorkingGuideUnitProof.json').read_bytes())
    assert proof['current_working_Newton_and_Probe_executed'] and proof['primary_iterations']==13
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'WorkingColdCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):(root/name).rename(ancestor/name)
    name='src/Solver/CCoupledDeformationContinuation.cls';working=(repo/name).read_text('utf-8-sig')
    wrapper=(here/'TestWorkingGuideController.cls.txt').read_text('utf-8-sig')
    anchor='Private Sub NotifyProgress()\n';assert working.count(anchor)==1
    hook='    modTestCoupledElasticState.TestCaptureStockContinuation Me, Details()\n'
    code=working.replace(anchor,anchor+hook,1)
    terminal='    mMeta.SetResult rsNumericalFailure, rcNumericalFailure, rkCapacity, reason, Details()\n'
    assert code.count(terminal)==1
    code=code.replace(terminal,terminal+hook,1)+'\n'+wrapper
    assert code.count(hook)==2 and code.replace(hook,'')==working+'\n'+wrapper
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    needle="-ModuleNames 'modTestCoupledElasticState'";assert compiler.count(needle)==1
    compiler=compiler.replace(needle,"-ModuleNames 'CCoupledDeformationContinuation'")
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Compile-TestExternalPoint.ps1':compiler.replace('\n','\r\n').encode('utf-8-sig'),
        'Run-TestHMixedStock.ps1':(here/'Run-TestHMixedStock.ps1').read_text('utf-8-sig').encode('utf-8-sig'),
        'ParentCodeUpdate.json':(parent/'docs/regression/CodeUpdate.json').read_bytes(),
        'ParentCompileClosure.json':(parent/'CompilePointClosure.json').read_bytes(),
        'Input/ActualWorkingGuideUnitProof.json':(parent/'WorkingGuideUnitProof.json').read_bytes(),
        'Input/CurrentColdController.cls':(repo/name).read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    for item,raw in values.items():(root/item).write_bytes(raw);prep['inputs'][item]=sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingGuideActualCold96',actual_import_this_pass=['CCoupledDeformationContinuation'],
        full_cold_from_zero=True,initial146_input_not_read_by_cold_macro=True,
        native_macro='modTestCoupledElasticState.RunTestStockHTrace',
        controller_exact_current_except_readonly_observer_and_test_wrapper=True,
        working_Newton141_unchanged_parent=True,original_production_probe_limit=96,
        maximum_shared_iterations_each=30,additional_H_budget_not_enabled=True,
        numerical_terminal_history_captured_by_readonly_hook=True,
        physical_capacity_certified=False,all_LoadPaths_not_yet_verified=True)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING GUIDE COLD96 READY; ACTUAL BOTH/EXCEL FROM ZERO; PRIMARY30/GLOBAL96; NO FUTURE HISTORY')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
