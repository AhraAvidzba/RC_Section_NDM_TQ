"""ДЛЯ ТЕСТОВ. Готовит частный линейный контроль растущей деформации фактически заданной арматуры без изменения её закона и пределов."""
from argparse import ArgumentParser
from pathlib import Path


def TestBuild(source,output):
    """Переиспользует проекцию стержня и его собственный знаковый предел; выбранная мера сама по себе не является разрушением."""
    output.mkdir()
    path=source/'src/Materials/CCoupledReinforcedResponse.cls'
    code=path.read_text('utf-8-sig')
    assert 'TrySelectIncreasingSteelStrain' not in code
    code+='''
' Выбирает стержень с наибольшим относительным ростом модуля деформации между двумя принятыми полями.
' Читает только кинематику и заданный предел материала; не вычисляет напряжения и не меняет принятую историю.
Friend Function TrySelectIncreasingSteelStrain(ByVal operators As CCoupledElasticState, _
        ByRef previous() As Double, ByRef current() As Double, ByRef projection() As Double, _
        ByRef coordinate As Double, ByRef spacing As Double, ByRef signedLimit As Double, _
        ByRef governingPoint As Long, ByRef transverse As Boolean) As Boolean
    If Not HasSteel Then Exit Function
    If operators Is Nothing Then Err.Raise 5, "CCoupledReinforcedResponse", "Подготовьте операторы деформации арматуры."
    If LBound(previous) <> 1 Or LBound(current) <> 1 Or UBound(previous) <> operators.DegreeCount Or _
            UBound(current) <> operators.DegreeCount Then Err.Raise 5, "CCoupledReinforcedResponse", "Поля управления арматурой не соответствуют подготовленному сечению."
    Dim point As Long, strain As Double, before As Double, limit As Double, previousLimit As Double
    Dim movement As Double, rate As Double, best As Double, direction As Double, degree As Long
    governingPoint = 0: coordinate = 0#: spacing = 0#: signedLimit = 0#: transverse = False
    For point = mFirstSteel To mLastSteel
        ReadSteelStrain operators, point, previous, before, previousLimit
        ReadSteelStrain operators, point, current, strain, limit
        movement = strain - before
        If movement * strain > 0# And Abs(limit) > Abs(strain) Then
            rate = Abs(movement) / Abs(limit) ' Рост нормируется собственным пределом этого класса стали, а не общим модулем для всех стержней.
            If rate > best Then
                best = rate: governingPoint = point
                direction = Sgn(movement): coordinate = direction * strain: spacing = Abs(movement)
                signedLimit = direction * limit: transverse = (point >= mFirstTransverse)
            End If
        End If
    Next point
    If governingPoint = 0 Then Exit Function
    operators.CopySteelStrainProjection governingPoint, projection
    For degree = 1 To UBound(projection): projection(degree) = direction * projection(degree): Next degree
    TrySelectIncreasingSteelStrain = True
End Function
'''
    (output/path.name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    path=source/'src/Solver/CCoupledNewtonSolver.cls';code=path.read_text('utf-8-sig')
    assert 'SelectSteelStrainDirectionControl' not in code
    code+='''
' Строит линейную меру растущей деформации продольного стержня либо хомута по двум принятым полям.
' Сохраняет нулевые коэффициенты множителей связей; не выполняет материальную пробу или принятие состояния.
Friend Function SelectSteelStrainDirectionControl(ByRef previous() As Double, ByRef current() As Double, _
        ByRef projection() As Double, ByRef coordinate As Double, ByRef spacing As Double, _
        ByRef limit As Double, ByRef point As Long, ByRef transverse As Boolean) As Boolean
    If Not TypeOf mResponse Is CCoupledReinforcedResponse Then Exit Function
    Dim reinforced As CCoupledReinforcedResponse: Set reinforced = mResponse
    Dim physical() As Double, degree As Long
    If Not reinforced.TrySelectIncreasingSteelStrain(mSection, previous, current, physical, _
            coordinate, spacing, limit, point, transverse) Then Exit Function
    If UBound(physical) <> mGaugeStart - 1 Then Err.Raise 5, "CCoupledNewtonSolver", "Размер проекции стержня не соответствует механическим координатам."
    ReDim projection(1 To mDegreeCount)
    For degree = 1 To UBound(physical): projection(degree) = physical(degree): Next degree
    SelectSteelStrainDirectionControl = True
End Function
'''
    (output/path.name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    print('PRIVATE STEEL STRAIN SELECTOR READY; TWO CORE CANDIDATES ONLY; EXISTING MATERIAL LIMITS, NO WORKING SOURCE CHANGE')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('source','output'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestBuild(args.source.resolve(),args.output.resolve())
