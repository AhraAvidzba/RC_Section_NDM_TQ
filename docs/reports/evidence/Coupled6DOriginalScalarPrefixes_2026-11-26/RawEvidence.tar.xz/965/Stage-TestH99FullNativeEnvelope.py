"""ДЛЯ ТЕСТОВ. Проверяет полный H-шаг с новым последним резервом от трёх исходных прогнозов, без внешнего поля и дополнительного бюджета."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
from zipfile import ZipFile


def TestStage(root, parent, candidate):
    """Собирает рабочие кандидаты методов в частной книге; читающий наблюдатель сохраняет только уже вычисленные состояния проходов."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    ancestor = root / 'FullNativeMeritCompilationAncestor'
    ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists(): (root/name).replace(ancestor/name)
    values = {'src/Solver/'+name:(candidate/name).read_bytes()
        for name in ('CCoupledHybridFactorization.cls','CCoupledHybridSolver.cls','CCoupledEnvelopeEquations.cls')}
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root/name).read_text('utf-8-sig')
    canonical = (candidate/'CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    pattern = r'(?ms)^Private Function SolveEnvelopeTarget\(.*?^End Function'
    method, = re.findall(pattern,canonical)
    hook = '        If solver.HasBestPoint Then mLastNorm = solver.BestResidual'
    assert method.count(hook) == 1
    method = method.replace(hook,hook+'\n        modTestCoupledElasticState.TestRecordFullMeritPass pass, remaining, budget, usedSteps, usedCalls, startCoordinates, solution, solver',1)
    code,count = re.subn(pattern,lambda _:method,code)
    assert count == 1
    accessor, = re.findall(r'(?ms)^Friend Sub CopyEquationResultantResidual\(.*?^End Sub',canonical)
    assert 'Friend Sub CopyEquationResultantResidual(' not in code
    code += '\n'+accessor+'\n'
    values[name] = code.replace('\n','\r\n').encode('utf-8-sig')
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root/name).read_text('utf-8-sig')
    body, = re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',(here/'TestColdRawReplay.bas.txt').read_text('utf-8-sig'))
    body = body.replace('    For caseIndex = 0 To 2','    For caseIndex = 0 To 2\n        mFullMeritCaseTest = caseIndex',1)
    code,count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code)
    assert count == 1
    code = code.replace('Option Explicit','Option Explicit\nPrivate mFullMeritCaseTest As Long',1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает счётчики и уже найденные координаты численного прохода без нового вычисления материала или принятия поля.
Public Sub TestRecordFullMeritPass(ByVal pass As Long, ByVal remaining As Long, ByVal budget As Long, _
        ByVal usedSteps As Long, ByVal usedCalls As Long, ByRef initial() As Double, ByRef solution() As Double, ByVal solver As CCoupledHybridSolver)
    If Len(mPolishRootTest) = 0 Then Exit Sub
    Dim handle As Integer: handle = FreeFile
    Dim signature As String: signature = "NDMHFULLPASS0001"
    Open mPolishRootTest & "\\Native\\FullMeritPass.Case" & CStr(mFullMeritCaseTest) & ".Pass" & CStr(pass) & ".bin" For Binary Access Write As #handle
    Put #handle, , signature
    TestWriteReverseBinaryVector handle, Array(mFullMeritCaseTest, pass, remaining, budget, solver.Steps, solver.FunctionCalls, _
        solver.JacobianCalls, solver.BestResidual, solver.StopCode, usedSteps, usedCalls)
    TestWriteReverseBinaryVector handle, initial
    If solver.HasBestPoint Then TestWriteReverseBinaryVector handle, solution Else TestWriteReverseBinaryVector handle, Array(0#)
    Close #handle
End Sub
'''
    assert max(map(len,code.splitlines())) < 1024
    values[name] = code.replace('\n','\r\n').encode('utf-8-sig')
    imports = ['CCoupledHybridFactorization','CCoupledHybridSolver','CCoupledEnvelopeEquations','CCoupledNewtonSolver','modTestCoupledElasticState']
    compiler = (here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace(
        "-ModuleNames 'modTestCoupledElasticState'",'-ModuleNames @('+','.join(repr(v) for v in imports)+')')
    values['Compile-TestExternalPoint.ps1'] = compiler.encode('utf-8-sig')
    values['ParentCodeUpdate.json'] = (parent/'docs/regression/CodeUpdate.json').read_bytes()
    values['ParentCompileClosure.json'] = (parent/'CompileClosure.json').read_bytes()
    for name in (Path(__file__).name,'Build-TestFullForceEnvelopeCandidate.py','Run-TestPersistentHController.ps1','Run-TestHBackendAcceptance.ps1'):
        values[name] = (here/name).read_bytes() if not name.endswith('.ps1') else (here/name).read_text('utf-8-sig').encode('utf-8-sig')
    for name,content in values.items():
        (root/name).write_bytes(content)
        prep['inputs'][name] = sha256(content).hexdigest().upper()
    with ZipFile(parent/'docs/regression/Diagnostic.xlsm') as book:
        (root/'ParentCompiledVBA.bin').write_bytes(book.read('xl/vbaProject.bin'))
    handoff = 'handoffTolerance:=' in canonical
    prep['directed_scope'].update(case='H99FullNativeEnvelopeMerit',actual_import_this_pass=imports,
        full_original_TryEnvelopeStep=True, first_two_methods_unchanged=not handoff,
        first_Newton_method_unchanged=True, own_matrix_early_handoff=handoff,
        only_last_reserve_uses_raw_full_force_merit=True, native_prior_best_same_context=True,
        no_external_answer_or_unaccepted_future_seed=True, maximum_shared_iterations_each=30,
        physical_acceptance_and_half_step_checks_unchanged=True, working_source_changed=False,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('FULL NATIVE H99 STEP READY; THREE NATIVE FORECASTS; ORIGINAL30 SHARED; EARLY HANDOFF',handoff)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    for name in ('root','parent','candidate'):parser.add_argument('--'+name,type=Path,required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(),args.parent.resolve(),args.candidate.resolve())
