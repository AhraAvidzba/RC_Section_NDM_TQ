﻿# ДЛЯ ТЕСТОВ. Направленная проверка H-решателя, без полного набора приёмки.
param([Parameter(Mandatory=$true)][string]$Root,
      [ValidateSet('Unit','Regression','Stock')][string]$Phase='Unit')
$ErrorActionPreference='Stop'
$previousTaskTemp=$env:TEMP; $previousTaskTmp=$env:TMP
Push-Location -LiteralPath $Root
try {
    . './Guard-IsolatedOffice.ps1'
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    foreach($pin in $prep.inputs.psobject.Properties) {
        if((Get-FileHash -LiteralPath $pin.Name).Hash -cne $pin.Value){throw ('Изменён вход '+$pin.Name)}
    }
    $book='docs/regression/Diagnostic.xlsm'
    $compilation=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    if(!$compilation.Compiled -or $compilation.ProductionChanged -or
       (Get-FileHash -LiteralPath $book).Hash -cne $compilation.WorkbookSHA256){throw 'Не подтверждена частная компиляция.'}
    if(Compare-Object ($compilation.Modules|Sort-Object) ($prep.directed_scope.actual_import_this_pass|Sort-Object)){
        throw 'Фактические импорты не соответствуют подготовленному сценарию.'
    }
    Assert-IsolatedOfficeReady ('HBackend'+$Phase)
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path; $env:TMP=$env:TEMP
    if($Phase -eq 'Unit') {
        & './tools/build_workbook/Run-FocusedKaniWatchdog.ps1' -SourceWorkbook $book -ReportPath 'Native/HBackendUnit.txt' `
            -Macro 'modTestCoupledHybrid.RunTestCoupledHybrid' -TimeoutSeconds 600 -Mode No -FailFast
    } elseif($Phase -eq 'Regression') {
        $suite=@('RunCoupledNewtonTests','RunTestCoupledSteelLimit','RunTestCoupledSpatialTransactions','RunTestCoupledContinuation',
            'RunTestCoupledDeformationSteelCrossing','RunTestCoupledHoopCapacity','RunTestCoupledSteelClasses','RunTestCoupledSteelAtDesign',
            'RunTestCoupledDeformationControl','RunTestCoupledRetainedShoulders','RunTestCoupledDesignWitness',
            'RunTestCoupledDiscardedShoulder','RunTestCoupledMinimumLoadStep','RunTestCoupledControlProgress')
        $macro=($suite|ForEach-Object {'modTestCoupledElasticState.'+$_}) -join ','
        & './tools/build_workbook/Run-FocusedKaniWatchdog.ps1' -SourceWorkbook $book -ReportPath 'Native/HBackendRegression.txt' `
            -Macro $macro -TimeoutSeconds 600 -Mode No -FailFast
    } else {
        & './tools/build_workbook/Run-FocusedKaniWatchdog.ps1' -SourceWorkbook $book -ReportPath 'Native/HBackendStock.txt' `
            -Macro 'modTestCoupledElasticState.RunTestCoupledWorkbookTiming' -MacroArgument1 'Both' -MacroArgument2 'Excel' `
            -VerifyResultsReopen -TimeoutSeconds 600 -Mode No -FailFast
    }
    if($LASTEXITCODE -ne 0){throw ('Направленный этап '+$Phase+' завершился с кодом '+$LASTEXITCODE)}
} finally {
    $env:TEMP=$previousTaskTemp; $env:TMP=$previousTaskTmp
    Pop-Location
}
