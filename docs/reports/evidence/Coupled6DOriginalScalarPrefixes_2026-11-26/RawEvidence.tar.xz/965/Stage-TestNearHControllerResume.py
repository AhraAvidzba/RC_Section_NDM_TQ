"""ДЛЯ ТЕСТОВ. Продолжает штатным контроллером точную холодную историю98 с частным уточнением близкого H-приближения."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root, parent):
    """Будущие поля не задаются; собственные двоичные снимки и H-запросы сохраняются прежним читающим наблюдателем."""
    here = Path(__file__).resolve().parent
    proof = json.loads((parent / 'ColdResultantProof.json').read_bytes())
    assert proof['full_states'] == proof['target_prefix'] == 98
    assert all(v['info'][1] == 1 for v in proof['cases'])
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    anchor = '    controller.Trace mReverseSolverTest,mReverseReinforcedTest,mReverseBaseTest,mReverseDirectionTest,fields, _'
    assert code.count(anchor) == 1
    code = code.replace(anchor, '''    mStockProbeRootTest = mPolishRootTest: Set mStockProbeObserverTest = Nothing
    mStockRawHistoryCountTest = 0: mStockHRequestCountTest = 0
''' + anchor, 1)
    anchor = '        mReverseOptionsTest(3),mReverseOptionsTest(4),loadTrace:=trace,observer:=observer'
    assert code.count(anchor) == 1
    code = code.replace(anchor, anchor + '\n    mStockProbeRootTest = vbNullString: Set mStockProbeObserverTest = Nothing', 1)
    runner = (here / 'Run-TestPersistentHController.ps1').read_text('utf-8-sig')
    assert runner.count('-TimeoutSeconds 600 -Mode No -FailFast') == 2
    runner = runner.replace('-TimeoutSeconds 600 -Mode No -FailFast', '-TimeoutSeconds 1800 -Mode No -FailFast', 1)
    origin = dict(parent=str(parent), initial_states=98, initial_history_is_exact_actual_cold=True,
        private_near_H_correction=True, native_controller_Trace_used=True, new_controller_from_existing_history=True,
        full_cold_from_zero=False, raw_Double_fields_and_H_requests_observer=True,
        future_field_or_material_target_not_prescribed=True, watchdog_seconds=1800,
        original_shared_H_iterations30=True, research_controller_probe_limit384=True, production_limit96_unchanged=True)
    values = {name: code.replace('\n', '\r\n').encode('utf-8-sig'),
        'Run-TestNearResume.ps1': runner.encode('utf-8-sig'), Path(__file__).name: Path(__file__).read_bytes(),
        'NearHResumeOrigin.json': (json.dumps(origin, indent=2, sort_keys=True) + '\n').encode()}
    for name, content in values.items():
        (root / name).write_bytes(content)
        prep['inputs'][name] = sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='NearHControllerFromCold98', actual_import_this_pass=['modTestCoupledElasticState'],
        initial_fields=98, full_cold_from_zero=False, source_private_numeric_classes_unchanged=True,
        native_Double_observer=True, future_field_not_prescribed=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING CONTROLLER FROM EXACT COLD98 READY; ONE TEST IMPORT; RAW DOUBLE OBSERVER; NO FUTURE FIELD')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve())
