"""ДЛЯ ТЕСТОВ. Проверяет деление H-восстановления до разрешимого шага внутри существующего общего бюджета."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root, parent):
    """Не меняет материалы и допуски; отдельное ограничение четырьмя переходами не обрывает проверку меньших разрешимых H-шагов."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for source, target in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / target).write_bytes((parent / source).read_bytes())
        prep['inputs'][target] = sha256((root / target).read_bytes()).hexdigest().upper()
    ancestor = root / ('HResolutionAncestor_' + root.name)
    ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists():
            (root / name).rename(ancestor / name)
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    pattern = r'(?ms)^Private Function TryEnvelopeRecovery\(.*?^End Function'
    before, = re.findall(pattern, code)
    anchor = '    Dim previous() As Double, accepted() As Double, seed() As Double, projection() As Double, field() As Double, actual() As Double'
    assert before.count(anchor) == 1
    # Начальный desired ниже ещё уточняется по принятой паре; глубину деления считаем после его окончательного ограничения.
    anchor = '    Dim ratio As Double, factor As Double, probes As Long, degree As Long, previousFactor As Double, fraction As Double'
    assert before.count(anchor) == 1
    after = before.replace(anchor, '''    Dim maximumAttempts As Long, reducedStep As Double
    reducedStep = desired
    Do While reducedStep > 2# * resolution And maximumAttempts < PROBE_LIMIT
        maximumAttempts = maximumAttempts + 1
        reducedStep = 0.5 * reducedStep ' Глубина следует тому же делению, которое выполняется после отказа H-пробы.
    Loop
''' + anchor, 1)
    anchor = 'Do While mEnvelopeAttemptsAtRevision < YIELD_RECOVERY_LIMIT And desired > 2# * resolution And mProbeCount + 2 <= PROBE_LIMIT'
    assert after.count(anchor) == 1
    after = after.replace(anchor, 'Do While mEnvelopeAttemptsAtRevision < maximumAttempts And desired > 2# * resolution And mProbeCount + 2 <= PROBE_LIMIT', 1)
    code = code.replace(before, after, 1)
    values = {name: code.replace('\n', '\r\n').encode('utf-8-sig'), Path(__file__).name: Path(__file__).read_bytes()}
    compiler = (here / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace(
        "-ModuleNames 'modTestCoupledElasticState'", "-ModuleNames 'CCoupledDeformationContinuation'")
    values['Compile-TestExternalPoint.ps1'] = compiler.encode('utf-8-sig')
    for name, data in values.items():
        (root / name).write_bytes(data)
        prep['inputs'][name] = sha256(data).hexdigest().upper()
    file = root / 'AllCoupledSources.json'
    if file.is_file():
        hashes = json.loads(file.read_bytes())
        name = 'src/Solver/CCoupledDeformationContinuation.cls'
        if name in hashes:
            hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']:
            prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='HRecoveryUntilResolution', actual_import_this_pass=['CCoupledDeformationContinuation'],
        H_halving_depth_derived_from_existing_resolution=True, original_total_probe_limit_unchanged=True,
        original_shared_H_iterations30=True, material_transition_limit4_unchanged=True,
        material_and_force_tolerance_unchanged=True, working_source_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('PRIVATE H RECOVERY TO RESOLUTION READY; ONE CONTROLLER IMPORT; SHARED GLOBAL/30 BUDGETS UNCHANGED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve())
