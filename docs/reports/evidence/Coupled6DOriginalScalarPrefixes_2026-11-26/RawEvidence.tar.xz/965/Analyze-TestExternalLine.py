"""ДЛЯ ТЕСТОВ. Восстанавливает фактическую линию поправки из точных запросов, без новых материальных вычислений."""

from argparse import ArgumentParser
import json
from pathlib import Path
import struct
import numpy as np


def TestRead(file):
    """Читает неизменяемые координаты и отклики Double с проверкой длины каждого запроса."""
    raw=file.read_bytes(); assert raw[:16]==b'NDMEXTFTRACE0001'
    n,=struct.unpack_from('<i',raw,16);stride=16+16*n
    assert (len(raw)-20)%stride==0
    records=[]
    for offset in range(20,len(raw),stride):
        values=np.frombuffer(raw,dtype='<f8',offset=offset+16,count=2*n).copy()
        records.append((values[:n],values[n:]))
    return n,records


def TestAnalyze(root):
    """Проверяет одноизломное приближение вдоль направления; его параметры не являются физическим критерием."""
    n,rows=TestRead(root/'Native/ExternalFTrace.bin')
    study=json.loads((root/'Native/ExternalDerivativeStudy.json').read_bytes())['study']
    index=next(i for i,row in enumerate(study) if row['relative_step']==1e-7)
    start=2+index*(2*n+12)
    baseline=rows[0][1];direction=np.asarray(study[index]['correction_coordinates'])
    jac=np.column_stack([(rows[start+2*i][1]-rows[start+2*i+1][1])/
        (rows[start+2*i][0][i]-rows[start+2*i+1][0][i]) for i in range(n)])
    action=jac@direction
    values=[];alphas=[];lines=[]
    for halving in range(11):
        alpha=2.**(-halving);x,f=rows[start+2*n+halving]
        assert np.allclose(x,rows[0][0]+alpha*direction,rtol=0,atol=1e-18)
        defect=f-baseline-alpha*action
        values.append(defect);alphas.append(alpha)
        lines.append(dict(alpha=alpha,max_F_MPa=float(max(abs(f))),
            max_nonlinear_defect_MPa=float(max(abs(defect))),critical_row=int(np.argmax(abs(defect)))+1))
    values=np.asarray(values);alphas=np.asarray(alphas)
    selected=alphas<=0.015625
    def TestFit(location):
        """Подбирает только вектор смены наклона при заданном месте непрерывного излома."""
        hinge=np.maximum(0,alphas[selected]-location)
        slope=hinge@values[selected]/(hinge@hinge)
        error=values[selected]-hinge[:,None]*slope
        return float(np.linalg.norm(error)),slope
    grid=np.linspace(0,min(alphas)*8,10001)
    error,location,slope=min((TestFit(t)[0],float(t),TestFit(t)[1]) for t in grid)
    low=max(0,location-grid[1]);high=min(float(max(grid)),location+grid[1])
    for _ in range(70):
        left=low+(high-low)/3;right=high-(high-low)/3
        if TestFit(left)[0]<TestFit(right)[0]:high=right
        else:low=left
    location=(low+high)/2;error,slope=TestFit(location)
    operators=__import__('runpy').run_path(str(Path(__file__).resolve().parent/'Check-TestHardHalfSteps.py'))['TestOperators']
    _,_,w,v,coordinates,_,_,_=operators(root/'Native/EnvelopeEnergy.Operators.csv',n-1,43)
    ranking=[];physical=56;target=slope[:physical]
    for point in range(25):
        for station,matrix in [('center',w[point,:,:physical].T),('end_pair',v[point,:,:physical].T/(2*.001))]:
            stress_slope=np.linalg.lstsq(matrix,target,rcond=None)[0]
            defect=matrix@stress_slope-target
            ranking.append(dict(point=point+1,station_type=station,
                relative_subspace_error=float(np.linalg.norm(defect)/np.linalg.norm(target)),
                stress_slope_components_MPa=stress_slope.tolist()))
    report=dict(newton_linear_system_error_MPa=float(max(abs(action+baseline))),lines=lines,
        single_hinge_approximation_location=location,single_hinge_error_norm_MPa=error,
        hinge_slope_largest_row=int(np.argmax(abs(slope)))+1,
        hinge_slope_maximum_MPa=float(max(abs(slope))),
        strongest_point_subspaces=sorted(ranking,key=lambda row:row['relative_subspace_error'])[:5],
        maximum_normalized_Newton_correction=float(max(abs(direction))),physical_failure=False)
    return report,jac,direction


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    report,_,_=TestAnalyze(args.root.resolve())
    args.out.write_bytes((json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps(report,indent=2))
