"""ДЛЯ ТЕСТОВ. Собирает рабочий соседний H-прогноз для контроля известного предела, регрессий и штатного поиска."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent):
    """Рабочие классы берёт из репозитория; единственный наблюдатель только записывает состояния штатного продолжения."""
    run_path(str(Path(__file__).parent/'Stage-TestScopedRestartStock.py'))['TestStage'](repo,root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingHNeighborStock',neighbor_initial_guess_without_commit=True,
        production_probe_limit=96,shared_neighbor_iterations_and_evaluations=True)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING H NEIGHBOR STOCK READY; CURRENT CORE; PROBE LIMIT96; OBSERVER ONLY')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--parent',type=Path,required=True)
    args=parser.parse_args();TestStage(args.repo.resolve(),args.root.resolve(),args.parent.resolve())
