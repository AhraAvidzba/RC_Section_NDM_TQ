"""ДЛЯ ТЕСТОВ. Собирает рабочий повтор и его включение только после подтверждённого материального перехода."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, parent):
    """Обновляет Newton и контроллер; единственный читающий наблюдатель остаётся вне рабочей математики."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestRefinedG.py'))['TestStage'](repo, root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (repo / name).read_text('utf-8-sig')
    anchor = 'Private Sub NotifyProgress()\n'
    assert code.count(anchor) == 1
    code = code.replace(anchor, anchor + '    modTestCoupledElasticState.TestCaptureStockContinuation Me, Details()\n', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig')); prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Compile-TestRefinedG.ps1'; code = (root / name).read_text('utf-8-sig')
    assert code.count("-ModuleNames 'CCoupledNewtonSolver'") == 1
    code = code.replace("-ModuleNames 'CCoupledNewtonSolver'", "-ModuleNames @('CCoupledNewtonSolver','CCoupledDeformationContinuation')", 1)
    (root / name).write_bytes(code.encode('utf-8-sig')); prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = Path(__file__).name; (root / name).write_bytes(Path(__file__).read_bytes()); prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    file = root / 'AllCoupledSources.json'
    if file.exists():
        hashes = json.loads(file.read_bytes()); name = 'src/Solver/CCoupledDeformationContinuation.cls'
        if name in hashes:
            hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']:
            prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ScopedRefinedRestartStock', actual_import_this_pass=['CCoupledNewtonSolver','CCoupledDeformationContinuation'],
        restart_only_material_growth_projection=True, production_probe_limit=96, original_force_and_material_criteria=True)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('SCOPED WORKING STOCK READY; NEWTON AND CONTROLLER IMPORTS; PROBE LIMIT 96')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
