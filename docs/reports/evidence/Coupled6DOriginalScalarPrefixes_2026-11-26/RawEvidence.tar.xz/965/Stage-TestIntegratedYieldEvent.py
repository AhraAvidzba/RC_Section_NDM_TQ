"""ДЛЯ ТЕСТОВ. Собирает отдельную книгу с рабочим расширением события CDP и проверяемым холодным входом."""
from pathlib import Path
from runpy import run_path
from hashlib import sha256
import json,re,subprocess
from argparse import ArgumentParser


def TestStage(repo,root,parent):
    """Заменяет рабочие компоненты исходниками ветки и сохраняет только тестовые экспортные методы родителя."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    (root/'ParentCodeUpdate.json').write_bytes((root/'docs/regression/CodeUpdate.json').read_bytes())
    (root/'ParentCompileClosure.json').write_bytes((root/'CompileClosure.json').read_bytes())
    ancestor=root/'IntegratedBuildAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).replace(ancestor/name)
    for name in ('src/Solver/CCoupledNewtonSolver.cls','src/Solver/CCoupledPrincipalTransition.cls'):
        parent_code=(root/name).read_text('utf-8-sig')
        code=(repo/name).read_text('utf-8-sig')
        if name.endswith('CCoupledNewtonSolver.cls'):
            marker='Friend Function ReadReverseControlTest() As Variant'
            assert parent_code.count(marker)==1
            start=parent_code.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,parent_code.index(marker))
            assert start>0
            code+='\n'+parent_code[start:]
        (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
        prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    match=re.search(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub',code);assert match
    before=match.group();anchor='    If Not solver.ReplayAcceptedFields(fields, fields.Count) Then Err.Raise 5, , "Не восстановлена история пространственного продолжения."'
    assert before.count(anchor)==1
    body=before[:before.index(anchor)+len(anchor)]+'\n    TestIntegratedYieldEvent\nEnd Sub'
    code=code[:match.start()]+body+code[match.end():]+'\n'+(here/'TestIntegratedYieldEvent.bas.txt').read_text('utf-8-sig')
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    compiler=compiler.replace("-ModuleNames 'modTestCoupledElasticState'", "-ModuleNames @('CCoupledNewtonSolver','CCoupledPrincipalTransition','modTestCoupledElasticState')")
    (root/'Compile-TestIntegratedYield.ps1').write_bytes(compiler.encode('utf-8-sig'))
    for name in ('ParentCodeUpdate.json','ParentCompileClosure.json','Compile-TestIntegratedYield.ps1',Path(__file__).name,'TestIntegratedYieldEvent.bas.txt'):
        if (here/name).exists():(root/name).write_bytes((here/name).read_bytes())
        prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name='tools/build_workbook/Update-IsolatedOptimizerCode.ps1'
    updater=(root/name).read_text('utf-8-sig')
    before='            $component=$components.Item($file.BaseName)'
    assert updater.count(before)==1
    updater=updater.replace(before,'''            for($componentReadAttempt=0;$componentReadAttempt -lt 3;$componentReadAttempt++) {
                try {$component=$components.Item($file.BaseName);break}
                catch {
                    if($_.Exception.HResult -ne -2147417856 -or $componentReadAttempt -eq 2){throw}
                    Write-Output ('COMPONENT_READ_RETRY: '+$file.BaseName)
                    Start-Sleep -Milliseconds 250
                }
            }''',1)
    before="        } elseif ($module.CountOfLines) {$module.DeleteLines(1,$module.CountOfLines)}\n        $module.AddFromString(($body -split '\\r?\\n') -join \"`r`n\")"
    assert updater.count(before)==1
    updater=updater.replace(before,'''        } else {
            # ДЛЯ ТЕСТОВ: повторяется полная замена частного модуля, а не добавление к возможному частичному результату.
            for($replaceAttempt=0;$replaceAttempt -lt 3;$replaceAttempt++) {
                try {
                    $module=$components.Item($file.BaseName).CodeModule
                    if($module.CountOfLines){$module.DeleteLines(1,$module.CountOfLines)}
                    $module.AddFromString(($body -split '\\r?\\n') -join "`r`n")
                    break
                } catch {
                    if($_.Exception.HResult -ne -2147417856 -or $replaceAttempt -eq 2){throw}
                    Write-Output ('COMPLETE_MODULE_REPLACE_RETRY: '+$file.BaseName)
                    Start-Sleep -Milliseconds 250
                }
            }
        }
        if($EntryPointNames.Count){$module.AddFromString(($body -split '\\r?\\n') -join "`r`n")}''',1)
    (root/name).write_bytes(updater.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingCDPMaterialEventIntegration',working_algorithm_changed=True,
        imported_this_pass=['CCoupledNewtonSolver','CCoupledPrincipalTransition','modTestCoupledElasticState'],
        original_material_precision=True,original_force_acceptance=True,automatic_event_point_selection=True,
        physical_capacity_certified=False,installed_workbook_changed=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    runner=(here/'Run-TestExternalEnvelope.py').read_text('utf-8-sig')
    begin=runner.index("        result['context_open_attempts']=[]")
    end=runner.index('\n    except Exception as error:',begin)
    runner=runner[:begin]+'''        result['outcome']='WorkingMaterialEventDiagnostic;NotCapacity'
        event=root/'Native/IntegratedEvent.csv'
        assert event.exists()
        result['event_trace_sha256']=sha256(event.read_bytes()).hexdigest().upper()
'''+runner[end:]
    (root/'Run-TestIntegratedYield.py').write_bytes(runner.encode())
    prep=json.loads((root/'Preparation.json').read_bytes())
    prep['inputs']['Run-TestIntegratedYield.py']=sha256((root/'Run-TestIntegratedYield.py').read_bytes()).hexdigest().upper()
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING CDP EVENT INTEGRATION READY; AUTOMATIC POINT; ORIGINAL MATERIAL')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,required=True);p.add_argument('--parent',type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
