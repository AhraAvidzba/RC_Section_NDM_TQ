"""ДЛЯ ТЕСТОВ. Воспроизводит остановку dogleg на недоступной пробе при известном корне sqrt(x)-1."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent,retry=False,resume=False):
    """Импортирует только два рабочих тестовых компонента в закрытую частную книгу."""
    here=Path(__file__).resolve().parent
    if resume:
        reuse=json.loads((root/'CompiledSourceReuse.json').read_bytes())
        assert Path(reuse['parent']).resolve()==parent.resolve() and not list((root/'Native').iterdir()) and not list((root/'Temp').iterdir())
        assert sha256((root/'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper()==reuse['compiled_workbook_sha256']
    else:run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    archive=root/('DomainCompilationAncestor_'+root.name);archive.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):(root/name).rename(archive/name)
    imports=['CCoupledHybridSolver','CHybridEquationsTest','modTestCoupledHybrid'] if retry else ['CHybridEquationsTest','modTestCoupledHybrid']
    prep=json.loads((root/'Preparation.json').read_bytes())
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    compiler=compiler.replace("-ModuleNames 'modTestCoupledElasticState'",'-ModuleNames @('+','.join(repr(x) for x in imports)+')')
    runner=(here/'Run-TestWorkingGuideRegressions.ps1').read_text('utf-8-sig')
    old='modTestCoupledEnvelopeControl.RunTestCoupledEnvelopeControl,modTestCoupledElasticState.RunTestCoupledRetainedShoulders,modTestCoupledElasticState.RunTestCoupledDiscardedShoulder'
    assert runner.count(old)==1
    runner=runner.replace(old,'modTestCoupledHybrid.RunTestCoupledHybrid').replace('WorkingGuideRegressions.txt','HybridDomain.txt')
    values={'Compile-TestExternalPoint.ps1':compiler.replace('\n','\r\n').encode('utf-8-sig'),
      'Run-TestHybridDomain.ps1':runner.replace('\n','\r\n').encode('utf-8-sig'),
      'ParentCodeUpdate.json':(parent/'docs/regression/CodeUpdate.json').read_bytes(),
      'ParentCompileClosure.json':(parent/'CompilePointClosure.json').read_bytes(),
      Path(__file__).name:Path(__file__).read_bytes()}
    for name in imports:
        path=('src/Solver/' if name=='CCoupledHybridSolver' else 'tests/')+name+('.cls' if name.startswith('C') else '.bas')
        values[path]=(repo/path).read_bytes()
    for name,raw in values.items():
        (root/name).write_bytes(raw);prep['inputs'][name]=sha256(raw).hexdigest().upper()
    prep['modules']=list(dict.fromkeys(prep['modules']+imports))
    prep['directed_scope'].update(case=('UnavailableDoglegKnownRootRetry' if retry else 'UnavailableDoglegKnownRootBaseline'),actual_import_this_pass=imports,
      no_material_model=True,known_root=1.,initial_coordinate=9.,max_function_evaluations=200,max_steps=200,
      working_hybrid_source_unchanged=not retry,all6_capacity_certified=False)
    (root/'Preparation.json').write_text(json.dumps(prep,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('HYBRID DOMAIN BASELINE STAGED; EXACT ROOT1;INITIAL9;TWO TEST IMPORTS')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--retry',action='store_true')
    p.add_argument('--resume-preparation',action='store_true')
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve(),a.retry,a.resume_preparation)
