"""ДЛЯ ТЕСТОВ. Проверяет резерв V8 на полном холодном пути384, чтобы отделить действие лимита96 от отказа численного метода."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root,parent):
    """Меняет только частный общий бюджет; прежние30 и явно дополнительные16 H-итераций, материалы и допуски сохраняются."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingBudget384.py'))['TestStage'](root,parent)
    before=(parent/'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')
    after=(root/'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')
    assert before.count('Private Const PROBE_LIMIT As Long = 96 ')==1
    assert after==before.replace('Private Const PROBE_LIMIT As Long = 96 ','Private Const PROBE_LIMIT As Long = 384 ',1)
    assert after.count('residualRecoverySteps:=16')==2
    prep=json.loads((root/'Preparation.json').read_bytes())
    prep['directed_scope'].update(case='RetainedNearV8Research384',working_core_checkpoint=665,
        research_candidate='V8 retained first near point, post-failure full67 merit',
        research_probe_limit=384,unchanged_production_probe_limit=96,
        original_H_phase_budget=30,explicit_additional_H_budget=16,
        per_trial_iteration_budget_unchanged_relative_to_parent=True,
        full_cold_from_zero=True,current_input_history_not_used_for_cold_run=True,
        first95_snapshots_must_match_parent=True,
        research_purpose='Test the verified local H99 strategy on a cold path beyond the unchanged ordinary96-budget stop; no numerical failure is treated as physical failure.',
        watchdog_seconds=1800,physical_capacity_certified=False,working_source_changed=False)
    for name in (Path(__file__).name,'Stage-TestWorkingBudget384.py'):
        content=(here/name).read_bytes();(root/name).write_bytes(content)
        prep['inputs'][name]=sha256(content).hexdigest().upper()
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('V8 RESEARCH384 READY; ONLY PRIVATE TOTAL CAP CHANGED; EXPLICIT H30+16; PHYSICAL TOLERANCES UNCHANGED')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('root','parent'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestStage(args.root.resolve(),args.parent.resolve())
