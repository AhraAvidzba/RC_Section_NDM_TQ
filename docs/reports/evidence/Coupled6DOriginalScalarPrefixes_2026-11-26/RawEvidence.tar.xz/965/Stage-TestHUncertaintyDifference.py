"""ДЛЯ ТЕСТОВ. Собирает резерв полной разностной касательной для оценки погрешности H без изменения материала."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent):
    """Дополняет согласованную подготовку рабочим разностным линейризатором и его аналитическими тестами."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHVariant.py'))['TestStage'](repo, root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    added = ['src/Solver/CCoupledHybridSolver.cls', 'tests/modTestCoupledHybrid.bas']
    for name in added:
        assert Path(name).stem in prep['modules']
        (root / name).write_bytes((repo / name).read_text('utf-8-sig').replace('\n', '\r\n').encode('utf-8-sig'))
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    file = root / 'AllCoupledSources.json'
    if file.exists():
        hashes = json.loads(file.read_bytes())
        for name in added:
            if name in hashes: hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']: prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    imports = prep['directed_scope']['actual_import_this_pass'] + [Path(name).stem for name in added]
    file = root / 'Compile-TestHVariant.ps1'; code = file.read_text('utf-8-sig')
    code, count = re.subn(r'-ModuleNames @\([^\r\n]*\)', '-ModuleNames @(' + ','.join("'" + name + "'" for name in imports) + ')', code)
    assert count == 1
    file.write_bytes(code.encode('utf-8-sig')); prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    unit = (root / added[1]).read_text('utf-8-sig')
    assertions = len(re.findall(r'(?m)^    TestCheck ', unit)) + 9
    assert len(re.findall(r'(?m)^        TestCheck ', unit)) == 1 and assertions == 75
    own = Path(__file__).resolve(); (root / own.name).write_bytes(own.read_bytes())
    prep['inputs'][own.name] = sha256(own.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='HUncertaintyFullDifferenceReserve', actual_import_this_pass=imports,
        hybrid_unit_expected_assertions=assertions, analytic_adjoint_failure_has_full_difference_reserve=True,
        material_model_changed=False, equilibrium_tolerance_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('H UNCERTAINTY DIFFERENCE RESERVE READY; FIVE IMPORTS; 75 HYBRID EXPECTATIONS')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
