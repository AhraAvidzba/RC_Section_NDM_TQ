"""ДЛЯ ТЕСТОВ. Собирает точечное уточнение касательной геометрического шага в частной книге."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, parent):
    """Заменяет только Newton; известный бетонный тест, контроллер и штатный наблюдатель сохраняются от проверенного родителя."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for before, after in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / after).write_bytes((parent / before).read_bytes()); prep['inputs'][after] = sha256((root / after).read_bytes()).hexdigest().upper()
    ancestor = root / ('RefinedGAncestor_' + root.name); ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists(): (root / name).rename(ancestor / name)
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    previous = (root / name).read_text('utf-8-sig'); marker = 'Friend Function ReadReverseControlTest() As Variant'
    assert previous.count(marker) == 1
    cut = previous.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, previous.index(marker)); assert cut > 0
    code = (repo / name).read_text('utf-8-sig') + '\n' + previous[cut:]
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig')); prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    file = root / 'AllCoupledSources.json'
    if file.exists():
        hashes = json.loads(file.read_bytes())
        if name in hashes: hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']: prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    compiler = (here / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    compiler = compiler.replace("-ModuleNames 'modTestCoupledElasticState'", "-ModuleNames 'CCoupledNewtonSolver'")
    for name, content in {'Compile-TestRefinedG.ps1': compiler.encode('utf-8-sig'), Path(__file__).name: Path(__file__).read_bytes()}.items():
        (root / name).write_bytes(content); prep['inputs'][name] = sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='RefinedGeometricSpatialTangent', actual_import_this_pass=['CCoupledNewtonSolver'],
        accepted_field_keeps_original_tangent=True, geometric_recovery_flags_unchanged=True,
        read_only_tangent_republishes_material_trial=True, material_model_changed=False,
        equilibrium_tolerance_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('REFINED G PRIVATE BOOK READY; ONE NEWTON IMPORT; MATERIAL AND ACCEPTANCE UNCHANGED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
