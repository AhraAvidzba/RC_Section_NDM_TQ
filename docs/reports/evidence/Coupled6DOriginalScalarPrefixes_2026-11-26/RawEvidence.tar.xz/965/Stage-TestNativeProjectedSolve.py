"""ДЛЯ ТЕСТОВ. Открывает доступ к существующему VBA-решателю на уже проверенной материальной координате."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root,parent):
    """Изменяет один тестовый вход, не переносит алгоритм SciPy и не меняет физические критерии."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    assert 'TestSolveExternalProjectedNative(' not in code
    (root/'ParentPointTestModule.bas').write_bytes((root/name).read_bytes())
    (root/'ParentCodeUpdate.json').write_bytes((root/'docs/regression/CodeUpdate.json').read_bytes())
    (root/'ParentCompileClosure.json').write_bytes((root/'CompileClosure.json').read_bytes())
    ancestor=root/'NativeSolveBuildAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        path=root/name
        if path.exists():path.replace(ancestor/name)
    name='tests/modTestCoupledElasticState.bas'
    code+='\n'+(here/'TestNativeProjectedSolve.bas.txt').read_text('utf-8-sig')
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    for name in ('TestNativeProjectedSolve.bas.txt',Path(__file__).name):(root/name).write_bytes((here/name).read_bytes())
    for name in ('ParentPointTestModule.bas','ParentCodeUpdate.json','ParentCompileClosure.json','TestNativeProjectedSolve.bas.txt',Path(__file__).name):
        prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='OwnVBAProjectedMaterialSolve',
        working_CCoulpedHybridSolver_used_without_changes=True,nonlinear_solver_is_SciPy=False,
        new_import_this_pass=['modTestCoupledElasticState'],maximum_native_steps=30,
        native_inner_stopping_tolerance='initial absolute-plus-relative force tolerance; actual final original force proof mandatory',
        physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('OWN VBA PROJECTED SOLVER ENTRY READY; ORIGINAL MATERIAL AND FINAL FORCE CRITERIA')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--parent',type=Path,required=True);args=parser.parse_args()
    TestStage(args.root.resolve(),args.parent.resolve())
