"""ДЛЯ ТЕСТОВ. Проверяет рабочий H-шаг с собственной касательной и разностным резервом в исходном бюджете."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent, baseline):
    """Новый способ импортирует два рабочих класса; контроль сохраняет точную родительскую компиляцию классов."""
    here = Path(__file__).resolve().parent
    if baseline:
        run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
        imports = ['modTestCoupledElasticState']
    else:
        run_path(str(here / 'Stage-TestHCoordinateGradient.py'))['TestStage'](repo, root, parent)
        imports = ['CCoupledNewtonSolver','CCoupledEnvelopeEquations','modTestCoupledElasticState']
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestWorkingEnvelopeKernel.bas.txt').read_text('utf-8-sig')
    body = body.replace('WorkingEnvelopeKernel;', 'WorkingEnvelopeBackend;')
    anchor = '        Print #handle, "WORKING_DETAILS;" & CStr(attempt) & ";" & mReverseSolverTest.ResultMeta.DiagnosticDetails'
    assert body.count(anchor) == 1
    body = body.replace(anchor, anchor + '\n        Print #handle, "WORKING_EFFORT;" & CStr(attempt) & TestHardPreparedVector(mReverseSolverTest.ReadPolishEffortTest)', 1)
    code, count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body, code)
    assert count == 1
    if 'Private Sub TestWorkingEnvelopeGuards(' not in code:
        code += '\n' + (here / 'TestWorkingEnvelopeGuards.bas.txt').read_text('utf-8-sig')
    names = re.findall(r'(?im)^(?:Public|Private|Friend) (?:Function|Sub) (\w+)', code)
    assert len(names) == len(set(value.lower() for value in names)) and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name, 'TestWorkingEnvelopeKernel.bas.txt', 'TestWorkingEnvelopeGuards.bas.txt'):
        (root / name).write_bytes((here / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    original = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](root / 'Input/Reverse1.bin')
    prep['directed_scope'].update(case=('HBackendBaseline' if baseline else 'HBackendOwnMatrixWithFDReserve'),
        actual_import_this_pass=imports, fresh_compilation_claimed=True, source_classes_unchanged=baseline,
        current_input_states=len(original['fields']), maximum_new_states=8,
        original_force_and_material_criteria=True, original_maximum_iterations=int(original['options'][2]),
        first_method_uses_half_remaining_step_budget=not baseline,
        production_H_backend_changed=not baseline, original_checkpoint637_core=False,
        working_class_sources_current=not baseline,
        new_states_require_original_force_revalidation=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('H BACKEND READY;', 'BASELINE' if baseline else 'CANDIDATE', len(original['fields']), 'EXACT INPUT STATES; 8 NEW STATE LIMIT')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    parser.add_argument('--baseline', action='store_true')
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve(), args.baseline)
