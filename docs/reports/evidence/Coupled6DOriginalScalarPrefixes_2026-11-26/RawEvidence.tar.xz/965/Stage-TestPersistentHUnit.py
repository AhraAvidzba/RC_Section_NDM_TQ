"""ДЛЯ ТЕСТОВ. Добавляет один независимый тестовый модуль к неизменной рабочей компиляции H."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent):
    """Меняет только состав тестов; материалы, решатель и контроллер берутся из точной родительской книги."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for before, after in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / after).write_bytes((root / before).read_bytes()); prep['inputs'][after] = sha256((root / after).read_bytes()).hexdigest().upper()
    ancestor = root / 'UnitCompileAncestor'; ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists(): (root / name).rename(ancestor / name)
    name = 'tests/modTestCoupledEnvelopeControl.bas'
    (root / name).write_bytes((repo / name).read_text('utf-8-sig').replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    assert 'modTestCoupledEnvelopeControl' not in prep['modules']
    prep['modules'].append('modTestCoupledEnvelopeControl')
    compiler = (root / 'Compile-TestPersistentH.ps1').read_text('utf-8-sig')
    compiler, count = re.subn(r"-ModuleNames @\([^\r\n]*\)", "-ModuleNames 'modTestCoupledEnvelopeControl'", compiler)
    assert count == 1
    files = {'Compile-TestPersistentHUnit.ps1': compiler.encode('utf-8-sig'), Path(__file__).name: Path(__file__).read_bytes()}
    for name, raw in files.items():
        (root / name).write_bytes(raw); prep['inputs'][name] = sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='PersistentHUnit', actual_import_this_pass=['modTestCoupledEnvelopeControl'],
        source_classes_unchanged=True, fresh_compilation_claimed=True, independent_uniaxial_capacity_reference='fc*A',
        three_independent_material_histories=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('PERSISTENT H UNIT READY; ONE TEST MODULE, WORKING CLASSES UNCHANGED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
