"""ДЛЯ ТЕСТОВ. Собирает рабочую материальную координату с точным происхождением пяти рабочих классов и тестового вызова."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path

TestWorking = ('src/Materials/CCoupledConcreteResponse.cls', 'src/Materials/CCoupledReinforcedResponse.cls',
    'src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledDeformationContinuation.cls', 'src/Solver/CCoupledEnvelopeEquations.cls')


def TestStage(repo, root, parent):
    """Переносит рабочий код без тестовых упрощений; старые читающие экспорты остаются отдельным суффиксом частной сборки."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestMaterialBranchEnergy.py'))['TestStage'](root, parent, 184, 1.)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for name in TestWorking:
        code = (repo / name).read_text('utf-8-sig')
        marker = None
        if name.endswith('CCoupledNewtonSolver.cls'):
            marker = 'Friend Function ReadReverseControlTest() As Variant'
        elif name.endswith('CCoupledConcreteResponse.cls'):
            marker = 'Friend Function ReadNewtonYieldEventStateTest('
        if marker:
            old = (root / name).read_text('utf-8-sig')
            assert old.count(marker) == 1
            cut = old.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, old.index(marker))
            assert cut > 0
            code += '\n' + old[cut:]
        (root / name).parent.mkdir(parents=True, exist_ok=True)
        (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
        if Path(name).stem not in prep['modules']:
            prep['modules'].append(Path(name).stem)
    all_sources = root / 'AllCoupledSources.json'
    if all_sources.is_file():
        sources = json.loads(all_sources.read_bytes())
        for name in sources:
            if name in TestWorking:
                sources[name] = sha256((root / name).read_bytes()).hexdigest().upper()
        all_sources.write_bytes((json.dumps(sources, indent=2, sort_keys=True) + '\n').encode())
        if all_sources.name in prep['inputs']:
            prep['inputs'][all_sources.name] = sha256(all_sources.read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestWorkingEnvelopeKernel.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body, code)
    code += '\n' + (here / 'TestWorkingEnvelopeGuards.bas.txt').read_text('utf-8-sig')
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    imports = [Path(name).stem for name in TestWorking] + ['modTestCoupledElasticState']
    compiler = (here / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    anchor = "-ModuleNames 'modTestCoupledElasticState'"
    assert compiler.count(anchor) == 1
    compiler = compiler.replace(anchor, '-ModuleNames @(' + ','.join("'" + n + "'" for n in imports) + ')', 1)
    contents = {'Compile-TestWorkingEnvelope.ps1': compiler.encode('utf-8-sig'),
        Path(__file__).name: Path(__file__).read_bytes(),
        'TestWorkingEnvelopeKernel.bas.txt': (here / 'TestWorkingEnvelopeKernel.bas.txt').read_bytes(),
        'TestWorkingEnvelopeGuards.bas.txt': (here / 'TestWorkingEnvelopeGuards.bas.txt').read_bytes()}
    for name, raw in contents.items():
        (root / name).write_bytes(raw)
        prep['inputs'][name] = sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingEnvelopeKernel', actual_import_this_pass=imports,
        working_class_sources_current=True, working_material_and_force_tolerances_unchanged=True,
        test_only_methods_are_readonly_exports_not_production_dependencies=True,
        component_count_expected=254, virtual_source_components_expected=41, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING ENVELOPE READY; SIX IMPORTS, ONE NEW WORKING CLASS, ORIGINAL TOLERANCES')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=Path.cwd())
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    a = p.parse_args()
    TestStage(a.repo.resolve(), a.root.resolve(), a.parent.resolve())
