"""ДЛЯ ТЕСТОВ. Проверяет исправление достижимости резерва одним импортом контроллера в подтверждённой книге настоящего Trace."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent):
    """Сохраняет Newton, тест и все103 исходных поля; новый вариант не получает готового будущего решения."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'WorkingDepartureTraceProof.json').read_bytes())
    assert proof['current140_Newton_methods_verified'] and proof['current_controller_verified']
    assert proof['initial_states']==proof['final_states']==103 and proof['new_reserve_attempts']==0
    assert proof['internal_status']==6 and proof['result_code']==10
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    (root/'WorkingDepartureTraceProof.json').rename(root/'Inherited.UnreachedReserveTraceProof.json')
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'EligibilityCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    name='src/Solver/CCoupledDeformationContinuation.cls';controller=(repo/name).read_bytes()
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    anchor="-ModuleNames 'modTestCoupledElasticState'";assert compiler.count(anchor)==1
    compiler=compiler.replace(anchor,"-ModuleNames 'CCoupledDeformationContinuation'")
    values={name:controller,'Input/WorkingDepartureController.cls':controller,
        'Compile-TestExternalPoint.ps1':compiler.replace('\n','\r\n').encode('utf-8-sig'),
        'Input/UnreachedReserveTraceProof.json':(parent/'WorkingDepartureTraceProof.json').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    for item,raw in values.items():
        (root/item).write_bytes(raw);prep['inputs'][item]=sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingDepartureExhaustedHEligibility103',
        actual_import_this_pass=['CCoupledDeformationContinuation'],
        failed_H_attempts_on_same_revision_enable_one_reserve=True,
        exact_parent_Newton_and_test_preserved=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('H EXHAUSTION ELIGIBILITY READY; ONE CONTROLLER IMPORT; SAME103FIELDS/NEWTON/TEST')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
