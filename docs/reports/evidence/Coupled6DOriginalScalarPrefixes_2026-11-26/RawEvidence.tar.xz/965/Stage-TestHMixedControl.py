"""ДЛЯ ТЕСТОВ. Собирает смешанное геометрическое/H-продолжение и читающую запись штатного пути."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent):
    """Тестовый перехват передаёт наблюдателю только копии принятых полей; рабочая математика смены меры берётся из исходников."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHUncertaintyDifference.py'))['TestStage'](repo, root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    anchor = 'Private Sub NotifyProgress()\n    If mObserver Is Nothing Then Exit Sub'
    assert code.count(anchor) == 1
    code = code.replace(anchor, 'Private Sub NotifyProgress()\n'
        '    modTestCoupledElasticState.TestCaptureStockContinuation Me, Details()\n'
        '    If mObserver Is Nothing Then Exit Sub', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    changed = [name]
    name = 'tests/modTestCoupledElasticState.bas'; code = (root / name).read_text('utf-8-sig')
    assert 'TestCaptureStockContinuation' not in code
    assert code.count('Option Explicit\n') == 1
    code = code.replace('Option Explicit\n', 'Option Explicit\n\nPrivate mStockProbeObserverTest As CCoupledProgressObserverTest\nPrivate mStockProbeRootTest As String\n', 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт только независимые копии состояния штатного продолжения существующему файловому наблюдателю.
Public Sub TestCaptureStockContinuation(ByVal branch As CCoupledDeformationContinuation, ByVal details As String)
    Dim folder As String: folder = mStockProbeRootTest
    If Len(folder) = 0 Then Exit Sub
    If mStockProbeObserverTest Is Nothing Or folder <> mStockProbeRootTest Then
        Set mStockProbeObserverTest = New CCoupledProgressObserverTest
        mStockProbeObserverTest.TestInitialize folder & "\\Native\\Stock.Checkpoints.csv"
        mStockProbeRootTest = folder
    End If
    Dim fields As Collection, trace As CCoupledLoadTrace, meta As CResultMeta
    Set fields = branch.AcceptedFields: Set trace = branch.SavedTrace
    If fields Is Nothing Or trace Is Nothing Then Exit Sub
    If fields.Count <> trace.Count Then Err.Raise 5, , "Не согласован штатный контрольный снимок."
    Set meta = branch.ResultMeta.Clone: meta.DiagnosticDetails = details
    Dim observer As ICoupledContinuationProgress: Set observer = mStockProbeObserverTest
    observer.Report fields, trace, meta
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запускает существующий штатный тест Both/Excel с записью принятых состояний в переданный частный каталог.
Public Function RunTestStockHTrace(ByVal root As String) As String
    mStockProbeRootTest = root: Set mStockProbeObserverTest = Nothing
    RunTestStockHTrace = RunTestCoupledWorkbookTiming("Both", "Excel")
End Function
'''
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper(); changed.append(name)
    file = root / 'AllCoupledSources.json'
    if file.exists():
        hashes = json.loads(file.read_bytes())
        for name in changed:
            if name in hashes: hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']: prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    imports = prep['directed_scope']['actual_import_this_pass'] + ['modTestCoupledElasticState']
    file = root / 'Compile-TestHVariant.ps1'; code = file.read_text('utf-8-sig')
    code, count = re.subn(r'-ModuleNames @\([^\r\n]*\)', '-ModuleNames @(' + ','.join("'" + name + "'" for name in imports) + ')', code)
    assert count == 1
    file.write_bytes(code.encode('utf-8-sig')); prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    own = Path(__file__).resolve(); (root / own.name).write_bytes(own.read_bytes())
    prep['inputs'][own.name] = sha256(own.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='MixedHGeometryControl', actual_import_this_pass=imports,
        stock_observer_export_only=True, premature_initial_H_for_steel_disabled=True,
        H_stagnation_can_restore_geometric_control=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('MIXED H CONTROL READY; SIX IMPORTS; OPTIONAL READ-ONLY STOCK CHECKPOINTS')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
