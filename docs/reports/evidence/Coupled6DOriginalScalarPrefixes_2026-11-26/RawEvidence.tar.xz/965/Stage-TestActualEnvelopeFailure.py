"""ДЛЯ ТЕСТОВ. Выделяет реально не сошедшийся H-уровень из двух законченных снимков неизменной принятой истории."""
from argparse import ArgumentParser
from hashlib import sha256
import csv,io,json,re,struct
from pathlib import Path
from runpy import run_path
import numpy as np


def TestStage(root,parent,trace_root,candidate_index=0):
    """Первый префикс 147 сохраняет в исходных Double, остальные поля восстанавливает из подлинного десятичного журнала."""
    here=Path(__file__).resolve().parent
    raw=(trace_root/'Native/Controller.Checkpoints.csv').read_bytes()
    blocks=[];current=None
    for row in csv.reader(io.StringIO(raw.decode('cp1251')),delimiter=';'):
        if not row:continue
        if row[0]=='CHECKPOINT':current=dict(call=int(row[1]),count=int(row[2]),details='',points=[])
        elif current is not None and row[0]=='DETAILS':current['details']=';'.join(row[1:])
        elif current is not None and row[0]=='P':current['points'].append(row[1:])
        elif current is not None and row[0]=='CHECKPOINT_END':
            assert int(row[1])==current['call'] and len(current['points'])==current['count']
            blocks.append(current);current=None
    candidates=[]
    pattern=r'цель H ([\d.Ee+\-]+) МПа, остановка (\d+), невязка ([\d.Ee+\-]+) МПа'
    for first,second in zip(blocks,blocks[1:]):
        if first['points']!=second['points'] or first['details']==second['details']:continue
        for target,stop,residual in re.findall(pattern,second['details']):
            if int(stop)==5 and float(residual)>1e-5:candidates.append((first,second,float(target),float(residual)))
    first,selected,target,reported=candidates[candidate_index]
    read=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original=read(trace_root/'Input/Reverse1.bin');template=read(parent/'Input/Reverse1.bin')
    assert len(original['fields'])==147
    for key in ('calibration','options','offset','direction'):assert np.array_equal(original[key],template[key]),key
    count=selected['count'];assert 147<count<1000
    assert [int(r[0]) for r in selected['points']]==list(range(1,count+1))
    fields=np.asarray([r[3:] for r in selected['points']],float)
    fractions=np.asarray([r[1] for r in selected['points']],float)
    factors=np.asarray([r[2] for r in selected['points']],float)
    assert fields.shape==(count,60)
    np.testing.assert_allclose(fields[:147],original['fields'],rtol=1e-14,atol=1e-300)
    fields[:147],fractions[:147],factors[:147]=original['fields'],original['fractions'],original['lambdas']
    vector=run_path(str(here/'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    snapshot=b'NDMREVTEST000001'+struct.pack('<i',60)
    for key in ('calibration','options','offset','direction'):snapshot+=vector(original[key])
    snapshot+=struct.pack('<i',count)
    for fraction,factor,field in zip(fractions,factors,fields):snapshot+=struct.pack('<dd',fraction,factor)+vector(field)
    for values in (fields[-2],fields[-1],fields[-1],original['offset']+factors[-1]*original['direction'],
                   original['projection'],[factors[-1],0.,factors[-1],0.],np.zeros(4)):
        snapshot+=vector(values)
    run_path(str(here/'Stage-TestEnvelopeDifferenceBatch.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    options=[(1e-6,1.,1.),(1e-5,1.,1.),(1e-4,1.,1.),(1e-5,0.,1.)]
    metadata=dict(source=trace_root.name,before_call=first['call'],after_call=selected['call'],
        count=count,target_H=target,reported_failed_residual_MPa=reported,
        accepted_fields_identical_in_two_source_snapshots=True,source_checkpoint_sha256=sha256(raw).hexdigest().upper(),
        first147_original_Double=True,later_fields_decimal_reconstructed=True,
        secant_predictor_reconstructed_not_original_machine_bits=True,physical_failure=False)
    pair=b''
    for block in (first,selected):
        begin=raw.index(('CHECKPOINT;'+str(block['call'])+';').encode())
        end=raw.index(('CHECKPOINT_END;'+str(block['call'])).encode(),begin)
        end=raw.find(b'\n',end)+1
        assert end>begin
        pair+=raw[begin:end]
    contents={'Input/Reverse1.bin':snapshot,'Input/EnvelopeFailureLevel.bin':vector([target]),
        'Input/EnvelopeDifferenceOptions.bin':vector([v for case in options for v in case]),
        'Input/FailureCheckpointPair.csv':pair,'Input/FailureOrigin.json':(json.dumps(metadata,indent=2,sort_keys=True)+'\n').encode()}
    for name,data in contents.items():(root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    anchor='    Dim target As Double: target = baseline + increment';assert code.count(anchor)==1
    extra='''
    Dim failedHandleTest As Integer: failedHandleTest = FreeFile
    Open mPolishRootTest & "\\Input\\EnvelopeFailureLevel.bin" For Binary Access Read As #failedHandleTest
    Dim failedInputTest As Variant: failedInputTest = TestReadPolishVector(failedHandleTest)
    If Seek(failedHandleTest) <> LOF(failedHandleTest) + 1 Then Err.Raise 5, , "Лишние байты исходной неудачной H-цели."
    Close #failedHandleTest
    If LBound(failedInputTest) <> 1 Or UBound(failedInputTest) <> 1 Then Err.Raise 5, , "Нужен один исходный H-уровень."
    target = failedInputTest(1)
    If target <= baseline Or increment <= 0# Then Err.Raise 5, , "Исходный H-уровень не продолжает принятую историю."
    Dim predictorRatioTest As Double: predictorRatioTest = GeomMin(1024#, (target - baseline) / increment)
'''
    code=code.replace(anchor,anchor+extra,1)
    anchor='seed(degree) = accepted(degree) + accepted(degree) - previous(degree)';assert code.count(anchor)==1
    code=code.replace(anchor,'seed(degree) = accepted(degree) + predictorRatioTest * (accepted(degree) - previous(degree))',1)
    anchor='projection, coordinate, seed, 2# * factor - previousFactor)';assert code.count(anchor)==1
    code=code.replace(anchor,'projection, coordinate, seed, factor + predictorRatioTest * (factor - previousFactor))',1)
    assert max(map(len,code.splitlines()))<1024
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ActualFailedEnvelopeLevel',initial_history_states=count,
        requested_H_from_actual_failure=target,reported_source_residual_MPa=reported,
        original_force_and_material_tolerances=True,first147_original_Double=True,
        later_fields_decimal_reconstructed=True,predictor_reconstructed=True,
        source_classes_unchanged=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('ACTUAL FAILED H LEVEL READY;',count,'STATES; TARGET',target,'SOURCE RESIDUAL',reported)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent','trace-root'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--candidate-index',type=int,default=0);a=p.parse_args()
    TestStage(a.root.resolve(),a.parent.resolve(),a.trace_root.resolve(),a.candidate_index)
