"""ДЛЯ ТЕСТОВ. Предоставляет SciPy точные рабочие уравнения H после остановки Newton; закон материала остаётся в VBA."""
from argparse import ArgumentParser
from hashlib import sha256
import csv,json,re
from pathlib import Path
from runpy import run_path


def TestStage(root,parent,homotopy):
    """Задаёт единственную неудачную цель 3/4 и её лучшее приближение; всё численное интегрирование материала выполняет исходное ядро."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingControllerResume.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    rows=list(csv.reader((homotopy/'Native/IntegratedEvent.csv').read_text('cp1251').splitlines(),delimiter=';'))
    field=next([float(v) for v in r[2:]] for r in rows if r[0]=='FIELD' and r[1]=='4')
    factor=next(float(r[2]) for r in rows if r[0]=='BEST' and r[1]=='4')
    target=next(float(r[2]) for r in rows if r[0]=='LEVEL' and r[1]=='4')
    vector=run_path(str(here/'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    for name,data in {'Input/ExternalSeed.bin':vector(field+[factor]),
        'Input/EnvelopeFailureLevel.bin':vector([target]),
        'Input/HomotopySourceEvent.csv':(homotopy/'Native/IntegratedEvent.csv').read_bytes()}.items():
        (root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    code,n=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',
        lambda _:'''Private Sub TestIntegratedYieldEvent()
    mPolishExecutedTest = True
End Sub''',code);assert n==1
    assert code.count('Private mExternalEnvelopeTest As CEnvelopeEnergyEquationsTest')==1
    code=code.replace('Private mExternalEnvelopeTest As CEnvelopeEnergyEquationsTest','Private mExternalEnvelopeTest As CCoupledEnvelopeEquations',1)
    body='''Public Function TestOpenExternalEnvelope(ByVal fraction As Double, ByVal seedKind As Long) As Variant
    mReverseSolverTest.EndNewtonLineTest
    Dim fields As Collection, trace As CCoupledLoadTrace, previous() As Double, accepted() As Double
    Dim unused() As Double, projection() As Double, context() As Double
    TestReadPolishSnapshot mPolishRootTest & "\\Input\\Reverse1.bin", fields, trace, previous, accepted, unused, projection, context
    Set mReverseFieldsTest = fields: Set mReverseTraceTest = trace.CopyPrefix(trace.Count)
    Dim factor As Double, previousFactor As Double, ignoredFraction As Double, baseline As Double, resolution As Double
    trace.ReadPoint trace.Count, ignoredFraction, factor: trace.ReadPoint trace.Count - 1, ignoredFraction, previousFactor
    If Not mReverseSolverTest.TryEnvelopeControlState(mReverseBaseTest, mReverseDirectionTest, factor, _
            mReverseOptionsTest(3), mReverseOptionsTest(4), baseline, resolution) Then Err.Raise 5, , "Нет исходной рабочей H-координаты."
    Dim handle As Integer: handle = FreeFile
    Open mPolishRootTest & "\\Input\\EnvelopeFailureLevel.bin" For Binary Access Read As #handle
    Dim targetInput As Variant: targetInput = TestReadPolishVector(handle): Close #handle
    Open mPolishRootTest & "\\Input\\ExternalSeed.bin" For Binary Access Read As #handle
    Dim seedValuesTest As Variant: seedValuesTest = TestReadPolishVector(handle): Close #handle
    If UBound(seedValuesTest) <> 61 Or UBound(targetInput) <> 1 Then Err.Raise 5, , "Неверный размер внешнего рабочего H-теста."
    Dim seed() As Double: ReDim seed(1 To 60)
    Dim index As Long
    For index = 1 To 60: seed(index) = seedValuesTest(index): Next index
    If Not mReverseSolverTest.BeginNewtonLineTest(mReverseBaseTest, mReverseDirectionTest, projection, 0#, seed, CDbl(seedValuesTest(61))) Then Err.Raise 5, , "Не открыт рабочий H-контекст."
    Dim prepared As New CCoupledEnvelopeEquations
    prepared.Initialize Nothing, mReverseOperatorsTest, mReverseReinforcedTest, mReverseSidesTest(2), mReverseSidesTest(4), 0.001, mReverseCalibrationTest(0) / mReverseCalibrationTest(3)
    Set mExternalEnvelopeTest = prepared.AtTarget(mReverseSolverTest, CDbl(targetInput(1)))
    mExternalEnergyTargetTest = targetInput(1): mExternalRowScaleTest = prepared.RowScale
    mExternalToleranceTest = resolution * prepared.RowScale
    TestOpenExternalEnvelope = Array(61, baseline, mExternalEnergyTargetTest, mExternalToleranceTest, mExternalRowScaleTest, factor, seedValuesTest(61), 1#, previousFactor, mReverseSolverTest.EquationContext, mReverseSolverTest.AcceptedRevision)
End Function'''
    code,n=re.subn(r'(?ms)^Public Function TestOpenExternalEnvelope\(.*?^End Function',lambda _:body,code);assert n==1
    anchor='mExternalEnvelopeTest.TrialEnergyTest(field,energy)';assert code.count(anchor)==1
    code=code.replace(anchor,'mExternalEnvelopeTest.TryCoordinate(field,energy)',1)
    methods=re.findall(r'(?im)^(?:Public|Private|Friend) (?:Function|Sub) (\w+)',code)
    assert len(methods)==len(set(v.lower() for v in methods)) and max(map(len,code.splitlines()))<1024
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    runner=(here/'Run-TestExternalEnvelope.py').read_text('utf-8-sig')
    anchor="        material=json.loads(material_path.read_bytes()) if material_path.exists() else None";assert runner.count(anchor)==1
    runner=runner.replace(anchor,'        material=None # Этот тест использует только рабочую H-строку; прежние диагностические строки не применяются.',1)
    for anchor in ("        if (root/'Input/InitialCoordinates.bin').exists():","        if (root/'Input/InitialResidual.bin').exists():"):
        assert runner.count(anchor)==1
        runner=runner.replace(anchor,'        if False: # Неприменимый вход другого диагностического контекста не читается.',1)
    name='Run-TestExactWorkingH.py';(root/name).write_bytes(runner.encode());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ExternalTRFExactWorkingH',
        source_classes_unchanged=True,actual_import_this_pass=['modTestCoupledElasticState'],
        working_H_adapter=True,working_material_integrated_in_VBA=True,
        target_H_MPa=target,seed_is_unaccepted_best_point=True,external_dependency_in_production=False,
        physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('EXACT WORKING H FOR EXTERNAL TRF READY; MATERIAL STAYS IN VBA')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent','homotopy'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve(),a.homotopy.resolve())
