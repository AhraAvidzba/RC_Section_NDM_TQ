"""ДЛЯ ТЕСТОВ. Открывает доступ к существующему рабочему адаптеру материальной координаты без изменения материала."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root,parent):
    """Меняет только тестовый модуль; состав рабочего ядра и силовая точность сохраняются."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestMaterialCoordinate.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    (root/'ParentPointTestModule.bas').write_bytes((root/name).read_bytes())
    (root/'ParentCodeUpdate.json').write_bytes((root/'docs/regression/CodeUpdate.json').read_bytes())
    (root/'ParentCompileClosure.json').write_bytes((root/'CompileClosure.json').read_bytes())
    ancestor=root/'BuildAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        path=root/name
        if path.exists():path.replace(ancestor/name)
    anchor='Private mExternalEnvelopeTest As CEnvelopeEnergyEquationsTest'
    assert code.count(anchor)==1
    code=code.replace(anchor,anchor+'\nPrivate mExternalProjectedControlTest As CCoupledConstraintEquations',1)
    anchor='    TestExternalCoordinates source,coordinates: Set equations = mExternalEnvelopeTest'
    assert code.count(anchor)==1
    code=code.replace(anchor,'''    TestExternalCoordinates source,coordinates
    If mExternalProjectedControlTest Is Nothing Then
        Set equations = mExternalEnvelopeTest
    Else
        Set equations = mExternalProjectedControlTest
    End If''',1)
    mapping='''    If Not mExternalProjectedControlTest Is Nothing Then
        Dim projectedCoordinates() As Double
        If Not mExternalProjectedControlTest.TryMap(coordinates, projectedCoordinates) Then Err.Raise 5, , "Не восстановлены действительные координаты материальной пробы."
        coordinates = projectedCoordinates
    End If
'''
    anchor='    TestExternalCoordinates source, coordinates\n    mReverseSolverTest.ReadNewtonLineFieldTest coordinates, field, factor'
    assert code.count(anchor)==1
    code=code.replace(anchor,'    TestExternalCoordinates source, coordinates\n'+mapping+'    mReverseSolverTest.ReadNewtonLineFieldTest coordinates, field, factor',1)
    anchor='    TestExternalCoordinates source,coordinates: mReverseSolverTest.ReadNewtonLineFieldTest coordinates,field,factor'
    assert code.count(anchor)==1
    code=code.replace(anchor,'    TestExternalCoordinates source,coordinates\n'+mapping+'    mReverseSolverTest.ReadNewtonLineFieldTest coordinates,field,factor',1)
    start=code.index('Public Function TestOpenExternalEnvelope(');end=code.index('\nEnd Function',start)
    body=code[start:end];anchor='    mReverseSolverTest.EndNewtonLineTest'
    assert body.count(anchor)==1
    body=body.replace(anchor,'    Set mExternalProjectedControlTest = Nothing\n'+anchor,1)
    code=code[:start]+body+code[end:]
    code+='\n'+(here/'TestNativeExternalProjected.bas.txt').read_text('utf-8-sig')
    name='tests/modTestCoupledElasticState.bas'
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    control=json.loads((root/'Input/MaterialControl.json').read_bytes());control['mode']='projected'
    (root/'Input/MaterialControl.json').write_bytes((json.dumps(control,indent=2,sort_keys=True)+'\n').encode())
    for name in (Path(__file__).name,'TestNativeExternalProjected.bas.txt'):(root/name).write_bytes((here/name).read_bytes())
    for name in ('ParentPointTestModule.bas','ParentCodeUpdate.json','ParentCompileClosure.json',
            'Input/MaterialControl.json',Path(__file__).name,'TestNativeExternalProjected.bas.txt'):
        prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ExistingNativeProjectedMaterialCoordinate',
        working_CCoulpedConstraintEquations_used=True,working_CreateMaterialConstraint_used=True,
        true_coordinates_must_be_mapped_before_native_force_check=True,
        last_equation_is_dimensionless_pivot_constraint=True,material_projection_tolerance_MPa=2e-12,
        imported_this_pass=['modTestCoupledElasticState'],physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('EXISTING NATIVE PROJECTED MATERIAL ADAPTER READY')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--parent',type=Path,required=True)
    args=parser.parse_args();TestStage(args.root.resolve(),args.parent.resolve())
