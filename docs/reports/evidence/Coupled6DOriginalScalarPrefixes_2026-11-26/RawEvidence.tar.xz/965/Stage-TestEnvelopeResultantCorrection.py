"""ДЛЯ ТЕСТОВ. Переиспользует минимальную деформационную поправку для точного холодного H-запроса."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestCandidate(code, here):
    """Выделяет общую сборку линейных ограничений и включает отдельную проверку шести интегралов до выхода из H-решения."""
    pattern = r'(?ms)^Private Function BuildSmallStrainSystem\(.*?^End Function'
    old, = re.findall(pattern, code)
    split = old.index('\n    For j = 1 To size\n') + 1
    before = old[:split]
    decl = '''Private Function PrepareSmallStrainSystem(ByRef matrix() As Double, ByRef residual() As Double, _
        ByRef load() As Double, ByVal tolerance As Double, ByRef force() As Double, ByRef forceResidual() As Double, _
        ByRef equality() As Double, ByRef equalityResidual() As Double, ByRef scales() As Double) As Boolean
    Dim projection() As Double
    Dim size As Long, weakRows As Long, i As Long, j As Long, k As Long, row As Long
    Dim maximum As Double, factor As Double, normalized As Double, direct As Double, area As Double, lengthScale As Double
    size = mDegreeCount + 1: weakRows = mGaugeStart - 1
    ReDim scales(1 To size)
'''
    original = before + '''    BuildSmallStrainSystem = PrepareSmallStrainSystem(matrix, residual, load, tolerance, _
        force, forceResidual, equality, equalityResidual, scales)
End Function'''
    original = original.replace('Dim matrix() As Double, residual() As Double, projection() As Double', 'Dim matrix() As Double, residual() As Double')
    original = original.replace('Dim size As Long, weakRows As Long, i As Long, j As Long, k As Long, row As Long', 'Dim size As Long, i As Long, j As Long')
    original = original.replace('    Dim maximum As Double, factor As Double, normalized As Double, direct As Double, area As Double, lengthScale As Double\n', '')
    original = original.replace('size = mDegreeCount + 1: weakRows = mGaugeStart - 1', 'size = mDegreeCount + 1')
    shared = "' Собирает ограничения малой поправки из уже нормированных силовых строк и выбранного уравнения управления.\n" + decl + old[split:].replace('BuildSmallStrainSystem = True', 'PrepareSmallStrainSystem = True')
    code = code.replace(old, original + '\n\n' + shared, 1)
    anchor = '''                If maximum <= tolerance Then
                    ReadEquationField solution, field, lambda
                    SolveEnvelopeTarget = True
                    Exit For
                End If'''
    assert code.count(anchor) == 1
    replacement = '''                If maximum <= tolerance Then
                    ReadEquationField solution, field, lambda
                    Dim load(1 To COMPONENT_COUNT) As Double, forceNorm As Double
                    SetControlledLoad lambda, load
                    forceNorm = mSection.ResultantResidualNorm(mTrialResultants, load)
                    If forceNorm > tolerance Then
                        mEnvelopeDetails = mEnvelopeDetails & "; силовые интегралы требуют уточнения: " & CStr(forceNorm) & " МПа"
                        solved = TryEnvelopeResultantCorrection(equations, solution, tolerance, remaining, maximumCalls, usedSteps, usedCalls)
                    End If
                    If solved Then
                        ReadEquationField solution, field, lambda
                        SolveEnvelopeTarget = True
                        Exit For
                    End If
                End If'''
    code = code.replace(anchor, replacement, 1)
    addition = (here / 'TestEnvelopeResultantCorrection.txt').read_text('utf-8-sig')
    code += '\n\n' + addition
    return code


def TestStage(repo, root, source):
    """Меняет два частных компонента; закон материала и точные Double исходного холодного пути остаются неизменны."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestColdRawReplay.py'))['TestStage'](root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    code = TestCandidate(code, here)
    assert max(map(len, code.splitlines())) < 1024
    data = code.replace('\n', '\r\n').encode('utf-8-sig')
    (root / name).write_bytes(data)
    prep['inputs'][name] = sha256(data).hexdigest().upper()
    for name in (Path(__file__).name, 'TestEnvelopeResultantCorrection.txt'):
        (root / name).write_bytes((here / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='EnvelopeResultantSmallStrainExactCold',
        inner_resultant_acceptance_verified=True, existing_small_strain_optimizer_reused=True,
        outer_force_tolerance_unchanged=True, correction_uses_original_shared_budget=True, working_source_changed=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('PRIVATE RESULTANT SMALL STRAIN CORRECTION READY; ORIGINAL TOLERANCE AND SHARED30')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
