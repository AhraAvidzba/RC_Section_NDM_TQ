"""ДЛЯ ТЕСТОВ. Собирает адаптацию шага после CDP на существующем рабочем контроллере и той же истории 147 состояний."""
from argparse import ArgumentParser
from pathlib import Path
from runpy import run_path
from hashlib import sha256
import json


def TestStage(repo,root,parent):
    """Рабочие два класса берёт из репозитория; дополнительные методы родителя остаются только читающими тестовыми экспортами."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingControllerResume.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    for name in ('src/Solver/CCoupledNewtonSolver.cls','src/Solver/CCoupledDeformationContinuation.cls'):
        code=(repo/name).read_text('utf-8-sig')
        if name.endswith('CCoupledNewtonSolver.cls'):
            old=(root/name).read_text('utf-8-sig');marker='Friend Function ReadReverseControlTest() As Variant'
            assert old.count(marker)==1
            start=old.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,old.index(marker));assert start>0
            code+='\n'+old[start:]
        (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    compiler=compiler.replace("-ModuleNames 'modTestCoupledElasticState'","-ModuleNames @('CCoupledNewtonSolver','CCoupledDeformationContinuation','modTestCoupledElasticState')")
    name='Compile-TestMaterialGrowth.ps1';(root/name).write_bytes(compiler.encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingCDPMaterialStepGrowth',source_classes_unchanged=False,
        actual_import_this_pass=['CCoupledNewtonSolver','CCoupledDeformationContinuation','modTestCoupledElasticState'],
        original_material_and_force_tolerance=True,working_Trace_API=True,full_stock_claimed=False,
        step_growth_requires_mechanical_and_load_predictor_fit=True,prescribed_material_point_or_level=False,
        initial_count_recorded_before_Trace=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING MATERIAL STEP GROWTH READY; EXACT SAME INPUT HISTORY; ORIGINAL TOLERANCES')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,required=True);p.add_argument('--parent',type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
