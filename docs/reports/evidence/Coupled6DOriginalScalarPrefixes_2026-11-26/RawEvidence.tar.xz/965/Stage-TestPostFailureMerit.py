"""ДЛЯ ТЕСТОВ. Сопоставляет исходный бюджет30 и явный резерв16 на шести повторениях трёх одинаковых прогнозов H99."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root,parent,candidate):
    """Первые три случая без резерва; следующие три от той же истории с суммарным пределом46, без ослабления физической приёмки."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestH99FullNativeEnvelope.py'))['TestStage'](root,parent,candidate)
    prep=json.loads((root/'Preparation.json').read_bytes())
    path=root/'src/Solver/CCoupledNewtonSolver.cls'
    code=path.read_text('utf-8-sig');canonical=(candidate/path.name).read_text('utf-8-sig')
    pattern=r'(?ms)^Friend Function TryEnvelopeStep\(.*?^End Function'
    method,=re.findall(pattern,canonical);code,count=re.subn(pattern,lambda _:method,code);assert count==1
    values={path.relative_to(root).as_posix():code.replace('\n','\r\n').encode('utf-8-sig')}
    path=root/'tests/modTestCoupledElasticState.bas';code=path.read_text('utf-8-sig')
    pattern=r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub'
    body,=re.findall(pattern,code)
    body=body.replace('For caseIndex = 0 To 2','For caseIndex = 0 To 5',1)
    body=body.replace('If caseIndex = 1 Then','If caseIndex Mod 3 = 1 Then',1).replace('ElseIf caseIndex = 2 Then','ElseIf caseIndex Mod 3 = 2 Then',1)
    old='CLng(info(8)), probes, CBool(info(11)))';assert body.count(old)==1
    body=body.replace(old,'CLng(info(8)), probes, CBool(info(11)), residualRecoverySteps:=IIf(caseIndex < 3, 0, 16))',1)
    code=re.sub(pattern,lambda _:body,code)
    values[path.relative_to(root).as_posix()]=code.replace('\n','\r\n').encode('utf-8-sig')
    values[Path(__file__).name]=Path(__file__).read_bytes()
    values['Build-TestPostFailureMeritCandidate.py']=(here/'Build-TestPostFailureMeritCandidate.py').read_bytes()
    values['Build-TestRetainedNearMeritCandidate.py']=(here/'Build-TestRetainedNearMeritCandidate.py').read_bytes()
    for name,content in values.items():(root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='H99ExplicitPostFailureMerit',first_two_methods_unchanged=True,
        first_three_methods_unchanged=True,own_matrix_early_handoff=False,maximum_shared_iterations_each=46,
        original_first_three_budget=30,explicit_additional_recovery_budget=16,
        additional_budget_used_only_after_all_original_methods_fail=True,paired_original_budget_controls=3,
        first_three_legacy_function_budgets_unchanged=True,physical_capacity_certified=False)
    prep['directed_scope']['readonly_first_near_field_retained']=('CopyRetainedNearPoint' in canonical)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('PAIRED H99 POST-FAILURE TEST READY; THREE ORIGINAL30 PLUS THREE EXPLICIT30+16; NO PHYSICAL TOLERANCE CHANGE')


if __name__ == '__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('root','parent','candidate'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestStage(args.root.resolve(),args.parent.resolve(),args.candidate.resolve())
