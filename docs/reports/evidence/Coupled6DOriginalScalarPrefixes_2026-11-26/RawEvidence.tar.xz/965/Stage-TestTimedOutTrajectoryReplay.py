"""ДЛЯ ТЕСТОВ. Закрепляет точный тайм-аут384-пути и подготавливает проверку последнего полного принятого префикса без нового поиска."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import numpy as np


def TestTimeout(source,ordinary,previous):
    """Отличает защитное завершение собственного Excel от физического отказа; не использует унаследованные сохранённые книги."""
    here=Path(__file__).resolve().parent
    text=(source/'Native/HBackendStock.txt').read_text('utf-8-sig')
    assert 'WATCHDOG_FAILURE: timeout=1800 sec;' in text and 'ownExcelState=Absent; exactCleanupRequested=True' in text
    assert 'RESULTS_SAVE_REOPEN:' not in text
    closed=json.loads((source/'Native/HBackendStock.txt.ProcessClosure.json').read_bytes())
    assert closed['Stage']=='TIMEOUT' and not closed['Passed'] and closed['Identity']['Valid']
    assert closed['Before']['State']=='Live' and closed['After']['State']=='Absent'
    owner,=re.findall(r'(?m)^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$',text)
    assert int(owner[0])==closed['Identity']['PID']==closed['Before']['PID']==closed['After']['PID']
    assert str(closed['Identity']['Ticks'])==owner[1]==closed['Before']['StartTicksUTC']==closed['After']['StartTicksUTC']
    assert closed['ExactOwnExcelStopRequestedOnlyByExplicitTimeout'] and closed['ExcelStopError'] is None
    compiled=json.loads((source/'docs/regression/CodeUpdate.json').read_bytes())
    assert compiled['Compiled'] and not compiled['ProductionChanged']
    assert sha256((source/'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper()==compiled['WorkbookSHA256']
    read=run_path(str(here/'Read-TestColdRawCapture.py'))['TestHistory']
    frames,metadata=read(source/'Native/Stock.RawHistory.bin')
    short,_=read(ordinary/'Native/Stock.RawHistory.bin');old,_=read(previous/'Native/Stock.RawHistory.bin')
    common=run_path(str(here/'Check-TestRetainedNearResearch384.py'))['TestCommonPrefix']
    assert len(short)==common(short,frames)==95 and metadata['incomplete_tail_bytes']==0
    return dict(outcome='Timeout;NotPhysicalFailure',watchdog_seconds=1800,
        exact_owned_PID_and_start_verified=True,own_excel_absent=True,closure=closed,
        input_compiled_book_unchanged=True,current_saved_reopened_book_available=False,
        calculation_finished_normally=False,full_cold_origin=True,
        last_complete_accepted_prefix_only=True,snapshots=len(frames),states=len(frames[-1]['fields']),
        maximum_lambda=float(np.max(frames[-1]['lambdas'])),raw_history=metadata,
        ordinary_first95_exact=True,previous384_common_snapshots=common(old,frames),
        previous384_states=len(old[-1]['fields']),previous384_maximum_lambda=float(np.max(old[-1]['lambdas'])),
        independent_current_prefix_equilibrium_not_yet_verified=True,
        physical_capacity_certified=False,entire_goal_completed=False)


def TestStage(root,source,ordinary,previous):
    """Меняет только тестовый модуль; восстанавливает принятые поля после тайм-аута, не продолжая физическую или численную траекторию."""
    here=Path(__file__).resolve().parent
    proof=TestTimeout(source,ordinary,previous)
    raw=(json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
    (source/'RetainedNear384TimeoutProof.json').write_bytes(raw)
    run_path(str(here/'Stage-TestRawTrajectoryReplay.py'))['TestStage'](root,source)
    prep=json.loads((root/'Preparation.json').read_bytes())
    origin=json.loads((root/'Input/RawTrajectoryOrigin.json').read_bytes())
    origin.update(parent_run_timed_out=True,parent_finished_normally=False,
        last_complete_snapshot_of_terminal_timed_out_run=True,
        last_snapshot_of_finished_run_used=False,entire_cold_calculation_completed=False,
        partial_accepted_prefix_only=True)
    values={'Input/RawTrajectoryOrigin.json':(json.dumps(origin,indent=2,sort_keys=True)+'\n').encode(),
        'Input/ParentTimeoutProof.json':raw,Path(__file__).name:Path(__file__).read_bytes()}
    for name,content in values.items():(root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='TimedOutV8AcceptedPrefixReplay',parent_watchdog_seconds=1800,
        parent_run_timed_out=True,parent_finished_normally=False,partial_accepted_prefix_only=True,
        only_final_accepted_path_replayed=False,only_last_complete_accepted_prefix_replayed=True,
        no_new_equilibrium_solution_requested=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('EXACT OWNED TIMEOUT VERIFIED; ACCEPTED PREFIX REPLAY READY',proof['states'],'STATES; NO NEW CAPACITY SEARCH')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('root','source','ordinary','previous'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestStage(args.root.resolve(),args.source.resolve(),args.ordinary.resolve(),args.previous.resolve())
