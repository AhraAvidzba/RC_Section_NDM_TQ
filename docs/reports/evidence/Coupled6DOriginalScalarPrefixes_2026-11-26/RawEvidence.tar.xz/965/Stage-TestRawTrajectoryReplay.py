"""ДЛЯ ТЕСТОВ. Восстанавливает все состояния завершённого холодного пути без дополнительных H-проб."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root, source):
    """Меняет только один тестовый модуль; точные Double итогового пути и вся рабочая арифметика остаются исходными."""
    here = Path(__file__).resolve().parent
    frames, history = run_path(str(here / 'Read-TestColdRawCapture.py'))['TestHistory'](source / 'Native/Stock.RawHistory.bin')
    frame = frames[-1]
    original = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](source / 'Input/Reverse1.bin')
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    raw = run_path(str(here / 'Stage-TestColdRawReplay.py'))['TestTrajectoryBytes'](original, frame)
    code = (root / 'tests/modTestCoupledElasticState.bas').read_text('utf-8-sig')
    body = '''Private Sub TestIntegratedYieldEvent()
    mPolishExecutedTest = True ' Полная история уже нативно восстановлена и выгружена; новое равновесие здесь не ищется.
End Sub'''
    code, count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body, code)
    assert count == 1
    origin = dict(source=str(source), history=history, initial_fields=len(frame['fields']),
        raw_input_bits_preserved=True, last_snapshot_of_finished_run_used=True, no_additional_equilibrium_probes=True,
        no_change_to_working_numerical_classes=True, full_physical_limit_certified=False)
    values = {'Input/Reverse1.bin': raw, 'tests/modTestCoupledElasticState.bas': code.replace('\n', '\r\n').encode('utf-8-sig'),
        'Input/RawTrajectoryOrigin.json': (json.dumps(origin, indent=2, sort_keys=True) + '\n').encode(),
        Path(__file__).name: Path(__file__).read_bytes()}
    for name, content in values.items():
        (root / name).write_bytes(content)
        prep['inputs'][name] = sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='RawFinalTrajectoryReplay', actual_import_this_pass=['modTestCoupledElasticState'],
        initial_fields=len(frame['fields']), only_final_accepted_path_replayed=True, no_H_forecast_comparison=True,
        no_new_equilibrium_solution_requested=True, working_source_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('RAW FINAL TRAJECTORY READY', len(frame['fields']), 'STATES; ONE TEST IMPORT; NO H PROBES')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.source.resolve())
