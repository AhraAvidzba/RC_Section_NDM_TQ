"""ДЛЯ ТЕСТОВ. Восстанавливает проверяемый уже записанный проект после ошибки COM при Save/Close, без повторного импорта."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import shutil
from zipfile import ZipFile


def TestRecover(repo,root,parent):
    """Compiled=True основан на пройденном условии компиляции до строки сбоя; нативное выполнение остаётся отдельной проверкой."""
    assert not root.exists() and root.parent==parent.parent
    failure=json.loads((parent/'CompileCapturedFailure.json').read_bytes())
    builder=(parent/'tools/build_workbook/Update-IsolatedOptimizerCode.ps1').read_text('utf-8-sig').splitlines()
    assert 'line 168' in failure['ScriptStackTrace'] and builder[167].strip()=='$book.Save();$book.Close($false);$book=$null'
    assert builder[165].strip()=="throw 'Private VBA compilation failed.'"
    closure=json.loads((parent/'CompileFailureClosure.json').read_bytes());assert closure['State']=='Absent'
    source=parent/'docs/regression/Diagnostic.xlsm'
    with ZipFile(source) as book:
        assert book.testzip() is None;binary=book.read('xl/vbaProject.bin')
    here=Path(__file__).resolve().parent
    helper,body,reader=run_path(str(here/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _,actual=reader(helper['TestContainer'](binary))
    text=body(actual['modTestCoupledElasticState'],'modTestCoupledElasticState')[0].lower()
    for name in ('TestStartExternalEnvelope','TestOpenExternalEnvelope','TestEvaluateExternalEnvelope','TestFinishExternalEnvelope'):
        assert name.lower() in text
    prep=json.loads((parent/'Preparation.json').read_bytes())
    for name,digest in prep['inputs'].items():assert sha256((parent/name).read_bytes()).hexdigest().upper()==digest,name
    shutil.copytree(parent,root,ignore=shutil.ignore_patterns('Temp','Native','Run.ndjson'))
    (root/'Temp').mkdir();(root/'Native').mkdir()
    (root/'CompileClosure.json').write_bytes((parent/'CompileFailureClosure.json').read_bytes())
    recovery=dict(parent=str(parent),failure_stage='AfterSuccessfulCompileAtSaveOrClose',
        exact_saved_workbook_sha256=sha256(source.read_bytes()).hexdigest().upper(),
        exact_CFB_sha256=sha256(binary).hexdigest().upper(),components=len(actual),
        fresh_compilation_claimed=False,source_imports_in_parent=len(prep['modules']),
        original_failure_retained=True,native_execution_still_required=True)
    (root/'CompilationRecovery.json').write_bytes((json.dumps(recovery,indent=2,sort_keys=True)+'\n').encode())
    compilation=dict(Workbook=str(root/'docs/regression/Diagnostic.xlsm'),WorkbookSHA256=recovery['exact_saved_workbook_sha256'],
        ProductionSHA256=prep['source_book_sha256'],Compiled=True,Modules=prep['modules'],RetiredModules=[],
        EntryPointNames=[],TraceGeometry=False,ProductionChanged=False,RecoveredAfterSaveOrCloseFailure=True,
        FreshCompilationClaimed=False,ImportedModulesInRecovery=[],SourceRecovery='CompilationRecovery.json')
    (root/'docs/regression/CodeUpdate.json').write_bytes((json.dumps(compilation,indent=2)+'\n').encode())
    for name in ('Run-TestExternalEnvelope.py',Path(__file__).name):
        (root/name).write_bytes((here/name).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(compilation_recovered_from_complete_saved_CFB=True,fresh_compilation_claimed=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('SAVED CFB RECOVERED AFTER PASSED COMPILATION;',len(actual),'COMPONENTS; NATIVE EXECUTION STILL REQUIRED')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,required=True);p.add_argument('--parent',type=Path,required=True)
    a=p.parse_args();TestRecover(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
