"""ДЛЯ ТЕСТОВ. Переиспользует точную одномерную поправку нагрузки на неизменном поле до деформационного Ньютона."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json,re

here=Path(__file__).resolve().parent;base=Path('D:/CodexScratch/RC_Section_NDM_TQ')
root=base/'Cold718ControlledLoadBalance_20261124';parent=base/'Cold717ShoulderAccuracy_20261124'
run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
archive=root/'ControlledBalanceCompilationAncestor';archive.mkdir()
for name in ('CompilePoint.log','CompilePointClosure.json'):(root/name).rename(archive/name)
prep=json.loads((root/'Preparation.json').read_bytes());values={}
path='src/Solver/CCoupledNewtonSolver.cls';code=(root/path).read_text('utf-8-sig')
assert 'Function TryBalanceControlledLoad(' not in code
method,=re.findall(r'(?ms)^Private Function SolveStep\(.*?^End Function',code);changed=method
anchor='''        If mIterations >= maxIterations Then Exit Do
        If Not SolveCorrection(current, correction) Then''';assert changed.count(anchor)==1
changed=changed.replace(anchor,'''        If mIterations >= maxIterations Then Exit Do
        If mControlActive Then
            Dim balanceUnavailable As Boolean, balanceDetails As String
            If TryBalanceControlledLoad(current, currentLambda, load, absoluteTolerance, relativeTolerance, balanceUnavailable, balanceDetails) Then
                SolveStep = True: Exit Function
            End If
            If balanceUnavailable Then Exit Function
            If mIterations >= maxIterations Then Exit Do ' Неудачный силовой повтор также расходует первичную итерацию.
        End If
        If Not SolveCorrection(current, correction) Then''',1)
anchor='    RecordFailure sfcNumericalFailure, "Достигнут лимит итераций связанного равновесия."\n';assert changed.count(anchor)==1
changed=changed.replace(anchor,anchor+'    If Len(balanceDetails) > 0 Then mMeta.DiagnosticDetails = mMeta.DiagnosticDetails & " | " & balanceDetails\n',1)
code=code.replace(method,changed,1)
helper=(here/'CandidateControlledLoadBalance.cls.txt').read_text('utf-8-sig')
helper=helper.replace("' Уточняет только множитель линейной траектории на неизменном поле после отказа факторизации.",
    "' Уточняет только множитель линейной траектории на неизменном поле перед деформационной поправкой Ньютона.",1)
code+='\n'+helper
values[path]=code.replace('\n','\r\n').encode('utf-8-sig')
compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace("-ModuleNames 'modTestCoupledElasticState'","-ModuleNames 'CCoupledNewtonSolver'")
values['Compile-TestExternalPoint.ps1']=compiler.replace('\n','\r\n').encode('utf-8-sig')
values['ParentCodeUpdate.json']=(parent/'docs/regression/CodeUpdate.json').read_bytes()
values['ParentCompileClosure.json']=(parent/'CompilePointClosure.json').read_bytes()
for name in (Path(__file__).name,'CandidateControlledLoadBalance.cls.txt'):values[name]=(here/name).read_bytes()
for name,data in values.items():(root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
prep['directed_scope'].update(case='FixedFieldControlledLoadBalance',actual_import_this_pass=['CCoupledNewtonSolver'],
    reused_earlier_controlled_balance_helper=True,only_lambda_changes_in_optional_correction=True,
    full_weak_gauge_control_and_six_resultants_rechecked=True,all_corrections_count_inside_primary30=True,
    material717_exact=True,controller717_exact=True,original_uncertainty_formula_exact=True,
    original96_probe_limit=True,original_capacity_accuracy=.001,physical_capacity_certified=False)
(root/'Preparation.json').write_text(json.dumps(prep,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print('718 EXACT LAMBDA BALANCE REUSED; SAME FIELD, MATERIAL, FULL CHECKS AND BUDGETS')
