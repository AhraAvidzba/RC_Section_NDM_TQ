"""ДЛЯ ТЕСТОВ. Готовит парные малые пробы прогноза; меняется только тестовый модуль реальной частной книги."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import struct


def TestStage(root,parent):
    """Переиспользует проверенные два частных класса, исходную103-историю, материалы и30итераций; новых пределов не вводит."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'SteelStrainLocalProof.json').read_bytes())
    assert proof['mathematical_equilibria']==3 and proof['certified_continuation_steps']==0
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    ancestor=root/'SteelSeedCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    payload=(here/'TestSteelStrainSeed.bas.txt').read_text('utf-8-sig')
    assert 'TestSteelSeedCoordinate' not in code
    code,count=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:payload.split('\n',2)[2],code);assert count==1
    options=[value for fraction in (1e-5,1e-4,1e-3) for mode in (0,2) for value in (fraction,float(mode))]
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Compile-TestExternalPoint.ps1':(here/'Compile-TestExternalPoint.ps1').read_bytes(),
        'Input/SteelSeedOptions.bin':struct.pack('<i%dd'%len(options),len(options),*options),
        'Input/ParentSteelLocalProof.json':(parent/'SteelStrainLocalProof.json').read_bytes()}
    for name in (Path(__file__).name,'TestSteelStrainSeed.bas.txt'):
        values[name]=(here/name).read_bytes()
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    file=root/'AllCoupledSources.json'
    if file.exists():
        hashes=json.loads(file.read_bytes())
        for name in values:
            if name in hashes:hashes[name]=prep['inputs'][name]
        file.write_bytes((json.dumps(hashes,indent=2,sort_keys=True)+'\n').encode())
        if file.name in prep['inputs']:prep['inputs'][file.name]=sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='SteelStrainPairedSeeds103',actual_import_this_pass=['modTestCoupledElasticState'],
        actual_current_compilation_reused_without_import=False,single_test_module_compiled=False,
        three_independent_strain_targets=False,six_paired_target_seed_trials=True,
        control_step_policy='same base as parent; target fractions1e-5,1e-4,1e-3, each constant versus load-distinct accepted secant',
        seed_modes={0:'constant accepted field',2:'nearest past positive-coordinate secant separated by64relTol(1+abs(lambda)); fallback last pair'},
        data_driven_seed_options=True,original_accepted_prefix=103,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    assert max(map(len,code.splitlines()))<1024
    print('SIX PAIRED STEEL-SEED PROBES READY; ONE TEST IMPORT; SAME MATERIALS, ORIGINAL30; NOT CAPACITY')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('root','parent'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestStage(args.root.resolve(),args.parent.resolve())
