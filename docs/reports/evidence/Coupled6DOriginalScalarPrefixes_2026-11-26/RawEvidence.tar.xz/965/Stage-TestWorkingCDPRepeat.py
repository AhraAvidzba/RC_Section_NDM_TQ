"""ДЛЯ ТЕСТОВ. Собирает рабочее подтверждение CDP в регрессионной или штатной книге одним импортом Newton."""
from argparse import ArgumentParser
from pathlib import Path


def TestStage(repo, root, parent, frozen):
    """Переиспользует точную замену рабочего префикса, оставляя все подготовленные данные и тестовые дополнения родителя."""
    here = Path(__file__).resolve().parent; source = here / 'Stage-TestWorkingCDPGate.py'
    code = source.read_text('utf-8-sig')
    for old, new in (("'Stage-TestH96CDPGate.py'", "'Build-TestWorkingCDPRepeat.py'"),
            ('WorkingGateAncestor_', 'WorkingRepeatAncestor_'), ('WorkingGateOriginalNewton', 'WorkingRepeatOriginalNewton'),
            ('WorkingGateNewton', 'WorkingRepeatNewton'), ('Compile-TestWorkingCDPGate.ps1', 'Compile-TestWorkingCDPRepeat.ps1'),
            ("case='WorkingCDPGate'", "case='WorkingCDPRepeat'"),
            ('exact_working_guard_reorder=True', 'exact_working_root_confirmation=True'),
            ('no_half_guard_or_step_size_change=True', 'relative_threshold_and_step_size_unchanged=True,comparison_semantics_updated=True'),
            ('WORKING CDP GUARD READY', 'WORKING CDP ROOT CONFIRMATION READY')):
        assert old in code, old
        code = code.replace(old, new)
    namespace = {'__file__': str(Path(__file__).resolve()), '__name__': 'working_CDP_repeat_stage_test'}
    exec(compile(code, str(source), 'exec'), namespace); namespace['TestStage'](repo, root, parent, frozen)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    for name in ('root', 'parent', 'frozen'): parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve(), args.frozen.resolve())
