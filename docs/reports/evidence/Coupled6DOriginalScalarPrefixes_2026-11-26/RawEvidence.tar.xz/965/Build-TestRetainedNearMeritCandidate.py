"""ДЛЯ ТЕСТОВ. Сохраняет первое близкое поле как читающий снимок, продолжая все исходные итерации до их обычного исхода."""
from argparse import ArgumentParser
from pathlib import Path
from runpy import run_path


def TestBuild(source,output):
    """Новый резерв получает ранее вычисленную пробу; сохранение снимка не останавливает исходный метод и не читает материал."""
    replace=run_path(str(Path(__file__).resolve().parent/'Build-TestRectangularMeritCandidate.py'))['TestReplace']
    output.mkdir()
    for path in source.iterdir():
        if path.is_file():(output/path.name).write_bytes(path.read_bytes())
    path=output/'CCoupledHybridSolver.cls';code=path.read_text('utf-8-sig')
    code=replace(code,'Private mBestNorm As Double, mBest() As Double, mBestResidual() As Double',
        'Private mBestNorm As Double, mBest() As Double, mBestResidual() As Double\nPrivate mRetainedNearReady As Boolean, mRetainedNearNorm As Double, mRetainedNear() As Double')
    start=code.index('Friend Function TrySolveLeastSquaresTrust(')
    end=code.index('\nEnd Function',start)
    method=code[start:end]
    method=replace(method,'Optional ByVal boundedMerit As Boolean = False) As Boolean',
        'Optional ByVal boundedMerit As Boolean = False, Optional ByVal retainedNearTolerance As Double = 0#) As Boolean')
    method=replace(method,'    On Error GoTo ArithmeticFailure',
        '    On Error GoTo ArithmeticFailure\n    mRetainedNearReady = False: Erase mRetainedNear')
    before='        If mBestNorm <= residualTolerance Then mStopCode = 1: Exit Do'
    assert method.count(before)==3
    method=method.replace(before,before+'\n        RetainFirstNearPoint retainedNearTolerance')
    code=code[:start]+method+code[end:]
    code+='''
' Сохраняет только первое фактически вычисленное близкое поле; не меняет лучшую пробу, численные решения или материальную историю.
Private Sub RetainFirstNearPoint(ByVal tolerance As Double)
    If tolerance <= 0# Or mRetainedNearReady Or Not mHasBest Then Exit Sub
    If mBestNorm > tolerance Then Exit Sub
    mRetainedNear = mBest: mRetainedNearNorm = mBestNorm: mRetainedNearReady = True
End Sub

' Возвращает неизменяемую копию первой близкой пробы для отдельного резерва после полного отказа исходного метода.
Friend Function CopyRetainedNearPoint(ByRef point() As Double, ByRef norm As Double) As Boolean
    If Not mRetainedNearReady Then Exit Function
    point = mRetainedNear: norm = mRetainedNearNorm: CopyRetainedNearPoint = True
End Function
'''
    path.write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    path=output/'CCoupledNewtonSolver.cls';code=path.read_text('utf-8-sig')
    code=replace(code,'tolerance, solution, relativeDifferenceStep:=0#)',
        'tolerance, solution, relativeDifferenceStep:=0#, retainedNearTolerance:=SMALL_STRAIN_MAX_NORM * tolerance)')
    old='        If pass = 2 And solver.HasBestPoint Then recoverySeed = solution: recoverySeedNorm = solver.BestResidual: recoverySeedReady = True'
    assert code.count(old)==1
    start=code.index(old);end=code.index('\n',start)
    code=code[:start]+'''        If pass = 2 Then
            recoverySeedReady = solver.CopyRetainedNearPoint(recoverySeed, recoverySeedNorm)
            If Not recoverySeedReady And solver.HasBestPoint Then
                recoverySeed = solution: recoverySeedNorm = solver.BestResidual: recoverySeedReady = True
            End If
        End If'''+code[end:]
    path.write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    print('RETAINED NEAR CANDIDATE READY; FIRST NEAR POINT SNAPSHOT WITHOUT HANDOFF OR EXTRA MATERIAL F; SAME EXPLICIT RESERVE16')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('source','output'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestBuild(args.source.resolve(),args.output.resolve())
