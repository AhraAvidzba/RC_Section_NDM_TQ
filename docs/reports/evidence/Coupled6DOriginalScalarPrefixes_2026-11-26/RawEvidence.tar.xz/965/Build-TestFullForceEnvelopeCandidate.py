"""ДЛЯ ТЕСТОВ. Подключает полные силовые невязки только к последнему резерву H, сохраняя первые способы и общий бюджет."""
from argparse import ArgumentParser
from pathlib import Path
import re
from runpy import run_path


def TestBuild(repo, output):
    """Не добавляет новый внешний решатель или дополнительный цикл30; последний разностный резерв получает67 строк для61 неизвестной."""
    here = Path(__file__).resolve().parent
    replace = run_path(str(here / 'Build-TestRectangularMeritCandidate.py'))['TestReplace']
    name = 'CCoupledEnvelopeEquations.cls'
    code = (repo / 'src/Solver' / name).read_text('utf-8-sig')
    code = replace(code, 'Private mAllowJacobian As Boolean', 'Private mAllowJacobian As Boolean, mIncludeResultants As Boolean')
    code = replace(code, 'Friend Sub OpenTarget(ByVal target As Double, Optional ByVal allowJacobian As Boolean = False)',
        'Friend Sub OpenTarget(ByVal target As Double, Optional ByVal allowJacobian As Boolean = False, _\n        Optional ByVal includeResultants As Boolean = False)')
    code = replace(code, '    mAllowJacobian = allowJacobian', '''    If allowJacobian And includeResultants Then Err.Raise 5, "CCoupledEnvelopeEquations", "Дополнительные силовые уравнения требуют полной разностной касательной."
    mAllowJacobian = allowJacobian: mIncludeResultants = includeResultants''')
    code = replace(code, 'Optional ByVal allowJacobian As Boolean = False) As CCoupledEnvelopeEquations',
        'Optional ByVal allowJacobian As Boolean = False, Optional ByVal includeResultants As Boolean = False) As CCoupledEnvelopeEquations')
    code = replace(code, '    result.OpenTarget target, allowJacobian', '    result.OpenTarget target, allowJacobian, includeResultants')
    code = replace(code, '    ICoupledEquationSystem_TryEvaluate = True', '''    If mIncludeResultants Then
        Dim forces() As Double, originalSize As Long, component As Long
        mOwner.CopyEquationResultantResidual forces
        originalSize = UBound(residual): ReDim Preserve residual(1 To originalSize + UBound(forces))
        For component = 1 To UBound(forces): residual(originalSize + component) = forces(component): Next component
    End If
    ICoupledEquationSystem_TryEvaluate = True''')
    code = code.replace("' Сохраняет силовые уравнения и заменяет последнюю строку условием H.",
        "' Сохраняет слабые уравнения и заменяет управляющую строку условием H; для разностного резерва добавляет шесть силовых интегралов.")
    (output / name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    name = 'CCoupledNewtonSolver.cls'
    code = (repo / 'src/Solver' / name).read_text('utf-8-sig')
    pattern = r'(?ms)^Private Function SolveEnvelopeTarget\(.*?^End Function'
    original, = re.findall(pattern, code)
    method = replace(original, '    Dim growthSeedReady As Boolean, functionBudget As Long',
        '    Dim growthSeedReady As Boolean, functionBudget As Long, recoverySeedReady As Boolean, recoverySeed() As Double')
    method = replace(method, '        Set wrapper = mEnvelope.AtTarget(Me, target, ownMatrix): Set equations = wrapper', '''        If pass = 3 And recoverySeedReady Then startCoordinates = recoverySeed
        Set wrapper = mEnvelope.AtTarget(Me, target, ownMatrix, includeResultants:=(pass = 3)): Set equations = wrapper''')
    method = replace(method, '            method = "доверительная область QR, разностный резерв"',
        '            method = "доверительная область QR, полные силовые невязки"')
    method = replace(method, 'tolerance, solution, relativeDifferenceStep:=HYBRID_DIFFERENCE_STEP)',
        'tolerance, solution, relativeDifferenceStep:=HYBRID_DIFFERENCE_STEP, _\n                equationCount:=size + COMPONENT_COUNT, boundedMerit:=True)')
    method = replace(method, '        If solver.HasBestPoint Then mLastNorm = solver.BestResidual', '''        If solver.HasBestPoint Then mLastNorm = solver.BestResidual
        If pass = 2 And solver.HasBestPoint Then recoverySeed = solution: recoverySeedReady = True ' Только последний резерв продолжает лучшее непринятое поле в том же контексте.''')
    method = replace(method, 'For i = 1 To size: maximum = GeomMax(maximum, Abs(residual(i))): Next i',
        'For i = 1 To UBound(residual): maximum = GeomMax(maximum, Abs(residual(i))): Next i')
    code = code.replace(original, method, 1)
    code += '''
' Возвращает шесть фактических силовых невязок последней читающей сборки, МПа; материал и принятая история не вычисляются повторно.
Friend Sub CopyEquationResultantResidual(ByRef residual() As Double)
    If Not mHybridActive Or mHybridOriginRevision <> mAcceptedRevision Then _
        Err.Raise 5, "CCoupledNewtonSolver", "Нет действующего неизменённого контекста силовых уравнений."
    Dim area As Double, length As Double, target As Double, component As Long
    mSection.CopyResultantResidualScales area, length
    ReDim residual(1 To COMPONENT_COUNT)
    For component = 1 To COMPONENT_COUNT
        target = mBaseLoad(component) + mCurrentControlLambda * mLoadDirection(component)
        residual(component) = (mTrialResultants(component) - target) / area
        If component >= 2 And component <= 4 Then residual(component) = residual(component) / length
    Next component
End Sub
'''
    (output / name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    for name in ('CCoupledEnvelopeEquations.cls','CCoupledNewtonSolver.cls'):
        assert max(map(len,(output/name).read_text('utf-8-sig').splitlines())) < 1024
    print('FULL H RESERVE CANDIDATE READY; ORIGINAL FIRST TWO METHODS; SAME GLOBAL BUDGET; BEST NATIVE FIELD ONLY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    TestBuild(args.repo.resolve(),args.output.resolve())
