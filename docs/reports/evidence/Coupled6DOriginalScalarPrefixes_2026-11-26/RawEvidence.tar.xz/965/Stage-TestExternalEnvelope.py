"""ДЛЯ ТЕСТОВ. Готовит защищённый COM-доступ SciPy к фактическим уравнениям VBA без переноса закона материала."""

from argparse import ArgumentParser
from hashlib import sha256
import csv
import json
from pathlib import Path
import re
from runpy import run_path
import struct


def TestStage(repo,root,source,checkpoint,binary,seed_source):
    """Параметры и префикс сверяются точно; десятичное приближение не объявляется исходным нативным Double."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestStage'](repo,root,source,checkpoint,binary,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    assert (root/'Input/Reverse1.bin').read_bytes()==(seed_source/'Input/Reverse1.bin').read_bytes()
    rows=list(csv.reader((seed_source/'Native/EnvelopeEnergy.csv').read_text('cp1251').splitlines(),delimiter=';'))
    selected,=[r for r in rows if r[:2]==['FINAL','4']]
    values=[float(x) for x in selected[3:]]+[float(selected[2])]
    assert len(values)==61
    name='Input/ExternalSeed.bin';(root/name).write_bytes(struct.pack('<i61d',61,*values))
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name='Input/ExternalSeedOrigin.csv';(root/name).write_text(';'.join(selected)+'\n',encoding='utf-8')
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    assert code.count('Option Explicit')==1
    code=code.replace('Option Explicit','''Option Explicit
Private mExternalEnvelopeTest As CEnvelopeEnergyEquationsTest
Private mExternalToleranceTest As Double, mExternalRowScaleTest As Double, mExternalEnergyTargetTest As Double''',1)
    code+='\n'+(here/'TestNativeExternalEnvelope.bas.txt').read_text('utf-8-sig')
    methods=re.findall(r'(?im)^(?:Public|Private|Friend) (?:Function|Sub) (\w+)',code)
    assert len(methods)==len(set(x.lower() for x in methods))
    assert max(map(len,code.splitlines()))<1024
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name,'TestNativeExternalEnvelope.bas.txt','Run-TestExternalEnvelope.py',
            'Check-TestActualReverseCapture.py','Check-TestHardHalfSteps.py'):
        (root/name).write_bytes((here/name).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name='tools/build_workbook/Update-IsolatedOptimizerCode.ps1';code=(root/name).read_text('utf-8-sig')
    anchor='    $componentNames=@($book.VBProject.VBComponents | ForEach-Object {$_.Name})'
    assert code.count(anchor)==2
    code=code.replace(anchor,'''    # ДЛЯ ТЕСТОВ: Excel может вернуть пустой проект до завершения загрузки VBE; это не ошибка численного кода.
    $book.Activate()
    $project=$null;$components=$null
    for ($projectProbe=0;$projectProbe -lt 20;$projectProbe++) {
        $project=$book.VBProject
        if ($project) {$components=$project.VBComponents}
        if ($components) {break}
        Start-Sleep -Milliseconds 250
    }
    if (!$components) {throw 'VBA project of the owned private workbook is unavailable after loading.'}
    $excel.VBE.ActiveVBProject=$project
    $componentNames=@($components | ForEach-Object {$_.Name})''',1)
    code=code.replace('$book.VBProject.VBComponents','$components').replace('$excel.VBE.ActiveVBProject=$book.VBProject','$excel.VBE.ActiveVBProject=$project')
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ExternalAlgorithmExactVBAEquations',
        production_external_dependency_added=False,material_law_ported_or_replaced=False,
        external_seed_is_decimal_reconstruction=True,external_seed_origin=str(seed_source),
        compiler_waits_for_and_caches_owned_VBA_project=True,
        native_equilibrium_and_unchanged_Double_recheck_required=True,
        candidate_diagnostic_replay_is_not_branch_admission=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_text(json.dumps(prep,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('EXACT VBA EQUATIONS FOR EXTERNAL NUMERICAL CONTROL READY')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','source','checkpoint','binary','seed-source'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.source.resolve(),a.checkpoint.resolve(),a.binary.resolve(),a.seed_source.resolve())
