"""ДЛЯ ТЕСТОВ. Собирает читающую двоичную запись нового холодного пути664 без изменения рабочего ядра."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent):
    """Изменяет только два тестовых компонента; сохраняет точные рабочие численные методы, материал, LoadPath и бюджет96."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    ancestor = root / ('ColdRawCompileAncestor_' + root.name)
    ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists():
            (root / name).rename(ancestor / name)
    for source, target in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / target).write_bytes((parent / source).read_bytes())
        prep['inputs'][target] = sha256((root / target).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    anchor = 'Private mStockProbeRootTest As String'
    assert code.count(anchor) == 1
    code = code.replace(anchor, anchor + '\nPrivate mStockRawHistoryCountTest As Long, mStockHRequestCountTest As Long', 1)
    anchor = '    observer.Report fields, trace, meta\nEnd Sub'
    assert code.count(anchor) == 1
    code = code.replace(anchor, '    observer.Report fields, trace, meta\n    TestCaptureColdRawHistory fields, trace\nEnd Sub', 1)
    anchor = '    mStockProbeRootTest = root: Set mStockProbeObserverTest = Nothing'
    assert code.count(anchor) == 1
    code = code.replace(anchor, anchor + '\n    mStockRawHistoryCountTest = 0: mStockHRequestCountTest = 0', 1)
    code += '\n' + (here / 'TestColdRawCapture.bas.txt').read_text('utf-8-sig')
    values = {name: code.replace('\n', '\r\n').encode('utf-8-sig')}
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    assert code.startswith((repo / name).read_text('utf-8-sig'))
    before = 'Friend Function TryEnvelopeStep('
    begin = code.index(before)
    end = code.index('\nEnd Function', begin)
    method = code[begin:end]
    anchor = '    ConfigureControlledLoad baseLoad, direction: ResetSolveState'
    assert method.count(anchor) == 1
    hook = '''    modTestCoupledElasticState.TestCaptureColdHRequest Me, baseLoad, direction, previous, acceptedLambda, seed, seedLambda, _
        target, absoluteTolerance, relativeTolerance, maxIterations, retainEnvelopeControl
'''
    method = method.replace(anchor, hook + anchor, 1)
    code = code[:begin] + method + code[end:]
    values[name] = code.replace('\n', '\r\n').encode('utf-8-sig')
    compiler = (root / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    compiler, count = re.subn(r"-ModuleNames\s+(?:@\([^\n]*\)|'[^']*')", "-ModuleNames @('CCoupledNewtonSolver','modTestCoupledElasticState')", compiler)
    assert count == 1
    values['Compile-TestExternalPoint.ps1'] = compiler.replace('\n', '\r\n').encode('utf-8-sig')
    for name in (Path(__file__).name, 'TestColdRawCapture.bas.txt'):
        values[name] = (here / name).read_bytes()
    for name, raw in values.items():
        assert not name.endswith(('.cls', '.bas')) or max(map(len, raw.decode('utf-8-sig').splitlines())) < 1024
        (root / name).write_bytes(raw)
        prep['inputs'][name] = sha256(raw).hexdigest().upper()
    controller = (root / 'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')
    hook = '    modTestCoupledElasticState.TestCaptureStockContinuation Me, Details()\n'
    assert controller.count(hook) == 1 and controller.replace(hook, '', 1) == (repo / 'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')
    prep['directed_scope'].update(case='Cold664RawDoubleCapture', working_core_checkpoint=664,
        actual_import_this_pass=['CCoupledNewtonSolver', 'modTestCoupledElasticState'],
        original_production_probe_limit=96, native_Double_fields_and_load_factors=True,
        native_Double_H_requests=True, test_capture_has_no_material_evaluation=True,
        material_force_tolerance_load_path_and_iteration_budget_unchanged=True,
        current_input_history_not_used_for_cold_run=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('COLD664 RAW DOUBLE CAPTURE READY; TWO READONLY TEST IMPORTS; ORIGINAL96/30')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
