"""ДЛЯ ТЕСТОВ. Собирает рабочий направляющий резерв и фактический Probe с проверкой первичного и общего бюджетов."""
from argparse import ArgumentParser
from hashlib import sha256
import json,re
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent):
    """Все рабочие методы берёт из текущих исходников; дополнительные тестовые интерфейсы сохраняет только в частной книге."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'OnlineSteelGuideProof.json').read_bytes())
    assert proof['original_control_return_verified'] and proof['total_primary_iterations']==7
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'WorkingGuideCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):(root/name).rename(ancestor/name)
    methods=run_path(str(here/'Stage-TestWorkingDepartureTrace.py'))['TestMethods']
    name='src/Solver/CCoupledNewtonSolver.cls';working=(repo/name).read_text('utf-8-sig');private=(root/name).read_text('utf-8-sig')
    before,actual=methods(private),methods(working)
    added=[key for key in actual if key not in before]
    assert added==[('Function','TryRecoverDeformationByGuide')] and len(actual)==141
    changed=[key for key in actual if key in before and actual[key].group()!=before[key].group()]
    assert set(changed)=={('Function','TryDeformationStep'),('Function','SolveStep')}
    for key,value in actual.items():
        if key in before:
            if key in changed:private=private.replace(before[key].group(),value.group(),1)
            else:assert value.group()==before[key].group(),key
        else:private+='\n\n\' Вычисляет направляющий прогноз с возвратом при исходной мере и общем первичном бюджете.\n'+value.group()+'\n'
    after=methods(private);assert all(after[key].group()==value.group() for key,value in actual.items())
    controller_name='src/Solver/CCoupledDeformationContinuation.cls';controller=(repo/controller_name).read_text('utf-8-sig')
    old_methods=methods((root/controller_name).read_text('utf-8-sig'));working_methods=methods(controller)
    for key,value in old_methods.items():
        if key not in working_methods:controller+='\n'+value.group()+'\n'
    controller+='\n'+(here/'TestWorkingGuideController.cls.txt').read_text('utf-8-sig')
    testname='tests/modTestCoupledElasticState.bas';code=(root/testname).read_text('utf-8-sig')
    payload=(here/'TestWorkingGuideUnit.bas.txt').read_text('utf-8-sig')
    body,=re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',payload)
    code,count=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert count==1
    imports=['CCoupledDeformationContinuation','CCoupledNewtonSolver','modTestCoupledElasticState']
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    anchor="-ModuleNames 'modTestCoupledElasticState'";assert compiler.count(anchor)==1
    compiler=compiler.replace(anchor,'-ModuleNames @('+','.join(repr(x) for x in imports)+')')
    values={name:private.replace('\n','\r\n').encode('utf-8-sig'),controller_name:controller.replace('\n','\r\n').encode('utf-8-sig'),
        testname:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Compile-TestExternalPoint.ps1':compiler.replace('\n','\r\n').encode('utf-8-sig'),
        'Input/WorkingGuideNewton.cls':(repo/name).read_bytes(),
        'Input/WorkingGuideController.cls':(repo/controller_name).read_bytes(),
        'ParentCodeUpdate.json':(parent/'docs/regression/CodeUpdate.json').read_bytes(),
        'ParentCompileClosure.json':(parent/'CompilePointClosure.json').read_bytes()}
    for item in (Path(__file__).name,'TestWorkingGuideController.cls.txt','TestWorkingGuideUnit.bas.txt'):
        values[item]=(here/item).read_bytes()
    for item,raw in values.items():(root/item).write_bytes(raw);prep['inputs'][item]=sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingGuideBudgetUnit146',actual_import_this_pass=imports,
        current_input_states=146,actual_current_Newton_methods=141,working_Probe_executed=True,
        explicitly_updated_working_methods=[list(key) for key in changed],guide_before_full_hybrid=True,
        main_Trace_loop_not_executed=True,initial_probe_counters=[94,93],global_probe_limit_unchanged=96,
        all_primary_iterations_shared=30,failed_guide_rollback_budget=3,
        guide_only_after_verified_local_peak=True,pre_peak_negative_guard_executed=True,
        no_prescribed_future_field=True,working_sources_not_release_book=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    assert max(map(len,code.splitlines()))<1024 and max(map(len,private.splitlines()))<1024
    print('WORKING GUIDE BUDGET UNIT146 READY;141 WORKING NEWTON METHODS; THREE IMPORTS; PRIMARY30/GLOBAL96')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
