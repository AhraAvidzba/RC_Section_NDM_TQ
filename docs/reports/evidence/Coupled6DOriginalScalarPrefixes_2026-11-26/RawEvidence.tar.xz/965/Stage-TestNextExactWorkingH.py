"""ДЛЯ ТЕСТОВ. Продолжает следующий точный принятый H-снимок без повторного импорта или изменения VBA."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root, parent, snapshot):
    """Использует прежнюю неизменную компиляцию; новый собственный Excel полностью воспроизводит материальную историю."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0, snapshot)
    data = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](snapshot)
    previous = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](parent / 'Input/Reverse1.bin')
    prep = json.loads((root / 'Preparation.json').read_bytes())
    origin = dict(source_snapshot=str(snapshot), sha256=data['sha256'], states=len(data['fields']),
                  original_prefix_states=len(previous['fields']), original_prefix_exact=True,
                  fields_and_factors_are_native_Double=True, physical_capacity_certified=False)
    contents = {'Input/ExactWorkingHOrigin.json': (json.dumps(origin, indent=2, sort_keys=True) + '\n').encode(),
                Path(__file__).name: Path(__file__).read_bytes()}
    for name, value in contents.items():
        (root / name).write_bytes(value)
        prep['inputs'][name] = sha256(value).hexdigest().upper()
    prep['directed_scope'].update(case='NextExactOriginalWorkingH', actual_import_this_pass=[], fresh_compilation_claimed=False,
        source_snapshot=str(snapshot), current_input_states=len(data['fields']), single_test_module_compiled=False,
        original_checkpoint637_core=True, mutable_material_state_reused=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('NEXT ORIGINAL H READY;', len(data['fields']), 'EXACT INPUT STATES; NO CODE IMPORT; FRESH MATERIAL HISTORY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    for name in ('root', 'parent', 'snapshot'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve(), args.snapshot.resolve())
