"""ДЛЯ ТЕСТОВ. Собирает текущие три рабочих численных класса с сохранёнными читающими экспортами тестовой книги."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, parent):
    """Не переносит частные методы в рабочее ядро; компилирует точный рабочий префикс отдельно от тестовых дополнений Newton."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for source, target in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / target).write_bytes((parent / source).read_bytes())
        prep['inputs'][target] = sha256((root / target).read_bytes()).hexdigest().upper()
    ancestor = root / ('WorkingTrustAncestor_' + root.name)
    ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists():
            (root / name).rename(ancestor / name)
    for name in ('src/Solver/CCoupledHybridFactorization.cls', 'src/Solver/CCoupledHybridSolver.cls', 'src/Solver/CCoupledNewtonSolver.cls'):
        code = (repo / name).read_text('utf-8-sig')
        if name.endswith('CCoupledNewtonSolver.cls'):
            old = (root / name).read_text('utf-8-sig')
            marker = 'Friend Function ReadReverseControlTest() As Variant'
            assert old.count(marker) == 1
            cut = old.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, old.index(marker))
            assert cut > 0
            code += '\n' + old[cut:]
        assert max(map(len, code.splitlines())) < 1024
        (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Compile-TestExternalPoint.ps1'
    compiler = (root / name).read_text('utf-8-sig')
    import re
    compiler, replacements = re.subn(r"-ModuleNames\s+(?:@\([^\n]*\)|'[^']*')", "-ModuleNames @('CCoupledHybridFactorization','CCoupledHybridSolver','CCoupledNewtonSolver','modTestCoupledElasticState')", compiler)
    assert replacements == 1
    (root / name).write_bytes(compiler.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name,):
        (root / name).write_bytes((here / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingNativeTrustH86', working_three_numeric_classes_exact=True,
        test_readers_only_in_private_Newton_suffix=True, no_per_trial_working_collection=True,
        exact_working_accepted_origin_and_trust_solver=True, production_modified=False,
        actual_import_this_pass=['CCoupledHybridFactorization', 'CCoupledHybridSolver', 'CCoupledNewtonSolver', 'modTestCoupledElasticState'])
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING TRUST READY; THREE EXACT WORKING CLASS PREFIXES; TEST READERS SEPARATE')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
