"""ДЛЯ ТЕСТОВ. Исправляет наблюдение контракта CopyRecoveredControl после реально обнаруженного несовпадения исходной цели."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import struct
import numpy as np


def TestFailure(parent):
    """Сохраняет неудачу исходного контрольного gate, не ослабляя его допуск и не называя восстановленный корень исходной целью."""
    here=Path(__file__).resolve().parent
    native,_=run_path(str(here/'Check-TestPersistentHEvidence.py'))['TestNative'](parent,'PersistentHController')
    assert native['passed']==1 and native['failed']==0 and native['own_process_closed']
    read=run_path(str(here/'Check-TestCold86HRecoveryEvidence.py'))['TestVectors']
    info,effort,p,before,seed,field,forces,_=read(parent/'Native/SteelSeed.Case5.bin',b'NDMGEOMCTRL00001',8)
    assert info[1]==1 and info[17]>.999999 and info[18]==2
    mechanics,fields=run_path(str(here/'Validate-TestHardPrepared.py'))['TestValidate'](parent,'SteelSeed.Case5.Sequence')
    np.testing.assert_allclose(fields[-1],field,rtol=1e-14,atol=1e-300)
    error=abs(float(p@field)-info[8]);bound=mechanics['states'][-1]['bound_MPa']/mechanics['material'][0]
    assert error>bound
    result=dict(outcome='OriginalTargetGateFailed;RecoveryProjectionNotCaptured',
        original_control_satisfied=False,original_control_error=float(error),original_control_bound=float(bound),
        mathematical_equilibrium_verified=True,lambda_value=float(info[10]),
        native_returned_success=True,recovered_control_not_yet_observed=True,
        core_copy_recovered_control_contract_requires_capture=True,
        original_force_tolerance_not_relaxed=True,physical_capacity_certified=False)
    raw=(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
    (parent/'SpatialSeedStudyFailure.json').write_bytes(raw)
    return raw


def TestStage(repo,root,parent):
    """Повторяет только фактическую шестую пробу, добавляя читающую запись восстановленной меры; рабочие методы не меняет."""
    here=Path(__file__).resolve().parent;failure=TestFailure(parent)
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'RecoveryCaptureCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    body,=re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',code)
    def TestReplace(before,after):
        """Ограничивает изменение сценарием наблюдения известной версии API."""
        nonlocal body
        assert body.count(before)==1,before
        body=body.replace(before,after,1)
    TestReplace('    Dim movement() As Double, scaleField() As Double, nominalSpacing As Double, scaleFactor As Double, scaleFraction As Double',
        '    Dim movement() As Double, scaleField() As Double, nominalSpacing As Double, scaleFactor As Double, scaleFraction As Double\n'+
        '    Dim recoveredProjection() As Double, hasRecovered As Boolean, recoveredUncertainty As Double, recoveryBranchTangent As Boolean')
    TestReplace('        lambdaBound = 0#: hasLambdaBound = False: boundSeconds = 0#',
        '        hasRecovered = False: recoveredUncertainty = 0#: recoveryBranchTangent = False: Erase recoveredProjection\n'+
        '        lambdaBound = 0#: hasLambdaBound = False: boundSeconds = 0#')
    TestReplace('            mReverseSolverTest.CopyTrial candidate, actual',
        '            mReverseSolverTest.CopyTrial candidate, actual\n'+
        '            hasRecovered = mReverseSolverTest.CopyRecoveredControl(recoveredProjection, recoveredUncertainty)\n'+
        '            If hasRecovered Then recoveryBranchTangent = mReverseSolverTest.RecoveredControlRequiresBranchTangent')
    TestReplace('signature = "NDMGEOMCTRL00001"','signature = "NDMGEOMCTRL00002"')
    TestReplace('Abs(CLng(hasLambdaBound)), lambdaBound, boundSeconds, nominalSpacing, unusedContext(4))',
        'Abs(CLng(hasLambdaBound)), lambdaBound, boundSeconds, nominalSpacing, unusedContext(4), _\n'+
        '            Abs(CLng(hasRecovered)), recoveredUncertainty, Abs(CLng(recoveryBranchTangent)))')
    TestReplace('        TestWriteReverseBinaryVector handle, solveEffort',
        '        TestWriteReverseBinaryVector handle, solveEffort\n'+
        '        If hasRecovered Then TestWriteReverseBinaryVector handle, recoveredProjection Else TestWriteReverseBinaryVector handle, Array(0#)')
    code=re.sub(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code,count=1)
    methods=json.loads((root/'WorkingSpatialMethods.json').read_bytes())
    pattern=r'(?ms)^Friend Function CopyRecoveredControl\(.*?^End Function'
    candidate,=re.findall(pattern,(root/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig'))
    working,=re.findall(pattern,(repo/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig'));assert candidate==working
    methods['CopyRecoveredControl']=dict(exact_working_method=True,sha256=sha256(candidate.encode()).hexdigest().upper())
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Input/SteelSeedOptions.bin':struct.pack('<i2d',2,1.,2.),
        'Input/OriginalSpatialCase5.bin':(parent/'Native/SteelSeed.Case5.bin').read_bytes(),
        'Input/OriginalSpatialTargetFailure.json':failure,
        'WorkingSpatialMethods.json':(json.dumps(methods,indent=2,sort_keys=True)+'\n').encode(),
        'Compile-TestExternalPoint.ps1':(here/'Compile-TestExternalPoint.ps1').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='StockSpatialRecoveredControlCapture103',actual_import_this_pass=['modTestCoupledElasticState'],
        actual_current_compilation_reused_without_import=False,single_test_module_compiled=False,fresh_compilation_claimed=True,
        original_failed_target_gate_preserved=True,original_case5_repeated_only=True,
        readonly_copy_recovered_control_added=True,primary_iteration_budget=30,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    assert max(map(len,code.splitlines()))<1024
    print('ORIGINAL TARGET FAILURE PRESERVED; ONE ACTUAL CASE REPEATED WITH RECOVERED CONTROL CAPTURE; NO KERNEL CHANGE')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
