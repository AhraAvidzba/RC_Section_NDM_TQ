"""ДЛЯ ТЕСТОВ. Сгущает H-шаг на общей принятой истории перед наблюдавшимся максимумом нагрузки."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import numpy as np


def TestStage(root, parent, snapshot, scale, maximum):
    """Добавляет только чтение трёх численных параметров сценария; рабочие классы, материалы и допуски не меняет."""
    assert scale in (.125, .25, .5, 1.) and maximum in (16, 24, 32, 48, 64)
    here = Path(__file__).resolve().parent
    read = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original, current = read(parent / 'Input/Reverse1.bin'), read(snapshot)
    for key in ('calibration', 'options', 'offset', 'direction'):
        assert np.array_equal(original[key], current[key]), key
    for key in ('fields', 'lambdas', 'fractions'):
        assert np.array_equal(original[key], current[key][:len(original['fields'])]), key
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    parent_code = (parent / name).read_text('utf-8-sig')
    pattern = r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub'
    body = re.search(pattern, parent_code).group()
    anchor = '    stepSize = baseline - previousEnergy'
    assert body.count(anchor) == 1
    body = body.replace(anchor, anchor + '''
    Dim pathHandleTest As Integer: pathHandleTest = FreeFile
    Open mPolishRootTest & "\\Input\\HPathTestOptions.bin" For Binary Access Read As #pathHandleTest
    Dim pathOptionsTest As Variant: pathOptionsTest = TestReadPolishVector(pathHandleTest)
    If Seek(pathHandleTest) <> LOF(pathHandleTest) + 1 Then Err.Raise 5, , "Лишние байты численных параметров H-теста."
    Close #pathHandleTest
    If LBound(pathOptionsTest) <> 1 Or UBound(pathOptionsTest) <> 3 Then Err.Raise 5, , "Нужны три численных параметра H-теста."
    Dim maximumHStatesTest As Long, growthHTest As Double
    maximumHStatesTest = CLng(pathOptionsTest(3)): growthHTest = CDbl(pathOptionsTest(2))
    If pathOptionsTest(1) <= 0# Or pathOptionsTest(1) > 1# Or growthHTest < 1# Or growthHTest > 1.25 Then Err.Raise 5, , "Недопустим масштаб шага H-теста."
    If maximumHStatesTest < 16 Or maximumHStatesTest > 64 Or maximumHStatesTest <> pathOptionsTest(3) Then Err.Raise 5, , "Недопустимо число новых состояний H-теста."
    stepSize = stepSize * CDbl(pathOptionsTest(1))
    Print #report, "H_NUMERICS" & TestHardPreparedVector(pathOptionsTest)
''', 1)
    for before, after in (('hAccepted >= 16', 'hAccepted >= maximumHStatesTest'),
                          ('AcceptedStateLimit16', 'RefinementStateLimit'),
                          ('hAttempt = 1 To 64', 'hAttempt = 1 To 4 * maximumHStatesTest'),
                          ('stepSize = 1.25 * stepSize', 'stepSize = growthHTest * stepSize'),
                          ('WorkingHContinuationFromExactSnapshot', 'WorkingHFixedStepRefinement')):
        assert body.count(before) == 1, before
        body = body.replace(before, after, 1)
    match = re.search(pattern, code)
    prefix = code[:match.start()].splitlines(keepends=True)
    while prefix and (not prefix[-1].strip() or prefix[-1].lstrip().startswith("'")):
        prefix.pop()
    header = "\n\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Продолжает ту же принятую историю заданным численным H-шагом для проверки максимума нагрузки; предел не назначает.\n"
    code = ''.join(prefix) + header + body + code[match.end():]
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    vector = run_path(str(here / 'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    origin = dict(source_snapshot=str(snapshot), sha256=current['sha256'], states=len(current['fields']),
                  shared_original_prefix_states=len(original['fields']), shared_original_prefix_exact=True)
    contents = {'Input/Reverse1.bin': snapshot.read_bytes(),
                'Input/HPathTestOptions.bin': vector([scale, 1., float(maximum)]),
                'Input/HRefinementOrigin.json': (json.dumps(origin, indent=2, sort_keys=True) + '\n').encode(),
                Path(__file__).name: Path(__file__).read_bytes()}
    for name, value in contents.items():
        (root / name).write_bytes(value)
        prep['inputs'][name] = sha256(value).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingHStepRefinement', actual_import_this_pass=['modTestCoupledElasticState'],
        fresh_compilation_claimed=True, source_classes_unchanged=True, original_checkpoint637_core=True,
        current_input_states=len(current['fields']), maximum_new_H_states=maximum, initial_H_step_scale=scale,
        successful_H_step_growth=1., maximum_H_failures_at_revision=4, controller_changed=False,
        original_force_and_material_criteria=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, sort_keys=True, indent=2) + '\n').encode())
    print('H STEP REFINEMENT READY;', len(current['fields']), 'EXACT SHARED STATES; SCALE', scale, '; LIMIT', maximum)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    for name in ('root', 'parent', 'snapshot'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--scale', type=float, default=.25)
    parser.add_argument('--maximum', type=int, default=24)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve(), args.snapshot.resolve(), args.scale, args.maximum)
