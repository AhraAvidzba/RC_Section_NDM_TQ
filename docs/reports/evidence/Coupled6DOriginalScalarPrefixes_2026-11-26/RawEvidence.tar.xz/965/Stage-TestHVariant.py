"""ДЛЯ ТЕСТОВ. Подготавливает согласование начального lambda и ограниченный рост H на тех же физических данных."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent):
    """Заменяет два рабочих класса и тест; остальные 252 компонента родителя должны остаться точными."""
    here = Path(__file__).resolve().parent
    if root.exists():
        assert not any((root / 'Native').iterdir())
        if (root / 'CompilePoint.log').exists():
            assert (root / 'CompilePoint.log').read_bytes() == (parent / 'CompilePoint.log').read_bytes()
            assert (root / 'CompilePointClosure.json').read_bytes() == (parent / 'CompilePointClosure.json').read_bytes()
        reuse = json.loads((root / 'CompiledSourceReuse.json').read_bytes())
        assert Path(reuse['parent']).resolve() == parent.resolve()
        compiled = json.loads((parent / 'docs/regression/CodeUpdate.json').read_bytes())
        assert sha256((root / 'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper() == compiled['WorkbookSHA256']
    else:
        run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for before, after in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / after).write_bytes((root / before).read_bytes()); prep['inputs'][after] = sha256((root / after).read_bytes()).hexdigest().upper()
    ancestor = root / ('VariantCompileAncestor_' + root.name); ancestor.mkdir(exist_ok=True)
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists(): (root / name).rename(ancestor / name)
    paths = ['src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledDeformationContinuation.cls', 'tests/modTestCoupledEnvelopeControl.bas']
    imports = [Path(name).stem for name in paths]
    for name in paths:
        code = (repo / name).read_text('utf-8-sig')
        if name.endswith('CCoupledNewtonSolver.cls'):
            old = (root / name).read_text('utf-8-sig')
            marker = 'Friend Function ReadReverseControlTest() As Variant'
            assert old.count(marker) == 1
            cut = old.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, old.index(marker)); assert cut > 0
            code += '\n' + old[cut:]
        assert Path(name).stem in prep['modules'] and max(map(len, code.splitlines())) < 1024
        (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    file = root / 'AllCoupledSources.json'
    if file.exists():
        hashes = json.loads(file.read_bytes())
        for name in paths:
            if name in hashes: hashes[name] = prep['inputs'][name]
        file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if file.name in prep['inputs']: prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    compiler = (root / 'Compile-TestPersistentHUnit.ps1').read_text('utf-8-sig')
    compiler, count = re.subn(r"-ModuleNames 'modTestCoupledEnvelopeControl'", '-ModuleNames @(' + ','.join("'" + name + "'" for name in imports) + ')', compiler)
    assert count == 1
    files = {'Compile-TestHVariant.ps1': compiler.encode('utf-8-sig'), Path(__file__).name: Path(__file__).read_bytes()}
    for name, raw in files.items():
        (root / name).write_bytes(raw); prep['inputs'][name] = sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='BoundedBalancedH', actual_import_this_pass=imports,
        source_classes_unchanged=False, fresh_compilation_claimed=True, original_force_and_material_criteria=True,
        balanced_initial_lambda=True,
        H_maximum_relative_increment=float(re.search(r'ENVELOPE_MAXIMUM_STEP_RATIO As Double = ([0-9.]+)', (root / paths[1]).read_text('utf-8-sig'))[1]),
        H_minimum_from_actual_equation_resolution=True,
        physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('BOUNDED BALANCED H READY; TWO WORKING CLASSES AND ONE TEST; ORIGINAL PHYSICAL DATA')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
