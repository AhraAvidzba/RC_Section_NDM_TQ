"""ДЛЯ ТЕСТОВ. Наблюдает отказ малой H-поправки без дополнительных вычислений материала или изменения численных решений."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root, source):
    """Фиксирует стадию отказа, фактические невязки проб и бюджет; исходные поля и закон материала не меняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestColdRawReplay.py'))['TestStage'](root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    anchor = 'Private mStockProbeRootTest As String'
    assert code.count(anchor) == 1
    code = code.replace(anchor, anchor + '\nPrivate mHCorrectionCaseTest As Long', 1)
    body, = re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', code)
    assert body.count('    For caseIndex = 0 To 2') == 1
    code = code.replace(body, body.replace('    For caseIndex = 0 To 2', '    For caseIndex = 0 To 2\n        mHCorrectionCaseTest = caseIndex', 1), 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает только уже вычисленные невязки и счётчики, не обращаясь к материалам и подтверждённой истории.
Public Sub TestObserveHCorrection(ByVal stage As Long, ByVal norm As Double, ByVal tolerance As Double, ByVal fraction As Double)
    If Len(mPolishRootTest) = 0 Then Exit Sub
    Dim handle As Integer: handle = FreeFile
    Open mPolishRootTest & "\\Native\\HCorrectionAttempts.csv" For Append As #handle
    Print #handle, CStr(mHCorrectionCaseTest) & ";" & CStr(stage) & TestHardPreparedVector(Array(norm, tolerance, fraction)) & _
        TestHardPreparedVector(mReverseSolverTest.ReadPolishEffortTest)
    Close #handle
End Sub
'''
    values = {name: code.replace('\n', '\r\n').encode('utf-8-sig')}
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    method, = re.findall(r'(?ms)^Private Function TryEnvelopeResultantCorrection\(.*?^End Function', code)
    original = method
    changes = {
        'If usedSteps >= maximumSteps Or maximumCalls - usedCalls < 2 Then Exit Function':
            'If usedSteps >= maximumSteps Or maximumCalls - usedCalls < 2 Then modTestCoupledElasticState.TestObserveHCorrection 9, 0#, tolerance, 0#: Exit Function',
        'If Not equations.TryEvaluate(coordinates, True, residual, matrix) Then Exit Function':
            'If Not equations.TryEvaluate(coordinates, True, residual, matrix) Then modTestCoupledElasticState.TestObserveHCorrection 1, 0#, tolerance, 0#: Exit Function',
        'If norm > SMALL_STRAIN_MAX_NORM * tolerance Then Exit Function':
            'If norm > SMALL_STRAIN_MAX_NORM * tolerance Then modTestCoupledElasticState.TestObserveHCorrection 2, norm, tolerance, 0#: Exit Function',
        'If Not PrepareSmallStrainSystem(matrix, residual, load, tolerance, force, forceResidual, equality, equalityResidual, scales) Then Exit Function':
            'If Not PrepareSmallStrainSystem(matrix, residual, load, tolerance, force, forceResidual, equality, equalityResidual, scales) Then modTestCoupledElasticState.TestObserveHCorrection 3, norm, tolerance, 0#: Exit Function',
        'SMALL_STRAIN_RADIUS * norm, SMALL_STRAIN_FORCE_FRACTION * tolerance, correction) Then Exit Function':
            '''SMALL_STRAIN_RADIUS * norm, SMALL_STRAIN_FORCE_FRACTION * tolerance, correction) Then
        modTestCoupledElasticState.TestObserveHCorrection 4, norm, tolerance, 0#
        Exit Function
    End If
    modTestCoupledElasticState.TestObserveHCorrection 5, norm, tolerance, 0#''',
        '            mLastNorm = maximum':
            '            mLastNorm = maximum\n            modTestCoupledElasticState.TestObserveHCorrection 6, maximum, tolerance, fraction',
        '                coordinates = trial: TryEnvelopeResultantCorrection = True':
            '                modTestCoupledElasticState.TestObserveHCorrection 7, maximum, tolerance, fraction\n                coordinates = trial: TryEnvelopeResultantCorrection = True',
        '        End If\n        fraction = fraction * 0.5':
            '        Else\n            modTestCoupledElasticState.TestObserveHCorrection 8, 0#, tolerance, fraction\n        End If\n        fraction = fraction * 0.5'}
    for before, after in changes.items():
        assert method.count(before) == 1, before
        method = method.replace(before, after, 1)
    code = code.replace(original, method, 1)
    values[name] = code.replace('\n', '\r\n').encode('utf-8-sig')
    values[Path(__file__).name] = Path(__file__).read_bytes()
    for name, content in values.items():
        (root / name).write_bytes(content)
        prep['inputs'][name] = sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='ReadOnlyHCorrectionDiagnostics', actual_import_this_pass=['CCoupledNewtonSolver', 'modTestCoupledElasticState'],
        correction_stages_only_observed=True, no_additional_material_evaluations=True, original_tolerance_and_shared30=True,
        working_source_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('READONLY H CORRECTION DIAGNOSTICS READY; EXACT RECORDED HISTORY; ORIGINAL30 AND MATERIAL')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.source.resolve())
