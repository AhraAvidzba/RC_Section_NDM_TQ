"""ДЛЯ ТЕСТОВ. Дополняет проверенный частный VBA-проект одним читающим интерфейсом точек материала."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct


def TestStage(root,parent,derivative):
    """Закрепляет точную прежнюю точку, направление Ньютона и неизменный состав рабочего материала."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestExternalRestart.py'))['TestStage'](root,parent,'diagnose')
    prep=json.loads((root/'Preparation.json').read_bytes())
    parent_compilation=(root/'docs/regression/CodeUpdate.json').read_bytes()
    (root/'ParentCodeUpdate.json').write_bytes(parent_compilation)
    (root/'ParentCompileClosure.json').write_bytes((root/'CompileClosure.json').read_bytes())
    name='tests/modTestCoupledElasticState.bas'
    code=(root/name).read_text('utf-8-sig')
    (root/'ParentPointTestModule.bas').write_bytes((root/name).read_bytes())
    addition=(here/'TestNativeExternalPointTrace.bas.txt').read_text('utf-8-sig')
    assert 'TestReadExternalPointTrace(' not in code
    (root/name).write_bytes((code+'\n'+addition).replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    report,jac,direction=run_path(str(here/'Analyze-TestExternalLine.py'))['TestAnalyze'](derivative)
    n=len(direction)
    (root/'Input/LineDirection.bin').write_bytes(struct.pack('<i',n)+direction.astype('<f8').tobytes())
    (root/'Input/LineJacobian.bin').write_bytes(struct.pack('<i',n)+jac.astype('<f8').tobytes())
    (root/'Input/LinePrediction.json').write_bytes((json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
    for name in ('TestNativeExternalPointTrace.bas.txt','Compile-TestExternalPoint.ps1',Path(__file__).name):
        content=(here/name).read_text('utf-8-sig').encode('utf-8-sig') if name.endswith('.ps1') else (here/name).read_bytes()
        (root/name).write_bytes(content)
    for name in ('ParentCodeUpdate.json','ParentCompileClosure.json','ParentPointTestModule.bas',
            'Input/LineDirection.bin','Input/LineJacobian.bin','Input/LinePrediction.json',
            'TestNativeExternalPointTrace.bas.txt','Compile-TestExternalPoint.ps1',Path(__file__).name):
        prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ReadOnlyMaterialPointLineTrace',
        new_readonly_test_module_only=True,imported_this_pass=['modTestCoupledElasticState'],
        prior_compiled_components_reused=252,original_material_law_unchanged=True,
        numerical_point_candidate_from_equilibrium_operator_projection=report['strongest_point_subspaces'][0],
        physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('ONE READONLY POINT INTERFACE READY; MATERIALS UNCHANGED')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    for name in ('root','parent','derivative'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args()
    TestStage(args.root.resolve(),args.parent.resolve(),args.derivative.resolve())
