"""ДЛЯ ТЕСТОВ. Закрепляет фактически исполняемый независимый проверяющий код рядом с частной книгой."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestPin(root):
    """Не заменяет компиляцию или источники VBA; сохраняет замкнутый набор функций только этой направленной проверки."""
    here=Path(__file__).resolve().parent
    names=['Check-TestSteelStrainSeed.py','Check-TestSteelStrainLocal.py','Check-TestPersistentHEvidence.py',
        'Check-TestActualReverseCapture.py','Check-TestCold86HRecoveryEvidence.py','Validate-TestHardPrepared.py']
    folder=root/'ValidationScripts';folder.mkdir()
    prep=json.loads((root/'Preparation.json').read_bytes())
    for name in names:
        raw=(here/name).read_bytes();(folder/name).write_bytes(raw)
        prep['inputs']['ValidationScripts/'+name]=sha256(raw).hexdigest().upper()
    raw=Path(__file__).read_bytes();name=Path(__file__).name
    (root/name).write_bytes(raw);prep['inputs'][name]=sha256(raw).hexdigest().upper()
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('ACTUAL SIX VALIDATION SCRIPTS PINNED; VBA AND COMPILE OUTPUT UNCHANGED')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True)
    TestPin(p.parse_args().root.resolve())
