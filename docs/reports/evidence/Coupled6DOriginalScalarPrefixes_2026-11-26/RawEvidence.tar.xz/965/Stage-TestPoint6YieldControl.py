"""ДЛЯ ТЕСТОВ. Проверяет существующий адаптер материального события в независимо локализованной точке 6."""
from argparse import ArgumentParser
from hashlib import sha256
import json,struct
from pathlib import Path
from runpy import run_path


def TestStage(root,parent,seed_source,target):
    """Номер точки задан только диагностике; рабочий закон, алгоритм и принятая история не меняются и не компилируются повторно."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,.001,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    result=json.loads((seed_source/'Native/ExternalResult.json').read_bytes())
    raw=(seed_source/'Native/ExternalNativeResult.bin').read_bytes();values=struct.unpack('<72d',raw)
    assert list(values)==result['native_verification']+result['field'] and result['owned_excel_final_state']['state']=='Exited'
    control=dict(mode='projected',point=6,side=-1,target_MPa=target,
        point_selected_from_independent_material_trace=True,automatic_point_selection_claimed=False,
        original_history200_unchanged=True,physical_capacity_certified=False)
    zero=struct.pack('<i61d',61,*([0.]*61))
    contents={'Input/ExternalSeed.bin':struct.pack('<i61d',61,*values[12:],values[4]),
        'Input/ProjectionOrigin.bin':zero,'Input/InitialCoordinates.bin':zero,
        'Input/NativeTolerance.bin':struct.pack('<id',1,result['context_metadata'][3]),
        'Input/MaterialControl.json':(json.dumps(control,sort_keys=True,indent=2)+'\n').encode(),
        'Input/NativeSolver.json':b'{"completeNewtonLineSearch":true}\n',
        'Input/ChangedInitialCondition.json':b'{"reason":"Point6 yield projection from exact unaccepted TRF100 field; same accepted200 history"}\n'}
    assert not (root/'Input/InitialProjectedResidual.bin').exists()
    for name,data in contents.items():(root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
    runner=(here/'Run-TestExternalEnvelope.py').read_text('utf-8-sig')
    anchor="        if (root/'Input/InitialResidual.bin').exists():";assert runner.count(anchor)==1
    runner=runner.replace(anchor,'        if False: # Другой диагностический контекст: его служебная невязка здесь неприменима.',1)
    name='Run-TestPoint6YieldControl.py';(root/name).write_bytes(runner.encode());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ExistingWorkingPoint6YieldControl',actual_import_this_pass=[],fresh_compilation_claimed=False,
        source_classes_unchanged=True,material_parameters_and_force_tolerances_unchanged=True,
        known_diagnostic_point_not_production_rule=True,target_trial_yield_MPa=target,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('EXISTING WORKING YIELD PROJECTION READY; POINT6 SIDE-1; TARGET',target,'; NO NEW COMPILATION')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent','seed-source'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--target',type=float,default=0.);a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve(),a.seed_source.resolve(),a.target)
