"""ДЛЯ ТЕСТОВ. Готовит второй полушаг на той же проекции арматуры с реально восстановленной историей первого полушага."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import struct
import numpy as np


def TestBody(code):
    """Меняет только тестовый способ задания меры; материалы, рабочие классы, допуски и30итераций остаются прежними."""
    body,=re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',code)
    def TestReplace(before,after):
        """Требует единственную известную точку изменения тестового сценария."""
        nonlocal body
        assert body.count(before)==1,before
        body=body.replace(before,after,1)
    TestReplace('Dim stem As String, handle As Integer, signature As String, targetFraction As Double, seedMode As Long',
        'Dim stem As String, handle As Integer, signature As String, targetFraction As Double, seedMode As Long, fixedTarget As Double')
    TestReplace('    Dim originH As Double, trialH As Double, hasOriginH As Boolean, hasTrialH As Boolean',
        '    Dim originH As Double, trialH As Double, hasOriginH As Boolean, hasTrialH As Boolean\n'+
        '    Dim lambdaBound As Double, hasLambdaBound As Boolean, boundSeconds As Double, boundStarted As Double, solveEffort As Variant')
    TestReplace('targetFraction = testOptions(2 * caseIndex + 1): seedMode = CLng(testOptions(2 * caseIndex + 2))',
        'fixedTarget = testOptions(2 * caseIndex + 1): seedMode = CLng(testOptions(2 * caseIndex + 2))')
    TestReplace('If targetFraction <= 0# Or targetFraction > 1# Then Err.Raise 5, , "Доля контрольного шага должна быть в (0; 1]."',
        'If fixedTarget <= 0# Then Err.Raise 5, , "Задайте положительный абсолютный уровень ориентированной деформации."')
    TestReplace('''        If Not mReverseSolverTest.SelectSteelStrainDirectionControl(previous, accepted, projection, coordinate, spacing, limit, point, transverse) Then _
            Err.Raise 5, , "В принятой паре не найден растущий деформационный параметр арматуры."''',
        '''        projection = unusedProjection: limit = unusedContext(2): point = CLng(unusedContext(3)): transverse = (unusedContext(4) <> 0#)
        If UBound(projection) <> UBound(accepted) Or point <= mReverseOperatorsTest.ConcretePointCount Or _
                point > mReverseOperatorsTest.PointCount Then Err.Raise 5, , "Фиксированная проекция не соответствует исходному сечению."
        coordinate = TestSteelSeedCoordinate(projection, accepted)
        spacing = Abs(coordinate - TestSteelSeedCoordinate(projection, previous)) ' Проекция взята из первой проверенной пробы и сохраняет смысл обоих полушагов.''')
    TestReplace('stepSize = GeomMin(stepSize, 0.25 * (limit - coordinate)): target = coordinate + stepSize * targetFraction',
        '''stepSize = GeomMin(stepSize, 0.25 * (limit - coordinate)): target = fixedTarget
        If stepSize <= 0# Or target <= coordinate Or target >= limit Then Err.Raise 5, , "Фиксированная цель должна лежать между принятым уровнем и границей стали."
        targetFraction = (target - coordinate) / stepSize''')
    TestReplace('        hasOriginH = mReverseSolverTest.TryReadEnvelopeCoordinate(True, originH)',
        '        lambdaBound = 0#: hasLambdaBound = False: boundSeconds = 0#\n        hasOriginH = mReverseSolverTest.TryReadEnvelopeCoordinate(True, originH)')
    TestReplace('        stats = mReverseSolverTest.ReadPolishEffortTest',
        '        stats = mReverseSolverTest.ReadPolishEffortTest: solveEffort = stats')
    TestReplace('            hasTrialH = mReverseSolverTest.TryReadEnvelopeCoordinate(False, trialH)',
        '''            hasTrialH = mReverseSolverTest.TryReadEnvelopeCoordinate(False, trialH)
            boundStarted = Timer
            hasLambdaBound = mReverseSolverTest.TrialLambdaUncertainty(mReverseOptionsTest(3), mReverseOptionsTest(4), lambdaBound)
            boundSeconds = Timer - boundStarted: If boundSeconds < 0# Then boundSeconds = boundSeconds + 86400#
            stats = mReverseSolverTest.ReadPolishEffortTest ' Отдельная оценка границы тоже расходует вызовы уравнений; сохраняются оба счётчика.''')
    TestReplace('signature = "NDMSTEELCTRL0002"','signature = "NDMSTEELCTRL0003"')
    TestReplace('originH, trialH, Abs(CLng(hasTrialH)), Abs(CLng(hasOriginH)), ratio, anchorCoordinate, anchorFactor)',
        'originH, trialH, Abs(CLng(hasTrialH)), Abs(CLng(hasOriginH)), ratio, anchorCoordinate, anchorFactor, _\n'+
        '            Abs(CLng(hasLambdaBound)), lambdaBound, boundSeconds)')
    TestReplace('        Close #handle\n        handle = FreeFile',
        '        TestWriteReverseBinaryVector handle, solveEffort\n        Close #handle\n        handle = FreeFile')
    return re.sub(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code,count=1)


def TestStage(root,parent,coarse):
    """Добавляет к исходным103 машинным полям реальный половинный корень; его дальнейшие корни пока не заданы и не объявлены пригодными."""
    here=Path(__file__).resolve().parent
    reader=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary']
    vectors=run_path(str(here/'Check-TestCold86HRecoveryEvidence.py'))['TestVectors']
    original=reader(parent/'Input/Reverse1.bin');assert len(original['fields'])==103
    proof=json.loads((parent/'SteelStrainSeedProof.json').read_bytes())
    assert proof['cases'][3]['forward_positive_resolved_candidate']
    half=vectors(parent/'Native/SteelSeed.Case3.bin',b'NDMSTEELCTRL0002',7)
    full=vectors(coarse/'Native/SteelSeed.Case5.bin',b'NDMSTEELCTRL0002',7)
    assert half[0][1]==full[0][1]==1 and half[0][3]==full[0][3] and half[0][4]==full[0][4]
    assert np.array_equal(half[2],full[2]) and np.array_equal(half[3],original['fields'][-1])
    np.testing.assert_allclose(half[0][8]-full[0][5],.5*(full[0][8]-full[0][5]),rtol=1e-10)
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    (root/'SteelStrainSeedProof.json').rename(root/'Inherited.MidpointProof.json')
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'FixedHalfCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    vector=run_path(str(here/'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    data=b'NDMREVTEST000001'+struct.pack('<i',60)
    for name in ('calibration','options','offset','direction'):data+=vector(original[name])
    data+=struct.pack('<i',104)
    for fraction,factor,field in zip(original['fractions'],original['lambdas'],original['fields']):
        data+=struct.pack('<dd',fraction,factor)+vector(field)
    data+=struct.pack('<dd',1.,half[0][10])+vector(half[5])
    context=[half[0][10],full[0][6],full[0][3],full[0][4]]
    for values in (original['fields'][-1],half[5],half[5],half[6],full[2],context,np.zeros(4)):data+=vector(values)
    # Уровни1/4,1/2,1 оставшегося участка, каждый с постоянным полем и непосредственной принятой секущей.
    options=[value for fraction in (.25,.5,1.) for mode in (0,1)
        for value in (half[0][8]+fraction*(full[0][8]-half[0][8]),float(mode))]
    name='tests/modTestCoupledElasticState.bas';code=TestBody((root/name).read_text('utf-8-sig'))
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Input/Reverse1.bin':data,'Input/SteelSeedOptions.bin':struct.pack('<i12d',12,*options),
        'Input/Original103Prefix.bin':(parent/'Input/Reverse1.bin').read_bytes(),
        'Input/ActualFirstHalf.bin':(parent/'Native/SteelSeed.Case3.bin').read_bytes(),
        'Input/DirectCoarseEnd.bin':(coarse/'Native/SteelSeed.Case5.bin').read_bytes(),
        'Input/FirstHalfProof.json':(parent/'SteelStrainSeedProof.json').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='FixedSteelSecondHalf104',actual_import_this_pass=['modTestCoupledElasticState'],
        actual_current_compilation_reused_without_import=False,single_test_module_compiled=False,
        fresh_compilation_claimed=True,initial_history_states=104,fixed_control_from_actual_original_selector=True,
        no_new_material_or_physical_cutoff=True,absolute_targets_not_fraction_options=True,
        sequential_first_half_history_replayed=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    checked=reader(root/'Input/Reverse1.bin')
    assert np.array_equal(checked['fields'][:103],original['fields']) and np.array_equal(checked['fields'][-1],half[5])
    assert max(map(len,code.splitlines()))<1024
    print('SECOND-HALF104 READY; FIXED ORIGINAL CONTROL, REAL HALF HISTORY, ONE TEST IMPORT; CAPACITY NOT CLAIMED')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent','coarse'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve(),a.coarse.resolve())
