"""ДЛЯ ТЕСТОВ. Готовит вычисление направляющего корня и возврат к малой цели без заранее известного будущего поля."""
from argparse import ArgumentParser
from hashlib import sha256
import json,re
from pathlib import Path
from runpy import run_path


def TestStage(root,parent):
    """Меняет один тестовый модуль; обе пробы делят исходные30 итераций и одну неизменную историю."""
    here=Path(__file__).resolve().parent
    assert json.loads((parent/'PostPeakSteelProof.json').read_bytes())['cases'][0]['forward_positive_resolved_candidate']
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    ancestor=root/'OnlineGuideCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):(root/name).rename(ancestor/name)
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    payload=(here/'TestOnlineSteelGuide.bas.txt').read_text('utf-8-sig')
    body,=re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',payload)
    assert 'DiagnosticMidSeed' not in body and body.count('Open ')==1
    code,count=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert count==1
    assert max(map(len,code.splitlines()))<1024
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Compile-TestExternalPoint.ps1':(here/'Compile-TestExternalPoint.ps1').read_bytes(),
        'ParentCodeUpdate.json':(parent/'docs/regression/CodeUpdate.json').read_bytes(),
        'ParentCompileClosure.json':(parent/'CompilePointClosure.json').read_bytes(),
        'TestOnlineSteelGuide.bas.txt':payload.encode('utf-8-sig'),Path(__file__).name:Path(__file__).read_bytes()}
    for item,raw in values.items():
        (root/item).write_bytes(raw);prep['inputs'][item]=sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='OnlineSteelGuide146',initial_states=146,independent_trials=1,
        actual_import_this_pass=['modTestCoupledElasticState'],guide_target_fraction=.25,original_target_fraction=.125,
        common_primary_iterations=30,no_known_future_field_read=True,guide_not_committed=True,
        accepted_revision_must_remain_exact=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('ONLINE GUIDE146 READY; GUIDE AND RETURN SHARE30; NO PRECOMPUTED FUTURE FIELD')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve())
