"""ДЛЯ ТЕСТОВ. Собирает постоянное H-управление в частной книге с неизменными материалами и допусками."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, parent):
    """Импортирует два рабочих класса и холодный сценарий Trace; будущих полей или заданного физического предела нет."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    working = ('src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledDeformationContinuation.cls')
    for name in working:
        code = (repo / name).read_text('utf-8-sig')
        if name.endswith('CCoupledNewtonSolver.cls'):
            previous = (root / name).read_text('utf-8-sig')
            marker = 'Friend Function ReadReverseControlTest() As Variant'
            assert previous.count(marker) == 1
            cut = previous.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, previous.index(marker))
            assert cut > 0
            code += '\n' + previous[cut:]
        assert max(map(len, code.splitlines())) < 1024
        (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    all_file = root / 'AllCoupledSources.json'
    if all_file.exists():
        hashes = json.loads(all_file.read_bytes())
        for name in working:
            if name in hashes:
                hashes[name] = prep['inputs'][name]
        all_file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if all_file.name in prep['inputs']:
            prep['inputs'][all_file.name] = sha256(all_file.read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    anchor = '    Dim controller As New CCoupledDeformationContinuation, observer As New CCoupledProgressObserverTest'
    assert code.count(anchor) == 1
    checks = '''    Dim pairPrevious() As Double, beforeH As Double, afterH As Double, readH As Double
    If Not mReverseSolverTest.TryAcceptedEnvelopeSegment(pairPrevious, beforeH, afterH) Then Err.Raise 5, , "Нет восстановленной пары H."
    previous = fields(fields.Count - 1)
    For i = 1 To UBound(previous)
        If previous(i) <> pairPrevious(i) Then Err.Raise 5, , "Предыдущее поле пары H не совпало с принятой историей."
    Next i
    If Not mReverseSolverTest.TryReadEnvelopeCoordinate(True, readH) Then Err.Raise 5, , "Нет принятой H."
    If readH <> afterH Then Err.Raise 5, , "Текущая H пары не совпала с буфером."
    If Not mReverseSolverTest.ReplayAcceptedFields(fields, fields.Count - 1) Then Err.Raise 5, , "Нет предыдущей истории H."
    If Not mReverseSolverTest.TryReadEnvelopeCoordinate(True, readH) Then Err.Raise 5, , "Нет предыдущей H."
    If readH <> beforeH Then Err.Raise 5, , "Предыдущая H пары не совпала с независимым повтором."
    If Not mReverseSolverTest.ReplayAcceptedFields(fields, fields.Count) Then Err.Raise 5, , "Не восстановлен полный префикс H."
    If Not mReverseSolverTest.TryAcceptedEnvelopeSegment(pairPrevious, beforeH, readH) Then Err.Raise 5, , "Повтор потерял пару H."
    If readH <> afterH Then Err.Raise 5, , "Холодный повтор изменил H."
'''
    code = code.replace(anchor, checks + anchor, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    imports = ['CCoupledNewtonSolver', 'CCoupledDeformationContinuation', 'modTestCoupledElasticState']
    compiler = (root / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    old = "-ModuleNames 'modTestCoupledElasticState'"
    assert compiler.count(old) == 1
    compiler = compiler.replace(old, '-ModuleNames @(' + ','.join("'" + value + "'" for value in imports) + ')', 1)
    contents = {'Compile-TestPersistentH.ps1': compiler.encode('utf-8-sig'),
        'Run-TestHBackendAcceptance.ps1': (here / 'Run-TestHBackendAcceptance.ps1').read_bytes(),
        Path(__file__).name: Path(__file__).read_bytes()}
    for name, value in contents.items():
        (root / name).write_bytes(value); prep['inputs'][name] = sha256(value).hexdigest().upper()
    prep['directed_scope'].update(case='PersistentHController', actual_import_this_pass=imports,
        original_force_and_material_criteria=True, original_common_probe_limit=96,
        accepted_H_pair_replayed=True, persistent_H_control=True, physical_capacity_certified=False,
        initial_H_when_distinguishable=('SelectInitialEnvelopeControl' in (root / working[1]).read_text('utf-8-sig')),
        iterative_H_step_adaptation=('mSolver.IterationCount' in (root / working[1]).read_text('utf-8-sig')))
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('PERSISTENT H PRIVATE BOOK READY; TWO WORKING CLASSES AND ONE TEST SCENARIO')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
