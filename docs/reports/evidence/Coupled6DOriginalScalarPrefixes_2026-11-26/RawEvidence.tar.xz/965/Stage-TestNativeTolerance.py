"""ДЛЯ ТЕСТОВ. Ужесточает только внутреннюю точность собственного численного решения, сохраняя материал и внешний критерий."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct


def TestStage(root,parent,tolerance):
    """Данные задают более строгий численный допуск; ослабление исходного допуска запрещено нативным методом."""
    assert 1e-13<=tolerance<=1e-7
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    (root/'ParentPointTestModule.bas').write_bytes((root/name).read_bytes())
    (root/'ParentCodeUpdate.json').write_bytes((root/'docs/regression/CodeUpdate.json').read_bytes())
    (root/'ParentCompileClosure.json').write_bytes((root/'CompileClosure.json').read_bytes())
    ancestor=root/'ToleranceBuildAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        path=root/name
        if path.exists():path.replace(ancestor/name)
    anchor='    started = Timer\n    solved = solver.TrySolve(equations, initial, maximumCalls, maximumSteps, mExternalToleranceTest, _'
    assert code.count(anchor)==1
    code=code.replace(anchor,'''    Dim stoppingTolerance As Double: stoppingTolerance = mExternalToleranceTest
    Dim precisionFile As String: precisionFile = mPolishRootTest & "\\Input\\NativeTolerance.bin"
    If Len(Dir$(precisionFile)) > 0 Then
        Dim precisionHandle As Integer, requestedTolerance As Variant: precisionHandle = FreeFile
        Open precisionFile For Binary Access Read As #precisionHandle
        requestedTolerance = TestReadPolishVector(precisionHandle)
        If Seek(precisionHandle) <> LOF(precisionHandle) + 1 Then Err.Raise 5, , "Лишние байты точности нативного теста."
        Close #precisionHandle
        If LBound(requestedTolerance) <> 1 Or UBound(requestedTolerance) <> 1 Then Err.Raise 5, , "Задайте один численный допуск."
        If requestedTolerance(1) <= 0# Or requestedTolerance(1) > mExternalToleranceTest Then _
            Err.Raise 5, , "Численный допуск теста может только ужесточать исходную точность сил."
        stoppingTolerance = requestedTolerance(1)
    End If
    started = Timer
    solved = solver.TrySolve(equations, initial, maximumCalls, maximumSteps, stoppingTolerance, _''',1)
    name='tests/modTestCoupledElasticState.bas';(root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    (root/'Input/NativeTolerance.bin').write_bytes(struct.pack('<id',1,tolerance))
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    for name in ('ParentPointTestModule.bas','ParentCodeUpdate.json','ParentCompileClosure.json','Input/NativeTolerance.bin',Path(__file__).name):
        prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='NativeNumericalAccuracySensitivity',
        inner_nonlinear_tolerance_MPa=tolerance,original_final_force_tolerance_unchanged=True,
        material_return_precision_unchanged=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('STRICTER NUMERICAL EQUILIBRIUM READY; MATERIAL UNCHANGED',tolerance)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--parent',type=Path,required=True)
    parser.add_argument('--tolerance',type=float,default=1e-10);args=parser.parse_args()
    TestStage(args.root.resolve(),args.parent.resolve(),args.tolerance)
