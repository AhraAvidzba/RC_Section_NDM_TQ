"""ДЛЯ ТЕСТОВ. Исправляет служебное число проверок по фактическому исходнику и нативному протоколу без изменения VBA."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re


def TestClarify(repo, root):
    """Сохраняет прежнее ожидание и подтверждает, что скорректирована только метаинформация состава теста."""
    prep = json.loads((root / 'Preparation.json').read_bytes())
    code = (repo / 'tests/modTestCoupledHybrid.bas').read_text('utf-8-sig')
    assert len(re.findall(r'(?m)^        TestCheck ', code)) == 1 and '    For i = 1 To 9\n        TestCheck ' in code
    actual = len(re.findall(r'(?m)^    TestCheck ', code)) + 9
    report = (root / 'Native/HBackendUnit.txt').read_text('utf-8-sig')
    assert re.findall(r'^TOTAL_COUPLED_HYBRID_TEST: passed=(\d+); failed=(\d+)', report, re.M) == [(str(actual), '0')]
    compiled = json.loads((root / 'docs/regression/CodeUpdate.json').read_bytes())['WorkbookSHA256']
    assert sha256((root / 'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper() == compiled
    before = prep['directed_scope']['hybrid_unit_expected_assertions']
    prep['directed_scope']['hybrid_unit_expected_assertions'] = actual
    names = ('Stage-TestHNewtonBackend.py', Path(__file__).name)
    for name in names:
        data = (Path(__file__).resolve().parent / name).read_bytes()
        (root / name).write_bytes(data); prep['inputs'][name] = sha256(data).hexdigest().upper()
    name = 'UnitScopeClarification.json'
    value = dict(previous_metadata_count=before, actual_source_and_native_count=actual,
                 compiled_workbook_sha256_unchanged=compiled, numerical_inputs_unchanged=True,
                 accepted_test_expectations_not_weakened=True)
    (root / name).write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('UNIT SCOPE CLARIFIED:', before, '->', actual, '; ACTUAL VBA UNCHANGED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestClarify(args.repo.resolve(), args.root.resolve())
