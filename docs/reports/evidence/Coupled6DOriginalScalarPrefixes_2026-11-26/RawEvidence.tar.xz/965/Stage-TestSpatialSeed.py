"""ДЛЯ ТЕСТОВ. Отделяет влияние прогноза от выбора меры: использует существующую пространственную секущую после остановки H."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import struct
import numpy as np


def TestBody(code):
    """Меняет только тестовый сценарий; мера и её геометрический масштаб вычисляются существующими методами рабочего решателя."""
    body,=re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',code)
    def TestReplace(before,after):
        """Не допускает применения преобразования к неизвестной версии сценария."""
        nonlocal body
        assert body.count(before)==1,before
        body=body.replace(before,after,1)
    TestReplace('    Dim lambdaBound As Double, hasLambdaBound As Boolean, boundSeconds As Double, boundStarted As Double, solveEffort As Variant',
        '    Dim lambdaBound As Double, hasLambdaBound As Boolean, boundSeconds As Double, boundStarted As Double, solveEffort As Variant\n'+
        '    Dim movement() As Double, scaleField() As Double, nominalSpacing As Double, scaleFactor As Double, scaleFraction As Double')
    TestReplace('If fixedTarget <= 0# Then Err.Raise 5, , "Задайте положительный абсолютный уровень ориентированной деформации."',
        'If unusedContext(4) = 0# And (fixedTarget <= 0# Or fixedTarget > 1#) Then Err.Raise 5, , "Доля пространственного численного шага должна быть в (0; 1]."')
    start=body.index('        projection = unusedProjection: limit = unusedContext(2)')
    end=body.index('        seed = accepted:',start)
    body=body[:start]+'''        If unusedContext(4) = 0# Then
            ReDim movement(1 To UBound(accepted))
            For i = 1 To mReverseSolverTest.PhysicalDegreeCount: movement(i) = accepted(i) - previous(i): Next i
            If Not mReverseSolverTest.SelectSpatialDirectionControl(previous, accepted, movement, projection, coordinate, spacing) Then _
                Err.Raise 5, , "Не построена штатная пространственная секущая."
            nominalSpacing = spacing
            For i = count - 1 To 1 Step -1
                trace.ReadPoint i, scaleFraction, scaleFactor
                If scaleFraction <> 1# Then Exit For
                If Abs(currentFactor - scaleFactor) > 64# * mReverseOptionsTest(4) * (1# + Abs(currentFactor)) Then
                    scaleField = fields(i)
                    nominalSpacing = GeomMax(nominalSpacing, mReverseSolverTest.SpatialFieldDistance(scaleField, accepted))
                    Exit For
                End If
            Next i
            target = coordinate + nominalSpacing * fixedTarget
        ElseIf unusedContext(4) = 1# Then
            projection = unusedProjection
            coordinate = TestSteelSeedCoordinate(projection, accepted)
            spacing = Abs(coordinate - TestSteelSeedCoordinate(projection, previous))
            nominalSpacing = unusedContext(1): target = fixedTarget ' Абсолютный уровень позволяет сохранить ту же меру при последовательном дроблении.
        Else
            Err.Raise 5, , "Неизвестный режим пространственного теста."
        End If
        If nominalSpacing <= 0# Or target <= coordinate Then Err.Raise 5, , "Пространственный шаг не продвигает заданную меру."
        targetFraction = (target - coordinate) / nominalSpacing
        point = 0: transverse = False: limit = 0# ' У геометрической меры нет собственного физического предела материала; эти три поля неприменимы.
''' +body[end:]
    TestReplace('signature = "NDMSTEELCTRL0003"','signature = "NDMGEOMCTRL00001"')
    TestReplace('Abs(CLng(hasLambdaBound)), lambdaBound, boundSeconds)',
        'Abs(CLng(hasLambdaBound)), lambdaBound, boundSeconds, nominalSpacing, unusedContext(4))')
    result=re.sub(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code,count=1)
    return result.replace('TestSteelSeedCoordinate','TestLinearSeedCoordinate')


def TestStage(repo,root,parent):
    """Восстанавливает исходные103поля, делает шесть парных проб штатной меры; не меняет рабочий контроллер и не повышает бюджет."""
    here=Path(__file__).resolve().parent
    checked=json.loads((parent/'SteelFixedHalfProof.json').read_bytes())
    assert checked['mathematical_equilibria']==6 and checked['full_vs_two_half']['same_original_control_target']
    read=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original=read(parent/'Input/Original103Prefix.bin');assert len(original['fields'])==103
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    (root/'SteelFixedHalfProof.json').rename(root/'Inherited.FixedHalfProof.json')
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'SpatialSeedCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    vector=run_path(str(here/'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    data=b'NDMREVTEST000001'+struct.pack('<i',60)
    for name in ('calibration','options','offset','direction'):data+=vector(original[name])
    data+=struct.pack('<i',103)
    for fraction,factor,field in zip(original['fractions'],original['lambdas'],original['fields']):
        data+=struct.pack('<dd',fraction,factor)+vector(field)
    for values in (original['fields'][-2],original['fields'][-1],original['fields'][-1],original['actual'],np.zeros(60),np.zeros(4),np.zeros(4)):
        data+=vector(values)
    options=[value for fraction in (.25,.5,1.) for mode in (0,2) for value in (fraction,float(mode))]
    name='tests/modTestCoupledElasticState.bas';code=TestBody((root/name).read_text('utf-8-sig'))
    values={name:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Input/Reverse1.bin':data,'Input/SteelSeedOptions.bin':struct.pack('<i12d',12,*options),
        'Input/ParentFixedHalfProof.json':(parent/'SteelFixedHalfProof.json').read_bytes(),
        'Compile-TestExternalPoint.ps1':(here/'Compile-TestExternalPoint.ps1').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    numerical={}
    for method in ('TryDeformationStep','SelectSpatialDirectionControl','SpatialFieldDistance','SpatialIncrementAdvances'):
        pattern=r'(?ms)^Friend (?:Function|Sub) '+method+r'\(.*?^End (?:Function|Sub)'
        candidate,=re.findall(pattern,(root/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig'))
        working,=re.findall(pattern,(repo/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig'))
        assert candidate==working,method
        numerical[method]=dict(exact_working_method=True,sha256=sha256(candidate.encode()).hexdigest().upper())
    name='WorkingSpatialMethods.json';values[name]=(json.dumps(numerical,indent=2,sort_keys=True)+'\n').encode()
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='StockSpatialControlPairedSeeds103',actual_import_this_pass=['modTestCoupledElasticState'],
        actual_current_compilation_reused_without_import=False,single_test_module_compiled=False,fresh_compilation_claimed=True,
        initial_history_states=103,stock_spatial_measure_and_nominal_scale=True,
        steel_selector_not_used=True,no_material_limit_invented_for_geometric_control=True,
        primary_iteration_budget=30,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    reread=read(root/'Input/Reverse1.bin');assert np.array_equal(reread['fields'],original['fields'])
    assert max(map(len,code.splitlines()))<1024
    print('STOCK SPATIAL SEED PAIRS READY; FOUR WORKING METHODS EXACT; ONLY TESTMODULE CHANGED; SAME103HISTORY AND30ITERATIONS')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
