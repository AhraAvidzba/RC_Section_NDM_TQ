"""ДЛЯ ТЕСТОВ. Проверяет следующие три уровня штатного деления шага без новой компиляции и без изменения физики."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct


def TestStage(root,parent):
    """После уровней1,1/2,1/4 проверяет1/8,1/16,1/32; это конечный направленный опыт, не повышение бюджета поиска."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'SpatialSeedProof.json').read_bytes())
    assert proof['stock_spatial_projection_verified_independently'] and proof['working_controller_not_changed']
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    (root/'SpatialSeedProof.json').rename(root/'Inherited.CoarseSpatialProof.json')
    prep=json.loads((root/'Preparation.json').read_bytes());old=json.loads((parent/'Preparation.json').read_bytes())
    options=[value for fraction in (1/32,1/16,1/8) for mode in (0,2) for value in (fraction,float(mode))]
    runner=(here/'Run-TestImmutableSteelSeed.ps1').read_text('utf-8-sig')
    before="'NDM_STEEL_SEED_EXACT_REUSE_01'";assert runner.count(before)==1
    runner=runner.replace(before,"'NDM_SPATIAL_SEED_EXACT_REUSE_01'")
    assert runner.count('CompiledSourceReuseProof.json')==1
    runner=runner.replace('CompiledSourceReuseProof.json','ImmutableSpatialReuseProof.json')
    runner=runner.replace('ImmutableSteelSeedMidpoints','ImmutableSpatialStepHalves').replace('Immutable steel-seed probes exited','Immutable spatial probes exited')
    values={'Input/SteelSeedOptions.bin':struct.pack('<i12d',12,*options),
        'Input/CoarseSpatialProof.json':(parent/'SpatialSeedProof.json').read_bytes(),
        'Run-TestImmutableSpatialSeed.ps1':runner.replace('\n','\r\n').encode('utf-8-sig'),
        Path(__file__).name:Path(__file__).read_bytes()}
    for name,content in values.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    immutable={}
    for name,expected in old['inputs'].items():
        assert sha256((parent/name).read_bytes()).hexdigest().upper()==expected,name
        if name!='Input/SteelSeedOptions.bin':
            assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name
            immutable[name]=expected
    for name in ('docs/regression/Diagnostic.xlsm','docs/regression/CodeUpdate.json','CompileClosure.json','PointTraceSourceComposition.json'):
        assert (root/name).read_bytes()==(parent/name).read_bytes(),name
        immutable[name]=sha256((root/name).read_bytes()).hexdigest().upper()
    compiled=json.loads((parent/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
    assert immutable['docs/regression/Diagnostic.xlsm']==compiled['WorkbookSHA256']
    reuse=dict(format='NDM_SPATIAL_SEED_EXACT_REUSE_01',parent=str(parent),
        compiled_workbook_sha256=compiled['WorkbookSHA256'],fresh_compilation_claimed=False,
        actual_import_this_pass=[],immutable_parent_files_verified=immutable,
        source_component_count=255,parent_other_components_checked=254,
        material_history_reused=False,fresh_replay_required=True,
        only_numerical_trial_options_changed=True,material_laws_limits_tolerances_and_iterations_unchanged=True,
        physical_capacity_certified=False)
    name='ImmutableSpatialReuseProof.json';raw=(json.dumps(reuse,indent=2,sort_keys=True)+'\n').encode()
    (root/name).write_bytes(raw);prep['inputs'][name]=sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='StockSpatialNextStepHalves103',actual_import_this_pass=[],
        actual_current_compilation_reused_without_import=True,single_test_module_compiled=False,fresh_compilation_claimed=False,
        only_numerical_trial_options_changed=True,three_next_halving_levels=[1/8,1/16,1/32],
        original103_history_and_primary30_preserved=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('THREE NEXT SPATIAL HALVING LEVELS READY; EXACT255-COMPONENT BOOK REUSED, NO IMPORT, ORIGINAL103/30')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve())
