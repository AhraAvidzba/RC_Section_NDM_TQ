"""ДЛЯ ТЕСТОВ. Продолжает точную принятую H-историю исходным ядром этапа 637 без экспериментального выбора событий."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import numpy as np


def TestStage(root, parent, snapshot, maximum):
    """Меняет только исходную историю и тестовый сценарий; все рабочие классы переиспользуются без правок."""
    assert maximum in (8, 16, 24)
    here = Path(__file__).resolve().parent
    read = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original, current = read(parent / 'Input/Reverse1.bin'), read(snapshot)
    for key in ('calibration', 'options', 'offset', 'direction'):
        assert np.array_equal(original[key], current[key]), key
    for key in ('fields', 'lambdas', 'fractions'):
        assert np.array_equal(original[key], current[key][:len(original['fields'])]), key
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestAutomaticYieldPreparation.bas.txt').read_text('utf-8-sig')
    begin, end = body.index('    Print #report, "SELECTION"'), body.index('\nFinished:')
    body = body[:begin] + '    GoTo Finished\n' + body[end:]
    body = body.replace('hAccepted >= 8', 'hAccepted >= ' + str(maximum), 1)
    body = body.replace('EightAcceptedStates', 'AcceptedStateLimit' + str(maximum), 1)
    body = body.replace('hAttempt = 1 To 32', 'hAttempt = 1 To ' + str(4 * maximum), 1)
    body = body.replace('AutomaticYieldPreparationAfterActualHFailure', 'WorkingHContinuationFromExactSnapshot', 1)
    body = body.replace('Вызывает выбор и обе стороны материального события после действительной неудачной H-пробы; номер точки не задаёт.',
                        'Продолжает исходную рабочую H-координату с силовым повтором и точными снимками; выбора события не вызывает.', 1)
    assert 'TestReadYieldPreparation' not in body and 'TryPreparePrincipalTransition' not in body
    code, count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body, code)
    assert count == 1
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Input/Reverse1.bin'
    (root / name).write_bytes(snapshot.read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    origin = dict(source_snapshot=str(snapshot), sha256=current['sha256'], states=len(current['fields']),
                  original_prefix_states=len(original['fields']), original_prefix_exact=True,
                  fields_and_factors_are_native_Double=True, physical_capacity_certified=False)
    contents = {'Input/ExactWorkingHOrigin.json': (json.dumps(origin, indent=2, sort_keys=True) + '\n').encode(),
                Path(__file__).name: Path(__file__).read_bytes(),
                'Run-TestIntegratedYield.py': (root.parent / 'ActualStrictPoint6Completion20261120/Run-TestIntegratedYield.py').read_bytes()}
    for name, value in contents.items():
        (root / name).write_bytes(value)
        prep['inputs'][name] = sha256(value).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingHContinuationFromExactSnapshot', actual_import_this_pass=['modTestCoupledElasticState'],
        source_classes_unchanged=True, original_checkpoint637_core=True, source_snapshot=str(snapshot),
        current_input_states=len(current['fields']), maximum_new_H_states=maximum, maximum_H_failures_at_revision=4,
        prescribed_material_point_or_level=False, event_context_restored=False, automatic_event_selection_exercised=False,
        original_force_and_material_criteria=True, controller_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, sort_keys=True, indent=2) + '\n').encode())
    print('ORIGINAL WORKING H READY;', len(current['fields']), 'EXACT INPUT STATES;', maximum, 'NEW STATE LIMIT; ONE TEST IMPORT')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    for name in ('root', 'parent', 'snapshot'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--maximum', type=int, default=16)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve(), args.snapshot.resolve(), args.maximum)
