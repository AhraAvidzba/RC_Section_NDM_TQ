"""ДЛЯ ТЕСТОВ. Заменяет только управляющую строку фактической пробной поверхностью обнаруженной бетонной точки."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root,parent):
    """Материальный уровень — численный размер шага, не предел прочности; силовые допуски исходные."""
    here=Path(__file__).resolve().parent
    study=json.loads((parent/'Native/ExternalLineStudy.json').read_bytes())
    result=json.loads((parent/'Native/ExternalResult.json').read_bytes())
    assert result['outcome']=='NoVerifiedLocalNDS;NotPhysicalFailure'
    assert result['owned_excel_final_state']['state'] in ('Absent','Exited')
    event=study['event'];assert len(study['selected_rows'])==1
    assert event['point']==study['candidate_point_from_operator_projection']
    baseline=next(row for row in study['changed_point_branch_rows'] if row['point']==event['point'] and row['side']==event['side'])['before'][3]
    tolerance=result['context_metadata'][3]
    control=dict(point=event['point'],side=event['side'],principal_index=0,
        observed_initial_trial_yield_MPa=baseline,target_MPa=baseline+10*tolerance,
        numerical_increment_MPa=10*tolerance,original_force_tolerance_MPa=tolerance,
        target_is_numerical_step_not_strength_criterion=True,
        material_law_and_native_force_gauge_rows_unchanged=True,
        branch_connection_not_yet_proven=True)
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='Input/MaterialControl.json';(root/name).write_bytes((json.dumps(control,indent=2,sort_keys=True)+'\n').encode())
    for name in ('Run-TestExternalEnvelope.py',Path(__file__).name):
        (root/name).write_bytes((here/name).read_bytes())
    for name in ('Input/MaterialControl.json','Run-TestExternalEnvelope.py',Path(__file__).name):
        prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ActualNativeMaterialCoordinate',
        scalar_control_row_from_actual_VBA_point_trial_yield=True,
        energy_coordinate_not_an_active_equation=True,
        full_equations_not_identical_to_energy_case=True,
        original_force_tolerance=True,material_laws_changed=False,
        production_external_dependency_added=False,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('ACTUAL NATIVE MATERIAL COORDINATE READY',control['point'],control['side'],control['target_MPa'])


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--parent',type=Path,required=True)
    args=parser.parse_args();TestStage(args.root.resolve(),args.parent.resolve())
