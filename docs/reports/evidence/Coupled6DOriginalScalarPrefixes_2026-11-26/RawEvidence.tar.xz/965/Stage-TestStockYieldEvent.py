"""ДЛЯ ТЕСТОВ. Готовит штатный Both/Excel от начала с текущим контроллером и проверенным ядром события CDP."""
from argparse import ArgumentParser
from pathlib import Path
from runpy import run_path
from hashlib import sha256
import json


def TestStage(repo,root,parent):
    """Нативные состояния не переносятся; выполняется одна новая компиляция текущего рабочего контроллера."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    for original,copy in [('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')]:
        (root/copy).write_bytes((root/original).read_bytes());prep['inputs'][copy]=sha256((root/copy).read_bytes()).hexdigest().upper()
    ancestor=root/('StockBuildAncestor_'+root.name);ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).replace(ancestor/name)
    name='src/Solver/CCoupledDeformationContinuation.cls'
    (root/name).write_bytes((repo/name).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace("-ModuleNames 'modTestCoupledElasticState'","-ModuleNames 'CCoupledDeformationContinuation'")
    name='Compile-TestStockYield.ps1';(root/name).write_bytes(compiler.encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    runner=(parent/'Run-TestWorkingASD.ps1').read_text('utf-8-sig')
    before='(Compare-Object ($prep.modules|Sort-Object) ($compile.Modules|Sort-Object))'
    assert runner.count(before)==1
    runner=runner.replace(before,"(Compare-Object @('CCoupledDeformationContinuation') ($compile.Modules|Sort-Object))",1)
    before="'-MacroArgument2','Excel','-TimeoutSeconds','240','-VerifyResultsReopen'"
    assert runner.count(before)==1
    runner=runner.replace(before,"'-MacroArgument2','Excel','-TimeoutSeconds','600','-VerifyResultsReopen'",1)
    name='Run-TestStockYield.ps1';(root/name).write_bytes(runner.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes());prep['inputs'][Path(__file__).name]=sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingCDPYieldEventStockBothExcel',fresh_native_history_from_zero=True,
        fresh_import_this_pass=['CCoupledDeformationContinuation'],no_prescribed_material_point_or_level=True,
        requested_load_path='Auto/All6 hard shear',native_timeout_seconds=600,results_saved_reopened_required=True,
        physical_capacity_certified=False,installed_workbook_changed=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('STOCK BOTH/EXCEL READY; CURRENT CONTROLLER; FRESH HISTORY FROM ZERO')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,required=True);p.add_argument('--parent',type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
