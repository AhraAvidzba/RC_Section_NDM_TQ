"""ДЛЯ ТЕСТОВ. Ограничивает отложенное уточнение пространственным CDP и поясняет неразличимый пик без изменения критериев."""
from pathlib import Path
from hashlib import sha256
from runpy import run_path
import json

here=Path(__file__).resolve().parent;base=Path('D:/CodexScratch/RC_Section_NDM_TQ')
root=base/'Cold719ScopedPeakRefinement_20261124';parent=base/'Cold718ControlledLoadBalance_20261124'
run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
archive=root/'ScopedPeakCompilationAncestor';archive.mkdir()
for name in ('CompilePoint.log','CompilePointClosure.json'):(root/name).rename(archive/name)
prep=json.loads((root/'Preparation.json').read_bytes());values={}
path='src/Solver/CCoupledDeformationContinuation.cls';code=(root/path).read_text('utf-8-sig')
anchor='''            If mDesignHistoryIndex = 0 Then Exit For ' До подтверждения расчётной нагрузки сохраняется грубый локальный пик; конечная приёмка по-прежнему требует исходной точности.
''';assert code.count(anchor)==1
code=code.replace(anchor,'''            If mSolver.UsesSpatialHistory And mSolver.SupportsHybridRecovery And mDesignHistoryIndex = 0 Then Exit For ' Только пространственный CDP откладывает точность раннего пика; конечная приёмка требует исходного допуска.
''',1)
anchor='    If peakIndex = 0 Then Exit Function\n';assert code.count(anchor)==1
code=code.replace(anchor,'''    If peakIndex = 0 Then
        mProbeDetails = "При повторе плеч не найден максимум, отделённый от соседних уровней с учётом погрешности lambda. " & _
            "Крайние множители: " & CStr(samples(0).Lambda) & " и " & CStr(samples(index).Lambda) & "; проверено промежуточных уровней: " & CStr(index - 1) & "."
        Exit Function
    End If
''',1)
values[path]=code.replace('\n','\r\n').encode('utf-8-sig')
compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig').replace("-ModuleNames 'modTestCoupledElasticState'","-ModuleNames 'CCoupledDeformationContinuation'")
values['Compile-TestExternalPoint.ps1']=compiler.replace('\n','\r\n').encode('utf-8-sig')
values['ParentCodeUpdate.json']=(parent/'docs/regression/CodeUpdate.json').read_bytes()
values['ParentCompileClosure.json']=(parent/'CompilePointClosure.json').read_bytes()
values[Path(__file__).name]=Path(__file__).read_bytes()
for name,data in values.items():(root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
prep['directed_scope'].update(case='ScopedSpatialPeakRefinement',actual_import_this_pass=['CCoupledDeformationContinuation'],
    delayed_early_peak_refinement_only_for_spatial_CDP=True,nonspatial_peak_precision_restored=True,
    original_twin_peak_reference_and_tolerance_unchanged=True,no_distinguishable_peak_reason_explicit=True,
    material718_exact=True,Newton718_exact=True,physical_capacity_certified=False)
(root/'Preparation.json').write_text(json.dumps(prep,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print('719 SCOPED SPATIAL CDP REFINEMENT; ORIGINAL NONSPATIAL PRECISION; EXPLICIT UNCERTAINTY REASON')
