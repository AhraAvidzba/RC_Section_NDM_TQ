"""ДЛЯ ТЕСТОВ. Собирает собственную H-касательную с тем же Newton–Armijo, что используется разностным резервом."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent):
    """Импортирует три рабочих класса и два тестовых модуля; материалы и силовые критерии сохраняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHBackend.py'))['TestStage'](repo, root, parent, False)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    working = ('src/Solver/CCoupledHybridSolver.cls', 'tests/modTestCoupledHybrid.bas')
    for name in working:
        code = (repo / name).read_text('utf-8-sig')
        if name.endswith('CCoupledHybridSolver.cls'):
            anchor = '            If accepted Then\n                mDifferenceBefore = before:'
            assert code.count(anchor) == 1
            code = code.replace(anchor, '            If accepted Then\n'
                '                modTestCoupledElasticState.TestRecordLiveDifference before, after, score, j, mJacobianCalls, mSteps, mFunctionCalls\n'
                '                mDifferenceBefore = before:', 1)
        (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
        if Path(name).stem not in prep['modules']:
            prep['modules'].append(Path(name).stem)
    name = 'AllCoupledSources.json'
    if (root / name).exists():
        hashes = json.loads((root / name).read_bytes())
        for source in working:
            hashes[source] = prep['inputs'][source]
        (root / name).write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if name in prep['inputs']:
            prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    compiler = (root / 'Compile-TestHCoordinateGradient.ps1').read_text('utf-8-sig')
    imports = ['CCoupledNewtonSolver','CCoupledEnvelopeEquations','modTestCoupledElasticState','CCoupledHybridSolver','modTestCoupledHybrid']
    old = "-ModuleNames @('CCoupledNewtonSolver','CCoupledEnvelopeEquations','modTestCoupledElasticState')"
    assert compiler.count(old) == 1
    compiler = compiler.replace(old, '-ModuleNames @(' + ','.join("'" + name + "'" for name in imports) + ')', 1)
    for name, raw in {'Compile-TestHNewtonBackend.ps1': compiler.encode('utf-8-sig'),
                      Path(__file__).name: Path(__file__).read_bytes()}.items():
        (root / name).write_bytes(raw); prep['inputs'][name] = sha256(raw).hexdigest().upper()
    unit_code = (repo / 'tests/modTestCoupledHybrid.bas').read_text('utf-8-sig')
    assert len(re.findall(r'(?m)^        TestCheck ', unit_code)) == 1 and '    For i = 1 To 9\n        TestCheck ' in unit_code
    unit_assertions = len(re.findall(r'(?m)^    TestCheck ', unit_code)) + 9
    prep['directed_scope'].update(case='HBackendOwnNewtonWithFDReserve', actual_import_this_pass=imports,
        own_matrix_globalization='FullNewtonArmijo', FD_reserve_globalization='FullNewtonArmijo',
        actual_prepared_source_components=len(prep['modules']),
        hybrid_unit_expected_assertions=unit_assertions)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('H NEWTON BACKEND READY; FIVE IMPORTS;', len(prep['modules']), 'PREPARED SOURCE COMPONENTS')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
