"""ДЛЯ ТЕСТОВ. Готовит продолжение после принятого материального перехода с прежним общим бюджетом96."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent):
    """Меняет только контроллер; физические входы,103 исходных поля и рабочие методы Newton сохраняет."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'DepartureEligibilityTraceProof.json').read_bytes())
    assert proof['current140_Newton_methods_verified'] and proof['current_controller_verified']
    assert proof['initial_states']==103 and proof['final_states']==118
    assert proof['new_reserve_attempts']==proof['new_reserve_accepted_points']==1
    assert proof['internal_status']==6 and proof['result_code']==10
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    (root/'DepartureEligibilityTraceProof.json').rename(root/'Inherited.MaterialTransition118Proof.json')
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'ContinuedBudgetCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    name='src/Solver/CCoupledDeformationContinuation.cls';controller=(repo/name).read_bytes()
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    anchor="-ModuleNames 'modTestCoupledElasticState'";assert compiler.count(anchor)==1
    compiler=compiler.replace(anchor,"-ModuleNames 'CCoupledDeformationContinuation'")
    values={name:controller,'Input/WorkingDepartureController.cls':controller,
        'Compile-TestExternalPoint.ps1':compiler.replace('\n','\r\n').encode('utf-8-sig'),
        'Input/MaterialTransition118Proof.json':(parent/'DepartureEligibilityTraceProof.json').read_bytes(),
        'Input/ParentPreparation.json':(parent/'Preparation.json').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    for item,raw in values.items():
        (root/item).write_bytes(raw);prep['inputs'][item]=sha256(raw).hexdigest().upper()
    prep['directed_scope']=dict(case='ContinuedMaterialTransitionBudget96',
        actual_import_this_pass=['CCoupledDeformationContinuation'],initial_states=103,
        existing_Newton_methods_exact_current=140,exact_parent_Newton_and_test_preserved=True,
        actual_working_Trace_API=True,global_probe_limit_unchanged=96,primary_iteration_budget=30,
        initial_step_limit_remains32_without_accepted_material_recovery=True,
        accepted_material_recovery_exempts_only_initial_step_limit=True,
        prescribed_future_field=False,prescribed_material_point_or_level=False,
        original_material_law_and_force_tolerances=True,history_replayed_from_zero=True,
        full_cold_start=False,working_output_book_unchanged=True,physical_capacity_certified=False,
        inherited_diagnostic_metadata_is_historical_in_ParentPreparation=True)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    print('CONTINUED MATERIAL BUDGET READY; ONE CONTROLLER IMPORT; SAME103FIELDS/NEWTON/TEST; TOTAL96/PRIMARY30')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
