﻿# ДЛЯ ТЕСТОВ: одна нативная проверка станционных пределов стали в частной книге.
param([string]$Root=$PSScriptRoot)
$ErrorActionPreference='Stop'
Push-Location -LiteralPath $Root
try {
    . './Guard-IsolatedOffice.ps1'
    Assert-IsolatedOfficeReady 'SpatialSteelLimits'
    & './tools/build_workbook/Run-FocusedKaniWatchdog.ps1' -SourceWorkbook 'docs/regression/Diagnostic.xlsm' -ReportPath 'Native/SpatialSteel.txt' `
        -Macro 'modTestCoupledElasticState.RunTestSpatialSteelLimits' -TimeoutSeconds 180 -Mode No -FailFast
    if($LASTEXITCODE -ne 0){throw ('Spatial steel test exited '+$LASTEXITCODE)}
} finally {Pop-Location}
