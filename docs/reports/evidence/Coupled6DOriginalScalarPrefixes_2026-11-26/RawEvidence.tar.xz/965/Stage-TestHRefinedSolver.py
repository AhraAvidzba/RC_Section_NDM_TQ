"""ДЛЯ ТЕСТОВ. Проверяет рабочую H-матрицу и сравнивает решения по собственной и глобальной разностной касательной."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, parent):
    """Импортирует два текущих рабочих класса и читающий сценарий; принятых состояний не добавляет."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHCoordinateGradient.py'))['TestStage'](repo, root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    anchor = '        Set target = coordinate.AtTarget(mReverseSolverTest, H): Set legacy = target'
    assert code.count(anchor) == 1
    body = '''        Dim mode As Long, hybrid As CCoupledHybridSolver, solution() As Double, solved As Boolean
        Dim solveStarted As Double, solveTolerance As Double, calls As Long, maximum As Double
        Dim solveField() As Double, solveFactor As Double, solveReady As Boolean
        solveTolerance = resolution * coordinate.RowScale
        calls = CLng((2# * size + 1#) * (mReverseOptionsTest(2) + 1#) + mReverseOptionsTest(2))
        Print #report, "S_OPTIONS" & TestHardPreparedVector(Array(probe, calls, mReverseOptionsTest(2), solveTolerance, H))
        For mode = 1 To 2
            Set hybrid = New CCoupledHybridSolver: solveStarted = Timer
            If mode = 1 Then
                solved = hybrid.TrySolve(equations, zero, calls, CLng(mReverseOptionsTest(2)), solveTolerance, _
                    0.00000000001, 0.2, solution, automaticScaling:=True, freshJacobian:=True)
            Else
                solved = hybrid.TrySolve(equations, zero, calls, CLng(mReverseOptionsTest(2)), solveTolerance, _
                    0.00000000001, 0.2, solution, relativeDifferenceStep:=0.000001, _
                    automaticScaling:=True, freshJacobian:=True, completeNewtonLineSearch:=True)
            End If
            maximum = 0#: solveReady = False
            If hybrid.HasBestPoint Then solveReady = equations.TryEvaluate(solution, False, after, ignored)
            If solveReady Then
                For row = 1 To size: maximum = GeomMax(maximum, Abs(after(row))): Next row
                mReverseSolverTest.ReadEquationField solution, solveField, solveFactor
                Print #report, "S_FIELD;" & CStr(probe) & ";" & CStr(mode) & ";" & TestOnsetNumber(solveFactor) & TestHardPreparedVector(solveField)
                Print #report, "S_RESIDUAL;" & CStr(probe) & ";" & CStr(mode) & TestHardPreparedVector(after)
            End If
            Print #report, "S_SOLVE" & TestHardPreparedVector(Array(probe, mode, solved, solveReady, Timer - solveStarted, _
                maximum, solveTolerance, hybrid.StopCode, hybrid.Steps, hybrid.FunctionCalls, hybrid.JacobianCalls, _
                mReverseSolverTest.AcceptedRevision = revision))
        Next mode
        If Not equations.TryEvaluate(zero, False, after, ignored) Then Err.Raise 5, , "Не повторена невязка после двух решений H."
        For row = 1 To size: If before(row) <> after(row) Then repeated = False
        Next row
        Print #report, "AFTER_SOLVE;" & CStr(probe) & TestHardPreparedVector(after)
'''
    code = code.replace(anchor, body + anchor)
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='RefinedHMatrixAndSolver', physical_matrix_absolute_acceptance_MPa=2e-6,
        physical_matrix_relative_acceptance=2e-5, two_methods_share_exact_initial_coordinate_and_target=True,
        analytic_method='ExistingFreshDogleg', reference_method='OriginalFullDifferenceNewton',
        original_force_and_material_criteria=True, maximum_new_states=0, production_H_backend_changed=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('REFINED WORKING H MATRIX AND TWO SOLVERS READY; HISTORY READ ONLY; ORIGINAL BUDGET')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
