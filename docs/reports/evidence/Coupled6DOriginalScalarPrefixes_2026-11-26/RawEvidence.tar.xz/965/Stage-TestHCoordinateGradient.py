"""ДЛЯ ТЕСТОВ. Собирает рабочую производную H и проверку её строки по независимым глобальным разностям."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, parent):
    """Переносит два актуальных рабочих класса и один тестовый сценарий, сохраняя только читающие тестовые суффиксы."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    working = ('src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledEnvelopeEquations.cls')
    for name in working:
        code = (repo / name).read_text('utf-8-sig')
        if name.endswith('CCoupledNewtonSolver.cls'):
            old = (root / name).read_text('utf-8-sig')
            marker = 'Friend Function ReadReverseControlTest() As Variant'
            assert old.count(marker) == 1
            cut = old.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, old.index(marker))
            assert cut > 0
            code += '\n' + old[cut:]
        (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    all_file = root / 'AllCoupledSources.json'
    if all_file.exists():
        hashes = json.loads(all_file.read_bytes())
        for name in working:
            if name in hashes:
                hashes[name] = prep['inputs'][name]
        all_file.write_bytes((json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode())
        if all_file.name in prep['inputs']:
            prep['inputs'][all_file.name] = sha256(all_file.read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    match = re.search(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', code)
    prefix = code[:match.start()].splitlines(keepends=True)
    while prefix and (not prefix[-1].strip() or prefix[-1].lstrip().startswith("'")):
        prefix.pop()
    body = (here / 'TestHCoordinateGradient.bas.txt').read_text('utf-8-sig')
    code = ''.join(prefix) + '\n\n' + body + code[match.end():]
    names = re.findall(r'(?im)^(?:Public|Private|Friend) (?:Function|Sub) (\w+)', code)
    assert len(names) == len(set(value.lower() for value in names)) and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    imports = ['CCoupledNewtonSolver', 'CCoupledEnvelopeEquations', 'modTestCoupledElasticState']
    compiler = (root / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    compiler = compiler.replace("-ModuleNames 'modTestCoupledElasticState'", '-ModuleNames @(' + ','.join("'" + value + "'" for value in imports) + ')', 1)
    contents = {'Compile-TestHCoordinateGradient.ps1': compiler.encode('utf-8-sig'),
                Path(__file__).name: Path(__file__).read_bytes(),
                'TestHCoordinateGradient.bas.txt': (here / 'TestHCoordinateGradient.bas.txt').read_bytes()}
    for name, value in contents.items():
        (root / name).write_bytes(value)
        prep['inputs'][name] = sha256(value).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingHCoordinateGradient', actual_import_this_pass=imports, fresh_compilation_claimed=True,
        working_class_sources_current=True, source_classes_unchanged=False, original_force_and_material_criteria=True,
        gradient_relative_acceptance=1e-4, gradient_absolute_acceptance_MPa=2e-7,
        independent_global_difference_step=1e-6, maximum_new_states=0, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING H GRADIENT READY; TWO WORKING CLASSES AND ONE TEST IMPORT; ORIGINAL MATERIALS')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.parent.resolve())
