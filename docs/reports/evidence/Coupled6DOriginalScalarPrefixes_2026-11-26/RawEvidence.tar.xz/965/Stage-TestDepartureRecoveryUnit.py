"""ДЛЯ ТЕСТОВ. Собирает фактический рабочий резерв с узкой имитацией состояния после H и штатной приёмкой кандидата."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo,root,parent):
    """Код контроллера берётся из текущих исходников; тестовая обёртка добавляется только в частную книгу и не задаёт будущего решения."""
    here=Path(__file__).resolve().parent
    proof=json.loads((parent/'SpatialSeedProof.json').read_bytes())
    assert proof['working_return_contract_observed'] and proof['mathematical_equilibria']==0
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    (root/'SpatialSeedProof.json').rename(root/'Inherited.SmallStepProof.json')
    prep=json.loads((root/'Preparation.json').read_bytes());ancestor=root/'DepartureUnitCompilationAncestor';ancestor.mkdir()
    for name in ('CompilePoint.log','CompilePointClosure.json'):
        if (root/name).exists():(root/name).rename(ancestor/name)
    for before,after in (('docs/regression/CodeUpdate.json','ParentCodeUpdate.json'),('CompileClosure.json','ParentCompileClosure.json')):
        (root/after).write_bytes((parent/before).read_bytes());prep['inputs'][after]=sha256((root/after).read_bytes()).hexdigest().upper()
    name='src/Solver/CCoupledDeformationContinuation.cls';working=(repo/name).read_text('utf-8-sig')
    assert 'TryRecoverEnvelopeDeparture' in working and 'TestRecoverEnvelopeDepartureOnce' not in working
    wrapper=(here/'TestDepartureRecoveryController.cls.txt').read_text('utf-8-sig')
    controller=working+'\n'+wrapper
    testname='tests/modTestCoupledElasticState.bas';code=(root/testname).read_text('utf-8-sig')
    payload=(here/'TestDepartureRecoveryUnit.bas.txt').read_text('utf-8-sig')
    body,=re.findall(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',payload)
    code,count=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert count==1
    imports=['CCoupledDeformationContinuation','modTestCoupledElasticState']
    compiler=(here/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    assert compiler.count("-ModuleNames 'modTestCoupledElasticState'")==1
    compiler=compiler.replace("-ModuleNames 'modTestCoupledElasticState'",'-ModuleNames @('+','.join(repr(x) for x in imports)+')')
    values={name:controller.replace('\n','\r\n').encode('utf-8-sig'),
        testname:code.replace('\n','\r\n').encode('utf-8-sig'),
        'Compile-TestExternalPoint.ps1':compiler.replace('\n','\r\n').encode('utf-8-sig'),
        'Input/WorkingDepartureController.cls':(repo/name).read_bytes(),
        'Input/ActualSmallStepProof.json':(parent/'SpatialSeedProof.json').read_bytes()}
    for item in (Path(__file__).name,'TestDepartureRecoveryController.cls.txt','TestDepartureRecoveryUnit.bas.txt'):
        values[item]=(here/item).read_bytes()
    for item,raw in values.items():
        (root/item).write_bytes(raw);prep['inputs'][item]=sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingDepartureRecoveryUnit103',actual_import_this_pass=imports,
        fresh_compilation_claimed=True,actual_current_compilation_reused_without_import=False,single_test_module_compiled=False,
        injected_post_H_departure_state=True,working_reserve_and_admission_methods_executed=True,
        main_Trace_loop_not_executed=True,no_prescribed_material_point_level_or_future_field=True,
        global_probe_limit_unchanged=96,primary_iteration_budget=30,working_output_book_unchanged=True,
        physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
    assert max(map(len,controller.splitlines()))<1024 and max(map(len,code.splitlines()))<1024
    print('WORKING DEPARTURE RECOVERY UNIT READY; TWO IMPORTS; NO FUTURE ROOT; GLOBAL96/PRIMARY30 UNCHANGED')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('root','parent'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
