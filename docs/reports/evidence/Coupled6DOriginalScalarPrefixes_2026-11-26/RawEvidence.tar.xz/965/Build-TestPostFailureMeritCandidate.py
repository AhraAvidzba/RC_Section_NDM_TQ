"""ДЛЯ ТЕСТОВ. Добавляет явно заданный резерв после трёх исходных H-методов, сохраняя успешные исходные решения."""
from argparse import ArgumentParser
from pathlib import Path
import re
from runpy import run_path


def TestBuild(repo, source, output):
    """Основной бюджет и дополнительный резерв учитываются раздельно; исходный допуск не меняется."""
    replace = run_path(str(Path(__file__).resolve().parent/'Build-TestRectangularMeritCandidate.py'))['TestReplace']
    output.mkdir()
    for name in ('CCoupledHybridFactorization.cls','CCoupledHybridSolver.cls','CCoupledEnvelopeEquations.cls'):
        (output/name).write_bytes((source/name).read_bytes())
    code = (repo/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    original, = re.findall(r'(?ms)^Private Function SolveEnvelopeTarget\(.*?^End Function',code)
    method = replace(original,
        'Optional ByVal ownOnly As Boolean = False, Optional ByVal maximumFunctionCalls As Long = 0, Optional ByVal originLambda As Double = -1#) As Boolean',
        'Optional ByVal ownOnly As Boolean = False, Optional ByVal maximumFunctionCalls As Long = 0, Optional ByVal originLambda As Double = -1#, _\n        Optional ByVal residualRecoverySteps As Long = 0) As Boolean')
    method = replace(method,'    Dim growthSeedReady As Boolean, functionBudget As Long',
        '    Dim growthSeedReady As Boolean, functionBudget As Long, recoverySeedReady As Boolean, recoverySeed() As Double\n    Dim recoverySeedNorm As Double, totalBudget As Long: totalBudget = remaining')
    method = replace(method,'    For pass = 1 To 3','    For pass = 1 To 4')
    method = replace(method,'        budget = remaining - usedSteps', '''        If pass = 4 Then
            If residualRecoverySteps < 1 Or Not recoverySeedReady Then Exit For
            If recoverySeedNorm > SMALL_STRAIN_MAX_NORM * tolerance Then Exit For
            totalBudget = remaining + residualRecoverySteps
            maximumCalls = maximumCalls + (2 * size + 2) * residualRecoverySteps
            startCoordinates = recoverySeed
        End If
        budget = totalBudget - usedSteps''')
    method = replace(method,'Set wrapper = mEnvelope.AtTarget(Me, target, ownMatrix): Set equations = wrapper',
        'Set wrapper = mEnvelope.AtTarget(Me, target, ownMatrix, includeResultants:=(pass = 4)): Set equations = wrapper')
    method = replace(method,'        Else\n            method = "доверительная область QR, разностный резерв"', '''        ElseIf pass = 4 Then
            method = "доверительная область QR, дополнительный резерв полных невязок"
            solved = solver.TrySolveLeastSquaresTrust(equations, startCoordinates, functionBudget, budget, _
                tolerance, solution, relativeDifferenceStep:=HYBRID_DIFFERENCE_STEP, _
                equationCount:=size + COMPONENT_COUNT, boundedMerit:=True)
        Else
            method = "доверительная область QR, разностный резерв"''')
    method = replace(method,'        If solver.HasBestPoint Then mLastNorm = solver.BestResidual', '''        If solver.HasBestPoint Then mLastNorm = solver.BestResidual
        If pass = 2 And solver.HasBestPoint Then recoverySeed = solution: recoverySeedNorm = solver.BestResidual: recoverySeedReady = True ' Непринятая проба принадлежит тому же неизменённому материальному контексту.''')
    method = replace(method,'For i = 1 To size: maximum = GeomMax(maximum, Abs(residual(i))): Next i',
        'For i = 1 To UBound(residual): maximum = GeomMax(maximum, Abs(residual(i))): Next i')
    method = replace(method,'tolerance, remaining, maximumCalls, usedSteps, usedCalls)',
        'tolerance, totalBudget, maximumCalls, usedSteps, usedCalls)')
    code = replace(code,original,method)
    original, = re.findall(r'(?ms)^Friend Function TryEnvelopeStep\(.*?^End Function',code)
    method = replace(original,'Optional ByVal retainEnvelopeControl As Boolean = False) As Boolean',
        'Optional ByVal retainEnvelopeControl As Boolean = False, Optional ByVal residualRecoverySteps As Long = 0) As Boolean')
    method = replace(method,'    probes = 0','    probes = 0\n    If residualRecoverySteps < 0 Then Err.Raise 5, "CCoupledNewtonSolver", "Дополнительный бюджет H не может быть отрицательным."')
    method = replace(method,'full, fullLambda, originLambda:=acceptedLambda)',
        'full, fullLambda, originLambda:=acceptedLambda, residualRecoverySteps:=residualRecoverySteps)')
    method = replace(method,'tolerance, maxIterations - mIterations, half, halfLambda, originLambda:=acceptedLambda)',
        'tolerance, maxIterations + residualRecoverySteps - mIterations, half, halfLambda, originLambda:=acceptedLambda)')
    code = replace(code,original,method)
    accessor, = re.findall(r'(?ms)^Friend Sub CopyEquationResultantResidual\(.*?^End Sub',(source/'CCoupledNewtonSolver.cls').read_text('utf-8-sig'))
    code += '\n'+accessor+'\n'
    (output/'CCoupledNewtonSolver.cls').write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    print('POST-FAILURE CANDIDATE; ORIGINAL THREE METHODS, OPTIONAL EXPLICIT ADDITIONAL BUDGET; NO WORKING SOURCE CHANGE')


if __name__ == '__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    for name in ('source','output'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();TestBuild(args.repo.resolve(),args.source.resolve(),args.output.resolve())
