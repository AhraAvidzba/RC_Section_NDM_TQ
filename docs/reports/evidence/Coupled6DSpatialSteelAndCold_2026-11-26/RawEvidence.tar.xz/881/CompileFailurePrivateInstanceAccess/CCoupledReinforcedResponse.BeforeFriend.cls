﻿VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CCoupledReinforcedResponse"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ==========================================================================
' Материальный отклик бетона с направленной ненапрягаемой арматурой
' ==========================================================================
' Бетонный закон вычисляется также в точках замещённого объёма.
' В этих точках суммируется отклик стали и вычитается совпадающий
' отклик бетона. История закладывается для каждой точки интегрирования.

Implements ICoupledPointResponse

Private Const COMPONENT_COUNT As Long = 6
Private mConcrete As ICoupledPointResponse
Private mSteelPositive As CCoupledReinforcedResponse, mSteelNegative As CCoupledReinforcedResponse
Private mSteelHalfStep As Double
Private mSteel() As CCoupledSteelModel
Private mDirection() As Double
Private mPlastic() As Double, mBackstress() As Double
Private mAxialStress() As Double ' Фактическое продольное напряжение стали до вычитания замещённого бетона.
Private mFirstSteel As Long, mLastSteel As Long, mFirstTransverse As Long
Private mAcceptedBuffer As Long, mTrialBuffer As Long
Private mTrialSteelUtilization As Double
Private mAcceptedSteelUtilization As Double
Private mTrialSteelPoint As Long, mAcceptedSteelPoint As Long
Private mTrialTransversePoint As Long, mAcceptedTransversePoint As Long
Private mTrialTransverseUtilization As Double, mAcceptedTransverseUtilization As Double
Private mTrialLongitudinalUtilization As Double, mAcceptedLongitudinalUtilization As Double
Private mTrialLongitudinalPoint As Long, mAcceptedLongitudinalPoint As Long

' Передаёт масштаб координаты только для бетонного закона с подготовленными энергиями огибающих.
Friend Property Get EnvelopeReferenceStress() As Double
    If Not (TypeOf mConcrete Is CCoupledConcreteResponse) Then Exit Property
    Dim concrete As CCoupledConcreteResponse: Set concrete = mConcrete
    EnvelopeReferenceStress = concrete.EnvelopeReferenceStress
End Property

' Читает координату исходного бетона; вытесненный под сталью бетон не меняет правило бетонной квадратуры.
' Пробный буфер читает только владелец полностью проверенного кандидата.
Friend Function TryReadBufferedEnvelope(ByVal point As Long, ByVal accepted As Boolean, ByRef value As Double) As Boolean
    If Not (TypeOf mConcrete Is CCoupledConcreteResponse) Then Exit Function
    Dim concrete As CCoupledConcreteResponse: Set concrete = mConcrete
    TryReadBufferedEnvelope = concrete.TryReadBufferedEnvelope(point, accepted, value)
End Function

' Делегирует чтение пробной координаты исходному бетонному закону без записи истории бетона и стали.
Friend Function TryReadEnvelope(ByVal point As Long, ByRef strain() As Double, ByRef value As Double) As Boolean
    If Not (TypeOf mConcrete Is CCoupledConcreteResponse) Then Exit Function
    Dim concrete As CCoupledConcreteResponse: Set concrete = mConcrete
    TryReadEnvelope = concrete.TryReadEnvelope(point, strain, value)
End Function

' Один раз сопоставляет точкам их диаграммы и проекции.
' Models индексируется классом стали, указанным в сформированной геометрии.
Friend Sub Initialize(ByVal operators As CCoupledElasticState, ByVal concrete As ICoupledPointResponse, _
        ByVal models As Object)
    If operators Is Nothing Or concrete Is Nothing Then _
        Err.Raise 5, "CCoupledReinforcedResponse", "Для связанного отклика требуется подготовленное сечение и бетон."
    Set mConcrete = Nothing
    Set mSteelPositive = Nothing: Set mSteelNegative = Nothing: mSteelHalfStep = 0#
    Erase mSteel: Erase mDirection
    mFirstSteel = operators.ConcretePointCount + 1
    mLastSteel = operators.PointCount
    mFirstTransverse = mLastSteel + 1
    If mLastSteel >= mFirstSteel Then
        If models Is Nothing Then Err.Raise 5, "CCoupledReinforcedResponse", "Не подготовлены диаграммы стали."
        ReDim mSteel(mFirstSteel To mLastSteel)
        ReDim mDirection(1 To COMPONENT_COUNT, mFirstSteel To mLastSteel)
        Dim point As Long, j As Long, projection(1 To COMPONENT_COUNT) As Double, material As String
        For point = mFirstSteel To mLastSteel
            If mFirstTransverse > mLastSteel And operators.TransverseGroupAt(point) > 0 Then mFirstTransverse = point
            material = operators.SteelClassAt(point)
            If Not models.Exists(material) Then Err.Raise vbObjectError + 1781, "CCoupledReinforcedResponse", _
                "Для связанного расчёта нет параметров стали класса " & material & "."
            Set mSteel(point) = models.Item(material)
            operators.SteelProjection point, projection
            For j = 1 To COMPONENT_COUNT
                mDirection(j, point) = projection(j)
            Next j
        Next point
    End If
    Set mConcrete = concrete
    ICoupledPointResponse_ClearHistory
End Sub


' Подключает только читающий контроль двух независимых боковых историй.
' Принятие и сброс каждой истории остаются обязанностью владельца решателя.
Friend Sub AttachSteelStations(ByVal positive As CCoupledReinforcedResponse, _
        ByVal negative As CCoupledReinforcedResponse, ByVal halfStep As Double)
    If (positive Is Nothing) Xor (negative Is Nothing) Then Err.Raise 5, , "Для контроля стали требуются обе боковые станции."
    If Not positive Is Nothing Then
        If positive Is Me Or negative Is Me Or positive Is negative Or halfStep <= 0# Then _
            Err.Raise 5, , "Для контроля стали нужны независимые станции и положительный шаг."
    End If
    Set mSteelPositive = positive: Set mSteelNegative = negative: mSteelHalfStep = halfStep
End Sub

' Возвращает максимум заданной группы без повторного расчёта материала.
' При равенстве приоритет имеет центральная станция; csuNone означает всю сталь.
Friend Function ReadSteelLimit(ByVal accepted As Boolean, ByVal family As ECoupledSteelUncertainty, _
        ByRef point As Long, ByRef side As Long) As Double
    Dim localPoint As Long, ratio As Double, station As Long, response As CCoupledReinforcedResponse
    side = 0: point = 0
    ReadSteelLimit = LocalSteelLimit(accepted, family, point)
    For station = -1 To 1 Step 2
        Set response = SteelStation(station)
        If Not response Is Nothing Then
            ratio = response.LocalSteelLimit(accepted, family, localPoint)
            If localPoint <> 0 And (point = 0 Or ratio > ReadSteelLimit) Then
                ReadSteelLimit = ratio: point = localPoint: side = station
            End If
        End If
    Next station
End Function

' Читает только собственную станцию, исключая рекурсивное объединение историй.
Private Function LocalSteelLimit(ByVal accepted As Boolean, ByVal family As ECoupledSteelUncertainty, ByRef point As Long) As Double
    Select Case family
        Case csuNone
            If accepted Then
                LocalSteelLimit = mAcceptedSteelUtilization: point = mAcceptedSteelPoint
            Else
                LocalSteelLimit = mTrialSteelUtilization: point = mTrialSteelPoint
            End If
        Case csuLongitudinal
            If accepted Then
                LocalSteelLimit = mAcceptedLongitudinalUtilization: point = mAcceptedLongitudinalPoint
            Else
                LocalSteelLimit = mTrialLongitudinalUtilization: point = mTrialLongitudinalPoint
            End If
        Case csuTransverse
            If accepted Then
                LocalSteelLimit = mAcceptedTransverseUtilization: point = mAcceptedTransversePoint
            Else
                LocalSteelLimit = mTrialTransverseUtilization: point = mTrialTransversePoint
            End If
        Case Else: Err.Raise 5, , "Неизвестная группа контроля стали."
    End Select
End Function

' Возвращает материал выбранной станции; ноль соответствует центральной.
Private Function SteelStation(ByVal side As Long) As CCoupledReinforcedResponse
    Select Case side
        Case -1: Set SteelStation = mSteelNegative
        Case 0: Set SteelStation = Me
        Case 1: Set SteelStation = mSteelPositive
        Case Else: Err.Raise 5, , "Номер станции стали должен быть -1, 0 или 1."
    End Select
End Function

' Возвращает знаковое смещение станции в безразмерных продольных координатах.
Friend Function SteelStationOffset(ByVal side As Long) As Double
    If Abs(side) > 1 Or (side <> 0 And mSteelPositive Is Nothing) Then Err.Raise 5, , "Станция стали не подготовлена."
    SteelStationOffset = side * mSteelHalfStep
End Function

' Читает фактическое принятое напряжение именно выбранной станции.
Friend Function AcceptedStationSteelStress(ByVal point As Long, ByVal side As Long) As Double
    Dim response As CCoupledReinforcedResponse: Set response = SteelStation(side)
    If response Is Nothing Then Err.Raise 5, , "Боковая история стали не подготовлена."
    AcceptedStationSteelStress = response.AcceptedSteelStress(point)
End Function

' Показывает наличие продольной или поперечной арматуры в балансе сечения.
Friend Property Get HasSteel() As Boolean
    HasSteel = (mFirstSteel > 0 And mLastSteel >= mFirstSteel)
End Property

' Показывает максимальное отношение деформации к пределу на последнем
' полностью вычисленном пробном поле. Первый вызов точки сбрасывает максимум.
Friend Property Get TrialSteelUtilization() As Double
    Dim point As Long, side As Long, ratio As Double
    ratio = ReadSteelLimit(False, csuNone, point, side)
    TrialSteelUtilization = ratio
End Property

' Показывает максимум принятого состояния, не изменяемый отклонёнными пробами.
Friend Property Get AcceptedSteelUtilization() As Double
    Dim point As Long, side As Long, ratio As Double
    ratio = ReadSteelLimit(True, csuNone, point, side)
    AcceptedSteelUtilization = ratio
End Property

' Возвращает точку максимального использования на последней полной пробе.
Friend Property Get TrialSteelCriticalPoint() As Long
    Dim point As Long, side As Long, ratio As Double
    ratio = ReadSteelLimit(False, csuNone, point, side)
    TrialSteelCriticalPoint = point
End Property

' Возвращает станцию точки максимального использования последней полной пробы.
Friend Property Get TrialSteelCriticalSide() As Long
    Dim point As Long, ratio As Double
    ratio = ReadSteelLimit(False, csuNone, point, TrialSteelCriticalSide)
End Property

' Возвращает контрольную точку принятого состояния по всей арматуре.
Friend Property Get AcceptedSteelCriticalPoint() As Long
    Dim point As Long, side As Long, ratio As Double
    ratio = ReadSteelLimit(True, csuNone, point, side)
    AcceptedSteelCriticalPoint = point
End Property

' Возвращает точку максимального использования поперечной арматуры.
' При её отсутствии сохраняется нулевой индекс.
Friend Property Get AcceptedTransverseCriticalPoint() As Long
    Dim point As Long, side As Long, ratio As Double
    ratio = ReadSteelLimit(True, csuTransverse, point, side)
    AcceptedTransverseCriticalPoint = point
End Property

' Возвращает использование по деформации в принятой точке хомута или ветви.
Friend Property Get AcceptedTransverseSteelUtilization() As Double
    Dim point As Long, side As Long, ratio As Double
    ratio = ReadSteelLimit(True, csuTransverse, point, side)
    AcceptedTransverseSteelUtilization = ratio
End Property

' Возвращает максимальное использование отдельно по продольным стержням.
Friend Property Get AcceptedLongitudinalUtilization() As Double
    Dim point As Long, side As Long, ratio As Double
    ratio = ReadSteelLimit(True, csuLongitudinal, point, side)
    AcceptedLongitudinalUtilization = ratio
End Property

' Возвращает продольную контрольную точку отдельно от хомутов.
Friend Property Get AcceptedLongitudinalPoint() As Long
    Dim point As Long, side As Long, ratio As Double
    ratio = ReadSteelLimit(True, csuLongitudinal, point, side)
    AcceptedLongitudinalPoint = point
End Property

' Считывает принятое напряжение стержня материальной точки в МПа.
Friend Property Get AcceptedSteelStress(ByVal point As Long) As Double
    AcceptedSteelStress = mAxialStress(point, mAcceptedBuffer)
End Property

' Обновляет независимую материальную точку. В поправке замещения площадь
' берётся у геометрических операторов и здесь не учитывается повторно.
Private Function ICoupledPointResponse_EvaluatePoint(ByVal point As Long, ByRef strain() As Double, _
        ByRef stress() As Double, ByRef tangent() As Double, _
        Optional ByVal tangentMode As ECoupledTangentMode = ctmFull, _
        Optional ByVal recordTrial As Boolean = True) As ESolverFailureCode
    If (tangentMode = ctmFullBranchConsistent Or tangentMode = ctmRefinedBranchConsistent) And recordTrial Then
        ICoupledPointResponse_EvaluatePoint = sfcInvalidConfiguration
        Exit Function
    End If
    If point = 1 And recordTrial Then
        mTrialSteelUtilization = 0#: mTrialSteelPoint = 0
        mTrialTransverseUtilization = 0#: mTrialTransversePoint = 0
        mTrialLongitudinalUtilization = 0#: mTrialLongitudinalPoint = 0
    End If
    ICoupledPointResponse_EvaluatePoint = mConcrete.EvaluatePoint(point, strain, stress, tangent, tangentMode, recordTrial)
    If ICoupledPointResponse_EvaluatePoint <> sfcNone Or point < mFirstSteel Then Exit Function
    Dim j As Long, k As Long, axialStrain As Double, axialStress As Double, axialTangent As Double
    Dim utilization As Double, plastic As Double, backstress As Double
    ReadSteelTrial point, strain, axialStrain, axialStress, axialTangent, plastic, backstress
    If recordTrial Then
        mPlastic(point, mTrialBuffer) = plastic: mBackstress(point, mTrialBuffer) = backstress
        mAxialStress(point, mTrialBuffer) = axialStress
        utilization = mSteel(point).StrainUtilization(axialStrain)
        If utilization > mTrialSteelUtilization Then
            mTrialSteelUtilization = utilization: mTrialSteelPoint = point
        End If
        If point >= mFirstTransverse Then
            If utilization > mTrialTransverseUtilization Or mTrialTransversePoint = 0 Then
                mTrialTransverseUtilization = utilization: mTrialTransversePoint = point
            End If
        ElseIf utilization > mTrialLongitudinalUtilization Or mTrialLongitudinalPoint = 0 Then
            mTrialLongitudinalUtilization = utilization: mTrialLongitudinalPoint = point
        End If
    End If
    For j = 1 To COMPONENT_COUNT
        stress(j) = axialStress * mDirection(j, point) - stress(j)
        If tangentMode <> ctmStressOnly Then
            For k = 1 To COMPONENT_COUNT
                If tangentMode <> ctmAxialGradient Or k = 3 Or k >= 5 Then _
                    tangent(j, k) = axialTangent * mDirection(j, point) * mDirection(k, point) - tangent(j, k)
            Next k
        End If
    Next j
End Function

' Считывает только бетонный вклад, включая знак вытеснения под стержнем.
' Используется для разностной касательной от фиксированной принятой истории.
Friend Function ReadConcreteStress(ByVal point As Long, ByRef strain() As Double, ByRef stress() As Double) As ESolverFailureCode
    Dim unusedTangent(1 To COMPONENT_COUNT, 1 To COMPONENT_COUNT) As Double, i As Long
    ReadConcreteStress = mConcrete.EvaluatePoint(point, strain, stress, unusedTangent, ctmStressOnly, recordTrial:=False)
    If ReadConcreteStress <> sfcNone Or point < mFirstSteel Then Exit Function
    For i = 1 To COMPONENT_COUNT: stress(i) = -stress(i): Next i
End Function

' Считывает осевой отклик стали от принятого буфера без записи пробы.
' Номер ветви равен знаку пластического приращения, ноль означает упругую ветвь.
Friend Function ReadSteelBranch(ByVal point As Long, ByRef strain() As Double, ByRef axialStrain As Double, _
        ByRef axialStress As Double, ByRef axialTangent As Double) As Long
    Dim plastic As Double, backstress As Double
    ReadSteelTrial point, strain, axialStrain, axialStress, axialTangent, plastic, backstress
    ReadSteelBranch = Sgn(plastic - mPlastic(point, mAcceptedBuffer))
End Function

' Вычисляет скалярную пробу для полного отклика и для поправки касательной.
Private Sub ReadSteelTrial(ByVal point As Long, ByRef strain() As Double, ByRef axialStrain As Double, _
        ByRef axialStress As Double, ByRef axialTangent As Double, ByRef plastic As Double, ByRef backstress As Double)
    Dim i As Long
    axialStrain = 0#
    For i = 1 To COMPONENT_COUNT
        axialStrain = axialStrain + mDirection(i, point) * strain(i)
    Next i
    mSteel(point).EvaluateTrial axialStrain, mPlastic(point, mAcceptedBuffer), mBackstress(point, mAcceptedBuffer), _
        axialStress, axialTangent, plastic, backstress
End Sub

' Читает пробный критерий вытесненного или обычного бетона.
' Коэффициенты знака замещения учитываются в уравнениях, а не здесь.
Friend Function TryReadTrialYield(ByVal point As Long, ByRef strain() As Double, ByRef value As Double, _
        ByRef gradient() As Double, Optional ByVal needGradient As Boolean = True) As Boolean
    If Not TypeOf mConcrete Is CCoupledConcreteResponse Then Exit Function
    Dim concrete As CCoupledConcreteResponse: Set concrete = mConcrete
    TryReadTrialYield = concrete.TryReadTrialYield(point, strain, value, gradient, needGradient)
End Function

' Передаёт наличие спектральных знаковых границ у бетонной составляющей.
Friend Property Get HasPrincipalBoundaries() As Boolean
    If Not TypeOf mConcrete Is CCoupledConcreteResponse Then Exit Property
    Dim concrete As CCoupledConcreteResponse: Set concrete = mConcrete
    HasPrincipalBoundaries = concrete.HasPrincipalBoundaries
End Property

' Читает знаковую границу ASD бетонной составляющей, включая вытесненный бетон стержня.
Friend Function TryReadPrincipalBoundary(ByVal point As Long, ByRef strain() As Double, ByVal principalIndex As Long, _
        ByRef value As Double, ByRef gradient() As Double, Optional ByVal needGradient As Boolean = True) As Boolean
    If Not TypeOf mConcrete Is CCoupledConcreteResponse Then Exit Function
    Dim concrete As CCoupledConcreteResponse: Set concrete = mConcrete
    TryReadPrincipalBoundary = concrete.TryReadPrincipalBoundary(point, strain, principalIndex, value, gradient, needGradient)
End Function

' Читает фактическую ветвь бетонной составляющей от принятой истории
' без записи отклика бетона или стали в пробные буферы.
Friend Function TryReadConcreteBranch(ByVal point As Long, ByRef strain() As Double, _
        ByRef plasticIncrement As Boolean, ByRef principalSign As Long, ByRef substeps As Long) As Boolean
    If Not TypeOf mConcrete Is CCoupledConcreteResponse Then Exit Function
    Dim concrete As CCoupledConcreteResponse: Set concrete = mConcrete
    TryReadConcreteBranch = concrete.TryReadConcreteBranch(point, strain, plasticIncrement, principalSign, substeps)
End Function

' Публикует новый буфер после принятия бетонных проб, без копирования массивов.
Private Sub ICoupledPointResponse_AcceptTrial()
    mConcrete.AcceptTrial
    mAcceptedBuffer = mTrialBuffer
    mTrialBuffer = 3 - mAcceptedBuffer
    mAcceptedSteelUtilization = mTrialSteelUtilization
    mAcceptedLongitudinalUtilization = mTrialLongitudinalUtilization: mAcceptedLongitudinalPoint = mTrialLongitudinalPoint
    mAcceptedSteelPoint = mTrialSteelPoint
    mAcceptedTransversePoint = mTrialTransversePoint
    mAcceptedTransverseUtilization = mTrialTransverseUtilization
End Sub

' Удаляет историю независимого сочетания в обоих материалах.
Private Sub ICoupledPointResponse_ClearHistory()
    mConcrete.ClearHistory
    mAcceptedBuffer = 1: mTrialBuffer = 2
    mTrialSteelUtilization = 0#: mAcceptedSteelUtilization = 0#
    mTrialLongitudinalUtilization = 0#: mAcceptedLongitudinalUtilization = 0#
    mTrialLongitudinalPoint = 0: mAcceptedLongitudinalPoint = 0
    mTrialSteelPoint = 0: mAcceptedSteelPoint = 0
    mTrialTransversePoint = 0: mAcceptedTransversePoint = 0
    mTrialTransverseUtilization = 0#: mAcceptedTransverseUtilization = 0#
    Erase mPlastic: Erase mBackstress: Erase mAxialStress
    If mLastSteel >= mFirstSteel Then
        ReDim mPlastic(mFirstSteel To mLastSteel, 1 To 2)
        ReDim mBackstress(mFirstSteel To mLastSteel, 1 To 2)
        ReDim mAxialStress(mFirstSteel To mLastSteel, 1 To 2)
    End If
End Sub

' Ищет знаковый предел внутри линейной оценки поправки поля. Оценка
' применяется только для запуска уточнения на той же материальной истории.
Friend Function SteelBoundaryWithinCorrection(ByVal operators As CCoupledElasticState, ByRef field() As Double, _
        ByRef correction() As Double, ByRef governingPoint As Long, ByRef unresolved As ECoupledSteelUncertainty, _
        Optional ByRef governingSide As Long = 0) As Boolean
    Dim family As Long, side As Long, candidate As Long, chosen As Long, chosenSide As Long
    Dim response As CCoupledReinforcedResponse, localUnresolved As ECoupledSteelUncertainty
    Dim exceeded As Boolean, familyExceeded As Boolean, group As ECoupledSteelUncertainty
    governingPoint = 0: governingSide = 0: unresolved = csuNone
    For family = 0 To 1
        chosen = 0: chosenSide = 0: familyExceeded = False
        For side = -1 To 1
            Set response = SteelStation(side)
            If Not response Is Nothing Then
                exceeded = False: candidate = 0
                If response.LocalSteelBoundaryWithinCorrection(operators, field, correction, candidate, localUnresolved, _
                        family, side * mSteelHalfStep, exceeded) Then
                    If chosen = 0 Or side = 0 Then chosen = candidate: chosenSide = side
                End If
                familyExceeded = familyExceeded Or exceeded
            End If
        Next side
        If chosen <> 0 And Not familyExceeded Then
            group = csuLongitudinal
            If family = 1 Then group = csuTransverse
            unresolved = unresolved Or group
            If governingPoint = 0 Then governingPoint = chosen: governingSide = chosenSide
        End If
    Next family
    SteelBoundaryWithinCorrection = (governingPoint <> 0)
End Function

' Проверяет одну станцию и одну группу; подтверждённое превышение группы
' исключает неопределённость от других точек той же группы.
Private Function LocalSteelBoundaryWithinCorrection(ByVal operators As CCoupledElasticState, ByRef field() As Double, _
        ByRef correction() As Double, ByRef governingPoint As Long, ByRef unresolved As ECoupledSteelUncertainty, ByVal selectedFamily As Long, ByVal offset As Double, ByRef definitelyExceeded As Boolean) As Boolean
    Const ROUNDING_STEP As Double = 2.22044604925031E-16
    Dim point As Long, degree As Long, strain As Double, limit As Double, otherLimit As Double, margin As Double
    Dim projection() As Double, movement As Double, arithmeticScale As Double
    Dim family As Long, best(0 To 1) As Double, candidates(0 To 1) As Long, exceeded(0 To 1) As Boolean
    governingPoint = 0
    For point = mFirstSteel To mLastSteel
        family = 0
        If point >= mFirstTransverse Then family = 1
        If family <> selectedFamily Then GoTo NextSteelPoint
        ReadSteelStrain operators, point, field, strain, limit, offset
        operators.CopySteelStrainProjection point, projection, offset
        movement = 0#: arithmeticScale = Abs(limit)
        For degree = 1 To UBound(projection)
            movement = movement + Abs(projection(degree) * correction(degree))
            arithmeticScale = arithmeticScale + Abs(projection(degree) * field(degree))
        Next degree
        otherLimit = mSteel(point).SignedStrainLimit(-limit)
        margin = Abs(strain - limit)
        If Abs(strain - otherLimit) < margin Then
            limit = otherLimit: margin = Abs(strain - limit)
            arithmeticScale = arithmeticScale + Abs(limit)
        End If
        ' Две геометрические компоненты на координату и шесть проекций оси.
        If margin <= movement + (4# * UBound(projection) + 12#) * ROUNDING_STEP * arithmeticScale Then
            margin = margin / Abs(limit)
            If candidates(family) = 0 Or margin < best(family) Then
                candidates(family) = point: best(family) = margin
            End If
        ElseIf mSteel(point).StrainUtilization(strain) > 1# Then
            exceeded(family) = True ' Дополнительная точка не меняет уже подтверждённый статус этой группы.
        End If
NextSteelPoint:
    Next point
    definitelyExceeded = exceeded(selectedFamily)
    unresolved = csuNone
    If Not exceeded(0) And candidates(0) <> 0 Then
        unresolved = csuLongitudinal: governingPoint = candidates(0)
    End If
    If Not exceeded(1) And candidates(1) <> 0 Then
        unresolved = unresolved Or csuTransverse
        If governingPoint = 0 Then governingPoint = candidates(1)
    End If
    LocalSteelBoundaryWithinCorrection = (governingPoint <> 0)
End Function

' Меняет одну координату поля по наиболее чувствительному коэффициенту
' проекции. Полученное поле требует отдельной проверки равновесия и стали.
Friend Function ProjectSteelBoundary(ByVal operators As CCoupledElasticState, ByVal point As Long, _
        ByRef field() As Double, Optional ByVal side As Long = 0) As Boolean
    Dim offset As Double: offset = SteelStationOffset(side)
    Dim strain As Double, limit As Double, projection() As Double
    ReadSteelStrain operators, point, field, strain, limit, offset
    operators.CopySteelStrainProjection point, projection, offset
    Dim i As Long, chosen As Long, maximum As Double
    For i = 1 To UBound(projection)
        If Abs(projection(i)) > maximum Then
            maximum = Abs(projection(i)): chosen = i
        End If
    Next i
    If chosen = 0 Then Exit Function
    field(chosen) = field(chosen) + (limit - strain) / projection(chosen)
    ReadSteelStrain operators, point, field, strain, limit, offset
    ProjectSteelBoundary = (strain = limit)
End Function

' Считывает деформацию и предел её знака тем же порядком вычислений,
' который используется для материальной точки стали.
Private Sub ReadSteelStrain(ByVal operators As CCoupledElasticState, ByVal point As Long, _
        ByRef field() As Double, ByRef strain As Double, ByRef limit As Double, Optional ByVal offset As Double = 0#)
    Dim tensor(1 To COMPONENT_COUNT) As Double, i As Long
    operators.PointStrain point, field, tensor
    If offset <> 0# Then
        Dim gradient(1 To COMPONENT_COUNT) As Double
        operators.AxialGradientAtPoint point, field, gradient
        For i = 1 To COMPONENT_COUNT: tensor(i) = tensor(i) + offset * gradient(i): Next i
    End If
    strain = 0#
    For i = 1 To COMPONENT_COUNT
        strain = strain + mDirection(i, point) * tensor(i)
    Next i
    limit = mSteel(point).SignedStrainLimit(strain)
End Sub

' Возвращает группы заданной арматуры. При отсутствии подтверждённой
' чувствительности каждая фактически заданная группа требует уточнения.
Friend Property Get PresentSteelCriteria() As ECoupledSteelUncertainty
    If Not HasSteel Then Exit Property
    Dim groups As ECoupledSteelUncertainty
    If mFirstSteel < mFirstTransverse Then groups = csuLongitudinal
    If mFirstTransverse <= mLastSteel Then groups = groups Or csuTransverse
    PresentSteelCriteria = groups
End Property

' Выбирает стержень с наибольшим относительным ростом модуля деформации между двумя принятыми полями.
' Читает только кинематику и заданный предел материала; не вычисляет напряжения и не меняет принятую историю.
Friend Function TrySelectIncreasingSteelStrain(ByVal operators As CCoupledElasticState, _
        ByRef previous() As Double, ByRef current() As Double, ByRef projection() As Double, _
        ByRef coordinate As Double, ByRef spacing As Double, ByRef signedLimit As Double, _
        ByRef governingPoint As Long, ByRef transverse As Boolean) As Boolean
    If Not HasSteel Then Exit Function
    If operators Is Nothing Then Err.Raise 5, "CCoupledReinforcedResponse", "Подготовьте операторы деформации арматуры."
    If LBound(previous) <> 1 Or LBound(current) <> 1 Or UBound(previous) <> operators.DegreeCount Or _
            UBound(current) <> operators.DegreeCount Then Err.Raise 5, "CCoupledReinforcedResponse", "Поля управления арматурой не соответствуют подготовленному сечению."
    Dim point As Long, strain As Double, before As Double, limit As Double, previousLimit As Double
    Dim movement As Double, rate As Double, best As Double, direction As Double, degree As Long
    governingPoint = 0: coordinate = 0#: spacing = 0#: signedLimit = 0#: transverse = False
    For point = mFirstSteel To mLastSteel
        ReadSteelStrain operators, point, previous, before, previousLimit
        ReadSteelStrain operators, point, current, strain, limit
        movement = strain - before
        If movement * strain > 0# And Abs(limit) > Abs(strain) Then
            rate = Abs(movement) / Abs(limit) ' Рост нормируется собственным пределом этого класса стали, а не общим модулем для всех стержней.
            If rate > best Then
                best = rate: governingPoint = point
                direction = Sgn(movement): coordinate = direction * strain: spacing = Abs(movement)
                signedLimit = direction * limit: transverse = (point >= mFirstTransverse)
            End If
        End If
    Next point
    If governingPoint = 0 Then Exit Function
    operators.CopySteelStrainProjection governingPoint, projection
    For degree = 1 To UBound(projection): projection(degree) = direction * projection(degree): Next degree
    TrySelectIncreasingSteelStrain = True
End Function

' Передаёт упругую знаковую границу CDP бетонной составляющей; усилия стали и вытеснение бетона здесь не меняются.
Friend Function TryReadElasticPrincipalBoundary(ByVal point As Long, ByRef strain() As Double, ByVal principalIndex As Long, _
        ByRef value As Double, ByRef gradient() As Double, Optional ByVal needGradient As Boolean = True) As Boolean
    If Not TypeOf mConcrete Is CCoupledConcreteResponse Then Exit Function
    Dim concrete As CCoupledConcreteResponse: Set concrete = mConcrete
    TryReadElasticPrincipalBoundary = concrete.TryReadElasticPrincipalBoundary(point, strain, principalIndex, value, gradient, needGradient)
End Function
