"""Собирает и проверяет воспроизводимый пакет нативных доказательств без рабочих книг."""

from hashlib import file_digest
import json
from pathlib import Path
from shutil import copyfile
from subprocess import run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from StockInputs import compare


HERE = Path(__file__).resolve().parent
BUILD = HERE.parent / "tpbuild3"
EXPERIMENT = HERE.parent / "tp"
DEPOT = Path("D:/CodexScratch/RC_Section_NDM_TQ")
NATIVE = DEPOT / "PlanarTorsionNativeD"
REJECTED = DEPOT / "PlanarTorsionNativeC"
BASE = EXPERIMENT / "workbook/output/RC_Section_NDM.xlsm"
HISTORICAL_EXPORT = EXPERIMENT / "workbook/output/VBA_All_Code.txt"
BOOK = BUILD / "RC_Section_NDM_Torsion.xlsm"
EXPORT = BUILD / "VBA_All_Code.txt"
DIAGNOSTIC = NATIVE / "docs/regression/Diagnostic.xlsm"
OUT = HERE / "PlanarTorsionExperimentNative20261117.zip"
TAGS = ("Rectangles-T0", "Rectangles-PureT", "Rectangles-Mixed", "Rectangles-HoopFail",
        "Circle-T0", "Circle-PureT", "Circle-Mixed")
CASE_ARTIFACTS = ("Diagrams.tsv", "Fields.tsv", "Geometry.tsv", "Torsion.tsv", "TorsionSteel.tsv",
                  "RC_Section_NDM_execution_report.txt", "Receipt.json", "txt", "txt.memory.json",
                  "txt.Ownership.json", "txt.ProcessClosure.json", "txt.RunnerCleanup.json",
                  "txt.stderr.log", "txt.stdout.log")


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest().upper()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")


def files():
    for name in ("README-Archive.md", "Pack-Archive.py", "Verify-Archive.py", "StockInputs.py"):
        yield HERE / name, name
    for name in ("Build.ps1", "BuildReceipt.json", "Inputs.json", "SourceAgreement.json", "Freeze.py", "VerifySource.py"):
        yield BUILD / name, "Build/" + name
    parser = "hs-s2/Verify-ExportDifference.py"
    yield HERE.parent / parser, parser
    for name in ("Preparation.json", "Run.ps1", "Run.ndjson", "Guard-IsolatedOffice.ps1", "Compile.log", "CompileClosure.json",
                 "tests/modTestPlanarTorsionWorkbook.bas"):
        yield NATIVE / name, name
    yield NATIVE / "Verification.json", "NativeVerification.json"
    yield NATIVE / "Verify.py", "NativeVerify.py"
    yield NATIVE / "docs/regression/CodeUpdate.json", "CodeUpdate.json"
    for case in TAGS:
        for kind in CASE_ARTIFACTS:
            name = f"Native/{case}.{kind}"
            yield NATIVE / name, name
    yield HERE.parent / "tpbuild2/BuildReceipt.json", "Rejected22EA/BuildReceipt.json"
    yield REJECTED / "docs/regression/CodeUpdate.json", "Rejected22EA/CodeUpdate.json"
    for name in ("Rectangles-PureT.txt", "Rectangles-PureT.txt.Ownership.json", "Rectangles-PureT.txt.ProcessClosure.json",
                 "Rectangles-PureT.Torsion.tsv"):
        yield REJECTED / "Native" / name, "Rejected22EA/" + name


def run_verification(directory, extra=()):
    step = run([sys.executable, "-B", "-X", "utf8", str(directory / "Verify-Archive.py"), *map(str, extra)],
               cwd=directory, capture_output=True, encoding="utf-8")
    if step.returncode:
        raise RuntimeError(step.stderr)
    return step.stdout


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    with TemporaryDirectory(prefix="packed-", dir=HERE) as stage, TemporaryDirectory(prefix="detached-", dir=HERE) as extracted:
        directory, detached = Path(stage), Path(extracted)
        for source, target in files():
            dst = directory / target
            dst.parent.mkdir(parents=True, exist_ok=True)
            copyfile(source, dst)
        write_json(directory / "StockInputVerification.json", {"historical_workbook_sha256": digest(BASE),
                   "built_workbook_sha256": digest(BOOK), "comparison": compare(BASE, BOOK)})
        members = sorted(path.relative_to(directory).as_posix() for path in directory.rglob("*") if path.is_file())
        write_json(directory / "SHA256SUMS.json", {name: digest(directory / name) for name in members})
        exact = run_verification(directory, ("--built-workbook", BOOK, "--historical-workbook", BASE,
                                "--diagnostic-workbook", DIAGNOSTIC, "--vba-export", EXPORT,
                                "--historical-export", HISTORICAL_EXPORT, "--source-tree", EXPERIMENT))
        tentative = directory / OUT.name
        with ZipFile(tentative, "x", compression=ZIP_DEFLATED, compresslevel=9) as archive:
            for name in sorted([*members, "SHA256SUMS.json"]):
                part = ZipInfo(name, (2026, 11, 17, 0, 0, 0))
                part.external_attr = 0o100644 << 16
                archive.writestr(part, (directory / name).read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(tentative) as archive:
            assert archive.testzip() is None and len(set(archive.namelist())) == len(archive.namelist())
            archive.extractall(detached)
        replay = run_verification(detached)
        assert replay == exact
        tentative.replace(OUT)
    checksum = digest(OUT)
    OUT.with_suffix(".zip.sha256").write_text(f"{checksum}  {OUT.name}\n", encoding="ascii")
    OUT.with_suffix(".replay.txt").write_text(replay, encoding="utf-8", newline="\n")
    print(replay, end="")
    print(f"{OUT.name} {OUT.stat().st_size} bytes SHA-256 {checksum}")


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    main()
