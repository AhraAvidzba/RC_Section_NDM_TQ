Attribute VB_Name = "modTestPlanarTorsionWorkbook"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет ввод и штатный расчёт экспериментальной книги на копии Excel.
' Время формирования и расчёта измеряется отдельно, отчёт читает Results.

Private Const TEST_LC As String = "TP-FIXTURE"

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запускает одно сочетание. Повторное открытие ведёт внешний runner.
Public Function RunTestPlanarTorsionWorkbook(ByVal loadCase As String, ByVal geometryType As String) As String
    Dim report As String, phase As String
    On Error GoTo FailedRun
    Dim book As Object: Set book = ThisWorkbook
    If Not book.ReadOnly Or InStr(1, book.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Нужна изолированная книга только для чтения."
    phase = "Setup"
    Dim loads As Variant, hoopResistance As Double
    hoopResistance = 240#
    Select Case loadCase
        Case "T0": loads = Array(-40000#, 3000000#, -1500000#, 0#)
        Case "PureT": loads = Array(0#, 0#, 0#, 1500000#)
        Case "Mixed": loads = Array(-40000#, 3000000#, -1500000#, 1500000#)
        Case "HoopFail"
            If geometryType <> "Rectangles" Then Err.Raise 5, , "Контроль хомута проводится на прямоугольнике."
            loads = Array(0#, 0#, 0#, 1500000#): hoopResistance = 12#
        Case Else: Err.Raise 5, , "Неизвестное контрольное сочетание."
    End Select
    report = "TP_CASE: " & geometryType & "|" & loadCase & vbCrLf
    report = report & "TP_INTERNAL_N_NMM: " & TestWire(loads(0)) & "|" & TestWire(loads(1)) & _
        "|" & TestWire(loads(2)) & "|" & TestWire(loads(3)) & vbCrLf
    report = report & "TP_ABSOLUTE_TOL: " & TestWorkbookInputs(book, geometryType, loads, hoopResistance) & vbCrLf
    Dim startTime As Double, elapsed As Double, message As String, attention As Boolean
    phase = "Formation"
    startTime = Timer
    message = FormSectionForWorkbook(book, requiresAttention:=attention)
    elapsed = TestElapsed(startTime)
    report = report & "TP_FORM: " & TestWire(elapsed) & "|" & TestWire(message) & vbCrLf
    report = report & "TP_FORM_ATTENTION: " & CStr(attention) & vbCrLf

    phase = "Calculation"
    startTime = Timer
    message = RunSectionCalculationForWorkbook(book, requiresAttention:=attention)
    elapsed = TestElapsed(startTime)
    report = report & "TP_CALC: " & TestWire(elapsed) & "|" & TestWire(message) & vbCrLf
    report = report & "TP_ATTENTION: " & CStr(attention) & vbCrLf

    phase = "Results"
    Dim data As Variant: data = ReadAnchoredResultTable(book, "rngNDMSectionProperties")
    Dim lcColumn As Long, nameColumn As Long, valueColumn As Long, unitColumn As Long
    lcColumn = ResultColumn(data, "LoadCase"): nameColumn = ResultColumn(data, "Parameter")
    valueColumn = ResultColumn(data, "Value"): unitColumn = ResultColumn(data, "Unit")
    Dim rowIndex As Long, count As Long, key As String, propertyName As String
    For rowIndex = 2 To UBound(data, 1)
        key = CStr(data(rowIndex, lcColumn)): propertyName = CStr(data(rowIndex, nameColumn))
        If key = TEST_LC Or (key = "ALL" And TestSharedProperty(propertyName)) Then
            report = report & "TP_PROPERTY: " & key & "|" & propertyName & "|" & _
                TestWire(data(rowIndex, valueColumn)) & "|" & TestWire(data(rowIndex, unitColumn)) & vbCrLf
            count = count + 1
        End If
    Next rowIndex
    If count = 0 Then Err.Raise 5, , "Свойства расчёта отсутствуют в Results."
    TestDumpMatrix book, "rngNDMSectionGeometry", "Geometry.tsv"
    TestDumpMatrix book, "rngNDMElementResults", "Fields.tsv"
    TestDumpMatrix book, "rngNDMMaterialDiagrams", "Diagrams.tsv"
    TestDumpTorsion book, "rngPlanarTorsionSummary", 9, "Torsion.tsv"
    TestDumpTorsion book, "rngPlanarTorsionSteel", 5, "TorsionSteel.tsv"
    RunTestPlanarTorsionWorkbook = report & "TOTAL_PLANAR_TORSION_EXCEL: passed=1; failed=0"
    Exit Function
FailedRun:
    RunTestPlanarTorsionWorkbook = report & "RUNTIME ERROR: " & phase & " " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Настраивает один профиль PR4 и геометрию через диапазоны обычного Excel.
Private Function TestWorkbookInputs(ByVal book As Object, ByVal geometryType As String, ByVal loads As Variant, _
        ByVal hoopResistance As Double) As String
    TestSetSetting book, "Geometry.Source", "Generated"
    TestSetSetting book, "Geometry.Type", geometryType
    TestSetSetting book, "Results.SnapshotStorage", "Excel"
    TestSetSetting book, "General.ExecutionReportEnabled", "Yes"
    TestSetSetting book, "Load.ReferenceOffsetX", 0#
    TestSetSetting book, "Load.ReferenceOffsetY", 0#
    TestSetSetting book, "Calculation.ZeroMomentPerDepth", 0#
    TestSetSetting book, "Output.CombinationMode", "Worst"
    TestSetSetting book, "Plot.Enabled", "Yes"
    TestSetSetting book, "Plot.AutoUpdateAfterCalculation", "Yes"
    TestSetSetting book, "Mesh.StepMode", "Auto 0.1"
    TestSetSetting book, "Mesh.CellGeometry", "Contour"
    Dim config As New CSystemSettingsReader, units As New CUnitSystem
    config.LoadFromWorkbook book: units.LoadFromSettings config
    Dim lengthFactor As Double: lengthFactor = units.InputLengthToInternal(1#)
    Dim geometry As Object: Set geometry = book.Names("rng" & geometryType & "Geometry").RefersToRange
    Dim rowKey As Variant
    Select Case geometryType
        Case "Rectangles"
            TestFixtureInputCell(geometry, "General", "B1").Value2 = 300# / lengthFactor
            TestFixtureInputCell(geometry, "General", "H1").Value2 = 400# / lengthFactor
            TestFixtureInputCell(geometry, "General", "B2").Value2 = 0#
            TestFixtureInputCell(geometry, "General", "H2").Value2 = 0#
            TestFixtureInputCell(geometry, "General", "R").Value2 = 0#
            For Each rowKey In Array("R1.Top", "R1.Bottom", "R1.Left", "R1.Right")
                TestSetBarRow geometry, CStr(rowKey), 2, 55#, lengthFactor
            Next rowKey
        Case "Circle"
            TestFixtureInputCell(geometry, "General", "D").Value2 = 400# / lengthFactor
            TestSetBarRow geometry, "Circle", 8, 0#, lengthFactor, "IncludeStart"
        Case Else: Err.Raise 5, , "Неизвестное контрольное сечение."
    End Select

    Dim hoop As Object: Set hoop = book.Names("rngPlanarTorsionHoop").RefersToRange
    If hoop.Rows.Count <> 5 Or hoop.Columns.Count <> 2 Then Err.Raise 5, , "Неверный размер диапазона хомута."
    Dim values As Variant, rowIndex As Long, hoopKeys As Variant
    hoopKeys = Array("Diameter", "Spacing", "Cover", "Rsw")
    values = Array(8# / lengthFactor, 100# / lengthFactor, 25# / lengthFactor, hoopResistance / units.InputStressToInternal(1#))
    For rowIndex = 0 To 3
        If StrComp(CStr(hoop.Cells(rowIndex + 2, 1).Value2), hoopKeys(rowIndex), vbBinaryCompare) <> 0 Then _
            Err.Raise 5, , "Неверный ключ: " & hoopKeys(rowIndex)
        hoop.Cells(rowIndex + 2, 2).Value2 = values(rowIndex)
    Next rowIndex

    Dim combinations As Object: Set combinations = book.Names("rngLoadCombinations").RefersToRange
    If combinations.Columns.Count <> 8 Or combinations.Rows.Count < 2 Then Err.Raise 5, , "Неверный размер таблицы сочетаний."
    If StrComp(CStr(combinations.Cells(1, 8).Value2), "T", vbBinaryCompare) <> 0 Then Err.Raise 5, , "Не прочитан точный заголовок T."
    combinations.Offset(1, 0).Resize(combinations.Rows.Count - 1, combinations.Columns.Count).ClearContents
    combinations.Cells(2, 1).Value2 = TEST_LC
    combinations.Cells(2, 2).Value2 = CDbl(loads(0)) / units.InputForceToInternal(1#)
    combinations.Cells(2, 3).Value2 = CDbl(loads(1)) / units.InputMomentMxToInternal(1#)
    combinations.Cells(2, 4).Value2 = CDbl(loads(2)) / units.InputMomentMyToInternal(1#)
    combinations.Cells(2, 5).Value2 = "PR4"
    combinations.Cells(2, 6).Value2 = "Auto"
    combinations.Cells(2, 8).Value2 = CDbl(loads(3)) / units.InputTorqueToInternal(1#)
    TestWorkbookInputs = TestWire(Abs(units.InputForceToInternal(config.GetDouble("Solver.ToleranceN", 5#, False)))) & "|" & _
        TestWire(Abs(units.InputMomentMxToInternal(config.GetDouble("Solver.ToleranceMx", 5000#, False)))) & "|" & _
        TestWire(Abs(units.InputMomentMyToInternal(config.GetDouble("Solver.ToleranceMy", 5000#, False))))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Разносит стержни по уникальным станциям оси вдали от углов контура.
Private Sub TestSetBarRow(ByVal table As Object, ByVal rowKey As String, ByVal numberOfBars As Long, _
        ByVal setback As Double, ByVal lengthFactor As Double, Optional ByVal endMode As String = "IncludeBoth")
    TestFixtureInputCell(table, "Main", rowKey, "as").Value2 = 43# / lengthFactor
    TestFixtureInputCell(table, "Main", rowKey, "d").Value2 = 16# / lengthFactor
    TestFixtureInputCell(table, "Main", rowKey, "n").Value2 = numberOfBars
    TestFixtureInputCell(table, "Main", rowKey, "s0").Value2 = setback / lengthFactor
    TestFixtureInputCell(table, "Main", rowKey, "s1").Value2 = setback / lengthFactor
    TestFixtureInputCell(table, "Main", rowKey, "endMode").Value2 = endMode
    TestFixtureInputCell(table, "Extra", rowKey, "d2").ClearContents
    TestFixtureInputCell(table, "Extra", rowKey, "d3").ClearContents
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Устанавливает только явно заданный параметр таблицы Config.
Private Sub TestSetSetting(ByVal book As Object, ByVal key As String, ByVal value As Variant)
    Dim settings As Object: Set settings = book.Names("rngSystemSettings").RefersToRange
    Dim rowIndex As Long
    For rowIndex = 2 To settings.Rows.Count
        If CStr(settings.Cells(rowIndex, 1).Value2) = key Then
            settings.Cells(rowIndex, 2).Value2 = value
            Exit Sub
        End If
    Next rowIndex
    Err.Raise 5, , "Не найдена настройка " & key
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выбирает размеры модели и единицы для независимого чтения отчёта.
Private Function TestSharedProperty(ByVal key As String) As Boolean
    TestSharedProperty = key = "RebarCount" Or key = "ConcreteCount" Or _
        Left$(key, 7) = "Output." Or Left$(key, 9) = "Geometry." Or _
        Left$(key, 9) = "Concrete." Or Left$(key, 13) = "LoadReference"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет фактические значения Results для независимого суммирования усилий.
Private Sub TestDumpMatrix(ByVal book As Object, ByVal tableName As String, ByVal fileName As String)
    Dim data As Variant: data = ReadAnchoredResultTable(book, tableName)
    TestDumpValues book.Path & "\" & fileName, data
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Диапазон Owned определяет реально записанное тело под двумя строками шапки.
Private Sub TestDumpTorsion(ByVal book As Object, ByVal tableName As String, ByVal width As Long, ByVal fileName As String)
    Dim anchor As Object: Set anchor = book.Names(tableName).RefersToRange
    Dim owned As Object, dataRows As Long, data As Variant
    On Error Resume Next
    Set owned = book.Names(tableName & "Owned").RefersToRange
    On Error GoTo 0
    If Not owned Is Nothing Then
        If owned.Column <> anchor.Column Or owned.Row <> anchor.Row + 2 Or owned.Columns.Count <> width Then _
            Err.Raise 5, , "Область результата не совпадает с якорем " & tableName
        dataRows = owned.Rows.Count
    End If
    data = anchor.Offset(1, 0).Resize(1 + dataRows, width).Value2
    TestDumpValues book.Path & "\" & fileName, data
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сериализует массив ячеек в табличную форму с машиночитаемыми числами.
Private Sub TestDumpValues(ByVal path As String, ByRef data As Variant)
    Dim rowIndex As Long, columnIndex As Long, outputFile As Object, line As String
    Set outputFile = CreateObject("Scripting.FileSystemObject").CreateTextFile(path, False, True)
    For rowIndex = LBound(data, 1) To UBound(data, 1)
        line = vbNullString
        For columnIndex = LBound(data, 2) To UBound(data, 2)
            If columnIndex > LBound(data, 2) Then line = line & vbTab
            line = line & Replace(TestWire(data(rowIndex, columnIndex)), vbTab, " ")
        Next columnIndex
        outputFile.WriteLine line
    Next rowIndex
    outputFile.Close
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает числа с десятичной точкой и защищает разделители строки.
Private Function TestWire(ByVal value As Variant) As String
    Select Case VarType(value)
        Case vbEmpty, vbNull: TestWire = vbNullString
        Case vbDouble, vbSingle, vbLong, vbInteger, vbCurrency: TestWire = Trim$(Str$(value))
        Case Else: TestWire = Replace(Replace(Replace(CStr(value), vbCr, " "), vbLf, " "), "|", "/")
    End Select
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Обрабатывает переход через полночь при измерении штатного времени.
Private Function TestElapsed(ByVal startTime As Double) As Double
    TestElapsed = Timer - startTime
    If TestElapsed < 0# Then TestElapsed = TestElapsed + 86400#
End Function
