"""Read native workbook evidence and sum longitudinal N, Mx and My independently."""

import argparse
from bisect import bisect_right
import csv
from hashlib import file_digest
import json
from math import fsum, isfinite, pi, ulp
from pathlib import Path
import re
from io import StringIO


HERE = Path(__file__).resolve().parent
DRAFT = HERE / "docs/regression/Diagnostic.xlsm"
BOOK = HERE / "workbook/output/RC_Section_NDM.xlsm"
REQUESTED = {"T0": (-40000., 3000000., -1500000., 0.), "PureT": (0., 0., 0., 1500000.),
             "Mixed": (-40000., 3000000., -1500000., 1500000.)}
HOOP_FAIL_REQUESTED = (0., 0., 0., 1500000.)
STATE = "StrengthState"
LENGTH = {"mm": 1., "cm": 10., "m": 1000.}
AREA = {"mm2": 1., "cm2": 100., "m2": 1e6}
STRESS = {"pa": 1e-6, "kpa": 1e-3, "mpa": 1., "kgf/cm2": .0980665, "tf/m2": .00980665}
CURVATURE = {"1/mm": 1., "1/m": .001}
FORCE = {"n": 1., "kn": 1000., "tf": 9806.65}
MOMENT = {"n*mm": 1., "kn*m": 1e6, "tf*m": 9806650.}


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest().upper()


def wire(path):
    data = path.read_bytes()
    return data.decode("utf-16" if data.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig").replace("\r\n", "\n")


def info(path):
    return json.loads(wire(path))


def only(pattern, text):
    (match,) = re.findall(pattern, text, re.MULTILINE)
    return match


def number(value):
    result = float(value)
    assert isfinite(result), value
    return result


def rows(path):
    with StringIO(wire(path), newline="") as stream:
        fields = csv.DictReader(stream, delimiter="\t", quoting=csv.QUOTE_NONE)
        if not any(fields.fieldnames or ()):
            assert not list(fields), path
            return []
        assert len(fields.fieldnames) == len(set(fields.fieldnames)), path
        return list(fields)


def named(row, key):
    (field,) = [value for column, value in row.items() if column.split(", ", 1)[0] == key]
    return field


def diagram_interpolation(points, physical_only):
    abscissa = [strain for strain, _ in points]
    assert len(abscissa) >= 3 and abscissa == sorted(set(abscissa)), points

    def stress(strain):
        if physical_only and strain <= abscissa[0]:
            return points[0][1]
        if physical_only and strain >= abscissa[-1]:
            return points[-1][1]
        assert abscissa[0] <= strain <= abscissa[-1], (strain, abscissa)
        left = min(bisect_right(abscissa, strain) - 1, len(abscissa) - 2)
        e0, s0 = points[left]
        e1, s1 = points[left + 1]
        return s0 + (s1 - s0) * ((strain - e0) / (e1 - e0))

    return stress


def confirm_inputs(inputs_only):
    prep = info(HERE / "Preparation.json")
    sha = prep["book_sha256"]
    assert digest(BOOK) == sha and digest(Path(prep["source_book"])) == sha, "Source changed"
    for name, expected in prep["files"].items():
        assert digest(HERE / name) == expected, name
    code = HERE / "docs/regression/CodeUpdate.json"
    if inputs_only:
        assert not code.exists() and not (HERE / "Compile.log").exists(), "A first compiler attempt already exists"
        assert digest(DRAFT) == sha and not any((HERE / "Native").iterdir()), "Private inputs are not fresh"
    else:
        builder = info(code)
        assert builder["Compiled"] and not builder["ProductionChanged"]
        assert builder["Modules"] == ["modTestPlanarTorsionWorkbook"] and not builder["EntryPointNames"]
        assert builder["ProductionSHA256"] == sha and builder["WorkbookSHA256"] == digest(DRAFT)
        assert info(HERE / "CompileClosure.json")["State"] == "Absent"
    return prep


def native_receipt(path):
    output = wire(path)
    assert "TOTAL_PLANAR_TORSION_EXCEL: passed=1; failed=0" in output
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in output
    owners = info(path.with_name(path.name + ".Ownership.json"))
    closure = info(path.with_name(path.name + ".ProcessClosure.json"))
    latest = closure["Closure"]["FinalState"]
    assert owners["SourceSHA256"] == digest(DRAFT) and owners["BeforeWorkbookOpen"] and owners["VerifiedNewOwner"]
    assert closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"] == 0
    assert latest["State"] == "Absent" and (latest["PID"], latest["StartTicksUTC"]) == (owners["PID"], owners["StartTicksUTC"])
    before, after = only(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=([0-9A-F]{64}); equal=True;", output)
    assert before == after
    receipt = info(path.with_suffix(".Receipt.json"))
    assert receipt["native_exit"] == 0
    form = number(only(r"^TP_FORM: ([^|]+)\|.*$", output))
    calc = number(only(r"^TP_CALC: ([^|]+)\|.*$", output))
    assert form > 0. and calc > 0. and receipt["wall_seconds"] >= form + calc
    return output, {"formation_seconds": form, "calculation_seconds": calc, "wall_seconds": receipt["wall_seconds"],
                    "results_reopen_sha256": before, "owner_pid": owners["PID"], "owner_absent": True}


def integrate(label, load_case, case, all_, request, tolerances):
    geometry_rows = rows(HERE / "Native" / f"{label}.Geometry.tsv")
    field_rows = rows(HERE / "Native" / f"{label}.Fields.tsv")
    diagram_rows = rows(HERE / "Native" / f"{label}.Diagrams.tsv")
    length = LENGTH[all_["Output.LengthUnit"][0].lower()]
    area = AREA[all_["Output.AreaUnit"][0].lower()]
    stress = STRESS[all_["Output.StressUnit"][0].lower()]
    force = FORCE[all_["Output.ForceUnit"][0].lower()]
    moment = MOMENT[all_["Output.MomentUnit"][0].lower()]
    signs = (-1 if all_["Output.SignConvention.N"][0].lower() == "compression" else 1,
             -1 if all_["Output.SignConvention.Mx"][0].lower() == "-y tension" else 1,
             -1 if all_["Output.SignConvention.My"][0].lower() == "-x tension" else 1)
    for key, target, factor, sign in zip(("N", "MxUser", "MyUser"), request, (force, moment, moment), signs):
        assert abs(number(case[key][0]) * factor * sign - target) <= 32 * ulp(max(1., abs(target))), (label, key)
    prefix = f"State.{STATE}."
    eps0 = number(case[prefix + "Epsilon0"][0])
    kx, ky = (number(case[prefix + key][0]) * CURVATURE[case[prefix + key][1].lower()] for key in ("KappaX", "KappaY"))
    diagrams = []
    for key in ("ConcreteDiagramId", "RebarDiagramId"):
        material = [row for row in diagram_rows if row["DiagramId"] == case[prefix + key][0]]
        (mode,) = set(row["DiagramMode"] for row in material)
        assert mode in ("Physical", "StateExtension"), (label, key, mode)
        points = sorted((number(row["Strain"]), number(named(row, "Stress")) * stress) for row in material)
        diagrams.append(diagram_interpolation(points, physical_only=mode == "Physical"))
    concrete, steel = diagrams
    fields = {row["ElementID"]: row for row in field_rows if row["StateType"] == STATE and row["LoadCase"] == "TP-FIXTURE"}
    assert len(fields) == len(field_rows) == len(geometry_rows), label
    assert len(geometry_rows) == int(all_["ConcreteCount"][0]) + int(all_["RebarCount"][0]), label
    assert int(all_["RebarCount"][0]) == 8
    cx = number(all_["LoadReferenceX"][0]) * length
    cy = number(all_["LoadReferenceY"][0]) * length
    terms, initial_terms, steel_fields = [], [], {}
    for row in geometry_rows:
        field = fields[row["ElementID"]]
        assert field["MaterialType"] == row["MaterialType"] and field["ProfileId"] == "PR4"
        x, y = (number(named(row, key)) * length for key in ("X", "Y"))
        ai = number(named(row, "Area")) * area
        assert ai > 0.
        sigma = number(named(field, "Stress")) * stress
        plane_strain = eps0 + kx * y + ky * x
        strain = number(field["Strain"])
        initial_strain = strain - plane_strain
        if row["MaterialType"] == "Rebar":
            close_tight(steel(strain), sigma, (label, row["ElementID"], "total steel diagram"))
            steel_fields[row["ElementID"]] = (ai, plane_strain, strain, sigma)
            sigma -= concrete(plane_strain)
            initial_force = ai * steel(initial_strain)
        else:
            assert row["MaterialType"] == "Concrete", row["MaterialType"]
            close_tight(concrete(strain), sigma, (label, row["ElementID"], "total concrete diagram"))
            initial_force = ai * concrete(initial_strain)
        f = sigma * ai
        terms.append((f, f * (y - cy), f * (x - cx)))
        initial_terms.append((initial_force, initial_force * (y - cy), initial_force * (x - cx)))
    resultants = tuple(fsum(values) for values in zip(*terms))
    initial_resultants = tuple(fsum(values) for values in zip(*initial_terms))
    errors = tuple(value - target for value, target in zip(resultants, request))
    # В дополнение к штатному допуску учитывается только округление 15-значного вывода.
    roundoff = tuple(100 * ulp(max(1., fsum(abs(value) for value in values))) for values in zip(*terms))
    assert all(abs(error) <= tol + margin for error, tol, margin in zip(errors, tolerances, roundoff)), (label, errors, tolerances)
    assert all(abs(value) <= tol for value, tol in zip(initial_resultants, tolerances)), (label, initial_resultants, tolerances)
    n_solver = number(case["Nint"][0]) * force * signs[0]
    assert abs(n_solver - resultants[0]) <= roundoff[0], (label, n_solver, resultants[0])
    return ({"actual_n_mx_my": resultants, "residual_n_mx_my": errors, "serialization_margin": roundoff,
             "initial_t_only_n_mx_my": initial_resultants,
             "state_plane_internal": [eps0, kx, ky], "concrete_cells": int(all_["ConcreteCount"][0]),
             "rebar_count": int(all_["RebarCount"][0]), "fields_columns": list(field_rows[0])}, steel_fields, steel)


def close_tight(actual, target, context):
    assert abs(actual - target) <= 1e-11 * max(1., abs(actual), abs(target)), (context, actual, target)


def verify_torsion(label, shape, torque, all_, steel_fields, steel, failing_hoop):
    reference = reference_torsion(shape, torque)
    (summary_rows, steel_rows) = [rows(HERE / "Native" / f"{label}.{name}.tsv") for name in ("Torsion", "TorsionSteel")]
    if torque == 0.:
        assert not summary_rows and not steel_rows
        assert all(abs(strain - plane) < 1e-15 for _, plane, strain, _ in steel_fields.values())
        return {"summary_rows": 0, "steel_detail_rows": 0, "reference": reference}
    (summary,) = summary_rows
    assert len(steel_rows) == len(steel_fields)
    expected_hoop_status = "FAIL" if failing_hoop else "OK"
    assert summary["Сочетание"] == "TP-FIXTURE" and summary["Статус хомута"] == expected_hoop_status, summary
    assert summary["Статус N/M + T"] == "OK", summary
    stress = STRESS[all_["Output.StressUnit"][0].lower()]
    moment = MOMENT[all_["Output.MomentUnit"][0].lower()]
    close_tight(number(named(summary, "T")) * moment, torque, (label, "T"))
    close_tight(number(named(summary, "q")), reference["flow_n_mm"], (label, "hoop shear flow"))
    close_tight(number(named(summary, "Напряжение хомута")) * stress, reference["hoop_stress_mpa"], (label, "hoop stress"))
    resistance = 12. if failing_hoop else 240.
    close_tight(number(summary["Запас хомута"]), resistance / reference["hoop_stress_mpa"], (label, "hoop reserve"))
    assert (number(summary["Запас хомута"]) < 1.) == failing_hoop
    details, found = [], set()
    for row in steel_rows:
        assert row["Сочетание"] == "TP-FIXTURE" and row["Стержень"] not in found
        found.add(row["Стержень"])
        ai, plane, strain, total = steel_fields[row["Стержень"]]
        initial_stress = number(named(row, "Начальное напряжение от T")) * stress
        initial_strain = number(row["Начальная деформация от T"])
        published_total = number(named(row, "Итоговое напряжение")) * stress
        assert initial_stress > 0. and initial_strain > 0.
        close_tight(steel(initial_strain), initial_stress, (label, row["Стержень"], "initial steel branch"))
        assert abs(plane + initial_strain - strain) < 1e-14, (label, row["Стержень"], plane, initial_strain, strain)
        close_tight(total, published_total, (label, row["Стержень"], "same published total"))
        details.append(initial_stress * ai)
    close_tight(fsum(details), reference["longitudinal_tension_n"], (label, "total torsion steel tension"))
    return {"summary_rows": len(summary_rows), "steel_detail_rows": len(steel_rows), "reference": reference,
            "initial_steel_tension_n": fsum(details), "summary": summary}


def verify_case(shape, load_case):
    label = f"{shape}-{load_case}"
    raw, result = native_receipt(HERE / "Native" / f"{label}.txt")
    assert only(r"^TP_CASE: ([^|]+)\|([^\n]+)$", raw) == (shape, load_case)
    request = tuple(map(number, only(r"^TP_INTERNAL_N_NMM: (.+)$", raw).split("|")))
    tolerances = tuple(map(number, only(r"^TP_ABSOLUTE_TOL: (.+)$", raw).split("|")))
    failing_hoop = load_case == "HoopFail"
    expected = HOOP_FAIL_REQUESTED if failing_hoop else REQUESTED[load_case]
    assert request == expected and len(tolerances) == 3 and min(tolerances) > 0.
    properties = {"ALL": {}, "TP-FIXTURE": {}}
    for scope, name, value, unit in re.findall(r"^TP_PROPERTY: ([^|]+)\|([^|]+)\|([^|]*)\|([^\n]*)$", raw, re.MULTILINE):
        assert name not in properties[scope], (label, name)
        properties[scope][name] = (value, unit)
    case, all_ = properties["TP-FIXTURE"], properties["ALL"]
    assert case["ProfileId"][0] == "PR4" and case["CapacityStatus"][0] == "N/A", (label, case)
    assert case["DirectStateStatus"][0] == "OK", (label, case)
    assert case["OverallStatus"][0] == ("FAIL" if failing_hoop else "OK"), (label, case)
    equilibrium, steel_fields, steel = integrate(label, load_case, case, all_, request, tolerances)
    result.update(equilibrium)
    result.update({"shape": shape, "load_case": load_case, "request_n_nmm": request, "tolerance_n_nmm": tolerances,
                   "torsion": verify_torsion(label, shape, request[3], all_, steel_fields, steel, failing_hoop), "statuses": {
                       key: case[key][0] for key in ("OverallStatus", "DirectStateStatus", "CapacityStatus")},
                   "published_torsion": {key: value for key, value in case.items() if key.startswith("Torsion.")}})
    return result


def reference_torsion(shape, torque):
    # Осевая линия хомута отстоит от границы на cover + diameter / 2.
    offset = 25. + 8. / 2.
    if shape == "Rectangles":
        width, height = 300. - 2 * offset, 400. - 2 * offset
        enclosed, perimeter = width * height, 2 * (width + height)
    else:
        radius = 200. - offset
        enclosed, perimeter = pi * radius**2, 2. * pi * radius
    shear_flow = abs(torque) / (2. * enclosed)
    return {"axis_area_mm2": enclosed, "axis_perimeter_mm": perimeter, "flow_n_mm": shear_flow,
            "hoop_stress_mpa": shear_flow * 100. / (pi * 8.**2 / 4.),
            "longitudinal_tension_n": shear_flow * perimeter}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--circle", action="store_true")
    parser.add_argument("--hoop-fail", action="store_true")
    args = parser.parse_args()
    prep = confirm_inputs(args.inputs_only)
    if args.inputs_only:
        print(f"INPUTS PASS {prep['book_sha256']} {len(prep['files'])} sealed sources")
        return
    shapes = ("Rectangles", "Circle") if args.circle else ("Rectangles",)
    cases = [verify_case(shape, case) for shape in shapes for case in REQUESTED]
    if args.hoop_fail:
        cases.append(verify_case("Rectangles", "HoopFail"))
    result = HERE / "Verification.json"
    result.write_text(json.dumps({"book_sha256": prep["book_sha256"], "cases": cases}, ensure_ascii=False, indent=2) + "\n",
                      encoding="utf-8")
    print(f"NATIVE PASS {len(cases)} scopes, verification SHA-256 {digest(result)}")


if __name__ == "__main__":
    main()
