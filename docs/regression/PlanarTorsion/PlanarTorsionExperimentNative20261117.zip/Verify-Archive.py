"""Повторяет проверку расчёта по сохранённым таблицам и сверяет происхождение книги."""

import argparse
from importlib.util import module_from_spec, spec_from_file_location
from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output
import sys

sys.dont_write_bytecode = True
import NativeVerify as native
from StockInputs import INPUTS, compare


HERE = Path(__file__).resolve().parent
BASE = "5786C56088352A0530BDFFEAA7BEB6701A211152896EE13DF85551428D5B10AF"
BASE_EXPORT = "E27CC2072D63C203003CFDC3BFD64E663F687F6D44513C780EC38D7D51F6A069"
BOOK = "978178F2AE2E49F0338405BE712EBEA7D7A1FA87922FD9ACBFA8402B50315344"
EXPORT = "5409BBBDF5E99306F1927D784D3132BDA9CDF488BC363B8479790FE0ED7CD862"
REVISION = "3e7da82d3391a90aab8678054584f259eda30fe7"
BUILD_SOURCE_PARENT = "06287f90dc9d29b8eac82f968732f439fe5b3147"
EXPERIMENT_SOURCE = "253d403812722a4f77c6bdd962c8e653eef79391"
LABELS = tuple((shape, case) for shape in ("Rectangles", "Circle") for case in native.REQUESTED) + (("Rectangles", "HoopFail"),)
EXECUTION_LABELS = (*LABELS[:3], LABELS[-1], *LABELS[3:-1])
TERMINAL_SHA = "44EE7B3444111CFEDE2665016DB922DE23DEB59642E9E4C767B94053D0571362"
TEST_MODULE = "modTestPlanarTorsionWorkbook"
NATIVE_COPIES = {"Guard-IsolatedOffice.ps1": "Guard-IsolatedOffice.ps1", "Run.ps1": "Run.ps1",
                 "Verify.py": "NativeVerify.py", f"tests/{TEST_MODULE}.bas": f"tests/{TEST_MODULE}.bas"}


def read_inventory():
    inventory = native.info(HERE / "SHA256SUMS.json")
    actual = {path.relative_to(HERE).as_posix() for path in HERE.rglob("*") if path.is_file()
              and "__pycache__" not in path.parts and path != HERE / "SHA256SUMS.json"}
    assert actual == set(inventory), (sorted(actual - set(inventory)), sorted(set(inventory) - actual))
    for name, sha in inventory.items():
        assert Path(name).suffix.lower() not in {".xlsm", ".xlsx", ".xls", ".ndm"}
        assert Path(name).name.lower() != "vba_all_code.txt"
        assert native.digest(HERE / name) == sha, name


def verify_build():
    root = HERE / "Build"
    saved = native.info(root / "BuildReceipt.json")
    manifest = native.info(root / "Inputs.json")
    agreement = native.info(root / "SourceAgreement.json")
    assert manifest["source_head"] == BUILD_SOURCE_PARENT and manifest["baseline_revision"] == REVISION
    assert manifest["experiment_branch"] == "codex/torsion-planar-experiment"
    assert saved["HistoricalWorkbookSHA256"] == manifest["baseline_sha256"] == BASE
    assert saved["WorkbookSHA256"] == BOOK and saved["ExportSHA256"] == EXPORT
    assert saved["InputManifestSHA256"] == native.digest(root / "Inputs.json")
    assert saved["Status"] == "PASS" and saved["Error"] is None and saved["Compile"] is True
    assert saved["Closure"] == "Absent" and saved["ClosureAction"] == "Quit"
    assert saved["Owner"] > 0 and int(saved["OwnerStartTicksUTC"]) > 0
    assert saved["Components"] == {"Before": 187, "Expected": 195, "Actual": 195}
    assert {key: agreement[key] for key in ("status", "before", "after", "unchanged", "changed", "added")} == {
        "status": "PASS", "before": 187, "after": 195, "unchanged": 175, "changed": 12, "added": 8}
    expected = {item["name"]: item for item in manifest["modules"]}
    verified = {item["module"]: item for item in agreement["verified"]}
    assert len(manifest["modules"]) == len(expected) == len(agreement["verified"]) == len(verified) == 20
    assert sum(item["new"] is True for item in expected.values()) == 8
    assert expected.keys() == verified.keys() and TEST_MODULE not in expected
    for name, item in expected.items():
        assert item["sha256"] == verified[name]["source_sha256"] and verified[name]["lines"] > 0, name
    for file, sha in manifest["helper"].items():
        assert native.digest(root / file) == sha, file
    return manifest, verified, saved["Owner"], int(saved["OwnerStartTicksUTC"])


def verify_stock(args):
    receipt = native.info(HERE / "StockInputVerification.json")
    assert receipt["historical_workbook_sha256"] == BASE and receipt["built_workbook_sha256"] == BOOK
    stock = receipt["comparison"]
    assert tuple(item["name"] for item in stock["matches"]) == INPUTS
    assert sum(item["meaningful_cells"] for item in stock["matches"]) == 2175
    assert len(stock["stock_validation_matches"]) == 2 and stock["new_inputs_blank"] is True
    assert stock["torque_header"] == "T" and stock["hoop_keys"] == ["Diameter", "Spacing", "Cover", "Rsw"]
    assert stock["anchors"] == {"rngPlanarTorsionHoop": ["Сечения", 1, 135, 2, 139],
                               "rngPlanarTorsionSummary": ["Results", 127, 156, 127, 156],
                               "rngPlanarTorsionSteel": ["Results", 138, 156, 138, 156]}
    if args.historical_workbook:
        assert args.built_workbook, "--historical-workbook requires --built-workbook"
        assert native.digest(args.historical_workbook) == BASE
        assert compare(args.historical_workbook, args.built_workbook) == stock
    if args.built_workbook:
        assert native.digest(args.built_workbook) == BOOK


def verify_optional_sources(args, manifest, verified):
    # Полные исходники и экспорты проверяются только по явно переданным путям.
    if args.source_tree:
        for item in manifest["modules"]:
            assert native.digest(args.source_tree / item["path"]) == item["sha256"], item["path"]
            frozen = check_output(["git", "-C", str(args.source_tree), "show", f"{EXPERIMENT_SOURCE}:{item['path']}"])
            assert sha256(frozen).hexdigest().upper() == item["sha256"], item["path"]
        for file, expected in manifest["builders"].items():
            assert native.digest(args.source_tree / "tools/build_workbook" / file) == expected, file
    if args.vba_export:
        spec = spec_from_file_location("official_source_agreement", HERE / "Build/VerifySource.py")
        source_agreement = module_from_spec(spec)
        spec.loader.exec_module(source_agreement)
        assert native.digest(args.vba_export) == EXPORT
        exported = source_agreement.PARSER.modules(args.vba_export)
        assert len(exported) == 195 and TEST_MODULE not in exported
        for item in manifest["modules"]:
            kind, body = exported[item["name"]]
            assert kind == item["type"] and len(source_agreement.lines(body)) == verified[item["name"]]["lines"], item["name"]
    if args.historical_export:
        assert args.vba_export, "--historical-export requires --vba-export"
        assert native.digest(args.historical_export) == BASE_EXPORT
        old = source_agreement.PARSER.modules(args.historical_export)
        assert len(old) == 187 and old.keys() <= exported.keys()
        assert {item["name"] for item in manifest["modules"] if item["new"]} == exported.keys() - old.keys()
        assert all(old[name][0] == exported[name][0] for name in old)
        lines = source_agreement.lines
        assert {name for name in old if lines(old[name][1]) != lines(exported[name][1])} == {
            item["name"] for item in manifest["modules"] if not item["new"]}
        if args.source_tree:
            for item in manifest["modules"]:
                name = item["name"]
                expected = source_agreement.source_lines((args.source_tree / item["path"]).read_bytes())
                observed = lines(exported[name][1])
                if expected != observed:
                    assert not item["new"] and len(expected) == len(observed), name
                    source_at_revision = check_output(["git", "-C", str(args.source_tree), "show",
                                                       f"{REVISION}:{item['path']}"])
                    inherited = set(zip(source_agreement.source_lines(source_at_revision), lines(old[name][1]), strict=True))
                    assert all(a == b or (a, b) in inherited for a, b in zip(expected, observed, strict=True)), name


def identity(record):
    return int(record["PID"]), int(record["StartTicksUTC"])


def verify_compiler():
    phase = native.info(HERE / "Preparation.json")
    assert phase["tools_baseline"] == REVISION and phase["book_sha256"] == BOOK
    for source, copied in NATIVE_COPIES.items():
        assert native.digest(HERE / copied) == phase["files"][source], copied
    code = native.info(HERE / "CodeUpdate.json")
    assert code["ProductionSHA256"] == BOOK and code["Compiled"] is True and code["ProductionChanged"] is False
    assert code["Modules"] == [TEST_MODULE] and code["RetiredModules"] == [] and code["EntryPointNames"] == []
    closure = native.info(HERE / "CompileClosure.json")
    compiler = native.only(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", native.wire(HERE / "Compile.log"))
    assert closure["State"] == "Absent" and identity(closure) == tuple(map(int, compiler))
    assert "PRIVATE_CODE_READY: modules=1; production unchanged=True" in native.wire(HERE / "Compile.log")
    phases = [json.loads(line) for line in native.wire(HERE / "Run.ndjson").splitlines()]
    assert [p["phase"] for p in phases] == ["BeforePlanarTorsionCompile", *(
        f"BeforePlanarTorsion{shape}-{case}" for shape, case in EXECUTION_LABELS)]
    return code["WorkbookSHA256"], identity(closure), {entry["Id"] for p in phases for entry in p["excel"] if entry["ProtectedUser"]}


def verification_receipt(path, instrumented, own_ids, protected):
    """Привязывает копию ведомости к хэшу диагностической книги и квитанциям отдельного процесса."""
    output = native.wire(path)
    assert "TOTAL_PLANAR_TORSION_EXCEL: passed=1; failed=0" in output
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in output
    owner, closure, cleanup = (native.info(path.with_name(path.name + "." + key + ".json"))
                               for key in ("Ownership", "ProcessClosure", "RunnerCleanup"))
    owned = identity(owner)
    assert owned not in own_ids and owned[0] not in protected
    own_ids.add(owned)
    assert owner["ProcessName"] == "EXCEL" and owner["SourceSHA256"] == instrumented
    assert owner["BeforeWorkbookOpen"] and owner["VerifiedNewOwner"]
    assert closure["Stage"] == "AFTER_CHILD_EXIT" and closure["Passed"] and closure["ChildHasExited"]
    assert closure["ChildExitCode"] == 0 and not closure["OrdinaryPathKilledAnything"]
    assert closure["RunnerCleanupValid"] and closure["RunnerCleanup"] == cleanup
    assert cleanup["OwnerVerified"] and cleanup["QuitRequested"] and cleanup["QuitSucceeded"] and not cleanup["Failed"]
    office = closure["Closure"]
    assert office["Passed"] and not office["OrdinaryPathKilledAnything"]
    latest = office["FinalState"]
    assert identity(cleanup) == owned == identity(latest) and latest["State"] == "Absent"
    assert office["Identity"]["Valid"] and (office["Identity"]["PID"], int(office["Identity"]["Ticks"])) == owned
    before, after = native.only(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=([0-9A-F]{64}); equal=True;", output)
    assert before == after
    receipt = native.info(path.with_suffix(".Receipt.json"))
    form = native.number(native.only(r"^TP_FORM: ([^|]+)\|.*$", output))
    calc = native.number(native.only(r"^TP_CALC: ([^|]+)\|.*$", output))
    assert receipt["native_exit"] == 0 and form > 0. and calc > 0. and receipt["wall_seconds"] >= form + calc
    return output, {"formation_seconds": form, "calculation_seconds": calc, "wall_seconds": receipt["wall_seconds"],
                    "results_reopen_sha256": before, "owner_pid": owned[0], "owner_absent": True}


def verify_cases(args, instrumented, own_ids, protected):
    if args.diagnostic_workbook:
        assert native.digest(args.diagnostic_workbook) == instrumented
    original = native.native_receipt
    native.native_receipt = lambda path: verification_receipt(path, instrumented, own_ids, protected)
    try:
        results = [native.verify_case(shape, case) for shape, case in LABELS]
    finally:
        native.native_receipt = original
    assert native.digest(HERE / "NativeVerification.json") == TERMINAL_SHA
    terminal = native.info(HERE / "NativeVerification.json")
    assert terminal["book_sha256"] == BOOK and json.loads(json.dumps(results)) == terminal["cases"]
    return results


def verify_rejected():
    """Сверяет отличительный статус отвергнутой сборки с нативными данными."""
    root = HERE / "Rejected22EA"
    build = native.info(root / "BuildReceipt.json")
    code = native.info(root / "CodeUpdate.json")
    sha = "22EA4EEAD789375609B00917DBA51B4415DA3A753066E2DA67FA993F0E50C379"
    assert build["WorkbookSHA256"] == code["ProductionSHA256"] == sha and sha != BOOK
    raw = root / "Rectangles-PureT.txt"
    owner, closure = (native.info(raw.with_name(raw.name + "." + key + ".json"))
                      for key in ("Ownership", "ProcessClosure"))
    assert owner["SourceSHA256"] == code["WorkbookSHA256"]
    final = closure["Closure"]["FinalState"]
    assert closure["ChildHasExited"] and closure["ChildExitCode"] == 0
    assert final["State"] == "Absent" and identity(owner) == identity(final)
    assert "TP_PROPERTY: TP-FIXTURE|OverallStatus|FAIL|-" in native.wire(raw)
    summary, = native.rows(root / "Rectangles-PureT.Torsion.tsv")
    assert summary["Статус хомута"] == "OK" and summary["Статус N/M + T"] == "FAIL"


def main():
    if not __debug__:
        raise SystemExit("Run Python without -O or PYTHONOPTIMIZE")
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("built-workbook", "historical-workbook", "diagnostic-workbook", "vba-export", "historical-export", "source-tree"):
        parser.add_argument("--" + name, type=Path)
    args = parser.parse_args()
    read_inventory()
    manifest, verified, build_pid, build_ticks = verify_build()
    verify_stock(args)
    verify_optional_sources(args, manifest, verified)
    verify_rejected()
    instrumented, compiler, protected = verify_compiler()
    assert compiler != (build_pid, build_ticks) and {compiler[0], build_pid}.isdisjoint(protected)
    results = verify_cases(args, instrumented, {compiler, (build_pid, build_ticks)}, protected)
    for case in results:
        print(f"{case['shape']}-{case['load_case']} {case['statuses']['OverallStatus']} "
              f"direct={case['statuses']['DirectStateStatus']} capacity={case['statuses']['CapacityStatus']} "
              f"calc={case['calculation_seconds']:.6f}s reopen={case['results_reopen_sha256']}")
    print(f"PLANAR TORSION EXPERIMENT PORTABLE VERIFIED {len(results)}/{len(LABELS)} {BOOK}")


if __name__ == "__main__":
    main()
