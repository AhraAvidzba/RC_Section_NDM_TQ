# Times the actual workbook calculation on a separate Excel copy per case.
param([switch]$Preflight,[switch]$Circle,[switch]$HoopFail)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$draft='docs/regression/Diagnostic.xlsm'
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
Push-Location -LiteralPath $root
try {
    & python -B -X utf8 'Verify.py' --inputs-only
    if ($LASTEXITCODE -ne 0) {throw 'Unverified workbook or source files.'}
    # Import the exact compiler support before any Office launch. This exercises
    # the nested sources and catalogs rather than checking only staged hashes.
    . (Join-Path $root 'tools/build_workbook/GeometryExampleSupport.ps1')
    . (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
    if (!(Get-Command Get-WorkbookPrintAreas -ErrorAction SilentlyContinue) -or
        !(Get-Command Get-GeometrySettingsCatalog -ErrorAction SilentlyContinue) -or
        $script:NormativeFormulaCatalog.Count -eq 0) {throw 'Compiler support failed to load.'}
    $null=@(Get-GeometrySettingsCatalog)
    $actualPrintAreas=@(Get-WorkbookPrintAreas (Resolve-Path -LiteralPath $draft).Path)
    if (!$actualPrintAreas.Count) {throw 'Compiled input workbook print areas are missing.'}
    Write-Output ('TOOLING PREFLIGHT PASS: scopes='+$actualPrintAreas.Count)
    if ($Preflight) {return}
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM_Results_Reopen.xlsm').Length -gt 210) {
        throw 'Excel temporary path is too long.'
    }
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw -Encoding UTF8 | ConvertFrom-Json
    $module='modTestPlanarTorsionWorkbook'
    $macro=$module+'.RunTestPlanarTorsionWorkbook'
    Assert-IsolatedOfficeReady 'BeforePlanarTorsionCompile'
    & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft -ModuleNames @($module) |
        Tee-Object -FilePath 'Compile.log'
    Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw -Encoding UTF8 | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $compiled.ProductionSHA256 -cne $prep.book_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or ($compiled.Modules -join ',') -cne $module) {
        throw 'Isolated test-only code import was not proved.'
    }
    $shapes=@('Rectangles')
    if ($Circle) {$shapes+=@('Circle')}
    foreach ($geometry in $shapes) {
        $modes=@('T0','PureT','Mixed')
        if ($HoopFail -and $geometry -eq 'Rectangles') {$modes+=@('HoopFail')}
        foreach ($mode in $modes) {
            $label=$geometry+'-'+$mode
            $report='Native/'+$label+'.txt'
            Assert-IsolatedOfficeReady ('BeforePlanarTorsion'+$label)
            $watch=[Diagnostics.Stopwatch]::StartNew()
            & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $draft `
                -ReportPath $report -Macro $macro -MacroArgument1 $mode -MacroArgument2 $geometry `
                -Mode No -TimeoutSeconds 80 -VerifyResultsReopen -FailFast
            $exit=$LASTEXITCODE
            $watch.Stop()
            [ordered]@{native_exit=$exit;wall_seconds=$watch.Elapsed.TotalSeconds} | ConvertTo-Json |
                Set-Content -LiteralPath ('Native/'+$label+'.Receipt.json') -Encoding UTF8
            if (Test-Path -LiteralPath $report) {
                $r=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
                if ($r.Count -eq 1) {
                    $folder=Split-Path -Parent $r[0].Substring('FIXTURE: '.Length)
                    if (!(Split-Path -Leaf $folder).StartsWith('RC_NDM_ModeSuite_',[StringComparison]::Ordinal) -or
                        !$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Unexpected fixture path.'}
                    foreach ($name in @('Geometry.tsv','Fields.tsv','Diagrams.tsv','Torsion.tsv','TorsionSteel.tsv','RC_Section_NDM_execution_report.txt')) {
                        $source=Join-Path $folder $name
                        if (Test-Path -LiteralPath $source) {Copy-Item -LiteralPath $source -Destination ('Native/'+$label+'.'+$name)}
                    }
                }
            }
            if ($exit -ne 0) {throw ('Excel runner failed on '+$label)}
        }
    }
    $verifyArgs=@()
    if ($Circle) {$verifyArgs+=@('--circle')}
    if ($HoopFail) {$verifyArgs+=@('--hoop-fail')}
    & python -B -X utf8 'Verify.py' @verifyArgs
    if ($LASTEXITCODE -ne 0) {throw 'Independent result verification failed.'}
}
finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
