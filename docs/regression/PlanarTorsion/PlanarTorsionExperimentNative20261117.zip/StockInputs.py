"""Сверяет сохранённый исходный ввод в двух книгах без запуска Excel."""

from hashlib import sha256
import json
from pathlib import PurePosixPath
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile


S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
INPUTS = ("rngSystemSettings", "rngUnitSettings", "rngSignConventionSettings", "rngCalculationProfiles",
          "rngConcreteMaterialParameters", "rngSteelMaterialParameters", "rngPlotAnnotationSettings", "rngStabilityDurationLoads",
          "rngCircleGeometry", "rngRectanglesGeometry", "rngPointedSectionGeometry", "rngHollowRectangleGeometry",
          "rngLoadCombinations")
UNIT = re.compile(r'^INDEX\(rngUnitSettings,MATCH\("(Length|Stress|Moment|Force|Area|Curvature)",INDEX\(rngUnitSettings,,1\),0\),2\)$')


def column(text):
    value = 0
    for symbol in text:
        value = 26 * value + ord(symbol) - 64
    return value


def position(address):
    letters, row = re.fullmatch(r"\$?([A-Z]+)\$?(\d+)", address).groups()
    return column(letters), int(row)


def region(address):
    sheet, refs = address.rsplit("!", 1)
    a, _, b = refs.partition(":")
    left, top = position(a)
    right, end = position(b or a)
    return sheet.strip("'"), left, top, right, end


def text(element):
    return "".join(t.text or "" for t in element.iter(S + "t"))


def read(path):
    names, cells, validation = {}, {}, {}
    with ZipFile(path) as book:
        assert book.testzip() is None
        root = ET.fromstring(book.read("xl/workbook.xml"))
        names = {item.get("name"): item.text for item in root.find(S + "definedNames") if item.get("localSheetId") is None}
        relations = {entry.get("Id"): entry.get("Target") for entry in ET.fromstring(book.read("xl/_rels/workbook.xml.rels"))}
        shared_strings = [text(node) for node in ET.fromstring(book.read("xl/sharedStrings.xml"))]
        for entry in root.find(S + "sheets"):
            sheet = entry.get("name")
            if sheet not in ("Config", "Сечения"):
                continue
            target = relations[entry.get(R + "id")]
            member = target.lstrip("/") if target.startswith("/") else (PurePosixPath("xl") / target).as_posix()
            result = ET.fromstring(book.read(member))
            data = list(result.iter(S + "c"))
            values = {}
            shared_formulas = {f.get("si"): f.text for cell in data if (f := cell.find(S + "f")) is not None and f.get("si") and f.text}
            for cell in data:
                kind = cell.get("t", "n")
                v = cell.findtext(S + "v")
                f = cell.find(S + "f")
                address = cell.get("r")
                if f is not None:
                    body = f.text
                    if body is None and f.get("t") == "shared":
                        body = shared_formulas[f.get("si")]
                        if not UNIT.fullmatch(body):
                            # Эти записи нужны только вне исходного ввода. При попадании в него сверка должна остановиться.
                            values[address] = ("unsupported_shared", body)
                            continue
                    values[address] = ("formula", body)
                elif kind == "inlineStr":
                    values[address] = ("text", text(cell))
                elif kind == "s" and v is not None:
                    values[address] = ("text", shared_strings[int(v)])
                elif v is not None:
                    values[address] = (kind, v)
            cells[sheet] = values
            validation[sheet] = {v.get("sqref"): (v.get("type"), v.get("errorStyle", "stop"), v.findtext(S + "formula1"))
                                 for v in result.iter(S + "dataValidation")}
    return names, cells, validation


def compact_sha(value):
    return sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest().upper()


def sample(cells, scope):
    sheet, left, top, right, end = scope
    selected = {}
    for address, value in cells[sheet].items():
        c, r = position(address)
        if left <= c <= right and top <= r <= end:
            assert value[0] != "unsupported_shared", (sheet, address, value)
            selected[address] = value
    return selected


def compare(old, new):
    baseline, old_cells, old_validation = read(old)
    exact, new_cells, new_validation = read(new)
    matches = []
    for name in INPUTS:
        scope = region(baseline[name])
        actual = region(exact[name])
        expected = scope if name != "rngLoadCombinations" else (*scope[:3], scope[3] + 1, scope[4])
        assert actual == expected, name
        before, after = sample(old_cells, scope), sample(new_cells, scope)
        assert before == after, name
        matches.append({"name": name, "original_scope": list(scope), "saved_scope": list(actual),
                        "meaningful_cells": len(after), "canonical_cells_sha256": compact_sha(after)})
    assert new_cells["Config"]["O70"] == ("text", "T")
    assert UNIT.fullmatch(new_cells["Config"]["O69"][1])
    assert new_cells["Config"]["O69"][1] == 'INDEX(rngUnitSettings,MATCH("Moment",INDEX(rngUnitSettings,,1),0),2)'
    assert not any(f"O{row}" in new_cells["Config"] for row in range(71, 101))
    assert tuple(new_cells["Сечения"][f"A{row}"][1] for row in range(136, 140)) == ("Diameter", "Spacing", "Cover", "Rsw")
    assert not any(f"B{row}" in new_cells["Сечения"] for row in range(136, 140))
    assert tuple(new_cells["Сечения"][f"D{row}"][1] for row in range(136, 140)) == tuple(
        f'INDEX(rngUnitSettings,MATCH("{unit}",INDEX(rngUnitSettings,,1),0),2)' for unit in ("Length", "Length", "Length", "Stress"))
    expected_anchors = {"rngPlanarTorsionHoop": ("Сечения", 1, 135, 2, 139),
                        "rngPlanarTorsionSummary": ("Results", 127, 156, 127, 156),
                        "rngPlanarTorsionSteel": ("Results", 138, 156, 138, 156)}
    assert {name: region(exact[name]) for name in expected_anchors} == expected_anchors
    stable_validations = []
    for address in ("L71:L100", "M71:M100"):
        original = old_validation["Config"][address]
        saved = new_validation["Config"][address]
        assert original == saved, address
        stable_validations.append({"range": address, "sha256": compact_sha(saved)})
    return {"matches": matches, "stock_validation_matches": stable_validations, "new_inputs_blank": True,
            "torque_header": "T", "hoop_keys": ["Diameter", "Spacing", "Cover", "Rsw"],
            "anchors": {name: list(scope) for name, scope in expected_anchors.items()}}
