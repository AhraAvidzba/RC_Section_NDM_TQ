"""Independent exact-rational reconstruction of the rectangular-grid L case."""

from fractions import Fraction as F
from math import pi


OUTER = [(-20, -20), (260, -20), (260, 120), (160, 120), (160, 240), (-20, 240)]
BARS = [(20, 10), (228, 28), (208, 88), (128, 116), (116, 208), (10, 184), (10, 65)]
HOLE = [60, 100, 120, 160]
GRID, COVER, HOOP_D, HOOP_STEP, STEEL_D = 20, 16, 8, 60, 16
TORQUE = 8_160_000


def sides(path):
    return list(zip(path, path[1:] + path[:1]))


def cross(u, v):
    return u[0] * v[1] - u[1] * v[0]


def area(path):
    return F(sum(cross(first, second) for first, second in sides(path)), 2)


def offset(path, distance):
    # CCW orthogonal lines shift by their unit left normal. Each pair supplies x and y.
    shifts = []
    for (x, y), (bx, by) in sides(path):
        dx, dy = bx - x, by - y
        if dx:
            assert dy == 0
            shifts.append((1, y + distance * (1 if dx > 0 else -1)))
        else:
            assert dy
            shifts.append((0, x - distance * (1 if dy > 0 else -1)))
    return [tuple(dict((previous, current))[axis] for axis in (0, 1))
            for previous, current in zip(shifts[-1:] + shifts[:-1], shifts)]


def project(point, path):
    x, y = point
    candidates = []
    cumulative = 0
    for (ax, ay), (bx, by) in sides(path):
        dx, dy = bx - ax, by - ay
        length = abs(dx) + abs(dy)
        along = max(F(0), min(F(length), F((x - ax) * dx + (y - ay) * dy, length)))
        distance2 = (x - ax - along * dx / length)**2 + (y - ay - along * dy / length)**2
        candidates.append((distance2, cumulative + along))
        cumulative += length
    minimum = min(distance2 for distance2, _ in candidates)
    stations = {station % cumulative for distance2, station in candidates if distance2 == minimum}
    return minimum, stations, cumulative


def concrete_location(x, y):
    # 20 mm grid aligns exactly with every outer and hole line.
    left, right, bottom, top = HOLE
    return (x < 160 or y < 120) and not (left < x < right and bottom < y < top)


def overlaps_bar(x, y):
    half = F(GRID, 2)
    radius = F(STEEL_D, 2)
    # For an axis-aligned mesh rectangle, distance to its bounding box is exact.
    clearance = [max(0, abs(x - bx) - half)**2 + max(0, abs(y - by) - half)**2 for bx, by in BARS]
    return min(clearance) <= radius**2


def solve_3(matrix, rhs):
    augmented = [list(map(F, row)) + [F(value)] for row, value in zip(matrix, rhs)]
    for pivot in range(3):
        value = augmented[pivot][pivot]
        assert value
        augmented[pivot] = [entry / value for entry in augmented[pivot]]
        for row in range(3):
            if row != pivot:
                value = augmented[row][pivot]
                augmented[row] = [entry - value * reference for entry, reference in zip(augmented[row], augmented[pivot])]
    return [row[-1] for row in augmented]


def oracle():
    axis = offset(OUTER, F(COVER) + F(HOOP_D, 2))
    concrete = [(x, y) for x in range(-10, 260, GRID) for y in range(-10, 240, GRID) if concrete_location(x, y)]
    assert len(concrete) * GRID**2 == area(OUTER) - (HOLE[1] - HOLE[0]) * (HOLE[3] - HOLE[2])
    entries = []
    for index, bar in enumerate(BARS):
        _, stations, perimeter = project(bar, axis)
        assert len(stations) == 1
        entries.append((stations.pop(), index))
    entries.sort()
    stations = [entries[-1][0] - perimeter] + [item[0] for item in entries] + [entries[0][0] + perimeter]
    widths = [F(0)] * len(BARS)
    for index, (_, original) in enumerate(entries):
        widths[original] = (stations[index + 2] - stations[index]) / 2
    assert sum(widths) == perimeter and min(widths) > 0

    flow = abs(TORQUE) / (2 * area(axis))
    steel = [flow * width for width in widths]
    steel_resultants = [sum(steel), sum(force * y for force, (x, y) in zip(steel, BARS)),
                        sum(force * x for force, (x, y) in zip(steel, BARS))]

    band = 2 * COVER + HOOP_D
    active = [(x, y) for x, y in concrete if project((x, y), axis)[0] <= band**2 and not overlaps_bar(x, y)]
    basis = [(1, y, x) for x, y in active]
    matrix = [[sum(GRID**2 * row[i] * row[j] for row in basis) for j in range(3)] for i in range(3)]
    coefficients = solve_3(matrix, steel_resultants)
    stresses = [-sum(value * component for value, component in zip(coefficients, row)) for row in basis]
    concrete_resultants = [sum(GRID**2 * stress * row[i] for stress, row in zip(stresses, basis)) for i in range(3)]
    assert max(stresses) < 0 and concrete_resultants == [-value for value in steel_resultants]
    split = sum(stress < F(-215, 100) for stress in stresses)
    return dict(concrete=len(concrete), steel=len(BARS), compressed=len(active), area_mm2=area(axis),
                perimeter_mm=perimeter, flow_N_per_mm=flow, hoop_MPa=float(flow * HOOP_STEP) / (pi * (HOOP_D/2)**2),
                widths=widths, steel_resultants=steel_resultants, concrete_resultants=concrete_resultants,
                min_stress=min(stresses), max_stress=max(stresses), knot_split=[split, len(active)-split])


if __name__ == "__main__":
    results = oracle()
    for name, value in results.items():
        print(f"{name}={value}")
