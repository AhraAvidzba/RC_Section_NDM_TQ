Attribute VB_Name = "modTestPlanarTorsionGeometry"
Option Explicit

' ==================== ДЛЯ ТЕСТОВ ====================
' Проверяет автоматическую ось хомута Г-образного сечения с отверстием,
' начальные деформации и равновесие чистого кручения. Диаграммы материала
' синтетические; контрольные числа получены независимым интегрированием.

Private Const TEST_TORQUE As Double = 8160000# ' Н*мм, даёт поток ровно 100 Н/мм.
Private Const TEST_FORCE_TOLERANCE As Double = 0.0000001 ' Н.
Private Const TEST_MOMENT_TOLERANCE As Double = 0.0001 ' Н*мм.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выполняет один холодный контроль геометрии и чистого T без чтения Config.
' Выдаёт размеры, усилия, ошибки равновесия и время этапов в нативном отчёте.
Public Function RunPlanarTorsionGeometryTests() As String
    On Error GoTo Failed
    Dim started As Double, phase As Double, buildTime As Double, prepTime As Double, solveTime As Double
    started = Timer
    Dim inverseError As Double, inverseRoundTripError As Double
    VerifyTorsionSteelInverseTest inverseError, inverseRoundTripError
    phase = Timer
    Dim section As CSectionModel, geometry As CGeometryRegion
    Set section = BuildConcaveTorsionSectionTest(geometry)
    buildTime = ElapsedTorsionTest(phase): phase = Timer

    Dim hasArea As Boolean, netArea As Double, meshX As Double, meshY As Double, meshArea As Double
    netArea = geometry.AnalyticalArea(hasArea)
    RequireTorsionTest hasArea And Not geometry.ContainsPoint(80#, 140#), "Отверстие отсутствует в бетонной области."
    RequireTorsionTest Not geometry.ContainsPoint(200#, 180#), "Вырез Г-образного сечения заполнен бетоном."
    RequireTorsionTest section.ConcreteCount = 148 And section.RebarCount = 7, "Изменилось число ячеек или стержней."
    RequireNearTorsionTest netArea, 59200#, 0.0000001, "Точная площадь бетона без отверстия"
    section.ConcreteMeshCentroid meshX, meshY, meshArea
    RequireNearTorsionTest meshArea, netArea, 0.0000001, "Площадь бетонной сетки"

    Dim hoop As New CTorsionHoopGeometry, axis As CGeometryPath
    hoop.InitializeAutomatic section, 16#, 8#
    Set axis = hoop.Centerline
    RequireTorsionTest axis.IsClosed And axis.SegmentCount = 6, "Автоматическая ось не совпала с замкнутой осью из шести граней."
    RequireTorsionTest hoop.ContainsInside(80#, 140#), "Ось должна охватывать внутреннее отверстие."
    RequireTorsionTest Not hoop.ContainsInside(200#, 180#), "Ось не должна огибать вырез как выпуклую область."
    RequireNearTorsionTest hoop.EnclosedArea, 40800#, 0.0000001, "Площадь внутри оси хомута"
    RequireNearTorsionTest hoop.Length, 920#, 0.0000001, "Длина оси хомута"
    RequireNearTorsionTest hoop.MinimumClearCover, 16#, 0.0000001, "Минимальный чистый защитный слой"

    Dim prepared As New CTorsionPlanarPreparation
    prepared.Initialize section, 8#, 60#, 16#, 450#
    RequireTorsionTest Len(prepared.FieldError) = 0, "Не подготовлено начальное поле. " & prepared.FieldError
    Dim flow As Double, hoopStress As Double, reserve As Double, longitudinal As Double
    prepared.Evaluate TEST_TORQUE, flow, hoopStress, reserve, longitudinal
    RequireNearTorsionTest flow, 100#, 0.00000001, "Поток от T"
    RequireNearTorsionTest hoopStress, 119.366207318922, 0.00000001, "Напряжение хомута"
    RequireNearTorsionTest reserve, 3.769911184308, 0.00000001, "Запас хомута"
    RequireNearTorsionTest longitudinal, 92000#, TEST_FORCE_TOLERANCE, "Продольная тяга"
    Dim reverseFlow As Double, reverseStress As Double, reverseReserve As Double, reverseLongitudinal As Double
    prepared.Evaluate -TEST_TORQUE, reverseFlow, reverseStress, reverseReserve, reverseLongitudinal
    RequireTorsionTest reverseFlow = flow And reverseStress = hoopStress And reverseReserve = reserve And _
        reverseLongitudinal = longitudinal, "Смена знака T изменила модуль потока или продольную тягу."

    Dim concrete As CMaterialDiagram, steel As CMaterialDiagram, field As CSectionInitialStrains, reason As String
    BuildTorsionDiagramsTest concrete, steel
    Set field = prepared.BuildInitialStrains(section, longitudinal, concrete, steel, reason)
    RequireTorsionTest Not field Is Nothing, "Исходные деформации не построены. " & reason
    RequireTorsionTest field.Matches(section), "Исходное поле принадлежит другой ревизии сечения."
    Dim active As Long, directN As Double, directMx As Double, directMy As Double
    AuditTorsionInitialFieldTest section, field, concrete, steel, active, directN, directMx, directMy
    prepTime = ElapsedTorsionTest(phase): phase = Timer

    Dim solver As New CSectionSolver
    solver.SetInitialStrainField field
    solver.ToleranceN = TEST_FORCE_TOLERANCE: solver.ToleranceMx = TEST_MOMENT_TOLERANCE: solver.ToleranceMy = TEST_MOMENT_TOLERANCE
    solver.EvaluateStrainPlane section, concrete, steel, 0#, 0#, 0#
    RequireNearTorsionTest solver.Nint, directN, TEST_FORCE_TOLERANCE, "Интеграл N решателя при исходной плоскости"
    RequireNearTorsionTest solver.Mxint, directMx, TEST_MOMENT_TOLERANCE, "Интеграл Mx решателя при исходной плоскости"
    RequireNearTorsionTest solver.Myint, directMy, TEST_MOMENT_TOLERANCE, "Интеграл My решателя при исходной плоскости"
    solver.Solve section, concrete, steel, 0#, 0#, 0#
    RequireTorsionTest solver.Converged, "Штатный расчёт равновесия не принят. " & solver.StopReason
    RequireNearTorsionTest solver.ResidualN, 0#, TEST_FORCE_TOLERANCE, "Итоговая невязка N"
    RequireNearTorsionTest solver.ResidualMx, 0#, TEST_MOMENT_TOLERANCE, "Итоговая невязка Mx"
    RequireNearTorsionTest solver.ResidualMy, 0#, TEST_MOMENT_TOLERANCE, "Итоговая невязка My"
    RequireNearTorsionTest solver.Epsilon0, 0#, 0.00000000001, "Дополнительная осевая деформация при чистом T"
    RequireNearTorsionTest solver.KappaX, 0#, 0.0000000000001, "Дополнительная кривизна X при чистом T"
    RequireNearTorsionTest solver.KappaY, 0#, 0.0000000000001, "Дополнительная кривизна Y при чистом T"
    solveTime = ElapsedTorsionTest(phase)

    RunPlanarTorsionGeometryTests = "TORSION_L_HOLE|concrete=148|steel=7|compressed=" & CStr(active) & _
        "|area_mm2=" & TorsionNumberTest(hoop.EnclosedArea) & "|perimeter_mm=" & TorsionNumberTest(hoop.Length) & _
        "|flow_N_per_mm=" & TorsionNumberTest(flow) & "|hoop_MPa=" & TorsionNumberTest(hoopStress) & vbCrLf & _
        "TORSION_L_HOLE_FORCE|N_N=" & TorsionNumberTest(solver.ResidualN) & "|Mx_Nmm=" & TorsionNumberTest(solver.ResidualMx) & _
        "|My_Nmm=" & TorsionNumberTest(solver.ResidualMy) & vbCrLf & _
        "TORSION_L_HOLE_BENCH|mesh_s=" & TorsionNumberTest(buildTime) & "|preparation_s=" & TorsionNumberTest(prepTime) & _
        "|evaluation_and_solve_s=" & TorsionNumberTest(solveTime) & "|total_s=" & TorsionNumberTest(ElapsedTorsionTest(started)) & vbCrLf & _
        "TORSION_STEEL_INVERSE|accepted=13|rejected=2|max_strain_error=" & TorsionNumberTest(inverseError) & _
        "|max_stress_error_MPa=" & TorsionNumberTest(inverseRoundTripError) & vbCrLf & _
        "TOTAL_PLANAR_TORSION_GEOMETRY_TEST: passed=1; failed=0"
    Exit Function
Failed:
    RunPlanarTorsionGeometryTests = "TORSION_L_HOLE_FAIL|" & CStr(Err.Number) & "|" & Err.Description & vbCrLf & _
        "TOTAL_PLANAR_TORSION_GEOMETRY_TEST: passed=0; failed=1"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет штатное обращение диаграммы на пяти узлах, между ними и около
' нулевого узла. На обеих сторонах запрошены значения за физической границей.
Private Sub VerifyTorsionSteelInverseTest(ByRef maximumStrainError As Double, ByRef maximumStressError As Double)
    Dim es(1 To 5) As Double, ss(1 To 5) As Double
    es(1) = -0.025: es(2) = -0.00175: es(4) = 0.00175: es(5) = 0.025
    ss(1) = -354.65: ss(2) = -350#: ss(4) = 350#: ss(5) = 354.65
    Dim material As New CMaterialDiagram
    material.InitializeFromArrays es, ss, 5, es(1), es(5)

    Dim requested As Variant, expected As Variant
    requested = Array(-354.65, -352.325, -350#, -175#, -1#, -0.000001, 0#, 0.000001, 1#, 175#, 350#, 352.325, 354.65)
    expected = Array(-0.025, -0.013375, -0.00175, -0.000875, -0.000005, -0.000000000005, _
        0#, 0.000000000005, 0.000005, 0.000875, 0.00175, 0.013375, 0.025)
    Dim i As Long, stress As Double, strain As Double, strainError As Double, stressError As Double
    For i = LBound(requested) To UBound(requested)
        stress = CDbl(requested(i))
        RequireTorsionTest material.TryInitialStrainForStress(stress, strain), _
            "Не обращено допустимое напряжение стали " & TorsionNumberTest(stress)
        RequireNearTorsionTest strain, CDbl(expected(i)), 0.000000000000002, "Обратная деформация стали"
        If stress = 0# Then RequireTorsionTest strain = 0#, "Нулевому узлу не соответствует точная нулевая деформация."
        strainError = Abs(strain - CDbl(expected(i)))
        stressError = Abs(material.GetStress(strain) - stress)
        If strainError > maximumStrainError Then maximumStrainError = strainError
        If stressError > maximumStressError Then maximumStressError = stressError
        RequireNearTorsionTest stressError, 0#, 0.0000000001, "Прямое напряжение стали после обращения"
    Next i
    RequireTorsionTest Not material.TryInitialStrainForStress(-354.6501, strain), "Принято сжатие стали за физической границей."
    RequireTorsionTest Not material.TryInitialStrainForStress(354.6501, strain), "Принято растяжение стали за физической границей."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит Г-образный наружный контур, отдельное отверстие и сетку 20 мм.
' Координаты фактических стержней исключают неоднозначную проекцию на ось.
Private Function BuildConcaveTorsionSectionTest(ByRef geometry As CGeometryRegion) As CSectionModel
    Dim path As New CGeometryPath
    path.Initialize "TestTorsionL"
    path.AddLine "TestBottom", -20#, -20#, 260#, -20#
    path.AddLine "TestRight", 260#, -20#, 260#, 120#
    path.AddLine "TestNotchBottom", 260#, 120#, 160#, 120#
    path.AddLine "TestNotchLeft", 160#, 120#, 160#, 240#
    path.AddLine "TestTop", 160#, 240#, -20#, 240#
    path.AddLine "TestLeft", -20#, 240#, -20#, -20#
    path.Seal True
    Dim query As New CSectionGeometryQuery, outer As CConcreteRegion, hole As CConcreteRegion, domain As CConcreteRegion
    Set outer = query.RegionFromPath(path)
    Set hole = query.RectangleRegion(80#, 140#, 40#, 40#)
    Set domain = query.SubtractContainedRegion(outer, hole)
    Set geometry = New CGeometryRegion: geometry.Initialize domain
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh geometry, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    geometry.BuildContours section.Contours
    Dim coordinates As Variant, point As Variant, area As Double
    area = 64# * GEOM_PI
    coordinates = Array(Array(20#, 10#), Array(228#, 28#), Array(208#, 88#), Array(128#, 116#), _
        Array(116#, 208#), Array(10#, 184#), Array(10#, 65#))
    For Each point In coordinates
        section.AddRebarElement CDbl(point(0)), CDbl(point(1)), 16#, area, "TestSteel"
    Next point
    Set BuildConcaveTorsionSectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Создаёт синтетические монотонные физические ветви. Излом сжатия бетона
' попадает между экстремумами напряжений в данном контуре.
Private Sub BuildTorsionDiagramsTest(ByRef concrete As CMaterialDiagram, ByRef steel As CMaterialDiagram)
    Dim ec(1 To 5) As Double, sc(1 To 5) As Double, es(1 To 5) As Double, ss(1 To 5) As Double
    ec(1) = -0.0035: ec(2) = -0.001: ec(3) = -0.000075: ec(5) = 0.0001
    sc(1) = -28#: sc(2) = -25#: sc(3) = -2.15
    es(1) = -0.02: es(2) = -0.0025: es(4) = 0.0025: es(5) = 0.02
    ss(1) = -520#: ss(2) = -500#: ss(4) = 500#: ss(5) = 520#
    Set concrete = New CMaterialDiagram: concrete.InitializeFromArrays ec, sc, 5, -0.0035
    Set steel = New CMaterialDiagram: steel.InitializeFromArrays es, ss, 5, -0.02, 0.02
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Независимо суммирует восстановленные поля и сверяет продольные силы
' стержней с длинами их участков. В местах вычитаемого бетона исходное
' бетонное напряжение равно нулю по контракту непересекающихся ячеек.
Private Sub AuditTorsionInitialFieldTest(ByVal section As CSectionModel, ByVal field As CSectionInitialStrains, _
        ByVal concrete As CMaterialDiagram, ByVal steel As CMaterialDiagram, ByRef active As Long, _
        ByRef n As Double, ByRef mx As Double, ByRef my As Double)
    Dim i As Long, strain As Double, stress As Double, force As Double, x As Double, y As Double, area As Double
    Dim minimum As Double, maximum As Double
    minimum = 0#: maximum = -1E+100
    For i = 1 To section.ConcreteCount
        strain = field.ConcreteStrain(i)
        RequireTorsionTest strain <= 0#, "Ячейка начального бетона растянута. " & section.ConcreteID(i)
        If strain < 0# Then
            active = active + 1
            stress = concrete.GetStress(strain)
            RequireTorsionTest stress < 0#, "Начальной деформации не соответствует сжатие бетона."
            If stress < minimum Then minimum = stress
            If stress > maximum Then maximum = stress
            section.ConcreteElementForSolver i, x, y, area
            force = stress * area
            n = n + force: mx = mx + force * y: my = my + force * x
        End If
    Next i
    RequireTorsionTest active = 107, "Изменилось число ячеек с начальным сжатием. Фактически " & CStr(active)
    RequireNearTorsionTest minimum, -2.174346402278539, 0.000000001, "Наибольшее начальное сжатие бетона"
    RequireNearTorsionTest maximum, -2.121542351955739, 0.000000001, "Наименьшее ненулевое сжатие бетона"
    RequireNearTorsionTest n, -92000#, TEST_FORCE_TOLERANCE, "Сумма сжатия бетона"
    RequireNearTorsionTest mx, -8784300#, TEST_MOMENT_TOLERANCE, "Момент начального бетона Mx"
    RequireNearTorsionTest my, -9519300#, TEST_MOMENT_TOLERANCE, "Момент начального бетона My"
    Dim tributaries As Variant: tributaries = Array(166.5, 176#, 94#, 106#, 140#, 135.5, 102#)
    For i = 1 To section.RebarCount
        section.RebarElementForSolver i, x, y, area
        force = (steel.GetStress(field.SteelStrain(i)) - concrete.GetStress(0#)) * area
        RequireNearTorsionTest force, 100# * CDbl(tributaries(i - 1)), TEST_FORCE_TOLERANCE, "Продольная сила " & section.RebarID(i)
        n = n + force: mx = mx + force * y: my = my + force * x
    Next i
    RequireNearTorsionTest n, 0#, TEST_FORCE_TOLERANCE, "Независимая невязка N при чистом T"
    RequireNearTorsionTest mx, 0#, TEST_MOMENT_TOLERANCE, "Независимая невязка Mx при чистом T"
    RequireNearTorsionTest my, 0#, TEST_MOMENT_TOLERANCE, "Независимая невязка My при чистом T"
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет булево условие с понятным описанием сбоя.
Private Sub RequireTorsionTest(ByVal passed As Boolean, ByVal message As String)
    If Not passed Then Err.Raise vbObjectError + 5690, "modTestPlanarTorsionGeometry", message
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Регистрирует фактическое расхождение чисел при выходе за допуск.
Private Sub RequireNearTorsionTest(ByVal actual As Double, ByVal expected As Double, ByVal tolerance As Double, ByVal label As String)
    RequireTorsionTest Abs(actual - expected) <= tolerance, label & ". Получено " & TorsionNumberTest(actual) & _
        ", ожидается " & TorsionNumberTest(expected) & "."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает продолжительность этапа независимо от перехода через полночь.
Private Function ElapsedTorsionTest(ByVal started As Double) As Double
    ElapsedTorsionTest = Timer - started
    If ElapsedTorsionTest < 0# Then ElapsedTorsionTest = ElapsedTorsionTest + 86400#
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет десятичную точку для независимого чтения нативного отчёта.
Private Function TorsionNumberTest(ByVal value As Double) As String
    TorsionNumberTest = Trim$(Str$(value))
End Function
