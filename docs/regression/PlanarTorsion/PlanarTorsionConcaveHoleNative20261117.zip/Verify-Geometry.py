"""Verify the isolated geometry test sources and the single native VBA report."""
import argparse
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
MODULE = "modTestPlanarTorsionGeometry"
DRAFT = "docs/regression/Diagnostic.xlsm"
REPORT = "Native/Geometry.txt"


def require(condition,message):
    if not condition:
        raise ValueError(message)


def take(path):
    return json.loads((ROOT/path).read_text(encoding="utf-8-sig"))


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def inputs():
    data=take("Preparation.json")
    for name,value in data["files"].items():
        require(digest(ROOT/name)==value,f"Staged dependency identity {name}")
    for book in ("workbook/output/RC_Section_NDM.xlsm",data["candidate_path"]):
        require(digest(ROOT/book)==data["candidate_sha256"],f"Immutable candidate identity {book}")
    return data


def fields(report,marker):
    lines=[line for line in report.splitlines() if line.startswith(marker+"|")]
    require(len(lines)==1,marker)
    return dict(pair.split("=",1) for pair in lines[0].split("|")[1:])


def verify(data):
    native_report=(ROOT/REPORT).read_text(encoding="utf-8-sig")
    require(native_report.count("TOTAL_PLANAR_TORSION_GEOMETRY_TEST: passed=1; failed=0")==1 and
            "TORSION_L_HOLE_FAIL" not in native_report,"successful native VBA marker")
    update=take("docs/regression/CodeUpdate.json")
    compile_closure=take("CompileClosure.json")
    require(update["Compiled"] and not update["ProductionChanged"] and update["Modules"]==[MODULE] and
            update["ProductionSHA256"]==data["candidate_sha256"],"compiled test-only macro")
    require(compile_closure["State"]=="Absent" and compile_closure["PID"]>0,"compilation process closed")
    compiled=digest(ROOT/DRAFT)
    require(compiled==update["WorkbookSHA256"] and native_report.count(f"SOURCE_SHA256: {compiled}")==1,"actual workbook identity")
    run=take("Native/RunReceipt.json")
    closure=take(REPORT+".ProcessClosure.json")
    require(run["native_exit"]==0 and closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"]==0 and
            closure["RunnerCleanupValid"] and not closure["OrdinaryPathKilledAnything"],"owned process closed without timeout")
    final=closure["Closure"]["FinalState"]
    require(final["State"]=="Absent" and final["PID"]!=compile_closure["PID"],"distinct native owner closed")
    require(native_report.count(f"TEST_EXCEL_PROCESS: id={final['PID']}; startTicks={final['StartTicksUTC']}")==1,"native owner receipt")
    geo=fields(native_report,"TORSION_L_HOLE")
    require([int(geo[x]) for x in ("concrete","steel","compressed")]==[148,7,107],"exact element counts")
    for key,value,tol in (("area_mm2",40800.,1e-7),("perimeter_mm",920.,1e-7),("flow_N_per_mm",100.,1e-8),("hoop_MPa",119.366207318922,1e-8)):
        require(abs(float(geo[key])-value)<=tol,key)
    residual=fields(native_report,"TORSION_L_HOLE_FORCE")
    for key,tol in (("N_N",1e-7),("Mx_Nmm",1e-4),("My_Nmm",1e-4)):
        require(abs(float(residual[key]))<=tol,key)
    bench={key:float(value) for key,value in fields(native_report,"TORSION_L_HOLE_BENCH").items()}
    require(set(bench)=={"mesh_s","preparation_s","evaluation_and_solve_s","total_s"} and all(isfinite(x) and x>=0 for x in bench.values()),"actual benchmark")
    inverse=fields(native_report,"TORSION_STEEL_INVERSE")
    require(inverse["accepted"]=="13" and inverse["rejected"]=="2" and
            0<=float(inverse["max_strain_error"])<=2e-15 and 0<=float(inverse["max_stress_error_MPa"])<=1e-10,
            "actual steel diagram inversion, both signs and exact origin")
    report={"checks":"PASS","candidate_sha256":data["candidate_sha256"],"compiled_test_sha256":compiled,"geometry":geo,
            "residuals":residual,"benchmarks":bench,"steel_inverse":inverse,"native_wall_seconds":run["wall_seconds"],"compile_owner":compile_closure,
            "native_owner":final,"raw_report_sha256":digest(ROOT/REPORT)}
    (ROOT/"VerificationGeometry.json").write_bytes((json.dumps(report,indent=2,sort_keys=True)+"\n").encode("utf-8"))
    print("PLANAR_TORSION_L_HOLE_NATIVE_PASS",geo["flow_N_per_mm"],geo["compressed"])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    args=parser.parse_args()
    data=inputs()
    if args.inputs_only:
        require(digest(ROOT/DRAFT)==data["candidate_sha256"],"unmodified D test copy")
        print("PLANAR_TORSION_L_HOLE_FROZEN_INPUTS_PASS",data["candidate_sha256"],len(data["files"]))
    else:
        verify(data)


if __name__=="__main__":
    main()
