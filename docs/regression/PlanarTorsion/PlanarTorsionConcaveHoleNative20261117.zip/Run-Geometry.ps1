# Компилирует один тестовый модуль и запускает один тест в частной книге на D.
param([switch]$Preflight)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$draft='docs/regression/Diagnostic.xlsm'
$report='Native/Geometry.txt'
$module='modTestPlanarTorsionGeometry'
$macro=$module+'.RunPlanarTorsionGeometryTests'
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$tempBefore=$env:TEMP
$tmpBefore=$env:TMP
Push-Location -LiteralPath $root
try {
    & python -B -X utf8 'Verify-Geometry.py' --inputs-only
    if ($LASTEXITCODE -ne 0) {throw 'Не подтверждена частная книга или источники.'}
    . (Join-Path $root 'tools/build_workbook/GeometryExampleSupport.ps1')
    . (Join-Path $root 'tools/build_workbook/SettingsCatalog.ps1')
    $null=@(Get-GeometrySettingsCatalog)
    $areas=@(Get-WorkbookPrintAreas (Resolve-Path -LiteralPath $draft).Path)
    if (!$areas.Count -or $script:NormativeFormulaCatalog.Count -eq 0) {throw 'Не прочитаны данные поддержки сборки.'}
    Write-Output ('PLANAR_TORSION_GEOMETRY_PREFLIGHT_PASS print_areas='+$areas.Count)
    if ($Preflight) {return}
    if ((Test-Path -LiteralPath $report) -or (Test-Path -LiteralPath 'Compile.log')) {throw 'Эта частная копия уже использовалась.'}
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Путь к временной книге превышает допустимый для Excel.'
    }
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw -Encoding UTF8 | ConvertFrom-Json
    Assert-IsolatedOfficeReady 'BeforeConcaveTorsionCompile'
    try {
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft -ModuleNames @($module) |
            Tee-Object -FilePath 'Compile.log'
    }
    finally {
        if ((Test-Path -LiteralPath 'Compile.log') -and (Select-String -LiteralPath 'Compile.log' -Pattern '^OWNED_EXCEL:' -Quiet)) {
            Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
        }
    }
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw -Encoding UTF8 | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw -Encoding UTF8 | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $compiled.ProductionSHA256 -cne $prep.candidate_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or ($compiled.Modules -join ',') -cne $module -or
        $closure.State -cne 'Absent') {throw 'Компиляция одного тестового модуля не подтверждена.'}
    Assert-IsolatedOfficeReady 'BeforeConcaveTorsionGeometryNative'
    $clock=[Diagnostics.Stopwatch]::StartNew()
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $draft `
        -ReportPath $report -Macro $macro -Mode No -TimeoutSeconds $prep.timeout_seconds -FailFast
    $exit=$LASTEXITCODE
    $clock.Stop()
    [ordered]@{native_exit=$exit;wall_seconds=$clock.Elapsed.TotalSeconds;macro=$macro} | ConvertTo-Json |
        Set-Content -LiteralPath 'Native/RunReceipt.json' -Encoding UTF8
    & python -B -X utf8 'Verify-Geometry.py'
    if ($LASTEXITCODE -ne 0 -or $exit -ne 0) {throw 'Независимая проверка нативного случая не прошла.'}
}
finally {
    $env:TEMP=$tempBefore
    $env:TMP=$tmpBefore
    Pop-Location
}
