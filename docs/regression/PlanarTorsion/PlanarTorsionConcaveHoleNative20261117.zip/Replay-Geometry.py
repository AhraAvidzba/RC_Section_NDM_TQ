"""Replay the sealed L/steel case from receipts and an independent oracle, without Excel."""

import argparse
from hashlib import sha256
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
WORKBOOK = "978178F2AE2E49F0338405BE712EBEA7D7A1FA87922FD9ACBFA8402B50315344"
COMPILED = "051A432B1D1237660E14E44CA2E823F1FF56684767F51141D759BB397C9FBFF2"
EXPORT = "5409BBBDF5E99306F1927D784D3132BDA9CDF488BC363B8479790FE0ED7CD862"
PREP = "AD74866EA6B2D47BBFE2A893FFF784E2C81EC5A44332A23DE3D86F7A67B9A7AF"
RAW = "B78D1E8ADB0DF3B5E69CF7FACE1AF0045B802A776EDC627AEE58F1D49B4306AA"
VERIFIED = "64017DB9458CEDDE9FDCB72051AB9C400B86C73CD9406C655FAFF97CC4ED632C"


def import_source(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT / file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def require(condition, label):
    if not condition:
        raise ValueError(label)


def raw(name):
    return (ROOT / name).read_text(encoding="utf-8-sig")


def read(name):
    return json.loads(raw(name))


def exact_receipts():
    manifest = read("Manifest.json")
    require({name for name in manifest} == {str(path.relative_to(ROOT)).replace("\\", "/") for path in ROOT.rglob("*")
                                            if path.is_file() and path.name != "Manifest.json" and "__pycache__" not in path.parts},
            "Archive manifest inventory")
    for name, value in manifest.items():
        require(sha(ROOT / name) == value, f"Manifest digest {name}")
    for name, value in (("Preparation.json", PREP), ("Native/Geometry.txt", RAW), ("VerificationGeometry.json", VERIFIED)):
        require(sha(ROOT / name) == value, f"Pinned digest {name}")

    preparation = read("Preparation.json")
    require(preparation["candidate_sha256"] == WORKBOOK and preparation["base_export_sha256"] == EXPORT and
            preparation["build_receipt_sha256"] == manifest["BuildReceipt.json"], "Test inputs point to exact built workbook")
    for file in ("Verify-Geometry.py", "Run-Geometry.ps1", "tests/modTestPlanarTorsionGeometry.bas"):
        require(preparation["files"][file] == manifest[file], f"Exact original native fixture file {file}")

    build = read("BuildReceipt.json")
    source = read("SourceAgreement.json")
    require(build["Status"] == "PASS" and build["Compile"] and build["Closure"] == "Absent" and
            build["WorkbookSHA256"] == WORKBOOK and build["ExportSHA256"] == EXPORT and
            build["InputManifestSHA256"] == manifest["Inputs.json"], "Exact workbook build and source export receipts")
    verified = {item["module"]:item["source_sha256"] for item in source["verified"]}
    require(source["status"] == "PASS" and (source["before"], source["after"], source["unchanged"], source["changed"], source["added"])
            == (187, 195, 175, 12, 8) and len(verified) == 20 and
            {"CTorsionHoopGeometry", "CTorsionConcreteBalance", "CTorsionLongitudinalDemand", "CTorsionPlanarPreparation",
             "CMaterialDiagram", "CSectionSolver"}.issubset(verified), "Compiled VBA source agreement")
    return manifest


def native_receipts():
    update = read("docs/regression/CodeUpdate.json")
    compile_owner = read("CompileClosure.json")
    run_owner = read("Native/Geometry.txt.Ownership.json")
    closure = read("Native/Geometry.txt.ProcessClosure.json")
    cleanup = read("Native/Geometry.txt.RunnerCleanup.json")
    native = read("Native/RunReceipt.json")
    report = raw("Native/Geometry.txt")
    require(update["Compiled"] and not update["ProductionChanged"] and update["Modules"] == ["modTestPlanarTorsionGeometry"] and
            not update["RetiredModules"] and not update["EntryPointNames"] and
            update["ProductionSHA256"] == WORKBOOK and update["WorkbookSHA256"] == COMPILED, "Test-only recompilation")
    require(compile_owner["State"] == "Absent" and raw("Compile.log").count(
            f"OWNED_EXCEL: id={compile_owner['PID']}; utcStartTicks={compile_owner['StartTicksUTC']}") == 1,
            "Compiler process closed and identity matched")
    final = closure["Closure"]["FinalState"]
    require(closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"] == native["native_exit"] == 0 and
            closure["RunnerCleanupValid"] and not closure["OrdinaryPathKilledAnything"] and
            final["State"] == "Absent" and final["PID"] != compile_owner["PID"] and cleanup["QuitSucceeded"] and
            run_owner["VerifiedNewOwner"] and run_owner["BeforeWorkbookOpen"] and run_owner["SourceSHA256"] == COMPILED and
            final["PID"] == run_owner["PID"] == cleanup["PID"] and
            final["StartTicksUTC"] == run_owner["StartTicksUTC"] == cleanup["StartTicksUTC"], "Native ownership and closure")
    require(report.count(f"SOURCE_SHA256: {COMPILED}") == 1 and
            report.count(f"TEST_EXCEL_PROCESS: id={final['PID']}; startTicks={final['StartTicksUTC']}") == 1 and
            report.count("SOURCE_UNCHANGED: True") == 1 and report.count("WATCHDOG_COMPLETED: exit=0; source unchanged=True") == 1 and
            report.count("TOTAL_PLANAR_TORSION_GEOMETRY_TEST: passed=1; failed=0") == 1 and "TORSION_L_HOLE_FAIL" not in report,
            "Raw output identifies exact workbook, test result and closed owner")
    summary = read("VerificationGeometry.json")
    require(summary["checks"] == "PASS" and summary["candidate_sha256"] == WORKBOOK and summary["compiled_test_sha256"] == COMPILED and
            summary["raw_report_sha256"] == RAW and summary["native_wall_seconds"] == native["wall_seconds"] and
            summary["compile_owner"] == compile_owner and summary["native_owner"] == final, "Replayed native verification summary")
    return report, summary


def physical_replay(report, summary):
    original = import_source("sealed_verifier", "Verify-Geometry.py")
    independent = import_source("rational_oracle", "Oracle-Geometry.py").oracle()
    geo = original.fields(report, "TORSION_L_HOLE")
    force = original.fields(report, "TORSION_L_HOLE_FORCE")
    inverse = original.fields(report, "TORSION_STEEL_INVERSE")
    require(summary["geometry"] == geo and summary["residuals"] == force and summary["steel_inverse"] == inverse and
            summary["benchmarks"] == {key:float(value) for key,value in original.fields(report, "TORSION_L_HOLE_BENCH").items()},
            "Replayed raw rows match native receipt")
    for key in ("concrete", "steel", "compressed", "area_mm2", "perimeter_mm", "flow_N_per_mm"):
        require(float(geo[key]) == independent[key], f"Exact independent geometry {key}")
    require(abs(float(geo["hoop_MPa"]) - independent["hoop_MPa"]) <= 1e-8, "Independent hoop stress")
    require(independent["steel_resultants"] == [92000, 8784300, 9519300] and independent["knot_split"] == [51, 56],
            "Independent reference sum and material knot coverage")
    for key, tol in (("N_N", 1e-7), ("Mx_Nmm", 1e-4), ("My_Nmm", 1e-4)):
        require(abs(float(force[key])) <= tol, f"Native force or moment residual {key}")
    require(inverse["accepted"] == "13" and inverse["rejected"] == "2" and
            0 <= float(inverse["max_strain_error"]) <= 2e-15 and 0 <= float(inverse["max_stress_error_MPa"]) <= 1e-10,
            "Both steel signs, knots and rejection outside the range")
    return geo, inverse


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, help="optionally verify a separately retained original workbook")
    options = parser.parse_args()
    exact_receipts()
    if options.candidate is not None:
        require(sha(options.candidate) == WORKBOOK, "Supplied native workbook identity")
    geo, inverse = physical_replay(*native_receipts())
    print("PLANAR_TORSION_L_HOLE_DETACHED_PASS", WORKBOOK[:8], geo["flow_N_per_mm"], geo["compressed"],
          f"steel={inverse['accepted']}+{inverse['rejected']}")


if __name__ == "__main__":
    main()
