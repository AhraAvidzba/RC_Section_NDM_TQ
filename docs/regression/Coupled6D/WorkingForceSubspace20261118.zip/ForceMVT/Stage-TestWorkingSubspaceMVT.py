"""ДЛЯ ТЕСТОВ: проверяет автоматический общий прогноз на собственной уточнённой истории MVT2."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re


def TestStage(repo, root, control=False):
    """Сохраняет исследовательский материал и квадратуру; ручной прогноз из теста исключён."""
    here = Path(__file__).resolve().parent
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/ClosedASDReducedNative20261118')
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, expected in prep['inputs'].items():
        raw = (template/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, name
        files[name] = raw
    for module, method in (('CCubicSplineBasis', 'QuadraticCoefficients'),
                           ('CCoupledSectionQuadrature', 'CopyQuadraticCoefficients'),
                           ('CCoupledElasticState', 'CopyQuadraticProjection')):
        relative = 'src/Solver/'+module+'.cls'
        code = (repo/relative).read_text('utf-8-sig')
        addition, = re.findall(r'(?ms)^Friend Sub '+method+r'\(.*?^End Sub$', code)
        private = files[relative].decode('utf-8-sig').replace('\r\n', '\n')
        assert 'Friend Sub '+method+'(' not in private
        header = "\n' Рабочее отображение квадратичных полиномов в подготовленный базис сечения.\n"
        files[relative] = (private+header+addition+'\n').replace('\n', '\r\n').encode('utf-8-sig')
    relative = 'src/Solver/CCoupledElasticState.cls'
    addition, = re.findall(r'(?ms)^Friend Property Get HasRefinedField\(.*?^End Property$', (repo/relative).read_text('utf-8-sig'))
    private = files[relative].decode('utf-8-sig').replace('\r\n', '\n')
    files[relative] = (private+"\n' Сообщает о внутренних узлах геометрического базиса сверх одного интервала.\n"+addition+'\n').replace('\n', '\r\n').encode('utf-8-sig')
    for module in ('CCoupledFieldSubspace', 'CCoupledNewtonSolver'):
        relative = 'src/Solver/'+module+'.cls'
        files[relative] = (repo/relative).read_bytes()
    old, new = 'modTestMVT2ReducedTest', 'modTestMVT2WorkingSubspaceTest'
    code = files.pop('tests/'+old+'.bas').decode('utf-8-sig').replace('\r\n', '\n')
    code = code.replace(old, new).replace('RunTestMVT2ReducedTest', 'RunTestMVT2WorkingSubspaceTest')
    code = code.replace('TOTAL_MVT2_REDUCED_TEST', 'TOTAL_MVT2_WORKING_SUBSPACE_TEST')
    code = code.replace('    Dim predictor As New CCoupledReducedPredictorTest\n    predictor.InitializeTest operators\n', '')
    start = code.index('Private Function RunReducedMVT2Test(')
    before, body = code[:start], code[start:]
    first = body.index('        If Not solved Then\n            solver.DiscardStep\n            solver.CopyAccepted acceptedBefore')
    last = body.index('        AddExperimentTraceTest report, tracePath, "REDUCED_FULL;', first)
    body = body[:first]+body[last:]
    body = body.replace('    Dim predicted() As Double, after() As Double, external() As Double, actual() As Double, expected(1 To 6) As Double',
                        '    Dim actual() As Double, expected(1 To 6) As Double')
    body = body.replace('Dim phase As String, row As String, solved As Boolean, auxiliary As Boolean, residual As Double',
                        'Dim phase As String, row As String, solved As Boolean, residual As Double')
    code = before+body
    if control:
        needle = '    RunReducedMVT2Test = True'
        assert code.count(needle) == 1
        code = code.replace(needle, '    RunReducedMVT2Test = RunWorkingSubspaceControlTest(solver, operators, previous, previousQ, currentQ, report, tracePath, stations)')
        continuation = (here/'TestNativeTransferredControl.bas.txt').read_text('utf-8')
        continuation = continuation.replace('RunTransferredControlTest', 'RunWorkingSubspaceControlTest').replace('phase = "TransferredControl"', 'phase = "WorkingSubspaceControl"')
        code += '\n'+continuation
    assert 'predictor.' not in code and 'New CCoupledReducedPredictorTest' not in code
    files['tests/'+new+'.bas'] = code.replace('\n', '\r\n').encode('utf-8-sig')
    files.pop('tests/CCoupledReducedPredictorTest.cls')
    driver = files['Run-Native.ps1'].decode('utf-8-sig').replace(old, new)
    driver = driver.replace('RunTestMVT2ReducedTest', 'RunTestMVT2WorkingSubspaceTest')
    driver = driver.replace("'CCoupledReducedPredictorTest'", "'CCoupledFieldSubspace'")
    files['Run-Native.ps1'] = driver.encode('utf-8-sig')
    files['docs/regression/Diagnostic.xlsm'] = files['workbook/output/RC_Section_NDM.xlsm']
    files[Path(__file__).name] = Path(__file__).read_bytes()
    prep['test_scope'] = 'automatic working quadratic predictor; own 38-state fine history; six force targets 65..75kN; no manual auxiliary solver'
    if control:
        prep['test_scope'] += '; then 30 native first-bar control steps'
        files['TestNativeTransferredControl.bas.txt'] = (here/'TestNativeTransferredControl.bas.txt').read_bytes()
    prep['same_total_iteration_budget'] = True
    prep['inputs'] = {name: sha256(raw).hexdigest().upper() for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    root.mkdir()
    for directory in ('Native', 'Temp', 'tests'):
        (root/directory).mkdir()
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('AUTOMATIC WORKING MVT SUBSPACE INPUTS READY', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--control', action='store_true')
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.control)
