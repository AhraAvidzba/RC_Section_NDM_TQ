"""ДЛЯ ТЕСТОВ: готовит чистую книгу для проверки общего рабочего квадратичного прогноза."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output


def TestStage(repo, root):
    """Копирует пять численных компонентов, сохраняя установленную книгу, листы, данные и модели материалов."""
    here = Path(__file__).resolve().parent
    template = here.parent/'krylov/KrylovFallbackBundle/Stock'
    original = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, expected in original.items():
        if name.startswith('tools/') or name == 'Guard-IsolatedOffice.ps1':
            file = template/name
            if not file.exists():
                file = Path('D:/CodexScratch/RC_Section_NDM_TQ/VBAFlowIntegratedCore')/name
            raw = file.read_bytes()
            assert sha256(raw).hexdigest().upper() == expected, name
            files[name] = raw
    source = (repo/'workbook/output/RC_Section_NDM.xlsm').read_bytes()
    expected = 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
    assert sha256(source).hexdigest().upper() == expected
    files['workbook/output/RC_Section_NDM.xlsm'] = source
    files['docs/regression/Diagnostic.xlsm'] = source
    modules = ('CCubicSplineBasis', 'CCoupledSectionQuadrature', 'CCoupledElasticState',
               'CCoupledFieldSubspace', 'CCoupledNewtonSolver')
    for name in modules:
        relative = 'src/Solver/'+name+'.cls'
        raw = (repo/relative).read_bytes()
        assert max(map(len, raw.decode('utf-8-sig').splitlines())) < 1024, name
        files[relative] = raw
    for name in (Path(__file__).name, 'Run-TestSubspaceCandidate.ps1'):
        files[name] = (here/name).read_bytes()
    root.mkdir()
    for directory in ('Native', 'Temp', 'tests'):
        (root/directory).mkdir()
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    prep = {'base_stage_commit': check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
            'source_book_sha256': expected, 'modules': list(modules), 'maximum_auxiliary_iterations': 8,
            'same_total_iteration_budget': True, 'auxiliary_state_committed': False,
            'inputs': {name: sha256(raw).hexdigest().upper() for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('WORKING SUBSPACE CANDIDATE INPUTS READY', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
