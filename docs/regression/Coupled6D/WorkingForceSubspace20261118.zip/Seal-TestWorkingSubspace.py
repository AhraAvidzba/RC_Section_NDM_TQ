"""ДЛЯ ТЕСТОВ: закрепляет общий силовой прогноз и нативные сравнения в журнале доказательств."""

from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED


def TestSeal(repo, root):
    """Добавляет переносимые проверки без замены прежних свидетельств и без объявления полной приёмки."""
    name = 'WorkingForceSubspace20261118'
    proof = json.loads((root/'WorkingForceMechanicsChecks.json').read_bytes())
    native = json.loads((root/'WorkingForceNativeChecks.json').read_bytes())
    assert proof['mvt']['ForceMVT']['states'] == 74 and len(native['native']) == 6
    assert proof['stock']['ForceStock']['trace_entries'] == 136
    assert not proof['physical_capacity_certified'] and not proof['installed_workbook_changed']
    for filename, expected in json.loads((root/'WorkingSources.json').read_bytes()).items():
        assert sha256((repo/filename).read_bytes()).hexdigest().upper() == expected
    target = repo/'docs/regression/Coupled6D'/(name+'.zip')
    with target.open('xb') as stream, ZipFile(stream, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for file in sorted(root.rglob('*')):
            if not file.is_file():
                continue
            assert '__pycache__' not in file.parts and file.suffix != '.pyc'
            info = ZipInfo(file.relative_to(root).as_posix(), date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, file.read_bytes(), compresslevel=9)
    assert target.stat().st_size < 100*2**20, target.stat().st_size
    fingerprint = sha256(target.read_bytes()).hexdigest().upper()
    relative = Path('docs/reports/Coupled6DEvidence.json')
    original = check_output(['git', 'cat-file', 'blob', 'HEAD:'+relative.as_posix()]).decode('utf-8').replace('\r\n', '\n')
    manifest = json.loads(original)
    assert json.loads((repo/relative).read_bytes()) == manifest and name not in manifest['archives']
    last_name, last_value = list(manifest['archives'].items())[-1]
    needle = '    '+json.dumps(last_name)+': '+json.dumps(last_value)
    assert original.count(needle) == 1
    updated = original.replace(needle, needle+',\n    '+json.dumps(name)+': '+json.dumps(fingerprint))
    cases = []
    for scope, output, message in (
        ('native', 'WorkingForceNativeChecks.json', 'WORKING FORCE SUBSPACE NATIVE VBA AND CLOSED EXCEL VERIFIED; CAPACITY OPEN'),
        ('mechanics', 'WorkingForceMechanicsChecks.json', 'WORKING FORCE SUBSPACE EQUILIBRIUM AND STOCK REGRESSIONS VERIFIED; PHYSICAL CAPACITY OPEN')):
        cases.append({'id': 'working-force-subspace-'+scope, 'journal_section': 595, 'archive': name,
                      'script': 'Verify-TestWorkingSubspace.py',
                      'arguments': ['--repo', '{repo}', '--root', '.', '--scope', scope, '--out', output],
                      'stdout_contains': message,
                      'outputs': {output: sha256((root/output).read_bytes()).hexdigest().upper()}})
    marker = '\n  ],\n  "frozen_repositories": {'
    assert updated.count(marker) == 1
    block = ',\n'.join('\n'.join('    '+line for line in json.dumps(case, ensure_ascii=False, indent=2).splitlines()) for case in cases)
    updated = updated.replace(marker, ',\n'+block+marker)
    manifest['archives'][name] = fingerprint
    manifest['cases'].extend(cases)
    assert json.loads(updated) == manifest
    (repo/relative).write_bytes(updated.replace('\n', '\r\n').encode())
    print('WORKING FORCE SUBSPACE SEALED', target.stat().st_size, fingerprint, len(manifest['archives']), len(manifest['cases']))


if __name__ == '__main__':
    TestSeal(Path.cwd(), Path('D:/CodexScratch/RC_Section_NDM_TQ/WorkingForceSubspaceEvidence20261118'))
