"""ДЛЯ ТЕСТОВ: сохраняет рабочие исходники, нативные сравнения и точные CFB общего прогноза."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED


TestCases = {'UngatedStock': 'WorkingSubspaceCandidate02202611118',
             'UngatedMVT': 'WorkingSubspaceMVT20261118',
             'RefinedStock': 'WorkingSubspaceRefined20261118',
             'RefinedMVTFailed': 'WorkingSubspaceMVTRefined0220261118',
             'ForceStock': 'ForceSubspaceStock20261118',
             'ForceMVT': 'ForceSubspaceMVT0220261118'}


def TestCopy(source, target):
    """Сохраняет точные байты, не заменяя другой результат существующего каталога."""
    raw = source.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw
    else:
        target.write_bytes(raw)


def TestXML(source, target):
    """Сохраняет полный OOXML результата отдельно от VBA; это проверочные данные, не самостоятельная XLSM."""
    with ZipFile(source) as original, target.open('xb') as stream, ZipFile(stream, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(original.namelist()):
            if name == 'xl/vbaProject.bin':
                continue
            info = ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, original.read(name), compresslevel=9)


def TestCollect(repo, root):
    """Включает только завершённые собственные запуски; исходная установка остаётся отдельной неизменной книгой."""
    here = Path(__file__).resolve().parent
    root.mkdir()
    for key, name in TestCases.items():
        source, target = Path('D:/CodexScratch/RC_Section_NDM_TQ')/name, root/key
        prep = json.loads((source/'Preparation.json').read_bytes())
        for relative, expected in prep['inputs'].items():
            raw = (source/relative).read_bytes()
            assert sha256(raw).hexdigest().upper() == expected, (key, relative)
            if not relative.endswith('.xlsm'):
                TestCopy(source/relative, target/relative)
        reports = ('Core', 'Stock') if key.endswith('Stock') else ('MVTGaussMixed',)
        for report in reports:
            closure = json.loads((source/'Native'/(report+'.txt.ProcessClosure.json')).read_text('utf-8-sig'))
            if key.endswith('Failed'):
                assert closure['Stage'] == 'TIMEOUT' and not closure['Passed'] and closure['After']['State'] == 'Absent'
                assert closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout']
            else:
                assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['Closure']['FinalState']['State'] == 'Absent'
        for relative in ('Preparation.json', 'Compile.log', 'CompileClosure.json', 'Run.ndjson', 'docs/regression/CodeUpdate.json'):
            TestCopy(source/relative, target/Path(relative).name)
        for file in (source/'Native').rglob('*'):
            if file.is_file():
                TestCopy(file, target/'Native'/file.relative_to(source/'Native'))
        if key.endswith('Failed'):
            log = (source/'Native/MVTGaussMixed.txt').read_text('utf-8-sig')
            fixture, = re.findall(r'^FIXTURE: ([^\r\n]+)$', log, re.M)
            folder = Path(fixture).parent.resolve()
            assert folder.is_relative_to((source/'Temp').resolve()) and folder.name.startswith('RC_NDM_ModeSuite_')
            capture = {}
            for suffix, name in (('.Operators.csv', 'Operators.csv'), ('.Tensor.csv', 'MVTGaussMixed.Tensor.csv'), ('', 'MVTGaussMixed.csv')):
                file = folder/('MVT2GaussSpan.csv'+suffix)
                TestCopy(file, target/'Native'/name)
                capture[name] = {'path': str(file), 'sha256': sha256(file.read_bytes()).hexdigest().upper()}
            (target/'FailedCapture.json').write_bytes((json.dumps(capture, indent=2, sort_keys=True)+'\n').encode())
        compiler = json.loads((source/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
        book = source/'docs/regression/Diagnostic.xlsm'
        assert sha256(book.read_bytes()).hexdigest().upper() == compiler['WorkbookSHA256']
        with ZipFile(book) as archive:
            raw = archive.read('xl/vbaProject.bin')
        (target/'CompiledVBA.bin').write_bytes(raw)
        (target/'CompiledVBA.json').write_bytes((json.dumps({'bytes': len(raw), 'sha256': sha256(raw).hexdigest().upper()}, indent=2)+'\n').encode())
        if key.endswith('Stock'):
            log = (source/'Native/Stock.txt').read_text('utf-8-sig')
            saved, = re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$', log, re.M)
            saved = Path(saved).resolve()
            assert saved.is_relative_to((source/'Temp').resolve()) and saved.name == 'RC_Section_NDM_saved.xlsm'
            TestXML(saved, target/'SavedWorkbookXML.zip')
            (target/'SavedWorkbook.json').write_bytes((json.dumps({'path': str(saved), 'sha256': sha256(saved.read_bytes()).hexdigest().upper(),
                'xml_zip_sha256': sha256((target/'SavedWorkbookXML.zip').read_bytes()).hexdigest().upper()}, indent=2)+'\n').encode())
    for name in ('Operators.csv', 'MVTGaussMixed.csv', 'MVTGaussMixed.Tensor.csv', 'MVTGaussMixed.txt'):
        TestCopy(here/'ResolutionEvidenceBundle/G5S2/Native'/name, root/'Prefix/Native'/name)
    scripts = ('Probe-TestASDMaterialSteps.py', 'Probe-TestASDClosure.py', 'TestResolutionSection.py',
               'Inspect-TestResolutionVBA.py', 'Verify-TestASDResolution.py', 'Verify-TestReducedEvidence.py',
               'Collect-TestWorkingSubspace.py', 'Verify-TestWorkingSubspace.py', 'Restore-TestWorkingSubspace.py',
               'Stage-TestSubspaceCandidate.py', 'Run-TestSubspaceCandidate.ps1', 'Stage-TestWorkingSubspaceMVT.py')
    for name in scripts:
        TestCopy(here/name, root/name)
    TestCopy(here.parent/'krylov/KrylovFallbackBundle/ReadWorkbookCurve.py', root/'ReadWorkbookCurve.py')
    expected = {}
    for name in ('CCubicSplineBasis', 'CCoupledSectionQuadrature', 'CCoupledElasticState', 'CCoupledFieldSubspace', 'CCoupledNewtonSolver'):
        relative = 'src/Solver/'+name+'.cls'
        TestCopy(repo/relative, root/'WorkingSources'/relative)
        expected[relative] = sha256((repo/relative).read_bytes()).hexdigest().upper()
    (root/'WorkingSources.json').write_bytes((json.dumps(expected, indent=2, sort_keys=True)+'\n').encode())
    TestCopy(Path('D:/CodexScratch/RC_Section_NDM_TQ/ReducedPredictorEvidence20261118/SourceBook.json'), root/'SourceBook.json')
    base = Path('D:/CodexScratch/RC_Section_NDM_TQ/ClosedASDG5S220261118/src/Solver/CCoupledNewtonSolver.cls')
    assert sha256(base.read_bytes()).hexdigest().upper() == 'E960D4DDFB01B4FECA54472901A3A9A4E5BD9B7765CEA780E621E15BFC9600A7'
    TestCopy(base, root/'BaseNewton.cls')
    (root/'Cases.json').write_bytes((json.dumps(TestCases, indent=2, sort_keys=True)+'\n').encode())
    print('WORKING SUBSPACE NATIVE EVIDENCE COLLECTED', len(TestCases))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
