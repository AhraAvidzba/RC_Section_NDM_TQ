"""ДЛЯ ТЕСТОВ: восстанавливает чистые входы одной нативной проверки рабочего подпространства."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestRestore(repo, root, key, destination):
    """Возвращает подготовленную исходную книгу и файлы, не копируя результаты завершённого расчёта."""
    source, digest = run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    prep = json.loads((root/key/'Preparation.json').read_bytes())
    assert prep['source_book_sha256'] == digest and not destination.exists()
    destination.mkdir()
    for name, expected in prep['inputs'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        raw = source if name == 'workbook/output/RC_Section_NDM.xlsm' else (root/key/relative).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, name
        path = destination/relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    for name in ('Native', 'Temp', 'tests', 'docs/regression'):
        (destination/name).mkdir(parents=True, exist_ok=True)
    (destination/'docs/regression/Diagnostic.xlsm').write_bytes(source)
    (destination/'Preparation.json').write_bytes((root/key/'Preparation.json').read_bytes())
    assert not (destination/'Compile.log').exists()
    print('CLEAN WORKING SUBSPACE INPUTS RESTORED', key)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--case', required=True)
    parser.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    assert args.case in json.loads((args.root/'Cases.json').read_bytes())
    TestRestore(args.repo.resolve(), args.root.resolve(), args.case, args.destination.resolve())
