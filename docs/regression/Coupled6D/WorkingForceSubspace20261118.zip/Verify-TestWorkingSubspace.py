"""ДЛЯ ТЕСТОВ: проверяет общее силовое подпространство, нативные регрессии и отклонённый деформационный вариант."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from xml.etree import ElementTree as ET
from zipfile import ZipFile

import numpy as np


def TestRead(path):
    """Читает точные протоколы Python и Windows PowerShell."""
    return json.loads(path.read_text('utf-8-sig'))


def TestBody(code, name):
    """Выделяет один существующий метод для проверки сохранности полного алгоритма."""
    result = re.findall(r'(?ms)^(?:Friend|Private|Public) Function '+name+r'\(.*?^End Function$', code)
    assert len(result) == 1, name
    return result[0]


def TestNative(repo, root, key, source, source_sha, helper, body, reader, gauss):
    """Сверяет весь фактический VBA, неизменные модули, закрытие Excel и состав направленных проверок."""
    folder = root/key
    prep, compiler = TestRead(folder/'Preparation.json'), TestRead(folder/'CodeUpdate.json')
    stock, timeout = key.endswith('Stock'), key.endswith('Failed')
    expected_modules = 5 if stock else 11
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and len(compiler['Modules']) == expected_modules
    assert compiler['ProductionSHA256'] == prep['source_book_sha256'] == source_sha
    for name, expected in prep['inputs'].items():
        raw = source if name == 'workbook/output/RC_Section_NDM.xlsm' else (folder/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, (key, name)
    assert TestRead(folder/'CompileClosure.json')['State'] == 'Absent'
    reports = ('Core', 'Stock') if stock else ('MVTGaussMixed',)
    summaries = {}
    for report in reports:
        log = (folder/'Native'/(report+'.txt')).read_text('utf-8-sig')
        closure = TestRead(folder/'Native'/(report+'.txt.ProcessClosure.json'))
        owner = TestRead(folder/'Native'/(report+'.txt.Ownership.json'))
        assert 'SOURCE_SHA256: '+compiler['WorkbookSHA256'] in log and 'RUNTIME ERROR:' not in log
        if timeout:
            assert closure['Stage'] == 'TIMEOUT' and not closure['Passed'] and closure['After']['State'] == 'Absent'
            assert closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout'] and 'WATCHDOG_FAILURE: timeout=240 sec;' in log
            identity = closure['Identity']
        else:
            assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['ChildExitCode'] == 0
            assert closure['Closure']['FinalState']['State'] == 'Absent' and 'WATCHDOG_FAILURE:' not in log
            identity = closure['Closure']['Identity']
        assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == compiler['WorkbookSHA256']
        assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
        totals = [(int(a), int(b)) for a, b in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', log, re.M)]
        if not timeout:
            assert totals and sum(b for _, b in totals) == 0
            if report == 'Core':
                assert len(totals) == 8 and sum(a for a, _ in totals) == 365
            elif report == 'Stock':
                assert totals == [(28, 0)]
                before, after = re.findall(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=([A-F0-9]+); equal=True;', log, re.M)[0]
                assert before == after
            else:
                assert 'CASE_FINISHED;MVTGaussMixed;True;' in log
        summaries[report] = {'passed_assertions': sum(a for a, _ in totals), 'scope_completed': not timeout}
    safety = [json.loads(row) for row in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert len(safety) == (3 if stock else 2)
    for state in safety:
        assert state['ramMiB'] >= 6500 and state['freeCommitGiB'] >= 6 and all(p['ProtectedUser'] for p in state['excel'])
    binary = (folder/'CompiledVBA.bin').read_bytes()
    pinned = TestRead(folder/'CompiledVBA.json')
    assert len(binary) == pinned['bytes'] and sha256(binary).hexdigest().upper() == pinned['sha256']
    _, actual = reader(helper['TestContainer'](binary))
    _, original = reader(BytesIO(source))
    assert set(actual) == set(original)|set(compiler['Modules'])
    untouched = 0
    for name, value in original.items():
        if name not in compiler['Modules']:
            try:
                a, b = body(value, name)[0], body(actual[name], name)[0]
            except IndexError:
                assert value == actual[name], (key, name)
            else:
                assert a == b, (key, name)
            untouched += 1
    conversions = {}
    for name in compiler['Modules']:
        files = [p for directory in ('src', 'tests') for p in (folder/directory).rglob(name+'.*') if p.suffix in ('.bas', '.cls')]
        assert len(files) == 1
        alias = 'modTestMVT2GaussSpan' if name.startswith('modTestMVT2') else name
        source_code = files[0].read_text('utf-8-sig')
        if stock and name == 'CCoupledSectionQuadrature':
            expected = body(source_code, alias)[0]
            assert expected.count('1e-7') == 1 and '1e-8' not in expected
            expected = expected.replace('1e-7', '0.0000001')
            changes = [{'kind': 'equivalent_literal', 'from': '1e-7', 'to': '0.0000001', 'count': 1}]
        else:
            expected, changes = helper['TestMVTCompilerBody'](body, source_code, alias)
        observed = body(actual[name], name)[0]
        expected, additions = gauss(expected, observed, name)
        comment = "' коэффициенты t и t² определяются симметрическими произведениями узлов."
        if name == 'CCubicSplineBasis' and comment in expected:
            assert expected.count(comment) == 1
            expected = expected.replace(comment, comment.replace('²', '?'))
            additions.append({'kind': 'superseded_candidate_comment_encoding_loss', 'from': comment, 'to': comment.replace('²', '?')})
        assert expected == observed, (key, name)
        if changes or additions:
            conversions[name] = changes+additions
    assert untouched == (222 if stock else 219) and len(actual) == (227 if stock else 230)
    return {'components': len(actual), 'unchanged_components': untouched, 'reports': summaries, 'conversions': conversions}


def TestProperties(path, curve):
    """Читает опубликованные статусы и усилия из фактического OOXML Results, не из сообщений теста."""
    with ZipFile(path) as book:
        data = ET.fromstring(book.read(curve['worksheet']))
        strings = [''.join(t.text or '' for t in item.findall('.//{*}t')) for item in ET.fromstring(book.read('xl/sharedStrings.xml'))]
        anchor = re.fullmatch(r"'?Results'?\!\$([A-Z]+)\$(\d+)", curve['named_anchor'])
        number = run_path(str(Path(__file__).with_name('ReadWorkbookCurve.py')))['column_number']
        base, first = number(anchor[1]), int(anchor[2])
        properties = {}
        for row in data.findall('.//{*}row'):
            if int(row.get('r')) < first:
                continue
            cells = {}
            for cell in row:
                match = re.match('[A-Z]+', cell.get('r', ''))
                value = cell.find('{*}v')
                if match and value is not None and value.text is not None:
                    cells[number(match[0])-base] = strings[int(value.text)] if cell.get('t') == 's' else value.text
            if cells.get(1) == 'HardShear' and 2 in cells:
                assert cells[2] not in properties
                properties[cells[2]] = cells.get(3, '')
    return properties


def TestVerify(repo, root, output, scope):
    """Проверяет рабочий численный этап; физические пределы и полная приёмка остаются открытыми."""
    if scope == 'native':
        source, digest = run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
        helper, body, reader = run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
        gauss = run_path(str(root/'Verify-TestASDResolution.py'))['TestGaussBody']
        cases = {key: TestNative(repo, root, key, source, digest, helper, body, reader, gauss) for key in TestRead(root/'Cases.json')}
        proof = {'native': cases, 'installed_workbook_changed': False, 'physical_capacity_certified': False}
        output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
        print('WORKING FORCE SUBSPACE NATIVE VBA AND CLOSED EXCEL VERIFIED; CAPACITY OPEN')
        return
    read_curve = run_path(str(root/'ReadWorkbookCurve.py'))['read_curve']
    stocks, sequence = {}, None
    for key in ('UngatedStock', 'RefinedStock', 'ForceStock'):
        folder = root/key
        saved = TestRead(folder/'SavedWorkbook.json')
        assert sha256((folder/'SavedWorkbookXML.zip').read_bytes()).hexdigest().upper() == saved['xml_zip_sha256']
        curve = read_curve(folder/'SavedWorkbookXML.zip')
        values = [(row[0], row[1], float(row[-1])) for row in curve['entries']]
        if sequence is None:
            sequence = values
        assert values == sequence
        properties = TestProperties(folder/'SavedWorkbookXML.zip', curve)
        assert properties['DirectStateStatus'] == 'OK' and properties['CapacityStatus'] == 'NumFail'
        assert properties['Coupled.Capacity.ResultCode'] == 'NUMERICAL_FAILURE'
        assert abs(float(properties['Coupled.Capacity.LowerLambda'])-1.10290889219566) < 1e-14
        for component in ('N', 'Mx', 'My', 'T', 'Qx', 'Qy'):
            assert properties.get('Coupled.Capacity.'+component+'Ultimate', '') == ''
        log = (folder/'Native/Stock.txt').read_text('utf-8-sig')
        seconds = float(re.findall(r'^TIMING_SECONDS: ([^ |]+)', log, re.M)[0])
        stocks[key] = {'seconds': seconds, 'trace_entries': len(values), 'confirmed_lower_lambda': float(properties['Coupled.Capacity.LowerLambda'])}
    summaries = {}
    replay = run_path(str(root/'TestResolutionSection.py'))['TestReplay']
    with TemporaryDirectory(dir=output.parent) as directory:
        temp = Path(directory)
        for key in ('UngatedMVT', 'RefinedMVTFailed', 'ForceMVT'):
            section, _, fields = replay(repo, root/key/'Native', temp/(key+'.json'), prefix_native=root/'Prefix/Native')
            data = TestRead(temp/(key+'.json'))
            summaries[key] = {'states': len(fields), 'last_Qy_N': data['states'][-1]['target_N_Nmm'][5],
                'maximum_native_stress_error_MPa': data['native_stress_error_MPa'],
                'maximum_norm_MPa': max(row['norm_MPa'] for row in data['states'])}
        restore = run_path(str(root/'Restore-TestWorkingSubspace.py'))['TestRestore']
        for key in ('ForceStock', 'ForceMVT'):
            restore(repo, root, key, temp/('Restored'+key))
    assert summaries['UngatedMVT']['states'] == 44 and summaries['RefinedMVTFailed']['states'] == 73
    assert summaries['ForceMVT']['states'] == 74 and summaries['ForceMVT']['last_Qy_N'] > 79900.
    final = root/'WorkingSources/src/Solver/CCoupledNewtonSolver.cls'
    code, original = final.read_text('utf-8-sig'), (root/'BaseNewton.cls').read_text('utf-8-sig')
    for name in ('SolveStep', 'TryDeformationStep', 'TryRecoverDeformationByArc'):
        assert TestBody(code, name) == TestBody(original, name), name
    assert 'TrySubspaceForceRecovery' in TestBody(code, 'TryStep')
    assert 'If Not mSection.HasRefinedField Then Exit Function' in code
    assert 'maxIterations - mIterations' in TestBody(code, 'TrySubspaceForceRecovery')
    for name, expected in TestRead(root/'WorkingSources.json').items():
        assert sha256((root/'WorkingSources'/name).read_bytes()).hexdigest().upper() == expected
        if name.endswith('/CCoupledNewtonSolver.cls'):
            assert (root/'ForceMVT'/name).read_bytes() == (root/'WorkingSources'/name).read_bytes()
            stock_code = (root/'ForceStock'/name).read_text('utf-8-sig')
            for method in ('TryStep', 'SolveStep', 'TryDeformationStep', 'BuildSubspaceForcePrediction', 'SubspaceForceResidualNorm'):
                assert TestBody(code, method) == TestBody(stock_code, method), method
        else:
            assert (root/'ForceStock'/name).read_bytes() == (root/'WorkingSources'/name).read_bytes()
    log = (root/'ForceMVT/Native/MVTGaussMixed.txt').read_text('utf-8-sig')
    line, = [row for row in log.splitlines() if row.startswith('REDUCED_DIRECT;Reduced65000;')]
    assert line.startswith('REDUCED_DIRECT;Reduced65000;True;') and 'подтверждён квадратичный прогноз' in line
    assert int(re.search(r'Итерации: (\d+);', line)[1]) <= 28
    assert 'REDUCED_AUXILIARY;' not in log and 'REDUCED_SEED;' not in log
    proof = {'stock': stocks, 'mvt': summaries, 'unchanged_full_newton_and_deformation_methods': True,
             'iteration_budget_preserved': True, 'manual_auxiliary_solver_used': False,
             'installed_workbook_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('WORKING FORCE SUBSPACE EQUILIBRIUM AND STOCK REGRESSIONS VERIFIED; PHYSICAL CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestVerify(args.repo.resolve(), args.root.resolve(), args.out.resolve(), args.scope)
