# ДЛЯ ТЕСТОВ: сохраняет неизвестный ранее существовавший Excel без команды закрытия и без заявления владения.
param([Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][int]$ObservedPID,
      [Parameter(Mandatory=$true)][long]$ObservedTicks,[string]$ReferenceClosure)
$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path -LiteralPath $Root).Path
$taskObserved=Get-Process -Id $ObservedPID -ErrorAction SilentlyContinue
if (!$taskObserved) {Write-Output 'OBSERVED_EXCEL_NATURALLY_ABSENT'; exit 0}
if ($taskObserved.ProcessName -ine 'EXCEL' -or $taskObserved.StartTime.ToUniversalTime().Ticks -ne $ObservedTicks) {
    throw 'Наблюдаемая личность Excel изменилась.'
}
$taskClosurePath=if ($ReferenceClosure) {(Resolve-Path -LiteralPath $ReferenceClosure).Path} else {Join-Path $taskRoot 'CompileClosure.json'}
$taskClosure=Get-Content -LiteralPath $taskClosurePath -Raw | ConvertFrom-Json
if ($taskClosure.State -cne 'Absent' -or ($taskClosure.PID -eq $ObservedPID -and [long]$taskClosure.StartTicksUTC -eq $ObservedTicks)) {
    throw 'Не подтверждено независимое закрытие известного процесса компиляции.'
}
$taskGuard=Join-Path $taskRoot 'Guard-IsolatedOffice.ps1'
$taskRaw=[IO.File]::ReadAllBytes($taskGuard)
$taskGuardHash=(Get-FileHash -LiteralPath $taskGuard).Hash
$taskBackupName='Guard.BeforeProtection-'+$ObservedPID+'.ps1'
[IO.File]::WriteAllBytes((Join-Path $taskRoot $taskBackupName),$taskRaw)
$taskText=[IO.File]::ReadAllText($taskGuard)
$taskLine='$protected['+$ObservedPID+']=[long]'+$ObservedTicks
# Вставка только после первой строки, остальные проверки памяти и владения сохраняются побайтно по тексту.
$taskFirst=$taskText.IndexOf("`n")
if ($taskFirst -lt 0) {throw 'Некорректный предохранитель.'}
$taskText=$taskText.Insert($taskFirst+1,$taskLine+"`r`n")
[IO.File]::WriteAllText($taskGuard,$taskText,[Text.UTF8Encoding]::new($false))
$taskRecord=[ordered]@{PID=$ObservedPID;StartTicksUTC=[string]$ObservedTicks;Class='ProtectedUnownedPreexisting';
    OwnerIsCurrentTask=$null;CloseRequested=$false;ProtectedByConservativeIsolation=$true;
    InitialGuardSHA256=$taskGuardHash;VerifiedCompilerPID=$taskClosure.PID;VerifiedCompilerTicks=$taskClosure.StartTicksUTC;
    ReferenceClosurePath=$taskClosurePath;GuardBackup=$taskBackupName;
    RecordedUTC=[DateTimeOffset]::UtcNow.ToString('o')}
$taskRecordName='ExternalExcelProtection-'+$ObservedPID+'.json'
$taskRecord | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskRoot $taskRecordName) -Encoding utf8
$taskPrepPath=Join-Path $taskRoot 'Preparation.json'
$taskPrep=Get-Content -LiteralPath $taskPrepPath -Raw | ConvertFrom-Json
$taskPrep.inputs.'Guard-IsolatedOffice.ps1'=(Get-FileHash -LiteralPath $taskGuard).Hash
foreach ($taskRelative in @($taskBackupName,$taskRecordName)) {
    $taskPrep.inputs | Add-Member -NotePropertyName $taskRelative -NotePropertyValue (Get-FileHash -LiteralPath (Join-Path $taskRoot $taskRelative)).Hash
}
$taskPrep | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $taskPrepPath -Encoding utf8
Write-Output 'OBSERVED_EXCEL_PROTECTED_WITHOUT_CLOSING; OWNERSHIP_NOT_ASSUMED'
