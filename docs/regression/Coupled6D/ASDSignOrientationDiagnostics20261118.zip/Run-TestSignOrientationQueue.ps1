# ДЛЯ ТЕСТОВ: направленные этапы выполняются последовательно в отдельных проверенных экземплярах Excel.
param([Parameter(Mandatory=$true)][string]$Root,[string[]]$Phases=@('Orientation','Core','Material','Trace74','Trace143','Stock'))
$ErrorActionPreference='Stop'
$taskRunner=Join-Path (Resolve-Path -LiteralPath $Root).Path 'Run-TestWorkingASD.ps1'
foreach ($taskPhase in $Phases) {
    & (Join-Path $PSScriptRoot 'Ensure-TestPreexistingExcelProtection.ps1') -Root $Root
    & $taskRunner -Phase $taskPhase
    Write-Output ('COMPLETED_DIRECTED_PHASE: '+$taskPhase)
}
