"""ДЛЯ ТЕСТОВ: различает равновесие, ориентацию ветви, предельный критерий и ошибки диагностической постановки."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import numpy as np


def TestRead(file):
    """Читает точные JSON нативного выполнения без нормализации значений."""
    return json.loads(file.read_text('utf-8-sig'))


def TestSave(output, result):
    """Сохраняет детерминированный результат проверки без заявления общей приёмки."""
    output.write_bytes((json.dumps(result, indent=2, sort_keys=True)+'\n').encode())


def TestNative(repo, root, output):
    """Декодирует каждый компонент и проверяет точные результаты направленных этапов и закрытие собственных процессов."""
    shared = run_path(str(root/'Check-TestMaterialRoundoff.py')); shared['TestFiles'](root)
    ticks = run_path(str(root/'Check-TestASDTransitions.py'))['TestTicks']
    source, _ = run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source)); cases = {}
    required = {'Contract': {'Trace149'}, 'Probes': {'ControlProbe'}, 'AdoptionOnly': {'Orientation', 'Core', 'Material', 'Trace74'},
                'Final': {'Orientation', 'Core', 'Material', 'Trace74', 'Trace143', 'Near143', 'Stock'}}
    for key in TestRead(root/'Cases.json'):
        folder = root/'Cases'/key
        record = shared['TestSourceComparison'](repo, root, folder, source, original, helper, body, reader)
        assert (record['components'], record['imported'], record['unchanged']) == (238, 23, 215)
        reports = {}; own = {(int(TestRead(folder/'CompileClosure.json')['PID']), int(TestRead(folder/'CompileClosure.json')['StartTicksUTC']))}
        for log in sorted((folder/'Native').glob('*.txt')):
            phase = log.stem; text = log.read_text('utf-8-sig'); negative = key == 'Contract'
            owner = TestRead(log.with_name(log.name+'.Ownership.json')); closure = TestRead(log.with_name(log.name+'.ProcessClosure.json'))
            own.add((int(owner['PID']), int(owner['StartTicksUTC'])))
            identity = closure['Closure']['Identity']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['Passed'] and closure['RunnerCleanupValid']
            assert int(owner['PID']) == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
            assert closure['Closure']['FinalState']['State'] == 'Absent' and closure['ChildExitCode'] == (1 if negative else 0)
            assert 'SOURCE_UNCHANGED: True' in text
            totals = [tuple(map(int, r)) for r in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', text, re.M)]
            if negative:
                assert phase == 'Trace149' and totals == [(0, 1)]
                assert 'Для продолжения нужны две последовательные точки возрастающей силовой ветви.' in text
                assert 'проб: 0' in text and 'RUNTIME ERROR: VBAProject Не сохранена фактическая ветвь продолжения.' in text
                reports[phase] = {'expected_diagnostic_contract_rejection': True, 'physical_capacity_certified': False}
                continue
            assert totals and all(failed == 0 for passed, failed in totals) and 'RUNTIME ERROR:' not in text
            if phase == 'Core': assert sum(passed for passed, _ in totals) == 365
            if phase == 'Material': assert totals == [(374, 0)]
            if phase == 'Orientation': assert len(re.findall(r'^ORIENTATION;', text, re.M)) == 147
            if phase == 'ControlProbe': assert len(re.findall(r'^CONTROL_PROBE;[^;]+;True;', text, re.M)) == 12
            if phase == 'Stock':
                assert totals == [(28, 0)] and 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10460833943358; limit=;' in text
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;', text, re.M)
            reports[phase] = {'assertions': sum(passed for passed, _ in totals), 'physical_capacity_certified': False}
        assert set(reports) == required[key], (key, set(reports))
        records = [TestRead(file) for file in folder.glob('ExternalExcelProtection*.json')]
        guard = (folder/'Guard-IsolatedOffice.ps1').read_text('utf-8-sig')
        for pin in records:
            assert pin['Class'] == 'ProtectedUnownedPreexisting' and pin['OwnerIsCurrentTask'] is None and not pin['CloseRequested']
            assert (pin['PID'], int(pin['StartTicksUTC'])) not in own
            backup = folder/pin.get('GuardBackup', 'Guard.BeforeProtection.ps1')
            assert sha256(backup.read_bytes()).hexdigest().upper() == pin['InitialGuardSHA256']
        stripped = re.sub(r'^\$protected\[\d+\]=\[long\]\d+\n', '', guard, flags=re.M)
        original_guard = (folder/'Guard.BeforeProtection.ps1').read_text('utf-8-sig')
        assert stripped == original_guard
        safety = list(map(json.loads, (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()))
        blocks = 0
        for index, state in enumerate(safety):
            assert state['ramMiB'] >= 6500 and state['freeCommitGiB'] >= 6 and state['freeC_MiB'] >= 80 and state['freeD_GiB'] >= 4
            for item in state['excel']:
                if item['ProtectedUser']: continue
                blocks += 1; observed = (item['Id'], ticks(item['StartTime']))
                known = any((pin['PID'], int(pin['StartTicksUTC'])) == observed for pin in records)
                later = [s for s in safety[index+1:] if s['phase'] == state['phase'] and all(p['ProtectedUser'] for p in s['excel'])]
                assert known or (later and all((p['Id'], ticks(p['StartTime'])) != observed for p in later[0]['excel']))
        if key == 'Final':
            raw = (repo/'docs/regression/Coupled6D/ASDSignRevision20261118.zip').read_bytes()
            assert sha256(raw).hexdigest().upper() == '5BE929B98682EFAB087E1986BB405F2EB04E53EE106E5754497F2AFC0CC89454'
            with ZipFile(BytesIO(raw)) as archive:
                for name in ('default.Native.csv', 'default.Probes.csv', 'ndm_uniaxial.Native.csv', 'ndm_uniaxial.Probes.csv'):
                    assert (folder/'Data'/name).read_bytes() == archive.read('Cases/Final/Data/'+name)
            prep = TestRead(folder/'Preparation.json')
            with TemporaryDirectory() as scratch:
                for name, digest in prep['inputs'].items():
                    data = source if name == 'workbook/output/RC_Section_NDM.xlsm' else (folder/name).read_bytes()
                    assert sha256(data).hexdigest().upper() == digest
                    target = Path(scratch)/name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
            record['clean_inputs_restored'] = len(prep['inputs']); record['baseline_material_files_byte_equal'] = 4
        record.update({'reports': reports, 'preflight_blocks': blocks, 'physical_capacity_certified': False})
        cases[key] = record
    TestSave(output, {'cases': cases, 'physical_capacity_certified': False, 'installed_workbook_changed': False, 'full_acceptance_completed': False})
    print('EXACT SIGN ORIENTATION VBA AND DIRECTED NATIVE OUTCOMES VERIFIED; PHYSICAL LIMIT OPEN')


def TestResearch(repo, root):
    """Повторяет сохранённые поля уточнения и четырёх проб без повторного запуска поиска решения."""
    model = run_path(str(root/'TestRefineBeforeSign.py'))
    section, history, fields, lines, load = model['TestRestore'](repo, root/'Cases/AdoptionOnly')
    proof = TestRead(root/'Research/RefineBeforeSign20261118.json'); refined = proof['refinement']; field = np.asarray(refined['field'])
    data = section.TestEvaluate(field, history, load)
    assert refined['solved'] and data[1] <= refined['tolerance_MPa'] == 1e-9 and abs(data[1]-refined['norm_MPa']) < 1e-9
    movement = field-fields[-2]; metric = model['TestMetric']; spacing = np.sqrt(metric(section, movement, movement))
    ratio = np.sqrt(metric(section, field-fields[-1], field-fields[-1])/metric(section, fields[-1]-fields[-2], fields[-1]-fields[-2]))
    assert abs(ratio-refined['refinement_distance_over_original_increment']) < 1e-9
    records = {}
    for name, trial in proof['trials'].items():
        value = np.asarray(trial['field']); target = np.array([0., -396.*trial['Qy_N'], 0., 10510000., 0., trial['Qy_N']])
        evaluation = section.TestEvaluate(value, data[4], target)
        advance = metric(section, movement, value-field)/spacing
        norm = max(float(evaluation[1]), abs(30000.*(advance-float(name)*spacing)))
        assert abs(norm-trial['norm_MPa']) < 1e-8 and (norm <= trial['tolerance_MPa']) == trial['solved']
        records[name] = {'solved': trial['solved'], 'norm_MPa': norm, 'signed_spatial_advance': advance}
    assert sum(r['solved'] for r in records.values()) == 1
    return {'refined_norm_MPa': float(data[1]), 'relative_refinement_distance': float(ratio), 'trials': records,
            'native_implementation_verified': False, 'physical_capacity_certified': False}


def TestMechanics(repo, root, output):
    """Проверяет фактические тензорные направления и равновесия; обратная ветвь не становится приёмкой несущей способности."""
    run_path(str(root/'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    metric = run_path(str(root/'Check-TestSignMetric.py')); group = TestRead(root/'SourceCheckpoint.json')['group']; results = {}
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch)
        if group == 'diagnostics':
            target = scratch/'Probes.json'
            run_path(str(root/'Validate-TestIndependentControl.py'))['TestValidate'](repo, root/'Cases/Probes', target)
            results['independent_probes'] = TestRead(target)
            cases = (('AdoptionOnly', 'Trace74'),)
            results['research'] = TestResearch(repo, root)
        else: cases = (('Final', 'Trace74'), ('Final', 'Trace143'), ('Final', 'Near143'))
        for key, phase in cases:
            folder = root/'Cases'/key; target = scratch/(key+phase+'.json')
            run_path(str(root/'Validate-TestSignContinuation.py'))['TestValidate'](repo, folder, phase, target)
            record = TestRead(target)
            direction = metric['TestRead'](folder/'Native'/(phase+'.Operators.csv'), folder/'Native'/(phase+'.csv'))
            reversed_states = [r for r in direction if r['signed_advance'] <= 0.]
            supplied_count = 74 if phase == 'Trace74' else 143
            reversed_new = [r for r in reversed_states if r['ending_state'] > supplied_count]
            if key == 'Final': assert not reversed_new
            else: assert reversed_states
            record['directions'] = direction; record['reversed_states'] = reversed_states
            record['supplied_prefix_states'] = supplied_count
            record['new_reversed_states'] = reversed_new
            record['whole_path_orientation_verified'] = not reversed_states
            if phase == 'Near143':
                fields = []
                for name in ('Reference/Trace74.Operators.csv', 'Native/Near143.Design.Operators.csv'):
                    fields.extend(np.asarray(r.split(';')[2:], float) for r in (folder/name).read_text('cp1251').splitlines() if r.startswith('F;'))
                exact_direction = metric['TestRead'](folder/'Native/Near143.Design.Operators.csv', folder/'Native/Near143.Design', np.asarray(fields))
                assert len(fields) == 144 and exact_direction[-1]['signed_advance'] > 0.
                record['exact_design_direction'] = exact_direction[-1]
            results[key+phase] = record
            if key+('orientation') not in results: results[key+'orientation'] = metric['TestNative'](folder)
    TestSave(output, {'group': group, 'cases': results, 'physical_capacity_certified': False, 'full_acceptance_completed': False})
    print('SIX EQUILIBRIA AND TENSOR ORIENTATION INDEPENDENTLY VERIFIED; REVERSE BRANCH EXCLUDED; PHYSICAL LIMIT OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True); parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(); (TestNative if args.scope == 'native' else TestMechanics)(args.repo.resolve(), args.root.resolve(), args.out.resolve())
