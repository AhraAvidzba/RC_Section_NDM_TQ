"""ДЛЯ ТЕСТОВ: сохраняет диагностику разворота и окончательные проверки в отдельных переносимых комплектах."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


TestGroups = {'diagnostics': {'Contract': 'AfterSign14920261118', 'Probes': 'PostSignControlProbes20261118',
                              'AdoptionOnly': 'SignOrientation20261118'},
              'final': {'Final': 'SignOrientationFinal20261118'}}


def TestCollect(repo, root, group):
    """Сохраняет точный VBA и фактические протоколы, включая исходную ошибку постановки теста и промежуточный недостаточный предохранитель."""
    here = Path(__file__).resolve().parent; shared = run_path(str(here/'Collect-TestFieldRecovery.py'))
    shared['TestCases'].clear(); shared['TestCases'].update(TestGroups[group]); shared['TestCollect'](repo, root)
    names = ('Collect-TestSignOrientation.py', 'Check-TestSignOrientation.py', 'Check-TestSignMetric.py',
             'Check-TestASDTransitions.py', 'Validate-TestIndependentControl.py', 'Validate-TestSignContinuation.py',
             'TestRefineBeforeSign.py', 'Stage-TestSignOrientation.py', 'Stage-TestAfterSign149.py', 'Stage-TestPostSignProbes.py',
             'Stage-TestSignNearOne.py', 'Stage-TestSignContinuation.py', 'Stage-TestFieldRecovery.py', 'Stage-TestGeneralContinuation.py',
             'TestNativeSignOrientation.bas.txt', 'Protect-TestObservedExcel.ps1', 'Ensure-TestPreexistingExcelProtection.ps1',
             'Run-TestSignOrientationQueue.ps1')
    for name in names:
        if (root/name).exists(): assert (root/name).read_bytes() == (here/name).read_bytes(), name
        else: shared['TestCopy'](here/name, root/name)
    if group == 'diagnostics':
        for name in ('RefineBeforeSign20261118.json', 'RefineBeforeSign.Memory.json'):
            shared['TestCopy'](here/name, root/'Research'/name)
    (root/'SourceCheckpoint.json').write_bytes((json.dumps({'base': 'e3b9079', 'group': group,
        'installed_workbook_changed': False, 'full_acceptance_completed': False, 'physical_capacity_certified': False}, indent=2)+'\n').encode())
    files = {p.relative_to(root).as_posix(): sha256(p.read_bytes()).hexdigest().upper()
             for p in root.rglob('*') if p.is_file() and p.name != 'Files.json'}
    (root/'Files.json').write_bytes((json.dumps(files, indent=2, sort_keys=True)+'\n').encode())
    print('SIGN ORIENTATION EVIDENCE COLLECTED', group, len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--group', choices=tuple(TestGroups), required=True)
    args = parser.parse_args(); TestCollect(args.repo.resolve(), args.root.resolve(), args.group)
