"""ДЛЯ ТЕСТОВ: повторяет каждую прямую нативную пробу от одной исходной истории, не смешивая независимые состояния."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestValidate(repo, root, output):
    """Проверяет все шесть усилий, слабые уравнения, связи, управление и три тензорные станции каждой принятой пробы."""
    here = Path(__file__).resolve().parent
    rows = [line.split(';') for line in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    logs = [line.split(';') for line in (root/'Native/ControlProbe.txt').read_text('utf-8-sig').splitlines()]
    trials = [r for r in logs if r[0] == 'CONTROL_PROBE']
    assert len(trials) == 12 and len({r[1] for r in trials}) == 12
    projections = {r[1]: np.asarray(r[2:], dtype=float) for r in rows if r[0] == 'CONTROL_PROJECTION'}
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch); prefix = scratch/'Prefix'; prefix.mkdir()
        for target, source in (('Operators.csv', 'Trace74.Operators.csv'), ('MVTGaussMixed.csv', 'Trace74.csv'),
                               ('MVTGaussMixed.Tensor.csv', 'Trace74.Tensor.csv')):
            (prefix/target).write_bytes((root/'Reference'/source).read_bytes())
        section, history, prefix_fields = run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo, prefix, scratch/'Prefix.json')
        prefix_proof = json.loads((scratch/'Prefix.json').read_bytes())
        assert len(prefix_fields) == 149
    operators = [line.split(';') for line in (root/'Native/ControlProbe.Operators.csv').read_text('cp1251').splitlines()]
    fields = {r[1]: np.asarray(r[2:], float) for r in operators if r[0] == 'F'}
    net = {}
    for row in operators:
        if row[0] == 'H':
            net.setdefault(row[1], np.empty((3, section.TestPointCount, 6)))[(0, 1, -1).index(int(row[2])), int(row[3])-1] = np.asarray(row[4:], float)
    tensor = [line.split(';') for line in (root/'Native/ControlProbe.Tensor.csv').read_text('cp1251').splitlines()]
    loads, center, phase = {}, {}, None
    for row in tensor:
        if row[0] == 'FRAME':
            phase = row[1]; torque, q = map(float, row[2:4])
            loads[phase] = np.array([0., -396.*q, 0., torque, 0., q])
            center[phase] = np.empty((section.TestPointCount, 6))
        elif row[0] == 'POINT': center[phase][int(row[1])-1] = np.asarray(row[8:], float)
    accepted = [r for r in trials if r[2] == 'True']
    assert set(fields) == set(loads) == set(center) == set(net) == {r[1] for r in accepted}
    records = []
    for row in accepted:
        label = row[1]; target = loads[label]; field = fields[label]
        result = section.TestEvaluate(field, history, target)
        tolerance = float(5e-7+5e-7*np.max(np.abs((target@section.l)[:section.TestDof-4])))
        control_error = float(abs(30000.*(projections[label]@field-float(row[3]))))
        norm = max(float(result[1]), control_error)
        assert norm <= tolerance, (label, norm, tolerance)
        assert target[3] == 10510000. and abs(75000.*float(row[4])-target[5]) < 1e-6
        concrete = result[3][0].copy()
        concrete[section.TestConcreteCount:] = result[5][0, :, None]*section.directions-concrete[section.TestConcreteCount:]
        error = float(max(np.max(np.abs(result[3]-net[label])), np.max(np.abs(concrete-center[label]))))
        assert error < 8e-7, (label, error)
        records.append({'label': label, 'target_N_Nmm': target.tolist(), 'norm_MPa': norm, 'tolerance_MPa': tolerance,
                        'control_error_MPa': control_error, 'native_stress_error_MPa': error})
    proof = {'prefix': prefix_proof, 'independent_probes': len(trials), 'accepted_probes': len(accepted),
             'states': records, 'all_trials_share_original_prefix': True, 'physical_capacity_certified': False,
             'rejected_labels': [r[1] for r in trials if r[2] != 'True']}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('INDEPENDENT NATIVE CONTROL PROBES SIX EQUATIONS AND ORIGINAL MATERIAL HISTORY VERIFIED', len(trials), len(accepted), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(); TestValidate(args.repo.resolve(), args.root.resolve(), args.out.resolve())
