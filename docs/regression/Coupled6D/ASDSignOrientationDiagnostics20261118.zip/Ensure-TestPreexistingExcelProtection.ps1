# ДЛЯ ТЕСТОВ: перед новым этапом сохраняет все не принадлежащие подтверждённым собственным процессам личности Excel.
param([Parameter(Mandatory=$true)][string]$Root,[string]$ReferenceClosure)
$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path -LiteralPath $Root).Path
$taskOwned=@()
$taskCompilerPath=if ($ReferenceClosure) {(Resolve-Path -LiteralPath $ReferenceClosure).Path} else {Join-Path $taskRoot 'CompileClosure.json'}
$taskCompiler=Get-Content -LiteralPath $taskCompilerPath -Raw | ConvertFrom-Json
$taskOwned+=,[pscustomobject]@{PID=[int]$taskCompiler.PID;Ticks=[long]$taskCompiler.StartTicksUTC}
foreach ($taskFile in Get-ChildItem -LiteralPath (Join-Path $taskRoot 'Native') -Filter '*.Ownership.json') {
    $taskOwner=Get-Content -LiteralPath $taskFile.FullName -Raw | ConvertFrom-Json
    $taskOwned+=,[pscustomobject]@{PID=[int]$taskOwner.PID;Ticks=[long]$taskOwner.StartTicksUTC}
}
. (Join-Path $taskRoot 'Guard-IsolatedOffice.ps1')
foreach ($taskExcel in @(Get-Process Excel -ErrorAction SilentlyContinue)) {
    try {$taskTicks=$taskExcel.StartTime.ToUniversalTime().Ticks} catch {
        if (!(Get-Process -Id $taskExcel.Id -ErrorAction SilentlyContinue)) {continue}
        throw
    }
    if ($taskOwned | Where-Object {$_.PID -eq $taskExcel.Id -and $_.Ticks -eq $taskTicks}) {
        throw 'Подтверждённый собственный Excel ещё работает; новый этап не запускается.'
    }
    if ($protected.ContainsKey($taskExcel.Id) -and $protected[$taskExcel.Id] -eq $taskTicks) {continue}
    & (Join-Path $PSScriptRoot 'Protect-TestObservedExcel.ps1') -Root $taskRoot -ObservedPID $taskExcel.Id -ObservedTicks $taskTicks -ReferenceClosure $taskCompilerPath
    $protected[$taskExcel.Id]=$taskTicks
}
