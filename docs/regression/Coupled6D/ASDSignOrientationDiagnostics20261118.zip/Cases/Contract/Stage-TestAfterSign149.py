"""ДЛЯ ТЕСТОВ: готовит продолжение от всех 149 равновесий закреплённой нативной ветви."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestStage(repo, root):
    """Меняет только исходный префикс теста; рабочий решатель, закон, допуски и бюджет 96 проб сохраняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestSignContinuation.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    raw = (repo/'docs/regression/Coupled6D/ASDSignRevision20261118.zip').read_bytes()
    digest = '5BE929B98682EFAB087E1986BB405F2EB04E53EE106E5754497F2AFC0CC89454'
    assert sha256(raw).hexdigest().upper() == digest
    with ZipFile(BytesIO(raw)) as archive:
        for name in ('Trace74.csv', 'Trace74.Operators.csv', 'Trace74.Tensor.csv'):
            value = archive.read('Cases/Final/Native/'+name)
            (root/'Reference'/name).write_bytes(value)
            prep['inputs']['Reference/'+name] = sha256(value).hexdigest().upper()
    loads, fields = {}, []
    for line in (root/'Reference/Trace74.Tensor.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME': loads[row[1]] = row[2:4]
    for line in (root/'Reference/Trace74.Operators.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'F': fields.append(';'.join([row[1], *loads[row[1]], *row[2:]]))
    assert len(fields) == 149
    (root/'AcceptedHistory.csv').write_bytes(('\r\n'.join(fields)+'\r\n').encode())
    name = 'tests/modTestMVT2ProductionASDTest.bas'; code = (root/name).read_text('utf-8-sig')
    old = 'Case "Trace44", "Trace74", "Trace143"'; assert code.count(old) == 1
    code = code.replace(old, old+', "Trace149"')
    (root/name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'; code = (root/runner).read_text('utf-8-sig')
    assert code.count("'Trace143'") == 4
    code = code.replace("'Trace143'", "'Trace143','Trace149'")
    (root/runner).write_bytes(code.encode('utf-8-sig'))
    script = Path(__file__); (root/script.name).write_bytes(script.read_bytes())
    for relative in ('AcceptedHistory.csv', name, runner, script.name):
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'traces': ['Trace149'], 'maximum_probe_count': 96, 'observation_seconds': 480,
                             'continuation_prefix_states': 149, 'parent_archive_sha256': digest,
                             'restart_is_not_uninterrupted_capacity_acceptance': True, 'full_acceptance': False}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('AFTER SIGN CONTINUATION READY; 149 OWN PREFIX STATES; SAME 96-PROBE BUDGET')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve())
