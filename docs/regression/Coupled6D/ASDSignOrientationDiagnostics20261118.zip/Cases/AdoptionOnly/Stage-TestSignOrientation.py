"""ДЛЯ ТЕСТОВ: готовит нативную проверку ориентации и штатного продолжения с исходного восходящего префикса."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestStage(repo, root):
    """Закрепляет прежнюю последовательность для отрицательного контроля; новые истории решаются рабочими классами с проверкой направления."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestSignNearOne.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    raw = (repo/'docs/regression/Coupled6D/ASDSignRevision20261118.zip').read_bytes()
    assert sha256(raw).hexdigest().upper() == '5BE929B98682EFAB087E1986BB405F2EB04E53EE106E5754497F2AFC0CC89454'
    with ZipFile(BytesIO(raw)) as archive:
        loads, fields = {}, []
        for line in archive.read('Cases/Final/Native/Trace74.Tensor.csv').decode('cp1251').splitlines():
            row = line.split(';')
            if row[0] == 'FRAME': loads[row[1]] = row[2:4]
        for line in archive.read('Cases/Final/Native/Trace74.Operators.csv').decode('cp1251').splitlines():
            row = line.split(';')
            if row[0] == 'F': fields.append(';'.join([row[1], *loads[row[1]], *row[2:]]))
    assert len(fields) == 149
    (root/'Data/DirectionSequence.csv').write_bytes(('\r\n'.join(fields)+'\r\n').encode())
    name = 'tests/modTestMVT2ProductionASDTest.bas'; code = (root/name).read_text('utf-8-sig')
    marker = '        Case "ControlProbe"'; assert code.count(marker) == 1
    code = code.replace(marker, '        Case "Orientation"\n            completed = RunSignOrientationTest(report, tracePath)\n'+marker)
    code += '\n'+(here/'TestNativeSignOrientation.bas.txt').read_text('utf-8')
    (root/name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'; code = (root/runner).read_text('utf-8-sig')
    assert code.count("'ControlProbe'") == 3
    code = code.replace("'ControlProbe'", "'ControlProbe','Orientation'")
    (root/runner).write_bytes(code.encode('utf-8-sig'))
    parent = Path('D:/CodexScratch/RC_Section_NDM_TQ/AfterSign14920261118')
    for relative in ('Guard-IsolatedOffice.ps1', 'Guard.BeforeProtection.ps1', 'ExternalExcelProtection.json'):
        (root/relative).write_bytes((parent/relative).read_bytes())
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    for relative in ('TestNativeSignOrientation.bas.txt', Path(__file__).name):
        (root/relative).write_bytes((here/relative).read_bytes())
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    for relative in (name, runner, 'Data/DirectionSequence.csv'):
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    prep['orientation_scope'] = {'retained_negative_control_states': 149, 'native_orientation_checks': 147,
        'physical_capacity_certified': False, 'material_law_changed': False}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('ORIENTED ASD CONTINUATION READY; 147 ORIENTATION CHECKS AND UNCHANGED LOAD TARGETS')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve())
