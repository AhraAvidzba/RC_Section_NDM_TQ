"""ДЛЯ ТЕСТОВ: сравнивает двенадцать прямых шагов от нисходящего префикса без перезапуска восходящего поиска."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Сохраняет все 149 состояний и сравнивает три меры с четырьмя шагами при одинаковом лимите Ньютона."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestAfterSign149.py'))['TestStage'](repo, root)
    name = 'tests/modTestMVT2ProductionASDTest.bas'; full = (root/name).read_text('utf-8-sig')
    begin = full.index('Private Function RunControlProbesTest(')
    end = full.index('\nEnd Function', begin)+len('\nEnd Function')
    code = full[begin:end]
    replacements = {
        'If history.Count <> 74 Then': 'If history.Count <> 149 Then',
        'Для сравнительных проб нужны 74 принятых состояния.': 'Для сравнительных проб нужны 149 принятых состояний.',
        'For index = 1 To 6': 'For index = 1 To 12',
        'Case 3, 4\n                mode = "Automatic"': 'Case 1 To 4\n                mode = "Automatic"',
        'Case 5\n                mode = "Twist"': 'Case 5 To 8\n                mode = "Twist"',
        'Case 6\n                Dim unused()': 'Case 9 To 12\n                Dim unused()',
        'factor = 32#: If index = 1 Or index = 3 Then factor = 4#': 'factor = 0.25 * 2# ^ ((index - 1) Mod 4)',
    }
    old = '''            Case 1, 2
                mode = "FirstBar": consistent = True
                operators.CopySteelStrainProjection operators.ConcretePointCount + 1, projection
                ReDim Preserve projection(1 To operators.DegreeCount)
'''
    assert code.count(old) == 1; code = code.replace(old, '')
    for old, new in replacements.items():
        assert code.count(old) == 1, old
        code = code.replace(old, new)
    (root/name).write_bytes((full[:begin]+code+full[end:]).replace('\n', '\r\n').encode('utf-8-sig'))
    prep = json.loads((root/'Preparation.json').read_bytes())
    parent = Path('D:/CodexScratch/RC_Section_NDM_TQ/AfterSign14920261118')
    for relative in ('Guard-IsolatedOffice.ps1', 'Guard.BeforeProtection.ps1', 'ExternalExcelProtection.json'):
        (root/relative).write_bytes((parent/relative).read_bytes())
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    script = Path(__file__); (root/script.name).write_bytes(script.read_bytes())
    for relative in (name, script.name): prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    prep['probe_scope'] = {'prefix_states': 149, 'independent_trials': 12, 'measures': ['Automatic', 'Twist', 'ShearY'],
        'multiples_of_last_increment': [0.25, 0.5, 1., 2.], 'newton_iterations_per_trial': 32,
        'numerical_algorithm_changed': False, 'physical_capacity_certified': False}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('POST-SIGN DIRECT PROBES READY; 149 PREFIX STATES; 12 INDEPENDENT TRIALS')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve())
