"""Упаковывает пробы продолжения от G13 и независимое восстановление метрики."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]/'docs/regression/Coupled6D/HardShearG14DirectionNative20261117.zip'
BASE_SHA = '596609AD534F382BE6FD06FCCBBBCCCF42D24A66236C34364D52164376AFCD02'
NAME = 'HardShearG13PhysicalArcNative20261117'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def collect(source):
    fixture = json.loads((source/'Fixture.json').read_bytes())
    names = ['Fixture.json','Compile.log','CompileClosure.json','docs/regression/CodeUpdate.json','Run.ndjson',*fixture['inputs']]
    lane = source/'Native/Order10'
    names.extend(path.relative_to(source).as_posix() for path in sorted(lane.iterdir()) if path.is_file())
    assert len(names) == len(set(names)) and 'Native/Order10/Verification.json' in names
    data = {name:(source/name).read_bytes() for name in names}
    assert all(sha(data[name]) == digest for name,digest in fixture['inputs'].items())
    assert sha(BASE.read_bytes()) == BASE_SHA
    with ZipFile(BASE) as package:
        for name,expected in fixture['production'].items():
            path = 'Production/'+name
            data[path] = package.read(path)
            assert sha(data[path]) == expected
    for name in ('Pack.py','Verify-Portable.py','README-Portable.md'):
        data[name] = (HERE/name).read_bytes()
    checksums = {name:sha(raw) for name,raw in data.items()}
    data['SHA256SUMS.json'] = (json.dumps(checksums,sort_keys=True,indent=2)+'\n').encode('utf-8')
    return data


def seal(path,raw):
    if path.exists():
        assert path.read_bytes() == raw
    else:
        path.write_bytes(raw)


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('source',type=Path)
    args = cli.parse_args()
    data = collect(args.source)
    folder = HERE/'proof'
    folder.mkdir(exist_ok=True)
    output = folder/(NAME+'.zip')
    with TemporaryDirectory(prefix='replay-',dir=folder) as directory:
        stage = Path(directory)
        zpath = stage/'candidate.zip'
        with ZipFile(zpath,'w',compression=ZIP_DEFLATED,compresslevel=9) as archive:
            for name,raw in sorted(data.items()):
                entry = ZipInfo(name,date_time=(2026,11,17,0,0,0))
                entry.create_system = 3
                entry.external_attr = 0o100644 << 16
                archive.writestr(entry,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
        extract = stage/'unpacked'
        with ZipFile(zpath) as archive:
            archive.extractall(extract)
        replay = run([sys.executable,'-B','-X','utf8','Verify-Portable.py'],cwd=extract,stdout=PIPE,check=True).stdout
        digest = sha(zpath.read_bytes())
        seal(output,zpath.read_bytes())
        seal(folder/(NAME+'.zip.sha256'),f'{digest} *{NAME}.zip\n'.encode('ascii'))
        seal(folder/(NAME+'.replay.txt'),replay)
    print(output,digest)
    print(replay.decode('utf-8').splitlines()[-1])


if __name__ == '__main__':
    main()
