' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает физическую плоскость и штатную меру дуги на одной истории G13.
Private Function TryHardG14ArcSectionsTest(ByVal history As Collection, ByRef saved() As Double, _
        ByRef factors() As Double, ByVal g14 As Double, ByRef offset() As Double, ByRef direction() As Double, _
        ByRef initialProjection() As Double, ByVal started As Double, ByRef probes As Long) As Boolean
    Dim trace As New CCoupledLoadTrace, i As Long, old() As Double, current() As Double, movement() As Double
    For i = 1 To history.Count: trace.Add 1#, factors(i): Next i
    old = history(24): current = history(25): movement = current
    For i = 1 To mDegreeCount: movement(i) = current(i) - old(i): Next i
    Dim coefficients() As Double, arcProjection() As Double, pureProjection() As Double, predicted() As Double
    Dim target As Double, loadProjection As Double, metric As Double, radius As Double, predictedLambda As Double
    mControlProjection = initialProjection: mTargetControl = g14
    If Not PrepareArcMeasure(history, trace, factors(25), coefficients, arcProjection, predicted, target, _
            loadProjection, metric, radius, predictedLambda) Then Exit Function
    Dim fieldLength As Double, augmentedLength As Double, latestLambda As Double
    latestLambda = factors(25) - factors(24)
    fieldLength = Sqr(ArcPhysicalSquare(coefficients, movement, pureProjection, True))
    augmentedLength = Sqr(fieldLength ^ 2 + metric * latestLambda ^ 2)
    For i = 1 To mGaugeStart - 1: pureProjection(i) = pureProjection(i) / fieldLength: Next i
    WriteHardRankRowTest "ARC-METRIC;" & HardRankBitsTest(metric) & ";" & HardRankBitsTest(radius) & ";" & _
        HardRankBitsTest(fieldLength) & ";" & HardRankBitsTest(augmentedLength) & ";" & HardRankBitsTest(loadProjection)
    WriteHardRankRowTest "ARC-PROJECTION;FIELD;" & HardRankVectorTest(pureProjection)
    WriteHardRankRowTest "ARC-PROJECTION;LOAD;" & HardRankVectorTest(arcProjection)
    WriteHardG14ArcOperatorTest coefficients
    Dim fraction As Variant, arm As Variant, fractionOfSecant As Double, selected() As Double
    Dim length As Double, weight As Double, usedMetric As Double
    For Each arm In Array("FIELD", "LOAD")
        If CStr(arm) = "FIELD" Then
            selected = pureProjection: length = fieldLength: weight = 0#: usedMetric = 0#
        Else
            selected = arcProjection: length = augmentedLength: weight = loadProjection: usedMetric = metric
        End If
        For Each fraction In Array(-0.5, 0.125, 0.25, 0.5)
            If Timer - started > 100# Then Exit Function
            fractionOfSecant = CDbl(fraction)
            probes = probes + 1
            RunHardG14ArcSectionTest CStr(arm), fractionOfSecant, current, movement, factors(25), latestLambda, _
                selected, length, weight, usedMetric, offset, direction, initialProjection, coefficients
            If Not HardG13HistoryAgreesTest(saved) Then Exit Function
            WriteHardRankRowTest "ARC-END;" & CStr(UBound(saved))
        Next fraction
    Next arm
    TryHardG14ArcSectionsTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает ненулевые коэффициенты деформаций и веса точек квадратуры.
Private Sub WriteHardG14ArcOperatorTest(ByRef coefficients() As Double)
    Dim point As Long, row As Long, i As Long, x As Double, y As Double, area As Double, record As String
    For point = 1 To mPointCount
        mSection.Point point, x, y, area
        WriteHardRankRowTest "ARC-AREA;" & CStr(point) & ";" & HardRankBitsTest(area)
        For row = 1 To 9
            record = "ARC-OP;" & CStr(point) & ";" & CStr(row)
            For i = 1 To mGaugeStart - 1
                If coefficients(i, 9 * (point - 1) + row) <> 0# Then _
                    record = record & ";" & CStr(i) & "=" & HardRankBitsTest(coefficients(i, 9 * (point - 1) + row))
            Next i
            WriteHardRankRowTest record
        Next row
    Next point
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет одну ортогональную плоскость, не фиксируя полученную историю.
Private Sub RunHardG14ArcSectionTest(ByVal arm As String, ByVal ratio As Double, ByRef current() As Double, _
        ByRef movement() As Double, ByVal acceptedLambda As Double, ByVal latestLambda As Double, _
        ByRef projection() As Double, ByVal length As Double, ByVal weight As Double, ByVal metric As Double, _
        ByRef offset() As Double, ByRef direction() As Double, ByRef initialProjection() As Double, ByRef coefficients() As Double)
    Const TOLERANCE As Double = 0.0000005, ITERATIONS As Long = 12
    Dim pred() As Double, seed As Variant, i As Long, shift As Double, target As Double
    Dim estimate As Double, factor As Double, solved As Boolean
    pred = current: estimate = acceptedLambda + ratio * latestLambda
    shift = ratio * length: target = weight * acceptedLambda + shift
    For i = 1 To mGaugeStart - 1
        target = target + projection(i) * current(i)
        pred(i) = current(i) + ratio * movement(i)
    Next i
    seed = pred
    solved = TryDeformationStep(offset, direction, projection, target, estimate, factor, TOLERANCE, TOLERANCE, _
        ITERATIONS, consistentControl:=True, initialField:=seed, loadProjection:=weight)
    WriteHardRankRowTest "ARC-TRY;" & arm & ";" & HardRankBitsTest(ratio) & ";" & HardRankBitsTest(target) & ";" & _
        HardRankBitsTest(shift) & ";" & HardRankBitsTest(estimate) & ";" & CStr(solved) & ";" & _
        CStr(mIterations) & ";" & CStr(mEvaluations) & ";" & Replace(mMeta.DiagnosticDetails, ";", "|")
    If Not solved Then Exit Sub
    Dim field() As Double, load(1 To COMPONENT_COUNT) As Double, resultants() As Double, unused() As Double
    Dim delta() As Double, norm As Double, tau As Double, reach As Double, travel As Double, errControl As Double
    Dim bound As Double, bounded As Boolean, verified As Boolean, withinArc As Boolean
    CopyTrial field, resultants
    delta = field: reach = weight * (factor - acceptedLambda)
    For i = 1 To COMPONENT_COUNT: load(i) = offset(i) + factor * direction(i): Next i
    For i = 1 To mGaugeStart - 1
        delta(i) = field(i) - current(i)
        reach = reach + projection(i) * delta(i)
    Next i
    travel = Sqr(ArcPhysicalSquare(coefficients, delta, unused) + metric * (factor - acceptedLambda) ^ 2)
    norm = EquilibriumNorm(load, field): tau = EquilibriumTolerance(TOLERANCE, TOLERANCE)
    errControl = ControlResidual(field)
    withinArc = (reach * shift > 0# And Abs(reach - shift) <= 0.125 * Abs(shift) And travel <= 3# * Abs(shift))
    verified = (norm <= tau And GaugesVerified(tau) And withinArc)
    WriteHardRankRowTest "ARC-BALANCE;" & HardRankBitsTest(factor) & ";" & HardRankBitsTest(norm) & ";" & _
        HardRankBitsTest(tau) & ";" & HardRankBitsTest(reach) & ";" & HardRankBitsTest(travel) & ";" & _
        HardRankBitsTest(errControl) & ";" & HardRankBitsTest(HardFineControlTest(initialProjection, field)) & ";" & CStr(verified)
    WriteHardRankRowTest "ARC-FIELD;" & HardRankVectorTest(field)
    WriteHardRankRowTest "ARC-RESIDUAL;" & HardRankVectorTest(mResidual)
    WriteHardRankRowTest "ARC-TARGET;" & HardRankVectorTest(load)
    WriteHardRankRowTest "ARC-WRENCH;" & HardRankVectorTest(resultants)
    If verified Then
        bounded = TrialLambdaUncertainty(TOLERANCE, TOLERANCE, bound)
        WriteHardRankRowTest "ARC-BOUND;" & CStr(bounded) & ";" & HardRankBitsTest(bound)
    End If
    DiscardStep
End Sub
