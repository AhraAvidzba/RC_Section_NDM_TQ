"""Seal the private HardShear pseudo-arc comparison and keep the shared arc source unchanged."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
ARC=HERE.parent/'arcv'
HISTORY=HERE.parent/'hard-audit'
BOOK='workbook/output/RC_Section_NDM.xlsm'
NEWTON='src/Solver/CCoupledNewtonSolver.cls'
SECTION='src/Solver/CCoupledSectionAnalysis.cls'
TEST='tests/modTestCoupledElasticState.bas'
ORIGINS=('src/Solver/CCoupledElasticState.cls','src/Materials/CCoupledConcreteResponse.cls',
         'src/Materials/CCoupledReinforcedResponse.cls','src/Materials/CCoupledSteelModel.cls',NEWTON,SECTION,TEST)
PINS={'HardShear-H68.csv':'DC3FDC82B66DA7CB4B64736D1F0F6B2A99764924D514F252F07D0CB7A10CDC0D',
      'HardShear-Geometry.csv':'E555084E4B6E4E89254A0896824162D6318771C63389D0086A1D860D66F62794',
      'HardShear-Reference.csv':'05B514EC47A5FD430D630D9DC7554E0E53F82C7F4BCEDBABBB841179D27EB6C2',
      'HardShear-HistoryReceipt.json':'A11C47CFF8E5FCD00B6BBA257E3B2E374FC966263E71732C374E146462EE71A3'}


def digest(value):
    return sha256(value.read_bytes() if isinstance(value,Path) else value).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def git(repo,ref,path):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{ref}:{path}'])


def put(name, content):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(content)
    return digest(path)


def once(source,old,new):
    assert source.count(old)==1,old
    return source.replace(old,new)


def encode(text):
    return (text.strip()+'\n').replace('\n','\r\n').encode('utf-8-sig')


def section_hook(source):
    source=once(source,'''    Dim solver As CCoupledNewtonSolver, branch As New CCoupledLoadContinuation
    Set solver = CreateNewtonSolver(response, fc, ft, models)''','''    Dim solver As CCoupledNewtonSolver, branch As New CCoupledLoadContinuation
    ' -------------------- ДЛЯ ТЕСТОВ --------------------
    ' Частный сценарий снимает подготовленное сечение до штатного силового поиска.
    If HardArcFixtureRequestedTest Then
        Dim testSides As New Collection
        Set solver = CreateNewtonSolver(response, fc, ft, models, testSides)
        RunPreparedHardArcTest solver, mOperators, concrete, response, testSides, path, _
            Array(mEb, mPoisson, fc, ft, mYieldRatio * fc, mPeakStrain, mGt, mGc, mLength), _
            maxIterations, STRESS_TOLERANCE, RELATIVE_TOLERANCE
        capacity.InitializeUnsupportedConfiguration "Частный тест снял пробные поля и отменил их."
        Exit Function
    End If
    Set solver = CreateNewtonSolver(response, fc, ft, models)''')
    source=once(source,'''        ByVal models As Object) As CCoupledNewtonSolver''','''        ByVal models As Object, Optional ByVal testSides As Collection = Nothing) As CCoupledNewtonSolver''')
    return once(source,'''    solver.Initialize mOperators, response, mEb, plusResponse, minusResponse''','''    solver.Initialize mOperators, response, mEb, plusResponse, minusResponse
    If Not testSides Is Nothing Then ' ДЛЯ ТЕСТОВ. Зафиксированные ссылки не меняют подготовку материала.
        testSides.Add minusConcrete: testSides.Add minusResponse
        testSides.Add plusConcrete: testSides.Add plusResponse
    End If''')


def stage(repo):
    assert HERE.is_relative_to(repo/'tmp') and not (HERE/'Fixture.json').exists()
    arc=read(ARC/'Fixture.json')
    assert digest(repo/BOOK)==arc['workbook_sha256']==digest(git(repo,'f4741ae',BOOK))
    assert digest(repo/NEWTON)==arc['solver_base_sha256'] and digest(repo/TEST)==arc['test_base_sha256']
    assert digest(ARC/'ArcMethod.txt')=='CF8175A56ADD943EE4DA46A7C1D38538EA2DF82D485153C4A8E7DD7CFAC37C50'
    frozen={}
    for name,expected in arc['frozen'].items():
        if name in (BOOK,NEWTON,'Guard-IsolatedOffice.ps1','ArcMethod.txt') or name.startswith('tools/'):
            assert digest(ARC/name)==expected,name
            frozen[name]=put(name,(ARC/name).read_bytes())
    assert put('docs/regression/Diagnostic.xlsm',(HERE/BOOK).read_bytes())==arc['workbook_sha256']
    for name,expected in PINS.items():
        assert digest(HISTORY/name)==expected,name
        frozen[name]=put(name,(HISTORY/name).read_bytes())
    frozen[SECTION]=put(SECTION,encode(section_hook((repo/SECTION).read_text(encoding='utf-8-sig'))))
    test=once((repo/TEST).read_text(encoding='utf-8-sig'),'Option Explicit\n','''Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
Public HardArcFixtureRequestedTest As Boolean
Private mHardArcPath As String, mHardArcResult As String
''')
    test=test.rstrip()+'\n\n'+(HERE/'HardTest.txt').read_text(encoding='utf-8-sig')
    names=re.findall(r'(?im)^(?:Public|Private) (?:Function|Sub) (\w+)',test)
    assert len(names)==len(set(name.casefold() for name in names)) and max(map(len,test.splitlines()))<1024
    frozen[TEST]=put(TEST,encode(test))
    for name in ('Prepare.py','HardTest.txt','Run.ps1','Verify.py','README.md'):
        frozen[name]=digest(HERE/name)
    for name in ('Native','Temp'):
        (HERE/name).mkdir(exist_ok=True)
    value={'workbookSHA256':arc['workbook_sha256'],'arcSourceFixtureSHA256':digest(ARC/'Fixture.json'),
           'arcSolverSHA256':arc['frozen'][NEWTON],'bookGit':'f4741ae',
           'currentSourceGit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
           'currentSourceBlobsSHA256':{name:digest(git(repo,'HEAD',name)) for name in ORIGINS},
           'macroTimeoutSeconds':100,'modules':['CCoupledNewtonSolver','CCoupledSectionAnalysis','modTestCoupledElasticState'],
           'frozen':frozen}
    put('Fixture.json',(json.dumps(value,indent=2)+'\n').encode('utf8'))


def check(repo):
    data=read(HERE/'Fixture.json')
    assert data['workbookSHA256']==digest(repo/BOOK)==digest(git(repo,data['bookGit'],BOOK))
    assert all(digest(HERE/name)==value for name,value in data['frozen'].items())
    assert all(digest(git(repo,'HEAD',name))==value for name,value in data['currentSourceBlobsSHA256'].items())
    assert data['arcSolverSHA256']==digest(ARC/NEWTON)==digest(HERE/NEWTON)
    assert {p.stem for dir in ('src','tests') for p in (HERE/dir).rglob('*') if p.is_file()}==set(data['modules'])
    print('HARD_ARC_FIXTURE_PASS',digest(HERE/'Fixture.json'),data['arcSolverSHA256'],data['frozen'][SECTION],data['frozen'][TEST])


if __name__=='__main__':
    parser=ArgumentParser()
    parser.add_argument('--repo-root',type=Path,required=True)
    modes=parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--stage',action='store_true')
    modes.add_argument('--check',action='store_true')
    inputs=parser.parse_args()
    repo=inputs.repo_root.resolve()
    if inputs.stage:
        stage(repo)
    check(repo)
