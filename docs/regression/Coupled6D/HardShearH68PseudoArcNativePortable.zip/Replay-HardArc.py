"""Replay the native comparison and reconstruct the four historical gauge equations."""
from argparse import ArgumentParser
from hashlib import sha256
from math import comb, fsum, isclose
from pathlib import Path
import csv
import json
import subprocess

HERE=Path(__file__).resolve().parent
BOOK='workbook/output/RC_Section_NDM.xlsm'
EC=30000.


def sha(data):
    return sha256(data).hexdigest().upper()


def read(name):
    return json.loads((HERE/name).read_bytes())


def rows(name):
    with (HERE/name).open(encoding='cp1251',newline='') as source:
        return list(csv.reader(source,delimiter=';'))


def compare(expected,actual):
    if isinstance(expected,dict):
        assert set(expected)==set(actual)
        for name in expected:
            compare(expected[name],actual[name])
    elif isinstance(expected,list):
        assert len(expected)==len(actual)
        for a,b in zip(expected,actual):
            compare(a,b)
    elif isinstance(expected,float):
        assert isclose(expected,actual,rel_tol=1e-12,abs_tol=1e-13),(expected,actual)
    else:
        assert expected==actual,(expected,actual)


def basis(t,j):
    return comb(3,j)*t**j*(1.-t)**(3-j)


def gauge_operator(geometry,area,length):
    rows=[[] for _ in range(4)]
    for _,kind,xt,yt,weight in geometry:
        if kind!='concrete':
            continue
        x,y,w=map(float,(xt,yt,weight))
        tx=.5+x/180.; ty=.5+y/120.
        pattern=[basis(tx,i)*basis(ty,j)*w/area for j in range(4) for i in range(4)]
        terms=[[],[],[],[]]
        for phi in pattern:
            for output,values in zip(terms,((phi,0.,0.),(0.,phi,0.),(0.,0.,phi),(-y/length*phi,x/length*phi,0.))):
                output.extend(values)
        for dest,values in zip(rows,terms):
            dest.append([0.]*4+values+[0.]*8)
    return [[fsum(column) for column in zip(*axis)] for axis in rows]


def gauge_proof(result):
    doc=read('HardShear-HistoryReceipt.json')
    area=doc['geometryArea_mm2']; length=doc['referenceLength_mm']
    geom=rows('HardShear-Geometry.csv')
    assert geom[0][:5]==['POINTS','43','25','2','16']
    operator=gauge_operator(geom[1:],area,length)
    assert all(len(item)==60 and not any(item[-8:]) for item in operator)
    def apply(q):
        return [fsum(x*y for x,y in zip(coef,q)) for coef in operator]
    hist=rows('HardShear-H68.csv')
    assert hist[0]==['HARD_SHEAR','68','60'] and len(hist)==69
    old={int(row[1]):apply(tuple(map(float,row[3:]))) for row in hist[1:]}
    max_old=max(abs(q) for case in old.values() for q in case)
    assert max_old<1e-17
    h69=next(row for row in rows('HardShear-Reference.csv') if row[:2]==['FIELD','69'])
    ref=apply(tuple(map(float,h69[3:])))
    matched={}
    for tag,point in {'Replay':result['replayedBase'],**result['arms']}.items():
        independently=apply(point['q'])
        captured=point['allWeakAndGaugeRows'][56:]
        discrepancy=max(abs(a-b) for a,b in zip(independently,captured))
        assert discrepancy<1e-17 and all(EC*abs(x)<=point['originalTolerance_MPa'] for x in independently)
        matched[tag]={'independentGaugeResiduals':independently,'nativeGaugeResiduals':captured,
                      'absoluteComponentMaximumDifference':discrepancy}
    return {'description':['mean u/L','mean v/L','mean w/L','mean (-y*u+x*v)/L^2'],
            'coefficients':operator,'archivedH67':old[67],'archivedH68':old[68],
            'archivedH69':ref,'archivedMaximumAbsAllH1to68':max_old,'currentEvidence':matched}


def observations(result):
    assert result['referenceH68CurrentLawAccepted'] and set(result['arms'])=={'Mean','Arc'}
    assert result['replayedBase']['maxDifferenceFromArchivedH68Wrench_MPa']<5e-13
    mean,arc=(result['arms'][mode] for mode in ('Mean','Arc'))
    for obj in (mean,arc):
        assert obj['solved'] and obj['fullBalanceQualified'] and obj['acceptedHistoryExactAfterDiscardAndReplay']
    raw=rows('Native/HardArcPair.csv')
    receipts=[r for r in raw if r[0] in ('REPLAY_CONFIRMED','ROLLBACK','REPLAY_ROLLBACK')]
    assert receipts==[['REPLAY_CONFIRMED','68'],['ROLLBACK','Mean','60','129'],['REPLAY_ROLLBACK','Mean','68','129'],
                      ['ROLLBACK','Arc','60','129'],['REPLAY_ROLLBACK','Arc','68','129']]
    return {'currentLawReplayPreservedArchivedSixWrenches':True,'rollbackReceipts':receipts,
            'gauges':gauge_proof(result),
            'observations':{'arcMinusMeanLambda':arc['lambda']-mean['lambda'],
                            'arcMinusMeanOrientedAverageShearXZ':arc['orientedMeanXZ']-mean['orientedMeanXZ'],
                            'arcMinusMeanWrench_N_Nmm':[a-b for a,b in zip(arc['signedIndependentWrench_N_Nmm'],mean['signedIndependentWrench_N_Nmm'])],
                            'arcMinusMeanNormalizedWork_MPa':arc['normalizedExternalIncrementWork_MPa']-mean['normalizedExternalIncrementWork_MPa'],
                            'normalizedWork_MPa':{i:v['normalizedExternalIncrementWork_MPa'] for i,v in result['arms'].items()},
                            'observedBalanceNorms_MPa':{i:v['allBalanceNorm_MPa'] for i,v in result['arms'].items()},
                            'observedSolverSeconds':{i:v['solverSeconds'] for i,v in result['arms'].items()},
                            'combinedGuardedNativeWallSeconds':result['closure']['nativeWallSeconds'],
                            'identicalIterationAndEvaluationCounts':all(mean[k]==arc[k] for k in ('solverIterations','equilibriumEvaluations')),
                            'physicalMaximumCertified':False}}


def main(repo):
    seal=read('Manifest.json'); fixture=read('Fixture.json'); history=read('HardShear-HistoryReceipt.json')
    assert seal['schema']=='HardShearH68PseudoArc/v1' and seal['workbookBytesOmitted']
    assert fixture['workbookSHA256']==fixture['frozen'][BOOK]==seal['currentWorkbookSHA256']
    assert all(sha((HERE/name).read_bytes())==expected for name,expected in seal['files'].items())
    assert all(seal['files'][name]==expected for name,expected in fixture['frozen'].items() if name!=BOOK)
    required=[(fixture['bookGit'],BOOK,fixture['workbookSHA256']),
              (history['baseBookPinnedGit'],BOOK,history['baseBookSHA256'])]
    required.extend((fixture['currentSourceGit'],name,expected) for name,expected in fixture['currentSourceBlobsSHA256'].items())
    for rev,name,expected in required:
        data=subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{rev}:{name}'])
        assert sha(data)==expected,(rev,name)
    source=HERE/'Verify.py'
    code=source.read_text(encoding='utf8')
    assert code.count("HERE/'HardArcVerification.json'")==1
    code=code.replace("HERE/'HardArcVerification.json'","HERE/'Replay-HardArcVerification.json'")
    ns={'__file__':str(source),'__name__':'portable_hard_arc'}
    exec(compile(code,str(source),'exec'),ns)
    ns['verify']()
    result=read('Replay-HardArcVerification.json')
    compare(read('HardArcVerification.json'),result)
    data=(json.dumps(observations(result),indent=2,allow_nan=False)+'\n').encode('utf8')
    (HERE/'HardArcDetachedChecks.json').write_bytes(data)
    print('HARD_ARC_PORTABLE_PASS',sha(data))


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    main(p.parse_args().repo_root.resolve())
