"""Archive the HardShear native experiment without workbook binaries."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import json

HERE=Path(__file__).resolve().parent
BOOK='workbook/output/RC_Section_NDM.xlsm'
RESULT_SHA='67BD8E2A33173DF0E1C7884A5251113295E9C4044B93006235CF8962A56DD47A'


def digest(data):
    return sha256(data).hexdigest().upper()


def main():
    fixture=json.loads((HERE/'Fixture.json').read_bytes())
    members=set(fixture['frozen'])-{BOOK}
    members.update(path.relative_to(HERE).as_posix() for path in (HERE/'Native').iterdir() if path.is_file())
    members.update(('Fixture.json','HardArcVerification.json','docs/regression/CodeUpdate.json','Run.ndjson',
                    'Replay-HardArc.py','Pack-HardArc.py','Portable-README.md'))
    data={name:(HERE/name).read_bytes() for name in sorted(members)}
    assert all(digest(data[name])==expected for name,expected in fixture['frozen'].items() if name!=BOOK)
    assert digest(data['HardArcVerification.json'])==RESULT_SHA
    assert not any(path.lower().endswith(('.xlsm','.xls','.xlsx')) for path in members)
    seal={'schema':'HardShearH68PseudoArc/v1','workbookBytesOmitted':True,
          'currentWorkbookSHA256':fixture['workbookSHA256'],'currentSourceGit':fixture['currentSourceGit'],
          'files':{name:digest(body) for name,body in data.items()}}
    data['Manifest.json']=(json.dumps(seal,indent=2)+'\n').encode('utf8')
    dest=HERE/'Portable'
    dest.mkdir(exist_ok=True)
    path=dest/'HardShearH68PseudoArcNativePortable.zip'
    with ZipFile(path,'w',compression=ZIP_DEFLATED,compresslevel=9) as out:
        for name,body in data.items():
            out.writestr(ZipInfo(name,(2026,11,16,0,0,0)),body,compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(path) as check:
        assert check.testzip() is None and set(check.namelist())==set(data)
    print(path,digest(path.read_bytes()),path.stat().st_size)


if __name__=='__main__':
    main()
