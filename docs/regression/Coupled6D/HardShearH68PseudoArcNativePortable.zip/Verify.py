"""Reintegrate signed HardShear forces and audit both continuation controls."""
from collections import defaultdict
from hashlib import sha256
from math import fsum, isfinite, sqrt
from pathlib import Path
import csv
import json
import re

HERE=Path(__file__).resolve().parent
NATIVE=HERE/'Native'
E=30000.
BASE=(28000.,510000.,180000.,1500000.,17000.,-7100.)


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def rows(path):
    with path.open(encoding='cp1251',newline='') as stream:
        return [line for line in csv.reader(stream,delimiter=';') if line]


def vector(values,size):
    result=tuple(map(float,values))
    assert len(result)==size and all(map(isfinite,result))
    return result


def peak(values):
    return max(map(abs,values))


def closeness(a,b,tol):
    assert abs(a-b)<=tol,(a,b,tol)


def closure(fixture):
    report=(NATIVE/'HardArcPair.txt').read_text(encoding='utf-8-sig')
    compiled=read(HERE/'docs/regression/CodeUpdate.json')
    first=read(NATIVE/'CompileClosure.json')
    own=read(NATIVE/'HardArcPair.txt.Ownership.json')
    end=read(NATIVE/'HardArcPair.txt.ProcessClosure.json')
    timing=read(NATIVE/'Timing.json')
    assert compiled['Compiled'] and not compiled['ProductionChanged']
    assert compiled['ProductionSHA256']==fixture['workbookSHA256'] and sorted(compiled['Modules'])==sorted(fixture['modules'])
    assert own['BeforeWorkbookOpen'] and own['VerifiedNewOwner'] and own['SourceSHA256']==compiled['WorkbookSHA256']
    assert re.findall(r'^SOURCE_SHA256: ([A-F0-9]{64})$',report,re.M)==[own['SourceSHA256']]
    assert 'TOTAL_HARD_ARC_PAIR: passed=1; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    assert end['Passed'] and end['ChildHasExited'] and end['ChildExitCode']==timing['nativeExit']==0
    assert end['Closure']['Passed'] and not end['Closure']['OrdinaryPathKilledAnything']
    last=end['Closure']['FinalState']
    assert first['State']==last['State']=='Absent' and (last['PID'],last['StartTicksUTC'])==(own['PID'],own['StartTicksUTC'])
    log=(NATIVE/'Compile.log').read_text(encoding='utf-8-sig')
    assert re.findall(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',log,re.M)==[(str(first['PID']),first['StartTicksUTC'])]
    pre=[json.loads(l) for l in (HERE/'Run.ndjson').read_text(encoding='utf-8-sig').splitlines()]
    assert [p['phase'] for p in pre]==['PreCompileHardArc','PreNativeHardArc']
    assert all(p['ramMiB']>=6500 and p['freeCommitGiB']>=8 and p['freeC_MiB']>=80 for p in pre)
    assert all(x['ProtectedUser'] and x['Id'] not in (first['PID'],last['PID']) for p in pre for x in p['excel'])
    return {'compile':first,'native':last,'nativeWallSeconds':timing['wallSeconds'],'workbookSHA256':own['SourceSHA256']}


def verify():
    fixture=read(HERE/'Fixture.json')
    owned=closure(fixture)
    receipt=read(HERE/'HardShear-HistoryReceipt.json')
    history=rows(HERE/'HardShear-H68.csv')
    targets={int(line[1]):vector(line[2:],61) for line in rows(HERE/'HardShear-Reference.csv')[1:]}
    assert history[0]==['HARD_SHEAR','68','60'] and len(history)==69
    left={i:vector(history[i][2:],61) for i in (67,68)}
    old_gate={x['i']:x for x in receipt['historicalPostpeakMeasures']}
    geo={int(line[0]):vector(line[2:],3) for line in rows(HERE/'HardShear-Geometry.csv')[1:]}
    raw=NATIVE/'HardArcPair.csv'
    static={}; tagged=defaultdict(dict); points=defaultdict(dict)
    for kind,*line in rows(raw):
        if kind in ('DIM','LAW','OPTIONS','DIRECTION','OFFSET','EXTERNAL_ROWS','MEAN_CONTROL','BASE_SNAPSHOT','REPLAY_CONFIRMED','REPLAY_REJECTED'):
            assert kind not in static
            static[kind]=line
        elif kind=='POINT':
            label,index,*numbers=line
            idx=int(index); assert idx not in points[label]
            points[label][idx]=vector(numbers,9)
        else:
            label,*data=line
            assert label not in tagged[kind]
            tagged[kind][label]=data
    dim=vector(static['DIM'],8)
    assert dim[:7]==(60.,56.,4.,43.,25.,3.,21600.)
    area,length=dim[6:]; closeness(length,receipt['referenceLength_mm'],5e-13)
    scales=(area,area*length,area*length,area*length,area,area)
    law=vector(static['LAW'],9)
    for v,r in zip(law,(30000.,.2,30.,3.,16.,.002,.12,80.,125.)):
        closeness(v,r,3e-12)
    iterations,abs_tol,rel_tol,lam_scale,ratio,target=vector(static['OPTIONS'],6)
    assert iterations==30 and abs_tol==rel_tol==5e-7 and ratio==1.
    closeness(lam_scale,4.3209876543209875e-5,5e-19)
    offset=vector(static['OFFSET'],6)
    direction=vector(static['DIRECTION'],6)
    assert not any(offset)
    assert peak(a-b for a,b in zip(direction,BASE))<2e-8
    ext=vector(static['EXTERNAL_ROWS'],60)
    independently=[0.]*60
    for i,component in ((0,0),(1,1),(2,2),(3,3),(53,5),(54,4)):
        independently[i]=direction[component]/scales[component]
    assert peak(a-b for a,b in zip(ext,independently))<2e-14
    normal=vector(static['MEAN_CONTROL'],60)
    assert not any(normal[-4:])
    for i in (67,68):
        assert left[i]==vector(tagged['LEFT'][str(i)],61)
        closeness(fsum(a*b for a,b in zip(normal,left[i][1:])),old_gate[i]['orientedControlMinusMeanXZ'],5e-17)
    closeness(target,old_gate[69]['orientedControlMinusMeanXZ'],5e-17)
    q0=left[68][1:]
    dl_prev=left[68][0]-left[67][0]
    dq_prev=tuple(a-b for a,b in zip(q0[:56],left[67][1:57]))
    arc0=sqrt(fsum(x*x for x in dq_prev)+(lam_scale*dl_prev)**2)

    def balance(label):
        lam,tau,weak_max,gauge,ctrl,force,assembly,usage=vector(tagged['BALANCE'][label],8)
        q=vector(tagged['FIELD'][label],60)
        weak=vector(tagged['WEAK'][label],60)
        expected=tuple(lam*d for d in direction)
        actual=vector(tagged['WRENCH'][label],6)
        closeness(tau,abs_tol+rel_tol*abs(lam)*peak(ext[:56]),3e-19)
        closeness(weak_max,peak(weak[:56]),1e-14)
        closeness(gauge,E*peak(weak[56:]),1e-14)
        large=[[] for _ in expected]
        assert list(points[label])==list(range(1,44))
        for i,v in points[label].items():
            x,y,a,_,_,zz,_,xz,yz=v
            assert peak(m-n for m,n in zip((x,y,a),geo[i]))<=3e-12
            for target_parts,value in zip(large,(zz,y*zz,x*zz,x*yz-y*xz,xz,yz)):
                target_parts.append(a*value)
        integrated=tuple(map(fsum,large))
        stated=vector(tagged['INTEGRATED'][label],6)
        assert peak((a-b)/s for a,b,s in zip(integrated,stated,scales))<=5e-13
        closeness(force,peak((a-b)/s for a,b,s in zip(integrated,expected,scales)),5e-13)
        closeness(assembly,peak((a-b)/s for a,b,s in zip(integrated,actual,scales)),5e-13)
        arc_progress=None
        if label=='Mean':
            control=fsum(a*b for a,b in zip(normal,q))-target
        elif label=='Arc':
            delta=[a-b for a,b in zip(q[:56],q0[:56])]
            arc_progress=(fsum(a*b for a,b in zip(dq_prev,delta))+lam_scale**2*dl_prev*(lam-left[68][0]))/arc0
            control=arc_progress-arc0
        else:
            control=0.
        closeness(ctrl,E*control,5e-12)
        maximum=max(weak_max,gauge,abs(ctrl),force)
        return {'lambda':lam,'q':q,'allWeakAndGaugeRows':weak,'signedNativeWrench_N_Nmm':actual,
                'signedIndependentWrench_N_Nmm':integrated,'allBalanceNorm_MPa':maximum,'forceNorm_MPa':force,
                'assemblyDifference_MPa':assembly,'originalTolerance_MPa':tau,'fullBalanceQualified':maximum<=tau and assembly<=2e-10,
                'steelUtilization':usage,'orientedMeanXZ':fsum(a*b for a,b in zip(normal,q)),
                'recordedControlError_MPa':ctrl,'arcProgress':arc_progress}

    base=balance('Replay') if 'Replay' in tagged['BALANCE'] else None
    if base:
        assert base['q']==q0
        old=old_gate[68]['storedInternalWrench_N_Nmm']
        base['maxDifferenceFromArchivedH68Wrench_MPa']=peak((a-b)/s for a,b,s in zip(base['signedIndependentWrench_N_Nmm'],old,scales))
    confirmed='REPLAY_CONFIRMED' in static
    assert confirmed==bool(base and base['fullBalanceQualified']) and confirmed!=('REPLAY_REJECTED' in static)
    arms={}
    if confirmed:
        assert static['REPLAY_CONFIRMED']==['68'] and set(tagged['STATUS'])=={'Mean','Arc'}
        snapshot=vector(static['BASE_SNAPSHOT'],3*(9*43+2))
        for label in ('Mean','Arc'):
            solved,internal,code,lam,seconds=vector(tagged['STATUS'][label],5)
            assert solved in (0.,1.) and seconds>=0
            assert tagged['ROLLBACK'][label]==['60','129'] and tagged['REPLAY_ROLLBACK'][label]==['68','129']
            details=';'.join(tagged['DIAGNOSTIC'][label])
            reported=re.match(r'^Итерации: (\d+); пробы: (\d+);',details)
            assert reported
            arm={'solved':bool(solved),'status':int(internal),'code':int(code),'solverSeconds':seconds,
                 'solverIterations':int(reported[1]),'equilibriumEvaluations':int(reported[2]),
                 'acceptedHistoryExactAfterDiscardAndReplay':True,'detail':details}
            if solved:
                point=balance(label)
                assert point['lambda']==lam and tagged['QUALIFIED'][label]==['1' if point['fullBalanceQualified'] and lam>0 and point['steelUtilization']<=1. else '0']
                diff=[x-y for x,y in zip(point['q'][:56],targets[69][1:57])]
                actual_step=[x-y for x,y in zip(point['q'][:56],q0[:56])]
                point.update({'archiveH69LambdaDifference':lam-targets[69][0],
                              'archiveH69PhysicalMaxDifference':peak(diff),
                              'physicalIncrementMax':peak(actual_step),
                              'normalizedExternalIncrementWork_MPa':0.5*(lam+left[68][0])*fsum(x*y for x,y in zip(ext[:56],actual_step)),
                              'mechanicalDirectionCosineWithLastStep':fsum(x*y for x,y in zip(dq_prev,actual_step))/sqrt(
                                  fsum(x*x for x in dq_prev)*fsum(x*x for x in actual_step))})
                arm.update(point)
            arms[label]=arm
    else:
        assert not tagged['STATUS'] and not tagged['ROLLBACK']
    result={'inputsSHA256':fixture['frozen']['HardShear-H68.csv'],'rawSHA256':digest(raw),'closure':owned,
            'solverSHA256':fixture['arcSolverSHA256'],'workbookSourceSHA256':fixture['workbookSHA256'],
            'material':law,'dimensions':dim,'referenceH68CurrentLawAccepted':confirmed,'replayedBase':base,
            'replayRejection':static.get('REPLAY_REJECTED'),'arms':arms,'arcRatio':ratio,'stepLengthInScaledFields':arc0}
    path=HERE/'HardArcVerification.json'
    path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print('HARD_ARC_PAIR_PASS',digest(path),confirmed,{k:(v['solved'],v['solverIterations'],v.get('allBalanceNorm_MPa')) for k,v in arms.items()})


if __name__=='__main__':
    verify()
