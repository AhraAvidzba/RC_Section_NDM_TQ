"""Повторяет проверку сжатого бетона на сохранённой траектории MVT2."""

from argparse import ArgumentParser
from bisect import bisect_right
from gzip import compress, decompress
from hashlib import sha256
from io import BytesIO
import json
from math import acos, cos, pi, sqrt
from os import devnull
from pathlib import Path
from zipfile import ZipFile


EVIDENCE = Path('docs/regression/Coupled6D')
PINS = {
    'MVT2LocalTraction20261117': '452C888BDE17C478A212A18E48035B3AA5FA247EC0F0A102665547C79F5DEBCF',
    'MVT2GaussASDNominalStationEvents20261117': '995411807958875B23F169688738FEE6E4EBDEDAF8EAE63789A1EE2BA7AF899A',
    'MVT2GaussASDNominalP7NaturalSwitch20261117': '0BF8235F231C8373331A5D1CD938DDA8DF4A18F7987C70D9AFAAE17DDCB09726',
}
HERE = Path(__file__).resolve().parent
STATIONS = (0., .001, -.001)
RESPONSES = ('equivalentTotalStrain', 'equivalentPlasticStrain', 'damage')
RECORD = 'MVT2CompressionWire.json.gz'
SELECTED_N = (51562.5, 51855.46875, 54375., 55156.25)


def sha(data):
    """Возвращает контрольную сумму байтов источника."""
    return sha256(data).hexdigest().upper()


def pinned(repo, key):
    """Открывает архив только после сверки контрольной суммы."""
    data = (repo / EVIDENCE / (key+'.zip')).read_bytes()
    assert sha(data) == PINS[key]
    return ZipFile(BytesIO(data))


def read_inputs(repo):
    """Читает 53 принятых состояния и отдельную отклонённую пробу."""
    with pinned(repo, 'MVT2LocalTraction20261117') as archive:
        code = archive.read('Verify-MVT2LocalTraction.py')
    local = {'__name__': '__pinned__', '__file__': str(HERE/'Verify-MVT2LocalTraction.py')}
    exec(compile(code, local['__file__'], 'exec'), local)
    with pinned(repo, 'MVT2GaussASDNominalStationEvents20261117') as archive:
        station = json.loads(decompress(archive.read('StationFlagWire.json.gz')))
    with pinned(repo, 'MVT2GaussASDNominalP7NaturalSwitch20261117') as archive:
        failed = json.loads(decompress(archive.read('P7NaturalSwitchWire.json.gz')))
    assert station['exact_H53_replayed'] and failed['history_before'] == failed['history_after'] == 53
    history = local['history'](repo)
    assert len(history) == 53 and history[-1][0]['Q_target_N'] == 55156.25
    section = failed['candidate']['section']
    assert section['norm_MPa'] > section['tolerance_MPa']
    assert failed['target'] == [0., -33140625., 0., 10510000., 0., 55234.375]
    return local, history, station['model_command'], failed


def capture(repo, target):
    """Повторяет материальную историю по точным полям из архивов OpenSees 3.8.0."""
    import numpy as np
    import openseespy.opensees as ops

    assert ops.version() == '3.8.0' and np.__version__ == '2.3.5'
    local, history, command, failed = read_inputs(repo)
    _, directions, _, _, _ = local['geometry'](repo)
    with local['archive'](repo, 'operators') as archive:
        raw = archive.read('Native/Operators.csv')
    rows = [row.split(';') for row in raw.decode('ascii').splitlines() if row.startswith('B;')]
    active = {(int(p), int(col)): [float(v) for v in components] for _, p, col, *components in rows}
    assert len(active) == len(rows) == 45*60
    operators = np.array([[active[p, column] for column in range(1, 61)]
                          for p in range(1, 46)]).transpose(0, 2, 1).copy()
    b = operators[:, :6, :].copy()
    z = operators[:, 6:, :].copy()
    shape = np.stack((b, b+STATIONS[1]*z, b+STATIONS[2]*z))

    def evaluate(field, read_full_response):
        """Сохраняет точные тензоры бетона и историю в точках квадратуры."""
        strain = shape @ np.asarray(field)
        concrete = [[], [], []]
        markers = [[], [], []]
        for angle, station in enumerate(strain):
            for point, eps in enumerate(station):
                tag = 1 + 45*angle + point
                ex, ey, ez, gxy, gxz, gyz = eps
                vector = (ex, ey, ez, gxy, gyz, gxz)  # Порядок OpenSees переставляет два последних сдвига.
                ops.NDTest('SetStrain', tag, *vector)
                assert tuple(ops.NDTest('GetStrain', tag)) == vector
                xx, yy, zz, xy, yz, xz = ops.NDTest('GetStress', tag)
                concrete[angle].append([xx, yy, zz, xy, xz, yz])
                if read_full_response and point < 25:
                    markers[angle].append([list(ops.NDTest('GetResponse', tag, label)) for label in RESPONSES])
        return concrete, markers

    ops.wipe()
    ops.logFile(devnull, '-noEcho')  # Служебные теги NDTest не нужны для числовой сверки.
    ops.model('basic', '-ndm', 3, '-ndf', 3)
    for tag in range(1, 136):
        ops.nDMaterial(command[0], tag, *command[1:])
    curves = { side: [list(ops.NDTest('GetResponse', 1, side+item)) for item in 'esq']
               for side in 'TC' }
    accepted = []
    exact_max = 0.
    try:
        for index, (step, stored_net, steel) in enumerate(history, 1):
            inspect = step['Q_target_N'] in SELECTED_N
            concrete, response = evaluate(step['field'], inspect)
            net = np.asarray(concrete)
            bar_stresses = np.asarray(steel[local['STEEL_COLUMN']])[:, :, 1]
            net[:, 25:] = -net[:, 25:] + bar_stresses[:, :, None]*np.asarray(directions)[None, :, :]
            delta = float(np.max(np.abs(net-np.asarray(stored_net))))
            exact_max = max(exact_max, delta)
            assert delta < 1e-12, (index,delta)
            if inspect:
                accepted.append({'step':index,'Qy_N':step['Q_target_N'],'response':response})
            for tag in range(1, 136):
                ops.NDTest('CommitState', tag)
        probe_concrete, probe = evaluate(failed['candidate']['field'], True)
        reference_net = failed['candidate']['section']['net_stresses_MPa']
        probe_error = float(np.max(np.abs(np.asarray(probe_concrete)[:, :25]-np.asarray(reference_net)[:, :25])))
        assert probe_error < 1e-12, probe_error
    finally:
        ops.wipe()
    wire = {'model_command': command, 'curve_columns_e_s_q': curves, 'responses_T_C': RESPONSES,
            'accepted': accepted, 'candidate_uncommitted': probe, 'version': ops.version(),
            'numpy': np.__version__, 'accepted_net_stress_max_error_MPa': exact_max,
            'replayed_accepted_fields':len(history),
            'candidate_gross_concrete_error_MPa': probe_error, 'operator_csv_sha256': sha(raw)}
    data = json.dumps(wire, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
    with target.open('xb') as out:
        out.write(compress(data, mtime=0))


def interpolate(xs, ys, x):
    """Интерполирует табличную ординату для эквивалентной меры."""
    upper = min(max(bisect_right(xs,x),1),len(xs)-1)
    low = upper - 1
    return ys[low]+(ys[upper]-ys[low])*(x-xs[low])/(xs[upper]-xs[low])


def minimum_principal(tensor):
    """Находит наименьшее главное напряжение симметричного тензора 3×3."""
    xx, yy, zz, xy, xz, yz = tensor
    mean = (xx+yy+zz)/3.
    x, y, z = xx-mean, yy-mean, zz-mean
    scale = sqrt((x*x+y*y+z*z+2.*(xy*xy+xz*xz+yz*yz))/6.)
    if scale == 0.:
        return mean
    det = (x*y*z+2.*xy*xz*yz-x*yz*yz-y*xz*xz-z*xy*xy)/(2.*scale**3)
    phi = acos(min(1.,max(-1.,det)))/3.
    return mean+2.*scale*cos(phi+2.*pi/3.)


def describe(response, net, points, peaks, prior):
    """Находит определяющие точки по сжатию, пластичности и растяжению."""
    rows = []
    for sid, (z, station, tensors, before) in enumerate(zip(STATIONS, response, net, prior, strict=True)):
        assert len(station) == len(before) == 25 and len(tensors) == 45
        for point, ((eq, plastic, damage), tensor, previous) in enumerate(zip(station, tensors[:25], before, strict=True), 1):
            assert len(eq) == len(plastic) == len(damage) == 2
            assert all(a >= b - 1e-16 for a,b in zip(eq,previous[0],strict=True))
            assert all(0. <= d < 1. for d in damage)
            if point <= 25:
                rows.append({'point':point,'x_y_mm':points[point-1][:2], 'z_mm':z,
                             'k_c':eq[1], 'k_t':eq[0], 'plastic_c':plastic[1],
                             'damage_c':damage[1], 'damage_t':damage[0],
                             'sigma_min_MPa':minimum_principal(tensor), 'sigma_zz_MPa':tensor[2]})
    center = [r for r in rows if r['z_mm']==0.]
    return {
        'max_compression_measure':max(rows,key=lambda r:r['k_c']),
        'max_compression_measure_center':max(center,key=lambda r:r['k_c']),
        'largest_principal_compression':min(rows,key=lambda r:r['sigma_min_MPa']),
        'largest_center_axial_compression':min(center,key=lambda r:r['sigma_zz_MPa']),
        'compression_measure_over_peak':max(r['k_c'] for r in rows)/peaks['C'],
        'compression_postpeak_gross_stations':sum(r['k_c']>peaks['C'] for r in rows),
        'tension_postpeak_gross_stations':sum(r['k_t']>peaks['T'] for r in rows),
        'max_compression_plastic_measure':max(r['plastic_c'] for r in rows),
        'max_compression_damage':max(r['damage_c'] for r in rows),
        'max_tension_damage':max(r['damage_t'] for r in rows),
    }


def check_tabulated_response(curves, response, young, table_error):
    """Сверяет ответы OpenSees с определениями через номинальную и эффективную кривые."""
    for station in response:
        for equivalent, plastic, damage in station:
            for i,key in enumerate('TC'):
                strain, nominal, effective = curves[key]
                x=equivalent[i]
                if x<strain[1]:
                    continue  # В первом интервале ASD ограничивает нулевую ординату своим допуском.
                s=interpolate(strain,nominal,x)
                q=interpolate(strain,effective,x)
                table_error[0]=max(table_error[0],abs((1.-s/q)-damage[i]))
                table_error[1]=max(table_error[1],abs((x-q/young)-plastic[i]))


def verify(repo, source):
    """Проверяет данные модели относительно принятой истории и фактической кривой."""
    local, history, command, failed = read_inputs(repo)
    points, _, area, length, _ = local['geometry'](repo)
    raw = source.read_bytes()
    wire = json.loads(decompress(raw))
    assert wire['model_command'] == command and wire['version']=='3.8.0' and wire['numpy']=='2.3.5'
    assert tuple(wire['responses_T_C']) == RESPONSES
    assert wire['accepted_net_stress_max_error_MPa'] < 1e-12
    assert wire['candidate_gross_concrete_error_MPa'] < 1e-12
    curves = wire['curve_columns_e_s_q']
    peaks = {}
    table_error = [0.,0.]
    for label, (e,s,q) in curves.items():
        assert len(e)==len(s)==len(q) and all(x<y for x,y in zip(e,e[1:]))
        peak = s.index(max(s))
        assert 1<peak<len(e)-1 and s[peak]>s[peak+1] and s[peak-1]<s[peak]
        peaks[label] = e[peak]
    details = []
    prior = [[[[0.,0.],[0.,0.],[0.,0.]] for _ in range(25)] for _ in STATIONS]
    largest = max_contract_residual = 0.
    peak_station_count = compression_damage_station_count = 0
    max_tension_damage = 0.
    recording = {item['step']:item for item in wire['accepted']}
    assert len(recording)==len(wire['accepted'])==len(SELECTED_N)
    for index, (step, net, _) in enumerate(history,1):
        n, t = step['Q_target_N'], step['T_target_Nmm']
        actual = local['signed_forces'](net[0],points)
        expected = (0.,-600.*n,0.,t,0.,n)
        scale = (area,area*length,area*length,area*length,area,area)
        err = max(abs(a-b)/s for a,b,s in zip(actual,expected,scale,strict=True))
        assert err<=step['tolerance_MPa']
        max_contract_residual=max(max_contract_residual,err)
        if index not in recording:
            continue
        item=recording[index]
        assert item['Qy_N']==n
        response=item['response']
        result=describe(response,net,points,peaks,prior)
        check_tabulated_response(curves,response,command[1],table_error)
        largest=max(largest,result['compression_measure_over_peak'])
        peak_station_count+=result['compression_postpeak_gross_stations']
        compression_damage_station_count+=sum(response[s][p][2][1]>0. for s in range(3) for p in range(25))
        max_tension_damage=max(max_tension_damage,result['max_tension_damage'])
        details.append({'Qy_N':n, 'accepted_sequence':index, **result})
        prior = response
    section=failed['candidate']['section']
    probe=describe(wire['candidate_uncommitted'],section['net_stresses_MPa'],points,peaks,prior)
    check_tabulated_response(curves,wire['candidate_uncommitted'],command[1],table_error)
    assert largest<1. and len(history)==wire['replayed_accepted_fields']==53 and peak_station_count==0
    assert details[-1]['Qy_N']==55156.25 and len(details)==len(SELECTED_N)
    assert section['norm_MPa']>section['tolerance_MPa']
    assert table_error[0] < 1e-12 and table_error[1] < 1e-12,table_error
    return {'status':'PASS','source_archives':PINS,'material_command':command,
            'curve_columns_e_s_q':curves,'compression_peak_equivalent_measure':peaks['C'],
            'compression_peak_nominal_MPa':max(curves['C'][1]),
            'tensile_peak_equivalent_measure':peaks['T'],
            'accepted_steps_replayed':len(history), 'gross_concrete_state_station_samples':len(details)*75,
            'accepted_net_stress_max_error_MPa':wire['accepted_net_stress_max_error_MPa'],
            'unaccepted_probe_gross_stress_max_error_MPa':wire['candidate_gross_concrete_error_MPa'],
            'maximum_reintegrated_action_residual_MPa':max_contract_residual,
            'maximum_tabulated_damage_and_plastic_measure_errors':table_error,
            'sampled_accepted_maximum_k_c_over_peak':largest,
            'sampled_accepted_concrete_station_samples_past_compression_peak':peak_station_count,
            'sampled_accepted_concrete_station_samples_with_compression_damage':compression_damage_station_count,
            'sampled_accepted_maximum_tension_damage':max_tension_damage,
            'selected_accepted_states':details,
            'unaccepted_probe':{'target':failed['target'],'residual_MPa':section['norm_MPa'],
                                'tolerance_MPa':section['tolerance_MPa'],**probe},
            'history_wire_sha256':sha(raw),'experiment_crushed_at_Qy_N':80000.,
            'experimental_benchmark_paper_doi':'10.1371/journal.pone.0175834',
            'experimental_benchmark_paper_sha256':local['PAPER_SHA'],
            'physical_capacity_established':False}


def main():
    """Создаёт материальный протокол или повторяет его автономную сверку."""
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--report',type=Path)
    parser.add_argument('--capture',type=Path)
    parser.add_argument('--wire',type=Path,default=HERE/RECORD)
    parser.add_argument('--literature',type=Path)
    args=parser.parse_args()
    if args.capture:
        capture(args.repo,args.capture)
        print('MVT2 ASD MATERIAL COMPRESSION CAPTURED',sha(args.capture.read_bytes()))
        return
    report=verify(args.repo,args.wire)
    if args.literature:
        path=args.literature/'Wang-Huang-2017-MVT-NMVT.pdf'
        assert sha(path.read_bytes())==report['experimental_benchmark_paper_sha256']
    with args.report.open('x',encoding='utf-8',newline='\n') as out:
        json.dump(report,out,ensure_ascii=False,sort_keys=True,indent=2)
        out.write('\n')
    print('MVT2 COMPRESSION HISTORY OFFLINE PASS',report['accepted_steps_replayed'])


if __name__ == '__main__':
    main()
