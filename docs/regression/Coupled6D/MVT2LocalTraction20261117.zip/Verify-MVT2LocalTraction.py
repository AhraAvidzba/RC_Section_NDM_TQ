"""Replay MVT2 steel and local traction from pinned, accepted section fields."""

import argparse
import gzip
import hashlib
import json
import math
from pathlib import Path
from zipfile import ZipFile


EVIDENCE = Path("docs/regression/Coupled6D")
SOURCES = {
    "geometry": ("MVT2GaussTensorCaptureNative20261117", "D2DBF6FDE48CDB5997FD099056DEC49231EEABE6D018D817E809C3F951D801A1"),
    "operators": ("MVT2GaussSpatialOperatorsNative20261117", "8807822311947EDB91EB483B6FDC8F359F95BCE10F9B36286E12DE7F37932D5A"),
    "postyield": ("MVT2GaussASDNominalPostyield20261117", "06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED"),
    "continuation": ("MVT2GaussASDNominalDirectionalFollow20261117", "53E7D62932498F6EEC71BAA39120920B814E3F34410A245F818B4EB982501E69"),
}
PAPER_SHA = "6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E"
STEEL_COLUMN = "columns_strain_stress_tangent_plastic_backstress_increment"
STATIONS = (0., .001, -.001)
TRAVEL = (51562.5, 51640.625, 51855.46875, 54375., 54726.5625, 55000., 55156.25)
FACES = (
    ("bottom left", 0, (1, 2)),
    ("left lower", 1, (1, 6)),
    ("bottom right", 0, (4, 5)),
    ("right lower", 1, (5, 10)),
)


def digest(data):
    return hashlib.sha256(data).hexdigest().upper()


def archive(repo, key):
    stem, expected = SOURCES[key]
    path = repo / EVIDENCE / (stem + ".zip")
    assert digest(path.read_bytes()) == expected, path
    return ZipFile(path)


def geometry(repo):
    with archive(repo, "geometry") as source:
        wire = source.read("Native/MVTGaussMixed.csv")
    rows = [line.split(";") for line in wire.decode("cp1251").splitlines()]
    header, = [row for row in rows if row[0] == "MVT_GEOM"]
    assert header[1:4] == ["25", "45", "60"]
    x0, y0, area, length = map(float, header[4:])
    assert (x0, y0, area) == (0., 0., 57600.)
    points = [row[1:] for row in rows if row[0] == "MVT_POINT"]
    assert [int(row[0]) for row in points] == list(range(1, 46))
    values = [tuple(map(float, row[1:])) for row in points]
    pos = [row[:3] for row in values]
    assert abs(math.fsum(a for _, _, a in pos[:25]) - area) < 2e-8
    assert [row[:2] for row in pos[25:29]] == [(-84., -84.), (-84., 84.), (84., -84.), (84., 84.)]
    assert all(abs(a - math.pi * 16.**2 / 4.) < 1e-11 for _, _, a in pos[25:29])
    dirs = [row[3:] for row in values[25:]]
    for side in range(4):
        hoop = pos[29+4*side:33+4*side]
        axis = 1 - side % 2
        axis_coordinate = (-96., 96., 96., -96.)[side]
        assert all(row[axis] == axis_coordinate for row in hoop)
        assert abs(math.fsum(row[2] for row in hoop) - 192. * math.pi * 8.**2 / 240.) < 1e-10
    return pos, dirs, area, length, digest(wire)


def steel_projectors(repo, directions):
    with archive(repo, "operators") as source:
        wire = source.read("Native/Operators.csv")
    records = [line.split(";") for line in wire.decode("ascii").splitlines() if line.startswith("B;")]
    columns = {(int(row[1]), int(row[2])): tuple(map(float, row[3:])) for row in records}
    assert len(records) == len(columns) == 45 * 60
    projectors = []
    for p, direction in enumerate(directions, 26):
        pairs = []
        for column in range(1, 61):
            center_gradient = columns[p, column]
            assert len(center_gradient) == 12
            pairs.append(tuple(math.fsum(a*b for a, b in zip(center_gradient[offset:offset+6], direction, strict=True))
                               for offset in (0, 6)))
        projectors.append(tuple(pairs))
    return projectors, digest(wire)


def history(repo):
    cases = (("postyield", "Postyield", "net_three_station_stress_MPa", "steel"),
             ("continuation", "FollowCorrected", "three_station_net_stresses", "three_station_steel"))
    steps = []
    for key, stem, stress_key, steel_key in cases:
        with archive(repo, key) as source:
            trace = json.loads(source.read(stem + ".json"))
            wire = json.loads(gzip.decompress(source.read(stem + ".stress.json.gz")))
        accepted = trace["result"]["accepted"] if key == "postyield" else trace["all_accepted"]
        assert len(accepted) == (49 if key == "postyield" else 4)
        steps.extend(zip(accepted, wire[stress_key], wire[steel_key], strict=True))
    return steps


def signed_forces(center, points):
    accumulated = [[] for _ in range(6)]
    for tensor, (x, y, area) in zip(center, points, strict=True):
        _, _, axial, _, shear_x, shear_y = tensor
        terms = (axial, axial*y, axial*x, shear_y*x-shear_x*y, shear_x, shear_y)
        for bucket, term in zip(accumulated, terms, strict=True):
            bucket.append(area * term)
    return tuple(math.fsum(values) for values in accumulated)


def projected_traction(tensor, tangent_axis):
    xx, yy, zz, xy, xz, yz = tensor
    normal_tensor = ((xx, xy, xz), (xy, yy, yz), (xz, yz, zz))
    out_axis = 1 - tangent_axis
    sigma_tt = normal_tensor[tangent_axis][tangent_axis]
    shear_zt = normal_tensor[2][tangent_axis]
    angle = .5 * math.atan2(2.*shear_zt, zz-sigma_tt)
    n_z, n_t = math.cos(angle), math.sin(angle)
    f1 = .5 * (zz + sigma_tt + math.hypot(zz-sigma_tt, 2.*shear_zt))
    n = [0., 0., n_z]
    n[tangent_axis] = n_t
    traction = [math.fsum(a*b for a, b in zip(row, n, strict=True)) for row in normal_tensor]
    assert abs(traction[2] - f1*n_z) < 3e-14
    assert abs(traction[tangent_axis] - f1*n_t) < 3e-14
    actual_normal = math.fsum(a*b for a, b in zip(traction, n, strict=True))
    assert abs(actual_normal - f1) < 3e-14
    return {
        "projected_tension_MPa": f1,
        "crack_acute_angle_to_z_deg": 90. - abs(math.degrees(angle)),
        "full_traction_xyz_MPa": traction,
        "out_of_face_tangential_traction_MPa": traction[out_axis],
        "out_of_face_over_projected_tension": abs(traction[out_axis])/f1 if f1 > 0. else None,
    }


def observations(path, points, projectors, area, length):
    first_yield = {}
    previous_plastic = [[0.] * 20 for _ in STATIONS]
    selected = []
    max_force_error = max_projection_error = max_stress_error = 0.
    max_hoop_tension = 0.
    for step, net, steel in path:
        q, t, field = step["Q_target_N"], step["T_target_Nmm"], step["field"]
        if q:
            assert t == 10510000.
        assert len(field) == 60 and len(net) == 3 and all(len(a) == 45 for a in net)
        assert all(len(a) == 6 and all(map(math.isfinite, a)) for s in net for a in s)
        applied = (0., -600.*q, 0., t, 0., q)
        actual = signed_forces(net[0], points)
        scale = (area, area*length, area*length, area*length, area, area)
        err = max(abs(a-b)/r for a, b, r in zip(actual, applied, scale, strict=True))
        assert err <= step["tolerance_MPa"]
        assert max(abs(a-b) for a, b in zip(actual, step["resultants_N_Nmm"], strict=True)) < 3e-8
        max_force_error = max(max_force_error, err)
        stations = []
        for sid, (z, rows) in enumerate(zip(STATIONS, steel[STEEL_COLUMN], strict=True)):
            maxima = []
            for index, ((strain, stress, tangent, plastic, backstress, increment), projection) in enumerate(zip(rows, projectors, strict=True)):
                p = 26 + index
                cap = 498. if p <= 29 else 450.
                predicted_strain = math.fsum((c+z*g)*v for (c, g), v in zip(projection, field, strict=True))
                old = previous_plastic[sid][index]
                elastic_trial = 200000. * (strain - old)
                expected = min(cap, max(-cap, elastic_trial))
                expected_tangent = 0. if abs(elastic_trial) > cap else 200000.
                max_projection_error = max(max_projection_error, abs(predicted_strain-strain))
                max_stress_error = max(max_stress_error, abs(expected-stress))
                assert abs(predicted_strain-strain) < 5e-18 and abs(expected-stress) < 4e-11
                assert abs(strain - expected/200000. - plastic) < 2e-17
                assert abs(plastic - old - increment) < 2e-17 and tangent == expected_tangent and backstress == 0.
                assert abs(strain) < .05
                previous_plastic[sid][index] = plastic
                if expected_tangent == 0.:
                    assert increment > 0. and stress == 498.
                    first_yield.setdefault((z, p), q)
                if p > 29:
                    maxima.append((stress, p))
            hoopt, hoop_id = max(maxima)
            max_hoop_tension = max(max_hoop_tension, hoopt)
            stations.append({"z_mm": z, "longitudinal_stress_MPa": [a[1] for a in rows[:4]],
                             "maximum_hoop_tension_MPa": hoopt, "maximum_hoop_point": hoop_id})
        if q in TRAVEL:
            faces = []
            for face, axis, locations in FACES:
                for p in locations:
                    faces.append({"face": face, "concrete_point": p, "x_y_mm": points[p-1][:2],
                                  **projected_traction(net[0][p-1], axis)})
            selected.append({"Qy_N": q, "stations": stations, "central_face_projections": faces})
    assert tuple(row["Qy_N"] for row in selected) == TRAVEL
    assert first_yield == {(-.001, 28): 51640.625, (0., 28): 51855.46875, (.001, 28): 51855.46875,
                           (-.001, 26): 54375., (0., 26): 54726.5625, (.001, 26): 55000.}
    assert 186.02 < max_hoop_tension < 186.05
    return {
        "accepted_section_states": len(path), "max_force_error_normalized_MPa": max_force_error,
        "max_steel_projection_error": max_projection_error, "max_steel_stress_error_MPa": max_stress_error,
        "first_local_tensile_yield": [{"z_mm": z, "bar": p, "Qy_N": q} for (z, p), q in first_yield.items()],
        "maximum_hoop_tension_MPa": max_hoop_tension,
        "maximum_hoop_tension_over_yield": max_hoop_tension/450.,
        "selected": selected,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--literature", type=Path)
    args = parser.parse_args()
    if args.literature is not None:
        assert digest((args.literature / "Wang-Huang-2017-MVT-NMVT.pdf").read_bytes()) == PAPER_SHA
    points, dirs, area, length, geometry_hash = geometry(args.repo)
    projectors, operator_hash = steel_projectors(args.repo, dirs)
    report = observations(history(args.repo), points, projectors, area, length)
    terminal = report["selected"][-1]
    corner = [row for row in terminal["central_face_projections"] if row["concrete_point"] == 5]
    assert len(corner) == 2 and all(row["out_of_face_over_projected_tension"] > 2. for row in corner)
    assert abs(corner[0]["crack_acute_angle_to_z_deg"] - corner[1]["crack_acute_angle_to_z_deg"]) > 10.
    report.update({
        "source_archives": SOURCES, "geometry_csv_sha256": geometry_hash, "operator_csv_sha256": operator_hash,
        "paper_sha256": PAPER_SHA, "paper_doi": "10.1371/journal.pone.0175834",
        "experiment_longitudinal_yield_inferred_Qy_N": 67500., "experiment_concrete_crushing_Qy_N": 80000.,
        "crack_patch_forces_identified": False, "section_capacity_identified": False, "status": "PASS",
    })
    args.report.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2)+"\n", encoding="utf-8")
    print("MVT2 LOCAL TRACTION OFFLINE PASS", report["accepted_section_states"], report["maximum_hoop_tension_MPa"])


if __name__ == "__main__":
    main()
