"""ДЛЯ ТЕСТОВ. Проверяет три фактические книги и исходные признаки потери направления полного Newton."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestFiles(root):
    """Архив сохраняет все исходные попытки без изменения численных данных ради приёмки."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == '62000fe'


def TestNative(repo, root, output):
    """Один PASS каждой книги относится к настройке опыта и неизменности истории, а не к успеху нелинейного решателя."""
    TestFiles(root)
    result = {}
    for key in ('Newton', 'Branches', 'Active'):
        folder = root / 'Cases' / key
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Code.json'
            run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit'](repo, folder, proof)
            record = json.loads(proof.read_bytes())
        assert (record['components'], record['imported'], record['unchanged']) == (244, 30, 214)
        assert len(record['checked_coupled_sources']) == 33
        path = folder / 'Native/ReversePolish.txt'
        log = path.read_text('utf-8-sig')
        assert {file.name for file in (folder / 'Native').glob('*.txt')} == {'ReversePolish.txt'}
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log and 'RUNTIME ERROR:' not in log
        assert 'TOTAL_REVERSE_POLISH_STUDY_TEST: passed=1; failed=0; numerical_outcomes_recorded_not_asserted; capacity_certified=False' in log
        source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
        assert source == record['compiled_workbook_sha256']
        closure = json.loads(path.with_name(path.name + '.ProcessClosure.json').read_bytes())
        assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
        assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
        record['native_setup_and_history_checks'] = 1
        record['owned_excel_absent'] = True
        result[key] = record
    output.write_text(json.dumps({'cases': result, 'working_runtime_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('THREE NEWTON STUDY ACTUAL VBA PROJECTS AND HISTORY CHECKS VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Проверяет арифметику, выбор стороны, изменение невязки и отдельно наличие либо отсутствие строгого корня."""
    TestFiles(root)
    results = {}
    for key, script in (('Newton', 'Analyze-TestNewtonLine.py'), ('Branches', 'Analyze-TestNewtonBranches.py'),
                        ('Active', 'Analyze-TestNewtonLine.py')):
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Analysis.json'
            run_path(str(root / script))['TestAnalyze'](root / 'Cases' / key, proof)
            results[key] = json.loads(proof.read_bytes())
    baseline = root / 'Cases/Newton/Input/Reverse1.bin'
    raw = baseline.read_bytes()
    for key in ('Branches', 'Active'):
        assert (root / 'Cases' / key / 'Input/Reverse1.bin').read_bytes() == raw
    branch = results['Branches']['cases']
    for key in ('0', '1'):
        switches = branch[key]['coordinate_branch_switches']
        assert set(switches) == {'1:25'}
        assert not switches['1:25']['base']['plastic'] and switches['1:25']['base']['yield_MPa'] < 0
        assert branch[key]['leading_to_second_asymmetry_ratio'] > 100000
        initial = results['Newton']['cases'][key]
        assert not initial['strict_root_found'] and initial['stop'] == 'NO_DESCENT_WITHIN_LINE_BUDGET'
        last = initial['iterations'][-1]
        assert last['chosen_line'] == 0
        assert all(item['merit_ratio_to_base'] > 1 for item in last['trials'] if item['material_evaluated'])
    result = {'studies': results, 'common_accepted_history_binary_exact': True,
        'switching_point_identified_in_both_terminal_fields': 'plus station, point 25',
        'new_method_critical_point_hardcoded': False, 'independent_material_reintegration': False,
        'working_runtime_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False}
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('NEWTON COMPLETE EQUATIONS AND MATERIAL BRANCH LOCALIZATION VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
