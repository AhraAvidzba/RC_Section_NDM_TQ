"""ДЛЯ ТЕСТОВ. Связывает асимметрию полной производной с прочитанными локальными ветвями материала."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestAnalyze(root, output):
    """Локальная смена ветви является диагностикой; существование строгого корня или предела ею не доказывается."""
    read = run_path(str(Path(__file__).resolve().parent / 'Analyze-TestNewtonLine.py'))['TestRead']
    rows = list(csv.reader((root / 'Native/NewtonBranches.csv').read_text('cp1251').splitlines(), delimiter=';'))
    residuals, branches = {}, {}
    for row in rows:
        if row[0] not in ('RESIDUAL', 'BRANCH'):
            continue
        key = tuple(map(int, row[1:5]))
        alpha = float(row[5])
        if row[0] == 'RESIDUAL':
            assert key not in residuals
            residuals[key] = np.asarray([float(value) for value in row[6:]])
            assert residuals[key].shape == (61,)
        else:
            point = (int(row[6]), int(row[7]))
            entry = {'alpha': alpha, 'yield_MPa': float(row[8]), 'plastic': row[9] == 'True',
                     'principal_sign': int(row[10]), 'substeps': int(row[11])}
            assert point not in branches.setdefault(key, {})
            branches[key][point] = entry
    assert len(residuals) == len(branches) == 2 * (1 + 2 * 56 + 8)
    result = {}
    for case in (0, 1):
        data = read(root / f'Input/Source.C{case}I10.bin')
        base = branches[(case, 0, 0, 0)]
        assert len(base) == 3 * 43
        np.testing.assert_allclose(residuals[(case, 0, 0, 0)], data['residual'], rtol=1e-14, atol=1e-300)
        switches = {}
        for column in range(1, 57):
            minus, plus = branches[(case, 1, column, -1)], branches[(case, 1, column, 1)]
            assert set(minus) == set(plus) == set(base)
            for sign, field in ((1, 'plus'), (-1, 'minus')):
                np.testing.assert_allclose(residuals[(case, 1, column, sign)], data[field][:, column - 1], rtol=1e-14, atol=1e-300)
            for point in base:
                a, b = minus[point], plus[point]
                if (a['plastic'], a['principal_sign'], a['substeps']) != (b['plastic'], b['principal_sign'], b['substeps']):
                    key = f'{point[0]}:{point[1]}'
                    switches.setdefault(key, {'base': base[point], 'columns': []})['columns'].append(
                        {'column': column, 'minus': a, 'plus': b})
        asymmetric = (data['plus'] + data['minus'] - 2 * data['residual'][:, None]) / data['sizes'][None, :]
        singular = np.linalg.svd(asymmetric, compute_uv=False)
        direction = []
        for index in range(4):
            item = {'amplitude': 10. ** (-2 - index), 'switches': []}
            minus, plus = branches[(case, 2, index, -1)], branches[(case, 2, index, 1)]
            for point in base:
                a, b = minus[point], plus[point]
                if (a['plastic'], a['principal_sign'], a['substeps']) != (b['plastic'], b['principal_sign'], b['substeps']):
                    item['switches'].append({'station': point[0], 'point': point[1], 'minus': a, 'plus': b})
            rp, rm = residuals[(case, 2, index, 1)], residuals[(case, 2, index, -1)]
            derivative = (rp - rm) / (2 * item['amplitude'])
            item['central_direction_relative_error'] = float(np.linalg.norm(derivative - data['jacobian'] @ data['correction']) / np.linalg.norm(data['residual']))
            item['positive_merit_ratio'] = float(np.linalg.norm(rp) / np.linalg.norm(data['residual']))
            item['negative_merit_ratio'] = float(np.linalg.norm(rm) / np.linalg.norm(data['residual']))
            direction.append(item)
        result[str(case)] = {'coordinate_branch_switches': switches, 'direction_probes': direction,
            'one_sided_asymmetry_singular_values_first_six': singular[:6].tolist(),
            'leading_to_second_asymmetry_ratio': float(singular[0] / singular[1]),
            'base_branch_count': len(base), 'branch_count_per_probe': len(base)}
        print('CASE', case, 'SWITCHING POINTS', list(switches), 'ASYMMETRY RANK RATIO', singular[0] / singular[1])
        for point, item in switches.items():
            print('POINT', point, 'BASE', item['base'], 'COORDINATES', len(item['columns']))
    output.write_text(json.dumps({'cases': result, 'terminal_residuals_native_binary_exact_asserted': True,
        'all_coordinate_residuals_match_original_samples': True, 'accepted_history_unchanged': True,
        'physical_capacity_certified': False, 'working_runtime_changed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('TERMINAL NEWTON LOCAL BRANCHES AND DIRECTION PROBES VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
