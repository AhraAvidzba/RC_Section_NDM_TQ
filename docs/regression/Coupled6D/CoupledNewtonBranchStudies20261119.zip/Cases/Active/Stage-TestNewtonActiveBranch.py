"""ДЛЯ ТЕСТОВ. Проверяет выбор стороны полной разности по общей фактической материальной ветви."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Не содержит номера особой точки: совпадение проверяется по всем бетонным точкам трёх историй."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestNewtonLine.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    def TestOnce(old, new):
        """Подстановка допустима только в однозначном месте частного теста."""
        nonlocal code
        assert code.count(old) == 1, old
        code = code.replace(old, new, 1)
    TestOnce('    Dim positiveSamples() As Double, negativeSamples() As Double, beforeMatrix() As Double',
             '''    Dim positiveSamples() As Double, negativeSamples() As Double, beforeMatrix() As Double
    Dim baseSignature As Variant, positiveBranches As Collection, negativeBranches As Collection, choices() As Long
    Dim plusMatches As Boolean, minusMatches As Boolean, signatureReads As Long''')
    TestOnce('        For column = 1 To count\n            delta =', '''        baseSignature = TestNewtonMaterialSignature(solver, x): signatureReads = signatureReads + 1
        Set positiveBranches = New Collection: Set negativeBranches = New Collection: ReDim choices(1 To count)
        For column = 1 To count
            delta =''')
    TestOnce('            point(column) = x(column) - delta: calls = calls + 1', '''            positiveBranches.Add TestNewtonMaterialSignature(solver, point): signatureReads = signatureReads + 1
            point(column) = x(column) - delta: calls = calls + 1''')
    TestOnce('            For row = 1 To count\n                positiveSamples', '''            negativeBranches.Add TestNewtonMaterialSignature(solver, point): signatureReads = signatureReads + 1
            plusMatches = TestNewtonSameSignature(baseSignature, positiveBranches(column))
            minusMatches = TestNewtonSameSignature(baseSignature, negativeBranches(column))
            If Not plusMatches And Not minusMatches Then outcome = "NO_SAME_BRANCH_DIFFERENCE": GoTo Finished
            If plusMatches And Not minusMatches Then choices(column) = 1
            If minusMatches And Not plusMatches Then choices(column) = -1
            For row = 1 To count
                positiveSamples''')
    TestOnce('                jacobian(column, row) = (plus(row) - minus(row)) / (2# * delta)', '''                If choices(column) = 1 Then
                    jacobian(column, row) = (plus(row) - residual(row)) / delta
                ElseIf choices(column) = -1 Then
                    jacobian(column, row) = (residual(row) - minus(row)) / delta
                Else
                    jacobian(column, row) = (plus(row) - minus(row)) / (2# * delta)
                End If''')
    TestOnce('            trialCoordinates, trialResiduals, trialFlags, trialAlphas, chosen',
             '            trialCoordinates, trialResiduals, trialFlags, trialAlphas, chosen, baseSignature, positiveBranches, negativeBranches, choices')
    TestOnce('    effort = Array(usedSteps, calls, maximumSteps, maximumCalls, TestNewtonMaximum(residual))',
             '    effort = Array(usedSteps, calls, maximumSteps, maximumCalls, TestNewtonMaximum(residual), signatureReads)')
    TestOnce('        ByVal trialFlags As Collection, ByVal trialAlphas As Collection, ByVal chosen As Long)',
             '''        ByVal trialFlags As Collection, ByVal trialAlphas As Collection, ByVal chosen As Long, _
        ByVal baseSignature As Variant, ByVal positiveBranches As Collection, ByVal negativeBranches As Collection, ByVal choices As Variant)''')
    TestOnce('magic = "NDMNEWTONTEST001"', 'magic = "NDMACTIVETEST001"')
    TestOnce('    Dim trials As Long: trials = trialCoordinates.Count', '''    TestWriteReverseBinaryVector handle, baseSignature
    Dim branchColumn As Long
    For branchColumn = 1 To count
        TestWriteReverseBinaryVector handle, positiveBranches(branchColumn)
        TestWriteReverseBinaryVector handle, negativeBranches(branchColumn)
    Next branchColumn
    TestWriteReverseBinaryVector handle, choices
    Dim trials As Long: trials = trialCoordinates.Count''')
    code += '\n' + (here / 'TestNativeNewtonActiveBranch.bas.txt').read_text('utf-8-sig')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeNewtonActiveBranch.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'CompleteNewtonSameMaterialBranchDifference',
        'difference_side': 'central if both signatures match; one-sided if only that signature matches; stop if neither matches',
        'all_three_stations_and_all_concrete_points_checked': True, 'hardcoded_critical_point': False,
        'additional_material_signature_reads_counted_separately': True, 'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('COMPLETE NEWTON SAME MATERIAL BRANCH DIFFERENCES READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
