"""ДЛЯ ТЕСТОВ. Локализует смену материальной ветви в последних направлениях полного Newton."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import struct


def TestStage(repo, root, source):
    """Считываются именно два сохранённых терминальных поля; повтор полного Newton не выполняется."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestNewtonLine.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestNativeNewtonBranches.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', lambda _: body, code)
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    read = run_path(str(here / 'Analyze-TestNewtonLine.py'))['TestRead']
    payload = bytearray(b'NDMBRANCHTEST001' + struct.pack('<i', 2))
    native = Path('D:/CodexScratch/RC_Section_NDM_TQ/NewtonLine20261119/Native')
    for case in (0, 1):
        file = native / f'NewtonLine.C{case}I10.bin'
        data = read(file)
        name = f'Input/Source.C{case}I10.bin'
        (root / name).write_bytes(file.read_bytes())
        prep['inputs'][name] = sha256(file.read_bytes()).hexdigest().upper()
        payload.extend(struct.pack('<i2d', case, data['seed_factor'], data['target']))
        for field in ('seed', 'projection', 'x', 'sizes', 'correction', 'residual'):
            vector = data[field]
            payload.extend(struct.pack('<i', len(vector)))
            payload.extend(vector.astype('<f8').tobytes())
    name = 'Input/Branches.bin'
    (root / name).write_bytes(payload)
    prep['inputs'][name] = sha256(payload).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeNewtonBranches.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'NewtonTerminalMaterialBranchAudit', 'new_Newton_search_executed': False,
        'terminal_cases': [0, 1], 'terminal_iteration': 10,
        'coordinate_probes': 'positive and negative original difference in every physical coordinate',
        'direction_probes': 'positive and negative 1e-2, 1e-3, 1e-4, 1e-5 of exact Newton direction',
        'material_readings': ['trial_yield', 'plastic_increment', 'principal_sign', 'substeps'],
        'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('TERMINAL NEWTON MATERIAL BRANCH AUDIT READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
