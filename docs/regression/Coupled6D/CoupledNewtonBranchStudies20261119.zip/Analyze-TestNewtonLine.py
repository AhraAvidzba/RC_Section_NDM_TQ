"""ДЛЯ ТЕСТОВ. Независимо проверяет полные производные, решение LU и фактические пробы поиска шага."""

from argparse import ArgumentParser
import csv
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestRead(path):
    """Читает ограниченный двоичный формат исходных Double без десятичного округления."""
    raw, at = path.read_bytes(), 16
    assert raw[:16] in (b'NDMNEWTONTEST001', b'NDMACTIVETEST001')
    active = raw[:16] == b'NDMACTIVETEST001'
    def TestValue(code):
        """Все числа записаны штатным VBA Binary Put little-endian."""
        nonlocal at
        size = struct.calcsize('<' + code)
        assert at + size <= len(raw)
        value = struct.unpack_from('<' + code, raw, at)
        at += size
        return value[0] if len(value) == 1 else value
    def TestVector():
        """Неполные, бесконечные и избыточно длинные векторы не допускаются."""
        nonlocal at
        size = TestValue('i')
        assert 0 < size <= 61 * 61 and at + 8 * size <= len(raw)
        value = np.frombuffer(raw, '<f8', size, at).copy()
        at += size * 8
        assert np.all(np.isfinite(value))
        return value
    count, case, iteration = TestValue('3i')
    assert count == 61 and case in (0, 1) and 0 <= iteration < 30
    seed_factor, target = TestValue('2d')
    names = ('scales', 'seed', 'projection', 'x', 'residual', 'sizes', 'plus', 'minus', 'jacobian', 'approximate', 'correction', 'linear_error')
    data = dict(zip(names, (TestVector() for _ in names)))
    for name in names:
        expected = 61 * 61 if name in ('plus', 'minus', 'jacobian', 'approximate') else 60 if name in ('seed', 'projection') else 61
        assert data[name].shape == (expected,), name
        if expected == 61 * 61:
            data[name] = data[name].reshape(61, 61)
    if active:
        data['base_branch'] = TestVector()
        positive, negative = [], []
        for column in range(61):
            positive.append(TestVector())
            negative.append(TestVector())
        data['positive_branches'] = np.column_stack(positive)
        data['negative_branches'] = np.column_stack(negative)
        data['choices'] = TestVector()
        assert data['base_branch'].shape == (387,) and data['choices'].shape == (61,)
        assert data['positive_branches'].shape == data['negative_branches'].shape == (387, 61)
    number, chosen = TestValue('2i')
    assert 1 <= number <= 21 and 0 <= chosen <= number
    trials = []
    for index in range(number):
        alpha, evaluated = TestValue('d'), TestValue('i')
        x, residual = TestVector(), TestVector()
        assert alpha == 2. ** (-index) and evaluated in (0, 1)
        assert x.shape == residual.shape == (61,)
        trials.append({'alpha': alpha, 'evaluated': bool(evaluated), 'x': x, 'residual': residual})
    assert at == len(raw)
    data.update(case=case, iteration=iteration, seed_factor=seed_factor, target=target, chosen=chosen, trials=trials, active_branch=active,
                sha256=sha256(raw).hexdigest().upper())
    return data


def TestAnalyze(root, output):
    """Численный эксперимент не подменяет подтверждение предельного события или независимый закон материала."""
    rows = list(csv.reader((root / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    cases = {}
    tiny = np.finfo(float).tiny
    for case in (0, 1):
        result, = [row for row in rows if row[:2] == ['RESULT', str(case)]]
        final, = [row for row in rows if row[:2] == ['FINAL', str(case)]]
        native, = [row for row in rows if row[:2] == ['NATIVE', str(case)]]
        seed, = [row for row in rows if row[:2] == ['SEED', str(case)]]
        files = sorted((root / 'Native').glob(f'NewtonLine.C{case}I*.bin'), key=lambda file: int(file.stem.split('I')[-1]))
        assert len(files) == int(result[5]) <= 30 and int(result[6]) <= 4500
        assert result[7:9] == ['30', '4500']
        history, previous = [], None
        for index, file in enumerate(files):
            data = TestRead(file)
            assert data['iteration'] == index and data['case'] == case
            x, r, j, a, d = (data[name] for name in ('x', 'residual', 'jacobian', 'approximate', 'correction'))
            # VBA может округлить расширенный промежуточный результат непосредственно в Double;
            # граница относится только к арифметике сохранённых чисел, не к допуску равновесия.
            np.testing.assert_allclose(data['sizes'], 1e-6 * (1. + np.abs(x)), rtol=4 * np.finfo(float).eps, atol=0)
            expected_j = (data['plus'] - data['minus']) / (2. * data['sizes'][None, :])
            if data['active_branch']:
                for column in range(61):
                    plus_match = np.array_equal(data['base_branch'], data['positive_branches'][:, column])
                    minus_match = np.array_equal(data['base_branch'], data['negative_branches'][:, column])
                    assert plus_match or minus_match
                    expected_choice = 0 if plus_match and minus_match else 1 if plus_match else -1
                    assert data['choices'][column] == expected_choice
                    if expected_choice == 1:
                        expected_j[:, column] = (data['plus'][:, column] - r) / data['sizes'][column]
                    elif expected_choice == -1:
                        expected_j[:, column] = (r - data['minus'][:, column]) / data['sizes'][column]
            np.testing.assert_allclose(j, expected_j,
                                       rtol=4 * np.finfo(float).eps, atol=0)
            error = r + j @ d
            round_bound = 128 * np.finfo(float).eps * (np.abs(r) + np.abs(j) @ np.abs(d)) + 1e-300
            assert np.all(np.abs(error - data['linear_error']) <= round_bound)
            backward = float(np.max(np.abs(error) / np.maximum(np.abs(r) + np.abs(j) @ np.abs(d), tiny)))
            assert backward < 1e-10
            if previous is not None:
                assert previous['chosen'] > 0
                np.testing.assert_array_equal(x, previous['trials'][previous['chosen'] - 1]['x'])
                np.testing.assert_array_equal(r, previous['trials'][previous['chosen'] - 1]['residual'])
            base_norm = np.linalg.norm(r)
            evaluations, acceptable = [], []
            for number, trial in enumerate(data['trials'], 1):
                alpha = trial['alpha']
                assert np.all(np.abs(trial['x'] - (x + alpha * d)) <= 4 * np.finfo(float).eps * (np.abs(x) + np.abs(alpha * d)) + 1e-300)
                if not trial['evaluated']:
                    evaluations.append({'alpha': alpha, 'material_evaluated': False})
                    continue
                norm = np.linalg.norm(trial['residual'])
                if norm <= (1. - 1e-4 * alpha) * base_norm:
                    acceptable.append(number)
                slope = (trial['residual'] - r) / alpha
                evaluations.append({'alpha': alpha, 'material_evaluated': True,
                    'residual_L2_MPa': float(norm), 'residual_max_MPa': float(np.max(np.abs(trial['residual']))),
                    'merit_ratio_to_base': float(norm / base_norm),
                    'complete_direction_relative_error': float(np.linalg.norm(slope - j @ d) / max(np.linalg.norm(j @ d), tiny)),
                    'assembled_direction_relative_error': float(np.linalg.norm(slope - a @ d) / max(np.linalg.norm(j @ d), tiny)),
                    'actual_normalized_merit_slope': float(np.dot(r, slope) / np.dot(r, r))})
            assert data['chosen'] == (acceptable[0] if acceptable else 0)
            history.append({'iteration': index, 'binary_sha256': data['sha256'],
                'residual_L2_MPa': float(base_norm), 'residual_max_MPa': float(np.max(np.abs(r))),
                'linear_backward_error': backward, 'chosen_line': data['chosen'],
                'assembled_complete_direction_relative_difference': float(np.linalg.norm((a - j) @ d) / max(np.linalg.norm(j @ d), tiny)),
                'same_branch_one_sided_columns': int(np.count_nonzero(data['choices'])) if data['active_branch'] else 0,
                'trials': evaluations})
            previous = data
        final_field = np.asarray([float(value) for value in final[3:]])
        assert final_field.shape == (60,)
        if previous is not None:
            last = previous['trials'][previous['chosen'] - 1] if previous['chosen'] else previous
            coordinate = last['x']
            expected_field = previous['seed'] + previous['scales'][:60] * coordinate[:60]
            expected_factor = previous['seed_factor'] + previous['scales'][60] * coordinate[60]
            np.testing.assert_allclose(final_field, expected_field, rtol=1e-14, atol=1e-300)
            np.testing.assert_allclose(float(final[2]), expected_factor, rtol=1e-14, atol=1e-300)
            expected_max = float(np.max(np.abs(last['residual'])))
            assert abs(float(result[9]) - expected_max) <= max(1e-18, expected_max * 1e-14)
        assert (result[2] == 'True') == (float(result[9]) <= 1e-10)
        cases[str(case)] = {'strict_root_found': result[2] == 'True', 'seconds': float(result[3]), 'stop': result[4],
            'corrections': int(result[5]), 'function_calls': int(result[6]), 'final_residual_max_MPa': float(result[9]),
            'final_lambda': float(final[2]), 'native_original_tolerance_verified': native[2] == 'True',
            'native_field_Double_unchanged': native[3] == 'True', 'native_forward_direction': native[4] == 'True',
            'native_steel_utilization': float(native[7]), 'iterations': history}
        if len(result) == 11:
            cases[str(case)]['additional_full_material_signature_reads'] = int(result[10])
        phase = f'NewtonLine.Reverse{20 + case}'
        if native[2:4] == ['True', 'True']:
            validate = run_path(str(Path(__file__).resolve().parent / 'Validate-TestHardPrepared.py'))['TestValidate']
            proof, fields = validate(root, phase)
            assert len(fields) == 27
            np.testing.assert_allclose(fields[-1], final_field, rtol=1e-14, atol=1e-300)
            cases[str(case)]['independent_all_equations'] = proof
    output.write_text(json.dumps({'cases': cases, 'complete_difference_arithmetic_verified': True,
        'actual_Armijo_decisions_verified': True, 'independent_material_reintegration': False,
        'physical_capacity_certified': False, 'working_runtime_changed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    for case, result in cases.items():
        print('CASE', case, 'STRICT', result['strict_root_found'], 'STOP', result['stop'],
              'R', result['final_residual_max_MPa'], 'SECONDS', result['seconds'], 'STEPS', result['corrections'])
    print('COMPLETE NEWTON MATRICES LINE PROBES AND CANDIDATES VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
