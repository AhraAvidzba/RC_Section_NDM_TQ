"""ДЛЯ ТЕСТОВ. Сохраняет полный Newton, локализацию ветви и независимый выбор стороны разности."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestCollect(repo, root):
    """Сохраняются действительные исполнения и исходные отрицательные результаты; рабочий код не меняется."""
    here = Path(__file__).resolve().parent
    cases = {'Newton': 'NewtonLine20261119', 'Branches': 'NewtonBranches20261119', 'Active': 'NewtonActiveBranch20261119'}
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for key in cases:
        folder = root / 'Cases' / key
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(sources) == 33
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    names = ('Collect-TestNewtonStudies.py', 'Check-TestNewtonStudies.py', 'Analyze-TestNewtonLine.py',
             'Analyze-TestNewtonBranches.py', 'Stage-TestNewtonLine.py', 'TestNativeNewtonLine.bas.txt',
             'Stage-TestNewtonBranches.py', 'TestNativeNewtonBranches.bas.txt', 'Stage-TestNewtonActiveBranch.py',
             'TestNativeNewtonActiveBranch.bas.txt', 'Check-TestActualReverseCapture.py',
             'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py', 'Audit-TestPrivateCoupledBook.py', 'Canonical-TestCoreVBA.py')
    for name in names:
        (root / name).write_bytes((here / name).read_bytes())
    (root / 'AnalysisArithmeticNote.json').write_text(json.dumps({
        'initial_check': 'exact equality of recomputed central matrix arithmetic',
        'initial_outcome': '18 of 3721 entries differ, maximum 1.7763568394002505e-15, relative 2.2181e-16',
        'arithmetic_comparison_bound': 'four binary64 epsilons for recomputation of saved Double arithmetic only',
        'reason': 'VBA intermediate arithmetic and independent binary64 arithmetic can round differently',
        'physical_equilibrium_tolerances_changed': False, 'native_numerical_data_changed': False}, indent=2)+'\n', encoding='utf-8')
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '62000fe',
        'runtime_sources': {name: sha256((repo / name).read_bytes()).hexdigest().upper() for name in
            ('src/Solver/CCoupledHybridSolver.cls', 'src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledDeformationContinuation.cls')},
        'installed_workbook_changed': False, 'working_runtime_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('COMPLETE NEWTON BRANCH STUDIES EVIDENCE COLLECTED', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
