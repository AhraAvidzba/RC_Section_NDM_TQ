"""Freeze the current workbook, archived B fields, and diagnostic-only module."""
import argparse
import hashlib
import json
from pathlib import Path
from shutil import copyfile

HERE=Path(__file__).resolve().parent
PRIOR=Path("D:/CodexScratch/RC_Section_NDM_TQ/MVT2MinimumFields")
BOOK=Path("workbook/output/RC_Section_NDM.xlsm")
DRAFT=Path("docs/regression/Diagnostic.xlsm")
MODULE=Path("tests/modTestCoupledExperiment.bas")
BOOK_SHA="A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A"
PREFIX_SHA="504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def main(repo, stage):
    assert digest(repo/BOOK)==BOOK_SHA
    archived=PRIOR/"MVT2ShearBReplay.csv"
    assert digest(archived)==PREFIX_SHA
    former=json.loads((PRIOR/"Preparation.json").read_text(encoding="utf-8"))
    assert digest(PRIOR/MODULE)==former["export_macro_sha256"]
    composed=((PRIOR/MODULE).read_text(encoding="utf-8-sig")+"\n"+
              (HERE/"Control.bas").read_text(encoding="utf-8")).replace("\n","\r\n").encode("utf-8")
    tools={path.relative_to(PRIOR):path for path in (PRIOR/"tools/build_workbook").iterdir() if path.is_file()}
    sources={**tools,BOOK:repo/BOOK,Path("Guard-IsolatedOffice.ps1"):PRIOR/"Guard-IsolatedOffice.ps1",Path("Replay.csv"):archived}
    for key,path in tools.items():
        assert digest(path)==former["frozen"][key.as_posix()]
    assert digest(sources[Path("Guard-IsolatedOffice.ps1")])==former["frozen"]["Guard-IsolatedOffice.ps1"]
    solver_source=(repo / "src/Solver/CCoupledNewtonSolver.cls").read_text(encoding="utf-8-sig")
    reader=(HERE/"SolverReader.txt").read_text(encoding="utf-8")
    assert "CopyTestWangTangent" not in solver_source and reader.strip()
    patched_solver=(solver_source+"\n"+reader).replace("\n","\r\n").encode("utf-8")
    extra_inputs={'AnchorField.csv': '3D8FC988610D1C338A988401815731F9DD5F61777C5FC3DCE0B813887731B003', 'PreviousNative.csv': 'A04C28C4B8D314243BB4EF0FE0373CD1F5CDBC4633FE3B64FA320C305E97708D', 'PreviousVerification.json': 'C5632BF17C49887DF7A15AF77CC34A29466FB3EDDB528C1A2CED5CF707BE08E5'}
    assert all(digest(HERE/name)==identity for name,identity in extra_inputs.items())
    gate={"candidate_radii":[2.5e-9,5e-9,1e-8],"min_global_drop":.15,"min_gradient_N_drop":.25,
          "each_signed_effort_bound":"previous_abs_or_original_tolerance","q53_witness_offsets":[5e-9,-5e-9],
          "plan_code_sha256":digest(HERE/"PlanFresh.py"),
          "verify_code_sha256":digest(HERE/"Verify-MVT2ShearControlled.py")}
    data={"control_gate":gate,"previous_input_sha256":extra_inputs,"book_sha256":BOOK_SHA,"replay_sha256":PREFIX_SHA,"watchdog_seconds":200,
          "only_updated_modules":["CCoupledNewtonSolver","modTestCoupledExperiment"],
          "solver_module_sha256":hashlib.sha256(patched_solver).hexdigest().upper(),
          "sources":{key.as_posix():digest(path) for key,path in sources.items()},
          "module_sha256":hashlib.sha256(composed).hexdigest().upper(),
          "native_harness":digest(HERE/"Run-MVT2ShearControlled.ps1")}
    receipt=HERE/"Preparation.json"
    if stage:
        assert not receipt.exists() and not (HERE/DRAFT).exists()
        for key,src in sources.items():
            dest=HERE/key
            dest.parent.mkdir(parents=True,exist_ok=True)
            assert not dest.exists()
            copyfile(src,dest)
        for directory in ("tests","Temp","Native","docs/regression"):
            (HERE/directory).mkdir(parents=True,exist_ok=True)
        (HERE/MODULE).write_bytes(composed)
        (HERE/"src/CCoupledNewtonSolver.cls").write_bytes(patched_solver)
        copyfile(HERE/BOOK,HERE/DRAFT)
        receipt.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
    assert json.loads(receipt.read_text(encoding="utf-8"))==data
    assert (HERE/MODULE).read_bytes()==composed
    assert (HERE/"src/CCoupledNewtonSolver.cls").read_bytes()==patched_solver
    assert all(digest(HERE/name)==expected for name,expected in data["sources"].items())
    print(data["book_sha256"],digest(receipt))

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo",type=Path)
    parser.add_argument("--stage",action="store_true")
    opts=parser.parse_args()
    main(opts.repo.resolve(strict=True),opts.stage)