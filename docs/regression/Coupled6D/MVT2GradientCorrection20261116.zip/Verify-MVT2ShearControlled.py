"""Independently reconstruct 56 weak equations, four constraints and six signed efforts."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import csv
import json
import math
import sys

HERE = Path(__file__).resolve().parent
DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result


def verify(phase):
    native=HERE/f"Native{phase}"
    prep = read(HERE/"Preparation.json")
    build = read(HERE/"docs/regression/CodeUpdate.json")
    closure = read(HERE/"CompileClosure.json")
    owner = read(native/"MVT2.txt.Ownership.json")
    watcher = read(native/"MVT2.txt.ProcessClosure.json")
    receipt = read(native/"RunReceipt.json")
    final = watcher["Closure"]["FinalState"]
    assert build["Compiled"] and not build["ProductionChanged"]
    assert sorted(build["Modules"])==prep["only_updated_modules"]==["CCoupledNewtonSolver","modTestCoupledExperiment"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and closure["State"]=="Absent"
    assert all(digest(HERE/name)==identity for name,identity in prep["previous_input_sha256"].items())
    assert digest(HERE/"src/CCoupledNewtonSolver.cls")==prep["solver_module_sha256"]
    assert digest(HERE/"tests/modTestCoupledExperiment.bas")==prep["module_sha256"]
    if "--offline" not in sys.argv:
        assert digest(HERE/"docs/regression/Diagnostic.xlsm")==build["WorkbookSHA256"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert watcher["Passed"] and watcher["ChildExitCode"]==receipt["native_exit"]==0
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (native/"MVT2.txt").read_text(encoding="utf-8-sig")
    assert digest(HERE/"Replay.csv")==prep["replay_sha256"]
    archived = list(csv.reader((HERE/"Replay.csv").read_text(encoding="ascii").splitlines(),delimiter=";"))[1:]
    assert len(archived)==24
    tags=defaultdict(list)
    trace = native/"MVT2.csv"
    for tag,*row in csv.reader(trace.read_text(encoding="cp1251").splitlines(),delimiter=";"):
        tags[tag].append(row)
    fields = vec(tags,"MVT2_CONTROL_FIELD")
    assert len(fields)==len(archived)
    for i,row in enumerate(archived,1):
        expected = [float(x) for x in row[9:]]
        assert int(row[0])==i and peak(diff(expected,fields[f"Replay{i}"]))<1e-15
    [[fb,ft]]=tags["B_TANGENT_LOAD"]
    base_factor, target_factor = float(fb),float(ft)
    near(base_factor,float(archived[-1][2]),1e-13)
    near(target_factor,base_factor+(base_factor-float(archived[-2][2]))/64.,1e-13)
    [[last,factor]]=tags["B_TANGENT_END"]
    assert int(last)==24 and float(factor)==base_factor
    state_fields, flags = {}, {}
    for label,h,f,*values in tags["B_TANGENT_FIELD"]:
        assert label not in state_fields and len(values)==DIM
        state_fields[label]=tuple(map(float,values))
        flags[label]=(int(h),float(f))
    residuals=vec(tags,"B_TANGENT_RESIDUAL")
    stations=defaultdict(dict)
    for label,point,side,*values in tags["B_TANGENT_STATION"]:
        identity=(int(point),int(side))
        assert label in residuals and identity not in stations[label] and len(values)==19
        stations[label][identity]=tuple(map(float,values))
    unavailable=defaultdict(list)
    for label,reason,*info in tags["B_TANGENT_UNAVAILABLE"]:
        unavailable[label].append((reason,*info))
    for name in state_fields.keys()-residuals.keys():
        assert name in unavailable and unavailable[name]==[("Residual",)]
    assert all(name in stations and name in state_fields for name in residuals)
    for label in ("Base24","Restored24"):
        assert state_fields[label]==fields["Replay24"] and stations[label]==stations["Base24"]
        assert flags[label]==(24,base_factor) and residuals[label]==residuals["Base24"]
    geometric_scale=(AREA,AREA*LENGTH,AREA*LENGTH,AREA*LENGTH,AREA,AREA)
    responses, diagnostics = {}, {}
    for name in residuals:
        h,f = flags[name]
        assert set(stations[name])=={(point,side) for point in range(1,46) for side in (-1,0,1)}
        computed, actual, error = reconstruct(state_fields[name],f,stations[name])
        discrepancy=peak(diff(computed,residuals[name]))
        assert error<4e-15 and discrepancy<3e-10,(name,error,discrepancy)
        integral=peak(delta/s for delta,s in zip(diff(actual,force(f)),geometric_scale,strict=True))
        weak=peak(computed[:56]); gauge=MODULUS*peak(computed[56:]); tol=5e-7*(1.+peak(loading(f)))
        diagnostics[name]={"history":h,"Qy_kN":f,"max_weak_MPa":weak,"gauge_MPa":gauge,"force_MPa":integral,
            "max_full_MPa":max(weak,gauge,integral),"worst_weak_row":max(range(56),key=lambda idx:abs(computed[idx]))+1,
            "equilibrium_tolerance_MPa":tol,"six_N_Nmm":actual,
            "independent_weak_difference_MPa":discrepancy,"station_strain_discrepancy":error}
        responses[name]=computed
    assert tags["B_FRESH_PHASE"]==[[phase]]
    prior=defaultdict(list)
    for tag,*row in csv.reader((HERE/"PreviousNative.csv").read_text().splitlines(),delimiter=";"):
        prior[tag].append(row)
    prior_fields={label:tuple(map(float,values)) for label,h,f,*values in prior["B_TANGENT_FIELD"]}
    prior_stations=defaultdict(dict)
    for label,point,side,*values in prior["B_TANGENT_STATION"]:
        prior_stations[label][int(point),int(side)]=tuple(map(float,values))
    previous_errors={}
    for current,older in (("Base24","Base24"),("Anchor","BothSmall")):
        field_discrepancy=peak(diff(state_fields[current],prior_fields[older]))
        assert field_discrepancy<4e-16
        assert set(stations[current])==set(prior_stations[older])
        errors=[peak(diff(stations[current][key],prior_stations[older][key])) for key in stations[current]]
        assert max(errors)<3e-9,(current,max(errors))
        near(peak(diff(residuals[current],vec(prior,"B_TANGENT_RESIDUAL")[older])),0.,5e-10)
        previous_errors[current]={"field":field_discrepancy,"station_rows":max(errors)}
    assert flags["Anchor"]==(24,target_factor)
    assert peak(responses["Anchor"][:56])==abs(responses["Anchor"][52])
    near(diagnostics["Anchor"]["max_full_MPa"],read(HERE/"PreviousVerification.json")["diagnostics"]["BothSmall"]["max_full_MPa"],4e-10)
    native_norm={name:float(norm) for name,norm in tags["B_BOUND_NORM"]}
    native_actual={name:tuple(map(float,values)) for name,*values in tags["B_BOUND_ACTUAL"]}
    assert set(native_norm)==set(native_actual)==set(diagnostics)
    queried_steel=defaultdict(dict)
    for name,point,side,axis,e,concrete,stress in tags["B_BOUND_STEEL"]:
        key=(int(point),int(side))
        assert key not in queried_steel[name]
        queried_steel[name][key]=(int(axis),float(e),float(concrete),float(stress))
    assert set(queried_steel)==set(diagnostics)
    for label,metrics in diagnostics.items():
        near(native_norm[label],metrics["max_full_MPa"],4e-10)
        assert len(native_actual[label])==6
        assert peak(delta/s for delta,s in zip(diff(native_actual[label],metrics["six_N_Nmm"]),geometric_scale,strict=True))<2e-12
        steel=queried_steel[label]; assert len(steel)==60
        ratios=[]; maxima=[]; history_peak=0.
        for (point,side),row in stations[label].items():
            if point<=25: continue
            x,y,_=row[:3]
            axis=2 if point<=29 else 1 if abs(x)>abs(y) else 0
            if point<=29:
                near(abs(x),84.,1e-8); near(abs(y),84.,1e-8)
            else: near(max(abs(x),abs(y)),96.,1e-8)
            named,e,concrete,stress=steel[point,side]
            assert named==axis+1
            near(e,row[7+axis],4e-16)
            near(stress,row[13+axis]+concrete,4e-10)
            near(stress,e*200000.,4e-8)
            limit=498. if point<=29 else 450.
            hist_max=max(abs(strain_at(q,operators(x,y),side)[axis])*200000. for q in fields.values())
            assert abs(stress)<limit and hist_max<limit
            history_peak=max(history_peak,hist_max)
            ratios.append(abs(e)/.05); maxima.append(abs(stress))
        metrics["max_steel_strain_utilization"]=max(ratios)
        metrics["max_steel_stress_MPa"]=max(maxima)
        metrics["max_archived_steel_stress_MPa"]=history_peak
    summary={"workbook_sha256":prep["book_sha256"],"history_sha256":prep["replay_sha256"],"solver_owned_closure":final,
        "compile_closure":closure,"wall_s":receipt["wall_seconds"],"trace_sha256":digest(trace),
        "origin_Qy_kN":base_factor,"target_Qy_kN":target_factor,"exact_rollback":True,"prior_compatibility":previous_errors,
        "diagnostics":diagnostics,"unavailable":dict(unavailable),"physical_limit_confirmed":False}
    if phase=="A":
        assert set(state_fields)=={"Base24","Anchor","GradientPositive","GradientNegative","Restored24"}
        mats=read_matrices(tags)
        assert "Stock" in mats and set(mats).issubset({"Stock","Consistent"})
        modes_unavailable=[row[0] for row in tags["B_FRESH_MATRIX_UNAVAILABLE"]]
        assert set(mats).union(modes_unavailable)=={"Stock","Consistent"}
        derivative_res=vec(tags,"B_FRESH_INTERNAL")
        assert set(derivative_res)==set(mats)
        for label,mat in mats.items():
            assert peak(diff(tuple(a-b for a,b in zip(derivative_res[label],loading(target_factor),strict=True)),responses["Anchor"]))<4e-10
            assert max(peak(diff(x,y)) for x,y in zip(mat[56:],mats["Stock"][56:],strict=True))<2e-15
        projection={int(idx):tuple(map(float,v)) for idx,*v in tags["B_FRESH_PROJECTION"]}
        expected_projection=make_projection()
        assert set(projection)==set(range(1,7))
        assert max(peak(diff(projection[i+1],expected_projection[i])) for i in range(6))<3e-14
        for name in diagnostics:
            actual=diagnostics[name]["six_N_Nmm"]; f=flags[name][1]
            integral=tuple(d/s for d,s in zip(diff(actual,force(f)),geometric_scale,strict=True))
            calc=tuple(dot(row,responses[name][:56]) for row in expected_projection)
            assert peak(diff(integral,calc))<4e-10
        energy={(int(point),int(side)):(float(kt),float(kc)) for point,side,kt,kc in tags["B_FRESH_ENERGY"]}
        assert set(energy)==set(stations["Base24"])
        assert all(0<=a<=1. and 0<=b<=1. for a,b in energy.values())
        summaries={}
        nominal_limit=8e-12*(588000./(.3*AREA))
        for name in ("Base24","Anchor"):
            apo=[]
            for key,row in stations[name].items():
                stress=list(row[13:19])
                if key[0]>25:
                    component,_,_,sigma=queried_steel[name][key]
                    stress=[-v for v in stress]; stress[component-1]+=sigma
                p=math.fsum(stress[:3])/3
                q=math.hypot(*(math.sqrt(1.5)*(v-p) for v in stress[:3]),*(math.sqrt(3)*v for v in stress[3:]))
                a,b,c,d,e,f=stress
                positive = a>0. and a*b>d*d and a*b*c+2*d*e*f-a*f*f-b*e*e-c*d*d>0.
                kt,kc=energy[key]
                if positive and q<=nominal_limit and 1/21<=kt<1.:
                    apo.append({"point":key[0],"side":key[1],"p_MPa":p,"q_MPa":q,"kt":kt,"kc":kc})
            summaries[name]=apo
        leading=52
        witness={}
        delta_g=5e-9
        for sign,name in ((1.,"GradientPositive"),(-1.,"GradientNegative")):
            direction=diff(state_fields[name],state_fields["Anchor"])
            near(direction[leading],sign*delta_g,4e-18)
            assert all(v==0. for i,v in enumerate(direction) if i!=leading)
            assert all(stations[name][key]==row for key,row in stations["Anchor"].items() if key[1]==0)
            assert diagnostics[name]["six_N_Nmm"]==diagnostics["Anchor"]["six_N_Nmm"]
            dr=diff(responses[name],responses["Anchor"])
            axial_by_point={}
            for point in range(1,46):
                a,b=stations[name][point,-1],stations[name][point,1]
                c,d=stations["Anchor"][point,-1],stations["Anchor"][point,1]
                axial_by_point[point]=a[2]*((b[15]-a[15])-(d[15]-c[15]))/(.002*AREA)
            near(math.fsum(axial_by_point.values()),dr[leading],4e-10)
            witness[name]={"row53_delta_MPa":dr[leading],"q53_delta":sign*delta_g,
                "central_six_exact":True,"signed_row53_derivative_MPa":dr[leading]/(sign*delta_g),
                "station_individual_row53_deltas_MPa":axial_by_point,
                "matrix_row53_derivative_MPa":{k:v[leading][leading] for k,v in mats.items()},
                "branch_flag_changes":sum(stations[name][key][3:6]!=row[3:6] for key,row in stations["Anchor"].items() if key[0]<=25),
                "other_rows_max_delta_MPa":peak(dr[:leading]+dr[leading+1:56]),
                "largest_other_residual_row":max((i for i in range(56) if i!=leading),key=lambda i:abs(responses[name][i]))+1}
        summary.update({"pure_gradient_witness":witness,"matrix_modes":list(mats),"unavailable_modes":modes_unavailable,
            "apex_scope_nominal_screen":summaries,"apex_nominal_q_limit_MPa":nominal_limit,"projection_verified":True})
    else:
        plan=validate_plan()
        names={row["name"]:row for row in plan["selected"]}
        assert set(state_fields)=={"Base24","Anchor","Restored24",*names}
        [[probe_count]]=tags["B_FRESH_PROBES"]
        assert int(probe_count)==len(names)
        for name,radius,prediction,extent in tags["B_FRESH_INPUT"]:
            item=names[name]
            near(float(radius),item["radius"],3e-18)
            near(float(prediction),item["prediction_MPa"],4e-12)
            near(float(extent),item["tensor_peak"],4e-16)
            expect=tuple(a+b for a,b in zip(state_fields["Anchor"],item["dq"],strict=True))
            assert peak(diff(expect,state_fields[name]))<2e-15 and flags[name]==(24,target_factor)
        ref=diagnostics["Anchor"]["max_full_MPa"]
        score={key:1.-diagnostics[key]["max_full_MPa"]/ref for key in names if key in diagnostics}
        d0=diagnostics["Anchor"]
        r0=responses["Anchor"]
        before=tuple((v-x)/s for v,x,s in zip(d0["six_N_Nmm"],force(target_factor),geometric_scale,strict=True))
        grades={}
        for name,improvement in score.items():
            d=diagnostics[name]
            new=tuple((v-x)/s for v,x,s in zip(d["six_N_Nmm"],force(target_factor),geometric_scale,strict=True))
            violations=[i+1 for i,(r,r_old) in enumerate(zip(new,before,strict=True))
                 if abs(r)>max(abs(r_old),d0["equilibrium_tolerance_MPa"])+4e-10]
            gradient_change=1.-abs(responses[name][52])/abs(r0[52])
            grades[name]={"actual_global_reduction":improvement,"actual_gradient_N_reduction":gradient_change,
                "row53_MPa":responses[name][52],"effort_residuals_MPa":new,"worsened_effort_components":violations,
                "passes_strict_improvement_gate":improvement>=.15 and gradient_change>=.25 and not violations}
        strict=[name for name,grade in grades.items() if grade["passes_strict_improvement_gate"]]
        summary.update({"candidate_plan_sha256":digest(HERE/"Plan.json"),"comparisons":grades,
            "preexisting_signed_effort_residuals_MPa":before,"best_actual":max(score,key=score.get) if score else None,
            "strict_improvement":max(strict,key=score.get) if strict else None})
    result=HERE/f"Verification{phase}.json"
    result.write_text(json.dumps(summary,indent=2)+"\n",encoding="utf8")
    print(result,digest(result))


def read_matrices(tags):
    nested=defaultdict(dict)
    for label,idx,*values in tags["B_FRESH_MATRIX"]:
        i=int(idx)
        assert i not in nested[label] and len(values)==DIM
        nested[label][i]=tuple(map(float,values))
    assert all(set(rows)==set(range(1,61)) for rows in nested.values())
    return {label:tuple(rows[i] for i in range(1,61)) for label,rows in nested.items()}


def make_projection():
    result=[[0.]*56 for _ in range(6)]
    for k in range(4): result[k][k]=1.
    coeff=(-120.,-40.,40.,120.)
    for j,y in enumerate(coeff):
        for i,x in enumerate(coeff):
            warp=6+3*(4*j+i)
            result[4][warp]=x/LENGTH
            result[5][warp]=y/LENGTH
    result[4][54]=1.; result[5][53]=1.
    return result


def read_A():
    tags=defaultdict(list)
    for tag,*row in csv.reader((HERE/"NativeA/MVT2.csv").read_text(encoding="cp1251").splitlines(),delimiter=";"):
        tags[tag].append(row)
    return tags


def validate_plan():
    plan=read(HERE/"Plan.json")
    tags=read_A(); mats=read_matrices(tags); proj=make_projection()
    assert digest(HERE/"NativeA/MVT2.csv")==plan["native_A_sha256"]
    assert digest(HERE/"VerificationA.json")==plan["verification_A_sha256"]
    b=vec(tags,"B_TANGENT_RESIDUAL")["Anchor"]
    alpha=peak(b[:56]); assert abs(b[52])==alpha
    q_goal=read(HERE/"VerificationA.json")["target_Qy_kN"]
    tolerance=5e-7*(1.+peak(loading(q_goal)))
    before=tuple(dot(row,b[:56]) for row in proj)
    effort_caps=tuple(max(abs(v),tolerance) for v in before)
    station_geometry=[(float(x),float(y),int(side)) for label,i,side,x,y,*_ in tags["B_TANGENT_STATION"] if label=="Anchor"]
    assert len(station_geometry)==135 and len(plan["selected"])<=6
    items={row[0]:tuple(map(float,row[1:])) for row in csv.reader((HERE/"Candidate.csv").read_text().splitlines(),delimiter=";")}
    assert set(items)=={row["name"] for row in plan["selected"]} and bool(items)
    for item in plan["selected"]:
        radius,sup,*dq=items[item["name"]]
        assert len(dq)==60 and dq==item["dq"] and item["radius"]==radius and item["prediction_MPa"]==sup
        limit=0.
        for x,y,side in station_geometry:
            xi=strain_at(dq,operators(x,y),side)
            limit=max(limit,peak(v/(1. if k<3 else math.sqrt(2.)) for k,v in enumerate(xi)))
        near(limit,item["tensor_peak"],4e-15)
        assert limit<=radius+4e-16 and radius<=1e-8
        results=[]; n=[]
        for name in item["modes"]:
            out=tuple(v+dot(row,dq) for v,row in zip(b,mats[name],strict=True))
            assert peak(out[56:])<3e-15
            actual=peak((*out[:56],*(dot(row,out[:56]) for row in proj)))
            expected=item["linear_by_mode"][name]
            effort=tuple(dot(row,out[:56]) for row in proj)
            near(actual,expected["max_MPa"],5e-12)
            near(out[52],expected["gradient_N_MPa"],5e-12)
            assert all(abs(v)<=tol+5e-12 for v,tol in zip(effort,effort_caps,strict=True))
            results.append(actual); n.append(abs(out[52]))
        near(max(results),sup,5e-12)
        assert sup<=.85*alpha+5e-12 and max(n)<=.75*alpha+5e-12
    print("PREVALIDATE",len(items),digest(HERE/"Candidate.csv"))
    return plan


if __name__=="__main__":
    if "--prevalidate" in sys.argv:
        validate_plan()
    else:
        phase=sys.argv[sys.argv.index("--phase")+1] if "--phase" in sys.argv else "A"
        verify(phase)
