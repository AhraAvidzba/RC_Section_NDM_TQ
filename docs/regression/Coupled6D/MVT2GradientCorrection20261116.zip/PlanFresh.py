"""Plan a few bounded corrections at the actual Envelope500 coordinate and H24."""
from pathlib import Path
from hashlib import sha256
import json
import runpy

import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
v=runpy.run_path(str(HERE/'Verify-MVT2ShearControlled.py'))
digest=v['digest']
trace=HERE/'NativeA/MVT2.csv'
result=HERE/'VerificationA.json'
mask=v['read_A']()
verify=json.loads(result.read_text())
assert verify['trace_sha256']==digest(trace) and verify['exact_rollback']
matrices={name:np.asarray(rows) for name,rows in v['read_matrices'](mask).items()}
base=np.asarray(v['vec'](mask,'B_TANGENT_RESIDUAL')['Anchor'])
leading=52
assert np.abs(base[leading])==np.linalg.norm(base[:56],np.inf) and base[leading]<0
alpha=abs(base[leading])
P=np.asarray(v['make_projection']())
actual=np.r_[base[:56],P@base[:56]]
load_tol=5e-7*(1.+max(map(abs,v['loading'](verify['target_Qy_kN']))))
effort_cap=np.maximum(np.abs(actual[56:]),load_tol)
stations=[(float(x),float(y),int(side)) for label,i,side,x,y,*unused in mask['B_TANGENT_STATION'] if label=='Anchor']
assert len(stations)==135
unit=np.eye(60)
S=np.stack([np.array([v['strain_at'](e,v['operators'](x,y),side) for e in unit]).T for x,y,side in stations]).reshape(-1,60)
S[3::6]/=np.sqrt(2.); S[4::6]/=np.sqrt(2.); S[5::6]/=np.sqrt(2.)
strain_unit=1e-7
stress_unit=1e-4
scaled={key:np.r_[matrix[:56],P@matrix[:56]]*strain_unit/stress_unit for key,matrix in matrices.items()}
E=matrices['Stock'][56:]
L=np.c_[E,np.zeros(4)]
h=-base[56:]/strain_unit
unscaled=np.r_[np.zeros(60),1]
SR=np.c_[S,np.zeros(len(S))]


def optimize(names,radius):
    A=np.vstack([scaled[key] for key in names])
    c=np.tile(actual/stress_unit,len(names))
    G=np.stack([scaled[key][leading] for key in names])
    X=np.c_[G,np.zeros(len(G))]
    efforts=np.vstack([scaled[key][56:] for key in names])
    effort_bounds=np.c_[efforts,np.zeros(len(efforts))]
    inequalities=np.r_[np.c_[A,-np.ones(len(A))],np.c_[-A,-np.ones(len(A))],SR,-SR,X,-X,effort_bounds,-effort_bounds]
    right=np.r_[-c,c,np.tile(radius/strain_unit,len(S)*2),
                np.repeat((.75*alpha-base[leading])/stress_unit,len(G)),np.repeat((.75*alpha+base[leading])/stress_unit,len(G)),
                np.tile((effort_cap-actual[56:])/stress_unit,len(names)),np.tile((effort_cap+actual[56:])/stress_unit,len(names))]
    result=linprog(unscaled,A_ub=inequalities,b_ub=right,A_eq=L,b_eq=h,bounds=[(None,None)]*60+[(0.,None)],
        options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9},method='highs')
    if not result.success:
        return {'radius':radius,'modes':list(names),'status':result.message}
    q=result.x[:60]*strain_unit
    onset=S@q
    bound=np.linalg.norm(onset,np.inf)
    assert bound<=radius+4e-16 and np.linalg.norm(E@q+base[56:],np.inf)<3e-15
    per_mode={}
    for key,mat in matrices.items():
        r=base+mat@q
        a=P@r[:56]
        per_mode[key]={'max_MPa':float(np.linalg.norm(np.r_[r[:56],a],np.inf)), 'gradient_N_MPa':float(r[leading]),
            'effort_MPa':a.tolist(),'greatest_weak_row':int(np.argmax(abs(r[:56]))+1)}
    f=max(per_mode[k]['max_MPa'] for k in names)
    assert abs(f-result.fun*stress_unit)<5e-11
    return {'radius':radius,'modes':list(names),'prediction_MPa':f,'tensor_peak':float(bound),
            'linear_by_mode':per_mode,'dq':q.tolist(),'fits_predeclared_screen':bool(f<=.85*alpha and max(abs(per_mode[k]['gradient_N_MPa']) for k in names)<=.75*alpha+5e-12
                and all(np.all(np.abs(per_mode[k]['effort_MPa'])<=effort_cap+5e-12) for k in names))}


all_modes=list(matrices)
groups={'Stock':['Stock']}
if len(all_modes)>1:
    groups['Both']=all_modes
radii=(2.5e-9,5e-9,1e-8)
tested={label:[optimize(names,rad) for rad in radii] for label,names in groups.items()}
chosen=[]
for name in ('Both','Stock'):
    admitted=[row for row in tested.get(name,[]) if row.get('fits_predeclared_screen')]
    if not admitted:
        continue
    first=admitted[0]; best=min(admitted,key=lambda x:x['prediction_MPa'])
    for hint,candidate in [('Small',first),('Best',best)]:
        vector=np.asarray(candidate['dq'])
        if any(np.linalg.norm(S@(vector-item['dq']),np.inf)<1e-9 for item in chosen):
            continue
        chosen.append(dict(candidate,name=name+hint))
summary={'native_A_sha256':digest(trace),'verification_A_sha256':digest(result),'fixed_Qy_kN':verify['target_Qy_kN'],
    'linearization_rows':62,'exact_gauges':4,'baseline_abs_gradient_N_MPa':float(alpha),
    'baseline_signed_efforts_MPa':actual[56:].tolist(), 'effort_caps_MPa':effort_cap.tolist(),
    'pure_axial_gradient_only_global_reduction_upper_bound':float(1.-abs(actual[56])/alpha),
    'gated_fraction_baseline_global':.85,'gated_fraction_baseline_gradient_N':.75,'tested':tested,'selected':chosen}
report=HERE/'Plan.json'
expect=json.dumps(summary,indent=2)+'\n'
if report.exists():
    assert report.read_text(encoding='utf8')==expect
else:
    report.write_text(expect,encoding='utf8')
output=HERE/'Candidate.csv'
if chosen:
    fmt=lambda x:format(x,'.17g')
    line=lambda x:';'.join([x['name'],fmt(x['radius']),fmt(x['prediction_MPa']),*map(fmt,x['dq'])])
    expected_lines=('\r\n'.join(line(row) for row in chosen)+'\r\n').encode('ascii')
    if output.exists():
        assert output.read_bytes()==expected_lines
    else:
        output.write_bytes(expected_lines)
    for item in chosen:
        print(item['name'],item['radius'],item['prediction_MPa'],item['linear_by_mode'])
else:
    print('NO_ELIGIBLE_CANDIDATE',digest(HERE/'Plan.json'))
