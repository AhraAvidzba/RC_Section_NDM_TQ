' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает касательную в подтверждённой пробе BothSmall и отдельно проверяет ограниченные поправки.
Public Function RunTestWangShearControlled(ByVal replayPath As String, ByVal phase As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Const EC As Double = 30000#, NU As Double = 0.2, FT As Double = 2.10667357864589
    Const PEAK_STRAIN As Double = 0.0022, LOCALIZATION_LENGTH As Double = 125#
    concrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    plusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    response.Initialize operators, concrete, steel
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, response, EC, plusSide, minusSide
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim materials(-1 To 1) As CCoupledConcreteResponse, responses(-1 To 1) As ICoupledPointResponse
    Set materials(0) = concrete: Set materials(1) = plusConcrete: Set materials(-1) = minusConcrete
    Set responses(0) = response: Set responses(1) = plusSide: Set responses(-1) = minusSide
    Dim base() As Double, anchor() As Double, qBase As Double, qTrial As Double, norm As Double, folder As String
    folder = Left$(replayPath, InStrRev(replayPath, "\"))
    ReadWangFreshAnchorTest folder & "AnchorField.csv", anchor
    base = history(24): qBase = factors(24): qTrial = qBase + (qBase - factors(23)) / 64#
    Dim output As Integer: output = FreeFile
    Open tracePath For Append As #output
    Print #output, "B_TANGENT_LOAD;" & ExperimentNumberTest(qBase) & ";" & ExperimentNumberTest(qTrial)
    Print #output, "B_FRESH_PHASE;" & phase
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Base24", 24, qBase, solver, operators, materials, responses, base)
    norm = RecordWangTangentStateTest(output, "Anchor", 24, qTrial, solver, operators, materials, responses, anchor)
    If norm <= 0# Then Err.Raise 5, , "Не воспроизведена проба BothSmall."
    If phase = "A" Then
        RecordWangFreshMatricesTest output, solver, operators, anchor
        Dim witness() As Double, sign As Variant, tag As String
        For Each sign In Array(1#, -1#)
            witness = anchor: witness(53) = witness(53) + CDbl(sign) * 0.000000005
            tag = "GradientPositive": If CDbl(sign) < 0# Then tag = "GradientNegative"
            norm = RecordWangTangentStateTest(output, tag, 24, qTrial, solver, operators, materials, responses, witness)
            If norm < 0# Then Err.Raise 5, , "Не получен контроль направления продольного градиента N."
        Next sign
        Dim i As Long, side As Long, kt As Double, kc As Double
        For i = 1 To operators.PointCount
            For side = -1 To 1
                materials(side).AcceptedPointDamage i, kt, kc
                Print #output, "B_FRESH_ENERGY;" & CStr(i) & ";" & CStr(side) & ";" & _
                    ExperimentNumberTest(kt) & ";" & ExperimentNumberTest(kc)
            Next side
        Next i
    ElseIf phase = "B" Then
        CheckWangFreshCandidatesTest output, folder & "Candidate.csv", history, solver, operators, materials, responses, _
            base, anchor, qTrial
    Else
        Err.Raise 5, , "Неизвестная фаза проверки MVT2 B."
    End If
    RequireWangAcceptedFieldTest solver, base
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Restored24", 24, qBase, solver, operators, materials, responses, base)
    Print #output, "B_TANGENT_END;24;" & ExperimentNumberTest(qBase)
    Close #output
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    Dim problem As String: problem = Err.Source & " " & Err.Description
    On Error Resume Next
    If output > 0 Then Close #output
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Масштабирует одно и то же направление без изменения принятого поля решателя.
Private Sub AddWangTangentDirectionTest(ByRef base() As Double, ByRef direction() As Double, _
        ByVal amount As Double, ByRef target() As Double)
    Dim j As Long
    ReDim target(1 To UBound(base))
    For j = 1 To UBound(base): target(j) = base(j) + amount * direction(j): Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает вектор в инвариантной форме для независимой проверки.
Private Sub EmitWangTangentVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef values() As Double)
    Dim row As String, j As Long
    row = prefix
    For j = 1 To UBound(values): row = row & ";" & ExperimentNumberTest(values(j)): Next j
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет независимые центральные и боковые напряжения, признаки ветви и слабые строки.
Private Function RecordWangTangentStateTest(ByVal output As Integer, ByVal label As String, ByVal historyCount As Long, _
        ByVal factor As Double, ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef field() As Double) As Double
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, grad(1 To 6) As Double
    Dim residual() As Double, matrix() As Double, external() As Double, row As String, flag As Long
    Dim yielding As Boolean, principal As Long, substeps As Long, yieldValue As Double
    Dim concretePoint As ICoupledPointResponse, concreteStress(1 To 6) As Double, component As Long
    EmitWangTangentVectorTest output, "B_TANGENT_FIELD;" & label & ";" & CStr(historyCount) & ";" & _
        ExperimentNumberTest(factor), field
    RecordWangTangentStateTest = -1#
    If Not solver.TestEquilibriumLinearization(field, False, False, residual, matrix) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";Residual"
        Exit Function
    End If
    operators.LoadEquations 0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, external
    For i = 1 To UBound(residual): residual(i) = residual(i) - external(i): Next i
    EmitWangTangentVectorTest output, "B_TANGENT_RESIDUAL;" & label, residual
    Dim norm As Double, value As Double, actual(1 To 6) As Double, demand(1 To 6) As Double
    For i = 1 To UBound(residual)
        value = Abs(residual(i))
        If i > solver.PhysicalDegreeCount Then value = value * 30000#
        norm = GeomMax(norm, value)
    Next i
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For point = 1 To operators.PointCount
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, slope
        For side = -1 To 1
            For i = 1 To 6: station(i) = strain(i) + side * 0.001 * slope(i): Next i
            If responses(side).EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Не подтвержден станционный отклик MVT2 B. " & label
            If side = 0 Then
                actual(1) = actual(1) + area * stress(3)
                actual(2) = actual(2) + area * stress(3) * y
                actual(3) = actual(3) + area * stress(3) * x
                actual(4) = actual(4) + area * (x * stress(6) - y * stress(5))
                actual(5) = actual(5) + area * stress(5)
                actual(6) = actual(6) + area * stress(6)
            End If
            If point > operators.ConcretePointCount Then
                Set concretePoint = materials(side)
                If concretePoint.EvaluatePoint(point, station, concreteStress, tangent, ctmStressOnly, False) <> sfcNone Then _
                    Err.Raise 5, , "Не подтверждён бетон в поправке замещения арматуры MVT2 B. " & label
                component = 3 ' Продольные стержни имеют ось z.
                If point > operators.ConcretePointCount + 4 Then
                    If Abs(x) > Abs(y) Then component = 2 Else component = 1 ' Ось ветви параллельна стенке квадрата.
                End If
                Print #output, "B_BOUND_STEEL;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & CStr(component) & ";" & _
                    ExperimentNumberTest(station(component)) & ";" & ExperimentNumberTest(concreteStress(component)) & ";" & _
                    ExperimentNumberTest(stress(component) + concreteStress(component))
            End If
            flag = -1: principal = 0: substeps = -1: yieldValue = 0#
            If point <= operators.ConcretePointCount Then
                If Not materials(side).TryReadConcreteBranch(point, station, yielding, principal, substeps) Then _
                    Err.Raise 5, , "Недоступна ветвь бетона MVT2 B. " & label
                If Not materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=False) Then _
                    Err.Raise 5, , "Недоступна пробная поверхность бетона MVT2 B. " & label
                flag = Abs(CLng(yielding))
            End If
            row = "B_TANGENT_STATION;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area) & ";" & _
                CStr(flag) & ";" & CStr(principal) & ";" & CStr(substeps) & ";" & ExperimentNumberTest(yieldValue)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(station(i)): Next i
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(i)): Next i
            Print #output, row
        Next side
    Next point
    EmitWangTangentVectorTest output, "B_BOUND_ACTUAL;" & label, actual
    RecordWangTangentStateTest = GeomMax(norm, operators.ResultantResidualNorm(actual, demand))
    Print #output, "B_BOUND_NORM;" & label & ";" & ExperimentNumberTest(RecordWangTangentStateTest)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает наибольшую взвешенную компоненту тензора на всех 135 станциях.
Private Function WangBoundedTensorPeakTest(ByVal operators As CCoupledElasticState, ByRef direction() As Double) As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double
    Dim point As Long, side As Long, j As Long, s As Double, peak As Double
    For point = 1 To operators.PointCount
        operators.PointStrain point, direction, strain
        operators.AxialGradientAtPoint point, direction, slope
        For side = -1 To 1
            For j = 1 To 6
                s = Abs(strain(j) + side * 0.001 * slope(j))
                If j > 3 Then s = s / Sqr(2#)
                peak = GeomMax(peak, s)
            Next j
        Next side
    Next point
    WangBoundedTensorPeakTest = peak
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает 60 архивных координат BothSmall без добавления поля в историю.
Private Sub ReadWangFreshAnchorTest(ByVal path As String, ByRef field() As Double)
    Dim file As Integer, row As String, values As Variant, k As Long
    file = FreeFile: Open path For Input As #file
    Line Input #file, row
    Close #file
    values = Split(row, ";")
    If UBound(values) <> 59 Then Err.Raise 5, , "Неверный архив поля BothSmall."
    ReDim field(1 To 60)
    For k = 1 To 60: field(k) = Val(values(k - 1)): Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает свежие матрицы и проекцию слабых строк в шесть подписанных усилий.
Private Sub RecordWangFreshMatricesTest(ByVal output As Integer, ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByRef anchor() As Double)
    Dim matrix() As Double, residual() As Double, projection() As Double, choice As Long, i As Long, j As Long
    Dim label As String, row As String
    For choice = 1 To 2
        label = "Stock": If choice = 2 Then label = "Consistent"
        If solver.CopyTestWangTangent(anchor, choice, residual, matrix) Then
            EmitWangTangentVectorTest output, "B_FRESH_INTERNAL;" & label, residual
            For i = 1 To UBound(anchor)
                row = "B_FRESH_MATRIX;" & label & ";" & CStr(i)
                For j = 1 To UBound(anchor): row = row & ";" & ExperimentNumberTest(matrix(j, i)): Next j
                Print #output, row
            Next i
        Else
            Print #output, "B_FRESH_MATRIX_UNAVAILABLE;" & label
        End If
    Next choice
    operators.CopyResultantResidualProjection projection
    For i = 1 To 6
        row = "B_FRESH_PROJECTION;" & CStr(i)
        For j = 1 To solver.PhysicalDegreeCount: row = row & ";" & ExperimentNumberTest(projection(j, i)): Next j
        Print #output, row
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет только заранее вычисленные ограниченные поправки, сохраняя принятую H24.
Private Sub CheckWangFreshCandidatesTest(ByVal output As Integer, ByVal path As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByRef anchor() As Double, ByVal factor As Double)
    Dim file As Integer, row As String, values As Variant, field() As Double, correction(1 To 60) As Double
    Dim count As Long, label As String, radius As Double, prediction As Double, extent As Double, k As Long, norm As Double
    file = FreeFile: Open path For Input As #file
    Do Until EOF(file)
        Line Input #file, row
        values = Split(row, ";")
        If UBound(values) <> 62 Or count >= 6 Then Err.Raise 5, , "Неверный перечень ограниченных проб MVT2 B."
        label = values(0): radius = Val(values(1)): prediction = Val(values(2))
        For k = 1 To 60: correction(k) = Val(values(k + 2)): Next k
        extent = WangBoundedTensorPeakTest(operators, correction)
        If radius <= 0# Or radius > 0.00000001 Or extent > radius + 0.0000000000000004 Then _
            Err.Raise 5, , "Нарушено ограничение приращения деформаций MVT2 B."
        RestoreWangShearBaselineTest solver, history, base
        AddWangTangentDirectionTest anchor, correction, 1#, field
        Print #output, "B_FRESH_INPUT;" & label & ";" & ExperimentNumberTest(radius) & ";" & _
            ExperimentNumberTest(prediction) & ";" & ExperimentNumberTest(extent)
        norm = RecordWangTangentStateTest(output, label, 24, factor, solver, operators, materials, responses, field)
        RequireWangAcceptedFieldTest solver, base
        count = count + 1
    Loop
    Close #file
    If count < 1 Then Err.Raise 5, , "Проверенных ограниченных поправок нет."
    Print #output, "B_FRESH_PROBES;" & CStr(count)
End Sub
