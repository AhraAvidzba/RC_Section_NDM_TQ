' -------------------- ДЛЯ ТЕСТОВ --------------------
' Уточняет локальную ветвь B от одного и того же принятого поля при постоянном T.
Public Function RunTestWangShearControlled(ByVal replayPath As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, 30000#, 0.2, _
        fc, 2.10667357864589, 0.0022, gt, gc, True
    Dim path As New CLoadPathVector, offset() As Double, direction() As Double
    path.Initialize 0#, 0#, 0#, 600000#, 0#, 0#, 10510000#, 0#, 0#, 0#, 0#, 1000#
    path.Components offset, direction
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim previous() As Double, baseline() As Double, trial() As Double, warmField() As Double, seed() As Double
    Dim target As Double, trialFactor As Double, startingFactor As Double, mode As Variant, multiple As Variant
    Dim ratio As Double, currentFactor As Double, previousFactor As Double, warmFactor As Double, k As Long
    Dim label As String, seedArgument As Variant
    previous = history(history.Count - 1): baseline = history(history.Count)
    previousFactor = factors(history.Count - 1): currentFactor = factors(history.Count)
    ReadWangWarmStartTest Left$(replayPath, InStrRev(replayPath, "\")) & "WarmStart.csv", warmField, warmFactor
    AppendWangFieldTest report, tracePath, "FormerPositiveRaw", warmField
    AddExperimentTraceTest report, tracePath, "B_CONTROL_WARM;" & ExperimentNumberTest(warmFactor)
    RestoreWangShearBaselineTest solver, history, baseline
    RecordWangShearEquilibriumTest operators, solver, response, path, baseline, currentFactor, 4, baseline(4), _
        "Base", report, tracePath
    For Each multiple In Array(0#, 0.25, 0.5, -0.5)
        ratio = CDbl(multiple) / 64#
        target = baseline(4) + ratio * (baseline(4) - previous(4))
        For Each mode In Array("Cold", "Warm")
            If mode = "Cold" Or ratio <> 0# Then
                RestoreWangShearBaselineTest solver, history, baseline
                label = CStr(mode) & "/" & ExperimentNumberTest(CDbl(multiple))
                If mode = "Cold" Then
                    startingFactor = currentFactor + ratio * (currentFactor - previousFactor)
                    TryWangShearControlProbeTest label, 4, True, solver, operators, response, path, _
                        offset, direction, previous, baseline, currentFactor, previousFactor, target, startingFactor, _
                        ratio, trial, trialFactor, report, tracePath
                Else
                    ReDim seed(1 To UBound(baseline))
                    For k = 1 To UBound(seed): seed(k) = baseline(k) + CDbl(multiple) * (warmField(k) - baseline(k)): Next k
                    seedArgument = seed
                    startingFactor = currentFactor + CDbl(multiple) * (warmFactor - currentFactor)
                    AppendWangFieldTest report, tracePath, label & "/Seed", seed
                    TryWangShearControlProbeTest label, 4, True, solver, operators, response, path, _
                        offset, direction, previous, baseline, currentFactor, previousFactor, target, startingFactor, _
                        ratio, trial, trialFactor, report, tracePath, seedArgument
                End If
                solver.DiscardStep
                RequireWangAcceptedFieldTest solver, baseline
                RestoreWangShearBaselineTest solver, history, baseline
                RecordWangShearEquilibriumTest operators, solver, response, path, baseline, currentFactor, 4, baseline(4), _
                    label & "/Rollback", report, tracePath
            End If
        Next mode
    Next multiple
    AddExperimentTraceTest report, tracePath, "B_CONTROL_END;LocalBracketOnly;0;" & ExperimentNumberTest(currentFactor)
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает одну точную пробу, проверяет продолжение физического направления, сталь и сопряжённую оценку.
Private Function TryWangShearControlProbeTest(ByVal label As String, ByVal axis As Long, ByVal consistent As Boolean, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, ByVal response As CCoupledReinforcedResponse, _
        ByVal path As CLoadPathVector, ByRef offset() As Double, ByRef direction() As Double, ByRef previous() As Double, _
        ByRef current() As Double, ByVal currentFactor As Double, ByVal previousFactor As Double, ByVal target As Double, _
        ByVal initialFactor As Double, ByVal ratio As Double, ByRef trial() As Double, ByRef trialFactor As Double, _
        ByRef report As String, ByVal tracePath As String, Optional ByRef seed As Variant) As Boolean
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005
    Dim projection(1 To 60) As Double, expected() As Double, actual() As Double
    Dim weak As Double, gauge As Double, integral As Double, control As Double, tolerance As Double
    Dim status As String, details As String, steel As Double, adjoint As Double, code As Long, k As Long
    Dim solved As Boolean, steelPoint As Long, adjointOK As Boolean
    Dim previousDelta As Double, currentDelta As Double, dot As Double, previous2 As Double, trial2 As Double
    Dim forward As Boolean, effectiveLoadBound As Double
    projection(axis) = 1#
    trialFactor = currentFactor
    status = "SolverRejected"
    solved = solver.TryDeformationStep(offset, direction, projection, target, initialFactor, trialFactor, _
        ABS_TOL, REL_TOL, 26, consistentControl:=consistent, initialField:=seed)
    Erase trial
    If solved Then
        solver.CopyTrial trial, actual
        steel = response.TrialSteelUtilization: steelPoint = response.TrialSteelCriticalPoint
        For k = 1 To solver.PhysicalDegreeCount
            previousDelta = current(k) - previous(k): currentDelta = trial(k) - current(k)
            dot = dot + previousDelta * currentDelta
            previous2 = previous2 + previousDelta * previousDelta: trial2 = trial2 + currentDelta * currentDelta
        Next k
        effectiveLoadBound = 3# * Abs(ratio) * GeomMax(Abs(currentFactor - previousFactor), 0.01)
        forward = (ratio = 0# Or (Sgn(ratio) * dot > 0# And trial2 <= 9# * ratio * ratio * previous2 And _
            Abs(trialFactor - currentFactor) <= effectiveLoadBound))
        status = "ForwardRejected"
        If trialFactor > 0# And steel <= 1# And forward Then
            path.TargetSix trialFactor, expected
            WangControlledNormTest operators, solver, trial, actual, expected, projection, target, 30000#, weak, gauge, integral, control
            tolerance = WangTurnToleranceTest(operators, path, initialFactor, ABS_TOL, REL_TOL)
            status = "BalanceRejected"
            If GeomMax(GeomMax(weak, gauge), GeomMax(integral, control)) <= tolerance Then
                status = "AdjointUnavailable"
                If solver.TrialLambdaUncertainty(ABS_TOL, REL_TOL, adjoint) Then status = "Accepted"
            End If
        End If
    End If
    code = solver.ResultMeta.ResultCode: details = solver.ResultMeta.DiagnosticDetails
    RequireWangAcceptedFieldTest solver, current
    AddExperimentTraceTest report, tracePath, "B_CONTROL_PROBE;" & label & ";" & CStr(axis) & ";" & _
        CStr(Abs(CLng(consistent))) & ";" & ExperimentNumberTest(target) & ";" & ExperimentNumberTest(initialFactor) & ";" & _
        ExperimentNumberTest(ratio) & ";" & ExperimentNumberTest(currentFactor) & ";" & ExperimentNumberTest(previousFactor) & ";" & _
        ExperimentNumberTest(trialFactor) & ";" & status & ";" & CStr(code) & ";" & Replace(details, vbCrLf, " ")
    If Not solved Then Exit Function
    adjointOK = (status = "Accepted")
    If Not adjointOK And status <> "AdjointUnavailable" Then adjointOK = solver.TrialLambdaUncertainty(ABS_TOL, REL_TOL, adjoint)
    Dim row As String
    row = "B_CONTROL_RAW;" & label & ";" & ExperimentNumberTest(dot) & ";" & _
        ExperimentNumberTest(previous2) & ";" & ExperimentNumberTest(trial2) & ";" & _
        ExperimentNumberTest(9# * ratio * ratio * previous2) & ";" & ExperimentNumberTest(Abs(trialFactor - currentFactor)) & ";" & _
        ExperimentNumberTest(effectiveLoadBound) & ";" & _
        ExperimentNumberTest(steel) & ";" & CStr(steelPoint) & ";" & CStr(Abs(CLng(adjointOK))) & ";" & ExperimentNumberTest(adjoint)
    For k = 1 To 6: row = row & ";" & ExperimentNumberTest(actual(k)): Next k
    AddExperimentTraceTest report, tracePath, row
    RecordWangShearEquilibriumTest operators, solver, response, path, trial, trialFactor, axis, target, _
        label & "/Raw", report, tracePath, raw:=True
    TryWangShearControlProbeTest = (status = "Accepted")
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает фактический центральный отклик, отдельно собирает шесть усилий и проверяет слабые строки.
Private Sub RecordWangShearEquilibriumTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByVal response As CCoupledReinforcedResponse, ByVal path As CLoadPathVector, ByRef field() As Double, _
        ByVal factor As Double, ByVal axis As Long, ByVal target As Double, ByVal label As String, _
        ByRef report As String, ByVal tracePath As String, Optional ByVal raw As Boolean = False)
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005
    If Not raw Then RequireWangAcceptedFieldTest solver, field
    Dim material As ICoupledPointResponse: Set material = response
    Dim strain(1 To 6) As Double, stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim actual(1 To 6) As Double, expected() As Double, projection(1 To 60) As Double, residual() As Double
    Dim i As Long, k As Long, x As Double, y As Double, area As Double, row As String
    Dim weak As Double, gauge As Double, integral As Double, control As Double, tolerance As Double
    For i = 1 To operators.PointCount
        operators.Point i, x, y, area
        operators.PointStrain i, field, strain
        If material.EvaluatePoint(i, strain, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
            Err.Raise 5, , "Невозможно пересчитать станционный отклик B."
        row = "B_CONTROL_STATION;" & label & ";" & CStr(i) & ";" & ExperimentNumberTest(x) & ";" & _
            ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area)
        For k = 1 To 6: row = row & ";" & ExperimentNumberTest(strain(k)): Next k
        For k = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(k)): Next k
        AddExperimentTraceTest report, tracePath, row
        actual(1) = actual(1) + area * stress(3)
        actual(2) = actual(2) + area * stress(3) * y
        actual(3) = actual(3) + area * stress(3) * x
        actual(4) = actual(4) + area * (x * stress(6) - y * stress(5))
        actual(5) = actual(5) + area * stress(5)
        actual(6) = actual(6) + area * stress(6)
    Next i
    projection(axis) = 1#
    path.TargetSix factor, expected
    WangControlledNormTest operators, solver, field, actual, expected, projection, target, 30000#, weak, gauge, integral, control
    tolerance = WangTurnToleranceTest(operators, path, factor, ABS_TOL, REL_TOL)
    If Not raw And GeomMax(GeomMax(weak, gauge), GeomMax(integral, control)) > tolerance Then _
        Err.Raise 5, , "Подтверждённая история B не воспроизвела исходный допуск равновесия. " & label & " " & _
            ExperimentNumberTest(weak) & " " & ExperimentNumberTest(gauge) & " " & ExperimentNumberTest(integral)
    row = "B_CONTROL_EQUILIBRIUM;" & label & ";" & CStr(axis) & ";" & ExperimentNumberTest(target) & ";" & _
        ExperimentNumberTest(factor) & ";" & ExperimentNumberTest(tolerance) & ";" & ExperimentNumberTest(weak) & ";" & _
        ExperimentNumberTest(gauge) & ";" & ExperimentNumberTest(integral) & ";" & ExperimentNumberTest(control)
    For k = 1 To 6: row = row & ";" & ExperimentNumberTest(actual(k)): Next k
    AddExperimentTraceTest report, tracePath, row
    AppendWangFieldTest report, tracePath, label, field
End Sub
 ' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считывает только архивный прогноз для первого шага Ньютона без записи истории.
Private Sub ReadWangWarmStartTest(ByVal filename As String, ByRef field() As Double, ByRef factor As Double)
    Dim file As Integer, row As String, parts As Variant, k As Long
    file = FreeFile
    Open filename For Input As #file
    Line Input #file, row
    Close #file
    parts = Split(row, ";")
    If UBound(parts) <> 60 Then Err.Raise 5, , "Неверный размер архивного прогноза B."
    factor = Val(parts(0))
    ReDim field(1 To 60)
    For k = 1 To 60: field(k) = Val(parts(k)): Next k
End Sub
