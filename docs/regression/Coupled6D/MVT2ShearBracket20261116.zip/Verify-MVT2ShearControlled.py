"""Independently reconstruct B resultants and verify exact directed controls and ownership."""
from collections import defaultdict
from hashlib import sha256
import json
import math
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
NATIVE=HERE/"Native"
MODULUS=30000.
BASE_FORCE_ARCHIVED=(-.0000439129602785443,11134865.9994933,-.00127382198084014,10509999.9997492,.0000042615867257784,18558.1099948724)

def reading(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()

def near(a,b,tol):
    assert abs(a-b)<=tol,(a,b,tol)

def maxdiff(x,y):
    return max(abs(a-b) for a,b in zip(x,y,strict=True))

def demand(q):
    return (0.,600000*q,0.,10510000.,0.,1000*q)

def reconstruct(stations):
    assert len(stations)==45
    parts=[]
    for n,x,y,area,*stuff in stations:
        assert int(n)==len(parts)+1 and len(stuff)==12 and all(map(math.isfinite,stuff))
        z,xz,yz=stuff[8],stuff[10],stuff[11]
        parts.append((area*z,area*z*y,area*z*x,area*(x*yz-y*xz),area*xz,area*yz))
    return tuple(map(math.fsum,zip(*parts,strict=True)))

def main():
    offline="--offline" in sys.argv
    prep=reading(HERE/"Preparation.json")
    build=reading(HERE/"docs/regression/CodeUpdate.json")
    compile_close=reading(HERE/"CompileClosure.json")
    receipt=reading(NATIVE/"RunReceipt.json")
    close=reading(NATIVE/"MVT2.txt.ProcessClosure.json")
    owner=reading(NATIVE/"MVT2.txt.Ownership.json")
    logs=(NATIVE/"MVT2.txt").read_text(encoding="utf-8-sig")
    assert build["Compiled"] and not build["ProductionChanged"] and sorted(build["Modules"])==prep["only_updated_modules"]==["CCoupledNewtonSolver","modTestCoupledExperiment"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and compile_close["State"]=="Absent"
    if not offline:
        assert digest(HERE/"docs/regression/Diagnostic.xlsm")==build["WorkbookSHA256"]
    assert digest(HERE/"Replay.csv")==prep["replay_sha256"]
    assert digest(HERE/"WarmStart.csv")==prep["warm_start_sha256"]
    assert digest(HERE/"src/CCoupledNewtonSolver.cls")==prep["solver_module_sha256"]
    assert digest(HERE/"tests/modTestCoupledExperiment.bas")==prep["module_sha256"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    final=close["Closure"]["FinalState"]
    assert close["Passed"] and close["ChildHasExited"] and close["RunnerCleanupValid"] and close["ChildExitCode"]==receipt["native_exit"]==0
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in logs and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in logs
    source=(NATIVE/"MVT2.csv").read_text(encoding="cp1251")
    tags=defaultdict(list)
    for line in source.splitlines():
        kind,*row=line.split(";")
        tags[kind].append(row)
    field={label:tuple(map(float,row)) for label,*row in tags["MVT2_CONTROL_FIELD"]}
    assert len(field)==len(tags["MVT2_CONTROL_FIELD"]) and all(len(values)==60 for values in field.values())
    archive=[tuple(map(float,line.split(";"))) for line in (HERE/"Replay.csv").read_text(encoding="ascii").splitlines()[1:]]
    assert len(archive)==24
    for i,(index,offset,factor,*load_field) in enumerate(archive,1):
        demand_row=list(demand(factor))
        demand_row[3]*=offset
        assert index==i and len(load_field)==66 and maxdiff(load_field[:6],demand_row)<1e-6
        assert maxdiff(field[f"Replay{i}"],load_field[6:])<1e-15
    stations=defaultdict(list)
    for label,*values in tags["B_CONTROL_STATION"]:
        stations[label].append(tuple(map(float,values)))
    assert len(tags["B_CONTROL_SETUP"])==1
    n,area,length=map(float,tags["B_CONTROL_SETUP"][0])
    assert n==24
    near(area,240.**2,1e-6);near(length,155.56349186104046,1e-7)
    scale=(area,area*length,area*length,area*length,area,area)
    def tolerance(factor):
        return 5e-7*(1+max(abs(force/s) for force,s in zip(demand(factor),scale,strict=True)))
    def normalized(a,b):
        return max(abs(x-y)/den for x,y,den in zip(a,b,scale,strict=True))
    equilibria={}
    for label,*values in tags["B_CONTROL_EQUILIBRIUM"]:
        axis,target,q,tol,weak,gauge,integral,control,*forces=map(float,values)
        assert label not in equilibria and len(forces)==6
        direct=reconstruct(stations[label])
        assert normalized(direct,forces)<=2e-12
        near(tol,tolerance(q),5e-15)
        near(integral,normalized(direct,demand(q)),2e-12)
        near(control,MODULUS*abs(field[label][int(axis)-1]-target),2e-12)
        if not label.endswith("/Raw"):
            assert max(weak,gauge,integral,control)<=tol+2e-12
        equilibria[label]={"q_kN":q,"coordinate":target,"resultants_N_Nmm":direct,"norms_MPa":[weak,gauge,integral,control],"tolerance_MPa":tol}
    assert field["Base"]==field["Replay24"] and set(stations)==set(equilibria)
    assert normalized(equilibria["Base"]["resultants_N_Nmm"],BASE_FORCE_ARCHIVED)<2e-8
    names=("Cold/0","Cold/.25","Warm/.25","Cold/.5","Warm/.5","Cold/-.5","Warm/-.5")
    warm_expected=list(map(float,(HERE/"WarmStart.csv").read_text(encoding="ascii").split(";")))
    [[warm_factor]]=tags["B_CONTROL_WARM"]
    assert float(warm_factor)==warm_expected[0] and tuple(warm_expected[1:])==field["FormerPositiveRaw"]
    for name in names:
        label=name+"/Rollback"
        assert field[label]==field["Base"] and stations[label]==stations["Base"]
        assert equilibria[label]==equilibria["Base"]
    raw_rows={label:tuple(map(float,values)) for label,*values in tags["B_CONTROL_RAW"]}
    assert len(raw_rows)==len(tags["B_CONTROL_RAW"]) and set(raw_rows).issubset(names)
    assert set(equilibria)=={"Base",*(f"{name}/Rollback" for name in names),*(f"{name}/Raw" for name in raw_rows)}
    [[outcome,added,terminal]]=tags["B_CONTROL_END"]
    assert outcome=="LocalBracketOnly" and int(added)==0 and not tags["B_CONTROL_BRANCH"]
    near(float(terminal),archive[-1][2],2e-13)
    left,right=field["Replay23"],field["Replay24"]
    delta=[b-a for a,b in zip(left[:56],right[:56],strict=True)]
    outputs={}
    for label,axis,consistent,target,initial,ratio,qold,qprev,q,status,code,*diag in tags["B_CONTROL_PROBE"]:
        axis,consistent,code=int(axis),int(consistent),int(code)
        target,initial,ratio,qold,qprev,q=map(float,(target,initial,ratio,qold,qprev,q))
        assert label in names and label not in outputs and axis==4 and consistent==1
        seed_mode,offset=label.split("/")
        offset=float(offset)
        near(ratio,offset/64,1e-16)
        near(qold,archive[23][2],3e-14);near(qprev,archive[22][2],3e-14)
        near(target,right[axis-1]+ratio*(right[axis-1]-left[axis-1]),3e-16)
        if seed_mode=="Cold":
            near(initial,qold+ratio*(qold-qprev),2e-13)
            assert label+"/Seed" not in field
        else:
            near(initial,qold+offset*(float(warm_factor)-qold),2e-13)
            seed=[a+offset*(b-a) for a,b in zip(right,warm_expected[1:],strict=True)]
            assert maxdiff(field[label+"/Seed"],seed)<2e-15
        result={"mode":seed_mode,"fraction_of_former_positive_displacement":offset,"target":target,
            "starting_q_kN":initial,"status":status,"code":code,"diagnostics":";".join(diag)}
        outputs[label]=result
        if status=="SolverRejected":
            assert label not in raw_rows and label+"/Raw" not in field and code!=0
            near(q,qold,2e-13)
            continue
        assert label in raw_rows and code==0 and status in ("ForwardRejected","BalanceRejected","AdjointUnavailable","Accepted")
        dot,past2,trial2,bound2,loadchange,loadbound,steel,steel_point,has_adjoint,adjoint,*forces=raw_rows[label]
        trial=field[label+"/Raw"]
        move=[b-a for a,b in zip(right[:56],trial[:56],strict=True)]
        near(dot,math.fsum(a*b for a,b in zip(delta,move,strict=True)),1e-17)
        near(past2,math.fsum(a*a for a in delta),1e-17)
        near(trial2,math.fsum(a*a for a in move),1e-17)
        near(bound2,9*ratio*ratio*past2,1e-17)
        near(loadchange,abs(q-qold),2e-13)
        near(loadbound,3*abs(ratio)*max(abs(qold-qprev),.01),2e-14)
        near(trial[3],target,2e-12)
        raw=equilibria[label+"/Raw"]
        assert len(forces)==6 and normalized(raw["resultants_N_Nmm"],forces)<2e-10
        assert has_adjoint in (0.,1.) and (adjoint>0. if has_adjoint else adjoint==0.)
        assert 26<=steel_point<=45
        def steel_utilization_for(row):
            _,x,y,_,*strain_stress=row
            if abs(abs(x)-84.)<1e-8 and abs(abs(y)-84.)<1e-8:
                axial=strain_stress[2]
            elif abs(abs(x)-96.)<1e-8:
                axial=strain_stress[1]
            else:
                near(abs(y),96.,1e-8)
                axial=strain_stress[0]
            return abs(axial)/.05
        utilization=[steel_utilization_for(row) for row in stations[label+"/Raw"][25:]]
        near(max(utilization),steel,3e-12)
        near(utilization[int(steel_point)-26],steel,3e-12)
        failed=[metric for metric,pass_ in zip(("positive_load","steel","forward_dot","field_length","load_length"),
            (q>0.,steel<=1.,ratio==0. or ratio*dot>0.,ratio==0. or trial2<=bound2,ratio==0. or loadchange<=loadbound),strict=True) if not pass_]
        assert (status=="ForwardRejected")==bool(failed)
        if status=="BalanceRejected":
            assert max(raw["norms_MPa"])>tolerance(initial)-2e-12
        elif status in ("Accepted","AdjointUnavailable"):
            assert max(raw["norms_MPa"])<=tolerance(initial)+2e-12
            assert (status=="Accepted")==bool(has_adjoint)
        result.update({"solved_q_kN":q,"failed_guard":failed,"resultant_delta_kN":q-qold,"dot":dot,
            "cosine":dot/math.sqrt(past2*trial2) if trial2 else None,
            "trial_step":math.sqrt(trial2),"step_bound":math.sqrt(bound2),"load_change_kN":loadchange,
            "load_bound_kN":loadbound,"steel_utilization":steel,"steel_point":int(steel_point),
            "adjoint_uncertainty_kN":adjoint if has_adjoint else None,"raw_equilibrium":raw})
    assert tuple(outputs)==names
    pairing={}
    for cold,warm in (("Cold/.25","Warm/.25"),("Cold/.5","Warm/.5"),("Cold/-.5","Warm/-.5")):
        if cold in raw_rows and warm in raw_rows:
            c,w=outputs[cold],outputs[warm]
            load_diff=w["solved_q_kN"]-c["solved_q_kN"]
            field_difference=math.dist(field[cold+"/Raw"][:56],field[warm+"/Raw"][:56])
            pairing[cold]={"warm_minus_cold_q_kN":load_diff,"physical_field_difference":field_difference}
    total={"source_workbook_sha256":prep["book_sha256"],"replay_sha256":prep["replay_sha256"],
        "native_trace_sha256":digest(NATIVE/"MVT2.csv"),"native_wall_s":receipt["wall_seconds"],
        "owner_pid":owner["PID"],"owner_ticks":str(owner["StartTicksUTC"]),"regular_closure":final["State"],
        "prefix_fields":len(archive),"exact_base_rollbacks":len(names),"base":equilibria["Base"],"probes":outputs,"warm_cold_comparison":pairing,
        "outcome":outcome,"last_q_kN":float(terminal),"physical_limit_confirmed":False}
    result=HERE/"Verification.json"
    result.write_text(json.dumps(total,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(result,digest(result))

if __name__=="__main__":
    main()
