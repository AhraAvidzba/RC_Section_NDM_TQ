"""Freeze the current workbook, archived B fields, and diagnostic-only module."""
import argparse
import hashlib
import json
from pathlib import Path
from shutil import copyfile

HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent/"MVT2MinimumFields"
BOOK=Path("workbook/output/RC_Section_NDM.xlsm")
DRAFT=Path("docs/regression/Diagnostic.xlsm")
MODULE=Path("tests/modTestCoupledExperiment.bas")
BOOK_SHA="A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A"
PREFIX_SHA="504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def main(repo, stage):
    assert digest(repo/BOOK)==BOOK_SHA
    archived=PRIOR/"MVT2ShearBReplay.csv"
    assert digest(archived)==PREFIX_SHA
    former=json.loads((PRIOR/"Preparation.json").read_text(encoding="utf-8"))
    assert digest(PRIOR/MODULE)==former["export_macro_sha256"]
    composed=((PRIOR/MODULE).read_text(encoding="utf-8-sig")+"\n"+
              (HERE/"Control.bas").read_text(encoding="utf-8")).replace("\n","\r\n").encode("utf-8")
    tools={path.relative_to(PRIOR):path for path in (PRIOR/"tools/build_workbook").iterdir() if path.is_file()}
    sources={**tools,BOOK:repo/BOOK,Path("Guard-IsolatedOffice.ps1"):PRIOR/"Guard-IsolatedOffice.ps1",Path("Replay.csv"):archived}
    for key,path in tools.items():
        assert digest(path)==former["frozen"][key.as_posix()]
    assert digest(sources[Path("Guard-IsolatedOffice.ps1")])==former["frozen"]["Guard-IsolatedOffice.ps1"]
    solver_source=(repo / "src/Solver/CCoupledNewtonSolver.cls").read_text(encoding="utf-8-sig")
    start=solver_source.index("Friend Function TryDeformationStep(")
    stop=solver_source.index("End Function",start)
    body=solver_source[start:stop]
    patched=body.replace("Optional ByVal consistentControl As Boolean = False) As Boolean", 
        "Optional ByVal consistentControl As Boolean = False, Optional ByRef initialField As Variant) As Boolean")
    patched=patched.replace("maxIterations, recoverYieldControl)", "maxIterations, recoverYieldControl, initialField)")
    assert body.count("Optional ByVal consistentControl As Boolean = False)")==1 and body.count("maxIterations, recoverYieldControl)")==1
    patched_solver=(solver_source[:start]+patched+solver_source[stop:]).replace("\n","\r\n").encode("utf-8")
    warm=HERE/"WarmStart.csv"
    assert digest(warm)=="1647A5364BFEDBDD9ACAB8796A573E280AFE762E8B557ED0406BB19662AF0D89"
    data={"book_sha256":BOOK_SHA,"replay_sha256":PREFIX_SHA,"watchdog_seconds":200,
          "only_updated_modules":["CCoupledNewtonSolver","modTestCoupledExperiment"],
          "solver_module_sha256":hashlib.sha256(patched_solver).hexdigest().upper(),"warm_start_sha256":digest(warm),
          "sources":{key.as_posix():digest(path) for key,path in sources.items()},
          "module_sha256":hashlib.sha256(composed).hexdigest().upper(),
          "native_harness":digest(HERE/"Run-MVT2ShearControlled.ps1")}
    receipt=HERE/"Preparation.json"
    if stage:
        assert not receipt.exists() and not (HERE/DRAFT).exists()
        for key,src in sources.items():
            dest=HERE/key
            dest.parent.mkdir(parents=True,exist_ok=True)
            assert not dest.exists()
            copyfile(src,dest)
        for directory in ("tests","Temp","Native","docs/regression"):
            (HERE/directory).mkdir(parents=True,exist_ok=True)
        (HERE/MODULE).write_bytes(composed)
        (HERE/"src/CCoupledNewtonSolver.cls").write_bytes(patched_solver)
        copyfile(HERE/BOOK,HERE/DRAFT)
        receipt.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
    assert json.loads(receipt.read_text(encoding="utf-8"))==data
    assert (HERE/MODULE).read_bytes()==composed
    assert (HERE/"src/CCoupledNewtonSolver.cls").read_bytes()==patched_solver
    assert all(digest(HERE/name)==expected for name,expected in data["sources"].items())
    print(data["book_sha256"],digest(receipt))

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo",type=Path)
    parser.add_argument("--stage",action="store_true")
    opts=parser.parse_args()
    main(opts.repo.resolve(strict=True),opts.stage)