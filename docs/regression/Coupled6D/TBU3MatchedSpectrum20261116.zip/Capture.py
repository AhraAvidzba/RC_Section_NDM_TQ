"""Capture center-station stresses from the authenticated TBU3 material replay."""
from argparse import ArgumentParser
from hashlib import sha256
from importlib.machinery import SourceFileLoader
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from types import SimpleNamespace
import json
import sys


def load_script(name, path):
    loader = SourceFileLoader(name, str(path))
    specification = spec_from_file_location(name, path, loader=loader)
    module = module_from_spec(specification)
    sys.modules[name] = module
    loader.exec_module(module)
    return module


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def capture(repo, helpers, output):
    archive = repo / 'docs/regression/Audit03/LocalGradientDerivative20261115'
    matched = archive / 'TBU3MatchedMaterial'
    tensors = archive / 'TBU3AcceptedTensors'
    receipt = matched / 'MatchedHistoryChecks.json'
    assert digest(receipt) == 'E42B5B4302F5C1D9CD4E5E9025C3421C2171A5FF65BF7790FC8A3CA6965D7BC4'
    replay = load_script('recorded_tbu3', matched / 'Compare-TBU3MatchedHistories.py')
    native = load_script('recorded_tbu3_native', tensors / 'Verify-TBU3AcceptedTensors.py')
    direct = replay.load_script('direct_probe', matched / 'Verify-NDTestAgainstBrick.py')
    material = load_script('recorded_asd_envelope', helpers / 'VerifyExplicitAsdEnvelope.py')
    args = SimpleNamespace(tensors=tensors, envelope=matched / 'TBU3Envelope.json')
    expected = json.loads(receipt.read_text(encoding='utf-8-sig'))
    rows = []
    original = replay.section_terms

    def read_center(geometry, stress, origin):
        if not rows:
            rows.append({'geometry': geometry, 'origin_mm': origin})
        assert rows[0] == {'geometry': geometry, 'origin_mm': origin}
        rows.append(stress)
        return original(geometry, stress, origin)

    replay.section_terms = read_center
    try:
        result = replay.compare(args, direct, native, material.load_envelope, material.install_envelope)
    finally:
        replay.ops.wipe()
    assert result['engine'] == expected['engine'] == '3.8.0'
    assert result['curve_sha256'] == expected['curve_sha256']
    assert set(result['steps']) == set(expected['steps'])
    layouts = ('matched', 'default', 'ndm')
    assert len(rows) == 1 + len(layouts) * len(result['steps'])
    fields = {}
    for index, (step, record) in enumerate(result['steps'].items()):
        assert tuple(record['wrench']) == layouts
        fields[step] = {
            'lambda': record['lambda_'], 'target': record['target'], 'wrenches': record['wrench'],
            'stress_by_model': {key: rows[1 + 3 * index + i] for i, key in enumerate(layouts)},
        }
        for key, wrench in record['wrench'].items():
            assert native.normalized_difference(wrench, expected['steps'][step]['wrench'][key]) < 2e-10
    proof = {
        'material_replay_sha256': digest(receipt), 'engine': result['engine'],
        'inputs': {'envelope_sha256': result['curve_sha256'], 'tensor_sha256': digest(tensors / 'Native2x6/TBU3_AcceptedTensors.csv')},
        **rows[0], 'fields': fields,
    }
    with output.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, separators=(',', ':'), allow_nan=False)
        stream.write('\n')
    print(output, digest(output))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', type=Path, required=True)
    parser.add_argument('--asd-helpers', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    inputs = parser.parse_args()
    capture(inputs.repo_root.resolve(), inputs.asd_helpers.resolve(), inputs.output)
