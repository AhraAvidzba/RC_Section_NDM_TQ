"""Split TBU3 torque into positive and negative principal stress contributions."""
from argparse import ArgumentParser
from hashlib import sha256
from math import fsum
from pathlib import Path
import json

import numpy as np


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def tensor(stress):
    xx, yy, zz, xy, xz, yz = stress
    return np.asarray(((xx, xy, xz), (xy, yy, yz), (xz, yz, zz)), dtype=float)


def torque(tensor_value, x, y, area):
    return float(area * (x * tensor_value[1, 2] - y * tensor_value[0, 2]) / 1e6)


def partition(geometries, origin, stresses):
    terms = []
    for point, concrete, steel in stresses:
        grade, _, x, y, area, projection = geometries[str(point)]
        x -= origin[0]
        y -= origin[1]
        tensor_value = tensor(concrete)
        principal, vectors = np.linalg.eigh(tensor_value)
        positive = (vectors * np.maximum(principal, 0.0)) @ vectors.T
        negative = (vectors * np.minimum(principal, 0.0)) @ vectors.T
        np.testing.assert_allclose(positive + negative, tensor_value, rtol=0, atol=5e-12)
        sign = 1.0 if grade == 'Concrete' else -1.0  # Сталь заменяет бетон своего приведённого объёма.
        steel_part = 0.0 if grade == 'Concrete' else torque(tensor(np.asarray(projection) * steel), x, y, area)
        terms.append((point, grade, x, y, torque(positive, x, y, sign * area),
                      torque(negative, x, y, sign * area), steel_part))
    assert len(terms) == len(geometries) == 176
    return terms


def sum_parts(terms):
    return [fsum(row[index] for row in terms) for index in (4, 5, 6)]


def classify(path, output):
    source = json.loads(path.read_text(encoding='utf-8'))
    original = path.with_name('MatchedHistoryChecks.json')
    assert digest(original) == source['material_replay_sha256'] == 'E42B5B4302F5C1D9CD4E5E9025C3421C2171A5FF65BF7790FC8A3CA6965D7BC4'
    reference = json.loads(original.read_text(encoding='utf-8'))
    results = {}
    summary = ('positive_concrete_kNm', 'negative_concrete_kNm', 'steel_kNm')
    for index, field in source['fields'].items():
        assert field['wrenches'] == reference['steps'][index]['wrench']
        partitions = {key: partition(source['geometry'], source['origin_mm'], stations)
                      for key, stations in field['stress_by_model'].items()}
        split = {key: sum_parts(parts) for key, parts in partitions.items()}
        for key, parts in split.items():
            assert abs(fsum(parts) - field['wrenches'][key][3] / 1e6) < 3e-11
        native, external = split['ndm'], split['matched']
        change = [a - b for a, b in zip(native, external, strict=True)]
        assert split['ndm'][2] == split['matched'][2] == split['default'][2]
        deviations = []
        for local, comparison in zip(partitions['ndm'], partitions['matched'], strict=True):
            assert local[:4] == comparison[:4]
            deviations.append((local[0], local[1], local[2], local[3], local[4] - comparison[4], local[5] - comparison[5]))
        assert abs(fsum(row[4] for row in deviations) - change[0]) < 1e-12
        assert abs(fsum(row[5] for row in deviations) - change[1]) < 1e-12
        deviations.sort(key=lambda row: abs(row[4] + row[5]), reverse=True)
        results[index] = {
            'target_torque_kNm': field['target'][3] / 1e6,
            'material_torque_kNm': {key: dict(zip(summary, value, strict=True)) for key, value in split.items()},
            'ndm_minus_matched_kNm': dict(zip(summary, change, strict=True)),
            'largest_local_differences': deviations[:5],
        }
    assert len(results) == 8
    end = results['8']
    change = end['ndm_minus_matched_kNm']
    signed_total = fsum(change.values())
    assert 16.11 < signed_total < 16.12 and 11.06 < change['negative_concrete_kNm'] < 11.08
    matched, default = (end['material_torque_kNm'][key] for key in ('matched', 'default'))
    proof = {'engine': source['engine'], 'captured_stress_sha256': digest(path),
             'compared_material_history_sha256': source['material_replay_sha256'], 'steps': results,
             'target_41_4_kNm': {'ndm_minus_matched_total_kNm': signed_total,
                 'negative_spectral_fraction_of_difference': change['negative_concrete_kNm'] / signed_total,
                 'default_minus_matched_kNm': {key: default[key] - matched[key] for key in summary}}}
    output.write_text(json.dumps(proof, indent=2, allow_nan=False) + '\n', encoding='utf-8', newline='\n')
    print(output, digest(output))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('capture', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    classify(args.capture, args.output)
