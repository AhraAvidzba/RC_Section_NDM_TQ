"""Stage an isolated-solver export using the already verified MVT2 tensor fixture."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
STORAGE = Path("D:/CodexScratch/RC_Section_NDM_TQ")
PREVIOUS = STORAGE / "MVTGauss25Tensors"
MACRO = "tests/modTestMVT2GaussSpan.bas"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def freeze():
    manifest = json.loads((PREVIOUS / "Preparation.json").read_bytes())
    files = {name: (PREVIOUS / name).read_bytes() for name in manifest["inputs"]}
    assert {name: digest(raw) for name, raw in files.items()} == manifest["inputs"]
    assert manifest["inputs"][MACRO] == "2711EFCEB259D3BC004A70CB06D6BED1DEC9AA394C7E84A8991984ECD974992A"
    solver = (REPO / "src/Solver/CCoupledNewtonSolver.cls").read_text(encoding="utf-8-sig")
    assert "Private Const SPATIAL_HALF_STEP As Double = 0.001 " in solver
    once = runpy.run_path(str(HERE.parent / "Stage.py"))["replace_one"]
    vb = files[MACRO].decode("utf-8-sig").replace("\r\n", "\n")
    vb = once(vb, '    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, FT, PEAK, gt, gc, True',
              '    Dim plusConcrete As CCoupledConcreteResponse, minusConcrete As CCoupledConcreteResponse\n'
              '    Dim plusSide As CCoupledReinforcedResponse, minusSide As CCoupledReinforcedResponse\n'
              '    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, FT, PEAK, gt, gc, True, _\n'
              '        plusConcrete, minusConcrete, plusSide, minusSide\n'
              '    If followMixed Then WriteMVT2OperatorsTest operators, tracePath')
    vb = once(vb, '        ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean)',
              '        ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean, _\n'
              '        ByRef plusConcrete As CCoupledConcreteResponse, ByRef minusConcrete As CCoupledConcreteResponse, _\n'
              '        ByRef plusSide As CCoupledReinforcedResponse, ByRef minusSide As CCoupledReinforcedResponse)')
    vb = once(vb, '    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse\n'
              '    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse',
              '    Set plusConcrete = New CCoupledConcreteResponse: Set minusConcrete = New CCoupledConcreteResponse\n'
              '    Set plusSide = New CCoupledReinforcedResponse: Set minusSide = New CCoupledReinforcedResponse')
    vb = once(vb, '        RunMVT2TorqueContinuationTest = RunMVT2ShearAfterPreloadTest(operators, concrete, response, solver, shearY, _\n'
              '            ATOL, RTOL, report, tracePath)',
              '        RunMVT2TorqueContinuationTest = RunMVT2ShearAfterPreloadTest(operators, concrete, response, solver, shearY, _\n'
              '            ATOL, RTOL, report, tracePath, plusConcrete, minusConcrete, plusSide, minusSide)')
    vb = once(vb, '        ByVal atol As Double, ByVal rtol As Double, ByRef report As String, ByVal tracePath As String) As Boolean',
              '        ByVal atol As Double, ByVal rtol As Double, ByRef report As String, ByVal tracePath As String, _\n'
              '        ByVal plusConcrete As CCoupledConcreteResponse, ByVal minusConcrete As CCoupledConcreteResponse, _\n'
              '        ByVal plusSide As CCoupledReinforcedResponse, ByVal minusSide As CCoupledReinforcedResponse) As Boolean')
    vb = once(vb, '        branch.CopySavedField item, field', '        branch.CopySavedField item, field\n'
              '        WriteMVT2OperatorFieldTest tracePath, "R" & CStr(item), field')
    vb = once(vb, '        WriteMVT2ShearTensorsTest operators, concrete, field, phase, TORQUE, qy, tracePath',
              '        WriteMVT2ShearTensorsTest operators, concrete, field, phase, TORQUE, qy, tracePath\n'
              '        WriteMVT2OperatorFieldTest tracePath, phase, field\n'
              '        If phase = "S1" Or phase = "S18" Then\n'
              '            WriteMVT2OperatorAnchorTest operators, tracePath, phase, -1, minusConcrete, minusSide\n'
              '            WriteMVT2OperatorAnchorTest operators, tracePath, phase, 0, concrete, response\n'
              '            WriteMVT2OperatorAnchorTest operators, tracePath, phase, 1, plusConcrete, plusSide\n'
              '        End If')
    vb += "\n" + (HERE / "OperatorCaptureTests.txt").read_text(encoding="utf-8")
    vb.encode("cp1251")
    assert max(map(len, vb.splitlines())) < 1024
    files[MACRO] = vb.replace("\n", "\r\n").encode("utf-8-sig")
    run = files["Run-Native.ps1"].decode("utf-8")
    run = once(run, '    python \'./Verify-Mixed.py\'',
               '    Copy-Item -LiteralPath ($trace+\'.Operators.csv\') -Destination "Native/Operators.csv"\n'
               '    python \'./Verify-Mixed.py\'')
    files["Run-Native.ps1"] = run.encode("utf-8")
    return manifest, files


def stage(root):
    manifest, files = freeze()
    manifest["inputs"] = {name: digest(raw) for name, raw in sorted(files.items())}
    if root is not None:
        root = root.resolve()
        authority = STORAGE.resolve()
        assert root != authority and root.is_relative_to(authority)
        root.mkdir()
        (root / "Temp").mkdir()
        book = files["workbook/output/RC_Section_NDM.xlsm"]
        files["docs/regression/Diagnostic.xlsm"] = book
        for name, raw in files.items():
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(raw)
        (root / "Preparation.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("PINNED", manifest["inputs"][MACRO], manifest["inputs"]["Run-Native.ps1"])


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path)
    stage(parser.parse_args().stage)
