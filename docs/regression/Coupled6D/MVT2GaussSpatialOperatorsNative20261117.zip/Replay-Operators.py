"""Reproduce seals and anchor checks from the independently extracted native archive."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import runpy
from subprocess import check_output


ROOT = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
BOOK_REV = "709e7dfa16c192748fc2c6d999925bdbf9948a4c"
MIXED_SHA = "9ECF9FE174B191D2C500435ECE66DF5C7DD8302066CFB0BD1CF5EE41287180F2"
OPERATOR_SHA = "D3B1A1EF41102F086A37F48288E861658BA71EEFAF592A8E6EC6598F68D10164"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def verify(repo):
    manifest = json.loads((ROOT / "Preparation.json").read_bytes())
    assert manifest["source_book_sha256"] == BOOK_SHA == manifest["inputs"][BOOK]
    current = repo / BOOK
    workbook = current.read_bytes() if current.is_file() else b""
    if digest(workbook) != BOOK_SHA:
        workbook = check_output(["git", "-C", str(repo), "show", f"{BOOK_REV}:{BOOK}"])
    assert digest(workbook) == BOOK_SHA
    book_path = ROOT / BOOK
    book_path.parent.mkdir(parents=True, exist_ok=True)
    with book_path.open("xb") as stream:
        stream.write(workbook)
    try:
        runpy.run_path(str(ROOT / "Verify-Mixed.py"))["main"]()
    finally:
        book_path.unlink()
    assert digest((ROOT / "VerificationMVTGaussMixed.json").read_bytes()) == MIXED_SHA
    check = runpy.run_path(str(ROOT / "Verify-Operators.py"))["verify"]
    result = check(ROOT, repo / "docs/regression/Coupled6D/MVT2GaussTensorCaptureNative20261117.zip")
    proof = (json.dumps(result, indent=2, sort_keys=True) + "\n").encode()
    assert digest(proof) == OPERATOR_SHA and proof == (ROOT / "VerifiedOperators.json").read_bytes()
    print("MVT2 SPATIAL OPERATORS PORTABLE PASS", OPERATOR_SHA)


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    verify(parser.parse_args().repo.resolve())
