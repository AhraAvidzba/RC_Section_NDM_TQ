"""Package verified MVT2 strain and equilibrium projection operators."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
NATIVE = Path("D:/CodexScratch/RC_Section_NDM_TQ/MVTGauss25Operators")


def digest(raw):
    return sha256(raw).hexdigest().upper()


def package(target):
    manifest = json.loads((NATIVE / "Preparation.json").read_bytes())
    frozen = {path: seal for path, seal in manifest["inputs"].items() if not path.endswith(".xlsm")}
    files = set(frozen) | {"Preparation.json", "Compile.log", "CompileClosure.json", "docs/regression/CodeUpdate.json",
                           "VerificationMVTGaussMixed.json", "VerificationMVTGaussTensors.json"}
    files |= {f"Native/{item.name}" for item in (NATIVE / "Native").iterdir() if item.is_file()}
    content = {name: (NATIVE / name).read_bytes() for name in sorted(files)}
    assert all(digest(content[name]) == seal for name, seal in frozen.items())
    for name in ("Replay-Operators.py", "Verify-Operators.py", "Stage-Operators.py", "Pack-Operators.py",
                 "OperatorCaptureTests.txt", "VerifiedOperators.json"):
        content[name] = (HERE / name).read_bytes()
    with ZipFile(target, "x", ZIP_DEFLATED, compresslevel=9) as output:
        for name, raw in content.items():
            output.writestr(ZipInfo(name), raw, ZIP_DEFLATED, compresslevel=9)
    print(target.name, digest(target.read_bytes()))


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    package(parser.parse_args().archive)
