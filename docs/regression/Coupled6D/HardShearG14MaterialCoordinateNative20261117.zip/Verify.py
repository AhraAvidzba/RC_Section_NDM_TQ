"""Recheck the four G14 material-control probes with the earlier physical tolerances."""

from argparse import ArgumentParser
import json
from math import fsum, isclose
from pathlib import Path

import DirectionVerify as reference
import PriorVerify as native


HERE=Path(__file__).resolve().parent
TARGETS=(-1.25e-7,-5e-8,5e-8,1.25e-7)


def inputs():
    fixture,expected,original=reference.inputs()
    receipt=native.read(HERE/'Baseline/Verification.json')
    path=HERE/'Baseline/HardG14Direction.csv'
    assert receipt['native_trace_sha256']==native.file_hash(path) and receipt['exact_prefix']==25
    return fixture,expected,original,path


def verify(fixture,expected,original,baseline_path):
    folder=HERE/'Native/Order10'
    proof=native.native_proof(fixture,folder)
    path=folder/'HardG14Direction.csv'
    earlier,old_tags,old_matrices,old_samples=reference.read_probe(baseline_path)
    events=[]
    trace=[]
    for row in path.read_text(encoding='cp1251').splitlines():
        key,*fields=row.split(';')
        if key=='EVENT':
            events.append({'args':fields})
        elif key.startswith('EVENT-'):
            assert events and key not in events[-1]
            events[-1][key]=fields
        else:
            trace.append(row)
    now,tags,matrices,samples=reference.read_probe(reference.TextTrace(trace))
    geometry,points,histories,_,rollback,records=now
    assert geometry['FINISH']==['COMPLETE','25','5']
    assert [part for part in now[1:]]==[part for part in earlier[1:]]
    assert tags==old_tags and matrices==old_matrices and samples==old_samples
    assert {name:geometry[name] for name in expected['geometry']}==expected['geometry']
    area,length,modulus,_=native.verify_geometry(fixture,10,geometry,points)
    scales=(area, area*length, area*length, area*length, area, area)
    direction,offset,projection=(native.numbers(geometry[name]) for name in ('DIRECTION','OFFSET','PROJECTION'))
    direction_eq=native.numbers(tags['DIRECTION-EQ'])
    start=native.numbers(samples[0]['DIR-FIELD'])
    delta=native.numbers(tags['CORRECTION'])
    end=[x+dx/128 for x,dx in zip(start,delta[:-1],strict=True)]
    prior,accepted=(native.numbers(records[entry]['FIELD']) for entry in (23,24))
    reports=[]
    for target,event in zip(TARGETS,events,strict=True):
        actual_target,fraction,seed_factor=native.numbers(event['args'][:3])
        solved=native.received(event['args'][3])
        iterations,evaluations=map(int,event['args'][4:])
        assert target==actual_target and 0.<fraction<1. and 1<=iterations<=6 and evaluations>=iterations
        assert seed_factor==samples[0]['lambda']+fraction/128*delta[-1]
        assert native.numbers(event['EVENT-SEED'])==[a+fraction*(b-a) for a,b in zip(start,end,strict=True)]
        assert event['EVENT-ROLLBACK']==['9744'] and ('EVENT-FIELD' in event)==solved
        report={'target_MPa':target,'solved':solved,'iterations':iterations,'evaluations':evaluations}
        if solved:
            factor,norm,tau,trial_yield,control,excursion,prior_move=native.numbers(event['EVENT-BALANCE'][:-1])
            assert native.received(event['EVENT-BALANCE'][-1]) and abs(trial_yield-target)<=2e-12 and factor>0.
            res,field,load,wrench=(native.numbers(event[name]) for name in ('EVENT-RESIDUAL','EVENT-FIELD','EVENT-LOAD','EVENT-WRENCH'))
            assert load==[a+factor*d for a,d in zip(offset,direction,strict=True)]
            assert isclose(control,fsum(a*b for a,b in zip(projection[:56],field[:56],strict=True)),abs_tol=2e-16)
            assert excursion==max(abs(x-a) for x,a in zip(field[:56],accepted[:56],strict=True))
            assert prior_move==max(abs(x-a) for x,a in zip(prior[:56],accepted[:56],strict=True))
            six=max(abs(a-b)/scale for a,b,scale in zip(load,wrench,scales,strict=True))
            weak=max(map(abs,res[:56]))
            assert isclose(norm,max(six,weak),abs_tol=1e-13)
            if all(v==0. for v in offset):
                assert isclose(tau,5e-7*(1.+abs(factor)*max(map(abs,direction_eq[:56]))),abs_tol=1e-15)
            assert norm<=tau and max(map(abs,res[56:]))<=tau/modulus
            report.update({'lambda':factor,'norm_MPa':norm,'tolerance_MPa':tau,
                           'event_coordinate_MPa':trial_yield,'original_coordinate':control,
                           'old_G14_target':original['control'],'field_move':excursion,'previous_field_move':prior_move})
        reports.append(report)
    report={'status':'PASS','scope':'Four p31/-1 material coordinates at unchanged equilibrium tolerances',
            'exact_prefix':25,'new_equilibrium_probes':sum(item['solved'] for item in reports),'events':reports,
            'physical_limit_certified':False,'native_trace_sha256':native.file_hash(path),'proof':proof}
    raw=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode()
    output=folder/'Verification.json'
    if output.exists():
        assert output.read_bytes()==raw
    else:
        output.write_bytes(raw)
    print('HARDSHEAR G14 MATERIAL COORDINATE OFFLINE PASS',json.dumps(reports,ensure_ascii=False))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',action='store_true')
    parser.add_argument('--order',type=int,choices=(10,))
    args=parser.parse_args()
    staged=inputs()
    if args.inputs:
        print('HARDSHEAR G14 MATERIAL COORDINATE INPUTS: PASS')
    else:
        assert args.order==10
        verify(*staged)
