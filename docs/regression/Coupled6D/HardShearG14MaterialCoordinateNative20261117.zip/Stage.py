"""Stage a private G14 sweep using the existing material-event control."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ARCHIVE = REPO/'docs/regression/Coupled6D/HardShearG14DirectionNative20261117.zip'
ARCHIVE_SHA = '596609AD534F382BE6FD06FCCBBBCCCF42D24A66236C34364D52164376AFCD02'
SOLVER = 'src/Solver/CCoupledNewtonSolver.cls'
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
BASE_SHA = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'


def digest(raw):
    return sha256(raw).hexdigest().upper()


def source(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def exact(code, earlier, change):
    assert code.count(earlier)==1, earlier
    return code.replace(earlier,change)


def edit_solver(raw):
    code = source(raw)
    marker = 'Private mHardG14ArmedTest As Boolean, mHardG14CapturedTest As Boolean\n'
    code = exact(code,marker, marker + 'Private mHardG14RestartOriginTest() As Double, mHardG14RestartCorrectionTest() As Double\n'
                                     'Private mHardG14RestartLambdaTest As Double\n')
    marker = '        Optional ByVal toleranceSpec As Double = 0.0000005, Optional ByVal commitTrial As Boolean = True) As Boolean'
    code = exact(code,marker,marker.replace(') As Boolean',', _\n        Optional ByVal recoverGuide As Boolean = True) As Boolean'))
    code = exact(code,'        recoverSameControl:=Not replay, initialField:=seed)','        recoverSameControl:=(Not replay And recoverGuide), initialField:=seed)')
    marker = '    mHardG14ArmedTest = False: mHardG14CapturedTest = True\n'
    code = exact(code,marker,marker+'    mHardG14RestartOriginTest = field: mHardG14RestartCorrectionTest = correction\n'
                                   '    mHardG14RestartLambdaTest = lambda\n')
    marker = '    RunHardG14DirectionTest = "COMPLETE"\nEnd Function\n'
    code = exact(code,marker,'    If Not TryHardG14RestartBankTest(history, saved, g14, offset, direction, projection, started, probes) Then\n'
                             '        RunHardG14DirectionTest = "RESTART_REFUSED": Exit Function\n'
                             '    End If\n'+marker)
    code = code.rstrip()+'\n\n'+source((HERE/'Restart.bas').read_bytes()).rstrip()+'\n'
    assert max(map(len,code.splitlines()))<1024
    return code.replace('\n','\r\n').encode('utf-8')


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,required=True)
    args=cli.parse_args()
    root=args.destination.resolve()
    assert root.is_relative_to(HERE) or root.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert digest(ARCHIVE.read_bytes())==ARCHIVE_SHA
    with ZipFile(ARCHIVE) as saved:
        original=json.loads(saved.read('Fixture.json'))
        files={name:saved.read(name) for name in original['inputs']}
        assert all(digest(raw)==original['inputs'][name] for name,raw in files.items())
        files['Baseline.json']=saved.read('Fixture.json')
        files['Baseline/Verification.json']=saved.read('Native/Order10/Verification.json')
        files['Baseline/HardG14Direction.csv']=saved.read('Native/Order10/HardG14Direction.csv')
        files['DirectionVerify.py']=files['Verify.py']
    files[SOLVER]=edit_solver(files[SOLVER])
    for name in ('Stage.py','Restart.bas','Verify.py'):
        files[name]=(HERE/name).read_bytes()
    stock=(REPO/BOOK).read_bytes()
    assert digest(stock)==original['source_workbook_sha256']==BASE_SHA
    plan={**original,'direction_archive_sha256':ARCHIVE_SHA,'watchdog_seconds':140,
          'scope':'G14 four prescribed trial-yield coordinates on p31/-1; fixed accepted history and old physical tolerances',
          'inputs':{name:digest(raw) for name,raw in files.items()}}
    files.update({BOOK:stock,'docs/regression/Diagnostic.xlsm':stock,
                  'Fixture.json':(json.dumps(plan,indent=2)+'\n').encode()})
    root.mkdir()
    for name in ('Temp','Native/Order10'):
        (root/name).mkdir(parents=True)
    for name,raw in files.items():
        path=root/name
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as destination:
            destination.write(raw)
    print(root,digest(files['Fixture.json']))


if __name__=='__main__':
    main()
