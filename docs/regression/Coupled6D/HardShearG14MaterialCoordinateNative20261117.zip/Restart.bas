' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет физическое равновесие по обе стороны материальной координаты G14.
Private Function TryHardG14RestartBankTest(ByVal history As Collection, ByRef saved() As Double, _
        ByVal target As Double, ByRef offset() As Double, ByRef direction() As Double, ByRef projection() As Double, _
        ByVal started As Double, ByRef probes As Long) As Boolean
    Const TOLERANCE As Double = 0.0000005, END_FRACTION As Double = 0.0078125
    Dim origin() As Double, crossingEnd() As Double, correction() As Double, accepted() As Double, i As Long
    origin = mHardG14RestartOriginTest: correction = mHardG14RestartCorrectionTest
    accepted = history(25): crossingEnd = origin
    For i = 1 To mDegreeCount: crossingEnd(i) = origin(i) + END_FRACTION * correction(i): Next i
    Dim station As TYieldStation, spot As Variant, fraction As Double, anchor() As Double
    If Not ReadYieldCrossing(31, -1, origin, crossingEnd, station) Then Exit Function
    For Each spot In Array(-0.000000125, -0.00000005, 0.00000005, 0.000000125)
        If Timer - started > 85# Then Exit Function
        If Not LocateYieldCoordinate(station, origin, crossingEnd, CDbl(spot), fraction) Then Exit Function
        anchor = origin
        For i = 1 To mDegreeCount: anchor(i) = origin(i) + fraction * (crossingEnd(i) - origin(i)): Next i
        Dim lambda As Double, result() As Double, resultLambda As Double, eventProjection() As Double
        Dim solved As Boolean, load(1 To COMPONENT_COUNT) As Double, beforeEvaluations As Long
        lambda = mHardG14RestartLambdaTest + fraction * END_FRACTION * correction(mDegreeCount + 1)
        mControlActive = False: mIterations = 0: beforeEvaluations = mEvaluations
        solved = FollowYieldCoordinate(station, anchor, lambda, CDbl(spot), TOLERANCE, TOLERANCE, False, _
            result, resultLambda, eventProjection, 6)
        probes = probes + 1
        WriteHardRankRowTest "EVENT;" & HardRankBitsTest(CDbl(spot)) & ";" & HardRankBitsTest(fraction) & ";" & _
            HardRankBitsTest(lambda) & ";" & CStr(solved) & ";" & CStr(mIterations) & ";" & CStr(mEvaluations - beforeEvaluations)
        WriteHardRankRowTest "EVENT-SEED;" & HardRankVectorTest(anchor)
        If solved Then
            Dim strain(1 To COMPONENT_COUNT) As Double, gradient(1 To COMPONENT_COUNT) As Double
            Dim actualYield As Double, norm As Double, tau As Double, verified As Boolean, excursion As Double
            Dim limit As Double, earlier() As Double, response As CCoupledReinforcedResponse
            Set response = YieldResponse(-1)
            YieldStrain 31, -1, result, strain
            If Not response.TryReadTrialYield(31, strain, actualYield, gradient, False) Then Exit Function
            SetControlledLoad resultLambda, load
            If Not Evaluate(result, False, recordTrial:=False) Then Exit Function
            norm = EquilibriumNorm(load, result): tau = EquilibriumTolerance(TOLERANCE, TOLERANCE)
            verified = (norm <= tau And GaugesVerified(tau) And Abs(actualYield - CDbl(spot)) <= YIELD_ROOT_TOLERANCE)
            earlier = history(24): limit = 0#: excursion = 0#
            For i = 1 To mGaugeStart - 1
                limit = GeomMax(limit, Abs(accepted(i) - earlier(i)))
                excursion = GeomMax(excursion, Abs(result(i) - accepted(i)))
            Next i
            WriteHardRankRowTest "EVENT-BALANCE;" & HardRankBitsTest(resultLambda) & ";" & HardRankBitsTest(norm) & ";" & _
                HardRankBitsTest(tau) & ";" & HardRankBitsTest(actualYield) & ";" & _
                HardRankBitsTest(HardFineControlTest(projection, result)) & ";" & HardRankBitsTest(excursion) & ";" & _
                HardRankBitsTest(limit) & ";" & CStr(verified)
            WriteHardRankRowTest "EVENT-FIELD;" & HardRankVectorTest(result)
            WriteHardRankRowTest "EVENT-RESIDUAL;" & HardRankVectorTest(mResidual)
            WriteHardRankRowTest "EVENT-LOAD;" & HardRankVectorTest(load)
            WriteHardRankRowTest "EVENT-WRENCH;" & HardRankVectorTest(mTrialResultants)
        End If
        If Not HardG13HistoryAgreesTest(saved) Then Exit Function
        WriteHardRankRowTest "EVENT-ROLLBACK;" & CStr(UBound(saved))
    Next spot
    TryHardG14RestartBankTest = True
End Function
