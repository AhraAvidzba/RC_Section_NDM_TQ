"""ДЛЯ ТЕСТОВ. Меняет параметры сгущения при точно той же истории и неизменном скомпилированном VBA."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root, parent, scale, maximum):
    """Создаёт независимые буферы будущего запуска; исходные материалы, силы, допуски и общие 229 состояний сохраняет."""
    assert scale in (.125, .25, .5, 1.) and maximum in (16, 24, 32, 48, 64)
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    vector = run_path(str(here / 'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    contents = {'Input/HPathTestOptions.bin': vector([scale, 1., float(maximum)]),
                Path(__file__).name: Path(__file__).read_bytes()}
    for name, value in contents.items():
        (root / name).write_bytes(value)
        prep['inputs'][name] = sha256(value).hexdigest().upper()
    assert (root / 'Input/Reverse1.bin').read_bytes() == (parent / 'Input/Reverse1.bin').read_bytes()
    prep['directed_scope'].update(case='WorkingHStepRefinementImmutableReuse', actual_import_this_pass=[],
        fresh_compilation_claimed=False, source_classes_unchanged=True, original_checkpoint637_core=True,
        initial_H_step_scale=scale, successful_H_step_growth=1., maximum_new_H_states=maximum,
        maximum_H_failures_at_revision=4, shared_history_binary_exact=True, mutable_material_state_reused=False,
        original_force_and_material_criteria=True, controller_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, sort_keys=True, indent=2) + '\n').encode())
    print('REFINEMENT INPUTS READY; SAME EXACT HISTORY; SCALE', scale, '; LIMIT', maximum, '; NO CODE IMPORT')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    parser.add_argument('--scale', type=float, default=.125)
    parser.add_argument('--maximum', type=int, default=48)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve(), args.scale, args.maximum)
