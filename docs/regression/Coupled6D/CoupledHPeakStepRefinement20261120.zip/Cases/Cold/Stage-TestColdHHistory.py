"""ДЛЯ ТЕСТОВ. Холодно воспроизводит полностью сохранённую принятую историю после watchdog без поиска новых равновесий."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import numpy as np


def TestStage(root, parent, snapshot):
    """Сохраняет факт незавершённого опыта; повтор проверяет только фактически принятые состояния из точного снимка."""
    here = Path(__file__).resolve().parent
    read = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original, current = read(parent / 'Input/Reverse1.bin'), read(snapshot)
    for key in ('calibration', 'options', 'offset', 'direction'):
        assert np.array_equal(original[key], current[key]), key
    for key in ('fields', 'lambdas', 'fractions'):
        assert np.array_equal(original[key], current[key][:len(original['fields'])]), key
    closure = json.loads((parent / 'Native/TimeoutClosure.json').read_bytes())
    assert closure['after']['state'] in ('Exited', 'Absent', 'Replaced')
    assert closure['original_source_workbook_unchanged'] and not closure['other_process_terminated']
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = '''Private Sub TestIntegratedYieldEvent()
    Dim report As Integer: report = FreeFile
    Open mPolishRootTest & "\\Native\\IntegratedEvent.csv" For Output As #report
    Print #report, "MODE;ColdAcceptedHHistoryOnly;NoNewEquilibriumSearch;NotCapacity"
    Print #report, "END;AcceptedHistoryExportedByBootstrap"
    Close #report
    mPolishExecutedTest = True
End Sub'''
    pattern = r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub'
    match = re.search(pattern, code)
    prefix = code[:match.start()].splitlines(keepends=True)
    while prefix and (not prefix[-1].strip() or prefix[-1].lstrip().startswith("'")):
        prefix.pop()
    header = "\n\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Сохраняет окончание холодного повтора точной принятой истории; нового решения и нового предела не ищет.\n"
    code = ''.join(prefix) + header + body + code[match.end():]
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    contents = {'Input/Reverse1.bin': snapshot.read_bytes(),
                'Input/ParentTimeout.json': (parent / 'Native/ExternalTimeout.json').read_bytes(),
                'Input/ParentTimeoutClosure.json': (parent / 'Native/TimeoutClosure.json').read_bytes(),
                'Input/ColdHistoryOrigin.json': (json.dumps(dict(snapshot=str(snapshot), sha256=current['sha256'],
                    accepted_states=len(current['fields']), shared_prefix_states=len(original['fields']),
                    original_parent_run_completed=False), sort_keys=True, indent=2) + '\n').encode(),
                Path(__file__).name: Path(__file__).read_bytes()}
    for name, value in contents.items():
        (root / name).write_bytes(value)
        prep['inputs'][name] = sha256(value).hexdigest().upper()
    prep['directed_scope'].update(case='ColdAcceptedHHistoryVerification', actual_import_this_pass=['modTestCoupledElasticState'],
        fresh_compilation_claimed=True, source_classes_unchanged=True, original_checkpoint637_core=True,
        current_input_states=len(current['fields']), no_new_equilibrium_search=True, parent_watchdog_not_hidden=True,
        original_parent_run_completed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('COLD HISTORY VERIFICATION READY;', len(current['fields']), 'EXACT ACCEPTED STATES; PARENT TIMEOUT PRESERVED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    for name in ('root', 'parent', 'snapshot'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve(), args.snapshot.resolve())
