"""Сохраняет фактическую отклонённую поправку в пробе 14 механической дуги."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
BASE=REPO/'docs/regression/Coupled6D/HardShearG13SerialArcExtendedNative20261117.zip'
BASE_SHA='FDE5A92997868C7708EE8E5C6767DAB362C48BC7258C0F64316D5D86C8FA46F6'
REPORT='BD3549286ED22226484C942513DFA52D1B5BD3B9145B69C2D8317168B94D8AAD'
BOOK='245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def once(src,a,b):
    assert src.count(a)==1,a
    return src.replace(a,b)


def seal(dest,name,raw):
    out=dest/name
    out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():
        assert out.read_bytes()==raw,name
    else:
        out.write_bytes(raw)
    return sha(raw)


def block(src,name,ending):
    declaration=src.index('Private Sub '+name+'(')
    start=src.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,declaration)
    end=src.index('\n'+ending,declaration)+len('\n'+ending)
    return src[start:end]


def inspect_support(source):
    capture=block(source,'CaptureHardG14DirectionTest','End Sub')
    capture=capture.replace('CaptureHardG14DirectionTest','ReadHardArc56DirectionTest')
    capture=once(capture,'    mHardG14ArmedTest = False: mHardG14CapturedTest = True\n'
                         '    mHardG14RestartOriginTest = field: mHardG14RestartCorrectionTest = correction\n'
                         '    mHardG14RestartLambdaTest = lambda\n','')
    capture=capture.replace('WriteHardRankRowTest','WriteHardArc56RowTest')
    capture=capture.replace('WriteHardG14MatrixTest','WriteHardArc56MatrixTest').replace('ReadHardG14SampleTest','ReadHardArc56SampleTest')
    capture=once(capture,'    WriteHardArc56MatrixTest "STOCK"\n',
                 '    WriteHardArc56MatrixTest "STOCK"\n'
                 '    Dim point As Long, x As Double, y As Double, area As Double\n'
                 '    For point = 1 To mPointCount\n'
                 '        mSection.Point point, x, y, area\n'
                 '        WriteHardArc56RowTest "LOCATION;" & CStr(point) & ";" & HardRankBitsTest(x) & ";" & _\n'
                 '            HardRankBitsTest(y) & ";" & HardRankBitsTest(area)\n    Next point\n')
    matrix=block(source,'WriteHardG14MatrixTest','End Sub').replace('WriteHardG14MatrixTest','WriteHardArc56MatrixTest')
    matrix=matrix.replace('WriteHardRankRowTest','WriteHardArc56RowTest')
    station=block(source,'RecordHardG13StationsTest','End Sub').replace('RecordHardG13StationsTest','RecordHardArc56StationsTest')
    station=station.replace('WriteHardRankRowTest','WriteHardArc56RowTest')
    sample=block(source,'ReadHardG14SampleTest','End Sub').replace('ReadHardG14SampleTest','ReadHardArc56SampleTest')
    sample=sample.replace('WriteHardRankRowTest','WriteHardArc56RowTest').replace('RecordHardG13StationsTest','RecordHardArc56StationsTest')
    sample=once(sample,'    ReDim mHardG14PartsTest(1 To mPointCount, 1 To 4)\n'
                       '    succeeded = Evaluate(field, False, recordTrial:=False)\n    mHardG14RowTest = 0\n',
                '    ReDim mHardG14PartsTest(1 To mPointCount, 1 To 8)\n'
                '    mHardArc56ReadingTest = True\n    succeeded = Evaluate(field, False, recordTrial:=False)\n'
                '    mHardG14RowTest = 0: mHardArc56ReadingTest = False\n')
    sample=once(sample,'Dim values(1 To 4) As Double','Dim values(1 To 8) As Double')
    sample=once(sample,'For i = 1 To 4: values(i) = mHardG14PartsTest(point, i): Next i',
                'For i = 1 To 8: values(i) = mHardG14PartsTest(point, i): Next i')
    return '\n\n'.join((capture,matrix,station,sample))


def solver(raw):
    source=text(raw)
    helper=text((HERE/'Hooks.bas').read_bytes()); helper.encode('cp1251')
    additions=inspect_support(source)+'\n\n'+helper
    marker='Private mHardG14RowTest As Long, mHardG14PartsTest() As Double, mHardG14InitialRowTest As Double\n'
    source=once(source,marker,marker+'Private mHardArc56ArmedTest As Boolean, mHardArc56ReadingTest As Boolean\n')
    marker='                If mHardG14ArmedTest Then\n'
    source=once(source,marker,'''                If mHardArc56ArmedTest Then
                    CaptureHardArc56Test current, currentLambda, correction, governingRow, baseEquation, _
                        trialEquation, trialFraction, norm, tolerance
                    Exit Function
                End If
'''+marker)
    marker='                If TrySmallStrainEquilibrium(current, currentLambda, load, norm, tolerance, _\n'
    source=once(source,marker,'                If mHardArc56ArmedTest Then WriteHardArc56RowTest "SMALL;ENTER;" & _\n'
                '                    HardRankBitsTest(norm) & ";" & HardRankBitsTest(tolerance)\n'+marker)
    small=source.index('Private Function TrySmallStrainEquilibrium(')
    end_small=source.index('\nEnd Function',small)
    method=source[small:end_small]
    method=once(method,'    If Not Evaluate(field, True, recordTrial:=False, refinedBranch:=True) Then Exit Function\n',
                '    If Not Evaluate(field, True, recordTrial:=False, refinedBranch:=True) Then\n'
                '        If mHardArc56ArmedTest Then WriteHardArc56RowTest "SMALL;REFINED_ASSEMBLY_REFUSED"\n'
                '        Exit Function\n    End If\n')
    method=once(method,'    If Not BuildSmallStrainSystem(field, load, tolerance, force, forceResidual, equality, equalityResidual, scales) Then Exit Function\n',
                '    If Not BuildSmallStrainSystem(field, load, tolerance, force, forceResidual, equality, equalityResidual, scales) Then\n'
                '        If mHardArc56ArmedTest Then WriteHardArc56RowTest "SMALL;SYSTEM_REFUSED"\n        Exit Function\n    End If\n')
    method=once(method,'            radius, SMALL_STRAIN_FORCE_FRACTION * tolerance, correction) Then Exit Function\n',
                '            radius, SMALL_STRAIN_FORCE_FRACTION * tolerance, correction) Then\n'
                '        If mHardArc56ArmedTest Then WriteHardArc56RowTest "SMALL;OPTIMIZER_REFUSED"\n        Exit Function\n    End If\n'
                '    If mHardArc56ArmedTest Then WriteHardArc56RowTest "SMALL;CHECKING_DAMPED_CANDIDATES"\n')
    method=once(method,'    Loop\n    Exit Function\n\nUnavailableCorrection:',
                '    Loop\n    If mHardArc56ArmedTest Then WriteHardArc56RowTest "SMALL;NO_DAMPED_EQUILIBRIUM"\n'
                '    Exit Function\nUnavailableCorrection:\n    If mHardArc56ArmedTest Then WriteHardArc56RowTest "SMALL;HANDLER_EXIT"')
    source=source[:small]+method+source[end_small:]
    marker='                mHardG14PartsTest(point, 4) = mPlusStress(3)\n'
    source=once(source,marker,marker+'''                If mHardArc56ReadingTest Then
                    mHardG14PartsTest(point, 5) = mMinusStress(5): mHardG14PartsTest(point, 6) = mMinusStress(6)
                    mHardG14PartsTest(point, 7) = mPlusStress(5): mHardG14PartsTest(point, 8) = mPlusStress(6)
                End If
''')
    marker='    seed = predicted\n    solved = TryDeformationStep(offset, direction, projection, target, estimate, lambda, TOLERANCE, TOLERANCE, _\n'
    source=once(source,marker,'    seed = predicted\n    mHardArc56ArmedTest = (attempt = 14)\n'
                '    solved = TryDeformationStep(offset, direction, projection, target, estimate, lambda, TOLERANCE, TOLERANCE, _\n')
    source=once(source,'        MAX_ITER, consistentControl:=True, initialField:=seed)\n    WriteHardRankRowTest "TRACE-TRY;"',
                '        MAX_ITER, consistentControl:=True, initialField:=seed)\n    mHardArc56ArmedTest = False\n'
                '    WriteHardRankRowTest "TRACE-TRY;"')
    output=source.rstrip()+'\n\n'+additions.rstrip()+'\n'
    assert max(map(len,output.splitlines()))<1024
    return output.replace('\n','\r\n').encode('utf-8')


def verifier(raw):
    source=text(raw)
    source=once(source,'import ExtendedProof as extra\n','import ExtendedProof as extra\nimport Arc56Proof as row56\n')
    source=once(source,'    extra.inputs(fixture, extract)\n','    extra.inputs(fixture, extract)\n    row56.inputs(fixture, extract)\n')
    source=once(source,"    for line in path.read_text(encoding='cp1251').splitlines():\n",
                "    for line in path.read_text(encoding='cp1251').splitlines():\n        if line.startswith('ARC56-'):\n            continue\n")
    source=once(source,"    output=folder/'Verification.json'\n",
                "    result['attempt14_direction']=row56.verify(fixture, extract, path, records, geometry, weights, steps)\n"
                "    output=folder/'Verification.json'\n")
    return source.encode('utf-8')


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready')
    cli.add_argument('--with-workbook',action='store_true')
    args=cli.parse_args()
    dest=args.destination.resolve()
    assert dest.is_relative_to(HERE) or dest.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(BASE.read_bytes())==BASE_SHA
    files={}
    with ZipFile(BASE) as archive:
        frozen=json.loads(archive.read('Fixture.json'))
        book=(REPO/frozen['workbook']).read_bytes()
        assert sha(book)==frozen['source_workbook_sha256']==BOOK
        report=archive.read('Native/Order10/Verification.json')
        trace=archive.read('Native/Order10/HardG14Direction.csv')
        assert sha(report)==REPORT and json.loads(report)['native_trace_sha256']==sha(trace)
        for path,raw in (('ExtendedPrior/Verification.json',report),('ExtendedPrior/HardG14Direction.csv',trace)):
            files[path]=seal(dest,path,raw)
        original_verifier=archive.read('DirectionVerify.py')
        baseline=text(original_verifier)
        baseline=once(baseline,'    assert base_norm>2.*tolerance\n','    assert base_norm>tolerance\n')
        files['ProbeVerify.py']=seal(dest,'ProbeVerify.py',baseline.encode('utf-8'))
        for path,digest in frozen['inputs'].items():
            raw=archive.read(path)
            assert sha(raw)==digest,path
            if path=='Stage.py':
                continue
            if path==SOLVER:
                raw=solver(raw)
            elif path=='Verify.py':
                raw=verifier(raw)
            elif path=='Run.ps1':
                raw=text(raw).replace('HardSerialLong','HardArc56').encode('utf-8')
            files[path]=seal(dest,path,raw)
    for path in ('Hooks.bas','Stage.py','Arc56Proof.py'):
        files[path]=seal(dest,path,(HERE/path).read_bytes())
    if args.with_workbook:
        seal(dest,frozen['workbook'],book)
        seal(dest,'docs/regression/Diagnostic.xlsm',book)
        for path in ('Native/Order10','Temp'):
            (dest/path).mkdir(parents=True,exist_ok=True)
    manifest={**frozen,'inputs':files,'watchdog_seconds':175,'extended_source_archive_sha256':BASE_SHA,
              'extended_source_report_sha256':REPORT,'scope':'one exact attempt14 raw direction and torsion-gradient station contributions'}
    print(dest,seal(dest,'Fixture.json',(json.dumps(manifest,indent=2)+'\n').encode('utf-8')))


if __name__=='__main__':
    main()
