"""Вычисляет знаковое отклонение вклада каждой станции в уравнение 56."""

from math import fsum, isclose

import Arc56Proof as row56
import PriorVerify as prior
import Verify


def verify(path):
    (raw, _, _, _), _, _, _, _, _ = Verify.extract(path)
    area, length, _ = prior.numbers(raw[0]['MESH'][-3:])
    points, _, _, _, _, samples = row56.raw_diagnostics(path)
    stock = {sample['h']:sample for sample in samples if sample['arm']=='STOCK'}
    zero, low, high, far = [stock[h] for h in (0.,-1/8192,1/8192,1/128)]
    assert set(points) == set(range(1,119))
    assert all(zero['stations'][k][1:]==sample['stations'][k][1:]
               for sample in (low,high) for k in zero['stations'])
    switched = {(p,s) for p,s in zero['stations'] if zero['stations'][p,s][1:]!=far['stations'][p,s][1:]}
    assert switched == {(31,-1)} | {(p,s) for p in (60,70,80) for s in (-1,0,1)}
    flags = []
    for point,side in sorted(switched):
        start,end = [sample['stations'][point,side] for sample in (zero,far)]
        assert start[1:]==(True,1,1) and end[1:]==(False,1,1) and start[0]>0>end[0]
        flags.append(dict(point=point,side=side,F_start_MPa=start[0],F_end_MPa=end[0],
                          plastic=[True,False],principal=[1,1],substeps=[1,1]))

    def departure(minus,base,plus,end):
        return 128*(end-base)-4096*(plus-minus)

    parts = {}
    for point,(x,y,weight) in points.items():
        multiplier = weight/(area*length*.002)
        values = []
        for sample in (low,zero,high,far):
            *_,txm,tym,txp,typ=sample['points'][point]
            values.append((multiplier*(y*txm-x*tym),multiplier*(-y*txp+x*typ)))
        parts[point]=[departure(*v) for v in zip(*values,strict=True)]
    seq=(low,zero,high,far)
    actual=departure(*(prior.number(r['DIR-RESIDUAL'][55]) for r in seq))
    affine=departure(*(prior.number(r['DIR-AFFINE'][0]) for r in seq))
    subtotal=fsum(v for values in parts.values() for v in values)
    assert isclose(subtotal+affine,actual,rel_tol=0.,abs_tol=9e-11)
    assert isclose(actual,4.928623455762e-6,rel_tol=2e-8)
    by_group={}
    for point in (31,60,70,80):
        a,b=parts[point]
        by_group[point]=dict(minus_MPa=a,plus_MPa=b,total_MPa=fsum((a,b)),
                             percent_of_measured_departure=100*fsum((a,b))/actual)
    return dict(
        measured_directional_departure_MPa=actual,station_sum_MPa=subtotal,
        affine_departure_MPa=affine,closure_difference_MPa=subtotal+affine-actual,
        flag_transitions=flags,largest_point_departures=by_group,
        h_for_local_central_slope=1/8192,h_for_crossing_secant=1/128,
    )
