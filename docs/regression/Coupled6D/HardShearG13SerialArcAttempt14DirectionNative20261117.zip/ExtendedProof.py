"""Сверяет десятичные выводы только после точного повтора ранее принятых восьми шагов."""

from pathlib import Path

import PriorVerify as native


HERE=Path(__file__).resolve().parent
REPORT='2B3AB8E51A91E540042DAC6483F6E02BE88723B09B0BB89F450DDDDC43E03ECF'
ANCHOR='48E5B874F9BDC62B87EC9AC3240C295674FE23C6C81D7F9E45FA36F9E1D7838D'


def inputs(fixture,extract):
    path=HERE/'SerialPrior/Verification.json'
    trace=HERE/'SerialPrior/HardG14Direction.csv'
    assert native.file_hash(path)==fixture['serial_reference_report_sha256']==REPORT
    receipt=native.read(path)
    assert receipt['status']=='PASS' and receipt['accepted_count']==8 and receipt['terminal']=='STEP_LIMIT'
    assert receipt['native_trace_sha256']==native.file_hash(trace)
    _,weights,op,steps,budget,final=extract(trace)
    assert len(weights)==118 and len(op)==118*9 and budget[:2]==['8','16']
    assert len(steps)==8 and final==['STEP_LIMIT','8','9744']
    assert all(row['TRACE-DECISION']==['ACCEPTED'] for row in steps)
    assert native.file_hash(HERE/'Anchor/Verification.json')==ANCHOR


def require_bit_identical_prefix(extract,weights,operator,steps,budget):
    _,old_weights,old_operator,old_steps,old_budget,_=extract(HERE/'SerialPrior/HardG14Direction.csv')
    assert weights==old_weights and operator==old_operator and budget[2:]==old_budget[2:]
    assert len(steps)>=len(old_steps) and steps[:len(old_steps)]==old_steps
    return len(old_steps)


def summarize(prefix_size,accepted,initial_lambda,initial_xz,old_g14):
    anchor=native.read(HERE/'Anchor/Verification.json')['max_confirmed']
    assert anchor['label']=='G13' and anchor['factor']==initial_lambda and anchor['coordinate']==initial_xz
    reference=anchor['uncertainty']
    def interval(row):
        difference=row['lambda']-initial_lambda
        uncertainty=reference+row['lambda_uncertainty']
        return [difference-uncertainty,difference+uncertainty]

    maximum=max(accepted,key=lambda row:row['lambda'])
    farthest=max(accepted,key=lambda row:row['xz'])
    crossed=next((row for row in accepted if row['xz']>=old_g14),None)
    rise=next((row for row in accepted if interval(row)[0]>0.),None)
    slopes=[]
    previous={'attempt':0,'lambda':initial_lambda,'lambda_uncertainty':reference,'xz':initial_xz}
    for current in accepted:
        delta=current['lambda']-previous['lambda']
        allowance=current['lambda_uncertainty']+previous['lambda_uncertainty']
        slopes.append({'from_attempt':previous['attempt'],'to_attempt':current['attempt'],
                       'increasing_xz':current['xz']>previous['xz'],'delta_lambda_interval':[delta-allowance,delta+allowance]})
        previous=current
    return {'previous_eight_steps_bit_identical':prefix_size,'additional_accepted_count':len(accepted)-prefix_size,
            'maximum_confirmed_sample':maximum,'highest_lambda_delta_from_G13_interval':interval(maximum),
            'farthest_old_xz_sample':farthest,'xz_still_needed_to_old_G14':old_g14-farthest['xz'],
            'first_xz_at_or_beyond_old_G14':crossed,'first_certified_signed_lambda_rise_from_G13':rise,
            'adjacent_signed_lambda_intervals':slopes}
