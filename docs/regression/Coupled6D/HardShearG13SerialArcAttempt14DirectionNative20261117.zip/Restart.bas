' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продолжает принятую историю по касательной к последней физической секущей.
' После серии возвращает исходные 25 полей и сверяет все буферы материалов.
Private Function TraceHardG13ArcTest(ByVal history As Collection, ByRef saved() As Double, ByRef factors() As Double, _
        ByRef offset() As Double, ByRef direction() As Double, ByRef originalProjection() As Double, _
        ByVal started As Double, ByRef probes As Long) As Boolean
    Const MAX_STEPS As Long = 32, MAX_ATTEMPTS As Long = 64
    Dim prior() As Double, current() As Double, lambdaPrior As Double, lambda As Double
    Dim coefficients() As Double, projection() As Double, movement() As Double, i As Long
    Dim length As Double, trialLength As Double, minLength As Double, requested As Double, seedScale As Double
    Dim attempt As Long, accepted As Long, trialLambda As Double, candidate() As Double, outcome As String
    prior = history(24): current = history(25): lambdaPrior = factors(24): lambda = factors(25)
    movement = current
    mSection.CopySpatialStrainCoefficients SPATIAL_HALF_STEP, coefficients
    For i = 1 To mGaugeStart - 1: movement(i) = current(i) - prior(i): Next i
    length = Sqr(ArcPhysicalSquare(coefficients, movement, projection, True))
    requested = 0.25 * length: trialLength = 0.125 * length: minLength = length / 32#
    WriteHardRankRowTest "TRACE-BUDGET;" & CStr(MAX_STEPS) & ";" & CStr(MAX_ATTEMPTS) & ";" & _
        HardRankBitsTest(requested) & ";" & HardRankBitsTest(trialLength) & ";" & HardRankBitsTest(minLength)
    WriteHardG13TraceOperatorTest coefficients
    outcome = "ATTEMPT_LIMIT"
    For attempt = 1 To MAX_ATTEMPTS
        If Timer - started > 210# Then outcome = "TIME_LIMIT": Exit For
        If requested < minLength Then outcome = "MINIMUM_RADIUS": Exit For
        For i = 1 To mGaugeStart - 1: movement(i) = current(i) - prior(i): Next i
        length = Sqr(ArcPhysicalSquare(coefficients, movement, projection, True))
        If length <= 0# Then outcome = "NO_SECANT": Exit For
        For i = 1 To mGaugeStart - 1: projection(i) = projection(i) / length: Next i
        seedScale = requested / length
        probes = probes + 1
        If TryHardG13TraceStepTest(attempt, accepted + 1, projection, current, movement, coefficients, originalProjection, _
                requested, seedScale, lambda, lambda + seedScale * (lambda - lambdaPrior), offset, direction, candidate, trialLambda) Then
            accepted = accepted + 1
            prior = current: current = candidate: lambdaPrior = lambda: lambda = trialLambda
            requested = trialLength
            If accepted = MAX_STEPS Then outcome = "STEP_LIMIT": Exit For
        Else
            requested = requested * 0.5
        End If
    Next attempt
    If Not ReplayAcceptedFields(history, 25) Then Exit Function
    If Not HardG13HistoryAgreesTest(saved) Then Exit Function
    WriteHardRankRowTest "TRACE-FINISH;" & outcome & ";" & CStr(accepted) & ";" & CStr(UBound(saved))
    TraceHardG13ArcTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт квадратурные веса и разреженный оператор деформаций для независимого контроля.
Private Sub WriteHardG13TraceOperatorTest(ByRef coefficients() As Double)
    Dim point As Long, row As Long, i As Long, x As Double, y As Double, area As Double, record As String
    For point = 1 To mPointCount
        mSection.Point point, x, y, area
        WriteHardRankRowTest "TRACE-AREA;" & CStr(point) & ";" & HardRankBitsTest(area)
        For row = 1 To 9
            record = "TRACE-OP;" & CStr(point) & ";" & CStr(row)
            For i = 1 To mGaugeStart - 1
                If coefficients(i, 9 * (point - 1) + row) <> 0# Then _
                    record = record & ";" & CStr(i) & "=" & HardRankBitsTest(coefficients(i, 9 * (point - 1) + row))
            Next i
            WriteHardRankRowTest record
        Next row
    Next point
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Принимает только локальную точку с полным равновесием и прежними пределами стали.
Private Function TryHardG13TraceStepTest(ByVal attempt As Long, ByVal stepIndex As Long, ByRef projection() As Double, _
        ByRef base() As Double, ByRef movement() As Double, ByRef coefficients() As Double, ByRef originalProjection() As Double, _
        ByVal travel As Double, ByVal scaleFactor As Double, ByVal previousLambda As Double, ByVal estimate As Double, _
        ByRef offset() As Double, ByRef direction() As Double, ByRef field() As Double, ByRef lambda As Double) As Boolean
    Const TOLERANCE As Double = 0.0000005, MAX_ITER As Long = 12
    Dim target As Double, predicted() As Double, seed As Variant, i As Long, solved As Boolean
    predicted = base: target = travel
    For i = 1 To mGaugeStart - 1
        target = target + projection(i) * base(i)
        predicted(i) = base(i) + scaleFactor * movement(i)
    Next i
    seed = predicted
    solved = TryDeformationStep(offset, direction, projection, target, estimate, lambda, TOLERANCE, TOLERANCE, _
        MAX_ITER, consistentControl:=True, initialField:=seed)
    WriteHardRankRowTest "TRACE-TRY;" & CStr(attempt) & ";" & CStr(stepIndex) & ";" & HardRankBitsTest(travel) & ";" & _
        HardRankBitsTest(target) & ";" & HardRankBitsTest(scaleFactor) & ";" & HardRankBitsTest(previousLambda) & ";" & _
        HardRankBitsTest(estimate) & ";" & CStr(solved) & ";" & CStr(mIterations) & ";" & CStr(mEvaluations)
    WriteHardRankRowTest "TRACE-PROJECTION;" & HardRankVectorTest(projection)
    WriteHardRankRowTest "TRACE-SEED;" & HardRankVectorTest(predicted)
    If Not solved Then
        WriteHardRankRowTest "TRACE-DECISION;REFUSED;" & Replace(mMeta.DiagnosticDetails, ";", "|")
        Exit Function
    End If
    Dim load(1 To COMPONENT_COUNT) As Double, wrench() As Double, delta() As Double, unused() As Double
    Dim norm As Double, tau As Double, advance As Double, distance As Double, steel As Double, controlError As Double
    Dim response As CCoupledReinforcedResponse, side As Long, bound As Double, bounded As Boolean, balanceOk As Boolean
    CopyTrial field, wrench
    delta = field
    For i = 1 To mGaugeStart - 1
        delta(i) = field(i) - base(i): advance = advance + projection(i) * delta(i)
    Next i
    distance = Sqr(ArcPhysicalSquare(coefficients, delta, unused))
    For i = 1 To COMPONENT_COUNT: load(i) = offset(i) + lambda * direction(i): Next i
    norm = EquilibriumNorm(load, field): tau = EquilibriumTolerance(TOLERANCE, TOLERANCE): controlError = ControlResidual(field)
    For side = -1 To 1
        Set response = YieldResponse(side)
        steel = GeomMax(steel, response.TrialSteelUtilization)
    Next side
    balanceOk = (lambda > 0# And norm <= tau And GaugesVerified(tau) And steel <= 1# And advance > 0# And _
        Abs(advance - travel) <= 0.125 * travel And distance <= 3# * travel)
    WriteHardRankRowTest "TRACE-BALANCE;" & HardRankBitsTest(lambda) & ";" & HardRankBitsTest(norm) & ";" & HardRankBitsTest(tau) & ";" & _
        HardRankBitsTest(advance) & ";" & HardRankBitsTest(distance) & ";" & HardRankBitsTest(steel) & ";" & _
        HardRankBitsTest(controlError) & ";" & HardRankBitsTest(HardFineControlTest(originalProjection, field)) & ";" & CStr(balanceOk)
    WriteHardRankRowTest "TRACE-FIELD;" & HardRankVectorTest(field)
    WriteHardRankRowTest "TRACE-RESIDUAL;" & HardRankVectorTest(mResidual)
    WriteHardRankRowTest "TRACE-LOAD;" & HardRankVectorTest(load)
    WriteHardRankRowTest "TRACE-WRENCH;" & HardRankVectorTest(wrench)
    If Not balanceOk Then
        DiscardStep
        WriteHardRankRowTest "TRACE-DECISION;LOCALITY_OR_BALANCE"
        Exit Function
    End If
    bounded = TrialLambdaUncertainty(TOLERANCE, TOLERANCE, bound)
    WriteHardRankRowTest "TRACE-BOUND;" & CStr(bounded) & ";" & HardRankBitsTest(bound)
    If Not bounded Or Not mCandidateReady Then
        DiscardStep
        WriteHardRankRowTest "TRACE-DECISION;BOUND_UNAVAILABLE"
        Exit Function
    End If
    AcceptStep
    Dim acceptedField() As Double: CopyAccepted acceptedField
    WriteHardRankRowTest "TRACE-DECISION;ACCEPTED"
    WriteHardRankRowTest "TRACE-COMMIT;" & HardRankVectorTest(acceptedField)
    TryHardG13TraceStepTest = True
End Function
