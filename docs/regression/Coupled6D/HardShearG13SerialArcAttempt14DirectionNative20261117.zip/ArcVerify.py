"""Rebuild the native strain metrics and check every prospect against the preserved history."""

from argparse import ArgumentParser
import json
from math import fsum, isclose, sqrt
from pathlib import Path
from statistics import median

import DirectionVerify as reference
import PriorVerify as native


HERE=Path(__file__).resolve().parent
RADII=(-.5,.125,.25,.5)


def inputs():
    fixture,expected,original=reference.inputs()
    receipt=native.read(HERE/'Baseline/Verification.json')
    path=HERE/'Baseline/HardG14Direction.csv'
    assert receipt['native_trace_sha256']==native.file_hash(path) and receipt['exact_prefix']==25
    return fixture,expected,original,path


def metric_value(weights,operator,movement):
    total=[]
    for point,area in weights.items():
        strain=[fsum(movement[index]*b for index,b in operator[point,row].items()) for row in range(1,10)]
        variable=[]
        for pos,w in ((3,1.),(5,.5),(7,.5)):
            left,right=strain[pos:pos+2]
            variable.append(w*(left*left+right*right+((left+right)/2.)**2))
        total.append(area*(3.*(strain[0]**2+strain[1]**2+.5*strain[2]**2)+fsum(variable)))
    return fsum(total)/(3.*fsum(weights.values()))


def norm_equations(load,wrench,residual,control,scales):
    return max(max(abs(a-b)/s for a,b,s in zip(load,wrench,scales,strict=True)),max(map(abs,residual[:56])),abs(control))


def extract(path):
    weights={}
    operator={}
    projections={}
    measures=None
    arcs=[]
    trace=[]
    for line in path.read_text(encoding='cp1251').splitlines():
        key,*parts=line.split(';')
        if key=='ARC-AREA':
            assert int(parts[0]) not in weights
            weights[int(parts[0])]=native.number(parts[1])
        elif key=='ARC-OP':
            label=(int(parts[0]),int(parts[1]))
            values=[member.split('=') for member in parts[2:]]
            assert label not in operator and len({i for i,_ in values})==len(values)
            operator[label]={int(i)-1:native.number(value) for i,value in values}
        elif key=='ARC-METRIC':
            assert measures is None
            measures=native.numbers(parts)
        elif key=='ARC-PROJECTION':
            assert parts[0] not in projections
            projections[parts[0]]=native.numbers(parts[1:])
        elif key=='ARC-TRY':
            arcs.append({'args':parts})
        elif key.startswith('ARC-'):
            assert arcs and key not in arcs[-1]
            arcs[-1][key]=parts
        else:
            trace.append(line)
    return reference.read_probe(reference.TextTrace(trace)),weights,operator,projections,measures,arcs


def verify(fixture,expected,original,baseline_path):
    folder=HERE/'Native/Order10'
    proof=native.native_proof(fixture,folder)
    path=folder/'HardG14Direction.csv'
    earlier,old_tags,old_matrices,old_samples=reference.read_probe(baseline_path)
    (raw,tags,matrices,samples),weights,operator,projections,measures,arcs=extract(path)
    geometry,points,_,_,_,records=raw
    assert geometry['FINISH']==['COMPLETE','25','9']
    assert list(raw[1:])==list(earlier[1:])
    assert tags==old_tags and matrices==old_matrices and samples==old_samples
    assert {name:geometry[name] for name in expected['geometry']}==expected['geometry']
    area,length,modulus,_=native.verify_geometry(fixture,10,geometry,points)
    assert sorted(weights)==list(range(1,119)) and all(value>0 for value in weights.values())
    assert set(operator)=={(point,row) for point in weights for row in range(1,10)}
    assert all(0<=i<56 for entries in operator.values() for i in entries)
    assert set(projections)=={'FIELD','LOAD'} and all(len(value)==60 and not any(value[56:]) for value in projections.values())
    scales=(area, area*length, area*length, area*length, area, area)
    direction,offset,initial=(native.numbers(geometry[name]) for name in ('DIRECTION','OFFSET','PROJECTION'))
    controls=[native.number(row['CONTROL'][0]) for row in records[21:25]]
    fields=[native.numbers(row['FIELD']) for row in records[21:25]]
    factors=[native.number(row['BALANCE'][0]) for row in records[21:25]]
    moves=[[b-a for a,b in zip(f0,f1,strict=True)] for f0,f1 in zip(fields[:-1],fields[1:],strict=True)]
    factor_moves=[b-a for a,b in zip(factors[:-1],factors[1:],strict=True)]
    norms=[sqrt(metric_value(weights,operator,d)) for d in moves]
    weight_metric,stock_radius,field_length,load_length,load_weight=measures
    assert isclose(weight_metric,median(v/dl for v,dl in zip(norms,factor_moves,strict=True))**2,rel_tol=3e-11)
    assert isclose(field_length,norms[-1],rel_tol=5e-12)
    assert isclose(load_length,sqrt(field_length**2+weight_metric*factor_moves[-1]**2),rel_tol=5e-12)
    assert isclose(load_weight,weight_metric*factor_moves[-1]/load_length,rel_tol=5e-12)
    stock=0.5*min(1.,(original['control']-controls[-1])/(controls[-1]-controls[-2]))*load_length
    assert isclose(stock_radius,stock,rel_tol=1e-5)
    baseline=fields[-1]
    final=factors[-1]
    move=moves[-1]
    load_dir=native.numbers(tags['DIRECTION-EQ'])
    details=[]
    schedule=[(mode,ratio) for mode in ('FIELD','LOAD') for ratio in RADII]
    for (mode,ratio),item in zip(schedule,arcs,strict=True):
        key,h,target,shift,estimate,solved,iterations,evaluations,diagnostic=item['args']
        control=projections[mode]
        w=load_weight if mode=='LOAD' else 0.
        mu=weight_metric if mode=='LOAD' else 0.
        span=load_length if mode=='LOAD' else field_length
        assert key==mode and native.number(h)==ratio and item['ARC-END']==['9744']
        assert int(iterations)<=12 and int(evaluations)>=int(iterations)
        target,shift,estimate=native.numbers((target,shift,estimate))
        assert isclose(reference.dot(control,move)+w*factor_moves[-1],span,rel_tol=2e-10)
        assert isclose(shift,ratio*span,rel_tol=1e-12) and estimate==final+ratio*factor_moves[-1]
        assert isclose(target,reference.dot(control[:56],baseline[:56])+w*final+shift,abs_tol=1e-16)
        solved=native.received(solved)
        report={'control':mode,'secant_fraction':ratio,'solver_returned':solved,'iterations':int(iterations),
                'evaluations':int(evaluations),'diagnostic':diagnostic}
        if solved:
            factor,norm,tau,reach,travel,ctrl_error,in_original=native.numbers(item['ARC-BALANCE'][:-1])
            local=native.received(item['ARC-BALANCE'][-1])
            field,residual,load,wrench=(native.numbers(item[name]) for name in ('ARC-FIELD','ARC-RESIDUAL','ARC-TARGET','ARC-WRENCH'))
            delta=[b-a for a,b in zip(baseline,field,strict=True)]
            assert load==[a+factor*dv for a,dv in zip(offset,direction,strict=True)]
            assert isclose(tau,5e-7*(1.+factor*max(map(abs,load_dir[:56]))),abs_tol=2e-15) or any(offset)
            assert isclose(reach,reference.dot(delta,control)+w*(factor-final),abs_tol=2e-20)
            assert isclose(travel,sqrt(metric_value(weights,operator,delta)+mu*(factor-final)**2),rel_tol=3e-11,abs_tol=1e-20)
            assert isclose(ctrl_error,modulus*(reach-shift),abs_tol=1e-12)
            assert isclose(in_original,reference.dot(initial[:56],field[:56]),abs_tol=2e-16)
            assert isclose(norm,norm_equations(load,wrench,residual,ctrl_error,scales),abs_tol=1e-13)
            assert local==(reach*shift>0. and abs(reach-shift)<=.125*abs(shift) and travel<=3.*abs(shift)
                           and norm<=tau and max(map(abs,residual[56:]))<=tau/modulus)
            absolute_bound=None
            if local:
                bounded,value=item['ARC-BOUND']
                if native.received(bounded):
                    absolute_bound=native.number(value)
                    assert absolute_bound>0.
            else:
                assert 'ARC-BOUND' not in item
            report.update({'verified_local_balance':local,'lambda':factor,'lambda_shift':factor-final,
                           'lambda_uncertainty':absolute_bound,'norm_MPa':norm,'tau_MPa':tau,'old_xz':in_original,
                           'projected_step':reach,'metric_step':travel})
        details.append(report)
    result={'status':'PASS','exact_prefix':25,'original_G13_lambda':final,'original_G13_xz':controls[-1],
            'field_secant_length':field_length,'combined_secant_length':load_length,
            'arcs':details,'physical_limit_certified':False,'native_trace_sha256':native.file_hash(path),'proof':proof}
    raw=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
    output=folder/'Verification.json'
    if output.exists():
        assert output.read_bytes()==raw
    else:
        output.write_bytes(raw)
    print('HARDSHEAR G13 PHYSICAL ARC OFFLINE PASS',json.dumps(details,ensure_ascii=False))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',action='store_true')
    parser.add_argument('--order',type=int,choices=(10,))
    args=parser.parse_args()
    staged=inputs()
    if args.inputs:
        print('HARDSHEAR G13 PHYSICAL ARC INPUTS: PASS')
    else:
        assert args.order==10
        verify(*staged)
