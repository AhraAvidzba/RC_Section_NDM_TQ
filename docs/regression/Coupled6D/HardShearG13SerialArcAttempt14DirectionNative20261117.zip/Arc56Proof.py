"""Сверяет неизменность ветви и вклад продольных станций в уравнение 56."""

from math import isclose
from pathlib import Path

import PriorVerify as prior
import ProbeVerify as probe


HERE=Path(__file__).resolve().parent
PREVIOUS='BD3549286ED22226484C942513DFA52D1B5BD3B9145B69C2D8317168B94D8AAD'


def inputs(fixture,extract):
    root=HERE/'ExtendedPrior'
    report=root/'Verification.json'; trace=root/'HardG14Direction.csv'
    assert prior.file_hash(report)==fixture['extended_source_report_sha256']==PREVIOUS
    receipt=prior.read(report)
    assert receipt['status']=='PASS' and receipt['terminal']=='MINIMUM_RADIUS' and receipt['accepted_count']==9
    assert prior.file_hash(trace)==receipt['native_trace_sha256']
    _,weights,ops,steps,_,final=extract(trace)
    assert len(weights)==118 and len(ops)==118*9 and len(steps)==14
    assert final==['MINIMUM_RADIUS','9','9744'] and steps[-1]['TRACE-DECISION'][0]=='REFUSED'


def raw_diagnostics(path):
    qualified=[]; points={}; outer={}; small=[]
    for row in path.read_text(encoding='cp1251').splitlines():
        if not row.startswith('ARC56-'):
            continue
        line=row.removeprefix('ARC56-'); key,*args=line.split(';')
        if key=='LOCATION':
            index=int(args[0]); assert index not in points
            points[index]=prior.numbers(args[1:])
        elif key=='SMALL':
            small.append(args)
        elif key in ('ANCHOR','CONTROL-TARGET','CONTROL-PROJECTION','ROLLBACK','ROLLBACK-FIELD'):
            assert key not in outer
            outer[key]=args
        else:
            qualified.append(line)
    argument=probe.TextTrace(['HARDSHEAR-G14-DIRECTION;1',*qualified,'FINISH;COMPLETE;25;1'])
    _, tags,matrices,samples=probe.read_probe(argument)
    return points,outer,small,tags,matrices,samples


def weak_contributions(samples,points,length,area,details):
    assert set(points)==set(range(1,119))
    unperturbed=next(sample for sample in samples if sample['arm']=='STOCK' and sample['h']==0.)
    ratio=.002
    decompositions=[]
    for sample,result in zip(samples,details,strict=True):
        if not sample['available']:
            continue
        selected=[]
        for point,(x,y,weight) in points.items():
            actual,_,_,_,txm,tym,txp,typ=sample['points'][point]
            previous,_,_,_,txm0,tym0,txp0,typ0=unperturbed['points'][point]
            factor=weight/(area*ratio*length)
            minus=factor*(y*txm-x*tym)
            plus=factor*(-y*txp+x*typ)
            assert isclose(actual,minus+plus,rel_tol=2e-11,abs_tol=2e-14)
            delta_below=factor*(y*(txm-txm0)-x*(tym-tym0))
            delta_above=factor*(-y*(txp-txp0)+x*(typ-typ0))
            assert isclose(actual-previous,delta_below+delta_above,abs_tol=2e-14,rel_tol=1e-9)
            selected.append({'point':point,'x_mm':x,'y_mm':y,'delta_total_MPa':delta_below+delta_above,
                             'delta_minus_MPa':delta_below,'delta_plus_MPa':delta_above})
        result['largest_material_points_with_station_signs']=sorted(selected,key=lambda x:abs(x['delta_total_MPa']),reverse=True)[:5]
        decompositions.append(result)
    return decompositions


def verify(fixture,extract,path,records,geometry,weights,steps):
    _,old_weights,old_ops,old_steps,old_budget,old_final=extract(HERE/'ExtendedPrior/HardG14Direction.csv')
    assert old_steps==steps and old_weights==weights
    points,outer,small,tags,matrices,samples=raw_diagnostics(path)
    assert len(records)>=25 and outer['ANCHOR']==outer['ROLLBACK-FIELD']
    assert outer['ANCHOR']==steps[10]['TRACE-COMMIT'] and outer['ROLLBACK']==['9744','True']
    assert outer['CONTROL-TARGET']==steps[-1]['args'][3:4] and outer['CONTROL-PROJECTION']==steps[-1]['TRACE-PROJECTION']
    assert all(weights[i]==points[i][2] for i in points)
    cap=tags['CAPTURE']; row=int(cap[0])-1
    base,rejected,h,norm,tolerance=prior.numbers(cap[1:6]); iterations,evaluations=map(int,cap[6:8])
    assert row==55 and (iterations,evaluations)==(0,14) and h==1/128
    assert isclose(norm,1.26725191206583e-6,rel_tol=2e-10)
    assert isclose((rejected-base)/h,3.66433125067911e-6,rel_tol=2e-10)
    assert small and small[0]==['ENTER',*cap[4:6]] and tolerance<norm<=2*tolerance
    assert small[-1][0] in {'REFINED_ASSEMBLY_REFUSED','SYSTEM_REFUSED','OPTIMIZER_REFUSED','NO_DAMPED_EQUILIBRIUM','HANDLER_EXIT'}
    area,length,modulus=prior.numbers(geometry['MESH'][-3:]); normalization=(area,length,modulus,118)
    direction=prior.numbers(geometry['DIRECTION'])
    measures={'PROJECTION':outer['CONTROL-PROJECTION'],'normalizers':normalization}
    actions,details=probe.validate_samples(samples,tags,matrices,measures,row,base,rejected,h,norm,tolerance,direction)
    available=weak_contributions(samples,points,length,area,details)
    return {'same_14_trace_records_bit_identical':True,'same_34_accepted_fields_before_trial':True,'equation':row+1,
            'initial_norm_MPa':norm,'tolerance_MPa':tolerance,'norm_over_tolerance':norm/tolerance,
            'last_ordinary_fraction':h,'actual_measured_direction_MPa':(rejected-base)/h,
            'matrix_action_on_original_direction_MPa':actions,'existing_small_strain_exit':small,
            'same_9744_history_values_after_capture':True,'samples':details,'available_station_decompositions':len(available),
            'refinement_status':tags.get('REFINED',[]),'new_accepted_point':False,'physical_limit_certified':False}
