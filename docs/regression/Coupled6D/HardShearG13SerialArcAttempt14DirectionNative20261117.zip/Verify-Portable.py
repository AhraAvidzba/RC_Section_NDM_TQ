"""Автономно проверяет архив попытки 14 без запуска Excel."""

import json
from pathlib import Path
from subprocess import PIPE, run
import sys

import Departure
import PriorVerify as prior


HERE=Path(__file__).resolve().parent


def main():
    sums=prior.read(HERE/'SHA256SUMS.json')
    actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}
    assert actual==set(sums)|{'SHA256SUMS.json'}
    for name,digest in sums.items():
        assert prior.file_hash(HERE/name)==digest and not name.lower().endswith('.xlsm'),name
    fixture=prior.read(HERE/'Fixture.json')
    assert prior.file_hash(HERE/'Fixture.json')=='FF16793FFEE203E69410E91AFF5DC07E185764DFD0235325BF47336C84E2BD4C'
    for name,digest in fixture['production'].items():
        assert prior.file_hash(HERE/'Production'/name)==digest,name
    result=run([sys.executable,'-B','-X','utf8','Verify.py','--order','10'],cwd=HERE,stdout=PIPE,check=True)
    print(result.stdout.decode('utf-8').strip())
    folder=HERE/'Native/Order10'
    native=prior.read(folder/'Verification.json')
    assert prior.file_hash(folder/'Verification.json')=='2378A37CF7B42ADDEF6D7871B50DA6C317482E84C0DA8D2D2DDFF695E91C5A8B'
    assert native['status']=='PASS' and native['accepted_count']==9 and native['terminal']=='MINIMUM_RADIUS'
    print(json.dumps(Departure.verify(folder/'HardG14Direction.csv'),ensure_ascii=False,indent=2))
    print('HARDSHEAR_ARC56_PORTABLE: VERIFIED_EVIDENCE; MINIMUM_RADIUS; physical_limit_certified=False')


if __name__=='__main__':
    main()
