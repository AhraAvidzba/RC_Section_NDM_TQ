' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает направление на последней пробе дуги и возвращает исходную диагностику.
Private Sub CaptureHardArc56Test(ByRef field() As Double, ByVal lambda As Double, ByRef correction() As Double, _
        ByVal equation As Long, ByVal before As Double, ByVal after As Double, ByVal fraction As Double, _
        ByVal norm As Double, ByVal tolerance As Double)
    mHardArc56ArmedTest = False
    Dim accepted() As Double, history() As Double, evaluations As Long, iterations As Long
    Dim external() As Double, matrix() As Double, residual() As Double, resultants() As Double, candidate() As Double
    Dim failureCode As ESolverFailureCode, savedNorm As Double, oldPivot As Double, materialPoint As Long
    Dim lastPoint As Long, lastSide As Long, failures As Long, gradientBuilds As Long, localGradientBuilds As Long
    Dim currentLoad As Double, savedMeta As CResultMeta
    CopyAccepted accepted: ReadHardF19HistoryTest history
    evaluations = mEvaluations: iterations = mIterations
    external = mExternal: matrix = mMatrix: residual = mResidual: resultants = mTrialResultants: candidate = mCandidate
    failureCode = mFailureCode: savedNorm = mLastNorm: oldPivot = mMinimumPivot: materialPoint = mMaterialPoint
    lastPoint = mLastFailedPoint: lastSide = mLastFailedSide: failures = mMaterialFailures
    gradientBuilds = mGradientBuilds: localGradientBuilds = mLocalGradientBuilds
    currentLoad = mCurrentControlLambda: Set savedMeta = mMeta.Clone
    WriteHardArc56RowTest "ANCHOR;" & HardRankVectorTest(accepted)
    WriteHardArc56RowTest "CONTROL-TARGET;" & HardRankBitsTest(mTargetControl)
    WriteHardArc56RowTest "CONTROL-PROJECTION;" & HardRankVectorTest(mControlProjection)
    ReadHardArc56DirectionTest field, lambda, correction, equation, before, after, fraction, norm, tolerance
    WriteHardArc56RowTest "ROLLBACK;" & CStr(UBound(history)) & ";" & CStr(HardG13HistoryAgreesTest(history))
    CopyAccepted accepted: WriteHardArc56RowTest "ROLLBACK-FIELD;" & HardRankVectorTest(accepted)
    mEvaluations = evaluations: mIterations = iterations
    mExternal = external: mMatrix = matrix: mResidual = residual: mTrialResultants = resultants: mCandidate = candidate
    mFailureCode = failureCode: mLastNorm = savedNorm: mMinimumPivot = oldPivot: mMaterialPoint = materialPoint
    mLastFailedPoint = lastPoint: mLastFailedSide = lastSide: mMaterialFailures = failures
    mGradientBuilds = gradientBuilds: mLocalGradientBuilds = localGradientBuilds
    mCurrentControlLambda = currentLoad: Set mMeta = savedMeta
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Отделяет новые сырые записи от ранее подтверждённой ветви.
Private Sub WriteHardArc56RowTest(ByVal value As String)
    WriteHardRankRowTest "ARC56-" & Replace(value, vbCrLf, vbCrLf & "ARC56-")
End Sub
