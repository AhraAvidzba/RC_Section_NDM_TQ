"""Recompute the spatial and signed resultant checks for the length sensitivity."""

from argparse import ArgumentParser
import gzip
from hashlib import sha256
import json
from pathlib import Path
import runpy
from subprocess import run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
ARCHIVE = "FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E"
PROOF = "7BD88A4D31D9B0D51FB10426EF7D372E55C2B295FE7CFBFFC42800423AC93655"
STRESSES = "DA97FBDDCE9B10B49CA1D25354952FB9BA5F385AED4F49DE00BF8ADBB5B8BC3B"


def digest(data):
    return sha256(data).hexdigest().upper()


def read(source, name, seal):
    raw = (source / name).read_bytes()
    assert digest(raw) == seal
    return raw


def verify(repo, runtime, numpy):
    archive = repo / "docs/regression/Coupled6D/MVT2GaussReequilibratedASD20261117.zip"
    assert digest(archive.read_bytes()) == ARCHIVE
    reference = json.loads(read(HERE, "ReferenceLength.json", PROOF))
    raw_stresses = json.loads(gzip.decompress(read(HERE, "ReferenceLength.stress.json.gz", STRESSES)))
    assert set(reference["modes"]) == set(raw_stresses) == {"tension_length", "compression_length", "both_lengths"}
    assert reference["engine"] == "3.8.0" and not reference["regularization_enabled"]
    assert reference["reference_length_mm"] == 18.621285527678477 and reference["comparison_length_mm"] == 125
    assert reference["max_stock_stress_reproduction_MPa"] == 0
    with TemporaryDirectory(prefix="MVT2-Length-") as temp:
        root = Path(temp)
        with ZipFile(archive) as source:
            baseline = json.loads(source.read("Authoritative.json"))["modes"]["default"]
            for name in ("Verify-Authoritative.py", "Reequilibrate.py", "Operators.py"):
                (root / name).write_bytes(source.read(name))
        control = runpy.run_path(str(root / "Verify-Authoritative.py"))
        operators, source = control["unpack"](root, repo)
        sys.path.insert(0, str(root))
        try:
            program = runpy.run_path(str(root / "Reequilibrate.py"))
            _, report, geometry, directions, area, length, op, _, _, identity = program["read_inputs"](operators, root, source)
        finally:
            sys.path.pop(0)
        assert reference["source"] == identity
        max_error = 0.0
        for mode, state in reference["modes"].items():
            records = state["accepted"]
            expected = 26 if mode == "compression_length" else 9
            assert len(records) == expected and all(row["subdivision"] == 0 for row in records)
            assert [row["phase"] for row in records] == [row["phase"] for row in report["frames"][:expected]]
            for net, row in zip(raw_stresses[mode], records, strict=True):
                norm, _ = control["check"](net, row, geometry, directions, area, length, op)
                max_error = max(max_error, norm)
            if expected == 9:
                assert state["terminal"]["Q_requested_N"] == 6250
                assert state["terminal"]["last_reached_Q_N"] == 5000
                assert state["terminal"]["reason"] == "bounded_numerical_stop"
            else:
                assert state["terminal"] is None and state["accepted"] == baseline["accepted"]
        assert reference["modes"]["tension_length"]["accepted"] == reference["modes"]["both_lengths"]["accepted"]
        assert raw_stresses["tension_length"] == raw_stresses["both_lengths"]
        print("MVT2 ASD REFERENCE LENGTH OFFLINE PASS", PROOF, STRESSES, max_error)
        if runtime:
            (root / "Native/Operators.csv").write_bytes(operators.read_bytes())
            generator = root / "Reference-Length.py"
            generator.write_bytes((HERE / generator.name).read_bytes())
            out = root / "Recheck.json"
            raw = root / "Recheck.stress.json.gz"
            run([sys.executable, "-B", str(generator), "--root", str(root), "--native", str(root),
                 "--fixed", str(source), "--numpy", str(numpy), "--out", str(out), "--raw-out", str(raw),
                 "--seconds", "80"], check=True)
            assert digest(out.read_bytes()) == PROOF and digest(raw.read_bytes()) == STRESSES
            print("MVT2 ASD REFERENCE LENGTH RUNTIME PASS", PROOF)


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--repo", type=Path, required=True)
    cli.add_argument("--runtime", action="store_true")
    cli.add_argument("--numpy", type=Path, default=Path("D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython"))
    args = cli.parse_args()
    verify(args.repo.resolve(), args.runtime, args.numpy)
