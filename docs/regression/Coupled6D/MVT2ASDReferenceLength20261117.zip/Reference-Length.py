"""Isolate the reference length used to generate ASDConcrete3D uniaxial curves."""

from argparse import ArgumentParser
import gzip
from hashlib import sha256
import json
from math import sqrt
from pathlib import Path
import sys
from time import perf_counter


def bezier(x, start, middle, end, initial, peak):
    a = start - 2.0 * middle + end
    b = 2.0 * (middle - start)
    u = (sqrt(b * b - 4.0 * a * (start - x)) - b) / (2.0 * a)
    return (initial - peak) * u * u + 2.0 * (peak - initial) * u + initial


def default_curves(e, nu, fc, ft, length=None):
    """Translations of the stock generator in the OpenSees 3.8.0 source."""
    ec = 2 * fc / e
    gt = 0.073 * fc ** 0.18
    gc = 2 * gt * (fc * fc) / (ft * ft)
    elastic_c = fc / e
    plastic_c = (ec - elastic_c) * 0.4 + elastic_c
    gc_prepeak = 0.5 * fc * (ec - plastic_c)
    native_length = min(0.01 * gc / gc_prepeak, 0.01 * gt / (0.5 * ft * ft / e))
    length = native_length if length is None else length

    e1 = 1.5 * ft / e
    plastic_t = e1 - ft / e
    opening = gt / length / ft
    e2 = max(1.001 * e1, opening + 0.2 * ft / e + plastic_t)
    e3 = max(1.001 * e2, 5.0 * opening + 1e-3 * ft / e + plastic_t)
    te = (0.0, 0.9 * ft / e, e1, e2, e3, 10.0 * e3)
    ts = (0.0, 0.9 * ft, ft, 0.2 * ft, 1e-3 * ft, 1e-3 * ft)
    tp = (0.0, 0.0, plastic_t, 0.9 * e2, 0.8 * e3, 0.8 * e3)

    fc0 = 0.5 * fc
    ec0 = fc0 / e
    fcr = 0.1 * fc
    ec_residual = ec + 2 * max(0.01 * gc_prepeak, gc / length - gc_prepeak) / (fc + fcr)
    step = (ec - ec0) / 9
    ce, cs, cp = [0.0, ec0], [0.0, fc0], [0.0, 0.0]
    for i in range(1, 10):
        x = ec0 + i * step
        ce.append(x)
        cs.append(bezier(x, ec0, elastic_c, ec, fc0, fc))
        cp.append(cp[-1] + 0.7 * (x - cp[-1]))
    ce += [ec_residual, ec_residual + ec0]
    cs += [fcr, fcr]
    cp += [cp[-1] + 0.7 * (ec_residual - cp[-1])] * 2

    curves = {}
    for kind, strain, stress, plastic in (("T", te, ts, tp), ("C", ce, cs, cp)):
        damage = [0.0, 0.0]
        for x, s, pl in zip(strain[2:], stress[2:], plastic[2:], strict=True):
            pl = min(pl, x - s / e)
            damage.append(1.0 - s / ((x - pl) * e))
        curves[kind] = (strain, stress, damage)
    return native_length, curves


def material_command(e, nu, curves):
    command = ["ASDConcrete3D", e, nu]
    for branch, arrays in curves.items():
        for coordinate, values in zip("esd", arrays, strict=True):
            command.extend([f"-{branch}{coordinate}", *values])
    return [*command, "-tangent"]


def prove_stock(ops, e, nu, fc, ft, curves, frames):
    ops.wipe()
    ops.model("basic", "-ndm", 3, "-ndf", 3)
    points = (0, 2, 15, 22, 26, 32, 44)
    error = 0.0
    try:
        for sample, point in enumerate(points):
            left, right = 2 * sample + 1, 2 * sample + 2
            ops.nDMaterial("ASDConcrete3D", left, e, nu, "-fc", fc, "-ft", ft, "-tangent")
            command = material_command(e, nu, curves)
            ops.nDMaterial(command[0], right, *command[1:])
            for frame in frames:
                xx, yy, zz, xy, xz, yz = frame["points"][point][:6]
                state = (xx, yy, zz, xy, yz, xz)
                for tag in (left, right):
                    ops.NDTest("SetStrain", tag, *state)
                error = max(error, *(abs(a - b) for a, b in zip(
                    ops.NDTest("GetStress", left), ops.NDTest("GetStress", right), strict=True)))
                for tag in (left, right):
                    ops.NDTest("CommitState", tag)
    finally:
        ops.wipe()
    assert error < 2e-11
    return error


def main():
    from Reequilibrate import read_inputs, simulate
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--root", type=Path, required=True)
    cli.add_argument("--native", type=Path, required=True)
    cli.add_argument("--out", type=Path, required=True)
    cli.add_argument("--raw-out", type=Path)
    cli.add_argument("--numpy", type=Path, required=True)
    cli.add_argument("--fixed", type=Path, required=True)
    cli.add_argument("--seconds", type=int, default=80)
    args = cli.parse_args()
    sys.path.insert(0, str(args.numpy))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version() == "3.8.0"
    helper, report, geo, dirs, area, length, operators, seeds, _, proof = read_inputs(
        args.root / "Native/Operators.csv", args.native, args.fixed)
    e, nu, fc, ft = report["model"][:4]
    lch = report["model"][-1]
    stock_length, stock = default_curves(e, nu, fc, ft)
    reference_error = prove_stock(ops, e, nu, fc, ft, stock, report["frames"])
    _, changed = default_curves(e, nu, fc, ft, lch)
    results, stresses = {}, {}
    variants = {"both_lengths": changed, "tension_length": {**stock, "T": changed["T"]},
                "compression_length": {**stock, "C": changed["C"]}}
    for mode, curves in variants.items():
        try:
            results[mode], stresses[mode] = simulate(np, ops, helper, report, geo, dirs, area, length, operators, seeds,
                                                     mode, material_command(e, nu, curves), perf_counter() + args.seconds, 26)
        finally:
            ops.wipe()
        print(mode, results[mode]["last_confirmed"], flush=True)
    proof = {"engine": ops.version(), "source": proof, "reference_length_mm": stock_length,
             "comparison_length_mm": lch, "max_stock_stress_reproduction_MPa": reference_error,
             "regularization_enabled": False, "modes": results}
    raw = (json.dumps(proof, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    with args.out.open("xb") as output:
        output.write(raw)
    print(sha256(raw).hexdigest().upper())
    if args.raw_out is not None:
        compressed = gzip.compress(json.dumps(stresses, separators=(",", ":"), allow_nan=False).encode(), mtime=0)
        with args.raw_out.open("xb") as output:
            output.write(compressed)
        print("STRESSES", sha256(compressed).hexdigest().upper())


if __name__ == "__main__":
    main()
