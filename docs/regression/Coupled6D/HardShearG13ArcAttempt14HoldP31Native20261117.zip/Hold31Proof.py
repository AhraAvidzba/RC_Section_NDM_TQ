"""Независимо проверяет дополнительную пробу, все силы и неизменность истории."""
from math import fsum, isclose
from pathlib import Path

import Arc56Proof as old
import ArcVerify as arc
import PriorVerify as prior

HERE = Path(__file__).resolve().parent
REPORT = '2378A37CF7B42ADDEF6D7871B50DA6C317482E84C0DA8D2D2DDFF695E91C5A8B'


def inputs(fixture):
    reference=HERE/'PreviousARC56'
    receipt=prior.read(reference/'Verification.json')
    assert fixture['exact_previous_arc56_report_sha256']==prior.file_hash(reference/'Verification.json')==REPORT
    assert receipt['native_trace_sha256']==prior.file_hash(reference/'HardG14Direction.csv')
    assert receipt['terminal']=='MINIMUM_RADIUS' and receipt['accepted_count']==9
    witness=receipt['attempt14_direction']
    assert witness['equation']==56 and not witness['new_accepted_point'] and witness['same_9744_history_values_after_capture']


def verify(path,geometry):
    source=path.read_text(encoding='cp1251').splitlines()
    baseline=(HERE/'PreviousARC56/HardG14Direction.csv').read_text(encoding='cp1251').splitlines()
    assert [line for line in source if not line.startswith('ARC31-')]==baseline
    _,outer,_,_,_,samples=old.raw_diagnostics(path)
    assert outer['ANCHOR']==outer['ROLLBACK-FIELD'] and outer['ROLLBACK']==['9744','True']
    zero=next(s for s in samples if s['arm']=='STOCK' and s['h']==0.)
    prefix={}
    checks=[]
    for line in source:
        if not line.startswith('ARC31-'):
            continue
        key,*args=line[6:].split(';')
        if key=='TRY':
            checks.append({key:args})
        elif key in {'RESULT','TRIAL','LOAD','WRENCH','RESIDUAL','FAILURE'}:
            assert key not in checks[-1]
            checks[-1][key]=args
        else:
            assert key not in prefix
            prefix[key]=args
    kind,=prefix['OUTCOME']
    result={'conclusion':kind,'exact_prior_trace':True,'committed':False,'restored_history_values':9744,'trials':[]}
    if kind in {'TANGENT_REFUSED','SYSTEM_REFUSED','EVENT_REFUSED','ZERO_EVENT_ROW','OPTIMIZER_REFUSED'}:
        assert not checks and 'CORRECTION' not in prefix
        return result
    assert kind in {'BALANCED_SAME_STATION_BRANCH','NO_SAME_BRANCH_BALANCE'} and len(checks)==4
    oldLambda,norm,tau,yieldAtBase=prior.numbers(prefix['BASE'][:4])
    assert prefix['BASE'][4:]==['True','1','1'] and yieldAtBase==zero['stations'][31,-1][0]>0
    assert oldLambda==zero['lambda'] and prefix['FIELD']==zero['DIR-FIELD']
    assert isclose(norm,1.2672519120658307e-6,rel_tol=1e-11) and isclose(tau,1.2271640014377922e-6,rel_tol=1e-11)
    radius,forceLimit=prior.numbers(prefix['LINEAR'])
    assert radius==2.5*norm and forceLimit==.92*tau
    grad,scales,correction,field=(prior.numbers(prefix[key]) for key in ('GRADIENT','SCALES','CORRECTION','FIELD'))
    assert len(field)==60 and len(grad)==len(scales)==len(correction)==61 and not any(grad[56:])
    assert all(scale>0. for scale in scales)
    assert max(abs(step*scale) for step,scale in zip(correction,scales,strict=True))<=radius*(1+2e-10)
    event_terms=[a*b for a,b in zip(grad,correction,strict=True)]
    direction_change=fsum(event_terms)
    assert abs(direction_change)<=max(2e-16,2e-9*fsum(map(abs,event_terms)))
    area,length,modulus=prior.numbers(geometry['MESH'][-3:])
    loadScales=(area,area*length,area*length,area*length,area,area)
    loadDir=prior.numbers(geometry['DIRECTION'])
    loadOffset=prior.numbers(geometry['OFFSET'])
    control=prior.numbers(outer['CONTROL-PROJECTION'])
    target,=prior.numbers(outer['CONTROL-TARGET'])
    for item,fraction in zip(checks,(1.,.5,.25,.125),strict=True):
        h,loadFactor,currentTau=prior.numbers(item['TRY'][:3])
        assert h==fraction and loadFactor==oldLambda+h*correction[-1]
        row={'fraction':h,'lambda':loadFactor,'tau_MPa':currentTau,'balanced_same_p31_branch':False}
        if not prior.received(item['TRY'][3]):
            assert set(item)=={'TRY','FAILURE'}
            row['failure']=item['FAILURE']
        else:
            trial,load,wrench,residual=(prior.numbers(item[key]) for key in ('TRIAL','LOAD','WRENCH','RESIDUAL'))
            assert trial==[a+h*b for a,b in zip(field,correction[:-1],strict=True)]
            assert load==[a+b*loadFactor for a,b in zip(loadOffset,loadDir,strict=True)]
            resultNorm,controlError=prior.numbers(item['RESULT'][:2])
            gaugeOK,flagsOK=map(prior.received,item['RESULT'][2:4])
            value=prior.number(item['RESULT'][4]); plastic=prior.received(item['RESULT'][5])
            principal,substeps=map(int,item['RESULT'][6:])
            assert isclose(controlError,modulus*(fsum(a*b for a,b in zip(control,trial,strict=True))-target),abs_tol=2e-13)
            assert isclose(resultNorm,arc.norm_equations(load,wrench,residual,controlError,loadScales),abs_tol=1e-14)
            assert gaugeOK==(max(map(abs,residual[56:]))<=currentTau/modulus)
            assert isclose(currentTau,5e-7*(1.+loadFactor*(tau/5e-7-1.)/oldLambda),abs_tol=2e-15)
            row.update(norm_MPa=resultNorm,gauges=gaugeOK,control_residual_MPa=controlError,F_MPa=value,plastic=plastic,
                       principal=principal,substeps=substeps,balanced_same_p31_branch=
                       flagsOK and value>0. and plastic and principal==substeps==1 and gaugeOK and resultNorm<=currentTau,
                       signed_normalized_force_error_MPa=[(a-b)/fac for a,b,fac in zip(wrench,load,loadScales,strict=True)])
        result['trials'].append(row)
    assert (kind=='BALANCED_SAME_STATION_BRANCH')==any(r['balanced_same_p31_branch'] for r in result['trials'])
    result['linear_direction_change_F_MPa']=direction_change
    return result
