"""Хранит разность HardArc31 относительно закреплённого архива ARC56."""

from base64 import b64decode, b64encode
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

BASE_SHA = '6CA5C64823399B7385635AA50F31C132A221164C47DE8D8E96B42DBC23037318'
FIXTURE_SHA = 'D4084B2483BEAE53F8BB78243C6D00DC821343AA314CCAC1ECC150E8058BF662'
TRACE = 'Native/Order10/HardG14Direction.csv'
REPORT = 'Native/Order10/Verification.json'
CODE = 'docs/regression/CodeUpdate.json'
PREFIX = b'ARC31-'
DELTA = 'Native/Order10/TraceDelta.json'
README = 'README-Portable.md'
SOURCE_MAP = {
    'PreviousARC56/Verification.json': REPORT,
    'PreviousARC56/HardG14Direction.csv': TRACE,
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def json_bytes(value):
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')


def load(raw):
    return json.loads(raw)


def fixture(raw):
    assert digest(raw)==FIXTURE_SHA
    spec=load(raw)
    assert spec['exact_previous_arc56_sha256']==BASE_SHA
    return spec


def baseline_members(path):
    assert digest(path.read_bytes())==BASE_SHA
    with ZipFile(path) as archive:
        return {name:archive.read(name) for name in archive.namelist()}


def group_delta(previous,current):
    baseline=previous.splitlines(keepends=True)
    candidate=current.splitlines(keepends=True)
    inserts=[]
    idx=0
    for line in candidate:
        if line.startswith(PREFIX):
            if not inserts or inserts[-1]['before_line']!=idx:
                inserts.append(dict(before_line=idx,lines=[]))
            inserts[-1]['lines'].append(b64encode(line).decode('ascii'))
        else:
            assert idx < len(baseline) and line==baseline[idx], f'ARC56 row {idx+1} changed'
            idx+=1
    assert inserts and idx==len(baseline)
    return {'previous_sha256':digest(previous),'native_sha256':digest(current),'inserts':inserts}


def restore_trace(previous,delta):
    assert delta['previous_sha256']==digest(previous)
    source=previous.splitlines(keepends=True)
    restored=[]
    seen=-1
    cursor=0
    for insert in delta['inserts']:
        idx=insert['before_line']
        assert seen<idx<=len(source) and insert['lines']
        restored.extend(source[cursor:idx])
        for encoded in insert['lines']:
            row=b64decode(encoded,validate=True)
            assert row.startswith(PREFIX) and row.endswith(b'\r\n') and len(row.splitlines())==1
            restored.append(row)
        seen=cursor=idx
    restored.extend(source[cursor:])
    raw=b''.join(restored)
    assert digest(raw)==delta['native_sha256']
    return raw


def prior_inputs(spec,baseline):
    for name,expected in spec['inputs'].items():
        source=baseline.get(SOURCE_MAP.get(name,name))
        if source is not None and digest(source)==expected:
            yield name,source
    for name,expected in spec['production'].items():
        name='Production/'+name
        source=baseline[name]
        assert digest(source)==expected
        yield name,source


def restore_files(archive,baseline):
    plan=fixture(archive['Fixture.json'])
    inherited=dict(prior_inputs(plan,baseline))
    assert archive.keys().isdisjoint(inherited)
    all_files={**inherited,**archive}
    for name,expected in plan['inputs'].items():
        assert digest(all_files[name])==expected,name
    if DELTA in archive:
        assert TRACE not in archive
        all_files[TRACE]=restore_trace(baseline[TRACE],load(archive[DELTA]))
    return all_files
