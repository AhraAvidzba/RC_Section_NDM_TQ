"""Запечатывает запись HardArc31, используя ARC56 для всех общих файлов."""
from argparse import ArgumentParser
from pathlib import Path
import sys
from subprocess import PIPE, run
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import PortableSupport as p

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'hs-arc56/proof/HardShearG13SerialArcAttempt14DirectionNative20261117.zip'
NAME='HardShearG13ArcAttempt14HoldP31Native20261117'
SUMS='SHA256SUMS.json'


def collect(source,base,native_sha):
    spec=p.fixture((source/'Fixture.json').read_bytes())
    shared=dict(p.prior_inputs(spec,base))
    for name,digest in spec['inputs'].items():
        raw=(source/name).read_bytes()
        assert p.digest(raw)==digest
        if name in shared:
            assert raw==shared[name]
    names=['Fixture.json','Compile.log','CompileClosure.json',p.CODE,'Run.ndjson',
           *(name for name in spec['inputs'] if name not in shared),
           *(path.relative_to(source).as_posix()
             for path in sorted((source/'Native/Order10').iterdir()) if path.is_file())]
    assert len(names)==len(set(names)) and p.REPORT in names and p.TRACE in names
    data={name:(source/name).read_bytes() for name in names}
    assert p.digest(data[p.REPORT])==native_sha.upper()
    assert p.load(data[p.REPORT])['native_trace_sha256']==p.digest(data[p.TRACE])
    data[p.DELTA]=p.json_bytes(p.group_delta(base[p.TRACE],data.pop(p.TRACE)))
    for name in ('PortableSupport.py','Pack.py','Verify-Portable.py',p.README):
        data[name]=(HERE/name).read_bytes()
    data[SUMS]=p.json_bytes(dict(sorted((name,p.digest(raw)) for name,raw in data.items())))
    return data


def seal(path,raw):
    if path.exists():
        assert path.read_bytes()==raw
    else:
        path.write_bytes(raw)


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('source',type=Path)
    cli.add_argument('report_sha256')
    cli.add_argument('--arc56',type=Path,default=BASE)
    args=cli.parse_args()
    baseline=args.arc56.resolve()
    files=collect(args.source,p.baseline_members(baseline),args.report_sha256)
    out=HERE/'proof'
    out.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix='portable-',dir=out) as name:
        work=Path(name)
        candidate=work/'candidate.zip'
        with ZipFile(candidate,'w',compression=ZIP_DEFLATED,compresslevel=9) as zipout:
            for relative,data in sorted(files.items()):
                entry=ZipInfo(relative,date_time=(2026,11,17,0,0,0))
                entry.create_system=3
                entry.external_attr=0o100644<<16
                zipout.writestr(entry,data,compress_type=ZIP_DEFLATED,compresslevel=9)
        extracted=work/'payload'
        with ZipFile(candidate) as zipout:
            zipout.extractall(extracted)
        replay=run([sys.executable,'-B','-X','utf8','Verify-Portable.py',str(baseline)],check=True,cwd=extracted,stdout=PIPE).stdout
        package=candidate.read_bytes()
        sha=p.digest(package)
        seal(out/(NAME+'.zip'),package)
        seal(out/(NAME+'.zip.sha256'),f'{sha} *{NAME}.zip\n'.encode())
        seal(out/(NAME+'.replay.txt'),replay)
    print(out/(NAME+'.zip'),sha,len(package))
    print(replay.decode().splitlines()[-1])


if __name__=='__main__':
    main()
