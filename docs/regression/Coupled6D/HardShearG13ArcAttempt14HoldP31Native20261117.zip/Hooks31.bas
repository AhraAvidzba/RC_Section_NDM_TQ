' -------------------- ДЛЯ ТЕСТОВ --------------------
' Добавляет только одно линейное равенство dFtrial = 0 на станции 31/-1.
' Оператор сил, исходное управление и радиус берутся из штатной малой поправки.
Private Sub CheckHardArc31Test(ByRef field() As Double, ByVal lambda As Double, ByVal norm As Double, ByVal tau As Double)
    Const POINT As Long = 31, SIDE As Long = -1, TOLERANCE As Double = 0.0000005
    Dim force() As Double, forceResidual() As Double, equality() As Double, equalityResidual() As Double
    Dim scales() As Double, strain() As Double, correction() As Double, trial() As Double, basis() As Double
    Dim load(1 To COMPONENT_COUNT) As Double, localStrain(1 To COMPONENT_COUNT) As Double, gradient(1 To COMPONENT_COUNT) As Double
    Dim material As CCoupledReinforcedResponse, optimizer As New CCoupledStepOptimizer
    Dim radius As Double, maxCoefficient As Double, dYield() As Double, value As Double, baseValue As Double
    Dim n As Long, i As Long, j As Long, row As Long, branch As Long, substeps As Long, basePlastic As Boolean
    Set material = YieldResponse(SIDE)
    SetControlledLoad lambda, load
    If Not Evaluate(field, True, recordTrial:=False, refinedBranch:=True) Then
        WriteHardRankRowTest "ARC31-OUTCOME;TANGENT_REFUSED": Exit Sub
    End If
    If Not BuildSmallStrainSystem(field, load, tau, force, forceResidual, equality, equalityResidual, scales) Then
        WriteHardRankRowTest "ARC31-OUTCOME;SYSTEM_REFUSED": Exit Sub
    End If
    YieldStrain POINT, SIDE, field, localStrain
    If Not material.TryReadTrialYield(POINT, localStrain, baseValue, gradient) Or _
            Not material.TryReadConcreteBranch(POINT, localStrain, basePlastic, branch, substeps) Then
        WriteHardRankRowTest "ARC31-OUTCOME;EVENT_REFUSED": Exit Sub
    End If
    WriteHardRankRowTest "ARC31-BASE;" & HardRankBitsTest(lambda) & ";" & HardRankBitsTest(norm) & ";" & _
        HardRankBitsTest(tau) & ";" & HardRankBitsTest(baseValue) & ";" & CStr(basePlastic) & ";" & CStr(branch) & ";" & CStr(substeps)
    WriteHardRankRowTest "ARC31-FIELD;" & HardRankVectorTest(field)
    n = UBound(scales)
    ReDim basis(1 To mDegreeCount), dYield(1 To n), trial(1 To mDegreeCount)
    row = UBound(equalityResidual) + 1
    ReDim Preserve equality(1 To n, 1 To row), equalityResidual(1 To row)
    For i = 1 To mGaugeStart - 1
        basis(i) = 1#
        YieldStrain POINT, SIDE, basis, localStrain
        For j = 1 To COMPONENT_COUNT
            dYield(i) = dYield(i) + gradient(j) * localStrain(j)
        Next j
        basis(i) = 0#
        equality(i, row) = dYield(i) / scales(i)
        maxCoefficient = GeomMax(maxCoefficient, Abs(equality(i, row)))
    Next i
    If maxCoefficient <= 0# Then
        WriteHardRankRowTest "ARC31-OUTCOME;ZERO_EVENT_ROW": Exit Sub
    End If
    For i = 1 To n: equality(i, row) = equality(i, row) / maxCoefficient: Next i
    mSection.CopySpatialStrainCoefficients SPATIAL_HALF_STEP, strain
    For row = 1 To UBound(strain, 2)
        For i = 1 To n: strain(i, row) = strain(i, row) / scales(i): Next i
    Next row
    radius = SMALL_STRAIN_RADIUS * norm
    WriteHardRankRowTest "ARC31-LINEAR;" & HardRankBitsTest(radius) & ";" & HardRankBitsTest(SMALL_STRAIN_FORCE_FRACTION * tau)
    WriteHardRankRowTest "ARC31-GRADIENT;" & HardRankVectorTest(dYield)
    WriteHardRankRowTest "ARC31-SCALES;" & HardRankVectorTest(scales)
    If Not optimizer.TryMinimizeStrain(force, forceResidual, equality, equalityResidual, strain, _
            radius, SMALL_STRAIN_FORCE_FRACTION * tau, correction) Then
        WriteHardRankRowTest "ARC31-OUTCOME;OPTIMIZER_REFUSED": Exit Sub
    End If
    For i = 1 To n: correction(i) = correction(i) / scales(i): Next i
    WriteHardRankRowTest "ARC31-CORRECTION;" & HardRankVectorTest(correction)

    Dim fraction As Double, trialLambda As Double, trialTau As Double, trialNorm As Double
    Dim succeeded As Boolean, flagsReady As Boolean, plastic As Boolean, sameBranch As Boolean, found As Boolean
    fraction = 1#
    Do While fraction >= 0.125
        For i = 1 To mDegreeCount: trial(i) = field(i) + fraction * correction(i): Next i
        trialLambda = lambda + fraction * correction(n)
        SetControlledLoad trialLambda, load
        trialTau = EquilibriumTolerance(TOLERANCE, TOLERANCE)
        succeeded = Evaluate(trial, False, recordTrial:=False)
        WriteHardRankRowTest "ARC31-TRY;" & HardRankBitsTest(fraction) & ";" & HardRankBitsTest(trialLambda) & ";" & _
            HardRankBitsTest(trialTau) & ";" & CStr(succeeded)
        If succeeded Then
            trialNorm = EquilibriumNorm(load, trial)
            YieldStrain POINT, SIDE, trial, localStrain
            flagsReady = material.TryReadTrialYield(POINT, localStrain, value, gradient, False) And _
                material.TryReadConcreteBranch(POINT, localStrain, plastic, branch, substeps)
            sameBranch = (flagsReady And value > 0# And plastic And branch = 1 And substeps = 1)
            WriteHardRankRowTest "ARC31-RESULT;" & HardRankBitsTest(trialNorm) & ";" & _
                HardRankBitsTest(ControlResidual(trial)) & ";" & CStr(GaugesVerified(trialTau)) & ";" & _
                CStr(flagsReady) & ";" & HardRankBitsTest(value) & ";" & CStr(plastic) & ";" & CStr(branch) & ";" & CStr(substeps)
            WriteHardRankRowTest "ARC31-TRIAL;" & HardRankVectorTest(trial)
            WriteHardRankRowTest "ARC31-LOAD;" & HardRankVectorTest(load)
            WriteHardRankRowTest "ARC31-WRENCH;" & HardRankVectorTest(mTrialResultants)
            WriteHardRankRowTest "ARC31-RESIDUAL;" & HardRankVectorTest(mResidual)
            found = found Or (trialNorm <= trialTau And GaugesVerified(trialTau) And sameBranch)
        Else
            WriteHardRankRowTest "ARC31-FAILURE;" & CStr(mFailureCode) & ";" & CStr(mLastFailedPoint) & ";" & CStr(mLastFailedSide)
        End If
        fraction = fraction * 0.5
    Loop
    If found Then
        WriteHardRankRowTest "ARC31-OUTCOME;BALANCED_SAME_STATION_BRANCH"
    Else
        WriteHardRankRowTest "ARC31-OUTCOME;NO_SAME_BRANCH_BALANCE"
    End If
End Sub
