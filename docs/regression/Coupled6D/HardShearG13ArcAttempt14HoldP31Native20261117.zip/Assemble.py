"""Готовит альтернативную малую поправку из точного архива ARC56."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ARCHIVE = REPO/'tmp/hs-arc56/proof/HardShearG13SerialArcAttempt14DirectionNative20261117.zip'
BASE_SHA = '6CA5C64823399B7385635AA50F31C132A221164C47DE8D8E96B42DBC23037318'
REPORT_SHA = '2378A37CF7B42ADDEF6D7871B50DA6C317482E84C0DA8D2D2DDFF695E91C5A8B'
SOLVER = 'src/Solver/CCoupledNewtonSolver.cls'

def sha(data):
    return sha256(data).hexdigest().upper()

def txt(data):
    return data.decode('utf-8-sig').replace('\r\n','\n')

def once(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)

def seal(base,name,data):
    out=base/name
    out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():
        assert out.read_bytes()==data,name
    else:
        out.write_bytes(data)
    return sha(data)

def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--destination',type=Path,default=HERE/'ready')
    parser.add_argument('--with-workbook',action='store_true')
    args=parser.parse_args()
    dest=args.destination.resolve()
    assert dest.is_relative_to(HERE) or dest.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(ARCHIVE.read_bytes())==BASE_SHA
    with ZipFile(ARCHIVE) as base:
        prev=json.loads(base.read('Fixture.json'))
        report=base.read('Native/Order10/Verification.json')
        trace=base.read('Native/Order10/HardG14Direction.csv')
        assert sha(report)==REPORT_SHA and json.loads(report)['native_trace_sha256']==sha(trace)
        book=(REPO/prev['workbook']).read_bytes()
        assert sha(book)==prev['source_workbook_sha256']
        files={}
        files['PreviousARC56/Verification.json']=seal(dest,'PreviousARC56/Verification.json',report)
        files['PreviousARC56/HardG14Direction.csv']=seal(dest,'PreviousARC56/HardG14Direction.csv',trace)
        for name,digest in prev['inputs'].items():
            data=base.read(name)
            assert sha(data)==digest,name
            if name=='Stage.py':
                continue
            if name==SOLVER:
                code=txt(data)
                marker='    WriteHardArc56RowTest "ROLLBACK;"'
                code=once(code,marker,'    CheckHardArc31Test field, lambda, norm, tolerance\n'+marker)
                hooks=txt((HERE/'Hooks31.bas').read_bytes()).rstrip()
                assert hooks.encode('cp1251') and max(map(len,hooks.splitlines()))<240
                data=(code.rstrip()+'\n\n'+hooks+'\n').replace('\n','\r\n').encode('utf-8')
            elif name=='Verify.py':
                code=txt(data).replace('import ExtendedProof as extra','import ExtendedProof as extra\nimport Hold31Proof as p31')
                code=once(code,"        if line.startswith('ARC56-'):","        if line.startswith(('ARC56-','ARC31-')):")
                code=once(code,'    row56.inputs(fixture, extract)','    row56.inputs(fixture, extract)\n    p31.inputs(fixture)')
                code=once(code,"    output=folder/'Verification.json'","    result['hold_p31_minus']=p31.verify(path, geometry)\n    output=folder/'Verification.json'")
                data=code.encode()
            elif name=='Run.ps1':
                data=txt(data).replace('HardArc56','HardArc31').encode()
            files[name]=seal(dest,name,data)
        for name in ('Assemble.py','Hooks31.bas','Hold31Proof.py'):
            files[name]=seal(dest,name,(HERE/name).read_bytes())
        if args.with_workbook:
            seal(dest,prev['workbook'],book)
            seal(dest,'docs/regression/Diagnostic.xlsm',book)
            for name in ('Native/Order10','Temp'):
                (dest/name).mkdir(parents=True,exist_ok=True)
    manifest={**prev,'inputs':files,'watchdog_seconds':200,
              'exact_previous_arc56_sha256':BASE_SHA,'exact_previous_arc56_report_sha256':REPORT_SHA,
              'scope':'same attempt14 exact history, bounded p31/-1 trial-yield equality probe, no commits'}
    print(dest,seal(dest,'Fixture.json',(json.dumps(manifest,indent=2)+'\n').encode()))

if __name__=='__main__':
    main()
