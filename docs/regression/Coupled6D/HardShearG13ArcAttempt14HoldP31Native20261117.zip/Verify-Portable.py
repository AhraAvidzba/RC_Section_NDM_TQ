"""Сверяет архив HardArc31 и восстанавливает исходную пробу без Excel."""

from argparse import ArgumentParser
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import PortableSupport as p

HERE=Path(__file__).resolve().parent
SUMS='SHA256SUMS.json'


def safe_path(name):
    path=Path(name)
    assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
    assert path.suffix.lower()!='.xlsm'
    return path


def replay(folder,baseline):
    expected=p.load((folder/SUMS).read_bytes())
    entries={path.relative_to(folder).as_posix():path.read_bytes() for path in folder.rglob('*') if path.is_file()}
    assert set(entries)==set(expected)|{SUMS}
    for name,digest in expected.items():
        safe_path(name)
        assert p.digest(entries[name])==digest,name
    files=p.restore_files(entries,p.baseline_members(baseline))
    assert p.REPORT in files and p.TRACE in files
    receipt=p.load(files[p.REPORT])
    assert receipt['native_trace_sha256']==p.digest(files[p.TRACE])
    with TemporaryDirectory(prefix='expanded-',dir=folder.parent) as name:
        target=Path(name)
        for filename,data in files.items():
            out=target/safe_path(filename)
            out.parent.mkdir(parents=True,exist_ok=True)
            out.write_bytes(data)
        completed=run([sys.executable,'-B','-X','utf8','Verify.py','--order','10'],cwd=target,stdout=PIPE,check=True)
        assert (target/p.REPORT).read_bytes()==files[p.REPORT]
    assert 'OFFLINE PASS' in completed.stdout.decode('utf-8')
    proof=receipt['hold_p31_minus']
    assert receipt['status']=='PASS' and receipt['terminal']=='MINIMUM_RADIUS'
    assert receipt['accepted_count']==9 and proof['exact_prior_trace'] and proof['restored_history_values']==9744
    assert not receipt['physical_limit_certified'] and not proof['committed']
    print(p.json_bytes(proof).decode().strip())
    print(f'HARDSHEAR_ARC31_PORTABLE: VERIFIED_EVIDENCE; {proof["conclusion"]}; physical_limit_certified=False')


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('arc56',type=Path)
    args=cli.parse_args()
    replay(HERE,args.arc56)


if __name__=='__main__':
    main()
