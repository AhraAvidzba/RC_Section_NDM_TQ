# Собирает конечные протоколы отдельной книги и её панельные поля.
param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference='Stop'
$native=Join-Path $Source 'Native'
$json=Join-Path $native 'MVTGaussMixed.txt.ProcessClosure.json'
$closure=Get-Content -LiteralPath $json -Raw | ConvertFrom-Json
if ($closure.Stage -eq 'TIMEOUT') {
    $closed = $closure.After.State -ceq 'Absent'
} elseif ($closure.Stage -eq 'AFTER_CHILD_EXIT') {
    $closed = $closure.Closure.FinalState.State -ceq 'Absent'
} else {
    $closed = $false
}
if (!$closed) {throw 'Закрытие собственного Excel ещё не проверено.'}
New-Item -ItemType Directory -Path "$Destination/Native","$Destination/tests","$Destination/src/Materials" | Out-Null
foreach($name in @('Run-Native.ps1','Preparation.json','Run.ndjson','Compile.log','CompileClosure.json',
                    'tests/modTestMVT2GaussSpan.bas','src/Materials/CCoupledConcreteResponse.cls')) {
    Copy-Item -LiteralPath "$Source/$name" -Destination "$Destination/$name"
}
Copy-Item -LiteralPath "$Source/docs/regression/CodeUpdate.json" -Destination "$Destination/CodeUpdate.json"
foreach($name in @('MVTGaussMixed.csv','MVTGaussMixed.txt','MVTGaussMixed.txt.memory.json',
                    'MVTGaussMixed.txt.Ownership.json','MVTGaussMixed.txt.ProcessClosure.json',
                    'MVTGaussMixed.txt.RunnerCleanup.json','MVTGaussMixed.txt.stdout.log')) {
    $file=Join-Path $native $name
    if (Test-Path -LiteralPath $file) {Copy-Item -LiteralPath $file -Destination "$Destination/Native/$name"}
}
$wire=Join-Path $native 'PanelWeights.csv'
if (!(Test-Path -LiteralPath $wire)) {
    $fixtureEntry=@(Get-Content -LiteralPath "$native/MVTGaussMixed.txt" -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixtureEntry.Count -ne 1) {throw 'В журнале требуется одна частная книга.'}
    $fixture=Split-Path -Parent $fixtureEntry[0].Substring('FIXTURE: '.Length)
    $actual=([System.IO.Path]::GetFullPath($fixture))
    $required=([System.IO.Path]::GetFullPath((Join-Path $Source 'Temp')))+'\'
    if (!$actual.StartsWith($required,[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь вне частной папки Temp.'}
    $wire=Join-Path $actual 'MVT2GaussSpan.csv.Dilation.csv'
}
Copy-Item -LiteralPath $wire -Destination "$Destination/Native/PanelWeights.csv"
