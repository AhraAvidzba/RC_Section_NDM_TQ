"""Готовит нативный контроль роли растяжения в дилатансии пяти панелей."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


HERE=Path(__file__).resolve().parent
CLASS='src/Materials/CCoupledConcreteResponse.cls'
TEST='tests/modTestMVT2GaussSpan.bas'


def material_test_wire(raw):
    """Добавляет параметр только в частную проверку, сохраняя значение 20 при подготовке бетона."""
    text=raw.decode('utf-8').replace('\r\n','\n')
    assert text.count('MIXED_DAMAGE_WEIGHT')==4
    text=text.replace('MIXED_DAMAGE_WEIGHT','mTestMixedDamageWeight')
    text=text.replace('Private Const mTestMixedDamageWeight As Double = 20#','Private mTestMixedDamageWeight As Double')
    anchor='    mPointCount = pointCount\n'
    assert text.count(anchor)==1
    text=text.replace(anchor,'    mTestMixedDamageWeight = 20#\n'+anchor)
    addition='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Задаёт вес растяжения в смешанной мере до первого шага панели.
Friend Sub TestSetMixedDilationWeight(ByVal value As Double)
    If value < 0# Then Err.Raise 5, , "Вес растяжения должен быть неотрицательным."
    mTestMixedDamageWeight = value
End Sub
'''
    addition.encode('cp1251')
    text+=addition
    return text.replace('\n','\r\n').encode('utf-8')


def stage(repo,root):
    base=run_path(str(HERE/'Stage-UnconfinedH35.py'))
    base['stage'](repo,root,False)
    material=root/CLASS
    material.write_bytes(material_test_wire(material.read_bytes()))
    test=root/TEST
    text=test.read_text(encoding='utf-8-sig')
    marker='completed = TestUnconfinedH35(report, tracePath)'
    assert text.count(marker)==1
    text=text.replace(marker,'completed = TestMixedPanelWeight(report, tracePath)')
    # Исключаем специализированный одноосный сценарий из новой книги.
    boundary="' Повторяет монотонное сжатие цилиндра H35_01 при свободных боковых гранях."
    index=text.index(boundary)
    header=text.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,index)
    text=text[:header]+(HERE/'MixedPanelWeight.bas.txt').read_text(encoding='utf-8')
    text.encode('cp1251')
    test.write_bytes(text.replace('\n','\r\n').encode('utf-8-sig'))
    driver=root/'Run-Native.ps1'
    driver.write_bytes(driver.read_text(encoding='utf-8').replace('Native/UnconfinedH35.csv','Native/PanelWeights.csv').encode('utf-8'))
    meta=root/'Preparation.json'
    data=json.loads(meta.read_bytes())
    del data['specimen']
    data['panels']=['PV13','PV16','PV23','PV25','PV28']
    data['mixed_weights']=[20,10,5]
    for item in (test,material,driver):
        data['inputs'][item.relative_to(root).as_posix()]=sha256(item.read_bytes()).hexdigest().upper()
    meta.write_bytes((json.dumps(data,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',required=True,type=Path)
    args=parser.parse_args()
    stage(args.repo.resolve(),args.stage.resolve())
