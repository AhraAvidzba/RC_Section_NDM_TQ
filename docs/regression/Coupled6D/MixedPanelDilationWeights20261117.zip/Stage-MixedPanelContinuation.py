"""Меняет только прогноз и производную в контрольном решателе панелей."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


HERE=Path(__file__).resolve().parent


def stage(repo,root):
    base=run_path(str(HERE/'Stage-MixedPanelWeight.py'))
    base['stage'](repo,root)
    test=root/base['TEST']
    code=test.read_text(encoding='utf-8-sig')
    anchor="' Повторяет испытания Vecchio и Collins"
    p=code.index(anchor)
    prefix,code=code[:p],code[p:]
    code=code.replace('current(1 To 6) As Double, plastic(1 To 2)',
                      'current(1 To 6) As Double, previous(1 To 4) As Double, plastic(1 To 2)')
    code=code.replace('panel, marker, current, plastic,','panel, marker, current, previous, plastic,')
    code=code.replace('ByRef current() As Double, ByRef plastic()',
                      'ByRef current() As Double, ByRef previous() As Double, ByRef plastic()')
    first='    For i = 1 To 3: strain(i) = current(i): Next i\n    attempts = attempts + 1\n    If TestSolvePanelWeight(material, panel, strain, plastic, stress, steel) Then\n        For i = 1 To 4: current(i) = strain(i): Next i'
    assert code.count(first)==1
    code=code.replace(first,'''    Dim predictionFactor As Double, solved As Boolean
    If current(4) > previous(4) Then predictionFactor = GeomMin(2#, (gamma - current(4)) / (current(4) - previous(4)))
    For i = 1 To 3: strain(i) = current(i) + predictionFactor * (current(i) - previous(i)): Next i
    attempts = attempts + 1
    solved = TestSolvePanelWeight(material, panel, strain, plastic, stress, steel)
    If Not solved And predictionFactor > 0# Then
        For i = 1 To 3: strain(i) = current(i): Next i
        solved = TestSolvePanelWeight(material, panel, strain, plastic, stress, steel)
    End If
    If solved Then
        For i = 1 To 4: previous(i) = current(i): current(i) = strain(i): Next i''')
    code=code.replace(' i As Long, j As Long, iteration As Long, damping As Long',
                      ' i As Long, iteration As Long, damping As Long, symmetric As Boolean, size As Long')
    code=code.replace('    If Not TestPanelResidual(material, panel, strain, plastic, stress, tangent, residual, steel, trialPlastic, tangentSteel, ctmFull, currentNorm) Then Exit Function',
                      '''    symmetric = (CDbl(panel(3)) = CDbl(panel(5)) And CDbl(panel(4)) = CDbl(panel(6)))
    size = 3
    If symmetric Then size = 2: strain(2) = strain(1)
    If Not TestPanelResidual(material, panel, strain, plastic, stress, tangent, residual, steel, trialPlastic, tangentSteel, ctmStressOnly, currentNorm) Then Exit Function''')
    a=code.index('        For i = 1 To 3\n            seed(i) = strain(i): delta(i) = -residual(i)')
    b=code.index('        fraction = 1#',a)
    code=code[:a]+'''        For i = 1 To 3: seed(i) = strain(i): delta(i) = -residual(i): Next i
        If symmetric Then delta(2) = delta(3)
        If Not TestPanelNormalTangent(material, panel, strain, plastic, residual, normal, symmetric) Then Exit Function
        If Not linear.Solve(normal, delta, size) Then Exit Function
        If symmetric Then delta(3) = delta(2): delta(2) = delta(1)
'''+code[b:]
    start=code.index('        If trialNorm > TOL Then\n')
    finish=code.index('        currentNorm = trialNorm',start)
    code=code[:start]+code[finish:]
    code=prefix+code+(HERE/'PanelNormalTangent.bas.txt').read_text(encoding='utf-8')
    code.encode('cp1251')
    test.write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    driver=root/'Run-Native.ps1'
    source=driver.read_text(encoding='utf-8')
    assert source.count("$timeout='165'")==1
    driver.write_bytes(source.replace("$timeout='165'","$timeout='240'").encode('utf-8'))
    meta=root/'Preparation.json'
    data=json.loads(meta.read_bytes())
    data['normal_secant_predictor']=True
    data['normal_jacobian_step']=1e-9
    for item in (driver,test):
        data['inputs'][item.relative_to(root).as_posix()]=sha256(item.read_bytes()).hexdigest().upper()
    meta.write_bytes((json.dumps(data,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',type=Path,required=True)
    args=parser.parse_args()
    stage(args.repo.resolve(),args.stage.resolve())
