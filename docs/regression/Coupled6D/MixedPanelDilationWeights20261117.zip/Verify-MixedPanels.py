"""Сверяет равновесие панелей, сталь, тензоры и экспериментальные ориентиры."""

from argparse import ArgumentParser
from hashlib import sha256
from itertools import product
import json
from math import fsum, isfinite
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


PIN='MVT2NativePublicationCutMaterialHistory20261117.zip'
PIN_SHA='6920EB24A5D01585E510FDBC1064513C0C83AA62583AEB0C2553D6F0D495EE55'
CLASS='src/Materials/CCoupledConcreteResponse.cls'
TEST='tests/modTestMVT2GaussSpan.bas'
WEIGHTS=(20,10,5)


def digest(data):
    return sha256(data).hexdigest().upper()


def load_sources(repo,root):
    """Привязывает измерения к двум первичным таблицам и рисункам 9 и 10."""
    data=json.loads((root/'PublishedPanels.json').read_bytes())
    for label,filename in (('primary','Vecchio-Collins-1986-Primary-Panels.pdf'),
                           ('competition','Collins-Vecchio-Mehlhorn-1985-PanelCompetition.pdf')):
        path=repo/'literature/Coupled6D'/filename
        if path.is_file():
            assert digest(path.read_bytes())==data[label+'_sha256']
    pixels=json.loads((root/'MeasuredPVShear.json').read_bytes())
    digitizer=run_path(str(root/'Digitize-PVShear.py'))
    if (repo/digitizer['PAPER']).is_file():
        assert digitizer['digitize'](repo)==pixels
    return data,pixels


def validate_owner(root,read,stock,book):
    """Устанавливает завершение нужной копии Excel по PID и метке запуска."""
    native=root/'Native'
    compiler=read(root/'CodeUpdate.json')
    owner=read(native/'MVTGaussMixed.txt.Ownership.json')
    closure=read(native/'MVTGaussMixed.txt.ProcessClosure.json')
    log=(native/'MVTGaussMixed.txt').read_text('utf-8-sig')
    assert compiler['ProductionSHA256']==book and not compiler['ProductionChanged'] and compiler['Compiled']
    assert compiler['WorkbookSHA256']==owner['SourceSHA256']
    assert set(compiler['Modules'])=={'modTestMVT2GaussSpan','CCoupledConcreteResponse',
                                     'CCoupledElasticState','CCoupledSectionQuadrature'}
    assert read(root/'CompileClosure.json')['State']=='Absent'
    assert owner['BeforeWorkbookOpen'] and owner['VerifiedNewOwner']
    assert 'RUNTIME ERROR:' not in log and f"TEST_EXCEL_PROCESS: id={owner['PID']}; startTicks={owner['StartTicksUTC']}" in log
    if closure['Stage']=='AFTER_CHILD_EXIT':
        assert closure['Passed'] and closure['ChildExitCode']==0 and closure['RunnerCleanupValid']
        assert closure['Closure']['FinalState']['State']=='Absent'
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
        identity=closure['Closure']['Identity']
        termination='completed'
    else:
        assert closure['Stage']=='TIMEOUT' and closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout']
        assert closure['After']['State']=='Absent' and closure['After']['PID']==owner['PID']
        seconds=165 if stock else 240
        assert f'WATCHDOG_FAILURE: timeout={seconds} sec;' in log and 'ownExcelState=Absent' in log
        assert int(closure['After']['StartTicksUTC'])==int(owner['StartTicksUTC'])
        identity=closure['Identity']
        termination='timeout'
    assert identity['Valid'] and identity['PID']==owner['PID'] and identity['Ticks']==int(owner['StartTicksUTC'])
    return termination,owner['PID']


def read_curves(root,terminated,material):
    """Декодирует полные записи. При таймере разрешена одна оборванная строка в конце."""
    rows=(root/'Native/PanelWeights.csv').read_text('ascii').splitlines()
    models,states,partial={},{},0
    for i,row in enumerate(rows):
        kind,*data=row.split(';')
        needed=6 if kind=='MODEL' else 33
        if len(data)!=needed:
            assert terminated=='timeout' and i==len(rows)-1 and len(data)<needed
            partial=1
            break
        name,weight,*values=data
        key=name,int(weight)
        if kind=='MODEL':
            assert key not in models
            model=tuple(map(float,values))
            fc=material[name][0]
            e=10000.*(.8+.2*(fc+8.)/88.)*(fc+8.)**(1./3.)
            ft=.302*fc**(2./3.); gt=.073*fc**.18; gc=(fc/ft)**2*gt
            assert max(abs(a-b) for a,b in zip(model,(e,ft,gt,gc),strict=True)) < 2e-9
            models[key]=model
            states[key]=[]
        else:
            assert kind=='STATE' and int(values[0])==len(states[key])+1
            d=tuple(map(float,values[1:]))
            assert all(map(isfinite,d))
            states[key].append(d)
    return models,states,partial


def reconstruct(values,modulus,principal):
    """Повторяет восстановление номинального тензора из пластики и повреждений."""
    eps=tuple(a-b for a,b in zip(values[:6],values[16:22],strict=True))
    mu=modulus/2.4
    lam=modulus*.2/(1.2*.6)
    e=(*[2.*mu*x+lam*fsum(eps[:3]) for x in eps[:3]],*[mu*x for x in eps[3:]])
    spectrum=principal(e)
    r=fsum(x for x in spectrum if x>0.)/fsum(map(abs,spectrum))
    dt,dc=values[-4:-2]
    nominal_scale=(1.-r*dt)*(1.-dc)
    delta=max(abs(a-nominal_scale*b) for a,b in zip(values[6:12],e,strict=True))
    return delta,r


def check_curve(values,panel,model,weight,principal):
    """Проверяет знаки нормальных нагрузок, историю стали и насыщение материала."""
    _,_,rx,fx,ry,fy,ratio,limit,*_=panel
    last_ep=(0.,0.)
    last_k=(0.,0.)
    last_gamma=0.
    max_res,max_stress_error,max_steel_error=0.,0.,0.
    saturation=0
    for state in values:
        assert last_gamma<state[3]<=limit+5e-16 and state[4]==state[5]==state[10]==state[11]==0.
        last_gamma=state[3]
        norm=max(abs(state[6]+rx*state[12]-ratio*state[9]),abs(state[7]+ry*state[13]-ratio*state[9]),abs(state[8]))
        assert norm<=2.00005e-7
        max_res=max(max_res,norm)
        steel=tuple(min(f,max(-f,200000.*(x-p))) for f,x,p in zip((fx,fy),state[:2],last_ep,strict=True))
        last_ep=tuple(x-s/200000. for x,s in zip(state[:2],steel,strict=True))
        error=max(abs(a-b) for a,b in zip((*steel,*last_ep),state[12:16],strict=True))
        assert error<1e-8
        max_steel_error=max(max_steel_error,error)
        reconstruction,r=reconstruct(state,model[0],principal)
        assert reconstruction<2e-9
        max_stress_error=max(max_stress_error,reconstruction)
        kt,kc=state[-2:]
        assert all(b>=a-1e-14 for a,b in zip(last_k,(kt,kc)))
        last_k=(kt,kc)
        assert 0.<=kt<=1. and 0.<=kc<=1.
        saturation+=1.-(1.-(1.+weight*r)*kt)*(1.-(1.-r)*kc)>=1.
    return {'normal_residual_MPa':max_res,'nominal_reconstruction_error_MPa':max_stress_error,
            'steel_history_stress_difference_MPa':max_steel_error,'saturation_count':saturation}


def at_gamma(values,gamma):
    """Интерполирует между принятыми состояниями без экстраполяции."""
    older=(0.,)*30
    for value in values:
        if value[3]>=gamma:
            fraction=(gamma-older[3])/(value[3]-older[3])
            return [a+fraction*(b-a) for a,b in zip(older,value,strict=True)]
        older=value
    return None


def metrics(name,points,published,pixels):
    """Описывает максимум принятых состояний и покрытие измеренных координат."""
    if not points:
        return None
    index=max(range(len(points)),key=lambda i:points[i][9])
    location=points[index]
    p=published['panels'][name]
    checkpoints=pixels.get(name,[])
    if name=='PV25':
        checkpoints=[{'gamma':g,'tau_MPa':tau,'ex':ex,'ey':ey} for tau,ex,ey,g in published['PV25_measured_strains']]
    compared=[]
    for point in checkpoints:
        matched=at_gamma(points,point['gamma'])
        compared.append(point | {'tau_calculated_MPa':matched[9] if matched else None,
                                 'ex_calculated':matched[0] if matched else None,'ey_calculated':matched[1] if matched else None})
    return {'states':len(points),'last_gamma':points[-1][3],'observed_maximum_MPa':location[9],
            'gamma_at_observed_maximum':location[3],'observed_descending_points':len(points)-1-index,
            'experimental_maximum_MPa':p[9],'simulation_steel_over_yield_strain':
                [location[0]*200000./p[3],location[1]*200000./p[5] if p[5] else None],
            'experimental_steel_over_yield_strain':p[10:12],'comparisons':compared}


def verify_run(repo,root,material,sources,utility,base,stage,stock):
    """Проверяет нативный запуск и собирает характеристики всех завершённых маршрутов."""
    read=utility['read']
    prep=read(root/'Preparation.json')
    assert prep['mixed_weights']==list(WEIGHTS) and prep['panels']==list(material)
    assert prep.get('normal_secant_predictor',False)==(not stock)
    assert (root/CLASS).read_bytes()==stage['material_test_wire'](base)
    for path in (CLASS,TEST,'Run-Native.ps1'):
        assert digest((root/path).read_bytes())==prep['inputs'][path]
    termination,pid=validate_owner(root,read,stock,utility['BOOK'])
    models,states,partial=read_curves(root,termination,material)
    plan=list(product(material,WEIGHTS))
    assert list(models)==plan[:len(models)] and models
    finished={}
    trace=(root/'Native/MVTGaussMixed.csv').read_text('cp1251')
    for line in trace.splitlines():
        if line.startswith('PANEL_WEIGHT_STATUS;'):
            _,name,weight,ok,accepted,repeated,last,target=line.split(';')
            key=name,int(weight)
            assert key in states and int(accepted)==len(states[key])
            assert states[key][-1][3]==float(last)
            assert int(repeated)>=int(accepted)
            if ok=='True':
                assert float(target)==float(last)==material[name][7]
            else:
                assert ok=='False' and float(target)>float(last)
            finished[key]={'target_achieved':ok=='True','attempts':int(repeated),'last_nominal_target':float(target)}
    if termination=='completed':
        assert list(finished)==plan and 'CASE_FINISHED;MVTGaussMixed;True;' in trace
    else:
        assert 'CASE_FINISHED;' not in trace and len(models)-len(finished)<=1
    output={}
    for (name,weight),points in states.items():
        histories=check_curve(points,material[name],models[name,weight],weight,utility['principal'])
        output[f'{name}-{weight}']={'states_check':histories,'metrics':metrics(name,points,*sources),
                                    'explicit_status':finished.get((name,weight))}
    return {'termination':termination,'excel_pid':pid,'incomplete_trailing_lines':partial,
            'macro_seconds':next((float(line.split(';')[3]) for line in trace.splitlines()
                                  if line.startswith('CASE_FINISHED;')),None),
            'verified_states':sum(map(len,states.values())),'cases':output}


def verify(repo,root):
    path=repo/'docs/regression/Coupled6D'/PIN
    assert digest(path.read_bytes())==PIN_SHA
    utility={'__name__':'__pinned__'}
    with ZipFile(path) as archive:
        exec(compile(archive.read('Verify-NativeMaterialHistory.py'),PIN,'exec'),utility)
        base=archive.read(CLASS)
    published,pixels=load_sources(repo,root)
    stage=run_path(str(root/'Stage-MixedPanelWeight.py'))
    return {key:verify_run(repo,root/key,published['panels'],(published,pixels),utility,base,stage,key=='Stock')
            for key in ('Stock','NormalContinuation')}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args()
    result=verify(args.repo.resolve(),args.root.resolve())
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(result,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('MIXED PANELS NATIVE OFFLINE PASS',*(r['verified_states'] for r in result.values()))
