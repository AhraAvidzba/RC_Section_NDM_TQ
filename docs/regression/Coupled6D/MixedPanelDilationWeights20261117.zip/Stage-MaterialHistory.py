"""Создаёт тестовую копию с чтением истории бетона без изменения алгоритма."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import json


HERE = Path(__file__).resolve().parent
EVIDENCE = 'MVT2NativePublicationCutSplit20261117.zip'
EVIDENCE_SHA = 'B90505E21FA5E7735B91374512602B901A4864F4F0C23D7191028F87268B8F46'
CLASS = 'src/Materials/CCoupledConcreteResponse.cls'


def digest(data):
    return sha256(data).hexdigest().upper()


def stage(repo, root):
    pinned = repo / 'docs/regression/Coupled6D' / EVIDENCE
    assert digest(pinned.read_bytes()) == EVIDENCE_SHA
    temp = repo / 'tmp'
    with TemporaryDirectory(dir=temp, prefix='stage-material-history-') as folder:
        work = Path(folder)
        with ZipFile(pinned) as z:
            for name in ('Stage-Recovery.py', 'PublicationRecovery.bas.txt'):
                (work / name).write_bytes(z.read(name))
        stage_base = run_path(str(work / 'Stage-Recovery.py'))
        stage_base['stage'](repo, root, False, False)

    test = root / 'tests/modTestMVT2GaussSpan.bas'
    module = test.read_text(encoding='utf-8-sig')
    anchor = '    ReDim seedValues(1 To 60)'
    assert module.count(anchor) == 1
    module = module.replace(anchor,
        '    TestPublicationRecovery = TestPublicationMaterialHistory(solver, operators, concrete, history, report, tracePath)\n'
        '    Exit Function\n' + anchor)
    module += (HERE / 'MaterialHistoryTest.bas.txt').read_text(encoding='utf-8-sig')
    module.encode('cp1251')
    test.write_bytes(module.replace('\n','\r\n').encode('utf-8-sig'))
    original = (repo / CLASS).read_bytes()
    material = original.decode('utf-8').replace('\r\n','\n')
    addition = (HERE / 'MaterialHistoryMethod.cls.txt').read_text(encoding='utf-8')
    addition.encode('cp1251')
    material += addition
    baked = root / CLASS
    baked.parent.mkdir(parents=True, exist_ok=True)
    baked.write_bytes(material.replace('\n','\r\n').encode('utf-8'))
    driver = root / 'Run-Native.ps1'
    powershell = driver.read_text(encoding='utf-8')
    old = "'CCoupledElasticState','modTestMVT2GaussSpan'"
    assert powershell.count(old) == 1
    driver.write_bytes(powershell.replace(old, old + ",'CCoupledConcreteResponse'").encode('utf-8'))
    info = root / 'Preparation.json'
    data = json.loads(info.read_bytes())
    data['material_base_sha256'] = digest(original)
    for file in (test, baked, driver):
        data['inputs'][file.relative_to(root).as_posix()] = digest(file.read_bytes())
    info.write_bytes((json.dumps(data,indent=2)+'\n').encode())
    print('MATERIAL HISTORY PREPARED', data['material_base_sha256'], flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--stage', type=Path, required=True)
    options = parser.parse_args()
    stage(options.repo.resolve(), options.stage.resolve())
