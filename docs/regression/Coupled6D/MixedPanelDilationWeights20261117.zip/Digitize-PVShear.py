"""Снимает экспериментальные пунктирные кривые PV13 и PV16 с рисунков авторов."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from statistics import median


PAPER='literature/Coupled6D/Poliotti-Bairan-2019-Evolutive-dilatancy.pdf'
SHA='55B25E1C0EF995543E8F7414F04BE670B112C294A9C69D02C1ECE20EC9E0A08D'
TARGETS={'PV13':(.001,.002,.004,.006,.008,.009),'PV16':(.001,.002,.003,.004,.006,.008,.010)}


def digitize(repo):
    """Выбирает слои с экспериментом и пересчитывает пиксели по меткам осей."""
    import fitz
    from PIL import Image

    paper=repo/PAPER
    assert sha256(paper.read_bytes()).hexdigest().upper()==SHA
    result={}
    with fitz.open(paper) as doc:
        for name,page,index in (('PV13',18,3),('PV16',19,0)):
            reference=doc[page].get_image_info(xrefs=True)[index]
            original=doc.extract_image(reference['xref'])
            image=Image.open(BytesIO(original['image'])).convert('RGB')
            assert image.size==(802,627)
            x0,x20,y0,y10=105,783,510,21
            wire=[]
            for gamma in TARGETS[name]:
                center=x0+gamma/.020*(x20-x0)
                # Максимум 2,14 МПа оставляет рабочее окно ниже цветных линий модели.
                matching=[]
                for x in range(round(center)-8,round(center)+9):
                    column=[]
                    for y in range(394,470):
                        rgb=image.getpixel((x,y))
                        if max(rgb)<160 and max(rgb)-min(rgb)<8:
                            column.append(y)
                    if column:
                        matching.append((abs(x-center),median(column)))
                assert matching
                nearest, row=min(matching)
                wire.append({'gamma':gamma,'tau_MPa':(y0-row)*10./(y0-y10),
                             'point_pixel_distance_x':nearest,'pixel_resolution_MPa':10./(y0-y10)})
            result[name]=wire
    return result


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args()
    result=digitize(args.repo.resolve())
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(result,output,indent=2,sort_keys=True)
        output.write('\n')
