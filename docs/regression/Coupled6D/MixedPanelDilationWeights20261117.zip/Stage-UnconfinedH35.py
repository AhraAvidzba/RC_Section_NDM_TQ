"""Готовит отдельную копию Excel для контрольного цилиндра Осорио H35_01."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent


def stage(repo, root, strict):
    base = run_path(str(HERE / 'Stage-MaterialHistory.py'))
    base['stage'](repo, root)
    test = root / 'tests/modTestMVT2GaussSpan.bas'
    text = test.read_text(encoding='utf-8-sig')
    entry = 'completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True)'
    assert text.count(entry) == 1
    text = text.replace(entry, 'completed = TestUnconfinedH35(report, tracePath)')
    test_body = (HERE / 'UnconfinedH35.bas.txt').read_text(encoding='utf-8')
    if strict:
        test_body = test_body.replace('Const STRESS_TOL As Double = 0.0000001', 'Const STRESS_TOL As Double = 0.00000001')
    text += test_body
    text.encode('cp1251')
    test.write_bytes(text.replace('\n', '\r\n').encode('utf-8-sig'))
    driver = root / 'Run-Native.ps1'
    content = driver.read_text(encoding='utf-8')
    old = ('    $tensorWire=$trace+\'.Tensor.csv\'\n'
           '    Copy-Item -LiteralPath $tensorWire -Destination "Native/$Case.Tensor.csv"\n'
           '    Copy-Item -LiteralPath ($trace+\'.Operators.csv\') -Destination "Native/Operators.csv"\n')
    assert content.count(old) == 1
    driver.write_bytes(content.replace(old,
        '    Copy-Item -LiteralPath ($trace+\'.Dilation.csv\') -Destination "Native/UnconfinedH35.csv"\n').encode('utf-8'))
    info = root / 'Preparation.json'
    prep = json.loads(info.read_bytes())
    prep['specimen'] = 'H35_01'
    for path in (test, driver):
        prep['inputs'][path.relative_to(root).as_posix()] = base['digest'](path.read_bytes())
    info.write_bytes((json.dumps(prep, indent=2) + '\n').encode('utf-8'))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--stage', required=True, type=Path)
    parser.add_argument('--strict', action='store_true')
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve(), args.strict)
