"""Повторяет MVT2 в расчётном сечении на расстоянии h₀ от середины пролёта."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys


REPO = Path(__file__).resolve().parents[2]
EVIDENCE = REPO / 'docs/regression/Coupled6D'
SOURCE = REPO / 'tmp/mvt-asd-equilibrium'
NATIVE = Path('D:/CodexScratch/RC_Section_NDM_TQ')
ASD = 'MVT2GaussReequilibratedASD20261117.zip'
STEEL = 'MVT2GaussASDNominalPostyield20261117.zip'
PDF = REPO / 'literature/Coupled6D/Wang-Huang-2017-MVT-NMVT.pdf'
INPUTS = {
    ASD: 'FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E',
    STEEL: '06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED',
    'operators': '3E8C00B7AC650B9FF6BBF55C412AED9A18A258BCEE3083D58ECEA9B7A07B653A',
    'paper': '6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E',
}


def digest(contents):
    return sha256(contents).hexdigest().upper()


def write_json(path, document):
    with path.open('x', encoding='utf-8', newline='\n') as fd:
        json.dump(document, fd, indent=2, sort_keys=True, allow_nan=False)
        fd.write('\n')


def run(output, tensors, arm, fine_tail):
    """Меняет только номинальное плечо после общего этапа чистого кручения."""
    operator_file = NATIVE / 'MVTGauss25Operators/Native/Operators.csv'
    assert digest(operator_file.read_bytes()) == INPUTS['operators']
    assert digest(PDF.read_bytes()) == INPUTS['paper']
    assert all(digest((EVIDENCE / name).read_bytes()) == INPUTS[name] for name in (ASD, STEEL))
    with ZipFile(EVIDENCE / ASD) as z:
        for filename in ('Reequilibrate.py', 'Operators.py'):
            assert (SOURCE / filename).read_bytes() == z.read(filename)
        original = json.loads(z.read('Authoritative.json'))['modes']['default']
        prefix_stress = json.loads(gzip.decompress(z.read('Authoritative.stress.json.gz')))['default'][:8]
    with ZipFile(EVIDENCE / STEEL) as z:
        text = z.read('Postyield.py')
    steel_module = {'__name__': '__replay__', '__file__': str(Path(__file__).with_name('Postyield.py'))}
    exec(compile(text, steel_module['__file__'], 'exec'), steel_module)
    sys.path.insert(0, str(NATIVE / 'CoupledEvidencePython'))
    sys.path.insert(0, str(SOURCE))
    import numpy as np
    import openseespy.opensees as ops

    assert (np.__version__, ops.version()) == ('2.3.5', '3.8.0')
    program = runpy.run_path(str(SOURCE / 'Reequilibrate.py'))
    shared, native, geom, dirs, area, length, op, seeds, _, identity = program['read_inputs'](
        operator_file, NATIVE / 'MVTGauss25Tensors')
    solve = program['simulate']
    model = solve.__globals__
    discard = model['test_discard']
    model['test_discard'] = lambda kit, command, trial, stages: discard(kit, command, trial, native['frames'])
    model['loads'] = lambda arrays, t, q: arrays.array((0., -arm * q, 0., t, 0., q))
    steel = []
    model['Section'] = steel_module['steel_section'](model['Section'], np, steel)
    requested = (*range(2500, 80001, 2500), 82340.)
    if fine_tail:
        requested = (*range(2500, 75001, 2500), *(75000. + 5000. * j / 64. for j in range(1, 65)), 82340.)
    targets = [{'phase': f'SectionQ{q / 1000:g}', 'T_Nmm': 10510000., 'Qy_N': q} for q in requested]
    case = {**native, 'frames': [*native['frames'][:8], *targets]}
    args = program['commands'](shared, native, ('default',))['default']
    try:
        result, stress = solve(np, ops, shared, case, geom, dirs, area, length, op, seeds, 'default',
                               args, perf_counter() + 95., len(case['frames']))
    finally:
        ops.wipe()
    assert len(result['accepted']) == len(stress) == len(steel)
    assert steel_module['compare_replay'](original['accepted'][:8], result['accepted'][:8])
    assert stress[:8] == prefix_stress
    assert result['rejected_trial_interleaving_max_MPa'] == 0.
    wire = gzip.compress(steel_module['record_bytes']({'stress': stress, 'steel': steel}), mtime=0)
    with tensors.open('xb') as fd:
        fd.write(wire)
    write_json(output, {
        'arm_mm': arm, 'original_torsion_prefix_bit_exact': 8, 'inputs': INPUTS,
        'requested_Qy_N': requested, 'fine_tail': fine_tail, 'ASD_engine': ops.version(), 'numpy': np.__version__,
        'physical_limit_established': False, 'operators': identity, 'stress_sha256': digest(wire),
        'result': result,
    })
    print('ACCEPTED', len(result['accepted']), result['last_confirmed'], result['terminal'], flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--report', required=True, type=Path)
    parser.add_argument('--tensors', required=True, type=Path)
    parser.add_argument('--arm-mm', type=float, required=True)
    parser.add_argument('--fine-tail', action='store_true')
    args = parser.parse_args()
    run(args.report, args.tensors, args.arm_mm, args.fine_tail)
