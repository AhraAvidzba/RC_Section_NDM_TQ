"""Независимо восстанавливает невязку повторной материальной пробы MVT2."""

from argparse import ArgumentParser
from hashlib import sha256
from math import fsum, isclose
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import gzip
import json
import runpy
import sys


HERE = Path(__file__).resolve().parent
BASE = 'MVT2PublicationCut20261117.zip'
BASE_SHA = '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD'
ASD = 'MVT2GaussReequilibratedASD20261117.zip'
ASD_SHA = 'FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E'
WIRE_SHA = '5E2DE4CC76104AD6DCE581A355BAD9A4B77B30B3E2061DF2F121CB41C35DFCE9'


def pinned(path, expected):
    wire = path.read_bytes()
    assert sha256(wire).hexdigest().upper() == expected, path.name
    return wire


def evaluate(op, geo, area, length, signed, record, stress):
    """Собирает четыре связи, 56 слабых уравнений и шесть усилий."""
    q = record['Q_target_N']
    wanted = (0., -396. * q, 0., record['T_target_Nmm'], 0., q)
    demand = [fsum(row[j] * load for row, load in zip(op['L'], wanted, strict=True))
              for j in range(60)]
    field = record['field']
    derivative = [[500. * (a - b) for a, b in zip(side_plus, side_minus, strict=True)]
                  for side_plus, side_minus in zip(stress[1], stress[2], strict=True)]
    residual = []
    for i in range(60):
        center = (v[i] * sig for point, cube in zip(op['S'], stress[0], strict=True)
                  for v, sig in zip(point, cube, strict=True))
        gradient = (v[i] * ds for point, cube in zip(op['R'], derivative, strict=True)
                    for v, ds in zip(point, cube, strict=True))
        gauge = (v * x for v, x in zip(op['G'][i], field, strict=True))
        residual.append(fsum((*center, *gradient, *gauge)) - demand[i])
    six = signed(stress[0], geo)
    force_scales = (area, area * length, area * length, area * length, area, area)
    force = max(abs(x - y) / factor for x, y, factor in zip(six, wanted, force_scales, strict=True))
    norm = max(force, max(map(abs, residual[:56])), 30000. * max(map(abs, residual[56:])))
    return norm, 5e-7 + 5e-7 * max(map(abs, demand)), list(six)


def verify(repo):
    """Проверяет опорную точку, повтор с нулевым шагом и оба журнала проб."""
    evidence = repo / 'docs/regression/Coupled6D'
    pinned(evidence / BASE, BASE_SHA)
    pinned(evidence / ASD, ASD_SHA)
    small_wire = pinned(HERE / 'Cut396TwistSmall.stress.json.gz', WIRE_SHA)
    assert small_wire == pinned(HERE / 'Cut396TwistWide.stress.json.gz', WIRE_SHA)
    zero = json.loads(gzip.decompress(small_wire))
    assert zero['stress'] == zero['steel'] == []
    with ZipFile(evidence / BASE) as cut:
        accepted = json.loads(cut.read('Cut396.json'))['result']['accepted']
        stress = json.loads(gzip.decompress(cut.read('Cut396.stress.json.gz')))['stress'][-1]
    assert len(accepted) == 41 and accepted[-1]['Q_target_N'] == 75312.5
    with TemporaryDirectory(prefix='MVT2CutTwist_') as folder:
        work = Path(folder)
        with ZipFile(evidence / ASD) as archive:
            for name in ('Verify-Authoritative.py', 'Operators.py', 'Reequilibrate.py'):
                (work / name).write_bytes(archive.read(name))
        sys.path.insert(0, str(work))
        try:
            tools = runpy.run_path(str(work / 'Verify-Authoritative.py'))
            op_path, helper = tools['unpack'](work, repo)
            engine = runpy.run_path(str(work / 'Reequilibrate.py'))
            _, _, geo, _, area, length, op, _, _, _ = engine['read_inputs'](op_path, work, helper)
        finally:
            sys.path.pop(0)
    current = accepted[-1]
    ref, tol, six = evaluate(op, geo, area, length, tools['signed_forces'], current, stress)
    assert ref <= tol and isclose(ref, current['all_weak_and_force_max_MPa'], abs_tol=3e-12)
    repeated = zero['uncommitted_zero_increment_stress']
    residual, repeated_tol, repeated_six = evaluate(op, geo, area, length, tools['signed_forces'], current, repeated)
    assert repeated_tol == tol and residual > tol
    change = max(abs(a - b) for left, right in zip(stress, repeated, strict=True)
                 for x, y in zip(left[:25], right[:25], strict=True) for a, b in zip(x, y, strict=True))

    scans = {}
    for name, count, digest in (
        ('Small', 8, 'D652081C56B804E85D5BAE91C5753C9D2D9AC248E92FBF247937A508BD3D0A09'),
        ('Wide', 4, 'CD552AAD1FB98019B86649A33465F48116ACA412125A72928350CE1E81B12856'),
    ):
        probe = json.loads(pinned(HERE / f'Cut396Twist{name}.json', digest))
        assert probe['stress_sha256'] == WIRE_SHA and probe['prefix_states_bit_exact'] == len(accepted)
        assert not probe['physical_limit_established'] and probe['accepted'] == []
        saved = probe['zero_increment_uncommitted_repeat']
        assert isclose(saved['max_concrete_stress_change_MPa'], change, abs_tol=1e-14)
        assert isclose(saved['new_norm_MPa'], residual, abs_tol=3e-12)
        assert isclose(saved['tolerance_MPa'], tol, abs_tol=1e-15)
        attempts = probe['attempts']
        assert len(attempts) == count and not any(row['accepted'] for row in attempts)
        assert all(row['reason'] == 'line_search_no_decrease' for row in attempts)
        best = min(row['norms'][-1] for row in attempts)
        assert best > tol
        scans[name] = {'attempted_steps': count, 'remaining_minimum_norm_MPa': best}
    return {'base_Qy_N': current['Q_target_N'], 'base_six': six, 'zero_repeat_six': repeated_six,
            'base_norm_MPa': ref, 'repeat_norm_MPa': residual, 'repeat_concrete_stress_change_MPa': change,
            'tolerance_MPa': tol, 'scans': scans, 'physical_limit_established': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    checked = verify(args.repo.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(checked, output, indent=2, sort_keys=True)
        output.write('\n')
    print('MVT2 CUT396 TWIST OFFLINE PASS')
