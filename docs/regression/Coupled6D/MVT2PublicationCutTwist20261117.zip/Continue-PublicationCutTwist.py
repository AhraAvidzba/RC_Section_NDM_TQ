"""Продолжает подтверждённую ветвь MVT2 по закручиванию при заданном T."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys


HERE = Path(__file__).resolve().parent
SETUP = runpy.run_path(str(HERE / 'Run-PublicationCut.py'))
TORQUE = 10510000.
ARM = 396.
THETA = 3
Q_SCALE = 1000.


def attach(np, ops, source):
    """Повторно использует прежнюю квадратуру, историю стали и аргументы ASD."""
    native = SETUP['NATIVE']
    program = runpy.run_path(str(source / 'Reequilibrate.py'))
    sh, native_cases, geom, dirs, area, length, op, *_ = program['read_inputs'](
        native / 'MVTGauss25Operators/Native/Operators.csv', native / 'MVTGauss25Tensors')
    command = program['commands'](sh, native_cases, ('default',))['default']
    steel_data = []
    postyield = SETUP['EVIDENCE'] / SETUP['STEEL']
    assert SETUP['digest'](postyield.read_bytes()) == SETUP['INPUTS'][SETUP['STEEL']]
    with ZipFile(postyield) as z:
        original = z.read('Postyield.py')
    steel_module = {'__name__': '__pinned__', '__file__': str(HERE / 'Postyield.py')}
    exec(compile(original, steel_module['__file__'], 'exec'), steel_module)
    section = steel_module['steel_section'](program['Section'], np, steel_data)(
        np, ops, command, geom, dirs, area, length, op, perf_counter() + 95.)
    return section, steel_data, program


def demand(q, torque=TORQUE):
    return 0., -ARM * q, 0., torque, 0., q


def replay(section, rows, tensors):
    """Подтверждает побитно все поля начальной истории перед сменой меры."""
    np = section.np
    for step, wire in zip(rows, tensors, strict=True):
        field = np.asarray(step['field'])
        value = section.equations(field, np.asarray(demand(step['Q_target_N'], step['T_target_Nmm'])))
        assert value[4] <= value[5] and value[2].tolist() == wire
        section.accepted_stresses.append(wire)
        section.commit()


def correct(section, program, left, current, width):
    """Фиксирует закручивание, заменяя его столбец производной столбцом Qy."""
    np = section.np
    last = np.asarray(current['field'])
    before = np.asarray(left['field'])
    quotient = width / (last[THETA] - before[THETA])
    field = last + quotient * (last - before)
    field[THETA] = last[THETA] + width
    q = current['Q_target_N'] + quotient * (current['Q_target_N'] - left['Q_target_N'])
    q_column = -Q_SCALE * (np.asarray((0., -ARM, 0., 0., 0., 1.)) @ section.L)
    merit = program['merit']
    log = []
    outcome = 'maximum_iterations'
    for iteration in range(program['MAX_ITER'] + 1):
        try:
            value = section.equations(field, np.asarray(demand(q)))
        except ArithmeticError:
            outcome = 'material_probe_rejected'
            break
        log.append(value[4])
        if value[4] <= value[5]:
            repeated = section.equations(field, np.asarray(demand(q)))
            assert np.array_equal(value[2], repeated[2])
            section.accepted_stresses.append(repeated[2].tolist())
            section.commit()
            record = program['q_record'](section, field, TORQUE, q, repeated, 'balanced', iteration, log)
            return record, {'attempted_width': width, 'accepted': True, 'last_q_N': q, 'norms': log}
        if iteration >= program['MAX_ITER']:
            break
        try:
            matrix = section.equations(field, np.asarray(demand(q)), True)[1]
            matrix[:, THETA] = q_column
            step = np.linalg.solve(matrix * section.scale[:, None], -value[0] * section.scale)
        except (ArithmeticError, np.linalg.LinAlgError):
            outcome = 'tangent_unavailable'
            break
        q_step = Q_SCALE * step[THETA]
        step[THETA] = 0.
        baseline = merit(np, value)
        for j in range(program['BACKTRACKS']):
            part = .5 ** j
            trial = field + part * step
            trial_q = q + part * q_step
            if trial_q <= 0.:
                continue
            try:
                next_value = section.equations(trial, np.asarray(demand(trial_q)))
            except ArithmeticError:
                continue
            if next_value[4] <= next_value[5] or merit(np, next_value) < baseline:
                field, q = trial, trial_q
                break
        else:
            outcome = 'line_search_no_decrease'
            break
    return None, {'attempted_width': width, 'accepted': False, 'last_q_N': q,
                  'reason': outcome, 'norms': log}


def main(wide, output_dir):
    sys.path.insert(0, str(SETUP['NATIVE'] / 'CoupledEvidencePython'))
    sys.path.insert(0, str(SETUP['SOURCE']))
    import numpy as np
    import openseespy.opensees as ops

    rows = json.loads((HERE / 'Cut396.json').read_bytes())['result']['accepted']
    base = json.loads(gzip.decompress((HERE / 'Cut396.stress.json.gz').read_bytes()))
    section, steel, program = attach(np, ops, SETUP['SOURCE'])
    size, found, attempts = len(rows), [], []
    try:
        replay(section, rows, base['stress'])
        assert steel == base['steel']
        left, current = rows[-2:]
        initial = current['field'][THETA] - left['field'][THETA]
        field = np.asarray(current['field'])
        zero = section.equations(field, np.asarray(demand(current['Q_target_N'])))
        zero_stress = zero[2].tolist()
        zero_repeat = {'new_norm_MPa': zero[4], 'tolerance_MPa': zero[5],
                       'max_concrete_stress_change_MPa': float(np.max(np.abs(
                           zero[2][:, :25] - np.asarray(base['stress'][-1])[:, :25])))}
        width = initial * (.5 if wide else .25)
        for _ in range(18):
            if width < initial / 512:
                break
            state, attempt = correct(section, program, left, current, width)
            attempts.append(attempt)
            if state is None:
                width = width * 2. if wide and not found else width / 2.
                if width > initial * 4.:
                    break
                continue
            found.append(state)
            left, current = current, state
            width = min(initial, width * 1.25)
    finally:
        ops.wipe()
    wire = gzip.compress(json.dumps({'stress': section.accepted_stresses[size:],
                                     'steel': steel[size:], 'uncommitted_zero_increment_stress': zero_stress},
                                    separators=(',', ':')).encode(), mtime=0)
    stem = 'Cut396TwistWide' if wide else 'Cut396TwistSmall'
    destination = output_dir / (stem + '.stress.json.gz')
    with destination.open('xb') as output:
        output.write(wire)
    SETUP['write_json'](output_dir / (stem + '.json'), {
        'prefix_states_bit_exact': size, 'initial_width': initial,
        'wide_pilot': wide, 'zero_increment_uncommitted_repeat': zero_repeat,
        'accepted': found, 'attempts': attempts, 'physical_limit_established': False,
        'stress_sha256': sha256(wire).hexdigest().upper(),
    })
    print('CUT396 TWIST', size, len(found), [round(row['Q_target_N'], 4) for row in found], flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--wide-pilot', action='store_true')
    parser.add_argument('--output-dir', type=Path, default=HERE)
    args = parser.parse_args()
    main(args.wide_pilot, args.output_dir)
