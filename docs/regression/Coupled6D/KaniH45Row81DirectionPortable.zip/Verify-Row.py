"""Replay the private Kani row 81 trace and attribute the Newton mismatch."""
from argparse import ArgumentParser
from pathlib import Path
import csv
import json
import re
import runpy

import numpy as np

H=Path(__file__).resolve().parent
Z=H/'Native'
NAMED=('Base','Last','Plus4','Minus4','Plus16','Minus16')
P=runpy.run_path(H/'Prepare-Row.py')


def rows(name):
    with (Z/name).open(encoding='cp1251',newline='') as f:
        yield from csv.reader(f,delimiter=';')


def maximum(x):
    return float(np.max(abs(x)))


def verify_accepted_history(repo):
    f=H/'AltVerifier.py'
    source=f.read_text(encoding='utf-8-sig')
    old="assert book['Modules'] == ['modTestKaniStage38']"
    assert source.count(old)==1
    source=source.replace(old,"assert sorted(book['Modules']) == ['CCoupledNewtonSolver','modTestKaniStage38']")
    ns={'__file__':str(f),'__name__':'kani_reference_verifier'}
    exec(compile(source,str(f),'exec'),ns)
    ns['P']['check']=lambda r:dict(P['check'](r),originalTauMPa=5.59190995944018e-7)
    check=ns['verify'](repo)
    return check,ns['archived_inputs'](repo)


def parse():
    shapes={'BASE_FIELD':87,'LAST_FIELD':87,'CORRECTION':88,'ROW_ACTION':88,
            'BASE_WEAK':87,'LAST_WEAK':87,'BASE_WRENCH':6,'LAST_WRENCH':6,'FAIL':10}
    native={}
    stress={k:np.full((3,184,6),np.nan) for k in ('BASE_STRESS','LAST_STRESS')}
    local=np.full((3,184,6),np.nan)
    for kind,*v in rows('KaniRowCapture.csv'):
        if kind in shapes:
            assert kind not in native and len(v)==shapes[kind]
            native[kind]=np.array(v,float)
        else:
            s,p,*pattern=v
            i,j=int(s)+1,int(p)-1
            assert 0<=i<3 and 0<=j<184 and len(pattern)==6
            dest=local if kind=='TANGENT_ZZ' else stress[kind]
            assert np.isnan(dest[i,j]).all()
            dest[i,j]=np.array(pattern,float)
    assert set(native)==set(shapes) and all(np.isfinite(x).all() for x in [*native.values(),*stress.values(),local[[0,2]]])
    fields={}
    stations={k:np.full((3,184,16),np.nan) for k in NAMED}
    frac={}
    errors=[]
    for kind,name,*v in rows('KaniRowProbes.csv'):
        assert name in NAMED
        if kind=='PROBE_FIELD':
            assert len(v)==88 and name not in fields
            fields[name]=np.array(v[1:],float)
            frac[name]=float(v[0])
        elif kind=='PROBE_ERROR':
            errors.append((name,*v))
        else:
            assert kind=='PROBE_STATION'
            s,p,*pattern=v
            i,j=int(s)+1,int(p)-1
            assert 0<=i<3 and 0<=j<184 and len(pattern)==16 and np.isnan(stations[name][i,j]).all()
            stations[name][i,j]=np.array(pattern,float)
    assert set(fields)==set(frac)==set(stations)
    assert all(np.isfinite(stations[k]).all() for k in ('Base','Last'))
    return native,stress,local,fields,frac,stations,errors


def verify(repo):
    base_receipt, archives=verify_accepted_history(repo)
    history,_,build,_=archives
    native,stress,local,fields,frac,stations,errors=parse()
    row,norm,best,tau,f,base_lambda,last_lambda,its,evals,mode=native['FAIL']
    assert row==81 and its==5 and evals==32 and mode in (0,3) and f in 0.5**np.arange(8)
    assert tau==base_receipt['originalH45Tau_MPa']
    assert 8.44e-5<best<8.45e-5 and 8.24e-5<norm<8.25e-5
    assert last_lambda>0 and base_lambda>0 and np.array_equal(fields['Base'],native['BASE_FIELD'])
    assert np.array_equal(fields['Last'],native['LAST_FIELD'])
    assert f==frac['Last'] and (frac['Plus4'],frac['Minus4'],frac['Plus16'],frac['Minus16'])==(f/4,-f/4,f/16,-f/16)
    assert abs(base_lambda+f*native['CORRECTION'][-1]-last_lambda)<3e-14
    assert maximum(fields['Last']-(fields['Base']+f*native['CORRECTION'][:87]))<8e-17

    geo=history['geometry']
    h,shape,g,physical,area,scale=build(geo,float(history['length']))
    alpha_source=(H/'H45DiscriminatingControl.csv').read_text(encoding='ascii').strip().split(';')
    alpha=np.array(alpha_source[5:],float)
    target=float(alpha_source[3])

    def strain(q):
        return h@q[:79]+np.array([-.001,0.,.001])[:,None,None]*(h[:,:,:4]@q[79:83])[None]

    def section(name, lam, sigma):
        q=fields[name]
        gradient=(sigma[2]-sigma[0])/.002
        weak=np.einsum('nij,ni,n->j',h,sigma[1],area)+g.T@q[83:]
        weak[4:]-=np.einsum('nk,na,n->ka',shape,gradient[:,[4,5,2]],area).ravel()
        lng=np.einsum('nij,ni,n->j',h[:,:,:4],gradient,area)
        lng[1]-=lam*1e5/scale[0]
        w=np.einsum('nij,nj,n->i',physical,sigma[1],geo[:,2])
        ext=np.r_[np.zeros(5),lam*1e5]
        force=np.r_[weak,lng,(w-ext)/scale]
        eq=25600*np.r_[g@q[:79],alpha@q-target]
        assert force.size==89 and eq.size==5
        return force,eq,w

    tensors={}
    assembly={}
    station_replay={}
    for k,lam in (('Base',base_lambda),('Last',last_lambda)):
        a=stress[k.upper()+'_STRESS']
        tensors[k]=section(k,lam,a)
        native_mismatch=maximum(tensors[k][0][:83]-native[k.upper()+'_WEAK'][:83])
        wrench_mismatch=maximum((tensors[k][2]-native[k.upper()+'_WRENCH'])/scale)
        strain_mismatch=maximum(stations[k][:,:,4:10]-strain(fields[k]))
        station_replay[k]=maximum(a-stations[k][:,:,10:])
        assert max(native_mismatch,wrench_mismatch)<2e-10 and strain_mismatch<2e-12
        assembly[k]=max(native_mismatch,wrench_mismatch)

    cr=native['CORRECTION']
    jv=float(native['ROW_ACTION']@cr)
    delta_f=(native['LAST_WEAK'][80]-native['BASE_WEAK'][80])/f
    current_row=float(native['BASE_WEAK'][80])
    assert jv<0<delta_f and current_row>0
    assert abs(jv+8.24294736431007e-5)<2e-12 and abs(delta_f-2.52677511992814e-4)<2e-10
    # Row 81 tests B_Mx=y/L against the z/L gradient of axial stress.
    # At a rebar station the reported material response already includes displacement of concrete.
    weights=np.array([-1,0,1])[:,None]*((geo[:,1]/float(history['length']))*area/.002)[None,:]
    predicted=np.zeros_like(weights)
    for i in (0,2):
        predicted[i]=weights[i]*np.einsum('ni,ni->n',local[i],strain(cr[:87])[i])
    measured=weights*(stress['LAST_STRESS'][:,:,2]-stress['BASE_STRESS'][:,:,2])/f
    load=float(native['ROW_ACTION'][-1]*cr[-1])
    assert abs(float(predicted.sum())+load-jv)<3e-11
    assert abs(float(measured.sum())+load-delta_f)<2e-9

    switched=np.any(stations['Base'][:,:,:3]!=stations['Last'][:,:,:3],axis=2)
    qs=(stations['Base'][:,:,3]>0)!=(stations['Last'][:,:,3]>0)
    error=measured-predicted
    complete={k:bool(np.isfinite(a).all()) for k,a in stations.items()}
    pair_stats={}
    local_pair_secants={}
    read_consistent=max(station_replay.values())<2e-10
    for k in NAMED[1:]:
        if not complete[k] or not read_consistent:
            continue
        a=stations[k]
        assert maximum(a[:,:,4:10]-strain(fields[k]))<2e-12
        d=weights*(a[:,:,12]-stations['Base'][:,:,12])/frac[k]
        local_pair_secants[k]=d
        pair_stats[k]={'signedSecantMPa':float(d.sum())+load,
            'allSixTargetEfforts_N_Nmm':section(k,base_lambda+frac[k]*cr[-1],a[:,:,10:])[2].tolist(),
            'coarseConcreteBranchSwitches':int(np.count_nonzero(np.any(a[:,:,:3]!=stations['Base'][:,:,:3],axis=2))),
            'predictorSignSwitches':int(np.count_nonzero((a[:,:,3]>0)!=(stations['Base'][:,:,3]>0)))}
    paired_gap={}
    for suffix in ('4','16'):
        plus,minus='Plus'+suffix,'Minus'+suffix
        if plus in local_pair_secants and minus in local_pair_secants:
            gap=local_pair_secants[plus]-local_pair_secants[minus]
            bp=stations[plus]
            bm=stations[minus]
            distinct=np.any(bp[:,:,:3]!=bm[:,:,:3],axis=2)
            paired_gap[suffix]={'sumMPa':float(gap.sum()),'maxStationAbsMPa':maximum(gap),
                                'coarseBranchChangedContributionMPa':float(gap[distinct].sum()),
                                'coarseBranchUnchangedContributionMPa':float(gap[~distinct].sum()),
                                'plusMinusCoarseFlagDifferences':int(np.count_nonzero(distinct))}
    hotspot=[]
    for ind in np.argsort(abs(error).reshape(-1))[-12:][::-1]:
        i,j=np.unravel_index(ind,error.shape)
        hotspot.append({'side':int(i)-1,'point':int(j)+1,'directConcrete':bool(j<144),'predictedMPa':float(predicted[i,j]),
                        'measuredMPa':float(measured[i,j]),'mismatchMPa':float(error[i,j]),
                        'baseBranch':stations['Base'][i,j,:3].astype(int).tolist(),'lastBranch':stations['Last'][i,j,:3].astype(int).tolist(),
                        'baseF_MPa':float(stations['Base'][i,j,3]),'lastF_MPa':float(stations['Last'][i,j,3]),
                        'pairedStressZZ_MPa':{k:float(a[i,j,12]) for k,a in stations.items() if np.isfinite(a[i,j,12])}})
    result={'workbookSHA256':base_receipt['workbookSHA256'],'exactH45Restored':base_receipt['unchangedReplay'],
            'fraction':float(f),'iterations':int(its),'evaluations':int(evals),'matrixMaterialMode':int(mode),
            'baseRow81MPa':current_row,'lastRow81MPa':float(native['LAST_WEAK'][80]),'tangentJvMPa':jv,
            'trueLastSecantMPa':delta_f,'actualMinusPredictedMPa':delta_f-jv,'loadContributionMPa':load,
            'coarseBranchUnchangedContributionMPa':float(error[~switched].sum()),
            'coarseBranchChangedContributionMPa':float(error[switched].sum()),
            'predictorSignChangedContributionMPa':float(error[qs].sum()),
            'directConcreteContributionMPa':float(error[:,:144].sum()),'netSteelReplacementContributionMPa':float(error[:,144:].sum()),
            'assemblyMismatchMPa':assembly,'stationReplayMismatchMPa':station_replay,
            'readOnlyStationReplayMatches':read_consistent,'pairSecants':pair_stats,'pairGaps':paired_gap,'hotspot':hotspot,
            'all89ForceRowsMPa':{k:v[0].tolist() for k,v in tensors.items()},
            'all5ControlsMPa':{k:v[1].tolist() for k,v in tensors.items()},
            'localProbeErrors':errors,'ownedExcelClosure':base_receipt['ownedExcelClosure']}
    output=H/'KaniRowVerification.json'
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(output,P['sha'](output),{k:result[k] for k in ('fraction','tangentJvMPa','trueLastSecantMPa','pairSecants','stationReplayMismatchMPa')})
    return result


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    verify(a.repo_root.resolve())
