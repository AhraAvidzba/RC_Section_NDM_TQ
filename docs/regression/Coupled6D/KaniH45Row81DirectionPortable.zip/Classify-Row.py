"""Attribute a native row-81 mismatch to validated station return modes."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json
import runpy

import numpy as np

H=Path(__file__).resolve().parent
APEX='KaniApexConstitutiveReplay20261116.zip'
APEX_SHA='7AC4030A1635FAFED411B69A6AB5AB23CEEC6A29EFA98D52C3D2DBEF5D496484'
GEO='KaniHydrostaticApex46Portable.zip'
GEO_SHA='B920F591EA6436DB65914CEF8582EA8EB42301679A15311A924253942FEAAEA5'


def inputs(repo):
    r=repo/'docs/regression/Coupled6D'
    assert sha256((r/APEX).read_bytes()).hexdigest().upper()==APEX_SHA
    assert sha256((r/GEO).read_bytes()).hexdigest().upper()==GEO_SHA
    with ZipFile(r/APEX) as z:
        code=z.read('Verify-KaniApexReturn.py').decode('utf-8-sig')
    ns={'__file__':str(r/APEX),'__name__':'kani_archived_apex'}
    exec(compile(code,str(r/APEX),'exec'),ns)
    with ZipFile(r/GEO) as z:
        geometry=np.loadtxt(BytesIO(z.read('GeometryAndDirections.csv')),delimiter=';')
        steel=json.loads(z.read('HydrostaticApexDecomposition.json'))
    assert steel['maximumReplayedSteelStress_MPa']<181.
    return ns,geometry


def classify(repo,verified,api,output='KaniRowDiagnosis.json'):
    # The previous accepted-path and replay routines already verify all input receipts.
    with open(H/'AltVerifier.py',encoding='utf-8-sig') as f:
        content=f.read()
    context={'__file__':str(H/'AltVerifier.py'),'__name__':'kani_accepted_apex_inputs'}
    exec(compile(content,'AltVerifier.py','exec'),context)
    history,receipt,build,_=context['archived_inputs'](repo)
    model,g=inputs(repo)
    assert np.array_equal(g[:,:3],history['geometry'])
    native,stress,tangent,fields,fractions,stations,_=api['parse']()
    h,*_,area,scale=build(history['geometry'],float(history['length']))
    q=native['CORRECTION'][:87]
    span=h[:,:,:4]@q[79:83]
    strain=h@q[:79]+np.array([-.001,0.,.001])[:,None,None]*span[None]
    weights=np.array([-1.,0.,1.])[:,None]*(g[None,:,1]/float(history['length']))*area[None,:]/.002
    actual=weights*(stress['LAST_STRESS'][:,:,2]-stress['BASE_STRESS'][:,:,2])/verified['fraction']
    prediction=np.zeros_like(actual)
    for i in (0,2):
        prediction[i]=weights[i]*np.einsum('ni,ni->n',tangent[i],strain[i])
    mismatch=actual-prediction
    assert abs(float(mismatch.sum())-verified['actualMinusPredictedMPa'])<2e-9
    committed_ix=list(history['names']).index('Committed45')
    st=history['stations'][history['station_index'][committed_ix]]
    energies=np.array(receipt['energiesByStation_minus0plus']['Committed45'])
    dirs=np.zeros((len(g),6))
    dirs[144:,:4]=g[144:,3:]
    labels=list(stations)
    series={n:{} for n in labels}
    exclusions={n:{} for n in labels}
    stress_tol=2e-10
    yield_tol=2e-9

    def steel_stress(x,point):
        sig=float(2e5*np.dot(x,dirs[point]))
        if point>=144 and abs(sig)>=min(400.,442.):
            raise ValueError('SteelOutsideVerifiedElasticRange')
        return sig*dirs[point]

    exact_direction={}
    for i in (0,2):
        for j in range(len(g)):
            nom0=st[i,j,6:]
            if j>=144:
                nom0=steel_stress(st[i,j,:6],j)-nom0
            nominal=model['matrix'](nom0)
            kt,kc=energies[i,j]
            for name in labels:
                record=stations[name][i,j]
                if not np.isfinite(record).all():
                    reason='NativeStationUnavailable'
                else:
                    eps=record[4:10]
                    try:
                        sigma,d=model['return_apex'](nominal,kt,kc,eps-st[i,j,:6])
                        pay=np.array(model['vector'](sigma))
                        if j>=144:
                            pay=steel_stress(eps,j)-pay
                        error=float(np.max(abs(pay-record[10:])))
                        error_f=abs(float(d['Ftrial']-record[3]))
                        if error<=stress_tol and error_f<=yield_tol:
                            series[name][i,j]=(d,error,error_f)
                            if name=='Base':
                                try:
                                    d_sigma,kind=model['apex_jvp'](nominal,kt,kc,eps-st[i,j,:6],strain[i,j])
                                    dz=float(d_sigma[2,2])
                                    if j>=144:
                                        dz=float(steel_stress(strain[i,j],j)[2])-dz
                                    exact_direction[i,j]=(weights[i,j]*dz,kind)
                                except (ValueError,AssertionError,ZeroDivisionError,np.linalg.LinAlgError):
                                    pass
                            continue
                        reason='ReplayedStressOrPredictorOutsideTolerance'
                    except ValueError as e:
                        reason=str(e)
                    except AssertionError:
                        reason='UnsupportedAnalyticBracket'
                exclusions[name][reason]=exclusions[name].get(reason,0)+1

    keys=series['Base'].keys()&series['Last'].keys()
    common=set(keys)
    mode_groups={}
    for i,j in sorted(keys):
        kind0=series['Base'][i,j][0]['kind']
        kind1=series['Last'][i,j][0]['kind']
        name=kind0+' -> '+kind1
        p=mode_groups.setdefault(name,{'stationCount':0,'signedMismatchMPa':0.,'sumAbsoluteStationMismatchMPa':0.})
        p['stationCount']+=1
        p['signedMismatchMPa']+=float(mismatch[i,j])
        p['sumAbsoluteStationMismatchMPa']+=abs(float(mismatch[i,j]))
    exc=float(sum(mismatch[i,j] for i in (0,2) for j in range(len(g)) if (i,j) not in common))
    good=float(sum(mismatch[i,j] for i,j in sorted(common)))
    groups={}
    for suffix in ('4','16'):
        plus,minus='Plus'+suffix,'Minus'+suffix
        splus=stations[plus]; sminus=stations[minus]; center=stations['Base']
        positive=weights*(splus[:,:,12]-center[:,:,12])/fractions[plus]
        negative=weights*(sminus[:,:,12]-center[:,:,12])/fractions[minus]
        diff=positive-negative
        union=set(series[plus])&set(series[minus])&set(series['Base'])
        switches={key for key in union if series[plus][key][0]['kind']!=series[minus][key][0]['kind']}
        groups[suffix]={'analyticOnBothSignsCount':len(union),'analyticModeSwitchCount':len(switches),
                        'signedGapMPaAtAnalyticStations':float(sum(diff[k] for k in sorted(union))),
                        'signedGapMPaAtAnalyticSwitches':float(sum(diff[k] for k in sorted(switches)))}
    directional={}
    if exact_direction:
        idx=sorted(exact_direction)
        exact=np.array([exact_direction[k][0] for k in idx])
        local_j=np.array([prediction[k] for k in idx])
        directional={'stationCount':len(idx),'analyticMinusInstalledJvSumMPa':float((exact-local_j).sum()),
                     'analyticMinusInstalledJvAbsoluteSumMPa':float(abs(exact-local_j).sum()),
                     'installedJvMPa':float(local_j.sum()),'analyticJvMPa':float(exact.sum())}
        if groups['16']['analyticOnBothSignsCount']:
            for suffix,token in [('Plus16','positive'),('Minus16','negative')]:
                stp=stations[suffix]; st0=stations['Base']
                run=(weights*(stp[:,:,12]-st0[:,:,12])/fractions[suffix])
                values=np.array([run[k] for k in idx])
                valid=np.isfinite(values)
                directional[token+'SecantMinusAnalyticJvSumMPa']=float((values[valid]-exact[valid]).sum())
    ranking=[]
    for point in verified['hotspot']:
        key=(point['side']+1,point['point']-1)
        material={}
        for n in labels:
            if key in series[n]:
                d,e,ef=series[n][key]
                material[n]={'kind':d['kind'],'qTrialEffectiveMPa':d['q_trial'],'qAfterReturnEffectiveMPa':d['q_return'],
                             'effectivePredictorMPa':d['Ftrial'],'stressErrorMPa':e,'predictorErrorMPa':ef}
        analytic_local=exact_direction.get(key)
        ranking.append(dict(point,analyticMaterialModes=material,
                            analyticJvMPa=None if analytic_local is None else float(analytic_local[0]),
                            analyticJvKind=None if analytic_local is None else analytic_local[1]))
    errors=[v for lookup in series.values() for v in lookup.values()]
    diag={'APEXInputSHA256':APEX_SHA,'GeometryInputSHA256':GEO_SHA,
          'scope':{'twoFieldsAnalyticStationCount':len(common),'sideStationsOfAnyMode':368,
                   'analyticallyMatchedMismatchMPa':good,'remainingMismatchMPa':exc,
                   'bothFieldsAnalyticModes':mode_groups,'pairSigns':groups,'exactAnalyticDirection':directional,
                   'maximumReplayStressErrorMPa':max((x[1] for x in errors),default=None),
                   'maximumReplayPredictorErrorMPa':max((x[2] for x in errors),default=None)},
          'stationCoverageByLabel':{n:len(s) for n,s in series.items()},
          'exclusionReasonsByLabel':exclusions,'hotspots':ranking,
          'assumptions':['Nondamaged stress reconstructed from H45 committed energy only within the saturated tensile apex law.',
                         'Rebar response is elastic over the trace, screened against both calibrated yield thresholds.',
                         'Unsupported stations are excluded from analytical branch attribution even if coarse branch flags are available.']}
    path=H/output
    path.write_text(json.dumps(diag,indent=2,allow_nan=False)+'\n',encoding='utf8')
    return diag


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    api=runpy.run_path(H/'Replay-Row.py')['row_api']()
    result=json.loads((H/'KaniRowVerification.json').read_text(encoding='utf8'))
    print(json.dumps(classify(a.repo_root.resolve(),result,api)['scope'],indent=2))
