"""Replay the Kani row-81 witness from the fixed Git input and native receipts."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import contextlib
import io
import json
import math
import runpy

H=Path(__file__).resolve().parent
SOURCE='workbook/output/RC_Section_NDM.xlsm'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def history_inputs(repo):
    manifest=read(H/'Manifest.json')
    prep=read(H/'Preparation.json')
    assert manifest['schema']=='KaniH45Row81/v1'
    assert all(sha(H/n)==h for n,h in manifest['files'].items())
    native_code=read(H/'docs/regression/CodeUpdate.json')
    own=read(H/'Native/KaniV4.txt.Ownership.json')
    assert not native_code['ProductionChanged'] and native_code['Compiled'] and own['VerifiedNewOwner']
    assert native_code['WorkbookSHA256']==own['SourceSHA256']==manifest['compiledPrivateSHA256']
    assert prep['bookSHA256']==prep['frozen'][SOURCE]==manifest['sourceWorkbookSHA256']
    assert prep['sourceGit']==manifest['sourceGit']
    p=runpy.run_path(H/'Prepare-Row.py')
    assert p['sha'](p['blob'](repo,SOURCE))==prep['bookSHA256']
    assert p['sha'](p['blob'](repo,SOLVER))==prep['sourceSolverSHA256']
    assert sha(repo/p['REFERENCE'])==prep['referenceSHA256']
    assert all(manifest['files'][n]==h for n,h in prep['frozen'].items() if n!=SOURCE)
    old=read(H/'FailedCompile/ProcessReceipt.json')
    assert old['observedState']=='Absent' and not old['compiled'] and not old['nativeMacroStarted']
    assert f"id={old['PID']}; utcStartTicks={old['StartTicksUTC']}" in (H/'FailedCompile/Compile.log').read_text(encoding='utf-8-sig')
    assert old['PID'] not in (own['PID'],read(H/'Native/CompileClosure.json')['PID'])
    return prep


def replace_once(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)


def row_api(portable=False):
    p=H/'Verify-Row.py'
    source=p.read_text(encoding='utf-8-sig')
    if portable:
        # A detached replay has the historical Git workbook and two agreeing
        # receipts for the ephemeral compiled workbook. Recalculate from the
        # compiled file too when the file happens to be present.
        at="    ns={'__file__':str(f),'__name__':'kani_reference_verifier'}"
        source=replace_once(source,at,"    source=adapt_workbook_receipt(source)\n"+at)
        source=replace_once(source,"'KaniRowVerification.json'","'Replay-KaniRowVerification.json'")
    ns={'__file__':str(p),'__name__':'kani_row_runtime','adapt_workbook_receipt':adapt_workbook_receipt}
    exec(compile(source,str(p),'exec'),ns)
    if portable:
        ns['P']['check']=history_inputs
    return ns


def adapt_workbook_receipt(source):
    old="    assert book['WorkbookSHA256'] == P['sha'](H / P['draft']) == own['SourceSHA256']"
    new="""    assert book['WorkbookSHA256'] == own['SourceSHA256']
    if (H / P['draft']).exists():
        assert book['WorkbookSHA256'] == P['sha'](H / P['draft'])"""
    return replace_once(source,old,new).replace("'AlternateVerification.json'","'Replay-AlternateVerification.json'")


def compare(expected,actual,path='result'):
    if isinstance(expected,dict):
        assert set(expected)==set(actual),path
        for k,v in expected.items():
            compare(v,actual[k],path+'.'+k)
    elif isinstance(expected,list):
        assert len(expected)==len(actual),path
        for i,(u,v) in enumerate(zip(expected,actual)):
            compare(u,v,f'{path}[{i}]')
    elif isinstance(expected,float):
        # Tiny BLAS differences are allowed after the native force/branch
        # predicates have independently passed at their original tolerance.
        assert math.isclose(expected,actual,rel_tol=2e-10,abs_tol=2e-12),(path,expected,actual)
    else:
        assert expected==actual,(path,expected,actual)


def replay(repo):
    expected=read(H/'KaniRowVerification.json')
    a=row_api(portable=True)
    with contextlib.redirect_stdout(io.StringIO()):
        result=a['verify'](repo)
    compare(expected,result)
    explain=runpy.run_path(H/'Classify-Row.py')['classify']
    diagnosis=explain(repo,result,a,output='Replay-KaniRowDiagnosis.json')
    compare(read(H/'KaniRowDiagnosis.json'),diagnosis)
    probe={k:result[k] for k in ('fraction','baseRow81MPa','lastRow81MPa','tangentJvMPa','trueLastSecantMPa',
                                 'actualMinusPredictedMPa','pairGaps','ownedExcelClosure')}
    print(json.dumps({'PASS':True,'result':probe,'supportedSaturatedApex':diagnosis['scope']},indent=2,ensure_ascii=False))
    return result


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    replay(a.repo_root.resolve())
