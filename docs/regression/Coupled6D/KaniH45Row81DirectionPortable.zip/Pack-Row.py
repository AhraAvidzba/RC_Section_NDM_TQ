"""Package one measured Kani row-81 event without distributing a workbook."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import json
import runpy

H=Path(__file__).resolve().parent
SOURCE='workbook/output/RC_Section_NDM.xlsm'
CLOSURE=('KaniV4.txt','KaniV4.txt.Ownership.json','KaniV4.txt.ProcessClosure.json',
         'KaniV4.txt.RunnerCleanup.json','KaniV4.txt.memory.json','KaniV4.txt.stdout.log',
         'KaniV4.txt.stderr.log','Compile.log','CompileClosure.json','Preflight.ndjson')
MEASURED=('KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv','KaniRowCapture.csv','KaniRowProbes.csv')
FAILED=('Compile.log','Preflight.ndjson','Preparation.json','MacroRowProbe.bas.txt','ProcessReceipt.json')


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def pack(repo):
    a=runpy.run_path(H/'Replay-Row.py')['row_api']()
    result=a['verify'](repo)
    runpy.run_path(H/'Classify-Row.py')['classify'](repo,result,a)
    prep=read(H/'Preparation.json')
    code=read(H/'docs/regression/CodeUpdate.json')
    files={n for n in prep['frozen'] if n!=SOURCE}
    files.update('Native/'+n for n in (*CLOSURE,*MEASURED))
    files.update('FailedCompile/'+n for n in FAILED)
    files.update(('Preparation.json','KaniRowVerification.json','AlternateVerification.json','KaniRowDiagnosis.json',
                  'docs/regression/CodeUpdate.json','Replay-Row.py','Classify-Row.py','Pack-Row.py','Portable-README.md'))
    assert all((H/n).is_file() for n in files) and not any(n.lower().endswith(('.xlsm','.xlsx')) for n in files)
    assert result['exactH45Restored'] and result['workbookSHA256']==prep['bookSHA256']
    manifest={'schema':'KaniH45Row81/v1','sourceGit':prep['sourceGit'],'sourceWorkbookSHA256':prep['bookSHA256'],
              'compiledPrivateSHA256':code['WorkbookSHA256'],'files':{n:sha(H/n) for n in sorted(files)}}
    folder=H/'Portable'
    folder.mkdir(exist_ok=True)
    archive=folder/'KaniH45Row81DirectionPortable.zip'
    fixed=(2026,11,16,0,0,0)
    with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
        for n in sorted(files):
            z.writestr(ZipInfo(n,fixed),(H/n).read_bytes(),compress_type=ZIP_DEFLATED,compresslevel=9)
        z.writestr(ZipInfo('Manifest.json',fixed),(json.dumps(manifest,indent=2)+'\n').encode(),compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==files|{'Manifest.json'}
    print(archive,sha(archive),archive.stat().st_size)


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    pack(a.repo_root.resolve())
