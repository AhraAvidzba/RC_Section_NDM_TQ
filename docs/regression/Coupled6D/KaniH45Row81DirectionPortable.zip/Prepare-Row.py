"""Prepare the exact native Kani row 81 replay with a private diagnostic module."""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json
import subprocess

H = Path(__file__).resolve().parent
STAGE = '0e6618a'
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
DRAFT = 'docs/regression/Diagnostic.xlsm'
SOLVER = 'src/Solver/CCoupledNewtonSolver.cls'
MOD = 'tests/modTestKaniStage38.bas'
REFERENCE = 'docs/regression/Coupled6D/KaniH45AlternateControlPortable.zip'
REFERENCE_SHA = '4A9CADBD73726D133E99B5EA1D58F1DB8DB574C45BC189470F8EEC856C911BD4'
BOOK_SHA = '9A99BF072D67536CBCCA525A75E049F510C5242D46CB4EA3ADA7BC4C726088F8'


def sha(x):
    return sha256(x.read_bytes() if isinstance(x,Path) else x).hexdigest().upper()


def blob(repo, name):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{STAGE}:{name}'])


def replace_once(source, old, new):
    assert source.count(old)==1,old
    return source.replace(old,new)


def read_source(name):
    return (H/name).read_text(encoding='utf-8-sig').rstrip()+'\n'


def instrument_solver(raw):
    src=raw.decode('utf-8-sig').replace('\r\n','\n').rstrip()+'\n'
    marker='Private mFailureCode As ESolverFailureCode'
    src=replace_once(src,marker,marker+"""
Private mTestKaniRowFile As Integer, mTestKaniRowCaptured As Boolean
Private mTestKaniStress() As Double, mTestKaniBaseStress() As Double, mTestKaniLastStress() As Double
Private mTestKaniBaseTangent() As Double, mTestKaniRowAction() As Double
Private mTestKaniBaseWeak() As Double, mTestKaniLastWeak() As Double
Private mTestKaniBaseWrench() As Double, mTestKaniLastWrench() As Double
Private mTestKaniFailedBase() As Double, mTestKaniFailedDirection() As Double, mTestKaniLastField() As Double
Private mTestKaniLastFraction As Double, mTestKaniLastLambda As Double, mTestKaniTangentMode As Long""")
    marker='            baseEquation = mResidual(governingRow)'
    src=replace_once(src,marker,marker+'\n            If mTestKaniRowFile <> 0 Then CopyTestKaniBase governingRow')
    marker='                    trialFraction = fraction'
    src=replace_once(src,marker,marker+'\n                    If mTestKaniRowFile <> 0 Then CopyTestKaniLastTrial fraction, candidateLambda')
    marker='            RecordFailure sfcNumericalFailure, "Уменьшение поправки не снизило невязку связанного сечения."'
    src=replace_once(src,marker,
        """            If mTestKaniRowFile <> 0 And hasValidTrial And governingRow = 81 And norm > SMALL_STRAIN_MAX_NORM * tolerance Then
                WriteTestKaniFailure current, correction, governingRow, norm, bestTrialNorm, tolerance, currentLambda
            End If
"""+marker)
    marker='    useGradientTangent = useGradientTangent And withMatrix And useAxialGradient'
    src=replace_once(src,marker,
        '    If mTestKaniRowFile <> 0 And withMatrix Then mTestKaniTangentMode = tangentMode\n'+marker)
    marker='        If mUseSpatialHistory Then\n            BuildSpatialGradient withMatrix'
    src=replace_once(src,marker,
        '        If mUseSpatialHistory Then\n            If mTestKaniRowFile <> 0 Then CopyTestKaniStation point, withMatrix\n            BuildSpatialGradient withMatrix')
    src += '\n'+read_source('SolverRowProbe.bas.txt')
    return src.encode('utf-8')


def instrument_macro(raw):
    src=raw.decode('utf-8-sig').replace('\r\n','\n').rstrip()+'\n'
    marker='    Dim trace As Integer, stations As Integer, tangents As Integer'
    src=replace_once(src,marker,marker+', rowCapture As Integer, rowProbes As Integer')
    marker='    solved = solver.TryDeformationStep(offset, direction, alt, targetAlpha, baseLambda, returned, _'
    src=replace_once(src,marker,
        """    rowCapture = FreeFile: Open ThisWorkbook.Path & "\\KaniRowCapture.csv" For Output As #rowCapture
    solver.StartTestKaniRowCapture rowCapture
"""+marker)
    marker='    Print #trace, "DIAGNOSTIC;Right;" & Replace(Replace(Replace(diag, ";", "|"), vbCr, " "), vbLf, " ")'
    src=replace_once(src,marker,marker+"""
    Dim failedBase() As Double, failedDirection() As Double, failedEndpoint() As Double, failedFraction As Double
    If Not solver.FinishTestKaniRowCapture(failedBase, failedDirection, failedEndpoint, failedFraction) Then _
        Err.Raise 5, , "Отказ строки 81 не воспроизвёлся в закреплённой пробе."
    If solved Then Err.Raise 5, , "Проверяемая поправка неожиданно стала сходящейся."
    Close #rowCapture: rowCapture = 0
    rowProbes = FreeFile: Open ThisWorkbook.Path & "\\KaniRowProbes.csv" For Output As #rowProbes
    WriteTestKaniRowNeighborhood rowProbes, operators, materials, failedBase, failedDirection, failedEndpoint, failedFraction
    Close #rowProbes: rowProbes = 0""")
    marker='    If tangents > 0 Then Close #tangents'
    src=replace_once(src,marker,marker+'\n    If rowCapture > 0 Then Close #rowCapture\n    If rowProbes > 0 Then Close #rowProbes')
    src += '\n'+read_source('MacroRowProbe.bas.txt')
    return src.encode('utf-8')


def make(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    if (H/'Preparation.json').is_file():
        return check(repo)
    source=blob(repo,BOOK); native=blob(repo,SOLVER)
    assert sha(source)==BOOK_SHA and sha(repo/BOOK)==BOOK_SHA and sha(repo/REFERENCE)==REFERENCE_SHA
    with ZipFile(repo/REFERENCE) as ref:
        old=json.loads(ref.read('Preparation.json'))
        old_git=old['sourceGit']
        for name in old['productionDiagnosticSourcesSHA256']:
            prev=subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{old_git}:{name}'])
            assert prev.replace(b'\r\n',b'\n')==blob(repo,name).replace(b'\r\n',b'\n'),name
        raw={n:ref.read(n) for n in old['frozen'] if n.startswith('tools/') or n.endswith(('.csv','.json'))}
        for n in raw:
            assert sha(raw[n])==old['frozen'][n]
        raw['AltVerifier.py']=ref.read('Verify-Alt.py')
        raw['Prepare-Alt.py']=ref.read('Prepare-Alt.py')
        raw[MOD]=instrument_macro(ref.read(MOD))
    raw[BOOK]=raw[DRAFT]=source
    raw[SOLVER]=instrument_solver(native)
    for file,data in raw.items():
        dst=H/file
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(data)
    for folder in ('Native','Temp'):
        (H/folder).mkdir(exist_ok=True)
    inputs=set(raw)-{DRAFT}
    inputs.update(('Prepare-Row.py','Verify-Row.py','Run-Row.ps1','MacroRowProbe.bas.txt','SolverRowProbe.bas.txt','README.md'))
    manifest={'sourceGit':STAGE,'referenceSHA256':REFERENCE_SHA,'bookSHA256':BOOK_SHA,'sourceSolverSHA256':sha(native),
              'frozen':{n:sha(H/n) for n in sorted(inputs)}}
    (H/'Preparation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    return check(repo)


def check(repo):
    m=json.loads((H/'Preparation.json').read_text(encoding='utf-8'))
    assert m['sourceGit']==STAGE and m['referenceSHA256']==REFERENCE_SHA==sha(repo/REFERENCE)
    assert m['bookSHA256']==BOOK_SHA==sha(blob(repo,BOOK))
    assert m['sourceSolverSHA256']==sha(blob(repo,SOLVER))
    assert all(sha(H/n)==v for n,v in m['frozen'].items())
    return m


if __name__=='__main__':
    p=ArgumentParser(); p.add_argument('--repo-root',type=Path,required=True); p.add_argument('--check',action='store_true')
    args=p.parse_args()
    data=(check if args.check else make)(args.repo_root.resolve())
    print(data['bookSHA256'],sha(H/'Preparation.json'))
