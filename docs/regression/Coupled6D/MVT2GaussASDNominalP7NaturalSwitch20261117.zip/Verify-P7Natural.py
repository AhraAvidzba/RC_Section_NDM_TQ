"""Offline audit of one natural p7 exchange and a two-direction cell bound."""
from argparse import ArgumentParser
from hashlib import sha256
from math import fsum
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WIRE='A29CA60B396007696D5772D5F956C4C923954050AB01FDD75A8E4995BB5F5A47'
KNOT=('MVT2GaussASDNominalP7KnotLevel20261117','9C8DA4155BFC448FE6BAAF904A3D1DD1CAC28D6B9260ADA7D1E012F6F38B30C4')


def sha(b):
    return sha256(b).hexdigest().upper()


def archive(repo,pin):
    name,seal=pin
    path=repo/'docs/regression/Coupled6D'/(name+'.zip')
    assert sha(path.read_bytes())==seal
    return ZipFile(path)


def dot(a,b):
    return fsum(x*y for x,y in zip(a,b,strict=True))


def clip(poly,a,b,h):
    """Intersect a 2-D convex polygon with a*x + b*y <= h."""
    if not poly:
        return []
    out=[]; last=poly[-1]; q=a*last[0]+b*last[1]-h
    for point in poly:
        v=a*point[0]+b*point[1]-h
        if (q>0.)!=(v>0.):
            t=q/(q-v)
            out.append((last[0]+t*(point[0]-last[0]),last[1]+t*(point[1]-last[1])))
        if v<=0.:
            out.append(point)
        last,q=point,v
    return out


def left_cell_bound(residual,action,shape,marker,marker_action,tau):
    region=[(-1.,-1.),(1.,-1.),(1.,1.),(-1.,1.)]
    for off,a,b in shape:
        region=clip(region,a,b,1.-off)
        region=clip(region,-a,-b,1.+off)
    # Use a unit-scaled half-plane to avoid comparing tiny material values
    # as if they were normalized strain or residual inequalities.
    unit=max(map(abs,(marker,*marker_action)))
    region=clip(region,marker_action[0]/unit,marker_action[1]/unit,-marker/unit)
    assert region and marker<0.

    def compatible(limit):
        result=region
        for value,(x,y) in zip(residual,action,strict=True):
            result=clip(result,x/tau,y/tau,(limit-value)/tau)
            result=clip(result,-x/tau,-y/tau,(limit+value)/tau)
            if not result:
                break
        return result

    weak=max(map(abs,residual)); lo,hi=0.,weak
    assert compatible(hi) and not compatible(tau)
    for _ in range(41):
        mid=(lo+hi)/2.
        if compatible(mid):
            hi=mid
        else:
            lo=mid
    return {'matching_left_cell_linear_norm_bracket_MPa':[lo,hi],'original_tolerance_feasible_in_measured_two_direction_left_model':False,
            'candidate_knot_flattened_polygon_vertices':len(region)}


def check(data,knot,ray,old,adj,watch,past,p7,guard,op,geo,area,length):
    assert data['history_before']==data['history_after']==knot['accepted_history_after']==53
    assert data['status']=='checked_one_candidate_rejected' and data['same_material']==knot['same_material']
    start=knot['candidate']; x=data['initial_field']; y=data['crossing_seed']; z=data['candidate']; target=data['target']
    assert x==start['field'] and data['initial_all66']==start['all66'] and data['initial_markers']==start['markers']
    assert target==[0.,-33140625.,0.,10510000.,0.,55234.375]
    assert y['field']==[a+d for a,d in zip(x,data['crossing_seed_move'],strict=True)]
    assert z['field']==[a+d for a,d in zip(y['field'],data['plan']['correction'],strict=True)]
    eq=watch['check_whole']; signed=guard['signed_forces']; sig=adj['signature']; tensor=past['tensor']; norm=adj['norm']; diff=adj['delta']
    span=(eq(start['section'],x,target,op,geo,area,length,signed),
          eq(y['section'],y['field'],target,op,geo,area,length,signed),
          eq(z['section'],z['field'],target,op,geo,area,length,signed))
    assert all(abs(a-b)<3e-12 for a,b in zip(span,(data['initial_norm_MPa'],y['independent_norm_MPa'],z['independent_norm_MPa']),strict=True))
    assert abs(span[1]-norm(y['all66']))<3e-12 and abs(span[2]-norm(z['all66']))<3e-12
    assert start['section']['steel_active_flags']==y['section']['steel_active_flags']==z['section']['steel_active_flags']
    sy,sx,sz=sig(y['markers']),sig(data['initial_markers']),sig(z['markers'])
    assert sx[:5]==sy[:5]==sz[:5] and sx[-1]==sz[-1]==1. and sy[-1]==-1.
    assert z['held_other_markers_and_steel'] and not z['admissible_improvement']
    for row in (y,z):
        for (point,side),m in zip(((20,1),(20,-1),(10,-1)),row['markers'][:3],strict=True):
            real=watch['eigen'](row['section']['net_stresses_MPa'][(0,1,-1).index(side)][point-1])[1]
            assert abs(real-m)<2e-13 and sig([real])==sig([m])
    cap=data['local_cap']; overall=data['physical_cap_centered_at_first_rejection']; tau=z['section']['tolerance_MPa']
    assert cap==knot['local_total_cap'] and overall==knot['cap_from_rejected_center']
    assert tau==start['section']['tolerance_MPa']==y['section']['tolerance_MPa']<span[0]<span[1]<span[2]

    def all_strains(vector):
        return [v for p in range(45) for side in (0,1,-1) for v in tensor(op,vector,p,side)]

    move=norm(all_strains(diff(z['field'],x)))
    total=norm(all_strains(diff(z['field'],old['first_rejected_trial'])))
    assert abs(move-z['physical_travel'])<4e-18 and move<cap+4e-18
    assert abs(total-z['cumulative_travel_from_rejected'])<4e-18 and total<overall
    model=data['actual_station_tangent_difference']; station=ray['stations'][-1]; event=station['events'][0]
    local={v['alpha']:v for v in station['values']}; a,b=event['outer_alpha']; lo,hi=event['actual_alpha_bracket']
    before=[i/(lo-a) for i in diff(local[lo]['stress'],local[a]['stress'])]
    after=[i/(b-hi) for i in diff(local[b]['stress'],local[hi]['stress'])]
    assert adj['error'](before,model['minus_stress_slope_MPa_per_alpha'])<1e-19
    assert adj['error'](after,model['plus_stress_slope_MPa_per_alpha'])<1e-19
    action=[-500.*dot((stress[i] for stress in op['R'][6]),diff(before,after))*(30000. if i>=56 else 1.) for i in range(60)]+[0.]*6
    assert adj['error'](action,model['projected_jump_in_derivative'])<1e-16
    raws=data['direction_samples']; assert len(raws)==2
    actions=[]; markers=[]
    for q in raws:
        frac=q['fraction']
        assert frac*cap==5e-10 and not q['plus_matches'] and q['minus_matches']
        assert sig(q['negative_markers'])==sy and sig(q['positive_markers'])==sx
        a=[v/frac for v in diff(y['all66'],q['negative_rows'])]
        markers.append((y['markers'][-1]-q['negative_markers'][-1])/frac)
        assert adj['error'](a,q['measured_action'])<2e-18
        actions.append(a)
    plan=data['plan']; coeff=plan['combination']
    assert len(coeff)==2 and all(0.<v<=1. for v in coeff)
    predicted=[r+dot(c,coeff) for r,c in zip(y['all66'],zip(*actions,strict=True),strict=True)]
    assert adj['error'](predicted,plan['predicted_rows'])<3e-18 and abs(norm(predicted)-plan['predicted_norm_MPa'])<2e-18
    projected_marker=y['markers'][-1]+dot(markers,coeff)
    assert projected_marker>0. and abs(projected_marker/z['markers'][-1]-1.)<.001
    shape=list(zip(*( [v/cap for v in all_strains(data['crossing_seed_move'])],
                       *([v/cap for v in all_strains(q['direction'])] for q in raws)),strict=True))
    feasible=left_cell_bound(y['all66'],list(zip(*actions,strict=True)),shape,y['markers'][-1],markers,tau)
    assert feasible['matching_left_cell_linear_norm_bracket_MPa'][0]>span[0]
    # Decompose the rejected N-gradient drift by the complete three stations
    # of point 7. This is distinct from the direct signed axial resultant.
    part=p7['point_contributions'](start['section'],z['section'],7,53,op)
    allparts=[p7['point_contributions'](start['section'],z['section'],i,53,op) for i in range(1,46)]
    observed_change=z['section']['normalized_60'][52]-start['section']['normalized_60'][52]
    assert abs(fsum(k for v in allparts for k in v)-observed_change)<3e-12
    assert abs(fsum(part)/observed_change-1.)<.003
    return {'status':'PASS','attempted_Qy_N':target[5],'last_accepted_Qy_N':55156.25,'preserved_history_count':53,
            'actual_augmented_norms_MPa':dict(anchor=span[0],crossed_seed=span[1],candidate_rejected=span[2],original_tolerance=tau),
            'left_branch_affine_candidate_MPa':norm(predicted),'actual_and_anticipated_candidate_p7_marker':[z['markers'][-1],projected_marker],
            'same_cell_feasibility':feasible,'candidate_raw_signed_six_N_Nmm':z['section']['signed_6'],
            'point7_contribution_to_weak_N_gradient_by_station_MPa':part,'actual_N_gradient_change_MPa':observed_change,
            'one_final_candidate_executed':True,'physical_limit_established':False}


def main(repo):
    raw=(HERE/'P7NaturalSwitchWire.json.gz').read_bytes(); assert sha(raw)==WIRE
    data=json.loads(gzip.decompress(raw))
    with tempfile.TemporaryDirectory(prefix='P7NaturalOffline_') as folder, archive(repo,KNOT) as k:
        root=Path(folder)
        def extract(z,name):
            f=root/name; f.write_bytes(z.read(name)); return runpy.run_path(str(f))
        knot=extract(k,'Verify-P7Knot.py'); initial=k.read('P7KnotLevelWire.json.gz')
        assert sha(initial)==knot['WIRE']==data['terminal_wire_sha256']
        with archive(repo,knot['OLD']) as z:
            adj=extract(z,'Verify-P7Adjacent.py'); shape=z.read('P7AllStationsWire.json.gz')
            assert sha(shape)==adj['STATION']==data['station_wire_sha256']
        with archive(repo,adj['P7']) as z:
            p7=extract(z,'Verify-P7.py')
        with archive(repo,p7['EXPANDED']) as z:
            ex=extract(z,'Verify-Expanded.py')
        with archive(repo,ex['PREVIOUS']) as z:
            prior=extract(z,'Verify-Cone.py'); old=z.read('ConeWire.json.gz'); assert sha(old)==prior['WIRE']
        with archive(repo,prior['STATION']) as z:
            watch=extract(z,'Verify-Stations.py')
        with archive(repo,watch['BASE']) as z:
            history=extract(z,'Verify-VectorEvidence.py')
        accepted,residual,_,_,_=history['history'](repo)
        assert accepted['Q_target_N']==55156.25 and residual<accepted['tolerance_MPa']
        with archive(repo,history['POST']) as z:
            past=extract(z,'Verify-Postyield.py')
        with archive(repo,past['AUTH']) as z:
            for f in ('Verify-Authoritative.py','Operators.py','Reequilibrate.py'):
                (root/f).write_bytes(z.read(f))
        sys.path.insert(0,str(root)); guard=runpy.run_path(str(root/'Verify-Authoritative.py'))
        operator,source=guard['unpack'](root,repo)
        engine=runpy.run_path(str(root/'Reequilibrate.py'))
        _,_,geo,_,area,length,op,_,_,identity=engine['read_inputs'](operator,root,source)
    assert data['operator_source']==identity
    return check(data,*[json.loads(gzip.decompress(x)) for x in (initial,shape,old)],adj,watch,past,p7,guard,op,geo,area,length)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--report',type=Path)
    options=parser.parse_args()
    result=main(options.repo)
    raw=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if options.report:
        with options.report.open('xb') as out: out.write(raw)
    print('MVT2_P7_NATURAL_SWITCH_OFFLINE_PASS',sha(raw),result['same_cell_feasibility']['matching_left_cell_linear_norm_bracket_MPa'])
