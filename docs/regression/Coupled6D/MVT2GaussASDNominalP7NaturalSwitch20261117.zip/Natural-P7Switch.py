"""A single two-direction actual-residual proposal through the p7 tensile branch."""
from pathlib import Path
from time import perf_counter
import gzip
import importlib.util
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('lock',HERE/'Lock-P7Knot.py')
lock=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(lock)
adjacent=lock.adjacent
study=lock.study
expand=lock.expand
cone=lock.cone
KNOT_WIRE='013E60B81278A070AAED99D6661FB0652E168CED98F7DEE8CEFDF8110C1D6F1C'
PROBE_STRAIN=5e-10


def prior_tangent(np,section,record):
    base=np.array(record['start_all66']); markers=np.array(record['start_markers'])
    J=np.zeros((66,60)); K=np.zeros((6,60))
    for p in record['finite_difference']['columns']:
        i=p['column']-1; step=p['step']; plus,minus=p['plus'],p['minus']
        r1,r2=(np.array(p['r_plus']),np.array(p['r_minus']))
        m1,m2=(np.array(p['m_plus']),np.array(p['m_minus']))
        if plus and minus:
            factor=.5/step; a,b=r1-r2,m1-m2
        elif plus:
            factor=1./step; a,b=r1-base,m1-markers
        else:
            assert minus; factor=1./step; a,b=base-r2,markers-m2
        J[:,i]=factor*a; K[:,i]=factor*b
    J[:60,56:]=section.G[:,56:]*section.scale[:,None]
    return J,K


def prior_station_slope(np,section,ray,K):
    p=ray['stations'][-1]
    assert (p['point'],p['side'])==(7,-1)
    table={x['alpha']:x for x in p['values']}
    event,=p['events']; lo,hi=event['actual_alpha_bracket']; a,b=event['outer_alpha']
    minus=(np.array(table[lo]['stress'])-np.array(table[a]['stress']))/(lo-a)
    plus=(np.array(table[b]['stress'])-np.array(table[hi]['stress']))/(b-hi)
    strength=K[-1]@np.array(ray['direction'])
    measured=(table[b]['equivalentTotalStrain'][0]-table[hi]['equivalentTotalStrain'][0])/(b-hi)
    assert strength>0. and abs(measured-strength)<.02*measured
    force=np.r_[(minus-plus)@section.project[2,6]*section.scale,np.zeros(6)]
    rank_one=np.outer(force,K[-1]/strength)
    return rank_one,{'minus_stress_slope_MPa_per_alpha':minus.tolist(),
                     'plus_stress_slope_MPa_per_alpha':plus.tolist(),'projected_jump_in_derivative':force.tolist(),
                     'computed_equivalent_tensile_slope':float(strength),'measured_equivalent_tensile_slope':measured}


def match(np,a,b):
    return np.array_equal(a[2],b[2]) and np.array_equal(np.sign(a[3]),np.sign(b[3]))


def measure_direction(np,section,x,load,base,vector,knot,d,cap,rank_one):
    factor=PROBE_STRAIN/cap
    rp=adjacent.current(np,section,x+factor*d,load,vector,knot)
    rm=adjacent.current(np,section,x-factor*d,load,vector,knot)
    plus=match(np,rp,base); minus=match(np,rm,base)
    receipt={'direction':d.tolist(),'fraction':factor,'plus_matches':bool(plus),'minus_matches':bool(minus),
             'positive_rows':rp[1].tolist(),'negative_rows':rm[1].tolist(),
             'positive_markers':rp[3].tolist(),'negative_markers':rm[3].tolist(),
             'rank_one_prediction':(rank_one@d).tolist()}
    if plus and minus:
        action=(rp[1]-rm[1])/(2.*factor)
    elif plus:
        action=(rp[1]-base[1])/factor
    elif minus:
        action=(base[1]-rm[1])/factor
    else:
        return None,receipt
    receipt['measured_action']=action.tolist()
    return action,receipt


def two_directions(np,section,J,res,cap):
    # The second direction concentrates its requested change on the four
    # largest measured residuals. Both are later screened against all 66 rows.
    main=np.argsort(np.abs(res))[-4:]
    targeted=np.zeros(66); targeted[main]=res[main]
    scale=np.linalg.norm(J,axis=0); assert np.all(scale>0.)
    dirs=np.linalg.lstsq(J/scale,-np.c_[res,targeted],rcond=1.e-12)[0]/scale[:,None]
    for i in range(dirs.shape[1]):
        dims=expand.physical(np,section,dirs[:,i]); assert dims>0.
        dirs[:,i]*=cap/dims
    assert np.linalg.matrix_rank(section.strain.reshape(-1,60)@dirs)==2
    return dirs,[int(v)+1 for v in main]


def choose(np,section,res,a,seed,directions,cap):
    from scipy.optimize import linprog

    normalization=float(np.max(np.abs(res)))
    strain_d=(section.strain @ directions).reshape(-1,2)/cap
    strain_seed=(section.strain @ seed).ravel()/cap
    action=a/normalization
    mat=np.vstack((np.c_[action,-np.ones(66)],np.c_[-action,-np.ones(66)],
                   np.c_[strain_d,np.zeros(len(strain_d))],np.c_[-strain_d,np.zeros(len(strain_d))]))
    b=np.r_[-res/normalization,res/normalization,1.-strain_seed,1.+strain_seed]
    optimum=linprog([0.,0.,1.],A_ub=mat,b_ub=b,bounds=[(-1.,1.),(-1.,1.),(0.,None)],
                    method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    report={'linear_status':int(optimum.status),'both_basis_coefficients_bounded_by_one':True}
    if not optimum.success:
        return None,report
    coefficients=optimum.x[:2]; d=directions@coefficients
    prediction=res+a@coefficients
    report.update({'combination':coefficients.tolist(),'correction':d.tolist(),'predicted_rows':prediction.tolist(),
                   'predicted_norm_MPa':float(np.max(np.abs(prediction))),'linear_total_travel':expand.physical(np,section,seed+d)})
    return d,report


def main():
    begun=perf_counter()
    saved=expand.read_wire('P7KnotLevelWire.json.gz',KNOT_WIRE)
    ray=expand.read_wire('P7AllStationsWire.json.gz',adjacent.PIN)
    older=expand.read_wire('ConeWire.json.gz',study.follow.PRIOR)
    _,probe,vector,receipt,np,ops,section,material,identity,load=study.exact_fixture()
    assert saved['operator_source']==identity and saved['same_material']==material
    assert saved['accepted_history_after']==53 and saved['target']==load.tolist()
    terminal=saved['candidate']; x=np.array(terminal['field']); knot=saved['p7_threshold']
    start=adjacent.current(np,section,x,load,vector,knot)
    assert probe.raw_section(section,x,load)==terminal['section'] and start[3].tolist()==terminal['markers']
    cap=saved['local_total_cap']; total=saved['cap_from_rejected_center']
    origin=np.array(older['first_rejected_trial'])
    assert expand.physical(np,section,x-origin)+cap<total
    J,K=prior_tangent(np,section,saved)
    update,material_action=prior_station_slope(np,section,ray,K)
    left_model=J+update
    normal=np.array(saved['plan']['minimum_norm_retraction_per_equivalent_strain'])
    assert np.isclose(K[-1]@normal,1.,atol=4e-14)
    # Move only far enough across the measured discontinuity to make its
    # actual residual present, then use that complete residual as the base.
    crossing=-2.*start[3][-1]*normal
    y=x+crossing
    base=adjacent.current(np,section,y,load,vector,knot)
    assert base[3][-1]<0.<start[3][-1] and np.array_equal(start[2],base[2])
    assert np.array_equal(np.sign(start[3][:5]),np.sign(base[3][:5]))
    watch=runpy.run_path(str(cone.PRIOR/'station/Verify-Stations.py'))
    base_snap=probe.raw_section(section,y,load)
    start_norm=terminal['actual_MPa']
    output={'terminal_wire_sha256':KNOT_WIRE,'station_wire_sha256':adjacent.PIN,'same_material':material,'operator_source':identity,
            'history_before':section.committed,'target':load.tolist(),'initial_field':x.tolist(),'initial_markers':start[3].tolist(),
            'initial_all66':start[1].tolist(),'initial_norm_MPa':start_norm,'local_cap':cap,'physical_cap_centered_at_first_rejection':total,
            'actual_station_tangent_difference':material_action,'crossing_seed_move':crossing.tolist(),
            'crossing_seed':{'field':y.tolist(),'section':base_snap,'markers':base[3].tolist(),'all66':base[1].tolist(),
                              'independent_norm_MPa':adjacent.follow_norm(section,watch,base_snap,y,load)},
            'direction_samples':[],'status':'no_reliable_measured_prediction'}
    directions,rows=two_directions(np,section,left_model,base[1],cap)
    output['targeted_direction_rows']=rows
    measured=[]
    for i in range(2):
        action,witness=measure_direction(np,section,y,load,base,vector,knot,directions[:,i],cap,left_model)
        output['direction_samples'].append(witness)
        if action is not None:
            measured.append(action)
    if len(measured)==2:
        d,model=choose(np,section,base[1],np.array(measured).T,crossing,directions,cap)
        output['plan']=model
        output['status']='two_direction_space_no_predicted_decrease'
        # A prospective improvement should exceed the measured negligible gain
        # of the previous exact-knot hold, without changing the true tolerance.
        past_progress=saved['start_section']['norm_MPa']-terminal['actual_MPa']
        output['previous_exact_knot_gain_MPa']=past_progress
        if d is not None and start_norm-model['predicted_norm_MPa']>past_progress:
            z=y+d
            end=adjacent.current(np,section,z,load,vector,knot)
            snap=probe.raw_section(section,z,load)
            result=adjacent.follow_norm(section,watch,snap,z,load)
            dist=expand.physical(np,section,z-x); budget=expand.physical(np,section,z-origin)
            held=np.array_equal(end[2],start[2]) and np.array_equal(np.sign(end[3][:5]),np.sign(start[3][:5]))
            allowed=bool(held and result<start_norm and dist<=cap*(1.+3e-9) and budget<=total)
            output['candidate']={'field':z.tolist(),'section':snap,'all66':end[1].tolist(),'markers':end[3].tolist(),
                                 'independent_norm_MPa':result,'physical_travel':dist,'cumulative_travel_from_rejected':budget,
                                 'held_other_markers_and_steel':bool(held),'admissible_improvement':allowed}
            output['status']='checked_one_candidate_rejected' if not allowed else (
                'balanced_uncommitted' if max(result,end[0][4])<=end[0][5] else 'one_admissible_non_equilibrium_reduction')
    assert probe.raw_section(section,x,load)==terminal['section'] and section.committed==53
    output['history_after']=section.committed
    ops.wipe()
    raw=gzip.compress(vector.raw_json(output),compresslevel=9,mtime=0)
    with (HERE/'P7NaturalSwitchWire.json.gz').open('xb') as sink:sink.write(raw)
    print('MVT2 ASD NATURAL P7 SWITCH WIRE',cone.digest(raw),len(raw),'seconds',perf_counter()-begun,output['status'])


if __name__=='__main__':
    main()
