"""Verify the independently corrected nominal section continuation without an engine."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
POST=("MVT2GaussASDNominalPostyield20261117","06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED")
PROOF="81C8F051FD0AF5AF16DF679EFED04D9B1BFDA97AEB13E1E7F95514D73710AA03"
WIRE="4E294A8405913BB1E66C82BC4C504D84DFA89BEE331B77AB1F4F4749178474CC"
REJECTED="F0D026284B14E17020BD6B52AB49744BB5770700AAB283F7A474AF474CD82305"
DIRECTION="CC38855508DF7B2E063FD1844D0AAAC918703E9C47D0D37806A25439D468A9A5"


def sha(raw):
    return sha256(raw).hexdigest().upper()


def check_manifest():
    seen=set()
    for line in (HERE/"SHA256SUMS").read_text(encoding="ascii").splitlines():
        digest,path=line.split("  ",1)
        pure=PurePosixPath(path)
        assert not pure.is_absolute() and ".." not in pure.parts and path not in seen
        assert sha((HERE/path).read_bytes())==digest
        seen.add(path)
    assert seen=={p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file() and p.name!="SHA256SUMS"}


def json_file(name,digest,raw=False):
    data=(HERE/name).read_bytes()
    assert sha(data)==digest
    return json.loads(gzip.decompress(data) if raw else data)


def main(repo):
    check_manifest()
    proof=json_file("FollowCorrected.json",PROOF)
    wire=json_file("FollowCorrected.stress.json.gz",WIRE,True)
    old_trial=json_file("RejectedNominal54.json",REJECTED)
    witness=json_file("RejectedNominal54Directional.json",DIRECTION)
    assert proof["native_postyield_prefix_sha256"]==POST[1] and proof["uncommitted_diagnostic_sha256"]==DIRECTION
    assert proof["status"]=="PASS" and not proof["physical_limit_established"]
    assert proof["accepted_stresses_sha256"]==WIRE and proof["exact_prefix_stress_and_steel_states"]==49
    assert old_trial["unchanged_committed_count"]==old_trial["prefix_exact_states"]==49
    assert witness["unchanged_history"] and witness["actual_norm_MPa"]<witness["tolerance_MPa"]
    archive=repo/"docs/regression/Coupled6D"/(POST[0]+".zip")
    assert sha(archive.read_bytes())==POST[1]
    with tempfile.TemporaryDirectory(prefix="MVTASDFollow_") as folder:
        root=Path(folder)
        with ZipFile(archive) as previous:
            (root/"Verify-Postyield.py").write_bytes(previous.read("Verify-Postyield.py"))
            frozen=json.loads(previous.read("Postyield.json"))
            prefix=json.loads(gzip.decompress(previous.read("Postyield.stress.json.gz")))
        past=runpy.run_path(str(root/"Verify-Postyield.py"))
        with past["archive"](repo,past["AUTH"]) as verified:
            for leaf in ("Verify-Authoritative.py","Operators.py","Reequilibrate.py"):
                (root/leaf).write_bytes(verified.read(leaf))
        sys.path.insert(0,str(root))
        guard=runpy.run_path(str(root/"Verify-Authoritative.py"))
        operator,source=guard["unpack"](root,repo)
        model=runpy.run_path(str(root/"Reequilibrate.py"))
        _,_,geo,dirs,area,length,op,_,_,identity=model["read_inputs"](operator,root,source)
        assert identity==proof["source_operator_identity"]
        path=frozen["result"]["accepted"]+proof["all_accepted"]
        sigmas=prefix["net_three_station_stress_MPa"]+wire["three_station_net_stresses"]
        steel=prefix["steel"]+wire["three_station_steel"]
        checks=[past["check_equilibrium"](s,p,op,geo,area,length,guard["signed_forces"]) for s,p in zip(sigmas,path,strict=True)]
        steel_check=past["verify_history"](path,steel,sigmas,op,dirs)
    assert [r["Q_target_N"] for r in path[49:]]==[54453.125,54726.5625,55000.,55156.25]
    recovery=proof["all_attempts"][0]
    assert recovery["stock"]==old_trial["exact_rejected_archive_diagnostic"]
    b=recovery["bounded_probe"]
    assert b["outcome"]=="accepted_original_equilibrium" and b["actual_probes_after_stock"]==4
    assert abs(b["alpha"]-witness["whole_residual_minimax_scalar"])<1e-12
    assert b["steel_side_identity"]==[True,True] and b["both_sides_reduce_governing_row"]
    assert b["predicted_full_norm_MPa"]+b["directional_disagreement_bound_MPa"]<=b["tolerance_MPa"]
    assert b["alpha"]<=b["alpha_max_with_trust"]<=4. and b["alpha"]*b["stock_direction_max_engineering_strain"]<=b["trust_extra_strain_bound_from_original_predictor"]
    assert b["actual_candidate_norm_MPa"]==witness["actual_norm_MPa"]
    assert abs(checks[49]-witness["actual_norm_MPa"])<2e-12
    assert len([r for r in proof["all_attempts"] if "bounded_probe" in r])==proof["limits"]["fallbacks_used"]==8
    assert proof["terminal"]=={"last_reached_Qy_N":55156.25,"requested_Qy_N":57500,"status":"bounded_numerical_stop"}
    print("MVT2 ASD DIRECTIONAL FOLLOW OFFLINE PASS",{"accepted_new_fields":4,"last_Qy_N":55156.25,
          "max_new_norm_MPa":max(checks[49:]),"maximum_steel_point_error_MPa":steel_check["max_point_stress_error_MPa"],
          "actual_first_recovery_norm_MPa":checks[49]})


if __name__=="__main__":
    p=ArgumentParser()
    p.add_argument("--repo",type=Path,default=Path.cwd())
    main(p.parse_args().repo)
