"""Continue the independent nominal ASD section with a bounded measured-direction correction."""
from hashlib import sha256
from math import isfinite
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
POST=REPO/"docs/regression/Coupled6D/MVT2GaussASDNominalPostyield20261117.zip"
POST_SHA="06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED"
UNCOMMITTED_SHA="CC38855508DF7B2E063FD1844D0AAAC918703E9C47D0D37806A25439D468A9A5"
TARGETS=(54453.125,55000.,*range(57500,80001,2500))
MAX_EXTRA=20
STEP=.25
ALPHA_CAP=4.


def sha(raw):
    return sha256(raw).hexdigest().upper()


def encoded(data):
    return json.dumps(data,sort_keys=True,separators=(",",":"),allow_nan=False).encode()


def affine_minimax(np,start,action,upper):
    candidates=[0.,float(upper)]
    for i in range(len(start)):
        if action[i]!=0.:
            candidates.append(float(-start[i]/action[i]))
        for k in range(i):
            for sign in (-1.,1.):
                difference=action[i]-sign*action[k]
                if difference!=0.:
                    candidates.append(float((sign*start[k]-start[i])/difference))
    return min((a for a in candidates if 0.<=a<=upper),
               key=lambda a:float(np.max(np.abs(start+a*action))))


def bounded_correction(np,section,program,field,load,last,predictor,q,reason):
    start=section.equations(field,load,True)
    residual,matrix,sigma,forces,norm,tolerance=start
    resume={"trigger":reason,"starting_norm_MPa":norm,"tolerance_MPa":tolerance,
            "committed_fields_before":section.committed,"actual_probes_after_stock":0}
    if norm<=tolerance:
        return None,{**resume,"outcome":"ordinary_acceptance_already_available"}
    original_tangents=section.next_steel[2].copy()
    try:
        delta=np.linalg.solve(matrix*section.scale[:,None],-residual*section.scale)
    except np.linalg.LinAlgError:
        return None,{**resume,"outcome":"singular_stock_direction"}
    magnitude=float(np.max(np.abs(section.strain@delta)))
    radius=float(np.max(np.abs(section.strain@(predictor-last))))
    resume.update({"stock_direction_max_engineering_strain":magnitude,
                   "trust_extra_strain_bound_from_original_predictor":radius})
    if not isfinite(magnitude) or magnitude<=0. or not isfinite(radius) or STEP*magnitude>radius:
        return None,{**resume,"outcome":"measured_probes_outside_physical_strain_trust"}
    def all_rows(values):
        return np.r_[values[0]*section.scale,(values[3]-load)/section.exact_force_scale]
    original=all_rows(start)
    active=int(np.argmax(np.abs(original)))
    raw=[]
    signs=[]
    for sign in (1.,-1.):
        resume["actual_probes_after_stock"]+=1
        try:
            sample=section.equations(field+sign*STEP*delta,load,False)
        except ArithmeticError:
            return None,{**resume,"outcome":"side_material_probe_invalid"}
        raw.append(all_rows(sample))
        signs.append(np.array_equal(original_tangents,section.next_steel[2]))
    if not all(signs):
        return None,{**resume,"outcome":"side_probe_changes_steel_tangent_branch","steel_side_identity":signs}
    along=(raw[0]-original)/STEP
    opposite=(original-raw[1])/STEP
    measured=.5*(along+opposite)
    resume.update({"active_equation_or_normalized_force_row":active+1,
                   "active_base_MPa":float(original[active]),
                   "measured_positive_side_active_action_MPa":float(along[active]),
                   "measured_negative_side_active_action_MPa":float(opposite[active]),
                   "steel_side_identity":signs,
                   "both_sides_reduce_governing_row":bool(along[active]*original[active]<0. and opposite[active]*original[active]<0.)})
    if not resume["both_sides_reduce_governing_row"]:
        return None,{**resume,"outcome":"governing_action_sign_disagreement"}
    upper=min(ALPHA_CAP,radius/magnitude,-original[active]/measured[active])
    chosen=affine_minimax(np,original,measured,upper)
    predicted=float(np.max(np.abs(original+chosen*measured)))
    signed_difference=.5*chosen*float(np.max(np.abs(along-opposite)))
    resume.update({"alpha_max_with_trust":upper,"alpha":chosen,"predicted_full_norm_MPa":predicted,
                   "directional_disagreement_bound_MPa":signed_difference})
    if chosen<=0. or predicted+signed_difference>tolerance:
        return None,{**resume,"outcome":"predicted_full_gate_cannot_close"}
    output=field+chosen*delta
    resume["actual_probes_after_stock"]+=1
    accepted=section.equations(output,load,False)
    resume["actual_candidate_norm_MPa"]=accepted[4]
    if accepted[4]>accepted[5] or not np.array_equal(original_tangents,section.next_steel[2]):
        return None,{**resume,"outcome":"actual_closure_or_steel_branch_rejected"}
    old_trial=[component.copy() for component in section.next_steel]
    resume["actual_probes_after_stock"]+=1
    confirmation=section.equations(output,load,False)
    assert np.array_equal(confirmation[2],accepted[2]) and np.array_equal(confirmation[0],accepted[0])
    assert all(np.array_equal(old,new) for old,new in zip(old_trial,section.next_steel,strict=True))
    assert section.committed==resume["committed_fields_before"]
    section.accepted_stresses.append(confirmation[2].tolist())
    section.commit()
    trace=program["q_record"](section,output,10510000.,q,confirmation,"measured_direction_accepted",0,[confirmation[4]])
    return (output,trace),{**resume,"outcome":"accepted_original_equilibrium"}


def main():
    started=perf_counter()
    fixture=runpy.run_path(str(HERE/"Postyield.py"))
    admit=(HERE/"RejectedNominal54Directional.json").read_bytes()
    assert sha(admit)==UNCOMMITTED_SHA
    assert sha(POST.read_bytes())==POST_SHA
    with ZipFile(POST) as archive:
        earlier=json.loads(archive.read("Postyield.json"))
        wire=json.loads(gzip.decompress(archive.read("Postyield.stress.json.gz")))
    SRC=fixture["SRC"]
    sys.path.insert(0,str(fixture["NUMPY"]));sys.path.insert(0,str(SRC))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0" and np.__version__=="2.3.5"
    program=runpy.run_path(str(SRC/"Reequilibrate.py"))
    shared,native,geo,dirs,area,length,op,seeds,obs,ident=program["read_inputs"](fixture["OPS"],fixture["NATIVE_ROOT"])
    assert ident==earlier["operators"]
    solve=program["try_correct"]
    cast=solve.__globals__
    cast["loads"]=lambda arrays,t,q:arrays.array((0.,-600.*q,0.,t,0.,q))
    steel=[]
    material=fixture["steel_section"](program["Section"],np,steel)
    command=program["commands"](shared,native,("default",))["default"]
    with_deadline=perf_counter()+120.
    section=material(np,ops,command,geo,dirs,area,length,op,with_deadline)
    accepted=earlier["result"]["accepted"].copy()
    for i,r in enumerate(accepted):
        net=section.equations(np.array(r["field"]),cast["loads"](np,r["T_target_Nmm"],r["Q_target_N"]),False)
        assert net[4]<=net[5] and np.array_equal(net[2],wire["net_three_station_stress_MPa"][i])
        section.accepted_stresses.append(net[2].tolist())
        section.commit()
    assert encoded(steel)==encoded(wire["steel"]) and section.committed==49
    log=[]
    fallback_count=0
    last_attempted_field=None
    terminal=None

    def advance(q,depth):
        nonlocal fallback_count,last_attempted_field
        last=np.array(accepted[-1]["field"])
        prior=np.array(accepted[-2]["field"])
        previous=accepted[-1]["Q_target_N"]
        step=previous-accepted[-2]["Q_target_N"]
        factor=(q-previous)/step
        predictor=last+factor*(last-prior) if abs(factor)<4. else last.copy()
        old=section.equations
        def observe(field,load,matrix=False):
            nonlocal last_attempted_field
            check=old(field,load,matrix)
            if not matrix:
                last_attempted_field=field.copy()
            return check
        last_attempted_field=None
        section.equations=observe
        try:
            field,evidence=solve(section,predictor,10510000.,q)
        finally:
            section.equations=old
        attempt={"requested_Qy_N":q,"depth":depth,"stock":{k:v for k,v in evidence.items() if k!="field"}}
        if field is None and last_attempted_field is not None and fallback_count<MAX_EXTRA and \
                evidence["kind"] in ("line_search_no_decrease","maximum_iterations"):
            fallback_count+=1
            candidate,favorable=bounded_correction(np,section,program,last_attempted_field,
                cast["loads"](np,10510000.,q),last,predictor,q,evidence["kind"])
            attempt["bounded_probe"]=favorable
            if candidate is not None:
                field,evidence=candidate
        log.append(attempt)
        if field is not None:
            accepted.append({**evidence,"phase":f"DirectQ{q:g}","subdivision":depth})
            return True
        if depth>=5 or fallback_count>=MAX_EXTRA:
            return False
        midpoint=(previous+q)*.5
        return advance(midpoint,depth+1) and advance(q,depth+1)

    print("START replayed",section.committed,"states; same nominal ray; bounded fallback",flush=True)
    for q in TARGETS:
        if not advance(q,0):
            terminal={"requested_Qy_N":q,"last_reached_Qy_N":accepted[-1]["Q_target_N"],"status":"bounded_numerical_stop"}
            break
        print("ACCEPTED",q,"MPa residual",accepted[-1]["all_weak_and_force_max_MPa"],flush=True)
    ops.wipe()
    after=accepted[49:]
    assert after and after[0]["Q_target_N"]==54453.125
    assert after[0]["status"]=="measured_direction_accepted"
    assert abs(after[0]["all_weak_and_force_max_MPa"]-json.loads(admit)["actual_norm_MPa"])<1e-12
    raw=gzip.compress(encoded({"three_station_net_stresses":section.accepted_stresses[49:],
                               "three_station_steel":steel[49:]}),mtime=0,compresslevel=9)
    report={"status":"PASS","working_scope":"independent nominal section, fixed T=10.51 kNm, Mx=-0.600Qy",
            "physical_limit_established":False,"native_postyield_prefix_sha256":POST_SHA,
            "uncommitted_diagnostic_sha256":UNCOMMITTED_SHA,"exact_prefix_stress_and_steel_states":49,
            "source_operator_identity":ident,"engine":"3.8.0","numpy":"2.3.5",
            "all_accepted":after,"all_attempts":log,"terminal":terminal,
            "limits":{"alpha_cap":ALPHA_CAP,"trust_extra":"one original predictor excursion, max 3-side point engineering strains",
                      "signed_delta_fraction":STEP,"fallback_budget":MAX_EXTRA,"fallbacks_used":fallback_count,
                      "original_stock_max_iters":14,"original_halving_depth":5},
            "accepted_stresses_sha256":sha(raw)}
    data=(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with (HERE/"FollowCorrected.stress.json.gz").open("xb") as f:f.write(raw)
    with (HERE/"FollowCorrected.json").open("xb") as f:f.write(data)
    print("PASS",sha(data),sha(raw),"final",after[-1]["Q_target_N"],terminal,"seconds",round(perf_counter()-started,6))


if __name__=="__main__":
    main()
