"""Replay one exact rejected nominal ASD step and inspect signed derivatives."""
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
POST=REPO/"docs/regression/Coupled6D/MVT2GaussASDNominalPostyield20261117.zip"
POST_SHA="06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED"
GOAL=54453.125


def sha(raw):
    return sha256(raw).hexdigest().upper()


def ranks(np,vector,n=8):
    return [[int(i)+1,float(vector[i])] for i in np.argsort(np.abs(vector))[-n:][::-1]]


def terms(np,section,change,row):
    contributions=np.einsum("spi,spi->sp",section.project[...,row],change)
    order=np.argsort(np.abs(contributions),axis=None)[::-1][:7]
    return [{"side":(0,1,-1)[int(i)//45],"point":int(i)%45+1,
             "action_MPa":float(contributions.flat[i])} for i in order]


def directional_witness(np,section,old,field,load,base,direction,steel0,row,eps):
    r,j,sigma,forces,norm,tau=base
    step=.25
    plus=old(field+step*direction,load,False)
    minus=old(field-step*direction,load,False)
    actual=(plus[2]-minus[2])/(2*step)
    strains=section.strain@field
    movement=section.strain@direction
    stock=np.zeros_like(sigma)
    for side in range(3):
        for point in range(45):
            raw=strains[side,point]
            spacing=eps+1e-5*np.max(np.abs(raw))
            tag=1+45*side+point
            for k in range(6):
                hi=raw.copy();lo=raw.copy()
                hi[k]+=spacing;lo[k]-=spacing
                stock[side,point]+=(np.array(section.trial(tag,hi))-np.array(section.trial(tag,lo)))/(2*spacing)*movement[side,point,k]
            if point>=25:
                direct=section.dirs[point]
                stock[side,point]=-stock[side,point]+steel0[side,point-25]*(direct@movement[side,point])*direct
    rank=terms(np,section,stock-actual,row)
    prediction=np.einsum("spi,spi->",section.project[...,row],stock)+(section.G@direction)[row]
    assert abs(prediction-(j@direction)[row])<5e-12
    derivative=(plus[0]-minus[0])/(2*step)
    force_error=(forces-load)/section.exact_force_scale
    force_action=(plus[3]-minus[3])/(2*step)/section.exact_force_scale
    rhs=np.r_[r*section.scale,force_error]
    tangent=np.r_[derivative*section.scale,force_action]
    assert rhs[row]*tangent[row]<0.
    # Compare the whole affine residual in the interval from the current field
    # to the measured zero of the single governing row. One actual probe only.
    upper=-rhs[row]/tangent[row]
    candidates=[0.,float(upper)]
    for i in range(len(rhs)):
        if tangent[i]!=0.:
            candidates.append(float(-rhs[i]/tangent[i]))
        for k in range(i):
            for sign in (-1.,1.):
                diff=tangent[i]-sign*tangent[k]
                if diff!=0.:
                    candidates.append(float((sign*rhs[k]-rhs[i])/diff))
    chosen=min((a for a in candidates if 0.<=a<=upper), key=lambda a:float(np.max(np.abs(rhs+a*tangent))))
    trial=old(field+chosen*direction,load,False)
    assert section.committed==49
    restored=old(field,load,False)
    assert np.array_equal(restored[2],sigma) and np.array_equal(restored[0],r)
    return {"station_rank_of_stock_minus_measured_row_action":rank,
            "stock_sum_error_from_assembled_MPa":float(prediction-(j@direction)[row]),
            "measured_zero_governing_row_scalar":float(upper),"whole_residual_minimax_scalar":chosen,
            "predicted_full_norm_MPa":float(np.max(np.abs(rhs+chosen*tangent))),
            "actual_norm_MPa":trial[4],"tolerance_MPa":tau,
            "unchanged_history":True,"actual_weak_ranks":ranks(np,trial[0][:56]),
            "actual_signed_resultants_N_Nmm":trial[3].tolist()}


def main():
    fixture=runpy.run_path(str(HERE/"Postyield.py"))
    assert sha(POST.read_bytes())==POST_SHA
    with ZipFile(POST) as z:
        assert z.read("Postyield.py")== (HERE/"Postyield.py").read_bytes()
        proof=json.loads(z.read("Postyield.json"))
        raw=json.loads(gzip.decompress(z.read("Postyield.stress.json.gz")))
    SRC=fixture["SRC"]; D=fixture["D"]
    sys.path.insert(0,str(fixture["NUMPY"]));sys.path.insert(0,str(SRC))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0" and np.__version__=="2.3.5"
    program=runpy.run_path(str(SRC/"Reequilibrate.py"))
    sh,report,geo,dirs,area,length,op,seeds,obs,identity=program["read_inputs"](fixture["OPS"],fixture["NATIVE_ROOT"])
    assert identity==proof["operators"]
    globals_=program["simulate"].__globals__
    globals_["loads"]=lambda arrays,t,q:arrays.array((0.,-600.*q,0.,t,0.,q))
    trigger=[]
    cls=fixture["steel_section"](program["Section"],np,trigger)
    command=program["commands"](sh,report,("default",))["default"]
    section=cls(np,ops,command,geo,dirs,area,length,op,perf_counter()+40.)
    accepted=proof["result"]["accepted"]
    for n,item in enumerate(accepted):
        field=np.array(item["field"])
        load=globals_["loads"](np,item["T_target_Nmm"],item["Q_target_N"])
        eval_=section.equations(field,load,False)
        assert eval_[4]<=eval_[5]
        assert np.array_equal(eval_[2],np.array(raw["net_three_station_stress_MPa"][n]))
        section.accepted_stresses.append(eval_[2].tolist())
        section.commit()
    compare=fixture["record_bytes"]
    assert compare(trigger)==compare(raw["steel"])
    events=[]
    old=section.equations
    def traced(field,load,matrix=False):
        value=old(field,load,matrix)
        if not matrix:
            events.append((field.copy(),value[0].copy(),value[4]))
        return value
    section.equations=traced
    q1=accepted[-1]["Q_target_N"];q0=accepted[-2]["Q_target_N"]
    field1=np.array(accepted[-1]["field"]);field0=np.array(accepted[-2]["field"])
    predictor=field1+(GOAL-q1)/(q1-q0)*(field1-field0)
    value,diagnostic=program["try_correct"](section,predictor,10510000.,GOAL)
    assert value is None and section.committed==49
    archived=proof["result"]["attempts"][-1]
    assert {k:archived[k] for k in diagnostic}==diagnostic
    field=events[-1][0]
    load=globals_["loads"](np,10510000.,GOAL)
    base=old(field,load,True)
    assert base[4]==archived["weak_or_forces_norm_MPa"] and np.array_equal(base[0],events[-1][1])
    r,J,sigma,forces,norm,tolerance=base
    steel0=section.next_steel[2].copy()
    direction=np.linalg.solve(J*section.scale[:,None],-r*section.scale)
    pred=J@direction
    max_row=int(np.argmax(np.abs(r[:56])))
    root=np.max(np.abs(section.strain@direction))
    probes=[]
    for h in (1/1024,1/256,1/64,1/16,1/4,1.):
        plus=old(field+h*direction,load,False)
        steel_plus=section.next_steel[2].copy()
        minus=old(field-h*direction,load,False)
        steel_minus=section.next_steel[2].copy()
        fp=(plus[0]-r)/h;fm=(r-minus[0])/h
        changes={}
        for sign,ss in (("plus",steel_plus),("minus",steel_minus)):
            changes[sign]=[{"station":(0,1,-1)[int(s)],"point":int(p)+26,
                            "before_tangent_MPa":float(steel0[s,p]),"after_tangent_MPa":float(ss[s,p])}
                           for s,p in np.argwhere(ss!=steel0)]
        probes.append({"factor":h,"plus_norm_MPa":plus[4],"minus_norm_MPa":minus[4],
                       "max_plus_minus_stock_derivative_errors_MPa": [float(np.max(np.abs(p[:56]-pred[:56]))) for p in (fp,fm)],
                       "dominant_row_pred_actual_plus_minus": [max_row+1,float(pred[max_row]),float(fp[max_row]),float(fm[max_row])],
                       "steel_branch_changes":changes,
                       "dominant_row_plus_station_action":terms(np,section,(plus[2]-sigma)/h,max_row),
                       "dominant_row_minus_station_action":terms(np,section,(sigma-minus[2])/h,max_row)})
    recovery=old(field,load,False)
    assert np.array_equal(recovery[0],r) and np.array_equal(recovery[2],sigma) and section.committed==49
    supplement=directional_witness(np,section,old,field,load,base,direction,steel0,max_row,program["EPS"]) if "--supplement" in sys.argv else None
    ops.wipe()
    evidence={"status":"PASS","archive":POST_SHA,"prefix_exact_states":49,"unchanged_committed_count":49,
              "Qy_N":GOAL,"exact_rejected_archive_diagnostic":diagnostic,"field":field.tolist(),
              "weak_and_gauge_residual_MPa_or_strain":r.tolist(),"physical_signed_resultants_N_Nmm":forces.tolist(),
              "norm_MPa":norm,"tolerance_MPa":tolerance,"ranked_abs_weak_rows":ranks(np,r[:56]),
              "matrix_delta_field":direction.tolist(),"matrix_delta_max_station_engineering_strain":float(root),
              "baseline_trial_min_norm_MPa":min(row[2] for row in events),
              "baseline_total_residual_calls":len(events),"probes_no_commit":probes}
    data=(json.dumps(evidence,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    output=HERE/"RejectedNominal54.json"
    if supplement is not None:
        assert output.read_bytes()==data
        data=(json.dumps(supplement,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
        output=HERE/"RejectedNominal54Directional.json"
    with output.open("xb") as f:f.write(data)
    print("PASS",sha(data),"top weak",evidence["ranked_abs_weak_rows"])


if __name__=="__main__":
    main()
