"""Verify the signed joint-direction measurement, exact history and conditional full field."""
import argparse
import csv
import json
from pathlib import Path

import VerifyBase as v

HERE=Path(__file__).resolve().parent
NATIVE=HERE/"NativeHalf"
LABELS=("HalfCenter","HalfGradient","HalfJoint","FullJoint")


def vector(state,stations):
    r,_,_=v.reconstruct(state["field"],state["q"],stations)
    return (*state["r"],*(a*v.MODULUS for a in r[-4:]))


def row(name):
    raw=(HERE/name).read_bytes()
    assert raw.count(b"\r\n")==raw.count(b"\n")==1
    return raw.decode("ascii").strip().split(";")


def prepare():
    prep=v.read(HERE/"Preparation.json")
    assert all(v.digest(HERE/name)==expected for name,expected in prep["inputs"].items())
    assert v.digest(HERE/"workbook/output/RC_Section_NDM.xlsm")==prep["book_sha256"]
    assert v.digest(HERE/"Replay.csv")==prep["replay_sha256"]
    plan=v.read(HERE/"JointPlan.json")
    assert v.digest(HERE/"PreviousNative.csv")==plan["source_event_trace_sha256"]
    archive,stations=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    base=archive["NormalsHalf"]
    assert base["q"]==plan["q_trial_kN"] and base["field"]==tuple(plan["base_field"])==tuple(map(float,row("AnchorField.csv")))
    match=vector(base,stations["NormalsHalf"])
    assert v.peak(v.diff(match,plan["base_all66_MPa"]))<4e-15
    assert tuple(map(float,row("ArchiveOrigin.csv")))==tuple(plan["base_all66_MPa"])
    gate=tuple(map(float,row("JointGate.csv")))
    assert gate==(plan["tau_MPa"],*plan["original_caps_MPa"],*plan["last_full_vector_actual_defect_MPa"][56:62])
    fields={}
    for label in LABELS:
        key,radius,*d=row(label+".csv")
        size=float(radius)
        delta=tuple(map(float,d))
        assert key==label and len(delta)==60 and v.tensor_radius(delta,base["geometry"])<=size+4e-16
        assert size<=(1e-8 if label!="FullJoint" else 2e-8)+4e-16
        fields[label]=delta
    assert fields["HalfCenter"][52:56]==(0.,)*4 and fields["HalfGradient"][:52]==(0.,)*52
    assert fields["HalfGradient"][56:]==(0.,)*4
    assert tuple(a+b for a,b in zip(fields["HalfCenter"],fields["HalfGradient"],strict=True))==fields["HalfJoint"]
    assert tuple(2*a for a in fields["HalfJoint"])==fields["FullJoint"]
    return prep,plan,base,stations["NormalsHalf"],fields,gate[7:]


def verify(prep,plan,old,old_stations,fields,pads):
    build=v.read(HERE/"docs/regression/CodeUpdate.json")
    compiler=v.read(HERE/"CompileClosure.json")
    owner=v.read(NATIVE/"MVT2.txt.Ownership.json")
    watcher=v.read(NATIVE/"MVT2.txt.ProcessClosure.json")
    run=v.read(NATIVE/"RunReceipt.json")
    assert build["Compiled"] and build["Modules"]==["modTestCoupledExperiment"] and not build["ProductionChanged"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and compiler["State"]=="Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    final=watcher["Closure"]["FinalState"]
    assert watcher["Passed"] and watcher["ChildHasExited"] and watcher["ChildExitCode"]==run["native_exit"]==0
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (NATIVE/"MVT2.txt").read_text(encoding="utf-8-sig")
    path=NATIVE/"MVT2.csv"
    tags=v.read_native(path)
    states,stations=v.verified_states(tags)
    [[qbase,q]]=tags["B_TANGENT_LOAD"]
    assert (float(qbase),float(q))==(plan["q_accepted_kN"],plan["q_trial_kN"])
    history=v.vec(tags,"MVT2_CONTROL_FIELD")
    rows=list(csv.reader((HERE/"Replay.csv").read_text().splitlines(),delimiter=";"))[1:]
    assert len(rows)==len(history)==24
    for i,raw in enumerate(rows,1):
        assert int(raw[0])==i and v.peak(v.diff(tuple(map(float,raw[9:])),history[f"Replay{i}"]))<1e-15
    assert states["Restored24"]==states["Base24"] and stations["Restored24"]==stations["Base24"]
    assert states["Base24"]["field"]==history["Replay24"]
    base=states["NormalsHalf"]
    base_stations=stations["NormalsHalf"]
    basevec=vector(base,base_stations)
    assert v.peak(v.diff(basevec,vector(old,old_stations)))<8e-10
    steel=v.verify_steel(tags,states,stations,history)
    caps=plan["original_caps_MPa"]
    cases={}
    for label,delta in fields.items():
        if label not in states:
            continue
        state=states[label]
        assert state["q"]==base["q"] and state["geometry"]==base["geometry"]
        assert v.peak(v.diff(state["field"],tuple(a+b for a,b in zip(base["field"],delta,strict=True))))<3e-15
        this=vector(state,stations[label])
        changed=[key for key,value in base_stations.items() if key[0]<=25
                 and (value[3:6]!=stations[label][key][3:6] or value[6]*stations[label][key][6]<=0.)]
        okay=all(abs(a)<=c for a,c in zip(this[56:62],caps,strict=True))
        cases[label]={"all66_MPa":this,"norm_MPa":v.peak(this),"signed_six_N_Nmm":state["signed_force_N_Nmm"],
          "gauge_MPa":list(this[-4:]),"branches_changed":changed,"six_caps_pass":okay,"peak_steel_MPa":steel[label],
          "gain_over_tau":(v.peak(basevec)-v.peak(this))/plan["tau_MPa"]}
    [[pass_raw,prediction,n_center,r55_gradient]]=tags["B_JOINT_GATE"]
    n_center,r55_gradient,prediction=map(float,(n_center,r55_gradient,prediction))
    native_gate=bool(int(pass_raw))
    diag={"trace_sha256":v.digest(path),"compiler":compiler,"owner":final,"wall_seconds":run["wall_seconds"],
          "H24_exact_rollback":True,"history_published":False,"τ_MPa":plan["tau_MPa"],
          "base_all66_MPa":basevec,"cases":cases,"full_allowed_by_native_gate":native_gate,
          "native_scaled_signed_half_norm_MPa":prediction,"native_half_axial_action_N":n_center,
          "native_half_gradient_action_MPa":r55_gradient}
    if all(label in cases for label in LABELS[:3]):
        c,g,j=[cases[label]["all66_MPa"] for label in LABELS[:3]]
        assert v.peak(v.diff(g[56:62],basevec[56:62]))<4e-10 and v.peak(v.diff(j[56:62],c[56:62]))<4e-10
        da=v.diff(c,basevec)
        db=v.diff(g,basevec)
        mat=((da[56]*v.AREA,db[56]*v.AREA),(da[54],db[54]))
        interaction=[a-b-d+e for a,b,d,e in zip(j,c,g,basevec,strict=True)]
        assert abs(mat[0][0]-n_center)<2e-5 and abs(mat[1][1]-r55_gradient)<4e-10
        extrap=[2*a-b for a,b in zip(j,basevec,strict=True)]
        force_spare=[limit-abs(k)-p for limit,k,p in zip(caps,extrap[56:62],pads,strict=True)]
        measured=max(v.peak(extrap[:56]),v.peak(extrap[-4:]),max(abs(x)+p for x,p in zip(extrap[56:62],pads,strict=True)))
        assert abs(measured-prediction)<4e-10
        diag.update({"measured_2_by_2_N_and_weak55":mat,"true_interaction_inf_MPa":v.peak(interaction),
            "interaction_N_and_weak55":[interaction[56]*v.AREA,interaction[54]],
            "scaled_forecast_signed_effort_spares_MPa":force_spare})
        if native_gate:
            assert all(cases[name]["six_caps_pass"] and not cases[name]["branches_changed"] for name in LABELS[:3])
            assert min(force_spare)>=-4e-10
            assert measured<=v.peak(basevec)-8*plan["tau_MPa"]+4e-10
            assert mat[0][0]>2.5*plan["tau_MPa"]*v.AREA and mat[1][1]<-2.5*plan["tau_MPa"]
            assert tags["B_JOINT_FULL_BRANCH"]==[["1"]]
            assert "FullJoint" in cases or ["FullJoint","Residual"] in tags["B_TANGENT_UNAVAILABLE"]
    if "FullJoint" in cases:
        diag["full_materially_improves"]=cases["FullJoint"]["six_caps_pass"] and not cases["FullJoint"]["branches_changed"] and cases["FullJoint"]["gain_over_tau"]>=8
        diag["native_equilibrium"]=cases["FullJoint"]["norm_MPa"]<=plan["tau_MPa"]
    return diag


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--inputs-only",action="store_true")
    p.add_argument("--phase",choices=("Half",))
    args=p.parse_args()
    frozen=prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert args.phase=="Half"
        result=verify(*frozen)
        out=HERE/"VerificationHalf.json"
        out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
        print(out,v.digest(out))
