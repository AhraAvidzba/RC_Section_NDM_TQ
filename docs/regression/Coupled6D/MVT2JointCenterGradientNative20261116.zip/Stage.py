"""Seal branch-cell joint probe and separate center and gradient witnesses."""
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"event"
PIN="60DE46B7044294109413E368C03418A5D0FE4B4F8EEB1C5F035E5E08CDA515C7"
PLAN="94793E28775B91FD46CCBE9F552A911D83773DB9A32006FBA436F758A0D4FB20"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name,raw):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==raw,path
    else:
        path.write_bytes(raw)
    return digest(raw)


def only(text,pattern,replacement):
    assert text.count(pattern)==1,pattern
    return text.replace(pattern,replacement)


def row(values):
    return (";".join(str(value) for value in values)+"\r\n").encode("ascii")


def main(repo):
    evidence=BASE/"MVT2SeparatedEventsNative20261116.zip"
    assert digest(evidence.read_bytes())==PIN
    assert digest((HERE/"JointPlan.json").read_bytes())==PLAN
    plan=json.loads((HERE/"JointPlan.json").read_text())
    cases=plan["selected_joint_experiment"]
    assert cases["gain_over_tau"]>=8 and cases["radius"]==2e-8 and cases["parts"]
    with ZipFile(evidence) as archive:
        prep=json.loads(archive.read("Preparation.json"))
        assets=("Replay.csv","VerifyBase.py","Guard-IsolatedOffice.ps1","Run-MVT2ShearControlled.ps1",
                *(name for name in prep["inputs"] if name.startswith("tools/")))
        inputs={name:save(name,archive.read(name)) for name in assets}
        assert all(inputs[name]==prep["inputs"][name] for name in assets)
        old=archive.read("NativeHalf/MVT2.csv")
        inputs["PreviousNative.csv"]=save("PreviousNative.csv",old)
        assert inputs["PreviousNative.csv"]==plan["source_event_trace_sha256"]
        vba=archive.read("Control.bas").decode("utf8")
        tests=archive.read("tests/modTestCoupledExperiment.bas").decode("utf8").replace("\r\n","\n")
    s1='    RecordWangFreshTrialsTest output, folder & phase & "\\Candidate.csv", history, solver, operators, materials, responses, base, anchor, qTrial'
    vba=only(vba,s1,'''    ProbeWangJointPartsTest output, folder, history, solver, operators, materials, responses, _
        base, anchor, qTrial, norm, referenceForces, residual''')
    reused=vba.index("Private Sub RecordWangFreshTrialsTest")
    beginning=vba.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,reused)
    end=vba.index("End Sub",reused)+len("End Sub")
    vba=vba[:beginning]+vba[end:]+(HERE/"NativeJoint.bas").read_text(encoding="utf8")
    entry="Public Function RunTestWangShearControlled("
    boundary=tests.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,tests.index(entry))
    module=(tests[:boundary]+vba).replace("\n","\r\n").encode("utf8")
    assert module.count(entry.encode())==1
    inputs["Control.bas"]=save("Control.bas",vba.encode("utf8"))
    inputs["tests/modTestCoupledExperiment.bas"]=save("tests/modTestCoupledExperiment.bas",module)
    inputs["JointPlan.json"]=PLAN
    inputs["AnchorField.csv"]=save("AnchorField.csv",row(plan["base_field"]))
    inputs["ArchiveOrigin.csv"]=save("ArchiveOrigin.csv",row(plan["base_all66_MPa"]))
    inputs["JointGate.csv"]=save("JointGate.csv",row((plan["tau_MPa"],*plan["original_caps_MPa"],
                *plan["last_full_vector_actual_defect_MPa"][56:62])))
    for label,step,mode in (("HalfCenter",.5,"center"),("HalfGradient",.5,"gradient"),("HalfJoint",.5,"joint"),("FullJoint",1.,"joint")):
        shape=cases["predicted"][mode]["radius"]
        dq=cases["predicted"][mode]["dq"]
        inputs[label+".csv"]=save(label+".csv",row((label,step*shape,*(step*value for value in dq))))
    book="workbook/output/RC_Section_NDM.xlsm"
    raw=(repo/book).read_bytes()
    assert digest(raw)==prep["book_sha256"]
    save(book,raw)
    save("docs/regression/Diagnostic.xlsm",raw)
    for directory in ("src","Temp","NativeHalf"):
        (HERE/directory).mkdir(exist_ok=True)
    inputs["Verify-MVT2ShearControlled.py"]=digest((HERE/"Verify-MVT2ShearControlled.py").read_bytes())
    result={"inputs":inputs,"book_sha256":prep["book_sha256"],"replay_sha256":plan["history_prefix"],
            "source_event_proof_sha256":PIN,"watchdog_seconds":200}
    print(save("Preparation.json",(json.dumps(result,indent=2)+"\n").encode("utf8")))


if __name__=="__main__":
    main(Path(sys.argv[1]).resolve(strict=True))
