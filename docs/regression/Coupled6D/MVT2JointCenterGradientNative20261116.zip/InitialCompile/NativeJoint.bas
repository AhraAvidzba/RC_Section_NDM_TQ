
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Измеряет раздельные действия центра и продольных уклонов, затем условно полное поле.
Private Sub ProbeWangJointPartsTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByRef anchor() As Double, ByVal factor As Double, ByVal originNorm As Double, _
        ByRef originEfforts() As Double, ByRef originWeak() As Double)
    Dim field() As Double, partial() As Double, actual() As Double, weak() As Double
    Dim demand(1 To 6) As Double, scale(1 To 6) As Double, cap(1 To 6) As Double, pad(1 To 6) As Double
    Dim row As String, values As Variant, file As Integer, k As Long, norm As Double, minimum As Double
    Dim area As Double, length As Double, openFull As Boolean, currentCaps As Boolean, branchOK As Boolean
    Dim nCenter As Double, r55Gradient As Double, extrap As Double, trial As Variant
    file = FreeFile
    Open folder & "JointGate.csv" For Input As #file
    Line Input #file, row
    Close #file
    values = Split(row, ";")
    If UBound(values) <> 12 Then Err.Raise 5, , "Неверный допуск раздельных проб."
    minimum = Val(values(0))
    operators.CopyResultantResidualScales area, length
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For k = 1 To 6
        scale(k) = area
        If k >= 2 And k <= 4 Then scale(k) = area * length
        cap(k) = Val(values(k)): pad(k) = Val(values(6 + k))
    Next k
    openFull = True
    For Each trial In Array("HalfCenter", "HalfGradient", "HalfJoint")
        ReadWangJointInputTest output, folder & CStr(trial) & ".csv", CStr(trial), operators, anchor, field
        RestoreWangShearBaselineTest solver, history, base
        norm = RecordWangTangentStateTest(output, CStr(trial), 24, factor, solver, operators, materials, responses, field, actual, weak)
        branchOK = False: currentCaps = False
        If norm >= 0# Then
            branchOK = CheckWangJointBranchesTest(operators, materials, anchor, field)
            currentCaps = True
            For k = 1 To 6
                If Abs((actual(k) - demand(k)) / scale(k)) > cap(k) Then currentCaps = False
            Next k
            If trial = "HalfCenter" Then nCenter = actual(1) - originEfforts(1)
            If trial = "HalfGradient" Then r55Gradient = weak(55) - originWeak(55)
            If trial = "HalfJoint" Then
                For k = 1 To 56
                    extrap = GeomMax(extrap, Abs(2# * weak(k) - originWeak(k)))
                Next k
                For k = 57 To 60
                    extrap = GeomMax(extrap, 30000# * Abs(2# * weak(k) - originWeak(k)))
                Next k
                For k = 1 To 6
                    extrap = GeomMax(extrap, Abs((2# * actual(k) - originEfforts(k) - demand(k)) / scale(k)) + pad(k))
                    If Abs((2# * actual(k) - originEfforts(k) - demand(k)) / scale(k)) + pad(k) > cap(k) Then openFull = False
                Next k
            End If
        End If
        If Not (branchOK And currentCaps) Then openFull = False
        Print #output, "B_JOINT_PART;" & CStr(trial) & ";" & CStr(Abs(CLng(branchOK))) & ";" & CStr(Abs(CLng(currentCaps)))
        RequireWangAcceptedFieldTest solver, base
    Next trial
    If nCenter <= 2.5 * minimum * area Or r55Gradient >= -2.5 * minimum Then openFull = False
    If extrap > originNorm - 8# * minimum Then openFull = False
    If openFull Then
        ReadWangJointInputTest output, folder & "FullJoint.csv", "FullJoint", operators, anchor, field
        RestoreWangShearBaselineTest solver, history, base
        openFull = CheckWangJointBranchesTest(operators, materials, anchor, field)
        Print #output, "B_JOINT_FULL_BRANCH;" & CStr(Abs(CLng(openFull)))
    End If
    Print #output, "B_JOINT_GATE;" & CStr(Abs(CLng(openFull))) & ";" & _
        ExperimentNumberTest(extrap) & ";" & ExperimentNumberTest(nCenter) & ";" & ExperimentNumberTest(r55Gradient)
    If openFull Then
        norm = RecordWangTangentStateTest(output, "FullJoint", 24, factor, solver, operators, materials, responses, field, actual, weak)
        RequireWangAcceptedFieldTest solver, base
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает замороженное приращение и проверяет его станционные тензоры.
Private Sub ReadWangJointInputTest(ByVal output As Integer, ByVal path As String, ByVal label As String, _
        ByVal operators As CCoupledElasticState, ByRef anchor() As Double, ByRef field() As Double)
    Dim file As Integer, row As String, values As Variant, k As Long
    Dim delta(1 To 60) As Double, radius As Double, actual As Double
    file = FreeFile: Open path For Input As #file
    Line Input #file, row
    If Not EOF(file) Then Err.Raise 5, , "Лишняя строка раздельной пробы."
    Close #file
    values = Split(row, ";")
    If UBound(values) <> 61 Or values(0) <> label Then Err.Raise 5, , "Неверное поле раздельной пробы."
    radius = Val(values(1))
    For k = 1 To 60: delta(k) = Val(values(1 + k)): Next k
    actual = WangBoundedTensorPeakTest(operators, delta)
    If actual > radius + 0.0000000000000004 Or radius > 0.0000000200000004 Then _
        Err.Raise 5, , "Приращение выходит за измеряемое поле."
    AddWangTangentDirectionTest anchor, delta, 1#, field
    Print #output, "B_JOINT_INPUT;" & label & ";" & ExperimentNumberTest(radius) & ";" & ExperimentNumberTest(actual)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет знаки пробной поверхности и фактические ветви по всем бетонным станциям.
Private Function CheckWangJointBranchesTest(ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef anchor() As Double, ByRef field() As Double) As Boolean
    Dim p As Long, side As Long, k As Long, f0 As Double, f1 As Double, plastic0 As Boolean, plastic1 As Boolean
    Dim sign0 As Long, sign1 As Long, sub0 As Long, sub1 As Long
    Dim a(1 To 6) As Double, da(1 To 6) As Double, b(1 To 6) As Double, db(1 To 6) As Double
    Dim pa(1 To 6) As Double, pb(1 To 6) As Double, unused(1 To 6) As Double
    For p = 1 To operators.ConcretePointCount
        operators.PointStrain p, anchor, a
        operators.AxialGradientAtPoint p, anchor, da
        operators.PointStrain p, field, b
        operators.AxialGradientAtPoint p, field, db
        For side = -1 To 1
            For k = 1 To 6
                pa(k) = a(k) + side * 0.001 * da(k): pb(k) = b(k) + side * 0.001 * db(k)
            Next k
            If Not materials(side).TryReadTrialYield(p, pa, f0, unused, needGradient:=False) Then Exit Function
            If Not materials(side).TryReadTrialYield(p, pb, f1, unused, needGradient:=False) Then Exit Function
            If f0 * f1 <= 0# Then Exit Function
            If Not materials(side).TryReadConcreteBranch(p, pa, plastic0, sign0, sub0) Then Exit Function
            If Not materials(side).TryReadConcreteBranch(p, pb, plastic1, sign1, sub1) Then Exit Function
            If plastic0 <> plastic1 Or sign0 <> sign1 Or sub0 <> sub1 Then Exit Function
        Next side
    Next p
    CheckWangJointBranchesTest = True
End Function
