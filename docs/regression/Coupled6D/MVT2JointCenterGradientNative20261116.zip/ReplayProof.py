"""Replay the native joint decomposition, stopped full gate and both Office receipts."""
from importlib.util import module_from_spec, spec_from_file_location
import argparse
from hashlib import sha256
import json
from pathlib import Path

import VerifyBase as v

HERE=Path(__file__).resolve().parent
NATIVE="E148698E4BD763828EB7131F49BE333424BC8B06EFF520674A9AAD5FAB763DB3"
RECEIPT="EAC3943860ACC076663D166BCB9A371F0D00C5B835FBDE0EB325A84A3A8FD9C1"


def load():
    spec=spec_from_file_location("joint_native_test",HERE/"Verify-MVT2ShearControlled.py")
    result=module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def replay(options):
    prep=v.read(HERE/"Preparation.json")
    plan=v.read(HERE/"JointPlan.json")
    assert all(v.digest(HERE/name)==expected for name,expected in prep["inputs"].items())
    if options.workbook is not None:
        assert v.digest(options.workbook)==prep["book_sha256"]
    source=load()
    states,stations=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    anchor=states["NormalsHalf"]
    assert tuple(plan["base_field"])==anchor["field"]==tuple(map(float,source.row("AnchorField.csv")))
    assert anchor["q"]==plan["q_trial_kN"] and v.digest(HERE/"Replay.csv")==prep["replay_sha256"]
    gate=tuple(map(float,source.row("JointGate.csv")))
    assert gate==(plan["tau_MPa"],*plan["original_caps_MPa"],*plan["last_full_vector_actual_defect_MPa"][56:62])
    fields={}
    for name in source.LABELS:
        label,rad,*d=source.row(name+".csv")
        assert label==name
        delta=tuple(map(float,d)); fields[name]=delta
        assert v.tensor_radius(delta,anchor["geometry"])<=float(rad)+4e-16
    assert tuple(a+b for a,b in zip(fields["HalfCenter"],fields["HalfGradient"],strict=True))==fields["HalfJoint"]
    assert tuple(2*x for x in fields["HalfJoint"])==fields["FullJoint"]
    result=source.verify(prep,plan,anchor,stations["NormalsHalf"],fields,gate[7:])
    raw=HERE/"VerificationHalf.json"
    assert result["trace_sha256"]==NATIVE and v.digest(raw)==RECEIPT
    assert (json.dumps(result,indent=2)+"\n").replace("\n","\r\n").encode("utf8")==raw.read_bytes()
    failed=v.read(HERE/"InitialCompile/FailedCompileClosure.json")
    log=(HERE/"InitialCompile/Compile.log").read_text(encoding="utf-8-sig")
    assert failed=={"State":"Absent","PID":18936,"StartTicksUTC":"639304482376161967"}
    assert f"OWNED_EXCEL: id={failed['PID']}; utcStartTicks={failed['StartTicksUTC']}" in log
    assert "COMPILE_LOCATION: module=modTestCoupledExperiment; line=1936; column=1" in log
    prior=(HERE/"InitialCompile/modTestCoupledExperiment.bas")
    previous_prep=v.read(HERE/"InitialCompile/Preparation.json")
    assert v.digest(prior)==previous_prep["inputs"]["tests/modTestCoupledExperiment.bas"]
    for name in ("JointPlan.json","AnchorField.csv","ArchiveOrigin.csv","Replay.csv","PreviousNative.csv",
                 "JointGate.csv","HalfCenter.csv","HalfGradient.csv","HalfJoint.csv","FullJoint.csv"):
        assert prep["inputs"][name]==previous_prep["inputs"][name]
    assert "scale(1 To 6)" in prior.read_text(encoding="utf8")
    assert "effortScale(1 To 6)" in (HERE/"tests/modTestCoupledExperiment.bas").read_text(encoding="utf8")
    assert result["H24_exact_rollback"] and not result["history_published"] and not result["full_allowed_by_native_gate"]
    native_tags=v.read_native(HERE/"NativeHalf/MVT2.csv")
    assert not native_tags["B_JOINT_FULL_BRANCH"]
    assert [row[0] for row in native_tags["B_JOINT_INPUT"]]==list(source.LABELS[:3])
    for case in result["cases"].values():
        assert case["six_caps_pass"] and not case["branches_changed"]
    before=result["base_all66_MPa"]
    c=result["cases"]["HalfCenter"]["all66_MPa"]
    g=result["cases"]["HalfGradient"]["all66_MPa"]
    joint=result["cases"]["HalfJoint"]["all66_MPa"]
    tau=plan["tau_MPa"]
    gate_value=v.peak(before)-8*tau
    forecast=v.diff([2*x for x in joint],before)
    guard_rows=[abs(e)+(gate[7+i-56] if 56<=i<62 else 0.) for i,e in enumerate(forecast)]
    assert abs(max(guard_rows)-result["native_scaled_signed_half_norm_MPa"])<4e-10
    assert max(guard_rows)>gate_value
    actual_spare=[(u-abs(a))*f for u,a,f in zip(plan["original_caps_MPa"],joint[56:62],v.SCALES,strict=True)]
    full_caps=[v*n for v,n in zip(result["scaled_forecast_signed_effort_spares_MPa"],v.SCALES,strict=True)]
    interaction=[a-b-d+e for a,b,d,e in zip(joint,c,g,before,strict=True)]
    report={"source_book_sha256":prep["book_sha256"],"native_trace_sha256":NATIVE,
            "verification_sha256":RECEIPT,"prep_sha256":v.digest(HERE/"Preparation.json"),
            "overlay_sha256":prep["inputs"]["tests/modTestCoupledExperiment.bas"],"H24_sha256":prep["replay_sha256"],
            "initial_failed_compiler":failed,"successful_compiler":result["compiler"],"successful_owner":result["owner"],
            "native_wall_s":result["wall_seconds"],"exact_H24_rollback":True,"history_published":False,"physical_limit_certified":False,
            "q_trial_kN":plan["q_trial_kN"],"q_accepted_kN":plan["q_accepted_kN"],"tau_MPa":tau,
            "native_joint_norm_MPa":v.peak(joint),"native_joint_gain_over_tau":result["cases"]["HalfJoint"]["gain_over_tau"],
            "measured_joint_half_action":result["measured_2_by_2_N_and_weak55"],
            "interaction_max_MPa":v.peak(interaction),"interaction_peak_row":max(range(66),key=lambda i:abs(interaction[i]))+1,
            "measured_interaction_N_and_weak55":result["interaction_N_and_weak55"],
            "half_joint_actual_active_rows":[[i+1,joint[i]] for i in sorted(range(66),key=lambda i:abs(joint[i]),reverse=True)[:12]],
            "half_joint_actual_six_margins_N_Nmm":dict(zip(v.EFFORT_NAMES,actual_spare,strict=True)),
            "scaled_half_forecast_with_pad_MPa":result["native_scaled_signed_half_norm_MPa"],
            "maximum_forecast_to_open_full_MPa":gate_value,"scaled_half_gate_excess_MPa":result["native_scaled_signed_half_norm_MPa"]-gate_value,
            "scaled_forecast_governing_row":max(range(66),key=lambda i:guard_rows[i])+1,
            "scaled_forecast_force_margins_N_Nmm":dict(zip(v.EFFORT_NAMES,full_caps,strict=True)),
            "full_probed":False,"local_wide_floors_not_physical":[s["minimum_norm"].get("upper_norm_MPa") for s in plan["wide_linear_screen_only"].values()]}
    out=HERE/"PortableReport.json"
    data=(json.dumps(report,indent=2)+"\n").encode("utf8")
    out.write_bytes(data)
    print(out,sha256(data).hexdigest().upper())


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook",type=Path)
    replay(parser.parse_args())
