"""ДЛЯ ТЕСТОВ: воспроизводит рабочий контракт спектрального угла и сохраняет реальные отрицательные исходы."""
from argparse import ArgumentParser
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestRead(path):
    """Читает закреплённую запись без округления численных ожиданий."""
    return json.loads(path.read_text('utf-8-sig'))


def TestNative(repo, root, output):
    """Сверяет каждую импортированную компоненту с фактическим CFB, владение процессами и ожидаемые исходы тестов."""
    shared = run_path(str(root/'Check-TestMaterialRoundoff.py')); shared['TestFiles'](root)
    source, _ = run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source)); cases = {}
    for key in TestRead(root/'Cases.json'):
        folder = root/'Cases'/key
        record = shared['TestSourceComparison'](repo, root, folder, source, original, helper, body, reader)
        assert (record['components'], record['imported'], record['unchanged']) == (239, 24, 215)
        compiler = TestRead(folder/'docs/regression/CodeUpdate.json'); reports = {}
        for file in sorted((folder/'Native').glob('*.txt')):
            log = file.read_text('utf-8-sig'); phase = file.stem
            owner = TestRead(file.with_name(file.name+'.Ownership.json'))
            closure = TestRead(file.with_name(file.name+'.ProcessClosure.json'))
            identity = closure['Closure']['Identity']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
            assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
            assert owner['SourceSHA256'] == compiler['WorkbookSHA256'] and 'SOURCE_UNCHANGED: True' in log
            assert closure['Closure']['FinalState']['State'] == 'Absent'
            totals = [tuple(map(int, row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', log, re.M)]
            assert totals
            if key == 'SelectorFailure':
                assert phase == 'ControlProbe' and totals == [(0, 1)] and closure['ChildExitCode'] == 1
                assert 'RUNTIME ERROR:' in log and 'CORNER_CONTRACT;automatic_preparation;False;' in log
            else:
                assert closure['Passed'] and closure['ChildExitCode'] == 0 and 'RUNTIME ERROR:' not in log
                assert all(failed == 0 for passed, failed in totals)
                if phase == 'Core': assert sum(passed for passed, failed in totals) == 365
                if phase == 'Material': assert totals == [(381, 0)]
                if phase == 'Stock':
                    assert totals == [(28, 0)] and 'RESULTS_SAVE_REOPEN:' in log
                    assert (folder/'SavedWorkbookMarkup.zip').is_file()
                if phase in ('ControlProbe', 'DesignIncoming', 'DesignOutgoing'):
                    count = 0 if key == 'Centered' else 11
                    assert f'CORNER_POST_COUNT;{count};requested;32' in log
            reports[phase] = {'passed': sum(passed for passed, failed in totals),
                              'failed': sum(failed for passed, failed in totals),
                              'expected_rejection': key == 'SelectorFailure'}
        safety = [json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety
        def safe(row):
            return (row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 and
                    all(process['ProtectedUser'] for process in row['excel']))
        blocked = [index for index, row in enumerate(safety) if not safe(row)]
        if blocked:
            assert key in ('Final', 'SelectorFailure') and blocked == [0]
            assert safety[0]['phase'] == safety[1]['phase'] == 'CompileWorkingASD' and safe(safety[1])
            started = datetime(1, 1, 1, tzinfo=timezone.utc)+timedelta(microseconds=int(TestRead(folder/'CompileClosure.json')['StartTicksUTC'])//10)
            assert datetime.fromisoformat(safety[0]['utc']) < datetime.fromisoformat(safety[1]['utc']) < started
            guard = (folder/'Guard-IsolatedOffice.ps1').read_text('utf-8-sig')
            assert 'if ($unknown.Count -or' in guard and '$state.freeCommitGiB -lt 6' in guard
            record['blocked_preflight_before_compile'] = 1
        assert all(safe(row) for index, row in enumerate(safety) if index not in blocked)
        record['reports'] = reports; cases[key] = record
    if (root/'CompileFailure').exists():
        folder = root/'CompileFailure'; failure = TestRead(folder/'CompileFailureClosure.json')
        assert failure['State'] == 'Absent' and not failure['Compiled'] and not failure['CodeUpdateExists']
        assert failure['SourceUnchanged'] and failure['WorkbookSHA256'] == sha256(source).hexdigest().upper()
        assert not (folder/'docs/regression/CodeUpdate.json').exists()
        assert 'COMPILE_LOCATION: module=CCoupledNewtonSolver' in (folder/'Compile.log').read_text('utf-8-sig')
        cases['CompileFailure'] = {'compiled': False, 'failure_preserved': True, 'closed': True}
    output.write_text(json.dumps({'cases': cases, 'installed_workbook_changed': False,
                                 'physical_capacity_certified': False, 'full_acceptance_completed': False},
                                indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('PRINCIPAL TRANSITION NATIVE SOURCES AND NEGATIVE OUTCOMES VERIFIED', flush=True)


def TestMechanics(repo, root, output):
    """Сверяет уравнения, историю и одностороннюю производную; ошибочную производную не принимает ради успешного макроса."""
    run_path(str(root/'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    corner = run_path(str(root/'Validate-TestNativeCorner.py'))['TestValidate']
    continuation = run_path(str(root/'Validate-TestGeneralContinuation.py'))['TestValidate']
    results = {}
    with TemporaryDirectory() as temporary:
        temporary = Path(temporary)
        for key in TestRead(root/'Cases.json'):
            folder = root/'Cases'/key; records = {}
            for phase in ('ControlProbe', 'DesignIncoming', 'DesignOutgoing'):
                if key == 'SelectorFailure' or not (folder/'Native'/(phase+'.txt')).exists(): continue
                target = temporary/(key+phase+'.json'); negative = key in ('Centered', 'SmallProbe')
                corner(repo, folder, target, phase, not negative)
                records[phase] = TestRead(target)
                if negative:
                    value = records[phase]['departure']['native_matrix_direction_relative_error']
                    assert value >= 2e-7 and not records[phase]['departure']['matrix_direction_verified']
                    try: corner(repo, folder, temporary/'Rejected.json', phase, True)
                    except AssertionError as error: assert abs(float(error.args[0])-value) < 1e-12
                    else: raise AssertionError('Не подтверждён ожидаемый отказ строгой проверки касательной.')
                    records[phase]['strict_derivative_expected_rejection'] = True
            if (folder/'Native/Trace74.txt').exists():
                target = temporary/(key+'Trace.json'); continuation(repo, folder, 'Trace74', target)
                records['Trace74'] = TestRead(target)
                if key == 'Bounded':
                    records['integrated_transition'] = TestIntegrated(root, folder, records['ControlProbe'])
            results[key] = records
    output.write_text(json.dumps({'cases': results, 'physical_capacity_certified': False,
                                 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('PRINCIPAL TRANSITION EQUILIBRIA HISTORY AND ONE SIDED DERIVATIVE VERIFIED; CAPACITY OPEN', flush=True)


def TestIntegrated(root, folder, independent_corner):
    """Связывает переход общего пути с отдельно проверенным событием на той же истории, включая первый обычный шаг."""
    read = run_path(str(root/'Validate-TestNativeCorner.py'))['TestRead']
    full, _, loads, _ = read(folder/'Native', '', 'Trace74')
    isolated, _, event_loads, _ = read(folder/'Native', '', 'ControlProbe')
    original, _, _, _ = read(folder/'Reference', '', 'Trace74')
    assert len(full) == 151 and len(original) == 148 and len(isolated) == 13
    assert all(np.array_equal(a, b) for (_, a), (_, b) in zip(full[:148], original))
    maximum = 0.
    for (name, field), (event, expected) in zip(full[148:], isolated[:3]):
        difference = float(np.max(np.abs(field-expected))); maximum = max(maximum, difference)
        assert difference < 1e-11, (name, event, difference)
        assert np.max(np.abs(loads[name]-event_loads[event])) < 1e-5
    metric = run_path(str(root/'Check-TestSignMetric.py'))['TestRead']
    ordinary = metric(folder/'Native/Trace74.Operators.csv', folder/'Native/Trace74.csv')
    assert all(row['signed_advance'] > 0. for row in ordinary if row['ending_state'] not in (150, 151))
    assert independent_corner['departure']['matrix_direction_verified']
    assert independent_corner['states'][2]['label'] == 'Post1'
    assert independent_corner['states'][2]['signed_spatial_advance'] > 0.
    log = (folder/'Native/Trace74.txt').read_text('utf-8-sig')
    assert 'проб: 96;' in log and 'подтверждённых переходов: 1;' in log
    return {'matched_same_148_state_origin': True, 'event_state_indices': [149, 150],
            'first_ordinary_state_index': 151, 'maximum_full_field_difference_from_separate_event': maximum,
            'ordinary_orientations_positive': True, 'event_and_departure_independently_verified': True,
            'global_probe_limit': 96, 'completed_transitions': 1, 'physical_capacity_certified': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True); args = parser.parse_args()
    (TestNative if args.scope == 'native' else TestMechanics)(args.repo.resolve(), args.root.resolve(), args.out.resolve())
