"""Post-yield nominal MVT2 section continuation with the original NDM steel law."""
from argparse import ArgumentParser
from hashlib import sha256
from math import copysign, fsum
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
SRC=HERE.parent/"mvt-asd-equilibrium"
RAYS=REPO/"docs/regression/Coupled6D/MVT2GaussASDExtendedCutRays20261117.zip"
AUTH=REPO/"docs/regression/Coupled6D/MVT2GaussReequilibratedASD20261117.zip"
RAYS_SHA="D319B3DF22E8054815715B0A3F22663B2F1A815C428538EE15EDC9CBB80DE0E7"
AUTH_SHA="FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E"
STEEL_SHA="161ED917323FAC968C5F49C032A141502FE90A76DDFF85D36435ACC18BD274A9"
REINF_SHA="06A82B613BB90A685E7374A0CA623B187C599A70D824E88070C99E1BCF3A7822"
D=Path("D:/CodexScratch/RC_Section_NDM_TQ")
NATIVE_ROOT=D/"MVTGauss25Tensors"
OPS=D/"MVTGauss25Operators/Native/Operators.csv"
OPS_SHA="3E8C00B7AC650B9FF6BBF55C412AED9A18A258BCEE3083D58ECEA9B7A07B653A"
NUMPY=D/"CoupledEvidencePython"
ELASTIC=200000.
STEEL_LIMIT=.05


def digest(raw):
    return sha256(raw).hexdigest().upper()


def read_archive(path,sha):
    assert digest(path.read_bytes())==sha
    return ZipFile(path)


def record_bytes(item):
    return json.dumps(item,sort_keys=True,separators=(",",":"),allow_nan=False).encode()


def scalar_update(strain,old_plastic,old_backstress,e,rst,rsc,slope_t,slope_c):
    """Direct scalar counterpart of CCoupledSteelModel.EvaluateTrial."""
    stress=e*(strain-old_plastic)
    relative=stress-old_backstress
    if -rsc<=relative<=rst:
        return stress,e,old_plastic,old_backstress,0.
    if relative>rst:
        excess=relative-rst
        raw=slope_t
    else:
        excess=relative+rsc
        raw=slope_c
    hard=raw/(1.-raw/e)
    delta=excess/(e+hard)
    return stress-e*delta,hard/(1.+hard/e),old_plastic+delta,old_backstress+hard*delta,delta


def independent_projection(strain,old_plastic,old_backstress,e,rst,rsc,slope_t,slope_c):
    """Project the trial relative stress onto the translated admissible interval."""
    selector=strain-(old_plastic+old_backstress/e)
    if -rsc/e<=selector<=rst/e:
        return e*(strain-old_plastic),old_plastic,old_backstress
    forward=selector>0.
    slope=slope_t if forward else slope_c
    bound=rst if forward else -rsc
    shift=slope*e/(e-slope)
    # p_new solves E(epsilon-p_new)-backstress_old-H*(p_new-p_old)=bound.
    plastic=(e*strain-old_backstress+shift*old_plastic-bound)/(e+shift)
    backstress=old_backstress+shift*(plastic-old_plastic)
    return backstress+bound,plastic,backstress


def verify_point_update():
    maximum=0.
    for y in (498.,450.):
        for slopes in ((0.,0.),(1500.,850.)):
            old_plastic=old_backstress=0.
            for epsilon in (0.,.001,.0035,.004,.001,-.001,-.004,-.002,0.,.005):
                sig,tan,p,b,delta=scalar_update(epsilon,old_plastic,old_backstress,ELASTIC,y,y,*slopes)
                ref=independent_projection(epsilon,old_plastic,old_backstress,ELASTIC,y,y,*slopes)
                maximum=max(maximum,*(abs(a-v) for a,v in zip((sig,p,b),ref,strict=True)))
                assert abs(sig-b)<=y+2e-10
                if delta:
                    assert abs(sig-b-copysign(y,delta))<2e-10
                    assert abs(tan-(slopes[0] if delta>0 else slopes[1]))<1e-9
                else:
                    assert tan==ELASTIC and p==old_plastic and b==old_backstress
                old_plastic,old_backstress=p,b
    assert maximum<2e-10
    return maximum


def steel_section(base,np,trigger):
    class PlasticSection(base):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.current_plastic=np.zeros((3,20))
            self.current_backstress=np.zeros((3,20))
            self.axial_operator=np.einsum("spij,pi->spj",self.strain[:,25:,:,:],self.dirs[25:])
            self.axial_projection=np.einsum("spir,pi->spr",self.project[:,25:,:,:],self.dirs[25:])

        def components(self,field):
            epsilon=self.strain@field
            if np.max(np.abs(epsilon))>.01:
                raise ArithmeticError("trial strain exceeds original diagnostic numerical domain")
            extension=np.einsum("spi,pi->sp",epsilon[:,25:,:],self.dirs[25:])
            stress=ELASTIC*(extension-self.current_plastic)
            relative=stress-self.current_backstress
            in_tension=relative>self.steel_allow
            in_compression=relative< -self.steel_allow
            # The MVT2 experiment fixture sets both strain-hardening slopes to zero.
            # The general scalar law and its nonzero branches are checked separately.
            yielded=in_tension|in_compression
            increment=np.zeros((3,20))
            increment[in_tension]=(relative-self.steel_allow)[in_tension]/ELASTIC
            increment[in_compression]=(relative+self.steel_allow)[in_compression]/ELASTIC
            stress-=ELASTIC*increment
            plastic=self.current_plastic+increment
            tangent=np.where(yielded,0.,ELASTIC)
            self.next_steel=(extension,stress,tangent,plastic,self.current_backstress.copy(),increment)
            self.last_tensor=epsilon
            return epsilon,stress

        def equations(self,field,demand,matrix=False):
            response=super().equations(field,demand,matrix)
            if matrix and np.any(self.next_steel[2]!=ELASTIC):
                update=np.einsum("spr,spq,sp->rq",self.axial_projection,self.axial_operator,
                                 self.next_steel[2]-ELASTIC,optimize=True)
                response=(response[0],response[1]+update,*response[2:])
            return response

        def commit(self):
            strain,stress,tangent,plastic,back,inc=self.next_steel
            # The production steel strain limit belongs to accepted central materials.
            # Check it before advancing any of the ASD or steel buffers.
            if np.max(np.abs(strain[0]))>=STEEL_LIMIT:
                raise ArithmeticError("central steel reaches the fixture strain limit")
            e=self.last_tensor[:,:25,:]
            stresses=np.asarray(self.accepted_stresses[-1])[:,:25,:]
            # Store observed principal extremes only; these are not a crushing test.
            ep=tensor_matrix(np,e,True)
            sp=tensor_matrix(np,stresses,False)
            material_bounds={"minimum_concrete_principal_strain":float(np.min(np.linalg.eigvalsh(ep))),
                             "minimum_concrete_principal_stress_MPa":float(np.min(np.linalg.eigvalsh(sp)))}
            trigger.append({"columns_strain_stress_tangent_plastic_backstress_increment":np.stack(self.next_steel,axis=-1).tolist(),
                            **material_bounds})
            super().commit()
            self.current_plastic=plastic.copy()
            self.current_backstress=back.copy()
    return PlasticSection


def tensor_matrix(np,tensor,engineering):
    result=np.empty((*tensor.shape[:-1],3,3))
    factor=.5 if engineering else 1.
    for j in range(3): result[...,j,j]=tensor[...,j]
    for j,(row,col) in enumerate(((0,1),(0,2),(1,2)),3):
        result[...,row,col]=result[...,col,row]=factor*tensor[...,j]
    return result


def compare_replay(original,calculated):
    numeric_keys=("field","twist_rad_per_m","resultants_N_Nmm","all_weak_and_force_max_MPa")
    return record_bytes([r[k] for r in original for k in numeric_keys])==record_bytes(
        [r[k] for r in calculated for k in numeric_keys])


def main(out,raw):
    assert digest((REPO/"src/Materials/CCoupledSteelModel.cls").read_bytes())==STEEL_SHA
    assert digest((REPO/"src/Materials/CCoupledReinforcedResponse.cls").read_bytes())==REINF_SHA
    assert digest(OPS.read_bytes())==OPS_SHA
    with read_archive(AUTH,AUTH_SHA) as auth, read_archive(RAYS,RAYS_SHA) as old:
        for leaf in ("Reequilibrate.py","Operators.py"):
            assert auth.read(leaf)==(SRC/leaf).read_bytes()
        refs=json.loads(auth.read("Authoritative.json"))["modes"]["default"]["accepted"][:8]
        refs+=json.loads(old.read("Midspan.json"))["new_after_pure_torsion"]
        tensors=json.loads(gzip.decompress(auth.read("Authoritative.stress.json.gz")))["default"][:8]
        tensors+=json.loads(gzip.decompress(old.read("Midspan.stress.json.gz")))
    assert len(refs)==len(tensors)==42 and refs[-1]["Q_target_N"]==51562.5
    sys.path.insert(0,str(NUMPY))
    sys.path.insert(0,str(SRC))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0" and np.__version__=="2.3.5"
    program=runpy.run_path(str(SRC/"Reequilibrate.py"))
    shared,native,geom,dirs,area,length,operators,seeds,observed,identity=program["read_inputs"](OPS,NATIVE_ROOT)
    requested=[51640.625,52500.,*range(55000,80001,2500)]
    replayed=[{"phase":r["phase"],"T_Nmm":r["T_target_Nmm"],"Qy_N":r["Q_target_N"]} for r in refs]
    targets=[{"phase":f"NominalQ{q/1000:g}","T_Nmm":10510000.,"Qy_N":q} for q in requested]
    report={**native,"frames":[*replayed,*targets]}
    options=program["simulate"].__globals__
    discard=options["test_discard"]
    options["test_discard"]=lambda kit,cmd,fn,frames:discard(kit,cmd,fn,native["frames"])
    options["loads"]=lambda arrays,t,q:arrays.array((0.,-600.*q,0.,t,0.,q))
    steel=[]
    options["Section"]=steel_section(options["Section"],np,steel)
    point_check=verify_point_update()
    commands=program["commands"](shared,native,("default",))["default"]
    print("START postyield after all 42 elastic nominal fields",flush=True)
    try:
        outcome,net=program["simulate"](np,ops,shared,report,geom,dirs,area,length,operators,
                                        seeds,"default",commands,perf_counter()+85.,len(report["frames"]))
    finally:
        ops.wipe()
    actual=outcome["accepted"]
    assert len(actual)==len(net)==len(steel) and len(actual)>=42
    assert compare_replay(refs,actual[:42]) and record_bytes(tensors)==record_bytes(net[:42])
    assert all(s[3]==s[4]==s[5]==0. for f in steel[:42]
               for side in f["columns_strain_stress_tangent_plastic_backstress_increment"] for s in side)
    print("ACCEPTED",len(actual),actual[-1]["Q_target_N"],outcome["terminal"],flush=True)
    wire=record_bytes({"net_three_station_stress_MPa":net,"steel":steel})
    compressed=gzip.compress(wire,compresslevel=9,mtime=0)
    with raw.open("xb") as stream:
        stream.write(compressed)
    proof={"status":"completed_bounded_control","native_elastic_prefix_fields_and_tensors_bit_exact":42,
           "Rays_archive_SHA256":RAYS_SHA,"ASD_archive_SHA256":AUTH_SHA,"operators":identity,
           "original_steel":{"Es_MPa":ELASTIC,"longitudinal_yield_MPa_both_signs":498.,
               "hoop_yield_MPa_both_signs":450.,"tangent_MPa_after_yield_both_signs":0.,
               "backstress_evolution":"native kinematic rule with H=0 in this calibration",
               "strain_limit_both_signs":STEEL_LIMIT,"point_projection_unit_tests_max_difference":point_check,
               "native_model_sha256":STEEL_SHA,"native_reinforced_response_sha256":REINF_SHA},
           "steel_elastic_predecessor_Qy_N":51562.5,"postyield_nominal_Qy_N":requested,
           "native_state_sha256":digest(compressed),"result":outcome,
           "physical_limit_established":False,"concrete_crushing_criterion_claimed":False,
           "scope":"local nominal midspan Mx=-0.600 Qy, monotonic positive Qy, fixed T=10.51 kNm",
           "engine":ops.version(),"numpy":np.__version__}
    data=(json.dumps(proof,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with out.open("xb") as stream:
        stream.write(data)
    print("POSTYIELD PASS",digest(data),digest(compressed))


if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=HERE/"Postyield.json")
    parser.add_argument("--raw",type=Path,default=HERE/"Postyield.stress.json.gz")
    args=parser.parse_args()
    main(args.out,args.raw)
