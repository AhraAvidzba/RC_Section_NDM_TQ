"""Offline checks of all stress resultants, section rows and steel return histories."""
from argparse import ArgumentParser
from hashlib import sha256
from math import acos, cos, fsum, pi, sqrt
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import gzip
import json
import runpy
import subprocess
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
AUTH=("MVT2GaussReequilibratedASD20261117","FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E")
RAYS=("MVT2GaussASDExtendedCutRays20261117","D319B3DF22E8054815715B0A3F22663B2F1A815C428538EE15EDC9CBB80DE0E7")
MODEL_COMMIT="70fa287fecbc500ffb83084d9fbe1e4d5e368298"
REPORT_SHA="D3B71E6F1956FA0638A8FA69AFFE50C61CCBE2B80F8B9B9487FC33192632433D"
WIRE_SHA="AA3829E82B5C303ACAD5AECECA87D06D509C5EDA327D778EC76193CCEA02ADBB"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def verify_manifest():
    accepted=set()
    for line in (HERE/"SHA256SUMS").read_text(encoding="ascii").splitlines():
        expected,leaf=line.split("  ",1)
        identity=PurePosixPath(leaf)
        assert not identity.is_absolute() and ".." not in identity.parts and leaf not in accepted
        assert digest((HERE/leaf).read_bytes())==expected
        accepted.add(leaf)
    assert accepted=={p.relative_to(HERE).as_posix() for p in HERE.rglob("*")
                      if p.is_file() and p.name!="SHA256SUMS"}


def archive(repo,ref):
    path=repo/"docs/regression/Coupled6D"/(ref[0]+".zip")
    assert digest(path.read_bytes())==ref[1]
    return ZipFile(path)


def source(repo,name,expected):
    path="src/Materials/"+name+".cls"
    wire=(repo/path).read_bytes()
    if digest(wire)!=expected:
        wire=subprocess.check_output(["git","-C",str(repo),"show",f"{MODEL_COMMIT}:{path}"])
    assert digest(wire)==expected


def arrays_equal(a,b):
    return json.dumps(a,sort_keys=True,separators=(",",":"),allow_nan=False)==json.dumps(
        b,sort_keys=True,separators=(",",":"),allow_nan=False)


def minimum_eigen(x,engineering):
    a,b,c,d,e,f=x
    if engineering:
        d*=.5;e*=.5;f*=.5
    avg=(a+b+c)/3
    u,v,w=(a-avg,b-avg,c-avg)
    scale=sqrt((u*u+v*v+w*w+2*(d*d+e*e+f*f))/6)
    if scale==0.:
        return avg
    determinant=(u*(v*w-f*f)-d*(d*w-e*f)+e*(d*f-e*v))/scale**3
    return avg+2*scale*cos(acos(max(-1.,min(1.,.5*determinant)))/3+2*pi/3)


def tensor(op,field,p,side):
    return [fsum((b+side*.001*g)*x for b,g,x in zip(row,slope,field,strict=True))
            for row,slope in zip(op["B"][p],op["Z"][p],strict=True)]


def check_equilibrium(net,step,op,geo,area,length,signed):
    assert len(net)==3 and all(len(station)==45 for station in net)
    x=step["field"]
    t,q=step["T_target_Nmm"],step["Q_target_N"]
    target=(0.,-600.*q,0.,t,0.,q)
    applied=[fsum(c[i]*v for c,v in zip(op["L"],target,strict=True)) for i in range(60)]
    slopes=[[500*(a-b) for a,b in zip(p,m,strict=True)] for p,m in zip(net[1],net[2],strict=True)]
    residual=[]
    for i in range(60):
        center=(w[i]*v for vectors,sigma in zip(op["S"],net[0],strict=True)
                for w,v in zip(vectors,sigma,strict=True))
        gradient=(w[i]*v for vectors,sigma in zip(op["R"],slopes,strict=True)
                  for w,v in zip(vectors,sigma,strict=True))
        gauge=(g*q for g,q in zip(op["G"][i],x,strict=True))
        residual.append(fsum((*center,*gradient,*gauge))-applied[i])
    actual=signed(net[0],geo)
    ratios=(area,area*length,area*length,area*length,area,area)
    f=max(abs(a-b)/r for a,b,r in zip(actual,target,ratios,strict=True))
    aggregate=max(f,max(map(abs,residual[:56])),30000*max(map(abs,residual[56:])))
    assert aggregate<=5e-7+5e-7*max(map(abs,applied))
    assert abs(aggregate-step["all_weak_and_force_max_MPa"])<3e-12
    assert max(abs(a-b) for a,b in zip(actual,step["resultants_N_Nmm"],strict=True))<3e-8
    assert abs(step["twist_rad_per_m"]-1000*x[3]/length)<1e-17
    return aggregate


def verify_history(steps,rows,stresses,op,dirs):
    old=[[0.]*20 for _ in range(3)]
    first_center=first_side=None
    max_error=0.
    for state,observed,net in zip(steps,rows,stresses,strict=True):
        field=state["field"]
        cement=[]
        minimum_strain=0.
        for side_index,side in enumerate((0,1,-1)):
            for p in range(25):
                minimum_strain=min(minimum_strain,minimum_eigen(tensor(op,field,p,side),True))
                cement.append(minimum_eigen(net[side_index][p],False))
            point_rows=observed["columns_strain_stress_tangent_plastic_backstress_increment"][side_index]
            for p,row in enumerate(point_rows,25):
                eps,stress,tangent,plastic,backstress,increment=row
                strain=fsum(a*b for a,b in zip(tensor(op,field,p,side),dirs[p],strict=True))
                assert abs(eps-strain)<5e-18 and abs(strain)<.05
                cap=498. if p<29 else 450.
                p_old=old[side_index][p-25]
                predictor=200000.*(strain-p_old)
                expected_stress=min(cap,max(-cap,predictor))
                expected_plastic=strain-expected_stress/200000.
                expected_tangent=0. if abs(predictor)>cap else 200000.
                max_error=max(max_error,abs(expected_stress-stress))
                assert abs(expected_stress-stress)<4e-11 and abs(expected_plastic-plastic)<2e-17
                assert abs(increment-(plastic-p_old))<2e-17 and tangent==expected_tangent and backstress==0.
                if increment:
                    event={"Qy_N":state["Q_target_N"],"point":p+1,"side":side,"plastic_increment":increment}
                    if side==0 and first_center is None:
                        first_center=event
                    if first_side is None:
                        first_side=event
                old[side_index][p-25]=plastic
        assert abs(minimum_strain-observed["minimum_concrete_principal_strain"])<5e-16
        assert abs(min(cement)-observed["minimum_concrete_principal_stress_MPa"])<1e-10
    assert first_side["Qy_N"]==51640.625 and first_side["point"]==28 and first_side["side"]==-1
    assert first_center["Qy_N"]==51855.46875 and first_center["point"]==28
    return {"first_any_station_yield":first_side,"first_center_yield":first_center,"max_point_stress_error_MPa":max_error}


def main(repo):
    verify_manifest()
    rp=(HERE/"Postyield.json").read_bytes()
    wire=(HERE/"Postyield.stress.json.gz").read_bytes()
    assert digest(rp)==REPORT_SHA and digest(wire)==WIRE_SHA
    report=json.loads(rp)
    assert report["native_state_sha256"]==WIRE_SHA and report["native_elastic_prefix_fields_and_tensors_bit_exact"]==42
    assert not report["physical_limit_established"] and not report["concrete_crushing_criterion_claimed"]
    s=report["original_steel"]
    source(repo,"CCoupledSteelModel",s["native_model_sha256"])
    source(repo,"CCoupledReinforcedResponse",s["native_reinforced_response_sha256"])
    assert s["Es_MPa"]==200000 and s["longitudinal_yield_MPa_both_signs"]==498 and s["hoop_yield_MPa_both_signs"]==450
    assert s["tangent_MPa_after_yield_both_signs"]==0. and s["strain_limit_both_signs"]==.05
    state=json.loads(gzip.decompress(wire))
    steps=report["result"]["accepted"]
    stress=state["net_three_station_stress_MPa"]
    assert len(steps)==len(stress)==len(state["steel"])==49
    with tempfile.TemporaryDirectory(prefix="MVTASDPostyield_") as td:
        tmp=Path(td)
        with archive(repo,AUTH) as base, archive(repo,RAYS) as rays:
            for leaf in ("Verify-Authoritative.py","Operators.py","Reequilibrate.py"):
                (tmp/leaf).write_bytes(base.read(leaf))
            reference=json.loads(base.read("Authoritative.json"))["modes"]["default"]["accepted"][:8]
            reference+=json.loads(rays.read("Midspan.json"))["new_after_pure_torsion"]
            reference_stress=json.loads(gzip.decompress(base.read("Authoritative.stress.json.gz")))["default"][:8]
            reference_stress+=json.loads(gzip.decompress(rays.read("Midspan.stress.json.gz")))
        assert arrays_equal(stress[:42],reference_stress)
        ks=("field","twist_rad_per_m","resultants_N_Nmm","all_weak_and_force_max_MPa")
        assert arrays_equal([r[k] for r in steps[:42] for k in ks],[r[k] for r in reference for k in ks])
        sys.path.insert(0,str(tmp))
        guard=runpy.run_path(str(tmp/"Verify-Authoritative.py"))
        op_path,helper=guard["unpack"](tmp,repo)
        engine=runpy.run_path(str(tmp/"Reequilibrate.py"))
        _,_,geom,dirs,area,length,op,_,_,identity=engine["read_inputs"](op_path,tmp,helper)
        assert identity==report["operators"]
        checks=[check_equilibrium(s,r,op,geom,area,length,guard["signed_forces"])
                for s,r in zip(stress,steps,strict=True)]
        steel=verify_history(steps,state["steel"],stress,op,dirs)
    terminal=report["result"]["terminal"]
    assert terminal["reason"]=="bounded_numerical_stop" and terminal["Q_requested_N"]==55000
    assert terminal["last_reached_Q_N"]==steps[-1]["Q_target_N"]==54375.
    failed=report["result"]["attempts"][-1]
    assert failed["kind"]=="maximum_iterations" and failed["Q_N"]==54453.125
    print("MVT2 EXACT STEEL POSTYIELD OFFLINE PASS",{**steel,"new_states":7,"max_norm_MPa":max(checks),
          "last_reached_Qy_N":54375.,"first_requested_Qy_N_not_reached":55000})


if __name__=="__main__":
    p=ArgumentParser()
    p.add_argument("--repo",type=Path,default=Path.cwd())
    main(p.parse_args().repo)
