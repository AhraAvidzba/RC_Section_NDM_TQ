"""Повторяет бетон на принятой VBA-истории MVT2 средствами OpenSees 3.8.0."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha256
import json
from math import fsum
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


NATIVE = ('MVT2NativeBarControl20261117.zip','6AF0A50074FD1179DD3430C435E8FD2F05F13BDF318F27776954B7E3B119C30A')
BALANCE = ('MVT2TabulatedActiveSteelVBA20261117.zip','87CECC42511E773F37611E4749AFD4947C299F5853893715F284FA9F498789FB')


def read_inputs(repo,temp):
    """Читает полную историю трёх станций и восстанавливает бетонную часть напряжений."""
    path=repo/'docs/regression/Coupled6D'/NATIVE[0]
    assert sha256(path.read_bytes()).hexdigest().upper()==NATIVE[1]
    api={'__name__':'__pinned__','__file__':'Verify-NativeMVT2BarControl.py'}
    with ZipFile(path) as z:
        exec(compile(z.read('Verify-NativeMVT2BarControl.py'),'Verify-NativeMVT2BarControl.py','exec'),api)
        tools,material,mesh,support,*_=api['references'](repo,temp)
        wire='Adaptive/Native/'
        tables=tools['read_operators'](z.read(wire+'Operators.csv'))
        frames=tools['read_tensor_frames'](z.read(wire+'MVTGaussMixed.Tensor.csv'),45)
    utility=support[0]
    commands=utility['read_inputs'](repo,temp)[3][0]['default']
    zero=(0.,)*6
    history={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
    eps,concrete,indices=[],[],[(s,p) for s in (0,1,-1) for p in mesh[1]]
    net_error=0.
    for label,frame in frames.items():
        history,net,_=material(tables['F'][label],tables,mesh[1],support,history)
        local=[]
        strains=[]
        for s,p in indices:
            strain,_,_,plastic=history[s,p]
            strains.append(strain)
            stress=net[s,p]
            if label.startswith('S') or label.startswith('Bar'):
                net_error=max(net_error,*(abs(a-b) for a,b in zip(stress,tables['H'][label,s,p],strict=True)))
            if p>25:
                direction=mesh[1][p][3:]
                axial=200000.*(fsum(a*b for a,b in zip(strain,direction,strict=True))-plastic)
                stress=tuple(axial*d-t for d,t in zip(direction,stress,strict=True))
            local.append(stress)
        eps.append(strains)
        concrete.append(local)
    assert len(frames)==166 and len(indices)==135 and net_error<8e-7
    return commands,eps,concrete,list(frames),(tables,frames,mesh)


def worker(output):
    """Выполняет три независимые истории материала в новом процессе с ограниченным числом вызовов NDTest."""
    import openseespy.opensees as ops

    command,frames=json.load(sys.stdin)
    assert ops.version()=='3.8.0'
    ops.wipe()
    ops.model('basic','-ndm',3,'-ndf',3)
    points=len(frames[0])
    for tag in range(1,points+1):ops.nDMaterial(command[0],tag,*command[1:])
    values=[]
    for frame in frames:
        response=[]
        for tag, strain in enumerate(frame,1):
            xx,yy,zz,xy,xz,yz=strain
            ops.NDTest('SetStrain',tag,xx,yy,zz,xy,yz,xz)
            assert tuple(ops.NDTest('GetStrain',tag))==(xx,yy,zz,xy,yz,xz)
            xx,yy,zz,xy,yz,xz=ops.NDTest('GetStress',tag)
            response.append([xx,yy,zz,xy,xz,yz])
            ops.NDTest('CommitState',tag)
        values.append(response)
    ops.wipe()
    output.write_bytes(json.dumps(values,separators=(',',':')).encode())


def capture(repo, root, interpreter, output):
    """Собирает независимый ответ партиями, не передавая в OpenSees историю или напряжения VBA."""
    with TemporaryDirectory(dir=root,prefix='native-bar-opensees-') as name:
        temporary=Path(name)
        command,frames,_,labels,_=read_inputs(repo,temporary)
        values=[[] for _ in frames]
        for start in range(0,135,3):
            chunk=[frame[start:start+3] for frame in frames]
            wire=json.dumps([command,chunk],separators=(',',':')).encode()
            target=temporary/f'Points{start}.json'
            result=run([str(interpreter),'-B','-X','utf8',str(Path(__file__).resolve()),'--worker',str(target)],
                       input=wire,stdout=PIPE,stderr=PIPE,timeout=45,check=True,
                       creationflags=0x08000000 if sys.platform=='win32' else 0)
            assert result.returncode==0
            data=json.loads(target.read_bytes())
            for row,new in zip(values,data,strict=True):row.extend(new)
        record={'engine':'OpenSees 3.8.0','native_archive_sha256':NATIVE[1],'commands':command,'phases':labels,
                'stress':values,'strain_input_sha256':sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest().upper()}
        output.write_bytes(compress(json.dumps(record,separators=(',',':')).encode(),mtime=0))
    print('NATIVE MVT2 OPENSEES CAPTURED 22410')


def verify(repo, root, captured):
    """Сравнивает независимые тензоры с нативной историей и скалярным повтором."""
    with TemporaryDirectory(dir=root,prefix='native-bar-compare-') as name:
        command,frames,expected,labels,projection=read_inputs(repo,Path(name))
    wire=json.loads(decompress(captured.read_bytes()))
    assert wire['engine']=='OpenSees 3.8.0' and wire['native_archive_sha256']==NATIVE[1]
    assert wire['commands']==command and wire['phases']==labels
    assert wire['strain_input_sha256']==sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest().upper()
    error=0.
    count=0
    for reference,actual in zip(expected,wire['stress'],strict=True):
        for a,b in zip(reference,actual,strict=True):
            assert len(a)==len(b)==6
            error=max(error,*(abs(x-y) for x,y in zip(a,b,strict=True)))
            count+=1
    assert count==22410 and error<8e-7,error
    compare=repo/'docs/regression/Coupled6D'/BALANCE[0]
    assert sha256(compare.read_bytes()).hexdigest().upper()==BALANCE[1]
    api={'__name__':'__pinned__','__file__':'Verify-ActiveSteelWitness.py'}
    with ZipFile(compare) as z:exec(compile(z.read('Verify-ActiveSteelWitness.py'),api['__file__'],'exec'),api)
    tables,states,mesh=projection
    largest=0.
    margin=float('inf')
    checked=0
    for i,label in enumerate(labels):
        if label.startswith('R'):continue
        net={}
        for position,s in enumerate((0,1,-1)):
            for p in mesh[1]:
                at=position*45+p-1
                external=wire['stress'][i][at]
                if p<=25:
                    net[s,p]=external
                else:
                    original=tables['H'][label,s,p]
                    net[s,p]=tuple(a+b-c for a,b,c in zip(original,expected[i][at],external,strict=True))
        norm,tol=api['measure'](tables['F'][label],states[label][1],net,tables,mesh)
        assert norm<=tol,(label,norm,tol)
        largest=max(largest,norm)
        margin=min(margin,tol-norm)
        checked+=1
    assert checked==158
    return {'states':count,'max_concrete_stress_error_MPa':error,'native_archive_sha256':NATIVE[1],
            'equilibrium_fields':checked,'maximum_external_equilibrium_MPa':largest,'minimum_tolerance_margin_MPa':margin,
            'physical_limit_established':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--capture',type=Path)
    p.add_argument('--python',type=Path)
    p.add_argument('--worker',type=Path)
    p.add_argument('--wire',type=Path)
    p.add_argument('--out',type=Path)
    a=p.parse_args()
    if a.worker:worker(a.worker)
    elif a.capture:
        assert a.python
        capture(a.repo.resolve(),a.root.resolve(),a.python.resolve(),a.capture.resolve())
    else:
        assert a.wire and a.out
        data=verify(a.repo,a.root,a.wire)
        a.out.write_bytes((json.dumps(data,indent=2,sort_keys=True)+'\n').encode())
        print('NATIVE MVT2 OPENSEES REPLAY VERIFIED',data['states'])
