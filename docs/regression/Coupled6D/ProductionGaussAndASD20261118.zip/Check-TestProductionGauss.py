"""ДЛЯ ТЕСТОВ: проверяет рабочий VBA, контроль геометрии и реальную ветвь MVT2."""
from argparse import ArgumentParser
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

def TestRead(path):
    """Читает точный JSON протоколов Python и Windows PowerShell."""
    return json.loads(path.read_text('utf-8-sig'))

def TestNative(repo,root,output):
    """Проверяет весь VBA и объём каждого завершённого направленного запуска."""
    for name,expected in TestRead(root/'Files.json').items(): assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name
    source,digest=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    with TemporaryDirectory() as scratch:
        restoration=run_path(str(root/'Restore-TestProductionGauss.py'))['TestRestore'](repo,root,Path(scratch)/'restored',source)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    gauss=run_path(str(root/'Verify-TestASDResolution.py'))['TestGaussBody']
    folder=root/'NativeCase'; prep=TestRead(folder/'Preparation.json'); compiler=TestRead(folder/'docs/regression/CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256']==digest
    assert len(compiler['Modules'])==16 and TestRead(folder/'CompileClosure.json')['State']=='Absent'
    for name,expected in prep['inputs'].items():
        raw=source if name.endswith('RC_Section_NDM.xlsm') else (folder/name).read_bytes()
        assert sha256(raw).hexdigest().upper()==expected,name
    _,original=reader(BytesIO(source)); binary=(folder/'CompiledVBA.bin').read_bytes()
    pin=TestRead(folder/'CompiledVBA.json'); assert len(binary)==pin['bytes'] and sha256(binary).hexdigest().upper()==pin['sha256']
    _,actual=reader(helper['TestContainer'](binary)); conversions={}; untouched=0
    assert set(actual)==set(original)|set(compiler['Modules'])
    for name in actual:
        if name not in compiler['Modules']:
            try: assert body(actual[name],name)[0]==body(original[name],name)[0],name
            except IndexError: assert actual[name]==original[name],name
            untouched+=1; continue
        files=[p for directory in ('src','tests') for p in (folder/directory).rglob(name+'.*') if p.suffix in ('.bas','.cls')]
        assert len(files)==1
        code=files[0].read_text('utf-8-sig')
        alias='modTestMVT2GaussSpan' if name=='modTestMVT2ProductionASDTest' else name
        expected,edits=helper['TestMVTCompilerBody'](body,code,alias)
        if name=='CCoupledSectionAnalysis':
            old="' рабочий знак my соответствует +x·σz."
            assert expected.count(old)==1; expected=expected.replace(old,old.replace('σ','?'))
            edits.append({'kind':'legacy_inline_comment_encoding_loss','from':old,'to':old.replace('σ','?')})
        if name=='modCoupledConcreteTensor':
            old,new='0.0000000000000001','1e-16'
            assert expected.count(old)==1 and Decimal(old)==Decimal(new)
            expected=expected.replace(old,new); edits.append({'kind':'equivalent_literal','from':old,'to':new,'count':1})
        observed=body(actual[name],name)[0]; expected,extra=gauss(expected,observed,name)
        assert expected==observed,name
        if edits or extra: conversions[name]=edits+extra
    assert len(actual)==233 and untouched==217
    reports={}
    for name,count in (('Quadrature',107),('Material',324),('Core',365),('Stock',28),('MVT',1)):
        log=(folder/'Native'/(name+'.txt')).read_text('utf-8-sig')
        closure=TestRead(folder/'Native'/(name+'.txt.ProcessClosure.json')); owner=TestRead(folder/'Native'/(name+'.txt.Ownership.json'))
        assert closure['Passed'] and closure['ChildExitCode']==0 and closure['RunnerCleanupValid']
        identity=closure['Closure']['Identity']; assert closure['Closure']['FinalState']['State']=='Absent'
        assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==compiler['WorkbookSHA256']
        assert owner['PID']==identity['PID'] and int(owner['StartTicksUTC'])==identity['Ticks']
        totals=[(int(a),int(b)) for a,b in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',log,re.M)]
        assert totals and sum(a for a,b in totals)==count and sum(b for a,b in totals)==0
        assert 'RUNTIME ERROR:' not in log and 'SOURCE_UNCHANGED: True' in log
        if name=='Stock':
            assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;',log,re.M)
            assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10290889219566; limit=;' in log
            seconds=float(re.findall(r'^TIMING_SECONDS: ([\d.]+)',log,re.M)[0])
        if name=='MVT':
            assert len(re.findall(r'^REDUCED_ACCEPTED;',log,re.M))==6 and len(re.findall(r'^TRANSFER_CONTROL_ACCEPTED;',log,re.M))==30
            assert re.search(r'^CASE_FINISHED;MVTGaussMixed;True;',log,re.M)
        reports[name]={'passed_assertions':count}
    safety=list(map(json.loads,(folder/'Run.ndjson').read_text('utf-8-sig').splitlines()))
    assert len(safety)==6 and all(row['ramMiB']>=6500 and row['freeCommitGiB']>=6 for row in safety)
    assert all(all(p['ProtectedUser'] for p in row['excel']) for row in safety)
    timeout=TestRead(root/'ExternalAttempt/CompletedParts/22.Timeout.json')
    assert timeout['rotation'] and timeout['timeout_seconds']==45 and not timeout['scope_completed']
    result={'components':len(actual),'unchanged_components':untouched,'imported_components':len(compiler['Modules']),
            'compiler_conversions':conversions,'reports':reports,'stock_seconds_to_results':seconds,
            'clean_input_restoration':restoration,'external_rotated_retry_scope_completed':False,
            'installed_workbook_changed':False,'physical_capacity_certified':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('PRODUCTION GAUSS VBA AND ALL DIRECTED SCOPES VERIFIED; EXTERNAL RETRY INCOMPLETE; CAPACITY OPEN')

def TestMechanics(repo,root,output):
    """Заново интегрирует всю принятую историю по независимому материалу и всем слабым уравнениям."""
    raw=(repo/'docs/regression/Coupled6D/WorkingForceSubspace20261118.zip').read_bytes()
    assert sha256(raw).hexdigest().upper()=='FBEACD63457F041E473358613DA96FCA0AB1C8A79194BD226EE7D1F821CFCA3B'
    with ZipFile(BytesIO(raw)) as archive:
        for file in (root/'Prefix/Native').iterdir(): assert file.read_bytes()==archive.read('Prefix/Native/'+file.name)
    run_path(str(root/'TestResolutionSection.py'))['TestReplay'](repo,root/'NativeCase/Mechanics',output,prefix_native=root/'Prefix/Native')
    result=TestRead(output); assert len(result['states'])==74 and result['degrees']==87 and result['concrete_points']==100
    assert result['states'][-1]['target_N_Nmm'][5]==79931.4253649896
    print('PRODUCTION MATERIAL MVT2 ALL SIX RESULTANTS AND 74 EQUILIBRIA VERIFIED; PHYSICAL LIMIT OPEN')

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--scope',choices=('native','mechanics'),required=True); parser.add_argument('--out',type=Path,required=True); args=parser.parse_args()
    (TestNative if args.scope=='native' else TestMechanics)(args.repo.resolve(),args.root.resolve(),args.out.resolve())
