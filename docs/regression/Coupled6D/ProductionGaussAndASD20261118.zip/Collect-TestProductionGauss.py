"""ДЛЯ ТЕСТОВ: сохраняет рабочую квадратуру, нативный MVT2 и точные источники контрольной книги."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED

def TestCopy(source,target):
    """Сохраняет точные байты без перезаписи другого результата."""
    raw=source.read_bytes(); target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists(): assert target.read_bytes()==raw,target
    else: target.write_bytes(raw)

def TestCollect(root):
    """Исключает временные полные XLSM; сохраняет их VBA и OOXML результата отдельно."""
    source=Path('D:/CodexScratch/RC_Section_NDM_TQ/ProductionGaussASD20261118'); root.mkdir()
    prep=json.loads((source/'Preparation.json').read_bytes())
    for name,expected in prep['inputs'].items(): assert sha256((source/name).read_bytes()).hexdigest().upper()==expected,name
    for file in source.rglob('*'):
        if not file.is_file(): continue
        name=file.relative_to(source)
        if name.parts[0] in ('Temp','workbook') or file.suffix.lower()=='.xlsm': continue
        TestCopy(file,root/'NativeCase'/name)
    with ZipFile(source/'docs/regression/Diagnostic.xlsm') as book: binary=book.read('xl/vbaProject.bin')
    (root/'NativeCase/CompiledVBA.bin').write_bytes(binary)
    (root/'NativeCase/CompiledVBA.json').write_bytes((json.dumps({'bytes':len(binary),'sha256':sha256(binary).hexdigest().upper()},indent=2)+'\n').encode())
    log=(source/'Native/Stock.txt').read_text('utf-8-sig')
    saved,=re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$',log,re.M)
    assert Path(saved).resolve().is_relative_to((source/'Temp').resolve())
    with ZipFile(saved) as book,ZipFile(root/'NativeCase/SavedWorkbookXML.zip','x',ZIP_DEFLATED,compresslevel=9) as out:
        for name in sorted(book.namelist()):
            if name=='xl/vbaProject.bin': continue
            entry=ZipInfo(name,date_time=(2026,11,18,0,0,0)); entry.compress_type=ZIP_DEFLATED
            out.writestr(entry,book.read(name),compresslevel=9)
    prefix=Path('D:/CodexScratch/RC_Section_NDM_TQ/WorkingForceSubspaceEvidence20261118/Prefix/Native')
    for name in ('Operators.csv','MVTGaussMixed.csv','MVTGaussMixed.Tensor.csv','MVTGaussMixed.txt'):
        TestCopy(prefix/name,root/'Prefix/Native'/name)
    external=Path('D:/CodexScratch/RC_Section_NDM_TQ/ASDReferenceCompletion20261118')
    for file in external.rglob('*'):
        if file.is_file(): TestCopy(file,root/'ExternalAttempt'/file.relative_to(external))
    here=Path(__file__).resolve().parent
    for name in ('Stage-TestWorkingASD.py','Run-TestWorkingASD.ps1','Collect-TestProductionGauss.py','Check-TestProductionGauss.py',
                 'Inspect-TestResolutionVBA.py','Verify-TestReducedEvidence.py','Verify-TestASDResolution.py',
                 'TestResolutionSection.py','Probe-TestASDMaterialSteps.py','Probe-TestASDClosure.py',
                 'Benchmark-TestNDResponse.py','Complete-TestASDReference.py','Restore-TestProductionGauss.py'):
        TestCopy(here/name,root/name)
    TestCopy(Path('D:/CodexScratch/RC_Section_NDM_TQ/WorkingForceSubspaceEvidence20261118/SourceBook.json'),root/'SourceBook.json')
    for name in ('OpenSees-3.8.0-OpenSeesNDTestCommands.cpp','OpenSees-3.8.0-PythonStream.cpp'):
        TestCopy(Path('literature/Coupled6D')/name,root/'PrimarySources'/name)
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper() for file in root.rglob('*') if file.is_file()}
    (root/'Files.json').write_bytes((json.dumps(files,indent=2,sort_keys=True)+'\n').encode())
    print('PRODUCTION GAUSS AND ASD EVIDENCE COLLECTED',len(files))

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--root',type=Path,required=True); args=parser.parse_args(); TestCollect(args.root.resolve())
