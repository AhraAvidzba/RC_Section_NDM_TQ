"""ДЛЯ ТЕСТОВ: восстанавливает чистые входы частной книги из закреплённого комплекта."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path

def TestRestore(repo,root,target,source_book=None):
    """Не запускает Excel и не копирует результаты, логи или изменённую контрольную книгу."""
    if source_book is None:
        source_book,_=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    folder=root/'NativeCase'; prep=json.loads((folder/'Preparation.json').read_bytes())
    assert sha256(source_book).hexdigest().upper()==prep['source_book_sha256']
    target.mkdir()
    for name,expected in prep['inputs'].items():
        raw=source_book if name=='workbook/output/RC_Section_NDM.xlsm' else (folder/name).read_bytes()
        assert sha256(raw).hexdigest().upper()==expected,name
        path=target/name; path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream: stream.write(raw)
    for name in ('Native','Temp','tests','docs/regression'): (target/name).mkdir(parents=True,exist_ok=True)
    (target/'docs/regression/Diagnostic.xlsm').write_bytes(source_book)
    (target/'Preparation.json').write_bytes((folder/'Preparation.json').read_bytes())
    for name,expected in prep['inputs'].items(): assert sha256((target/name).read_bytes()).hexdigest().upper()==expected,name
    return {'restored_inputs':len(prep['inputs']),'all_input_hashes_verified':True,'source_book_sha256':prep['source_book_sha256'],
            'compiled_workbook_or_results_reused':False,'excel_started':False}

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--target',type=Path,required=True); args=parser.parse_args()
    print(json.dumps(TestRestore(args.repo.resolve(),args.root.resolve(),args.target.resolve()),sort_keys=True))
