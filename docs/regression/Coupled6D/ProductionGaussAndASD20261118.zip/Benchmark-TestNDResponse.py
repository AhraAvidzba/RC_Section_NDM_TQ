"""ДЛЯ ТЕСТОВ: измеряет стоимость нативных вызовов и диагностического чтения внутренних переменных."""
from pathlib import Path
from time import perf_counter
import json
from os import devnull
import openseespy.opensees as ops
import openseespywin.opensees as native
from hashlib import sha256

assert ops.NDTest is native.NDTest
assert sha256(Path(native.__file__).read_bytes()).hexdigest().upper()=='25BA42E1672526137D765D9C3631D1403E091F54F5AFCDB9242F9243C63C3A96'
ops.wipe(); ops.logFile(devnull,'-noEcho'); ops.model('basic','-ndm',3,'-ndf',3)
ops.nDMaterial('ASDConcrete3D',1,30000.,.2,'-fc',34.,'-ft',2.,'-tangent')
proof={}
for name,arguments in [('SetStrain',('SetStrain',1,0.,0.,.00001,0.,0.,0.)),('GetStress',('GetStress',1)),
                       ('Coordinate',('GetResponse',1,'equivalentTotalStrain')),('Damage',('GetResponse',1,'damage')),('Commit',('CommitState',1))]:
    start=perf_counter()
    for i in range(10): value=ops.NDTest(*arguments)
    proof[name]={'calls':10,'seconds':perf_counter()-start}
proof['api']=[name for name in dir(ops) if 'esponse' in name or 'Material' in name or name.startswith('ND')]
ops.wipe(); print(json.dumps(proof),flush=True)
