"""ДЛЯ ТЕСТОВ: завершает внешний контроль; вырожденный сдвиг проверяет в его точных главных осях."""
from argparse import ArgumentParser
from gzip import decompress
from hashlib import sha256
from io import BytesIO
import json
from math import sqrt
from pathlib import Path
from runpy import run_path
from subprocess import run,PIPE,TimeoutExpired
import sys
from zipfile import ZipFile

TestArchive='WorkingASDMaterialIntegration20261118'
TestArchiveSHA='834DD5A33866D4AE2267E90F0E0DBBCC495A859895EF9E1EEE748777ACB5CFF1'

def TestRotateStrain(row):
    """Поворачивает на 45 градусов вокруг z; чистый сдвиг превращается в точный диагональный тензор."""
    x,y,z,xy,xz,yz=row; c=1./sqrt(2.)
    return [(x+y-xy)/2.,(x+y+xy)/2.,z,x-y,c*(xz-yz),c*(xz+yz)]

def TestRestoreStress(row):
    """Возвращает физические напряжения из главных осей сдвига в исходные оси."""
    x,y,z,xy,xz,yz=row; c=1./sqrt(2.)
    return [(x+y+2.*xy)/2.,(x+y-2.*xy)/2.,z,(y-x)/2.,c*(xz+yz),c*(-xz+yz)]

def TestStage(repo,root):
    """Берёт только закреплённые входы и уже завершённые первичные ответы."""
    raw=(repo/'docs/regression/Coupled6D'/(TestArchive+'.zip')).read_bytes()
    assert sha256(raw).hexdigest().upper()==TestArchiveSHA
    root.mkdir(); inputs={}
    with ZipFile(BytesIO(raw)) as archive:
        names=[name for name in archive.namelist() if name.startswith('Final/Data/') or name.startswith('Final/PrimaryParts/')]
        names+=['Verify-TestWorkingASD.py','Final/default.OpenSeesClosed.json','Final/ndm_uniaxial.OpenSees1025.json']
        for name in names:
            payload=archive.read(name); file=root/name; file.parent.mkdir(parents=True,exist_ok=True); file.write_bytes(payload)
            inputs[name]=sha256(payload).hexdigest().upper()
    for name in ('Complete-TestASDReference.py',):
        raw=Path(__file__).read_bytes(); (root/name).write_bytes(raw); inputs[name]=sha256(raw).hexdigest().upper()
    (root/'Inputs.json').write_bytes((json.dumps({'archive':TestArchive,'archive_sha256':TestArchiveSHA,'inputs':inputs},indent=2,sort_keys=True)+'\n').encode())
    print('PRIMARY COMPLETION INPUTS PINNED',len(inputs),flush=True)

def TestRun(root,interpreter):
    """Не повторяет готовые процессы и не меняет критерий замыкания рабочего материала."""
    prep=json.loads((root/'Inputs.json').read_bytes())
    for name,expected in prep['inputs'].items(): assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name
    helper=run_path(str(root/'Verify-TestWorkingASD.py'))
    paths={}
    for line in (root/'Final/Data/History.csv').read_text().splitlines():
        row=line.split(';'); paths.setdefault(row[0],[]).append(list(map(float,row[2:])))
    selected=dict(paths); expected={}
    for line in (root/'Final/Data/ndm_uniaxial.Native.csv').read_text().splitlines():
        row=line.split(';'); expected.setdefault(row[0],[]).append(list(map(float,row[8:])))
    for line in (root/'Final/Data/ndm_uniaxial.Probes.csv').read_text().splitlines():
        row=line.split(';'); key=row[0]+'#Probe'+row[1]
        selected[key]=paths[row[0]][:int(row[1])+1]+[list(map(float,row[2:8]))]
        expected[key]=[list(map(float,row[8:]))]
    command=json.loads((root/'Final/ndm_uniaxial.OpenSees1025.json').read_bytes())['command']
    parts=root/'CompletedParts'; parts.mkdir()
    maximum=0.; scalar_count=0; summaries=[]
    for index,(path,rows) in enumerate(selected.items()):
        inherited=root/'Final/PrimaryParts'/('ndm_uniaxial.'+str(index)+'.json')
        rotation=(path=='Shear#Probe12')
        if inherited.exists():
            assert not rotation
            part=inherited; data=json.loads(part.read_bytes()); scope='inherited completed native history'
        else:
            part=parts/(str(index)+'.json'); assert not part.exists()
            wire=json.dumps([command,{path:list(map(TestRotateStrain,rows)) if rotation else rows}],separators=(',',':')).encode()
            (parts/(str(index)+'.Input.json')).write_bytes(wire)
            memory=helper['TestMemory']()
            record={'index':index,'path':path,'rotation':rotation,'input_sha256':sha256(wire).hexdigest().upper(),'resources':memory}
            with (root/'Run.ndjson').open('a',encoding='utf-8') as stream: stream.write(json.dumps(record)+'\n')
            try:
                process=run([str(interpreter),'-B','-X','utf8',str(root/'Verify-TestWorkingASD.py'),'--worker',str(part)],
                            input=wire,stdout=PIPE,stderr=PIPE,timeout=45,creationflags=0x08000000,check=True)
            except TimeoutExpired as error:
                (parts/(str(index)+'.Timeout.json')).write_bytes((json.dumps({**record,'timeout_seconds':45,'scope_completed':False},indent=2)+'\n').encode())
                (parts/(str(index)+'.Stdout.txt')).write_bytes(error.stdout or b'')
                (parts/(str(index)+'.Stderr.txt')).write_bytes(error.stderr or b'')
                raise
            assert process.returncode==0
            data=json.loads(part.read_bytes()); scope='new native history'
        assert data['command']==command and data['binary_sha256']==helper['TestBinary'] and data['tolerance_MPa']==1e-9
        observed=data['stress'][path]
        if rotation: observed=list(map(TestRestoreStress,observed))
        actual=[observed[-1]] if '#Probe' in path else observed
        error=max(abs(a-b) for left,right in zip(actual,expected[path],strict=True) for a,b in zip(left,right,strict=True))
        assert error<8e-7,(path,error)
        count=6*len(actual); scalar_count+=count; maximum=max(maximum,error)
        summaries.append({'path':path,'scope':scope,'rotated_reference_axes':rotation,'maximum_stress_error_MPa':error,
                          'scalar_comparisons':count,'native_sha256':sha256(part.read_bytes()).hexdigest().upper(),
                          'maximum_closure_repeats':max(data['closure_iterations'][path])})
        print('PRIMARY MATERIAL HISTORY VERIFIED',path,error,'rotation',rotation,flush=True)
    assert scalar_count==900 and len(summaries)==48
    proof={'histories':summaries,'maximum_stress_error_MPa':maximum,'scalar_comparisons':scalar_count,
           'equivalent_rotated_reference_histories':1,'original_axes_external_failure_preserved':True,
           'binary_sha256':helper['TestBinary'],'global_external_capacity_search':False,'physical_capacity_certified':False}
    (root/'PrimaryCompletionChecks.json').write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('PRIMARY MATERIAL CONTROL COMPLETED IN EQUIVALENT AXES; ORIGINAL NUMERICAL FAILURE RETAINED',maximum,flush=True)

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--python',type=Path); parser.add_argument('--stage',action='store_true'); args=parser.parse_args()
    if args.stage: TestStage(args.repo.resolve(),args.root.resolve())
    else: TestRun(args.root.resolve(),args.python.resolve())
