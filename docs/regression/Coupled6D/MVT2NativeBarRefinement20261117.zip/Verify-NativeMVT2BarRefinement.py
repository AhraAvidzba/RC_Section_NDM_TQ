"""Проверяет чувствительность максимума MVT2 к нативному деформационному шагу."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


COARSE = ('MVT2NativeBarControl20261117.zip','6AF0A50074FD1179DD3430C435E8FD2F05F13BDF318F27776954B7E3B119C30A')
COARSE_PROOF = '1606F813066A2DED5A1164E2C3D2DD02EC3EEE4C05038415609D6B8BA03405EA'
TOLERANCE = .002


def peak(data):
    """Возвращает подтверждённую точку наибольшей поперечной силы."""
    return max(data['accepted'],key=lambda row:row['Qy_N'])


def verify(repo,root,temp):
    """Повторяет обе уточнённые истории и сравнивает максимум с закреплённым крупным шагом."""
    common=run_path(str(root/'Verify-NativeMVT2BarControl.py'))
    refs=common['references'](repo,temp)
    variants={name:common['variant'](root/name,refs) for name in ('Half','Quarter')}
    assert [len(variants[k]['accepted']) for k in ('Half','Quarter')]==[145,124]
    for name,expected in (('Half',1e-5),('Quarter',5e-6)):
        config=common['read'](root/name/'Preparation.json')
        assert config['maximum_bar_step']==expected
    path=repo/'docs/regression/Coupled6D'/COARSE[0]
    assert sha256(path.read_bytes()).hexdigest().upper()==COARSE[1]
    with ZipFile(path) as z:
        raw=z.read('NativeBarControlProof.json')
        assert sha256(raw).hexdigest().upper()==COARSE_PROOF
        coarse=json.loads(raw)['Adaptive']
    peaks={name:peak(data) for name,data in ({'Coarse':coarse}|variants).items()}
    forces=[row['Qy_N'] for row in peaks.values()]
    relative=(max(forces)-min(forces))/min(forces)
    assert relative<TOLERANCE
    assert all(80000.<value<81000. for value in forces)
    return {'native':variants,'peaks':peaks,'relative_peak_spread':relative,'declared_relative_tolerance':TOLERANCE,
            'physical_limit_established':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    with TemporaryDirectory(dir=a.out.resolve().parent) as folder:
        proof=verify(a.repo,a.root,Path(folder))
    a.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('NATIVE MVT2 BAR REFINEMENT VERIFIED 145 124')
