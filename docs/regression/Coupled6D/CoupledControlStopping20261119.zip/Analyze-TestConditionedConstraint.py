"""ДЛЯ ТЕСТОВ. Проверяет общий подсчёт обусловленности и сохраняет отрицательный нелинейный результат."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestAnalyze(root, coordinates, output):
    """Точная матрица и все оценки сверяются независимо; линейный успех не подменяет силовую приёмку."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Analyze-TestYieldSequence.py'))['TestAnalyze'](root, output)
    result = json.loads(output.read_bytes())
    reference = run_path(str(here / 'Analyze-TestMaterialCoordinates.py'))['TestRead'](coordinates / 'Native/MaterialCoordinates1.bin')
    raw = (root / 'Native/NewtonLine.Rank0.bin').read_bytes()
    assert raw[:16] == b'NDMRANKTEST00001'
    size, = struct.unpack_from('<i', raw, 16)
    assert size == 61 and len(raw) == 20 + 8 * (3*size + 3*size*size)
    values = np.frombuffer(raw, '<f8', offset=20)
    seed, scales, residual = (values[j*size:(j+1)*size] for j in range(3))
    matrices = values[3*size:].reshape(3, size, size)
    np.testing.assert_array_equal(seed[:60], reference['seed'])
    assert seed[60] == reference['factor']
    np.testing.assert_array_equal(scales, reference['scales'])
    np.testing.assert_array_equal(residual, reference['residual'])
    np.testing.assert_array_equal(matrices[0], reference['positive'])
    np.testing.assert_array_equal(matrices[1], reference['negative'])
    rebuilt = (matrices[0]-matrices[1]) / .000002
    assert np.all(np.abs(matrices[2] - rebuilt) <= 2*np.spacing(np.abs(rebuilt)))
    normalized = matrices[2] / np.linalg.norm(matrices[2], axis=1)[:, None]
    inverse = np.linalg.inv(normalized)
    null = inverse[:, -1]
    rows = list(csv.reader((root / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    observed = [row for row in rows if row[0] == 'COORDINATE_SCORE']
    assert len(observed) == len(reference['surfaces']) == 129
    scores, maximum_error = [], 0.
    for surface, row in zip(reference['surfaces'], observed):
        assert [int(row[1]), int(row[2])] == [surface['point'], surface['side']]
        assert (row[3] == 'True') == surface['crossing']
        if not surface['crossing']:
            assert row[4] == 'False'
            continue
        assert surface['available'] and row[4] == 'True'
        gradient = surface['gradient'] / np.linalg.norm(surface['gradient'])
        transformed = gradient @ inverse
        shift = (-transformed + np.eye(size)[-1]) / transformed[-1]
        candidate_inverse = inverse + null[:, None]*shift[None, :]
        augmented = np.vstack((normalized[:-1], gradient))
        assert np.linalg.norm(augmented @ candidate_inverse - np.eye(size), np.inf) < 1e-8
        score = np.linalg.norm(candidate_inverse, 'fro')
        error = abs(float(row[5])-score)/score
        maximum_error = max(maximum_error, error)
        assert error < 1e-8
        assert abs(float(row[6]) - abs(transformed[-1])/np.linalg.norm(null)) < 1e-9
        scores.append(dict(point=surface['point'], side=surface['side'], inverse_norm=float(score), target_MPa=surface['value']))
    scores.sort(key=lambda item: item['inverse_norm'])
    selected, = [row for row in rows if row[:2] == ['AUTO_EVENT', 'ConditionedSecant']]
    assert selected[2] == 'True' and [int(selected[3]), int(selected[4])] == [scores[0]['point'], scores[0]['side']]
    assert float(selected[7]) == float([row for row in rows if row[0] == 'EVENT_TARGET'][0][2])
    assert result['accepted_steps'] == 0 and not result['cases']['0']['configured_residual_criterion_met']
    assert not result['cases']['0']['native_original_tolerance_verified']
    assert result['cases']['0']['stop'] == 'NO_DESCENT_WITHIN_LINE_BUDGET'
    result.update(all_129_candidates_and_exact_selection_matrix_verified=True,
        coordinate_ranking=scores, maximum_score_relative_difference=maximum_error,
        selection_seconds=float(selected[-1]), nonlinear_seconds=result['cases']['0']['seconds'],
        observed_total_full_equation_reads=123+result['cases']['0']['function_calls'],
        linear_condition_does_not_guarantee_nonlinear_convergence=True,
        numerical_rejection_is_not_physical_failure=True, installed_workbook_changed=False)
    assert result['observed_total_full_equation_reads'] <= 4500
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('ALL CANDIDATE SCORES AND CONDITIONED COORDINATE FAILURE VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--coordinates', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.coordinates.resolve(), args.out.resolve())
