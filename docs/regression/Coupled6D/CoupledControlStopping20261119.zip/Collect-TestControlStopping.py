"""ДЛЯ ТЕСТОВ. Сохраняет координаты, отрицательную проверку обусловленности и рабочую остановку гибридного резерва."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
from zipfile import ZipFile, ZIP_DEFLATED


def TestCollect(repo, root):
    """Сохраняет реальные проекты, контрольные архивные ссылки и XML сохранённого/открытого Results."""
    here = Path(__file__).resolve().parent
    cases = {'ObserverError': 'MaterialCoordinates20261119', 'Coordinates': 'MaterialCoordinates02202611119',
             'Selection': 'ConditionedConstraint04202611119', 'Stopping': 'HybridConfigured20261119'}
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for key in cases:
        folder = root / 'Cases' / key
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(sources) == 36
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    scratch = root.parent
    failed = scratch / 'ConditionedConstraint20261119'
    for name in ('Compile.log', 'CompileFailureClosure.json', 'Preparation.json',
                 'src/Solver/CCoupledControlCondition.cls', 'tests/modTestCoupledControlCondition.bas'):
        target = root / 'FailedCompilation' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((failed / name).read_bytes())
    final = scratch / cases['Stopping']
    saved, = re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$', (final / 'Native/Stock.txt').read_text('utf-8-sig'), re.M)
    assert Path(saved).resolve().is_relative_to((final / 'Temp').resolve())
    with ZipFile(saved) as book, ZipFile(root / 'Cases/Stopping/SavedWorkbookMarkup.zip', 'x', ZIP_DEFLATED, compresslevel=9) as bundle:
        for name in sorted(book.namelist()):
            if Path(name).suffix.lower() in ('.xml', '.rels', '.vml'):
                bundle.writestr(name, book.read(name))
    (root / 'Cases/Stopping/SavedWorkbookScope.json').write_text(json.dumps({
        'whole_workbook_preserved': False, 'xml_relationships_vml_saved': True, 'binary_media_saved': False,
        'results_save_reopen_verified_by_native_report': True}, indent=2)+'\n', encoding='utf-8')
    manifest = json.loads((repo / 'docs/reports/Coupled6DEvidence.json').read_bytes())
    references = {}
    plans = {'CoupledOriginalAccuracy20261119': ('Cases/Adaptive/', ('src/Solver/CCoupledNewtonSolver.cls',
        'src/Materials/CCoupledConcreteResponse.cls', 'src/Materials/CCoupledConcreteReturn.cls',
        'Input/Reverse1.bin', 'Native/NewtonLine.csv'), 'Reference/Adaptive'),
        'CoupledDefaultRecovery20261119': ('Cases/Default/', ('Native/ActualReverse.txt',), 'Reference/Stock')}
    for name, (prefix, members, destination) in plans.items():
        archive = repo / 'docs/regression/Coupled6D' / (name + '.zip')
        digest = sha256(archive.read_bytes()).hexdigest().upper()
        assert digest == manifest['archives'][name]
        pins = {}
        with ZipFile(archive) as bundle:
            recorded = json.loads(bundle.read('Files.json'))
            for member in members:
                raw = bundle.read(prefix + member)
                assert sha256(raw).hexdigest().upper() == recorded[prefix + member]
                target = root / destination / member
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(raw)
                pins[member] = recorded[prefix + member]
        references[name] = dict(archive_sha256=digest, prefix=prefix, destination=destination, files=pins)
    (root / 'ReferenceArchives.json').write_text(json.dumps(references, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    names = ('Collect-TestControlStopping.py', 'Check-TestControlStopping.py', 'Check-TestOriginalAccuracy.py',
        'Audit-TestGenericConstraintBook.py', 'Audit-TestPrivateCoupledBook.py', 'Canonical-TestCoreVBA.py',
        'Analyze-TestMaterialCoordinates.py', 'Analyze-TestConditionedConstraint.py', 'Analyze-TestHybridConfigured.py',
        'Analyze-TestNewtonLine.py', 'Analyze-TestYieldProjection.py', 'Analyze-TestYieldSequence.py',
        'Analyze-TestGenericBridge.py', 'Stage-TestMaterialCoordinates.py', 'TestNativeMaterialCoordinates.bas.txt',
        'Stage-TestConditionedConstraint.py', 'TestNativeConditionedCoordinate.cls.txt', 'Stage-TestHybridConfigured.py',
        'Stage-TestOriginalAccuracy.py', 'Stage-TestResolvedBridge.py', 'Stage-TestAdaptiveBridge.py',
        'Stage-TestAutomaticConstraint.py', 'Stage-TestGenericConstraint.py', 'Stage-TestGenericSequence.py',
        'Stage-TestYieldProjectedSequence.py', 'CProjectedEquationsTest.cls', 'TestNativeGenericHybrid.bas.txt',
        'TestNativeOrdinaryBridge.bas.txt', 'TestNativeYieldProjection.bas.txt', 'TestNativeNewtonLine.bas.txt',
        'TestNativeNewtonYieldEvent.bas.txt', 'Stage-TestNewtonYieldPrecision.py', 'Stage-TestNewtonYieldEvent.py',
        'Stage-TestNewtonLine.py', 'Guard-TestExistingOffice.py', 'Check-TestActualReverseCapture.py',
        'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py', 'Pack-TestCompiledProjects.py')
    for name in names:
        (root / name).write_bytes((here / name).read_bytes())
    for name in ('CCoupledConcreteResponse.cls', 'CCoupledConcreteReturn.cls'):
        target = root / 'WorkingMaterials' / name
        target.parent.mkdir(exist_ok=True)
        target.write_bytes((repo / 'src/Materials' / name).read_bytes())
    working = ('src/Solver/CCoupledNewtonSolver.cls', 'tests/CCoupledControlConditionTest.cls',
               'tests/modTestCoupledControlCondition.bas', 'docs/CoupledConstraintEquations.md')
    working_pins = {}
    for name in working:
        target = root / 'WorkingSources' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((repo / name).read_bytes())
        working_pins[name] = sha256(target.read_bytes()).hexdigest().upper()
    run_path(str(here / 'Pack-TestCompiledProjects.py'))['TestPack'](root, cases)
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '7d9b7ecdd3b63e83afaebfb59efe6a40458df440',
        'working_sources': working_pins, 'only_working_solver_behavior_change': 'requested absolute hybrid stopping',
        'condition_selector_is_test_only': True, 'new_constraint_recovery_enabled_in_stock': False,
        'installed_workbook_changed': False, 'physical_capacity_certified': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name not in ('Files.json', 'CompiledVBA.bin')}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('CONTROL AND STOPPING EVIDENCE COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
