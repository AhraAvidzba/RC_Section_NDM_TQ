"""ДЛЯ ТЕСТОВ. Сравнивает исходную и заданную точность остановки при неизменной силовой приёмке."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from runpy import run_path


def TestAnalyze(root, reference, output):
    """Проверяет фактические поля и их допуски; разница историй после ранней остановки не скрывается."""
    here = Path(__file__).resolve().parent
    analyze = run_path(str(here / 'Analyze-TestGenericBridge.py'))['TestAnalyze']
    analyze(root, output)
    result = json.loads(output.read_bytes())
    old_code = (reference / 'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    new_code = (root / 'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    old = 'remaining, GeomMin(absoluteTolerance, 0.0000000001), _'
    new = 'remaining, absoluteTolerance, _'
    assert old_code.count(old) == 1 and old_code.replace(old, new, 1) == new_code
    for name in ('CCoupledConcreteReturn.cls', 'CCoupledConcreteResponse.cls'):
        assert (reference / 'src/Materials' / name).read_bytes() == (root / 'src/Materials' / name).read_bytes()
    assert (reference / 'Input/Reverse1.bin').read_bytes() == (root / 'Input/Reverse1.bin').read_bytes()
    old_rows = list(csv.reader((reference / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    new_rows = list(csv.reader((root / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    previous = [row for row in old_rows if row[0] == 'BRIDGE_RESULT']
    current = [row for row in new_rows if row[0] == 'BRIDGE_RESULT']
    assert len(previous) == len(current) == result['ordinary_bridge']['accepted_steps'] == 6
    for index in range(3):
        old_field, = [row for row in old_rows if row[:2] == ['BRIDGE_FINAL', str(index)]]
        new_field, = [row for row in new_rows if row[:2] == ['BRIDGE_FINAL', str(index)]]
        assert old_field == new_field
    result.update(working_runtime_changed=True, only_solver_change_is_requested_hybrid_stopping=True,
        physical_material_sources_exact_equal=True, accepted_prefix_binary_equal=True,
        first_three_ordinary_fields_and_lambdas_CSV_equal=True,
        later_accepted_histories_are_not_claimed_identical=True,
        previous_seconds_including_rejected_trials=sum(float(row[3]) for row in previous),
        current_seconds_including_rejected_trials=sum(float(row[3]) for row in current),
        final_admission_and_uncertainty_gates_unchanged=True,
        physical_capacity_certified=False, installed_workbook_changed=False)
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('REQUESTED HYBRID STOPPING SOURCE DIFFERENCE AND ALL ACCEPTED EQUATIONS VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--reference', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.reference.resolve(), args.out.resolve())
