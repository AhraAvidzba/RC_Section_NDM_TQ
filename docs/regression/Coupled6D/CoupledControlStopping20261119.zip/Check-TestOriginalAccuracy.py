"""ДЛЯ ТЕСТОВ. Разделяет пригодное НДС, различимое продвижение нагрузки и неподтверждённый физический предел."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
import csv
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


def TestFiles(root):
    """Проверяет точные архивные входы до исполнения повторяемых проверок."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == '32ffcc49c6440cbc6b4c65ec1d39124857a922d9'


def TestMaterial(root, folder):
    """Возврат полностью исходный; у отклика разрешён лишь один читающий экспорт принятого состояния."""
    name = 'CCoupledConcreteReturn.cls'
    assert (root / 'WorkingMaterials' / name).read_bytes() == (folder / 'src/Materials' / name).read_bytes()
    name = 'CCoupledConcreteResponse.cls'
    original = (root / 'WorkingMaterials' / name).read_text('utf-8-sig')
    actual = (folder / 'src/Materials' / name).read_text('utf-8-sig')
    assert actual.startswith(original)
    addition = actual[len(original):]
    assert re.fullmatch(r"\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Читает принятую историю для независимого контроля, без изменения рабочего закона\.\nFriend Function ReadNewtonYieldEventStateTest\(ByVal point As Long\) As Variant\n.*?\nEnd Function\n", addition, re.S)
    assert 'ReturnPrecisionFactorTest' not in actual
    return {'return_source_bytes_exact': True, 'response_source_exact_except_one_readonly_export': True,
            'working_return_sha256': sha256((root / 'WorkingMaterials/CCoupledConcreteReturn.cls').read_bytes()).hexdigest().upper()}


def TestNative(repo, root, output):
    """Проверяет фактические VBA четырёх книг и безопасное завершение собственных Office."""
    TestFiles(root)
    projects = {}
    for folder in sorted((root / 'Cases').iterdir()):
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Code.json'
            run_path(str(root / 'Audit-TestGenericConstraintBook.py'))['TestAudit'](repo, folder, proof)
            record = json.loads(proof.read_bytes())
        assert (record['components'], record['imported'], record['unchanged']) == (250, 37, 213)
        assert len(record['checked_coupled_sources']) == 36 and record['compiled_project_storage'] == 'solid-exact-CFB'
        log_path = folder / 'Native/ReversePolish.txt'
        log = log_path.read_text('utf-8-sig')
        assert 'RUNTIME ERROR:' not in log and '\nFAIL:' not in log
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
        source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
        assert source == record['compiled_workbook_sha256']
        closure = json.loads(log_path.with_name(log_path.name + '.ProcessClosure.json').read_bytes())
        assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
        assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
        record['original_material_methods'] = TestMaterial(root, folder)
        projects[folder.name] = record
    assert set(projects) == {'Original', 'Resolved', 'Adaptive', 'Automatic'}
    output.write_text(json.dumps({'projects': projects, 'working_sources_changed': False,
        'ordinary_solver_recovery_enabled': False, 'installed_workbook_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('FOUR ACTUAL VBA PROJECTS AND ORIGINAL MATERIAL METHODS VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Не меняет допуски для получения успеха; крупные отказы и неразрешённые малые шаги сохраняются отдельно."""
    TestFiles(root)
    results = {}
    for key in ('Original', 'Resolved', 'Adaptive', 'Automatic'):
        folder = root / 'Cases' / key
        script = 'Analyze-TestYieldSequence.py' if key == 'Automatic' else 'Analyze-TestGenericBridge.py'
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Analysis.json'
            run_path(str(root / script))['TestAnalyze'](folder, proof)
            result = json.loads(proof.read_bytes())
        if key != 'Automatic':
            assert all(case['configured_residual_criterion_met'] for case in result['cases'].values())
        rows = list(csv.reader((folder / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
        result['automatic_event_observations'] = [row for row in rows if row[0] == 'AUTO_EVENT']
        result['explicit_ordinary_stops'] = [row for row in rows if row[0] == 'BRIDGE_STOP']
        result['bounded_cutback_attempts'] = [row for row in rows if row[0] == 'BRIDGE_TRY']
        for row in result['bounded_cutback_attempts']:
            assert 0 <= int(row[2]) <= 4 and 0 <= int(row[6]) <= 30
        if key == 'Original':
            assert result['accepted_steps'] == 4 and result['ordinary_bridge']['accepted_steps'] == 2
            assert all(not step['gain_exceeds_adjoint_uncertainty'] for step in result['ordinary_bridge']['steps'].values())
        elif key in ('Resolved', 'Adaptive'):
            assert result['accepted_steps'] == 4
            assert all(step['gain_exceeds_adjoint_uncertainty'] for step in result['ordinary_bridge']['steps'].values())
        if key == 'Resolved':
            assert result['ordinary_bridge']['accepted_steps'] == 2
            assert result['explicit_ordinary_stops'] == [['BRIDGE_STOP', '2', 'NotPhysicalFailure']]
        if key == 'Automatic':
            selected, = [row for row in rows if row[0] == 'EVENT_LOCATION']
            dominant, = [row for row in rows if row[:2] == ['AUTO_EVENT', 'DominantSecant']]
            target, = [row for row in rows if row[0] == 'EVENT_TARGET']
            assert dominant[2] == 'True' and selected[2:5] == dominant[3:6]
            assert float(target[2]) == float(dominant[7])
            assert result['accepted_steps'] == 0 and not result['cases']['0']['configured_residual_criterion_met']
            assert not result['cases']['0']['native_original_tolerance_verified']
            assert result['cases']['0']['stop'] == 'NO_DESCENT_WITHIN_LINE_BUDGET'
            result['event_location_and_target_from_actual_native_departure'] = True
            result['automatically_selected_constraint_failed_not_a_physical_failure'] = True
        results[key] = result
    results.update(independent_material_reintegration=False, ordinary_solver_recovery_enabled=False,
        installed_workbook_changed=False, physical_capacity_certified=False, full_acceptance_completed=False)
    output.write_text(json.dumps(results, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('ORIGINAL MATERIAL ACCURACY LOAD RESOLUTION CUTBACKS AND AUTOMATIC COORDINATE VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
