"""ДЛЯ ТЕСТОВ. Независимо проверяет все материальные градиенты и ранжирует координаты по полной матрице равновесия."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestRead(path):
    """Читает точные исходные Double с проверкой размеров и отсутствия остатка."""
    raw, position = path.read_bytes(), 16
    assert raw[:16] == b'NDMCOORDTEST0002'

    def TestScalar(code):
        """Скалярный формат имеет явный little-endian порядок."""
        nonlocal position
        size = struct.calcsize('<' + code)
        assert position + size <= len(raw)
        result, = struct.unpack_from('<' + code, raw, position)
        position += size
        return result

    def TestVector():
        """VBA-массивы записаны вместе с размером, без текстового округления."""
        nonlocal position
        size = TestScalar('i')
        assert 1 <= size <= 1000 and position + 8 * size <= len(raw)
        result = np.frombuffer(raw, '<f8', count=size, offset=position).copy()
        position += 8 * size
        assert np.all(np.isfinite(result))
        return result

    size, index, factor = TestScalar('i'), TestScalar('i'), TestScalar('d')
    assert size == 61 and index in (0, 1)
    result = dict(index=index, factor=factor, seed=TestVector(), scales=TestVector(), residual=TestVector(), sizes=TestVector())
    assert result['seed'].shape == (60,) and all(result[key].shape == (61,) for key in ('scales', 'residual', 'sizes'))
    for name in ('positive', 'negative', 'jacobian', 'assembled'):
        count = size * size
        assert position + 8 * count <= len(raw)
        result[name] = np.frombuffer(raw, '<f8', count=count, offset=position).copy().reshape(size, size)
        position += 8 * count
        assert np.all(np.isfinite(result[name]))
    total = TestScalar('i')
    assert 1 <= total <= 3000
    surfaces = []
    for _ in range(total):
        point, side, principal, crossing, available = [TestScalar('i') for _ in range(5)]
        value, other_value = TestScalar('d'), TestScalar('d')
        gradient, state = TestVector(), TestVector()
        assert gradient.shape == (61,) and state.shape == (10,)
        assert point >= 1 and side in (-1, 0, 1) and principal == 0 and crossing in (-1, 0) and available in (-1, 0)
        surfaces.append(dict(point=point, side=side, crossing=crossing == -1,
            value=value, accepted_value=other_value, gradient=gradient, state=state, available=available == -1))
    assert position == len(raw)
    result['surfaces'] = surfaces
    result['sha256'] = sha256(raw).hexdigest().upper()
    return result


def TestLaw(operator, field, state, elastic, with_gradient=True):
    """Собственные значения симметричного тензора дают независимые значение CDP и аналитический градиент."""
    alpha, gamma, cc, ct = state[0], state[1], state[8], state[9]
    stress = elastic @ (operator @ field - state[2:8])
    tensor = np.array(((stress[0], stress[3], stress[4]), (stress[3], stress[1], stress[5]), (stress[4], stress[5], stress[2])))
    values, directions = np.linalg.eigh(tensor)
    trace = np.sum(stress[:3])
    deviator = tensor - np.eye(3) * trace / 3
    q = np.sqrt(1.5 * np.sum(deviator * deviator))
    high = values[-1]
    branch = cc / ct * (1-alpha) - (1+alpha) if high > 0 else gamma
    value = (alpha * trace + q + branch * high) / (1-alpha) - cc
    if not with_gradient:
        return float(value), None
    vector = directions[:, -1]
    projector = np.outer(vector, vector)
    derivative = np.r_[alpha + 1.5 * (stress[:3] - trace / 3) / q + branch * vector**2,
        3 * stress[3:] / q + 2 * branch * projector[np.triu_indices(3, 1)]] / (1-alpha)
    return float(value), derivative @ elastic @ operator


def TestAnalyze(root, output):
    """Ранжирование не объявляет выбранную координату пригодным нелинейным решением; это требует новой силовой проверки."""
    here = Path(__file__).resolve().parent
    read_source = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original = read_source(root / 'Input/Reverse1.bin')
    operators = run_path(str(here / 'Check-TestHardHalfSteps.py'))['TestOperators']
    _, _, _, _, _, _, basis, slope = operators(root / 'Native/NewtonLine.Operators.csv', 60, 43)
    modulus, poisson = original['calibration'][:2]
    elastic = np.zeros((6, 6))
    factor = modulus / ((1+poisson)*(1-2*poisson))
    elastic[:3, :3] = factor * poisson
    np.fill_diagonal(elastic[:3, :3], factor * (1-poisson))
    elastic[3:, 3:] = np.eye(3) * modulus / (2 * (1+poisson))
    contexts = {}
    for index in (0, 1):
        data = TestRead(root / f'Native/MaterialCoordinates{index}.bin')
        expected_seed = original['accepted'].copy()
        expected_factor = original['lambdas'][-1]
        if index:
            expected_seed[:56] += .5 * (original['accepted'] - original['previous'])[:56]
            expected_factor += .5 * (original['lambdas'][-1] - original['lambdas'][-2])
        np.testing.assert_array_equal(data['seed'], expected_seed)
        assert data['factor'] == expected_factor
        rebuilt = (data['positive'] - data['negative']) / (2*data['sizes'])
        # Финальное скалярное деление VBA допускает отличие в последних битах от NumPy binary64; входные пробы остаются точными.
        assert np.all(np.abs(data['jacobian'] - rebuilt) <= 2*np.spacing(np.abs(rebuilt)))
        a = data['jacobian'][:-1]
        row_norms = np.linalg.norm(a, axis=1)
        assert np.all(row_norms > 0)
        scaled = a / row_norms[:, None]
        _, singular, vt = np.linalg.svd(scaled, full_matrices=True)
        null = vt[-1]
        assert np.linalg.norm(scaled @ null) < 1e-13
        asymmetric = (data['positive'][:-1] + data['negative'][:-1] - 2*data['residual'][:-1, None]) / data['sizes']
        _, asymmetry_singular, asymmetry_vt = np.linalg.svd(asymmetric / row_norms[:, None], full_matrices=False)
        records, unavailable, value_error, gradient_error = [], [], 0., 0.
        for surface in data['surfaces']:
            operator = (basis + surface['side'] * .001 * slope)[surface['point']-1]
            value, gradient = TestLaw(operator, data['seed'], surface['state'], elastic, surface['available'])
            value_error = max(value_error, abs(value - surface['value']))
            assert abs(value - surface['value']) < 1e-9
            if not surface['available']:
                assert np.all(surface['gradient'] == 0)
                unavailable.append(dict(point=surface['point'], side=surface['side'], value_MPa=surface['value']))
                continue
            expected_gradient = np.r_[gradient * data['scales'][:-1], 0.]
            discrepancy = np.linalg.norm(expected_gradient - surface['gradient']) / np.linalg.norm(expected_gradient)
            gradient_error = max(gradient_error, discrepancy)
            assert discrepancy < 1e-9
            assert surface['gradient'][-1] == 0
            c = surface['gradient'] / np.linalg.norm(surface['gradient'])
            augmented = np.vstack((scaled, c))
            spectrum = np.linalg.svd(augmented, compute_uv=False)
            records.append(dict(point=surface['point'], side=surface['side'], crossing=surface['crossing'],
                value_MPa=surface['value'], accepted_value_MPa=surface['accepted_value'],
                null_alignment=abs(float(c @ null)), smallest_singular_value=float(spectrum[-1]),
                asymmetry_alignment=abs(float(c @ asymmetry_vt[0])),
                condition=float(spectrum[0]/spectrum[-1])))
        records.sort(key=lambda item: (-item['smallest_singular_value'], item['point'], item['side']))
        contexts[str(index)] = dict(sha256=data['sha256'], total_surfaces=len(data['surfaces']),
            available_gradients=len(records), unavailable_gradients=unavailable,
            maximum_independent_value_error_MPa=value_error, maximum_independent_gradient_relative_error=gradient_error,
            row_scaled_equilibrium_singular_values=singular.tolist(),
            row_scaled_asymmetry_singular_values=asymmetry_singular.tolist(),
            raw_control_condition=float(np.linalg.cond(data['jacobian'] / np.linalg.norm(data['jacobian'], axis=1)[:, None])),
            ranking=records, crossing_ranking=[item for item in records if item['crossing']])
        print('CONTEXT', index, 'TOP ALL', [(r['point'], r['side'], r['condition']) for r in records[:5]], flush=True)
        print('CONTEXT', index, 'TOP CROSSINGS', [(r['point'], r['side'], r['condition']) for r in contexts[str(index)]['crossing_ranking'][:5]], flush=True)
        print('CONTEXT', index, 'TOP ASYMMETRY', [(r['point'], r['side'], r['asymmetry_alignment']) for r in sorted(records, key=lambda r: -r['asymmetry_alignment'])[:5]], flush=True)
    output.write_text(json.dumps(dict(contexts=contexts, all_values_gradients_and_difference_arithmetic_verified=True,
        material_history_unchanged=True, nonlinear_convergence_of_ranked_coordinate_not_yet_verified=True,
        physical_capacity_certified=False, installed_workbook_changed=False), indent=2, sort_keys=True)+'\n', encoding='utf-8')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
