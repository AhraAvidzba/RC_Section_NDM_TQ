"""ДЛЯ ТЕСТОВ. Готовит полные матрицы и все материальные градиенты для выбора устойчивой координаты управления."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Исходный закон и принятая история неизменны; новые равновесия на этапе записи не ищутся."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestOriginalAccuracy.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig') + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Наблюдает штатное подтверждение смены ветви для явно перечисляемой точки; не выбирает точку по номеру.
Friend Function ReadMaterialCrossingTest(ByRef initial() As Double, ByRef ends() As Double, ByVal point As Long, ByVal side As Long) As Variant
    Dim station As TYieldStation, ready As Boolean
    ready = ReadYieldCrossing(point, side, initial, ends, station)
    ReadMaterialCrossingTest = Array(ready, station.FromValue, station.ToValue)
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestNativeMaterialCoordinates.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', lambda _: body, code)
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for filename in (Path(__file__).name, 'TestNativeMaterialCoordinates.bas.txt'):
        (root / filename).write_bytes((here / filename).read_bytes())
        prep['inputs'][filename] = sha256((here / filename).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'AllMaterialCoordinateConditioning',
        'new_equilibrium_or_capacity_search_executed': False,
        'contexts': ['accepted', 'half_forward_secant'],
        'all_model_points_and_three_stations_enumerated': True,
        'full_raw_central_difference_matrices_saved': True,
        'material_scalar_values_gradients_and_committed_states_saved': True,
        'original_material_methods_exact_except_readonly_state_export': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('ALL MATERIAL COORDINATES AND FULL MATRICES READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
