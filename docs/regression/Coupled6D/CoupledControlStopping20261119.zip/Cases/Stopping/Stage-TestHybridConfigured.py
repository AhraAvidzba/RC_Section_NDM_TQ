"""ДЛЯ ТЕСТОВ. Проверяет остановку рабочего гибридного резерва на заданном абсолютном допуске при неизменной полной приёмке."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Повторяет те же четыре переходных и до шести обычных шагов; точность материалов и критерии приёмки не меняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestAdaptiveBridge.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    code = (root / 'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    assert 'remaining, absoluteTolerance, _' in code
    assert 'remaining, GeomMin(absoluteTolerance, 0.0000000001)' not in code
    for filename in (Path(__file__).name,):
        (root / filename).write_bytes((here / filename).read_bytes())
        prep['inputs'][filename] = sha256((here / filename).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'WorkingHybridConfiguredAbsoluteStopping',
        'working_runtime_changed': True, 'installed_workbook_changed': False,
        'hybrid_stopping_uses_requested_absolute_tolerance': True,
        'final_force_gauge_control_direction_and_steel_admission_unchanged': True,
        'lambda_uncertainty_and_resolution_gates_unchanged': True,
        'physical_materials_and_their_accuracy_unchanged': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('WORKING HYBRID REQUESTED STOPPING CRITERION READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
