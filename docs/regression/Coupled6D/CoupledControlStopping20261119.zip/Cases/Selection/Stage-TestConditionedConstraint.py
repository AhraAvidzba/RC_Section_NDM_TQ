"""ДЛЯ ТЕСТОВ. Выбирает материальную координату рабочей оценкой обусловленности и проверяет её нелинейным решением."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Перечисление охватывает всю модель; параметры прочности и допуски не меняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestAutomaticConstraint.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for name in ('tests/CCoupledControlConditionTest.cls', 'tests/modTestCoupledControlCondition.bas'):
        (root / name).write_bytes((repo / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
        prep['modules'].append(Path(name).stem)
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig') + '\n' + (here / 'TestNativeConditionedCoordinate.cls.txt').read_text('utf-8-sig')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '        target = 0.001'
    assert code.count(old) == 1
    code = code.replace(old, '        target = coordinate + 0.5 * spacing', 1)
    old = 'solver.ReadDominantYieldCrossingTest(accepted, seed, currentFactor, seedFactor)'
    assert code.count(old) == 1
    code = code.replace(old, 'solver.ReadConditionedYieldCrossingTest(accepted, seed, currentFactor, seedFactor, handle, mHardPreparedPathTest & ".Rank0.bin")', 1)
    code = code.replace('AUTO_EVENT;DominantSecant;', 'AUTO_EVENT;ConditionedSecant;', 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт единую инвариантную числовую запись для наблюдателя общего класса ранжирования.
Public Function TestControlNumber(ByVal value As Double) As String
    TestControlNumber = TestOnsetNumber(value)
End Function
'''
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = 'modTestCoupledConstraint.RunTestCoupledConstraint,modTestCoupledHybrid.RunTestCoupledHybrid'
    assert code.count(old) == 1
    code = code.replace(old, old + ',modTestCoupledControlCondition.RunTestCoupledControlCondition', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for filename in (Path(__file__).name, 'TestNativeConditionedCoordinate.cls.txt'):
        (root / filename).write_bytes((here / filename).read_bytes())
        prep['inputs'][filename] = sha256((here / filename).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'ConditionedMaterialCoordinateOriginalAccuracy',
        'native_selection_uses_CCoupledControlConditionTest': True,
        'selection_full_raw_FD_evaluations': 123,
        'conditioned_native_scores_for_all_confirmed_crossings_saved': True,
        'no_target_or_point_hardcoded': True,
        'event_location_and_target_are_native_selection_results': True,
        'experimental_class_in_tests_not_enabled_in_stock_search': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('WORKING CONDITION CLASS AND AUTOMATIC NONLINEAR VERIFICATION READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
