"""ДЛЯ ТЕСТОВ. Проверяет уменьшение действительно отклонённого обычного шага и материальную причину ошибки касательной."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Сохраняет явный лимит проб; принятые поля не заменяются при отказе очередной цели."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestResolvedBridge.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig') + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выбирает переход по действительному отклонению напряжений от касательной в наиболее нарушенной силовой строке.
Friend Function ReadDominantYieldCrossingTest(ByRef initial() As Double, ByRef ends() As Double, _
        ByVal initialLambda As Double, ByVal endLambda As Double) As Variant
    Dim station As TYieldStation, held As TYieldStation, ready As Boolean, row As Long, i As Long, j As Long
    Dim load(1 To 6) As Double, before() As Double, matrix() As Double, mismatch As Double, value As Double, largest As Double
    SetControlledLoad initialLambda, load
    If Not Evaluate(initial, True, recordTrial:=False, consistentBranch:=True) Then GoTo FinishedTest
    before = mResidual: matrix = mMatrix
    SetControlledLoad endLambda, load
    If Not Evaluate(ends, False, recordTrial:=False) Then GoTo FinishedTest
    For i = 1 To mGaugeStart - 1
        value = mResidual(i) - before(i) + mDirectionEquations(i) * (endLambda - initialLambda)
        For j = 1 To mDegreeCount: value = value - matrix(j, i) * (ends(j) - initial(j)): Next j
        If Abs(value) > largest Then largest = Abs(value): mismatch = value: row = i
    Next i
    If row > 0 Then ready = FindYieldDeparture(held, initial, ends, row, mismatch, station)
FinishedTest:
    ReadDominantYieldCrossingTest = Array(ready, station.Point, station.Side, station.PrincipalIndex, _
        station.FromValue, station.ToValue, row, mismatch)
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '        Dim scales As Variant: scales = solver.ReadNewtonLineScalesTest'
    assert code.count(old) == 1
    code = code.replace(old, '''        If probeCase = 0 Then
            eventStartedTest = Timer: eventTest = solver.ReadDominantYieldCrossingTest(accepted, seed, currentFactor, seedFactor)
            Print #handle, "AUTO_EVENT;DominantSecant;" & CStr(eventTest(0)) & TestResolvedEventVector(eventTest) & ";" & TestOnsetNumber(Timer - eventStartedTest)
        End If
''' + old, 1)
    block, = re.findall(r'(?ms)^Private Sub TestReturnToOrdinaryControl\(.*?^End Sub', code)
    start = block.index('        Print #report, "BRIDGE_RATIO;"')
    end = block.index('        Print #report, "BRIDGE_RESULT;"', start)
    previous = block[start:end]
    attempt = previous[previous.index('        seed = accepted'):]
    assert attempt.endswith('        seconds = Timer - started\n')
    attempt = attempt.replace('        seconds = Timer - started\n', '')
    replacement = '''        Dim cutbackTest As Long, totalSecondsTest As Double, revisionTest As Long, copyTest() As Double
        totalSecondsTest = 0#: revisionTest = solver.AcceptedRevision
        For cutbackTest = 0 To 4
            Print #report, "BRIDGE_RATIO;" & CStr(stepIndex) & ";" & CStr(cutbackTest) & ";" & TestOnsetNumber(stepRatioTest)
''' + attempt + '''            seconds = Timer - started: totalSecondsTest = totalSecondsTest + seconds
            Print #report, "BRIDGE_TRY;" & CStr(stepIndex) & ";" & CStr(cutbackTest) & ";" & CStr(solved) & ";" & _
                TestOnsetNumber(seconds) & ";" & TestOnsetNumber(factor) & TestHardPreparedVector(solver.ReadPolishEffortTest)
            If solver.AcceptedRevision <> revisionTest Then Err.Raise 5, , "Проба уменьшения шага изменила принятую ревизию."
            solver.CopyAccepted copyTest
            For degree = 1 To UBound(accepted)
                If copyTest(degree) <> accepted(degree) Then Err.Raise 5, , "Проба уменьшения шага изменила принятое поле."
            Next degree
            If solved Then Exit For
            solver.DiscardStep: stepRatioTest = stepRatioTest * 0.5
        Next cutbackTest
        seconds = totalSecondsTest
'''
    body = block[:start] + replacement + block[end:]
    code = code.replace(block, body, 1)
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'AdaptiveOrdinaryBridgeOriginalMaterialAccuracy',
        'ordinary_bridge_cutbacks_per_step_limit': 4,
        'ordinary_bridge_cutbacks_preserve_accepted_field_and_revision': True,
        'dominant_material_departure_on_secant_observed': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('BOUNDED CUTBACKS AND DOMINANT TRANSITION OBSERVATION READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
