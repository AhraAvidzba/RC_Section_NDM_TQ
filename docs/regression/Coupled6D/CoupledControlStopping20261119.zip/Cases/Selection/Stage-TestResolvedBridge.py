"""ДЛЯ ТЕСТОВ. Проверяет различимые шаги обычного продолжения и автоматический выбор наблюдаемого материального события."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Не меняет рабочую точность и не принимает малый прирост нагрузки в качестве разрешённого продолжения."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestOriginalAccuracy.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig') + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Наблюдает действующий выбор ближайшего события на заданном отрезке без выбора номера точки в тесте.
Friend Function ReadFirstYieldCrossingTest(ByRef initial() As Double, ByRef ends() As Double) As Variant
    Dim station As TYieldStation, ready As Boolean
    ready = FirstYieldCrossing(initial, ends, station)
    ReadFirstYieldCrossingTest = Array(ready, station.Point, station.Side, station.PrincipalIndex, station.FromValue, station.ToValue)
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '        If Not solver.BeginNewtonLineTest(mReverseBaseTest, mReverseDirectionTest, projection, target, seed, seedFactor) Then _'
    assert code.count(old) == 2
    probe = '''        If probeCase = 0 Then
            Dim eventTest As Variant, eventStartedTest As Double
            eventStartedTest = Timer: eventTest = solver.ReadFirstYieldCrossingTest(accepted, original)
            Print #handle, "AUTO_EVENT;OriginalRejected;" & CStr(eventTest(0)) & TestHardPreparedVector(eventTest) & ";" & TestOnsetNumber(Timer - eventStartedTest)
            eventStartedTest = Timer: eventTest = solver.ReadFirstYieldCrossingTest(accepted, seed)
            Print #handle, "AUTO_EVENT;SecantSeed;" & CStr(eventTest(0)) & TestHardPreparedVector(eventTest) & ";" & TestOnsetNumber(Timer - eventStartedTest)
        End If
'''
    # Boolean фиксируется отдельным полем, остальные поля — числовым массивом без изменения знаков.
    probe = probe.replace('TestHardPreparedVector(eventTest)', 'TestResolvedEventVector(eventTest)')
    code = code.replace(old, probe + old, 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет номера и координаты события отдельно от логического признака результата.
Private Function TestResolvedEventVector(ByVal values As Variant) As String
    Dim i As Long
    For i = 1 To UBound(values): TestResolvedEventVector = TestResolvedEventVector & ";" & TestOnsetNumber(CDbl(values(i))): Next i
End Function
'''
    block, = re.findall(r'(?ms)^Private Sub TestReturnToOrdinaryControl\(.*?^End Sub', code)
    body = block.replace('    For stepIndex = 0 To 1', '    For stepIndex = 0 To 5')
    old = '        seed = accepted'
    assert body.count(old) == 1
    body = body.replace(old, '''        Dim stepRatioTest As Double: stepRatioTest = 2#
        If stepIndex = 0 Then stepRatioTest = 4#
        Print #report, "BRIDGE_RATIO;" & CStr(stepIndex) & ";" & TestOnsetNumber(stepRatioTest)
''' + old, 1)
    body = body.replace('0.5 * movement(degree)', 'stepRatioTest * movement(degree)')
    body = body.replace('0.5 * spacing', 'stepRatioTest * spacing')
    body = body.replace('0.5 * (currentFactor - previousFactor)', 'stepRatioTest * (currentFactor - previousFactor)')
    old = '        solver.CopyTrial field, actual'
    assert body.count(old) == 1
    body = body.replace(old, '''        Dim resolutionTest As Double, resolvedTest As Boolean
        resolutionTest = 8# * mReverseOptionsTest(4) * (1# + Abs(currentFactor))
        resolvedTest = (factor - currentFactor > uncertaintyTest And factor - currentFactor > resolutionTest)
        Print #report, "BRIDGE_RESOLUTION;" & CStr(stepIndex) & ";" & CStr(resolvedTest) & ";" & TestOnsetNumber(resolutionTest)
        If Not resolvedTest Then
            solver.DiscardStep
            Print #report, "BRIDGE_STOP;" & CStr(stepIndex) & ";LoadGainUnresolved;NotPhysicalFailure"
            Exit For
        End If
''' + old, 1)
    body = body.replace('& ";2;PhysicalCapacityOpen"', '& ";6;PhysicalCapacityOpen"')
    assert body != block and '0.5 *' not in body
    code = code.replace(block, body, 1)
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'ResolvedOrdinaryBridgeOriginalMaterialAccuracy',
        'bridge_step_limit': 6, 'resolved_ordinary_steps_required': True,
        'ordinary_bridge_step_ratios': [4, 2, 2, 2, 2, 2],
        'native_first_event_selection_observed_on_original_and_secant_segments': True,
        'automatic_event_not_used_to_claim_capacity': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('RESOLVED ORDINARY BRIDGE AND AUTOMATIC EVENT OBSERVATION READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
