"""ДЛЯ ТЕСТОВ. Решает один переход при станции и цели, выбранных из фактической ошибки касательной, без постоянной точки и q."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Берёт цель из реальной конечной пробы; единственный шаг сохраняет исходную точность и полную силовую приёмку."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestAdaptiveBridge.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code = code.replace('Option Explicit\n', 'Option Explicit\nPrivate mEventPointTest As Long, mEventSideTest As Long\n', 1)
    block, = re.findall(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', code)
    body = block.replace('For probeCase = 0 To 3', 'For probeCase = 0 To 0')
    old = '''        Print #handle, "EVENT_TARGET;" & CStr(probeCase) & ";" & TestOnsetNumber(target)

        Dim eventConcrete As CCoupledConcreteResponse: Set eventConcrete = sides(3)
        Print #handle, "EVENT_STATE;" & CStr(probeCase) & TestHardPreparedVector(eventConcrete.ReadNewtonYieldEventStateTest(25))
'''
    assert body.count(old) == 1
    body = body.replace(old, '', 1)
    old = '        Dim scales As Variant: scales = solver.ReadNewtonLineScalesTest'
    assert body.count(old) == 1
    body = body.replace(old, '''        If Not CBool(eventTest(0)) Or CLng(eventTest(3)) <> 0 Then Err.Raise 5, , "Не выбран наблюдаемый переход CDP."
        mEventPointTest = CLng(eventTest(1)): mEventSideTest = CLng(eventTest(2))
        target = CDbl(eventTest(5))
        Print #handle, "EVENT_LOCATION;" & CStr(probeCase) & ";" & CStr(mEventPointTest) & ";" & CStr(mEventSideTest) & ";0"
        Print #handle, "EVENT_TARGET;" & CStr(probeCase) & ";" & TestOnsetNumber(target)
        Dim eventConcrete As CCoupledConcreteResponse: Set eventConcrete = TestEventConcreteResponse()
        Print #handle, "EVENT_STATE;" & CStr(probeCase) & TestHardPreparedVector(eventConcrete.ReadNewtonYieldEventStateTest(mEventPointTest))
''' + old, 1)
    body = body.replace('CreateMaterialConstraint(25, 1, 0, target)', 'CreateMaterialConstraint(mEventPointTest, mEventSideTest, 0, target)')
    assert body.count('CreateMaterialConstraint(mEventPointTest, mEventSideTest, 0, target)') == 2
    body = body.replace('& ";4;PhysicalCapacityOpen"', '& ";1;PhysicalCapacityOpen"')
    body = body.replace('    TestReturnToOrdinaryControl solver, handle\n', '')
    code = code.replace(block, body, 1)
    for method in ('TestReadNewtonYieldEvent', 'TestReadNewtonYieldEventGradient'):
        block, = re.findall(r'(?ms)^Public (?:Function|Sub) ' + method + r'\(.*?^End (?:Function|Sub)', code)
        body = block.replace('PointStrain 25,', 'PointStrain mEventPointTest,').replace('AxialGradientAtPoint 25,', 'AxialGradientAtPoint mEventPointTest,')
        body = body.replace('0.001 * slope(component)', '(mEventSideTest * 0.001) * slope(component)')
        body = body.replace('Set response = mReverseSidesTest(3)', 'Set response = TestEventConcreteResponse()')
        body = body.replace('TryReadTrialYield(25,', 'TryReadTrialYield(mEventPointTest,')
        assert body != block
        code = code.replace(block, body, 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выбирает сохранённую историю центральной, левой или правой станции по автоматическому результату.
Private Function TestEventConcreteResponse() As CCoupledConcreteResponse
    Select Case mEventSideTest
        Case -1: Set TestEventConcreteResponse = mReverseSidesTest(1)
        Case 0: Set TestEventConcreteResponse = mReverseConcreteTest
        Case 1: Set TestEventConcreteResponse = mReverseSidesTest(3)
        Case Else: Err.Raise 5, , "Неизвестная тестовая станция."
    End Select
End Function
'''
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'AutomaticDominantMaterialConstraintOriginalAccuracy',
        'case_ids': [0], 'step_limit': 1, 'bridge_step_limit': 0,
        'event_point': None, 'event_station_z_over_L': None, 'event_target_MPa': None,
        'event_location_and_target_are_native_selection_results': True,
        'ordinary_bridge_step_ratios': [], 'generic_projection_used_only_for_first_four_steps': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('AUTOMATIC DOMINANT MATERIAL CONSTRAINT READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
