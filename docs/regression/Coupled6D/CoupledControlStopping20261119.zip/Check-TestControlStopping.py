"""ДЛЯ ТЕСТОВ. Проверяет исходные методы материала, отрицательный выбор координаты и рабочее изменение остановки."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def TestFiles(root):
    """Проверяет точные входы и код до исполнения повторяемых проверок."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == '7d9b7ecdd3b63e83afaebfb59efe6a40458df440'


def TestNative(repo, root, output):
    """Проверяет четыре фактических проекта, отрицательный запуск наблюдателя, регрессии и сохранение Results."""
    TestFiles(root)
    projects, totals = {}, {}
    phases = {'ObserverError': ('ReversePolish',), 'Coordinates': ('ReversePolish',),
        'Selection': ('ConstraintUnit', 'ReversePolish'), 'Stopping': ('Core', 'ReversePolish', 'Stock')}
    material = run_path(str(root / 'Check-TestOriginalAccuracy.py'))['TestMaterial']
    for key, reports in phases.items():
        folder = root / 'Cases' / key
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Code.json'
            run_path(str(root / 'Audit-TestGenericConstraintBook.py'))['TestAudit'](repo, folder, proof)
            record = json.loads(proof.read_bytes())
        assert (record['components'], record['imported'], record['unchanged']) == ((252, 39, 213) if key == 'Selection' else (250, 37, 213))
        assert len(record['checked_coupled_sources']) == 36 and record['compiled_project_storage'] == 'solid-exact-CFB'
        record['original_material_methods'] = material(root, folder)
        for phase in reports:
            log_path = folder / 'Native' / (phase + '.txt')
            log = log_path.read_text('utf-8-sig')
            expected_exit = 1 if key == 'ObserverError' else 0
            assert f'WATCHDOG_COMPLETED: exit={expected_exit}; source unchanged=True' in log
            source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
            assert source == record['compiled_workbook_sha256']
            closure = json.loads(log_path.with_name(log_path.name + '.ProcessClosure.json').read_bytes())
            assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == expected_exit
            assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
            if key == 'ObserverError':
                assert 'Type mismatch' in log and 'RUNTIME ERROR:' in log
                continue
            assert 'RUNTIME ERROR:' not in log and '\nFAIL:' not in log
            observed = re.findall(r'^(TOTAL_[^:]+): passed=(\d+); failed=(\d+)', log, re.M)
            assert all(int(failed) == 0 for _, _, failed in observed)
            totals[key + '/' + phase] = {name: int(passed) for name, passed, _ in observed}
        projects[key] = record
    assert totals['Selection/ConstraintUnit'] == {'TOTAL_COUPLED_CONSTRAINT_TEST': 12,
        'TOTAL_COUPLED_HYBRID_TEST': 36, 'TOTAL_COUPLED_CONTROL_CONDITION_TEST': 17}
    assert sum(totals['Stopping/Core'].values()) == 382 and len(totals['Stopping/Core']) == 8
    assert totals['Stopping/Stock'] == {'TOTAL_COUPLED_WORKBOOK_TIMING': 28}
    compile_bytes = (root / 'FailedCompilation/Compile.log').read_bytes()
    compile_log = compile_bytes.decode('utf-16' if compile_bytes[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig')
    assert 'COMPILE_LOCATION: module=CCoupledControlCondition' in compile_log
    assert 'Dim scale As Double' in compile_log
    assert json.loads((root / 'FailedCompilation/CompileFailureClosure.json').read_text('utf-8-sig'))['State'] == 'Absent'
    stock = (root / 'Cases/Stopping/Native/Stock.txt').read_text('utf-8-sig')
    before, after, _ = re.findall(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=([A-F0-9]+); equal=True; file=(.+)$', stock, re.M)[0]
    assert before == after
    with ZipFile(root / 'Cases/Stopping/SavedWorkbookMarkup.zip') as bundle:
        assert bundle.testzip() is None and 'xl/workbook.xml' in bundle.namelist()
        assert all(Path(name).suffix.lower() in ('.xml', '.rels', '.vml') for name in bundle.namelist())
    output.write_text(json.dumps({'projects': projects, 'native_totals': totals, 'targeted_assertions': 475,
        'saved_reopened_results_hash': before, 'observer_and_compile_errors_preserved': True,
        'condition_selector_is_test_only': True, 'installed_workbook_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('ACTUAL VBA 475 TARGETED ASSERTIONS AND SAVED REOPENED RESULTS VERIFIED; CAPACITY OPEN')


def TestTiming(log):
    """Сохраняет фактические статусы и отсутствие предела независимо от времени расчёта."""
    seconds, = re.findall(r'^TIMING_SECONDS: (\S+) \| Both \| Excel$', log, re.M)
    direct, capacity, lower, limit, code = re.findall(r'^TIMING_STATES: direct=(\w+); capacity=(\w+); confirmed lower=([^;]+); limit=([^;]*); code=(\w+)$', log, re.M)[0]
    assert (direct, capacity, limit, code) == ('OK', 'NumFail', '', 'NUMERICAL_FAILURE')
    return dict(seconds=float(seconds), direct=direct, capacity=capacity, confirmed_lower_lambda=float(lower), physical_limit=None)


def TestMechanics(repo, root, output):
    """Отделяет неудачную линейную эвристику от проверенного изменения остановки и сохраняет штатный NumFail."""
    TestFiles(root)
    jobs = {'Coordinates': ('Analyze-TestMaterialCoordinates.py', (root / 'Cases/Coordinates',)),
        'Selection': ('Analyze-TestConditionedConstraint.py', (root / 'Cases/Selection', root / 'Cases/Coordinates')),
        'Stopping': ('Analyze-TestHybridConfigured.py', (root / 'Cases/Stopping', root / 'Reference/Adaptive'))}
    results = {}
    for key, (script, args) in jobs.items():
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Analysis.json'
            run_path(str(root / script))['TestAnalyze'](*args, proof)
            results[key] = json.loads(proof.read_bytes())
    old = TestTiming((root / 'Reference/Stock/Native/ActualReverse.txt').read_text('utf-8-sig'))
    new = TestTiming((root / 'Cases/Stopping/Native/Stock.txt').read_text('utf-8-sig'))
    assert abs(old['confirmed_lower_lambda']-new['confirmed_lower_lambda']) < 1e-8
    assert new['seconds'] < old['seconds'] and new['seconds'] > 10
    assert results['Stopping']['ordinary_bridge']['accepted_steps'] == 6
    assert results['Selection']['accepted_steps'] == 0
    results.update(stock_old=old, stock_current=new, stock_timing_is_one_run_per_variant=True,
        independent_material_reintegration=False, new_constraint_recovery_enabled_in_stock=False,
        installed_workbook_changed=False, physical_capacity_certified=False, full_acceptance_completed=False)
    output.write_text(json.dumps(results, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('ALL MATERIAL GRADIENTS NEGATIVE CONDITION SELECTION AND REQUESTED HYBRID STOPPING VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
