Attribute VB_Name = "modTestCoupledControlCondition"
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: аналитические оценки выбора координаты управления
' ==========================================================================
Private mPassedTest As Long, mFailedTest As Long

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет известные обратные матрицы, вырожденную координату и независимость от исходной строки управления и масштабов строк.
Public Sub RunTestCoupledControlCondition()
    mPassedTest = 0: mFailedTest = 0
    Dim matrix(1 To 3, 1 To 3) As Double, gradient(1 To 3) As Double, score As Double, alignment As Double
    Dim selector As New CCoupledControlCondition, i As Long
    For i = 1 To 3: matrix(i, i) = 1#: Next i
    TestAssert selector.TryInitialize(matrix, 3), "Единичная матрица подготовлена"
    gradient(3) = 1#
    TestAssert selector.TryRank(gradient, score, alignment), "Ортогональная координата доступна"
    TestAssert Abs(score - Sqr(3#)) < 0.000000000001, "Норма обратной единичной матрицы"
    TestAssert Abs(alignment - 1#) < 0.000000000001, "Косинус нулевого направления"
    gradient(1) = 3#: gradient(3) = 4#
    TestAssert selector.TryRank(gradient, score, alignment), "Наклонная координата доступна"
    TestAssert Abs(score - Sqr(4.125)) < 0.000000000001, "Аналитическая норма наклонной обратной матрицы"
    TestAssert Abs(alignment - 0.8) < 0.000000000001, "Аналитический косинус наклонной координаты"
    gradient(1) = 3000#: gradient(3) = 4000#
    TestAssert selector.TryRank(gradient, score, alignment) And Abs(score - Sqr(4.125)) < 0.000000000001, "Масштаб градиента не меняет оценку"
    matrix(1, 3) = 1#
    TestAssert selector.TryInitialize(matrix, 3), "Иная исходная строка подготовлена"
    TestAssert selector.TryRank(gradient, score, alignment) And Abs(score - Sqr(4.125)) < 0.000000000001, "Оценка не зависит от исходного управления"
    matrix(1, 3) = 0#: matrix(1, 1) = 5#: matrix(2, 2) = -7#: matrix(3, 3) = 100#
    TestAssert selector.TryInitialize(matrix, 3), "Разные масштабы и знак строк подготовлены"
    TestAssert selector.TryRank(gradient, score, alignment) And Abs(score - Sqr(4.125)) < 0.000000000001, "Масштабы и знак строк не меняют оценку"
    gradient(3) = 0#
    TestAssert Not selector.TryRank(gradient, score, alignment), "Координата внутри строки равновесия не устраняет вырождение"
    gradient(1) = 0#
    TestAssert Not selector.TryRank(gradient, score, alignment), "Нулевой градиент исключён"
    matrix(1, 1) = 1#: matrix(2, 1) = 1#: matrix(2, 2) = 1#: matrix(3, 3) = 1#
    gradient(3) = 1#
    TestAssert selector.TryInitialize(matrix, 3), "Несимметричная опора подготовлена"
    TestAssert selector.TryRank(gradient, score, alignment) And Abs(score - Sqr(5#)) < 0.000000000001, "Точная норма несимметричной обратной матрицы"
    matrix(3, 3) = 0#
    TestAssert Not selector.TryInitialize(matrix, 3), "Вырожденная линейная опора отклонена"
    Debug.Print "TOTAL_COUPLED_CONTROL_CONDITION_TEST: passed=" & CStr(mPassedTest) & "; failed=" & CStr(mFailedTest)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает независимые аналитические утверждения и выдаёт точную причину отказа.
Private Sub TestAssert(ByVal passed As Boolean, ByVal description As String)
    If passed Then
        mPassedTest = mPassedTest + 1
        Debug.Print "PASS: " & description
    Else
        mFailedTest = mFailedTest + 1
        Debug.Print "FAIL: " & description
    End If
End Sub
