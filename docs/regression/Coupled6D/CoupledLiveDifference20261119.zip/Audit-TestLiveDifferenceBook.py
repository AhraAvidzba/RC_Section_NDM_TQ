"""ДЛЯ ТЕСТОВ. Сверяет фактический VBA с 37 компонентами ядра, включая читающий наблюдатель разностных проб."""

from argparse import ArgumentParser
from pathlib import Path


def TestAudit(repo, root, output):
    """Расширяет явную область четырьмя интерфейсами/классами; правила точного сравнения VBE остаются неизменными."""
    source = Path(__file__).resolve().parent / 'Audit-TestPrivateCoupledBook.py'
    code = source.read_text('utf-8-sig')
    anchor = '        assert len(coupled) == 33'
    assert code.count(anchor) == 1
    code = code.replace(anchor, '''        assert len(coupled) == 37
        assert {'ICoupledScalarConstraint', 'CCoupledConstraintEquations', 'CCoupledMaterialConstraint', 'ICoupledDifferenceObserver'} <= set(coupled)''', 1)
    anchor = '        expected, observed = normalize(expected)[0], normalize(observed)[0]'
    assert code.count(anchor) == 1
    code = code.replace(anchor, '''        if name == 'modTestCoupledElasticState':
            pairs = (
                ('if verified and unchanged and forward and steel <= 1# and factor-currentfactor > bound + 8#*options(4)*(1#+abs(currentfactor)) then',
                 'if verified and unchanged and forward and steel <= 1# and factor - currentfactor > bound + 8# * options(4) * (1# + abs(currentfactor)) then'),
                ('if verified and unchanged and forward and steel <= 1# and factor-currentfactor > bound and factor-currentfactor > 8#*options(4)*(1#+abs(currentfactor)) then',
                 'if verified and unchanged and forward and steel <= 1# and factor - currentfactor > bound and factor - currentfactor > 8# * options(4) * (1# + abs(currentfactor)) then'))
            for compact, spaced in pairs:
                if compact in expected:
                    assert expected.count(compact) == 1 and observed.count(spaced) == 1
                    expected = expected.replace(compact, spaced, 1)
                    edits.append({'kind': 'one_exact_live_admission_operator_spacing', 'runtime_values_unchanged': True})
''' + anchor, 1)
    namespace = {'__name__': 'live_difference_book_audit', '__file__': str(source)}
    exec(compile(code, str(source), 'exec'), namespace)
    namespace['TestAudit'](repo, root, output)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAudit(args.repo.resolve(), args.root.resolve(), args.out.resolve())
