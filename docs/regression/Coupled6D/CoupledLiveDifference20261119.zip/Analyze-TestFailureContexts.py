"""ДЛЯ ТЕСТОВ: повторяет точечные контексты отказа и соседние пробы касательной независимо от VBA."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np

def TestPlastic(strain,effective):
    """Вычисляет инженерную пластическую деформацию из изотропной упругой части."""
    result=strain.copy(); volume=.2*np.sum(effective[...,:3],axis=-1,keepdims=True)
    result[...,:3]-=(1.2*effective[...,:3]-volume)/30000.
    result[...,3:]-=effective[...,3:]/12500.
    return result

def TestRun(repo,root,output):
    """Проверяет существование напряжений по обе стороны без ослабления материального допуска."""
    here=Path(__file__).resolve().parent
    section=run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    step=run_path(str(here/'TestClosedASDTangent.py'))['TestConcrete']
    records=[]
    for line in (root/'Native/ControlProbe.txt').read_text('utf-8-sig').splitlines():
        row=line.split(';')
        if row[0]!='MATERIAL_CONTEXT': continue
        assert len(row)==28
        strain=np.array(list(map(float,row[10:16]))).reshape(1,1,6)
        prior=np.array(list(map(float,row[16:22]))).reshape(1,1,6)
        effective=np.array(list(map(float,row[22:28]))).reshape(1,1,6)
        coordinates=np.array(list(map(float,row[8:10]))).reshape(2,1,1)
        history=(prior,effective,coordinates)
        stress,current,_,iterations=step(section,strain,history,maximum_iterations=1024)
        initial_plastic=TestPlastic(prior,effective)
        plastic_change=float(np.max(np.abs(TestPlastic(strain,current[1])-initial_plastic)))
        record={'phase':row[1],'side':int(row[2]),'point':int(row[3]),'stage':row[4],'component':int(row[6]),
                'base_repeats':iterations,'base_plastic_increment':plastic_change,
                'base_coordinate_change':(current[2]-coordinates).ravel().tolist(),'neighbours':[]}
        component=int(row[6])-1
        delta=2e-9*(1.+abs(float(strain[...,component].item())))
        if int(row[5])==4: delta/=64.
        for attempt in range(3):
            for sign in (1.,-1.):
                target=strain.copy(); target[...,component]+=sign*delta
                try:
                    observed=step(section,target,history,maximum_iterations=1024)
                    change=float(np.max(np.abs(TestPlastic(target,observed[1][1])-initial_plastic)))
                    record['neighbours'].append({'attempt':attempt,'sign':sign,'closed':True,'repeats':observed[3],
                        'plastic_increment':change,'coordinate_change':(observed[1][2]-coordinates).ravel().tolist(),
                        'stress_difference_MPa':float(np.max(np.abs(observed[0]-stress)))})
                except ArithmeticError as error:
                    record['neighbours'].append({'attempt':attempt,'sign':sign,'closed':False,'reason':str(error)})
            delta*=.25
        records.append(record)
    output.write_bytes((json.dumps(records,indent=2,sort_keys=True)+'\n').encode())
    print('POINT FAILURE CONTEXTS REPLAYED',len(records),flush=True)
    for record in records:
        print(record['phase'],record['point'],'plastic',record['base_plastic_increment'],'coordinates',record['base_coordinate_change'],
              'closed',sum(row['closed'] for row in record['neighbours']),flush=True)

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True); args=parser.parse_args(); TestRun(args.repo.resolve(),args.root.resolve(),args.out.resolve())
