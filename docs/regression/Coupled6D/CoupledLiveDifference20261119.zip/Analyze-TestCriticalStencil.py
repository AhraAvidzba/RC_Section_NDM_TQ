"""ДЛЯ ТЕСТОВ. Проверяет выбор разностного пересечения, уровень из прогноза и полное принятие равновесия."""

from argparse import ArgumentParser
import csv
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestBackward(matrix, vector, target):
    """Проверяет покомпонентную обратную ошибку независимо от большой обусловленности физических координат."""
    residual = np.abs(matrix @ vector-target)
    scale = np.abs(matrix) @ np.abs(vector) + np.abs(target)
    bound = 64*len(vector)*np.finfo(float).eps*scale
    assert np.all(residual <= bound + np.finfo(float).tiny)
    return float(np.max(np.divide(residual, scale, out=np.zeros_like(scale), where=scale>0)))


def TestAnalyze(root, coordinates, output):
    """Независимо проверяет наблюдённый переход и принятие; несошедшийся вариант также сохраняется явно."""
    here = Path(__file__).resolve().parent
    sequence = run_path(str(here / 'Analyze-TestYieldSequence.py'))['TestAnalyze']
    sequence(root, output)
    result = json.loads(output.read_bytes())
    rows = list(csv.reader((root / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    prep = json.loads((root / 'Preparation.json').read_bytes())
    source = run_path(str(here / 'Analyze-TestNewtonLine.py'))['TestRead'](root / 'Input/SourceFailedMatrix.bin')
    assert source['sha256'] == prep['inputs']['Input/SourceFailedMatrix.bin']
    asymmetric = (source['plus']+source['minus']-2*source['residual'][:, None])/source['sizes']
    row_norms = np.linalg.norm(source['jacobian'], axis=1)
    assert np.all(row_norms > 0)
    scores = np.linalg.norm(asymmetric/row_norms[:, None], axis=0)
    column = int(np.argmax(scores))
    assert column+1 == prep['directed_scope']['selected_FD_column_1_based']
    raw = (root / 'Input/CriticalStencil.bin').read_bytes()
    assert len(raw) == 2*(4+61*8)
    probes = []
    for index, sign in enumerate((-1, 1)):
        offset = index*(4+61*8)
        assert struct.unpack_from('<i', raw, offset)[0] == 61
        observed = np.frombuffer(raw, '<f8', count=61, offset=offset+4)
        x = source['x'].copy(); x[column] += sign*source['sizes'][column]
        expected = np.r_[source['seed']+source['scales'][:60]*x[:60], source['seed_factor']+source['scales'][60]*x[60]]
        np.testing.assert_array_equal(observed, expected)
        probes.append(observed)
    chosen, = [row for row in rows if row[:2] == ['AUTO_EVENT', 'CriticalStencil']]
    assert chosen[2] == 'True'
    event = run_path(str(here / 'Analyze-TestNewtonLine.py'))['TestYieldEventFunction'](root, rows, 0)
    observed_values = [float(chosen[6]), float(chosen[7])]
    for probe, expected in zip(probes, observed_values):
        assert abs(event(probe[:60])-expected) < 1e-9
    assert observed_values[0]*observed_values[1] < 0
    raw = (root / 'Native/NewtonLine.Level0.bin').read_bytes()
    version = raw[:16]
    assert version in (b'NDMLEVELTEST0001', b'NDMLEVELTEST0002')
    size, point, side, principal = struct.unpack_from('<4i', raw, 16)
    assert size == 61 and [point, side, principal] == list(map(int, chosen[3:6]))
    count = 13 if version.endswith(b'1') else 16
    assert len(raw) == 32+8*(count+size*size+2*size)
    data = np.frombuffer(raw, '<f8', count=count, offset=32)
    offset = 32+8*count
    matrix = np.frombuffer(raw, '<f8', count=size*size, offset=offset).reshape(size, size)
    weights = np.frombuffer(raw, '<f8', count=size, offset=offset+8*size*size)
    direction = np.frombuffer(raw, '<f8', count=size, offset=offset+8*(size*size+size))
    target = np.eye(size)[-1]
    null_error = TestBackward(matrix, direction, target)
    adjoint_error = TestBackward(matrix.T, weights, target)
    assert data[4] == direction[-1]
    uncertainty = np.sum(np.abs(weights))*data[5]+2e-12*(1+abs(data[0]))
    assert abs(uncertainty-data[6]) < 1e-12*max(1e-30, uncertainty)
    assert abs(data[7]-8*data[11]*(1+abs(data[0]))) < 1e-18
    assert abs(data[8]-max(8*data[7], 2*data[6])) < 1e-18
    reference = run_path(str(here / 'Analyze-TestMaterialCoordinates.py'))['TestRead'](coordinates / 'Native/MaterialCoordinates1.bin')
    selected = next(item for item in reference['surfaces'] if (item['point'], item['side']) == (point, side))
    assert data[2] == selected['value'] and data[3] == selected['accepted_value']
    expected_gradient = selected['gradient']/reference['scales']
    np.testing.assert_allclose(matrix[-1], expected_gradient, rtol=1e-11, atol=1e-14)
    if count == 13:
        assert data[9] == data[2]
    else:
        _, _, _, _, _, axes, _, _ = run_path(str(here / 'Check-TestHardHalfSteps.py'))['TestOperators'](root / 'Native/NewtonLine.Operators.csv', 60, 43)
        concrete_count = int(np.sum(np.all(axes == 0, axis=1)))
        assert np.all(axes[:concrete_count] == 0) and np.all(np.any(axes[concrete_count:] != 0, axis=1))
        sign = np.sign(data[2]-data[3])
        maximum = max((sign*(item['value']-item['accepted_value']), item['point'], item['side'])
                      for item in reference['surfaces'] if item['point'] <= concrete_count)
        assert data[13] == maximum[0] and list(map(int, data[14:16])) == list(maximum[1:])
        assert data[9] == data[3]+sign*data[13]
    level, = [row for row in rows if row[0] == 'EVENT_TARGET']
    assert float(level[2]) == float([row for row in rows if row[0] == 'LEVEL_DETAILS'][0][-1])
    assert abs(float(level[2])-data[9]) <= 1e-17
    bound, = [row for row in rows if row[0] == 'SCALAR_UNCERTAINTY']
    accepted = result['accepted_steps'] == 1
    if accepted:
        assert bound[2] == 'True' and bound[-1] == 'True'
        assert float(bound[4]) > float(bound[3]) and float(bound[4]) > data[7]
        assert result['cases']['0']['configured_residual_criterion_met']
    else:
        assert bound[-1] == 'False'
    result.update(critical_FD_column=column+1, source_matrix_sha256=source['sha256'],
        selected_point=point, selected_side=side, selected_principal=principal,
        source_probe_yield_values_MPa=observed_values,
        target_MPa=float(data[9]), predicted_critical_yield_MPa=float(data[2]),
        predicted_lambda_sensitivity_per_MPa=float(data[4]),
        seed_linear_sensitivity_is_not_equilibrated_branch_sensitivity=True,
        diagnostic_linear_uncertainty=float(data[6]), diagnostic_load_resolution=float(data[7]),
        diagnostic_null_backward_error=null_error, diagnostic_adjoint_backward_error=adjoint_error,
        actual_scalar_bound_ready=bound[2] == 'True', actual_scalar_lambda_uncertainty=float(bound[3]),
        actual_lambda_gain=float(bound[4]), actual_progress_resolved=bound[-1] == 'True',
        maximum_predicted_loading_step_used=count == 16,
        selected_point_and_target_not_hardcoded=True,
        installed_workbook_changed=False, physical_capacity_certified=False)
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('OBSERVED CRITICAL STENCIL MATERIAL STEP AND ALL ACCEPTED EQUATIONS VERIFIED', result['accepted_steps'], 'CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--coordinates', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.coordinates.resolve(), args.out.resolve())
