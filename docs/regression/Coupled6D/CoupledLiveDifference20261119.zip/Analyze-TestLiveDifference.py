"""ДЛЯ ТЕСТОВ. Независимо проверяет живой выбор материального перехода, исходный префикс и шесть сил принятого поля."""

from argparse import ArgumentParser
from hashlib import sha256
import csv
import json
from pathlib import Path
import re
from runpy import run_path
import numpy as np


def TestAnalyze(root, coordinates, output):
    """Отделяет принятый шаг от численной неудачи; сохранённые напряжения используются без внешней реинтеграции материала."""
    here = Path(__file__).resolve().parent
    read = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    source = read(root / 'Input/Reverse1.bin')
    prep = json.loads((root / 'Preparation.json').read_bytes())
    assert source['sha256'] == prep['inputs']['Input/Reverse1.bin']
    rows = list(csv.reader((root / 'Native/LiveDifference.csv').read_text('cp1251').splitlines(), delimiter=';'))
    result, = [row for row in rows if row[0] == 'RESULT']
    details, = [row for row in rows if row[0] == 'DETAILS']
    live_code = (root / 'tests/modTestCoupledElasticState.bas').read_text('utf-8-sig')
    body, = re.findall(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', live_code)
    assert 'solver.TryDeformationStep(' in body and 'referenceLambda:=currentFactor' in body
    assert all(item not in body for item in ('BeginNewtonLineTest', 'CreateMaterialConstraint', 'ReadCriticalLevelTest', 'SourceFailedMatrix'))
    evidence = dict(solved=result[1] == 'True', seconds=float(result[2]), iterations=int(result[4]),
        function_evaluations=int(result[5]), hybrid_steps=int(result[6]), hybrid_matrices=int(result[7]),
        hybrid_function_evaluations=int(result[8]), native_residual_MPa=float(result[-1]),
        no_external_material_coordinate_supplied=True, details=';'.join(details[1:]),
        independent_material_reintegration=False, physical_capacity_certified=False, installed_workbook_changed=False)
    assert evidence['iterations'] <= source['options'][2]
    if not evidence['solved']:
        assert any(row == ['STOP', 'NumericalRecoveryNotFound', 'NotPhysicalFailure'] for row in rows)
        assert not any(row[0] == 'ACCEPTED' for row in rows)
        output.write_text(json.dumps(evidence, indent=2, ensure_ascii=False, sort_keys=True)+'\n', encoding='utf-8')
        print('LIVE RECOVERY FAILURE PRESERVED; NO STATE OR PHYSICAL LIMIT ACCEPTED')
        return
    recovered, = [row for row in rows if row[0] == 'RECOVERED']
    native, = [row for row in rows if row[0] == 'NATIVE']
    final, = [row for row in rows if row[0] == 'FINAL']
    accepted, = [row for row in rows if row[0] == 'ACCEPTED']
    assert recovered[1] == 'True' and native[1:4] == ['True', 'True', 'True'] and float(native[4]) <= 1
    factor, bound, gain = float(final[1]), float(recovered[2]), float(recovered[3])
    resolution = 8*source['options'][4]*(1+abs(source['lambdas'][-1]))
    assert bound > 0 and gain > bound+resolution and abs(factor-float(accepted[1])) < 1e-14
    assert abs(gain-(factor-source['lambdas'][-1])) < 2e-14
    validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
    proof, fields = validate(root, 'LiveDifference.Reverse20')
    count = len(source['fields'])
    assert len(fields) == count+1 and not proof['reversed_fields']
    np.testing.assert_allclose(fields[:count], source['fields'], rtol=1e-14, atol=1e-300)
    np.testing.assert_array_equal(fields[-1], np.array(final[2:], float))
    assert abs(proof['states'][-1]['lambda']-factor) < 1e-14
    observed = list(csv.reader((root / 'Native/LiveDifference.Brackets.csv').read_text('cp1251').splitlines(), delimiter=';'))
    assert observed and all(row[0] == 'OBSERVED' and row[6] == 'True' for row in observed)
    last = observed[-1]
    matrix, steps, calls, column = map(int, last[1:5])
    point, side, principal = map(int, last[7:10])
    assert float(last[10])*float(last[11]) < 0 and principal == 0
    selected, = re.findall(r'переходу; точка: (\d+); станция: (-?\d+); материальная координата, МПа: ([^ |]+)', evidence['details'])
    assert [point, side] == list(map(int, selected[:2]))
    level = float(selected[2].replace(',', '.'))
    reference = run_path(str(here / 'Analyze-TestMaterialCoordinates.py'))['TestRead'](coordinates / 'Native/MaterialCoordinates1.bin')
    current = next(item for item in reference['surfaces'] if (item['point'], item['side']) == (point, side))
    operators = run_path(str(here / 'Check-TestHardHalfSteps.py'))['TestOperators']
    _, _, _, _, _, axes, _, _ = operators(root / 'Native/LiveDifference.Operators.csv', 60, 43)
    concrete_count = int(np.sum(np.all(axes == 0, axis=1)))
    sign = np.sign(current['value']-current['accepted_value'])
    maximum = max(sign*(item['value']-item['accepted_value']) for item in reference['surfaces'] if item['point'] <= concrete_count)
    assert abs(level-(current['accepted_value']+sign*maximum)) < 1e-17
    evidence.update(lambda_value=factor, lambda_gain=gain, actual_lambda_uncertainty=bound, load_resolution=resolution,
        gain_exceeds_uncertainty_plus_resolution=True, accepted_steps=1, original_prefix_states=count,
        independent_equilibrium=proof, actual_material_point=point, actual_material_side=side, actual_material_principal=principal,
        actual_FD_column=column, actual_FD_matrix=matrix, observed_crossings=len(observed),
        maximum_predicted_loading_MPa=float(maximum), material_level_MPa=level,
        source_coordinates_sha256=reference['sha256'], source_binary_sha256=sha256((root / 'Input/Reverse1.bin').read_bytes()).hexdigest().upper())
    output.write_text(json.dumps(evidence, indent=2, ensure_ascii=False, sort_keys=True)+'\n', encoding='utf-8')
    print('LIVE MATERIAL RECOVERY AND ALL', count+1, 'STATES INDEPENDENTLY VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--coordinates', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.coordinates.resolve(), args.out.resolve())
