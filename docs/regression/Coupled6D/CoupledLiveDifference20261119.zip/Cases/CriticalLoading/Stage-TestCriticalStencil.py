"""ДЛЯ ТЕСТОВ. Выбирает материальный переход из реально наблюдённой асимметрии полной разностной матрицы."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import struct
from zipfile import ZipFile
import numpy as np


def TestStage(repo, root, source):
    """Источник отклонённой матрицы проверен по архиву; номер точки и уровень управления не задаются постоянными."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestAutomaticConstraint.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    archive_name = 'CoupledNewtonBranchStudies20261119'
    manifest = json.loads((repo / 'docs/reports/Coupled6DEvidence.json').read_bytes())
    archive = repo / 'docs/regression/Coupled6D' / (archive_name + '.zip')
    assert sha256(archive.read_bytes()).hexdigest().upper() == manifest['archives'][archive_name]
    member = 'Cases/Newton/Native/NewtonLine.C0I10.bin'
    with ZipFile(archive) as bundle:
        raw = bundle.read(member)
        assert sha256(raw).hexdigest().upper() == json.loads(bundle.read('Files.json'))[member]
    name = 'Input/SourceFailedMatrix.bin'
    (root / name).write_bytes(raw)
    prep['inputs'][name] = sha256(raw).hexdigest().upper()
    data = run_path(str(here / 'Analyze-TestNewtonLine.py'))['TestRead'](root / name)
    asymmetry = (data['plus'] + data['minus'] - 2*data['residual'][:, None]) / data['sizes']
    row_norm = np.linalg.norm(data['jacobian'], axis=1)
    assert np.all(row_norm > 0)
    scores = np.linalg.norm(asymmetry / row_norm[:, None], axis=0)
    column = int(np.argmax(scores))
    samples = []
    for sign in (-1, 1):
        x = data['x'].copy(); x[column] += sign*data['sizes'][column]
        field = data['seed'] + data['scales'][:60]*x[:60]
        factor = data['seed_factor'] + data['scales'][60]*x[60]
        samples.extend([*field, factor])
    name = 'Input/CriticalStencil.bin'
    (root / name).write_bytes(struct.pack('<i61di61d', 61, *samples[:61], 61, *samples[61:]))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig') + '\n' + (here / 'TestNativeCriticalCoordinate.cls.txt').read_text('utf-8-sig')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    block, = re.findall(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', code)
    old = '    Dim acceptedCountTest As Long'
    assert block.count(old) == 1
    body = block.replace(old, '''    Dim stencilHandleTest As Integer: stencilHandleTest = FreeFile
    Open mPolishRootTest & "\\Input\\CriticalStencil.bin" For Binary Access Read As #stencilHandleTest
    Dim stencilFirstTest As Variant, stencilLastTest As Variant, stencilBeforeTest() As Double, stencilAfterTest() As Double
    stencilFirstTest = TestReadPolishVector(stencilHandleTest): stencilLastTest = TestReadPolishVector(stencilHandleTest)
    If UBound(stencilFirstTest) <> 61 Or UBound(stencilLastTest) <> 61 Or Seek(stencilHandleTest) <> LOF(stencilHandleTest) + 1 Then _
        Err.Raise 5, , "Неверные поля наблюдённого разностного пересечения."
    Close #stencilHandleTest
    ReDim stencilBeforeTest(1 To 61): ReDim stencilAfterTest(1 To 61)
    For degree = 1 To 61: stencilBeforeTest(degree) = stencilFirstTest(degree): stencilAfterTest(degree) = stencilLastTest(degree): Next degree
''' + old, 1)
    body = body.replace('        target = 0.001', '        target = coordinate + 0.5 * spacing', 1)
    old = 'solver.ReadDominantYieldCrossingTest(accepted, seed, currentFactor, seedFactor)'
    assert body.count(old) == 1
    body = body.replace(old, 'solver.ReadCriticalStencilTest(stencilBeforeTest, stencilAfterTest)', 1)
    body = body.replace('AUTO_EVENT;DominantSecant;', 'AUTO_EVENT;CriticalStencil;', 1)
    old = '        target = CDbl(eventTest(5))'
    assert body.count(old) == 1
    body = body.replace(old, '''        Dim levelTest As Variant
        levelTest = solver.ReadCriticalLevelTest(mEventPointTest, mEventSideTest, 0, accepted, seed, currentFactor, seedFactor, _
            mReverseOptionsTest(3), mReverseOptionsTest(4), mHardPreparedPathTest & ".Level0.bin")
        target = CDbl(levelTest(6))
        Print #handle, "LEVEL_DETAILS;" & CStr(probeCase) & TestHardPreparedVector(levelTest)''', 1)
    old = '        Print #handle, "NATIVE;"'
    assert body.count(old) == 1
    body = body.replace(old, '''        Dim resolvedTest As Boolean, boundTest As Double, boundReadyTest As Boolean
        If verified And unchanged And forward Then
            boundReadyTest = solver.ReadCriticalTrialBoundTest(mEventPointTest, mEventSideTest, 0, factor, _
                mReverseOptionsTest(3), mReverseOptionsTest(4), boundTest)
            resolvedTest = boundReadyTest And factor - currentFactor > boundTest And _
                factor - currentFactor > 8# * mReverseOptionsTest(4) * (1# + Abs(currentFactor))
        End If
        Print #handle, "SCALAR_UNCERTAINTY;" & CStr(probeCase) & ";" & CStr(boundReadyTest) & ";" & TestOnsetNumber(boundTest) & ";" & _
            TestOnsetNumber(factor - currentFactor) & ";" & CStr(resolvedTest)
''' + old, 1)
    old = 'If solved And verified And unchanged And forward And steelUse <= 1# Then'
    assert body.count(old) == 1
    body = body.replace(old, 'If solved And verified And unchanged And forward And steelUse <= 1# And resolvedTest Then', 1)
    code = code.replace(block, body, 1)
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for filename in (Path(__file__).name, 'TestNativeCriticalCoordinate.cls.txt'):
        (root / filename).write_bytes((here / filename).read_bytes())
        prep['inputs'][filename] = sha256((here / filename).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'CriticalStencilAndResolvedMaterialLevel',
        'source_archive': archive_name, 'source_archive_sha256': manifest['archives'][archive_name],
        'source_matrix_member': member, 'selected_FD_column_1_based': column+1,
        'asymmetry_column_scores': scores.tolist(),
        'event_location_from_actual_FD_crossing': True,
        'target_from_load_resolution_and_linear_precision': False,
        'target_from_original_secant_material_coordinate': False,
        'target_from_maximum_predicted_concrete_loading_in_selected_direction': True,
        'nonequilibrium_linear_precision_is_diagnostic_only': True,
        'candidate_scalar_lambda_uncertainty_gate_required': True,
        'point_or_MPa_target_not_hardcoded': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('CRITICAL STENCIL AND RESOLVED LEVEL READY COLUMN', column+1)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
