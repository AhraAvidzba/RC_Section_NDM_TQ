"""Строит чистый исходник варианта §525 без диагностических счётчиков."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path

from Stage import BOOK_SHA, REPO, SOLVER, STOCK_SHA, source


HERE = Path(__file__).resolve().parent
CANDIDATE = '27099C1E3F2CB0514C18AD3804039D784B91015D83366A200ADC49BACEE923B8'


def digest(content):
    return sha256(content).hexdigest().upper()


def replace_once(text, original, replacement):
    assert text.count(original) == 1, original
    return text.replace(original, replacement)


def clean(raw):
    assert digest(raw) == STOCK_SHA
    tested = source(raw)
    assert digest(tested) == CANDIDATE
    text = tested.decode('utf-8').replace('\r\n', '\n')
    stock = raw.decode('utf-8-sig').replace('\r\n', '\n')
    diagnostics = (
        'Private mBeyondDoubleTest As Long, mFinalPostPeakLambdaTest As Double\n',
        '    mBeyondDoubleTest = 0: mFinalPostPeakLambdaTest = 0#\n',
        '                If increment > POST_PEAK_STEP_RATIO * nominal Then mBeyondDoubleTest = mBeyondDoubleTest + 1\n',
        '                mFinalPostPeakLambdaTest = trial.Lambda\n',
        '    If mPostPeakControlPoints > 0 Then Details = Details & _\n'
        '        "; GrowthTestAcceptedBeyondDouble=" & CStr(mBeyondDoubleTest) & _\n'
        '        "; GrowthTestFinalLambda=" & CStr(mFinalPostPeakLambdaTest)\n',
    )
    for diagnostic in diagnostics:
        text = replace_once(text, diagnostic, '')
    tested_constant = "Private Const POST_PEAK_TEST_RATIO As Double = 4# ' Пробный предел после шести гладких шагов сменившейся меры.\n"
    tested_gate = '            If smoothSteps >= 6 Then stepCeiling = POST_PEAK_TEST_RATIO * nominal\n'
    assert replace_once(replace_once(text, tested_constant, ''), tested_gate, '') == stock
    text = replace_once(text, tested_constant,
                        'Private Const POST_PEAK_EXTENDED_RATIO As Double = 4# ' +
                        "' Верхний шаг после шести гладких приращений подряд.\n")
    text = replace_once(text, tested_gate,
                        tested_gate.replace('POST_PEAK_TEST_RATIO', 'POST_PEAK_EXTENDED_RATIO'))
    text.encode('cp1251')
    return text.replace('\n', '\r\n').encode('utf-8')


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--stage-source', action='store_true')
    args = cli.parse_args()
    assert digest((REPO / 'workbook/output/RC_Section_NDM.xlsm').read_bytes()) == BOOK_SHA
    generated = clean((REPO / SOLVER).read_bytes())
    if args.stage_source:
        target = HERE / 'clean' / SOLVER
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == generated, target
        else:
            target.write_bytes(generated)
    print('CLEAN GROWTH SOURCE', digest(generated))


if __name__ == '__main__':
    main()
