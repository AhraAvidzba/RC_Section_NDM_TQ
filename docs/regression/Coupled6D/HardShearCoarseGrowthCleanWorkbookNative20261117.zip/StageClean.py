"""Готовит чистую книгу-кандидат для повтора кривой §525 в Excel."""

from argparse import ArgumentParser
from json import dumps, loads
from pathlib import Path

from CleanGrowthSource import clean, digest, replace_once
from Stage import BOOK, BOOK_SHA, REPO, SOLVER, STORAGE


HERE = Path(__file__).resolve().parent
PRIOR = STORAGE / 'HardGrowthAB1'
TARGET = STORAGE / 'HardGrowthClean1'
PRIOR_RECEIPT = '976DB81C6B049808D2D19C57322E5353A2C2D745C7E3C8E89697BDF278BF7365'


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--stage', action='store_true')
    args = cli.parse_args()
    assert TARGET.resolve().parent == STORAGE.resolve()
    manifest = loads((PRIOR / 'ABManifest.json').read_bytes())
    files = {name: (PRIOR / name).read_bytes() for name in manifest['inputs'] if name != BOOK}
    assert all(digest(raw) == manifest['inputs'][name] for name, raw in files.items())
    receipt = (PRIOR / 'ABVerification.json').read_bytes()
    assert digest(receipt) == PRIOR_RECEIPT
    draft = loads(receipt)
    assert draft['continuation']['accepted_beyond_double'] == 48
    files[SOLVER] = clean((REPO / SOLVER).read_bytes())
    candidate = digest(files[SOLVER])
    files['PreviousB.json'] = receipt
    files['ReadWorkbookCurve.py'] = (HERE / 'ReadWorkbookCurve.py').read_bytes()
    files['StageClean.py'] = Path(__file__).read_bytes()
    run = files['Run-FullAB.ps1'].decode('utf-8').replace(PRIOR.name, TARGET.name)
    files['Run-FullAB.ps1'] = run.encode('utf-8')
    verify = files['Verify-FullAB.py'].decode('utf-8')
    verify = replace_once(verify, manifest['inputs'][SOLVER], candidate)
    old_parser = (HERE / 'ReadGrowth.py.inc').read_text(encoding='utf-8')
    parser = (HERE / 'CompareClean.py.inc').read_text(encoding='utf-8')
    verify = replace_once(verify, old_parser, parser)
    files['Verify-FullAB.py'] = verify.encode('utf-8')
    manifest['inputs'] = {name: digest(raw) for name, raw in files.items()} | {BOOK: BOOK_SHA}
    files['ABManifest.json'] = (dumps(manifest, indent=2) + '\n').encode('utf-8')
    print('CLEAN GROWTH WORKBOOK INPUTS', TARGET, candidate, digest(files['ABManifest.json']))
    if not args.stage:
        return
    original = (REPO / BOOK).read_bytes()
    assert digest(original) == BOOK_SHA
    TARGET.mkdir()
    for directory in ('Temp', 'Native/B', 'tests'):
        (TARGET / directory).mkdir(parents=True)
    files |= {BOOK: original, manifest['draft']: original}
    for name, contents in files.items():
        path = TARGET / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(contents)


if __name__ == '__main__':
    main()
