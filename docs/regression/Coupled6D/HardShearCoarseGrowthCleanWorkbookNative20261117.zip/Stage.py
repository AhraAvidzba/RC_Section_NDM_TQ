"""Готовит изолированную проверку большего шага на гладком спаде HardShear."""

from argparse import ArgumentParser
from hashlib import sha256
from json import dumps, loads
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
STORAGE = Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve()
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
SOLVER = 'src/Solver/CCoupledDeformationContinuation.cls'
STOCK_SHA = '5154E5B80EF6D3CB16E592F533185FDC3816AA228AA64C14BBC11CA1EB2408FB'
BASELINE = 'HardShearInstalledStockTiming20261117.zip'
RUNNER = REPO / 'tmp/hs-p31-generic'
MODULE = Path(SOLVER).stem


def digest(raw):
    return sha256(raw).hexdigest().upper()


def edit(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


def source(raw):
    assert digest(raw) == STOCK_SHA
    text = raw.decode('utf-8-sig').replace('\r\n', '\n')
    constants = 'Private Const POST_PEAK_SECANT_TOLERANCE As Double ='
    text = edit(text, constants, 'Private Const POST_PEAK_TEST_RATIO As Double = 4# ' +
                "' Пробный предел после шести гладких шагов сменившейся меры.\n" + constants)
    text = edit(text, 'Private mPostPeakWidePoints As Long\n',
                'Private mPostPeakWidePoints As Long\nPrivate mBeyondDoubleTest As Long, mFinalPostPeakLambdaTest As Double\n')
    text = edit(text, '    mPostPeakWidePoints = 0\n',
                '    mPostPeakWidePoints = 0\n    mBeyondDoubleTest = 0: mFinalPostPeakLambdaTest = 0#\n')
    step = '                If increment > nominal Then mPostPeakWidePoints = mPostPeakWidePoints + 1\n'
    text = edit(text, step, step + '                If increment > POST_PEAK_STEP_RATIO * nominal Then mBeyondDoubleTest = mBeyondDoubleTest + 1\n' +
                '                mFinalPostPeakLambdaTest = trial.Lambda\n')
    step = '            If smoothSteps >= 2 Then stepCeiling = POST_PEAK_STEP_RATIO * nominal\n'
    text = edit(text, step, step + '            If smoothSteps >= 6 Then stepCeiling = POST_PEAK_TEST_RATIO * nominal\n')
    detail = '    If mPostPeakWidePoints > 0 Then Details = Details & "; принято увеличенных шагов: " & CStr(mPostPeakWidePoints)\n'
    text = edit(text, detail, detail + '    If mPostPeakControlPoints > 0 Then Details = Details & _\n' +
                '        "; GrowthTestAcceptedBeyondDouble=" & CStr(mBeyondDoubleTest) & _\n' +
                '        "; GrowthTestFinalLambda=" & CStr(mFinalPostPeakLambdaTest)\n')
    text.encode('cp1251')
    return text.replace('\n', '\r\n').encode('utf-8')


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--stage', action='store_true')
    args = cli.parse_args()
    dest = (STORAGE / 'HardGrowthAB1').resolve()
    assert dest.parent == STORAGE
    prior_files = ('StockProof.json', 'Native/Both.txt', 'Native/Both.Execution.txt',
                   'Native/Both.txt.Ownership.json', 'Native/Both.txt.ProcessClosure.json')
    archive_file = REPO / 'docs/regression/Coupled6D' / BASELINE
    index = loads((REPO / 'docs/reports/Coupled6DEvidence.json').read_bytes())
    assert digest(archive_file.read_bytes()) == index['archives'][Path(BASELINE).stem]
    with ZipFile(archive_file) as archive:
        fixture = archive.read('Fixture.json')
        prior = loads(fixture)
        files = {name: archive.read(name) for name in prior['inputs'] if name != BOOK}
        assert all(digest(raw) == prior['inputs'][name] for name, raw in files.items())
        files |= {'Fixture.json': fixture, 'Verify-Stock.py': archive.read('Verify-Stock.py')}
        files |= {'StockPrior/' + name: archive.read(name) for name in prior_files}

    files[SOLVER] = source((REPO / SOLVER).read_bytes())
    candidate = digest(files[SOLVER])
    files['Stage.py'] = Path(__file__).read_bytes()
    run = (RUNNER / 'Run-FullAB.ps1').read_text(encoding='utf-8')
    run = run.replace('HardBranchGenericAB1', dest.name).replace('HardBranchGenericAB', 'HardGrowthAB')
    run = edit(run, '-ModuleNames CCoupledNewtonSolver', '-ModuleNames ' + MODULE)
    files['Run-FullAB.ps1'] = run.encode('utf-8')
    verify = (RUNNER / 'Verify-FullAB.py').read_text(encoding='utf-8')
    verify = edit(verify, 'src/Solver/CCoupledNewtonSolver.cls', SOLVER)
    verify = edit(verify, '["CCoupledNewtonSolver"]', '["' + MODULE + '"]')
    verify = edit(verify, '375F826A3ECD152807593B0A6B7A688F5FB82C7A5DE7DAD458A66F61AFC276FD', candidate)
    verify = edit(verify, '    out = HERE / "ABVerification.json"\n', (HERE / 'ReadGrowth.py.inc').read_text(encoding='utf-8') +
                  '    out = HERE / "ABVerification.json"\n')
    files['Verify-FullAB.py'] = verify.encode('utf-8')
    draft = 'docs/regression/Diagnostic.xlsm'
    standard = (REPO / BOOK).read_bytes()
    assert prior['book_sha256'] == digest(standard) == BOOK_SHA
    sealed_inputs = {name: digest(raw) for name, raw in files.items()} | {BOOK: BOOK_SHA}
    plan = {'book_sha256': BOOK_SHA, 'draft': draft, 'modules': [MODULE], 'inputs': sealed_inputs}
    files['ABManifest.json'] = (dumps(plan, indent=2) + '\n').encode('utf-8')
    print('GROWTH INPUTS', dest, candidate, digest(files['ABManifest.json']))
    if not args.stage:
        return
    dest.mkdir()
    for directory in ('Temp', 'Native/B', 'tests'):
        (dest / directory).mkdir(parents=True)
    files |= {BOOK: standard, draft: standard}
    for name, raw in files.items():
        target = dest / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as output:
            output.write(raw)


if __name__ == '__main__':
    main()
