"""Verify the clean workbook and the exact accepted curve from the growth experiment."""
from argparse import ArgumentParser
from hashlib import sha256
from json import loads
from pathlib import Path, PureWindowsPath
import re
from runpy import run_path
from sys import path as python_path
from zipfile import Path as ZipPath, ZipFile

HERE = Path(__file__).resolve().parent
MODULE = "CCoupledDeformationContinuation"
SOURCE = f"src/Solver/{MODULE}.cls"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
STOCK_SOURCE_SHA = "5154E5B80EF6D3CB16E592F533185FDC3816AA228AA64C14BBC11CA1EB2408FB"
CLEAN_SOURCE_SHA = "C99CA320BA1D82F75AE227E84C6FF98AD19EDF7A112853C2DCD1B15A2771FB29"
STAGE_SHA = "E8C76BBB5397B59519CE6DCE4C0A6AA5AE9393031BEE660711A1FC171F9BA142"
COMPILED_SHA = "BD7DB986507FC1B43B22A8ADB5E78F7145874DF06727D06BCCA0AC03FE783D76"
STOCK_NAME = "HardShearInstalledStockTiming20261117.zip"
STOCK_ARCHIVE_SHA = "C452D2A59077C5DA5F6667DDD5ADF33778A0681F1B955A0E091FB08D8D2EE24F"
GROWTH_NAME = "HardShearCoarseGrowthWorkbookNative20261117.zip"
GROWTH_ARCHIVE_SHA = "40B29680E2E73033519883545091BD201DC109430D405151D8EC5EBF97B99302"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def json_file(path):
    return loads(path.read_text(encoding="utf-8-sig"))


def without_growth_lines(raw):
    lines = raw.splitlines(keepends=True)
    removed = [line for line in lines if b"POST_PEAK_EXTENDED_RATIO" in line]
    assert len(removed) == 2
    assert removed[0].startswith(b"Private Const POST_PEAK_EXTENDED_RATIO As Double = 4# ")
    assert removed[1].strip() == b"If smoothSteps >= 6 Then stepCeiling = POST_PEAK_EXTENDED_RATIO * nominal"
    stock = b"".join(line for line in lines if b"POST_PEAK_EXTENDED_RATIO" not in line)
    assert digest(stock) == STOCK_SOURCE_SHA
    return stock


def steel_crossing(root, manifest):
    rel = "Native/SteelCrossing/Report.txt"
    if rel not in manifest:
        return None
    text = (root / rel).read_text(encoding="utf-8-sig")
    assert f"SOURCE_SHA256: {COMPILED_SHA}" in text and "SOURCE_UNCHANGED: True" in text
    assert not re.search(r"^(RUNTIME ERROR:|FAIL:|NOT RUN:)", text, re.MULTILINE)
    reports = re.findall(r"^TOTAL_COUPLED_DEFORMATION_STEEL_CROSSING: passed=(\d+); failed=0$", text, re.MULTILINE)
    assert reports == ["32"]
    fingerprints = re.findall(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=([A-F0-9]{64}); equal=True;", text, re.MULTILINE)
    assert len(fingerprints) == 1 and fingerprints[0][0] == fingerprints[0][1]
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in text
    owner = json_file(root / (rel + ".Ownership.json"))
    receipt = json_file(root / (rel + ".ProcessClosure.json"))
    final = receipt["Closure"]["FinalState"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == COMPILED_SHA
    assert (final["State"], final["PID"], final["StartTicksUTC"]) == ("Absent", owner["PID"], owner["StartTicksUTC"])
    assert receipt["Passed"] and receipt["ChildHasExited"] and receipt["ChildExitCode"] == 0
    return int(reports[0])


def check(root, repo, saved_workbook=None):
    manifest = json_file(root / "SHA256SUMS.json")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    assert actual == set(manifest) | {"SHA256SUMS.json"}
    for name, expected in manifest.items():
        path = (root / name).resolve()
        assert path.is_relative_to(root) and digest(path.read_bytes()) == expected, name
    assert manifest[SOURCE] == CLEAN_SOURCE_SHA and manifest["ABManifest.json"] == STAGE_SHA
    plan = json_file(root / "ABManifest.json")
    assert plan["modules"] == [MODULE] and plan["book_sha256"] == BOOK_SHA
    for name in (SOURCE, "Stage.py", "Run-FullAB.ps1", "Verify-FullAB.py", "ReadWorkbookCurve.py"):
        assert plan["inputs"][name] == manifest[name]
    compiled = json_file(root / "docs/regression/CodeUpdate.json")
    closure = json_file(root / "CompileClosure.json")
    assert compiled["Modules"] == [MODULE] and compiled["Compiled"] and not compiled["ProductionChanged"]
    assert compiled["ProductionSHA256"] == BOOK_SHA and compiled["WorkbookSHA256"] == COMPILED_SHA
    assert PureWindowsPath(compiled["Workbook"]) == PureWindowsPath(
        r"D:\CodexScratch\RC_Section_NDM_TQ\HardGrowthClean1\docs\regression\Diagnostic.xlsm"
    )
    code_log = (root / "Compile.log").read_text(encoding="utf-8-sig")
    assert closure["State"] == "Absent"
    assert code_log.count(f"OWNED_EXCEL: id={closure['PID']}; utcStartTicks={closure['StartTicksUTC']}") == 1

    clean = (root / SOURCE).read_bytes()
    stock_source = without_growth_lines(clean)
    python_path.insert(0, str(root))
    try:
        builder = run_path(str(root / "CleanGrowthSource.py"))
        assert builder["clean"](stock_source) == clean
    finally:
        python_path.pop(0)

    archive_root = repo / "docs/regression/Coupled6D"
    stock, growth = (archive_root / name for name in (STOCK_NAME, GROWTH_NAME))
    assert digest(stock.read_bytes()) == STOCK_ARCHIVE_SHA and digest(growth.read_bytes()) == GROWTH_ARCHIVE_SHA
    verifier = run_path(str(root / "Verify-FullAB.py"))
    with ZipFile(stock) as original:
        a = verifier["native"](ZipPath(original, at="Native/"), BOOK_SHA)
        assert a["report_sha256"] == loads(original.read("StockProof.json"))["report_sha256"]
    b = verifier["native"](root / "Native/B", COMPILED_SHA)
    report = json_file(root / "ABVerification.json")
    curve = report["curve"]
    assert report == {"stock_source": "archive §490", "A": a, "B": b,
                      "matched_runtime_delta_s": None, "same_previously_verified_curve": True, "curve": curve}
    if saved_workbook:
        read = run_path(str(root / "ReadWorkbookCurve.py"))["read_curve"]
        assert read(saved_workbook) == curve
    with ZipFile(growth) as previous:
        earlier = previous.read("ABVerification.json")
        assert digest(earlier) == plan["inputs"]["PreviousB.json"]
        old_b = loads(earlier)["B"]
        for name in ("direct_N_Nmm", "capacity_status", "result_code", "lower_lambda", "limit_lambda",
                     "ultimate_N_Nmm", "probes", "assertions"):
            assert b[name] == old_b[name], name
        assert b["direct_N_Nmm"] == a["direct_N_Nmm"]
        old_curve = loads(previous.read("CandidateWorkbookCurve.json"))
        stock_curve = loads(previous.read("StockWorkbookCurve.json"))
    samples = curve["entries"]
    assert len(samples) == 136 and samples == old_curve["entries"]
    assert samples[-2][5] == "0.86051086816311118" and stock_curve["entries"][-2][5] == "0.96921408144626919"
    assert samples[16][5] == stock_curve["entries"][16][5] == "1.1029088921956576"
    assert all(item[5] == "1" for item in samples[1::2])
    return {
        "exact_accepted_samples": len(samples) // 2,
        "last_lambda_stock_clean": [stock_curve["entries"][-2][5], samples[-2][5]],
        "peak_lambda_stock_clean": samples[16][5],
        "probes": b["probes"],
        "checks": b["assertions"],
        "existing_steel_crossing_checks": steel_crossing(root, manifest),
        "status": b["capacity_status"],
        "clean_seconds": b["timing_s"]["results"],
        "saved_results_fingerprint_each_run": [a["results_reopened_sha256"], old_b["results_reopened_sha256"],
                                                b["results_reopened_sha256"]],
    }


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--saved-workbook", type=Path)
    options = parser.parse_args()
    result = check(HERE, options.repo, options.saved_workbook)
    print("HARDSHEAR CLEAN GROWTH PORTABLE VERIFIED")
    print(result)
