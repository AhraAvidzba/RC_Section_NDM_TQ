"""Повторяет расчёт трёх станций Excel и проверяет поздние отклонённые пробы."""

from argparse import ArgumentParser
import json
from math import fsum, isclose
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


HERE = Path(__file__).resolve().parent
LATEST = ('MVT2TabulatedActiveSteel20261117.zip', '12AC8259874E45568C5B04BB110F4C17D18FDEBD617532A30DE34C262B999792')
TORQUE = 10510000.


def shadow(z, name):
    """Подключает проверенную процедуру из закреплённого архива."""
    scope={'__name__':'__pinned__','__file__':name}
    exec(compile(z.read(name),name,'exec'),scope)
    return scope


def accepted(repo, root, temp):
    """Сверяет закрытие своего Excel, историю и шесть усилий для каждого поля."""
    stage = run_path(str(root/'Stage-ActiveSteelMVT2.py'))
    from hashlib import sha256
    from zipfile import ZipFile
    directory=repo/'docs/regression/Coupled6D'
    for name,stamp in ((stage['BASE'],stage['BASE_SHA']),LATEST):
        assert sha256((directory/name).read_bytes()).hexdigest().upper()==stamp
    digest=lambda data:sha256(data).hexdigest().upper()
    with ZipFile(directory/LATEST[0]) as z:
        verifier=shadow(z,'Verify-MVT2TabulatedContinuation.py')
        previous=json.loads(z.read('MVT2TabulatedContinuation.json'))
    with ZipFile(directory/stage['BASE']) as z:
        base=shadow(z,'Stage-TabulatedFlowNative.py')
        receipt=shadow(z,'Verify-TabulatedFlowNative.py')
    assert stage['SOURCE_SHA']==LATEST[1]
    status=receipt['receipt'](root,'Equilibrium',receipt['BOOK'],base)
    assert status['termination']=='completed'
    path=root/'Native'
    prep=json.loads((root/'Preparation.json').read_bytes())
    assert prep['force_schedule']=='ActiveSteelWitness' and prep['private_commit_reserve_GiB']==6
    assert prep['seed_archive_sha256']==LATEST[1] and prep['native_last_field_sha256']==stage['BASE_SHA']
    for filename in (stage['WATCHDOG'],stage['SEEDS']):
        assert prep['inputs'][filename]==digest((root/filename).read_bytes())
    proof_memory=receipt['read'](path/'MVTGaussMixed.txt.memory.json')
    assert proof_memory['Ready'] and proof_memory['RequiredCommitGiB']==6 and proof_memory['FreeCommitGiB']>=6
    windows=[json.loads(line) for line in (root/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert len(windows)==2 and all(x['freeCommitGiB']>=6 and x['ramMiB']>=6500 for x in windows)
    assert all(e['ProtectedUser'] and e['Id']!=status['excel_pid'] for x in windows for e in x['excel'])
    sources=base|{'digest':digest}
    seeds=stage['seeds'](directory,sources)
    wire=(root/stage['SEEDS']).read_bytes()
    assert wire.count(b'\r\n')==len(seeds)
    values={float(row[0]):list(map(float,row[1:])) for row in (line.split(';') for line in wire.decode().splitlines())}
    assert values=={q:list(field) for q,field in seeds.items()}
    old,old_frames,mesh,support,equation=verifier['load'](repo,temp)
    with verifier['archive'](repo,verifier['OPERATORS']) as z:
        tools,_,_,_,_,_=shadow(z,'Verify-NativeFollow.py')['read_references'](repo)
    tables=tools['read_operators']((path/'Operators.csv').read_bytes())
    frames=tools['read_tensor_frames']((path/'MVTGaussMixed.Tensor.csv').read_bytes(),45)
    assert all(old[key]==tables[key] for key in 'GLBSR')
    early=[label for label,(_,q,_) in old_frames.items() if q<=72500.]
    assert all(old_frames[label]==frames[label] and old['F'][label]==tables['F'][label] for label in early)
    wire=(path/'MVTGaussMixed.csv').read_text('cp1251')
    steps=[(label,float(q),float(t),float(m),result,internal,code) for label,t,q,m,result,internal,code in re.findall(
        r'^MVT2_CUT_TRIAL;([^;]+);([^;]+);([^;]+);([^;]+);([^;]+);([^;]+);([^;]+);',wire,re.M)]
    assert [q for _,q,*_ in steps]==prep['requested_Qy_N']
    assert all((t,m,result,internal,code)==(TORQUE,-396.*q,'True','4','0') for _,q,t,m,result,internal,code in steps)
    offered=[(label,float(q)) for label,q in re.findall(r'^MVT2_ACTIVE_STEEL_SEED;([^;]+);([^;]+);True$',wire,re.M)]
    assert offered==[(label,q) for label,q,*_ in steps if q in seeds]
    seconds,=re.findall(r'^CASE_FINISHED;MVTGaussMixed;True;([^\n]+)',wire,re.M)
    numerical=dict(re.findall(r'^MVT2_CUT_TRIAL;([^;]+);[^\n]+?Итерации: (\d+);',wire,re.M))
    inserted={label+'A'+q for label,q in re.findall(r'^MVT2_CUT_INSERTED;([^;]+);([^;]+);',wire,re.M)}
    assert inserted=={'S28A63750'}
    mixed_count=len(steps)+len(inserted)
    assert len(tables['H'])==135*mixed_count and len(frames)==mixed_count+8
    zero=(0.,)*6
    material=verifier['material']
    history={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
    histories,tensor_error=[],0.
    for label,frame in frames.items():
        torque,q,_=frame
        field=tables['F'][label]
        history,net,center=material(field,tables,mesh[1],support,history)
        if label.startswith('R'):
            continue
        tensor_error=max(tensor_error,*(abs(a-b) for (s,p),tensor in net.items() for a,b in zip(
            tensor,tables['H'][label,s,p],strict=True)))
        eq=equation(label,frame,tables,mesh)
        assert max(abs(a-b) for p in center for a,b in zip(center[p],frame[2][p],strict=True))<8e-7
        if q in seeds:
            assert torque==TORQUE and numerical[label]=='0'
            assert all(isclose(a,b,rel_tol=6e-15,abs_tol=1e-24) for a,b in zip(field,seeds[q],strict=True))
            histories.append({'Qy_kN':q/1000.,'actions':eq['actions_N_Nmm'],
                              'norm_MPa':max(eq[k] for k in ('weak_MPa','gauge_MPa','resultant_MPa')),
                              'tol_MPa':eq['tolerance_MPa'],
                              'twist_mrad_per_m':1e6*field[3]/mesh[0][3]})
    assert tensor_error<8e-7 and len(histories)==7
    return {'seconds':float(seconds),'mixed_fields':mixed_count,'all_tensor_error_MPa':tensor_error,
            'witness':histories},(verifier,old,old_frames,mesh,support,previous)


def measure(field, q, net, tables, mesh):
    """Считает максимальную и силовую невязки с полной проекцией тензоров."""
    load=(0.,-396.*q,0.,TORQUE,0.,q)
    external=[fsum(tables['L'][k][j]*x for k,x in enumerate(load,1)) for j in range(60)]
    residual=[]
    for j in range(60):
        gauge=fsum(x*g for x,g in zip(field,tables['G'][j+1],strict=True))
        r=fsum(tables['S'][p,k][j]*net[0,p][k-1] +
               tables['R'][p,k][j]*(net[1,p][k-1]-net[-1,p][k-1])/.002
               for p in mesh[1] for k in range(1,7))
        residual.append(gauge+r-external[j])
    weights=[]
    for p,(x,y,w,*_) in mesh[1].items():
        zz,xz,yz=(net[0,p][k] for k in (2,4,5))
        weights.append(tuple(w*a for a in (zz,y*zz,x*zz,x*yz-y*xz,xz,yz)))
    forces=tuple(map(fsum,zip(*weights,strict=True)))
    _,_,area,radius=mesh[0]
    force=max(abs(a-b)/(area*radius if k in (1,2,3) else area)
              for k,(a,b) in enumerate(zip(forces,load,strict=True)))
    norm=max(max(map(abs,residual[:56])),30000.*max(map(abs,residual[56:])),force)
    return norm,5e-7+5e-7*max(map(abs,external[:56]))


def rejected(root, base):
    """Проверяет, что для отклонённых проб кинематическое управление не обеспечило равновесие."""
    verifier,tables,frames,mesh,support,previous=base
    material=verifier['material']
    starts=verifier['replay_native'](tables,frames,mesh[1],support)
    history=starts[72812.5]
    rows=previous['routes']['active;2e-09;72812.5'][:-1]+previous['tail']['none;125'][:1]
    for row in rows:
        assert row['accepted']
        history=material(row['field'],tables,mesh[1],support,history)[0]
    data=json.loads((root/'MVT2TwistControl.json').read_bytes())
    assert not data['verified_limit'] and len(data['routes'])==5
    results={}
    for path, (row,) in data['routes'].items():
        _,net,_=material(row['field'],tables,mesh[1],support,history)
        norm,tol=measure(row['field'],row['Qy_N'],net,tables,mesh)
        assert not row['accepted'] and norm>tol and abs(norm-row['norm_MPa'])<2e-9
        assert isclose(tol,row['tol_MPa'],abs_tol=1e-16)
        results[path]={'Qy_kN':row['Qy_N']/1000.,'norm_MPa':round(norm,12),'tol_MPa':round(tol,12)}
    return results


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,default=HERE)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    with TemporaryDirectory(dir=args.out.resolve().parent) as name:
        native,base=accepted(args.repo,args.root,Path(name))
        result={'native':native,'rejected_probes':rejected(args.root,base),'physical_limit_established':False}
    args.out.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode('utf-8'))
    print('MVT2 ACTIVE STEEL VBA WITNESS PASS',len(native['witness']),len(result['rejected_probes']))
