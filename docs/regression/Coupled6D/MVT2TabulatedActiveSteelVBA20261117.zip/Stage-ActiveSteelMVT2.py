"""Готовит частную книгу для проверки полей MVT2 при штатных допусках VBA."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
SOURCE = 'MVT2TabulatedActiveSteel20261117.zip'
SOURCE_SHA = '12AC8259874E45568C5B04BB110F4C17D18FDEBD617532A30DE34C262B999792'
BASE = 'MVT2TabulatedFlowNative20261117.zip'
BASE_SHA = '0DDB248B0B2F61AF814F1E70EAE55CABE46CC07C261E8E8043A8D8A960850F49'
WATCHDOG = 'tools/build_workbook/Run-FocusedKaniWatchdog.ps1'
GUARD = 'Guard-IsolatedOffice.ps1'
SEEDS = 'ActiveSteel.Seeds.csv'


READ_SEED = r'''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает только начальное поле, не меняет принятую историю расчёта.
Private Function ReadActiveSteelSeedTest(ByVal qy As Double, ByRef guess As Variant) As Boolean
    Dim number As Integer, wire As String, items() As String, field(1 To 60) As Double, i As Long
    number = FreeFile
    Open Environ$("NDM_MVT_FLOW_FOLDER") & "\ActiveSteel.Seeds.csv" For Input As #number
    Do Until EOF(number)
        Line Input #number, wire
        items = Split(wire, ";")
        If UBound(items) <> 60 Then
            Close #number
            Err.Raise 5, , "Неверное число компонент начального поля MVT2."
        End If
        If Val(items(0)) = qy Then
            For i = 1 To 60: field(i) = Val(items(i)): Next i
            guess = field
            ReadActiveSteelSeedTest = True
            Exit Do
        End If
    Loop
    Close #number
End Function
'''


def seeds(archive_root, base):
    """Присоединяет подтверждённое поле Excel к независимым полям после текучести."""
    inputs = ((BASE, BASE_SHA), (SOURCE, SOURCE_SHA))
    for name, expected in inputs:
        assert base['digest']((archive_root/name).read_bytes()) == expected
    with ZipFile(archive_root/BASE) as source:
        pre_yield, = [line.split(';')[2:] for line in source.read('Matched/Native/Operators.csv').decode().splitlines()
                      if line.startswith('F;S32A72812.5;')]
    with ZipFile(archive_root/SOURCE) as source:
        result = json.loads(source.read('MVT2TabulatedContinuation.json'))
    candidates = result['routes']['active;2e-09;72812.5'] + result['tail']['none;125']
    fields = {72812.5: tuple(map(float,pre_yield))}
    fields.update({row['Qy_N']:row['field'] for row in candidates if row['accepted']})
    assert list(fields)==[72812.5,73750.,75000.,75312.5,76000.,77500.,77625.] and all(len(x)==60 for x in fields.values())
    return fields


def isolated_thresholds(stage, base):
    """Задаёт запас для одной короткой последовательной частной проверки."""
    guard=stage/GUARD
    raw=base['once'](guard.read_text('utf-8'), '$state.freeCommitGiB -lt 8', '$state.freeCommitGiB -lt 6')
    guard.write_bytes(raw.encode('utf-8'))
    watchdog=stage/WATCHDOG
    raw=base['once'](watchdog.read_text('utf-8-sig'),'$freeCommitBytes -ge 7GB','$freeCommitBytes -ge 6GB')
    raw=base['once'](raw,'RequiredCommitGiB=7','RequiredCommitGiB=6')
    raw=base['once'](raw,'or 7 GiB commit','or 6 GiB commit')
    watchdog.write_bytes(raw.encode('utf-8-sig'))


def prepare(repo, stage, guard_pid, guard_ticks):
    """Готовит проверяемую копию с утверждённым силовым путём и подсказками поля."""
    base = run_path(str(HERE/'Stage-TabulatedFlowNative.py'))
    base['stage'](repo,stage,'Equilibrium','default',guard_pid,guard_ticks,'Matched')
    filename=base['TEST']
    test=stage/filename
    source=test.read_text(encoding='utf-8-sig')
    initial=base['matched_goals'](repo)
    fields=seeds(repo/'docs/regression/Coupled6D',base)
    schedule=[q for q in initial if q<=72500.] + list(fields)
    body=base['once'](source,base['staged_goals'](initial),base['staged_goals'](schedule))
    marker='        solved = solver.TryStep(0#, expected(2), 0#, TORQUE, 0#, qy, atol, rtol, MAX_ITERATIONS)'
    body=base['once'](body,marker,'''        Dim guess As Variant, hasSeed As Boolean
        hasSeed = False
        If qy > 72500# Then
            hasSeed = ReadActiveSteelSeedTest(qy, guess)
            If Not hasSeed Then Err.Raise 5, , "Отсутствует начальное поле принятой независимой ступени."
        End If
        If hasSeed Then
            solved = solver.TryStep(0#, expected(2), 0#, TORQUE, 0#, qy, atol, rtol, MAX_ITERATIONS, initialField:=guess)
            AddExperimentTraceTest report, tracePath, "MVT2_ACTIVE_STEEL_SEED;" & phase & ";" & _
                ExperimentNumberTest(qy) & ";" & CStr(solved)
        Else
'''+ '    '+marker+'''
        End If''')
    body=base['once'](body,'If Not solved And meta.InternalStatus = rsNumericalFailure Then\n            AddExperimentTraceTest',
                       'If Not hasSeed And Not solved And meta.InternalStatus = rsNumericalFailure Then\n            AddExperimentTraceTest')
    base['writes'](test,body+READ_SEED,bom=True)
    line = lambda q,field: ';'.join([str(q),*(format(x,'.17g').upper() for x in field)])
    (stage/SEEDS).write_bytes(('\r\n'.join(line(q,field) for q,field in fields.items())+'\r\n').encode('ascii'))
    isolated_thresholds(stage,base)
    meta=stage/'Preparation.json'
    prep=json.loads(meta.read_bytes())
    prep.update(force_schedule='ActiveSteelWitness',requested_Qy_N=schedule,seed_archive_sha256=SOURCE_SHA,
                native_last_field_sha256=BASE_SHA,private_commit_reserve_GiB=6)
    prep['inputs'].update({file:base['digest']((stage/file).read_bytes()) for file in (filename,SEEDS,GUARD,WATCHDOG)})
    meta.write_bytes((json.dumps(prep,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',type=Path,required=True)
    parser.add_argument('--guard-pid',type=int,required=True)
    parser.add_argument('--guard-ticks',type=int,required=True)
    args=parser.parse_args()
    prepare(args.repo.resolve(),args.stage.resolve(),args.guard_pid,args.guard_ticks)
