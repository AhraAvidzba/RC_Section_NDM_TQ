"""Проверяет достижимость поздних состояний MVT2 при силовом и кинематическом управлении."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from scipy.optimize import least_squares


UPSTREAM = 'MVT2TabulatedActiveSteel20261117.zip'
UPSTREAM_SHA = '12AC8259874E45568C5B04BB110F4C17D18FDEBD617532A30DE34C262B999792'
TORQUE = 10510000.
ARM = 396.
FIELD_SCALE = 2e-5
FORCE_SCALE = 250.


def load(repo):
    """Восстанавливает подтверждённую историю §575 через неизменный закон материала."""
    path = repo/'docs/regression/Coupled6D'/UPSTREAM
    assert sha256(path.read_bytes()).hexdigest().upper()==UPSTREAM_SHA
    utility = {'__name__':'__pinned__'}
    with ZipFile(path) as tape:
        exec(compile(tape.read('Continue-MVT2Tabulated.py'),str(path),'exec'),utility)
        earlier=json.loads(tape.read('MVT2TabulatedContinuation.json'))
    a,b,_ = utility['CHAINS']
    with utility['pinned'](repo,b) as tape:
        material = [json.loads(tape.read(name)) for name in ('MVT2ASDBackboneTables.json','MVT2EffectiveInitial.json')]
    with utility['pinned'](repo,a) as native:
        section = utility['Section'](native,material,'default')
        states,_ = utility['start'](section,native)
    rows = earlier['routes']['active;2e-09;72812.5'][:-1] + earlier['tail']['none;125'][:1]
    assert [x['Qy_N'] for x in rows]==[73750.,75000.,75312.5,76000.,77500.,77625.]
    _,history = states[72812.5]
    for row in rows:
        assert row['accepted']
        q,field = row['Qy_N'],np.asarray(row['field'])
        result=section.evaluate(field,history,demand(q))
        assert result[1] <= row['tolerance_MPa'] and abs(result[1]-row['norms_MPa'][-1])<1e-9
        states[q] = field, result[4]
        history=result[4]
    return section,states,utility['strain_tensors']


def demand(q):
    """Формирует тот же знаковый вектор внешних усилий."""
    return np.array([0.,-ARM*q,0.,TORQUE,0.,q])


def solve(section, history, last, imposed, mode, guess, q_last, q_guess, h):
    """Минимизирует полную невязку, а затем сверяет исходный критерий её максимума."""
    columns=np.arange(60) if mode=='force' else np.delete(np.arange(60),3)
    x0=(guess[columns]-last[columns])/FIELD_SCALE
    if mode=='twist':
        x0=np.r_[x0,(q_guess-q_last)/FORCE_SCALE]

    def unpack(point):
        current=last.copy()
        current[columns]+=FIELD_SCALE*point[:len(columns)]
        if mode=='force':
            return current,imposed
        current[3]=imposed
        return current,q_last+FORCE_SCALE*point[-1]

    def all_residuals(point):
        field,q=unpack(point)
        loads=demand(q)
        rr=section.evaluate(field,history,loads)
        return np.r_[rr[0]*section.gauge_scale,(rr[2]-loads)/section.force_scale]

    widths=np.full(60,h/FIELD_SCALE)
    if mode=='twist':
        widths[-1]=.01/FORCE_SCALE

    def jacobian(point):
        perturbations=np.diag(widths)
        return np.stack([(all_residuals(point+v)-all_residuals(point-v))/(2.*w)
                         for w,v in zip(widths,perturbations,strict=True)],axis=1)

    solution=least_squares(all_residuals,x0,jac=jacobian,method='trf',ftol=1e-12,xtol=1e-12,gtol=1e-12,max_nfev=75)
    field,q=unpack(solution.x)
    load=demand(q)
    result=section.evaluate(field,history,load)
    tolerance=5e-7+5e-7*np.max(np.abs((load@section.l)[:56]))
    assert isfinite(result[1]) and isfinite(q)
    return field,q,result,float(tolerance), solution


def record(section, field,q,result,tol,solution,mode,goal,strain_tensors):
    """Сохраняет проверяемые поля, физические показатели и статус исходных уравнений."""
    eps=result[4][0][:,:25]
    return {'mode':mode,'requested':float(goal),'accepted':bool(result[1]<=tol), 'Qy_N':float(q),
            'field':field.tolist(),'forces':result[2].tolist(), 'norm_MPa':float(result[1]),'tol_MPa':tol,
            'weak_row':int(np.argmax(np.abs(result[0][:56])))+1,'call_count':int(solution.nfev),
            'twist_rad_per_m':float(1000.*field[3]/section.radius), 'cost':float(solution.cost),
            'min_concrete_strain': float(np.min(np.linalg.eigvalsh(strain_tensors(eps))))}


def trace(section, initial, previous, q, goals, mode, h, predictor, strain_tensors):
    """Идёт по связанным принятым полям без записи отклонённых состояний."""
    field,history=initial
    before,q_before=previous
    rows=[]
    for goal in goals:
        if mode=='force':
            ratio=(goal-q)/(q-q_before) if predictor else 0.
            q_guess=goal
        else:
            ratio=(goal-field[3])/(field[3]-before[3])
            q_guess=q+ratio*(q-q_before)
        guess=field+ratio*(field-before)
        next_field,next_q,result,tolerance,optimum=solve(section,history,field,goal,mode,guess,q,q_guess,h)
        row=record(section,next_field,next_q,result,tolerance,optimum,mode,goal,strain_tensors)
        rows.append(row)
        if not row['accepted']:
            break
        history=result[4]
        before,q_before,field,q=field,q,next_field,next_q
        if q>=80000.:
            break
    return rows


def run(repo,out):
    """Проверяет одни и те же исходные поля при двух схемах управления."""
    section,states,tensors=load(repo)
    before=states[77500.][0]
    after=states[77625.][0]
    q=77625.
    dt=(after[3]-before[3])
    rows={}
    for method,ratio,h in [('force',1.,2e-9),('force',.5,2e-9),('twist',1.,2e-9),('twist',.5,2e-9),('twist',.5,5e-10)]:
        target_offset=125.*ratio if method=='force' else dt*ratio
        start=q if method=='force' else after[3]
        goals=[start+n*target_offset for n in range(1,41)]
        data=trace(section,states[77625.],(before,77500.),q,goals,method,h,True,tensors)
        key=f'{method};{ratio:g};{h:g}'
        rows[key]=data
        print(key,len(data),sum(x['accepted'] for x in data),[(x['Qy_N'],x['norm_MPa']) for x in data[-2:]],flush=True)
    out.write_bytes((json.dumps({'routes':rows,'evaluations':section.calls,'verified_limit':False},indent=2)+'\n').encode('utf-8'))


if __name__=='__main__':
    arguments=ArgumentParser(description=__doc__)
    arguments.add_argument('--repo',type=Path,default=Path.cwd())
    arguments.add_argument('--out',type=Path,required=True)
    args=arguments.parse_args()
    run(args.repo,args.out)
