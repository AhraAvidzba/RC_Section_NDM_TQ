"""ДЛЯ ТЕСТОВ: независимый поиск следующего равновесия при таблицах НДМ."""

from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from time import perf_counter
from zipfile import ZipFile

import numpy as np
from scipy.optimize import least_squares


def TestLoadSection(repo):
    """Восстанавливает восемь принятых ступеней из проверенного нативного архива."""
    api=run_path(str(repo/'tmp/mvt-split-follow/Continue-MVT2Tabulated.py'))
    source=repo/'docs/regression/Coupled6D/MVT2NdmCurveConsistency20261117.zip'
    assert sha256(source.read_bytes()).hexdigest().upper()=='CE2DD6CE11F0C30BCAF46F3F14ABF35E25295B38762A4DBEDD90B0075DF85034'
    memory=BytesIO()
    with ZipFile(source) as original,ZipFile(memory,'w') as mapped:
        for name in ('Operators.csv','MVTGaussMixed.csv','MVTGaussMixed.Tensor.csv'):
            mapped.writestr('Matched/Native/'+name,original.read('Native/'+name))
    with api['pinned'](repo,'MVT2EffectivePlasticFlow20261117.zip') as z:
        material=[json.loads(z.read(name)) for name in ('MVT2ASDBackboneTables.json','MVT2EffectiveInitial.json')]
    with ZipFile(memory) as z:
        section=api['Section'](z,material,'ndm_uniaxial')
        fields={label:np.asarray(values,dtype=float) for _,label,*values in api['records'](z,'Matched/Native/Operators.csv','F')}
        torques={label:float(torque) for _,label,torque,q in api['records'](z,'Matched/Native/MVTGaussMixed.Tensor.csv','FRAME')}
        assert list(fields)==[f'R{i}' for i in range(1,9)]
        history=section.initial()
        for label,field in fields.items():
            torque=torques[label]
            result=section.evaluate(field,history,np.array([0.,0.,0.,torque,0.,0.]))
            tolerance=5e-7+5e-7*np.max(np.abs((result[2]@section.l)[:56]))
            assert result[1]<tolerance
            history=result[4]
    return section,history,fields['R8']


def TestRun(repo,out):
    """Сравнивает доверительную область и исходный Ньютон без изменения материалов."""
    section,history,origin=TestLoadSection(repo)
    trials=[]
    for q in (0.,50.,312.5,2500.):
        target=np.array([0.,-396.*q,0.,10510000.,0.,q])
        initial=section.evaluate(origin,history,target)
        started=perf_counter()
        trace=[]
        def TestResidual(field):
            value=section.evaluate(field,history,target)
            trace.append(float(value[1]))
            return value[0]*section.gauge_scale
        def TestJacobian(field):
            h=1e-9
            return np.column_stack([(TestResidual(field+h*unit)-TestResidual(field-h*unit))/(2*h) for unit in np.eye(60)])
        fit=least_squares(TestResidual,origin,jac=TestJacobian,x_scale='jac',
                          ftol=1e-12,xtol=1e-12,gtol=1e-12,max_nfev=100)
        value=section.evaluate(fit.x,history,target)
        tolerance=5e-7+5e-7*np.max(np.abs((target@section.l)[:56]))
        trials.append({'Qy_N':q,'accepted':bool(value[1]<=tolerance),'initial_norm_MPa':float(initial[1]),
                       'final_norm_MPa':float(value[1]),'tolerance_MPa':float(tolerance),
                       'status':int(fit.status),'message':fit.message,'calls':len(trace),
                       'elapsed_s':perf_counter()-started,'forces':value[2].tolist(),'field':fit.x.tolist()})
        print(q,value[1],tolerance,fit.message,flush=True)
    out.write_bytes((json.dumps({'method':'scipy least_squares trf; exact same constitutive update',
                                'trials':trials},indent=2)+'\n').encode())


if __name__=='__main__':
    repo=Path.cwd()
    TestRun(repo,repo/'tmp/mvt-split-follow/NdmCurveEquilibrium.json')
