"""Продолжает MVT2 по сохранённой VBA-истории с независимым расчётом касательной."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np


TORQUE = 10510000.
ARM = 396.
E = 30000.
ES = 200000.
TENSOR = ((0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2))
CHAINS = {
    'MVT2TabulatedFlowNative20261117.zip': '0DDB248B0B2F61AF814F1E70EAE55CABE46CC07C261E8E8043A8D8A960850F49',
    'MVT2EffectivePlasticFlow20261117.zip': '42D0340DACD7FE6E3A9BE3592DD6464219A6F58832F43061EC59999553E12220',
    'MVT2PublicationCut20261117.zip': '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD',
}


def pinned(repo, name):
    """Возвращает архив только после совпадения закреплённой контрольной суммы."""
    path = repo / 'docs/regression/Coupled6D' / name
    assert sha256(path.read_bytes()).hexdigest().upper() == CHAINS[name]
    return ZipFile(path)


def records(z, path, prefix=None):
    """Возвращает записи экспорта с фильтром по формату строки."""
    rows = (line.split(';') for line in z.read(path).decode('cp1251').splitlines())
    return (row for row in rows if prefix is None or row[0] == prefix)


class Curve:
    """Одноосная огибающая для одного знака главных напряжений."""

    def __init__(self, table, floor):
        self.x, self.nominal, self.effective = np.asarray(table)
        self.floor = floor
        self.edges = self.x + np.min(np.diff(self.x)) * 1e-6

    def value(self, x, y):
        """Интерполирует ординату и продолжает последнюю неотрицательную касательную."""
        index = np.clip(np.searchsorted(self.edges, x), 1, len(self.x) - 1)
        slope = (y[index] - y[index - 1]) / (self.x[index] - self.x[index - 1])
        slope = np.where(x > self.edges[-1], np.maximum(0., slope), slope)
        return np.maximum(self.floor, y[index - 1] + slope * (x - self.x[index - 1]))

    def update(self, old, trial):
        """Возвращает историю и масштабы эффективного и номинального напряжения."""
        plastic = old - self.value(old, self.effective) / E
        current = np.maximum(old, trial + plastic)
        reference = E * (current - plastic)
        return current, self.value(current, self.nominal) / reference, self.value(current, self.effective) / reference


class Section:
    """Использует уравнения сечения из Excel с независимым обновлением материала."""

    def __init__(self, z, material, mode):
        prefix = 'Matched/Native/'
        wire = prefix + 'Operators.csv'
        vector = lambda key: np.asarray([[float(x) for x in row[2:]] for row in records(z, wire, key)])
        block = lambda key: np.asarray([[float(x) for x in row[3:]] for row in records(z, wire, key)])
        dx, = [float(row[-1]) for row in records(z, wire, 'SIZE')]
        b = block('B').reshape(45,60,12).transpose(0,2,1)
        self.b = np.stack((b[:, :6], b[:, :6] + dx * b[:, 6:], b[:, :6] - dx * b[:, 6:]))
        self.g, self.l = vector('G'), vector('L')
        self.s = block('S').reshape(45,6,60)
        self.r = block('R').reshape(45,6,60)
        self.double_dx = 2. * dx
        point_data = np.asarray([[float(x) for x in row[2:]] for row in records(z, prefix + 'MVTGaussMixed.csv', 'MVT_POINT')])
        self.xy, self.weight, self.directions = point_data[:, :2], point_data[:, 2], point_data[25:, 3:]
        result_scale = np.array([float(x) for x in next(records(z, prefix + 'MVTGaussMixed.csv', 'MVT_GEOM'))[-2:]])
        self.force_scale = result_scale[0] * np.array([1., result_scale[1], result_scale[1], result_scale[1], 1., 1.])
        self.radius = result_scale[1]
        self.gauge_scale = np.array([1.] * 56 + [E] * 4)
        self.bounds = np.asarray([498.] * 4 + [450.] * 16)
        self.a = np.einsum('pi,spij->spj', self.directions, self.b[:, 25:]).reshape(60, 60)
        self.scatter = np.concatenate([np.einsum('pi,pij->jp', self.directions, matrix[25:])
                                      for matrix in (self.s, self.r / self.double_dx, -self.r / self.double_dx)], axis=1)
        self.curves = [Curve(table, -E * p) for table,p in zip(material[0][mode].values(),material[1][mode][3],strict=True)]
        self.ratio = max(5., max(self.curves[1].nominal) / max(self.curves[0].nominal))
        self.calls = 0

    def initial(self):
        """Начальная история на трёх станциях, со своими бетонными и стальными точками."""
        return np.zeros((3,45,6)), np.zeros((3,45,6)), np.zeros((2,3,45)), np.zeros((3,20))

    def nominal(self, field, history):
        """Рассчитывает пробные тензоры и новую историю без записи принятого состояния."""
        self.calls += 1
        prior_strain, prior_eff, old, prior_steel = history
        eps = self.b @ field
        increment = eps - prior_strain
        trial = prior_eff + increment * np.array([25000.] * 3 + [12500.] * 3)
        trial[..., :3] += (25000./3.) * increment[..., :3].sum(axis=-1, keepdims=True)
        tensor = np.empty((*trial.shape[:-1],3,3))
        for k,(i,j) in enumerate(TENSOR):
            tensor[...,i,j] = tensor[...,j,i] = trial[...,k]
        values, axes = np.linalg.eigh(tensor)
        stress_multipliers, effective_multipliers, new = [], [], []
        alpha, gamma = 4./33., 3.
        beta = (1. - alpha) * self.ratio - (1. + alpha)
        for k, curve in enumerate(self.curves):
            v = values if k == 0 else np.minimum(values, 0.)
            mean = v.mean(axis=-1)
            dev = np.sqrt(1.5 * ((v - mean[...,None]) ** 2).sum(axis=-1))
            high = v[..., -1]
            equiv = ((3. * alpha * mean + dev + beta * np.maximum(high, 0.) - gamma * np.maximum(-high,0.)) /
                     ((1.-alpha) * E * (self.ratio if k == 0 else 1.)))
            if k == 0:
                equiv = np.where(high < curve.floor, 0., equiv)
            current, stress, effective = curve.update(old[k], equiv)
            new.append(current)
            stress_multipliers.append(stress)
            effective_multipliers.append(effective)
        eig = lambda m: np.einsum('...ik,...k,...jk->...ij', axes,
                                  values * np.where(values < 0., m[1][...,None], m[0][...,None]), axes)
        comp = lambda matrix: np.stack([matrix[...,i,j] for i,j in TENSOR],axis=-1)
        concrete = comp(eig(stress_multipliers))
        concrete[:,25:] *= -1.
        steel_strain = (self.a @ field).reshape(3,20)
        steel_trial = ES * (steel_strain - prior_steel)
        steel = np.clip(steel_trial, -self.bounds, self.bounds)
        plastic = steel_strain - steel / ES
        return concrete, steel, steel_trial, (eps, comp(eig(effective_multipliers)), np.asarray(new), plastic)

    def projected(self, field, sigma):
        """Собирает слабые уравнения с центрированной производной и связи."""
        return (self.g @ field + np.einsum('pij,pi->j',self.s,sigma[0]) +
                np.einsum('pij,pi->j',self.r,(sigma[1]-sigma[2])/self.double_dx))

    def loads(self, center):
        """Интегрирует знаковые усилия по центральным напряжениям."""
        x,y = self.xy.T
        zz,xz,yz = center[:,2],center[:,4],center[:,5]
        return np.asarray([self.weight @ z for z in (zz,y*zz,x*zz,x*yz-y*xz,xz,yz)])

    def evaluate(self, field, history, target):
        """Собирает пробу и проверяемую невязку всех уравнений и усилий."""
        concrete, steel, trial, proposed = self.nominal(field, history)
        stress = concrete.copy()
        stress[:,25:] += steel[...,None] * self.directions
        residual = self.projected(field, stress) - target @ self.l
        forces = self.loads(stress[0])
        norm = max(np.max(np.abs(residual * self.gauge_scale)), np.max(np.abs(forces-target)/self.force_scale))
        return residual, norm, forces, stress, proposed, steel, trial

    def correction(self, field, history, result, method, h):
        """Сравнивает численную касательную с точной кусочно-линейной сталью."""
        tangent = np.empty((60,60))
        for k, unit in enumerate(np.eye(60)):
            plus = self.nominal(field + h * unit, history)
            minus = self.nominal(field - h * unit, history)
            concrete = (plus[0] - minus[0]) / (2. * h)
            tangent[:,k] = self.projected(unit, concrete)
            if method == 'central':
                tangent[:,k] += self.scatter @ ((plus[1] - minus[1]) / (2. * h)).ravel()
        if method == 'central':
            return np.linalg.solve(tangent, -result[0]), 1
        trial = result[-1].ravel()
        bounds = np.tile(self.bounds, 3)
        clipped = np.clip(trial,-bounds,bounds)
        mask = np.sign(trial - clipped)
        visited = set()
        for i in range(1,9):
            visited.add(mask.tobytes())
            elastic = mask == 0.
            matrix = tangent + (self.scatter[:,elastic] * ES) @ self.a[elastic]
            right = -result[0] - self.scatter @ (np.where(elastic,trial,mask*bounds)-clipped)
            step = np.linalg.solve(matrix,right)
            if method == 'exact':
                return step,i
            predicted = trial + ES * (self.a @ step)
            new = np.sign(predicted - np.clip(predicted,-bounds,bounds))
            if new.tobytes() in visited:
                return step,i
            mask = new
        return step,i

    def solve(self, field, history, q, method, h):
        """Решает заданную силовую цель, сохраняя историю при отклонении."""
        target = np.array([0., -ARM*q, 0., TORQUE, 0., q])
        tol = 5e-7 + 5e-7 * np.max(np.abs((target @ self.l)[:56]))
        result = self.evaluate(field, history, target)
        norms, branches = [float(result[1])], []
        for i in range(18):
            if result[1] <= tol:
                break
            step, branch_iterations = self.correction(field, history, result, method, h)
            branches.append(branch_iterations)
            for fraction in (2. ** -np.arange(13)):
                candidate = field + fraction * step
                other = self.evaluate(candidate, history, target)
                if other[1] < result[1]:
                    field, result = candidate, other
                    norms.append(float(result[1]))
                    break
            else:
                break
        solved = result[1] <= tol
        report = {'Qy_N': q,'accepted': bool(solved),'tolerance_MPa': float(tol),'norms_MPa': norms,
                  'branch_iterations':branches,'forces': result[2].tolist(),'field': field.tolist(),
                  'point28_plastic': result[4][3][:,2].tolist(), 'twist_rad_per_m': float(1000.*field[3]/self.radius),
                  'concrete_minimum_strain': float(np.min(np.linalg.eigvalsh(strain_tensors(result[4][0][:,:25])))),
                  'steel_maximum_absolute_strain': float(np.max(np.abs(self.a @ field)))}
        return field, result[4], report


def start(section, native):
    """Восстанавливает принятую историю и сверяет полные тензоры на каждом совместном поле."""
    prefix = 'Matched/Native/'
    fields = {label: np.asarray(coords,dtype=float) for _,label,*coords in records(native,prefix+'Operators.csv','F')}
    loads = {label: (float(t),float(q)) for _,label,t,q in records(native,prefix+'MVTGaussMixed.Tensor.csv','FRAME')}
    stress = {}
    for _, label, side, point, *values in records(native,prefix+'Operators.csv','H'):
        stress.setdefault(label, np.empty((3,45,6)))[(0,1,-1).index(int(side)),int(point)-1] = values
    states, error = {}, 0.
    history = section.initial()
    for label, field in fields.items():
        t,q = loads[label]
        result = section.evaluate(field,history,np.array([0.,-ARM*q,0.,t,0.,q]))
        history = result[4]
        if label in stress:
            error = max(error, float(np.max(np.abs(stress[label]-result[3]))))
            states[q] = field,history
    assert error < 8e-7 and len(stress) == 32
    return states,error


def strain_tensors(strain):
    """Собирает тензор деформаций из нормальных и инженерных сдвигов."""
    tensor = np.empty((*strain.shape[:-1],3,3))
    for k,(i,j) in enumerate(TENSOR):
        tensor[...,i,j] = tensor[...,j,i] = strain[...,k] * (1. if k<3 else .5)
    return tensor


def sequence(s, initial, goals, rule, h, seeds=None, previous=None):
    """Запускает новую последовательность с одного холодного снимка принятого состояния."""
    field, history = initial
    data = []
    for q in goals:
        if isinstance(seeds,dict):
            first = np.asarray(seeds[q])
        elif seeds == 'secant' and previous:
            qa, fa, qb = previous
            first = field + (q-qb)/(qb-qa) * (field-fa)
        else:
            first = field
        accepted_field, candidate, report = s.solve(first,history,q,rule,h)
        data.append(report)
        if not report['accepted']:
            break
        if seeds == 'secant' and previous:
            previous = previous[2], field, q
        field = accepted_field
        history = candidate
    return data, (field,history)


def run(repo, out):
    """Продолжает обе подтверждённые стартовые точки без смены допуска и физики стали."""
    a,b,c = CHAINS
    with pinned(repo,b) as tape:
        material = [json.loads(tape.read(name)) for name in ('MVT2ASDBackboneTables.json','MVT2EffectiveInitial.json')]
    with pinned(repo,a) as native:
        section = Section(native,material,'default')
        states,error = start(section,native)
    with pinned(repo,c) as ref:
        reference = {step['Q_target_N']: step['field'] for step in json.loads(ref.read('Cut396.json'))['result']['accepted']}
    routes = {}
    dense = [*range(72625,75001,125),75312.5,*range(75500,80001,250)]
    for method in ('central','exact','active'):
        for h in (2e-9, 8e-9):
            for start_q, goals in ((72500.,dense), (72812.5,[73750.,75000.,75312.5,76000.,77500.,80000.])):
                key = f'{method};{h:g};{start_q:g}'
                data, current = sequence(section, states[start_q], goals, method, h)
                routes[key] = data
                print(key, 'accepted', sum(x['accepted'] for x in data), 'last goal', data[-1]['Qy_N'], flush=True)
    prefix, current = sequence(section,states[72812.5],[73750.,75000.,75312.5,76000.,77500.],'active',2e-9)
    assert all(x['accepted'] for x in prefix)
    previous = 76000., np.asarray(prefix[-2]['field']), 77500.
    tail = {}
    for approach, step in (('none',125),('secant',125),('secant',250)):
        tail[approach,step], _ = sequence(section,current,range(77500+step,80001,step),'active',2e-9,approach,previous)
        rows = tail[approach,step]
        print(approach,step,'accepted',sum(x['accepted'] for x in rows),'last goal', rows[-1]['Qy_N'],flush=True)
    seeded, _ = sequence(section,states[72812.5],[73750.,75000.,75312.5],'exact',2e-9,reference)
    proof = {'replay_error_MPa': error, 'source_fields': len(states), 'evaluations': section.calls,
             'routes': routes,'external_seed_diagnostic': seeded, 'physical_limit_established': False,
             'tail': {f'{approach};{step}': data for (approach,step),data in tail.items()}}
    out.write_bytes((json.dumps(proof,indent=2) + '\n').encode('utf-8'))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--out', type=Path, required=True)
    options = parser.parse_args()
    run(options.repo,options.out)
