"""ДЛЯ ТЕСТОВ: уточняет шаг совместного нагружения при фиксированных кривых и допусках."""

from copy import copy
import json
from pathlib import Path
from runpy import run_path
from time import perf_counter

import numpy as np


def TestRun(repo,out):
    """Восстанавливает кручение и уменьшает только приращение Qy, сохраняя все шесть усилий."""
    common=run_path(str(repo/'tmp/mvt-split-follow/Probe-TestASDEnergySection.py'))
    helpers=run_path(str(repo/'tmp/mvt-split-follow/Continue-MVT2Tabulated.py'))
    loader=run_path(str(repo/'tmp/mvt-split-follow/Probe-TestNdmCurveEquilibrium.py'))['TestLoadSection']
    seed,_,_=loader(repo)
    energy=json.loads((repo/'tmp/mvt-split-follow/ASDEnergySection.json').read_bytes())['cases']
    damage=json.loads((repo/'tmp/mvt-split-follow/ASDDamageSection.json').read_bytes())['cases']
    records={}
    for name,case in [('ASDNDMEnergies125',energy['ASDNDMEnergies125']),*damage.items()]:
        started=perf_counter()
        section=copy(seed)
        section.curves=[helpers['Curve'](table,floor) for table,floor in zip(case['curves'].values(),case['floors'],strict=True)]
        history=section.initial()
        accepted=[]
        for trial in case['trials'][:8]:
            assert trial['accepted']
            field=np.asarray(trial['field'])
            target=np.array([0.,0.,0.,trial['T_Nmm'],0.,0.])
            result=section.evaluate(field,history,target)
            assert abs(result[1]-trial['norm_MPa'])<1e-10
            history=result[4]
        step,q=2500.,0.
        before=None
        attempts=[]
        for iteration in range(70):
            goal=min(q+step,10000.)
            target=np.array([0.,-396.*goal,0.,10510000.,0.,goal])
            predicted=field
            if before is not None:
                previous_q,previous_field=before
                predicted=field+(goal-q)/(q-previous_q)*(field-previous_field)
            trial,result,count,solved=common['TestForceStep'](section,predicted,history,target)
            row={'Qy_N':goal,'accepted':solved,'norm_MPa':float(result[1]),'iterations':count,
                 'forces':result[2].tolist(),'field':trial.tolist()}
            attempts.append(row)
            if solved:
                before=q,field
                q,field,history=goal,trial,result[4]
                accepted.append(row)
                step=min(2500.,2.*step)
                if q>=10000.:break
            else:
                step*=0.5
                if step<1.:break
        records[name]={'accepted':accepted,'attempts':attempts,'last_Qy_N':q,'elapsed_s':perf_counter()-started}
        out.write_bytes((json.dumps(records,indent=2)+'\n').encode())
        print(name,q,len(accepted),len(attempts),flush=True)


if __name__=='__main__':
    root=Path.cwd()
    TestRun(root,root/'tmp/mvt-split-follow/ASDAdaptiveSection.json')
