"""ДЛЯ ТЕСТОВ: строит кривые ASDConcrete3D с явно заданными энергиями и длиной."""

from math import sqrt


def TestBezierStress(x,control,stress):
    """Находит параметр квадратичной кривой Безье по полной деформации."""
    a=control[0]-2.*control[1]+control[2]
    b=2.*(control[1]-control[0])
    c=control[0]-x
    t=-2.*c/(b+sqrt(b*b-4.*a*c))
    return (1.-t)**2*stress[0]+2.*t*(1.-t)*stress[1]+t*t*stress[2]


def TestNormalize(x,y,damage,modulus):
    """Обеспечивает начальный модуль, необратимость пластической координаты и повреждения."""
    x,y,damage=list(x),list(y),list(damage)
    y[0]=damage[0]=0.
    y[1]=modulus*x[1]
    floor=1e-6*min(abs(a-b) for a,b in zip(y[1:],y[:-1],strict=True) if a!=b)
    tolerance=1e-6*min(a-b for a,b in zip(x[1:],x[:-1],strict=True))
    q=[0.]*len(x)
    for i in range(1,len(x)):
        x[i]=max(x[i],x[i-1]+tolerance)
        y[i]=max(floor,min(y[i],y[i-1]+modulus*(x[i]-x[i-1])))
        prior=x[i-1]-y[i-1]/((1.-damage[i-1])*modulus)
        plastic=x[i]-y[i]/((1.-damage[i])*modulus)
        if plastic<prior:
            damage[i]=min(1.,max(0.,1.-y[i]/modulus/(x[i]-prior)))
        damage[i]=max(damage[i-1],damage[i])
        if (y[i]-y[i-1])/(x[i]-x[i-1])>(1.-damage[i])*modulus:
            y[i]=(1.-damage[i])*modulus*(x[i]-prior)
        q[i]=y[i]/(1.-damage[i])
    return [x,y,q],floor


def TestBuildCurves(modulus,fc,ft,gt,gc,length):
    """Использует построитель OpenSees 3.8.0; Gt, Gc и длина передаются явно, без подбора."""
    assert min(modulus,fc,ft,gt,gc,length)>0.
    tensile_peak=1.5*ft/modulus
    tensile_plastic=tensile_peak-ft/modulus
    x2=max(gt/length/ft+0.2*ft/modulus+tensile_plastic,1.001*tensile_peak)
    x3=max(5.*gt/length/ft+0.001*ft/modulus+tensile_plastic,1.001*x2)
    tx=[0.,0.9*ft/modulus,tensile_peak,x2,x3,10.*x3]
    ty=[0.,0.9*ft,ft,0.2*ft,0.001*ft,0.001*ft]
    tp=[0.,0.,tensile_plastic,0.9*x2,0.8*x3,0.8*x3]
    td=[0.,0.]+[1.-stress/((strain-min(plastic,strain-stress/modulus))*modulus)
                for strain,stress,plastic in zip(tx[2:],ty[2:],tp[2:],strict=True)]
    e0,ep,peak=0.5*fc/modulus,fc/modulus,2.*fc/modulus
    compression_plastic=(peak-ep)*0.4+ep
    initial_work=0.5*fc*(peak-compression_plastic)
    tail=max(0.01*initial_work,gc/length-initial_work)
    residual=peak+2.*tail/(1.1*fc)
    cx=[0.,e0]+[e0+(i+1)*(peak-e0)/9. for i in range(9)]+[residual,residual+e0]
    cy=[0.,0.5*fc]+[TestBezierStress(e,(e0,ep,peak),(0.5*fc,fc,fc)) for e in cx[2:11]]+[0.1*fc,0.1*fc]
    cp=[0.,0.]
    for strain in cx[2:12]:cp.append(cp[-1]+0.7*(strain-cp[-1]))
    cp.append(cp[-1])
    cd=[0.,0.]+[1.-stress/((strain-min(plastic,strain-stress/modulus))*modulus)
                for strain,stress,plastic in zip(cx[2:],cy[2:],cp[2:],strict=True)]
    tension,tfloor=TestNormalize(tx,ty,td,modulus)
    compression,cfloor=TestNormalize(cx,cy,cd,modulus)
    command=['ASDConcrete3D',modulus,0.2,'-Te',*tx,'-Ts',*ty,'-Td',*td,
             '-Ce',*cx,'-Cs',*cy,'-Cd',*cd,'-tangent']
    return {'T':tension,'C':compression},(tfloor,cfloor),command
