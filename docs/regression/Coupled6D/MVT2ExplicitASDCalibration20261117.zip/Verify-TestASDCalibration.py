"""ДЛЯ ТЕСТОВ: проверяет явную калибровку ASD, нативные поля и отклонённые численные пробы."""

from argparse import ArgumentParser
from datetime import datetime,timezone,timedelta
from gzip import compress,decompress
from hashlib import sha256
import json
from math import fsum
from pathlib import Path
from runpy import run_path
from subprocess import run,PIPE
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


BALANCE=('MVT2TabulatedActiveSteelVBA20261117.zip','87CECC42511E773F37611E4749AFD4947C299F5853893715F284FA9F498789FB')
ORIGIN=('MVT2NdmCurveConsistency20261117.zip','CE2DD6CE11F0C30BCAF46F3F14ABF35E25295B38762A4DBEDD90B0075DF85034')
REPLAY=('MVT2NativeBarOpenSeesReplay20261117.zip','3FC1E30F23F2410CCF8C3C716D5B8554E385BB59F21DC14DE69CE53DD9301DFE')
MATERIAL=('MVT2EffectivePlasticFlow20261117.zip','42D0340DACD7FE6E3A9BE3592DD6464219A6F58832F43061EC59999553E12220')


def TestArchive(repo,entry):
    """Открывает только закреплённые входы исследования."""
    source=repo/'docs/regression/Coupled6D'/entry[0]
    assert sha256(source.read_bytes()).hexdigest().upper()==entry[1]
    return ZipFile(source)


def TestProcess(root,expected):
    """Проверяет отдельную компиляцию и закрытие, сохраняя запись первого заблокированного запуска."""
    read=lambda name:json.loads((root/name).read_text('utf-8-sig'))
    prep=read('Preparation.json')
    assert prep['source_core']==expected['source_core']
    assert prep['controlled_material']=='tabulated:explicit_energy_125'
    for name,stamp in prep['inputs'].items():
        if (root/name).exists():assert sha256((root/name).read_bytes()).hexdigest().upper()==stamp,name
    modules={'CCoupledSectionQuadrature','CCoupledElasticState','modTestMVT2GaussSpan','CCoupledConcreteResponse',
             'CTestConcreteBackbone','CTestTabulatedConcreteFlow','CCoupledNewtonSolver','CCoupledSteelCorrection','CCoupledReinforcedResponse'}
    compiler=read('CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged']
    assert compiler['ProductionSHA256']==prep['source_book_sha256']==expected['source_book_sha256']
    assert set(compiler['Modules'])==modules and read('CompileClosure.json')['State']=='Absent'
    owner=read('Native/MVTGaussMixed.txt.Ownership.json')
    close=read('Native/MVTGaussMixed.txt.ProcessClosure.json')
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    assert owner['SourceSHA256']==compiler['WorkbookSHA256']
    assert close['Passed'] and close['RunnerCleanupValid'] and close['ChildExitCode']==0
    assert close['Closure']['Identity']['Valid'] and close['Closure']['FinalState']['State']=='Absent'
    assert close['Closure']['Identity']['PID']==owner['PID']
    assert close['Closure']['Identity']['Ticks']==int(owner['StartTicksUTC'])
    log=(root/'Native/MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'RUNTIME ERROR:' not in log and 'target_reached=False' in log and 'SOURCE_UNCHANGED: True' in log
    memory=[json.loads(row) for row in (root/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert len(memory)==3
    for row in memory:assert row['ramMiB']>=6500 and row['freeCommitGiB']>=6
    unknown=[x for x in memory[0]['excel'] if not x['ProtectedUser']]
    assert len(unknown)==1 and unknown[0]['Id']==14328
    compile_time=datetime(1,1,1,tzinfo=timezone.utc)+timedelta(microseconds=int(read('CompileClosure.json')['StartTicksUTC'])//10)
    assert datetime.fromisoformat(memory[0]['utc'])<datetime.fromisoformat(memory[1]['utc'])<compile_time
    for row in memory[1:]:
        assert all(x['ProtectedUser'] and x['Id']!=owner['PID'] and x['Id']!=14328 for x in row['excel'])
    return prep


def TestInputs(repo,root,temp):
    """Подключает независимый скалярный материал и проверяет явный построитель кривых."""
    common=run_path(str(root/'Verify-NativeMVT2BarControl.py'))
    tools,material,mesh,support,_,expected,_,_=common['references'](repo,temp)
    prep=TestProcess(root,expected)
    with TestArchive(repo,BALANCE) as z:
        env={'__name__':'__pinned__','__file__':'Verify-ActiveSteelWitness.py'}
        exec(compile(z.read(env['__file__']),env['__file__'],'exec'),env)
    measure=env['measure']
    build=run_path(str(root/'Build-TestASDConcreteTables.py'))['TestBuildCurves']
    with TestArchive(repo,MATERIAL) as z:
        tables=json.loads(z.read('MVT2ASDBackboneTables.json'))
        initials=json.loads(z.read('MVT2EffectiveInitial.json'))
    calibration=prep['explicit_calibration']
    assert calibration['Gt_N_per_mm']==0.13773772513882 and calibration['Gc_N_per_mm']==15.8584746385201
    assert calibration['length_mm']==125. and calibration['compression_yield_ratio']==0.5
    curves,floors,command=build(30000.,calibration['fc_MPa'],calibration['ft_MPa'],calibration['Gt_N_per_mm'],
                               calibration['Gc_N_per_mm'],calibration['length_mm'])
    csv=(root/'default.csv').read_text('ascii').splitlines()
    expected_csv=['ASDFlow1;30000;0.2']
    for (key,values),floor in zip(curves.items(),floors,strict=True):
        expected_csv.append(f'BRANCH;{key};{len(values[0])};{floor!r}')
        expected_csv.extend(';'.join(repr(v) for v in row) for row in zip(*values,strict=True))
    assert csv==expected_csv
    native=tools['read_operators']((root/'Native/Operators.csv').read_bytes())
    frames=tools['read_tensor_frames']((root/'Native/MVTGaussMixed.Tensor.csv').read_bytes(),45)
    assert list(frames)==[f'R{i}' for i in range(1,9)]+['S2','S3A3750']
    return tools,material,mesh,support,measure,build,tables,initials,curves,floors,command,native,frames


def TestHistory(rows,tables,material,mesh,support,measure,curves,floors,history=None):
    """Повторяет пробы из одного принятого буфера и принимает только подтверждённые равновесия."""
    utility,backbone,rotation,_=support
    laws=[backbone['Backbone'](values,floor) for values,floor in zip(curves.values(),floors,strict=True)]
    support=utility,backbone,rotation,laws
    zero=(0.,)*6
    if history is None:history={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
    accepted=rejected=0
    maximum=0.
    for row in rows:
        proposed,net,center=material(row['field'],tables,mesh[1],support,history)
        measure.__globals__['TORQUE']=row['T_Nmm']
        norm,tolerance=measure(row['field'],row['Qy_N'],net,tables,mesh)
        maximum=max(maximum,abs(norm-row['norm_MPa']))
        assert abs(norm-row['norm_MPa'])<1e-8,(row['Qy_N'],norm,row['norm_MPa'])
        assert bool(norm<=tolerance)==row['accepted'],(row['Qy_N'],norm,tolerance)
        if row['accepted']:
            history=proposed
            accepted+=1
        else:rejected+=1
    return history,accepted,rejected,maximum


def TestNative(repo,root,temp):
    """Собирает полную нативную историю и независимые чисто бетонные напряжения трёх станций."""
    refs=TestInputs(repo,root,temp)
    tools,material,mesh,support,measure,_,_,_,curves,floors,command,tables,frames=refs
    utility,backbone,rotation,_=support
    support=utility,backbone,rotation,[backbone['Backbone'](x,f) for x,f in zip(curves.values(),floors,strict=True)]
    zero=(0.,)*6
    history={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
    strains,stresses=[],[]
    error=0.
    for phase,(torque,q,center) in frames.items():
        field=tables['F'][phase]
        history,net,c=material(field,tables,mesh[1],support,history)
        error=max(error,max(abs(a-b) for p in c for a,b in zip(c[p],center[p],strict=True)))
        measure.__globals__['TORQUE']=torque
        norm,tol=measure(field,q,net,tables,mesh)
        assert norm<=tol,(phase,norm,tol)
        strains.append([history[s,p][0] for s in (0,1,-1) for p in mesh[1]])
        stress=[]
        for s in (0,1,-1):
            for p in mesh[1]:
                value=net[s,p]
                if p>25:
                    eps,_,_,plastic=history[s,p]
                    axial=200000.*(fsum(a*d for a,d in zip(eps,mesh[1][p][3:],strict=True))-plastic)
                    value=tuple(axial*d-v for d,v in zip(mesh[1][p][3:],value,strict=True))
                stress.append(value)
        stresses.append(stress)
    assert error<8e-7
    return refs,command,strains,stresses,error


def TestWorker(target):
    """Считывает реальные таблицы и тензоры библиотеки для независимых материальных точек."""
    import openseespy.opensees as ops
    command,frames=json.load(sys.stdin)
    assert ops.version()=='3.8.0'
    ops.wipe();ops.model('basic','-ndm',3,'-ndf',3)
    for i in range(1,len(frames[0])+1):ops.nDMaterial(command[0],i,*command[1:])
    curves={sign:[ops.NDTest('GetResponse',1,sign+k) for k in ('e','s','q')] for sign in ('T','C')}
    stress=[]
    for frame in frames:
        row=[]
        for tag,(xx,yy,zz,xy,xz,yz) in enumerate(frame,1):
            ops.NDTest('SetStrain',tag,xx,yy,zz,xy,yz,xz)
            xx,yy,zz,xy,yz,xz=ops.NDTest('GetStress',tag)
            row.append([xx,yy,zz,xy,xz,yz]);ops.NDTest('CommitState',tag)
        stress.append(row)
    ops.wipe()
    target.write_bytes(json.dumps({'curves':curves,'stress':stress},separators=(',',':')).encode())


def TestCapture(repo,root,interpreter,target):
    """Выполняет три последовательных внешних пакета по 45 полных историй."""
    with TemporaryDirectory(dir=root) as name:
        temp=Path(name)
        _,command,frames,_,_=TestNative(repo,root,temp)
        data=[[] for _ in frames]
        for start in range(0,135,45):
            part=temp/f'Part{start}.json'
            wire=json.dumps([command,[frame[start:start+45] for frame in frames]]).encode()
            run([str(interpreter),'-B','-X','utf8',str(Path(__file__).resolve()),'--worker',str(part)],input=wire,
                stdout=PIPE,stderr=PIPE,timeout=45,check=True,creationflags=0x08000000 if sys.platform=='win32' else 0)
            actual=json.loads(part.read_bytes())
            for row,new in zip(data,actual['stress'],strict=True):row.extend(new)
        target.write_bytes(compress(json.dumps({'commands':command,'stress':data,'curves':actual['curves'],
            'engine':'OpenSees 3.8.0','strain_sha256':sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest().upper()},
            separators=(',',':')).encode(),mtime=0))


def TestVerify(repo,root,wire,temp):
    """Сверяет нативные и исследовательские поля, сохраняя все численные отказы как отказы."""
    refs,command,frames,stress,native_error=TestNative(repo,root,temp)
    tools,material,mesh,support,measure,build,old_tables,initials,curves,floors,_,tables,_=refs
    observed=json.loads(decompress(wire.read_bytes()))
    assert observed['commands']==command and observed['engine']=='OpenSees 3.8.0'
    assert observed['strain_sha256']==sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest().upper()
    curve_error=max(abs(a-b) for key in curves for old,new in zip(curves[key],observed['curves'][key],strict=True)
                    for a,b in zip(old,new,strict=True))
    stress_error=max(abs(a-b) for old,new in zip(stress,observed['stress'],strict=True)
                     for x,y in zip(old,new,strict=True) for a,b in zip(x,y,strict=True))
    assert curve_error<2e-11 and stress_error<8e-7
    results={}
    energy=json.loads((root/'ASDEnergySection.json').read_bytes())['cases']
    damage=json.loads((root/'ASDDamageSection.json').read_bytes())['cases']
    for name,case in {**energy,**damage}.items():
        if name=='NDMNominalDamage':expected=old_tables['ndm_uniaxial']
        else:expected=build(30000.,34.0277777777778,2.10667357864589,0.13773772513882,case['Gc_N_per_mm'],case['length_mm'])[0]
        if 'Damage' in name:expected={k:[v[0],v[1],[30000.*x for x in v[0]]] for k,v in expected.items()}
        assert case['curves']==expected
        history,a,b,error=TestHistory(case['trials'],tables,material,mesh,support,measure,case['curves'],case['floors'])
        results[name]={'accepted':a,'rejected':b,'maximum_norm_difference_MPa':error}
    adaptive=json.loads((root/'ASDAdaptiveSection.json').read_bytes())
    for name,case in adaptive.items():
        source=energy.get(name,damage.get(name))
        h,*_=TestHistory(source['trials'][:8],tables,material,mesh,support,measure,source['curves'],source['floors'])
        rows=[dict(row,T_Nmm=10510000.) for row in case['attempts']]
        _,a,b,error=TestHistory(rows,tables,material,mesh,support,measure,source['curves'],source['floors'],h)
        assert [x for x in rows if x['accepted']][-1]['Qy_N']==case['last_Qy_N']
        results[name+'Adaptive']={'accepted':a,'rejected':b,'last_Qy_N':case['last_Qy_N'],'maximum_norm_difference_MPa':error}
    with TestArchive(repo,ORIGIN) as z:
        origin=tools['read_operators'](z.read('Native/Operators.csv'))
        accepted=tools['read_tensor_frames'](z.read('Native/MVTGaussMixed.Tensor.csv'),45)
    ndm=old_tables['ndm_uniaxial'];ndm_floors=[-30000.*x for x in initials['ndm_uniaxial'][3]]
    rows=[]
    for key,(torque,q,_) in accepted.items():
        zero=(0.,)*6
        rows.append({'T_Nmm':torque,'Qy_N':q,'field':origin['F'][key],'accepted':True,'norm_MPa':0.})
    # Для начального префикса проверяется исходный допуск; норма берётся из независимого повтора.
    h={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
    utility,backbone,rotation,_=support
    ndm_support=utility,backbone,rotation,[backbone['Backbone'](x,f) for x,f in zip(ndm.values(),ndm_floors,strict=True)]
    for row in rows:
        h,net,_=material(row['field'],tables,mesh[1],ndm_support,h)
        measure.__globals__['TORQUE']=row['T_Nmm']
        norm,tol=measure(row['field'],0.,net,tables,mesh)
        assert norm<=tol
    least=json.loads((root/'NdmCurveEquilibrium.json').read_bytes())['trials']
    rows=[dict(row,T_Nmm=10510000.,norm_MPa=row['final_norm_MPa']) for row in least]
    _,a,b,error=TestHistory(rows,tables,material,mesh,support,measure,ndm,ndm_floors,h)
    assert a==0 and b==4
    return {'native_accepted_fields':10,'native_last_Qy_N':3750.,'OpenSees_states':1350,
            'max_native_scalar_stress_error_MPa':native_error,'max_OpenSees_curve_error':curve_error,
            'max_OpenSees_stress_error_MPa':stress_error,'routes':results,
            'least_squares_rejected_fields':b,'least_squares_max_norm_difference_MPa':error,
            'physical_limit_established':False,'production_material_changed':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--capture',type=Path);p.add_argument('--python',type=Path)
    p.add_argument('--wire',type=Path);p.add_argument('--out',type=Path);p.add_argument('--worker',type=Path)
    a=p.parse_args()
    if a.worker:TestWorker(a.worker)
    elif a.capture:TestCapture(a.repo.resolve(),a.root.resolve(),a.python.resolve(),a.capture.resolve())
    else:
        with TemporaryDirectory(dir=a.root) as name:proof=TestVerify(a.repo.resolve(),a.root.resolve(),a.wire,Path(name))
        a.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
        print('EXPLICIT ASD CALIBRATION VERIFIED 1350')
