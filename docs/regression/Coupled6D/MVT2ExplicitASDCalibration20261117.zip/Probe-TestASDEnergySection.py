"""ДЛЯ ТЕСТОВ: разделяет влияние длины и энергии сжатия на связанный расчёт MVT2."""

from io import BytesIO
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from time import perf_counter
from zipfile import ZipFile

import numpy as np


def TestForceStep(section,field,history,target):
    """Ищет силовую цель с неизменным допуском и принятым состоянием материала."""
    field=field.copy()
    tolerance=5e-7+5e-7*np.max(np.abs((target@section.l)[:56]))
    value=section.evaluate(field,history,target)
    for iteration in range(26):
        if value[1]<=tolerance:return field,value,iteration,True
        step,_=section.correction(field,history,value,'active',1e-9)
        for fraction in 2.**-np.arange(13):
            trial=field+fraction*step
            candidate=section.evaluate(trial,history,target)
            if candidate[1]<value[1]:
                field,value=trial,candidate
                break
        else:break
    return field,value,iteration,False


def TestRun(repo,out,damage_only):
    """Применяет заранее выбранные калибровки, не подбирая параметры по опытным 80 кН."""
    helpers=run_path(str(repo/'tmp/mvt-split-follow/Continue-MVT2Tabulated.py'))
    builder=run_path(str(repo/'tmp/mvt-split-follow/Build-TestASDConcreteTables.py'))['TestBuildCurves']
    loader=run_path(str(repo/'tmp/mvt-split-follow/Probe-TestNdmCurveEquilibrium.py'))['TestLoadSection']
    seed,_,_=loader(repo)
    fc,ft,gt,gc=34.0277777777778,2.10667357864589,0.13773772513882,15.8584746385201
    auto_gc=2.*gt*(fc/ft)**2
    length=0.01*gt/(0.5*ft*ft/30000.)
    with helpers['pinned'](repo,'MVT2EffectivePlasticFlow20261117.zip') as z:
        all_tables=json.loads(z.read('MVT2ASDBackboneTables.json'))
        default=all_tables['default']
    native,_,_=builder(30000.,fc,ft,gt,auto_gc,length)
    error=max(abs(a-b) for key in ('T','C') for left,right in zip(native[key],default[key],strict=True)
              for a,b in zip(left,right,strict=True))
    assert error<2e-11,error
    cases={}
    variants=(('ASDDefault',auto_gc,length),('ASDLength125',auto_gc,125.),('ASDNDMEnergies125',gc,125.))
    if damage_only:variants=(('NDMNominalDamage',gc,125.),('ASDNDMEnergies125Damage',gc,125.))
    for name,chosen_gc,chosen_length in variants:
        started=perf_counter()
        curves,floors,command=builder(30000.,fc,ft,gt,chosen_gc,chosen_length)
        if name=='NDMNominalDamage':
            curves=all_tables['ndm_uniaxial']
            floors=[c.floor for c in seed.curves]
        if damage_only:
            curves={key:[values[0],values[1],[30000.*x for x in values[0]]] for key,values in curves.items()}
            command=['ASDConcrete3D',30000.,0.2]
            for key,values in curves.items():
                x,y,q=values
                damage=[1.-b/c if c else 0. for b,c in zip(y,q,strict=True)]
                assert all(-1e-14<=d<1. for d in damage)
                assert all(b>=a-1e-14 for a,b in zip(damage[:-1],damage[1:],strict=True))
                command.extend(['-'+key+'e',*x,'-'+key+'s',*y,'-'+key+'d',*damage])
            command.append('-tangent')
        section=__import__('copy').copy(seed)
        section.curves=[helpers['Curve'](table,floor) for table,floor in zip(curves.values(),floors,strict=True)]
        field=np.zeros(60)
        history=section.initial()
        reports=[]
        last_target=np.zeros(6)
        targets=[(t,0.) for t in (262750.,525500.,1051000.,2102000.,4204000.,6831500.,8670750.,10510000.)]
        targets.extend((10510000.,q) for q in np.arange(2500.,80001.,2500.))
        for torque,q in targets:
            target=np.array([0.,-396.*q,0.,torque,0.,q])
            trial,result,iterations,accepted=TestForceStep(section,field,history,target)
            report={'T_Nmm':torque,'Qy_N':float(q),'accepted':accepted,'norm_MPa':float(result[1]),
                    'iterations':iterations,'field':trial.tolist(),'forces':result[2].tolist()}
            reports.append(report)
            print(name,torque,q,accepted,result[1],flush=True)
            if not accepted:break
            field,history=trial,result[4]
            last_target=target
        repeated=section.evaluate(field,history,last_target)
        cases[name]={'Gc_N_per_mm':chosen_gc,'length_mm':chosen_length,'curves':curves,'floors':floors,
                     'commands':command,'trials':reports,'elapsed_s':perf_counter()-started,
                     'repeat_norm_MPa':float(repeated[1])}
        out.write_bytes((json.dumps({'default_table_error_MPa':error,'cases':cases},indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--damage-only',action='store_true')
    args=parser.parse_args()
    repo=Path.cwd()
    filename='ASDDamageSection.json' if args.damage_only else 'ASDEnergySection.json'
    TestRun(repo,repo/'tmp/mvt-split-follow'/filename,args.damage_only)
