"""Архивирует нативное сравнение секущего кандидата со штатным HardShear."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
STOCK = HERE.parents[1]/'docs/regression/Coupled6D/HardShearInstalledStockTiming20261117.zip'
STOCK_SHA = 'C452D2A59077C5DA5F6667DDD5ADF33778A0681F1B955A0E091FB08D8D2EE24F'
NAME = 'HardShearSecantContinuationABNative20261117'
TERMINAL = {'B1/Native/HardShear/Verification.json': '8934B010B13A6C4175902D5E447E4F56F6C281E48D7B31F9ADCC87CCCAF151D3',
            'Corrected/A/Native/Synthetic/Verification.json':'966559EBBC9317270AB7B82935767899CAC5EC18D4CDB6E7EDFCC6523BC32A5F',
            'Corrected/B/Native/Synthetic/Verification.json':'8B5AA5DD6A3AD2D34B3D5C9F8AFD75AE31DB77DD6D1A97C7A5145F1754DF5D7B'}


def sha(raw):
    return sha256(raw).hexdigest().upper()


def collect(source,label,suites,files):
    plan = json.loads((source/'Fixture.json').read_bytes())
    paths = ['Fixture.json','Compile.log','CompileClosure.json','docs/regression/CodeUpdate.json','Run.ndjson',*plan['inputs']]
    for suite in suites:
        folder = source/'Native'/suite
        paths.extend(path.relative_to(source).as_posix() for path in sorted(folder.iterdir()) if path.is_file())
    assert len(paths) == len(set(paths))
    for path in paths:
        raw = (source/path).read_bytes()
        if path in plan['inputs']:
            assert sha(raw) == plan['inputs'][path]
        files[label+'/'+path] = raw


def seal(path,raw):
    if path.exists():
        assert path.read_bytes() == raw
    else:
        path.write_bytes(raw)


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('initial',type=Path)
    cli.add_argument('corrected',type=Path)
    args = cli.parse_args()
    assert sha(STOCK.read_bytes()) == STOCK_SHA
    files = {'Stock-Archive.sha256':(STOCK_SHA+'\n').encode('ascii')}
    with ZipFile(STOCK) as original:
        for entry in original.namelist():
            if not entry.endswith('/'):
                assert not entry.lower().endswith('.xlsm')
                files['Stock/'+entry] = original.read(entry)
    collect(args.initial/'B','B1',('Synthetic','HardShear'),files)
    collect(args.corrected/'A','Corrected/A',('Synthetic',),files)
    collect(args.corrected/'B','Corrected/B',('Synthetic',),files)
    for key,value in TERMINAL.items():
        assert sha(files[key]) == value
    for path in ('Pack.py','Verify-Portable.py','README-Portable.md','NativePlan.md'):
        files[path] = (HERE/path).read_bytes()
    manifest = {key:sha(raw) for key,raw in files.items()}
    files['SHA256SUMS.json'] = (json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode('utf-8')
    output = HERE/'proof-final'
    output.mkdir(exist_ok=True)
    with TemporaryDirectory(dir=output,prefix='replay-') as directory:
        folder = Path(directory)
        candidate = folder/'candidate.zip'
        with ZipFile(candidate,'w',compression=ZIP_DEFLATED,compresslevel=9) as archive:
            for name,raw in sorted(files.items()):
                entry = ZipInfo(name,date_time=(2026,11,17,0,0,0))
                entry.create_system = 3
                entry.external_attr = 0o100644 << 16
                archive.writestr(entry,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
        extracted = folder/'unpacked'
        with ZipFile(candidate) as archive:
            archive.extractall(extracted)
        replay = run([sys.executable,'-B','-X','utf8','Verify-Portable.py'],cwd=extracted,stdout=PIPE,check=True).stdout
        fingerprint = sha(candidate.read_bytes())
        seal(output/(NAME+'.zip'),candidate.read_bytes())
        seal(output/(NAME+'.zip.sha256'),f'{fingerprint} *{NAME}.zip\n'.encode('ascii'))
        seal(output/(NAME+'.replay.txt'),replay)
    print(output/(NAME+'.zip'),fingerprint)
    print(replay.decode('utf-8').splitlines()[-1])


if __name__ == '__main__':
    main()
