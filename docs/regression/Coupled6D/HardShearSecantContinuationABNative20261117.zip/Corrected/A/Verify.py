"""Проверяет происхождение нативных прогонов A/B и точные условия синтетических случаев."""

import argparse
from hashlib import sha256
import json
from math import isclose
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
MODES = ('Linear','Cubic','NoDesign','Configuration')


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def number(text):
    return float(text.replace(',','.'))


def inputs():
    plan = read(HERE/'Fixture.json')
    for path,expected in plan['inputs'].items():
        assert sha(HERE/path) == expected, path
    book = HERE/plan['workbook']
    if book.exists():
        assert sha(book) == plan['source_workbook_sha256']
    manifest = HERE/'SourceManifest.json'
    assert sha(manifest) == plan['candidate_manifest_sha256']
    overlay = read(manifest)
    if plan['lane'] == 'B':
        assert {Path(k).stem for k in overlay} < set(plan['modules'])
        assert all(sha(HERE/name) == data['candidate'] for name,data in overlay.items())
    else:
        assert plan['lane'] == 'A' and set(plan['modules']) == {'modTestCoupledElasticState','CTestCoupledPointResponse'}
        assert all(not (HERE/p).exists() for p in overlay)
    return plan


def native_proof(plan, folder):
    compiled = read(HERE/'docs/regression/CodeUpdate.json')
    compiler = read(HERE/'CompileClosure.json')
    owner = read(folder/'Report.txt.Ownership.json')
    native = read(folder/'Report.txt.ProcessClosure.json')
    close = native['Closure']['FinalState']
    assert compiled['Compiled'] and not compiled['ProductionChanged']
    assert sorted(compiled['Modules']) == sorted(plan['modules'])
    assert compiled['ProductionSHA256'] == plan['source_workbook_sha256']
    assert compiler['State'] == 'Absent'
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256'] == compiled['WorkbookSHA256']
    assert native['Passed'] and native['ChildHasExited'] and native['ChildExitCode'] == 0
    assert not native['OrdinaryPathKilledAnything'] and close['State'] == 'Absent'
    assert close['PID'] == owner['PID'] and close['StartTicksUTC'] == owner['StartTicksUTC']
    return compiled['WorkbookSHA256']


def total(text, label):
    found = re.findall(fr'^{label}: passed=(\d+); failed=(\d+)',text,re.MULTILINE)
    assert len(found) == 1 and int(found[0][0]) > 0 and int(found[0][1]) == 0, found
    return int(found[0][0])


def synthetic(plan, text):
    expected = total(text,'TOTAL_COUPLED_SECANT_START')
    candidates = re.findall(r'^SECANT_CASE: (.*)$',text,re.MULTILINE)
    assert len(candidates) == len(MODES)
    outcomes = {}
    for raw, required in zip(candidates,MODES,strict=True):
        lane, name, lower, count, retried, code, strain, weak, etc = raw.split('|')
        assert lane == plan['lane'] and name == required
        accepted = lane == 'B' and name == 'Linear'
        retry = lane == 'B' and name in ('Linear','Cubic')
        assert (retried == 'True') == retry
        assert int(count) == 2 + accepted
        strain, lower, weak, etc = map(number,(strain,lower,weak,etc))
        assert isclose(strain,.0007 if accepted else .0006,rel_tol=0.,abs_tol=1e-11)
        assert 0. <= weak <= 1e-8 and 0. <= etc <= 1e-8/30000.
        if accepted:
            assert code == '9' and isclose(lower,1.75,abs_tol=1e-8)
        else:
            assert code == '10'
            up = {'Linear':1.5,'Cubic':15.84/11.36,'NoDesign':1.515,'Configuration':1.5}[name]
            assert isclose(lower,up,abs_tol=1e-8)
        outcomes[name] = {'admitted_retry':retry,'accepted':accepted,'accepted_points':int(count),'confirmed_lambda':lower,
                          'code':int(code),'weak_norm_MPa':weak,'gauge_norm':etc}
    return {'assertions':expected,'scenarios':outcomes}


def hard_shear(text, folder):
    count = total(text,'TOTAL_COUPLED_WORKBOOK_TIMING')
    match = re.search(r'^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([^;]+); limit=; code=([A-Z_]+)$',text,re.MULTILINE)
    assert match is not None and number(match[1]) > 1.
    timer = re.search(r'^TIMING_SECONDS: ([^|]+) \| Both \| Excel$',text,re.MULTILINE)
    assert timer is not None
    report = folder/'ExecutionReport.txt'
    if report.exists():
        plain = report.read_text(encoding='utf-8-sig',errors='replace')
        if 'проб с секущим прогнозом' not in plain:
            plain = report.read_text(encoding='cp1251',errors='replace')
        retry_detail = next((line.strip() for line in plain.splitlines() if 'проб с секущим прогнозом' in line),None)
    else:
        retry_detail = None
    return {'assertions':count,'direct_status':'OK','capacity_status':'NumFail','lower':number(match[1]),'capacity_code':match[2],
            'seconds':number(timer[1].strip()),'execution_report_sha256':sha(report) if report.exists() else None,
            'retry_detail_if_available':retry_detail}


def verify(plan, suite):
    folder = HERE/'Native'/suite
    compiled = native_proof(plan,folder)
    native = folder/'Report.txt'
    text = native.read_text(encoding='utf-8-sig')
    reopened = re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=([A-F0-9]+); equal=True;',text,re.MULTILINE)
    assert reopened and reopened[1] == reopened[2] and 'SOURCE_UNCHANGED: True' in text
    result = {'lane':plan['lane'],'suite':suite,'compiled_workbook_sha256':compiled,'native_report_sha256':sha(native),
              'reopened_sha256':reopened[1],'physical_limit_certified':False}
    result.update(synthetic(plan,text) if suite == 'Synthetic' else hard_shear(text,folder))
    path = folder/'Verification.json'
    encoded = (json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
    if path.exists():
        assert path.read_bytes() == encoded
    else:
        path.write_bytes(encoded)
    print(f'HARDSHEAR_SECANT_{suite.upper()}: {plan["lane"]}; PASS; {sha(path)}')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--inputs',action='store_true')
    cli.add_argument('--suite',choices=('Synthetic','HardShear'))
    args = cli.parse_args()
    plan = inputs()
    if args.inputs:
        print(f'HARDSHEAR_SECANT_INPUTS: {plan["lane"]}; PASS')
    else:
        assert args.suite
        verify(plan,args.suite)


if __name__ == '__main__':
    main()
