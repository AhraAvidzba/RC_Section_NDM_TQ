"""Повторяет сверку штатной книги, кандидата и четырёх направленных тестов."""

from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import PIPE, run
import sys


ROOT = Path(__file__).resolve().parent
BOOK_SHA = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
STOCK_SHA = 'C452D2A59077C5DA5F6667DDD5ADF33778A0681F1B955A0E091FB08D8D2EE24F'
COMPONENTS = ('N','Mx','My','T','Qx','Qy')
RAY = tuple(map(Decimal,('28000','510000','180000','1500000','17000','-7100')))


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def reported(path):
    return path.read_text(encoding='utf-8-sig')


def closure(folder,name,source,exit_code):
    owner = read(folder/(name+'.Ownership.json'))
    closed = read(folder/(name+'.ProcessClosure.json'))
    last = closed['Closure']['FinalState']
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == source
    assert closed['ChildHasExited'] and closed['ChildExitCode'] == exit_code
    assert closed['Closure']['Passed'] and not closed['OrdinaryPathKilledAnything']
    assert (last['State'],last['PID'],last['StartTicksUTC']) == ('Absent',owner['PID'],owner['StartTicksUTC'])


def workbook_report(folder,name,execution,source):
    closure(folder,name,source,0)
    body = reported(folder/name)
    match = re.search(r'^TIMING_STATES: direct=(\w+); capacity=(\w+); confirmed lower=([^;]+); limit=([^;]*); code=([A-Z_]+)$',body,re.MULTILINE)
    assert match is not None and (match[1],match[2],match[4],match[5]) == ('OK','NumFail','','NUMERICAL_FAILURE')
    assert 'TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0' in body and 'SOURCE_UNCHANGED: True' in body
    assert re.findall(r'^OK: no unconfirmed limit component (.+)$',body,re.MULTILINE) == list(COMPONENTS)
    found = re.findall(r'^OK: direct (N|Mx|My|T|Qx|Qy) actual=([\d.E+\-]+) expected=([\d.E+\-]+)$',body,re.MULTILINE)
    assert tuple(row[0] for row in found) == COMPONENTS
    six = [Decimal(row[1])*(Decimal('9806650') if i in (1,2,3) else Decimal('9806.65')) for i,row in enumerate(found)]
    assert max(abs(a-b) for a,b in zip(six,RAY,strict=True)) < Decimal('1e-4')
    elapsed = float(re.search(r'^TIMING_SECONDS: ([\d.]+) \| Both \| Excel$',body,re.MULTILINE)[1])
    saved = re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=([A-F0-9]{64}); equal=True;',body,re.MULTILINE)
    assert saved is not None and saved[1] == saved[2]
    detail = (folder/execution).read_text(encoding='utf-16')
    direct = float(re.search(r'^\[([\d.]+) с\] Связанное равновесие подтверждено по шести усилиям\.',detail,re.MULTILINE)[1])
    capacity = float(re.search(r'^\[([\d.]+) с\] Подтверждён локальный максимум',detail,re.MULTILINE)[1])
    match_search = re.search(r'равновесие при lambda = 1 подтверждено: True; проб: (\d+);[^\n]*принято полей после максимума в новой мере: (\d+);',detail)
    assert match_search is not None and 0. < direct < capacity < elapsed
    return {'direct_status':match[1],'capacity_status':match[2],'lower':float(match[3]),'limit_output':match[4],
            'capacity_code':match[5],'signed_resultants_nonrounded':list(map(str,six)),
            'signed_output_lexemes':[row[1] for row in found], 'seconds':elapsed,'direct_equilibrium_seconds':direct,
            'capacity_endpoint_seconds':capacity,'probe_count':int(match_search[1]),'postpeak_accepted':int(match_search[2]),
            'source_workbook_sha256':source,'reopened_sha256':saved[1], 'run_log_sha256':sha(folder/name),
            'secant_rejected': ('проб с секущим прогнозом: 1 | Секущая проба: Равновесное поле вышло за границы локального секущего прогноза.' in detail)}


def replay(folder,suite):
    result = run([sys.executable,'-B','-X','utf8','Verify.py','--suite',suite],cwd=folder,stdout=PIPE,check=True)
    print(result.stdout.decode('utf-8').strip())
    return read(folder/'Native'/suite/'Verification.json')


def compare():
    stock = ROOT/'Stock'
    stock_plan = read(stock/'Fixture.json')
    assert stock_plan['book_sha256'] == stock_plan['inputs']['workbook/output/RC_Section_NDM.xlsm'] == BOOK_SHA
    for n,h in stock_plan['inputs'].items():
        if not n.lower().endswith('.xlsm'):
            assert sha(stock/n) == h
    a = workbook_report(stock/'Native','Both.txt','Both.Execution.txt',BOOK_SHA)
    stock_proof = read(stock/'StockProof.json')
    assert a['run_log_sha256'] == stock_proof['report_sha256'] and a['reopened_sha256'] == stock_proof['reopened_results_sha256']
    b1 = ROOT/'B1'
    b_read = replay(b1,'HardShear')
    b = workbook_report(b1/'Native/HardShear','Report.txt','ExecutionReport.txt',b_read['compiled_workbook_sha256'])
    assert b['run_log_sha256'] == b_read['native_report_sha256']
    for key in ('direct_status','capacity_status','lower','limit_output','capacity_code','signed_output_lexemes','signed_resultants_nonrounded','probe_count'):
        assert a[key] == b[key]
    assert a['probe_count'] == 96 and (a['postpeak_accepted'],b['postpeak_accepted']) == (55,54)
    assert not a['secant_rejected'] and b['secant_rejected']
    assert b['seconds'] > a['seconds']

    earlier = b1/'Native/Synthetic'
    closure(earlier,'Report.txt',b['source_workbook_sha256'],1)
    old = reported(earlier/'Report.txt')
    assert 'actual=3.81492909200121E-04 expected=0.0004' in old and 'actual=5.45801918831984E-04 expected=0.0006' in old
    assert 'RUNTIME ERROR: TestCoupledSecantScenario' in old and 'FAIL_FAST' in old
    corrected = ROOT/'Corrected'
    a2, b2 = (replay(corrected/lane,'Synthetic') for lane in ('A','B'))
    assert a2['scenarios']['Linear']['confirmed_lambda'] == 1.5 and b2['scenarios']['Linear']['confirmed_lambda'] == 1.75
    assert b2['scenarios']['Linear']['accepted'] and b2['scenarios']['Cubic']['admitted_retry'] and not b2['scenarios']['Cubic']['accepted']
    assert not any(b2['scenarios'][name]['admitted_retry'] for name in ('NoDesign','Configuration'))

    plan = read(b1/'Fixture.json')
    plan2 = read(corrected/'B/Fixture.json')
    plan_a2 = read(corrected/'A/Fixture.json')
    assert plan['source_workbook_sha256'] == plan2['source_workbook_sha256'] == plan_a2['source_workbook_sha256'] == BOOK_SHA
    assert plan['candidate_manifest_sha256'] == plan2['candidate_manifest_sha256'] == plan_a2['candidate_manifest_sha256']
    production = read(b1/'SourceManifest.json')
    assert all(plan['inputs'][p] == plan2['inputs'][p] == item['candidate'] for p,item in production.items())
    assert plan2['inputs']['tests/modTestCoupledElasticState.bas'] == plan_a2['inputs']['tests/modTestCoupledElasticState.bas']
    assert plan2['inputs']['tests/CTestCoupledPointResponse.cls'] == plan_a2['inputs']['tests/CTestCoupledPointResponse.cls']
    return {'stock':a,'candidate_B1':b,'delta_total_seconds':b['seconds']-a['seconds'],
            'relative_delta_one_pair':b['seconds']/a['seconds']-1.,'initial_synthetic_invalid_fixture':{'exit_code':1,'raw_sha256':sha(earlier/'Report.txt')},
            'corrected_A2':a2,'corrected_B2':b2,'physical_limit_certified':False,'production_adopted':False}


def main():
    hashes = read(ROOT/'SHA256SUMS.json')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    assert actual == set(hashes)|{'SHA256SUMS.json'}
    for name,value in hashes.items():
        assert not name.lower().endswith('.xlsm') and sha(ROOT/name) == value, name
    assert (ROOT/'Stock-Archive.sha256').read_text(encoding='ascii').strip() == STOCK_SHA
    print(json.dumps(compare(),indent=2,ensure_ascii=False))
    print('HARDSHEAR_SECANT_PORTABLE: VERIFIED_EVIDENCE; production_adopted=False; physical_limit_certified=False')


if __name__ == '__main__':
    main()
