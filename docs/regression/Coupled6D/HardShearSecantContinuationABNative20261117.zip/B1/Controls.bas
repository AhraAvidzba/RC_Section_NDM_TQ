' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет действующий маршрут Trace при численном отказе и локальном секущем прогнозе.
Public Function RunTestCoupledSecantStart(ByVal lane As String) As String
    Dim passed As Long, failed As Long, report As String
    On Error GoTo Failed
    If lane <> "A" And lane <> "B" Then Err.Raise 5, , "Укажите проверяемый вариант A или B."
    Dim scenario As Variant
    For Each scenario In Array("Linear", "Cubic", "NoDesign", "Configuration")
        TestCoupledSecantScenario CStr(scenario), lane, passed, failed, report
    Next scenario
    RunTestCoupledSecantStart = report & "TOTAL_COUPLED_SECANT_START: passed=" & passed & "; failed=" & failed
    Exit Function
Failed:
    RunTestCoupledSecantStart = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет два штатных равновесия и проверяет физические результаты повтора.
Private Sub TestCoupledSecantScenario(ByVal scenario As String, ByVal lane As String, _
        ByRef passed As Long, ByRef failed As Long, ByRef report As String)
    Const AREA As Double = 21600#, E As Double = 30000#, TOLERANCE As Double = 0.00000001
    Dim section As CSectionModel: Set section = TestBuildSection(TestFixtureBox(180#, 120#))
    Dim operators As New CCoupledElasticState, center As New CTestCoupledPointResponse
    Dim plus As New CTestCoupledPointResponse, minus As New CTestCoupledPointResponse, solver As New CCoupledNewtonSolver
    operators.PrepareModel section, E, 0#, 1, 1, 5
    center.TestInitialize operators.PointCount
    plus.TestInitialize operators.PointCount
    minus.TestInitialize operators.PointCount
    If scenario = "Cubic" Then
        center.TestUseDescendingAxialLaw
        plus.TestUseDescendingAxialLaw
        minus.TestUseDescendingAxialLaw
    End If
    solver.Initialize operators, center, E, plus, minus
    Dim baseLoad(1 To 6) As Double, direction(1 To 6) As Double, field() As Double, actual() As Double
    Dim trace As New CCoupledLoadTrace, history As New Collection, factor As Double, previousFactor As Double
    Dim targetForce As Double, strain As Double, i As Long
    previousFactor = 1#
    If scenario = "NoDesign" Then previousFactor = 1.01
    direction(1) = TestCoupledSecantAxialForce(0.0004, scenario = "Cubic") / previousFactor
    For i = 1 To 2
        strain = 0.0002# * CDbl(i + 1)
        targetForce = TestCoupledSecantAxialForce(strain, scenario = "Cubic")
        If i = 1 Then factor = previousFactor Else factor = targetForce / direction(1)
        targetForce = factor * direction(1)
        If Not solver.TryStep(targetForce, 0#, 0#, 0#, 0#, 0#, TOLERANCE, TOLERANCE, 30) Then _
            Err.Raise 5, "TestCoupledSecantScenario", "Не подтверждена исходная серия " & scenario & ". " & solver.ResultMeta.DiagnosticDetails
        solver.CopyTrial field, actual
        TestExpectNear field(1), strain, 0.00000000001, scenario & " / исходная деформация " & CStr(i), passed, failed, report
        solver.AcceptStep
        history.Add field: trace.Add 1#, factor
    Next i
    ' Ограничение имитирует численный отказ в исходном старте без изменения напряжений.
    If scenario = "Configuration" Then center.TestTangentFailure = sfcInvalidConfiguration Else center.TestMinimumAxialStrain = 0.00065
    Dim branch As New CCoupledDeformationContinuation, meta As CResultMeta
    branch.Trace solver, Nothing, baseLoad, direction, history, previousFactor, factor, actual, _
        1.8, 0.001, 30, TOLERANCE, TOLERANCE, trace
    Set meta = branch.ResultMeta
    Dim wantRetry As Boolean, wantAccepted As Boolean, sawRetry As Boolean, lower As Double
    wantRetry = (lane = "B" And (scenario = "Linear" Or scenario = "Cubic"))
    wantAccepted = (lane = "B" And scenario = "Linear")
    sawRetry = (InStr(1, meta.DiagnosticDetails, "проб с секущим прогнозом: 1", vbBinaryCompare) > 0)
    TestRecord sawRetry = wantRetry, scenario & " / допуск ровно одного повтора", passed, failed, report
    lower = factor
    If wantAccepted Then lower = 1.75
    TestExpectNear branch.BestAdmissibleLambda, lower, TOLERANCE, scenario & " / подтверждённая нагрузка", passed, failed, report
    Dim finalTrace As CCoupledLoadTrace: Set finalTrace = branch.SavedTrace
    Dim expectedStates As Long: expectedStates = 2
    If wantAccepted Then expectedStates = 3
    TestRecord finalTrace.Count = expectedStates, scenario & " / число принятых полей", passed, failed, report
    TestRecord center.TestAcceptedSteps = expectedStates And plus.TestAcceptedSteps = expectedStates And _
        minus.TestAcceptedSteps = expectedStates, scenario & " / все три принятых буфера", passed, failed, report
    TestRecord meta.InternalStatus = rsNumericalFailure, scenario & " / штатный итог поиска неопределён", passed, failed, report
    If wantAccepted Then
        TestRecord meta.ResultCode = rcSearchBoundReached, scenario & " / сохранена граница поиска", passed, failed, report
    Else
        TestRecord meta.ResultCode = rcNumericalFailure, scenario & " / сохранён численный отказ", passed, failed, report
    End If
    If wantRetry And scenario = "Cubic" Then _
        TestRecord InStr(1, meta.DiagnosticDetails, "вышло за границы локального", vbBinaryCompare) > 0, _
            scenario & " / равновесие отклонено дальше секущей", passed, failed, report

    ' Возвращаем полную доступность линейного тестового закона для проверки принятого поля.
    center.TestMinimumAxialStrain = 0#: center.TestTangentFailure = sfcNone
    Dim committed() As Double, residual() As Double, nothingTangent() As Double, external() As Double
    Dim gaugeStart As Long, maxWeak As Double, maxGauge As Double
    solver.CopyAccepted committed
    If wantAccepted Then strain = 0.0007#
    TestExpectNear committed(1), strain, 0.00000000001, scenario & " / фактический прогресс меры", passed, failed, report
    If Not solver.TestEquilibriumLinearization(committed, False, False, residual, nothingTangent) Then _
        Err.Raise 5, "TestCoupledSecantScenario", "Не проверено принятое поле."
    targetForce = lower * direction(1)
    operators.LoadEquations targetForce, 0#, 0#, 0#, 0#, 0#, external
    gaugeStart = solver.PhysicalDegreeCount + 1
    For i = 1 To gaugeStart - 1: maxWeak = GeomMax(maxWeak, Abs(residual(i) - external(i))): Next i
    For i = gaugeStart To UBound(residual): maxGauge = GeomMax(maxGauge, Abs(residual(i))): Next i
    TestRecord maxWeak <= TOLERANCE And maxGauge <= TOLERANCE / E, scenario & " / слабое равновесие и четыре связи", passed, failed, report
    Dim selected As Variant: selected = committed
    If Not solver.TryStep(targetForce, 0#, 0#, 0#, 0#, 0#, TOLERANCE, TOLERANCE, 1, selected) Then _
        Err.Raise 5, "TestCoupledSecantScenario", "Не подтверждены усилия принятого поля."
    Dim returned() As Double: solver.CopyTrial returned, actual
    Dim loads(1 To 6) As Double: loads(1) = targetForce
    TestRecord operators.ResultantResidualNorm(actual, loads) <= TOLERANCE, scenario & " / шесть исходных усилий", passed, failed, report
    solver.DiscardStep
    report = report & "SECANT_CASE: " & lane & "|" & scenario & "|" & CStr(lower) & "|" & CStr(finalTrace.Count) & "|" & _
        CStr(sawRetry) & "|" & CStr(meta.ResultCode) & "|" & CStr(committed(1)) & "|" & _
        CStr(maxWeak) & "|" & CStr(maxGauge) & vbCrLf
    report = report & "SECANT_DIAGNOSTICS: " & scenario & "|" & meta.ResultComment & "|" & meta.DiagnosticDetails & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вычисляет точное усилие контрольного осевого закона отдельно от решателя.
Private Function TestCoupledSecantAxialForce(ByVal strain As Double, ByVal cubic As Boolean) As Double
    Dim stress As Double: stress = 30000# * strain
    If cubic Then stress = stress - 1E+10# * strain ^ 3
    TestCoupledSecantAxialForce = 21600# * stress
End Function
