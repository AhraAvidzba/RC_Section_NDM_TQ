# Запускает отдельную компиляцию и одну проверку в новой копии.
param(
    [ValidateSet('Inputs','Compile','Native')][string]$Phase='Inputs',
    [ValidateSet('Synthetic','HardShear')][string]$Suite='Synthetic'
)

$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$nativeDir="Native/$Suite"
$report="$nativeDir/Report.txt"
Push-Location -LiteralPath $root
try {
    python -B -X utf8 'Verify.py' --inputs
    if ($LASTEXITCODE) {throw 'Входы проверки не подтверждены.'}
    if ($Phase -eq 'Inputs') {return}
    $data=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    $modules=@($data.modules)
    $ready="PRIVATE_CODE_READY: modules=$($modules.Count); production unchanged=True"
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Превышена длина пути фикстуры Excel.'
    }
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    if ($Phase -eq 'Compile') {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Test-Path -LiteralPath $report) -or
            (Get-FileHash -LiteralPath $draft).Hash -cne $data.source_workbook_sha256) {
            throw 'Для компиляции нужна новая изолированная книга.'
        }
        Assert-IsolatedOfficeReady "CompileSecant$($data.lane)"
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft `
            -ModuleNames $modules | Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
        return
    }
    $code=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closed=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    $compileLog=@(Get-Content -LiteralPath 'Compile.log' -Encoding utf8)
    if (!$code.Compiled -or $code.ProductionChanged -or $code.ProductionSHA256 -cne $data.source_workbook_sha256 -or
        $code.Workbook -ine (Resolve-Path -LiteralPath $draft).Path -or
        $code.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or
        @($code.Modules).Count -ne $modules.Count -or
        ((@($code.Modules) | Sort-Object -CaseSensitive) -join ',') -cne (($modules | Sort-Object -CaseSensitive) -join ',') -or
        $code.RetiredModules.Count -or $code.EntryPointNames.Count -or $code.TraceGeometry -or $closed.State -cne 'Absent' -or
        @($compileLog | Where-Object {$_ -ceq "OWNED_EXCEL: id=$($closed.PID); utcStartTicks=$($closed.StartTicksUTC)"}).Count -ne 1 -or
        $compileLog[-1] -cne $ready) {throw 'Протокол компиляции не соответствует подготовленной книге.'}
    $worker=Get-Process -Id $closed.PID -ErrorAction SilentlyContinue
    if ($worker -and $worker.StartTime.ToUniversalTime().Ticks -eq [long]$closed.StartTicksUTC) {throw 'Процесс компиляции ещё видим.'}
    if (@(Get-ChildItem -LiteralPath $nativeDir -Force).Count) {throw 'Есть результаты предыдущего нативного запуска.'}
    Assert-IsolatedOfficeReady "RunSecant$($data.lane)$Suite"
    $runner='tools/build_workbook/Run-Audit03Watchdog.ps1'
    if ($Suite -eq 'Synthetic') {
        & $legacy -NoProfile -ExecutionPolicy Bypass -File $runner -SourceWorkbook $draft -ReportPath $report `
            -Macro 'modTestCoupledElasticState.RunTestCoupledSecantStart' -MacroArgument1 $data.lane `
            -Mode No -TimeoutSeconds $data.synthetic_timeout -FailFast -VerifyResultsReopen
    } else {
        & $legacy -NoProfile -ExecutionPolicy Bypass -File $runner -SourceWorkbook $draft -ReportPath $report `
            -Macro 'modTestCoupledElasticState.RunTestCoupledWorkbookTiming' -MacroArgument1 'Both' -MacroArgument2 'Excel' `
            -Mode No -TimeoutSeconds $data.hardshear_timeout -FailFast -VerifyResultsReopen
    }
    if ($LASTEXITCODE) {throw "Нативный прогон завершён с кодом $LASTEXITCODE."}
    if ($Suite -eq 'HardShear') {
        $origin=@(Get-Content -LiteralPath $report -Encoding utf8 | Where-Object {$_ -like 'FIXTURE: *'})
        if ($origin.Count -eq 1) {
            $directory=Split-Path -Parent $origin[0].Substring('FIXTURE: '.Length)
            if (!$directory.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Нативная фикстура за рабочим каталогом.'}
            $workReport=Join-Path $directory 'RC_Section_NDM_execution_report.txt'
            if (Test-Path -LiteralPath $workReport) {Copy-Item -LiteralPath $workReport -Destination (Join-Path $nativeDir 'ExecutionReport.txt')}
        }
    }
    python -B -X utf8 'Verify.py' --suite $Suite
    if ($LASTEXITCODE) {throw 'Независимая сверка не пройдена.'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
