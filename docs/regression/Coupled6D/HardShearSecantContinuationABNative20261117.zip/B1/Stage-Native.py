"""Собирает два изолированных нативных варианта секущего старта HardShear."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
TOOLS = HERE.parent / 'hs-f19/ready'
TOOLS_SHA = 'B89584EC04324BC43A343FF1063972E918A8E95DC10D28610791C41C3EE9869E'
STOCK_BOOK = 'workbook/output/RC_Section_NDM.xlsm'
STOCK_SHA = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
CANDIDATE = HERE / 'candidate'
CANDIDATE_SHA = 'B34B67AF2C74AA6C6F70F5E81DD37A15104267D50506CAC5028616CECC860EFE'
TESTS = 'tests/modTestCoupledElasticState.bas'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def seal(folder, name, raw):
    target = folder / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, name
    else:
        target.write_bytes(raw)
    return sha(raw)


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--destination', type=Path, default=HERE / 'ready')
    cli.add_argument('--lane', choices=('A','B','Both'), default='Both')
    cli.add_argument('--with-workbooks', action='store_true')
    args = cli.parse_args()
    output = args.destination.resolve()
    assert output.is_relative_to(HERE) or output.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    source = (REPO / STOCK_BOOK).read_bytes()
    assert sha(source) == STOCK_SHA
    stock_tests = (REPO / TESTS).read_bytes()
    tooling = (TOOLS / 'Fixture.json').read_bytes()
    overlay = (CANDIDATE / 'SourceManifest.json').read_bytes()
    original = (HERE.parent / 'hs-mesh/ready/Fixture.json').read_bytes()
    assert sha(tooling) == TOOLS_SHA and sha(overlay) == CANDIDATE_SHA
    assert sha(stock_tests) == json.loads(original)['production'][TESTS]
    base_production = json.loads(overlay)
    for name, hashes in base_production.items():
        assert sha((REPO / name).read_bytes()) == hashes['stock']
        assert sha((CANDIDATE / name).read_bytes()) == hashes['candidate']

    extras = (HERE / 'Controls.bas').read_bytes().decode('utf-8-sig').replace('\r\n', '\n')
    extras.encode('cp1251')
    stock = stock_tests.decode('utf-8-sig').replace('\r\n', '\n').rstrip()
    merged = stock + '\n\n' + extras.rstrip() + '\n'
    assert max(map(len,merged.splitlines())) < 1024
    test_input = merged.replace('\n','\r\n').encode('utf-8')
    lanes = ('A','B') if args.lane == 'Both' else (args.lane,)
    for lane in lanes:
        folder = output / lane
        files = {}
        for path, expected in json.loads(tooling)['inputs'].items():
            if path.startswith('tools/') or path == 'Guard-IsolatedOffice.ps1':
                raw = (TOOLS / path).read_bytes()
                assert sha(raw) == expected
                files[path] = seal(folder,path,raw)
        for path in ('Run.ps1','Verify.py','Stage-Native.py','Controls.bas'):
            files[path] = seal(folder,path,(HERE / path).read_bytes())
        files['SourceManifest.json'] = seal(folder,'SourceManifest.json',overlay)
        files[TESTS] = seal(folder,TESTS,test_input)
        if lane == 'B':
            for path in base_production:
                files[path] = seal(folder,path,(CANDIDATE / path).read_bytes())
        if args.with_workbooks:
            seal(folder,STOCK_BOOK,source)
            seal(folder,'docs/regression/Diagnostic.xlsm',source)
            for p in ('Temp','Native/Synthetic','Native/HardShear'):
                (folder / p).mkdir(parents=True, exist_ok=True)
        modules = [Path(TESTS).stem]
        if lane == 'B':
            modules.extend(Path(path).stem for path in base_production)
        fixture = {'lane':lane,'source_workbook_sha256':STOCK_SHA,'workbook':STOCK_BOOK,'modules':modules,'inputs':files,
                   'candidate_manifest_sha256':CANDIDATE_SHA,'synthetic_timeout':80,'hardshear_timeout':160,
                   'scope':'production continuation admission and focused workbook A/B; no physical limit verdict'}
        fingerprint = seal(folder,'Fixture.json',(json.dumps(fixture,indent=2)+'\n').encode('utf-8'))
        print(f'HARDSHEAR_SECANT_RIG {lane}: {folder} {fingerprint}')


if __name__ == '__main__':
    main()
