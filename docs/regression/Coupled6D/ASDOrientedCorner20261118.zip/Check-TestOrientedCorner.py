"""ДЛЯ ТЕСТОВ: закрепляет независимые пробы, проверку производной и нативное прохождение негладкого угла."""
from argparse import ArgumentParser
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestRead(path):
    """Читает JSON с сохранением различий численного отказа и физического предела."""
    return json.loads(path.read_text('utf-8-sig'))


def TestNative(repo, root, output):
    """Сверяет фактически собранный VBA, отрицательные исходы и закрытие только собственных экземпляров Excel."""
    shared = run_path(str(root/'Check-TestMaterialRoundoff.py')); shared['TestFiles'](root)
    source, _ = run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source)); cases = {}
    for key in TestRead(root/'Cases.json'):
        folder = root/'Cases'/key
        record = shared['TestSourceComparison'](repo, root, folder, source, original, helper, body, reader)
        assert (record['components'], record['imported'], record['unchanged']) == (238, 23, 215)
        log = folder/'Native/ControlProbe.txt'; text = log.read_text('utf-8-sig')
        owner = TestRead(log.with_name(log.name+'.Ownership.json')); closure = TestRead(log.with_name(log.name+'.ProcessClosure.json'))
        identity = closure['Closure']['Identity']; compiler = TestRead(folder/'docs/regression/CodeUpdate.json')
        assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['Passed'] and closure['RunnerCleanupValid']
        assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
        assert int(owner['PID']) == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
        assert closure['Closure']['FinalState']['State'] == 'Absent' and 'SOURCE_UNCHANGED: True' in text
        totals = [tuple(map(int, r)) for r in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', text, re.M)]
        if key == 'BoundaryRecovery':
            assert closure['ChildExitCode'] == 1 and totals == [(0, 1)]
            assert 'CORNER_STEP;FaceReadOnly;False;0;' in text and 'RUNTIME ERROR: VBAProject Не решена тестовая спектральная координата: FaceReadOnly' in text
            record['expected_event_solver_rejection'] = True
        else:
            assert closure['ChildExitCode'] == 0 and totals == [(1, 0)] and 'RUNTIME ERROR:' not in text
        if key == 'Probes':
            trials = re.findall(r'^CONTROL_PROBE;([^;]+);(True|False);', text, re.M)
            assert len(trials) == 16 and all(success == 'False' for _, success in trials)
            record['rejected_raw_newton_trials'] = 16
        if key in ('NativeCorner', 'StaleFaceExport'):
            assert 'CORNER_POST_COUNT;10;requested;32' in text and 'CORNER_POST;Post11;False;' in text
            assert 'CORNER_ORIENTATION;Outgoing;False;' in text
            record['accepted_post_steps'] = 10; record['all_32_steps_reached'] = False
        safety = [json.loads(r) for r in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(r['ramMiB'] >= 6500 and r['freeCommitGiB'] >= 6 for r in safety)
        assert all(all(p['ProtectedUser'] for p in r['excel']) for r in safety)
        cases[key] = record
    failure = TestRead(root/'FirstCompileFailure/CompileFailureClosure.json')
    assert failure['State'] == 'Absent' and not failure['Compiled'] and not failure['CodeUpdateExists']
    result = {'cases': cases, 'first_compile_failure_preserved': True, 'installed_workbook_changed': False,
              'physical_capacity_certified': False, 'full_acceptance_completed': False}
    output.write_bytes((json.dumps(result, indent=2, sort_keys=True)+'\n').encode())
    print('ORIENTED CORNER NATIVE SOURCES AND EXPECTED NEGATIVE OUTCOMES VERIFIED', flush=True)


def TestMechanics(repo, root, output):
    """Повторяет поля от действительной истории; отрицательный экспорт не принимается ради успешного макроса."""
    shared = run_path(str(root/'Check-TestMaterialRoundoff.py')); shared['TestFiles'](root)
    results = {}
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch)
        for key, script, function, folder, extra in (
            ('probes', 'Validate-TestIndependentControl.py', 'TestValidate', 'Probes', (148, 16)),
            ('direction', 'Analyze-TestRejectedDirection.py', 'TestAnalyze', 'Direction', ()),
            ('event', 'TestOriented148Corner.py', 'TestRun', 'Direction', ()),
            ('native_corner', 'Validate-TestNativeCorner.py', 'TestValidate', 'NativeCorner', ())):
            target = scratch/(key+'.json')
            run_path(str(root/script))[function](repo, root/'Cases'/folder, target, *extra)
            results[key] = TestRead(target)
        try:
            run_path(str(root/'Validate-TestNativeCorner.py'))['TestValidate'](repo, root/'Cases/StaleFaceExport', scratch/'Stale.json')
        except AssertionError as error:
            value = float(error.args[0]); assert value > 8e-7
            results['stale_readonly_export'] = {'expected_rejection': True, 'native_stress_error_MPa': value}
        else: raise AssertionError('Экспорт принятого буфера вместо пробного не был отвергнут.')
    event = results['event']; native = results['native_corner']
    assert event['event_solved'] and event['event_norm_MPa'] <= 1e-9
    assert abs(event['event_Qy_N']-native['readonly_face']['Qy_N']) < 1e-4
    assert all(s['principal_rate_for_mechanical_forward'] > 0. for s in event['sides'] if s['side'] == -1)
    assert all(s['principal_rate_for_mechanical_forward'] < 0. for s in event['sides'] if s['side'] == 1)
    assert native['accepted_post_steps'] == 10 and not native['completed_all_requested_steps']
    results.update(physical_capacity_certified=False, full_acceptance_completed=False,
                   blanket_negative_mechanical_advance_is_not_a_physical_failure_criterion=True)
    output.write_bytes((json.dumps(results, indent=2, sort_keys=True)+'\n').encode())
    print('ORIENTED CORNER SIX EQUILIBRIA AND SEQUENTIAL HISTORY VERIFIED; PHYSICAL CAPACITY OPEN', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True); args = parser.parse_args()
    (TestNative if args.scope == 'native' else TestMechanics)(args.repo.resolve(), args.root.resolve(), args.out.resolve())
