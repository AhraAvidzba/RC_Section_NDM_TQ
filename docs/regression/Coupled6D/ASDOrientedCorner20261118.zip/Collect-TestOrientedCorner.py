"""ДЛЯ ТЕСТОВ: сохраняет нативные попытки и независимые проверки спектрального угла без изменения рабочей книги."""
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestCollect(repo, target):
    """Сохраняет отрицательные попытки отдельно; успех одного диагностического макроса не повышает до полной приёмки."""
    here = Path(__file__).resolve().parent; scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    cases = {'Probes': 'Oriented148Probes0220261118', 'Direction': 'Oriented148Direction20261118',
             'BoundaryRecovery': 'NativeCornerTrace0220261118', 'StaleFaceExport': 'NativeCornerTrace0320261118',
             'NativeCorner': 'NativeCornerTrace0420261118'}
    collect = run_path(str(here/'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases; collect(repo, target)
    names = ('Check-TestOrientedCorner.py', 'Validate-TestIndependentControl.py', 'Stage-TestOriented148Probes.py',
             'Stage-TestOriented148Direction.py', 'TestRefineBeforeSign.py', 'TestOriented148Corner.py',
             'Validate-TestNativeCorner.py', 'TestNativeCornerTrace.bas.txt', 'TestNativePrincipalStep.bas.txt',
             'Stage-TestNativeCornerTrace.py', Path(__file__).name)
    for name in names: (target/name).write_bytes((here/name).read_bytes())
    failure = target/'FirstCompileFailure'; failure.mkdir()
    first = scratch/'Oriented148Probes20261118'
    for name in ('Compile.log', 'CompileFailureClosure.json', 'Preparation.json', 'Run.ndjson'):
        (failure/name).write_bytes((first/name).read_bytes())
    prep = json.loads((first/'Preparation.json').read_bytes()); comparisons = {}
    for name in prep['inputs']:
        if name.startswith(('src/', 'tests/')):
            raw = (first/name).read_bytes()
            assert raw == (scratch/cases['Probes']/name).read_bytes(), name
            comparisons[name] = sha256(raw).hexdigest().upper()
    (failure/'InputComparison.json').write_bytes((json.dumps(comparisons, indent=2, sort_keys=True)+'\n').encode())
    frozen = {}; final = scratch/cases['NativeCorner']
    for name in json.loads((final/'Preparation.json').read_bytes())['inputs']:
        if name.startswith(('src/', 'tests/')) and name != 'tests/modTestMVT2ProductionASDTest.bas':
            actual, working = (final/name).read_text('utf-8-sig'), (repo/name).read_text('utf-8-sig')
            if name == 'src/Solver/CCoupledNewtonSolver.cls': assert actual.startswith(working+'\n')
            else: assert actual == working, name
            frozen[name] = sha256((repo/name).read_bytes()).hexdigest().upper()
    pins = {'workbook/output/RC_Section_NDM.xlsm': 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450',
            'workbook/output/VBA_All_Code.txt': 'DB8023F9384B0059E1D1C51D59FE0E62F9B8CD94AC4D9B329DD0EE810AF676CC'}
    assert all(sha256((repo/name).read_bytes()).hexdigest().upper() == pin for name, pin in pins.items())
    (target/'SourceCheckpoint.json').write_bytes((json.dumps({'base': 'c237612', 'installed_inputs': pins,
        'production_sources': frozen, 'working_algorithm_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n').encode())
    text = '''# Негладкая спектральная граница, 18.11.2026

Журнал §606, база c237612. Рабочий код и основная пара E47ACB70… /
DB8023F9… не изменены. Все добавленные методы существуют только в частных
диагностических книгах, не являются готовой общей реализацией.

Probes: 16 независимых прямых шагов от общей истории из 148 полей,
четыре меры и четыре размера. Ни один не сошёлся; это численные отказы,
не доказательство разрушения. Direction сохраняет фактическую поправку,
касательную и 28 долей шага. Локальная производная верна, но конечный
шаг пересекает спектральную границу точки 36, станции −1.

Независимое решение G=0 и h=0 нашло общую угловую точку с невязкой
около 1.3e-12 МПа. Односторонние касательные имеют разные направления
при том же механическом ориентире. Это обосновывает исследование
связанного негладкого перехода, не снятие всех проверок ориентации.

BoundaryRecovery: существующая короткая координатная доводка не решила
точку h=0; сохранён реальный неуспешный нативный макрос. В NativeCorner
добавлен только тестовый расширенный Ньютон по 87 уравнениям и h,
максимум 32 итерации и 17 долей. Внешние поля равновесия не переносятся.
FaceReadOnly не принимается. Затем Incoming и Outgoing последовательно
решаются и принимаются; история Incoming сохранена перед Outgoing.

StaleFaceExport выявлен независимой проверкой: экспорт принятого буфера
не соответствует непринятому пробному полю. Этот вариант сохранён как
отрицательный контроль, а в NativeCorner применён читающий материальный
отклик без изменения истории. Допуск 8e-7 МПа не ослаблялся.

После события NativeCorner получил 10 обычных равновесий; Post11 не
сошёлся. Все шесть усилий, слабые уравнения, связи и три станции
напряжений независимо повторены. Метка target_reached=True общего
диагностического макроса означает его завершение; 32 шага не пройдены
и несущая способность не установлена. Исходящий шаг имеет отрицательную
ориентацию относительно входящего. Следующие 10 шагов ориентированы
относительно нового исходящего направления. Условие положительного
скалярного произведения не является универсальным критерием связности
негладкой кривой и тем более физического разрушения.

FirstCompileFailure сохраняет первую неоконченную компиляцию и закрытие
её собственного процесса. Точные исходники VBA совпадают с последующей
успешной Probes; причина исходного инфраструктурного отказа не доказана.

Повтор без Excel с NumPy 2.3.5 и SciPy 1.18.1:

    python -B -X utf8 Check-TestOrientedCorner.py --repo <проект> --root . --scope native --out NativeProof.json
    python -B -X utf8 Check-TestOrientedCorner.py --repo <проект> --root . --scope mechanics --out MechanicsProof.json

Полный ON/OFF/Focused/AutoCAD, глобальный OpenSees и переустановка
основной книги не выполнялись. Общая автоматическая сертификация угла,
предел трудных случаев, LoadPath, сходимость по шагу и пространству,
производительность и окончательная приёмка остаются открытыми.
'''
    (target/'README.md').write_bytes(text.replace('\n', '\r\n').encode())
    files = {p.relative_to(target).as_posix(): sha256(p.read_bytes()).hexdigest().upper()
             for p in target.rglob('*') if p.is_file() and p.name != 'Files.json'}
    (target/'Files.json').write_bytes((json.dumps(files, indent=2, sort_keys=True)+'\n').encode())
    print('ORIENTED CORNER EVIDENCE COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    from argparse import ArgumentParser
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
