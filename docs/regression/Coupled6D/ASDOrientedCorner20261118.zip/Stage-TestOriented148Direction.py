"""ДЛЯ ТЕСТОВ: сохраняет точную неудачную итерацию малой пробы от ориентированного состояния 148."""
from argparse import ArgumentParser
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Добавляет только копирование итерации и невязок; алгоритм и исходная история остаются прежними."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestOriented148Probes.py'))['TestStage'](repo, root)
    run_path(str(here/'Stage-TestRejectedDirection.py'))['TestInstrument'](root, loop_count=16, first_index=1)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve())
