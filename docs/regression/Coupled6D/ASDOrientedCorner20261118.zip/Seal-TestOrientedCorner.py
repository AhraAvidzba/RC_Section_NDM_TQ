"""ДЛЯ ТЕСТОВ: закрепляет переносимый комплект и две новые проверки манифеста без изменения исторических случаев."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED


def TestSeal():
    """Фиксирует границы диагностического результата; не заменяет основную книгу и не объявляет физический предел."""
    repo = Path.cwd(); here = Path(__file__).resolve().parent
    root = Path('D:/CodexScratch/RC_Section_NDM_TQ/OrientedCornerEvidence20261118')
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    files = {p.relative_to(root).as_posix(): sha256(p.read_bytes()).hexdigest().upper()
             for p in root.rglob('*') if p.is_file() and p.name != 'Files.json'}
    (root/'Files.json').write_bytes((json.dumps(files, indent=2, sort_keys=True)+'\n').encode())
    name = 'ASDOrientedCorner20261118'; archive = repo/'docs/regression/Coupled6D'/(name+'.zip')
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted(root.rglob('*')):
            if path.is_file(): output.write(path, path.relative_to(root).as_posix())
    assert archive.stat().st_size < 100000000
    digest = sha256(archive.read_bytes()).hexdigest().upper()
    path = repo/'docs/reports/Coupled6DEvidence.json'; manifest = json.loads(path.read_bytes())
    assert name not in manifest['archives']; manifest['archives'][name] = digest
    pins = {}
    for scope, title, marker in (
        ('native', 'NativeProof.json', 'ORIENTED CORNER NATIVE SOURCES AND EXPECTED NEGATIVE OUTCOMES VERIFIED'),
        ('mechanics', 'MechanicsProof.json', 'ORIENTED CORNER SIX EQUILIBRIA AND SEQUENTIAL HISTORY VERIFIED; PHYSICAL CAPACITY OPEN')):
        pins[title] = sha256((here/('OrientedCorner.'+title)).read_bytes()).hexdigest().upper()
        manifest['cases'].append({'id': 'asd-oriented-corner-'+scope, 'journal_section': 606, 'archive': name,
            'script': 'Check-TestOrientedCorner.py', 'arguments': ['--repo', '{repo}', '--root', '.', '--scope', scope, '--out', title],
            'stdout_contains': marker, 'outputs': {title: pins[title]}, 'timeout_seconds': 300})
    path.write_bytes((json.dumps(manifest, ensure_ascii=False, indent=2)+'\n').encode())
    result = {'archive': name, 'bytes': archive.stat().st_size, 'sha256': digest, 'proofs': pins}
    (repo/'tmp/OrientedCornerSeal.json').write_bytes((json.dumps(result, indent=2)+'\n').encode())
    print(json.dumps(result, indent=2))


if __name__ == '__main__': TestSeal()
