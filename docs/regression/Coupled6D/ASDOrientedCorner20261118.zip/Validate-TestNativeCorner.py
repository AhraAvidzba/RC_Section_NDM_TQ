"""ДЛЯ ТЕСТОВ: независимо повторяет нативный спектральный угол и непрерывную последовательность после него."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestRead(folder, suffix):
    """Читает фактические поля, шесть внешних усилий и все три станции одного нативного экспорта."""
    rows = [r.split(';') for r in (folder/('ControlProbe'+suffix+'.Operators.csv')).read_text('cp1251').splitlines()]
    fields = [(r[1], np.asarray(r[2:], float)) for r in rows if r[0] == 'F']
    net = {}
    for row in rows:
        if row[0] == 'H':
            key = ((0, 1, -1).index(int(row[2])), int(row[3])-1)
            assert key not in net.setdefault(row[1], {})
            net[row[1]][key] = np.asarray(row[4:], float)
    loads, center, label = {}, {}, None
    for line in (folder/('ControlProbe'+suffix+'.Tensor.csv')).read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME':
            label = row[1]; assert label not in loads
            torque, q = map(float, row[2:4])
            loads[label] = np.array([0., -396.*q, 0., torque, 0., q]); center[label] = {}
        elif row[0] == 'POINT':
            point = int(row[1])-1; assert point not in center[label]
            center[label][point] = np.asarray(row[8:], float)
    assert {r[0] for r in fields} == set(net) == set(loads) == set(center)
    return fields, net, loads, center


def TestState(section, history, field, load, net, center, strict=False):
    """Проверяет равновесие, каждое напряжение и возвращает новую историю без изменения исходной."""
    result = section.TestEvaluate(field, history, load)
    tolerance = 1e-9 if strict else float(5e-7+5e-7*np.max(np.abs((load@section.l)[:section.TestDof-4])))
    assert result[1] <= tolerance, (result[1], tolerance)
    assert len(net) == 3*section.TestPointCount and len(center) == section.TestPointCount
    net_error = max(float(np.max(np.abs(result[3][s, p]-stress))) for (s, p), stress in net.items())
    concrete = result[3][0].copy()
    concrete[section.TestConcreteCount:] = result[5][0, :, None]*section.directions-concrete[section.TestConcreteCount:]
    error = max(net_error, max(float(np.max(np.abs(concrete[p]-stress))) for p, stress in center.items()))
    assert error < 8e-7, error
    return result[4], {'norm_MPa': float(result[1]), 'tolerance_MPa': tolerance, 'native_stress_error_MPa': error}


def TestValidate(repo, root, output):
    """Не отождествляет законченный диагностический макрос с достижением физического предела или всех 32 шагов."""
    here = Path(__file__).resolve().parent
    replay = run_path(str(here/'TestResolutionSection.py'))['TestReplay']
    metric = run_path(str(here/'TestRefineBeforeSign.py'))['TestMetric']
    boundary = run_path(str(here/'TestOriented148Corner.py'))['TestBoundary']
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch); prefix = scratch/'Prefix'; prefix.mkdir()
        for target, source in (('Operators.csv', 'Trace74.Operators.csv'), ('MVTGaussMixed.csv', 'Trace74.csv'),
                               ('MVTGaussMixed.Tensor.csv', 'Trace74.Tensor.csv')):
            (prefix/target).write_bytes((root/'Reference'/source).read_bytes())
        section, history, original = replay(repo, prefix, scratch/'Prefix.json')
        prefix_proof = json.loads((scratch/'Prefix.json').read_bytes())
    assert len(original) == 148
    log = [r.split(';') for r in (root/'Native/ControlProbe.txt').read_text('utf-8-sig').splitlines()]
    events = {r[1]: r for r in log if r[0] == 'CORNER_STEP'}
    coordinates = {r[1]: float(r[2]) for r in log if r[0] == 'CORNER_COORDINATE'}
    orientation = {r[1]: r for r in log if r[0] == 'CORNER_ORIENTATION'}
    assert set(events) == set(coordinates) == {'FaceReadOnly', 'Incoming', 'Outgoing'}
    assert all(r[2] == 'True' for r in events.values())
    proof = {'prefix': prefix_proof, 'states': [], 'physical_capacity_certified': False,
             'external_equilibrium_seed_used': False, 'working_algorithm_changed': False}
    face, net, loads, centers = TestRead(root/'Native', '.Face')
    assert len(face) == 1 and face[0][0] == 'FaceReadOnly'
    label, field = face[0]
    _, record = TestState(section, history, field, loads[label], net[label], centers[label], strict=True)
    h = boundary(section, history, field)[0]
    assert abs(h) < 1e-9 and abs(h-coordinates[label]) < 2e-10
    proof['readonly_face'] = dict(record, label=label, Qy_N=float(loads[label][5]), principal_MPa=h)
    fields, net, loads, centers = TestRead(root/'Native', '')
    assert [r[0] for r in fields[:2]] == ['Incoming', 'Outgoing']
    data = [r.split(';') for r in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    projections = {r[1]: np.asarray(r[2:], float) for r in data if r[0] == 'CONTROL_PROJECTION'}
    targets = {r[1]: float(r[2]) for r in data if r[0] == 'CORNER_TARGET'}
    previous, current = original[-2][1], original[-1][1]
    for label, field in fields:
        proposed, record = TestState(section, history, field, loads[label], net[label], centers[label], strict=(label in events))
        if label in events:
            h = boundary(section, history, field)[0]; target = float(events[label][3])
            assert abs(h-target) < 1e-9 and abs(h-coordinates[label]) < 2e-10 and h*target > 0.
            record.update(principal_MPa=h, principal_target_MPa=target)
        else:
            control = abs(float(30000.*(projections[label]@field-targets[label])))
            assert control <= record['tolerance_MPa']
            record['control_error_MPa'] = control
        reference = np.sqrt(metric(section, current-previous, current-previous))
        advance = metric(section, current-previous, field-current)/reference
        assert abs(advance-float(orientation[label][3])) < 2e-12
        assert (advance > 0.) == (orientation[label][2] == 'True')
        if label.startswith('Post'): assert advance > 0.
        record.update(label=label, Qy_N=float(loads[label][5]), signed_spatial_advance=advance,
                      twist_rad_per_m=float(1000.*field[3]/section.radius))
        proof['states'].append(record)
        history = proposed; previous, current = current, field
    count, = [r for r in log if r[0] == 'CORNER_POST_COUNT']
    posts = [r for r in log if r[0] == 'CORNER_POST']
    accepted = len(fields)-2
    assert int(count[1]) == accepted and int(count[3]) == 32
    assert [r[1] for r in posts[:accepted]] == [r[0] for r in fields[2:]]
    assert all(r[2] == 'True' for r in posts[:accepted])
    proof.update(accepted_post_steps=accepted, requested_post_steps=32, completed_all_requested_steps=(accepted == 32),
                 rejected_post_steps=[r[1] for r in posts if r[2] != 'True'],
                 readonly_face_not_committed=True, incoming_history_committed_before_outgoing=True)
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE CORNER VERIFIED', len(fields), 'post_steps', accepted, 'capacity', False, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True); args = parser.parse_args()
    TestValidate(args.repo.resolve(), args.root.resolve(), args.out.resolve())
