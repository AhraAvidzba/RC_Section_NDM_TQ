"""ДЛЯ ТЕСТОВ: готовит нативное решение входящей и исходящей сторон спектрального события без переноса внешнего поля."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Использует рабочий решатель, его нелинейный контроль и собственную историю 148 полей; дополнительные методы только тестовые."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestOriented148Probes.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'; original = (root/name).read_bytes()
    code = original.decode('utf-8-sig').replace('\r\n', '\n')+'\n'+(here/'TestNativePrincipalStep.bas.txt').read_text('utf-8')
    (root/name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['test_only_instrumentation'] = {name: {'before': sha256(original).hexdigest().upper(), 'purpose': 'Expose existing principal-coordinate step for native event experiment only'}}
    name = 'tests/modTestMVT2ProductionASDTest.bas'; code = (root/name).read_text('utf-8-sig')
    begin = code.index('Private Function RunControlProbesTest('); end = code.index('\nEnd Function', begin)+len('\nEnd Function')
    replacement = (here/'TestNativeCornerTrace.bas.txt').read_text('utf-8')
    (root/name).write_bytes((code[:begin]+replacement+code[end:]).replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'; code = (root/runner).read_text('utf-8-sig')
    old = "foreach ($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv'))"; assert code.count(old) == 1
    code = code.replace(old, "foreach ($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv','.Face','.Face.Tensor.csv','.Face.Operators.csv'))")
    (root/runner).write_bytes(code.encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledNewtonSolver.cls', name, runner): prep['inputs'][name] = sha256((root/name).read_bytes()).hexdigest().upper()
    for name in ('TestNativePrincipalStep.bas.txt', 'TestNativeCornerTrace.bas.txt', Path(__file__).name):
        (root/name).write_bytes((here/name).read_bytes()); prep['inputs'][name] = sha256((root/name).read_bytes()).hexdigest().upper()
    prep['probe_scope'] = {'prefix_states': 148, 'incoming_and_outgoing': True, 'readonly_face': True, 'post_steps_requested': 32,
        'event_absolute_tolerance_MPa': 1e-9, 'side_principal_targets_MPa': [-1e-8, 1e-8],
        'external_equilibrium_field_seed': False, 'working_algorithm_changed': False, 'physical_capacity_certified': False}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE CORNER TRACE READY; ORIGINAL HISTORY; NO EXTERNAL FIELD SEED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve())
