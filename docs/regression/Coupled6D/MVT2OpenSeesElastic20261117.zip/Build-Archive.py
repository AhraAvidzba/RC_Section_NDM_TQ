"""Build the byte-reproducible, flat MVT2 verification archive."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
FILES = ("Build-Archive.py", "ElasticResult.json", "MVT2Elastic.py", "README.md", "VerificationElastic.json", "Verify-Elastic.py")
OUT = HERE / "MVT2OpenSeesElastic20261117.zip"


def add(archive, name, data):
    entry = ZipInfo(name, (2026, 11, 17, 0, 0, 0))
    entry.create_system = 3
    entry.external_attr = 0o100644 << 16
    entry.compress_type = ZIP_STORED
    archive.writestr(entry, data)


def main():
    records = []
    with ZipFile(OUT, "w") as archive:
        for name in FILES:
            payload = (HERE / name).read_bytes()
            records.append(f"{sha256(payload).hexdigest()}  {name}\n")
            add(archive, name, payload)
        add(archive, "SHA256SUMS", "".join(records).encode("ascii"))
    print(sha256(OUT.read_bytes()).hexdigest().upper(), OUT)


if __name__ == "__main__":
    main()
