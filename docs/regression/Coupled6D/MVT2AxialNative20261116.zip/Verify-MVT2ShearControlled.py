"""Independent native verification of the measured MVT2 secant predictions and rollback."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import sys
import csv
import json
import math

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def read_native(path,encoding="cp1251"):
    tables=defaultdict(list)
    for marker,*row in csv.reader(path.read_text(encoding=encoding).splitlines(),delimiter=";"):
        tables[marker].append(row)
    return tables


def verified_states(tags):
    fields, stations = {}, defaultdict(dict)
    for name, history, q, *x in tags["B_TANGENT_FIELD"]:
        assert name not in fields and len(x) == 60
        fields[name] = (int(history), float(q), tuple(map(float, x)))
    for name, point, side, *row in tags["B_TANGENT_STATION"]:
        key = int(point), int(side)
        assert key not in stations[name] and len(row) == 19
        stations[name][key] = tuple(map(float, row))
    raw_r = vec(tags, "B_TANGENT_RESIDUAL")
    raw_force = {name: tuple(map(float, row)) for name, *row in tags["B_BOUND_ACTUAL"]}
    raw_norm = {name: float(value) for name, value in tags["B_BOUND_NORM"]}
    output = {}
    assert set(fields) == set(stations) == set(raw_r) == set(raw_force) == set(raw_norm)
    for name, (history, q, x) in fields.items():
        assert history == 24 and len(stations[name]) == 135
        rows, actual, strain_error = reconstruct(x, q, stations[name])
        error = peak(diff(rows, raw_r[name]))
        assert strain_error < 4e-15 and error < 3e-10
        assert max(abs(a-b)/s for a,b,s in zip(actual, raw_force[name], SCALES, strict=True)) < 4e-12
        signed = diff(actual, force(q))
        efforts = tuple(r/s for r, s in zip(signed, SCALES, strict=True))
        residual = (*rows[:56], *efforts)
        gauge_norm = MODULUS*peak(rows[56:])
        tol = 5e-7*(1.+peak(loading(q)))
        near(max(peak(residual), gauge_norm),raw_norm[name], 4e-10)
        assert gauge_norm <= tol
        output[name] = {"q": q, "field": x, "r": residual, "gauge_MPa": gauge_norm, "tol_MPa": tol,
            "signed_force_N_Nmm": signed, "norm_MPa": peak(residual), "reconstruction_error_MPa": error,
            "geometry": {key: row[:3] for key, row in stations[name].items()}}
    return output, stations


def tensor_radius(field, geometry):
    maximum = 0.
    for (_, side), (x, y, _) in geometry.items():
        strain = strain_at(field, operators(x, y), side)
        maximum = max(maximum, peak(s/(1. if i < 3 else math.sqrt(2.)) for i, s in enumerate(strain)))
    return maximum


HERE=Path(__file__).resolve().parent
NATIVE=HERE/'Native'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def verify_run(prep):
    build=read(HERE/'docs/regression/CodeUpdate.json')
    compiler=read(HERE/'CompileClosure.json')
    owner=read(NATIVE/'MVT2.txt.Ownership.json')
    watch=read(NATIVE/'MVT2.txt.ProcessClosure.json')
    receipt=read(NATIVE/'RunReceipt.json')
    final=watch['Closure']['FinalState']
    assert build['Compiled'] and build['Modules']==['modTestCoupledExperiment'] and not build['ProductionChanged']
    assert build['ProductionSHA256']==prep['book_sha256'] and compiler['State']=='Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==build['WorkbookSHA256']
    assert watch['Passed'] and watch['ChildExitCode']==receipt['native_exit']==0 and watch['ChildHasExited']
    assert final['State']=='Absent' and final['PID']==owner['PID'] and final['StartTicksUTC']==owner['StartTicksUTC']
    assert 'TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0' in (NATIVE/'MVT2.txt').read_text(encoding='utf-8-sig')
    if '--offline' not in sys.argv:
        assert digest(HERE/'docs/regression/Diagnostic.xlsm')==build['WorkbookSHA256']
    return compiler,final,receipt['wall_seconds']


def verify_steel(tags, native, stations, accepted):
    steel=defaultdict(dict)
    for name,point,side,ax,e,concrete,sigma in tags['B_BOUND_STEEL']:
        key=int(point),int(side)
        assert key not in steel[name]
        steel[name][key]=int(ax)-1,float(e),float(concrete),float(sigma)
    assert set(steel)==set(native)
    peaks={}
    for name,stress in steel.items():
        assert len(stress)==60
        for (point,side),(ax,e,concrete,sigma) in stress.items():
            row=stations[name][point,side]
            x,y,area=row[:3]
            assert ax==(2 if point<=29 else 1 if abs(x)>abs(y) else 0)
            near(e,row[7+ax],4e-16)
            near(sigma,row[13+ax]+concrete,4e-10)
            near(sigma,200000.*e,4e-8)
            limit=498. if point<=29 else 450.
            assert abs(sigma)<limit
            block=operators(x,y)
            assert max(abs(strain_at(q,block,side)[ax])*200000. for q in accepted.values())<limit
        peaks[name]=max(abs(row[3]) for row in stress.values())
    return peaks


def main():
    prep=read(HERE/'Preparation.json')
    compiler,owner,wall=verify_run(prep)
    assert digest(HERE/'Replay.csv')==prep['replay_sha256']
    assert digest(HERE/'tests/modTestCoupledExperiment.bas')==prep['module_sha256']
    assert all(digest(HERE/name)==value for name,value in prep['prior_input_sha256'].items())
    tags=read_native(NATIVE/'MVT2.csv')
    native,stations=verified_states(tags)
    earlier,early_stations=verified_states(read_native(HERE/'PreviousNative.csv','ascii'))
    old_anchor=earlier['MeasuredCombination']
    archived=list(csv.reader((HERE/'Replay.csv').read_text().splitlines(),delimiter=';'))[1:]
    accepted=vec(tags,'MVT2_CONTROL_FIELD')
    assert len(accepted)==len(archived)==24
    for i,r in enumerate(archived,1):
        assert int(r[0])==i and peak(diff(tuple(map(float,r[9:])),accepted[f'Replay{i}']))<1e-15
    [[qbase,qtrial]]=tags['B_TANGENT_LOAD']
    qbase,qtrial=map(float,(qbase,qtrial))
    near(qbase,float(archived[-1][2]),2e-13)
    near(qtrial,qbase+(qbase-float(archived[-2][2]))/64.,2e-13)
    anchors=['Base24','Restored24','AxialCompPlus/Rollback','AxialCompMinus/Rollback']
    for name in anchors:
        assert native[name]==native['Base24'] and native[name]['q']==qbase
        assert native[name]['field']==accepted['Replay24'] and stations[name]==stations['Base24']
    assert tags['B_TANGENT_END']==[['24',f'{qbase:g}']] or (len(tags['B_TANGENT_END'])==1 and tags['B_TANGENT_END'][0][0]=='24' and float(tags['B_TANGENT_END'][0][1])==qbase)
    anchor=native['Anchor']
    assert anchor['q']==old_anchor['q']==qtrial and anchor['geometry']==old_anchor['geometry']
    assert peak(diff(anchor['field'],old_anchor['field']))<3e-15
    assert peak(diff(anchor['r'],old_anchor['r']))<4e-10
    assert max(peak(diff(x,early_stations['MeasuredCombination'][key])) for key,x in stations['Anchor'].items())<3e-9
    tol=anchor['tol_MPa']; caps=tuple(max(tol,abs(v)) for v in anchor['r'][56:])
    [[r0_log,tol_log]]=tags['B_MEASURE_ORIGIN']
    near(float(r0_log),anchor['norm_MPa'],4e-10); near(float(tol_log),tol,5e-15)
    [[name,*native_caps]]=tags['B_MEASURE_CAPS']
    assert name=='Anchor' and peak(diff(tuple(map(float,native_caps)),caps))<4e-10
    work=read(HERE/'WorkItem.json')
    near(work['N_anchor_N'],anchor['signed_force_N_Nmm'][0],3e-7)
    near(work['tolerance_MPa'],tol,5e-15)
    near(work['native_numerical_force_scale_at_tolerance_N'],tol*AREA,1e-10)
    delta=tuple(work['increment_nonzero_1_based'].get(str(k),0.) for k in range(1,61))
    expected_rows=list(csv.reader((HERE/'Fields.csv').read_text().splitlines(),delimiter=';'))[1:]
    planned={name:(float(q),tuple(map(float,x))) for name,q,*x in expected_rows}
    assert list(planned)==['Centre','AxialCompPlus','AxialCompMinus'] and planned['Centre'][0]==qtrial
    assert peak(diff(planned['Centre'][1],anchor['field']))<3e-15
    assert set(native)==set(anchors+['Anchor','AxialCompPlus','AxialCompMinus'])
    inputs={name:float(radius) for name,radius in tags['B_MEASURE_INPUT']}
    assert set(inputs)=={'AxialCompPlus','AxialCompMinus'}
    native_status={name:tuple(map(int,v)) for name,*v in tags['B_MEASURE_STATUS']}
    native_effort={name:tuple(map(float,v)) for name,*v in tags['B_MEASURE_RELATIVE_EFFORTS']}
    assert set(native_effort)==set(native_status)==set(inputs)
    steel=verify_steel(tags,native,stations,accepted)
    reports={}
    for name,sign in (('AxialCompPlus',1.),('AxialCompMinus',-1.)):
        q,field=planned[name];state=native[name]
        assert state['q']==q==qtrial
        assert peak(diff(state['field'],field))<3e-15
        expected=tuple(a+sign*b for a,b in zip(planned['Centre'][1],delta,strict=True))
        assert peak(diff(expected,field))<3e-15
        radius=tensor_radius(diff(field,planned['Centre'][1]),anchor['geometry'])
        near(radius,work['physical_tensor_component_cap'],5e-15)
        near(radius,inputs[name],5e-15)
        assert radius<=1e-8+4e-16
        signed=state['r'][56:]
        assert peak(diff(signed,native_effort[name]))<4e-10
        violations=[key for key,v,limit in zip(EFFORT_NAMES,signed,caps,strict=True) if abs(v)>limit+4e-10]
        if not any(abs(abs(v)-c)<4e-10 for v,c in zip(signed,caps,strict=True)):
            assert native_status[name][1]==int(not violations)
        dr=diff(state['r'],anchor['r'])
        dn=state['signed_force_N_Nmm'][0]-anchor['signed_force_N_Nmm'][0]
        near(dn,dr[0]*AREA,4e-7)
        gradient=dr[52:56]
        gauge=state['gauge_MPa']
        true_norm=max(state['norm_MPa'],gauge)
        full=true_norm<=tol
        decline=true_norm<anchor['norm_MPa']
        assert native_status[name][0]==int(full) and native_status[name][2]==int(decline)
        row_contributions=[]
        for key,row in stations[name].items():
            if key[1]==0:
                old=stations['Anchor'][key]
                de=row[7+2]-old[7+2]
                near(de,sign*delta[0],5e-16)
                row_contributions.append((key[0],row[2]*(row[15]-old[15])))
        near(math.fsum(v for ip,v in row_contributions),dn,4e-7)
        report={
            'tensor_radius':radius,'N_change_N':dn,'N_signal_expected_sign_and_above_original_scale':sign*dn>tol*AREA,
            'absolute_error_of_the_axial_prediction_N':abs(dn-sign*work['expected_first_order_N_increment_N']),
            'gradient_rows_53_56_MPa':state['r'][52:56],'gradient_row_changes_MPa':gradient,
            'gradient_compensation_within_original_tol':peak(gradient)<=tol,
            'gauge_MPa':gauge,'true_max_MPa':true_norm,'original_tol_MPa':tol,'full_equilibrium':full,
            'weak_row_governing':max(range(56),key=lambda i:abs(state['r'][i]))+1,
            'largest_weak_changes' : [{'row':i+1,'delta_MPa':dr[i],'residual_MPa':state['r'][i]}
                for i in sorted(range(56),key=lambda i:abs(dr[i]),reverse=True)[:8]],
            'effort_error_N_Nmm':state['signed_force_N_Nmm'],'worsened_efforts':violations,
            'genuine_progress_at_fixed_caps':decline and not violations,'highest_steel_stress_MPa':steel[name],
            'axial_increment_by_central_station_N':row_contributions,
            'full_residual_MPa':state['r'],'full_action_MPa':dr,
        }
        reports[name]=report
    plus,minus=(reports[n] for n in ('AxialCompPlus','AxialCompMinus'))
    even=[a+b for a,b in zip(plus['full_action_MPa'],minus['full_action_MPa'],strict=True)]
    final={'source_workbook_sha256':prep['book_sha256'],'replay_sha256':prep['replay_sha256'],
        'native_trace_sha256':digest(NATIVE/'MVT2.csv'),'compiler':compiler,'owner':owner,'native_wall_s':wall,
        'target_Qy_kN':qtrial,'qLastAccepted_kN':qbase,'anchor_norm_MPa':anchor['norm_MPa'],'equilibrium_tolerance_MPa':tol,
        'effort_cap_MPa':caps,'anchor_signed_force_error_N_Nmm':anchor['signed_force_N_Nmm'],
        'anchor_r_vector_MPa':anchor['r'],'both_exact_rollbacks':True,'native_results':reports,
        'independent_axial_direction_measured':all(x['N_signal_expected_sign_and_above_original_scale'] for x in reports.values()),
        'frozen_gradient_compensation_confirmed':all(x['gradient_compensation_within_original_tol'] for x in reports.values()),
        'signed_even_part_peak_MPa':peak(even),'signed_even_part_peak_row':max(range(62),key=lambda k:abs(even[k]))+1,
        'physical_limit_confirmed':False}
    path=HERE/'Verification.json'
    path.write_text(json.dumps(final,indent=2)+'\n',encoding='utf8')
    print(path,digest(path))


if __name__=='__main__':
    main()
