"""Replay the archived A2 field-seed proof and normalize the scalar baseline comparison."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import math
import subprocess

HERE=Path(__file__).resolve().parent
BOOK='workbook/output/RC_Section_NDM.xlsm'


def digest(data):
    return sha256(data).hexdigest().upper()


def read(name):
    return json.loads((HERE/name).read_bytes())


def compare(a,b):
    if isinstance(a,dict):
        assert set(a)==set(b)
        for key in a:
            compare(a[key],b[key])
    elif isinstance(a,list):
        assert len(a)==len(b)
        for x,y in zip(a,b):
            compare(x,y)
    elif isinstance(a,float):
        assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-13),(a,b)
    else:
        assert a==b,(a,b)


def main(repo):
    seal=read('Manifest.json')
    fixture=read('Fixture.json')
    assert seal['schema']=='A2FieldSeedPair/v1' and seal['sourceWorkbookOmitted']
    assert fixture['historicalGit']==seal['historicalGit']
    assert all(digest((HERE/name).read_bytes())==expected for name,expected in seal['files'].items())
    assert all(seal['files'][name]==expected for name,expected in fixture['frozen'].items() if name!=BOOK)
    assert fixture['workbookSHA256']==fixture['frozen'][BOOK]==seal['sourceWorkbookSHA256']
    for name,expected in {BOOK:fixture['workbookSHA256'],**fixture['sectionSources']}.items():
        data=subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{seal["historicalGit"]}:{name}'])
        assert digest(data)==expected,name

    original=read('A2FieldSeedVerification.json')
    source=HERE/'Verify-Field.py'
    code=source.read_text(encoding='utf-8')
    insert='    ns={\'__name__\':\'verify_field\','
    assert code.count(insert)==1
    replace="    code=code.replace('A2FieldSeedVerification.json','Replay-A2FieldSeedVerification.json')\n"
    code=code.replace(insert,replace+insert)
    namespace={'__file__':str(source),'__name__':'detached_field_replay'}
    exec(compile(code,str(source),'exec'),namespace)
    namespace['namespace']()['verify']()
    rebuilt=read('Replay-A2FieldSeedVerification.json')
    compare(original,rebuilt)

    prior=read('ScalarVerification.json')['arms']['DefaultCurrent']
    current=rebuilt['arms']['DefaultCurrent']
    keys=('status','code','solved','iterations','equilibriumEvaluations','solverReportedNormMPa','lambda','wrenchesN_Nmm',
          'independentIntegratedWrenchesN_Nmm','steelUtilization','maximumIndependentBalanceMPa')
    checks={key:prior[key]==current[key] for key in keys}
    assert all(checks.values())
    assert rebuilt['rightStates']['noInputArmReproducesArchive'] is False
    data={'noInputArmReproducesScalarArchiveAfterJSONNormalization':True,'exactAgreements':checks,
          'originalIndicatorUsedIncompatibleSequenceTypes':True,
          'originalResultSHA256':digest((HERE/'A2FieldSeedVerification.json').read_bytes())}
    output=(json.dumps(data,indent=2)+'\n').encode('utf-8')
    (HERE/'Replay-FieldBaseline.json').write_bytes(output)
    print('A2_FIELD_SEED_PORTABLE_PASS',digest(output))


if __name__=='__main__':
    parser=ArgumentParser()
    parser.add_argument('--repo-root',type=Path,required=True)
    main(parser.parse_args().repo_root.resolve())
