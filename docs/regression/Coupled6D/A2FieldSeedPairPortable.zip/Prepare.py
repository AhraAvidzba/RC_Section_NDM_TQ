"""Create a private two-module field-seed fixture from the measured scalar pair."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
DONOR = HERE.parent/'a2seed'
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
CORE = 'src/Solver/CCoupledNewtonSolver.cls'
MODULE = 'tests/modTestCoupledExperiment.bas'
ROOT_SHA = '5657630AABEF0AC4FF1EEB00C1EFC128A091583AAA0D6E340276DED500CA73C8'
DONOR_SHA = '55F52A46168A537D8D266BFF939971905CCEB4ED43D2236F3339BEF01AF9F2B0'


def digest(value):
    return sha256(value.read_bytes() if isinstance(value, Path) else value).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def blob(repo, ref, name):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{ref}:{name}'])


def replace_one(text, old, new):
    assert text.count(old)==1,old
    return text.replace(old,new)


def put(name, data):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
    return digest(path)


def module_text(text):
    return (text.rstrip()+'\n').replace('\n','\r\n').encode('utf-8-sig')


def solver_overlay(original):
    start=original.index('Friend Function TryDeformationStep(')
    end=original.index('End Function',start)
    part=original[start:end]
    part=replace_one(part,'Optional ByVal consistentControl As Boolean = False) As Boolean',
                     'Optional ByVal consistentControl As Boolean = False, Optional ByRef initialField As Variant) As Boolean')
    default='    TryDeformationStep = SolveStep(load, initialLambda, absoluteTolerance, relativeTolerance, maxIterations, recoverYieldControl)'
    part=replace_one(part,default,'''    If IsMissing(initialField) Then
'''+'    '+default+'''
    Else
        TryDeformationStep = SolveStep(load, initialLambda, absoluteTolerance, relativeTolerance, maxIterations, _
            recoverYieldControl, initialField)
    End If''')
    return original[:start]+part+original[end:]


def test_entry(original):
    section=original.replace('RunTestA2SeedPair','RunTestA2FieldSeedPair').replace('A2SeedPair.csv','A2FieldSeedPair.csv')
    section=section.replace('TOTAL_A2_SEED_PAIR','TOTAL_A2_FIELD_SEED_PAIR')
    section=replace_one(section,'''    Dim secantSeed As Double: secantSeed = currentSeed + ratio * ((torque(27) - torque(26)) / 100000000#)
''','')
    section=replace_one(section,'''    Dim trialTwist As Double: trialTwist = Val(trialText)
''','''    Dim options() As String: options = Split(trialText, ";")
    Dim repeatBaseline As Boolean
    If UBound(options) = 1 Then repeatBaseline = (options(1) = "Repeat")
    If UBound(options) > 1 Or (UBound(options) = 1 And Not repeatBaseline) Then _
        Err.Raise 5, , "Неизвестный режим повтора A2."
    Dim trialTwist As Double: trialTwist = Val(options(0))
''')
    section=replace_one(section,'        ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc)\n',
        '        ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc) & ";" & CStr(Abs(CLng(repeatBaseline)))\n')
    start=section.index('    Dim ordinarySolved As Boolean')
    end=section.index('    Close #traceFile',start)
    section=section[:start]+'''    Dim previous() As Double, predicted() As Double, warm As Variant
    previous = fields(26): predicted = fields(27)
    For j = 1 To 56: predicted(j) = predicted(j) + ratio * (predicted(j) - previous(j)): Next j
    predicted(4) = measure ' Закручивание задано в той же безразмерной координате, что и в решателе.
    warm = predicted
    Dim ordinarySolved As Boolean, secantSolved As Boolean, repeatedSolved As Boolean
    Dim ordinaryRight() As Double, secantRight() As Double, repeatedRight() As Double
    ordinarySolved = TryA2SeedArmTest("DefaultCurrent", traceFile, operators, steel, fields, saved, gt, gc, measure, currentSeed, ordinaryRight)
    secantSolved = TryA2SeedArmTest("FieldSecant", traceFile, operators, steel, fields, saved, gt, gc, measure, currentSeed, secantRight, warm)
    If ordinarySolved And secantSolved Then
        For j = 1 To 56
            If Abs(ordinaryRight(j) - secantRight(j)) > 0.000000005 Then repeatBaseline = True
        Next j
    Else
        repeatBaseline = True
    End If
    If repeatBaseline Then _
        repeatedSolved = TryA2SeedArmTest("DefaultRepeat", traceFile, operators, steel, fields, saved, gt, gc, measure, currentSeed, repeatedRight)
'''+section[end:]
    section=replace_one(section,'ByVal label As String, ByVal consistent As Boolean, ByVal traceFile As Integer, _',
                        'ByVal label As String, ByVal traceFile As Integer, _')
    section=replace_one(section,'        ByVal gt As Double, ByVal gc As Double, ByVal measure As Double, ByVal seed As Double) As Boolean',
                        '        ByVal gt As Double, ByVal gc As Double, ByVal measure As Double, ByVal seed As Double, _\n'+
                        '        ByRef rightField() As Double, Optional ByRef initialField As Variant) As Boolean')
    section=replace_one(section,'''    solveStart = Timer
    solved = solver.TryDeformationStep(offset, direction, projection, measure, seed, lambda, ABS_TOL, REL_TOL, 24, consistentControl:=consistent)
''','''    Dim firstField() As Double: firstField = accepted
    If Not IsMissing(initialField) Then firstField = initialField
    Print #traceFile, "FIRST;" & label & A2SeedVectorTest(firstField)
    solveStart = Timer
    If IsMissing(initialField) Then
        solved = solver.TryDeformationStep(offset, direction, projection, measure, seed, lambda, ABS_TOL, REL_TOL, 24)
    Else
        solved = solver.TryDeformationStep(offset, direction, projection, measure, seed, lambda, ABS_TOL, REL_TOL, 24, initialField:=initialField)
    End If
''')
    section=replace_one(section,'CStr(Abs(CLng(consistent)))','CStr(Abs(CLng(Not IsMissing(initialField))))')
    section=replace_one(section,'''    solver.AcceptStep
    RecordA2SeedStateTest traceFile, label, "Accepted", solver, operators, concrete, center, sides
    TryA2SeedArmTest = True''','''    RecordA2FieldSeedBranchesTest traceFile, label, operators, concrete, sides, found
    solver.AcceptStep
    solver.CopyAccepted rightField
    RecordA2SeedStateTest traceFile, label, "Accepted", solver, operators, concrete, center, sides
    fields.Add rightField
    Dim replayed As Boolean: replayed = solver.ReplayAcceptedFields(fields, 28)
    fields.Remove 28
    If Not replayed Then Err.Raise 5, , "Не восстановлено подтверждённое правое поле A2."
    RecordA2SeedStateTest traceFile, label, "ReplayedRight", solver, operators, concrete, center, sides
    If Not solver.ReplayAcceptedFields(fields, 27) Then Err.Raise 5, , "Не восстановлено исходное левое поле A2."
    RecordA2SeedStateTest traceFile, label, "Restored27", solver, operators, concrete, center, sides
    TryA2SeedArmTest = True''')
    return section


def stage(repo):
    assert HERE.is_relative_to(repo/'tmp') and not (HERE/'Fixture.json').exists()
    assert digest(DONOR/'Fixture.json')==DONOR_SHA and digest(DONOR/'A2SeedVerification.json')==ROOT_SHA
    prior=read_json(DONOR/'Fixture.json')
    assert all(digest(DONOR/name)==checksum for name,checksum in prior['frozen'].items())
    revision=prior['historicalGit']
    assert all(digest(blob(repo,revision,name))==checksum for name,checksum in prior['sectionSources'].items())
    frozen={}
    for name,checksum in prior['frozen'].items():
        if name.startswith('tools/') or name in (BOOK,'Guard-IsolatedOffice.ps1','A2Own27.csv','Reference28.csv'):
            frozen[name]=put(name,(DONOR/name).read_bytes())
    assert put('docs/regression/Diagnostic.xlsm',(HERE/BOOK).read_bytes())==prior['workbookSHA256']
    entry=(DONOR/'A2SeedEntry.bas.txt').read_text(encoding='utf-8-sig')
    original=(DONOR/MODULE).read_text(encoding='utf-8-sig')
    assert original.rstrip().endswith(entry.rstrip())
    core=blob(repo,revision,CORE).decode('utf-8-sig').replace('\r\n','\n')
    updated=solver_overlay(core)
    frozen[CORE]=put(CORE,module_text(updated))
    branch=(HERE/'FieldSeedBranches.bas.txt').read_text(encoding='utf-8-sig')
    generated=original[:original.rfind(entry.rstrip())]+test_entry(entry)+'\n'+branch
    declarations=re.findall(r'(?im)^(?:Public|Private) (?:Function|Sub) (\w+)',generated)
    assert len(declarations)==len(set(x.casefold() for x in declarations)) and max(map(len,generated.splitlines()))<1024
    frozen[MODULE]=put(MODULE,module_text(generated))
    frozen['ScalarVerification.json']=put('ScalarVerification.json',(DONOR/'A2SeedVerification.json').read_bytes())
    frozen['Verify-Scalar.py']=put('Verify-Scalar.py',(DONOR/'Verify-Seed.py').read_bytes())
    for name in ('Prepare.py','Run-Field.ps1','Verify-Field.py','FieldSeedBranches.bas.txt','README.md'):
        frozen[name]=digest(HERE/name)
    for name in ('Native','Temp'):
        (HERE/name).mkdir(exist_ok=True)
    fixture={k:prior[k] for k in ('historicalGit','workbookSHA256','sectionSources','trialTwistRadM')}
    fixture.update({'scalarReferenceSHA256':ROOT_SHA,'macroTimeoutSeconds':120,
                    'modules':['CCoupledNewtonSolver','modTestCoupledExperiment'],'frozen':frozen})
    put('Fixture.json',(json.dumps(fixture,indent=2)+'\n').encode('utf8'))


def check(repo):
    fixture=read_json(HERE/'Fixture.json')
    assert digest(blob(repo,fixture['historicalGit'],BOOK))==digest(repo/BOOK)==fixture['workbookSHA256']
    assert all(digest(blob(repo,'HEAD',name))==expected for name,expected in fixture['sectionSources'].items())
    assert all(digest(HERE/name)==expected for name,expected in fixture['frozen'].items())
    assert {x.stem for loc in ('src','tests') for x in (HERE/loc).rglob('*') if x.is_file()}==set(fixture['modules'])
    print('A2_FIELD_SEED_FIXTURE_PASS',digest(HERE/'Fixture.json'),fixture['frozen'][CORE],fixture['frozen'][MODULE])


if __name__=='__main__':
    parser=ArgumentParser()
    parser.add_argument('--repo-root',type=Path,required=True)
    stage_mode=parser.add_mutually_exclusive_group(required=True)
    stage_mode.add_argument('--stage',action='store_true')
    stage_mode.add_argument('--check',action='store_true')
    args=parser.parse_args()
    root=args.repo_root.resolve()
    if args.stage:
        stage(root)
    check(root)
