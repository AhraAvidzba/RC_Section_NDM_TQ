"""Replay the field-seed proof using the unchanged scalar balance and ownership checks."""
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent


def replace_one(script, old, new):
    assert script.count(old)==1,old
    return script.replace(old,new)


def right_comparison(result,phases,stations,branches,base,peak):
    left,right='DefaultCurrent','FieldSecant'
    if not (result[left].get('accepted') and result[right].get('accepted')):
        return {'classification':'at least one arm not accepted'}
    qleft,qright=phases[left]['Accepted'],phases[right]['Accepted']
    first,second=stations[left,'Accepted'],stations[right,'Accepted']
    a,b=branches[left],branches[right]
    changed=[key for key in a if a[key][:3]!=b[key][:3]]
    q_difference=peak(x-y for x,y in zip(qleft[:56],qright[:56]))
    strain_difference=max(peak(x-y for x,y in zip(a[k][3:],b[k][3:])) for k in base)
    stress_difference=max(peak(x-y for x,y in zip(first[k][:6],second[k][:6])) for k in base)
    rod_difference=max(abs(first[k][8]-second[k][8]) for k in base)
    energy_difference=max(peak(x-y for x,y in zip(first[k][6:8],second[k][6:8])) for k in base)
    torque_difference=abs(result[left]['wrenchesN_Nmm'][3]-result[right]['wrenchesN_Nmm'][3])/1e6
    bounds={'physicalField':5e-9,'pointStrain':5e-8,'pointStressMPa':1e-3,'steelStressMPa':1e-3,
            'damageEnergy':5e-6,'torque_kNm':1e-3}
    values={'physicalField':q_difference,'pointStrain':strain_difference,'pointStressMPa':stress_difference,
            'steelStressMPa':rod_difference,'damageEnergy':energy_difference,'torque_kNm':torque_difference}
    exceeded=[key for key in bounds if values[key]>bounds[key]]
    if exceeded:
        classification='different accepted fields beyond comparison resolution'
    elif changed:
        classification='close accepted fields with different material return flags'
    else:
        classification='same observed branch within comparison resolution'
    return {'classification':classification,'exactRightField':qleft==qright,'exactAcceptedStations':first==second,
            'absoluteDifferences':values,'comparisonResolution':bounds,'exceeded':exceeded,
            'differentReturnFlags':changed,'exactBranchTable':a==b}


def namespace():
    original=HERE/'Verify-Scalar.py'
    code=original.read_text(encoding='utf-8')
    for old,new in {'A2SeedPair':'A2FieldSeedPair', 'A2_SEED_PAIR':'A2_FIELD_SEED_PAIR',
                    'A2_SEED_PROTOCOL_PASS':'A2_FIELD_SEED_PROTOCOL_PASS',
                    'A2SeedVerification.json':'A2FieldSeedVerification.json',
                    'PreCompileA2Seed':'PreCompileA2Field','PreNativeA2Seed':'PreNativeA2Field',
                    "'DefaultSecant'":"'FieldSecant'"}.items():
        code=code.replace(old,new)
    code=replace_one(code,"RECOVERY = ('DefaultRepeat', 'ConsistentCurrent', 'ConsistentSecant')","RECOVERY = ('DefaultRepeat',)")
    code=replace_one(code,"assert metadata['Modules'] == ['modTestCoupledExperiment']",
                     "assert sorted(metadata['Modules']) == sorted(fixture['modules'])")
    code=replace_one(code,"'wallSeconds':timing['wallSeconds']}","'wallSeconds':timing['wallSeconds'],'repeatRequested':timing['repeatRequested']}")
    code=replace_one(code,'tw26,tw27,target,ratio,measure,area,length,gt,gc = vector(setup,9)',
                     'tw26,tw27,target,ratio,measure,area,length,gt,gc,asked = vector(setup,10)\n'+
                     "    assert asked==int(owned['repeatRequested'])")
    code=replace_one(code,'    secant=current+ratio*(current-float(prefix[-2][5])/1e8)',
                     '''    prior=vector(prefix[-2][8:],60)
    secant=list(source_left)
    for i in range(56):
        secant[i]=source_left[i]+ratio*(source_left[i]-prior[i])
    secant[3]=measure''')
    code=replace_one(code,'    phases=defaultdict(dict)', '    phases=defaultdict(dict)\n    branches=defaultdict(dict)')
    code=replace_one(code,"        if tag=='STATION':",'''        if tag=='BRANCH':
            side,point,*pieces=items
            key=(int(side),int(point))
            assert key not in branches[name]
            branch=vector(pieces,9)
            assert branch[0] in (0,1) and branch[1] in (-1,0,1) and branch[2]>=0 and branch[2]==int(branch[2])
            branches[name][key]=branch
        elif tag=='STATION':''')
    code=replace_one(code,"    assert set(groups['STATUS'])==set(groups['DIAGNOSTIC'])==set(groups['REPLAY'])==set(phases)",
        "    assert set(groups['STATUS'])==set(groups['DIAGNOSTIC'])==set(groups['REPLAY'])==set(phases)==set(groups['FIRST'])")
    code=replace_one(code,'''        consistent,seed,solved,internal_status,code,lam,solve,arm=vector(groups['STATUS'][name],8)
        close(seed,secant if name.endswith('Secant') else current,8e-14)
        assert consistent==int(name.startswith('Consistent')) and solved in (0,1) and 0<=solve<=arm''','''        provided,seed,solved,internal_status,code,lam,solve,arm=vector(groups['STATUS'][name],8)
        close(seed,current,8e-14)
        assert provided==int(name=='FieldSecant') and solved in (0,1) and 0<=solve<=arm
        first_field=vector(groups['FIRST'][name],60)
        assert peak(x-y for x,y in zip(first_field,secant if provided else source_left))<=8e-17
        assert first_field[56:]==source_left[56:]''')
    code=replace_one(code,"{'consistentControl':bool(consistent),'initialTorque_kNm':seed*100.,'solved':bool(solved),",
                     "{'consistentControl':False,'fieldPredictorUsed':bool(provided),'initialTorque_kNm':seed*100.,'solved':bool(solved),")
    code=replace_one(code,"                state['independentIntegratedWrenchesN_Nmm']=wrought",'''                state['independentIntegratedWrenchesN_Nmm']=wrought
                assert phases[name]['ReplayedRight']==field and phases[name]['Restored27']==source_left
                right=stations[name,'Accepted']
                replayed=stations[name,'ReplayedRight']
                assert set(replayed)==set(right)==set(branches[name])==set(base)
                max_replay=max(peak(x-y for x,y in zip(replayed[k],right[k])) for k in right)
                assert max_replay<=2e-10 and stations[name,'Restored27']==base
                state.update({'rightReplayed':True,'rightReplayExactlySameStationData':max_replay==0.,
                              'rightReplayMaxStationDataDifference':max_replay,'restoredOriginalH27Exactly':True})''')
    old=code.index('    assert (tuple(cases)==DEFAULT+RECOVERY)')
    end=code.index('    path=NATIVE/',old)
    code=code[:old]+'''    pair=right_comparison(result,phases,stations,branches,base,peak)
    defaults_accepted=all(result[name].get('accepted',False) for name in DEFAULT)
    requested_repeat=bool(asked) or not defaults_accepted or pair['absoluteDifferences']['physicalField']>5e-9
    assert ('DefaultRepeat' in result)==requested_repeat
    if requested_repeat:
        omit={'solverSeconds','armSeconds'}
        reference={k:v for k,v in result['DefaultCurrent'].items() if k not in omit}
        repeated={k:v for k,v in result['DefaultRepeat'].items() if k not in omit}
        assert reference==repeated and phases['DefaultCurrent']==phases['DefaultRepeat']
        assert branches['DefaultCurrent']==branches['DefaultRepeat']
        for phase in phases['DefaultCurrent']:
            assert stations['DefaultCurrent',phase]==stations['DefaultRepeat',phase]
    frozen=read(HERE/'ScalarVerification.json')['arms']['DefaultCurrent']
    baseline=result['DefaultCurrent']
    agrees=all(baseline.get(key)==frozen.get(key) for key in ('solved','status','code','iterations','equilibriumEvaluations',
               'solverReportedNormMPa','lambda','wrenchesN_Nmm'))
    pair['noInputArmReproducesArchive']=agrees
'''+code[end:]
    ns={'__name__':'verify_field','__file__':str(original),'right_comparison':right_comparison}
    exec(compile(code,str(original),'exec'),ns)
    return ns


if __name__=='__main__':
    namespace()['verify']()
