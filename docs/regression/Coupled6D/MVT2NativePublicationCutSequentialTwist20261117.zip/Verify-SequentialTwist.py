"""Восстанавливает две последовательные траектории MVT2 и проверяет спад."""

from argparse import ArgumentParser
from hashlib import sha256
from math import isclose
from pathlib import Path
from zipfile import ZipFile
import json


FOLLOW = 'MVT2NativePublicationCutFollow20261117.zip'
FOLLOW_SHA = '9F55DE3FC0B1B652DD1ED9683507423ADE4DF6AB3B008D9590EE1D9327F9864E'
RUNS = {
    'SequentialTwist': ('E23AD9A5C0026AA8FC6790E06C84C3E4FB1A60CEEB557E7E1610F936C574EE85', 5, 2., .25, .5),
    'RefinedTwist': ('553469EDA86EABFE8A39BFB52E08AFF74DB7593F7946B98DF89218444D57F729', 8, 1., .125, .125),
}


def digest(wire):
    return sha256(wire).hexdigest().upper()


def close(a, b, limit):
    return isclose(a, b, rel_tol=0., abs_tol=limit)


def verify_run(root, mode, follow, reference):
    utility, recovery, old_fields, baseline, baseline_tensors, mesh = reference
    native = root / 'Native'
    book, count, length_factor, first_step, cap = RUNS[mode]
    preparation = follow['read_json'](root / 'Preparation.json')
    assert preparation['follow_mode'] == mode and preparation['follow_history_archive'] == follow['SPLIT_SHA']
    assert preparation['source_book_sha256'] == recovery['BOOK_SHA']
    history_bytes = (root / 'Replay.Fields.csv').read_bytes()
    assert digest(history_bytes) == follow['HISTORY_SHA']
    for leaf in ('Replay.Fields.csv', 'Run-Native.ps1', 'tests/modTestMVT2GaussSpan.bas'):
        assert digest((root / leaf).read_bytes()) == preparation['inputs'][leaf]
    history = [row.split(';') for row in history_bytes.decode('ascii').splitlines()]
    assert [row[0] for row in history] == [*old_fields, *list(baseline['F'])[1:]]
    for phase, q, torque, *values in history:
        expected = old_fields[phase] if phase in old_fields else baseline['F'][phase]
        assert tuple(map(float, values)) == expected
        if phase in baseline_tensors:
            assert (float(torque), float(q)) == baseline_tensors[phase][:2]

    log = (native / 'MVTGaussMixed.txt').read_text(encoding='utf-8-sig')
    assert follow['read_json'](root / 'CodeUpdate.json')['WorkbookSHA256'] == book
    status, pid, ticks = follow['owner_check'](root, log, recovery)
    assert status == 'completed'
    operators = utility['read_operators']((native / 'Operators.csv').read_bytes())
    frames = utility['read_tensor_frames']((native / 'MVTGaussMixed.Tensor.csv').read_bytes(), 45)
    rows = [row.split(';') for row in (native / 'MVTGaussMixed.csv').read_text(encoding='cp1251').splitlines()]
    assert recovery['geometry'](rows) == mesh
    assert all(operators[k] == baseline[k] for k in 'GLBSR')
    assert [row for row in rows if row[0] == 'MVT2_FOLLOW_REPLAY'] == [['MVT2_FOLLOW_REPLAY', '28', '22392.578125']]

    start = follow['LAST']
    first = operators['F']['Replay']
    assert first == baseline['F'][start]
    assert frames['Replay'][:2] == baseline_tensors[start][:2]
    delta = max(abs(a-b) for side in (-1, 0, 1) for p in mesh[1]
                for a,b in zip(operators['H']['Replay',side,p], baseline['H'][start,side,p], strict=True))
    assert delta < 5e-12
    physical_scale = 1000. / mesh[0][3]
    previous_axis, theta = baseline['F']['Split10'][3], first[3]
    base_width = theta - previous_axis
    q, previous_q = 22.392578125, 22.3828125
    step = base_width * first_step
    end = theta + length_factor * base_width
    proof = recovery['equations']('Replay', frames['Replay'], operators, mesh)
    accepted = [{'phase':'Replay', 'Qy_N':q*1000., 'fraction':0., 'twist_rad_per_m':theta * physical_scale,
                 'equilibrium':proof}]
    trials = [row for row in rows if row[0] == 'MVT2_SEQUENTIAL_TWIST']
    assert len(trials) == count
    for i,row in enumerate(trials, 1):
        _, phase, old, target, raw_q, guess, returned, success, internal, code, *details = row
        assert phase == f'TwistStep{i}' and ';'.join(row) in log
        assert success == 'True'
        wanted = min(theta + step, end)
        assert close(float(old), theta, 3e-17) and close(float(target), wanted, 3e-17)
        assert close(float(raw_q), q, 1e-12)
        assert close(float(guess), q + (wanted-theta) / (theta-previous_axis) * (q-previous_q), 2e-11)
        work = follow['trial_work'](details, success, internal, code)
        assert work['accepted']
        proof = recovery['equations'](phase, frames[phase], operators, mesh)
        new_theta = operators['F'][phase][3]
        assert new_theta > theta and close(new_theta, wanted, 3e-17)
        assert abs(new_theta - wanted) * 30000. <= proof['tolerance_MPa']
        result_q = frames[phase][1]
        assert frames[phase][0] == follow['TORQUE'] and close(result_q, 1000. * float(returned), 1e-8)
        accepted.append({'phase':phase, 'Qy_N':result_q, 'fraction':(new_theta-first[3])/base_width,
                         'twist_rad_per_m':new_theta * physical_scale, 'equilibrium':proof,
                         'iterations':work['iterations'], 'evaluations':work['evaluations']})
        previous_axis, theta = theta, new_theta
        previous_q, q = q, float(returned)
        step = min(step * 2., cap * base_width)
    assert close(theta, end, 3e-17)
    names = [item['phase'] for item in accepted]
    assert list(frames) == list(operators['F']) == names
    assert set(operators['H']) == {(phase, side, p) for phase in names for side in (-1,0,1) for p in mesh[1]}
    finish, = [row for row in rows if row[0] == 'CASE_FINISHED']
    assert finish[2] == 'True' and 0 < float(finish[3]) < 165
    assert 'TOTAL_MVT2_GAUSS_SPAN: passed=1; failed=0; target_reached=True' in log
    peak = max(range(len(accepted)), key=lambda i: accepted[i]['Qy_N'])
    assert 0 < peak < len(accepted)-1
    assert all(b['Qy_N'] > a['Qy_N'] for a,b in zip(accepted[:peak], accepted[1:peak+1], strict=True))
    assert all(b['Qy_N'] < a['Qy_N'] for a,b in zip(accepted[peak:-1], accepted[peak+1:], strict=True))
    return {'run':mode,'excel_seconds':float(finish[3]), 'closed_pid':pid, 'closed_ticks':ticks,
            'restored_net_stress_delta_MPa':delta, 'accepted':accepted,'maximum':accepted[peak],
            'end':accepted[-1], 'physical_limit_established':False}


def main(repo, root):
    path = repo / 'docs/regression/Coupled6D' / FOLLOW
    assert digest(path.read_bytes()) == FOLLOW_SHA
    follow = {'__name__': '__pinned__'}
    with ZipFile(path) as bundle:
        exec(compile(bundle.read('Verify-NativeFollow.py'), FOLLOW, 'exec'), follow)
    reference = follow['read_references'](repo)
    result = {mode: verify_run(root / mode, mode, follow, reference) for mode in RUNS}
    coarse, fine = (result[name]['accepted'] for name in RUNS)
    difference = {}
    for common in (.25, .75):
        col_a, = [row for row in coarse if close(row['fraction'], common, 2e-10)]
        col_b, = [row for row in fine if close(row['fraction'], common, 2e-10)]
        assert close(col_a['twist_rad_per_m'], col_b['twist_rad_per_m'], 3e-16)
        difference[str(common)] = col_b['Qy_N'] - col_a['Qy_N']
    return {'comparison':difference, 'path_results':result}


if __name__ == '__main__':
    options = ArgumentParser(description=__doc__)
    options.add_argument('--repo', type=Path, required=True)
    options.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    options.add_argument('--report', type=Path, required=True)
    args = options.parse_args()
    result = main(args.repo.resolve(), args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(result, output, indent=2, sort_keys=True, allow_nan=False)
        output.write('\n')
    print('MVT2 SEQUENTIAL TWIST OFFLINE PASS 13')
