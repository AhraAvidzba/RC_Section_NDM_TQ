"""ДЛЯ ТЕСТОВ. Проверяет реальное подключение малой поправки и раздельные отрицательные гипотезы."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestRead(file):
    """Читает точные закреплённые признаки каждого законченного этапа."""
    return json.loads(file.read_text('utf-8-sig'))


def TestBaseline(repo, root):
    """Подтверждает происхождение исходных нативных полей, не подставляя другую историю."""
    record = TestRead(root / 'Baseline/Origin.json')
    assert sha256((repo / 'docs/regression/Coupled6D' / record['archive']).read_bytes()).hexdigest().upper() == record['sha256']
    for name, entry in record['entries'].items():
        assert sha256((root / 'Baseline' / name).read_bytes()).hexdigest().upper() == entry['sha256']


def TestCheckpoint(root):
    """Отвергает оставшуюся от общего сборщика метку другой базы, даже при правильных фактических исходниках."""
    scope = TestRead(root / 'Scope.json')
    assert scope == TestRead(root / 'SourceCheckpoint.json'), 'Scope/source checkpoint mismatch'
    assert scope['base'] == 'd779a5b'
    for key in TestRead(root / 'Cases.json'):
        assert TestRead(root / 'Cases' / key / 'Preparation.json')['base_stage_commit'].startswith('d779a5b'), key


def TestNative(repo, root, output):
    """Сверяет все 30 компонентов расчёта, импортированные тесты и личности изолированных Excel."""
    shared = run_path(str(root / 'Check-TestMaterialRoundoff.py'))
    TestCheckpoint(root)
    shared['TestFiles'](root)
    source, _ = run_path(str(root / 'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root / 'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    canonical = run_path(str(root / 'Canonical-TestCoreVBA.py'))
    normal = lambda text: canonical['TestCanonical'](text)[0]
    controls = [normal('x=1e-8') == normal('x=0.00000001'), normal('x=1e-8') != normal('x=1e-7'),
        normal('x=200000#') != normal('x=200000'), normal('s="ε"') != normal('s="?"'),
        normal('s="1e-8"') != normal('s="0.00000001"'), normal("x=1 'бетон") != normal("x=1 'сталь"),
        normal("x=1 'ν") == normal("x=1 '?"), normal('x=10000000000#') != normal('x=10000000001#')]
    assert all(controls)
    core_body = canonical['TestWrap'](body)
    study = TestRead(root / 'Scope.json')['scope'] == 'study'
    cases = {}
    for key in TestRead(root / 'Cases.json'):
        folder = root / 'Cases' / key
        result = shared['TestSourceComparison'](repo, root, folder, source, original, helper, core_body, reader)
        assert (result['components'], result['imported'], result['unchanged']) == (239, 25, 214)
        compiler = TestRead(folder / 'docs/regression/CodeUpdate.json')
        _, actual = reader(helper['TestContainer']((folder / 'CompiledVBA.bin').read_bytes()))
        coupled = []
        for relative in TestRead(folder / 'AllCoupledSources.json'):
            file = folder / relative
            name = file.stem
            expected, _ = helper['TestMVTCompilerBody'](body, file.read_text('utf-8-sig'), name)
            observed = body(actual[name], name)[0]
            if name == 'CCoupledConcreteReturn':
                def TestSpacing(text):
                    """Учитывает выравнивание единственной константы VBE перед тем же комментарием."""
                    rows = text.splitlines(keepends=True)
                    for index, line in enumerate(rows):
                        if line.startswith('private const rounding_limit as double = '):
                            code, comment = line.split("'", 1)
                            rows[index] = code.rstrip() + " '" + comment
                    return ''.join(rows)
                expected, observed = TestSpacing(expected), TestSpacing(observed)
            assert normal(expected) == normal(observed), (key, name)
            coupled.append(name)
        assert len(coupled) == 30
        result['all_coupled_sources_match'] = coupled
        reports = {}
        for file in sorted((folder / 'Native').glob('*.txt')):
            log = file.read_text('utf-8-sig')
            phase = file.stem
            owner = TestRead(file.with_name(file.name + '.Ownership.json'))
            closure = TestRead(file.with_name(file.name + '.ProcessClosure.json'))
            identity = closure['Closure']['Identity']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
            assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
            assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
            assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['Closure']['FinalState']['State'] == 'Absent'
            assert 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
            totals = [tuple(map(int, pair)) for pair in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', log, re.M)]
            assert totals and all(failed == 0 for _, failed in totals)
            if phase.startswith('Hard'):
                assert totals == [(1, 0)]
                assert re.search(r'^HARD_PREPARED_RESULT;\d+;[\d.E+-]+;6;', log, re.M)
            elif phase == 'Core': assert sum(a for a, _ in totals) == 382
            elif phase == 'PeakRegression': assert sum(a for a, _ in totals) == 168
            elif phase == 'Stock':
                assert totals == [(28, 0)] and 'TIMING_STATES: direct=OK; capacity=NumFail;' in log
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;', log, re.M)
                result['stock_seconds'] = float(re.search(r'^TIMING_SECONDS: ([\d.]+)', log, re.M)[1])
                result['stock_state'] = re.search(r'^TIMING_STATES: (.*)$', log, re.M)[1]
            elif phase == 'Trace74': assert totals == [(1, 0)] and 'PRODUCTION_PATH_COUNT;151' in log
            else: raise AssertionError((key, phase))
            reports[phase] = totals
        expected = {'Hard' + {'BroadRefined': 'Refined', 'NearRetry': 'NearRetry', 'SmallRescue': 'SmallRescue', 'GaugeOnly': 'GaugeOnly'}[key]} if study else {
            'Core', 'PeakRegression', 'Stock', 'Trace74'} if key == 'Final' else {'HardEarlyField'}
        assert set(reports) == expected, (key, set(reports))
        safety = [json.loads(line) for line in (folder / 'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in safety)
        assert all(all(p['ProtectedUser'] for p in row['excel']) for row in safety)
        result['reports'] = reports
        cases[key] = result
    output.write_text(json.dumps({'cases': cases, 'scope': 'study' if study else 'working',
        'canonical_controls': controls, 'installed_workbook_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('SMALL CORRECTION ACTUAL VBA NATIVE REPORTS AND OWNED PROCESS CLOSURE VERIFIED', flush=True)


def TestMechanics(repo, root, output):
    """Повторяет силы и полные уравнения; независимое интегрирование закона CDP этим не подменяется."""
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    TestBaseline(repo, root)
    validate = run_path(str(root / 'Validate-TestHardPrepared.py'))['TestValidate']
    with TemporaryDirectory() as temporary:
        temporary = Path(temporary)
        (temporary / 'Native').mkdir()
        for name in ('HardEarlyField.csv', 'HardEarlyField.Operators.csv'):
            (temporary / 'Native' / name).write_bytes((root / 'Baseline' / name).read_bytes())
        baseline, original = validate(temporary, 'HardEarlyField')
    assert len(original) == 23 and baseline['maximum_lambda'] == 1.10760941419977
    study = TestRead(root / 'Scope.json')['scope'] == 'study'
    selections = [('BroadRefined', 'HardRefined', 21, 1.10585716098957, 10),
        ('NearRetry', 'HardNearRetry', 25, 1.10776539834113, 23),
        ('SmallRescue', 'HardSmallRescue', 25, 1.10776538831823, 23),
        ('GaugeOnly', 'HardGaugeOnly', 23, 1.10760941419977, 23)] if study else [
        ('Capture', 'HardEarlyField', 25, 1.10776538831823, 23)]
    cases = {}
    for key, phase, count, maximum, prefix in selections:
        proof, fields = validate(root / 'Cases' / key, phase)
        assert len(fields) == count and proof['maximum_lambda'] == maximum
        assert not proof['reversed_fields'] and proof['meta'][:2] == ['6', '10']
        assert proof['material'] == baseline['material'] and proof['options'] == baseline['options']
        assert np.array_equal(fields[:prefix], original[:prefix]), key
        proof['original_prefix_exact'] = prefix
        cases[key] = proof
    output.write_text(json.dumps({'cases': cases, 'independent_material_reintegration': False,
        'physical_capacity_certified': False}, indent=2, sort_keys=True, ensure_ascii=False) + '\n', encoding='utf-8')
    print('SMALL CORRECTION SIX FORCES FULL EQUATIONS ORIENTATION AND ORIGINAL PREFIX VERIFIED; CAPACITY OPEN', flush=True)


def TestSpatial(repo, root, output):
    """Повторяет весь согласованный ASD-материал и проверяет неизменность 151 полей MVT2."""
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    TestBaseline(repo, root)
    run_path(str(root / 'Validate-TestGeneralContinuation.py'))['TestValidate'](repo, root / 'Cases/Final', 'Trace74', output)
    def TestFields(file):
        """Не округляет записи полей и не исключает координаты служебных множителей."""
        return [line for line in file.read_text('cp1251').splitlines() if line.startswith('F;')]
    original = TestFields(root / 'Baseline/Trace74.Operators.csv')
    fields = TestFields(root / 'Cases/Final/Native/Trace74.Operators.csv')
    assert len(fields) == len(original) == 151 and fields == original
    proof = TestRead(output)
    proof['all_original_fields_byte_exact'] = 151
    output.write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('SMALL CORRECTION MVT2 MATERIAL ALL EQUILIBRIA AND 151 ORIGINAL FIELDS VERIFIED', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics', 'spatial'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics, 'spatial': TestSpatial}[args.scope](
        args.repo.resolve(), args.root.resolve(), args.out.resolve())
