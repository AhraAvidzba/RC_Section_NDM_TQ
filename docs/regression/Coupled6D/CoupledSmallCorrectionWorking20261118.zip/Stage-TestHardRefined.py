"""ДЛЯ ТЕСТОВ. Проверяет существующую уточнённую касательную и резерв малой поправки после полевой смены меры CDP."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """В частной копии включает уже реализованный режим только после численного отказа и смены пространственной меры."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardPrepared.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    def TestOnce(code, old, new):
        """Не применяет диагностическую замену при неоднозначном исходном контракте."""
        assert code.count(old) == 1, old
        return code.replace(old, new)
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, 'Public HardPreparedRequestedTest As Boolean, EarlyFieldRequestedTest As Boolean',
        'Public HardPreparedRequestedTest As Boolean, EarlyFieldRequestedTest As Boolean, RefinedFieldRequestedTest As Boolean')
    code = TestOnce(code, 'If mode <> "Baseline" And mode <> "EarlyField" Then',
        'If mode <> "Baseline" And mode <> "EarlyField" And mode <> "Refined" Then')
    code = TestOnce(code, '    EarlyFieldRequestedTest = (mode = "EarlyField")',
        '    EarlyFieldRequestedTest = (mode <> "Baseline"): RefinedFieldRequestedTest = (mode = "Refined")')
    assert code.count('EarlyFieldRequestedTest = False') == 2
    code = code.replace('EarlyFieldRequestedTest = False', 'EarlyFieldRequestedTest = False: RefinedFieldRequestedTest = False')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, '''    mUsesTransverseControl = False: mUsesFieldControl = True: mUsesYieldControl = False
    mBranchTangentControl = False
    mFieldControlChanges = mFieldControlChanges + 1''', '''    mUsesTransverseControl = False: mUsesFieldControl = True: mUsesYieldControl = False
    ' -------------------- ДЛЯ ТЕСТОВ --------------------
    ' Уточнённая касательная и существующий резерв малой поправки; история, нагрузки и допуски неизменны.
    mBranchTangentControl = modTestCoupledElasticState.RefinedFieldRequestedTest And Not mSolver.HasPrincipalBoundaries
    mFieldControlChanges = mFieldControlChanges + 1''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, "'Compile','HardBaseline','HardEarlyField'", "'Compile','HardBaseline','HardEarlyField','HardRefined'")
    code = TestOnce(code, '''        if ($Phase -in @('HardBaseline','HardEarlyField')) {
            $caseMode=if ($Phase -eq 'HardBaseline') {'Baseline'} else {'EarlyField'}
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardPrepared','-MacroArgument1',$PSScriptRoot,
                '-MacroArgument2',$caseMode,'-TimeoutSeconds','240')''', '''        if ($Phase -in @('HardBaseline','HardEarlyField','HardRefined')) {
            $caseMode=$Phase.Substring(4)
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardPrepared','-MacroArgument1',$PSScriptRoot,
                '-MacroArgument2',$caseMode,'-TimeoutSeconds','360')''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledDeformationContinuation.cls', 'tests/modTestCoupledElasticState.bas', 'Run-TestWorkingASD.ps1'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'case': 'HardRefined', 'working_code_changed': False,
        'refined_control_only_after_field_change': True, 'recovery_per_revision': False,
        'numerical_tolerances_changed': False, 'global_probe_limit': 96, 'full_acceptance_completed': False}
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRIVATE CDP REFINED FIELD CONTROL READY; WORKING CODE UNCHANGED', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
