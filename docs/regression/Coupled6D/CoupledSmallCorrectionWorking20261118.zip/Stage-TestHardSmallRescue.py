"""ДЛЯ ТЕСТОВ. Проверяет прямой вызов имеющегося резерва малой поправки после отказа CDP."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Не меняет обычные итерации; уточнённая касательная строится внутри уже существующего резерва."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardNearRetry.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    block = '''            ' -------------------- ДЛЯ ТЕСТОВ --------------------
            ' Только реальный отказ демпфирования после смены меры; повтор расходует итерацию той же цели.
            If modTestCoupledElasticState.NearRetryArmedTest And mControlActive And mUseSpatialHistory And _
                    Not mConsistentControl And Not HasPrincipalBoundaries And norm <= SMALL_STRAIN_MAX_NORM * tolerance And _
                    mIterations + 1 < maxIterations Then
                mConsistentControl = True: mIterations = mIterations + 1
                modTestCoupledElasticState.NearRetryCountTest = modTestCoupledElasticState.NearRetryCountTest + 1
                GoTo RecomputeTangent
            End If
'''
    assert code.count(block) == 1
    code = code.replace(block, '')
    needle = '            If mControlActive And mConsistentControl And norm <= SMALL_STRAIN_MAX_NORM * tolerance Then'
    assert code.count(needle) == 1
    code = code.replace(needle, '''            ' -------------------- ДЛЯ ТЕСТОВ --------------------
            ' Резерв сам собирает уточнённую касательную и проверяет все уравнения при неизменной цели.
            If mControlActive And (mConsistentControl Or (modTestCoupledElasticState.NearRetryArmedTest And _
                    mUseSpatialHistory And Not HasPrincipalBoundaries)) And norm <= SMALL_STRAIN_MAX_NORM * tolerance Then
                If Not mConsistentControl Then modTestCoupledElasticState.NearRetryCountTest = modTestCoupledElasticState.NearRetryCountTest + 1''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    assert code.count('mode <> "NearRetry"') == code.count('mode = "NearRetry"') == 1
    code = code.replace('mode <> "NearRetry"', 'mode <> "SmallRescue"').replace('mode = "NearRetry"', 'mode = "SmallRescue"')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    assert code.count('HardNearRetry') == 2
    code = code.replace('HardNearRetry', 'HardSmallRescue')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledNewtonSolver.cls', 'tests/modTestCoupledElasticState.bas', 'Run-TestWorkingASD.ps1'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'case': 'HardSmallRescue', 'working_code_changed': False,
        'direct_small_strain_rescue_only': True, 'ordinary_newton_iterations_unchanged': True,
        'only_after_field_control_change': True, 'numerical_tolerances_changed': False,
        'global_probe_limit': 96, 'full_acceptance_completed': False}
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRIVATE DIRECT CDP SMALL-STRAIN RESCUE READY; WORKING CODE UNCHANGED', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
