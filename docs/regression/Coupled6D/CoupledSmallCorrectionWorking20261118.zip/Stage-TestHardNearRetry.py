"""ДЛЯ ТЕСТОВ. Уточняет касательную только после неудачного демпфирования при малой невязке CDP."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Сохраняет принятую историю и допуски; резерв действует после смены пространственной меры."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardPrepared.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    def TestOnce(code, old, new):
        """Не допускает неточной либо повторной вставки диагностического условия."""
        assert code.count(old) == 1, old
        return code.replace(old, new)
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, 'Public HardPreparedRequestedTest As Boolean, EarlyFieldRequestedTest As Boolean',
        'Public HardPreparedRequestedTest As Boolean, EarlyFieldRequestedTest As Boolean\n'
        'Public NearRetryRequestedTest As Boolean, NearRetryArmedTest As Boolean, NearRetryCountTest As Long')
    code = TestOnce(code, 'If mode <> "Baseline" And mode <> "EarlyField" Then',
        'If mode <> "Baseline" And mode <> "EarlyField" And mode <> "NearRetry" Then')
    code = TestOnce(code, '    EarlyFieldRequestedTest = (mode = "EarlyField")',
        '    EarlyFieldRequestedTest = (mode <> "Baseline"): NearRetryRequestedTest = (mode = "NearRetry")\n'
        '    NearRetryArmedTest = False: NearRetryCountTest = 0')
    assert code.count('EarlyFieldRequestedTest = False') == 2
    code = code.replace('EarlyFieldRequestedTest = False',
        'EarlyFieldRequestedTest = False: NearRetryRequestedTest = False: NearRetryArmedTest = False')
    code = TestOnce(code, '    Print #handle, "SOLVER_SECONDS;" & TestOnsetNumber(Timer - started)',
        '    Print #handle, "SOLVER_SECONDS;" & TestOnsetNumber(Timer - started)\n'
        '    Print #handle, "NEAR_RETRY_COUNT;" & CStr(NearRetryCountTest)')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, '    mFieldControlChanges = mFieldControlChanges + 1',
        '    mFieldControlChanges = mFieldControlChanges + 1\n'
        '    modTestCoupledElasticState.NearRetryArmedTest = modTestCoupledElasticState.NearRetryRequestedTest')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    assert 'CCoupledNewtonSolver' in prep['modules']
    code = (root / name).read_text('utf-8-sig')
    needle = '            If mControlActive And mConsistentControl And norm <= SMALL_STRAIN_MAX_NORM * tolerance Then'
    code = TestOnce(code, needle, '''            ' -------------------- ДЛЯ ТЕСТОВ --------------------
            ' Только реальный отказ демпфирования после смены меры; повтор расходует итерацию той же цели.
            If modTestCoupledElasticState.NearRetryArmedTest And mControlActive And mUseSpatialHistory And _
                    Not mConsistentControl And Not HasPrincipalBoundaries And norm <= SMALL_STRAIN_MAX_NORM * tolerance And _
                    mIterations + 1 < maxIterations Then
                mConsistentControl = True: mIterations = mIterations + 1
                modTestCoupledElasticState.NearRetryCountTest = modTestCoupledElasticState.NearRetryCountTest + 1
                GoTo RecomputeTangent
            End If
''' + needle)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, "'Compile','HardBaseline','HardEarlyField'", "'Compile','HardBaseline','HardEarlyField','HardNearRetry'")
    code = TestOnce(code, '''        if ($Phase -in @('HardBaseline','HardEarlyField')) {
            $caseMode=if ($Phase -eq 'HardBaseline') {'Baseline'} else {'EarlyField'}
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardPrepared','-MacroArgument1',$PSScriptRoot,
                '-MacroArgument2',$caseMode,'-TimeoutSeconds','240')''', '''        if ($Phase -in @('HardBaseline','HardEarlyField','HardNearRetry')) {
            $caseMode=$Phase.Substring(4)
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardPrepared','-MacroArgument1',$PSScriptRoot,
                '-MacroArgument2',$caseMode,'-TimeoutSeconds','360')''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledDeformationContinuation.cls', 'src/Solver/CCoupledNewtonSolver.cls',
                 'tests/modTestCoupledElasticState.bas', 'Run-TestWorkingASD.ps1'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'case': 'HardNearRetry', 'working_code_changed': False,
        'refined_control_only_after_failed_damping': True, 'only_after_field_control_change': True,
        'numerical_tolerances_changed': False, 'same_target_iteration_budget': True,
        'global_probe_limit': 96, 'full_acceptance_completed': False}
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRIVATE CDP NEAR-TOLERANCE RETRY READY; WORKING CODE UNCHANGED', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
