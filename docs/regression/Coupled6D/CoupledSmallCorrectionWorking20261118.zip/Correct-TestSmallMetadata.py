"""ДЛЯ ТЕСТОВ. Исправляет только метку базы двух ещё не закоммиченных новых архивов и повторяет контроль происхождения."""

from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from shutil import copyfile
from subprocess import run, DEVNULL
from zipfile import ZipFile, ZIP_DEFLATED


def TestCorrect():
    """Не меняет расчётные входы, нативные отчёты или исторические архивы; точные исходники и доказательства сохраняются."""
    repo = Path.cwd()
    here = Path(__file__).resolve().parent
    scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    path = repo / 'tmp/SmallCorrectionSeal.json'
    previous = json.loads(path.read_bytes())
    plans = [('SmallCorrectionStudyEvidence20261118', previous[0]),
             ('SmallCorrectionWorkingEvidence20261118', previous[1])]
    checker = run_path(str(here / 'Check-TestSmallCorrection.py'))
    for directory, seal in plans:
        root = scratch / directory
        checkpoint = json.loads((root / 'Scope.json').read_bytes())
        assert checkpoint['base'] == 'd779a5b'
        assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == 'fcae8f7'
        rejected = False
        try:
            checker['TestCheckpoint'](root)
        except AssertionError as error:
            assert str(error) == 'Scope/source checkpoint mismatch'
            rejected = True
        assert rejected
        (root / 'SourceCheckpoint.json').write_text(json.dumps(checkpoint, indent=2) + '\n', encoding='utf-8')
        for name in ('Collect-TestSmallCorrection.py', 'Check-TestSmallCorrection.py', Path(__file__).name):
            (root / name).write_bytes((here / name).read_bytes())
        (root / 'Operational/MetadataCorrection.json').write_text(json.dumps({
            'incorrect_metadata_base': 'fcae8f7', 'actual_preparation_base': 'd779a5b',
            'incorrect_metadata_rejected': rejected, 'runtime_sources_changed': False,
            'native_reports_changed': False}, indent=2) + '\n', encoding='utf-8')
        excluded = {'Files.json', 'NativeProof.json', 'MechanicsProof.json', 'SpatialProof.json'}
        files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
            for file in root.rglob('*') if file.is_file() and file.relative_to(root).as_posix() not in excluded}
        (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        checker['TestNative'](repo, root, root / 'NativeProof.json')
        assert sha256((root / 'NativeProof.json').read_bytes()).hexdigest().upper() == seal['proofs']['NativeProof.json']
    corrected = []
    manifest_path = repo / 'docs/reports/Coupled6DEvidence.json'
    manifest_text = manifest_path.read_text('utf-8').replace('\r\n', '\n')
    manifest_before = json.loads(manifest_text)
    journal_path = repo / 'docs/reports/Coupled6DProgress.md'
    journal_text = journal_path.read_bytes().decode('utf-8')
    for directory, seal in plans:
        root = scratch / directory
        name = seal['archive']
        relative = 'docs/regression/Coupled6D/' + name + '.zip'
        assert run(['git', 'cat-file', '-e', 'HEAD:' + relative], cwd=repo, stdout=DEVNULL, stderr=DEVNULL).returncode != 0
        destination = repo / relative
        assert sha256(destination.read_bytes()).hexdigest().upper() == seal['sha256']
        revised = scratch / (name + '-MetadataCorrected.zip')
        with ZipFile(revised, 'x', ZIP_DEFLATED, compresslevel=9) as output:
            for file in sorted(root.rglob('*')):
                if file.is_file(): output.write(file, file.relative_to(root).as_posix())
        assert revised.stat().st_size < 100000000
        digest = sha256(revised.read_bytes()).hexdigest().upper()
        copyfile(revised, destination)
        old_entry = json.dumps(name) + ': ' + json.dumps(seal['sha256'])
        assert manifest_text.count(old_entry) == 1
        manifest_text = manifest_text.replace(old_entry, json.dumps(name) + ': ' + json.dumps(digest), 1)
        assert journal_text.count(seal['sha256']) == 1
        journal_text = journal_text.replace(seal['sha256'], digest, 1)
        old_size = '](../regression/Coupled6D/' + name + '.zip), ' + str(seal['bytes']) + ' байт.'
        assert journal_text.count(old_size) == 1
        journal_text = journal_text.replace(old_size, '](../regression/Coupled6D/' + name + '.zip), ' + str(revised.stat().st_size) + ' байт.', 1)
        corrected.append({**seal, 'bytes': revised.stat().st_size, 'sha256': digest})
    current = json.loads(manifest_text)
    assert current['cases'] == manifest_before['cases']
    changed = {key for key in current['archives'] if current['archives'][key] != manifest_before['archives'][key]}
    assert changed == {seal['archive'] for seal in previous}
    manifest_path.write_bytes(manifest_text.replace('\n', '\r\n').encode())
    journal_path.write_bytes(journal_text.encode('utf-8'))
    path.write_text(json.dumps(corrected, indent=2) + '\n', encoding='utf-8')
    print('BOTH NEW ARCHIVE BASE METADATA CORRECTED; RUNTIME SOURCES AND NUMERICAL PROOFS UNCHANGED', flush=True)
    print(json.dumps(corrected, indent=2), flush=True)


if __name__ == '__main__':
    TestCorrect()
