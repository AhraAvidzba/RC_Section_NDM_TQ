"""ДЛЯ ТЕСТОВ. Сохраняет раздельные исследования численного резерва и проверку рабочего подключения."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestCollect(repo, root, scope):
    """Закрепляет исходники, CFB, реальные нативные отчёты и выбранный подтверждённый префикс."""
    here = Path(__file__).resolve().parent
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    cases = {'BroadRefined': 'HardRefinedField20261118', 'NearRetry': 'HardNearRetry20261118',
        'SmallRescue': 'HardSmallRescue20261118', 'GaugeOnly': 'HardGaugeOnly20261118'} if scope == 'study' else {
        'Final': 'SmallRescueWorking20261118', 'Capture': 'SmallRescueCapture20261118'}
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for folder in (root / 'Cases').iterdir():
        source_scope = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            destination = folder / relative
            if not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(file.read_bytes())
            source_scope[relative.as_posix()] = sha256(destination.read_bytes()).hexdigest().upper()
        assert len(source_scope) == 30
        (folder / 'AllCoupledSources.json').write_text(json.dumps(source_scope, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    for name in ('Collect-TestSmallCorrection.py', 'Check-TestSmallCorrection.py', 'Validate-TestHardPrepared.py',
        'Stage-TestHardPrepared.py', 'Stage-TestHardRefined.py', 'Stage-TestHardNearRetry.py',
        'Stage-TestHardSmallRescue.py', 'Stage-TestHardGaugeOnly.py', 'TestNativeHardPrepared.bas.txt',
        'Stage-TestClosedBranchPeak.py', 'Stage-TestSteelHistory.py', 'Canonical-TestCoreVBA.py'):
        (root / name).write_bytes((here / name).read_bytes())
    baseline = repo / 'docs/regression/Coupled6D/CoupledHardFieldControl20261118.zip'
    digest = sha256(baseline.read_bytes()).hexdigest().upper()
    assert digest == 'CDC30660560F67E7F4374BA83AF4C538161E35CCB6F5E3A97FAC8741875381BF'
    (root / 'Baseline').mkdir()
    entries = {}
    selections = [('HardEarlyField.csv', 'Cases/RecoveryTrial/Native/HardEarlyField.csv'),
        ('HardEarlyField.Operators.csv', 'Cases/RecoveryTrial/Native/HardEarlyField.Operators.csv')]
    if scope == 'working':
        selections += [('Trace74.Operators.csv', 'Cases/Final/Native/Trace74.Operators.csv')]
    with ZipFile(baseline) as archive:
        for name, entry in selections:
            raw = archive.read(entry)
            (root / 'Baseline' / name).write_bytes(raw)
            entries[name] = {'entry': entry, 'sha256': sha256(raw).hexdigest().upper()}
    (root / 'Baseline/Origin.json').write_text(json.dumps({'archive': baseline.name,
        'sha256': digest, 'entries': entries}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    checkpoint = {'scope': scope, 'base': 'd779a5b',
        'physical_capacity_certified': False, 'full_acceptance_completed': False,
        'installed_workbook_changed': False}
    for name in ('Scope.json', 'SourceCheckpoint.json'):
        (root / name).write_text(json.dumps(checkpoint, indent=2) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('SMALL CORRECTION EVIDENCE COLLECTED', scope, len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('study', 'working'), required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve(), args.scope)
