"""ДЛЯ ТЕСТОВ. Закрепляет раздельные пробы и фактическую рабочую книгу после независимых проверок."""

from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile, ZIP_DEFLATED


def TestSeal():
    """Добавляет пять доказательств в двух архивах, сохраняя все исторические записи манифеста."""
    repo = Path.cwd()
    scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    study = scratch / 'SmallCorrectionStudyEvidence20261118'
    working = scratch / 'SmallCorrectionWorkingEvidence20261118'
    assert len(json.loads((study / 'NativeProof.json').read_bytes())['cases']) == 4
    assert len(json.loads((working / 'NativeProof.json').read_bytes())['cases']) == 2
    assert json.loads((working / 'SpatialProof.json').read_bytes())['all_original_fields_byte_exact'] == 151
    mechanisms = json.loads((working / 'MechanicsProof.json').read_bytes())
    assert len(mechanisms['cases']['Capture']['states']) == 25
    plans = [('CoupledSmallCorrectionStudy20261118', study, ('native', 'mechanics')),
             ('CoupledSmallCorrectionWorking20261118', working, ('native', 'mechanics', 'spatial'))]
    titles = {'native': 'NativeProof.json', 'mechanics': 'MechanicsProof.json', 'spatial': 'SpatialProof.json'}
    markers = {'native': 'SMALL CORRECTION ACTUAL VBA NATIVE REPORTS AND OWNED PROCESS CLOSURE VERIFIED',
        'mechanics': 'SMALL CORRECTION SIX FORCES FULL EQUATIONS ORIENTATION AND ORIGINAL PREFIX VERIFIED; CAPACITY OPEN',
        'spatial': 'SMALL CORRECTION MVT2 MATERIAL ALL EQUILIBRIA AND 151 ORIGINAL FIELDS VERIFIED'}
    receipts, cases, additions = [], [], {}
    for name, root, scopes in plans:
        operational = root / 'Operational'
        operational.mkdir()
        (operational / 'Coupled6DMaterialContract.md').write_bytes((repo / 'docs/Coupled6DMaterialContract.md').read_bytes())
        (operational / 'Preflight.json').write_text(json.dumps({
            'same_shell_compile_to_native_preflight_rejected': ['HardSmallRescue20261118', 'HardGaugeOnly20261118'],
            'native_reports_existed_before_rejection': False,
            'native_run_restarted': False, 'own_compiler_closure_checked': True,
            'fresh_shell_preflight_passed_before_first_native_start': True,
            'guards_weakened': False, 'unowned_excel_closed': False}, indent=2) + '\n', encoding='utf-8')
        (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
        excluded = set(titles.values()) | {'Files.json'}
        files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
            for file in root.rglob('*') if file.is_file() and file.relative_to(root).as_posix() not in excluded}
        (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        archive = scratch / (name + '.zip')
        with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as output:
            for file in sorted(root.rglob('*')):
                if file.is_file(): output.write(file, file.relative_to(root).as_posix())
        assert archive.stat().st_size < 100000000
        digest = sha256(archive.read_bytes()).hexdigest().upper()
        destination = repo / 'docs/regression/Coupled6D' / archive.name
        assert not destination.exists()
        copyfile(archive, destination)
        pins = {titles[scope]: sha256((root / titles[scope]).read_bytes()).hexdigest().upper() for scope in scopes}
        receipts.append({'archive': name, 'bytes': archive.stat().st_size, 'sha256': digest, 'proofs': pins})
        additions[name] = digest
        label = 'study' if root == study else 'working'
        for scope in scopes:
            title = titles[scope]
            cases.append({'id': 'coupled-small-correction-' + label + '-' + scope, 'journal_section': 612,
                'archive': name, 'script': 'Check-TestSmallCorrection.py',
                'arguments': ['--repo', '{repo}', '--root', '.', '--scope', scope, '--out', title],
                'stdout_contains': markers[scope], 'outputs': {title: pins[title]},
                'timeout_seconds': 600 if scope == 'spatial' else 300})
    path = repo / 'docs/reports/Coupled6DEvidence.json'
    text = path.read_text('utf-8').replace('\r\n', '\n')
    old = json.loads(text)
    assert len(old['archives']) == 302 and len(old['cases']) == 334
    index = text.index('\n  },\n  "cases": [')
    text = text[:index] + ',\n' + ',\n'.join('    ' + json.dumps(name) + ': ' + json.dumps(pin) for name, pin in additions.items()) + text[index:]
    index = text.index('\n  ],\n  "frozen_repositories": {')
    text = text[:index] + ',\n' + ',\n'.join('\n'.join('    ' + line for line in json.dumps(case, ensure_ascii=False, indent=2).splitlines()) for case in cases) + text[index:]
    current = json.loads(text)
    assert current['cases'][:334] == old['cases'] and len(current['cases']) == 339
    assert all(current['archives'][key] == pin for key, pin in old['archives'].items())
    path.write_bytes(text.replace('\n', '\r\n').encode())
    (repo / 'tmp/SmallCorrectionSeal.json').write_text(json.dumps(receipts, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipts, indent=2), flush=True)


if __name__ == '__main__':
    TestSeal()
