"""ДЛЯ ТЕСТОВ. Проверяет автоматическое прохождение известной точки и действительную причину предыдущей остановки."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


def TestFiles(root):
    """Закреплённые исходы, ошибки обмена и исходники не подменяются при повторе."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == '7a6955c35b0734c4bc47fc7bc1c650ed9b191796'


def TestNative(repo, root, output):
    """Проверяет пять исполненных книг и отдельно сохраняет отказ компиляции вспомогательного журнала."""
    TestFiles(root)
    audit = run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit']
    plans = {'First': {'HybridStall': 2}, 'Compare': {'HybridStall': 2}, 'TargetOnly': {'Stock': 28},
             'Gate': {'Stock': 28}, 'Final': {'Stock': 28, 'Core': 382, 'PeakRegression': 168}}
    cases = {}
    for case, phases in plans.items():
        folder = root / 'Cases' / case
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            file = Path(temporary) / 'Code.json'
            audit(repo, folder, file)
            record = json.loads(file.read_bytes())
        expected = (245, 31, 214) if case in ('First', 'Compare') else (244, 30, 214)
        assert (record['components'], record['imported'], record['unchanged']) == expected
        assert len(record['checked_coupled_sources']) == 33
        assert {file.stem for file in (folder / 'Native').glob('*.txt')} == set(phases)
        reports = {}
        for phase, expected_total in phases.items():
            path = folder / 'Native' / (phase + '.txt')
            log = path.read_text('utf-8-sig')
            closure = json.loads(path.with_name(path.name + '.ProcessClosure.json').read_bytes())
            assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
            assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
            assert closure['RunnerCleanupValid'] and 'RUNTIME ERROR:' not in log
            assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
            totals = re.findall(r'^TOTAL[^:\r\n]*:\s*passed=(\d+);\s*failed=(\d+)', log, re.M)
            assert (sum(int(a) for a, b in totals), sum(int(b) for a, b in totals)) == (expected_total, 0)
            source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
            assert source == record['compiled_workbook_sha256']
            reports[phase] = {'passed': expected_total, 'failed': 0, 'owned_excel_closed': True}
        record['native_reports'] = reports
        cases[case] = record
    failed = root / 'Cases/GateCompileFailure'
    assert not (failed / 'CompileClosure.json').exists()
    closure = json.loads((failed / 'CompileFailureClosure.json').read_bytes())
    assert closure['State'] == 'Absent' and closure['PID'] == 38144
    raw = (failed / 'Compile.log').read_bytes()
    assert raw.startswith(b'\xff\xfe')
    compile_log = raw.decode('utf-16')
    assert 'COMPILE_LOCATION:' in compile_log
    assert 'TestHardPreparedVector(projection)' in compile_log
    assert not list((failed / 'Native').glob('*.txt'))
    result = {'cases': cases, 'separate_test_logger_compile_failure_preserved': True,
              'test_logger_compile_log_encoding': 'UTF-16 with BOM',
              'installed_workbook_changed': False, 'full_acceptance_completed': False, 'physical_capacity_certified': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('RESOLVED LOAD STEP FIVE EXECUTED VBA BOOKS REGRESSIONS AND EXPECTED TEST LOGGER FAILURE VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Проверяет корень, историю, истинные флаги остановки и реальное прохождение штатным контроллером."""
    TestFiles(root)
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        temporary = Path(temporary)
        own, gate, stock = (temporary / (name + '.json') for name in ('Own', 'Gate', 'Stock'))
        run_path(str(root / 'Check-TestStockHybridCompare.py'))['TestCheck'](root / 'Cases/Compare', root / 'Cases/First', own)
        run_path(str(root / 'Analyze-TestHybridExitGate.py'))['TestAnalyze'](root / 'Cases/Gate', root / 'Cases/Compare', gate)
        run_path(str(root / 'Check-TestResolvedLoadStepStock.py'))['TestCheck'](root / 'Cases/TargetOnly', root / 'Cases/Final', root / 'Cases/Compare', stock)
        comparison, gates, automatic = (json.loads(file.read_bytes()) for file in (own, gate, stock))
    final = gates['final_exit']
    assert final['lastProbeFailed'] is False and final['lastNoProgress'] is False and final['unresolvedSteel'] is False
    assert final['code'] == 0 and final['supports'] is True and gates['successful_witness_projection_equals_final']
    assert final['increment'] < final['minimum'] and automatic['accepted_load_points_after'] == 26
    assert automatic['after']['native_state'].startswith('direct=OK; capacity=NumFail;')
    assert automatic['after']['seconds'] == 169.228515625
    result = {'own_and_external_comparison': comparison, 'actual_prior_exit': gates, 'automatic_stock_regression': automatic,
              'physical_capacity_certified': False, 'auto_accepted_field_history_not_independently_exported': True,
              'automatic_saved_load_prefix_verified': 25, 'manual_witness_full_field_prefix_verified': 25,
              'independent_material_reintegration': False, 'no_material_or_equilibrium_gate_weakened': True}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('RESOLVED LOAD STEP AUTOMATIC BOOK REACHED THE VERIFIED EQUILIBRIUM; PRIOR EXIT CAUSE AND ORIGINAL PREFIX VERIFIED; CAPACITY OPEN')


def TestMatrix(repo, root, output):
    """Повторяет только независимую сборку первого полного Якобиана и его линейные проверки."""
    TestFiles(root)
    run_path(str(root / 'Analyze-TestStockFullJacobian.py'))['TestAnalyze'](root / 'Cases/First', output)
    data = json.loads(output.read_bytes())
    assert data['maximum_difference_row_column_one_based'] == [53, 53]
    assert data['legacy_correction_complete_linear_residual_MPa'] > data['base_residual_MPa']
    assert data['linear_directions_are_not_equilibrium_points']
    print('RESOLVED LOAD STEP COMPLETE JACOBIAN AND LEGACY DIRECTION MISMATCH INDEPENDENTLY VERIFIED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics', 'matrix'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics, 'matrix': TestMatrix}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
