"""ДЛЯ ТЕСТОВ. Восстанавливает первый внешний полный Якобиан из точных двоичных ответов VBA."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestAnalyze(root, output):
    """Сравнивает сборку и действие касательных; направления линейной системы не выдаёт за новые равновесия."""
    here = Path(__file__).resolve().parent
    helpers = run_path(str(here / 'Check-TestHardHalfSteps.py'))
    rows = helpers['TestRows'](root / 'Native/HardEarlyField.Stall.csv')
    header = {row[0]: row[1:] for row in rows if row[0] in ('CONTEXT', 'FIELD', 'CORRECTION', 'PROJECTION', 'DIRECTION', 'RESIDUAL')}
    main = helpers['TestRows'](root / 'Native/HardEarlyField.csv')
    dim = next(row for row in main if row[0] == 'DIM')
    size, physical = int(dim[1]), int(dim[2])
    modulus = float(next(row[1] for row in main if row[0] == 'LAW'))
    assert size == 60 and float(dim[5]) == .001
    bridge = root / 'Native/HybridBridge'
    read = lambda number: np.frombuffer((bridge / f'response-{number}.bin').read_bytes(), dtype='<f8')
    seed, scales, residual = (read(number) for number in (1, 2, 3))
    assert seed.shape == scales.shape == residual.shape == (size + 1,) and np.all(scales > 0)
    np.testing.assert_allclose(seed[:size], np.asarray(header['FIELD'], float), rtol=1e-14, atol=0)
    progress = {item['sequence']: item for item in (json.loads(line) for line in (bridge / 'Progress.ndjson').read_text('utf-8').splitlines())}
    complete = np.column_stack([(read(4 + 2 * column) - read(5 + 2 * column)) / (2e-6) for column in range(size + 1)])
    for number in range(4, 4 + 2 * size):
        assert progress[number]['lambda'] == seed[-1]
    assert progress[4 + 2 * size]['lambda'] == seed[-1] + scales[-1] * 1e-6
    assert progress[5 + 2 * size]['lambda'] == seed[-1] - scales[-1] * 1e-6
    matrix = np.empty((size, size))
    for row in rows:
        if row[0] == 'J' and row[1] == 'Recorded':
            matrix[int(row[2]) - 1] = np.asarray(row[3:], float)
    _, load, _, _, _, _, _, _ = helpers['TestOperators'](root / 'Native/HardEarlyField.Operators.csv', size, 43)
    augmented = np.zeros((size + 1, size + 1))
    augmented[:size, :size] = matrix
    augmented[:size, -1] = -load @ np.asarray(header['DIRECTION'], float)
    augmented[physical:size] *= modulus
    augmented[-1, :size] = modulus * np.asarray(header['PROJECTION'], float)
    augmented *= scales
    # Кинематические строки, линейная мера и нагрузка проверяются отдельно от материальной линеаризации.
    gauge_error = float(np.max(np.abs(complete[physical:size] - augmented[physical:size])))
    control_error = float(np.max(np.abs(complete[-1] - augmented[-1])))
    load_error = float(np.max(np.abs(complete[:, -1] - augmented[:, -1])))
    assert max(gauge_error, control_error, load_error) < 1e-7
    direction = np.asarray(header['CORRECTION'], float) / scales
    old_action, full_action = augmented @ direction, complete @ direction
    original_linear_error = float(np.max(np.abs(old_action + residual)))
    assert original_linear_error < 1e-8
    error = complete - augmented
    worst = np.unravel_index(int(np.argmax(np.abs(error))), error.shape)
    singular = np.linalg.svd(complete, compute_uv=False)
    correction = np.linalg.solve(complete, -residual)
    result = {'base_residual_MPa': float(np.max(np.abs(residual))),
              'spatial_coordinate': 'z/L', 'spatial_half_step_dimensionless': .001,
              'first_complete_difference_matrix_shape': list(complete.shape),
              'exact_response_sequence_range': [4, 5 + 2 * size],
              'linear_gauge_error': gauge_error, 'linear_control_error': control_error, 'linear_load_error': load_error,
              'original_recorded_correction_linear_error_MPa': original_linear_error,
              'maximum_scaled_Jacobian_difference': float(np.max(np.abs(error))),
              'maximum_difference_row_column_one_based': [int(worst[0]) + 1, int(worst[1]) + 1],
              'singular_values_complete': singular.tolist(),
              'condition_number_complete': float(singular[0] / singular[-1]),
              'legacy_correction_complete_linear_residual_MPa': float(np.max(np.abs(full_action + residual))),
              'complete_correction_linear_residual_MPa': float(np.max(np.abs(complete @ correction + residual))),
              'legacy_correction_predicts_descent_for_true_linearization': bool(np.max(np.abs(full_action + residual)) < np.max(np.abs(residual))),
              'linear_directions_are_not_equilibrium_points': True, 'physical_capacity_certified': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('DEFAULT H COMPLETE JACOBIAN REASSEMBLED FROM EXACT NATIVE RESPONSES; LINEAR DIRECTIONS ARE NOT EQUILIBRIA')
    print('JACOBIAN DIFFERENCE', result['maximum_scaled_Jacobian_difference'], 'WORST', result['maximum_difference_row_column_one_based'])
    print('ORIGINAL ACTION ERROR', result['legacy_correction_complete_linear_residual_MPa'], 'BASE', result['base_residual_MPa'])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
