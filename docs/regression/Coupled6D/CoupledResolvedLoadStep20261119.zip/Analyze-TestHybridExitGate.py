"""ДЛЯ ТЕСТОВ. Разбирает фактические условия выхода контроллера и сопоставляет их с успешной удержанной пробой."""

from argparse import ArgumentParser
import csv
from io import StringIO
import json
from pathlib import Path
import numpy as np


def TestAnalyze(root, comparison, output):
    """Не изменяет флаги и не выводит физическое разрушение из причины численной остановки."""
    rows = list(csv.reader(StringIO((root / 'Native/HybridGate.csv').read_text('cp1251')), delimiter=';'))
    keys = rows[0][1:16]
    assert keys == ['attempt', 'lambda', 'coordinate', 'increment', 'minimum', 'lastProbeFailed', 'lastNoProgress',
                    'unresolvedSteel', 'supports', 'code', 'revision', 'hybridRevision', 'hybridTarget', 'fieldChanges', 'probes']
    records = []
    for row in rows[1:]:
        assert len(row) == 76
        data = {'stage': row[0], **{key: (value == 'True' if value in ('True', 'False') else float(value))
                                    for key, value in zip(keys, row[1:16])}}
        data['projection'] = list(map(float, row[16:]))
        records.append(data)
    final, = [item for item in records if item['stage'] == 'LoopExit']
    witness_rows = list(csv.reader(StringIO((comparison / 'Native/HardEarlyField.Stall.csv').read_text('cp1251')), delimiter=';'))
    context = next(row for row in witness_rows if row and row[0] == 'CONTEXT')
    projection = np.asarray(next(row[1:] for row in witness_rows if row and row[0] == 'PROJECTION'), float)
    result = {'records': records, 'final_exit': final,
              'successful_witness_target': float(context[4]),
              'successful_witness_projection_equals_final': bool(np.array_equal(projection, np.asarray(final['projection']))),
              'repeated_last_small_target': final['coordinate'] + 2 * final['increment'],
              'plain_minimum_guard_has_failed_probe': bool(final['lastProbeFailed'] or final['lastNoProgress']),
              'plain_minimum_guard_has_unresolved_steel': final['unresolvedSteel'],
              'physical_capacity_certified': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('ACTUAL CONTINUATION EXIT GATES RECORDED; NO PHYSICAL LIMIT INFERRED')
    print({key: value for key, value in final.items() if key != 'projection'})
    print('WITNESS PROJECTION MATCH', result['successful_witness_projection_equals_final'], 'TARGETS', result['successful_witness_target'], result['repeated_last_small_target'])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--comparison', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.comparison.resolve(), args.out.resolve())
