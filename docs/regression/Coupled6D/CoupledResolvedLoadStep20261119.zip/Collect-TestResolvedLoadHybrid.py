"""ДЛЯ ТЕСТОВ. Сохраняет найденный штатный корень, причину ложного тупика и рабочий автоматический повтор."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
from zipfile import ZIP_DEFLATED, ZipFile


def TestCollect(repo, root):
    """Не устанавливает книги; сохраняет фактический VBA, исходники, протоколы и необходимые XML сохранённых Results."""
    here = Path(__file__).resolve().parent
    cases = {'First': 'StockCompleteJacobian20261119', 'Compare': 'StockHybridCompare20261119',
             'TargetOnly': 'TargetHybridStock20261119', 'GateCompileFailure': 'HybridExitGate20261119',
             'Gate': 'HybridExitGate0220261119', 'Final': 'ResolvedLoadHybridStock20261119'}
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    for key, directory in cases.items():
        folder = root / 'Cases' / key
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(sources) == 33
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        if key in ('TargetOnly', 'Gate', 'Final'):
            source = scratch / directory
            if key != 'Final':
                saved, = re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$',
                                    (source / 'Native/Stock.txt').read_text('utf-8-sig'), re.M)
                assert Path(saved).resolve().is_relative_to((source / 'Temp').resolve())
                with ZipFile(saved) as book, ZipFile(folder / 'SavedWorkbookMarkup.zip', 'x', ZIP_DEFLATED, compresslevel=9) as output:
                    for name in sorted(book.namelist()):
                        if Path(name).suffix.lower() in ('.xml', '.rels', '.vml'):
                            output.writestr(name, book.read(name))
            (folder / 'SavedWorkbookScope.json').write_text(json.dumps({'original_scratch_root': str(source),
                'results_saved_and_reopened': True, 'whole_workbook_preserved': False}, indent=2) + '\n', encoding='utf-8')
    names = ('Collect-TestResolvedLoadHybrid.py', 'Check-TestResolvedLoadHybrid.py', 'Audit-TestPrivateCoupledBook.py',
             'Compare-TestSavedCoupledTrace.py', 'Check-TestStockHybridCompare.py', 'Analyze-TestStockFullJacobian.py',
             'Analyze-TestHybridExitGate.py', 'Check-TestResolvedLoadStepStock.py', 'Validate-TestHardPrepared.py',
             'Check-TestHardHalfSteps.py', 'Canonical-TestCoreVBA.py', 'Stage-TestStockCompleteJacobian.py',
             'Stage-TestStockHybridCompare.py', 'TestNativeStockHybridCompare.bas.txt', 'Stage-TestHybridExitGate.py')
    for name in names:
        (root / name).write_bytes((here / name).read_bytes())
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '7a6955c35b0734c4bc47fc7bc1c650ed9b191796',
        'installed_workbook_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False,
        'source_metadata_mm_label_erratum': 'First and Compare JSON retain their original incorrect label; h is dimensionless in z/L, no numerical values changed.'}, indent=2) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('RESOLVED LOAD HYBRID EVIDENCE COLLECTED', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
