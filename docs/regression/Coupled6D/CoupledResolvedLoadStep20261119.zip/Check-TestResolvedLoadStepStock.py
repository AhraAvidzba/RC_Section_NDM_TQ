"""ДЛЯ ТЕСТОВ. Требует от автоматического пути достижения независимо подтверждённой допустимой точки."""

from argparse import ArgumentParser
import json
from pathlib import Path
import re
from runpy import run_path


def TestStock(root):
    """Читает завершённый нативный результат; NumFail не подменяет предельной точкой."""
    report = (root / 'Native/Stock.txt').read_text('utf-8-sig')
    assert 'TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0' in report
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in report
    closure = json.loads((root / 'Native/Stock.txt.ProcessClosure.json').read_bytes())
    assert closure['Passed'] and closure['ChildHasExited'] and closure['Closure']['FinalState']['State'] == 'Absent'
    state, = re.findall(r'^TIMING_STATES: (.+)$', report, re.M)
    assert state.startswith('direct=OK;')
    lower, = re.findall(r'confirmed lower=([\d.E+-]+);', state)
    seconds, = re.findall(r'^TIMING_SECONDS: ([\d.]+) \| Both \| Excel$', report, re.M)
    assert 'equal=True;' in report
    return {'seconds': float(seconds), 'lower_lambda': float(lower), 'native_state': state}


def TestCheck(before, after, comparison, output):
    """Сохранённая допустимая точка является внешним для контроллера эталоном достижимости, а не критерием разрушения."""
    old, new = TestStock(before), TestStock(after)
    witness = json.loads((comparison / 'Native/HybridBridge/Result.json').read_bytes())
    assert witness['native_equilibrium_found'] and witness['native_validation'][0:2] == [1., 1.]
    required = float(witness['best_lambda']) - 1e-7
    assert old['lower_lambda'] < required, 'Negative control no longer reproduces the verified stall'
    assert new['lower_lambda'] >= required, (new['lower_lambda'], required)
    trace = run_path(str(Path(__file__).resolve().parent / 'Compare-TestSavedCoupledTrace.py'))['TestSavedTrace']
    previous, current = trace(before), trace(after)
    old_points = [key for key in previous if '.Capacity.' in key and key.endswith('.Lambda')]
    assert len(old_points) == 25
    for index in range(1, 26):
        for kind in ('Lambda', 'Offset'):
            key = f'Coupled.Trace.Capacity.{index}.{kind}'
            assert previous[key]['value'] == current[key]['value'], key
    count = sum('.Capacity.' in key and key.endswith('.Lambda') for key in current)
    assert count > 25
    result = {'before': old, 'after': new, 'required_known_admissible_lambda': required,
              'reference_equilibrium_lambda': float(witness['best_lambda']), 'old_case_is_negative_control': True,
              'first_saved_25_load_points_exact': True, 'accepted_load_points_after': count,
              'new_root_not_called_physical_capacity': True, 'independent_material_reintegration': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('AUTOMATIC STOCK CONTINUATION REACHED THE INDEPENDENTLY VERIFIED POINT; ORIGINAL LOAD PREFIX 25 EXACT; CAPACITY NOT INFERRED')
    print('LOWER LAMBDA', old['lower_lambda'], new['lower_lambda'], 'POINTS', count, 'SECONDS', new['seconds'])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--before', type=Path, required=True)
    parser.add_argument('--after', type=Path, required=True)
    parser.add_argument('--comparison', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestCheck(args.before.resolve(), args.after.resolve(), args.comparison.resolve(), args.out.resolve())
