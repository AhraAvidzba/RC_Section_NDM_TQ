"""ДЛЯ ТЕСТОВ. Сохраняет фактические флаги выхода штатного контроллера без изменения его решений."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Только частная книга вызывает тестовый журнал перед проверкой минимального шага и после выхода из цикла."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestIntegratedHybridStock.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    call = '''            modTestCoupledElasticState.TestLogHybridGate "Minimum", Array(attempt, current.Lambda, current.Coordinate, increment, minimum, _
                lastProbeFailed, lastNoProgress, unresolvedSteel, mSolver.SupportsHybridRecovery, CLng(mSolver.ResultMeta.ResultCode), _
                mSolver.AcceptedRevision, mLastHybridRevision, mLastHybridTarget, mFieldControlChanges, mProbeCount), mProjection'''
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '        If increment < minimum Then'
    assert code.count(old) == 1
    code = code.replace(old, old + '\n' + call, 1)
    old = '    Next attempt\n    If mProbeCount >= PROBE_LIMIT Then'
    assert code.count(old) == 1
    final = call.replace('"Minimum"', '"LoopExit"')
    final = '\n'.join(line[8:] for line in final.splitlines())
    code = code.replace(old, '    Next attempt\n' + final + '\n    If mProbeCount >= PROBE_LIMIT Then', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig') + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет скалярные условия выхода и точную проекцию; не читает Excel и не меняет контроллер.
Public Sub TestLogHybridGate(ByVal stage As String, ByVal values As Variant, ByRef projection() As Double)
    Dim path As String: path = Environ$("NDM_HYBRID_GATE_TEST")
    If Len(path) = 0 Then Exit Sub
    Dim row As String: row = stage
    Dim index As Long
    For index = LBound(values) To UBound(values)
        If VarType(values(index)) = vbBoolean Then
            row = row & ";" & CStr(values(index))
        Else
            row = row & ";" & TestOnsetNumber(CDbl(values(index)))
        End If
    Next index
    Dim handle As Integer: handle = FreeFile
    Dim first As Boolean: first = (Len(Dir$(path)) = 0)
    Open path For Append As #handle
    If first Then Print #handle, "MODE;attempt;lambda;coordinate;increment;minimum;lastProbeFailed;lastNoProgress;unresolvedSteel;supports;code;revision;hybridRevision;hybridTarget;fieldChanges;probes;projection..."
    Print #handle, row & TestHardPreparedVector(projection)
    Close #handle
End Sub
'''
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'private_read_only_exit_gate_log': True, 'working_decision_conditions_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('READ ONLY CONTINUATION EXIT GATE LOG READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
