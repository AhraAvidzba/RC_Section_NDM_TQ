"""ДЛЯ ТЕСТОВ. Готовит рабочую книгу без подготовительных переключателей и без изменения продольного шага."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Все рабочие классы берутся из текущих исходников; штатный Both/Excel сохраняет пользовательскую схему и результат."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestClosedBranchPeak.py'))['TestStage'](repo, root, False)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for name in ('src/Interfaces/ICoupledEquationSystem.cls', 'src/Solver/CCoupledHybridFactorization.cls',
        'src/Solver/CCoupledHybridSolver.cls', 'tests/CHybridEquationsTest.cls', 'tests/modTestCoupledHybrid.bas'):
        source = repo / name
        (root / name).parent.mkdir(parents=True, exist_ok=True)
        (root / name).write_bytes(source.read_bytes())
        prep['inputs'][name] = sha256(source.read_bytes()).hexdigest().upper()
        prep['modules'].append(source.stem)
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'Compile','ClosedPeak'"
    assert code.count(old) == 1
    code = code.replace(old, "'Compile','HybridCore','ClosedPeak'", 1)
    old = "        if ($Phase -eq 'ClosedPeak') {"
    assert code.count(old) == 1
    code = code.replace(old, '''        if ($Phase -eq 'HybridCore') {
            $arguments+=@('-Macro','modTestCoupledHybrid.RunTestCoupledHybrid','-TimeoutSeconds','120')
        } elseif ($Phase -eq 'ClosedPeak') {''', 1)
    old = "'-MacroArgument2','Excel','-TimeoutSeconds','240','-VerifyResultsReopen'"
    assert code.count(old) == 1
    code = code.replace(old, "'-MacroArgument2','Excel','-TimeoutSeconds','600','-VerifyResultsReopen'", 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'working_hybrid_connected': True, 'private_preparation_switches': False,
        'spatial_half_step_changed': False, 'material_tangent_perturbation_changed': False,
        'directed_stock_watchdog_seconds': 600, 'full_acceptance_completed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('WORKING INTEGRATED HYBRID STOCK AND REGRESSIONS READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
