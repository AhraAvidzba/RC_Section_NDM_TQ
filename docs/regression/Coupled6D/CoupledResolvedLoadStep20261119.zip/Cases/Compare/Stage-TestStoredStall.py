"""ДЛЯ ТЕСТОВ. Готовит независимый численный контроль одного фактического отказа без смены материальной истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Удерживает точные массивы VBA в памяти; внешний процесс получает только значения остатка и матрицы."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardStallTangent.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    def TestOnce(code, old, new):
        """Запрещает неоднозначное изменение подготовленного тестового модуля."""
        assert code.count(old) == 1, old
        return code.replace(old, new, 1)
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, 'Option Explicit\n', '''Option Explicit
#If VBA7 Then
Private Declare PtrSafe Sub TestHybridSleep Lib "kernel32" Alias "Sleep" (ByVal milliseconds As Long)
#Else
Private Declare Sub TestHybridSleep Lib "kernel32" Alias "Sleep" (ByVal milliseconds As Long)
#End If
''')
    old = 'Private mHardStallPendingTest As Collection, mHardStallLastTest As Collection, mHardStallCountTest As Long'
    code = TestOnce(code, old, old + '''
Public HardStoreStallRequestedTest As Boolean
Private mStoredSolverTest As CCoupledNewtonSolver, mStoredOperatorsTest As CCoupledElasticState
Private mStoredConcreteTest As CCoupledConcreteResponse, mStoredReinforcedTest As CCoupledReinforcedResponse
Private mStoredSidesTest As Collection, mStoredFieldsTest As Collection, mStoredTraceTest As CCoupledLoadTrace
Private mStoredFieldTest() As Double, mStoredBaseTest() As Double, mStoredDirectionTest() As Double, mStoredProjectionTest() As Double
Private mStoredExternalTest() As Double, mStoredDirectionExternalTest() As Double
Private mStoredFactorTest As Double, mStoredTargetTest As Double, mStoredArcTest As Double, mStoredModulusTest As Double
Private mStoredCalibrationTest As Variant, mStoredOptionsTest As Variant''')
    old = '    If HardStallRequestedTest Then TestReplayHardStall solver, operators, concrete, reinforced, sides, fields'
    code = TestOnce(code, old, old + ', trace, calibration, Array(initialSteps, attempts, maxIterations, absTol, relTol, lambdaTolerance, maximumLambda)')
    old = '''        ByVal history As Collection)
    If mHardStallLastTest Is Nothing'''
    code = TestOnce(code, old, '''        ByVal history As Collection, ByVal trace As CCoupledLoadTrace, ByVal calibration As Variant, ByVal options As Variant)
    If mHardStallLastTest Is Nothing''')
    old = '    Dim scales As Variant, modes As Variant, names As Variant, weak() As Double, linearized() As Double'
    code = TestOnce(code, old, '''    If HardStoreStallRequestedTest Then
        TestHoldHardStall solver, operators, concrete, reinforced, sides, history, trace, prefix, mHardStallLastTest, calibration, options
        Close #handle
        Exit Sub
    End If
''' + old)
    code += '\n' + (here / 'TestNativeStoredStall.bas.txt').read_text('utf-8-sig')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, "'Compile','StallTangent'", "'Compile','HybridStall','StallTangent'")
    code = TestOnce(code, "        if ($Phase -eq 'StallTangent') {", '''        if ($Phase -eq 'HybridStall') {
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHybridStall','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','480')
        } elseif ($Phase -eq 'StallTangent') {''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('tests/modTestCoupledElasticState.bas', 'Run-TestWorkingASD.ps1'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeStoredStall.bas.txt', here / 'TestHybridOptimizer.py'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'HybridStall', 'model_held_exactly_in_memory': True,
        'external_optimizer_only_for_tests': True, 'main_workbook_changed': False,
        'external_process_budget_seconds': 180, 'VBA_bridge_budget_seconds': 240})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('EXACT IN MEMORY STALL MODEL AND INDEPENDENT NUMERICAL BRIDGE READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
