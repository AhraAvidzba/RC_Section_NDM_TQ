"""ДЛЯ ТЕСТОВ. Готовит направленную книгу собственного гибридного метода на точном удержанном контексте."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Добавляет три рабочих компонента без подключения к штатному продолжению и отдельные тестовые реализации интерфейса."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestStoredStall.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for name in ('src/Interfaces/ICoupledEquationSystem.cls', 'src/Solver/CCoupledHybridFactorization.cls',
        'src/Solver/CCoupledHybridSolver.cls', 'tests/CHybridEquationsTest.cls', 'tests/modTestCoupledHybrid.bas'):
        file = repo / name
        (root / name).parent.mkdir(parents=True, exist_ok=True)
        (root / name).write_bytes(file.read_bytes())
        prep['inputs'][name] = sha256(file.read_bytes()).hexdigest().upper()
        prep['modules'].append(file.stem)
    name = 'tests/CHeldHybridEquationsTest.cls'
    (root / name).write_bytes((here / 'CHeldHybridEquationsTest.cls.txt').read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['modules'].append('CHeldHybridEquationsTest')
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig') + '\n' + (here / 'TestNativeVBAHybrid.bas.txt').read_text('utf-8-sig')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'Compile','HybridStall'"
    assert code.count(old) == 1
    code = code.replace(old, "'Compile','HybridCore','VBAHybridStall','HybridStall'", 1)
    old = "        if ($Phase -eq 'HybridStall') {"
    assert code.count(old) == 1
    code = code.replace(old, '''        if ($Phase -eq 'HybridCore') {
            $arguments+=@('-Macro','modTestCoupledHybrid.RunTestCoupledHybrid','-TimeoutSeconds','120')
        } elseif ($Phase -eq 'VBAHybridStall') {
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestVBAHybridStall','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','480')
        } elseif ($Phase -eq 'HybridStall') {''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'OwnVBAHybrid', 'external_optimizer_run': False,
        'runtime_components_added': 3, 'runtime_continuation_connected': False,
        'hybrid_max_evaluations': 350, 'hybrid_max_steps': 350, 'hybrid_residual_tolerance_MPa': 1e-10})
    for file in (Path(__file__), here / 'CHeldHybridEquationsTest.cls.txt', here / 'TestNativeVBAHybrid.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('OWN VBA HYBRID CORE AND HELD NATIVE CONTEXT READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
