"""ДЛЯ ТЕСТОВ. Удерживает штатный отказ HardShear при h=0,001 для внешней полной касательной тех же VBA-уравнений."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root):
    """Материалы, история, пространственный шаг и критерии штатные; инструментирование только читает и экспортирует данные."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestVBAHybrid.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    code, count = re.subn(r'(?m)^(Private Const SPATIAL_HALF_STEP As Double = )[\d.E+#-]+', r'\g<1>0.001', code)
    assert count == 1
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code, count = re.subn(r'(?m)^(Private Const HARD_PREPARED_HALF_TEST As Double = )[\d.E+#-]+', r'\g<1>0.001', code)
    assert count == 1
    old = '    RunTestHardStallTangent = RunTestHardFineTangent(outputRoot)'
    assert code.count(old) == 1
    code = code.replace(old, '    RunTestHardStallTangent = RunTestHardPrepared(outputRoot, "EarlyField")', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'TestHybridOptimizer.py'
    code = (root / name).read_text('utf-8-sig')
    old = '''            x = seed + scale * y
            matrix = TestRequest('J', x)
            assert matrix.shape == (61 * 61,) and np.all(np.isfinite(matrix))
            return matrix.reshape(61, 61) * scale[None, :]'''
    assert code.count(old) == 1
    code = code.replace(old, '''            matrix = np.empty((61, 61))
            for column in range(61):
                step = 1e-6 * max(1., abs(float(y[column])))
                plus, minus = y.copy(), y.copy()
                plus[column] += step
                minus[column] -= step
                matrix[:, column] = (TestResidual(plus) - TestResidual(minus)) / (2. * step)
            return matrix''', 1)
    old = '            """Читает обычную касательную VBA в порядке строк и учитывает только масштабы неизвестных."""'
    assert code.count(old) == 1
    code = code.replace(old, '            """Независимо дифференцирует полную невязку в масштабированных координатах, не меняя принятую историю."""', 1)
    old = "        'independent_numerical_algorithms': True, 'methods': [], 'native_validation_required': True}"
    assert code.count(old) == 1
    code = code.replace(old, "        'independent_numerical_algorithms': True, 'methods': [], 'native_validation_required': True,\n"
        "        'complete_central_jacobian': True, 'relative_coordinate_step': 1e-6, 'spatial_half_step_mm': .001}", 1)
    (root / name).write_text(code, encoding='utf-8')
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'modTestCoupledElasticState.RunTestHybridStall','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','480'"
    assert code.count(old) == 1
    code = code.replace(old, old.replace("'480'", "'600'"), 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'case': 'StockCompleteJacobian', 'spatial_half_step_mm': .001,
        'ordinary_material_perturbation_factor': 1., 'full_working_controller': True,
        'material_laws_changed': False, 'constitutive_history_held_in_VBA': True,
        'external_complete_central_jacobian': True, 'relative_coordinate_step': 1e-6,
        'native_unchanged_candidate_and_branch_validation_required': True,
        'global_probe_limit': 96, 'external_wall_budget_seconds': 180, 'outer_watchdog_seconds': 600,
        'diagnostic_not_a_capacity_result': True, 'full_acceptance_completed': False}
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('DEFAULT H STOCK STALL COMPLETE JACOBIAN CONTROL READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
