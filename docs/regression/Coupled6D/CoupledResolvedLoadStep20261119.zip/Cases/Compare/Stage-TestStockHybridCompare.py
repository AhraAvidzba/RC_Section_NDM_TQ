"""ДЛЯ ТЕСТОВ. Сравнивает рабочий резерв и внешний полный Якобиан на одной точной штатной истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Дополнительная рабочая проба не принимает материал; внешний контроль получает тот же исходный контекст."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestStockCompleteJacobian.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig') + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает фактический общий бюджет и признак публикации управляемой пробы.
Friend Function ReadHybridEffortTest() As Variant
    ReadHybridEffortTest = Array(mIterations, mEvaluations, mHybridSteps, mHybridMatrices, mHybridEvaluations, _
        IIf(mCandidateReady, 1, 0), mAcceptedRevision)
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '    Dim folder As String: folder = outputRoot & "\\Native\\HybridBridge"'
    assert code.count(old) == 1
    code = code.replace(old, '    Dim ownResult As String: ownResult = TestStockControlledHybrid(outputRoot)\n' + old, 1)
    old = '    RunTestHybridStall = setup & vbCrLf & "HYBRID_CONTROL;"'
    assert code.count(old) == 1
    code = code.replace(old, '    RunTestHybridStall = setup & vbCrLf & ownResult & vbCrLf & "HYBRID_CONTROL;"', 1)
    code += '\n' + (here / 'TestNativeStockHybridCompare.bas.txt').read_text('utf-8-sig')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'TestHybridOptimizer.py'
    code = (root / name).read_text('utf-8-sig')
    old = "result['methods'].append({'method': method, 'success': False, 'error': repr(error),"
    assert code.count(old) == 1
    code = code.replace(old, "result['methods'].append({'method': method, 'success': False, 'error': repr(error), 'traceback': traceback.format_exc(),", 1)
    (root / name).write_text(code, encoding='utf-8')
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for path in (Path(__file__), here / 'TestNativeStockHybridCompare.bas.txt'):
        (root / path.name).write_bytes(path.read_bytes())
        prep['inputs'][path.name] = sha256(path.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'StockOwnAndExternalCompleteJacobian', 'own_controlled_API_before_external': True,
        'own_api_max_iterations': 60, 'accepted_history_must_remain_exact': True, 'method_IO_error_traceback_recorded': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('SAME DEFAULT H HISTORY OWN AND EXTERNAL CONTROL READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
