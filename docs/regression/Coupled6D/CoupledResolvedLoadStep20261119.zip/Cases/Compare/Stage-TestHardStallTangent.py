"""ДЛЯ ТЕСТОВ. Снимает действительный отказ и проверяет линеаризацию на той же принятой истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Не меняет траекторию; вариации разностной касательной выполняет только после сохранения основных полей."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardFineTangent.py'))['TestStage'](repo, root, .001 / 128)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    def TestOnce(code, old, new):
        """Фиксирует единственное место читающего инструмента."""
        assert code.count(old) == 1, old
        return code.replace(old, new, 1)
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '        ReDim mCandidate(1 To mDegreeCount)\n        fraction = 1#: accepted = False: hasValidTrial = False'
    code = TestOnce(code, old, '''        If mControlActive And mUseSpatialHistory And modTestCoupledElasticState.HardStallRequestedTest Then _
            modTestCoupledElasticState.TestRememberHardStall current, correction, mAccepted, mMatrix, mResidual, mControlProjection, _
                mBaseLoad, mLoadDirection, currentLambda, mTargetControl, mArcLoadProjection, mConsistentControl, mAcceptedRevision, mExternal
''' + old)
    old = '        If Not accepted Then\n            If useSteelCorrection And mSteelBranchBuilds > 0'
    code = TestOnce(code, old, '''        If Not accepted Then
            If mControlActive And mUseSpatialHistory And modTestCoupledElasticState.HardStallRequestedTest Then _
                modTestCoupledElasticState.TestCommitHardStall
            If useSteelCorrection And mSteelBranchBuilds > 0''')
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Собирает читающую линеаризацию с явно заданным режимом касательной на восстановленной истории.
Friend Function TestHardStallLinearization(ByRef field() As Double, ByVal withMatrix As Boolean, ByVal mode As Long, _
        ByRef residual() As Double, ByRef matrix() As Double) As Boolean
    ReDim mExternal(1 To mDegreeCount)
    If Not Evaluate(field, withMatrix, recordTrial:=False, consistentBranch:=(mode = 1), refinedBranch:=(mode = 2)) Then Exit Function
    residual = mResidual
    If withMatrix Then matrix = mMatrix
    TestHardStallLinearization = True
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'src/Materials/CCoupledConcreteResponse.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '                If mode = ctmRefinedBranchConsistent Then delta = delta / 64#'
    code = TestOnce(code, old, '''                If modTestCoupledElasticState.HardStallTangentFactorTest > 0# And mASDFlow Is Nothing Then _
                    delta = STRAIN_PERTURBATION * (1# + Abs(strain(j))) * modTestCoupledElasticState.HardStallTangentFactorTest
''' + old)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = 'Public FineOrdinaryCDPTangentTest As Boolean'
    code = TestOnce(code, old, old + '''
Public HardStallRequestedTest As Boolean, HardStallTangentFactorTest As Double
Private mHardStallPendingTest As Collection, mHardStallLastTest As Collection, mHardStallCountTest As Long''')
    old = '    Close #handle\n    mHardPreparedReportTest = '
    code = TestOnce(code, old, '''    Close #handle
    If HardStallRequestedTest Then TestReplayHardStall solver, operators, concrete, reinforced, sides, fields
    mHardPreparedReportTest = ''')
    code += '\n' + (here / 'TestNativeHardStallTangent.bas.txt').read_text('utf-8-sig')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, "'Compile','FineTangent'", "'Compile','StallTangent','FineTangent'")
    code = TestOnce(code, "        if ($Phase -eq 'FineTangent') {", '''        if ($Phase -eq 'StallTangent') {
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardStallTangent','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','360')
        } elseif ($Phase -eq 'FineTangent') {''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledNewtonSolver.cls', 'src/Materials/CCoupledConcreteResponse.cls',
        'tests/modTestCoupledElasticState.bas', 'Run-TestWorkingASD.ps1'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeHardStallTangent.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'StallTangent', 'main_trajectory_unmodified': True,
        'tangent_factors_after_main': [1 / 64, 1, 4, 16, 64, 256], 'field_probes_are_equilibria': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('READ ONLY STALL TANGENT DIAGNOSTIC READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
