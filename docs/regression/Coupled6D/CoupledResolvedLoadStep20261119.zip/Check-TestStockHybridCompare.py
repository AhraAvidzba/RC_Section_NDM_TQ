"""ДЛЯ ТЕСТОВ. Проверяет собственную и внешнюю точки на одной штатной истории, не принимая флаг SciPy за критерий равновесия."""

from argparse import ArgumentParser
import csv
from io import StringIO
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestCheck(root, original, output):
    """Независимо собирает внешний свидетель, сравнивает три станции и проверяет бюджет рабочего API."""
    here = Path(__file__).resolve().parent
    validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
    main, fields = validate(root, 'HardEarlyField')
    candidate, candidate_fields = validate(root, 'HardEarlyField.HybridCandidate')
    first, first_fields = validate(original, 'HardEarlyField')
    assert len(fields) == len(first_fields) == 25 and len(candidate_fields) == 26
    assert np.array_equal(fields, first_fields) and np.array_equal(fields, candidate_fields[:25])
    assert not main['reversed_fields'] and not candidate['reversed_fields']
    rows = list(csv.reader(StringIO((root / 'Native/StockOwnHybrid.csv').read_text('cp1251')), delimiter=';'))
    record = next(row for row in rows if row and row[0] == 'CONTROL60')
    assert record[1] == 'True'
    factor, seconds = float(record[2]), float(record[3])
    stats = np.asarray(record[4:], float)
    assert stats.shape == (7,) and stats[0] == 3 and stats[2] == 2 and stats[3] == 1 and stats[4] == 125
    assert stats[1] == 135 and stats[5] == 1 and stats[0] <= 60
    unchanged = next(row for row in rows if row and row[0] == 'ACCEPTED_HISTORY_UNCHANGED')
    assert unchanged[1] == 'True' and float(unchanged[2]) == stats[6]
    own = np.asarray(next(row[1:] for row in rows if row and row[0] == 'FIELD'), float)
    actual = np.asarray(next(row[1:] for row in rows if row and row[0] == 'ACTUAL'), float)
    helpers = run_path(str(here / 'Check-TestHardHalfSteps.py'))
    _, load, _, _, _, _, b, slope = helpers['TestOperators'](root / 'Native/HardEarlyField.Operators.csv', 60, 43)
    main_rows = helpers['TestRows'](root / 'Native/HardEarlyField.csv')
    offset = np.asarray(next(row[1:] for row in main_rows if row[0] == 'OFFSET'), float)
    direction = np.asarray(next(row[1:] for row in main_rows if row[0] == 'DIRECTION'), float)
    options = np.asarray(next(row[1:] for row in main_rows if row[0] == 'OPTIONS'), float)
    force_scales = np.asarray([1 / load[0, 0], *([1 / load[1, 1]] * 3), *([1 / load[0, 0]] * 2)])
    force_norm = float(np.max(np.abs((actual - offset - factor * direction) / force_scales)))
    tolerance = options[3] + options[4] * float(np.max(np.abs((load @ (offset + factor * direction))[:56])))
    assert force_norm <= tolerance
    external = json.loads((root / 'Native/HybridBridge/Result.json').read_bytes())
    before = json.loads((original / 'Native/HybridBridge/Result.json').read_bytes())
    assert external['native_equilibrium_found'] and external['native_validation'][0:2] == [1., 1.]
    assert external['best_residual_MPa'] <= external['native_validation'][2]
    assert before['native_equilibrium_found'] and 'PermissionError' in before['methods'][0]['error']
    assert all('error' not in method for method in external['methods'])
    exact_seed = {}
    for sequence in (1, 2, 3):
        left = (root / f'Native/HybridBridge/response-{sequence}.bin').read_bytes()
        right = (original / f'Native/HybridBridge/response-{sequence}.bin').read_bytes()
        assert left == right
        exact_seed[str(sequence)] = True
    reference = np.frombuffer((root / 'Native/HybridBridge/BestCandidate.bin').read_bytes(), dtype='<f8')
    difference = own - reference[:60]
    strain_error = max(float(np.max(np.abs(np.einsum('pcd,d->pc', b + side * .001 * slope, difference)))) for side in (-1, 0, 1))
    lambda_error = abs(factor - float(reference[-1]))
    assert lambda_error < 1e-6 and strain_error < 1e-8
    result = {'main': main, 'external_candidate': candidate, 'own_API_lambda': factor, 'own_API_seconds': seconds,
              'own_API_effort': stats.tolist(), 'accepted_native_field_and_revision_unchanged': True,
              'saved_original_field_prefix_exact': 25, 'own_force_norm_MPa': force_norm, 'own_force_tolerance_MPa': tolerance,
              'seed_scales_and_first_residual_binary_exact_between_studies': exact_seed,
              'own_external_lambda_difference': lambda_error, 'own_external_three_station_strain_difference': strain_error,
              'external_result': external, 'first_study_IO_exception_retained': before['methods'][0]['error'],
              'source_metadata_mm_label_incorrect': True, 'actual_spatial_coordinate': 'z/L', 'spatial_half_step_dimensionless': .001,
              'generic_scipy_success_not_used_as_physical_criterion': True,
              'independent_material_reintegration': False, 'physical_capacity_certified': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('DEFAULT H OWN AND EXTERNAL EQUILIBRIA MATCH; ACCEPTED PREFIX 25 EXACT; ALL SIX OWN FORCES VERIFIED; CAPACITY OPEN')
    print('POINT DIFFERENCES', lambda_error, strain_error)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--original', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestCheck(args.root.resolve(), args.original.resolve(), args.out.resolve())
