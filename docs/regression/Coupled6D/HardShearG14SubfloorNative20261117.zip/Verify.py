"""Сверяет одну дополнительную поправку, исходную задачу и откат G14."""

from argparse import ArgumentParser
import json
from math import fsum,isclose
from pathlib import Path

import G14Verify as direction
import G13Verify as g13
import PriorVerify as prior


HERE=Path(__file__).resolve().parent


def inputs():
    plan=prior.read(HERE/'Fixture.json'); expected=prior.read(HERE/'Expected.json')
    for name,digest in plan['inputs'].items():
        assert prior.file_hash(HERE/name)==digest,name
    native=prior.read(HERE/'Prior/Verification.json')
    assert prior.file_hash(HERE/'Prior/Verification.json')==plan['prior_report_sha256']
    assert native['proof']['compiled_workbook_sha256']==plan['prior_compiled_workbook_sha256']
    trace=HERE/'Prior/HardG14Direction.csv'
    assert prior.file_hash(trace)==native['native_trace_sha256']
    old=direction.read_probe(trace)
    assert native['capture']['equation']==53 and native['capture']['original_fraction']==1/128
    assert old[0][-1][-1]['control']==prior.number(expected['old_G14']['control'])
    book=HERE/plan['workbook']
    if book.exists():
        assert prior.file_hash(book)==plan['source_workbook_sha256']
    return plan,expected,old


def parse(path):
    lines=path.read_text(encoding='cp1251').splitlines()
    assert lines.pop(0)=='HARDSHEAR-SUBFLOOR;1'
    raw=['HARDSHEAR-G13;1']; arms={}; active=None; state=None; label=None
    for line in lines:
        key,*p=line.split(';')
        if key=='ARM':
            assert active is None and p[0] not in arms
            active={'id':p[0],'setting':p[1:],'states':[],'branches':{},'checks':[],'unavailable':[]}
        elif key=='ARM-END':
            assert active is not None and active['id']==p[0] and state is None
            arms[p[0]]=active; active=None; label=None
        elif key=='STATE':
            assert active is not None and state is None
            state={'role':p[0],'data':p[1:]}
        elif key=='END-STATE':
            assert state is not None
            active['states'].append(state); state=None
        elif state is not None:
            assert key.startswith('STATE-') and key not in state
            state[key]=prior.numbers(p)
        elif key=='STATIONS' and active is not None:
            label=p[0]; assert label not in active['branches']
            active['branches'][label]={}
        elif key=='STATION' and active is not None:
            data=active['branches'][label]; point=(int(p[0]),int(p[1])); assert point not in data
            data[point]=p[2:]
        elif key=='STEP-GATE':
            active['checks'].append(p)
        elif key=='UNAVAILABLE':
            active['unavailable'].append(p)
        elif active is not None:
            assert key not in active
            active[key]=p
        else:
            raw.append(line)
    assert active is None and state is None
    return g13.parse(direction.TextTrace(raw)),arms


def inspect_state(state,p,ray,normalization):
    h,factor,norm,tau,control=prior.numbers(state['data'][:5]); gauge_ok=prior.received(state['data'][5])
    area,length,modulus,_=normalization
    field=state['STATE-FIELD']; residual=state['STATE-RESIDUAL']; target=state['STATE-TARGET']; actual=state['STATE-ACTUAL']
    assert len(residual)==60 and len(actual)==len(target)==6
    assert all(isclose(a,factor*b,rel_tol=3e-15) for a,b in zip(target,ray,strict=True))
    scales=(area,area*length,area*length,area*length,area,area)
    six=max(abs(a-b)/s for a,b,s in zip(target,actual,scales,strict=True)); weak=max(map(abs,residual[:56]))
    gauges=max(map(abs,residual[56:])); assert gauge_ok==(gauges<=tau/modulus)
    assert isclose(norm,max(six,weak,abs(control)),rel_tol=3e-12,abs_tol=2e-14)
    return {**state,'h':h,'lambda':factor,'norm':norm,'tau':tau,'gauge_ok':gauge_ok,'six_norm_MPa':six,
            'weak_norm_MPa':weak,'gauge_norm':gauges,'control_absolute':fsum(x*y for x,y in zip(p,field,strict=True))}


def verify(plan,expected,old):
    folder=HERE/'Native/Order10'; proof=prior.native_proof(plan,folder); trace=folder/'HardSubfloor.csv'
    (geometry,points,histories,_,_,prefix),arms=parse(trace)
    norm=prior.verify_geometry(plan,10,geometry,points)
    for key in expected['geometry']:
        assert geometry[key]==expected['geometry'][key]
    p,ray=(prior.numbers(geometry[k]) for k in ('PROJECTION','DIRECTION'))
    accepted=geometry['VIRGIN']; exact=0
    for a,b in zip(prefix,expected['fields']):
        assert a['commit'] and a['label']==b['label'] and a['START-FIELD']==accepted and a['SEED']==b['FIELD']
        g13.row_check(a,p,ray,*norm[:3]); accepted=a['STOP-FIELD']
        if a['ready']:
            exact+=1
            assert all(a[k]==b[k] for k in g13.FIELDS)
    outcome,n,count=geometry['FINISH']
    assert exact==int(n)
    result={'outcome':outcome,'prefix_exact':exact,'arm_diagnostics':{},'no_new_physical_state_committed':True,
            'physical_limit_certified':False,'native_trace_sha256':prior.file_hash(trace),'proof':proof}
    if outcome=='COMPLETE':
        assert exact==25 and len(prefix)==25 and count=='2' and tuple(arms)==('A','B')
        actual=expected['fields'][-1]['FIELD']
        for idx in ('24','25'):
            initial,replayed=histories[idx,'SOLVED'],histories[idx,'REBUILT']
            assert initial==replayed and len(initial[2])==initial[0]==9744
        aa,bb=(arms[v] for v in ('A','B'))
        before,tags,_,samples=old
        original=before[-1][-1]
        assert aa['setting']==bb['setting'] and aa['ARM-SEED']==bb['ARM-SEED']==original['SEED']
        goal,estimate,tolerance=prior.numbers(aa['setting'][:3]); cap=int(aa['setting'][3])
        assert (goal,estimate,tolerance,cap)==(original['control'],original['seed_factor'],5e-7,12)
        assert aa['WRONG-DIRECTION']==bb['WRONG-DIRECTION']
        capture=aa['WRONG-DIRECTION']; start_row,before_value,after_value,h,base,tau,steps,evaluations=capture[:8]
        assert capture[:8]==tags['CAPTURE']
        base=prior.number(base)
        assert aa['BASE-FIELD']==bb['BASE-FIELD']==samples[0]['DIR-FIELD']
        assert aa['BASE-CORRECTION']==bb['BASE-CORRECTION']==tags['CORRECTION']
        initial_field=prior.numbers(aa['BASE-FIELD']); correction=prior.numbers(aa['BASE-CORRECTION'])
        assert not aa['states'] and aa['ARM-SOLVER'][:5]==['False','6','10',steps,evaluations]
        assert len(bb['checks'])<=6
        guard=bb['GUARD-31']; lo=samples[0]['stations'][31,-1]; hi=samples[6]['stations'][31,-1]
        assert guard[:2]==['True','True'] and lo[1]!=hi[1]
        assert guard[2:4]==[str(lo[1]),str(hi[1])] and [int(k) for k in guard[4:]]==[lo[2],hi[2],lo[3],hi[3]]
        for arm in (aa,bb):
            assert arm['ARM-ANCHOR']==actual and arm['ARM-ROLLBACK']==['9744',*actual]
            assert int(arm['ARM-SOLVER'][3])<=cap
            checked=[inspect_state(s,p,ray,norm) for s in arm['states']]
            for state in checked:
                if state['role'] in ('STEP','RECORDED'):
                    assert all(isclose(a,b+state['h']*d,rel_tol=5e-14,abs_tol=2e-16) for a,b,d in zip(state['STATE-FIELD'],initial_field,correction[:60],strict=True))
                    assert isclose(state['lambda'],prior.number(capture[8])+state['h']*correction[60],rel_tol=1e-15)
                elif state['role']=='FINAL':
                    assert abs(state['control_absolute']-goal)<=state['tau']/norm[2] and state['norm']<=state['tau'] and state['gauge_ok']
            for index,test in enumerate(arm['checks'],8):
                h_value=prior.number(test[0]); assert h_value==1/2**index
                sample=next((s for s in checked if s['role']=='STEP' and s['h']==h_value),None)
                assert prior.received(test[1])==(sample is not None and sample['norm']<base*(1.-1e-4*h_value) and sample['gauge_ok'])
            took=arm.get('TAKEN')
            if took:
                assert arm['id']=='B' and arm['checks'][-1]==[took[0],'True','True']
                first,last=(arm['branches'][name] for name in ('BASE','STEP'))
                assert set(first)==set(last) and len(first)==300
                assert all(first[key][0]==last[key][0]=='ok' and first[key][2:]==last[key][2:] for key in first)
            final=[s for s in checked if s['role']=='FINAL']
            assert len(final)==int(prior.received(arm['ARM-SOLVER'][0]))
            slim=[{k:v for k,v in s.items() if not k.startswith('STATE-') and k!='data'} for s in checked]
            result['arm_diagnostics'][arm['id']]={'solver':arm['ARM-SOLVER'],'fraction_taken':prior.number(took[0]) if took else None,
                                                'checked_states':slim,'gate':arm.get('GUARD-31'),'unchanged_concrete_branch_signatures':300 if took else None}
        result['old_G14_target']=goal
        result['origin_norm_MPa']=base
    name=folder/'Verification.json'; raw=(json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
    if name.exists():
        assert name.read_bytes()==raw
    else:
        name.write_bytes(raw)
    print(f'HARDSHEAR_SUBFLOOR: {outcome}; prefix={exact}; sha={prior.file_hash(name)}')


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',action='store_true')
    parser.add_argument('--order',type=int,choices=(10,))
    args=parser.parse_args()
    plan,expected,old=inputs()
    if args.inputs:
        print('HARDSHEAR_SUBFLOOR_INPUTS: PASS')
    else:
        assert args.order==10
        verify(plan,expected,old)


if __name__=='__main__':
    main()
