' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает штатный шаг и единственный более мелкий старт при точно той же цели G14.
Private Function RunHardG14DirectionTest(ByVal history As Collection, ByVal snapshots As Collection, ByRef controls() As Double, _
        ByRef factors() As Double, ByRef projection() As Double, ByVal goal As Double, ByRef offset() As Double, _
        ByRef direction() As Double, ByVal started As Double, ByRef probes As Long) As String
    Const TOLERANCE As Double = 0.0000005
    Const ITERATIONS As Long = 12
    Dim recent() As Double, earlier() As Double, seed As Variant, saved() As Double, coordinate As Double, span As Double
    Dim ratio As Double, initialLambda As Double, i As Long
    recent = history(25): earlier = history(24): saved = snapshots(2)
    coordinate = HardFineControlTest(projection, recent)
    span = coordinate - HardFineControlTest(projection, earlier)
    If span <= 0# Or goal <= coordinate Then
        RunHardG14DirectionTest = "INVALID_WINDOW": Exit Function
    End If
    ratio = (goal - coordinate) / span
    initialLambda = factors(25) + ratio * (factors(25) - factors(24))
    For i = 1 To UBound(recent): recent(i) = recent(i) + ratio * (recent(i) - earlier(i)): Next i
    seed = recent
    Dim arm As Variant, lambda As Double, solved As Boolean, status As CResultMeta, accepted() As Double
    For Each arm In Array("A", "B")
        If Not ReplayAcceptedFields(history, 25) Then
            RunHardG14DirectionTest = "ROLLBACK_REFUSED": Exit Function
        End If
        If Not HardG13HistoryAgreesTest(saved) Then
            RunHardG14DirectionTest = "ROLLBACK_REFUSED": Exit Function
        End If
        CopyAccepted accepted
        WriteHardRankRowTest "ARM;" & CStr(arm) & ";" & HardRankBitsTest(goal) & ";" & HardRankBitsTest(initialLambda) & ";" & _
            HardRankBitsTest(TOLERANCE) & ";" & CStr(ITERATIONS)
        WriteHardRankRowTest "ARM-SEED;" & HardRankVectorTest(recent)
        WriteHardRankRowTest "ARM-ANCHOR;" & HardRankVectorTest(accepted)
        mHardSubfloorEnabledTest = (arm = "B")
        mHardG14CapturedTest = False: mHardG14ArmedTest = True
        probes = probes + 1
        solved = TryDeformationStep(offset, direction, projection, goal, initialLambda, lambda, _
            TOLERANCE, TOLERANCE, ITERATIONS, consistentControl:=True, initialField:=seed)
        mHardG14ArmedTest = False
        Set status = ResultMeta
        WriteHardRankRowTest "ARM-SOLVER;" & CStr(solved) & ";" & CStr(status.InternalStatus) & ";" & CStr(status.ResultCode) & ";" & _
            CStr(mIterations) & ";" & CStr(mEvaluations) & ";" & Replace(status.DiagnosticDetails, ";", "|")
        If solved Then
            Dim field() As Double, actual() As Double, load(1 To COMPONENT_COUNT) As Double
            CopyTrial field, actual
            For i = 1 To COMPONENT_COUNT: load(i) = offset(i) + lambda * direction(i): Next i
            RecordHardSubfloorStateTest "FINAL", 0#, lambda, field, load, EquilibriumNorm(load, field), _
                EquilibriumTolerance(TOLERANCE, TOLERANCE), GaugesVerified(EquilibriumTolerance(TOLERANCE, TOLERANCE))
        End If
        DiscardStep
        If Not HardG13HistoryAgreesTest(saved) Then
            RunHardG14DirectionTest = "ROLLBACK_REFUSED": Exit Function
        End If
        CopyAccepted accepted
        WriteHardRankRowTest "ARM-ROLLBACK;" & CStr(UBound(saved)) & ";" & HardRankVectorTest(accepted)
        WriteHardRankRowTest "ARM-END;" & CStr(arm)
    Next arm
    RunHardG14DirectionTest = "COMPLETE"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подтверждает наблюдаемую смену ветви и применяет строго меньшие доли одной поправки.
Private Function TryHardSubfloorTest(ByRef field() As Double, ByVal lambda As Double, ByRef correction() As Double, _
        ByVal equation As Long, ByVal valueBefore As Double, ByVal valueAfter As Double, ByVal priorFraction As Double, _
        ByVal norm As Double, ByVal tolerance As Double, ByRef load() As Double, ByVal absoluteTolerance As Double, _
        ByVal relativeTolerance As Double, ByRef candidateLambda As Double, ByRef candidateNorm As Double, _
        ByRef candidateTolerance As Double) As Boolean
    mHardG14ArmedTest = False: mHardG14CapturedTest = True
    WriteHardRankRowTest "WRONG-DIRECTION;" & CStr(equation) & ";" & HardRankBitsTest(valueBefore) & ";" & HardRankBitsTest(valueAfter) & ";" & _
        HardRankBitsTest(priorFraction) & ";" & HardRankBitsTest(norm) & ";" & HardRankBitsTest(tolerance) & ";" & _
        CStr(mIterations) & ";" & CStr(mEvaluations) & ";" & HardRankBitsTest(lambda)
    WriteHardRankRowTest "BASE-FIELD;" & HardRankVectorTest(field)
    WriteHardRankRowTest "BASE-CORRECTION;" & HardRankVectorTest(correction)
    If Not mHardSubfloorEnabledTest Then Exit Function
    If Not mControlActive Or Not mConsistentControl Or priorFraction <> MIN_FRACTION Then Exit Function
    Dim trial() As Double, i As Long
    trial = field
    For i = 1 To mDegreeCount: trial(i) = field(i) + priorFraction * correction(i): Next i
    Dim oldPlastic As Boolean, newPlastic As Boolean, oldCertain As Boolean, currentCertain As Boolean
    Dim oldSign As Long, newSign As Long, oldSubsteps As Long, newSubsteps As Long
    HardSubfloorPoint31Test field, oldPlastic, oldSign, oldSubsteps, oldCertain
    HardSubfloorPoint31Test trial, newPlastic, newSign, newSubsteps, currentCertain
    WriteHardRankRowTest "GUARD-31;" & CStr(oldCertain) & ";" & CStr(currentCertain) & ";" & CStr(oldPlastic) & ";" & _
        CStr(newPlastic) & ";" & CStr(oldSign) & ";" & CStr(newSign) & ";" & CStr(oldSubsteps) & ";" & CStr(newSubsteps)
    If Not oldCertain Or Not currentCertain Or oldPlastic = newPlastic Then Exit Function

    Dim divisor As Variant, fraction As Double, passed As Boolean, sameBranch As Boolean
    For Each divisor In Array(256#, 512#, 1024#, 2048#, 4096#, 8192#)
        fraction = 1# / CDbl(divisor)
        For i = 1 To mDegreeCount: trial(i) = field(i) + fraction * correction(i): Next i
        candidateLambda = lambda + fraction * correction(mDegreeCount + 1)
        SetControlledLoad candidateLambda, load
        sameBranch = False: passed = False
        If Evaluate(trial, False, recordTrial:=False) Then
            candidateTolerance = EquilibriumTolerance(absoluteTolerance, relativeTolerance)
            candidateNorm = EquilibriumNorm(load, trial)
            passed = candidateNorm < norm * (1# - MIN_PROGRESS * fraction) And GaugesVerified(candidateTolerance)
            If passed Then sameBranch = HardSubfloorSameConcreteTest(field, trial)
            RecordHardSubfloorStateTest "STEP", fraction, candidateLambda, trial, load, candidateNorm, candidateTolerance, _
                GaugesVerified(candidateTolerance)
        Else
            WriteHardRankRowTest "UNAVAILABLE;" & HardRankBitsTest(fraction) & ";" & CStr(mFailureCode)
            If mFailureCode <> sfcNumericalFailure And mFailureCode <> sfcSingularTangent Then Exit Function
        End If
        WriteHardRankRowTest "STEP-GATE;" & HardRankBitsTest(fraction) & ";" & CStr(passed) & ";" & CStr(sameBranch)
        If Not (sameBranch And passed) Then GoTo NextFraction
        If Not Evaluate(trial, False) Then Exit Function ' Снова проверяем тот же корень при записи пробы.
        candidateTolerance = EquilibriumTolerance(absoluteTolerance, relativeTolerance)
        candidateNorm = EquilibriumNorm(load, trial)
        If candidateNorm >= norm * (1# - MIN_PROGRESS * fraction) Or Not GaugesVerified(candidateTolerance) Then Exit Function
        mCandidate = trial
        RecordHardSubfloorStateTest "RECORDED", fraction, candidateLambda, trial, load, candidateNorm, candidateTolerance, True
        WriteHardRankRowTest "STATIONS;BASE"
        RecordHardG13StationsTest field
        WriteHardRankRowTest "STATIONS;STEP"
        RecordHardG13StationsTest trial
        WriteHardRankRowTest "TAKEN;" & HardRankBitsTest(fraction)
        TryHardSubfloorTest = True
        Exit Function
NextFraction:
    Next divisor
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает пластический флаг, знак и подшаги конкретной станции первого перехода.
Private Sub HardSubfloorPoint31Test(ByRef field() As Double, ByRef plastic As Boolean, ByRef principal As Long, _
        ByRef subdivisions As Long, ByRef known As Boolean)
    Dim response As CCoupledReinforcedResponse: Set response = YieldResponse(-1)
    Dim strain(1 To COMPONENT_COUNT) As Double
    YieldStrain 31, -1, field, strain
    known = response.TryReadConcreteBranch(31, strain, plastic, principal, subdivisions)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Требует одинаковые признаки всех бетонных откликов от той же принятой истории.
Private Function HardSubfloorSameConcreteTest(ByRef old() As Double, ByRef trial() As Double) As Boolean
    Dim response As CCoupledReinforcedResponse, point As Long, side As Long
    Dim strain(1 To COMPONENT_COUNT) As Double, plastic As Boolean, trialPlastic As Boolean
    Dim principal As Long, trialPrincipal As Long, substeps As Long, trialSubsteps As Long
    For point = 1 To mSection.ConcretePointCount
        For side = -1 To 1
            Set response = YieldResponse(side)
            YieldStrain point, side, old, strain
            If Not response.TryReadConcreteBranch(point, strain, plastic, principal, substeps) Then Exit Function
            YieldStrain point, side, trial, strain
            If Not response.TryReadConcreteBranch(point, strain, trialPlastic, trialPrincipal, trialSubsteps) Then Exit Function
            If plastic <> trialPlastic Or principal <> trialPrincipal Or substeps <> trialSubsteps Then Exit Function
        Next side
    Next point
    HardSubfloorSameConcreteTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает все уравнения и нагрузку, включая знак исходного поперечного усилия.
Private Sub RecordHardSubfloorStateTest(ByVal name As String, ByVal fraction As Double, ByVal lambda As Double, _
        ByRef field() As Double, ByRef load() As Double, ByVal norm As Double, ByVal tolerance As Double, ByVal gauges As Boolean)
    WriteHardRankRowTest "STATE;" & name & ";" & HardRankBitsTest(fraction) & ";" & HardRankBitsTest(lambda) & ";" & _
        HardRankBitsTest(norm) & ";" & HardRankBitsTest(tolerance) & ";" & HardRankBitsTest(ControlResidual(field)) & ";" & CStr(gauges)
    WriteHardRankRowTest "STATE-FIELD;" & HardRankVectorTest(field)
    WriteHardRankRowTest "STATE-RESIDUAL;" & HardRankVectorTest(mResidual)
    WriteHardRankRowTest "STATE-TARGET;" & HardRankVectorTest(load)
    WriteHardRankRowTest "STATE-ACTUAL;" & HardRankVectorTest(mTrialResultants)
    WriteHardRankRowTest "END-STATE"
End Sub
