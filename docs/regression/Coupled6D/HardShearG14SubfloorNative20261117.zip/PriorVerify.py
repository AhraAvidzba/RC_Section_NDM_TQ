"""Независимо сверяет точки интегрирования, поля, усилия и диапазоны двух проб."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum, isclose, isfinite, ulp
from pathlib import Path
from struct import unpack


HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def file_hash(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def number(token):
    value, = unpack(">d", bytes.fromhex(token))
    assert isfinite(value)
    return value


def numbers(tokens):
    return list(map(number, tokens))


def close(a, b, abs_tol=0.):
    return isclose(a, b, rel_tol=1e-13, abs_tol=abs_tol)


def received(flag):
    assert flag in ("True", "False"), flag
    return flag == "True"


def inputs():
    plan = read(HERE / "Fixture.json")
    for path, expected in plan["inputs"].items():
        assert file_hash(HERE / path) == expected, path
    assert file_hash(HERE / "PriorVerification.json") == plan["prior_report_sha256"]
    if (HERE / plan["workbook"]).exists():
        assert file_hash(HERE / plan["workbook"]) == plan["source_workbook_sha256"]
    assert plan["orders"] == [5, 10] and plan["basis_spans"] == [1, 1]
    assert plan["ray"] == [28000., 510000., 180000., 1500000., 17000., -7100.]
    assert all(a < b for a, b in zip([0.] + plan["prefix"], plan["prefix"] + plan["probes"][:1]))
    assert len(plan["probes"]) == 6 and sorted(plan["probes"]) == plan["probes"]
    return plan


def parse(path, order):
    raw = path.read_text(encoding="cp1251").splitlines()
    assert raw[0] == f"HARDSHEAR-MESH-GATE;1;{order}"
    tags, quadrature, finished = {}, {}, []
    active = None
    for row in raw[1:]:
        key, *args = row.split(";")
        if key == "BEGIN":
            assert active is None
            active = {"label": args[0], "control": number(args[1]), "seed_factor": number(args[2]),
                      "committing": received(args[3]), "stations": {}}
        elif key == "END":
            assert active is not None and active["label"] == args[0]
            active["ready"] = received(args[1])
            finished.append(active)
            active = None
        elif key == "QUAD":
            point = int(args[0])
            assert point not in quadrature
            quadrature[point] = numbers(args[1:])
        elif key == "SAMPLE":
            assert active is None and finished[-1]["ready"] and "delta" not in finished[-1]
            finished[-1]["delta"] = number(args[0])
        elif key == "STATION":
            point, side = int(args[0]), int(args[1])
            p = (point, side)
            assert active is not None and p not in active["stations"]
            if args[2] == "ok":
                active["stations"][p] = (number(args[3]), received(args[4]), int(args[5]), int(args[6]))
            else:
                assert args[2:] == ["failed"]
                active["stations"][p] = None
        elif active is None:
            assert key not in tags and key in {"MESH", "OFFSET", "DIRECTION", "PROJECTION", "VIRGIN", "PREFIX-END", "ANCHOR", "DONE"}, key
            tags[key] = args
        else:
            assert key not in active and key in {"SOLVER", "FIELD", "TARGET", "ACTUAL", "RESIDUAL", "BALANCE", "BOUND", "STATIONS"}, key
            active[key] = args
    assert active is None and "DONE" in tags
    return tags, quadrature, finished


def verify_geometry(plan, order, tags, points):
    reported_order, concrete, all_points = map(int, tags["MESH"][:3])
    area, length, modulus = numbers(tags["MESH"][3:])
    assert reported_order == order and concrete == order**2 and all_points == concrete + 18
    width, height = plan["geometry_mm"]
    assert close(area, plan["area_mm2"]) and close(length, plan["length_scale_mm"])
    assert modulus == plan["material"]["E_MPa"]
    assert set(points) == set(range(1, concrete + 1))
    nearest_cells = set()
    for x, y, weight in points.values():
        ix_raw = (x + width/2.) / (width/order) - .5
        iy_raw = (y + height/2.) / (height/order) - .5
        ix, iy = round(ix_raw), round(iy_raw)
        assert 0 <= ix < order and 0 <= iy < order and (ix, iy) not in nearest_cells
        assert abs(ix-ix_raw) <= 2e-12 and abs(iy-iy_raw) <= 2e-12
        assert close(weight, area/concrete)
        nearest_cells.add((ix, iy))
    return area, length, modulus, all_points


def verify_field(record, projection, direction, area, length, modulus):
    assert "SOLVER" in record
    ok = received(record["SOLVER"][0])
    if not ok:
        assert not record["ready"] and "FIELD" not in record
        return
    factor, norm, tau, control_residual, longitudinal, transverse = numbers(record["BALANCE"][:6])
    verified = received(record["BALANCE"][6])
    assert longitudinal >= 0. and transverse >= 0.
    assert record["ready"] == (verified and max(longitudinal, transverse) <= 1.)
    field = numbers(record["FIELD"])
    target, actual, residual = map(numbers, (record["TARGET"], record["ACTUAL"], record["RESIDUAL"]))
    assert len(field) == len(residual) == 60 and len(target) == len(actual) == 6
    measured_control = fsum(p*v for p, v in zip(projection, field, strict=True))
    assert close(abs(control_residual), abs(measured_control-record["control"])*modulus, 1e-12)
    scales = (area, area*length, area*length, area*length, area, area)
    for signed, prescribed, integrated, unit in zip(direction, target, actual, scales, strict=True):
        assert close(prescribed, signed*factor)
        if verified:
            assert abs(integrated - prescribed) <= tau*unit + 32*ulp(max(abs(integrated), abs(prescribed)))
    if verified:
        assert factor > 0. and norm <= tau and abs(control_residual) <= tau
        assert max(map(abs, residual[:56])) <= tau
        assert max(map(abs, residual[56:])) <= tau/modulus
    record.update(factor=factor, norm=norm, tau=tau, field=field, longitudinal=longitudinal, transverse=transverse)
    if "BOUND" in record:
        assert not record["committing"] and verified
        if received(record["BOUND"][0]):
            uncertainty = number(record["BOUND"][1])
            assert uncertainty > 0.
            record["uncertainty"] = uncertainty


def secant(left, right):
    if "uncertainty" not in left or "uncertainty" not in right:
        return None
    width = right["control"]-left["control"]
    assert width > 0.
    nominal = right["factor"]-left["factor"]
    allowance = left["uncertainty"]+right["uncertainty"]
    return [(nominal-allowance)/width, (nominal+allowance)/width]


def native_proof(plan, folder):
    native = read(folder / "HardShear.txt.ProcessClosure.json")
    owner = read(folder / "HardShear.txt.Ownership.json")
    compile_close = read(HERE / "CompileClosure.json")
    compilation = read(HERE / "docs/regression/CodeUpdate.json")
    assert compilation["Compiled"] and not compilation["ProductionChanged"]
    assert sorted(compilation["Modules"]) == sorted(plan["modules"])
    assert compilation["ProductionSHA256"] == plan["source_workbook_sha256"]
    assert owner["SourceSHA256"] == compilation["WorkbookSHA256"]
    assert compile_close["State"] == "Absent" and owner["VerifiedNewOwner"]
    assert native["Passed"] and native["ChildHasExited"] and native["ChildExitCode"] == 0
    expected_close = native["Closure"]["FinalState"]
    assert expected_close["State"] == "Absent"
    assert (expected_close["PID"], expected_close["StartTicksUTC"]) == (owner["PID"], owner["StartTicksUTC"])
    report = (folder / "HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_YIELD_GATE: passed=1; failed=0" in report
    assert "RESULTS_SAVE_REOPEN:" in report and "equal=True" in report and "SOURCE_UNCHANGED: True" in report
    timer = float(next(row.split(": ", 1)[1] for row in report.splitlines() if row.startswith("RANK_TIME: ")).replace(",", "."))
    return {"compiled_workbook_sha256": owner["SourceSHA256"], "seconds": timer,
            "closure_sha256": file_hash(folder / "HardShear.txt.ProcessClosure.json")}


def verify(plan, order):
    folder = HERE / "Native" / f"Order{order}"
    proof = native_proof(plan, folder)
    path = folder / "HardYieldGate.csv"
    tags, points, steps = parse(path, order)
    area, length, modulus, all_points = verify_geometry(plan, order, tags, points)
    offset, direction, projection = (numbers(tags[key]) for key in ("OFFSET", "DIRECTION", "PROJECTION"))
    assert offset == [0.]*6 and all(close(a, b) for a,b in zip(plan["ray"], direction, strict=True))
    frozen = read(HERE / "Expected.json")
    assert projection == numbers(frozen["projection"])
    assert numbers(tags["VIRGIN"]) == [0.]*60
    assert len(steps) == int(tags["DONE"][0])
    reached, prefix_attempts = map(int, tags["PREFIX-END"])
    assert 0 <= reached <= 8 and prefix_attempts <= 24
    assert all(trial["committing"] for trial in steps[:prefix_attempts])
    assert all(not trial["committing"] for trial in steps[prefix_attempts:])
    for trial in steps:
        verify_field(trial, projection, direction, area, length, modulus)
        stations = trial["stations"]
        if "STATIONS" in trial:
            assert int(trial["STATIONS"][1]) == all_points
            assert set(stations) == {(point, side) for point in range(1, all_points+1) for side in (-1, 0, 1)}
    prefixes = [trial for trial in steps[:prefix_attempts] if trial["ready"] and trial["label"][0] in "PR"]
    assert len(prefixes) == reached
    assert all(close(a["control"], b) for a,b in zip(prefixes, plan["prefix"][:reached], strict=True))
    window = steps[prefix_attempts:]
    assert bool(window) == (reached == len(plan["prefix"]))
    if reached == len(plan["prefix"]):
        assert numbers(tags["ANCHOR"]) == prefixes[-1]["field"]
        assert len(window) == 6
        assert all(close(a["control"], b) for a,b in zip(window, plan["probes"], strict=True))
    slopes = [secant(a, b) for a,b in zip(window[:-1], window[1:], strict=True)]
    signs = [0 if slope is None or slope[0]<=0.<=slope[1] else (1 if slope[0] > 0. else -1) for slope in slopes]
    states = []
    for trial in window:
        states.append({key: trial.get(key) for key in ("control", "ready", "factor", "uncertainty", "norm", "tau",
                                                         "longitudinal", "transverse", "SOLVER")})
    transitions = []
    for a, b in zip(window[:-1], window[1:], strict=True):
        switched = [(*point, *points[point[0]][:2]) for point in a["stations"].keys() & b["stations"].keys()
                    if point[0] in points and a["stations"][point] and b["stations"][point]
                    and a["stations"][point][1] != b["stations"][point][1]]
        transitions.append(sorted(switched))
    classified = "control_window_incomplete"
    if len(window) == 6 and all(t["ready"] and "uncertainty" in t for t in window):
        classified = "signed_local_bracket" if 1 in signs and -1 in signs[signs.index(1)+1:] else "no_signed_bracket_in_sampled_window"
    result = {"order": order, "prefix_reached": reached, "prefix_attempts": prefix_attempts, "window": states,
              "secant_intervals": slopes, "secant_signs": signs, "concrete_transitions": transitions,
              "outcome": classified, "native_trace_sha256": file_hash(path), "physical_limit_certified": False, "proof": proof}
    result_path = folder / "Verification.json"
    raw = (json.dumps(result, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    if result_path.exists():
        assert result_path.read_bytes() == raw
    else:
        result_path.write_bytes(raw)
    print(f"HARDSHEAR_MESH: order={order}; {classified}; {file_hash(result_path)}")


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--inputs", action="store_true")
    cli.add_argument("--order", type=int, choices=[5, 10])
    args = cli.parse_args()
    plan = inputs()
    if args.inputs:
        print("HARDSHEAR_MESH_INPUTS: PASS")
    else:
        assert args.order is not None
        verify(plan, args.order)


if __name__ == "__main__":
    main()
