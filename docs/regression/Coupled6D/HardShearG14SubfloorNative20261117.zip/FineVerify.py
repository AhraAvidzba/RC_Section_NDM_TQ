"""Сверяет восстановленный буфер полей и независимое продолжение HardShear."""

from argparse import ArgumentParser
import json
from math import fsum, isclose
from pathlib import Path
import re

import PriorVerify as prior


HERE = Path(__file__).resolve().parent
LABELS = ["P1", "P2", "P3", "P4", "P5", "I6"]
STOP_CODES = {"PROBE_LIMIT", "CONTROL_BOUND", "MINIMUM_STEP", "PREFIX_REFUSED"}


def verify_embedded_vba(expected):
    path = HERE / "tests/modTestCoupledElasticState.bas"
    source = path.read_text(encoding="utf-8-sig")
    _, method = source.rsplit("Public Function ReplayHardYieldGateTest(", maxsplit=1)
    vectors, variables = [], []
    chunks = []
    for line in method.splitlines():
        if line.startswith('    packed = '):
            match = re.fullmatch(r'    packed = (?:packed & )?"([0-9A-F]{1,192})"', line)
            assert match is not None
            chunks.append(match[1])
        elif line.startswith("    HardRankUnpackTest packed, "):
            assert len(chunks) == 5
            vectors.append(''.join(chunks))
            variables.append(line.rsplit(', ', maxsplit=1)[1])
            chunks.clear()
    expected_vectors = [''.join(row['FIELD']) for row in expected['fields']]
    expected_vectors.append(''.join(expected['geometry']['PROJECTION']))
    assert not chunks and vectors == expected_vectors and variables == ["field"]*6 + ["projection"]
    replay_call = re.search(r'^    ReplayHardYieldGateTest = solver\.TraceHardFineResumeTest\(history, controls, factors, projection, _\n'
                            r'        ([0-9.]+)#, offset, direction\)$', method, re.MULTILINE)
    assert replay_call is not None and float(replay_call[1]) == expected["max_control"]


def verify_inputs():
    plan = prior.read(HERE / "Fixture.json")
    for name, expected in plan["inputs"].items():
        assert prior.file_hash(HERE / name) == expected, name
    actual = HERE / plan["workbook"]
    if actual.exists():
        assert prior.file_hash(actual) == plan["source_workbook_sha256"]
    source = prior.read(HERE / "Prior/Verification.json")
    assert prior.file_hash(HERE / "Prior/Verification.json") == plan["prior_report_sha256"]
    assert prior.file_hash(HERE / "Prior/HardYieldGate.csv") == source["native_trace_sha256"]
    assert source["proof"]["compiled_workbook_sha256"] == plan["prior_compiled_workbook_sha256"]
    expected = prior.read(HERE / "Expected.json")
    tags, _, rows = prior.parse(HERE / "Prior/HardYieldGate.csv", 10)
    ids = ("OFFSET", "DIRECTION", "PROJECTION")
    assert expected["geometry"] == {key: tags[key] for key in ids}
    exact = [row for row in rows if row["ready"] and row["committing"]]
    assert [row["label"] for row in exact] == LABELS
    for row, anchor in zip(exact, expected["fields"], strict=True):
        assert row["control"] == prior.number(anchor["control"])
        for field in ("label", "FIELD", "ACTUAL", "TARGET", "RESIDUAL", "BALANCE"):
            assert row[field] == anchor[field]
    verify_embedded_vba(expected)
    return plan, expected


def parse(path):
    data = path.read_text(encoding="cp1251").splitlines()
    assert data.pop(0) == "HARDSHEAR-FINE-RESUME;1"
    tags, points, rows = {}, {}, []
    active = None
    for line in data:
        key, *rest = line.split(";")
        if key == "BEGIN":
            assert active is None and rest[3] == "True"
            active = {"label": rest[0], "control": prior.number(rest[1]), "seed_factor": prior.number(rest[2]), "matrix": {}}
        elif key == "END":
            assert active is not None and active["label"] == rest[0]
            active["ready"] = prior.received(rest[1])
            rows.append(active)
            active = None
        elif key in ("QUAD", "K"):
            index = int(rest[0])
            mapping = points if key == "QUAD" else active["matrix"]
            assert index not in mapping
            mapping[index] = prior.numbers(rest[1:])
        elif active is None:
            assert key not in tags and key in {"MESH", "OFFSET", "DIRECTION", "PROJECTION", "VIRGIN", "ADAPT", "FINISH"}
            tags[key] = rest
        else:
            assert key not in active and key in {"SEED", "START-FIELD", "SOLVER", "FIELD", "TARGET", "ACTUAL", "RESIDUAL", "CONTROL",
                                                  "BALANCE", "BOUND", "DIRECTION-EQ", "BOUND-RES", "STOP-FIELD", "DECISION"}
            active[key] = rest
    assert active is None and tags["FINISH"][0] in STOP_CODES
    return tags, points, rows


def linear_solution(matrix, right):
    data = [row + [rhs] for row, rhs in zip(matrix, right, strict=True)]
    size = len(data)
    scales = [max(map(abs, row[:-1])) for row in data]
    assert min(scales) > 0.
    for col in range(size):
        pivot = max(range(col, size), key=lambda j: abs(data[j][col])/scales[j])
        assert abs(data[pivot][col]) > 1e-15 * scales[pivot]
        data[col], data[pivot] = data[pivot], data[col]
        scales[col], scales[pivot] = scales[pivot], scales[col]
        row = data[col]
        for below in data[col+1:]:
            amount = below[col]/row[col]
            for j in range(col, size+1):
                below[j] -= amount * row[j]
    result = [0.] * size
    for i in reversed(range(size)):
        result[i] = (data[i][-1] - fsum(data[i][j] * result[j] for j in range(i+1, size))) / data[i][i]
    return result


def uncertainty(row, projection, modulus):
    if "BOUND" not in row or not prior.received(row["BOUND"][0]):
        assert not row["matrix"]
        return None
    assert set(row["matrix"]) == set(range(1, 61))
    load_eq = prior.numbers(row["DIRECTION-EQ"])
    residual = prior.numbers(row["BOUND-RES"])
    bordered = [row["matrix"][i+1] + [-load_eq[i]] for i in range(60)]
    assert all(len(k) == 61 for k in bordered)
    bordered.append([modulus*p for p in projection] + [0.])
    for i in range(56, 60):
        bordered[i] = [modulus * a for a in bordered[i]]
    adjoint = linear_solution([list(col) for col in zip(*bordered, strict=True)], [0.]*60 + [1.])
    constraint = abs(prior.number(row["BALANCE"][3]))
    radius = max(row["tau"], max(map(abs, residual[:56])), modulus * max(map(abs, residual[56:])), constraint)
    independent = radius*fsum(map(abs, adjoint)) + 2e-12*(1.+abs(row["factor"]))
    recorded = prior.number(row["BOUND"][1])
    assert recorded > 0. and isclose(recorded, independent, rel_tol=1e-7, abs_tol=1e-13)
    return max(recorded, independent)


def verify_row(row, projection, direction, area, length, modulus):
    ordinary = dict(row)
    ordinary.pop("BOUND", None)
    ordinary["committing"] = True
    ordinary["ready"] = False
    if "BALANCE" in row:
        ordinary["ready"] = prior.received(row["BALANCE"][-1]) and max(prior.numbers(row["BALANCE"][4:6])) <= 1.
    prior.verify_field(ordinary, projection, direction, area, length, modulus)
    if "BALANCE" in row:
        row.update({k: ordinary[k] for k in ("factor", "norm", "tau", "field", "longitudinal", "transverse")})
        physical_control = fsum(p*x for p,x in zip(projection, row["field"], strict=True))
        row["coordinate"] = prior.number(row["CONTROL"][0])
        assert abs(row["coordinate"] - physical_control) <= 4e-18
        row["uncertainty"] = uncertainty(row, projection, modulus)
    assert row["ready"] == (row["DECISION"] == ["ACCEPTED"])
    if row["ready"]:
        assert ordinary["ready"] and row["STOP-FIELD"] == row["FIELD"]
    else:
        assert row["STOP-FIELD"] == row["START-FIELD"]


def record(row):
    keys = ("label", "control", "coordinate", "factor", "norm", "tau", "uncertainty", "longitudinal", "transverse", "DECISION", "SOLVER")
    return {k: row[k] for k in keys if k in row}


def derivative(a, b):
    if a["uncertainty"] is None or b["uncertainty"] is None:
        return None
    length = b["coordinate"] - a["coordinate"]
    delta = b["factor"] - a["factor"]
    uncertainty = a["uncertainty"] + b["uncertainty"]
    assert length > 0.
    low, high = (delta-uncertainty)/length, (delta+uncertainty)/length
    return {"left": a["label"], "right": b["label"], "slope_interval": [low, high],
            "sign": 1 if low>0. else -1 if high<0. else 0}


def continuation(start, rows, tags, expected):
    if len(start) != len(LABELS):
        assert not rows
        return []
    assert len(start) >= 2
    old, current = start[-2:]
    a = tags["ADAPT"]
    nominal, minimum, maximum, control_bound = prior.numbers(a[:4])
    cap = int(a[4])
    assert cap == expected["max_probes"] and len(rows) <= cap
    assert nominal == (current["coordinate"] - old["coordinate"]) / 16.
    assert minimum == nominal / 64. and maximum == 4. * nominal and control_bound == expected["max_control"]
    increment, consecutive = nominal, 0
    accepted = []
    for index, row in enumerate(rows, 1):
        assert row["label"] == f"F{index}" and increment >= minimum
        target = min(control_bound, current["coordinate"] + increment)
        assert row["control"] == target and target > current["coordinate"]
        ratio = (target - current["coordinate"]) / (current["coordinate"] - old["coordinate"])
        predicted = [x + ratio*(x-y) for x,y in zip(current["field"], old["field"], strict=True)]
        assert all(isclose(a,b,rel_tol=3e-14,abs_tol=3e-16) for a,b in zip(predicted, prior.numbers(row["SEED"]), strict=True))
        assert isclose(row["seed_factor"], current["factor"] + ratio*(current["factor"]-old["factor"]), abs_tol=1e-15)
        if row["ready"]:
            assert row["coordinate"] > current["coordinate"]
            motion = max(abs(a-b) for a,b in zip(predicted[:56], current["field"][:56], strict=True))
            deviation = max(abs(a-b) for a,b in zip(predicted[:56], row["field"][:56], strict=True))
            assert deviation <= expected["local_predictor_deviation_factor"] * motion and motion > 0.
            old, current = current, row
            accepted.append(row)
            consecutive += 1
            if consecutive >= 2:
                increment = min(maximum, increment * 1.4)
        else:
            consecutive = 0
            increment *= .5
    return accepted


def verify(plan, expected):
    folder = HERE / "Native/Order10"
    proof = prior.native_proof(plan, folder)
    path = folder / "HardFineResume.csv"
    tags, points, raw = parse(path)
    area, length, modulus, _ = prior.verify_geometry(plan, 10, tags, points)
    for k in ("OFFSET", "DIRECTION", "PROJECTION"):
        assert tags[k] == expected["geometry"][k]
    direction, projection = prior.numbers(tags["DIRECTION"]), prior.numbers(tags["PROJECTION"])
    final_field = tags["VIRGIN"]
    assert prior.numbers(final_field) == [0.]*60
    for row in raw:
        assert row["START-FIELD"] == final_field
        verify_row(row, projection, direction, area, length, modulus)
        final_field = row["STOP-FIELD"]
    prefix = [row for row in raw if not row["label"].startswith("F")]
    assert [row["label"] for row in prefix] == LABELS[:len(prefix)]
    restored = []
    for row, anchor in zip(prefix, expected["fields"]):
        assert row["control"] == prior.number(anchor["control"]) and row["SEED"] == anchor["FIELD"]
        assert row["seed_factor"] == prior.number(anchor["BALANCE"][0])
        if row["ready"]:
            assert row["FIELD"] == anchor["FIELD"] and row["TARGET"] == anchor["TARGET"] and row["ACTUAL"] == anchor["ACTUAL"]
            assert row["BALANCE"][0] == anchor["BALANCE"][0]
            restored.append(row)
    reason, prefix_count, probes, *reported_accepts = tags["FINISH"]
    assert int(prefix_count) == len(restored)
    if reason == "PREFIX_REFUSED":
        assert len(prefix) < 7 and len(restored) == len(prefix) - 1
    else:
        assert len(restored) == len(LABELS)
    adaptive = raw[len(prefix):]
    accepted = continuation(restored, adaptive, tags, expected)
    assert len(adaptive) == int(probes) and len(accepted) == (int(reported_accepts[0]) if reported_accepts else 0)
    branch = restored[-1:] + accepted
    intervals = [derivative(a, b) for a,b in zip(branch[:-1], branch[1:], strict=True)]
    signs = [value["sign"] for value in intervals if value]
    result = {"outcome": reason, "prefix_bit_identical_count": len(restored),
              "prefix_exact_residual_count": sum(a["RESIDUAL"] == b["RESIDUAL"] for a,b in zip(restored, expected["fields"])),
              "prefix": [record(row) for row in prefix], "attempts": [record(row) for row in adaptive],
              "positive_intervals": signs.count(1), "negative_intervals": signs.count(-1),
              "secants": intervals, "max_confirmed": record(max(restored+accepted, key=lambda row: row["factor"])) if restored else None,
              "physical_limit_certified": False, "native_trace_sha256": prior.file_hash(path), "proof": proof}
    receipt = folder / "Verification.json"
    data = (json.dumps(result, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    if receipt.exists():
        assert receipt.read_bytes() == data
    else:
        receipt.write_bytes(data)
    print(f"HARDSHEAR_FINE_RESUME: {reason}; {len(restored)} exact; {len(accepted)} accepted; {prior.file_hash(receipt)}")


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--inputs", action="store_true")
    cli.add_argument("--order", type=int, choices=[10])
    args = cli.parse_args()
    plan, expected = verify_inputs()
    if args.inputs:
        print("HARDSHEAR_FINE_RESUME_INPUTS: PASS")
    else:
        assert args.order == 10
        verify(plan, expected)


if __name__ == "__main__":
    main()
