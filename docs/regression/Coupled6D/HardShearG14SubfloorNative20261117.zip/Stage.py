"""Готовит нативное сравнение одного дробления поправки ниже штатной границы."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = REPO/'docs/regression/Coupled6D/HardShearG14DirectionNative20261117.zip'
BASE_SHA = '596609AD534F382BE6FD06FCCBBBCCCF42D24A66236C34364D52164376AFCD02'
PROOF_SHA = '047F46B19AA43468A5A21B52D788DDBA5FEF4C1A1CF695A63C4C00790F855CA2'
BOOK_SHA = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
SOLVER = 'src/Solver/CCoupledNewtonSolver.cls'
TEST = 'tests/modTestCoupledElasticState.bas'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def code(source):
    assert max(map(len,source.splitlines())) < 1024
    return (source.rstrip().replace('\n','\r\n')+'\r\n').encode('utf-8')


def once(source,a,b):
    assert source.count(a) == 1, a
    return source.replace(a,b)


def seal(stage,name,raw):
    path=stage/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==raw,name
    else:
        path.write_bytes(raw)
    return sha(raw)


def solver(raw):
    source=text(raw)
    source=once(source,'Private mHardG14RowTest As Long, mHardG14PartsTest() As Double, mHardG14InitialRowTest As Double\n',
                'Private mHardSubfloorEnabledTest As Boolean\n')
    source=once(source,'                    CaptureHardG14DirectionTest current, currentLambda, correction, governingRow, baseEquation, _\n'
                       '                        trialEquation, trialFraction, norm, tolerance\n                    Exit Function\n',
                '                    If TryHardSubfloorTest(current, currentLambda, correction, governingRow, baseEquation, trialEquation, _\n'
                '                            trialFraction, norm, tolerance, load, absoluteTolerance, relativeTolerance, _\n'
                '                            candidateLambda, candidateNorm, candidateTolerance) Then GoTo AcceptHardSubfloorTest\n'
                '                    Exit Function\n')
    source=once(source,'        mIterations = mIterations + 1\n        If candidateNorm <= candidateTolerance And GaugesVerified(candidateTolerance) Then\n',
                'AcceptHardSubfloorTest:\n        mIterations = mIterations + 1\n'
                '        If candidateNorm <= candidateTolerance And GaugesVerified(candidateTolerance) Then\n')
    source=once(source,'    If mHardG14RowTest > 0 Then mHardG14InitialRowTest = mResidual(mHardG14RowTest)\n','')
    source=once(source,'    Dim hardG14BeforeTest As Double\n','')
    source=once(source,'            If mHardG14RowTest > 0 Then hardG14BeforeTest = mResidual(mHardG14RowTest)\n','')
    source=once(source,'''            If mHardG14RowTest > 0 Then
                mHardG14PartsTest(point, 1) = mResidual(mHardG14RowTest) - hardG14BeforeTest
                mHardG14PartsTest(point, 2) = mMinusStress(3): mHardG14PartsTest(point, 3) = mStress(3)
                mHardG14PartsTest(point, 4) = mPlusStress(3)
            End If
''','')
    start=source.index('Private Function RunHardG14DirectionTest(')
    start=source.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,start)
    addition=text((HERE/'Subfloor.bas').read_bytes())
    addition.encode('cp1251')
    return code(source[:start]+addition)


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready')
    cli.add_argument('--with-workbook',action='store_true')
    args=cli.parse_args()
    stage=args.destination.resolve()
    assert stage.is_relative_to(HERE) or stage.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(BASE.read_bytes())==BASE_SHA
    inputs={}
    with ZipFile(BASE) as archive:
        inherited=json.loads(archive.read('Fixture.json'))
        book=(REPO/inherited['workbook']).read_bytes()
        assert sha(book)==inherited['source_workbook_sha256']==BOOK_SHA
        proof=archive.read('Native/Order10/Verification.json')
        trace=archive.read('Native/Order10/HardG14Direction.csv')
        assert sha(proof)==PROOF_SHA and json.loads(proof)['native_trace_sha256']==sha(trace)
        for name,raw in (('Prior/Verification.json',proof),('Prior/HardG14Direction.csv',trace),('G14Verify.py',archive.read('Verify.py'))):
            inputs[name]=seal(stage,name,raw)
        for path,digest in inherited['inputs'].items():
            raw=archive.read(path)
            assert sha(raw)==digest,path
            if not(path.startswith(('src/','tools/')) or path in (TEST,'Run.ps1','Guard-IsolatedOffice.ps1','Expected.json',
                                                                  'F19Verify.py','G13Verify.py','FineVerify.py','PriorVerify.py')):
                continue
            if path==SOLVER:
                raw=solver(raw)
            elif path==TEST:
                raw=code(text(raw).replace('HardG14Direction.csv','HardSubfloor.csv').replace('HARDSHEAR-G14-DIRECTION;1','HARDSHEAR-SUBFLOOR;1'))
            elif path=='Run.ps1':
                raw=text(raw).replace('HardG14Direction','HardSubfloor').encode('utf-8')
            inputs[path]=seal(stage,path,raw)
    for path in ('Stage.py','Verify.py','Subfloor.bas'):
        inputs[path]=seal(stage,path,(HERE/path).read_bytes())
    if args.with_workbook:
        seal(stage,inherited['workbook'],book)
        seal(stage,'docs/regression/Diagnostic.xlsm',book)
        for path in ('Temp','Native/Order10'):
            (stage/path).mkdir(parents=True,exist_ok=True)
    manifest={**inherited,'inputs':inputs,'watchdog_seconds':150,'prior_archive_sha256':BASE_SHA,'prior_report_sha256':PROOF_SHA,
              'prior_compiled_workbook_sha256':json.loads(proof)['proof']['compiled_workbook_sha256'],
              'scope':'one guarded branch-preserving Newton update below ordinary floor; exact old G14, original tolerances, no commit'}
    print(stage,seal(stage,'Fixture.json',(json.dumps(manifest,indent=2)+'\n').encode('utf-8')))


if __name__=='__main__':
    main()
