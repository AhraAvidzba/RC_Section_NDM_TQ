"""Проверяет точный префикс G13, обе численные серии и интервалы секущих."""

from argparse import ArgumentParser
import json
from math import isclose
from pathlib import Path
import re

import F19Verify as previous
import FineVerify as fine
import PriorVerify as prior


HERE = Path(__file__).resolve().parent
TARGETS = ('L1S','L1T','L2S','L2T','L3S','L3T','R1S','R1T','R2S','R2T')
FIELDS = ('FIELD','ACTUAL','TARGET','RESIDUAL','CONTROL','BALANCE')


def inputs():
    plan = prior.read(HERE/'Fixture.json')
    expected = prior.read(HERE/'Expected.json')
    for path,fingerprint in plan['inputs'].items():
        assert prior.file_hash(HERE/path) == fingerprint, path
    report = prior.read(HERE/'Prior/Verification.json')
    assert prior.file_hash(HERE/'Prior/Verification.json') == plan['prior_report_sha256']
    assert report['proof']['compiled_workbook_sha256'] == plan['prior_compiled_workbook_sha256']
    raw = HERE/'Prior/HardF19.csv'
    assert prior.file_hash(raw) == report['native_trace_sha256']
    tags,_,_,rows = previous.parse(raw)
    selected = [r for r in rows if r['ready']]
    assert len(selected) == len(expected['fields']) == 25
    for a,b in zip(selected,expected['fields'],strict=True):
        assert a['label'] == b['label'] and a['control'] == prior.number(b['control'])
        assert all(a[k] == b[k] for k in FIELDS)
    assert {key:tags[key] for key in expected['geometry']} == expected['geometry']
    assert rows[-1]['label'] == 'G14' and not rows[-1]['ready']
    assert rows[-1]['control'] == prior.number(expected['old_G14']['control'])
    body = (HERE/'tests/modTestCoupledElasticState.bas').read_text(encoding='utf-8-sig').rsplit('Public Function ReplayHardYieldGateTest(',1)[1]
    parts, reconstructed = [], []
    for row in body.splitlines():
        if row.startswith('    packed = '):
            part = re.fullmatch(r'    packed = (?:packed & )?"([0-9A-F]{192})"',row)
            assert part is not None
            parts.append(part[1])
        elif row.startswith('    HardRankUnpackTest packed, '):
            assert len(parts) == 5
            reconstructed.append(''.join(parts)); parts.clear()
    assert not parts and reconstructed == [''.join(x['FIELD']) for x in selected]+[''.join(tags['PROJECTION'])]
    assert f'HardRankValueTest("{expected["old_G14"]["control"]}"), offset, direction)' in body
    return plan,expected


def parse(path):
    raw = path.read_text(encoding='cp1251').splitlines()
    assert raw.pop(0) == 'HARDSHEAR-G13;1'
    tags,points,history,pairs,rollback,records = {},{},{},{},{},[]
    current = None
    for line in raw:
        key,*p = line.split(';')
        if key == 'BEGIN':
            assert current is None
            current = {'label':p[0],'control':prior.number(p[1]),'seed_factor':prior.number(p[2]),'commit':prior.received(p[3]),'matrix':{},'stations':{}}
        elif key == 'END':
            assert current is not None and current['label'] == p[0]
            current['ready'] = prior.received(p[1]); records.append(current); current = None
        elif key in ('QUAD','K'):
            data = points if key == 'QUAD' else current['matrix']
            assert int(p[0]) not in data
            data[int(p[0])] = prior.numbers(p[1:])
        elif key == 'STATION':
            point = (int(p[0]),int(p[1]))
            assert current is not None and point not in current['stations']
            current['stations'][point] = (prior.number(p[3]),prior.received(p[4]),int(p[5]),int(p[6])) if p[2] == 'ok' else None
        elif key == 'HISTORY':
            assert (p[0],p[1]) not in history
            history[p[0],p[1]] = (int(p[2]),int(p[3]),[])
        elif key == 'HISTORY-PART':
            size,cap,values = history[p[0],p[1]]
            assert int(p[2]) == 1+len(values)//64 and int(p[2]) <= cap
            assert len(p[3:]) == min(64,size-len(values))
            values.extend(p[3:])
        elif key in ('PAIR','ROLLBACK'):
            data = pairs if key == 'PAIR' else rollback
            assert current is None and p[0] not in data
            data[p[0]] = p[1:]
        elif current is None:
            assert key in {'MESH','OFFSET','DIRECTION','PROJECTION','VIRGIN','FINISH'} and key not in tags
            tags[key] = p
        else:
            assert key in {'SEED','START-FIELD','SOLVER','FIELD','TARGET','ACTUAL','RESIDUAL','CONTROL','BALANCE','BOUND','DIRECTION-EQ',
                           'BOUND-RES','STOP-FIELD','DECISION','RECOVERY'} and key not in current
            current[key] = p
    assert current is None and 'FINISH' in tags
    return tags,points,history,pairs,rollback,records


def row_check(row,projection,direction,area,length,modulus):
    proxy = dict(row)
    if not row['commit'] and row['ready']:
        assert row['DECISION'] == ['VERIFIED_PROBE']
        proxy.update(DECISION=['ACCEPTED'], **{'STOP-FIELD':row['FIELD']})
    fine.verify_row(proxy,projection,direction,area,length,modulus)
    for key in ('factor','norm','tau','field','longitudinal','transverse','coordinate','uncertainty'):
        if key in proxy:
            row[key] = proxy[key]
    if not row['commit']:
        assert row['STOP-FIELD'] == row['START-FIELD']


def compare_endpoints(rows,points):
    intervals = []
    for key in ('LS','LT','RS','RT'):
        arm = [r for r in rows if r['label'][0]+r['label'][-1] == key]
        for a,b in zip(arm[:-1],arm[1:],strict=True):
            if not (a['ready'] and b['ready']):
                intervals.append({'pair':[a['label'],b['label']],'sign':None,'reason':'unconfirmed equilibrium'})
                continue
            found = fine.derivative(a,b)
            if not found:
                intervals.append({'pair':[a['label'],b['label']],'sign':None,'reason':'unavailable uncertainty'})
                continue
            found['concrete_switches'] = [(*p,*points[p[0]][:2]) for p in sorted(a['stations'].keys() & b['stations'].keys())
                                          if a['stations'][p] and b['stations'][p] and a['stations'][p][1] != b['stations'][p][1]]
            intervals.append(found)
    return intervals


def verify(plan,expected):
    folder = HERE/'Native/Order10'
    trace = folder/'HardG13.csv'
    proof = prior.native_proof(plan,folder)
    tags,points,history,pairs,rollback,rows = parse(trace)
    area,length,modulus,_ = prior.verify_geometry(plan,10,tags,points)
    for key in expected['geometry']:
        assert tags[key] == expected['geometry'][key]
    direction,projection = (prior.numbers(tags[k]) for k in ('DIRECTION','PROJECTION'))
    prefix = [row for row in rows if row['commit']]
    new = rows[len(prefix):]
    assert all(not row['commit'] for row in new)
    after = tags['VIRGIN']
    assert prior.numbers(after) == [0.]*60
    exact = []
    assert len(prefix) <= 25
    for row,old in zip(prefix,expected['fields']):
        assert row['START-FIELD'] == after and row['label'] == old['label'] and row['SEED'] == old['FIELD']
        assert row['control'] == prior.number(old['control']) and row['seed_factor'] == prior.number(old['BALANCE'][0])
        row_check(row,projection,direction,area,length,modulus)
        if row['ready']:
            assert all(row[k] == old[k] for k in FIELDS)
            exact.append(row)
        after = row['STOP-FIELD']
    reason,size,count = tags['FINISH']
    assert int(size) == len(exact) and int(count) == len(new)
    assert reason in {'COMPLETE','TIME_BOUND','PREFIX_REFUSED','HISTORY_REFUSED','ROLLBACK_REFUSED','INVALID_WINDOW'}
    if new or reason == 'COMPLETE':
        assert len(exact) == 25
        for idx in ('24','25'):
            a,b = history[idx,'SOLVED'],history[idx,'REBUILT']
            assert a == b and a[0] == len(a[2]) == 9744
    names = [row['label'] for row in new]
    assert names == list(TARGETS[:len(new)]) and set(pairs) == set(names)
    if reason == 'COMPLETE':
        assert names == list(TARGETS) and set(rollback) == set(names)
    archive_g14 = prior.number(expected['old_G14']['control'])
    for row in new:
        label = row['label']
        anchor = 24 if label[0] == 'L' else 25
        center = exact[anchor-1]
        old = exact[anchor-2]
        tol = expected['stock_tolerance'] if label[-1] == 'S' else expected['tight_tolerance']
        assert int(pairs[label][0]) == anchor and prior.number(pairs[label][1]) == tol
        if label in rollback:
            assert rollback[label] == [str(anchor),'9744']
        assert row['START-FIELD'] == center['FIELD']
        controls = ((.5*(center['coordinate']+exact[-1]['control']),exact[-1]['control'],archive_g14) if anchor == 24
                    else (.5*(center['coordinate']+archive_g14),archive_g14))
        assert row['control'] == controls[int(label[1])-1]
        ratio = (row['control']-center['coordinate'])/(center['coordinate']-old['coordinate'])
        seed = [a + ratio*(a-b) for a,b in zip(center['field'],old['field'],strict=True)]
        assert all(isclose(a,b,rel_tol=3e-14,abs_tol=3e-16) for a,b in zip(seed,prior.numbers(row['SEED']),strict=True))
        row_check(row,projection,direction,area,length,modulus)
        if row['ready']:
            assert row['coordinate'] > center['coordinate']
            assert len(row['stations']) == 300
            if row.get('uncertainty') is not None:
                scale = max(abs(value*row['factor']) for value in prior.numbers(row['DIRECTION-EQ'])[:56])
                assert isclose(row['tau'],tol+tol*scale,rel_tol=3e-12)
    for a,b in zip(new[::2],new[1::2]):
        assert a['control'] == b['control'] and a['SEED'] == b['SEED'] and a['seed_factor'] == b['seed_factor'] and a['START-FIELD'] == b['START-FIELD']
    detail = []
    for row in new:
        entry = fine.record(row)
        entry.update(verified_probe=row['ready'],guide=row['RECOVERY'],rollback=row['label'] in rollback)
        detail.append(entry)
    result = {'outcome':reason,'exact_prefix_fields':len(exact),'probes':detail,'small_window_secants':compare_endpoints(new,points),
              'old_G14_control':archive_g14,'strict_relative_and_absolute_ratio':.001,
              'native_trace_sha256':prior.file_hash(trace),'physical_limit_certified':False,'proof':proof}
    receipt = folder/'Verification.json'
    raw = (json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
    if receipt.exists():
        assert receipt.read_bytes() == raw
    else:
        receipt.write_bytes(raw)
    print(f'HARDSHEAR_G13: {reason}; exact={len(exact)}; probes={len(new)}; sha={prior.file_hash(receipt)}')


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--inputs',action='store_true')
    cli.add_argument('--order',type=int,choices=(10,))
    args = cli.parse_args()
    plan,expected = inputs()
    if args.inputs:
        print('HARDSHEAR_G13_INPUTS: PASS')
    else:
        assert args.order == 10
        verify(plan,expected)


if __name__ == '__main__':
    main()
