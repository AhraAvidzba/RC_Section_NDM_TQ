"""Автономно сверяет исходную поправку G14, пробы знака и материальные вклады."""

from argparse import ArgumentParser
import json
from math import fsum, isclose
from pathlib import Path
import re

import G13Verify as g13
import PriorVerify as prior


HERE = Path(__file__).resolve().parent


class TextTrace:
    def __init__(self, lines):
        self.lines = lines

    def read_text(self, encoding):
        return '\n'.join(self.lines)


def inputs():
    plan = prior.read(HERE/'Fixture.json')
    expect = prior.read(HERE/'Expected.json')
    for name,digest in plan['inputs'].items():
        assert prior.file_hash(HERE/name) == digest, name
    old_file = HERE/'Prior/HardG13.csv'
    old_outcome = HERE/'Prior/Verification.json'
    old = prior.read(old_outcome)
    assert prior.file_hash(old_outcome) == plan['prior_report_sha256']
    assert old['proof']['compiled_workbook_sha256'] == plan['prior_compiled_workbook_sha256']
    assert prior.file_hash(old_file) == old['native_trace_sha256']
    _,_,_,_,_,records = g13.parse(old_file)
    same = next(row for row in records if row['label'] == 'R2S')
    assert not same['ready'] and same['control'] == prior.number(expect['old_G14']['control'])
    book = HERE/plan['workbook']
    if book.exists():
        assert prior.file_hash(book) == plan['source_workbook_sha256']
    return plan,expect,same


def read_probe(path):
    lines = path.read_text(encoding='cp1251').splitlines()
    assert lines.pop(0) == 'HARDSHEAR-G14-DIRECTION;1'
    ordinary, tags, matrices, samples = ['HARDSHEAR-G13;1'],{},{'STOCK':{},'REFINED':{}},[]
    case=None
    for line in lines:
        key,*parts = line.split(';')
        if key == 'DIR-SAMPLE':
            assert case is None
            case = {'arm':parts[0],'h':prior.number(parts[1]),'lambda':prior.number(parts[2]),'available':prior.received(parts[3]),
                    'points':{},'stations':{}}
        elif key == 'DIR-END':
            assert case is not None
            samples.append(case); case=None
        elif case is not None:
            if key == 'DIR-PART':
                assert int(parts[0]) not in case['points']
                case['points'][int(parts[0])] = prior.numbers(parts[1:])
            elif key == 'STATION':
                point = (int(parts[0]),int(parts[1]))
                assert point not in case['stations']
                case['stations'][point] = (prior.number(parts[3]),prior.received(parts[4]),int(parts[5]),int(parts[6])) if parts[2] == 'ok' else None
            else:
                assert key not in case and key.startswith('DIR-')
                case[key]=parts
        elif key == 'MAT':
            matrix=matrices[parts[0]]; index=int(parts[1])
            assert index not in matrix
            matrix[index]=prior.numbers(parts[2:])
        elif key in {'CAPTURE','DIRECTION-EQ','CORRECTION','REFINED-CORRECTION'}:
            assert key not in tags
            tags[key]=parts
        elif key == 'REFINED':
            tags.setdefault(key,[]).append(parts)
        else:
            ordinary.append(line)
    assert case is None
    return g13.parse(TextTrace(ordinary)),tags,matrices,samples


def dot(a,b):
    return fsum(x*y for x,y in zip(a,b,strict=True))


def validate_samples(samples, tags, matrices, geometry, row, before, after, fraction, base_norm, tolerance, direction):
    projection=prior.numbers(geometry['PROJECTION'])
    area,length,modulus,total=geometry['normalizers']
    load_equations=prior.numbers(tags['DIRECTION-EQ'])
    origin=samples[0]
    assert origin['arm']=='STOCK' and origin['h']==0. and origin['available']
    x0=prior.numbers(origin['DIR-FIELD']); external0=prior.numbers(origin['DIR-EXTERNAL'])
    r0=prior.numbers(origin['DIR-RESIDUAL'])
    assert isclose(r0[row],before,rel_tol=1e-8,abs_tol=1e-13)
    assert isclose(prior.number(origin['DIR-BALANCE'][0]),base_norm,rel_tol=1e-8,abs_tol=1e-13)
    assert base_norm>2.*tolerance
    wanted=[('STOCK',fraction*g) for g in (0.,-1.,-.125,-.015625,.015625,.125,1.)]
    if 'REFINED-CORRECTION' in tags:
        wanted += [('REFINED',fraction*g) for g in (.015625,.125,1.)]
    assert [(row['arm'],row['h']) for row in samples] == wanted
    corrections={'STOCK':prior.numbers(tags['CORRECTION'])}
    if 'REFINED-CORRECTION' in tags:
        corrections['REFINED']=prior.numbers(tags['REFINED-CORRECTION'])
    actions={}
    original=corrections['STOCK']
    for name,mat in matrices.items():
        if not mat:
            continue
        assert set(mat) == set(range(1,61))
        projected=[dot(mat[i+1],original[:60])-load_equations[i]*original[60] for i in range(60)]
        actions[name]=projected[row]
        if name=='STOCK':
            assert max(abs(r+delta) for r,delta in zip(r0,projected,strict=True)) < 2e-10
            assert isclose(actions[name],-before,rel_tol=1e-8)
    details=[]
    for sample in samples:
        h=sample['h']; correction=corrections[sample['arm']]
        field=prior.numbers(sample['DIR-FIELD'])
        assert all(isclose(a,x+h*d,rel_tol=5e-14,abs_tol=2e-16) for a,x,d in zip(field,x0,correction[:60],strict=True))
        assert isclose(sample['lambda'],origin['lambda']+h*correction[60],rel_tol=1e-15)
        if not sample['available']:
            details.append({'arm':sample['arm'],'h':h,'failure':sample['DIR-FAILURE']});continue
        target,actual,external,r=map(prior.numbers,(sample['DIR-TARGET'],sample['DIR-ACTUAL'],sample['DIR-EXTERNAL'],sample['DIR-RESIDUAL']))
        assert len(actual)==len(target)==6 and len(r)==len(external)==60
        assert all(isclose(f,sample['lambda']*d,rel_tol=3e-15) for f,d in zip(target,direction,strict=True))
        assert all(isclose(g,sample['lambda']*d,rel_tol=3e-15,abs_tol=1e-15) for g,d in zip(external,load_equations,strict=True))
        assert set(sample['points'])==set(range(1,total+1)) and len(sample['stations'])==300
        affine=prior.number(sample['DIR-AFFINE'][0]); base_affine=prior.number(origin['DIR-AFFINE'][0])
        recovered=fsum(piece[0] for piece in sample['points'].values())+affine
        assert isclose(recovered,r[row],rel_tol=1e-9,abs_tol=1e-12)
        control=prior.number(sample['DIR-BALANCE'][1]); original_control=prior.number(origin['DIR-BALANCE'][1])
        assert isclose(control-original_control,modulus*h*dot(projection,correction[:60]),rel_tol=1e-7,abs_tol=5e-13)
        scales=(area,area*length,area*length,area*length,area,area)
        force_norm=max(abs(a-b)/s for a,b,s in zip(target,actual,scales,strict=True))
        norm=prior.number(sample['DIR-BALANCE'][0]); weak=max(map(abs,r[:56]))
        assert isclose(norm,max(force_norm,weak,abs(control)),rel_tol=3e-12,abs_tol=1e-13)
        stations=[p for p,s in sample['stations'].items() if s and origin['stations'][p] and s[1:]!=origin['stations'][p][1:]]
        change=[(int(p),v[0]-origin['points'][p][0]) for p,v in sample['points'].items()]
        details.append({'arm':sample['arm'],'h':h,'lambda':sample['lambda'],'norm_MPa':norm,'row_MPa':r[row],
                        'row_direction_MPa':(r[row]-r0[row])/h if h else None,'weak_norm_MPa':weak,'six_norm_MPa':force_norm,
                        'gauge_dimensionless':max(map(abs,r[56:])),'affine_change_MPa':affine-base_affine,
                        'station_changes':stations,'largest_point_changes_MPa':sorted(change,key=lambda x:abs(x[1]),reverse=True)[:5]})
        if sample['arm']=='STOCK' and h==fraction:
            assert isclose(r[row],after,rel_tol=1e-8,abs_tol=1e-13)
    return actions,details


def verify(plan,expect,same):
    folder=HERE/'Native/Order10'
    proof=prior.native_proof(plan,folder)
    path=folder/'HardG14Direction.csv'
    (geometry,points,histories,_,roll,rows),tags,matrices,samples=read_probe(path)
    reference=prior.verify_geometry(plan,10,geometry,points)
    assert {key:geometry[key] for key in expect['geometry']}==expect['geometry']
    direction,projection=(prior.numbers(geometry[k]) for k in ('DIRECTION','PROJECTION'))
    prefix=rows[:25]
    outcome=geometry['FINISH'][0]
    assert outcome in {'COMPLETE','NO_CAPTURE','PREFIX_REFUSED','ROLLBACK_REFUSED','HISTORY_REFUSED','INVALID_WINDOW'}
    exact=0; after=geometry['VIRGIN']
    for row,old in zip(prefix,expect['fields']):
        assert row['commit'] and row['label']==old['label'] and row['START-FIELD']==after and row['SEED']==old['FIELD']
        assert row['control']==prior.number(old['control']) and row['seed_factor']==prior.number(old['BALANCE'][0])
        g13.row_check(row,projection,direction,*reference[:3])
        after=row['STOP-FIELD']
        if row['ready']:
            assert all(row[key]==old[key] for key in g13.FIELDS)
            exact+=1
    assert exact==int(geometry['FINISH'][1])
    actions={}; details=[]; capture=None
    if outcome=='COMPLETE':
        assert exact==25 and len(rows)==26 and geometry['FINISH'][2]=='1'
        for anchor in ('24','25'):
            a,b=histories[anchor,'SOLVED'],histories[anchor,'REBUILT']
            assert a==b and a[0]==len(a[2])==9744
        final=rows[-1]
        assert final['label']=='R2S' and not final['commit'] and not final['ready'] and roll['R2S']==['25','9744']
        for key in ('control','seed_factor','SEED','START-FIELD'):
            assert final[key]==same[key]
        assert final['STOP-FIELD']==final['START-FIELD']==prefix[-1]['FIELD']
        cap=tags['CAPTURE']; row=int(cap[0])-1
        assert row==52 and (int(cap[6]),int(cap[7]))==(3,26)
        base,after,h,base_norm,tol=prior.numbers(cap[1:6])
        original_direction=(after-base)/h
        assert h>0. and isclose(base_norm,1.07773459521787e-5,rel_tol=2e-10)
        assert isclose(original_direction,3.92914471324668e-5,rel_tol=2e-10)
        actions,details=validate_samples(samples,tags,matrices,{**geometry,'normalizers':reference},row,base,after,h,base_norm,tol,direction)
        capture={'equation':row+1,'original_fraction':h,'base_norm_MPa':base_norm,'tolerance_MPa':tol,'ordinary_action_MPa':actions['STOCK'],
                 'logged_measured_direction_MPa':original_direction,'stock_iterations':int(cap[6]),'stock_evaluations':int(cap[7])}
    result={'outcome':outcome,'exact_prefix':exact,'capture':capture,'same_old_direction_matrix_actions_MPa':actions,'samples':details,
            'refined_status':tags.get('REFINED',[]),'no_field_accepted_after_G13':True,'physical_limit_certified':False,
            'native_trace_sha256':prior.file_hash(path),'proof':proof}
    target=folder/'Verification.json'
    output=(json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
    if target.exists():
        assert target.read_bytes()==output
    else:
        target.write_bytes(output)
    print(f'HARDSHEAR_G14_DIRECTION: {outcome}; exact={exact}; sha={prior.file_hash(target)}')


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--inputs',action='store_true')
    cli.add_argument('--order',type=int,choices=(10,))
    args=cli.parse_args()
    plan,expect,same=inputs()
    if args.inputs:
        print('HARDSHEAR_G14_DIRECTION_INPUTS: PASS')
    else:
        assert args.order==10
        verify(plan,expect,same)


if __name__=='__main__':
    main()
