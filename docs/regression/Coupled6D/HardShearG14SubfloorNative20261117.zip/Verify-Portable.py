"""Проверяет нативное доказательство без установки Excel, книги и истории Git."""

import json
from pathlib import Path
from subprocess import PIPE, run
import sys

import PriorVerify as prior


HERE = Path(__file__).resolve().parent


def main():
    sums = prior.read(HERE/'SHA256SUMS.json')
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}
    assert actual == set(sums)|{'SHA256SUMS.json'}
    for name,expected in sums.items():
        assert prior.file_hash(HERE/name) == expected and not name.lower().endswith('.xlsm'), name
    plan = prior.read(HERE/'Fixture.json')
    for name,expected in plan['production'].items():
        assert prior.file_hash(HERE/'Production'/name) == expected
    replay = run([sys.executable,'-B','-X','utf8','Verify.py','--order','10'],cwd=HERE,stdout=PIPE,check=True)
    print(replay.stdout.decode('utf-8').strip())
    native = prior.read(HERE/'Native/Order10/Verification.json')
    assert prior.file_hash(HERE/'Native/Order10/Verification.json') == 'CD33836B5FB737C2173A04E408ECFC59FD344B280C58DDB22D6731C54DE21E43'
    assert not native['physical_limit_certified'] and native['no_new_physical_state_committed']
    a, b = (native['arm_diagnostics'][key] for key in ('A', 'B'))
    assert a['solver'][:5] == ['False', '6', '10', '3', '26']
    assert b['solver'][:5] == ['False', '6', '10', '4', '38'] and b['fraction_taken'] == 1/512
    assert b['unchanged_concrete_branch_signatures'] == 300
    norm = next(p['norm'] for p in b['checked_states'] if p['role'] == 'RECORDED')
    native['fractional_merit_reduction_at_accepted_iteration'] = 1 - norm/native['origin_norm_MPa']
    print(json.dumps(native,indent=2,ensure_ascii=False))
    print(f'HARDSHEAR_SUBFLOOR_PORTABLE: VERIFIED_EVIDENCE; {native["outcome"]}; physical_limit_certified=False')


if __name__ == '__main__':
    main()
