"""Автономная сверка принятой истории через F19 и следующих проб HardShear."""

import argparse
import json
from math import isclose
from pathlib import Path
import re

import FineVerify as fine
import PriorVerify as prior


HERE = Path(__file__).resolve().parent
ANCHORS = ('5', '6', '19')
STOPS = {'PROBE_LIMIT', 'CONTROL_BOUND', 'MINIMUM_STEP', 'TIME_BOUND', 'PREFIX_REFUSED', 'HISTORY_REFUSED'}


def verify_inputs():
    plan = prior.read(HERE / 'Fixture.json')
    expected = prior.read(HERE / 'Expected.json')
    for path, claimed in plan['inputs'].items():
        assert prior.file_hash(HERE / path) == claimed, path
    old_trace = HERE / 'Prior/HardFineResume.csv'
    old_report = HERE / 'Prior/Verification.json'
    assert prior.file_hash(old_report) == plan['prior_report_sha256']
    old = prior.read(old_report)
    assert prior.file_hash(old_trace) == old['native_trace_sha256']
    assert old['proof']['compiled_workbook_sha256'] == plan['prior_compiled_workbook_sha256']
    tags, _, steps = fine.parse(old_trace)
    accepted = [s for s in steps if s['ready']]
    assert len(accepted) == len(expected['fields']) == 19
    for a,b in zip(accepted, expected['fields'], strict=True):
        assert a['label'] == b['label'] and a['control'] == prior.number(b['control'])
        assert a['seed_factor'] == prior.number(b['estimate'])
        for key in ('FIELD','CONTROL','TARGET','ACTUAL','RESIDUAL','BALANCE','SOLVER','SEED'):
            assert a[key] == b[key]
    failed = steps[-1]
    assert not failed['ready'] and failed['label'] == 'F20'
    assert failed['control'] == prior.number(expected['prior']['failed_F20']['control'])
    for key in ('OFFSET','DIRECTION','PROJECTION'):
        assert tags[key] == expected['prior'][key]
    project_book = HERE / plan['workbook']
    if project_book.exists():
        assert prior.file_hash(project_book) == plan['source_workbook_sha256']
    source = (HERE / 'tests/modTestCoupledElasticState.bas').read_text(encoding='utf-8-sig')
    body = source.rsplit('Public Function ReplayHardYieldGateTest(', maxsplit=1)[1]
    pieces, vectors = [], []
    for row in body.splitlines():
        if row.startswith('    packed = '):
            part = re.fullmatch(r'    packed = (?:packed & )?"([0-9A-F]{192})"', row)
            assert part is not None
            pieces.append(part[1])
        elif row.startswith('    HardRankUnpackTest packed, '):
            assert len(pieces) == 5
            vectors.append(''.join(pieces))
            pieces.clear()
    assert not pieces and vectors == [''.join(item['FIELD']) for item in accepted] + [''.join(tags['PROJECTION'])]
    assert f'HardRankValueTest("{expected["prior"]["failed_F20"]["control"]}"), offset, direction)' in body
    return plan, expected


def parse(path):
    lines = path.read_text(encoding='cp1251').splitlines()
    assert lines.pop(0) == 'HARDSHEAR-F19;1'
    tags, rows, points, histories = {}, [], {}, {}
    active = None
    for line in lines:
        key, *columns = line.split(';')
        if key == 'BEGIN':
            assert active is None and columns[3] == 'True'
            active = {'label':columns[0], 'control':prior.number(columns[1]), 'seed_factor':prior.number(columns[2]), 'matrix':{}}
        elif key == 'END':
            assert active is not None and active['label'] == columns[0]
            active['ready'] = prior.received(columns[1])
            rows.append(active)
            active = None
        elif key in ('QUAD','K'):
            destination = points if key == 'QUAD' else active['matrix']
            index = int(columns[0])
            assert index not in destination
            destination[index] = prior.numbers(columns[1:])
        elif key == 'HISTORY':
            assert active is None
            label, arm, size, count = columns
            assert label in ANCHORS and arm in ('SOLVED','REBUILT') and (label,arm) not in histories
            histories[label,arm] = (int(size), int(count), [])
        elif key == 'HISTORY-PART':
            label, arm, part, *values = columns
            size, count, observed = histories[label,arm]
            index = int(part)
            assert active is None and index == len(observed)//64+1 and 1 <= index <= count
            assert len(values) == min(64, size-len(observed))
            observed.extend(values)
        elif active is None:
            assert key not in tags and key in {'MESH','OFFSET','DIRECTION','PROJECTION','VIRGIN','ADAPT','FINISH'}, key
            tags[key] = columns
        else:
            assert key not in active and key in {'SEED','START-FIELD','SOLVER','FIELD','TARGET','ACTUAL','RESIDUAL','CONTROL','BALANCE',
                                                 'BOUND','DIRECTION-EQ','BOUND-RES','STOP-FIELD','DECISION','RECOVERY'}, key
            active[key] = columns
    assert active is None and tags['FINISH'][0] in STOPS
    return tags, points, histories, rows


def continue_branch(start, rows, tags, expected):
    if 'ADAPT' not in tags:
        assert not rows
        return []
    nominal, minimum, maximum, end = prior.numbers(tags['ADAPT'][:4])
    cap = int(tags['ADAPT'][4]); soft = prior.number(tags['ADAPT'][5])
    first = prior.number(expected['prior']['failed_F20']['control'])
    old, current = start[-2:]
    assert nominal == first - current['coordinate'] and minimum == nominal/128. and maximum == nominal*16.
    assert end == expected['max_control'] and cap == expected['max_probes'] and soft == expected['soft_seconds']
    accepted = []
    increment, consecutive = nominal, 0
    for i, row in enumerate(rows, 1):
        assert row['label'] == f'G{i}' and len(rows) <= cap and increment >= minimum
        target = first if i == 1 else min(end, current['coordinate'] + increment)
        assert row['control'] == target and target > current['coordinate']
        amount = (target-current['coordinate'])/(current['coordinate']-old['coordinate'])
        seed = [x + amount*(x-y) for x,y in zip(current['field'],old['field'],strict=True)]
        assert all(isclose(a,b,rel_tol=3e-14,abs_tol=3e-16) for a,b in zip(seed, prior.numbers(row['SEED']), strict=True))
        assert isclose(row['seed_factor'], current['factor']+amount*(current['factor']-old['factor']), rel_tol=1e-15)
        guided, mismatch, changed = map(prior.received,row['RECOVERY'])
        if guided:
            assert mismatch and not changed
        if row['ready']:
            assert row['coordinate'] > current['coordinate'] and not changed
            motion = max(abs(a-b) for a,b in zip(seed[:56], current['field'][:56], strict=True))
            deviation = max(abs(a-b) for a,b in zip(seed[:56], row['field'][:56], strict=True))
            assert 0. < motion and deviation <= expected['deviation_factor']*motion
            accepted.append(row); old,current = current,row
            consecutive += 1
            if consecutive >= 2:
                increment = min(maximum, increment*1.4)
        else:
            consecutive = 0
            increment *= .5
    return accepted


def report_row(row):
    result = fine.record(row)
    result['recovery'] = row['RECOVERY']
    return result


def verify(plan, expected):
    folder = HERE / 'Native/Order10'
    proof = prior.native_proof(plan,folder)
    trace = folder / 'HardF19.csv'
    tags, pts, histories, raw = parse(trace)
    area,length,modulus,total = prior.verify_geometry(plan,10,tags,pts)
    for key in ('OFFSET','DIRECTION','PROJECTION'):
        assert tags[key] == expected['prior'][key]
    direction,projection = (prior.numbers(tags[k]) for k in ('DIRECTION','PROJECTION'))
    field = tags['VIRGIN']
    assert prior.numbers(field) == [0.]*60
    for row in raw:
        assert row['START-FIELD'] == field
        fine.verify_row(row,projection,direction,area,length,modulus)
        field = row['STOP-FIELD']
    prefix = [row for row in raw if not row['label'].startswith('G')]
    so_far = []
    for a,b in zip(prefix,expected['fields']):
        assert a['label'] == b['label'] and a['control'] == prior.number(b['control'])
        assert a['seed_factor'] == prior.number(b['BALANCE'][0]) and a['SEED'] == b['FIELD']
        assert not prior.received(a['RECOVERY'][0])
        if a['ready']:
            for key in ('FIELD','CONTROL','TARGET','ACTUAL','RESIDUAL','BALANCE'):
                assert a[key] == b[key], (a['label'],key)
            so_far.append(a)
    reason, exact, probe_count, *accepted_count = tags['FINISH']
    assert len(so_far) == int(exact)
    variants = {}
    for label in ANCHORS:
        if (label,'SOLVED') in histories:
            left = histories[label,'SOLVED']
            right = histories.get((label,'REBUILT'))
            assert len(left[2]) == left[0] == 3*(1+27*total+7+3*18)
            variants[label] = {'values':left[0], 'bit_identical':left == right}
    if reason not in ('PREFIX_REFUSED','HISTORY_REFUSED'):
        assert len(so_far) == 19 and len(variants) == 3 and all(row['bit_identical'] for row in variants.values())
    continued = raw[len(prefix):]
    confirmed = continue_branch(so_far,continued,tags,expected)
    assert len(continued) == int(probe_count) and len(confirmed) == (int(accepted_count[0]) if accepted_count else 0)
    joined = so_far[-1:] + confirmed
    secants = [fine.derivative(a,b) for a,b in zip(joined[:-1],joined[1:],strict=True)]
    signs = [x['sign'] for x in secants if x]
    first = prior.number(expected['prior']['failed_F20']['control'])
    at_old_fail = [report_row(row) for row in confirmed if row['control'] == first]
    beyond = next((report_row(row) for row in confirmed if row['coordinate'] > first),None)
    result = {'outcome':reason,'exact_prefix_fields':len(so_far),'history_snapshots':variants,
              'attempts':[report_row(row) for row in continued], 'first_same_F20':at_old_fail, 'first_beyond_F20':beyond,
              'secants':secants,'positive_intervals':signs.count(1),'negative_intervals':signs.count(-1),
              'max_confirmed':report_row(max(so_far+confirmed,key=lambda row:row['factor'])) if so_far else None,
              'native_trace_sha256':prior.file_hash(trace),'physical_limit_certified':False,'proof':proof}
    path = folder / 'Verification.json'
    encoded = (json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
    if path.exists():
        assert path.read_bytes() == encoded
    else:
        path.write_bytes(encoded)
    print(f'HARDSHEAR_F19: {reason}; exact={len(so_far)}; accepted={len(confirmed)}; sha={prior.file_hash(path)}')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--inputs',action='store_true')
    cli.add_argument('--order',type=int,choices=(10,))
    args = cli.parse_args()
    plan,expected = verify_inputs()
    if args.inputs:
        print('HARDSHEAR_F19_INPUTS: PASS')
    else:
        assert args.order == 10
        verify(plan,expected)


if __name__ == '__main__':
    main()
