"""Разделяет влияние пластического течения и способа применения повреждения."""

from argparse import ArgumentParser
from hashlib import sha256
from itertools import groupby
import json
from math import fsum, sqrt
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


REVERSE = 'MVT2ReverseConcreteMaterial20261117.zip'
REVERSE_SHA = 'E22671B7D47DAD52C911C9C38207324F95276875D50AD60901CB0CB3F980D23D'
HELPER = 'MVT2NativePublicationCutMaterialHistory20261117.zip'
HELPER_SHA = '6920EB24A5D01585E510FDBC1064513C0C83AA62583AEB0C2553D6F0D495EE55'
CHECKPOINTS = {
    'NDM': (0., 10000., 20000., 21875.),
    'MatchedASD': (0., 10000., 20000., 21875.),
    'LongASD': (20000., 40000., 67500., 75312.5),
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def elastic(strain):
    """Вычисляет изотропное напряжение из инженерных деформаций."""
    pressure = (25000. / 3.) * fsum(strain[:3])
    return (*[25000. * x + pressure for x in strain[:3]], *[12500. * x for x in strain[3:]])


def multiply(row, multiplier):
    return tuple(multiplier * x for x in row)


def add(*rows):
    return tuple(map(fsum, zip(*rows, strict=True)))


def dot(a, b):
    """Возвращает скалярное произведение двух симметричных тензоров."""
    return fsum(x * y * (1. if i < 3 else 2.) for i, (x, y) in enumerate(zip(a, b, strict=True)))


def decompose(strain, plastic, native, dt, dc, asd, spectra, spectral_parts):
    """Восстанавливает исходный отклик и вычисляет два варианта распределения повреждения."""
    p = elastic(plastic)
    initial = elastic(strain)
    effective = add(initial, multiply(p, -1.))
    vals = spectra(effective)
    mag = fsum(map(abs, vals))
    r = fsum(x for x in vals if x > 0.) / mag if mag > 0. else 0.
    scalar = (1. - r*dt) * (1. - dc)
    recovered = multiply(effective, scalar)
    assert max(abs(a-b) for a,b in zip(native, recovered, strict=True)) < 3e-10
    isotropic = fsum(p[:3]) / 3.
    volume = (-isotropic, -isotropic, -isotropic, 0., 0., 0.)
    deviator = add(multiply(p, -1.), multiply(volume, -1.))
    damage = multiply(effective, scalar - 1.)
    combined = add(initial, volume, deviator, damage)
    assert max(abs(a-b) for a,b in zip(native, combined, strict=True)) < 3e-10

    em, ep = spectral_parts(effective, spectra)
    am, ap = spectral_parts(asd, spectra)
    split = add(multiply(em, 1. - dc), multiply(ep, 1. - dt))
    # Наименьшая ошибка при произвольном допустимом скалярном множителе сжимающей части.
    norm = dot(em, em)
    matched_scalar = max(0., min(1., dot(em, am)/norm)) if norm > 0. else 0.
    remaining = add(multiply(em, matched_scalar), multiply(am, -1.))
    # Это граница возможного улучшения при любом независимом скалярном законе сжатия.
    best_compression = dot(remaining, remaining)
    original_compression_delta = add(multiply(em, scalar), multiply(am, -1.))
    baseline_compression = dot(original_compression_delta, original_compression_delta)
    assert best_compression <= baseline_compression + 2e-10
    numerical_ap = spectra(ap)
    assert numerical_ap[0] >= -5e-7
    return {
        'elastic': initial, 'plastic_volume': volume, 'plastic_deviator': deviator, 'damage': damage,
        'split_damage': split, 'stress_recovered': recovered,
        'best_compression_local_squared_error': best_compression,
        'baseline_compression_local_squared_error': baseline_compression,
    }


def read_state(row):
    """Читает номинальное напряжение и принятую историю из квитанции Excel."""
    assert len(row) == 29
    vals = tuple(map(float, row[3:]))
    return vals[:6], vals[6:12], vals[12:18], vals[-4], vals[-3]


def verify(repo, root):
    """Повторяет материальную декомпозицию и интегралы на закреплённых историях."""
    base = repo / 'docs/regression/Coupled6D'
    archive = base / REVERSE
    assert digest(archive.read_bytes()) == REVERSE_SHA
    helper = base / HELPER
    assert digest(helper.read_bytes()) == HELPER_SHA
    material = {'__name__': '__pinned__'}
    with ZipFile(helper) as source:
        exec(compile(source.read('Verify-NativeMaterialHistory.py'), str(helper), 'exec'), material)
    with ZipFile(archive) as source:
        for name in ('Stage-ReverseMaterial.py', 'Verify-ReverseMaterial.py'):
            (root / name).write_bytes(source.read(name))
        stage = run_path(str(root / 'Stage-ReverseMaterial.py'))
        native = run_path(str(root / 'Verify-ReverseMaterial.py'))
        data = source.read('Native/MaterialReplay.csv')
    spectra = material['principal']
    order, (tables, _, points, area, radius, _), ext = stage['load'](repo)
    operator, reference_asd, matched, long = ext
    partition = native['spectral_parts']
    assemble = operator['assemble_net']
    scale = (area, area*radius, area*radius, area*radius, area, area)
    compare = {}
    source_states = {'NDM': reference_asd, 'MatchedASD': matched['stress'], 'LongASD': long['stress']}
    rows = (r.split(';') for r in data.decode('ascii').splitlines())
    counter = 0
    for (label, number), batch in groupby(rows, key=lambda r: (r[0],int(r[1]))):
        index = number-1
        records = list(batch)
        assert [int(r[2]) for r in records] == list(range(1,136))
        counter += len(records)
        name, torque, shear, field = order[label][index]
        # В первой части история содержит восемь шагов при одинаковой Qy=0.
        if shear not in CHECKPOINTS[label] or (not shear and index not in (0,7)):
            continue
        # Проверяем также исходный упругий шаг для неизменности формул.
        native_rows = [read_state(r) for r in records]
        bar_values = []
        for j in range(3):
            if label == 'NDM':
                bar_values.append({p: fsum(a*b for a,b in zip(points[p][3:], native_rows[j*45+p-1][0], strict=True))
                                       *200000. for p in range(26,46)})
            else:
                steel = matched if label == 'MatchedASD' else long
                values = steel['steel'][index]['columns_strain_stress_tangent_plastic_backstress_increment'][j]
                bar_values.append({p: values[p-26][1] for p in range(26,46)})
        asd = source_states[label][index]
        if label != 'NDM':
            asd = [assemble(layer, bars, points) for layer, bars in zip(asd, bar_values, strict=True)]
        contributions = []
        for i, (strain, sigma, plastic, dt, dc) in enumerate(native_rows):
            contributions.append(decompose(strain, plastic, sigma, dt, dc, asd[i//45][i%45], spectra, partition))
        wanted = (0., -396.*shear, 0., torque, 0., shear)
        raw_ndm = [[v[1] for v in native_rows[j:j+45]] for j in (0,45,90)]
        split = [[v['split_damage'] for v in contributions[j:j+45]] for j in (0,45,90)]
        evaluations = {tag: native['integrate'](operator, tables, points, scale, field, tensor, bar_values, wanted)
                       for tag, tensor in (('base_ndm',raw_ndm),('split_damage',split),('asd',asd))}
        centre = contributions[:45]
        balance = {}
        for tag in ('elastic', 'plastic_volume', 'plastic_deviator', 'damage', 'stress_recovered'):
            net = [v[tag] if p<25 else multiply(v[tag],-1.) for p,v in enumerate(centre)]
            balance[tag] = operator['resultant'](points, net)
        assert max(abs(a-b) for a,b in zip(balance['stress_recovered'], add(
            balance['elastic'], balance['plastic_volume'], balance['plastic_deviator'],
            balance['damage']), strict=True)) < 1e-7
        assert balance['plastic_volume'][3:] == (0., 0., 0.)
        weights = [points[p][2] for p in range(1,26)]  # Только бетонные точки с положительной площадью.
        errors = {}
        for tag in ('best','baseline'):
            key = f'{tag}_compression_local_squared_error'
            errors[tag] = sqrt(fsum(w*v[key] for w,v in zip(weights, centre[:25], strict=True)) / area)
        if index == 0:
            assert max(abs(a-b) for a,b in zip(evaluations['base_ndm']['internal_N_Nmm'],
                                               evaluations['split_damage']['internal_N_Nmm'], strict=True)) < 1e-8
        compare.setdefault(label,[]).append({
            'phase': name, 'T_Nmm': torque, 'Qy_N': shear, 'evaluations': evaluations,
            'concrete_balance_N_Nmm': balance, 'area_weighted_compression_tensor_rms_MPa': errors,
        })
    assert counter == 11475
    assert {name: len(points) for name,points in compare.items()} == {'NDM':5,'MatchedASD':5,'LongASD':4}
    return {'stored_points_checked':counter, 'decomposed_points':135 * sum(map(len, compare.values())),
            'combined_histories':compare}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    with TemporaryDirectory(dir=args.report.resolve().parent) as folder:
        proof = verify(args.repo.resolve(), Path(folder))
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, indent=2, sort_keys=True, allow_nan=False)
        output.write('\n')
    print('MVT2 STRESS ATTRIBUTION OFFLINE PASS', proof['decomposed_points'])
