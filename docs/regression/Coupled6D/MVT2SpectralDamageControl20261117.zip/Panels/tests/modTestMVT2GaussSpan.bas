﻿Attribute VB_Name = "modTestMVT2GaussSpan"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет квадратуру Гаусса в изолированной книге и сохраняет исходные поля.
Public Function RunTestMVT2GaussSpan(ByVal caseKey As String) As String
    Dim report As String, tracePath As String, completed As Boolean, started As Double, elapsed As Double
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для сравнения квадратуры нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\MVT2GaussSpan.csv"
    started = Timer
    Select Case caseKey
        Case "Geometry"
            RunGaussGeometryTest "SquareStock", False, False, report, tracePath
            RunGaussGeometryTest "SquareGauss", False, True, report, tracePath
            RunGaussGeometryTest "HoleStock", True, False, report, tracePath
            RunGaussGeometryTest "HoleGauss", True, True, report, tracePath
            completed = True
        Case "MVTStock", "MVTGauss"
            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, caseKey = "MVTGauss")
        Case "MVTGaussMixed"
            completed = TestMixedPanelWeight(report, tracePath)
        Case Else
            Err.Raise 5, , "Неизвестный режим проверки квадратуры."
    End Select
    elapsed = Timer - started
    If elapsed < 0# Then elapsed = elapsed + 86400#
    AddExperimentTraceTest report, tracePath, "CASE_FINISHED;" & caseKey & ";" & CStr(completed) & ";" & ExperimentNumberTest(elapsed)
    RunTestMVT2GaussSpan = report & "TOTAL_MVT2_GAUSS_SPAN: passed=1; failed=0; target_reached=" & CStr(completed)
    Exit Function
Failed:
    RunTestMVT2GaussSpan = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description & vbCrLf
    RunTestMVT2GaussSpan = RunTestMVT2GaussSpan & "TOTAL_MVT2_GAUSS_SPAN: passed=0; failed=1"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Использует замкнутое отверстие 4x4 мм внутри центрального интервала сплайна.
Private Function BuildGaussTestSection(ByVal withHole As Boolean) As CSectionModel
    If Not withHole Then
        Set BuildGaussTestSection = BuildBareMVT2SquareTest()
        Exit Function
    End If
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion, concrete As CConcreteRegion
    Set concrete = query.SubtractContainedRegion(query.RectangleRegion(0#, 0#, 240#, 240#), _
                                                 query.RectangleRegion(13#, -20#, 4#, 4#))
    region.Initialize concrete
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Set BuildGaussTestSection = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет действительные узлы и напряжения при чистом кручении и смешанной нагрузке.
Private Sub RunGaussGeometryTest(ByVal caseKey As String, ByVal withHole As Boolean, ByVal useGauss As Boolean, _
        ByRef report As String, ByVal tracePath As String)
    Dim operators As New CCoupledElasticState, frame As New CSectionNumericalFrame, section As CSectionModel
    Dim area As Double, lengthScale As Double, spans As Long, point As Long, component As Long, testLoad As Long
    Dim x As Double, y As Double, weight As Double, row As String, loadValue As Variant
    Dim deformation() As Double, forces() As Double, stress() As Double
    spans = 1: If withHole Then spans = 3
    Set section = BuildGaussTestSection(withHole)
    frame.Initialize section
    operators.PrepareModel section, 30000#, 0.2, spans, spans, 5, useFullSpanGauss5:=useGauss
    operators.CopyResultantResidualScales area, lengthScale
    AddExperimentTraceTest report, tracePath, "GEO_SETUP;" & caseKey & ";" & CStr(spans) & ";" & _
        CStr(operators.ConcretePointCount) & ";" & CStr(operators.PointCount) & ";" & ExperimentNumberTest(frame.OriginX) & ";" & _
        ExperimentNumberTest(frame.OriginY) & ";" & ExperimentNumberTest(area) & ";" & ExperimentNumberTest(lengthScale)
    For point = 1 To operators.PointCount
        operators.Point point, x, y, weight
        AddExperimentTraceTest report, tracePath, "GEO_POINT;" & caseKey & ";" & CStr(point) & ";" & _
            ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(weight)
    Next point
    For testLoad = 1 To 2
        If testLoad = 1 Then
            loadValue = Array(0#, 0#, 0#, 262750#, 0#, 0#)
        Else
            loadValue = Array(-3600#, -95000#, 73500#, 262750#, 830#, -1020#)
        End If
        If Not operators.Solve(CDbl(loadValue(0)), CDbl(loadValue(1)), CDbl(loadValue(2)), CDbl(loadValue(3)), _
                CDbl(loadValue(4)), CDbl(loadValue(5)), deformation, forces, stress) Then _
            Err.Raise 5, , "Не подтверждено упругое равновесие при проверке квадратуры."
        row = "GEO_LOAD;" & caseKey & ";" & CStr(testLoad) & ";" & ExperimentNumberTest(1000# * deformation(4))
        For component = 0 To 5: row = row & ";" & ExperimentNumberTest(CDbl(loadValue(component))): Next component
        For component = 1 To 6: row = row & ";" & ExperimentNumberTest(forces(component)): Next component
        AddExperimentTraceTest report, tracePath, row
        For point = 1 To operators.PointCount
            row = "GEO_STRESS;" & caseKey & ";" & CStr(testLoad) & ";" & CStr(point)
            For component = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(component, point)): Next component
            AddExperimentTraceTest report, tracePath, row
        Next point
    Next testLoad
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет координаты и веса бетона и поправок стали для независимых интегралов.
Private Sub RecordGaussPointsTest(ByVal section As CSectionModel, ByVal operators As CCoupledElasticState, _
        ByRef report As String, ByVal tracePath As String)
    Dim frame As New CSectionNumericalFrame, area As Double, lengthScale As Double
    Dim p As Long, i As Long, x As Double, y As Double, weight As Double, direction(1 To 6) As Double, row As String
    frame.Initialize section
    operators.CopyResultantResidualScales area, lengthScale
    AddExperimentTraceTest report, tracePath, "MVT_GEOM;" & CStr(operators.ConcretePointCount) & ";" & _
        CStr(operators.PointCount) & ";" & CStr(operators.DegreeCount) & ";" & ExperimentNumberTest(frame.OriginX) & ";" & _
        ExperimentNumberTest(frame.OriginY) & ";" & ExperimentNumberTest(area) & ";" & ExperimentNumberTest(lengthScale)
    For p = 1 To operators.PointCount
        operators.Point p, x, y, weight
        If p > operators.ConcretePointCount Then operators.SteelProjection p, direction
        row = "MVT_POINT;" & CStr(p) & ";" & ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(weight)
        For i = 1 To 6: row = row & ";" & ExperimentNumberTest(direction(i)): Next i
        AddExperimentTraceTest report, tracePath, row
    Next p
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет принятые центральные напряжения бетона и отдельно напряжение стержня.
Private Sub RecordGaussStressesTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByVal stage As Long, ByRef report As String, ByVal tracePath As String)
    Dim p As Long, i As Long, row As String, values(1 To 6) As Double, steelStress As Double
    For p = 1 To operators.PointCount
        concrete.CopyAcceptedStress p, values
        steelStress = 0#
        If p > operators.ConcretePointCount Then steelStress = response.AcceptedSteelStress(p)
        row = "MVT_STRESS;R" & CStr(stage) & ";" & CStr(p)
        For i = 1 To 6: row = row & ";" & ExperimentNumberTest(values(i)): Next i
        row = row & ";" & ExperimentNumberTest(steelStress)
        AddExperimentTraceTest report, tracePath, row
    Next p
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function RunMVT2TorqueContinuationTest(ByVal quadraturePoints As Long, ByRef report As String, _
        ByVal tracePath As String, ByVal useGauss As Boolean, _
        Optional ByVal followMixed As Boolean = False) As Boolean
    Const EC As Double = 30000#, NU As Double = 0.2, PEAK As Double = 0.0022, FT As Double = 2.10667357864589
    Const ATOL As Double = 0.0000005, RTOL As Double = 0.0000005
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim branch As New CCoupledLoadContinuation, wire As New CLoadPathVector
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#)
    nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, EC, NU, 1, 1, quadraturePoints, transverse, steelModels:=steel, useFullSpanGauss5:=useGauss
    If operators.ConcretePointCount <> quadraturePoints ^ 2 Or _
            operators.PointCount <> operators.ConcretePointCount + 20 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура уточнённого кручения MVT2 не совпала с контрольной."
    Dim plusConcrete As CCoupledConcreteResponse, minusConcrete As CCoupledConcreteResponse
    Dim plusSide As CCoupledReinforcedResponse, minusSide As CCoupledReinforcedResponse
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, FT, PEAK, gt, gc, True, _
        plusConcrete, minusConcrete, plusSide, minusSide
    If followMixed Then WriteMVT2OperatorsTest operators, tracePath
    wire.Initialize 0#, 0#, 0#, 0#, 0#, 0#, 0#, 1000000#, 0#, 0#, 0#, 0#
    branch.Initialize solver, wire, 1, 44, 26, ATOL, RTOL, True
    AddExperimentTraceTest report, tracePath, "MVT2_ADAPT_SETUP;" & CStr(quadraturePoints) & ";" & _
        ExperimentNumberTest(fc) & ";" & ExperimentNumberTest(FT) & ";" & ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc)
    RecordGaussPointsTest section, operators, report, tracePath
    AddExperimentTraceTest report, tracePath, "MVT_BUDGET;1;44;26;5e-7;5e-7"
    If followMixed Then
        RunMVT2TorqueContinuationTest = TestPublicationRecovery(solver, operators, concrete, response, _
            minusConcrete, minusSide, plusConcrete, plusSide, report, tracePath)
        Exit Function
    End If
    Dim targets As Variant, target As Variant, stage As Long, reached As Double, previousCount As Long, item As Long
    Dim solved As Boolean, meta As CResultMeta, expected(1 To 6) As Double, trace As CCoupledLoadTrace
    Dim fraction As Double, acceptedLambda As Double, field() As Double, actual() As Double, residual As Double
    Dim shearX() As Double, shearY() As Double
    operators.MeanShearProjections shearX, shearY
    targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 10.51)
    For Each target In targets
        stage = stage + 1
        solved = branch.Advance(CDbl(target))
        Set meta = branch.ResultMeta
        reached = branch.AcceptedLambda
        AddExperimentTraceTest report, tracePath, "MVT2_ADAPT_TRIAL;R" & CStr(stage) & ";" & _
            ExperimentNumberTest(CDbl(target)) & ";" & ExperimentNumberTest(reached) & ";" & CStr(solved) & ";" & _
            CStr(meta.InternalStatus) & ";" & CStr(meta.ResultCode) & ";" & meta.DiagnosticDetails
        AddExperimentTraceTest report, tracePath, "MVT_WORK;R" & CStr(stage) & ";" & _
            CStr(branch.RejectedAttempts)
        Set trace = branch.SavedTrace
        If branch.SavedFieldCount <> trace.Count Then Err.Raise 5, , "Не согласованы история и траектория кручения."
        For item = previousCount + 1 To trace.Count
            trace.ReadPoint item, fraction, acceptedLambda
            If fraction <> 1# Then Err.Raise 5, , "Изменилась заданная чисто крутящая траектория."
            AddExperimentTraceTest report, tracePath, "MVT2_ADAPT_HISTORY;R" & CStr(stage) & ";" & CStr(item) & _
                ";" & ExperimentNumberTest(acceptedLambda)
        Next item
        previousCount = trace.Count
        If previousCount > 0 Then
            branch.CopyAccepted field, actual
            expected(4) = reached * 1000000#
            residual = operators.ResultantResidualNorm(actual, expected)
            If residual > 0.000005 Then Err.Raise 5, , "Контроль усилий уточнённого кручения не подтверждён."
            RecordWangMVT2StateTest operators, concrete, response, field, actual, shearY, "R" & CStr(stage), _
                CDbl(target), reached, actual(4), residual, report, tracePath
            RecordGaussStressesTest operators, concrete, response, stage, report, tracePath
        End If
        If Not solved Then Exit Function
        If reached <> CDbl(target) Then Err.Raise 5, , "Не подтверждена фактическая запрошенная цель кручения."
    Next target
    Dim eps0 As Double, kappaX As Double, kappaY As Double, twist As Double
    If followMixed Then
        operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist
        If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _
            Err.Raise 5, , "История чистого кручения перед совместной пробой отличается."
        WriteMVT2TorqueTensorsTest operators, concrete, branch, EC, NU, fc, FT, PEAK, gt, gc, tracePath
        AddExperimentTraceTest report, tracePath, "MVT_PRELOAD_END;8;10.51"
        RunMVT2TorqueContinuationTest = RunMVT2ShearAfterPreloadTest(operators, concrete, response, solver, shearY, _
            ATOL, RTOL, report, tracePath, plusConcrete, minusConcrete, plusSide, minusSide)
        Exit Function
    End If
    RunMVT2TorqueContinuationTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function BuildBareMVT2SquareTest() As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("MVT2_Outer", Array(Array(-120#, -120#, 240#, 240#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Set BuildBareMVT2SquareTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function BuildWangMVT2SectionTest(ByRef transverse As CTransverseRebarLayout, ByRef steel As Object) As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("MVT2_Outer", Array(Array(-120#, -120#, 240#, 240#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Dim xSign As Long, ySign As Long
    For xSign = -1 To 1 Step 2
        For ySign = -1 To 1 Step 2
            section.AddRebarElement 84# * xSign, 84# * ySign, 16#, GEOM_PI * 64#, "MVT2_LONG"
        Next ySign
    Next xSign
    Set transverse = New CTransverseRebarLayout
    transverse.AddContourGroup section, "MVT2_HOOP", vbNullString, 8#, 60#, 20#, "MVT2_HOOP"
    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "MVT2_LONG", ExperimentBilinearSteelTest(200000#, 498#, 0#)
    steel.Add "MVT2_HOOP", ExperimentBilinearSteelTest(200000#, 450#, 0#)
    Set BuildWangMVT2SectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Sub InitializeExperimentSolverTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal center As CCoupledReinforcedResponse, ByVal steel As Object, _
        ByVal ec As Double, ByVal nu As Double, ByVal fc As Double, ByVal ft As Double, ByVal peakStrain As Double, _
        ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean, _
        ByRef plusConcrete As CCoupledConcreteResponse, ByRef minusConcrete As CCoupledConcreteResponse, _
        ByRef plusSide As CCoupledReinforcedResponse, ByRef minusSide As CCoupledReinforcedResponse)
    Const LOCALIZATION_LENGTH As Double = 125# ' мм, принятое значение во всех трёх сопоставлениях.
    Dim pointCount As Long: pointCount = operators.PointCount
    Dim fc0 As Double: fc0 = 0.6 * fc ' Начальная прочность сжатия в материальной модели.
    concrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    center.Initialize operators, concrete, steel
    If Not spatialHistory Then
        solver.Initialize operators, center, ec
        Exit Sub
    End If
    Set plusConcrete = New CCoupledConcreteResponse: Set minusConcrete = New CCoupledConcreteResponse
    Set plusSide = New CCoupledReinforcedResponse: Set minusSide = New CCoupledReinforcedResponse
    plusConcrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, center, ec, plusSide, minusSide
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function ExperimentBilinearSteelTest(ByVal modulus As Double, ByVal strength As Double, ByVal hardening As Double) As CCoupledSteelModel
    Dim steel As New CCoupledSteelModel
    steel.Initialize modulus, strength, strength, hardening, hardening, 0.05, 0.05
    Set ExperimentBilinearSteelTest = steel
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Sub RecordWangMVT2StateTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByRef resultants() As Double, ByRef shearY() As Double, _
        ByVal stage As String, ByVal requested As Double, ByVal reached As Double, ByVal torque As Double, ByVal residual As Double, _
        ByRef report As String, ByVal tracePath As String)
    Const LONG_YIELD As Double = 498#
    Const HOOP_YIELD As Double = 450#
    Dim point As Long, i As Long, gamma As Double, eps0 As Double, kappaX As Double, kappaY As Double, twist As Double
    Dim maxLong As Double, maxHoop As Double, atLong As Long, atHoop As Long, steelStress As Double
    Dim maximumTension As Double, maximumCompression As Double, tension As Double, compression As Double
    Dim minPrincipal As Double, maxPrincipal As Double, trace As Double, q As Double, high As Double, mid As Double, low As Double
    Dim stress(1 To 6) As Double
    operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist
    For i = 1 To UBound(shearY): gamma = gamma + shearY(i) * field(i): Next i
    For point = 1 To operators.PointCount
        If point <= operators.ConcretePointCount Then
            concrete.AcceptedPointDamage point, tension, compression
            maximumTension = GeomMax(maximumTension, tension): maximumCompression = GeomMax(maximumCompression, compression)
            concrete.CopyAcceptedStress point, stress
            CoupledStressInvariants stress, trace, q, high, mid, low
            If point = 1 Or low < minPrincipal Then minPrincipal = low
            If point = 1 Or high > maxPrincipal Then maxPrincipal = high
        Else
            steelStress = Abs(response.AcceptedSteelStress(point))
            If operators.TransverseGroupAt(point) > 0 Then
                maxHoop = GeomMax(maxHoop, steelStress)
                If steelStress >= HOOP_YIELD * (1# - 0.00000001) Then atHoop = atHoop + 1
            Else
                maxLong = GeomMax(maxLong, steelStress)
                If steelStress >= LONG_YIELD * (1# - 0.00000001) Then atLong = atLong + 1
            End If
        End If
    Next point
    AddExperimentTraceTest report, tracePath, "MVT2_STATE;" & stage & ";" & ExperimentNumberTest(requested) & ";" & _
        ExperimentNumberTest(reached) & ";" & ExperimentNumberTest(resultants(1) / 1000#) & ";" & ExperimentNumberTest(resultants(2) / 1000000#) & ";" & _
        ExperimentNumberTest(resultants(3) / 1000000#) & ";" & ExperimentNumberTest(torque / 1000000#) & ";" & _
        ExperimentNumberTest(resultants(5) / 1000#) & ";" & ExperimentNumberTest(resultants(6) / 1000#) & ";" & _
        ExperimentNumberTest(eps0) & ";" & ExperimentNumberTest(1000# * kappaX) & ";" & ExperimentNumberTest(1000# * kappaY) & ";" & _
        ExperimentNumberTest(1000# * twist) & ";" & ExperimentNumberTest(gamma) & ";" & ExperimentNumberTest(maxLong) & ";" & _
        ExperimentNumberTest(maxHoop) & ";" & CStr(atLong) & ";" & CStr(atHoop) & ";" & ExperimentNumberTest(maximumTension) & ";" & _
        ExperimentNumberTest(maximumCompression) & ";" & ExperimentNumberTest(minPrincipal) & ";" & _
        ExperimentNumberTest(maxPrincipal) & ";" & ExperimentNumberTest(residual)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function ExperimentNumberTest(ByVal value As Double) As String
    ExperimentNumberTest = Trim$(Str$(value))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Sub AddExperimentTraceTest(ByRef report As String, ByVal path As String, ByVal row As String)
    report = report & row & vbCrLf
    If Len(path) = 0 Then Exit Sub
    Dim file As Integer: file = FreeFile
    Open path For Append As #file
    Print #file, row
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль совместного нагружения после подтверждённой истории кручения.
Private Function RunMVT2ShearAfterPreloadTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByVal solver As CCoupledNewtonSolver, ByRef shearY() As Double, _
        ByVal atol As Double, ByVal rtol As Double, ByRef report As String, ByVal tracePath As String, _
        ByVal plusConcrete As CCoupledConcreteResponse, ByVal minusConcrete As CCoupledConcreteResponse, _
        ByVal plusSide As CCoupledReinforcedResponse, ByVal minusSide As CCoupledReinforcedResponse) As Boolean
    Const TORQUE As Double = 10510000#, ARM As Double = 396#, MAX_ITERATIONS As Long = 26
    Dim goals As Variant, i As Long, qy As Double, previousQ As Double, solved As Boolean, phase As String
    Dim expected(1 To 6) As Double, field() As Double, actual() As Double, residual As Double, meta As CResultMeta
    ReDim goals(1 To 32)
    For i = 1 To 32: goals(i) = 2500# * i: Next i
    Dim stations As New Collection
    stations.Add minusConcrete: stations.Add minusSide
    stations.Add concrete: stations.Add response
    stations.Add plusConcrete: stations.Add plusSide
    expected(4) = TORQUE
    For i = LBound(goals) To UBound(goals)
        qy = goals(i): expected(6) = qy: expected(2) = -ARM * qy
        phase = "S" & CStr(i + 1)
        solved = solver.TryStep(0#, expected(2), 0#, TORQUE, 0#, qy, atol, rtol, MAX_ITERATIONS)
        Set meta = solver.ResultMeta
        If Not solved And meta.InternalStatus = rsNumericalFailure Then
            AddExperimentTraceTest report, tracePath, "MVT2_CUT_DIRECT_STOP;" & phase & ";" & meta.DiagnosticDetails
            solver.DiscardStep
            solved = BisectWangCutTest(solver, operators, ARM, TORQUE, previousQ, qy, 3, atol, rtol, MAX_ITERATIONS, _
                phase, report, tracePath, stations)
            Set meta = solver.ResultMeta
        End If
        AddExperimentTraceTest report, tracePath, "MVT2_CUT_TRIAL;" & phase & ";" & ExperimentNumberTest(TORQUE) & ";" & _
            ExperimentNumberTest(qy) & ";" & ExperimentNumberTest(expected(2)) & ";" & CStr(solved) & ";" & _
            CStr(meta.InternalStatus) & ";" & CStr(meta.ResultCode) & ";" & meta.DiagnosticDetails
        If Not solved Then
            solver.DiscardStep
            solver.CopyAccepted field
            RecordGaussRetainedTest operators, concrete, response, field, report, tracePath
            Exit Function
        End If
        solver.CopyTrial field, actual
        residual = operators.ResultantResidualNorm(actual, expected)
        If residual > 0.000005 Then Err.Raise 5, , "Контроль шести усилий на правом срезе не подтверждён."
        solver.AcceptStep
        previousQ = qy
        RecordWangMVT2StateTest operators, concrete, response, field, actual, shearY, phase, _
            qy / 1000#, qy / 1000#, actual(4), residual, report, tracePath
        RecordGaussMixedStressesTest operators, concrete, response, phase, report, tracePath
        WriteMVT2FullFrameTest operators, field, phase, TORQUE, qy, tracePath, stations
    Next i
    RunMVT2ShearAfterPreloadTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль совместного нагружения после подтверждённой истории кручения.
Private Function BisectWangCutTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal armMm As Double, ByVal torque As Double, ByVal lowerQ As Double, ByVal upperQ As Double, ByVal depth As Long, _
        ByVal atol As Double, ByVal rtol As Double, ByVal maximum As Long, ByVal phase As String, _
        ByRef report As String, ByVal tracePath As String, ByVal stations As Collection) As Boolean
    Dim midQ As Double, solved As Boolean, meta As CResultMeta
    midQ = (lowerQ + upperQ) / 2#
    solved = solver.TryStep(0#, -armMm * midQ, 0#, torque, 0#, midQ, atol, rtol, maximum)
    If Not solved Then
        Set meta = solver.ResultMeta
        If depth <= 1 Or meta.InternalStatus <> rsNumericalFailure Then Exit Function
        solver.DiscardStep
        If Not BisectWangCutTest(solver, operators, armMm, torque, lowerQ, midQ, depth - 1, atol, rtol, maximum, _
                phase, report, tracePath, stations) Then Exit Function
    End If
    Dim field() As Double, actual() As Double, expected(1 To 6) As Double, residual As Double, i As Long, wire As String
    expected(2) = -armMm * midQ: expected(4) = torque: expected(6) = midQ
    solver.CopyTrial field, actual
    residual = operators.ResultantResidualNorm(actual, expected)
    If residual > 0.000005 Then Err.Raise 5, , "Невязка промежуточной ступени MVT2 превышает допуск."
    For i = 1 To 6: wire = wire & ";" & ExperimentNumberTest(actual(i)): Next i
    solver.AcceptStep
    AddExperimentTraceTest report, tracePath, "MVT2_CUT_INSERTED;" & phase & ";" & ExperimentNumberTest(midQ) & _
        ";" & ExperimentNumberTest(residual) & wire
    WriteMVT2FullFrameTest operators, field, phase & "A" & ExperimentNumberTest(midQ), _
        torque, midQ, tracePath, stations
    solved = solver.TryStep(0#, -armMm * upperQ, 0#, torque, 0#, upperQ, atol, rtol, maximum)
    If Not solved And depth > 1 Then
        Set meta = solver.ResultMeta
        If meta.InternalStatus = rsNumericalFailure Then
            solver.DiscardStep
            solved = BisectWangCutTest(solver, operators, armMm, torque, midQ, upperQ, depth - 1, atol, rtol, maximum, _
                phase, report, tracePath, stations)
        End If
    End If
    BisectWangCutTest = solved
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль совместного нагружения после подтверждённой истории кручения.
Private Sub RecordGaussMixedStressesTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByVal phase As String, ByRef report As String, ByVal tracePath As String)
    Dim p As Long, i As Long, row As String, values(1 To 6) As Double, steelStress As Double
    For p = 1 To operators.PointCount
        concrete.CopyAcceptedStress p, values
        steelStress = 0#
        If p > operators.ConcretePointCount Then steelStress = response.AcceptedSteelStress(p)
        row = "MVT_SHEAR_STRESS;" & phase & ";" & CStr(p)
        For i = 1 To 6: row = row & ";" & ExperimentNumberTest(values(i)): Next i
        row = row & ";" & ExperimentNumberTest(steelStress)
        AddExperimentTraceTest report, tracePath, row
    Next p
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль совместного нагружения после подтверждённой истории кручения.
Private Sub RecordGaussRetainedTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByRef report As String, ByVal tracePath As String)
    Dim eps0 As Double, kappaX As Double, kappaY As Double, twist As Double
    operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist
    AddExperimentTraceTest report, tracePath, "MVT_SHEAR_RETAINED;" & ExperimentNumberTest(1000# * twist)
    RecordGaussMixedStressesTest operators, concrete, response, "END", report, tracePath
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Восстанавливает центральную историю чистого кручения по всем принятым полям.
' В основных точках проверяет повтор по фактическим принятым напряжениям.
Private Sub WriteMVT2TorqueTensorsTest(ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal branch As CCoupledLoadContinuation, _
        ByVal modulus As Double, ByVal poisson As Double, ByVal fc As Double, ByVal ft As Double, _
        ByVal peak As Double, ByVal gt As Double, ByVal gc As Double, ByVal tracePath As String)
    Dim replay As New CCoupledConcreteResponse, material As ICoupledPointResponse
    replay.Initialize operators.PointCount, modulus, poisson, 0.6 * fc, fc, ft, peak, gt, gc, 125#
    Set material = replay
    Dim path As String: path = tracePath & ".Tensor.csv"
    Dim handle As Integer: handle = FreeFile
    Open path For Output As #handle
    Print #handle, "MODEL;" & ExperimentNumberTest(modulus) & ";" & ExperimentNumberTest(poisson) & ";" & _
        ExperimentNumberTest(fc) & ";" & ExperimentNumberTest(ft) & ";" & ExperimentNumberTest(peak) & ";" & _
        ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc) & ";125"
    PrintMVT2CurveTest concrete, modulus, False, "TENSION", handle
    PrintMVT2CurveTest concrete, modulus, True, "COMPRESSION", handle
    Dim trace As CCoupledLoadTrace: Set trace = branch.SavedTrace
    Dim item As Long, point As Long, fraction As Double, lambda As Double, field() As Double, component As Long
    Dim strain(1 To 6) As Double, stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim reference(1 To 6) As Double, row As String
    For item = 1 To trace.Count
        trace.ReadPoint item, fraction, lambda
        If fraction <> 1# Then Err.Raise 5, , "Неверная принятая доля начального кручения."
        branch.CopySavedField item, field
        WriteMVT2OperatorFieldTest tracePath, "R" & CStr(item), field
        Print #handle, "FRAME;R" & CStr(item) & ";" & ExperimentNumberTest(lambda * 1000000#) & ";0"
        For point = 1 To operators.PointCount
            operators.PointStrain point, field, strain
            If material.EvaluatePoint(point, strain, stress, tangent, ctmStressOnly) <> sfcNone Then _
                Err.Raise 5, , "Материал не воспроизвёл принятое поле кручения."
            If item = trace.Count Then
                concrete.CopyAcceptedStress point, reference
                For component = 1 To 6
                    If Abs(stress(component) - reference(component)) > 0.000000001 Then _
                        Err.Raise 5, , "Конечное напряжение кручения в повторе отличается от принятого."
                Next component
            End If
            PrintMVT2TensorTest handle, point, strain, stress
        Next point
        material.AcceptTrial
    Next item
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет центральный срез после принятия равновесного шага сдвига.
Private Sub WriteMVT2ShearTensorsTest(ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByRef field() As Double, ByVal phase As String, _
        ByVal torque As Double, ByVal qy As Double, ByVal tracePath As String)
    Dim handle As Integer: handle = FreeFile
    Open tracePath & ".Tensor.csv" For Append As #handle
    Print #handle, "FRAME;" & phase & ";" & ExperimentNumberTest(torque) & ";" & ExperimentNumberTest(qy)
    Dim point As Long, strain(1 To 6) As Double, stress(1 To 6) As Double
    For point = 1 To operators.PointCount
        operators.PointStrain point, field, strain
        concrete.CopyAcceptedStress point, stress
        PrintMVT2TensorTest handle, point, strain, stress
    Next point
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает шесть инженерных деформаций и шесть сопряжённых напряжений.
Private Sub PrintMVT2TensorTest(ByVal handle As Integer, ByVal point As Long, _
        ByRef strain() As Double, ByRef stress() As Double)
    Dim row As String: row = "POINT;" & CStr(point)
    Dim component As Long
    For component = 1 To 6: row = row & ";" & ExperimentNumberTest(strain(component)): Next component
    For component = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(component)): Next component
    Print #handle, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет фактические точки огибающей из того же объекта материала.
Private Sub PrintMVT2CurveTest(ByVal concrete As CCoupledConcreteResponse, ByVal modulus As Double, _
        ByVal compression As Boolean, ByVal name As String, ByVal handle As Integer)
    Dim strain() As Double, stress() As Double, point As Long
    concrete.CopyCalibrationPoints compression, modulus, strain, stress
    For point = LBound(strain) To UBound(strain)
        Print #handle, "CURVE;" & name & ";" & ExperimentNumberTest(strain(point)) & ";" & ExperimentNumberTest(stress(point))
    Next point
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает действие штатных операторов на единичные поля, усилия и напряжения.
' Нелинейная материальная история при этом ещё пуста и не используется.
Private Sub WriteMVT2OperatorsTest(ByVal operators As CCoupledElasticState, ByVal tracePath As String)
    Dim path As String: path = tracePath & ".Operators.csv"
    Dim handle As Integer: handle = FreeFile
    Open path For Output As #handle
    Print #handle, "SIZE;" & CStr(operators.DegreeCount) & ";" & CStr(operators.PointCount) & ";0.001"
    Dim field() As Double, external() As Double, residual() As Double, matrix() As Double
    Dim dimension As Long: dimension = operators.DegreeCount
    ReDim field(1 To dimension)
    operators.LoadEquations 0#, 0#, 0#, 0#, 0#, 0#, external
    operators.StartEquations field, external, residual, matrix, True
    Dim column As Long, rowIndex As Long, point As Long, component As Long, row As String
    For column = 1 To dimension
        row = "G;" & CStr(column)
        For rowIndex = 1 To dimension: row = row & ";" & ExperimentNumberTest(matrix(rowIndex, column)): Next rowIndex
        Print #handle, row
    Next column
    Dim load(1 To 6) As Double
    For component = 1 To 6
        load(component) = 1#
        operators.LoadEquations load(1), load(2), load(3), load(4), load(5), load(6), external
        Print #handle, "L;" & CStr(component) & MVT2OperatorValuesTest(external)
        load(component) = 0#
    Next component
    Dim strain(1 To 6) As Double, gradient(1 To 6) As Double, stress(1 To 6) As Double
    Dim direction(1 To 6) As Double, resultants(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    operators.LoadEquations 0#, 0#, 0#, 0#, 0#, 0#, external
    For point = 1 To operators.PointCount
        For column = 1 To dimension
            field(column) = 1#
            operators.PointStrain point, field, strain
            operators.AxialGradientAtPoint point, field, gradient
            Print #handle, "B;" & CStr(point) & ";" & CStr(column) & _
                MVT2OperatorValuesTest(strain) & MVT2OperatorValuesTest(gradient)
            field(column) = 0#
        Next column
        For component = 1 To 6
            stress(component) = 1#
            operators.StartEquations field, external, residual, matrix, False
            operators.AddSpatialPointEquilibrium point, stress, tangent, direction, tangent, tangent, _
                residual, matrix, False, resultants
            Print #handle, "S;" & CStr(point) & ";" & CStr(component) & MVT2OperatorValuesTest(residual)
            stress(component) = 0#
            direction(component) = 1#
            operators.StartEquations field, external, residual, matrix, False
            operators.AddSpatialPointEquilibrium point, stress, tangent, direction, tangent, tangent, _
                residual, matrix, False, resultants
            Print #handle, "R;" & CStr(point) & ";" & CStr(component) & MVT2OperatorValuesTest(residual)
            direction(component) = 0#
        Next component
    Next point
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет только физически принятые коэффициенты из той же расчётной сетки.
Private Sub WriteMVT2OperatorFieldTest(ByVal tracePath As String, ByVal phase As String, ByRef field() As Double)
    Dim handle As Integer: handle = FreeFile
    Open tracePath & ".Operators.csv" For Append As #handle
    Print #handle, "F;" & phase & MVT2OperatorValuesTest(field)
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает напряжение, передаваемое в уравнения как отклик данной станции.
' В точке стали вычитает бетон и добавляет фактическое усилие стержня на площадь.
Private Sub WriteMVT2OperatorAnchorTest(ByVal operators As CCoupledElasticState, ByVal tracePath As String, _
        ByVal phase As String, ByVal side As Long, ByVal concrete As CCoupledConcreteResponse, _
        ByVal steel As CCoupledReinforcedResponse)
    Dim handle As Integer: handle = FreeFile
    Open tracePath & ".Operators.csv" For Append As #handle
    Dim point As Long, component As Long, stress(1 To 6) As Double, direction(1 To 6) As Double, rebar As Double
    For point = 1 To operators.PointCount
        concrete.CopyAcceptedStress point, stress
        If point > operators.ConcretePointCount Then
            operators.SteelProjection point, direction
            rebar = steel.AcceptedSteelStress(point)
            For component = 1 To 6: stress(component) = rebar * direction(component) - stress(component): Next component
        End If
        Print #handle, "H;" & phase & ";" & CStr(side) & ";" & CStr(point) & MVT2OperatorValuesTest(stress)
    Next point
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Представляет коэффициенты и напряжения в инвариантном формате архива.
Private Function MVT2OperatorValuesTest(ByRef values() As Double) As String
    Dim i As Long
    For i = LBound(values) To UBound(values)
        MVT2OperatorValuesTest = MVT2OperatorValuesTest & ";" & ExperimentNumberTest(values(i))
    Next i
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет центральные тензоры, поле и узловой отклик трёх станций.
Private Sub WriteMVT2FullFrameTest(ByVal operators As CCoupledElasticState, _
        ByRef field() As Double, ByVal phase As String, ByVal torque As Double, _
        ByVal shear As Double, ByVal tracePath As String, ByVal stations As Collection)
    Dim concrete As CCoupledConcreteResponse, steel As CCoupledReinforcedResponse, side As Long
    Set concrete = stations.Item(3)
    WriteMVT2ShearTensorsTest operators, concrete, field, phase, torque, shear, tracePath
    WriteMVT2OperatorFieldTest tracePath, phase, field
    For side = -1 To 1
        Set concrete = stations.Item(2 * side + 3)
        Set steel = stations.Item(2 * side + 4)
        WriteMVT2OperatorAnchorTest operators, tracePath, phase, side, concrete, steel
    Next side
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Восстанавливает принятую историю и сравнивает два прогноза для одной
' силовой цели. Невязка и допуски остаются штатными.
Private Function TestPublicationRecovery(ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByVal minusConcrete As CCoupledConcreteResponse, _
        ByVal minusSide As CCoupledReinforcedResponse, ByVal plusConcrete As CCoupledConcreteResponse, _
        ByVal plusSide As CCoupledReinforcedResponse, ByRef report As String, ByVal tracePath As String) As Boolean
    Const T As Double = 10510000#, ARM As Double = 396#, Q_ACCEPTED As Double = 21875#, Q_TARGET As Double = 22500#
    Const ATOL As Double = 0.0000005, RTOL As Double = 0.0000005, MAX_ITERATIONS As Long = 26
    Dim history As New Collection, stations As New Collection, inputFile As Integer, path As String
    Dim line As String, parts As Variant, field() As Double, leftField() As Double, rightField() As Double
    Dim seedValues() As Double, actual() As Double, load(1 To 6) As Double, seed As Variant
    Dim i As Long, mode As Variant, attempt As Boolean, result As CResultMeta
    path = Environ$("NDM_MVT_REPLAY")
    If Len(path) = 0 Then Err.Raise 5, , "Не задана история принятого поля."
    inputFile = FreeFile
    Open path For Input As #inputFile
    Do While Not EOF(inputFile)
        Line Input #inputFile, line
        parts = Split(line, ";")
        If UBound(parts) <> 62 Then
            Close #inputFile
            Err.Raise 5, , "Неверный размер записи истории MVT2."
        End If
        ReDim field(1 To 60)
        For i = 1 To 60: field(i) = Val(parts(i + 2)): Next i
        history.Add field
    Loop
    Close #inputFile
    If history.Count <> 22 Or Val(parts(1)) <> Q_ACCEPTED Then Err.Raise 5, , "История MVT2 не совпала."
    leftField = history.Item(21): rightField = history.Item(22)
    stations.Add minusConcrete: stations.Add minusSide
    stations.Add concrete: stations.Add response
    stations.Add plusConcrete: stations.Add plusSide
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена история MVT2."
    WriteMVT2FullFrameTest operators, rightField, "Replay", T, Q_ACCEPTED, tracePath, stations
    AddExperimentTraceTest report, tracePath, "MVT2_RECOVERY_REPLAY;22;21875"
    TestPublicationRecovery = TestPublicationMaterialHistory(solver, operators, concrete, history, report, tracePath)
    Exit Function
    ReDim seedValues(1 To 60)
    For i = 1 To 60: seedValues(i) = rightField(i) + (rightField(i) - leftField(i)): Next i ' Равный шаг 625 Н.
    load(2) = -ARM * Q_TARGET: load(4) = T: load(6) = Q_TARGET
    For Each mode In Array("AcceptedField", "ForceSecant")
        If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена общая история MVT2."
        If mode = "AcceptedField" Then
            attempt = solver.TryStep(0#, load(2), 0#, T, 0#, Q_TARGET, ATOL, RTOL, MAX_ITERATIONS)
        Else
            seed = seedValues
            attempt = solver.TryStep(0#, load(2), 0#, T, 0#, Q_TARGET, ATOL, RTOL, MAX_ITERATIONS, seed)
        End If
        Set result = solver.ResultMeta
        AddExperimentTraceTest report, tracePath, "MVT2_RECOVERY_TRIAL;" & CStr(mode) & ";22500;" & CStr(attempt) & ";" & _
            CStr(result.InternalStatus) & ";" & CStr(result.ResultCode) & ";" & result.DiagnosticDetails
        If attempt Then
            solver.CopyTrial field, actual
            If operators.ResultantResidualNorm(actual, load) > 0.000005 Then Err.Raise 5, , "Превышена силовая невязка MVT2."
            solver.AcceptStep
            WriteMVT2FullFrameTest operators, field, CStr(mode), T, Q_TARGET, tracePath, stations
            TestPublicationRecovery = True
        Else
            solver.DiscardStep
        End If
    Next mode
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считывает принятую историю локального возмущения в центральном сечении.
Private Function TestPublicationMaterialHistory(ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal history As Collection, ByRef report As String, ByVal tracePath As String) As Boolean
    Dim index As Variant, selected As Variant, field() As Double, strain(1 To 6) As Double
    Dim stress(1 To 6) As Double, values() As Double, tag As String, row As String
    For Each index In Array(8, 18, 19, 20, 21, 22)
        If Not solver.ReplayAcceptedFields(history, CLng(index)) Then Err.Raise 5, , "Не восстановлена история бетона MVT2."
        field = history.Item(index)
        tag = "Material" & CStr(index)
        For Each selected In Array(11, 14, 15)
            operators.PointStrain CLng(selected), field, strain
            concrete.CopyAcceptedStress CLng(selected), stress
            concrete.TestCopyAcceptedMaterialHistory CLng(selected), values
            row = "MVT2_NATIVE_MATERIAL;" & tag & ";" & CStr(selected) & _
                MVT2OperatorValuesTest(strain) & MVT2OperatorValuesTest(stress) & MVT2OperatorValuesTest(values)
            AddExperimentTraceTest report, tracePath, row
        Next selected
    Next index
    TestPublicationMaterialHistory = True
End Function


' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет испытания Vecchio и Collins при заданном инженерном сдвиге.
' Равновесие решается по трём нормальным деформациям панели.
Private Function TestMixedPanelWeight(ByRef report As String, ByVal tracePath As String) As Boolean
    Dim panels As Variant
    panels = Array(Array("PV13", 18.2, 0.0027, 0.0179, 248#, 0#, 0#, 0#, 0.012), _
                   Array("PV16", 21.7, 0.002, 0.0074, 255#, 0.0074, 255#, 0#, 0.01), _
                   Array("PV23", 20.5, 0.002, 0.0179, 518#, 0.0179, 518#, -0.39, 0.012), _
                   Array("PV25", 19.2, 0.0018, 0.0179, 466#, 0.0179, 466#, -0.69, 0.012), _
                   Array("PV28", 19#, 0.0019, 0.0179, 483#, 0.0179, 483#, 0.32, 0.012))
    Dim handle As Integer: handle = FreeFile
    Open tracePath & ".Dilation.csv" For Output As #handle
    On Error GoTo Failed
    Dim panel As Variant, weight As Variant
    For Each panel In panels
        For Each weight In Array(20, 10, 5)
            TestRunMixedPanelWeight panel, CDbl(weight), report, tracePath, handle
        Next weight
    Next panel
    Close #handle
    TestMixedPanelWeight = True
    Exit Function
Failed:
    Dim description As String: description = Err.Description
    Close #handle
    Err.Raise 5, , description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Готовит материалы одной панели и сохраняет каждый принятый шаг истории.
Private Sub TestRunMixedPanelWeight(ByVal panel As Variant, ByVal weight As Double, _
        ByRef report As String, ByVal tracePath As String, ByVal handle As Integer)
    Const STEP_SIZE As Double = 0.000025, NU As Double = 0.2, LENGTH As Double = 140#
    Dim concrete As New CCoupledConcreteResponse, material As ICoupledPointResponse
    Dim fc As Double: fc = CDbl(panel(1))
    Dim modulus As Double, ft As Double, gt As Double, gc As Double
    modulus = 10000# * (0.8 + 0.2 * (fc + 8#) / 88#) * (fc + 8#) ^ (1# / 3#)
    ft = 0.302 * fc ^ (2# / 3#): gt = 0.073 * fc ^ 0.18: gc = (fc / ft) ^ 2 * gt
    concrete.Initialize 1, modulus, NU, 0.6 * fc, fc, ft, CDbl(panel(2)), gt, gc, LENGTH
    concrete.TestSetMixedDilationWeight weight
    Set material = concrete
    Dim marker As String: marker = CStr(panel(0)) & ";" & CStr(weight)
    Print #handle, "MODEL;" & marker & ";" & ExperimentNumberTest(modulus) & ";" & _
        ExperimentNumberTest(ft) & ";" & ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc)
    Dim current(1 To 6) As Double, previous(1 To 4) As Double, plastic(1 To 2) As Double, nextStep As Long, steps As Long
    Dim accepted As Long, achieved As Boolean, attempts As Long, gamma As Double
    steps = CLng(CDbl(panel(8)) / STEP_SIZE)
    For nextStep = 1 To steps
        gamma = nextStep * STEP_SIZE
        achieved = TestAdvancePanelWeight(concrete, material, panel, marker, current, previous, plastic, gamma, 0, handle, accepted, attempts)
        If Not achieved Then Exit For
    Next nextStep
    AddExperimentTraceTest report, tracePath, "PANEL_WEIGHT_STATUS;" & marker & ";" & CStr(achieved) & ";" & _
        CStr(accepted) & ";" & CStr(attempts) & ";" & ExperimentNumberTest(current(4)) & ";" & ExperimentNumberTest(gamma)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Делит только отклонённое приращение. Принимает и выгружает подшаги по порядку.
Private Function TestAdvancePanelWeight(ByVal concrete As CCoupledConcreteResponse, _
        ByVal material As ICoupledPointResponse, ByVal panel As Variant, ByVal marker As String, _
        ByRef current() As Double, ByRef previous() As Double, ByRef plastic() As Double, ByVal gamma As Double, ByVal depth As Long, _
        ByVal handle As Integer, ByRef accepted As Long, ByRef attempts As Long) As Boolean
    Dim strain(1 To 6) As Double, stress(1 To 6) As Double, state() As Double, steel(1 To 2) As Double, i As Long
    strain(4) = gamma
    Dim predictionFactor As Double, solved As Boolean
    If current(4) > previous(4) Then predictionFactor = GeomMin(2#, (gamma - current(4)) / (current(4) - previous(4)))
    For i = 1 To 3: strain(i) = current(i) + predictionFactor * (current(i) - previous(i)): Next i
    attempts = attempts + 1
    solved = TestSolvePanelWeight(material, panel, strain, plastic, stress, steel)
    If Not solved And predictionFactor > 0# Then
        For i = 1 To 3: strain(i) = current(i): Next i
        solved = TestSolvePanelWeight(material, panel, strain, plastic, stress, steel)
    End If
    If solved Then
        For i = 1 To 4: previous(i) = current(i): current(i) = strain(i): Next i
        accepted = accepted + 1
        concrete.TestCopyAcceptedMaterialHistory 1, state
        Print #handle, "STATE;" & marker & ";" & CStr(accepted) & MVT2OperatorValuesTest(strain) & _
            MVT2OperatorValuesTest(stress) & MVT2OperatorValuesTest(steel) & MVT2OperatorValuesTest(plastic) & MVT2OperatorValuesTest(state)
        TestAdvancePanelWeight = True
        Exit Function
    End If
    If depth = 7 Then Exit Function
    Dim midpoint As Double: midpoint = 0.5 * (current(4) + gamma)
    If Not TestAdvancePanelWeight(concrete, material, panel, marker, current, previous, plastic, midpoint, depth + 1, _
            handle, accepted, attempts) Then Exit Function
    TestAdvancePanelWeight = TestAdvancePanelWeight(concrete, material, panel, marker, current, previous, plastic, gamma, depth + 1, _
        handle, accepted, attempts)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Решает нормальные уравнения при пропорциональной нормальной нагрузке.
' Состояние бетона и пластика стали записываются после сходимости.
Private Function TestSolvePanelWeight(ByVal material As ICoupledPointResponse, ByVal panel As Variant, _
        ByRef strain() As Double, ByRef plastic() As Double, ByRef stress() As Double, ByRef steel() As Double) As Boolean
    Const TOL As Double = 0.0000002 ' МПа, допуск направленных панельных опытов.
    Dim residual(1 To 3) As Double, normal(1 To 3, 1 To 3) As Double, delta(1 To 3) As Double, seed(1 To 3) As Double
    Dim tangent(1 To 6, 1 To 6) As Double, trialPlastic(1 To 2) As Double, tangentSteel(1 To 2) As Double
    Dim linear As New CCoupledLinearSystem, i As Long, iteration As Long, damping As Long, symmetric As Boolean, size As Long
    Dim currentNorm As Double, trialNorm As Double, fraction As Double
    symmetric = (CDbl(panel(3)) = CDbl(panel(5)) And CDbl(panel(4)) = CDbl(panel(6)))
    size = 3
    If symmetric Then size = 2: strain(2) = strain(1)
    If Not TestPanelResidual(material, panel, strain, plastic, stress, tangent, residual, steel, trialPlastic, tangentSteel, ctmStressOnly, currentNorm) Then Exit Function
    For iteration = 0 To 20
        If currentNorm <= TOL Then
            material.AcceptTrial
            For i = 1 To 2: plastic(i) = trialPlastic(i): Next i
            TestSolvePanelWeight = True
            Exit Function
        End If
        For i = 1 To 3: seed(i) = strain(i): delta(i) = -residual(i): Next i
        If symmetric Then delta(2) = delta(3)
        If Not TestPanelNormalTangent(material, panel, strain, plastic, residual, normal, symmetric) Then Exit Function
        If Not linear.Solve(normal, delta, size) Then Exit Function
        If symmetric Then delta(3) = delta(2): delta(2) = delta(1)
        fraction = 1#
        For damping = 0 To 10
            For i = 1 To 3: strain(i) = seed(i) + fraction * delta(i): Next i
            If TestPanelResidual(material, panel, strain, plastic, stress, tangent, residual, steel, trialPlastic, tangentSteel, ctmStressOnly, trialNorm) Then
                If trialNorm < currentNorm Then Exit For
            End If
            fraction = 0.5 * fraction
        Next damping
        If damping > 10 Then Exit Function
        currentNorm = trialNorm
    Next iteration
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Суммирует напряжения бетона и двух размазанных направлений стали.
Private Function TestPanelResidual(ByVal material As ICoupledPointResponse, ByVal panel As Variant, _
        ByRef strain() As Double, ByRef plastic() As Double, ByRef stress() As Double, ByRef tangent() As Double, _
        ByRef residual() As Double, ByRef steel() As Double, ByRef trialPlastic() As Double, _
        ByRef tangentSteel() As Double, ByVal mode As ECoupledTangentMode, ByRef norm As Double) As Boolean
    Const E_STEEL As Double = 200000#
    If material.EvaluatePoint(1, strain, stress, tangent, mode) <> sfcNone Then Exit Function
    Dim i As Long, trial As Double, fy As Double
    For i = 1 To 2
        fy = CDbl(panel(2 * i + 2))
        trial = E_STEEL * (strain(i) - plastic(i))
        steel(i) = GeomMax(-fy, GeomMin(fy, trial))
        trialPlastic(i) = strain(i) - steel(i) / E_STEEL
        tangentSteel(i) = 0#
        If Abs(trial) < fy Then tangentSteel(i) = E_STEEL
        residual(i) = stress(i) + CDbl(panel(2 * i + 1)) * steel(i) - CDbl(panel(7)) * stress(4)
    Next i
    residual(3) = stress(3)
    norm = GeomMax(Abs(residual(3)), GeomMax(Abs(residual(1)), Abs(residual(2))))
    TestPanelResidual = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит производную непосредственно по нормальным уравнениям панели.
' История бетона и арматуры во время всех разностей остаётся принятой.
Private Function TestPanelNormalTangent(ByVal material As ICoupledPointResponse, ByVal panel As Variant, _
        ByRef strain() As Double, ByRef plastic() As Double, ByRef residual() As Double, _
        ByRef normal() As Double, ByVal symmetric As Boolean) As Boolean
    Const DIFFERENCE As Double = 0.000000001
    Dim probeStrain(1 To 6) As Double, probeStress(1 To 6) As Double, unusedTangent(1 To 6, 1 To 6) As Double
    Dim trial(1 To 3) As Double, low(1 To 3) As Double, holdSteel(1 To 2) As Double
    Dim holdPlastic(1 To 2) As Double, holdTangent(1 To 2) As Double, norm As Double
    Dim i As Long, j As Long, column As Long, size As Long, hasLow As Boolean, hasHigh As Boolean
    size = 3
    If symmetric Then size = 2
    For j = 1 To size
        For i = 1 To 6: probeStrain(i) = strain(i): Next i
        column = j
        If symmetric And j = 2 Then column = 3
        probeStrain(column) = strain(column) - DIFFERENCE
        If symmetric And j = 1 Then probeStrain(2) = probeStrain(1)
        hasLow = TestPanelResidual(material, panel, probeStrain, plastic, probeStress, unusedTangent, low, holdSteel, holdPlastic, holdTangent, ctmStressOnly, norm)
        probeStrain(column) = strain(column) + DIFFERENCE
        If symmetric And j = 1 Then probeStrain(2) = probeStrain(1)
        hasHigh = TestPanelResidual(material, panel, probeStrain, plastic, probeStress, unusedTangent, trial, holdSteel, holdPlastic, holdTangent, ctmStressOnly, norm)
        If Not hasLow And Not hasHigh Then Exit Function
        For i = 1 To size
            Dim row As Long: row = i
            If symmetric And i = 2 Then row = 3
            If hasLow And hasHigh Then
                normal(j, i) = (trial(row) - low(row)) / (2# * DIFFERENCE)
            ElseIf hasHigh Then
                normal(j, i) = (trial(row) - residual(row)) / DIFFERENCE
            Else
                normal(j, i) = (residual(row) - low(row)) / DIFFERENCE
            End If
        Next i
    Next j
    TestPanelNormalTangent = True
End Function
