"""Готовит раздельное номинальное повреждение для двух направленных проверок."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent
MATERIAL = 'src/Materials/CCoupledConcreteResponse.cls'


def digest(raw):
    return sha256(raw).hexdigest().upper()


def once(text, old, new):
    assert text.count(old) == 1
    return text.replace(old, new)


def change(original, method):
    """Меняет только номинальный тензор после прежнего пластического возврата."""
    body = original.decode('utf-8-sig').replace('\r\n', '\n')
    body = once(body, '        Dim fraction As Double\n        fraction = (1# - r * dt) * (1# - dc)\n'
                      '        For i = 1 To N_COMPONENTS: apparent(i) = fraction * elastic(i): Next i',
                '        TestSplitNominal elastic, trialHigh, trialMid, trialLow, dt, dc, apparent')
    body = once(body, '    fraction = (1# - r * dt) * (1# - dc)\n    For i = 1 To N_COMPONENTS\n'
                      '        updated.Plastic(i) = committed.Plastic(i) + increment(i)\n'
                      '        apparent(i) = fraction * effective(i)\n    Next i',
                '    TestSplitNominal effective, high, mid, low, dt, dc, apparent\n    For i = 1 To N_COMPONENTS\n'
                '        updated.Plastic(i) = committed.Plastic(i) + increment(i)\n    Next i')
    return (body + method).replace('\n', '\r\n').encode('utf-8')


def stage(repo, root, run, guard_pid, guard_ticks):
    """Устанавливает вариант только в каталоге изолированной проверки."""
    touched = [root / MATERIAL]
    if run == 'Replay':
        prepare = run_path(str(HERE / 'Stage-ReverseMaterial.py'))
        prepare['stage'](repo, root, guard_pid, guard_ticks)
        original = (root / MATERIAL).read_bytes()
    elif run == 'Panels':
        prepare = run_path(str(HERE / 'Stage-PanelFine.py'))
        prepare['stage'](repo, root, guard_pid, guard_ticks)
        original = (root / MATERIAL).read_bytes()
    else:
        prepare = run_path(str(HERE / 'Stage-DilationEquilibrium.py'))
        prepare['stage'](repo, root, 32)
        original = (repo / MATERIAL).read_bytes()
        test = root / 'tests/modTestMVT2GaussSpan.bas'
        module = test.read_text(encoding='utf-8-sig')
        module = once(module, 'targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 10.51)',
                      'targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 8.67075, 10.51)')
        module = once(module, 'If branch.SavedFieldCount <> 8 Or twist <= 0# Then _',
                      'If branch.SavedFieldCount < UBound(targets) - LBound(targets) + 1 Or twist <= 0# Then _')
        module = once(module, '"MVT_PRELOAD_END;8;10.51"',
                      '"MVT_PRELOAD_END;" & CStr(branch.SavedFieldCount) & ";10.51"')
        test.write_bytes(module.replace('\n','\r\n').encode('utf-8-sig'))
        driver = root / 'Run-Native.ps1'
        text = driver.read_text('utf-8')
        text = once(text, "'CCoupledElasticState','modTestMVT2GaussSpan')",
                    "'CCoupledElasticState','modTestMVT2GaussSpan','CCoupledConcreteResponse')")
        driver.write_bytes(text.encode('utf-8'))
        guard = root / 'Guard-IsolatedOffice.ps1'
        protect = guard.read_text('utf-8')
        protect = once(protect, '$protected=@{', f'$protected=@{{{guard_pid}=[long]{guard_ticks};')
        guard.write_bytes(protect.encode('utf-8'))
        touched.extend((test, driver, guard))
    material = root / MATERIAL
    material.parent.mkdir(parents=True, exist_ok=True)
    method = (HERE / 'SplitNominal.cls.txt').read_text(encoding='utf-8')
    method.encode('cp1251')
    material.write_bytes(change(original, method))
    meta = root / 'Preparation.json'
    data = json.loads(meta.read_bytes())
    data['split_nominal_damage'] = True
    data['private_probe'] = run
    data['material_before_split_sha256'] = digest(original)
    for path in touched:
        data['inputs'][path.relative_to(root).as_posix()] = digest(path.read_bytes())
    meta.write_bytes((json.dumps(data, indent=2) + '\n').encode('utf-8'))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--run', choices=('Replay','Equilibrium','Panels'), required=True)
    parser.add_argument('--guard-pid', type=int, required=True)
    parser.add_argument('--guard-ticks', type=int, required=True)
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve(), args.run, args.guard_pid, args.guard_ticks)
