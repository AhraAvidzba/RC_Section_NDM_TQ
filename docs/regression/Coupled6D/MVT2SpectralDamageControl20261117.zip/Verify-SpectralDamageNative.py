"""Проверяет нативные траектории и тензоры варианта раздельного повреждения."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from re import findall
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


MATERIAL = 'src/Materials/CCoupledConcreteResponse.cls'
FOLLOW = 'MVT2NativePublicationCutFollow20261117.zip'
FOLLOW_SHA = '9F55DE3FC0B1B652DD1ED9683507423ADE4DF6AB3B008D9590EE1D9327F9864E'
TORQUES = (262750., 525500., 1051000., 2102000., 4204000., 6831500., 8670750., 10510000.)
PANELS = 'PanelFineCrackNormal20261117.zip'
PANELS_SHA = '954C0B70FF88387229084BF7C284605CDB647AB629AFD9F7E601AA09727AB89E'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(raw):
    return sha256(raw).hexdigest().upper()


def receipt(root, stage, book):
    """Подтверждает источник VBA и закрытие точного владельца копии Excel."""
    prep = read(root / 'Preparation.json')
    assert prep['split_nominal_damage'] and prep['private_probe'] == stage and prep['source_book_sha256'] == book
    for file in (MATERIAL, 'tests/modTestMVT2GaussSpan.bas', 'Run-Native.ps1', 'Guard-IsolatedOffice.ps1'):
        assert digest((root / file).read_bytes()) == prep['inputs'][file]
    compiler = read(root / 'CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256'] == book
    assert set(compiler['Modules']) == {'CCoupledConcreteResponse','CCoupledSectionQuadrature',
                                       'CCoupledElasticState','modTestMVT2GaussSpan'}
    assert read(root / 'CompileClosure.json')['State'] == 'Absent'
    folder = root / 'Native'
    owner = read(folder / 'MVTGaussMixed.txt.Ownership.json')
    closure = read(folder / 'MVTGaussMixed.txt.ProcessClosure.json')
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
    report = (folder / 'MVTGaussMixed.txt').read_text(encoding='utf-8-sig')
    assert f'TEST_EXCEL_PROCESS: id={owner["PID"]}; startTicks={owner["StartTicksUTC"]}' in report
    assert 'RUNTIME ERROR:' not in report
    if closure['Stage'] == 'TIMEOUT':
        assert stage in ('Equilibrium','Panels') and closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout']
        duration = 165 if stage == 'Equilibrium' else 240
        assert f'WATCHDOG_FAILURE: timeout={duration} sec;' in report and 'ownExcelState=Absent' in report
        identity, closed = closure['Identity'], closure['After']
        ending = 'timeout'
    else:
        assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['RunnerCleanupValid']
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in report
        identity, closed = closure['Closure']['Identity'], closure['Closure']['FinalState']
        ending = 'completed'
    assert identity['Valid'] and identity['PID'] == owner['PID'] and identity['Ticks'] == int(owner['StartTicksUTC'])
    assert closed['State'] == 'Absent'
    return {'excel_pid': owner['PID'], 'termination': ending}


def verify_replay(root, source, material, previous, spectra):
    """Сравнивает штатные истории с тензорами раздельного повреждения."""
    response = receipt(root, 'Replay', material['BOOK'])
    assert response['termination'] == 'completed'
    prep = read(root / 'Preparation.json')
    strain = (root / 'Replay.Fields.csv').read_bytes()
    assert digest(strain) == prep['inputs']['Replay.Fields.csv'] and strain == source.read('Replay.Fields.csv')
    trace = (root / 'Native/MVTGaussMixed.csv').read_text('ascii')
    counts = findall(r'MVT2_REVERSE_MATERIAL;(\w+);(\d+);(\d+)', trace)
    assert [(key, int(n), int(fail)) for key,n,fail in counts] == [('NDM',22,0),('MatchedASD',22,0),('LongASD',41,0)]
    actual = (root / 'Native/MaterialReplay.csv').read_text('ascii').splitlines()
    earlier = source.read('Native/MaterialReplay.csv').decode('ascii').splitlines()
    error = largest_stress_change = 0.
    for old, new in zip(earlier, actual, strict=True):
        inputs = old.split(';')
        results = new.split(';')
        assert len(results) == 29 and inputs[:9] == results[:9] and inputs[15:] == results[15:]
        total = tuple(map(float, inputs[3:9]))
        plastic = tuple(map(float, inputs[15:21]))
        dt, dc = map(float, inputs[-4:-2])
        effective = previous['elastic'](previous['add'](total, previous['multiply'](plastic,-1.)))
        negative, positive = spectra(effective, material['principal'])
        expected = previous['add'](previous['multiply'](negative, 1.-dc), previous['multiply'](positive, 1.-dt))
        stress = tuple(map(float, results[9:15]))
        error = max(error, *(abs(a-b) for a,b in zip(stress, expected, strict=True)))
        largest_stress_change = max(largest_stress_change, *(abs(a-float(b)) for a,b in zip(stress,inputs[9:15],strict=True)))
    assert error < 3e-9
    elapsed, = findall(r'CASE_FINISHED;MVTGaussMixed;True;([^\n]+)', trace)
    return response | {'material_states':len(actual), 'max_tensor_error_MPa':error,
                       'max_stress_change_MPa':largest_stress_change, 'macro_seconds':float(elapsed),
                       'equal_internal_variables':True}


def verify_equilibrium(repo, root, book, reference_path):
    """Собирает физические уравнения каждого принятого поля нового пути."""
    response = receipt(root, 'Equilibrium', book)
    evidence = repo / 'docs/regression/Coupled6D'
    follow_path = evidence / FOLLOW
    assert digest(follow_path.read_bytes()) == FOLLOW_SHA
    follow = {'__name__':'__pinned__'}
    with ZipFile(follow_path) as source:
        exec(compile(source.read('Verify-NativeFollow.py'), str(follow_path), 'exec'), follow)
    utilities, recovery, _, _, _, mesh = follow['read_references'](repo)
    with ZipFile(reference_path) as source:
        stock = json.loads(source.read('NativePublicationCutProof.json'))
        baseline = utilities['read_operators'](source.read('Native/Operators.csv'))
        wire = source.read('modTestMVT2GaussSpan.bas').decode('utf-8-sig').replace('\r\n','\n')
    text = (root / 'tests/modTestMVT2GaussSpan.bas').read_text(encoding='utf-8-sig')
    new_gate = 'If branch.SavedFieldCount < UBound(targets) - LBound(targets) + 1 Or twist <= 0# Then _'
    old_gate = 'If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _'
    assert text.count(', dilation:=32#') == 4 and text.count(new_gate) == 1
    targets_stock = 'targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 10.51)'
    targets_matched = 'targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 8.67075, 10.51)'
    assert text.count(targets_matched) == 1
    marker = '"MVT_PRELOAD_END;" & CStr(branch.SavedFieldCount) & ";10.51"'
    assert text.count(marker) == 1
    assert text.replace(', dilation:=32#','').replace(new_gate,old_gate).replace(
        targets_matched,targets_stock).replace(marker,'"MVT_PRELOAD_END;8;10.51"') == wire
    n = root / 'Native'
    trace = (n / 'MVTGaussMixed.csv').read_text('cp1251')
    rows = [raw.split(';') for raw in trace.splitlines()]
    assert recovery['geometry'](rows) == mesh
    tables = utilities['read_operators']((n / 'Operators.csv').read_bytes())
    frames = utilities['read_tensor_frames']((n / 'MVTGaussMixed.Tensor.csv').read_bytes(), 45)
    assert all(tables[key] == baseline[key] for key in 'GLBSR')
    assert list(tables['F']) == list(frames)
    preload_labels = [name for name in frames if name.startswith('R')]
    assert preload_labels == [f'R{i+1}' for i in range(len(preload_labels))]
    actual_preload = [frames[name][0] for name in preload_labels]
    goal_rows = [row for row in rows if row[0] == 'MVT2_ADAPT_TRIAL']
    plateaus = [row for row in rows if row[0] == 'MVT2_ADAPT_HISTORY']
    assert [int(row[2]) for row in plateaus] == list(range(1,len(plateaus)+1))
    assert [float(row[3])*1e6 for row in plateaus] == actual_preload
    assert [float(row[2])*1e6 for row in goal_rows] == list(TORQUES)
    assert all(row[2] == row[3] and row[4:7] == ['True','4','0'] for row in goal_rows)
    assert all(t in actual_preload for t in TORQUES) and all(frames[name][1] == 0. for name in preload_labels)
    assert f'MVT_PRELOAD_END;{len(actual_preload)};10.51' in trace
    certify = run_path(str(root.parent / 'Verify-DilationEquilibrium.py'))['integrate_preload']
    _, _, area, radius = mesh[0]
    scales = (area, area*radius, area*radius, area*radius, area, area)
    preloads = []
    for name in preload_labels:
        t, _, sigma = frames[name]
        k = tables['F'][name]
        forces = certify(k, sigma, mesh, tables)
        norm = max(abs(a-b)/size for a,b,size in zip(forces,(0.,0.,0.,t,0.,0.),scales,strict=True))
        assert norm <= 5e-7 + 5e-7*abs(t)/scales[3]
        preloads.append({'phase':name,'T_Nmm':t,'twist_rad_per_m':k[3]*1000./radius,
                         'signed_resultants_N_Nmm':forces,'eq_norm_MPa':norm})
    targets, accepted = [], {}
    for row in rows:
        if row[0] == 'MVT2_CUT_TRIAL':
            _, phase, t, q, m, ok, internal, code, *details = row
            shear = float(q)
            assert float(t) == TORQUES[-1] and float(m) == -396.*shear
            work = follow['trial_work'](details,ok,internal,code)
            targets.append(work | {'phase':phase,'Qy_N':shear})
            if ok == 'True':
                accepted[phase] = shear
        elif row[0] == 'MVT2_CUT_INSERTED':
            accepted[row[1]+'A'+row[2]] = float(row[2])
    assert [row['Qy_N'] for row in targets] == [2500.*i for i in range(1,len(targets)+1)]
    mixed = [name for name in frames if name not in preload_labels]
    assert set(mixed) == set(accepted)
    assert len(tables['H']) == 135*len(mixed)
    comparison = {v['Qy_N']:v for v in stock['compared_same_six_force_states']}
    checks = []
    for label in mixed:
        torque, shear, _ = frames[label]
        assert torque == TORQUES[-1] and shear == accepted[label]
        field = tables['F'][label]
        check = recovery['equations'](label,frames[label],tables,mesh)
        checks.append({'phase':label,'Qy_N':shear,'T_Nmm':torque,'twist_rad_per_m':field[3]*1000./radius,
                       'kappaX_per_m':field[1]*1000./radius,'equilibrium':check,
                       'stock_and_OpenSees_same_force':comparison.get(shear)})
    assert all(a['Qy_N']<b['Qy_N'] for a,b in zip(checks,checks[1:]))
    finish = findall(r'CASE_FINISHED;MVTGaussMixed;(True|False);([^\n]+)',trace)
    if response['termination'] == 'completed':
        assert len(finish) == 1
        response['target_status'], response['macro_seconds'] = finish[0][0],float(finish[0][1])
    else:
        assert not finish
    return response | {'preloads':preloads,'mixed_fields':checks,'attempted_nominal_targets':targets}


def verify_original_targets(root):
    """Различает достигнутый момент и ошибочную проверку числа принятых полей."""
    rows = [raw.split(';') for raw in (root / 'MVTGaussMixed.csv').read_text('cp1251').splitlines()]
    trial = [(float(t),float(value),status,int(internal),int(code))
             for _, _, t, value, status, internal, code, *_ in
             (row for row in rows if row[0] == 'MVT2_ADAPT_TRIAL')]
    moments = tuple(t/1e6 for t in (*TORQUES[:6],TORQUES[-1]))
    assert trial == [(t,t,'True',4,0) for t in moments]
    records = [(int(row[2]),float(row[3])) for row in rows if row[0] == 'MVT2_ADAPT_HISTORY']
    assert records == list(enumerate(moments,1))
    text = (root / 'MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'История чистого кручения перед совместной пробой отличается.' in text
    assert 'WATCHDOG_COMPLETED: exit=1; source unchanged=True' in text
    closing = read(root / 'MVTGaussMixed.txt.ProcessClosure.json')
    assert closing['Passed'] and closing['ChildExitCode'] == 1 and closing['Closure']['FinalState']['State'] == 'Absent'
    return {'loads_kNm': list(moments), 'accepted_fields':len(records), 'stopped_in_test_field_count_check':True}


def verify_panels(repo, root, temporary, material, class_editor, method, spectral):
    """Проверяет изменённый закон на тех же панельных траекториях с мелким шагом."""
    archives = repo / 'docs/regression/Coupled6D'
    path = archives / PANELS
    assert digest(path.read_bytes()) == PANELS_SHA
    with ZipFile(path) as source:
        setup = source.read('Fine/tests/modTestMVT2GaussSpan.bas')
        original = source.read(f'Fine/{MATERIAL}')
        raw = source.read('Fine/Native/PanelWeights.csv')
    assert (root / 'tests/modTestMVT2GaussSpan.bas').read_bytes() == setup
    assert (root / MATERIAL).read_bytes() == class_editor(original, method)
    native_receipt = receipt(root,'Panels',material['BOOK'])
    coarse = archives / 'PanelJacobianColumnFirst20261117.zip'
    assert digest(coarse.read_bytes()) == 'C24E80C272560006B8E117CC7AF1855E40093B36A1388995478106DE40B69627'
    with ZipFile(coarse) as source:
        for name in ('Verify-MixedPanels.py','Digitize-PVShear.py','MeasuredPVShear.json','PublishedPanels.json'):
            (temporary / name).write_bytes(source.read(name))
    panels = run_path(str(temporary/'Verify-MixedPanels.py'))
    published,pixels = panels['load_sources'](repo,temporary)
    records = raw.decode('ascii').splitlines()
    original_peaks = {}
    for row in records:
        kind,name,weight,*values = row.split(';')
        if kind == 'STATE':
            key = f'{name}-{weight}'
            original_peaks[key] = max(original_peaks.get(key,0.),float(values[10]))

    def reconstruct(state, modulus, principal):
        """Сверяет пластический сдвиг, две части повреждения и знаковое равновесие."""
        e = tuple(a-b for a,b in zip(state[:6],state[16:22],strict=True))
        mu = modulus/2.4
        bulk_offset = modulus*.2/(1.2*.6)*sum(e[:3])
        trial = (*[2.*mu*x+bulk_offset for x in e[:3]],*[mu*x for x in e[3:]])
        spectrum = principal(trial)
        absolute = sum(map(abs,spectrum))
        r = sum(x for x in spectrum if x > 0.)/absolute if absolute else 0.
        negative, positive = spectral(trial,principal)
        dt, dc = state[-4:-2]
        expected = tuple((1.-dc)*m+(1.-dt)*p for m,p in zip(negative,positive,strict=True))
        return max(abs(a-b) for a,b in zip(state[6:12],expected,strict=True)),r

    panels['check_curve'].__globals__['reconstruct'] = reconstruct
    override = {'material_test_wire':lambda _: class_editor(original,method)}
    out = panels['verify_run'](repo,root,published['panels'],(published,pixels),material,None,override,False)
    assert out['termination'] == native_receipt['termination']
    assert set(out['cases']) <= set(original_peaks)
    for key, item in out['cases'].items():
        item['stock_shear_max_MPa'] = original_peaks[key]
    return out


def verify(repo, root, temporary):
    """Сопоставляет исходник поправки, точечные и равновесные прогоны."""
    earlier = run_path(str(root / 'Verify-MVT2StressAttribution.py'))
    change = run_path(str(root / 'Stage-SpectralDamage.py'))['change']
    archives = repo / 'docs/regression/Coupled6D'
    source_path = archives / earlier['REVERSE']
    material_path = archives / earlier['HELPER']
    assert digest(source_path.read_bytes()) == earlier['REVERSE_SHA']
    assert digest(material_path.read_bytes()) == earlier['HELPER_SHA']
    with ZipFile(material_path) as source:
        utility = {'__name__':'__pinned__'}
        exec(compile(source.read('Verify-NativeMaterialHistory.py'), str(material_path), 'exec'), utility)
        diagnostic = source.read(MATERIAL)
        addition = source.read('MaterialHistoryMethod.cls.txt').replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
        assert diagnostic.endswith(addition)
        original = diagnostic[:-len(addition)]
        assert digest(original) == utility['SOURCE_SHA']
    book = utility['BOOK']
    method = (root / 'SplitNominal.cls.txt').read_text(encoding='utf-8')
    path = archives / utility['REFERENCE']
    assert digest(path.read_bytes()) == utility['REFERENCE_SHA']
    with ZipFile(source_path) as source:
        for mode, material_before in (('Replay',source.read(MATERIAL)),('Equilibrium',original)):
            folder = root / mode
            assert read(folder / 'Preparation.json')['material_before_split_sha256'] == digest(material_before)
            assert (folder / MATERIAL).read_bytes() == change(material_before,method)
        (temporary / 'Verify-ReverseMaterial.py').write_bytes(source.read('Verify-ReverseMaterial.py'))
        partition = run_path(str(temporary/'Verify-ReverseMaterial.py'))['spectral_parts']
        replay = verify_replay(root/'Replay',source,utility,earlier,partition)
    panels = verify_panels(repo,root/'Panels',temporary,utility,change,method,partition)
    return {'material_replay': replay, 'computed_equilibrium':verify_equilibrium(repo,root/'Equilibrium',book,path),
            'panels':panels,
            'seven_preload_targets':verify_original_targets(root/'OriginalTargets'),
            'material_dissection':earlier['verify'](repo,temporary)}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    with TemporaryDirectory(dir=args.report.resolve().parent) as directory:
        result = verify(args.repo.resolve(),args.root.resolve(),Path(directory))
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(result,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('MVT2 SPECTRAL DAMAGE NATIVE OFFLINE PASS',result['material_replay']['material_states'],
          len(result['computed_equilibrium']['mixed_fields']),result['panels']['verified_states'])
