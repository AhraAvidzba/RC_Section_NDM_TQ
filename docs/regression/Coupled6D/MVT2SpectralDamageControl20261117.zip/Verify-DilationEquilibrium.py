"""Проверяет равновесные поля MVT2 при изменённом угле дилатансии."""

from argparse import ArgumentParser
from hashlib import sha256
from itertools import product
import json
from math import fsum
from pathlib import Path
from zipfile import ZipFile


REFERENCE = 'MVT2NativePublicationCutTimed20261117.zip'
REFERENCE_SHA = 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A'
FOLLOW = 'MVT2NativePublicationCutFollow20261117.zip'
FOLLOW_SHA = '9F55DE3FC0B1B652DD1ED9683507423ADE4DF6AB3B008D9590EE1D9327F9864E'
TEST = 'tests/modTestMVT2GaussSpan.bas'
TORSION = (262750., 525500., 1051000., 2102000., 4204000., 6831500., 8670750., 10510000.)
ARM = 396.


def digest(data):
    return sha256(data).hexdigest().upper()


def integrate_preload(field, stress, mesh, operators):
    """Пересчитывает шесть усилий чистого кручения с упругой сталью."""
    (ox, oy, _, _), points = mesh
    parts = []
    for point, (x, y, weight, *direction) in points.items():
        strain = tuple(fsum(value * operators['B'][point, j][k] for j, value in enumerate(field, 1)) for k in range(6))
        assert max(abs(a-b) for a,b in zip(strain, stress[point][:6], strict=True)) < 3e-16
        net = stress[point][6:]
        if point > 25:
            steel = 200000. * fsum(a*d for a,d in zip(strain, direction, strict=True))
            assert abs(steel) < (498. if point <= 29 else 450.)
            net = tuple(steel*d-s for s,d in zip(net, direction, strict=True))
        _, _, zz, _, xz, yz = net
        parts.append((weight*zz, weight*(y-oy)*zz, weight*(x-ox)*zz,
                      weight*((x-ox)*yz-(y-oy)*xz), weight*xz, weight*yz))
    return tuple(map(fsum, zip(*parts, strict=True)))


def verify(repo, root):
    evidence = repo / 'docs/regression/Coupled6D'
    follow = {'__name__': '__pinned__'}
    assert digest((evidence / FOLLOW).read_bytes()) == FOLLOW_SHA
    assert digest((evidence / REFERENCE).read_bytes()) == REFERENCE_SHA
    with ZipFile(evidence / FOLLOW) as archive:
        exec(compile(archive.read('Verify-NativeFollow.py'), FOLLOW, 'exec'), follow)
    utility, recovery, _, _, _, mesh = follow['read_references'](repo)
    with ZipFile(evidence / REFERENCE) as archive:
        baseline_proof = json.loads(archive.read('NativePublicationCutProof.json'))
        old_operators = utility['read_operators'](archive.read('Native/Operators.csv'))
        old_test = archive.read('modTestMVT2GaussSpan.bas').decode('utf-8-sig').replace('\r\n', '\n')
        old_driver = archive.read('Run-Native.ps1')

    prep = follow['read_json'](root / 'Preparation.json')
    assert prep['dilation_max_degrees'] == 26 and prep['source_book_sha256'] == recovery['BOOK_SHA']
    assert (root / 'Run-Native.ps1').read_bytes() == old_driver
    assert digest((root / TEST).read_bytes()) == prep['inputs'][TEST]
    text = (root / TEST).read_text(encoding='utf-8-sig')
    assert text.count(', dilation:=26#') == 4
    new_gate = 'If branch.SavedFieldCount <> 8 Or twist <= 0# Then _'
    old_gate = 'If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _'
    assert text.count(new_gate) == 1 and text.replace(', dilation:=26#', '').replace(new_gate, old_gate) == old_test

    native = root / 'Native'
    log = (native / 'MVTGaussMixed.txt').read_text('utf-8-sig')
    ending, pid, ticks = follow['owner_check'](root, log, recovery)
    trace = (native / 'MVTGaussMixed.csv').read_bytes()
    rows = [line.split(';') for line in trace.decode('cp1251').splitlines()]
    assert recovery['geometry'](rows) == mesh and 'MVT_PRELOAD_END;8;10.51' in trace.decode('cp1251')
    operators = utility['read_operators']((native / 'Operators.csv').read_bytes())
    frames = utility['read_tensor_frames']((native / 'MVTGaussMixed.Tensor.csv').read_bytes(), 45)
    assert all(operators[key] == old_operators[key] for key in 'GLBSR')
    assert list(operators['F']) == list(frames)
    torsion_labels = [f'R{i}' for i in range(1, 9)]
    assert list(frames)[:8] == torsion_labels
    assert [frames[label][:2] for label in torsion_labels] == [(t, 0.) for t in TORSION]
    _, _, area, length = mesh[0]
    preload = []
    for label in torsion_labels:
        target, _, stress = frames[label]
        field = operators['F'][label]
        signed = integrate_preload(field, stress, mesh, operators)
        expected = (0., 0., 0., target, 0., 0.)
        normal = max(abs(a-b) / (area*length if i in (1,2,3) else area)
                     for i,(a,b) in enumerate(zip(signed, expected, strict=True)))
        assert normal < 5e-6
        preload.append({'phase':label, 'T_Nmm':target, 'twist_rad_per_m':field[3]*1000./length,
                        'resultants_N_Nmm':signed, 'normalized_resultant_error_MPa':normal})

    targets, inserted = [], {}
    for row in rows:
        if row[0] == 'MVT2_CUT_TRIAL':
            _, phase, t, q, m, ok, internal, code, *details = row
            shear = float(q)
            assert float(t) == TORSION[-1] and float(m) == -ARM*shear
            work = follow['trial_work'](details, ok, internal, code)
            targets.append(work | {'phase':phase,'Qy_N':shear})
            if ok == 'True':
                inserted[phase] = shear
        elif row[0] == 'MVT2_CUT_INSERTED':
            inserted[row[1]+'A'+row[2]] = float(row[2])
    assert targets and [rec['Qy_N'] for rec in targets] == [2500.*i for i in range(1,len(targets)+1)]
    mixed = [name for name in frames if name not in torsion_labels]
    assert set(inserted) == set(mixed)
    assert set(operators['H']) == set(product(mixed, (-1,0,1), mesh[1]))
    checks, prior = [], 0.
    for label in mixed:
        t, q, _ = frames[label]
        assert t == TORSION[-1] and q == inserted[label] and q > prior
        prior = q
        field = operators['F'][label]
        checks.append({'phase':label, 'Qy_N':q, 'twist_rad_per_m':field[3]*1000./length,
                       'kappaX_per_m':field[1]*1000./length,
                       'equilibrium':recovery['equations'](label, frames[label], operators, mesh)})
    if ending == 'completed':
        finish, = [row for row in rows if row[0] == 'CASE_FINISHED']
        assert finish[2] in ('True', 'False') and 0. < float(finish[3]) < 165.
        seconds = float(finish[3])
    else:
        assert not any(row[0] == 'CASE_FINISHED' for row in rows)
        seconds = None

    baseline = {row['Qy_N']:row for row in baseline_proof['compared_same_six_force_states']}
    common = []
    for item in checks:
        if item['Qy_N'] in baseline:
            record = baseline[item['Qy_N']]
            common.append({key:record[key] for key in ('Qy_N','NDM_twist_rad_per_m','ASD_twist_rad_per_m',
                           'NDM_kappaX_per_m','ASD_kappaX_per_m')} |
                          {'NDM26_twist_rad_per_m':item['twist_rad_per_m'],'NDM26_kappaX_per_m':item['kappaX_per_m']})
    return {'preload':preload, 'preload_32deg_final_rad_per_m': old_operators['F']['R8'][3]*1000./length,
            'checks':checks, 'completed_force_targets':targets, 'common_states':common,
            'ending':ending, 'macro_seconds':seconds, 'excel_closed_pid':pid, 'excel_closed_ticks':ticks,
            'physical_limit_established':False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    result = verify(args.repo.resolve(), args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(result, output, indent=2, sort_keys=True, allow_nan=False)
        output.write('\n')
    print('MVT2 DILATION EQUILIBRIUM OFFLINE PASS', len(result['checks']))
