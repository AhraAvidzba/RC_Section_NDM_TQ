# Собирает тензоры и квитанции только после подтверждения выхода Excel.
param(
    [Parameter(Mandatory=$true)][string]$Source,
    [Parameter(Mandatory=$true)][string]$Destination,
    [Parameter(Mandatory=$true)][ValidateSet('Equilibrium','Replay')][string]$Mode
)

$ErrorActionPreference = 'Stop'
$native = Join-Path $Source 'Native'
$closure = Get-Content -LiteralPath "$native/MVTGaussMixed.txt.ProcessClosure.json" -Raw | ConvertFrom-Json
$closed = ($closure.Stage -eq 'AFTER_CHILD_EXIT' -and $closure.Closure.FinalState.State -ceq 'Absent')
if ($closure.Stage -eq 'TIMEOUT') {
    $closed = $closure.After.State -ceq 'Absent' -and $closure.ExactOwnExcelStopRequestedOnlyByExplicitTimeout
}
if (!$closed) { throw 'Завершение тестового процесса не подтверждено.' }

New-Item -ItemType Directory -Path "$Destination/Native","$Destination/tests","$Destination/src/Materials" | Out-Null
foreach ($file in @('Preparation.json','Run-Native.ps1','Guard-IsolatedOffice.ps1','Run.ndjson','Compile.log',
                    'CompileClosure.json','tests/modTestMVT2GaussSpan.bas','src/Materials/CCoupledConcreteResponse.cls')) {
    Copy-Item -LiteralPath "$Source/$file" -Destination "$Destination/$file"
}
Copy-Item -LiteralPath "$Source/docs/regression/CodeUpdate.json" -Destination "$Destination/CodeUpdate.json"
Get-ChildItem -File -LiteralPath $native | Copy-Item -Destination "$Destination/Native"

if ($Mode -eq 'Replay') {
    Copy-Item -LiteralPath "$Source/Replay.Fields.csv" -Destination "$Destination/Replay.Fields.csv"
    exit 0
}

if ($closure.Stage -eq 'TIMEOUT') {
    $entries = @(Get-Content -LiteralPath "$native/MVTGaussMixed.txt" -Encoding UTF8 | Where-Object { $_ -like 'FIXTURE: *' })
    if ($entries.Count -ne 1) { throw 'Нужен единственный путь частной книги.' }
    $folder = [IO.Path]::GetFullPath((Split-Path -Parent $entries[0].Substring('FIXTURE: '.Length)))
    $anchor = [IO.Path]::GetFullPath((Join-Path $Source 'Temp')) + '\'
    if (!$folder.StartsWith($anchor,[StringComparison]::OrdinalIgnoreCase)) { throw 'Путь вне частного каталога.' }
    $trace = Join-Path $folder 'MVT2GaussSpan.csv'
    Copy-Item -LiteralPath ($trace+'.Tensor.csv') -Destination "$Destination/Native/MVTGaussMixed.Tensor.csv"
    Copy-Item -LiteralPath ($trace+'.Operators.csv') -Destination "$Destination/Native/Operators.csv"
}
