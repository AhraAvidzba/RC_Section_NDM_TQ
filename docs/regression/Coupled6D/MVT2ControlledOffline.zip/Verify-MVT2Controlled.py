"""Сверяет силовую историю и принятие деформационных проб MVT2."""
import csv
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
BOUND = 30.0
TORQUE = 10510000.0
AREA = 240.0**2
LENGTH = math.hypot(110.0, 110.0)
REFERENCE_MODULUS = 30000.0
EXPECTED_HISTORY = (10.51, 15.0, 22.11622, 25.0)


def sha(path):
    """Возвращает контрольную сумму источника в виде записи журнала."""
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def close(a, b, absolute=1e-10):
    """Сверяет округлённую запись VBA с независимой формулой."""
    assert math.isclose(a, b, rel_tol=1e-9, abs_tol=absolute), (a, b)


def main():
    """Проверяет общую историю, допустимость полей и статус остановки."""
    native = HERE / "Native/MVT2.txt"
    trace = HERE / "Native/MVT2.csv"
    closure = json.loads((HERE / "Native/MVT2.txt.ProcessClosure.json").read_text(encoding="utf-8-sig"))
    text = native.read_text(encoding="utf-8-sig")
    baseline = json.loads((HERE / "ColdFollow.json").read_text(encoding="utf-8-sig"))
    prep = json.loads((HERE / "Preparation.json").read_text(encoding="utf-8-sig"))
    compile_closure = json.loads((HERE / "CompileClosure.json").read_text(encoding="utf-8-sig"))
    compiled = json.loads((HERE / "docs/regression/CodeUpdate.json").read_text(encoding="utf-8-sig"))
    assert compile_closure["State"] == "Absent"
    assert compiled["Modules"] == ["modTestCoupledExperiment"] and not compiled["ProductionChanged"]
    assert compiled["ProductionSHA256"] == prep["book_sha256"]
    timeout = closure["Stage"] == "TIMEOUT"
    assert (closure["After"]["State"] == "Absent" if timeout else
            closure["Passed"] and closure["Closure"]["FinalState"]["State"] == "Absent")
    assert "SOURCE_SHA256: " + compiled["WorkbookSHA256"] in text
    assert sha(HERE / "ColdFollow.json") == prep["source_report_sha256"]
    if not timeout:
        assert "TOTAL_COUPLED_WANG_MVT2_FOLLOW: passed=" in text and "failed=0" in text
        assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in text

    with trace.open(encoding="cp1251", newline="") as handle:
        rows: dict[str, list[list[str]]] = {}
        for record in csv.reader(handle, delimiter=";"):
            if record:
                tag, *values = record
                rows.setdefault(tag, []).append(values)
    native_history = rows["WANG_PAIR_STATUS"]
    prefix_matches = 0
    for row, last, target in zip(native_history, baseline["result"]["load_shell"], EXPECTED_HISTORY):
        assert row[4].lower() == "true" and row[5] == last["status"] == "OK" and float(row[3]) == target
        prefix_matches += 1
    assert timeout or prefix_matches == len(EXPECTED_HISTORY)
    assert rows["MVT2_GEOMETRY"][0][-3:] == ["25", "45", "60"]
    control = rows.get("MVT2_CONTROL_START", [])
    result = {
        "status": "VerifiedPartialTimeout" if timeout else "VerifiedDiagnostic",
        "book_sha256": prep["book_sha256"], "compiled_test_book_sha256": compiled["WorkbookSHA256"],
        "trace_sha256": sha(trace), "native_sha256": sha(native), "matched_prefix": prefix_matches,
        "native_last_load_control": native_history[-1][:10], "control_attempts": [], "controlled_accepts": [],
        "physical_capacity_claimed": False,
    }
    if control:
        source, = control
        old_lambda, current_lambda, current_coordinate, last_increment = map(float, source[:4])
        close(current_lambda, float(native_history[-1][3]), 1e-12)
        result["controlled_start_kN"] = current_lambda
        result["archived_start_kN"] = baseline["solver_termination"]["last_confirmed_Qy_kN"]
        result["control_name"] = source[4]
        packed = {label: list(map(float, values)) for label, *values in rows["MVT2_CONTROL_FIELD"]}
        prior, current, projection = (packed[key] for key in ("Prior", "Base", "Projection"))
        assert len(prior) == len(current) == len(projection) == 60
        def project(q):
            """Выбирает физические степени свободы, исключая реакции связей."""
            return math.fsum(c * v for c, v in zip(projection[:-4], q[:-4]))
        close(project(current), current_coordinate, 1e-14)
        close(project(current)-project(prior), last_increment, 1e-14)
        accepted = {int(key): data for key, *data in rows.get("MVT2_CONTROL_ACCEPT", [])}
        probes = rows.get("MVT2_CONTROL_PROBE", [])
        for i, probe in enumerate(probes, start=1):
            assert int(probe[0]) == i and i <= prep["max_control_attempts"]
            coordinate, increment, trial_lambda = map(float, probe[1:4])
            close(current_coordinate + increment, coordinate, 1e-15)
            assert increment > 0.0
            solved, forward = map(int, probe[4:6])
            ratio = increment / last_increment
            result["control_attempts"].append(
                {"attempt": i, "solved": bool(solved), "forward": bool(forward), "q_kN": trial_lambda,
                 "result_code": int(probe[6]), "details": ";".join(probe[7:])}
            )
            if i not in accepted:
                assert timeout or not (solved and forward)
                continue
            assert solved and forward
            data = list(map(float, accepted.pop(i)))
            lam, target, weak, gauge, wrench, condition, tolerance, steel = data[:8]
            forces = data[8:]
            assert len(forces) == 6
            close(lam, trial_lambda)
            close(target, coordinate, 1e-15)
            assert steel <= 1 and lam > 0.0
            assert abs(lam-current_lambda) <= 3*ratio*max(abs(current_lambda-old_lambda), .01)*(1+1e-8)
            predicted = current_lambda + ratio*(current_lambda-old_lambda)
            expected_tolerance = 5e-7 * (1+max(TORQUE/(AREA*LENGTH), 6e5*abs(predicted)/(AREA*LENGTH), abs(predicted)*1e3/AREA))
            close(tolerance, expected_tolerance, 1e-13)
            target_forces = (0.0, 6e5*lam, 0.0, TORQUE, 0.0, 1e3*lam)
            actual_wrench = max(abs(u-v)/AREA/(LENGTH if 0<i<4 else 1)
                                for i, (u,v) in enumerate(zip(forces,target_forces)))
            close(actual_wrench, wrench, 1e-11)
            candidate = packed[str(i)]
            close(abs(project(candidate)-coordinate)*REFERENCE_MODULUS, condition, 1e-10)
            assert max(weak, gauge, actual_wrench, condition) <= tolerance + 1e-10
            d = [c-p for c,p in zip(current[:-4],prior[:-4])]
            z = [n-c for n,c in zip(candidate[:-4],current[:-4])]
            dot = math.fsum(a*b for a,b in zip(d,z))
            assert dot > 0 and math.hypot(*z) <= 3*ratio*math.hypot(*d)*(1+1e-8)
            result["controlled_accepts"].append({
                "attempt": i, "q_kN": lam, "q_delta_kN": lam-current_lambda, "control": coordinate,
                "wrench_N_Nmm": forces, "normalized_wrench_gap_MPa": actual_wrench,
                "native_weak_gauges_control_MPa": [weak,gauge,condition], "tolerance_MPa": tolerance,
                "field_forward_cosine": dot/math.hypot(*d)/math.hypot(*z),
            })
            old_lambda,current_lambda = current_lambda,lam
            prior,current = current,candidate
            current_coordinate,last_increment = coordinate,increment
        assert not accepted
        result["last_controlled_lambda_kN"] = current_lambda
        if not timeout:
            stop, = rows["MVT2_CONTROL_STOP"]
            assert int(stop[0]) == len(result["controlled_accepts"]) <= prep["max_accepted"]
            close(float(stop[1]), current_lambda)
            assert int(stop[2]) == len(probes)
    (HERE / "Verification.json").write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n',encoding="utf-8")
    print(result["status"], prefix_matches, len(result["control_attempts"]), len(result["controlled_accepts"]))


if __name__ == "__main__":
    main()