"""Check exact Q5 replay and the retained signed Q10 material snapshot differences."""
import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isfinite
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
UPSTREAM = "BADC056B0CD7287D62441D19D9E242719485F6CBE92969B25C10C7AEF8329F8C"
SOURCE = "EE284CD98841403F76E6BD60655CF7AF37FEA1CE07840A2D657CF0F337B8150A"
NATIVE = "NonlinearDistributedDamageReplay.json"
FIELDS = {"damage":2,"equivalentTotalStrain":2,"strain":6,"stress":6,"time":3}
COMPONENTS = ("N","Mx","My","T","Qx","Qy")
SCALES = (1.,240.,240.,240.,1.,1.)
CUTS = (800.,860.,1340.,1400.)
T = 10510000.


def require(condition,label):
    if not condition:
        raise ValueError(label)


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def normalized(row,target):
    require(len(row)==6 and all(map(isfinite,row)),"finite six-component wrench")
    return max(abs(a-b)/k for a,b,k in zip(row,target,SCALES,strict=True))


def read_snapshot(snapshot, station_ids):
    require(len(snapshot["nodal_sha256_float64_le"])==64 and isfinite(snapshot["global_load_time"]),"node hash/load time")
    entries = snapshot["stations"]
    require([(row["element"],row["gauss"]) for row in entries]==station_ids,"frozen 50 ordered stations")
    for row in entries:
        require(set(row["response"])==set(FIELDS),"material response names")
        for name,n in FIELDS.items():
            require(len(row["response"][name])==n and all(map(isfinite,row["response"][name])),f"shape and finite {name}")
    return entries


def compare(a,b,expected,station_ids):
    old,new = read_snapshot(a,station_ids),read_snapshot(b,station_ids)
    exact_time = a["global_load_time"]==b["global_load_time"]
    exact_nodes = a["nodal_sha256_float64_le"]==b["nodal_sha256_float64_le"]
    require(exact_time==expected["load_time_exact"] and exact_nodes==expected["all_nodes_exact"],"node/time equality receipt")
    require((expected["max_nodal_delta_mm"]==0.)==exact_nodes,"zero displacement drift cross-check")
    by_field = {}
    for name,n in FIELDS.items():
        differences = []
        largest = 0.
        argmax = None
        for left,right in zip(old,new,strict=True):
            require(left["location"]==right["location"],"station location unchanged")
            a0,b0 = left["response"][name],right["response"][name]
            delta = [v-u for u,v in zip(a0,b0,strict=True)]
            if any(v!=0. for v in delta):
                differences.append({"element":left["element"],"gauss":left["gauss"],"signed_delta":delta,
                                    "before":a0,"after":b0})
            for var,(x,y,d) in enumerate(zip(a0,b0,delta,strict=True)):
                if abs(d)>largest:
                    largest=abs(d)
                    argmax={"element":left["element"],"gauss":left["gauss"],"component_zero_based":var,
                            "before":x,"after":y,"location":left["location"]}
        require(expected["material"][name]=={"changed_points":len(differences),"max_abs_delta":largest,"argmax":argmax},f"independent difference {name}")
        by_field[name] = {"max_abs_delta":largest,"argmax":argmax,"changed_stations":differences}
    return {"time_exact":exact_time,"nodal_bytes_exact":exact_nodes,"difference":by_field}


def returned_balance(readout):
    gauge = readout["gauge_reactions_N"]
    require(set(gauge)=={"1289","1297","1293","4065"},"four unchanged numerical gauges")
    gauge_max = max(abs(v) for row in gauge.values() for v in row)
    error = gauge_max
    cuts = readout["actual_cuts"]
    require(tuple(x["z_mm"] for x in cuts)==CUTS,"four physical cuts in returned state")
    for row in cuts:
        z = row["z_mm"]
        nominal = (0.,-min(z-500.,1700.-z)*5000.,0.,T,0.,-5000. if z<1100. else 5000.)
        defects = [normalized(face,nominal) for face in row["low_and_high_raw"]]
        require(defects==row["error_N_equivalent"],"independent force integration comparison")
        error = max(error,*defects)
    require(error==readout["peak_balance_error_N_equivalent"],"reported peak cut/gauge error")
    require((error<=.05)==readout["same_as_original_equilibrium_gate"],"original six-equation gate")
    return {"peak_error_N_equivalent":error,"original_equilibrium_gate_pass":error<=.05,"gauge_max_N":gauge_max}


def verify(upstream):
    require(digest(upstream)==UPSTREAM,"pinned held-T Q5 verification")
    require(digest(HERE/"MVT2DamageReplay.py")==SOURCE,"exact driver")
    receipt = json.loads((HERE/"DamageReplayReceipt.json").read_bytes())
    for file,checksum in receipt["native_sha256"].items():
        require(digest(HERE/file)==checksum,file)
    with ZipFile(upstream) as archive:
        old_native = archive.read("NonlinearDistributedShear15.json")
        require(sha256(archive.read("Verify-Pads.py")).hexdigest().upper()==digest(HERE/"Verify-Pads.py"),"trusted independent cut verifier")
    old = json.loads(old_native)
    output = json.loads((HERE/NATIVE).read_bytes())
    require(output["opensees_version"]==old["opensees_version"]=="3.8.0","runtime continuity")
    require(output["frozen_shear_native_sha256"]==sha256(old_native).hexdigest().upper(),"frozen Q5 path")
    require(output["replay_passed"] and output["accepted_torsion_replayed"]==7 and output["replay_states"]==old["replay_states"],"exact seven archived preload steps")
    require(output["base_replay_attempt"]=={"solver_code":0,"iterations":6,"observed_load_time":1./3.},"exact Q5 solver step")
    require(output["base_lambda"]==1./3. and output["probe_lambda"]==2./3. and output["physical_load_reference_P_N"]==30_000.,"same physical load reference")
    for name in ("E_MPa","nu","fc_MPa","ft_MPa","steel_yield_MPa","norm_unbalance_force","Newton_iteration_cap","validated_input_sha256"):
        require(output[name]==old[name],f"kept {name}")
    old_base = old["shear_confirmed_states"][0]
    for name,value in output["base_Q5_state"].items():
        require(value==old_base[name],f"zero drift for {name}")
    require(all(delta==0. for delta in output["base_Q5_replayed"].values()),"exact zero replays")
    spec = spec_from_file_location("equilibrium",HERE/"Verify-Pads.py")
    equilibrium = module_from_spec(spec)
    spec.loader.exec_module(equilibrium)
    base = equilibrium.verify_state(output["base_Q5_state"]["rig_balance"],T,10_000.)
    require(output["termination"]==receipt["raw_termination"] and output["physical_limit_established"] is False,"retained outcome")
    require((HERE/"NonlinearDistributedDamageReplay.stdout.log").read_text(encoding="utf-8").strip()==
            f"MVT2_DAMAGE_REPLAY {output['termination']} {NATIVE}","native child terminal")
    require(receipt["outer_closure"]=={"outer_tool_exit_code":0,"outer_tool_stdout":f"MVT2_DAMAGE_REPLAY_CLOSED code=0 result={NATIVE}"},"outer exit status")
    station_ids = [tuple(pair) for pair in output["material_station_ids"]]
    require(len(station_ids)==len(set(station_ids))==output["total_unique_material_stations"]==50,"unique station census")
    snaps = output["snapshots"]
    require(sum("prior_guard_plane_mm" in cell["location"] for cell in snaps["just_after_Q5_commit"]["stations"])==42,"42 original material stations")
    checks = {}
    steps = (("immediate_read_repeat","just_after_Q5_commit","immediate_read_repeat"),
             ("pretrial_readouts","just_after_Q5_commit","after_original_Q5_readouts"),
             ("attempt_effect","after_original_Q5_readouts","immediately_after_Q10_attempt"))
    for label,a,b in steps:
        checks[label] = compare(snaps[a],snaps[b],output["snapshot_differences"][label],station_ids)
    trial = output["sole_Q10_trial"]
    report = {"checks":"PASS","exact_Q5_base":base,"sole_Q10_trial":trial,"observed_snapshot_comparisons":checks,
              "termination":output["termination"],"outer_closure":receipt["outer_closure"],"physical_limit_established":False}
    if output["termination"]=="Q10_numeric_failure_material_trace_saved":
        require(trial["solver_code"]==-3 and trial["observed_load_time"]==1./3.,"Q10 rejected and time returned")
        checks["post_failure_readouts"] = compare(snaps["immediately_after_Q10_attempt"],snaps["after_post_failure_force_readout"],
                                                   output["snapshot_differences"]["post_failure_readouts"],station_ids)
        report["returned_Q5_balance"] = returned_balance(output["returned_Q5_balance_readout"])
    elif output["termination"]=="Q10_probe_accepted":
        require(trial["solver_code"]==0 and trial["observed_load_time"]==2./3.,"independent fresh Q10 acceptance")
        report["new_Q10_equilibrium"] = equilibrium.verify_state(output["unexpected_Q10_equilibrium"]["rig_balance"],T,20_000.)
    else:
        raise ValueError("Run did not retain the declared one-shot probe evidence")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("upstream",type=Path)
    parser.add_argument("--out",type=Path)
    opts = parser.parse_args()
    proof = verify(opts.upstream)
    if opts.out:
        opts.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True,allow_nan=False)+"\n").encode("utf-8"))
    print("MVT2_DAMAGE_REPLAY_DETACHED_PASS",proof["sole_Q10_trial"]["solver_code"],proof["termination"])


if __name__ == "__main__":
    main()
