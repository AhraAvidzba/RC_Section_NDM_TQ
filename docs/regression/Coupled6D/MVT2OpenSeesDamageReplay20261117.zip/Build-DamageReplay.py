"""Pack the one-shot damage rollback witness using deterministic ZIP metadata."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
MANIFEST = ("Build-DamageReplay.py","Damage-Replay-Proof.md","Damage-Replay.md","DamageReplayReceipt.json","MVT2DamageReplay.py",
            "NonlinearDistributedDamageReplay.json","NonlinearDistributedDamageReplay.stderr.log","NonlinearDistributedDamageReplay.stdout.log",
            "VerificationDamageReplay.json","Verify-DamageReplay.py","Verify-Pads.py")
OUT = HERE / "MVT2OpenSeesDamageReplay20261117.zip"


def add(archive,name,body):
    entry = ZipInfo(name,(2026,11,17,0,0,0))
    entry.create_system = 3
    entry.external_attr = 0o100644 << 16
    entry.compress_type = ZIP_STORED
    archive.writestr(entry,body)


def main():
    checksums = []
    with ZipFile(OUT,"w") as archive:
        for name in MANIFEST:
            payload = (HERE/name).read_bytes()
            checksums.append(f"{sha256(payload).hexdigest()}  {name}\n")
            add(archive,name,payload)
        add(archive,"SHA256SUMS","".join(checksums).encode("ascii"))
    print(sha256(OUT.read_bytes()).hexdigest().upper())


if __name__ == "__main__":
    main()
