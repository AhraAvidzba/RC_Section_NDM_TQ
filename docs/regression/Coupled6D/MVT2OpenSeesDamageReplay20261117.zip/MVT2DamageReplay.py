"""Run a frozen cold Q5 replay and one Q10 attempt with paired ASD response snapshots."""
import argparse
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path
import struct
import subprocess
import sys
from time import monotonic
from types import SimpleNamespace


sys.dont_write_bytecode = True
import MVT2PadsShear as shear


HERE = Path(__file__).resolve().parent
BASE = HERE/"NonlinearDistributedShear15.json"
SOURCE_SHA = "08939C97186E56D68D28B705CACDF746CFD7DE7413E8FC200800BF61C96A6786"
RAW_SHA = "B05FACE57BB63645A5D5D01B034CB71A3B4EE40C9903FF5C930082C2CF47D5B9"
RESULT = HERE/"NonlinearDistributedDamageReplay.json"
ORIGINAL,RIG = shear.ORIGINAL,shear.RIG
FIELDS = {"damage":2,"equivalentTotalStrain":2,"strain":6,"stress":6,"time":3}


def inputs(opts):
    identity = tuple(sha256(path.read_bytes()).hexdigest().upper() for path in (HERE/"MVT2PadsShear.py",BASE))
    if identity!=(SOURCE_SHA,RAW_SHA):
        raise ValueError("Prior held-T Q5/Q10 path changed")
    opts.max_qy = 15
    geometry,meta,prior_torsion = shear.inputs(opts)
    initial = json.loads(BASE.read_bytes())
    recorded = initial["shear_confirmed_states"]
    first,failed = initial["attempts"][-2:]
    if (len(recorded)!=1 or initial["accepted_torsion_replayed"]!=7 or recorded[0]["Qy_kN"]!=5. or
            first["solver_code"]!=0 or first["iterations"]!=6 or failed["target_Qy_kN"]!=10. or
            failed["solver_code"]!=-3 or failed["rollback_sampled_damage_exact"] is not False):
        raise ValueError("Prior frozen controller trial is absent")
    meta.update(scope="fresh seven-step T replay and one accepted Q5 then exactly one Q10 trial",
                frozen_shear_native_sha256=RAW_SHA,frozen_shear_source_sha256=SOURCE_SHA,
                physical_load_reference_P_N=30000.,base_lambda=1./3.,probe_lambda=2./3.,
                material_response_widths=FIELDS,original_guard_station_count=42,archive_survey_max_stations=8,
                physical_limit_established=False)
    layer_size = geometry.raw.nx*geometry.raw.ny
    analytic_bricks = [[(layer*layer_size+index+1,) for index in range(layer_size)] for layer in range(geometry.raw.nz)]
    staged = controlled_stations(SimpleNamespace(z=geometry.raw.z,bricks=analytic_bricks),recorded[0])
    if any(not 1<=tag<=layer_size*geometry.raw.nz or not 1<=point<=8 for tag,point in staged):
        raise ValueError("Frozen archive selects nonexistent stations")
    meta["total_unique_material_stations"] = len(staged)
    meta["material_station_ids"] = [list(key) for key in staged]
    return geometry,meta,prior_torsion,recorded[0]


def controlled_stations(model,archive_row):
    original = {}
    additional = {}
    for section in (500.,800.,860.,1100.,1340.,1400.,1700.):
        k = max(0,model.z.index(section)-1)
        layer = model.bricks[k]
        for index in (0,len(layer)//2,-1):
            tag = layer[index][0]
            for gp in (1,8):
                original[(tag,gp)] = {"prior_guard_plane_mm":section,"element_z_mm":model.z[k:k+2]}
    for band,modes in archive_row["concrete_damage_by_station_band"].items():
        for kind,value in modes.items():
            key = (value["element"],value["point"])
            additional.setdefault(key,[]).append({"band":band,"mode":kind,"xyz_mm":value["xyz_mm"]})
    if len(original)!=42:
        raise ValueError("Original material rollback selection changed")
    return {key:{**original.get(key,{}),"archived_band_extrema":additional.get(key,[])}
            for key in sorted(original.keys() | additional.keys())}


def nodal_digest(values):
    return sha256(struct.pack(f"<{len(values)}d",*values)).hexdigest().upper()


def material_schedule_snapshot(model,locations):
    ops = model.ops
    nodal = tuple(value for tag in model.geometry.coords for value in ops.nodeDisp(tag))
    if len(nodal)!=3*len(model.coords) or not all(map(isfinite,nodal)):
        raise ValueError("Invalid full nodal snapshot")
    stations = []
    for (tag,gp),location in locations.items():
        response = {}
        for name,width in FIELDS.items():
            values = tuple(ops.eleResponse(tag,"material",gp,name))
            if len(values)!=width or not all(map(isfinite,values)):
                raise ValueError(("Invalid ASD station response",tag,gp,name,values))
            response[name] = values
        stations.append({"element":tag,"gauss":gp,"location":location,"response":response})
    return nodal,{"global_load_time":ops.getTime(),"nodal_sha256_float64_le":nodal_digest(nodal),"stations":stations}


def snapshot_difference(before,after):
    un,base = before
    vn,probe = after
    changes = {field:{"max_abs_delta":0.,"changed_points":0,"argmax":None} for field in FIELDS}
    for a,b in zip(base["stations"],probe["stations"],strict=True):
        if (a["element"],a["gauss"])!=(b["element"],b["gauss"]):
            raise ValueError("Station ordering drift")
        for field,d in changes.items():
            left,right = a["response"][field],b["response"][field]
            local = [abs(x-y) for x,y in zip(left,right,strict=True)]
            i = max(range(len(local)),key=local.__getitem__)
            d["changed_points"] += int(local[i]!=0.)
            if local[i]>d["max_abs_delta"]:
                d.update(max_abs_delta=local[i],argmax={"element":a["element"],"gauss":a["gauss"],"component_zero_based":i,
                         "before":left[i],"after":right[i],"location":a["location"]})
    return {"load_time_exact":base["global_load_time"]==probe["global_load_time"],"all_nodes_exact":un==vn,
            "max_nodal_delta_mm":max(abs(a-b) for a,b in zip(un,vn,strict=True)),"material":changes}


def post_failure_force_readout(model,t,p):
    ops = model.ops
    geometry = model.geometry
    ops.reactions()
    gauge = {tag:tuple(ops.nodeReaction(tag)) for tag in geometry.supports}
    error = max(abs(v) for pair in gauge.values() for v in pair)
    cuts = []
    for z in RIG.CUTS:
        i = geometry.z.index(z)
        lower,upper = model.utility.Prism.cut(model,i-1,True),model.utility.Prism.cut(model,i,False)
        exact = RIG.expected_section(z,t,p)
        defects = [RIG.error(row,exact) for row in (lower,upper)]
        error = max(error,*defects)
        cuts.append({"z_mm":z,"low_and_high_raw":[lower,upper],"error_N_equivalent":defects})
    return {"gauge_reactions_N":gauge,"actual_cuts":cuts,"peak_balance_error_N_equivalent":error,
            "same_as_original_equilibrium_gate":error<=RIG.MAX_BALANCE_ERROR}


def run(opts,geometry,report,prior_torsion,archive_row):
    sys.path.insert(0,str(RIG.UTILITY.parent))
    import validate_opensees_hardshear as utility

    ops = utility.ops
    adapter = ORIGINAL.MaterialCommands(ops,"default")
    deadline = monotonic()+opts.wall_seconds-15.
    model = shear.STARTUP.PadModel(geometry,SimpleNamespace(ops=adapter,Prism=utility.Prism))
    shear.set_load(ops,1,geometry.torque_unit,RIG.TORQUE)
    shear.configure_analysis(ops)
    report.update(termination="running",opensees_version=ops.version())
    shear.persist(RESULT,report)

    def follow():
        termination = shear.replay_torsion(model,prior_torsion,report,RESULT,deadline)
        if termination is not None:
            return termination
        ops.loadConst("-time",0.)
        shear.set_load(ops,2,geometry.vertical_unit,30_000.)
        before = ORIGINAL.rollback_sample(model)
        ops.integrator("LoadControl",1./3.-before[0])
        code = ops.analyze(1)
        report["base_replay_attempt"] = {"solver_code":code,"iterations":ops.testIter(),"observed_load_time":ops.getTime()}
        if (code,ops.testIter(),ops.getTime())!=(0,6,1./3.):
            return "Q5_replay_solver_mismatch"
        locations = controlled_stations(model,archive_row)
        if [list(key) for key in locations]!=report["material_station_ids"]:
            raise ValueError("Native Gauss station IDs differ from staged fixture")
        accepted = material_schedule_snapshot(model,locations)
        only_read = material_schedule_snapshot(model,locations)
        base_state = shear.assess_state(model,RIG.TORQUE,10_000.)
        shear.summarize(model,base_state,True)
        keys = {"rig_balance":shear.BALANCE_TOL,"displacement":shear.DISP_TOL,"concrete_damage_by_station_band":shear.MATERIAL_TOL,
                "steel_signed_extrema_by_band":shear.MATERIAL_TOL,"concrete_peak_stress_by_longitudinal_and_surface_band":shear.STRESS_TOL}
        report["base_Q5_replayed"] = {key:shear.torsion.replay_error(archive_row[key],json.loads(json.dumps(base_state[key])),tol,key)
                                     for key,tol in keys.items()}
        observed = material_schedule_snapshot(model,locations)
        report["snapshots"] = {"just_after_Q5_commit":accepted[1],"immediate_read_repeat":only_read[1],"after_original_Q5_readouts":observed[1]}
        report["snapshot_differences"] = {"immediate_read_repeat":snapshot_difference(accepted,only_read),
                                          "pretrial_readouts":snapshot_difference(accepted,observed)}
        report["base_Q5_state"] = base_state
        shear.persist(RESULT,report)
        if monotonic()>=deadline:
            return "bounded_budget_after_verified_Q5"
        prior = ORIGINAL.rollback_sample(model)
        ops.integrator("LoadControl",2./3.-prior[0])
        code = ops.analyze(1)
        report["sole_Q10_trial"] = {"solver_code":code,"iterations":ops.testIter(),"observed_load_time":ops.getTime()}
        after = material_schedule_snapshot(model,locations)
        report["snapshots"]["immediately_after_Q10_attempt"] = after[1]
        report["snapshot_differences"]["attempt_effect"] = snapshot_difference(observed,after)
        shear.persist(RESULT,report)
        if code==0:
            if ops.getTime()!=2./3.:
                return "Q10_committed_time_mismatch"
            report["unexpected_Q10_equilibrium"] = shear.assess_state(model,RIG.TORQUE,20_000.)
            return "Q10_probe_accepted"
        if code!=-3:
            return "Q10_other_numeric_failure"
        report["returned_Q5_balance_readout"] = post_failure_force_readout(model,RIG.TORQUE,10_000.)
        checked = material_schedule_snapshot(model,locations)
        report["snapshots"]["after_post_failure_force_readout"] = checked[1]
        report["snapshot_differences"]["post_failure_readouts"] = snapshot_difference(after,checked)
        return "Q10_numeric_failure_material_trace_saved"

    try:
        report["termination"] = follow()
    except Exception as exc:
        report.update(termination="verification_or_engine_exception",detail=str(exc))
        raise
    finally:
        shear.persist(RESULT,report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs",action="store_true")
    mode.add_argument("--start",action="store_true")
    mode.add_argument("--child",action="store_true",help=argparse.SUPPRESS)
    parser.add_argument("--wall-seconds",type=int,default=165)
    opts = parser.parse_args()
    if not 120<=opts.wall_seconds<=180:
        parser.error("Use 120–180 watchdog seconds.")
    geometry,report,prior_torsion,archive_row = inputs(opts)
    if opts.check_inputs:
        print("MVT2_DAMAGE_REPLAY_INPUTS_OK",json.dumps(report,allow_nan=False))
        return 0
    if RESULT.exists() or RESULT.with_suffix(".json.part").exists():
        raise FileExistsError(RESULT)
    if opts.child:
        run(opts,geometry,report,prior_torsion,archive_row)
        print("MVT2_DAMAGE_REPLAY",report["termination"],RESULT.name)
        return 0
    argv = [sys.executable,"-B","-X","utf8",str(Path(__file__).resolve()),"--child","--wall-seconds",str(opts.wall_seconds)]
    with RESULT.with_suffix(".stdout.log").open("xb") as stdout, RESULT.with_suffix(".stderr.log").open("xb") as stderr:
        try:
            code = subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=opts.wall_seconds).returncode
        except subprocess.TimeoutExpired:
            print(f"MVT2_DAMAGE_REPLAY_WATCHDOG {opts.wall_seconds}s; see {RESULT.name} if created")
            return 124
    print(f"MVT2_DAMAGE_REPLAY_CLOSED code={code} result={RESULT.name}")
    return code


if __name__ == "__main__":
    sys.exit(main())
