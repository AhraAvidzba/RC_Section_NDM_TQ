"""ДЛЯ ТЕСТОВ. Проверяет коррекцию полной матрицы по короткой отвергнутой направленной секущей."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Пробы модели не принимают материал и делят исходный бюджет 30 поправок с обычным Newton."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestNewtonLine.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    def TestOnce(old, new):
        """Подстановка допустима только в однозначном месте неизменного теста полного Newton."""
        nonlocal code
        assert code.count(old) == 1, old
        code = code.replace(old, new, 1)
    TestOnce('    Dim positiveSamples() As Double, negativeSamples() As Double, beforeMatrix() As Double',
             '''    Dim positiveSamples() As Double, negativeSamples() As Double, beforeMatrix() As Double
    Dim retryModel As Boolean, modelUpdated As Boolean, modelRetries As Long, modelUpdates As Long
    Dim priorModel() As Double, modelDirection() As Double, modelSlope() As Double, modelAlpha As Double''')
    TestOnce('        ReDim jacobian(1 To count, 1 To count): ReDim sizes(1 To count)',
             '''        If Not retryModel Then
        modelUpdated = False
        ReDim jacobian(1 To count, 1 To count): ReDim sizes(1 To count)''')
    TestOnce('        calls = calls + 1\n        beforeMatrix = residual',
             '        End If\n        calls = calls + 1\n        beforeMatrix = residual')
    TestOnce('            trialCoordinates, trialResiduals, trialFlags, trialAlphas, chosen',
             '''            trialCoordinates, trialResiduals, trialFlags, trialAlphas, chosen, _
            modelUpdated, priorModel, modelDirection, modelSlope, modelAlpha''')
    TestOnce('''        If chosen = 0 Then outcome = "NO_DESCENT_WITHIN_LINE_BUDGET": Exit For
        x = trialCoordinates(chosen): residual = trialResiduals(chosen)''', '''        If chosen = 0 Then
            If modelRetries >= 3 Or usedSteps >= maximumSteps Then outcome = "DIRECTION_MODEL_RETRY_LIMIT": Exit For
            Dim shortIndex As Long, candidateIndex As Long, squaredLength As Double, modelValue As Double, mismatch As Double
            shortIndex = 0
            For candidateIndex = 1 To trialAlphas.Count
                If trialFlags(candidateIndex) And CDbl(trialAlphas(candidateIndex)) <= 0.0001 Then shortIndex = candidateIndex: Exit For
            Next candidateIndex
            If shortIndex = 0 Then outcome = "NO_SHORT_MODEL_PROBE": Exit For
            priorModel = jacobian: modelDirection = correction
            plus = trialResiduals(shortIndex): modelAlpha = trialAlphas(shortIndex)
            ReDim modelSlope(1 To count)
            squaredLength = 0#
            For column = 1 To count: squaredLength = squaredLength + correction(column) * correction(column): Next column
            If squaredLength <= 0# Then outcome = "ZERO_MODEL_DIRECTION": Exit For
            For row = 1 To count
                modelSlope(row) = (plus(row) - residual(row)) / modelAlpha
                modelValue = 0#
                For column = 1 To count: modelValue = modelValue + priorModel(column, row) * correction(column): Next column
                mismatch = modelSlope(row) - modelValue
                For column = 1 To count
                    jacobian(column, row) = priorModel(column, row) + mismatch * correction(column) / squaredLength
                Next column
            Next row
            modelRetries = modelRetries + 1: modelUpdates = modelUpdates + 1
            modelUpdated = True: retryModel = True
            Print #report, "MODEL_UPDATE;" & CStr(probeCase) & ";" & CStr(iteration) & ";" & CStr(shortIndex) & ";" & TestOnsetNumber(modelAlpha)
        Else
            x = trialCoordinates(chosen): residual = trialResiduals(chosen)
            retryModel = False: modelRetries = 0
        End If''')
    TestOnce('    effort = Array(usedSteps, calls, maximumSteps, maximumCalls, TestNewtonMaximum(residual))',
             '    effort = Array(usedSteps, calls, maximumSteps, maximumCalls, TestNewtonMaximum(residual), modelUpdates)')
    TestOnce('        ByVal trialFlags As Collection, ByVal trialAlphas As Collection, ByVal chosen As Long)',
             '''        ByVal trialFlags As Collection, ByVal trialAlphas As Collection, ByVal chosen As Long, _
        ByVal modelUpdated As Boolean, ByRef priorModel() As Double, ByRef modelDirection() As Double, _
        ByRef modelSlope() As Double, ByVal modelAlpha As Double)''')
    TestOnce('magic = "NDMNEWTONTEST001"', 'magic = "NDMDIRECTTEST001"')
    TestOnce('    Dim trials As Long: trials = trialCoordinates.Count', '''    Dim modelFlag As Long: modelFlag = IIf(modelUpdated, 1, 0)
    Put #handle, , modelFlag
    If modelUpdated Then
        Put #handle, , modelAlpha
        TestWriteReverseBinaryVector handle, TestNewtonFlatten(priorModel)
        TestWriteReverseBinaryVector handle, modelDirection
        TestWriteReverseBinaryVector handle, modelSlope
    End If
    Dim trials As Long: trials = trialCoordinates.Count''')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'CompleteNewtonShortDirectionalMatrixModel',
        'short_probe': 'first already rejected evaluable alpha <= 1e-4',
        'matrix_update': 'J + ((v-J*d)*d_transpose)/(d_transpose*d), v=(F(x+alpha*d)-F(x))/alpha',
        'maximum_model_retries_per_point': 3, 'model_retries_share_thirty_correction_budget': True,
        'no_additional_material_signature_evaluations': True, 'model_acceptance_uses_full_actual_residual': True,
        'hardcoded_critical_point': False, 'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('COMPLETE NEWTON SHORT DIRECTIONAL MODEL WITH SHARED BUDGET READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
