"""ДЛЯ ТЕСТОВ. Отделяет силовое равновесие от заданной деформационной координаты на той же истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Фиксирует один исходный множитель всех шести усилий; дополнительное уравнение определяет только lambda."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestNewtonLine.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '    mArcLoadProjection = 0#: mConsistentControl = False'
    assert code.count(old) == 1
    code = code.replace(old, '    mArcLoadProjection = 1#: mConsistentControl = False', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    module = (root / name).read_text('utf-8-sig')
    original_body, = re.findall(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', module)
    code = original_body
    old = '    Dim handle As Integer: handle = FreeFile\n    Open mHardPreparedPathTest & ".csv" For Output As #handle'
    assert code.count(old) == 1
    new = '''    Dim forceInputHandle As Integer: forceInputHandle = FreeFile
    Open mPolishRootTest & "\\Input\\NearSeed.bin" For Binary Access Read As #forceInputHandle
    Dim forceInput As Variant: forceInput = TestReadPolishVector(forceInputHandle)
    Close #forceInputHandle
    Dim targetFactor As Double: targetFactor = forceInput(61)
    ReDim projection(1 To operators.DegreeCount): target = targetFactor
''' + old
    code = code.replace(old, new, 1)
    old = '        Print #handle, "SEED;" & CStr(probeCase)'
    assert code.count(old) == 1
    code = code.replace(old, '        seedFactor = targetFactor\n' + old, 1)
    old = '    Print #handle, "CONTROL;" & TestOnsetNumber(target) & TestHardPreparedVector(projection)'
    assert code.count(old) == 1
    code = code.replace(old, old + '\n    Print #handle, "CONTROL_ARC;1;FixedLoadFactor;NoPrescribedFieldCoordinate"', 1)
    module = module.replace(original_body, code, 1)
    assert max(map(len, module.splitlines())) < 1024
    (root / name).write_bytes(module.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'CompleteNewtonFixedForceCompanion', 'force_control': True,
        'control_equation': 'E*(lambda-targetFactor)=0; field projection exactly zero',
        'target_factor_source': 'exact Double in Input/NearSeed.bin, last entry',
        'load_path_and_all_six_components_unchanged': True, 'accepted_prefix_binary_exact': True,
        'strict_global_equilibrium_still_requires_all_original_force_and_gauge_equations': True,
        'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('COMPLETE NEWTON FIXED FORCE COMPANION READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
