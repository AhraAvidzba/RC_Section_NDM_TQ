"""ДЛЯ ТЕСТОВ. Проверяет непрерывность локального закона в выявленной точке переключения CDP."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Используются две точные терминальные базы и их принятая история; точка25 является входом конкретного теста."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestNewtonBranches.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Materials/CCoupledConcreteResponse.cls'
    code = (root / name).read_text('utf-8-sig') + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает локальные напряжения и параметры возвращённой истории без записи материала; используется только для аудита непрерывности.
Friend Function ReadYieldContinuityPointTest(ByVal point As Long, ByRef strain() As Double) As Variant
    If Not mASDFlow Is Nothing Then Err.Raise 5, , "Аудит поверхности CDP неприменим к спектральному материалу."
    Dim updated As TConcreteHistory, stress(1 To 6) As Double, virginElastic As Boolean, substeps As Long
    If Not UpdateWithSubsteps(strain, mHistory(point, mCommitted), updated, stress, virginElastic, substeps) Then _
        Err.Raise 5, , "Локальный возврат не выполнен в аудите непрерывности."
    Dim values(1 To 41) As Double, component As Long
    For component = 1 To 6
        values(component) = strain(component): values(component + 6) = stress(component)
        values(component + 12) = updated.Plastic(component): values(component + 18) = mHistory(point, mCommitted).Plastic(component)
    Next component
    values(25) = updated.Tension: values(26) = updated.Compression
    values(27) = updated.TensionCohesion: values(28) = updated.CompressionCohesion
    values(29) = updated.TensionDamage: values(30) = updated.CompressionDamage
    values(31) = mHistory(point, mCommitted).Tension: values(32) = mHistory(point, mCommitted).Compression
    values(33) = mHistory(point, mCommitted).TensionCohesion: values(34) = mHistory(point, mCommitted).CompressionCohesion
    values(35) = mHistory(point, mCommitted).TensionDamage: values(36) = mHistory(point, mCommitted).CompressionDamage
    values(37) = updated.TensionEnergy: values(38) = updated.CompressionEnergy
    values(39) = mHistory(point, mCommitted).TensionEnergy: values(40) = mHistory(point, mCommitted).CompressionEnergy
    values(41) = substeps
    ReadYieldContinuityPointTest = values
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    assert 'CCoupledConcreteResponse' in prep['modules']
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestNativeYieldContinuity.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', lambda _: body, code)
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeYieldContinuity.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'LocalYieldContinuity', 'new_global_Newton_search_executed': False,
        'point': 25, 'station_z_over_L': .001, 'local_yield_event_root_bisections': 80,
        'two_sided_yield_perturbation_MPa': '1e-3 through 1e-13 along the exact failed Newton direction',
        'accepted_material_unchanged_after_local_reads_verified_by_exact_full_residual': True,
        'working_material_law_and_tolerances_unchanged': True, 'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('LOCAL CDP YIELD CONTINUITY AUDIT READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
