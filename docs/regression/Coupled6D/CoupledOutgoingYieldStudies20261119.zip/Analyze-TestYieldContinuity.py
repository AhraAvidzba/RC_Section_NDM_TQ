"""ДЛЯ ТЕСТОВ. Проверяет локальные двухсторонние напряжения и независимо восстанавливает упругую сторону CDP."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
import numpy as np


def TestAnalyze(root, output):
    """Измеренные пределы дискретных проб не выдаются за доказанную непрерывность на всех состояниях материала."""
    rows = list(csv.reader((root / 'Native/YieldContinuity.csv').read_text('cp1251').splitlines(), delimiter=';'))
    events = {int(row[1]): row for row in rows if row[0] == 'EVENT'}
    assert set(events) == {0, 1}
    modulus, poisson = 30000., .2
    elastic = np.zeros((6, 6))
    factor = modulus / ((1. + poisson) * (1. - 2. * poisson))
    elastic[:3, :3] = factor * poisson
    np.fill_diagonal(elastic[:3, :3], factor * (1. - poisson))
    elastic[3:, 3:] = np.eye(3) * modulus / (2. * (1. + poisson))
    result = {}
    for case, event in events.items():
        samples = {}
        for row in rows:
            if row[:2] != ['SAMPLE', str(case)]:
                continue
            power, sign, eta, trial_yield = int(row[2]), int(row[3]), float(row[4]), float(row[5])
            values = np.asarray([float(value) for value in row[9:]])
            assert values.shape == (41,) and np.all(np.isfinite(values))
            strain, stress, plastic, prior_plastic = (values[a:a+6] for a in (0, 6, 12, 18))
            effective = elastic @ (strain - prior_plastic)
            tensor = np.asarray(((effective[0], effective[3], effective[4]),
                                 (effective[3], effective[1], effective[5]),
                                 (effective[4], effective[5], effective[2])))
            spectrum = np.linalg.eigvalsh(tensor)
            fraction = np.sum(np.maximum(spectrum, 0)) / np.sum(np.abs(spectrum))
            apparent = (1. - fraction * values[34]) * (1. - values[35]) * effective
            deviation = float(np.max(np.abs(stress - apparent)))
            if row[6] == 'False':
                np.testing.assert_array_equal(plastic, prior_plastic)
                np.testing.assert_allclose(stress, apparent, rtol=1e-12, atol=1e-12)
            assert values[40] == int(row[8])
            samples[(power, sign)] = {'eta': eta, 'trial_yield_MPa': trial_yield,
                'plastic_increment': row[6] == 'True', 'principal_sign': int(row[7]), 'substeps': int(row[8]),
                'stress_MPa': stress.tolist(), 'deviation_from_committed_elastic_stress_MPa': deviation,
                'updated_tension': float(values[24]), 'updated_compression': float(values[25]),
                'prior_tension': float(values[30]), 'prior_compression': float(values[31]),
                'updated_tension_cohesion_MPa': float(values[26]), 'prior_tension_cohesion_MPa': float(values[32]),
                'updated_compression_cohesion_MPa': float(values[27]), 'prior_compression_cohesion_MPa': float(values[33])}
        assert set(samples) == {(power, sign) for power in range(3, 14) for sign in (-1, 1)}
        pairs = []
        for power in range(3, 14):
            minus, plus = samples[(power, -1)], samples[(power, 1)]
            gap = float(np.max(np.abs(np.asarray(plus['stress_MPa']) - minus['stress_MPa'])))
            pairs.append({'requested_yield_magnitude_MPa': 10. ** (-power), 'power': power,
                'stress_gap_max_MPa': gap, 'minus': minus, 'plus': plus})
        result[str(case)] = {'event_eta': float(event[2]), 'event_trial_yield_MPa': float(event[3]),
            'event_eta_bracket': [float(event[4]), float(event[5])], 'initial_yield_directional_derivative_MPa': float(event[6]),
            'pairs': pairs, 'smallest_sample_stress_gap_MPa': pairs[-1]['stress_gap_max_MPa'],
            'smallest_sample_plastic_deviation_MPa': max(pairs[-1][side]['deviation_from_committed_elastic_stress_MPa'] for side in ('minus', 'plus'))}
        print('CASE', case, 'EVENT Q', event[3], 'GAP AT 1e-13', pairs[-1]['stress_gap_max_MPa'],
              'PLASTIC DEVIATION', result[str(case)]['smallest_sample_plastic_deviation_MPa'])
    output.write_text(json.dumps({'cases': result, 'negative_elastic_stress_independently_reconstructed': True,
        'accepted_full_residual_binary_exact_before_and_after_native_reads': True,
        'local_material_tolerances_unchanged': True, 'physical_capacity_certified': False,
        'global_root_existence_proved': False, 'working_runtime_changed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('LOCAL CDP YIELD CONTINUITY SAMPLES AND ELASTIC STRESS VERIFIED; GLOBAL ROOT OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
