"""Сверяет точный снимок NDMSNP06 и сохранённый нативный НДМ HardShear."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path, PureWindowsPath
import re
from struct import calcsize, unpack
from xml.etree import ElementTree as ET
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
WORKBOOK_SHA = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'
EXCEL_CONTROL = 'HardShearCoarseGrowthWorkbookRelease20261117.zip'
EXCEL_CONTROL_SHA = '6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63'


def digest(data):
    """Возвращает SHA-256 в формате снимка."""
    return sha256(data).hexdigest().upper()


class MatrixReader:
    """Читает сохранённый столбцовый формат в ограниченных границах блока."""

    def __init__(self, raw):
        self.raw = raw
        self.index = 0

    def take(self, size):
        """Возвращает точное число байтов и сдвигает позицию."""
        start = self.index
        self.index += size
        assert size >= 0 and self.index <= len(self.raw)
        return self.raw[start:self.index]

    def numbers(self, format):
        """Читает числа little-endian."""
        return unpack('<' + format, self.take(calcsize('<' + format)))

    def scalar(self, kind):
        """Декодирует пустое, UTF-16, Double или Boolean без Excel."""
        if kind == 0:
            return None
        if kind == 1:
            size, = self.numbers('i')
            assert 0 <= size <= 131072 and size % 2 == 0
            return self.take(size).decode('utf-16-le')
        assert kind in (2, 3)
        value, = self.numbers('d')
        return bool(value) if kind == 3 else value

    def column(self, rows):
        """Декодирует независимые значения, серии или колонки со словарём."""
        mask, = self.numbers('B')
        if mask == 5:
            return [self.scalar(self.numbers('B')[0]) for _ in range(rows)]
        if mask == 4:
            count, = self.numbers('i')
            assert 1 <= count <= rows
            result = []
            for _ in range(count):
                length, kind = self.numbers('iB')
                assert 1 <= length <= rows - len(result)
                result.extend([self.scalar(kind)] * length)
            assert len(result) == rows
            return result
        assert 0 <= mask <= 3
        flags = self.take(rows)
        numbers = self.numbers(f'{rows}d') if mask & 1 else ()
        codes = self.numbers(f'{rows}i') if mask & 2 else ()
        strings = []
        if codes:
            count, = self.numbers('i')
            assert 1 <= count <= rows
            strings = [self.scalar(1) for _ in range(count)]
        content = []
        for i, flag in enumerate(flags):
            assert 0 <= flag <= 3
            if flag == 1:
                assert 1 <= codes[i] <= len(strings)
                content.append(strings[codes[i] - 1])
            else:
                content.append(None if flag == 0 else (numbers[i] if flag == 2 else bool(numbers[i])))
        return content

    def matrix(self, expected_columns):
        """Собирает матрицу из колонок и проверяет, что блок исчерпан."""
        rows, columns = self.numbers('ii')
        assert 1 <= rows <= 1000000 and columns == expected_columns
        contents = zip(*(self.column(rows) for _ in range(columns)), strict=True)
        result = list(contents)
        assert self.index == len(self.raw)
        return result


def inspect_snapshot(raw):
    """Проверяет заголовок, каталог, размер и SHA всех индексированных блоков."""
    magic, version, run, elapsed, tables = unpack('<8siddi', raw[:32])
    assert magic == b'NDMSNP06' and version == 6 and 1 <= tables <= 64
    assert digest(raw[:32]).encode('ascii') == raw[32:96]
    offset, size, footer_run, hash_bytes, footer = unpack('<iid64s8s', raw[-88:])
    assert footer == b'NDMIDX06' and run == footer_run and offset >= 96 and size >= 8
    assert offset + size == len(raw) - 88
    directory = raw[offset:offset + size]
    assert digest(directory).encode('ascii') == hash_bytes
    position = 96
    entries = MatrixReader(directory).matrix(17)
    found = {}
    for key, kind, start, length, checksum, rows, columns, _, entry_run, *_ in entries:
        start, length = int(start), int(length)
        assert start == position and 0 < length <= offset - position and entry_run == run
        assert 1 <= rows and 1 <= columns <= 256
        block = raw[start:start + length]
        assert digest(block) == checksum
        if kind in ('Table', 'ElementHeader', 'ElementIDs'):
            assert key not in found
            found[key] = len(MatrixReader(block).matrix(int(columns)))
            assert found[key] == rows
        else:
            assert kind == 'State' and columns == 9 and key == 'rngNDMElementResults'
        if key == 'LoadCase.Properties':
            properties = MatrixReader(block).matrix(6)
        position += length
    assert position == offset and len(found) == tables + 1
    assert 'Snapshot.Kind' not in found and entries and 'LoadCase.Properties' in found
    selected = [row for row in properties[1:] if row[1] == 'HardShear']
    assert all(row[0] == run for row in selected)
    values = {row[2]: row[3] for row in selected}
    assert len(values) == len(selected)
    return hash_bytes.decode('ascii'), values, {'table_count': tables, 'blocks_hashed': len(entries),
                                                'run_id': run, 'elapsed_header': elapsed}


def verify_native(proof, directory_hash):
    """Сверяет журналы Excel и индекс, записанный в свойства сохранённой книги."""
    text = (proof / 'Both-File.txt').read_text(encoding='utf-8-sig')
    assert f'SOURCE_SHA256: {WORKBOOK_SHA}' in text
    assert 'TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0' in text
    assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10290889219566; limit=; code=NUMERICAL_FAILURE' in text
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    assert 'OK: native capacity series matches accepted trace' in text
    before, after, saved = re.findall(r'^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=([0-9A-F]{64}); equal=True; file=(.+)$', text, re.M)[0]
    assert before == after and PureWindowsPath(saved).name == 'RC_Section_NDM_saved.xlsm'
    closure = json.loads((proof / 'Both-File.txt.ProcessClosure.json').read_text(encoding='utf-8-sig'))
    assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['RunnerCleanupValid']
    assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
    properties = ET.fromstring((proof / 'SavedCustomProperties.xml').read_bytes())
    link = {entry.attrib['name']: entry[0].text for entry in properties}
    assert link['NDM.CalculationSnapshot.File'] == 'HardShearWorkbook.ndm'
    assert link['NDM.CalculationSnapshot.Hash'] == 'IDX6:' + directory_hash
    fixture, = re.findall(r'^FIXTURE: (.+)$', text, re.M)
    assert PureWindowsPath(link['NDM.CalculationSnapshot.Folder']) == PureWindowsPath(fixture).parent
    seconds, = re.findall(r'^TIMING_SECONDS: ([\d.,]+) \| Both \| File$', text, re.M)
    return {'results_signature': before, 'timing_seconds': float(seconds.replace(',', '.'))}


def main(repo, proof):
    """Сравнивает оба носителя на штатной истории HardShear и на фактическом НДС."""
    payload = (proof / 'HardShearWorkbook.ndm').read_bytes()
    directory_hash, values, stats = inspect_snapshot(payload)
    native = verify_native(proof, directory_hash)
    control = repo / 'docs/regression/Coupled6D' / EXCEL_CONTROL
    assert digest(control.read_bytes()) == EXCEL_CONTROL_SHA
    with ZipFile(control) as packet:
        baseline = json.loads(packet.read('PackagedNativeVerification.json'))
    expected = {row[3]: row[5] for row in baseline['curve']['entries']}
    trace = {k: v for k, v in values.items() if k.startswith('Coupled.Trace.Capacity.')}
    assert len(trace) == len(expected) == 136 and set(trace) == set(expected)
    # Округление происходит только в числовом тексте XML другого носителя.
    error = max(abs(float(v) - float(expected[k])) for k, v in trace.items())
    assert error < 3e-14
    for index, factor in enumerate((.25, .5, .75, 1.), 1):
        assert values[f'Coupled.Trace.Direct.{index}.Lambda'] == factor
        assert values[f'Coupled.Trace.Direct.{index}.Offset'] == 1.
    assert sum(k.startswith('Coupled.Trace.Direct.') for k in values) == 8
    force = []
    components = ('N', 'Mx', 'My', 'T', 'Qx', 'Qy')
    for component, scaled in zip(components, (9806.65, 9806650., 9806650., 9806650., 9806.65, 9806.65), strict=True):
        assert values.get(f'Coupled.Capacity.{component}Ultimate') in ('', None)
        force.append(values[f'Coupled.Internal.{component}'] * scaled)
    target = (28000., 510000., 180000., 1500000., 17000., -7100.)
    assert all(abs(a - b) <= 2e-12 * abs(b) for a, b in zip(force, target, strict=True))
    assert values['DirectStateStatus'] == 'OK' and values['CapacityStatus'] == 'NumFail'
    assert values['Coupled.Capacity.ResultCode'] == 'NUMERICAL_FAILURE'
    assert abs(float(values['Coupled.Capacity.LowerLambda']) - 1.10290889219566) < 3e-14
    return {'workbook_sha256': WORKBOOK_SHA, 'snapshot_sha256': digest(payload), 'directory_sha256': directory_hash,
            **stats, **native, 'capacity_accepted_points': len(trace) // 2, 'direct_accepted_points': 4,
            'trace_max_abs_error': error, 'direct_N_Nmm': force,
            'direct': values['DirectStateStatus'], 'capacity': values['CapacityStatus'],
            'lower_lambda': values['Coupled.Capacity.LowerLambda'], 'physical_limit_established': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--report', type=Path, required=True)
    arguments = parser.parse_args()
    result = main(arguments.repo.resolve(), HERE)
    with arguments.report.open('x', encoding='utf-8', newline='\n') as out:
        json.dump(result, out, indent=2, sort_keys=True, allow_nan=False)
        out.write('\n')
    print('HARDSHEAR INSTALLED FILE SNAPSHOT OFFLINE PASS')
