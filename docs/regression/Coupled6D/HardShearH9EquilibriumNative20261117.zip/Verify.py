"""Проверяет знаковую скобку пластического перехода по реальным равновесиям HardShear."""

import argparse
from hashlib import file_digest
import json
from math import fsum, isclose, isfinite, ulp
from pathlib import Path
import re
from struct import unpack


HERE = Path(__file__).resolve().parent
STEPS = (-25e-12, 1.5e-12, 5e-12, 8e-12, 25e-12, 80e-12)
DIRECTION = (28000., 510000., 180000., 1500000., 17000., -7100.)
FORCE_SCALES = (21600., 2219577.365175632, 2219577.365175632, 2219577.365175632, 21600., 21600.)
STATION = (22, -1)


def file_sha(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest().upper()


def read(name):
    return json.loads((HERE / name).read_text(encoding="utf-8-sig"))


def number(raw):
    value, = unpack(">d", bytes.fromhex(raw))
    assert isfinite(value)
    return value


def numbers(tokens):
    return list(map(number, tokens))


def dot(a, b):
    return fsum(x*y for x, y in zip(a, b, strict=True))


def relative(a, b, abs_tol=0.):
    return isclose(a, b, rel_tol=1e-10, abs_tol=abs_tol)


def solve(matrix, right):
    """Независимое исключение с частичным выбором ведущего элемента по шкале строки."""
    data = [row[:] + [rhs] for row, rhs in zip(matrix, right, strict=True)]
    n = len(data)
    weights = [max(map(abs, row[:n])) for row in data]
    assert min(weights) > 0.
    for column in range(n):
        i = max(range(column, n), key=lambda idx: abs(data[idx][column])/weights[idx])
        assert abs(data[i][column])/weights[i] > 1e-14
        data[column], data[i] = data[i], data[column]
        weights[column], weights[i] = weights[i], weights[column]
        row = data[column]
        for below in data[column+1:]:
            factor = below[column]/row[column]
            for j in range(column+1, n+1):
                below[j] -= factor*row[j]
    roots = [0.] * n
    for i in range(n-1, -1, -1):
        roots[i] = (data[i][-1] - fsum(data[i][j]*roots[j] for j in range(i+1, n)))/data[i][i]
    return roots


def discover(path):
    raw = path.read_text(encoding="cp1251").splitlines()
    assert raw[0] == "HARDSHEAR-YIELD-GATE;1"
    metadata, probes = {}, []
    active = None
    for line in raw[1:]:
        key, *values = line.split(";")
        if key == "BEGIN":
            assert active is None
            active = {"plan": numbers(values), "stations": {}, "matrix": []}
        elif key == "END":
            assert active["plan"][0] == number(values[0])
            probes.append(active)
            active = None
        elif key == "STATIONS":
            assert number(values[0]) == active["plan"][0] and values[1] == "43"
        elif key == "STATION":
            point, side, success, *state = values
            identity = int(point), int(side)
            assert identity not in active["stations"]
            active["stations"][identity] = ((number(state[0]), state[1] == "True", int(state[2]), int(state[3]))
                                             if success == "ok" else None)
        elif key == "K":
            assert len(values) == 61 and int(values[0]) == len(active["matrix"])+1
            active["matrix"].append(numbers(values[1:]))
        else:
            table = active if active is not None else metadata
            assert key not in table
            table[key] = values
    assert active is None and tuple(probe["plan"][0] for probe in probes) == STEPS
    return metadata, probes


def phase_uncertainty(probe, native, projection, modulus, norm, tau, factor):
    if not native:
        return None
    matrix = probe["matrix"]
    equations = numbers(probe["DIRECTION-EQ"])
    assert len(matrix) == 60 and equations[56:] == [0.] * 4
    bordered = [row + [-force] for row, force in zip(matrix, equations, strict=True)]
    bordered.append([modulus*p for p in projection] + [0.])
    for i in range(56, 60):
        bordered[i] = [modulus*x for x in bordered[i]]
    demand = [0.] * 60 + [1.]
    adjoint = solve(list(map(list, zip(*bordered, strict=True))), demand)
    propagated = fsum(map(abs, adjoint))*max(tau, norm) + 2e-12*(1.+abs(factor))
    assert isclose(propagated, native, rel_tol=2e-5, abs_tol=2e-13)
    derivative = solve(bordered, [0.] * 60 + [modulus])[-1]
    return max(propagated, native), derivative


def verify_samples(meta, probes, expected):
    assert meta["H8"] == meta["RESTORED"] == expected["prefix"][-1] and meta["H9"] == expected["peak"]
    assert meta["PROJECTION"] == expected["projection"]
    direction = numbers(meta["DIRECTION"])
    offset = numbers(meta["OFFSET"])
    assert tuple(direction) == DIRECTION and offset == [0.]*6
    equations = numbers(expected["load_equations"])
    p = numbers(meta["PROJECTION"])
    raw_a, raw_r, cap, raw_e, raw_stride = meta["SETTINGS"]
    a, r, modulus, stride = numbers((raw_a, raw_r, raw_e, raw_stride))
    assert (a, r, int(cap), modulus) == (5e-11, 5e-11, 8, 30000.)
    peak_c, peak_factor, source_slope = numbers(meta["ARCHIVE"])
    assert (peak_c, peak_factor, meta["ARCHIVE"][-1]) == (expected["peak_control"], expected["peak_lambda"], expected["secant"][-1])
    v = numbers(expected["secant"][:-1])
    size = max(map(abs, v[:56]))
    assert relative(stride, dot(p[:56], [item/size for item in v[:56]]), 8e-16)
    report = []
    for trial in probes:
        step, target, initial = trial["plan"]
        assert abs(target - (peak_c + stride*step)) <= 2*ulp(peak_c)
        assert abs(initial - (peak_factor + source_slope*step/size)) <= 2*ulp(peak_factor)
        ok, status, code, cycles, evaluations, detail = trial["SOLVER"]
        assert 0 <= int(cycles) <= int(cap) and int(evaluations) > 0
        result = {"h": step, "target_control": target, "solver_returned_candidate": ok == "True",
                  "solver_status": int(status), "solver_code": int(code), "iterations": int(cycles),
                  "evaluations": int(evaluations), "detail": detail}
        report.append(result)
        if ok == "False":
            assert "BALANCE" not in trial
            continue
        assert (ok, int(status), int(code)) == ("True", 4, 0)
        factor, norm, tau, steel, control = numbers(trial["BALANCE"][:-1])
        assert norm >= 0 and factor > 0
        assert relative(tau, a+r*max(abs(factor*x) for x in equations), 1e-19)
        field, target_force, actual, residual = (numbers(trial[key]) for key in ("FIELD", "TARGET", "ACTUAL", "RESIDUAL"))
        assert all(relative(x, y*factor, 1e-13) for x,y in zip(target_force, direction, strict=True))
        coordinate = dot(field[:56], p[:56])
        control_mpa = modulus*(coordinate - target)
        sum_bound = fsum(abs(x*y) for x,y in zip(field[:56], p[:56], strict=True))
        roundoff = 16.*ulp(max(abs(target), sum_bound))*modulus
        assert abs(control_mpa - control) <= roundoff
        force = max(abs(x-y)/s for x,y,s in zip(target_force, actual, FORCE_SCALES, strict=True))
        weak = max(map(abs, residual[:56]))
        gauges = modulus*max(map(abs, residual[56:]))
        closure = max(weak, gauges, force, abs(control_mpa))
        strict = trial["BALANCE"][-1] == "True"
        assert relative(norm, max(weak, force, abs(control)), roundoff)
        assert (closure <= tau+roundoff) or not strict
        assert len(trial["stations"]) == 129
        info = trial["stations"][STATION]
        label = "unavailable"
        if info and info[0] != 0. and info[1] == (info[0] > 0.):
            label = "plastic" if info[1] else "elastic"
        bounded, raw_bound = trial["BOUND"]
        propagated = phase_uncertainty(trial, number(raw_bound) if bounded == "True" else None, p, modulus, norm, tau, factor)
        result.update(original_equilibrium_certified=bool(strict and closure <= tau+roundoff and 0 <= steel <= 1),
                      factor=factor, actual_control=coordinate, abs_control_bound=(tau+roundoff)/modulus,
                      closure_mpa=closure, tau_mpa=tau, weak_mpa=weak, gauges_mpa=gauges, six_force_mpa=force,
                      steel_usage=steel, station=info, material_side=label,
                      factor_uncertainty=propagated[0] if propagated else None,
                      one_sided_tangent_dlambda_dc=propagated[1] if propagated else None)
    return report


def intervals(results, probes):
    eligible = [row for row in results if row.get("original_equilibrium_certified") and row["material_side"] in ("elastic", "plastic")]
    possible = [(left, right) for left in eligible for right in eligible
                if left["material_side"] == "elastic" and right["material_side"] == "plastic"
                and right["actual_control"]-left["actual_control"] > left["abs_control_bound"]+right["abs_control_bound"]]
    all_material = {row["h"]: probe["stations"] for row, probe in zip(results, probes, strict=True)}
    def material_changes(left, right):
        l, r = all_material[left["h"]], all_material[right["h"]]
        changes = [key for key in l if l[key] is None or r[key] is None or
                   (l[key][0]>0., *l[key][1:]) != (r[key][0]>0., *r[key][1:])]
        return changes
    possible = [(left, right) for left, right in possible if material_changes(left, right) == [STATION]]
    bracket = min(possible, key=lambda pair: pair[1]["actual_control"]-pair[0]["actual_control"]) if possible else None
    slopes = []
    if bracket:
        for side, row in zip(("elastic", "plastic"), bracket, strict=True):
            same = [other for other in eligible if other["material_side"] == side and other is not row
                    and (other["h"] < row["h"] if side == "elastic" else other["h"] > row["h"])
                    and not material_changes(other, row) and other["factor_uncertainty"] is not None]
            if row["factor_uncertainty"] is None:
                continue
            for other in same:
                low, high = sorted((row, other), key=lambda p: p["actual_control"])
                dc = high["actual_control"] - low["actual_control"]
                uc = high["abs_control_bound"] + low["abs_control_bound"]
                dl = high["factor"] - low["factor"]
                ul = high["factor_uncertainty"] + low["factor_uncertainty"]
                if dc <= uc:
                    continue
                combinations = [(dl+sign*ul)/(dc+step*uc) for sign in (-1,1) for step in (-1,1)]
                lo, hi = min(combinations), max(combinations)
                sign = "positive" if lo > 0. else ("negative" if hi < 0. else "unresolved")
                slopes.append({"side": side, "h_pair": [low["h"], high["h"]], "dlambda_dc_interval": [lo,hi], "sign": sign})
    localized = bool(bracket)
    left_signs = {row["sign"] for row in slopes if row["side"] == "elastic" and row["sign"] != "unresolved"}
    right_signs = {row["sign"] for row in slopes if row["side"] == "plastic" and row["sign"] != "unresolved"}
    positive, negative = left_signs == {"positive"}, right_signs == {"negative"}
    scope = ("same_history_equilibrium_bracket_and_signed_secants" if positive and negative else
             "same_history_equilibrium_bracket_slopes_open" if localized else
             "no_exclusive_equilibrium_bracket_report_only")
    return {"conclusion_scope": scope, "p22_minus1_equilibrium_bracket_found": localized,
            "chosen_h_pair": [row["h"] for row in bracket] if bracket else None,
            "same_side_secant_intervals": slopes, "physical_limit_certified": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", action="store_true")
    args = parser.parse_args()
    prep = read("Fixture.json")
    assert all(file_sha(HERE / name) == sha for name, sha in prep["inputs"].items())
    workbook = HERE / prep["workbook"]
    if workbook.is_file():
        assert file_sha(workbook) == prep["source_workbook_sha256"]
    if args.inputs:
        print("HARDSHEAR H9 INPUTS", file_sha(HERE / "Fixture.json"), "workbook-present=" + str(workbook.is_file()))
        return
    code, comp = read("docs/regression/CodeUpdate.json"), read("CompileClosure.json")
    assert code["Compiled"] and not code["ProductionChanged"] and code["ProductionSHA256"] == prep["source_workbook_sha256"]
    assert code["Modules"] == ["CCoupledDeformationContinuation", "CCoupledNewtonSolver", "modTestCoupledElasticState"]
    log = (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    assert comp["State"] == "Absent" and f"OWNED_EXCEL: id={comp['PID']}; utcStartTicks={comp['StartTicksUTC']}" in log
    owner, closure = read("Native/HardShear.txt.Ownership.json"), read("Native/HardShear.txt.ProcessClosure.json")
    assert owner["SourceSHA256"] == code["WorkbookSHA256"] and owner["VerifiedNewOwner"]
    final = closure["Closure"]["FinalState"]
    assert closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"] == 0 and final["State"] == "Absent"
    assert (owner["PID"], owner["StartTicksUTC"]) == (final["PID"], final["StartTicksUTC"])
    macros = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_YIELD_GATE: passed=1; failed=0" in macros
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in macros
    assert re.search(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=\1; equal=True;", macros, re.M)
    path = HERE / "Native/HardYieldGate.csv"
    metadata, probes = discover(path)
    points = verify_samples(metadata, probes, read("Expected.json"))
    report = {"archive_source_revision": prep["source_revision"], "workbook_sha256": prep["source_workbook_sha256"],
              "native_trace_sha256": file_sha(path), "stock_history_H8_restored": True, "samples": points,
              **intervals(points, probes)}
    out = HERE / "Native/Verification.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print("HARDSHEAR H9 NATIVE AUDITED", report["conclusion_scope"], file_sha(out))


if __name__ == "__main__":
    if not __debug__:
        raise SystemExit("Use Python without -O")
    main()
