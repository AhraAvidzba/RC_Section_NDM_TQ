"""Собирает архив проверки HardShear H9 из закрытых нативных результатов."""

from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
SOURCE = Path("D:/CodexScratch/RC_Section_NDM_TQ/HardH9Yield")
BOOK = "workbook/output/RC_Section_NDM.xlsm"


def main():
    spec = spec_from_file_location("pack", HERE.parent / "mvbridge-proof/Pack.py")
    pack = module_from_spec(spec)
    spec.loader.exec_module(pack)
    pack.HERE, pack.CURRENT = HERE, SOURCE
    pack.OUT = HERE / "HardShearH9EquilibriumNative20261117.zip"
    prep = json.loads((SOURCE / "Fixture.json").read_bytes())
    assert pack.digest(REPO / BOOK) == prep["source_workbook_sha256"] == pack.digest(SOURCE / BOOK)
    for archive, sha in prep["source_archives"].items():
        assert pack.digest(REPO / "docs/regression/Coupled6D" / archive) == sha, archive
    actual = {"Fixture.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json", *prep["inputs"]}
    actual.update(path.relative_to(SOURCE).as_posix() for path in (SOURCE / "Native").iterdir() if path.is_file())
    dry = HERE.parent / "hs-yield-eq/native-final"
    assert pack.digest(SOURCE / "Fixture.json") == pack.digest(dry / "Fixture.json")
    assert all(pack.digest(dry / name) == sha for name, sha in prep["inputs"].items())

    def inputs():
        for name in sorted(actual):
            yield SOURCE / name, name
        for name, expected in prep["production"].items():
            source = REPO / name
            assert pack.digest(source) == expected
            yield source, "ProductionSource/" + name
        yield HERE.parent / "hs-rank/Verify.py", "RankTools.py"
        for name in ("Verify-Portable.py", "Pack-H9.py", "README-Portable.md"):
            yield HERE / name, name

    pack.locate_files = inputs
    pack.main()


if __name__ == "__main__":
    main()
