"""Сверяет равновесные пробы HardShear, восстановление H8 и ранг в двух точках."""

import argparse
import json
from math import isclose
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
import Verify as native
from RankTools import dot, matvec, null_basis, singular


HERE = Path(__file__).resolve().parent
FIXTURE = "70819A9A9283757BDF9D3A90F10825EB95718C12A6FDFFD76B82FFF7670096BA"
BOOK = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
DIAGNOSTIC = "56BD23CC9C9D937166F009DD7CB848CF7125733312868FFD0084C1170567BE85"
TERMINAL = "D84FFD33C26BF9A6E4F66D931BC2FD38168DC996E6BA5DCD6DF7315944039FFA"
RAW = "8DC09214A2A0049BFFF7A74D5E8741BE1A09116630E7492B0FF748F34D388E86"


def verify_inputs(args):
    inventory = native.read("SHA256SUMS.json")
    actual = {item.relative_to(HERE).as_posix() for item in HERE.rglob("*") if item.is_file()
              and item.name != "SHA256SUMS.json" and "__pycache__" not in item.parts}
    assert actual == set(inventory)
    for name, expected in inventory.items():
        assert Path(name).suffix.lower() not in {".xlsm", ".xlsx", ".xls", ".ndm"}
        assert Path(name).name.lower() != "vba_all_code.txt"
        assert native.file_sha(HERE / name) == expected, name
    assert native.file_sha(HERE / "Fixture.json") == FIXTURE
    fixture = native.read("Fixture.json")
    assert all(native.file_sha(HERE / name) == sha for name, sha in fixture["inputs"].items())
    assert fixture["source_revision"] == "709e7dfa16c192748fc2c6d999925bdbf9948a4c"
    assert fixture["source_workbook_sha256"] == BOOK and fixture["native_hook_only_in_continuation"] is True
    if args.workbook:
        assert native.file_sha(args.workbook) == BOOK
    if args.diagnostic_workbook:
        assert native.file_sha(args.diagnostic_workbook) == DIAGNOSTIC
    if args.prior_archives:
        for name, sha in fixture["source_archives"].items():
            assert native.file_sha(args.prior_archives / name) == sha
    return fixture


def verify_sources(fixture):
    hook = """    If HardRankRequestedTest Then
        HardRankFinishedTest = ReplayHardYieldGateTest(mSolver, mOffset, mDirection)
        StopSearch "Диагностическая остановка после направленных проб H9."
        Exit Sub
    End If

"""
    for name, sha in fixture["production"].items():
        parent = HERE / "ProductionSource" / name
        assert native.file_sha(parent) == sha
        stock = parent.read_text(encoding="utf-8-sig").rstrip()
        isolated = (HERE / name).read_text(encoding="utf-8").rstrip()
        if name.endswith("CCoupledDeformationContinuation.cls"):
            assert isolated.count(hook) == 1 and isolated.replace(hook, "") == stock
        elif name.endswith("CCoupledNewtonSolver.cls"):
            assert isolated.startswith(stock + "\n\n")
            assert "Friend Function ProbeHardYieldEquilibriumTest" in isolated
        else:
            prefix = isolated.split("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Подготавливает штатный HardShear", 1)[0]
            imports = re.search(r"\n\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Изолированный нативный запуск .*?End Type\n\nPrivate Type THardRankWordsTest.*?^End Type",
                                prefix, re.M | re.S)[0]
            assert prefix.replace(imports, "").rstrip() == stock


def verify_closed(fixture):
    code = native.read("docs/regression/CodeUpdate.json")
    assert code["Compiled"] and not code["ProductionChanged"]
    assert code["ProductionSHA256"] == fixture["source_workbook_sha256"] == BOOK
    assert code["WorkbookSHA256"] == DIAGNOSTIC and not code["EntryPointNames"] and not code["RetiredModules"]
    assert code["Modules"] == ["CCoupledDeformationContinuation", "CCoupledNewtonSolver", "modTestCoupledElasticState"]
    comp = native.read("CompileClosure.json")
    rows = (HERE / "Compile.log").read_text(encoding="utf-8-sig").splitlines()
    assert rows == [f"OWNED_EXCEL: id={comp['PID']}; utcStartTicks={comp['StartTicksUTC']}",
                    "PRIVATE_CODE_READY: modules=3; production unchanged=True"]
    assert comp["State"] == "Absent"
    owner = native.read("Native/HardShear.txt.Ownership.json")
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == DIAGNOSTIC
    close = native.read("Native/HardShear.txt.ProcessClosure.json")
    clean = native.read("Native/HardShear.txt.RunnerCleanup.json")
    assert close["Passed"] and close["ChildHasExited"] and close["ChildExitCode"] == 0
    assert close["RunnerCleanupValid"] and close["RunnerCleanup"] == clean
    assert clean["OwnerVerified"] and clean["QuitRequested"] and clean["QuitSucceeded"] and clean["Errors"] == []
    assert not clean["Failed"] and not close["OrdinaryPathKilledAnything"]
    final = close["Closure"]["FinalState"]
    assert final["State"] == "Absent" and (final["PID"], final["StartTicksUTC"]) == (owner["PID"], owner["StartTicksUTC"])
    assert (comp["PID"], comp["StartTicksUTC"]) != (owner["PID"], owner["StartTicksUTC"])
    text = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_YIELD_GATE: passed=1; failed=0" in text
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in text
    reopen = re.search(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=\1; equal=True;", text, re.M)
    assert reopen[1] == "8B4DCE5A97F20C43DC23C6BFDA0989CF923C1DF50372FCE415B5FDD1D91FA2D7"
    runtime = float(re.search(r"^RANK_TIME: ([^\r\n]+)", text, re.M)[1].replace(",", "."))
    assert runtime == 16.2431640625
    return runtime


def analyze_rank(probes, result):
    tested = {row["plan"][0]: row for row in probes}
    reply = []
    for h in result["chosen_h_pair"]:
        k = tested[h]["matrix"]
        constraint = [row[:56] for row in k[56:]]
        assert len(constraint) == 4 and all(value == 0. for row in k[56:] for value in row[56:])
        basis = null_basis(constraint)
        assert len(basis) == 52
        columns = [matvec(k[:56], [*vector, *([0.]*4)]) for vector in basis]
        projected = [[dot(left, applied) for applied in columns] for left in basis]
        lower, higher, _, _ = singular(projected)
        reply.append({"h": h, "sigma_min_MPa": lower, "sigma_max_MPa": higher, "sigma_ratio": lower/higher})
    for row, expected in zip(reply, (44.164887704776675, 45.02503890948366), strict=True):
        assert isclose(row["sigma_min_MPa"], expected, rel_tol=4e-11)
    assert all(row["sigma_ratio"] > 1e-5 for row in reply)
    return reply


def main():
    if not __debug__:
        raise SystemExit("Use Python without -O")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook", type=Path)
    parser.add_argument("--diagnostic-workbook", type=Path)
    parser.add_argument("--prior-archives", type=Path)
    args = parser.parse_args()
    fixture = verify_inputs(args)
    verify_sources(fixture)
    timing = verify_closed(fixture)
    path = HERE / "Native/HardYieldGate.csv"
    assert native.file_sha(path) == RAW
    meta, probes = native.discover(path)
    points = native.verify_samples(meta, probes, native.read("Expected.json"))
    result = {"archive_source_revision": fixture["source_revision"], "workbook_sha256": BOOK, "native_trace_sha256": RAW,
              "stock_history_H8_restored": True, "samples": points, **native.intervals(points, probes)}
    assert native.file_sha(HERE / "Native/Verification.json") == TERMINAL
    assert json.loads(json.dumps(result)) == native.read("Native/Verification.json")
    assert result["conclusion_scope"] == "same_history_equilibrium_bracket_and_signed_secants"
    assert result["chosen_h_pair"] == [5e-12, 8e-12] and all(p["original_equilibrium_certified"] for p in points)
    ranks = analyze_rank(probes, result)
    for rank in ranks:
        point, = [p for p in points if p["h"] == rank["h"]]
        print(f"H9 h={point['h']:.1e}, c={point['actual_control']:.16g}, "
              f"F={point['station'][0]:.8e} MPa, λ={point['factor']:.16g}, "
              f"dλ/dc={point['one_sided_tangent_dlambda_dc']:.8g}, σmin={rank['sigma_min_MPa']:.9g} MPa")
    print(f"6/6 EQUILIBRIA, H8 RESTORED, REOPEN EXACT, {timing:.6f} s")
    print("HARDSHEAR H9 EQUILIBRIUM PORTABLE VERIFIED", TERMINAL)


if __name__ == "__main__":
    main()
