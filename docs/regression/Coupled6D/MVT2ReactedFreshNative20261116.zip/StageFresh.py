"""Prepare the private §367 tangent replay while pinning archived sources and baseline."""
import csv
from hashlib import sha256
import json
from pathlib import Path
import shutil
import sys
from zipfile import ZipFile

import numpy as np

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
sys.path.insert(0,str(BASE/"r29b"))
from VerifyBase import diff, operators, read_native, tensor_radius, verified_states

ZIP="MVT2Row29ReactionsNative20261116.zip"
SHA="3E496D7AC294E3FF95F5F4F15778B10A656AFFF87C55EFEC58E0197E207601E0"
BOOK="A90C7A5E610C19D2C3CF0D7DB12831651DB12EEFD052E5DBED1378EE3C2C04FA"
SOURCE="9EC02E71D00DD083D2249126DA7F675D4531F143E4330182F04266C25789691E"
NATIVE="305240FE549B7E8B10382E5175C639E05874276ECB3B451C47FE754FF07F82ED"
H24="504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8"
EXTRA="8e-10"


def digest(payload):
    return sha256(payload).hexdigest().upper()


def put(path,data):
    path=HERE/path
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==data,path
    else:
        path.write_bytes(data)


def csv_bytes(rows):
    return ("\r\n".join(";".join(map(str,row)) for row in rows)+"\r\n").encode("ascii")


def gauges(geometry):
    G=np.zeros((4,60))
    for j in range(1,26):
        x,y,area=geometry[j,0]
        _,shape,xn,yn=operators(x,y)
        for node,basis in enumerate(shape):
            w=area*basis/57600.
            u=4+3*node
            for axis in range(3):
                G[axis,u+axis]+=w
            G[3,u]-=w*yn
            G[3,u+1]+=w*xn
    return G


def manifest(repo):
    frozen=repo/"docs/regression/Coupled6D"/ZIP
    assert digest(frozen.read_bytes())==SHA
    with ZipFile(frozen) as archive:
        for name,released,identity in (
            ("Replay.csv","Replay.csv",H24),("Native/MVT2.csv","PreviousNative.csv",NATIVE),
            ("Row29Plan.json","PreviousPlan.json","027BCCA0FC6A14CE3AB3B1B064B8F1CDF002AA312DDEE907E27CA7DD30A02E60"),
            ("Comparison.json","PreviousComparison.json","94728188D0C1AC05F176DC26E6E98EB29BA7CBDFEFC1257FB515CB034F433A48"),
        ):
            payload=archive.read(name)
            assert digest(payload)==identity
            put(released,payload)
    previous=read_native(HERE/"PreviousNative.csv")
    states,stations=verified_states(previous)
    ref=states["Reacted"]
    plan=json.loads((HERE/"PreviousPlan.json").read_text(encoding="utf8"))
    assert max(map(abs,diff(ref["field"],plan["after"])))<3e-15
    put("AnchorField.csv",csv_bytes([ref["field"]]))
    radius=plan["predicted_relative_physical_radius"]
    G=gauges(ref["geometry"])
    E=np.eye(60)
    u=E[28]-G.T@np.linalg.solve(G@G.T,G@E[28])
    assert max(abs(G@u))<1e-14 and max(abs(G@E[0]))<1e-14 and u[28]>0.
    witnesses=[]
    for name,direction in (("Axial",E[0]),("Weak29",u)):
        step=direction*radius/tensor_radius(direction,ref["geometry"])
        assert max(abs(G@step))<1e-22
        for side,sign in (("Plus",1.),("Minus",-1.)):
            witnesses.append((name+side,radius,0.,*(sign*step)))
    put("Witness.csv",csv_bytes(witnesses))
    vba=(BASE/"r29b/Control.bas").read_text(encoding="utf8")
    # Reuse the exact mechanics and full station trace. The §361 mixed-probe procedure is dropped.
    begin=vba.index("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Проверяет исходные отклики")
    vba=vba[:begin]
    vba=vba.replace('ByVal replayPath As String) As String','ByVal replayPath As String, ByVal phase As String) As String',1)
    vba=vba.replace("' Проверяет точную смешанную поправку после проверки четырёх известных исходных полей MVT2 B.",
                    "' Переоценивает касательную в точном Reacted при фиксированной истории H24.",1)
    start=vba.index('    norm = RecordWangTangentStateTest(output, "Anchor"')
    end=vba.index('    RequireWangAcceptedFieldTest solver, base',start)
    vba=vba[:start]+'''    Print #output, "B_FRESH_PHASE;" & phase
    norm = RecordWangTangentStateTest(output, "Reacted", 24, qTrial, solver, operators, materials, responses, anchor, referenceForces, residual)
    If norm <= 0# Then Err.Raise 5, , "Не воспроизведено измеренное исходное поле Reacted."
    ProcessWangFreshReactedTest output, folder, phase, history, solver, operators, materials, responses, base, anchor, qTrial
'''+vba[end:]
    put("Control.bas",(vba+(HERE/"Fresh.bas").read_text(encoding="utf8")).encode("utf8"))
    marker="' -------------------- ДЛЯ ТЕСТОВ --------------------"
    archived=(BASE/"r29b/tests/modTestCoupledExperiment.bas").read_text(encoding="utf8")
    signature='Public Function RunTestWangShearControlled('
    boundary=archived.rindex(marker,0,archived.index(signature))
    combined=(archived[:boundary]+(HERE/"Control.bas").read_text(encoding="utf8")).replace("\n","\r\n").encode("utf8")
    assert combined.count(signature.encode())==1
    put("tests/modTestCoupledExperiment.bas",combined)
    source=repo/"src/Solver/CCoupledNewtonSolver.cls"
    assert digest(source.read_bytes())==SOURCE
    text=source.read_text(encoding="utf-8-sig")
    addition=(BASE/"SolverReader.txt").read_text(encoding="utf8")
    assert "CopyTestWangTangent" not in text
    put("src/CCoupledNewtonSolver.cls",(text+"\n"+addition).replace("\n","\r\n").encode("utf8"))
    original=repo/"workbook/output/RC_Section_NDM.xlsm"
    assert digest(original.read_bytes())==BOOK
    put("workbook/output/RC_Section_NDM.xlsm",original.read_bytes())
    if not (HERE/"docs/regression/Diagnostic.xlsm").exists():
        put("docs/regression/Diagnostic.xlsm",original.read_bytes())
    for name in ("Temp","NativeA","NativeB"):
        (HERE/name).mkdir(exist_ok=True)

    inherited=json.loads((BASE/"r29b/Preparation.json").read_text(encoding="utf8"))
    reusable=[name for name in inherited["sources"] if name.startswith("tools/") or name=="Guard-IsolatedOffice.ps1"]
    for name in reusable:
        payload=(BASE/"r29b"/name).read_bytes()
        assert digest(payload)==inherited["sources"][name]
        put(name,payload)
    runner=(BASE/"Run-MVT2ShearControlled.ps1").read_text(encoding="utf8")
    old="python -B -X utf8 (Join-Path $root 'Prepare-MVT2ShearControlled.py') $repo"
    assert runner.count(old)==1
    runner=runner.replace(old,"python -B -X utf8 (Join-Path $root 'Verify-MVT2ShearControlled.py') --inputs-only")
    put("Run-MVT2ShearControlled.ps1",runner.encode("utf8"))
    verifier=(BASE/"r29b/VerifyBase.py").read_text(encoding="utf8")
    put("VerifyBase.py",verifier.encode("utf8"))
    inputs=("Replay.csv","PreviousNative.csv","PreviousPlan.json","PreviousComparison.json","AnchorField.csv","Witness.csv",
            "tests/modTestCoupledExperiment.bas","src/CCoupledNewtonSolver.cls","Run-MVT2ShearControlled.ps1",
            "Verify-MVT2ShearControlled.py","PlanFresh.py","VerifyBase.py",*reusable)
    receipt={"source_archive_sha256":SHA,"book_sha256":BOOK,"stock_solver_sha256":SOURCE,"replay_sha256":H24,
             "watchdog_seconds":200,"roundoff_MPa":float(EXTRA),"target_Qy_kN":ref["q"],
             "prior_native_sha256":NATIVE,"tested_modules":["CCoupledNewtonSolver","modTestCoupledExperiment"],
             "inputs":{name:digest((HERE/name).read_bytes()) for name in inputs}}
    put("Preparation.json",(json.dumps(receipt,indent=2)+"\n").encode("utf8"))
    print("Preparation.json",digest((HERE/"Preparation.json").read_bytes()))


if __name__=="__main__":
    manifest(Path(sys.argv[1]).resolve(strict=True))
