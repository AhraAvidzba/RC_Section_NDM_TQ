"""Replay both native phases and reproduce the bounded plan without an Excel binary."""
import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import sys

import VerifyBase as v

HERE=Path(__file__).resolve().parent


def load(name,file):
    spec=spec_from_file_location(name,HERE/file)
    script=module_from_spec(spec)
    spec.loader.exec_module(script)
    return script


def dumps(value):
    return (json.dumps(value,indent=2)+"\n").encode("utf8")


def source_checks(workbook):
    prep=v.read(HERE/"Preparation.json")
    assert all(v.digest(HERE/name)==identity for name,identity in prep["inputs"].items())
    if workbook is not None:
        assert v.digest(workbook)==prep["book_sha256"]
    old,station=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    ref=old["Reacted"]
    assert prep["target_Qy_kN"]==ref["q"]==18.5720088671875
    assert v.digest(HERE/"PreviousNative.csv")==prep["prior_native_sha256"]
    plan=v.read(HERE/"PreviousPlan.json")
    comparison=v.read(HERE/"PreviousComparison.json")
    assert comparison["trace_sha256"]==prep["prior_native_sha256"] and comparison["exact_H24_restore"]
    assert not comparison["history_published"] and plan["tau_MPa"]==ref["tol_MPa"]
    encoded=(HERE/"AnchorField.csv").read_bytes()
    assert encoded.count(b"\r\n")==1
    assert tuple(map(float,encoded.decode("ascii").strip().split(";")))==ref["field"]
    return prep,ref,station["Reacted"],tuple(plan["original_caps_MPa"])


def independent(result_B,original_caps):
    tags=v.read_native(HERE/"NativeB/MVT2.csv")
    states,stations=v.verified_states(tags)
    requested=v.force(result_B["q_trial_kN"])
    proof={}
    for key in ("Reacted","Fresh1First","Fresh2Best"):
        state=states[key]
        rows,internal,geometry_error=v.reconstruct(state["field"],state["q"],stations[key])
        signed=v.diff(internal,requested)
        recovered=v.peak(v.diff(signed,state["signed_force_N_Nmm"]))
        assert recovered<4e-10
        margins=tuple(cap*scale-abs(x) for x,cap,scale in zip(signed,original_caps,v.SCALES,strict=True))
        shape=None if key=="Reacted" else v.tensor_radius(v.diff(state["field"],states["Reacted"]["field"]),state["geometry"])
        proof[key]={"norm_MPa":state["norm_MPa"],"governing_weak_row":max(range(56),key=lambda i:abs(rows[i]))+1,
                    "row29_MPa":rows[28],"row53_MPa":rows[52],"exact_four_gauges_MPa":[v.MODULUS*k for k in rows[56:]],
                    "signed_actual_efforts_N_Nmm":dict(zip(v.EFFORT_NAMES,internal,strict=True)),
                    "signed_effort_residuals_N_Nmm":dict(zip(v.EFFORT_NAMES,signed,strict=True)),
                    "original_cap_margins_N_Nmm":dict(zip(v.EFFORT_NAMES,margins,strict=True)),
                    "station_kinematic_reconstruction_error":geometry_error,"shape_peak_over_Reacted":shape,
                    "passed_caps":min(margins)>=0.,
                    "passes_equilibrium":max(state["norm_MPa"],state["gauge_MPa"])<=result_B["tau_MPa"]}
    assert proof["Fresh1First"]["passed_caps"] and not proof["Fresh2Best"]["passed_caps"]
    assert [name for name,val in proof["Fresh2Best"]["original_cap_margins_N_Nmm"].items() if val<0.]==["My"]
    assert states["Restored24"]==states["Base24"] and stations["Restored24"]==stations["Base24"]
    return {"effort_order":list(v.EFFORT_NAMES),"signed_requested_efforts_N_Nmm":list(requested),
            "exact_H24_field_and_station_restore":True,"states":proof}


def replay(workbook,run_numerical_plan,output):
    prep,ref,stations,caps=source_checks(workbook)
    verifier=load("fresh_verified","Verify-MVT2ShearControlled.py")
    outputs={}
    for phase in ("A","B"):
        if phase=="B":
            verifier.gate_B()
        result=verifier.verify(phase,prep,ref,stations,caps,offline=True)
        expected=HERE/f"Verification{phase}.json"
        assert dumps(result).replace(b"\n",b"\r\n")==expected.read_bytes(),expected
        outputs[phase]=result
    plan_paths=(HERE/"Plan.json",HERE/"Candidate.csv")
    original=[p.read_bytes() for p in plan_paths]
    if run_numerical_plan:
        planner=load("fresh_planner","PlanFresh.py")
        planner.plan()
        regenerated=plan_paths[0].read_bytes().replace(b"\r\n",b"\n").replace(b"\n",b"\r\n")
        assert regenerated==original[0]
        plan_paths[0].write_bytes(regenerated)
        assert original==[p.read_bytes() for p in plan_paths]
    output.write_bytes(dumps({
        "archived_source_book_sha256":prep["book_sha256"],"source_overlay_sha256":{
            name:prep["inputs"][name] for name in prep["inputs"] if name.startswith(("src/","tests/"))},
        "verified_source_archive_sha256":prep["source_archive_sha256"],
        "native_A_sha256":outputs["A"]["trace_sha256"],"native_B_sha256":outputs["B"]["trace_sha256"],
        "verification_A_sha256":v.digest(HERE/"VerificationA.json"),"verification_B_sha256":v.digest(HERE/"VerificationB.json"),
        "plan_sha256":v.digest(plan_paths[0]),"candidate_sha256":v.digest(plan_paths[1]),
        "q_trial_kN":outputs["B"]["q_trial_kN"],"last_accepted_q_kN":outputs["B"]["q_last_accepted_kN"],
        "H24_sha256":outputs["B"]["H24_sha256"],"history_published":False,"tau_MPa":outputs["B"]["tau_MPa"],
        "phase_A":{k:outputs["A"][k] for k in ("native_wall_s","compile_owner","native_owner","archive_vector_error_MPa")},
        "phase_B":{k:outputs["B"][k] for k in ("native_wall_s","compile_owner","native_owner","archive_vector_error_MPa")},
        "signed_validation":independent(outputs["B"],caps),
    }))
    print(output,v.digest(output))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook",type=Path)
    parser.add_argument("--plan",action="store_true",help="regenerate the LP using NumPy/SciPy and require bytewise match")
    parser.add_argument("--output",type=Path,default=HERE/"PortableReport.json")
    opts=parser.parse_args()
    replay(opts.workbook,opts.plan,opts.output)
