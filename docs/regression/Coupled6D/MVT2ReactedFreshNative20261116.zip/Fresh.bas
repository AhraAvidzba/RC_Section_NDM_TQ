' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет свежие касательные на точном Reacted и проверяет только рассчитанные ограниченные поправки.
Private Sub ProcessWangFreshReactedTest(ByVal output As Integer, ByVal folder As String, ByVal phase As String, _
        ByVal history As Collection, ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByRef anchor() As Double, ByVal factor As Double)
    Dim matrix() As Double, residual() As Double, projection() As Double, i As Long, j As Long
    Dim choice As Long, label As String, row As String
    If phase = "A" Then
        For choice = 1 To 3
            RestoreWangShearBaselineTest solver, history, base
            Select Case choice
                Case 1: label = "Stock"
                Case 2: label = "Consistent"
                Case 3: label = "Refined"
            End Select
            If solver.CopyTestWangTangent(anchor, choice, residual, matrix) Then
                EmitWangTangentVectorTest output, "B_FRESH_INTERNAL;" & label, residual
                For i = 1 To UBound(anchor)
                    row = "B_FRESH_MATRIX;" & label & ";" & CStr(i)
                    For j = 1 To UBound(anchor): row = row & ";" & ExperimentNumberTest(matrix(j, i)): Next j
                    Print #output, row
                Next i
            Else
                Print #output, "B_FRESH_MATRIX_UNAVAILABLE;" & label
            End If
            RequireWangAcceptedFieldTest solver, base
        Next choice
        operators.CopyResultantResidualProjection projection
        For i = 1 To 6
            row = "B_FRESH_PROJECTION;" & CStr(i)
            For j = 1 To solver.PhysicalDegreeCount: row = row & ";" & ExperimentNumberTest(projection(j, i)): Next j
            Print #output, row
        Next i
        RecordWangFreshTrialsTest output, folder & "Witness.csv", history, solver, operators, materials, responses, base, anchor, factor
    ElseIf phase = "B" Then
        RecordWangFreshTrialsTest output, folder & "Candidate.csv", history, solver, operators, materials, responses, base, anchor, factor
    Else
        Err.Raise 5, , "Неизвестная фаза проверки Reacted."
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пробует приращения при прежних станциях, нагрузке и принятой истории. Пробы в историю не добавляет.
Private Sub RecordWangFreshTrialsTest(ByVal output As Integer, ByVal path As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByRef anchor() As Double, ByVal factor As Double)
    Dim file As Integer, row As String, values As Variant, field() As Double, correction(1 To 60) As Double
    Dim count As Long, label As String, radius As Double, prediction As Double, extent As Double, k As Long, norm As Double
    Dim actual() As Double, residual() As Double
    file = FreeFile: Open path For Input As #file
    Do Until EOF(file)
        Line Input #file, row
        values = Split(row, ";")
        If UBound(values) <> 62 Or count >= 4 Then Err.Raise 5, , "Неверный перечень ограниченных проб Reacted."
        label = values(0): radius = Val(values(1)): prediction = Val(values(2))
        For k = 1 To 60: correction(k) = Val(values(k + 2)): Next k
        extent = WangBoundedTensorPeakTest(operators, correction)
        If radius <= 0# Or radius > 0.00000001 Or extent > radius + 0.0000000000000004 Then _
            Err.Raise 5, , "Нарушено ограничение приращения деформаций Reacted."
        RestoreWangShearBaselineTest solver, history, base
        AddWangTangentDirectionTest anchor, correction, 1#, field
        Print #output, "B_FRESH_INPUT;" & label & ";" & ExperimentNumberTest(radius) & ";" & _
            ExperimentNumberTest(prediction) & ";" & ExperimentNumberTest(extent)
        norm = RecordWangTangentStateTest(output, label, 24, factor, solver, operators, materials, responses, field, actual, residual)
        RequireWangAcceptedFieldTest solver, base
        count = count + 1
    Loop
    Close #file
    If count < 1 Then Err.Raise 5, , "Отсутствуют ограниченные пробы Reacted."
    Print #output, "B_FRESH_PROBES;" & CStr(count)
End Sub
