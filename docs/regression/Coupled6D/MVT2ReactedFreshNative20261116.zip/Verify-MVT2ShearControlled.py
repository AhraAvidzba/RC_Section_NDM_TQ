"""Independently attest exact Reacted baseline, native phase, original caps and rollback."""
import argparse
import csv
import json
from pathlib import Path
import sys

import VerifyBase as v

HERE=Path(__file__).resolve().parent
LABELS=("AxialPlus","AxialMinus","Weak29Plus","Weak29Minus")


def norm(state,stations):
    return v.peak(response(state,stations))


def response(state,stations):
    raw,_,_=v.reconstruct(state["field"],state["q"],stations)
    return (*state["r"],*(x*v.MODULUS for x in raw[56:]))


def freeze():
    prep=v.read(HERE/"Preparation.json")
    assert all(v.digest(HERE/name)==value for name,value in prep["inputs"].items())
    assert v.digest(HERE/"workbook/output/RC_Section_NDM.xlsm")==prep["book_sha256"]
    old,stations=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    q=prep["target_Qy_kN"]
    ref=old["Reacted"]
    assert q==ref["q"]==18.5720088671875
    path=HERE/"AnchorField.csv"
    assert path.read_bytes().count(b"\r\n")==1
    field=tuple(map(float,path.read_text().strip().split(";")))
    assert field==ref["field"] and len(field)==60
    cfg=v.read(HERE/"PreviousPlan.json")
    assert cfg["tau_MPa"]==ref["tol_MPa"]
    compare=v.read(HERE/"PreviousComparison.json")
    assert compare["trace_sha256"]==prep["prior_native_sha256"]
    assert v.digest(HERE/"PreviousNative.csv")==prep["prior_native_sha256"]
    assert compare["exact_H24_restore"] and not compare["history_published"]
    assert (HERE/"Witness.csv").read_bytes().count(b"\r\n")==4
    return prep,ref,stations["Reacted"],tuple(cfg["original_caps_MPa"]),compare


def designs(path):
    raw=path.read_bytes()
    assert raw.count(b"\r\n")==raw.count(b"\n")
    rows=list(csv.reader(raw.decode("ascii").splitlines(),delimiter=";"))
    assert 1<=len(rows)<=4
    out={}
    for name,radius,pred,*values in rows:
        assert name not in out and len(values)==60
        out[name]=(float(radius),float(pred),tuple(map(float,values)))
    return out


def phase_receipts(phase,prep,offline):
    native=HERE/f"Native{phase}"
    build=v.read(HERE/"docs/regression/CodeUpdate.json")
    compiler=v.read(HERE/"CompileClosure.json")
    owner=v.read(native/"MVT2.txt.Ownership.json")
    watcher=v.read(native/"MVT2.txt.ProcessClosure.json")
    receipt=v.read(native/"RunReceipt.json")
    final=watcher["Closure"]["FinalState"]
    assert build["Compiled"] and sorted(build["Modules"])==prep["tested_modules"] and not build["ProductionChanged"]
    assert compiler["State"]=="Absent" and build["ProductionSHA256"]==prep["book_sha256"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert watcher["Passed"] and watcher["ChildHasExited"] and watcher["ChildExitCode"]==receipt["native_exit"]==0
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (native/"MVT2.txt").read_text(encoding="utf-8-sig")
    if not offline:
        assert v.digest(HERE/"docs/regression/Diagnostic.xlsm")==build["WorkbookSHA256"]
    return native,compiler,final,receipt["wall_seconds"]


def verify(phase,prep,ref,ref_stations,caps,offline):
    native,compile_owner,run_owner,wall=phase_receipts(phase,prep,offline)
    trace=native/"MVT2.csv"
    tags=v.read_native(trace)
    states,stations=v.verified_states(tags)
    assert tags["B_FRESH_PHASE"]==[[phase]]
    [[qbase,q]]=tags["B_TANGENT_LOAD"]
    qbase,q=map(float,(qbase,q))
    assert q==ref["q"]
    historic=v.vec(tags,"MVT2_CONTROL_FIELD")
    rows=list(csv.reader((HERE/"Replay.csv").read_text().splitlines(),delimiter=";"))[1:]
    assert len(rows)==len(historic)==24
    for i,row in enumerate(rows,1):
        assert int(row[0])==i and v.peak(v.diff(tuple(map(float,row[9:])),historic[f"Replay{i}"]))<1e-15
    v.near(qbase,float(rows[-1][2]),2e-13)
    v.near(q,qbase+(qbase-float(rows[-2][2]))/64,2e-13)
    assert states["Restored24"]==states["Base24"]
    assert states["Base24"]["field"]==historic["Replay24"] and states["Base24"]["q"]==qbase
    assert stations["Restored24"]==stations["Base24"]
    current=states["Reacted"]
    tau=current["tol_MPa"]
    actual=response(current,stations["Reacted"])
    difference=v.peak(v.diff(actual,response(ref,ref_stations)))
    assert difference<prep["roundoff_MPa"]
    assert current["geometry"]==ref["geometry"] and v.peak(v.diff(current["field"],ref["field"]))<3e-15
    assert max(abs(val)-cap for val,cap in zip(actual[56:62],caps,strict=True))<=0.
    steel=v.verify_steel(tags,states,stations,historic)
    candidates=designs(HERE/("Witness.csv" if phase=="A" else "Candidate.csv"))
    announced={name:tuple(map(float,values)) for name,*values in tags["B_FRESH_INPUT"]}
    assert set(candidates)==set(announced)
    assert tags["B_FRESH_PROBES"]==[[str(len(candidates))]]
    measured={}
    for name,(radius,pred,delta) in candidates.items():
        assert 0.<radius<=1e-8
        extent=v.tensor_radius(delta,current["geometry"])
        assert extent<=radius+4e-16
        assert v.peak(v.diff((radius,pred,extent),announced[name]))<4e-15
        if name not in states:
            assert [name,"Residual"] in tags["B_TANGENT_UNAVAILABLE"]
            measured[name]={"available":False}
            continue
        trial=states[name]
        assert trial["q"]==q and trial["geometry"]==current["geometry"]
        assert v.peak(v.diff(trial["field"],(a+d for a,d in zip(current["field"],delta,strict=True))))<3e-15
        vector=response(trial,stations[name])
        failed=[key for key,x,cap in zip(v.EFFORT_NAMES,vector[56:62],caps,strict=True) if abs(x)>cap]
        magnitude=v.peak(vector)
        measured[name]={"available":True,"norm_MPa":magnitude,"all66_MPa":vector,"signed_six_N_Nmm":trial["signed_force_N_Nmm"],
            "failed_original_caps":failed,"gain_over_tau":(v.peak(actual)-magnitude)/tau,
            "equilibrium":magnitude<=tau,"gauge_MPa":trial["gauge_MPa"],
            "peak_steel_MPa":steel[name],"passes_progress":not failed and magnitude<=v.peak(actual)-tau}
    return {"phase":phase,"source_book_sha256":prep["book_sha256"],"trace_sha256":v.digest(trace),
            "archive_vector_error_MPa":difference,"q_trial_kN":q,"q_last_accepted_kN":qbase,
            "H24_sha256":prep["replay_sha256"],"exact_rollback":True,"history_published":False,
            "reference_norm_MPa":v.peak(actual),"tau_MPa":tau,"reference_all66_MPa":actual,
            "original_caps_MPa":caps,"measured":measured,"native_wall_s":wall,"compile_owner":compile_owner,"native_owner":run_owner}


def gate_B():
    plan=v.read(HERE/"Plan.json")
    assert plan["phase_A_sha256"]==v.digest(HERE/"NativeA/MVT2.csv")
    assert plan["selected"]
    assert v.digest(HERE/"Candidate.csv")==plan["candidate_sha256"]
    fields=designs(HERE/"Candidate.csv")
    assert list(fields)==[row["label"] for row in plan["selected"]]
    for row in plan["selected"]:
        assert row["linear_gate"] and tuple(row["dq"])==fields[row["label"]][2]


if __name__=="__main__":
    args=argparse.ArgumentParser(description=__doc__)
    args.add_argument("--inputs-only",action="store_true")
    args.add_argument("--prevalidate",action="store_true")
    args.add_argument("--offline",action="store_true")
    args.add_argument("--phase",choices=("A","B"))
    options=args.parse_args()
    prep,ref,stations,caps,_=freeze()
    if options.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"),"Qy",ref["q"],"tau",ref["tol_MPa"],"all_six_caps",caps)
    elif options.prevalidate:
        gate_B()
    else:
        assert options.phase in ("A","B")
        if options.phase=="B":
            gate_B()
        report=verify(options.phase,prep,ref,stations,caps,options.offline)
        output=HERE/f"Verification{options.phase}.json"
        output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
        print(output,v.digest(output))
