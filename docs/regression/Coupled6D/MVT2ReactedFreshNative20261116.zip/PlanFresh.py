"""Solve a bounded corrected linear system on a freshly measured Reacted state."""
import csv
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import linprog

import VerifyBase as v

HERE=Path(__file__).resolve().parent
ROUND=8e-10
DISPLACEMENT_UNIT=1e-9
REACTION_UNIT=1e-3
STRESS_UNIT=1e-4


def gauge_matrix(geometry):
    rows=np.zeros((4,60))
    for p in range(1,26):
        x,y,a=geometry[p,0]
        _,shape,xn,yn=v.operators(x,y)
        for j,b in enumerate(shape):
            w=a*b/v.AREA
            k=4+3*j
            for axis in range(3):
                rows[axis,k+axis]+=w
            rows[3,k]-=yn*w
            rows[3,k+1]+=xn*w
    return rows


def strain_matrix(geometry):
    unit=np.eye(60)
    collected=[]
    for (_,side),(x,y,_) in geometry.items():
        block=v.operators(x,y)
        part=np.array([v.strain_at(e,block,side) for e in unit]).T
        part[3:]/=np.sqrt(2.)
        collected.extend(part)
    return np.array(collected)


def assembled(tags,base,reference,geometry,load):
    gauge=gauge_matrix(geometry)
    projection=np.array([list(map(float,row)) for _,*row in tags["B_FRESH_PROJECTION"]])
    assert projection.shape==(6,56)
    assert max(abs(projection@base[:56]-base[56:62]))<4e-10
    assert np.max(abs(projection@gauge[:,:56].T))<4e-14
    fields={}
    for name,index,*row in tags["B_FRESH_MATRIX"]:
        rows=fields.setdefault(name,{})
        assert int(index) not in rows
        rows[int(index)]=list(map(float,row))
    assert set(fields).union(x[0] for x in tags["B_FRESH_MATRIX_UNAVAILABLE"])=={"Stock","Consistent","Refined"}
    modes={}
    metadata={}
    internal=v.vec(tags,"B_FRESH_INTERNAL")
    for name,rows in fields.items():
        M=np.array([rows[i] for i in range(1,61)])
        assert all(len(row)==60 for row in M)
        assert np.max(abs(M[-4:]-gauge))<=2e-12
        assert np.max(abs(M[:56,-4:]-gauge[:,:56].T))<=2e-12
        error=np.array(internal[name])-v.loading(load)
        mismatch=max(abs(np.r_[error[:56],projection@error[:56],error[56:]*v.MODULUS]-base))
        metadata[name]={"internal_anchor_discrepancy_MPa":float(mismatch),"eligible_response":bool(mismatch<=ROUND)}
        if mismatch>ROUND:
            continue
        # Replace the machine-dumped constraints and reaction columns by the exact section operators.
        M[:56,-4:]=gauge[:,:56].T
        M[-4:]=gauge
        modes[name]=np.r_[M[:56],projection@M[:56],M[-4:]*v.MODULUS]
    return modes,gauge,metadata


def solve(base,gauges,S,modes,caps,radius,padding):
    step=np.r_[np.full(56,DISPLACEMENT_UNIT),np.full(4,REACTION_UNIT)]
    scaled=np.vstack(list(modes.values()))*step/STRESS_UNIT
    force=np.vstack([M[56:62] for M in modes.values()])*step/STRESS_UNIT
    M=np.vstack((scaled,-scaled,force,-force,S*step/DISPLACEMENT_UNIT,-S*step/DISPLACEMENT_UNIT))
    epi=np.r_[-np.ones(2*len(scaled)),np.zeros(2*len(force)+2*len(S))]
    q=np.tile(base, len(modes))/STRESS_UNIT
    U=np.r_[-q,q,np.tile(caps-padding-base[56:62],len(modes))/STRESS_UNIT,
        np.tile(caps-padding+base[56:62],len(modes))/STRESS_UNIT,np.full(2*len(S),radius/DISPLACEMENT_UNIT)]
    M=np.c_[M,epi]
    exact=np.c_[gauges*step/DISPLACEMENT_UNIT,np.zeros(4)]
    eq=-base[-4:]/v.MODULUS/DISPLACEMENT_UNIT
    objective=np.r_[np.zeros(60),1.]
    result=linprog(objective,A_ub=M,b_ub=U,A_eq=exact,b_eq=eq,bounds=[(None,None)]*60+[(0,None)],method="highs",
                   options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
    if not result.success:
        return {"radius":radius,"mode_names":list(modes),"solver_terminal":result.message}
    dq=result.x[:60]*step
    radius_actual=float(max(abs(S@dq)))
    assert radius_actual<=radius+4e-16
    equilibrium_error=float(max(abs(gauges@dq+base[-4:]/v.MODULUS)))
    assert equilibrium_error<2e-17
    expected={key:base+M@dq for key,M in modes.items()}
    f=max(float(max(abs(y))) for y in expected.values())
    cap_spare=min(float(min(caps-abs(y[56:62]))) for y in expected.values())
    assert cap_spare>=padding-5e-13
    assert abs(f-result.fun*STRESS_UNIT)<2e-12
    tau=5e-7*(1.+max(map(abs,v.loading(18.5720088671875))))
    robust_gain=float(max(abs(base)))-f-padding
    primary=float(min(abs(base[28])-abs(x[28]) for x in expected.values()))
    return {"radius":radius,"mode_names":list(modes),"prediction_MPa":f,"shape_peak":radius_actual,
            "gauge_error_abs_strain":equilibrium_error,"smallest_six_effort_margin_MPa":cap_spare,
            "padding_MPa":padding,"predicted_drop_after_padding_over_tau":robust_gain/tau,"row29_minimum_drop_MPa":primary,
            "by_mode_all66_MPa":{name:list(z) for name,z in expected.items()},"dq":list(dq),
            "linear_gate":bool(robust_gain>=tau and primary>=tau)}


def plan():
    trace=HERE/"NativeA/MVT2.csv"
    measure=v.read(HERE/"VerificationA.json")
    assert measure["trace_sha256"]==v.digest(trace) and measure["exact_rollback"]
    tags=v.read_native(trace)
    states,stations=v.verified_states(tags)
    ref=states["Reacted"]
    baseline=np.array(measure["reference_all66_MPa"])
    assert int(np.argmax(np.abs(baseline)))==28
    caps=np.array(measure["original_caps_MPa"])
    modes,gauge,metadata=assembled(tags,baseline,ref,ref["geometry"],measure["q_trial_kN"])
    S=strain_matrix(ref["geometry"])
    witnesses={}
    with (HERE/"Witness.csv").open(newline="") as file:
        for name,radius,_,*d in csv.reader(file,delimiter=";"):
            measured=measure["measured"][name]
            if measured["available"]:
                witnesses[name]=(float(radius),np.array(list(map(float,d))),np.array(measured["all66_MPa"])-baseline)
    scales={name:{trial:float(max(abs(J@d-observed))) for trial,(_,d,observed) in witnesses.items()}
            for name,J in modes.items()}
    old=v.read(HERE/"PreviousComparison.json")
    prior_error=old["Reacted"]["model_error_MPa"]
    tau=measure["tau_MPa"]
    radius0=float(v.read(HERE/"PreviousPlan.json")["predicted_relative_physical_radius"])
    # The smallest radius is the last validated local radius. Larger radii were
    # already predeclared in the bounded mechanics verification.
    radii=(radius0,2.5e-9,5e-9,1e-8)
    eligible={k:J for k,J in modes.items() if len(witnesses)==4 and max(scales[k].values())+ROUND<tau}
    groups=[eligible] if eligible else []
    if len(eligible)>1:
        best=min(eligible,key=lambda k:max(scales[k].values()))
        groups.append({best:eligible[best]})
    tested=[]
    selected=[]
    for group in groups:
        witness_error=max(err for key in group for err in scales[key].values())
        for radius in radii:
            margin=max(prior_error,witness_error*radius/radius0)+ROUND
            tested.append(solve(baseline,gauge,S,group,caps,radius,margin))
        valid=[item for item in tested if item.get("linear_gate") and item["mode_names"]==list(group)]
        if not valid:
            continue
        best=max(valid,key=lambda item:item["predicted_drop_after_padding_over_tau"])
        for tag,item in (("First",valid[0]),("Best",best)):
            delta=item["dq"]
            if any(max(abs(S@(np.array(archived["dq"])-delta)))<radius0 for archived in selected):
                continue
            selected.append({**item,"label":"Fresh"+str(len(selected)+1)+tag})
        if selected:
            break
    emitted=None
    if selected:
        rows=[]
        for item in selected:
            rows.append(";".join([item["label"],*(format(x,".17g") for x in
                         (item["radius"],item["prediction_MPa"],*item["dq"]))]))
        raw=("\r\n".join(rows)+"\r\n").encode("ascii")
        (HERE/"Candidate.csv").write_bytes(raw)
        emitted=sha256(raw).hexdigest().upper()
    result={"phase_A_sha256":measure["trace_sha256"],"tau_MPa":tau,
            "original_effort_caps_MPa":list(caps),"station_rows":int(len(S)/6),
            "physical_H24_calibration":"same fixed load and same 24 exact records",
            "gates":"gain >= original tau after reserve, row29 gain >= tau, original six caps and exact guides",
            "model_availability":metadata,"four_fresh_signed_witnesses_max_error_MPa":scales,"eligible_models":list(eligible),
            "selected":selected,"candidate_sha256":emitted,"tested":tested}
    path=HERE/"Plan.json"
    path.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print("READY_B" if selected else "NO_B",path,v.digest(path),"candidate",emitted)


if __name__=="__main__":
    plan()
