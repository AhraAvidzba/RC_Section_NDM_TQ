from pathlib import Path
from hashlib import sha256
import json, numpy as np
from scipy.interpolate import BSpline

def operators(geometry, L):
    x,y,area=geometry.T
    normalized=area/(305.*610.)
    gx_knots=np.array([-152.5]*4+[0.]+[152.5]*4)
    gy_knots=np.array([-305.]*4+[0.]+[305.]*4)
    basis=np.eye(5)
    spline_x=BSpline(gx_knots,basis,3,extrapolate=False)
    spline_y=BSpline(gy_knots,basis,3,extrapolate=False)
    nx,ny=spline_x(x),spline_y(y)
    dx,dy=spline_x.derivative()(x),spline_y.derivative()(y)
    def pair(a,b):
        return (a[:,:,None]*b[:,None,:]).reshape((len(x),25))
    shape=pair(ny,nx)
    slope_x=L*pair(ny,dx)
    slope_y=L*pair(dy,nx)
    h=np.zeros((184,6,79))
    u=slice(4,79,3)
    v=slice(5,79,3)
    w=slice(6,79,3)
    h[:,2,0]=1.
    h[:,2,1]=y/L
    h[:,2,2]=x/L
    h[:,4,3]=-y/L
    h[:,5,3]=x/L
    h[:,0,u]=slope_x
    h[:,1,v]=slope_y
    h[:,3,u]=slope_y
    h[:,3,v]=slope_x
    h[:,4,w]=slope_x
    h[:,5,w]=slope_y
    c=np.zeros((4,79))
    concrete=slice(144)
    shape_weight=shape[concrete]*normalized[concrete,None]
    c[0,u]=c[1,v]=c[2,w]=shape_weight.sum(axis=0)
    c[3,u]=(-y[concrete,None]/L*shape_weight).sum(axis=0)
    c[3,v]=(x[concrete,None]/L*shape_weight).sum(axis=0)
    resultants=np.zeros((184,6,6))
    resultants[:,0,2]=1.
    resultants[:,1,2]=y
    resultants[:,2,2]=x
    resultants[:,3,4]=-y
    resultants[:,3,5]=x
    resultants[:,4,4]=1.
    resultants[:,5,5]=1.
    scales=305.*610.*np.array([1.,L,L,L,1.,1.])
    return h, shape, c, resultants, normalized, scales

ROOT=Path(__file__).resolve().parent
def read(name): return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def digest(name): return sha256((ROOT/name).read_bytes()).hexdigest().upper()
def peak(a): return float(np.max(np.abs(a)))
def near(a,b,tol): assert abs(a-b)<=tol,(a,b,tol)

def control_certificate(residual,weights,tau):
    coeff=weights[2]
    pos=coeff>0.
    lo=float(np.max((-tau-residual[:79][pos])/coeff[pos]))
    hi=float(np.min((tau-residual[:79][pos])/coeff[pos]))
    involved=np.r_[pos,np.zeros(10,dtype=bool)]
    feasible=lo<=hi and peak(residual[~involved])<=tau
    return lo,hi,bool(feasible)

def computed(d, original):
    g,L=d["geometry"],float(d["length"])
    h,shape,c,qmat,weights,scales=operators(g,L)
    states={}
    for name,field,native,index in zip(d["names"],d["fields"],d["states"],d["station_index"],strict=True):
        tag=str(name)
        stations=d["stations"][int(index)]
        lam,target=field[:2]
        q=field[2:]
        coord=q[:79]
        depth=q[79:83]
        mu=q[83:]
        assert lam==native[1] and target==native[0]
        strains=h@coord
        slope=h[:,:,:4]@depth
        eps3=np.array([strains+i*.001*slope for i in (-1,0,1)])
        assert peak(eps3-stations[:,:,:6])<2e-12
        stresses=stations[1,:,6:]
        gradient=(stations[2,:,6:]-stations[0,:,6:])/.002
        eq=np.einsum("nij,ni,n->j",h,stresses,weights)
        eq[4:]-=np.einsum("nk,na,n->ka",shape,gradient[:,[4,5,2]],weights).ravel()
        eq+=c.T@mu
        long_eq=np.einsum("nij,ni,n->j",h[:,:,:4],gradient,weights)
        long_eq[1]-=1e5*lam/scales[0]
        gauge=c@coord
        force=np.einsum("nij,nj,n->i",qmat,stresses,g[:,2])
        assert peak(np.r_[eq,long_eq,gauge]-native[12:])<2e-10
        assert peak((force-native[6:12])/scales)<2e-10
        r=np.r_[eq,long_eq,(force-np.r_[np.zeros(5),1e5*lam])/scales]
        gamma=float(weights[:144]@strains[:144,5])
        tau=float(native[3])
        assert abs(gamma-target)*25600. <=tau and peak(gauge)*25600.<=tau
        norm=max(peak(r),abs(gamma-target)*25600.)
        near(norm,native[2],2e-10)
        states[tag]={"r":r,"tau":tau,"norm":norm,"field":field,"idx":int(index),"resultants":native[6:12]}
    return states,c

def verify():
    manifest=read("Manifest.json")
    for name,value in manifest["files"].items():
        assert digest(name)==value,name
    witness=read("NativeVerification.json")
    owner=read("NativeOwner.json")
    native=read("NativeClosure.json")
    compile_closed=read("CompileClosure.json")
    preparation=read("PreparedNative.json")
    raw=(ROOT/"NativeTreatment.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_KANI_V4_STAGE38: passed=1; failed=0" in raw
    assert "SOURCE_UNCHANGED: True" in raw
    assert native["Passed"] and int(native["ChildExitCode"])==0
    stop=native["Closure"]["FinalState"]
    assert stop==witness["closure"] and stop["State"]==compile_closed["State"]=="Absent"
    assert int(stop["PID"])==int(owner["PID"]) and stop["StartTicksUTC"]==owner["StartTicksUTC"]
    assert int(stop["PID"])!=int(compile_closed["PID"]) and owner["VerifiedNewOwner"]
    assert preparation["workbook_sha256"]==witness["workbook"]
    assert preparation["production_source_sha256"]==witness["production_sources"]
    assert sha256((ROOT/"InputsHistory42And43.csv").read_bytes()).hexdigest().upper()==preparation["frozen"]["KaniGaugeInput.csv"]
    historical_hashes=manifest["archive_input_sources"]
    assert historical_hashes["KaniV4Trace.csv"]==witness["trace_sha"]
    assert historical_hashes["KaniV4Stations.csv"]==witness["station_sha"]
    pred=read("PlannedProbes.json")
    proof=read("PredictionCheckNative.json")
    pair_record=read("RequiredPairChange.json")
    assert digest("History44Verified.csv")==proof["history44_sha"]
    with np.load(ROOT/"MeasuredSamples.npz",allow_pickle=False) as d:
        st,c=computed(d,witness)
    assert len(st)==manifest["recordedStates"] and len({m["idx"] for m in st.values()})==manifest["uniqueMaterialStates"]
    a,b=c[2,[45,69]]
    assert a>0 and b>0 and np.count_nonzero(c[[0,1,3]][:,[45,69]])==0
    def invariant(r): return float((b*r[45]-a*r[69])/(a+b))
    pair_proofs={}
    outcomes={}
    for h,group in witness["tests"].items():
        assert st[h+"/End"]["idx"]==st[h+"/Base"]["idx"]
        assert np.array_equal(st[h+"/End"]["field"],st[h+"/Base"]["field"])
        outcomes[h]={}
        for tag,case in group.items():
            root=f"{h}/{tag}"
            before=st[root+"/Probe"]
            lo,hi,allowed=control_certificate(before["r"],c,before["tau"])
            near(lo,case["interval_MPa"][0],2e-11)
            near(hi,case["interval_MPa"][1],2e-11)
            assert allowed==case["feasible"]
            fp=invariant(before["r"])
            needed=max(abs(fp)-before["tau"],0.)
            if not allowed:
                assert needed>0
            outcomes[h][tag]={"initial_MPa":before["norm"],"scalarInterval_MPa":[lo,hi],"feasible":allowed,
                              "minPairLInfChange_MPa":needed}
            if case["exact"]:
                final=st[root+"/Solved"]
                assert before["idx"]==final["idx"] and np.array_equal(before["resultants"],final["resultants"])
                assert np.array_equal(np.flatnonzero(before["field"]!=final["field"]),[87])
                near(final["norm"],case["after_MPa"],2e-10)
                assert final["norm"]<=before["tau"]
                outcomes[h][tag]["final_MPa"]=final["norm"]
        pair_proofs[h]=outcomes[h]["Bracket19of512"]["minPairLInfChange_MPa"]
        near(pair_proofs[h],pair_record["exactMeasurements"][h+"/Bracket19of512/Probe"]["minPairLInfChange_MPa"],2e-13)
    commit=st["History43/Committed"]
    selected=st["History43/"+witness["commit"]["tag"]+"/Solved"]
    assert selected["idx"]==commit["idx"] and np.array_equal(selected["field"],commit["field"])
    assert st["History43/Restore"]["idx"]==st["History43/Base"]["idx"]
    assert np.array_equal(st["History43/Restore"]["field"],st["History43/Base"]["field"])
    near(commit["norm"],witness["commit"]["complete_norm_MPa"],2e-10)
    near(commit["field"][0],witness["commit"]["lambda"],1e-15)
    restored=(ROOT/"History44Verified.csv").read_text(encoding="ascii").strip().split(";")
    assert restored[:3]==["KANI_B_FIELD","History44Verified","1"]
    assert np.array_equal(commit["field"],np.array([restored[-1],*restored[3:-1]],float))
    assert commit["norm"]<=commit["tau"] and witness["commit"]["lambda_uncertainty"]>0.
    old=st["OldHistory42/Nominal5of128"]
    oldgap=abs(invariant(old["r"]))-old["tau"]
    assert oldgap>0.
    near(oldgap,pair_record["exactMeasurements"]["History42_5of128"]["minPairLInfChange_MPa"],2e-13)
    err=[]
    delta=[]
    target=5/128
    i43={}
    bracket=19/512
    for name,record in pred["Predictions"].items():
        r1=st["OldHistory42/Nominal1of32"]["r"]
        r2=old["r"]
        t=record["t"]
        forecast=r1+(t-1/32)/(target-1/32)*(r2-r1)
        r42=st[f"History42/{name}/Probe"]["r"]
        r43=st[f"History43/{name}/Probe"]["r"]
        err.append(peak(r42-forecast))
        delta.append(peak(r43-r42))
        i43[t]=invariant(r43)
    extrap=[abs(y+(target-x)/(bracket-x)*(i43[bracket]-y))-old["tau"] for x,y in i43.items() if x<bracket]
    exp=pair_record["conditionalPredictions"]["History43_5of128_from_new_history_secants"]
    near(min(extrap),min(x["minPairLInfChange_MPa"] for x in exp.values()),3e-13)
    near(max(extrap),max(x["minPairLInfChange_MPa"] for x in exp.values()),3e-13)
    assert max(err)<3e-10 and max(delta)<5e-10
    result={"workbook":witness["workbook"],"closed_native":stop,
            "mechanicsChecks":{"states":len(st),"stationsPerState":552,"forceRows":89,
                               "kinematicConstraints":4,"controlRows":1},
            "outcomes":outcomes,"selected":witness["commit"]["tag"],"selectedNorm_MPa":commit["norm"],
            "selectedQy_N":float(commit["field"][0]*1e5),"requiredPairChangeMeasured5of128_MPa":oldgap,
            "requiredPairChangePredicted5of128History43_MPa":[min(extrap),max(extrap)],
            "maxNativeInterpolationError_MPa":max(err),"maxNativeHistoryEffect_MPa":max(delta)}
    print(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False))

if __name__=="__main__":
    verify()
