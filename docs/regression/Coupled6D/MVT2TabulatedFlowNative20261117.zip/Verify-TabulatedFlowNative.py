"""Сверяет новый нативный закон точек и равновесие сечения MVT2."""

from argparse import ArgumentParser
from gzip import decompress
import json
from itertools import groupby
from math import fsum
from pathlib import Path
from re import findall
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


BOOK = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'
OLD_BALANCE = 'MVT2NativePublicationCutTimed20261117.zip'
OLD_SHA = 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A'
REVERSE = 'MVT2ReverseConcreteMaterial20261117.zip'
REVERSE_SHA = 'E22671B7D47DAD52C911C9C38207324F95276875D50AD60901CB0CB3F980D23D'
FOLLOW = 'MVT2NativePublicationCutFollow20261117.zip'
FOLLOW_SHA = '9F55DE3FC0B1B652DD1ED9683507423ADE4DF6AB3B008D9590EE1D9327F9864E'
TORQUES = (262750., 525500., 1051000., 2102000., 4204000., 6831500., 8670750., 10510000.)


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def receipt(root, scope, book, tools):
    """Сверяет конфигурацию, компиляцию шести модулей и завершение своего Excel."""
    meta = read(root/'Preparation.json')
    assert meta['scope']==scope and meta['source_book_sha256']==book
    assert meta['material_reference_sha256']==tools['SOURCE_SHA']
    inputs = ['Run-Native.ps1','Guard-IsolatedOffice.ps1',tools['TEST'],tools['MATERIAL'],'default.csv','ndm_uniaxial.csv']
    inputs.extend(f'src/Materials/{name}.cls' for name in (tools['BACKBONE'],tools['FLOW']))
    if scope=='Replay':
        inputs.append('Replay.Fields.csv')
    for filename in inputs:
        assert tools['digest']((root/filename).read_bytes()) == meta['inputs'][filename]
    compiler=read(root/'CodeUpdate.json')
    owner_path=root/'Native/MVTGaussMixed.txt'
    owner=read(owner_path.with_name(owner_path.name+'.Ownership.json'))
    closure=read(owner_path.with_name(owner_path.name+'.ProcessClosure.json'))
    transcript=owner_path.read_text(encoding='utf-8-sig')
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256']==book
    assert set(compiler['Modules'])=={
        'CCoupledSectionQuadrature','CCoupledElasticState','modTestMVT2GaussSpan','CCoupledConcreteResponse',
        tools['BACKBONE'],tools['FLOW']}
    assert compiler['WorkbookSHA256']==owner['SourceSHA256'] and owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    assert read(root/'CompileClosure.json')['State']=='Absent'
    assert 'RUNTIME ERROR:' not in transcript
    assert f'TEST_EXCEL_PROCESS: id={owner["PID"]}; startTicks={owner["StartTicksUTC"]}' in transcript
    if closure['Stage']=='AFTER_CHILD_EXIT':
        assert closure['Passed'] and closure['ChildExitCode']==0 and closure['RunnerCleanupValid']
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in transcript
        identity,final=closure['Closure']['Identity'],closure['Closure']['FinalState']
        scope_status='completed'
    else:
        assert scope=='Equilibrium' and closure['Stage']=='TIMEOUT'
        assert closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout']
        assert 'WATCHDOG_FAILURE: timeout=165 sec;' in transcript and 'ownExcelState=Absent' in transcript
        identity,final=closure['Identity'],closure['After']
        scope_status='timeout'
    assert identity['Valid'] and identity['PID']==owner['PID'] and identity['Ticks']==int(owner['StartTicksUTC'])
    assert final['State']=='Absent'
    return {'excel_pid':owner['PID'],'termination':scope_status}


def verify_material(repo, root, source, temporary, tools):
    """Вычисляет эталонные эффективные тензоры и сверяет VBA после отката проб."""
    outcome=receipt(root,'Replay',BOOK,tools)
    assert outcome['termination']=='completed'
    folder=temporary/'Effective'; folder.mkdir()
    for name in ('Compare-MVT2EffectiveFlow.py','MVT2EffectiveInitial.json','MVT2EffectiveFlow.json.gz'):
        (folder/name).write_bytes(source.read(name))
    utility=run_path(str(folder/'Compare-MVT2EffectiveFlow.py'))
    loaded=utility['read_inputs'](repo,folder)
    _,_,_,(_,rotate),_=loaded
    initial=read(folder/'MVT2EffectiveInitial.json')
    native=json.loads(decompress(source.read('MVT2EffectiveFlow.json.gz')))['material']
    replay=root/'Replay.Fields.csv'
    curves,reference_input=tools['source_wires'](repo)
    assert replay.read_bytes()==reference_input
    for file,data in curves.items(): assert (root/file).read_bytes()==data
    raw=(root/'Native/MaterialReplay.csv').read_text(encoding='ascii').splitlines()
    proofs={}
    for (mode,path), rows in groupby((line.split(';') for line in raw),lambda row: (row[0],row[1])):
        observations=list(rows)
        expected=native[mode][path]
        assert len(observations)==45*len(expected)
        prev=[initial[mode][:4]]*45
        max_nom=max_eff=max_history=max_damage=0.
        for step,fields in enumerate(expected,1):
            for p,(strain,nominal,total,plastic,damage) in enumerate(fields,1):
                row=observations[(step-1)*45+p-1]
                assert len(row)==26 and tuple(map(int,row[2:4]))==(step,p)
                incoming=tuple(map(float,row[4:10]))
                assert incoming==tuple(strain)
                ref_history,_,_,_=utility['update_asd'](nominal,total,plastic,damage,strain,prev[p-1],rotate)
                prev[p-1]=ref_history
                values=tuple(map(float,row[10:]))
                max_nom=max(max_nom,*map(abs,utility['minus'](values[:6],nominal)))
                max_eff=max(max_eff,*map(abs,utility['minus'](values[6:12],ref_history[0])))
                max_history=max(max_history,*map(abs,utility['minus'](values[12:14],total)))
                max_damage=max(max_damage,*map(abs,utility['minus'](values[14:],damage)))
        assert max_nom<4e-7 and max_eff<4e-7 and max_history<1e-11 and max_damage<4e-7, (
            mode,path,max_nom,max_eff,max_history,max_damage)
        proofs[mode,path]={'states':len(observations),'nominal_error_MPa':max_nom,'effective_error_MPa':max_eff,
                           'history_error':max_history,'damage_error':max_damage}
    check=(root/'Native/MVTGaussMixed.csv').read_text('ascii')
    report=findall(r'TABULATED_FLOW;(\w+);(\w+);(\d+);(\d+)',check)
    expected=[(m,n,len(rows),2*len(rows)) for m,paths in native.items() for n,rows in paths.items()]
    assert [(m,n,int(count),int(rejected)) for m,n,count,rejected in report]==expected
    assert list(proofs)==[(m,n) for m,n,_,_ in expected]
    seconds,=findall(r'CASE_FINISHED;MVTGaussMixed;True;([^\n]+)',check)
    return outcome | {'macro_seconds':float(seconds),'states':len(raw),'discarded_trials':sum(x[3] for x in expected),
                      'tensor_checks':{';'.join(key):v for key,v in proofs.items()}}


def equilibrium_material(frames, tables, points, mode, support):
    """Независимо повторяет бетон и идеально пластичную сталь на всех принятых полях VBA."""
    utility, backbone, raw_tables, initial, rotate = support
    laws=[backbone['Backbone'](raw_tables[mode][side],-30000.*p) for side,p in zip(
            ('T','C'),initial[mode][3],strict=True)]
    ratio=max(5.,max(laws[1].nominal)/max(laws[0].nominal))
    spectral=utility['spectral']; tensor=utility['tensor']; elastic=utility['elastic']; minus=utility['minus']
    zero=utility['ZERO']
    prior={(side,p):(zero,zero,(0.,0.),0.) for side in (0,1,-1) for p in points}
    centre_error=all_error=0.
    count=0
    for phase,(_,_,centre) in frames.items():
        field=tables['F'][phase]
        for side in (0,1,-1):
            for p,(_,_,_,*direction) in points.items():
                b=[tables['B'][p,j] for j in range(1,61)]
                eps=tuple(fsum((coef[k]+side*.001*coef[k+6])*v for coef,v in zip(b,field,strict=True)) for k in range(6))
                ep_old,eff_old,x_old,plastic_steel=prior[side,p]
                trial=tuple(a+b for a,b in zip(eff_old,elastic(minus(eps,ep_old)),strict=True))
                values,axes=spectral(trial,rotate)
                next_state=[law.step(x,backbone['equivalent'](values,ratio,j==0,laws[0].floor))
                            for j,(law,x) in enumerate(zip(laws,x_old,strict=True))]
                stress=tensor([v*next_state[int(v<0.)][1] for v in values],axes)
                effective=tensor([v*next_state[int(v<0.)][2] for v in values],axes)
                net=stress
                if p>25:
                    steel_strain=fsum(a*b for a,b in zip(direction,eps,strict=True))
                    fy=498. if p<=29 else 450.
                    steel=max(-fy,min(fy,200000.*(steel_strain-plastic_steel)))
                    plastic_steel=steel_strain-steel/200000.
                    net=tuple(steel*d-v for d,v in zip(direction,stress,strict=True))
                prior[side,p]=eps,effective,tuple(s[0] for s in next_state),plastic_steel
                count+=1
                if side==0:
                    centre_error=max(centre_error,max(map(abs,minus(stress,centre[p][6:]))))
                if (phase,side,p) in tables['H']:
                    all_error=max(all_error,max(map(abs,minus(net,tables['H'][phase,side,p]))))
    assert centre_error<8e-7 and all_error<8e-7,(centre_error,all_error)
    return {'count':count,'centre_nominal_error_MPa':centre_error,'all_net_stress_error_MPa':all_error}


def verify_balance(repo, root, stage, support, utilities, recovery, geometry, old, external, schedule):
    """Проверяет фактически принятый путь и сравнивает с общими точками OpenSees."""
    status=receipt(root,'Equilibrium',BOOK,stage)
    meta=read(root/'Preparation.json')
    expected=stage['matched_goals'](repo) if schedule=='Matched' else [2500.*i for i in range(1,33)]
    assert meta.get('force_schedule',schedule)==schedule and meta.get('requested_Qy_N',expected)==expected
    assert meta['controlled_material']=='tabulated:default'
    old_module, old_tables, old_proof=old
    code=(root/stage['TEST']).read_text(encoding='utf-8-sig')
    anchors=(
        (', dilation:=32#',''),
        ('If branch.SavedFieldCount < UBound(targets) - LBound(targets) + 1 Or twist <= 0# Then _',
         'If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _'),
        ('targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 8.67075, 10.51)',
         'targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 10.51)'),
        ('"MVT_PRELOAD_END;" & CStr(branch.SavedFieldCount) & ";10.51"','"MVT_PRELOAD_END;8;10.51"'),
    )
    if schedule=='Matched':
        anchors += ((stage['staged_goals'](expected),
                     '    ReDim goals(1 To 32)\n    For i = 1 To 32: goals(i) = 2500# * i: Next i'),)
    for anchor,original in anchors:
        assert anchor in code
        code=code.replace(anchor,original)
    assert code==old_module
    native=root/'Native'
    rows=[line.split(';') for line in (native/'MVTGaussMixed.csv').read_text('cp1251').splitlines()]
    assert recovery['geometry'](rows)==geometry
    points=geometry[1]
    _,_,area,radius=geometry[0]
    tables=utilities['read_operators']((native/'Operators.csv').read_bytes())
    frames=utilities['read_tensor_frames']((native/'MVTGaussMixed.Tensor.csv').read_bytes(),45)
    assert all(tables[key]==old_tables[key] for key in 'GLBSR')
    assert list(tables['F'])==list(frames)
    preload=[x for x in frames if x.startswith('R')]
    assert len(preload)==8 and [frames[x][:2] for x in preload]==[(t,0.) for t in TORQUES]
    torque_check=run_path(str(root.parent/'Verify-DilationEquilibrium.py'))['integrate_preload']
    scaled=(area,area*radius,area*radius,area*radius,area,area)
    preload_data=[]
    for label in preload:
        torque,_,stress=frames[label]
        field=tables['F'][label]
        resultant=torque_check(field,stress,geometry,tables)
        err=max(abs(a-b)/g for a,b,g in zip(resultant,(0.,0.,0.,torque,0.,0.),scaled,strict=True))
        assert err<=5e-7+5e-7*torque/scaled[3]
        preload_data.append({'phase':label,'T_Nmm':torque,'twist_rad_per_m':field[3]*1000./radius,
                             'force_error_MPa':err})
    demand, accepted={}, {}
    trial_rows=[x for x in rows if x[0]=='MVT2_CUT_TRIAL']
    assert [float(row[3]) for row in trial_rows]==expected[:len(trial_rows)]
    for row in rows:
        if row[0]=='MVT2_CUT_TRIAL':
            _,label,torque,q,moment,success,internal,code,*_=row
            q=float(q)
            assert (float(torque),float(moment))==(TORQUES[-1],-396.*q)
            assert (internal,code)==(('4','0') if success=='True' else ('6','10'))
            demand[label]={'Qy_N':q,'success':success=='True','logged_diagnostics':';'.join(row[8:])}
            if success=='True':
                accepted[label]=q
        elif row[0]=='MVT2_CUT_INSERTED':
            accepted[row[1]+'A'+row[2]]=float(row[2])
    mixed=[label for label in frames if label not in preload]
    assert set(mixed)==set(accepted) and len(tables['H'])==135*len(mixed)
    reference={float(p['Q_target_N']):p for p in external['result']['accepted'][8:]}
    equations=[]
    for label in mixed:
        t,q,_=frames[label]
        assert t==TORQUES[-1] and q==accepted[label]
        field=tables['F'][label]
        checks=recovery['equations'](label,frames[label],tables,geometry)
        section={'phase':label,'Qy_N':q,'kappaX_per_m':field[1]*1000./radius,
                 'twist_rad_per_m':field[3]*1000./radius,'equilibrium':checks}
        if q in reference:
            previous=reference[q]
            section['ASD_twist_rad_per_m']=previous['twist_rad_per_m']
            section['ASD_kappaX_per_m']=previous['field'][1]*1000./radius
        equations.append(section)
    finishes=[row for row in rows if row[0]=='CASE_FINISHED']
    if status['termination']=='completed':
        finish,=finishes
        _, _, successful, secs=finish
        status['macro_seconds']=float(secs)
        status['target_reached']=(successful=='True')
    else:
        assert not finishes
    assert all(a['Qy_N']<b['Qy_N'] for a,b in zip(equations,equations[1:]))
    assert old_proof['accepted'][-1]['Qy_N']==21875.
    return status | {'nominal_trials':list(demand.values()),'preload':preload_data,'mixed':equations,
                     'nonlinear_material':equilibrium_material(frames,tables,points,'default',support)}


def verify(repo,root,temporary):
    """Читает закреплённый эталон и независимо проверяет все нативные квитанции."""
    stage=run_path(str(root/'Stage-TabulatedFlowNative.py'))
    directory=repo/'docs/regression/Coupled6D'
    path=directory/stage['EVIDENCE']
    digest=stage['digest']
    assert digest(path.read_bytes())==stage['SOURCE_SHA']
    history=directory/REVERSE
    assert digest(history.read_bytes())==REVERSE_SHA
    baseline=directory/OLD_BALANCE
    assert digest(baseline.read_bytes())==OLD_SHA
    follow_file=directory/FOLLOW
    assert digest(follow_file.read_bytes())==FOLLOW_SHA
    follow={'__name__':'__pinned__'}
    with ZipFile(follow_file) as previous:
        exec(compile(previous.read('Verify-NativeFollow.py'),str(follow_file),'exec'),follow)
    utilities,recovery,_,_,_,mesh=follow['read_references'](repo)
    with ZipFile(baseline) as old:
        old_data=(old.read('modTestMVT2GaussSpan.bas').decode('utf-8-sig').replace('\r\n','\n'),
                 utilities['read_operators'](old.read('Native/Operators.csv')),
                 json.loads(old.read('NativePublicationCutProof.json')))
    ext_file=directory/stage['EXTERNAL']
    assert digest(ext_file.read_bytes())==stage['EXTERNAL_SHA']
    with ZipFile(ext_file) as external_wire:
        external=json.loads(external_wire.read('Cut396.json'))
    reference_base=directory/'MVT2NativePublicationCutMaterialHistory20261117.zip'
    assert digest(reference_base.read_bytes())=='6920EB24A5D01585E510FDBC1064513C0C83AA62583AEB0C2553D6F0D495EE55'
    with ZipFile(reference_base) as source, ZipFile(history) as reverse:
        cls=source.read(stage['MATERIAL'])
        tail=source.read('MaterialHistoryMethod.cls.txt').replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
        assert cls.endswith(tail)
        base=cls[:-len(tail)]
        addition=(root/'TabulatedConcreteIntegration.cls.txt').read_text(encoding='utf-8')
        for scope,stock in (('Replay',reverse.read(stage['MATERIAL'])),('Equilibrium',base),('Matched',base)):
            folder=root/scope
            assert read(folder/'Preparation.json')['material_before_overlay_sha256']==digest(stock)
            expected=stage['class_change'](stock,addition).replace('\n','\r\n').encode('utf-8')
            assert (folder/stage['MATERIAL']).read_bytes()==expected
    for scope in ('Replay','Equilibrium','Matched'):
        for name in (stage['BACKBONE'],stage['FLOW']):
            assert (root/scope/f'src/Materials/{name}.cls').read_text('utf-8') == (root/f'{name}.cls').read_text('utf-8')
    with ZipFile(path) as source:
        replay=verify_material(repo,root/'Replay',source,temporary,stage)
        flow=temporary/'Effective/Compare-MVT2EffectiveFlow.py'
        b=flow.with_name('Verify-MVT2BackboneReplay.py')
        b.write_bytes(source.read(b.name))
        raw=json.loads(source.read('MVT2ASDBackboneTables.json'))
        initial=json.loads(source.read('MVT2EffectiveInitial.json'))
    utility=run_path(str(flow))
    rotation=utility['read_inputs'](repo,temporary/'Effective')[3][1]
    support=(utility,run_path(str(b)),raw,initial,rotation)
    results={}
    for folder,schedule in (('Equilibrium','Nominal'),('Matched','Matched')):
        results[schedule]=verify_balance(repo,root/folder,stage,support,utilities,recovery,mesh,old_data,external,schedule)
    return {'replay':replay,'balanced':results}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args()
    with TemporaryDirectory(dir=args.report.resolve().parent) as temporary:
        proof=verify(args.repo.resolve(),args.root.resolve(),Path(temporary))
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(proof,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('MVT2 TABULATED VBA OFFLINE PASS',proof['replay']['states'],
          *(len(result['mixed']) for result in proof['balanced'].values()))
