"""Готовит изолированные повторы спектрального закона и равновесия MVT2."""

from argparse import ArgumentParser
from gzip import decompress
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
EVIDENCE = 'MVT2EffectivePlasticFlow20261117.zip'
SOURCE_SHA = '42D0340DACD7FE6E3A9BE3592DD6464219A6F58832F43061EC59999553E12220'
MATERIAL = 'src/Materials/CCoupledConcreteResponse.cls'
BACKBONE = 'CTestConcreteBackbone'
FLOW = 'CTestTabulatedConcreteFlow'
TEST = 'tests/modTestMVT2GaussSpan.bas'
FLOW_MODE = ('default','ndm_uniaxial')
EXTERNAL = 'MVT2PublicationCut20261117.zip'
EXTERNAL_SHA = '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD'


def digest(raw):
    return sha256(raw).hexdigest().upper()


def once(body, old, new):
    assert body.count(old) == 1, old
    return body.replace(old,new)


def writes(path, data, bom=False, validate_chars=True):
    if validate_chars:
        data.encode('cp1251')
    path.write_bytes(data.replace('\n','\r\n').encode('utf-8-sig' if bom else 'utf-8'))


def class_change(raw, addition):
    """Подключает опытный закон к существующему кэшу, касательной и буферам шагов."""
    code = raw.decode('utf-8-sig').replace('\r\n','\n')
    code = once(code,'    Plastic(1 To 6) As Double\n','    Plastic(1 To 6) As Double\n    TestEffective(1 To 6) As Double\n')
    marker = 'Private mReturn As CCoupledConcreteReturn'
    code = once(code,marker,marker+'\nPrivate mTestTabulatedFlow As CTestTabulatedConcreteFlow\nPrivate mTestFlowMode As String')
    marker = '    mPointCount = pointCount\n    ICoupledPointResponse_ClearHistory'
    code = once(code,marker,'''    mPointCount = pointCount
    Dim testTables As String: testTables = Environ$("NDM_MVT_FLOW_FOLDER")
    Set mTestTabulatedFlow = Nothing
    If LenB(testTables) <> 0 Then
        If LenB(mTestFlowMode) = 0 Then TestChooseTabulatedMode Environ$("NDM_MVT_FLOW_MODE")
        Set mTestTabulatedFlow = New CTestTabulatedConcreteFlow
        mTestTabulatedFlow.TestInitialize testTables & "\\" & mTestFlowMode & ".csv", modulus, poisson
    End If
    ICoupledPointResponse_ClearHistory''')
    marker = '    If Not moved Then\n        updated = committed'
    code = once(code,marker,'''    If Not moved And mTestTabulatedFlow Is Nothing Then
        updated = committed''')
    marker = '    initial.ElasticTangentExact = True'
    code = once(code,marker,'    initial.ElasticTangentExact = (mTestTabulatedFlow Is Nothing)')
    marker = '    If compression Then\n        mCompression.CopyCalibrationPoints'
    code = once(code,marker,'''    If Not mTestTabulatedFlow Is Nothing Then
        mTestTabulatedFlow.TestCopyCurve compression, strain, stress
        Exit Sub
    End If
    If compression Then
        mCompression.CopyCalibrationPoints''')
    marker = '        ByRef updated As TConcreteHistory, ByRef apparent() As Double, ByRef virginElastic As Boolean) As Boolean\n'
    code = once(code,marker,marker+'''    If Not mTestTabulatedFlow Is Nothing Then
        TestUpdateTabulatedPoint strain, committed, updated, apparent
        virginElastic = False
        UpdatePoint = True
        Exit Function
    End If
''')
    return code+addition


def source_wires(repo):
    """Закрепляет обе таблицы и точные деформации сравниваемых историй."""
    artifact=repo/'docs/regression/Coupled6D'/EVIDENCE
    assert digest(artifact.read_bytes())==SOURCE_SHA
    with ZipFile(artifact) as old:
        tables=json.loads(old.read('MVT2ASDBackboneTables.json'))
        initial=json.loads(old.read('MVT2EffectiveInitial.json'))
        material=json.loads(decompress(old.read('MVT2EffectiveFlow.json.gz')))['material']
    curves={}
    paths=[]
    for mode in FLOW_MODE:
        source=['ASDFlow1;30000;0.2']
        for branch,ip in zip(('T','C'),initial[mode][3],strict=True):
            points=list(zip(*tables[mode][branch],strict=True))
            source.append(f'BRANCH;{branch};{len(points)};{-30000.*ip!r}')
            source.extend(';'.join(map(repr,row)) for row in points)
        curves[f'{mode}.csv']=('\r\n'.join(source)+'\r\n').encode('ascii')
        for label,fields in material[mode].items():
            paths.append(f'PATH;{mode};{label};{len(fields)}')
            for step,field in enumerate(fields,1):
                for point,entry in enumerate(field,1):
                    paths.append(f'{step};{point};'+';'.join(map(repr,entry[0])))
    return curves, ('\r\n'.join(paths)+'\r\n').encode('ascii')


def matched_goals(repo):
    """Возвращает силы принятого внешнего маршрута без полей и подсказок."""
    path=repo/'docs/regression/Coupled6D'/EXTERNAL
    assert digest(path.read_bytes())==EXTERNAL_SHA
    with ZipFile(path) as archive:
        rows=json.loads(archive.read('Cut396.json'))['result']['accepted'][8:]
    loads=[row['Q_target_N'] for row in rows]
    assert len(loads)==33 and loads[-1]==75312.5 and all(a<b for a,b in zip(loads,loads[1:]))
    return loads


def staged_goals(goals):
    """Формирует читаемые присваивания цели по каждой принятой нагрузке."""
    result=[f'    ReDim goals(1 To {len(goals)})']
    result.extend(f'    goals({i}) = {q:g}#' for i,q in enumerate(goals,1))
    return '\n'.join(result)


def stage(repo, root, run, mode, pid, ticks, schedule):
    curves,replay=source_wires(repo)
    added=[]
    requested=None
    if run=='Replay':
        run_path(str(HERE/'Stage-ReverseMaterial.py'))['stage'](repo,root,pid,ticks)
        test=root/TEST
        body=test.read_text(encoding='utf-8-sig')
        body=once(body,'completed = TestReversedMVT2Material(report, tracePath)',
                  'completed = TestReplayTabulatedConcrete(report, tracePath)')
        body+=(HERE/'TabulatedConcreteReplay.bas.txt').read_text(encoding='utf-8')
        writes(test,body,bom=True)
        (root/'Replay.Fields.csv').write_bytes(replay)
        added.append('Replay.Fields.csv')
    else:
        run_path(str(HERE/'Stage-DilationEquilibrium.py'))['stage'](repo,root,32)
        test=root/TEST
        body=test.read_text(encoding='utf-8-sig')
        body=once(body,'targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 10.51)',
                  'targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 8.67075, 10.51)')
        body=once(body,'If branch.SavedFieldCount <> 8 Or twist <= 0# Then _',
                  'If branch.SavedFieldCount < UBound(targets) - LBound(targets) + 1 Or twist <= 0# Then _')
        body=once(body,'"MVT_PRELOAD_END;8;10.51"','"MVT_PRELOAD_END;" & CStr(branch.SavedFieldCount) & ";10.51"')
        requested = [2500.*i for i in range(1,33)]
        if schedule=='Matched':
            requested = matched_goals(repo)
            body=once(body,'    ReDim goals(1 To 32)\n    For i = 1 To 32: goals(i) = 2500# * i: Next i',
                      staged_goals(requested))
        writes(test,body,bom=True)
        guard=root/'Guard-IsolatedOffice.ps1'
        guard.write_bytes(once(guard.read_text('utf-8'),'$protected=@{',
                         f'$protected=@{{{pid}=[long]{ticks};').encode())
        added.append('Guard-IsolatedOffice.ps1')
    material=root/MATERIAL
    wp=material.read_bytes() if material.is_file() else (repo/MATERIAL).read_bytes()
    material.parent.mkdir(parents=True,exist_ok=True)
    addition=(HERE/'TabulatedConcreteIntegration.cls.txt').read_text(encoding='utf-8')
    addition.encode('cp1251')
    writes(material,class_change(wp,addition),validate_chars=False)
    for name in (BACKBONE,FLOW):
        filename=f'src/Materials/{name}.cls'
        writes(root/filename,(HERE/f'{name}.cls').read_text(encoding='utf-8'))
        added.append(filename)
    for filename,raw in curves.items():
        (root/filename).write_bytes(raw)
        added.append(filename)

    driver=root/'Run-Native.ps1'
    body=driver.read_text(encoding='utf-8')
    anchor="'CCoupledElasticState','modTestMVT2GaussSpan'"
    if run=='Equilibrium':
        anchor+=')'
        replacement=anchor[:-1]+",'CCoupledConcreteResponse')"
        body=once(body,anchor,replacement)
    body=once(body,"'CCoupledConcreteResponse')",f"'CCoupledConcreteResponse','{BACKBONE}','{FLOW}')")
    marker="$env:TMP=$env:TEMP"
    body=once(body,marker,marker+f'\n    $env:NDM_MVT_FLOW_FOLDER=$root\n    $env:NDM_MVT_FLOW_MODE=\'{mode}\'')
    tag='$tmpBefore=$env:TMP'
    body=once(body,tag,tag+'\n$flowBefore=$env:NDM_MVT_FLOW_FOLDER\n$modeBefore=$env:NDM_MVT_FLOW_MODE')
    body=once(body,'    $env:TMP=$tmpBefore','    $env:TMP=$tmpBefore\n    $env:NDM_MVT_FLOW_FOLDER=$flowBefore\n    $env:NDM_MVT_FLOW_MODE=$modeBefore')
    driver.write_bytes(body.encode('utf-8'))
    meta=root/'Preparation.json'
    manifest=json.loads(meta.read_bytes())
    manifest['controlled_material']=f'tabulated:{mode}'
    manifest['scope']=run
    if requested is not None:
        manifest['force_schedule']=schedule
        manifest['requested_Qy_N']=requested
    manifest['material_reference_sha256']=SOURCE_SHA
    manifest['material_before_overlay_sha256']=digest(wp)
    for filename in (TEST,MATERIAL,'Run-Native.ps1',*added):
        manifest['inputs'][filename]=digest((root/filename).read_bytes())
    meta.write_bytes((json.dumps(manifest,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',type=Path,required=True)
    parser.add_argument('--run',choices=('Replay','Equilibrium'),required=True)
    parser.add_argument('--mode',choices=FLOW_MODE,default='default')
    parser.add_argument('--schedule',choices=('Nominal','Matched'),default='Nominal')
    parser.add_argument('--guard-pid',type=int,required=True)
    parser.add_argument('--guard-ticks',type=int,required=True)
    args=parser.parse_args()
    stage(args.repo.resolve(),args.stage.resolve(),args.run,args.mode,args.guard_pid,args.guard_ticks,args.schedule)
