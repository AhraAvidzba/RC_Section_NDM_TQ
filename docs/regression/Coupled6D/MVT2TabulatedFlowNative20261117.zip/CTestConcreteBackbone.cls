VERSION 1.0 CLASS
BEGIN
  MultiUse = -1
END
Attribute VB_Name = "CTestConcreteBackbone"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подготовленная табличная ветвь бетона для проверки раздельного возврата.
' Входные ординаты передаются положительными в МПа для обоих знаков.

Private mStrain() As Double, mNominal() As Double, mEffective() As Double
Private mFloor As Double, mSearchTolerance As Double, mPeak As Double
Private mCount As Long

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает одну ветвь из ASCII, уже нормированную эталонным материалом.
Friend Sub TestRead(ByVal handle As Integer, ByVal expected As String)
    Dim row As String, parts() As String, i As Long, smallest As Double, spacing As Double
    Line Input #handle, row
    parts = Split(row, ";")
    If UBound(parts) <> 3 Then Err.Raise 5, , "Неверная шапка таблицы бетона."
    If parts(0) <> "BRANCH" Or parts(1) <> expected Then Err.Raise 5, , "Неверный знак таблицы бетона."
    mCount = CLng(Val(parts(2))): mFloor = Val(parts(3))
    If mFloor <= 0# Or mCount < 2 Then Err.Raise 5, , "Некорректные параметры таблицы бетона."
    ReDim mStrain(1 To mCount): ReDim mNominal(1 To mCount): ReDim mEffective(1 To mCount)
    For i = 1 To mCount
        Line Input #handle, row
        parts = Split(row, ";")
        If UBound(parts) <> 2 Then Err.Raise 5, , "Неверное число ординат таблицы бетона."
        mStrain(i) = Val(parts(0)): mNominal(i) = Val(parts(1)): mEffective(i) = Val(parts(2))
        If mNominal(i) > mPeak Then mPeak = mNominal(i)
        If i > 1 Then
            spacing = mStrain(i) - mStrain(i - 1)
            If spacing <= 0# Then Err.Raise 5, , "Нарушен порядок деформаций таблицы."
            If smallest = 0# Or spacing < smallest Then smallest = spacing
        ElseIf mStrain(i) <> 0# Or mNominal(i) <> 0# Or mEffective(i) <> 0# Then
            Err.Raise 5, , "Ветвь бетона должна начинаться в нуле."
        End If
    Next i
    If mPeak <= 0# Then Err.Raise 5, , "Таблица бетона не содержит положительной прочности."
    mSearchTolerance = smallest * 0.000001
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает максимальное номинальное напряжение подготовленной ветви.
Friend Property Get TestPeak() As Double
    TestPeak = mPeak
End Property

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает нижний табличный уровень напряжения для ухода от нулевой ординаты.
Friend Property Get TestFloor() As Double
    TestFloor = mFloor
End Property

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Интерполирует обе ординаты. За последней точкой сохраняет только положительный наклон.
Friend Sub TestStresses(ByVal strain As Double, ByRef nominal As Double, ByRef effective As Double)
    Dim left As Long, right As Long, middle As Long, span As Double, width As Double
    left = 2: right = mCount
    Do While left < right
        middle = (left + right) \ 2
        If strain <= mStrain(middle) + mSearchTolerance Then right = middle Else left = middle + 1
    Loop
    width = mStrain(right) - mStrain(right - 1)
    If strain <= mStrain(right) + mSearchTolerance Then
        span = (strain - mStrain(right - 1)) / width
        nominal = mNominal(right - 1) + span * (mNominal(right) - mNominal(right - 1))
        effective = mEffective(right - 1) + span * (mEffective(right) - mEffective(right - 1))
    Else
        span = (strain - mStrain(right)) / width
        nominal = mNominal(right) + span * GeomMax(0#, mNominal(right) - mNominal(right - 1))
        effective = mEffective(right) + span * GeomMax(0#, mEffective(right) - mEffective(right - 1))
    End If
    nominal = GeomMax(mFloor, nominal): effective = GeomMax(mFloor, effective)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Копирует реальные табличные узлы для подписи опытной одноосной диаграммы.
Friend Sub TestCopyCurve(ByVal direction As Double, ByRef strain() As Double, ByRef stress() As Double)
    Dim i As Long
    ReDim strain(1 To mCount): ReDim stress(1 To mCount)
    For i = 1 To mCount
        strain(i) = direction * mStrain(i): stress(i) = direction * mNominal(i)
    Next i
End Sub
