"""ДЛЯ ТЕСТОВ. Возвращает управление H после реально принятого половинного шага и события точки 6."""
from argparse import ArgumentParser
from hashlib import sha256
import json,re,struct
from pathlib import Path
from runpy import run_path
import numpy as np


def TestStage(root,parent):
    """Принимает точное двоичное поле события как 202-е состояние; следующие поля ищет неизменное рабочее ядро."""
    here=Path(__file__).resolve().parent
    original=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](parent/'Input/Reverse1.bin')
    assert len(original['fields'])==201
    native=np.frombuffer((parent/'Native/ExternalNativeResult.bin').read_bytes(),dtype='<f8')
    assert native.shape==(72,) and native[0]==native[1]==native[2]==1
    run_path(str(here/'Stage-TestWorkingControllerResume.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes());vector=run_path(str(here/'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    data=b'NDMREVTEST000001'+struct.pack('<i',60)
    for key in ('calibration','options','offset','direction'):data+=vector(original[key])
    data+=struct.pack('<i',202)
    for fraction,factor,field in zip(original['fractions'],original['lambdas'],original['fields']):data+=struct.pack('<dd',fraction,factor)+vector(field)
    data+=struct.pack('<dd',1.,native[4])+vector(native[12:])
    for values in (original['fields'][-1],native[12:],native[12:],original['offset']+native[4]*original['direction'],
        original['projection'],[native[4],0.,native[4],0.],np.zeros(4)):data+=vector(values)
    name='Input/Reverse1.bin';(root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    body=(here/'TestWorkingEnvelopeKernel.bas.txt').read_text('utf-8-sig')
    code,n=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert n==1
    methods=re.findall(r'(?im)^(?:Public|Private|Friend) (?:Function|Sub) (\w+)',code)
    assert len(methods)==len(set(v.lower() for v in methods))
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name,'TestWorkingEnvelopeKernel.bas.txt'):
        (root/name).write_bytes((here/name).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingHAfterPoint6Event',initial_history_states=202,
        actual_import_this_pass=['modTestCoupledElasticState'],fresh_compilation_claimed=True,
        source_classes_unchanged=True,selected_event_exact_Double=True,half_step_decimal_reconstructed=True,
        actual_material_histories_committed=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING H AFTER ACTUAL POINT6 EVENT READY; 202 INPUT STATES; ONE TEST MODULE IMPORT')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--parent',type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve())
