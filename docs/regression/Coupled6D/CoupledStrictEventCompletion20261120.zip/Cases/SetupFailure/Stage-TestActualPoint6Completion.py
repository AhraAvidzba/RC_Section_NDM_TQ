"""ДЛЯ ТЕСТОВ. Вызывает действующий TryCompletePrincipalTransition с реальной историей входящего события точки 6."""
from argparse import ArgumentParser
from hashlib import sha256
import json,re
from pathlib import Path
from runpy import run_path


def TestStage(root,parent):
    """Добавляет только восстановление проверенного тестового контекста и читающий вывод внутренних полушагов."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingControllerResume.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='tests/modTestCoupledElasticState.bas';code=(root/name).read_text('utf-8-sig')
    body=(here/'TestActualPoint6Completion.bas.txt').read_text('utf-8-sig')
    code,n=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert n==1
    methods=re.findall(r'(?im)^(?:Public|Private|Friend) (?:Function|Sub) (\w+)',code)
    assert len(methods)==len(set(v.lower() for v in methods)) and max(map(len,code.splitlines()))<1024
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name='src/Solver/CCoupledNewtonSolver.cls';code=(root/name).read_text('utf-8-sig')
    anchor='        If SpatialFieldDistance(doubled, outgoing) > YIELD_EVENT_HALF_ERROR * stepLength Then GoTo Unsuccessful';assert code.count(anchor)==1
    code=code.replace(anchor,'        modTestCoupledElasticState.TestRecordActualEventHalf face, outgoing, halfField, faceLambda, trialLambda, halfLambda, stepLength, SpatialFieldDistance(doubled, outgoing)\n'+anchor,1)
    code+='''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Восстанавливает контекст уже независимо проверенного и реально принятого события; поиск точки и входящую доводку этим методом не проверяют.
Friend Function TestRestoreVerifiedPoint6Transition(ByRef baseLoad() As Double, ByRef direction() As Double, _
        ByRef older() As Double, ByRef origin() As Double, ByVal originLambda As Double, ByVal faceLambda As Double, _
        ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double) As CCoupledPrincipalTransition
    If mCandidateReady Or mHybridActive Or Not mPrincipalTransition Is Nothing Then Err.Raise 5, , "Не завершён прежний контекст тестового события."
    If Not mUseSpatialHistory Or mAcceptedRevision < 1 Then Err.Raise 5, , "Нет принятой пространственной истории тестового события."
    ConfigureControlledLoad baseLoad, direction
    Dim station As TYieldStation: station.Point = 6: station.Side = -1
    Dim strain(1 To 6) As Double, unused(1 To 6) As Double, value As Double
    YieldStrain station.Point, station.Side, origin, strain
    If Not ReadTransitionValue(station, strain, value, unused, False) Or value >= 0# Then Err.Raise 5, , "Не подтверждена входящая сторона восстановленного события."
    Dim load(1 To 6) As Double, gap As Double, reference As Double
    SetControlledLoad originLambda, load: gap = 3# * EquilibriumTolerance(absoluteTolerance, relativeTolerance)
    reference = SpatialFieldDistance(older, origin)
    Dim prepared As New CCoupledPrincipalTransition
    prepared.Initialize mAcceptedRevision - 1, 6, -1, 0, -1#, gap, reference, faceLambda, faceLambda, origin, mAccepted, mAccepted
    If Not prepared.MatchesIncoming(mAcceptedRevision, mAccepted) Then Err.Raise 5, , "Не совпала принятая история восстановленного события."
    Set mPrincipalTransition = prepared: mPrincipalBaseLoad = baseLoad: mPrincipalLoadDirection = direction
    Set TestRestoreVerifiedPoint6Transition = prepared
End Function
'''
    assert max(map(len,code.splitlines()))<1024
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    compiler=(root/'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    compiler=compiler.replace("-ModuleNames 'modTestCoupledElasticState'","-ModuleNames @('CCoupledNewtonSolver','modTestCoupledElasticState')",1)
    name='Compile-TestActualPoint6Completion.ps1';(root/name).write_bytes(compiler.encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name,'TestActualPoint6Completion.bas.txt'):
        (root/name).write_bytes((here/name).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ActualWorkingPoint6Completion',actual_import_this_pass=['CCoupledNewtonSolver','modTestCoupledElasticState'],
        exact_existing_working_complete_method=True,working_1e12_scalar_and_half_error_criteria=True,
        event_context_restored_from_verified_history=True,automatic_event_selection_claimed=False,
        only_readonly_trace_added_inside_working_method=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('ACTUAL WORKING EVENT COMPLETION READY; VERIFIED INCOMING202; TWO TEST IMPORTS')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--parent',type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve())
