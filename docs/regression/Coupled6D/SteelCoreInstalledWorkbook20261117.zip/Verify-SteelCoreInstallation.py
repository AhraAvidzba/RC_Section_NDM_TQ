"""Проверяет установленную книгу, выгрузку и исходники по точной контрольной точке."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile


BASE_REV = '0081ce2aee08b83f49c74dbe9c7d95a991ebd327'
REV = '826221bfde2fef1e690c65745c0169ef4a342161'
PROOF = ('HardShearIntegratedSteelWorkbook20261117.zip','5E28B5A6CB9F49855708E91249A3370403A93461E325CDAEE41BB0520A63F9E1')
SOURCE = ('HardShearCoarseGrowthWorkbookRelease20261117.zip','6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63')


def digest(data):
    """Возвращает отпечаток проверяемых байтов."""
    return sha256(data).hexdigest().upper()


def pinned(repo, name, stamp, revision):
    """Читает точный текущий файл либо его точную историческую версию."""
    raw=(repo/name).read_bytes()
    if digest(raw)!=stamp:
        raw=check_output(['git','cat-file','blob',f'{revision}:{name}'],cwd=repo)
    assert digest(raw)==stamp,name
    return raw


def load_script(repo, entry, filename):
    """Подключает парсер фактического VBA из закреплённого архива."""
    path=repo/'docs/regression/Coupled6D'/entry[0]
    assert digest(path.read_bytes())==entry[1]
    env={'__name__':'__pinned__','__file__':filename}
    with ZipFile(path) as z:
        exec(compile(z.read(filename),filename,'exec'),env)
    return env


def verify(repo, root):
    """Подтверждает синхронизацию рабочей пары с исходниками и проверенным пакетом."""
    receipt=json.loads((root/'SteelCoreInstallation.json').read_bytes())
    archive=repo/'docs/regression/Coupled6D'/PROOF[0]
    assert digest(archive.read_bytes())==PROOF[1]==receipt['verified_native_archive']
    with ZipFile(archive) as z:
        package=json.loads(z.read('Package.json'))
        proof=json.loads(z.read('CleanSteelHardShearProof.json'))
        original_source={file:z.read(file) for file in ('src/Solver/CCoupledNewtonSolver.cls',
                        'src/Solver/CCoupledSteelCorrection.cls','src/Materials/CCoupledReinforcedResponse.cls')}
    assert receipt['installed_inputs']['workbook/output/RC_Section_NDM.xlsm']==package['candidate_sha256']
    assert receipt['installed_inputs']['workbook/output/VBA_All_Code.txt']==proof['code']['sha256']
    installed={file:pinned(repo,file,stamp,REV) for file,stamp in receipt['installed_inputs'].items()}
    stock=pinned(repo,'workbook/output/RC_Section_NDM.xlsm',receipt['previous_inputs']['workbook/output/RC_Section_NDM.xlsm'],BASE_REV)
    with ZipFile(BytesIO(installed['workbook/output/RC_Section_NDM.xlsm'])) as new, ZipFile(BytesIO(stock)) as old:
        names=new.namelist()
        assert names==old.namelist() and len(names)==122
        assert [name for name in names if old.read(name)!=new.read(name)]==['xl/vbaProject.bin']
        assert {name:digest(new.read(name)) for name in names}==package['parts']
    helper=load_script(repo,SOURCE,'Stage-Release.py')
    prior_dump=pinned(repo,'workbook/output/VBA_All_Code.txt',receipt['previous_inputs']['workbook/output/VBA_All_Code.txt'],BASE_REV)
    before=helper['components'](prior_dump)
    after=helper['components'](installed['workbook/output/VBA_All_Code.txt'])
    assert set(after)==set(before)|{'CCoupledSteelCorrection'} and len(after)==226
    changed=[name for name in before if before[name]!=after[name]]
    assert sorted(changed)==package['normalized_changed_modules']
    observer,parse=helper['parse_vba'](repo)
    _,embedded=parse(BytesIO(installed['workbook/output/RC_Section_NDM.xlsm']))
    normalize=observer['compiler_body']
    for file,expected in original_source.items():
        live=(repo/file).read_bytes().replace(b'\r\n',b'\n')
        if live!=expected.replace(b'\r\n',b'\n'):
            live=check_output(['git','cat-file','blob',f'{REV}:{file}'],cwd=repo)
        assert live.replace(b'\r\n',b'\n')==expected.replace(b'\r\n',b'\n')
        name=Path(file).stem
        assert normalize(live.decode('utf-8-sig'),name)[0]==normalize(embedded[name],name)[0]
    return {'checkpoint':REV,'installed_inputs':receipt['installed_inputs'],'native_assertions':proof['native']['assertions'],
            'results_states':proof['accepted_curve_states'],'components':226,'unchanged_modules':223,'unchanged_parts':121,
            'physical_limit_certified':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    proof=verify(a.repo,a.root)
    a.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('STEEL CORE INSTALLED PAIR VERIFIED 226 121 68')
