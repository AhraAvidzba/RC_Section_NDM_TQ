"""Устанавливает проверенные книгу и нативную выгрузку VBA с восстановлением при ошибке."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from os import replace
from pathlib import Path
from subprocess import check_output
from tempfile import NamedTemporaryFile
from zipfile import ZipFile


OLD = {'workbook/output/RC_Section_NDM.xlsm':'97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5',
       'workbook/output/VBA_All_Code.txt':'8F48A525BD7983304E7CB83874F4FBCE0F475C63ED4D210E2550353DE0F956EF'}
NEW = {'workbook/output/RC_Section_NDM.xlsm':('docs/regression/Audit03/RC_Section_NDM.xlsm',
                                          'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'),
       'workbook/output/VBA_All_Code.txt':('docs/regression/Audit03/VBA_All_Code.txt',
                                         'DB8023F9384B0059E1D1C51D59FE0E62F9B8CD94AC4D9B329DD0EE810AF676CC')}
PROOF = ('HardShearIntegratedSteelWorkbook20261117.zip','5E28B5A6CB9F49855708E91249A3370403A93461E325CDAEE41BB0520A63F9E1')
PROOF_FILE = ('CleanSteelHardShearProof.json','0D9B34C933F065673381AEF336FDC7EACE4E5461508E474688AC21B255E048EE')


def digest(data):
    """Сверяет полные байты установочного входа."""
    return sha256(data).hexdigest().upper()


def update(path, content):
    """Меняет один проверенный файл атомарным переименованием в его же каталоге."""
    with NamedTemporaryFile(dir=path.parent,prefix='ndm-steel-core-',delete=False) as stream:
        staged=Path(stream.name)
        stream.write(content)
    try:
        replace(staged,path)
    finally:
        staged.unlink(missing_ok=True)


def install(repo, candidate, receipt):
    """Проверяет исходники, сохранённый Results и устанавливает согласованную пару файлов."""
    assert check_output(['git','branch','--show-current'],cwd=repo).strip()==b'codex/coupled-6d'
    assert not check_output(['git','status','--porcelain'],cwd=repo).strip()
    archive=repo/'docs/regression/Coupled6D'/PROOF[0]
    assert digest(archive.read_bytes())==PROOF[1]
    with ZipFile(archive) as z:
        raw=z.read(PROOF_FILE[0])
        assert digest(raw)==PROOF_FILE[1]
        proof=json.loads(raw)
        assert proof['accepted_curve_states']==68 and proof['maximum_curve_difference']==0.
        assert proof['native']['assertions']==28 and not proof['physical_limit_certified']
        for code in ('src/Solver/CCoupledNewtonSolver.cls','src/Solver/CCoupledSteelCorrection.cls',
                     'src/Materials/CCoupledReinforcedResponse.cls'):
            assert (repo/code).read_bytes().replace(b'\r\n',b'\n')==z.read(code).replace(b'\r\n',b'\n')
    assert proof['candidate_sha256']==NEW[next(iter(NEW))][1] and proof['code']['sha256']==NEW[list(NEW)[1]][1]
    work=[]
    for name,(stage_name,expected) in NEW.items():
        file=(repo/name).resolve()
        assert file.is_relative_to(repo) and file==repo/name
        old,new=file.read_bytes(),(candidate/stage_name).read_bytes()
        assert digest(old)==OLD[name] and digest(new)==expected
        work.append((file,old,new,expected))
    applied=[]
    try:
        for file,old,new,expected in work:
            assert file.read_bytes()==old
            update(file,new)
            applied.append((file,old))
            assert digest(file.read_bytes())==expected
    except BaseException:
        for file,old in reversed(applied): update(file,old)
        raise
    result={'installed_inputs':{str(p.relative_to(repo)).replace('\\','/'):expected for p,_,_,expected in work},
            'previous_inputs':OLD,'verified_native_archive':PROOF[1],'physical_limit_certified':False}
    receipt.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode('utf-8'))
    print('STEEL CORE WORKBOOK INSTALLED',result['installed_inputs'])


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--candidate',type=Path,required=True)
    p.add_argument('--receipt',type=Path,required=True)
    a=p.parse_args()
    install(a.repo.resolve(),a.candidate.resolve(),a.receipt.resolve())
