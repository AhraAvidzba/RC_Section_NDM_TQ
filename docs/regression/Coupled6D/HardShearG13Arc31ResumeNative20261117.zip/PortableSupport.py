"""Восстанавливает исходную запись ARC31Resume из двух закреплённых архивов."""

from base64 import b64decode, b64encode
from hashlib import sha256
import json
from zipfile import ZipFile

BASE56='6CA5C64823399B7385635AA50F31C132A221164C47DE8D8E96B42DBC23037318'
BASE31='645D47A4E2792F0B60FF9E4998B9653FD7047CB719D9F5CFC844FDA58BFDA058'
FIXTURE='A6CEB5C7BF37D852E2768BE33617173C03B4EB508A3C8C9B0D210BD5B849EF57'
TRACE='Native/Order10/HardG14Direction.csv'
REPORT='Native/Order10/Verification.json'
CODE='docs/regression/CodeUpdate.json'
DELTA='Native/Order10/TraceDeltaResume.json'
SUMS='SHA256SUMS.json'
REFERENCES={
    'Preceding56/HardG14Direction.csv':(56,TRACE),
    'Preceding31/Verification.json':(31,REPORT),
    'Preceding31/TraceDelta.json':(31,'Native/Order10/TraceDelta.json'),
}


def sha(raw):
    return sha256(raw).hexdigest().upper()


def json_bytes(value):
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')


def fixture(raw):
    assert sha(raw)==FIXTURE
    spec=json.loads(raw)
    assert spec['preceding_arc31_sha256']==BASE31
    return spec


def read_zip(path,expected):
    assert sha(path.read_bytes())==expected
    with ZipFile(path) as archive:
        return {name:archive.read(name) for name in archive.namelist()}


def read_baselines(arc56,arc31):
    return {56:read_zip(arc56,BASE56),31:read_zip(arc31,BASE31)}


def trace_delta(old,new):
    a,b=(part.splitlines(keepends=True) for part in (old,new))
    prefix=0
    while prefix<min(len(a),len(b)) and a[prefix]==b[prefix]:
        prefix+=1
    suffix=0
    while suffix<min(len(a),len(b))-prefix and a[-suffix-1]==b[-suffix-1]:
        suffix+=1
    middle=b[prefix:len(b)-suffix]
    assert prefix>10000 and 0<len(middle)<40 and sum(map(len,middle))<70000
    return dict(old_sha256=sha(old),new_sha256=sha(new),old_lines=len(a),new_lines=len(b),
                prefix_lines=prefix,suffix_lines=suffix,
                middle=b64encode(b''.join(middle)).decode('ascii'))


def restore_trace(old,delta):
    lines=old.splitlines(keepends=True)
    prefix,suffix=delta['prefix_lines'],delta['suffix_lines']
    assert sha(old)==delta['old_sha256'] and len(lines)==delta['old_lines']
    assert 0<=suffix<=len(lines)-prefix and 10000<prefix<=len(lines)
    middle=b64decode(delta['middle'],validate=True)
    result=b''.join(lines[:prefix])+middle+b''.join(lines[len(lines)-suffix:])
    assert sha(result)==delta['new_sha256'] and len(result.splitlines())==delta['new_lines']
    assert trace_delta(old,result)==delta
    return result


def inherited(spec,baselines):
    for name,expected in spec['inputs'].items():
        origin,path=REFERENCES.get(name,(56,name))
        raw=baselines[origin].get(path)
        if raw is not None and sha(raw)==expected:
            yield name,raw
    for name,digest in spec['production'].items():
        path='Production/'+name
        raw=baselines[56][path]
        assert sha(raw)==digest
        yield path,raw


def restore_files(delta_pack,baselines):
    existing=dict(inherited(fixture(delta_pack['Fixture.json']),baselines))
    assert existing.keys().isdisjoint(delta_pack) and TRACE not in delta_pack
    files={**existing,**delta_pack}
    for name,digest in fixture(files['Fixture.json'])['inputs'].items():
        assert sha(files[name])==digest,name
    files[TRACE]=restore_trace(baselines[56][TRACE],json.loads(delta_pack[DELTA]))
    return files
