"""Собирает один контрольный повтор ARC31 и максимум один обычный следующий шаг."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/'tmp/hs-arc56/proof/HardShearG13SerialArcAttempt14DirectionNative20261117.zip'
BASE_SHA='6CA5C64823399B7385635AA50F31C132A221164C47DE8D8E96B42DBC23037318'
ARC31_SHA='645D47A4E2792F0B60FF9E4998B9653FD7047CB719D9F5CFC844FDA58BFDA058'
ARC31_REPORT='93AA9AD5BEB2D9F5F8E9169DDF01DB47EAF70E0A411D90C44472560B345DEAAE'
ARC31=ROOT/'tmp/hs-p31/proof/HardShearG13ArcAttempt14HoldP31Native20261117.zip'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'
MACROS='tests/modTestCoupledElasticState.bas'
TRACE='Native/Order10/HardG14Direction.csv'
REPORT='Native/Order10/Verification.json'

def sha(raw):
    return sha256(raw).hexdigest().upper()

def txt(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')

def once(src,before,after):
    assert src.count(before)==1,before
    return src.replace(before,after)

def seal(dest,name,data):
    out=dest/name
    out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():
        assert out.read_bytes()==data,name
    else:
        out.write_bytes(data)
    return sha(data)

def packed(tokens):
    assert len(tokens)==60 and all(len(token)==16 for token in tokens)
    hexstr=''.join(tokens)
    chunks=[hexstr[i:i+160] for i in range(0,len(hexstr),160)]
    return '\n'.join('    packed = '+('packed & ' if chunk else '')+'"'+part+'"' for chunk,part in enumerate(chunks))

def line(rows,prefix):
    selected=[r.split(';')[1:] for r in rows if r.startswith(prefix+';')]
    assert len(selected)==1,(prefix,len(selected))
    return selected[0]

def compose(raw,expected):
    src=txt(raw)
    src=once(src,'                        trialEquation, trialFraction, norm, tolerance\n                    Exit Function\n                End If\n                If mHardG14ArmedTest',
             '                        trialEquation, trialFraction, norm, tolerance\n'
             '                    SolveStep = RestoreHardArc31Test(current, currentLambda, absoluteTolerance, relativeTolerance)\n'
             '                    Exit Function\n                End If\n                If mHardG14ArmedTest')
    src=once(src,'    Next attempt\n    If Not ReplayAcceptedFields(history, 25) Then Exit Function',
        '        If attempt = 15 Then outcome = "SINGLE_STOCK_PROBE": Exit For\n'
        '    Next attempt\n    If Not ReplayAcceptedFields(history, 25) Then Exit Function')
    guards=[]
    for expected_key,variable in (('anchor','current'),('origin','origin'),('projection','mControlProjection')):
        guards.append(packed(expected[expected_key]))
        guards.append('    If Replace(HardRankVectorTest('+variable+'), ";", vbNullString) <> packed Then GoTo NoRecovery')
    guards.extend('    If HardRankBitsTest('+key+') <> "'+value+'" Then GoTo NoRecovery' for key,value in
                  [('lambda',expected['base_lambda']),('mTargetControl',expected['target'])])
    hooks=txt((HERE/'Candidate.bas').read_bytes()).replace('@VBA_GUARD@','\n'.join(guards)).replace(
        '@VBA_CANDIDATE@',packed(expected['field'])).replace('@FACTOR@',expected['candidate_lambda'])
    assert max(map(len,hooks.splitlines()))<220 and hooks.encode('cp1251')
    return (src.rstrip()+'\n\n'+hooks.rstrip()+'\n').replace('\n','\r\n').encode()

def verifier(raw):
    src=txt(raw)
    src=once(src,'import ExtendedProof as extra','import ExtendedProof as extra\nimport ResumeProof as resume')
    src=once(src,'    row56.inputs(fixture, extract)','    row56.inputs(fixture, extract)\n    resume.inputs(fixture, extract)')
    src=once(src,"        if line.startswith('ARC56-'):","        if line.startswith(('ARC56-','ARC31-')):")
    src=once(src,"{'ATTEMPT_LIMIT','MINIMUM_RADIUS','STEP_LIMIT','TIME_LIMIT','NO_SECANT'}","{'MINIMUM_RADIUS','SINGLE_STOCK_PROBE'}")
    src=once(src,"    result['attempt14_direction']=row56.verify(fixture, extract, path, records, geometry, weights, steps)",
                  "    result['arc31_follow_on']=resume.verify(path,extract,steps,final,accepted,geometry)")
    return src.encode()

def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready')
    cli.add_argument('--with-workbook',action='store_true')
    args=cli.parse_args()
    dest=args.destination.resolve()
    assert dest.is_relative_to(HERE) or dest.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(BASE.read_bytes())==BASE_SHA and sha(ARC31.read_bytes())==ARC31_SHA
    files={}
    with ZipFile(BASE) as base, ZipFile(ARC31) as arc31:
        plan=json.loads(base.read('Fixture.json'))
        report=arc31.read(REPORT)
        assert sha(report)==ARC31_REPORT and json.loads(report)['hold_p31_minus']['trials'][0]['balanced_same_p31_branch']
        delta=json.loads(arc31.read('Native/Order10/TraceDelta.json'))
        from base64 import b64decode
        new=[b64decode(word,validate=True) for part in delta['inserts'] for word in part['lines']]
        new=[row.decode('ascii').strip() for row in new]
        old=base.read(TRACE).decode('cp1251').splitlines()
        stock=next(i for i,row in enumerate(old) if row.startswith('ARC56-DIR-SAMPLE;STOCK;0000000000000000;'))
        arc=next(i for i,row in enumerate(new) if row.startswith('ARC31-TRY;3FF0000000000000;'))
        field=line(new[arc:arc+7],'ARC31-TRIAL')
        expected=dict(
            origin=line(new,'ARC31-FIELD'),field=field,anchor=line(old,'ARC56-ANCHOR'),
            projection=line(old,'ARC56-CONTROL-PROJECTION'),target=line(old,'ARC56-CONTROL-TARGET')[0],
            base_lambda=line(new,'ARC31-BASE')[0],candidate_lambda=new[arc].split(';')[2],
        )
        assert expected['origin']==old[stock+1].split(';')[1:]
        for name,raw in [('Preceding56/HardG14Direction.csv',base.read(TRACE)),('Preceding31/Verification.json',report),
                         ('Preceding31/TraceDelta.json',arc31.read('Native/Order10/TraceDelta.json')),
                         ('Candidate.json',(json.dumps(expected,indent=2)+'\n').encode())]:
            files[name]=seal(dest,name,raw)
        book=(ROOT/plan['workbook']).read_bytes()
        assert sha(book)==plan['source_workbook_sha256']
        for name,digest in plan['inputs'].items():
            raw=base.read(name)
            assert sha(raw)==digest,name
            if name=='Stage.py':
                continue
            if name==SOLVER:
                raw=compose(raw,expected)
            elif name==MACROS:
                code=txt(raw)
                for method in ('Function HardRankValueTest','Sub HardRankUnpackTest'):
                    code=once(code,'Private '+method,'Public '+method)
                raw=code.replace('\n','\r\n').encode()
            elif name=='Verify.py':
                raw=verifier(raw)
            elif name=='Run.ps1':
                raw=txt(raw).replace('HardArc56','HardArc31Resume').encode()
            files[name]=seal(dest,name,raw)
        for name in ('Assemble.py','Candidate.bas','ResumeProof.py'):
            files[name]=seal(dest,name,(HERE/name).read_bytes())
        if args.with_workbook:
            seal(dest,plan['workbook'],book)
            seal(dest,'docs/regression/Diagnostic.xlsm',book)
            for name in ('Native/Order10','Temp'):
                (dest/name).mkdir(parents=True,exist_ok=True)
    result={**plan,'inputs':files,'watchdog_seconds':215,'preceding_arc31_sha256':ARC31_SHA,
            'scope':'one exact ARC31 recorded check, standard serial grant and one subsequent stock attempt, final rollback'}
    print(dest,seal(dest,'Fixture.json',(json.dumps(result,indent=2)+'\n').encode()))

if __name__=='__main__':
    main()
