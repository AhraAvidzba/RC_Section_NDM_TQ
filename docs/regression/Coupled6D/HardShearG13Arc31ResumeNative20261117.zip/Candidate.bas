' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторно подтверждает точную пробу ARC31 на той же истории и мере управления.
' Принятие материала и контролируемый пробный шаг оставляет обычным воротам дуги.
Private Function RestoreHardArc31Test(ByRef origin() As Double, ByVal lambda As Double, _
        ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double) As Boolean
    Dim packed As String, field() As Double, current() As Double, candidateLambda As Double, tolerance As Double
    Dim load(1 To COMPONENT_COUNT) As Double, norm As Double, position As CCoupledReinforcedResponse
    Dim localStrain(1 To COMPONENT_COUNT) As Double, gradient(1 To COMPONENT_COUNT) As Double
    Dim value As Double, plastic As Boolean, principal As Long, substeps As Long
    CopyAccepted current
@VBA_GUARD@
    candidateLambda = HardRankValueTest("@FACTOR@")
@VBA_CANDIDATE@
    HardRankUnpackTest packed, field
    SetControlledLoad candidateLambda, load
    tolerance = EquilibriumTolerance(absoluteTolerance, relativeTolerance)
    If Not Evaluate(field, False, recordTrial:=False) Then GoTo NoRecovery
    If EquilibriumNorm(load, field) > tolerance Or Not GaugesVerified(tolerance) Then GoTo NoRecovery
    Set position = YieldResponse(-1)
    YieldStrain 31, -1, field, localStrain
    If Not position.TryReadTrialYield(31, localStrain, value, gradient, False) Then GoTo NoRecovery
    If Not position.TryReadConcreteBranch(31, localStrain, plastic, principal, substeps) Then GoTo NoRecovery
    If value <= 0# Or Not plastic Or principal <> 1 Or substeps <> 1 Then GoTo NoRecovery
    If Not Evaluate(field, False) Then GoTo NoRecovery
    norm = EquilibriumNorm(load, field)
    If norm > tolerance Or Not GaugesVerified(tolerance) Then GoTo NoRecovery
    mCandidate = field: mIterations = mIterations + 1: mWrongControlDirection = False
    PublishCandidate candidateLambda
    WriteHardRankRowTest "ARC31-RETRY;RECHECKED;" & HardRankBitsTest(candidateLambda) & ";" & _
        HardRankBitsTest(norm) & ";" & HardRankBitsTest(tolerance) & ";" & HardRankBitsTest(value)
    RestoreHardArc31Test = True
    Exit Function
NoRecovery:
    DiscardStep
    WriteHardRankRowTest "ARC31-RETRY;REFUSED"
End Function
