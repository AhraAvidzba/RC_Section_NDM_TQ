"""Пересчитывает условия приёмки и точность знакового приращения множителя."""
from math import isclose
from pathlib import Path

import PriorVerify as prior

HERE=Path(__file__).resolve().parent
PRECEDING='93AA9AD5BEB2D9F5F8E9169DDF01DB47EAF70E0A411D90C44472560B345DEAAE'


def inputs(fixture,extract):
    before=HERE/'Preceding56/HardG14Direction.csv'
    assert prior.file_hash(before)=='FA02F66488C612238C74228C22562569EC4422197EF3FFF3696D843F84067FDF'
    _,_,_,steps,_,final=extract(before)
    assert len(steps)==14 and final==['MINIMUM_RADIUS','9','9744']
    witness=HERE/'Preceding31/Verification.json'
    assert prior.file_hash(witness)==PRECEDING
    actual=prior.read(witness)['hold_p31_minus']['trials'][0]
    candidate=prior.read(HERE/'Candidate.json')
    assert actual['fraction']==1. and actual['balanced_same_p31_branch']
    assert actual['lambda']==prior.number(candidate['candidate_lambda'])
    assert candidate['anchor']==steps[10]['TRACE-COMMIT'] and candidate['projection']==steps[13]['TRACE-PROJECTION']
    assert candidate['target']==steps[13]['args'][3]


def difference(previous,new):
    a,b=previous['lambda'],new['lambda']
    width=previous['lambda_uncertainty']+new['lambda_uncertainty']
    low,high=(b-a)-width,(b-a)+width
    return dict(nominal=b-a,low=low,high=high,sign=1 if low>0 else -1 if high<0 else 0)


def verify(path,extract,steps,final,accepted,geometry):
    source=path.read_text(encoding='cp1251').splitlines()
    oldPath=HERE/'Preceding56/HardG14Direction.csv'
    old=oldPath.read_text(encoding='cp1251').splitlines()
    assert [line for line in source if line.startswith('ARC56-')]==[line for line in old if line.startswith('ARC56-')]
    _,_,_,before,_,_=extract(oldPath)
    assert steps[:13]==before[:13]
    assert steps[13]['args'][:7]==before[13]['args'][:7]
    assert all(steps[13][k]==before[13][k] for k in ('TRACE-PROJECTION','TRACE-SEED'))
    rows=[line for line in source if line.startswith('ARC31-')]
    assert len(rows)==1
    key,decision,*details=rows[0].split(';')
    assert key=='ARC31-RETRY' and decision in {'RECHECKED','REFUSED'}
    case=steps[13]['TRACE-DECISION'][0]
    probe=steps[14]['TRACE-DECISION'][0] if len(steps)==15 else None
    result=dict(exact_13_previous_trials=True,same_34_fields_before_retry=True,restored_original_history_words=9744,
                attempt14=case,native_recheck=decision,stock_attempt15=probe,
                attempt14_lambda_difference_interval=None,stock15_lambda_difference_interval=None,
                physical_limit_certified=False)
    if decision=='REFUSED':
        assert not details and case=='REFUSED'
    else:
        factor,norm,tau,value=prior.numbers(details)
        chosen=prior.read(HERE/'Candidate.json')
        witness=prior.read(HERE/'Preceding31/Verification.json')['hold_p31_minus']['trials'][0]
        assert factor==prior.number(chosen['candidate_lambda']) and steps[13]['TRACE-FIELD']==chosen['field']
        assert norm<=tau and value>0 and value==witness['F_MPa']
        assert isclose(norm,witness['norm_MPa'],rel_tol=1e-11) and tau==witness['tau_MPa']
        scales=prior.numbers(geometry['MESH'][-3:])
        area,length=scales[:2]
        result['attempt14_signed_normalized_force_error_MPa']=[(a-b)/s for a,b,s in zip(
            prior.numbers(steps[13]['TRACE-WRENCH']),prior.numbers(steps[13]['TRACE-LOAD']),
            (area,area*length,area*length,area*length,area,area),strict=True)]
    if case=='ACCEPTED':
        assert decision=='RECHECKED' and probe is not None and final[0]=='SINGLE_STOCK_PROBE'
        assert len(steps)==15 and steps[13]['TRACE-COMMIT']==steps[13]['TRACE-FIELD']
        assert [r['attempt'] for r in accepted[-2 if probe!='ACCEPTED' else -3:]][:2]==[11,14]
        last={r['attempt']:r for r in accepted}
        result['attempt14_lambda_difference_interval']=difference(last[11],last[14])
        if probe=='ACCEPTED':
            result['stock15_lambda_difference_interval']=difference(last[14],last[15])
    else:
        assert final[0]=='MINIMUM_RADIUS' and len(steps)==14 and final[1]=='9' and probe is None
    return result
