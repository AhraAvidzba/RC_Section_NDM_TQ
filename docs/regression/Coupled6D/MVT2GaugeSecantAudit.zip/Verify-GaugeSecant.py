"""Verify the MVT2 post-peak secant test on stored fields and one synthetic trial."""

import argparse
import csv
from dataclasses import dataclass, replace
from hashlib import sha256
import io
import json
import math
from pathlib import Path
import re
from zipfile import ZipFile

SOURCE_SHA256 = "1ACA0DF0DA6485E58D359A0E6BC7A2849F8EDDE15D606576FE5D85F710594F93"
ARCHIVES = {
    "coarse": ("MVT2ControlledOffline.zip", "FAD3D91F3698D726CB871EF4D3F5F7952BF6E8D8B2F9C5024BDB87573B2217B2"),
    "refined": ("MVT2TurnOffline.zip", "5220E9613EB633B07C06CF9A270DB1F89340B718E319B0F882A7D84B194600A9"),
}
KANI_WARP_MU_MPA = -5.66313495971864e-7
KANI_SOURCE = ("KaniV4GaugeProjection/ScalarGaugeFit.json",
               "C5320C5E2BAB685444C8474DC477596E083378E4409F32170A3363B93F2FE621",
               "rows/Frozen/5/Fit/WarpMuChange_MPa")

@dataclass(frozen=True)
class Point:
    name: str
    coordinate: float
    load: float
    field: tuple

def digest(value):
    return sha256(value).hexdigest().upper()

def read_trace(path, hash_expected, kind, count):
    assert digest(path.read_bytes()) == hash_expected
    with ZipFile(path) as archive:
        raw = archive.read("Native/MVT2.csv")
    trace = csv.reader(io.StringIO(raw.decode("cp1251")), delimiter=";")
    accepted, fields = [], {}
    for tag, *columns in trace:
        if tag == "MVT2_CONTROL_FIELD":
            name, *values = columns
            assert name not in fields and len(values) == 60
            fields[name] = tuple(float(value) for value in values)
            assert all(map(math.isfinite, fields[name]))
        if kind == "coarse" and tag == "MVT2_CONTROL_ACCEPT":
            attempt, load, coordinate, *_ = columns
            accepted.append((attempt, float(coordinate), float(load)))
        if kind == "refined" and tag == "MVT2_TURN_ACCEPT":
            attempt, _, _, coordinate, load, *_ = columns
            accepted.append(("Turn"+attempt, float(coordinate), float(load)))
    assert len(accepted) == count and all(fields["Projection"][index] == 0 for index in range(56, 60))
    points = [Point(name, coordinate, load, fields[name]) for name, coordinate, load in accepted]
    for point in points:
        coordinate = math.fsum(x * y for x, y in zip(point.field, fields["Projection"], strict=True))
        assert abs(coordinate - point.coordinate) <= 2e-14
    return points, digest(raw)

def field_term(left, current, trial, ratio, first, last, relative_tolerance):
    expected = [ratio * (current[i] - left[i]) for i in range(first,last)]
    deviation = [(trial[i] - current[i]) - expected[i-first] for i in range(first,last)]
    max_expected = max(map(abs,expected))
    max_deviation = max(map(abs,deviation))
    return {"max_expected": max_expected, "max_deviation": max_deviation,
            "max_expected_coordinate": first + 1 + max(range(len(expected)), key=lambda i: abs(expected[i])),
            "max_deviation_coordinate": first + 1 + max(range(len(deviation)), key=lambda i: abs(deviation[i])),
            "allowed_deviation": relative_tolerance * max_expected,
            "passes": max_expected > 0 and max_deviation <= relative_tolerance * max_expected}

def comparison(left, current, trial, relative_tolerance, load_resolution_coefficient):
    spacing = current.coordinate - left.coordinate
    assert spacing > 0 and trial.coordinate > current.coordinate and trial.load > 0
    ratio = (trial.coordinate-current.coordinate)/spacing
    expected_load = ratio * (current.load-left.load)
    deviation = abs(trial.load-current.load-expected_load)
    resolution = load_resolution_coefficient*(1+abs(current.load))
    load_descends = expected_load < -resolution
    load_close = deviation <= relative_tolerance * abs(expected_load)
    args = left.field, current.field, trial.field, ratio
    all_coordinates = field_term(*args, 0, 60, relative_tolerance)
    mechanical = field_term(*args, 0, 56, relative_tolerance)
    multipliers = field_term(*args, 56, 60, relative_tolerance)
    return {
        "fields": [point.name for point in (left,current,trial)], "coordinate_ratio": ratio,
        "load": {"expected_change_kN": expected_load, "deviation_kN": deviation,
                 "resolution_kN": resolution, "allowed_deviation_kN": relative_tolerance * abs(expected_load),
                 "descending_gate": load_descends, "secant_gate": load_close},
        "last_field_test": {"all_60": all_coordinates, "mechanical_56": mechanical, "multipliers_4": multipliers},
        "whole_criterion": {"all_60": load_descends and load_close and all_coordinates["passes"],
                            "mechanical_56": load_descends and load_close and mechanical["passes"]},
    }

def synthetic_trials(sequences, relative_tolerance, load_resolution_coefficient):
    rows, total, load_pass = [], 0, 0
    for kind, sequence in sequences.items():
        for left,current in zip(sequence, sequence[1:]):
            if current.load >= left.load:
                continue
            for ratio in (.5, 1., 1.25):
                trial_field = tuple(y + ratio*(y-x) for x,y in zip(left.field,current.field,strict=True))
                trial = Point("linear extrapolation", current.coordinate+ratio*(current.coordinate-left.coordinate),
                              current.load+ratio*(current.load-left.load), trial_field)
                before = comparison(left,current,trial,relative_tolerance,load_resolution_coefficient)
                total += 1
                load_pass += before["load"]["descending_gate"] and before["load"]["secant_gate"]
                field=list(trial.field)
                field[58]+=KANI_WARP_MU_MPA
                after=comparison(left,current,replace(trial, name="only mu_w changed",field=tuple(field)),
                                 relative_tolerance,load_resolution_coefficient)
                assert before["load"] == after["load"]
                assert before["last_field_test"]["mechanical_56"] == after["last_field_test"]["mechanical_56"]
                if before["whole_criterion"]["all_60"] and not after["whole_criterion"]["all_60"]:
                    assert after["whole_criterion"]["mechanical_56"]
                    rows.append({"sequence":kind,"before":before,"after":after})
    return {"tests":total,"complete_load_gate_passed":load_pass,"switches":rows}

def isolated_mu_trial(sequences, relative_tolerance, load_resolution_coefficient):
    """Keep previous gauge increments zero, then change only the trial warp multiplier."""
    left,current,recorded=sequences["refined"][-3:]
    ratio=(recorded.coordinate-current.coordinate)/(current.coordinate-left.coordinate)
    fixed=current.field[56:]
    altered_left=replace(left,field=left.field[:56]+fixed)
    trial_mechanical=tuple(y+ratio*(y-x) for x,y in zip(left.field[:56],current.field[:56],strict=True))
    predicted=Point("exact mechanical and load secants",recorded.coordinate,
                    current.load+ratio*(current.load-left.load),trial_mechanical+fixed)
    after_field=list(predicted.field)
    after_field[58]+=KANI_WARP_MU_MPA
    perturbed=replace(predicted,name="only mu_w changed",field=tuple(after_field))
    before=comparison(altered_left,current,predicted,relative_tolerance,load_resolution_coefficient)
    after=comparison(altered_left,current,perturbed,relative_tolerance,load_resolution_coefficient)
    assert before["load"]==after["load"] and before["whole_criterion"]["all_60"]
    assert before["last_field_test"]["mechanical_56"]==after["last_field_test"]["mechanical_56"]
    assert not after["whole_criterion"]["all_60"] and after["whole_criterion"]["mechanical_56"]
    return {
        "definition":"Anchored on the recorded Turn4/Turn7 mechanical and load secants at Turn11 spacing; "
                     "gauge increments set to zero before injecting the saved Kani warp-multiplier change. "
                     "The trial load and mechanical coordinates use exact extrapolation. This is an algebraic example.",
        "before":before, "after":after,
    }

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkout",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    root=args.checkout
    src=(root/"src/Solver/CCoupledDeformationContinuation.cls").read_bytes()
    assert digest(src)==SOURCE_SHA256
    old_src=src.decode("utf-8-sig")
    tolerance=float(re.search(r"POST_PEAK_SECANT_TOLERANCE As Double = ([0-9.]+)",old_src)[1])
    resolution_factor=float(re.search(r"LoadResolution = ([0-9.]+)# \* mRelTol",old_src)[1])
    source_analysis=(root/"src/Solver/CCoupledSectionAnalysis.cls").read_text(encoding="utf-8-sig")
    relative_tolerance=float(re.search(r"RELATIVE_TOLERANCE As Double = ([0-9.]+)",source_analysis)[1])
    coefficient=resolution_factor*relative_tolerance
    sequences, input_hashes={},{}
    for kind,count in [("coarse",5),("refined",6)]:
        archive, expected_hash = ARCHIVES[kind]
        path=root/"docs/regression/Coupled6D"/archive
        sequences[kind], input_hashes[kind] = read_trace(path,expected_hash,kind,count)
    trials = {kind: [comparison(a,b,c,tolerance,coefficient)
                     for a,b,c in zip(points, points[1:], points[2:])]
              for kind,points in sequences.items()}
    all_trials=[case for panel in trials.values() for case in panel]
    numerical_effects={}
    for name,key,comparison_key in [
            ("max_gauge_secant_expected","max_expected","max_expected"),
            ("max_gauge_secant_deviation","max_deviation","max_deviation"),
            ("max_gauge_expected_over_mechanical","max_expected","max_expected"),
            ("max_gauge_deviation_over_mechanical","max_deviation","max_deviation")]:
        metric=lambda case: case["last_field_test"]["multipliers_4"][key]
        if name.endswith("_over_mechanical"):
            value=metric
            metric=lambda case: value(case)/case["last_field_test"]["mechanical_56"][comparison_key]
        identified=max(all_trials,key=metric)
        numerical_effects[name]={"fields":identified["fields"],"value":metric(identified),
                                 "raw_gauge_component":identified["last_field_test"]["multipliers_4"][key+"_coordinate"]}
    synthetic=synthetic_trials(sequences,tolerance,coefficient)
    result={"result":"PASS","provenance":{"source_sha256":SOURCE_SHA256,"csv_sha256":input_hashes,
              "archive_sha256":{kind:fields[1] for kind,fields in ARCHIVES.items()},
              "kani_mu":[*KANI_SOURCE,KANI_WARP_MU_MPA]},
            "relative_tolerance":relative_tolerance,"secant_tolerance":tolerance,
            "sequence_length":{kind:len(points) for kind,points in sequences.items()},
            "coordinate57_60_max_absolute":[max(abs(point.field[i]) for points in sequences.values() for point in points) for i in range(56,60)],
            "largest_gauge_effect":numerical_effects,"tested_triplets":trials,
            "changed_whole_criterion":sum(row["whole_criterion"]["all_60"]!=row["whole_criterion"]["mechanical_56"] for row in all_trials),
            "changed_last_field_test":sum(row["last_field_test"]["all_60"]["passes"]!=row["last_field_test"]["mechanical_56"]["passes"] for row in all_trials),
            "synthetic_with_recorded_gauges":synthetic,
            "synthetic_with_fixed_gauges":isolated_mu_trial(sequences,tolerance,coefficient)}
    with args.output.open("x",encoding="utf-8",newline="\n") as stream:
        json.dump(result,stream,indent=2,ensure_ascii=False,allow_nan=False)
        stream.write("\n")
    print(f"{len(all_trials)} triplets, {result['changed_whole_criterion']} whole verdict changes, {len(synthetic['switches'])} synthetic switches with recorded gauges")
    print("SHA-256",digest(args.output.read_bytes()))

if __name__=="__main__":
    main()