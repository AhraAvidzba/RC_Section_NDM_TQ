"""Compare the current-book native MVT2 stop with the historical trace."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
HISTORICAL = "94C2373FFDE9EA0E0E359E0A325CE813BFA91B90E00AE88A75FBEDE4429853A1"
PRODUCTION = "C603E41639484DB313C5390930BC52F1AC3CC42ED4CE01BC1946BC01ED84FA95"


def checksum(value):
    return sha256(value).hexdigest().upper()


def read(name):
    return json.loads((HERE / name).read_bytes().decode("utf-8-sig"))


def rows(raw, prefix):
    return [line for line in raw.decode("cp1251").splitlines() if line.startswith(prefix)]


def verify(historical):
    assert checksum(historical.read_bytes()) == HISTORICAL
    with ZipFile(historical) as archive:
        prior = archive.read("NativeResume/MVT2.csv")
    native = (HERE / "NativeResume/MVT2.csv").read_bytes()
    compiled = read("docs/regression/CodeUpdate.json")
    compiler = read("CompileClosure.json")
    watch = read("NativeResume/MVT2.txt.ProcessClosure.json")
    receipt = read("NativeResume/RunReceipt.json")
    report = (HERE / "NativeResume/MVT2.txt").read_text(encoding="utf-8-sig")
    assert compiled["Compiled"] and not compiled["ProductionChanged"] and compiled["ProductionSHA256"] == PRODUCTION
    assert set(compiled["Modules"]) == {"CCoupledNewtonSolver", "CCoupledDeformationContinuation", "modTestCoupledExperiment"}
    assert f"SOURCE_SHA256: {compiled['WorkbookSHA256']}" in report and "SOURCE_UNCHANGED: True" in report
    assert watch["Passed"] and watch["ChildHasExited"] and watch["ChildExitCode"] == receipt["native_exit"] == 1
    assert watch["Closure"]["FinalState"]["State"] == compiler["State"] == "Absent"
    assert watch["Closure"]["FinalState"]["PID"] != compiler["PID"]
    assert "Не восстановлена принятая точка Attempt1." in report

    for prefix in ("MVT2_CONTROL_FIELD;Replay", "B_ARC_HISTORY;Base24", "B_ARC_HISTORY;BeforeSolveAttempt1",
                   "B_ARC_HISTORY;BeforeDecisionAttempt1", "B_BOUND_ACTUAL;Base24",
                   "B_EXT_PROJECTION;Attempt1", "B_EXT_SEED;Attempt1", "B_EXT_TRY;Attempt1"):
        now, before = rows(native, prefix), rows(prior, prefix)
        assert now == before and len(now) == (24 if prefix.endswith("Replay") else 1), prefix

    stock, reference = (rows(trace, "B_EXT_SOLVER;Attempt1;") for trace in (native, prior))
    assert len(stock) == len(reference) == 1
    assert stock[0].split(";")[2:5] == ["0", "6", "10"] and reference[0].split(";")[2:5] == ["1", "4", "0"]
    assert not rows(native, "B_OWN_") and not rows(native, "B_FB_TRIAL;")
    window = [
        [int(fields[1]), *(float(value) for value in fields[2:])]
        for fields in (line.split(";") for line in rows(prior, "B_FB_TRIAL;"))
    ]
    assert len(window) == 2 and window[0][1] > window[0][2] == window[1][1] > window[1][2]
    assert window[0][2] > window[0][4] and window[1][2] <= window[1][4]
    assert all(row[3] <= row[4] for row in window)
    stock_norm = float(re.search(r"невязка, МПа: ([\d.E+-]+)", stock[0])[1])
    matched = rows(prior, "B_EXT_GATES;Attempt1;")[0].split(";")
    assert float(matched[3]) == window[1][2] and float(matched[4]) == window[1][4]
    assert stock_norm > float(matched[4])
    return {"status": "PASS", "compilation_only": True, "accepted_prefix_count": 24,
            "current_early_residual_MPa": stock_norm, "historical_usable_residual_MPa": window[1][2],
            "historical_tolerance_MPa": window[1][4], "candidate_api_exercised": False,
            "native_trace_sha256": checksum(native), "historical_corrections": window}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("historical", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    options = parser.parse_args()
    proof = verify(options.historical)
    with options.out.open("x", encoding="utf-8", newline="\n") as output:
        output.write(json.dumps(proof, indent=2, sort_keys=True) + "\n")
    print("MVT2_CURRENT_API_FIXTURE_STOP_PASS", proof["accepted_prefix_count"])
