"""Independently validate fixed-history, fixed-control seeds beyond the measured G14 switch."""

from argparse import ArgumentParser
import json
from math import isclose
from pathlib import Path

import DirectionVerify as baseline
import G13Verify as history_check
import PriorVerify as native


HERE=Path(__file__).resolve().parent
CONTROL_SPECS=('CROSS1','CROSS2','CROSS4')


def validate_inputs():
    fixture,expected,original=baseline.inputs()
    report=native.read(HERE/'Baseline/Verification.json')
    path=HERE/'Baseline/HardG14Direction.csv'
    assert report['native_trace_sha256']==native.file_hash(path)
    parsed,_,_,_=baseline.read_probe(path)
    assert parsed[0]['FINISH']==['COMPLETE','25','1'] and report['exact_prefix']==25
    return fixture,expected,original,path


def verify(fixture,expected,original,baseline_path):
    folder=HERE/'Native/Order10'
    proof=native.native_proof(fixture,folder)
    path=folder/'HardG14Direction.csv'
    original_rows,old_tags,old_matrices,old_samples=baseline.read_probe(baseline_path)
    raw=path.read_text(encoding='cp1251').splitlines()
    restarts=[]
    filtered=[]
    for row in raw:
        if row.startswith('RESTART;'):
            restarts.append(row.split(';')[1:])
        else:
            filtered.append(row)
    def read_focused_trace(_, encoding):
        assert encoding=='cp1251'
        return '\n'.join(filtered)
    trace=type('ReadOnlyTrace',(),{'read_text':read_focused_trace})()
    parsed,tags,matrices,samples=baseline.read_probe(trace)
    geometry,points,histories,_,rollback,records=parsed
    assert geometry['FINISH'][0]=='COMPLETE' and geometry['FINISH'][1]=='25'
    assert tags==old_tags and matrices==old_matrices and samples==old_samples
    assert points==original_rows[1] and histories==original_rows[2] and records[:26]==original_rows[-1]
    assert {k:geometry[k] for k in expected['geometry']}==expected['geometry']
    reference=native.verify_geometry(fixture,10,geometry,points)
    direction,projection=(native.numbers(geometry[name]) for name in ('DIRECTION','PROJECTION'))
    base=native.numbers(samples[0]['DIR-FIELD'])
    accepted=native.numbers(records[24]['FIELD'])
    correction=native.numbers(tags['CORRECTION'])
    guard=max(abs(a-b) for a,b in zip(base[:56],accepted[:56],strict=True))
    assert len(restarts)==3
    by_label={row['label']:row for row in records[26:]}
    assert len(by_label)==len(records)-26
    assert int(geometry['FINISH'][2])==1+len(by_label)
    out=[]
    for spec,row,fraction in zip(CONTROL_SPECS,restarts,(1/128,1/64,1/32),strict=True):
        assert 'CROSS'+row[0]==spec
        h,f0,f1,excursion,limit,error=native.numbers(row[1:])
        assert h==fraction and f0==samples[0]['stations'][31,-1][0] and limit==guard
        seed=[a+h*dv for a,dv in zip(base,correction[:60],strict=True)]
        assert max(abs(a-b) for a,b in zip(seed[:56],base[:56],strict=True))==excursion
        allowed=f0<0<f1 and excursion<=guard and error<=5e-7
        assert (spec in by_label)==allowed
        details={'label':spec,'fraction':fraction,'station_trial_before_MPa':f0,'station_trial_seed_MPa':f1,
                 'coordinate_excursion':excursion,'coordinate_limit':limit,'attempted':allowed}
        if allowed:
            arm=by_label[spec]
            assert not arm['commit'] and rollback[spec]==['25','9744']
            assert arm['START-FIELD']==arm['STOP-FIELD']==records[24]['FIELD']
            assert records[25]['control']==original['control']==arm['control']
            assert native.numbers(arm['SEED'])==seed
            assert arm['seed_factor']==samples[0]['lambda']+h*correction[-1]
            assert not any(native.received(flag) for flag in (arm['RECOVERY'][0],arm['RECOVERY'][2]))
            history_check.row_check(arm,projection,direction,*reference[:3])
            details.update({'decision':arm['DECISION'][0],'solver':arm['SOLVER'], 'verified_equilibrium':arm['ready']})
            if arm['ready']:
                factor,norm,tolerance,control,*_=native.numbers(arm['BALANCE'][:-1])
                assert norm<=tolerance and isclose(control,0.,abs_tol=tolerance)
                details.update({'factor':factor,'norm_MPa':norm,'tolerance_MPa':tolerance,
                                'verified_concrete_station_count':len(arm['stations'])})
        out.append(details)
    assert set(by_label)=={row['label'] for row in out if row['attempted']}
    result={'status':'PASS','scope':'Local same-control seeds after p31/-1 with stock branch-consistent corrector and no recovery guide',
            'exact_prefix':25,'total_new_attempts':len(by_label),'restarts':out,'physical_limit_certified':False,
            'native_trace_sha256':native.file_hash(path),'proof':proof}
    data=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
    target=folder/'Verification.json'
    if target.exists():
        assert target.read_bytes()==data
    else:
        target.write_bytes(data)
    print('HARDSHEAR G14 SAME-CONTROL RESTART OFFLINE PASS',json.dumps(out,ensure_ascii=False))


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--inputs',action='store_true')
    cli.add_argument('--order',type=int,choices=(10,))
    args=cli.parse_args()
    fixture,expected,original,old=validate_inputs()
    if args.inputs:
        print('HARDSHEAR G14 SAME-CONTROL RESTART INPUTS: PASS')
    else:
        assert args.order==10
        verify(fixture,expected,original,old)
