' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит штатную пробу G14 и останавливает её у первой неверной поправки.
Private Function RunHardG14DirectionTest(ByVal history As Collection, ByVal snapshots As Collection, ByRef controls() As Double, _
        ByRef factors() As Double, ByRef projection() As Double, ByVal g14 As Double, ByRef offset() As Double, _
        ByRef direction() As Double, ByVal started As Double, ByRef probes As Long) As String
    Const TOLERANCE As Double = 0.0000005
    Dim after() As Double, before() As Double, saved() As Double, seed As Variant, i As Long
    Dim afterControl As Double, beforeControl As Double, ratio As Double, estimate As Double
    Dim acceptedControl As Double, lambda As Double, verified As Boolean
    If Not ReplayAcceptedFields(history, 25) Then
        RunHardG14DirectionTest = "ROLLBACK_REFUSED": Exit Function
    End If
    saved = snapshots(2)
    If Not HardG13HistoryAgreesTest(saved) Then
        RunHardG14DirectionTest = "ROLLBACK_REFUSED": Exit Function
    End If
    after = history(25): before = history(24)
    afterControl = HardFineControlTest(projection, after): beforeControl = HardFineControlTest(projection, before)
    If afterControl <= beforeControl Or g14 <= afterControl Then
        RunHardG14DirectionTest = "INVALID_WINDOW": Exit Function
    End If
    ratio = (g14 - afterControl) / (afterControl - beforeControl)
    estimate = factors(25) + ratio * (factors(25) - factors(24))
    For i = 1 To UBound(after): after(i) = after(i) + ratio * (after(i) - before(i)): Next i
    seed = after
    mHardG14CapturedTest = False: mHardG14ArmedTest = True
    probes = 1
    verified = TryHardFinePointTest("R2S", g14, estimate, offset, direction, projection, _
        seed, acceptedControl, lambda, False, False, TOLERANCE, False)
    mHardG14ArmedTest = False
    If Not HardG13HistoryAgreesTest(saved) Then
        RunHardG14DirectionTest = "ROLLBACK_REFUSED": Exit Function
    End If
    WriteHardRankRowTest "ROLLBACK;R2S;25;" & CStr(UBound(saved))
    If verified Or Not mHardG14CapturedTest Then
        RunHardG14DirectionTest = "NO_CAPTURE": Exit Function
    End If
    RunHardG14DirectionTest = "COMPLETE"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает фактическую отклонённую поправку в точке до смены материальной меры.
Private Sub CaptureHardG14DirectionTest(ByRef field() As Double, ByVal lambda As Double, ByRef correction() As Double, _
        ByVal equation As Long, ByVal valueBefore As Double, ByVal valueAfter As Double, ByVal fraction As Double, _
        ByVal norm As Double, ByVal tolerance As Double)
    mHardG14ArmedTest = False: mHardG14CapturedTest = True
    WriteHardRankRowTest "CAPTURE;" & CStr(equation) & ";" & HardRankBitsTest(valueBefore) & ";" & HardRankBitsTest(valueAfter) & ";" & _
        HardRankBitsTest(fraction) & ";" & HardRankBitsTest(norm) & ";" & HardRankBitsTest(tolerance) & ";" & _
        CStr(mIterations) & ";" & CStr(mEvaluations)
    WriteHardRankRowTest "DIRECTION-EQ;" & HardRankVectorTest(mDirectionEquations)
    WriteHardRankRowTest "CORRECTION;" & HardRankVectorTest(correction)
    WriteHardG14MatrixTest "STOCK"

    Dim h As Variant, abscissa As Double, i As Long, trial() As Double
    Dim relativeFractions As Variant: relativeFractions = Array(0#, -1#, -0.125, -0.015625, 0.015625, 0.125, 1#)
    For Each h In relativeFractions
        abscissa = fraction * CDbl(h): trial = field
        For i = 1 To mDegreeCount: trial(i) = field(i) + abscissa * correction(i): Next i
        ReadHardG14SampleTest "STOCK", abscissa, trial, lambda + abscissa * correction(mDegreeCount + 1), equation
    Next h

    ' Используем тот же исходный итерат для второй численной касательной.
    Dim load(1 To COMPONENT_COUNT) As Double
    SetControlledLoad lambda, load
    If Not Evaluate(field, True, recordTrial:=False, refinedBranch:=True) Then
        WriteHardRankRowTest "REFINED;NO_TANGENT;" & CStr(mFailureCode)
        Exit Sub
    End If
    WriteHardRankRowTest "REFINED;TANGENT"
    WriteHardG14MatrixTest "REFINED"
    Dim finer() As Double
    If Not SolveCorrection(field, finer) Then
        WriteHardRankRowTest "REFINED;NO_DIRECTION;" & CStr(mSystem.FailureCode)
        Exit Sub
    End If
    WriteHardRankRowTest "REFINED-CORRECTION;" & HardRankVectorTest(finer)
    For Each h In Array(0.015625, 0.125, 1#)
        abscissa = fraction * CDbl(h): trial = field
        For i = 1 To mDegreeCount: trial(i) = field(i) + abscissa * finer(i): Next i
        ReadHardG14SampleTest "REFINED", abscissa, trial, lambda + abscissa * finer(mDegreeCount + 1), equation
    Next h
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Копирует матрицу без переноса строк в исходнике VBA.
Private Sub WriteHardG14MatrixTest(ByVal arm As String)
    Dim lines() As String, row() As Double, i As Long, j As Long
    ReDim lines(1 To mDegreeCount): ReDim row(1 To mDegreeCount)
    For i = 1 To mDegreeCount
        For j = 1 To mDegreeCount: row(j) = mMatrix(j, i): Next j
        lines(i) = "MAT;" & arm & ";" & CStr(i) & ";" & HardRankVectorTest(row)
    Next i
    WriteHardRankRowTest Join(lines, vbCrLf)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вычисляет только остаток и вклад отдельных точек при заданном поле и множителе.
Private Sub ReadHardG14SampleTest(ByVal arm As String, ByVal fraction As Double, ByRef field() As Double, _
        ByVal lambda As Double, ByVal equation As Long)
    Dim load(1 To COMPONENT_COUNT) As Double, succeeded As Boolean
    SetControlledLoad lambda, load
    mHardG14RowTest = equation
    ReDim mHardG14PartsTest(1 To mPointCount, 1 To 4)
    succeeded = Evaluate(field, False, recordTrial:=False)
    mHardG14RowTest = 0
    WriteHardRankRowTest "DIR-SAMPLE;" & arm & ";" & HardRankBitsTest(fraction) & ";" & HardRankBitsTest(lambda) & ";" & CStr(succeeded)
    WriteHardRankRowTest "DIR-FIELD;" & HardRankVectorTest(field)
    If succeeded Then
        WriteHardRankRowTest "DIR-TARGET;" & HardRankVectorTest(load)
        WriteHardRankRowTest "DIR-ACTUAL;" & HardRankVectorTest(mTrialResultants)
        WriteHardRankRowTest "DIR-EXTERNAL;" & HardRankVectorTest(mExternal)
        WriteHardRankRowTest "DIR-AFFINE;" & HardRankBitsTest(mHardG14InitialRowTest)
        WriteHardRankRowTest "DIR-RESIDUAL;" & HardRankVectorTest(mResidual)
        WriteHardRankRowTest "DIR-BALANCE;" & HardRankBitsTest(EquilibriumNorm(load, field)) & ";" & HardRankBitsTest(ControlResidual(field))
        Dim values(1 To 4) As Double, lines() As String, point As Long, i As Long
        ReDim lines(1 To mPointCount)
        For point = 1 To mPointCount
            For i = 1 To 4: values(i) = mHardG14PartsTest(point, i): Next i
            lines(point) = "DIR-PART;" & CStr(point) & ";" & HardRankVectorTest(values)
        Next point
        WriteHardRankRowTest Join(lines, vbCrLf)
        RecordHardG13StationsTest field
    Else
        WriteHardRankRowTest "DIR-FAILURE;" & CStr(mFailureCode) & ";" & CStr(mLastFailedPoint) & ";" & CStr(mLastFailedSide)
    End If
    WriteHardRankRowTest "DIR-END"
End Sub
