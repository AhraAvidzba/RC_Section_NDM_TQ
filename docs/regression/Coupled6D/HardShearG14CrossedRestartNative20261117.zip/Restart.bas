' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет G14 от точек за известным переходом бетона, сохраняя исходную историю.
Private Function TryHardG14RestartBankTest(ByVal history As Collection, ByRef saved() As Double, _
        ByVal target As Double, ByRef offset() As Double, ByRef direction() As Double, ByRef projection() As Double, _
        ByVal started As Double, ByRef probes As Long) As Boolean
    Const TOLERANCE As Double = 0.0000005
    Dim point As TYieldStation, arm As Variant, h As Double, lambda As Double, i As Long
    Dim field() As Double, strain(1 To COMPONENT_COUNT) As Double, baseStrain(1 To COMPONENT_COUNT) As Double
    Dim unused(1 To COMPONENT_COUNT) As Double, f0 As Double, f1 As Double, response As CCoupledReinforcedResponse
    Dim origin() As Double, correction() As Double, prior() As Double, excursion As Double, distance As Double
    Dim limit As Double, control As Double, reached As Double, seed As Variant, solved As Boolean
    origin = mHardG14RestartOriginTest: correction = mHardG14RestartCorrectionTest
    prior = history(25)
    limit = 0#
    For i = 1 To mGaugeStart - 1
        limit = GeomMax(limit, Abs(origin(i) - prior(i))) ' Ограничение возмущения из фактического прогноза.
    Next i
    For Each arm In Array(1#, 2#, 4#)
        If Timer - started > 85# Then Exit Function
        h = CDbl(arm) / 128#
        field = origin
        excursion = 0#
        For i = 1 To mDegreeCount
            field(i) = origin(i) + h * correction(i)
            If i < mGaugeStart Then excursion = GeomMax(excursion, Abs(field(i) - origin(i)))
        Next i
        lambda = mHardG14RestartLambdaTest + h * correction(mDegreeCount + 1)
        Set response = YieldResponse(-1)
        YieldStrain 31, -1, origin, baseStrain
        YieldStrain 31, -1, field, strain
        If Not response.TryReadTrialYield(31, baseStrain, f0, unused, False) Then Exit Function
        If Not response.TryReadTrialYield(31, strain, f1, unused, False) Then Exit Function
        distance = Abs(HardFineControlTest(projection, field) - target) * mReferenceModulus
        WriteHardRankRowTest "RESTART;" & CStr(arm) & ";" & HardRankBitsTest(h) & ";" & _
            HardRankBitsTest(f0) & ";" & HardRankBitsTest(f1) & ";" & HardRankBitsTest(excursion) & ";" & _
            HardRankBitsTest(limit) & ";" & HardRankBitsTest(distance)
        If f0 < 0# And f1 > 0# And excursion <= limit And distance <= TOLERANCE Then
            If Not ReadYieldCrossing(31, -1, origin, field, point) Then Exit Function
            probes = probes + 1
            seed = field
            solved = TryHardFinePointTest("CROSS" & CStr(arm), target, lambda, offset, direction, projection, _
                seed, control, reached, False, True, TOLERANCE, False, False)
            If Not HardG13HistoryAgreesTest(saved) Then Exit Function
            WriteHardRankRowTest "ROLLBACK;CROSS" & CStr(arm) & ";25;" & CStr(UBound(saved))
        End If
    Next arm
    TryHardG14RestartBankTest = True
End Function
