"""Replay native MVT2 evidence and minimize a measured directional residual model."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import argparse
import csv
import json
import math

import numpy as np
from scipy.optimize import linprog

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



ARCHIVES = {
    "gradient": ("MVT2GradientCorrection20261116.zip", "FA407B0A7625E2CC09C240470D205A5C70CE86BDC67AE04443C3B5306B323CA9"),
    "repeated": ("MVT2RepeatedFixed20261116.zip", "2A4127B75031E56AA35AD06FC2C6CA52EF4DF51E9E69EE3BCC75358B4401A1A2"),
}
SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def load_native(folder, name, member):
    archive, expected = ARCHIVES[name]
    path = folder / archive
    assert digest(path) == expected
    with ZipFile(path) as package:
        trace = package.read(member)
    tables = defaultdict(list)
    for marker, *row in csv.reader(trace.decode("cp1251").splitlines(), delimiter=";"):
        tables[marker].append(row)
    return tables, sha256(trace).hexdigest().upper()


def verified_states(tags):
    fields, stations = {}, defaultdict(dict)
    for name, history, q, *x in tags["B_TANGENT_FIELD"]:
        assert name not in fields and len(x) == 60
        fields[name] = (int(history), float(q), tuple(map(float, x)))
    for name, point, side, *row in tags["B_TANGENT_STATION"]:
        key = int(point), int(side)
        assert key not in stations[name] and len(row) == 19
        stations[name][key] = tuple(map(float, row))
    raw_r = vec(tags, "B_TANGENT_RESIDUAL")
    raw_force = {name: tuple(map(float, row)) for name, *row in tags["B_BOUND_ACTUAL"]}
    raw_norm = {name: float(value) for name, value in tags["B_BOUND_NORM"]}
    output = {}
    assert set(fields) == set(stations) == set(raw_r) == set(raw_force) == set(raw_norm)
    for name, (history, q, x) in fields.items():
        assert history == 24 and len(stations[name]) == 135
        rows, actual, strain_error = reconstruct(x, q, stations[name])
        error = peak(diff(rows, raw_r[name]))
        assert strain_error < 4e-15 and error < 3e-10
        assert max(abs(a-b)/s for a,b,s in zip(actual, raw_force[name], SCALES, strict=True)) < 4e-12
        signed = diff(actual, force(q))
        efforts = tuple(r/s for r, s in zip(signed, SCALES, strict=True))
        residual = (*rows[:56], *efforts)
        gauge_norm = MODULUS*peak(rows[56:])
        tol = 5e-7*(1.+peak(loading(q)))
        near(max(peak(residual), gauge_norm),raw_norm[name], 4e-10)
        assert gauge_norm <= tol
        output[name] = {"q": q, "field": x, "r": residual, "gauge_MPa": gauge_norm, "tol_MPa": tol,
            "signed_force_N_Nmm": signed, "norm_MPa": peak(residual), "reconstruction_error_MPa": error,
            "geometry": {key: row[:3] for key, row in stations[name].items()}}
    return output, stations


def tensor_radius(field, geometry):
    maximum = 0.
    for (_, side), (x, y, _) in geometry.items():
        strain = strain_at(field, operators(x, y), side)
        maximum = max(maximum, peak(s/(1. if i < 3 else math.sqrt(2.)) for i, s in enumerate(strain)))
    return maximum


def replay_iterations(tags, states, stations):
    assert tags["BOUNDED_READY"] == [["0"]]
    same = "Restored24"
    assert states[same] == states["Base24"] and stations[same] == stations["Base24"]
    fields = vec(tags, "BOUNDED_FIELD")
    base = states["Anchor"]
    final = states["FinalProvisional"]
    current = {int(step): (float(norm), float(tol)) for step,norm,tol in tags["BOUNDED_CURRENT"]}
    updates = {int(step):float(norm) for step,norm in tags["BOUNDED_UPDATE"]}
    assert set(current) == set(range(5)) and set(updates) == set(range(1, 5))
    assert tuple(fields) == ("1", "2", "3", "4") and fields["4"] == final["field"]
    near(current[0][0], base["norm_MPa"], 4e-10)
    near(current[4][0], final["norm_MPa"], 4e-10)
    assert all(abs(tol-base["tol_MPa"]) < 5e-15 for _,tol in current.values())
    trials = defaultdict(list)
    for iteration, mode, fraction, true_norm, prediction, cap, solves in tags["BOUNDED_PROBE"]:
        trials[int(iteration)].append({"refined": bool(int(mode)), "fraction": float(fraction),
            "native_true_norm_MPa": float(true_norm), "unscaled_LP_prediction_MPa": float(prediction),
            "logged_tensor_radius": float(cap), "linear_solves": int(solves)})
    assert list(trials) == [0,1,2,3] and [len(v) for v in trials.values()] == [1,1,2,3]
    previous = base["field"]
    updates_report = []
    for step in range(1, 5):
        probes = trials[step-1]
        candidate = fields[str(step)]
        delta = diff(candidate, previous)
        measured = tensor_radius(delta, base["geometry"])
        chosen = probes[-1]
        near(measured, chosen["logged_tensor_radius"], 2e-11)
        assert measured <= 1e-8+2e-14
        for rejected in probes[:-1]:
            assert rejected["native_true_norm_MPa"] >= .99*current[step-1][0]
            extent = measured * rejected["fraction"]/chosen["fraction"]
            near(extent, rejected["logged_tensor_radius"], 2e-11)
        near(chosen["native_true_norm_MPa"], updates[step], 5e-14)
        near(updates[step], current[step][0], 5e-14)
        assert updates[step] < .99*current[step-1][0]
        assert len({test["unscaled_LP_prediction_MPa"] for test in probes}) == 1
        updates_report.append({"step": step, "true_norm_MPa": updates[step], "independent_radius": measured,
            "q53_increment": delta[52], "probes": probes, "full_residual_archived": step == 4})
        previous = candidate
    before, after = base["signed_force_N_Nmm"], final["signed_force_N_Nmm"]
    deteriorated = [name for name,a,b in zip(EFFORT_NAMES,before,after,strict=True) if abs(b)>abs(a)]
    assert deteriorated == ["My"]
    return {"initial_norm_MPa": base["norm_MPa"], "final_norm_MPa": final["norm_MPa"], "target_tolerance_MPa": base["tol_MPa"],
        "relative_decrease": 1.-final["norm_MPa"]/base["norm_MPa"], "remaining_over_tolerance": final["norm_MPa"]/base["tol_MPa"],
        "initial_signed_effort_N_Nmm": before, "final_signed_effort_N_Nmm": after, "deteriorated_efforts": deteriorated,
        "full_residual_archived_only_at_anchor_and_final": True, "true_probe_count": sum(map(len,trials.values())), "updates": updates_report}


def admissible_interval(residual, measured_action, caps):
    lower, upper = 0., 1.
    for r, v, cap in zip(residual[56:], measured_action[56:], caps, strict=True):
        near(max(0., abs(r)-cap), 0., 3e-15)
        if v == 0.:
            continue
        first, second = (-cap-r)/v, (cap-r)/v
        lower = max(lower, min(first, second))
        upper = min(upper, max(first, second))
    assert lower <= upper and upper >= 0.
    return lower, max(0., upper)


def maximum_along(residual, action, factor):
    state = tuple(a+factor*b for a,b in zip(residual,action,strict=True))
    return peak(state), state


def minimizing_scale(residual, action, interval):
    lower, upper = interval
    lines = [(sign*a,sign*b) for a,b in zip(residual,action,strict=True) for sign in (-1.,1.)]
    candidates = {lower, upper}
    for i,(a,b) in enumerate(lines):
        for c,d in lines[:i]:
            if b != d:
                point = (c-a)/(b-d)
                if lower < point < upper:
                    candidates.add(point)
    score, t = min((maximum_along(residual,action,t)[0],t) for t in candidates)
    return t, score


def line_audits(reference, rays, caps):
    r0=reference["r"]
    output={}
    for name,(q_delta,action) in rays.items():
        interval=admissible_interval(r0,action,caps)
        full_t,full_score=minimizing_scale(r0,action,(0.,1.))
        t,score=minimizing_scale(r0,action,interval)
        value,predicted=maximum_along(r0,action,t)
        near(value,score,1e-15)
        assert all(abs(f)<=c+3e-15 for f,c in zip(predicted[56:],caps,strict=True))
        endpoint, state=maximum_along(r0,action,1.)
        output[name]={"actual_measured_endpoint_norm_MPa": endpoint, "line_force_feasible_interval": interval,
            "model_optimal_fraction_without_individual_effort_caps": full_t, "model_optimal_norm_without_individual_effort_caps_MPa":full_score,
            "model_optimal_fraction": t, "model_optimal_norm_MPa": score,
            "expected_row53_MPa":predicted[52], "predicted_signed_effort_N_Nmm": [f*s for f,s in zip(predicted[56:],SCALES,strict=True)],
            "deteriorated_efforts_at_measured_endpoint": [n for n,f,c in zip(EFFORT_NAMES,state[56:],caps,strict=True) if abs(f)>c+3e-15],
            "predicted_tensor_radius": t*tensor_radius(q_delta,reference["geometry"]),
            "kind": "measured performance at both chord endpoints; interior value only a prediction"}
    return output


def combination(reference, rays, caps, names):
    """Minimize affine measured action on the convex hull, with exact effort caps."""
    r = np.asarray(reference["r"])
    act = np.asarray([rays[name][1] for name in names]).T
    perturbations = np.asarray([rays[name][0] for name in names]).T
    size=len(names)
    scale = 1e4      # Condition the linear program; physical unit remains MPa.
    g = act*scale
    cap_matrix = np.c_[g[56:], np.zeros(6)]
    linear = np.vstack((np.c_[g,-np.ones(62)], np.c_[-g,-np.ones(62)], cap_matrix, -cap_matrix, np.r_[np.ones(size),0.]))
    limit = np.r_[-r*scale, r*scale, (np.asarray(caps)-r[56:])*scale, (np.asarray(caps)+r[56:])*scale, 1.]
    result=linprog(np.r_[np.zeros(size),1.], A_ub=linear, b_ub=limit, bounds=[(0.,1.)]*size+[(0.,None)],
        options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9},method="highs")
    assert result.success,result.message
    beta=result.x[:size]
    projected=r+act@beta
    score=peak(projected)
    dq=perturbations@beta
    near(score,result.fun/scale,5e-12)
    assert sum(beta)<=1.+2e-12 and min(beta)>=0.
    assert all(abs(f)<=c+5e-12 for f,c in zip(projected[56:],caps,strict=True))
    radius=tensor_radius(dq,reference["geometry"])
    assert radius<=max(tensor_radius(rays[name][0],reference["geometry"]) for name in names)+3e-15
    return {"measured_direction_weights": dict(zip(names,beta.tolist(),strict=True)), "prediction_MPa":score,
        "prediction_relative_decrease":1.-score/reference["norm_MPa"], "weighted_tensor_radius":radius,
        "absolute_Qy_N": reference["q"]*1000., "predicted_signed_effort_N_Nmm": (projected[56:]*SCALES).tolist(),
        "predicted_row53_MPa":float(projected[52]),"dq":dq.tolist(),
        "coordinate":(np.asarray(reference["field"])+dq).tolist(),"kind":"unmeasured combination; native verification required"}


def main(folder, output, candidate_output):
    r_tags, r_hash = load_native(folder,"repeated","NativeA/MVT2.csv")
    a_tags, a_hash = load_native(folder,"gradient","NativeA/MVT2.csv")
    b_tags, b_hash = load_native(folder,"gradient","NativeB/MVT2.csv")
    repeated,repeated_stations=verified_states(r_tags)
    a,a_stations=verified_states(a_tags)
    b,_=verified_states(b_tags)
    base=repeated["Anchor"]
    for observation in (a["Anchor"],b["Anchor"]):
        assert observation["field"]==base["field"] and observation["q"]==base["q"]
        assert observation["geometry"]==base["geometry"]
        near(peak(diff(observation["r"],base["r"])),0.,4e-10)
    recovery=replay_iterations(r_tags,repeated,repeated_stations)
    rays={}
    for states,endpoint,label in ((a,"GradientPositive","AxialGradientPositive"),(a,"GradientNegative","AxialGradientNegative"),
                               (b,"BothSmall","BoundedSmall"),(b,"BothBest","BoundedLarge"),
                               (repeated,"FinalProvisional","RepeatedTotalChord")):
        reference=states["Anchor"]
        state=states[endpoint]
        assert reference["q"]==state["q"]
        rays[label]=(diff(state["field"],reference["field"]),diff(state["r"],reference["r"]))
    ga=a["Anchor"]["r"]
    gplus,gminus=(rays[name][1] for name in ("AxialGradientPositive","AxialGradientNegative"))
    witness=tuple(x+y for x,y in zip(gplus,gminus,strict=True))
    check_center=all(a_stations[name][key]==value for key,value in a_stations["Anchor"].items() if key[1]==0
                     for name in ("GradientPositive","GradientNegative"))
    assert check_center and max(peak(gplus[56:]),peak(gminus[56:]))==0.
    assert peak(witness)<base["tol_MPa"]
    caps=tuple(max(abs(x),base["tol_MPa"]) for x in base["r"][56:])
    lines=line_audits(base,rays,caps)
    assert lines["RepeatedTotalChord"]["line_force_feasible_interval"]==(0.,0.)
    candidate_groups=(
        ("BoundedSmall","BoundedLarge"),
        ("BoundedSmall","BoundedLarge","AxialGradientPositive"),
        ("BoundedSmall","BoundedLarge","AxialGradientNegative"),
    )
    jointly=[combination(base,rays,caps,names) for names in candidate_groups]
    best=min(jointly,key=lambda value:value["prediction_MPa"])
    result={"traces_sha256":{"325A":a_hash,"325B":b_hash,"328":r_hash},"section328_replay":recovery,
        "pure_gradient_holdout":{"all_six_exact_on_both_sides":check_center,
           "max_error_predicting_opposite_sign_by_positive_secant_MPa":peak(witness),"worst_row":max(range(62),key=lambda k:abs(witness[k]))+1,
           "initial_axial_MPa":ga[0],"global_improvement_ceiling_from_axial_unchanged":1.-abs(ga[0])/peak(ga)},
        "measured_chord_search":lines,"reduced_measured_action_candidates":jointly,"best_unverified_candidate":best,
        "scope":"Only archived nonlinear measurements are confirmed. Interior line search values and all combinations are affine predictions, with H24 and fixed load."}
    line=lines["BoundedLarge"]
    fraction=line["model_optimal_fraction"]
    ray=rays["BoundedLarge"][0]
    line_candidate=tuple(a+fraction*d for a,d in zip(base["field"],ray,strict=True))
    near(tensor_radius(diff(line_candidate,base["field"]),base["geometry"]),line["predicted_tensor_radius"],4e-15)
    result["native_proposal"]={"reference_history_count":24,"fixed_Qy_kN":base["q"],
        "individual_effort_caps_MPa":caps,"first_line_fraction":fraction,
        "proposed_full_line_verification_field":line_candidate,
        "triggered_native_calculations":0}
    if candidate_output is not None:
        with candidate_output.open("w",encoding="ascii",newline="") as stream:
            writer=csv.writer(stream,delimiter=";",lineterminator="\r\n")
            writer.writerow(("field_label","Qy_kN","predicted_residual_MPa",*(f"q{i}" for i in range(1,61))))
            writer.writerow(("MeasuredLine",base["q"],line["model_optimal_norm_MPa"],*line_candidate))
            writer.writerow(("MeasuredCombination",base["q"],best["prediction_MPa"],*best["coordinate"]))
    data=json.dumps(result,indent=2)+"\n"
    output.write_text(data,encoding="utf-8")
    print(output,digest(output))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence_directory",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--candidate-output",type=Path)
    args=parser.parse_args()
    main(args.evidence_directory,args.output,args.candidate_output)
