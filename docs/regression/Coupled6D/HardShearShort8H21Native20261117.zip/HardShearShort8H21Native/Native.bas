' -------------------- ДЛЯ ТЕСТОВ --------------------
' Загружает точную историю короткого плеча и передаёт её штатному решателю.
Public Function ReplayHardNextTest(ByVal solver As CCoupledNewtonSolver, ByRef offset() As Double, _
        ByRef direction() As Double, ByVal maxLambda As Double, ByVal absoluteTolerance As Double, _
        ByVal relativeTolerance As Double, ByVal iterations As Long) As Boolean
    Dim history As New Collection, projection() As Double, target As Double, initialLambda As Double
    HardNextInputTest history, projection, target, initialLambda
    WriteHardRankRowTest "PROBLEM;" & HardRankBitsTest(initialLambda) & ";" & HardRankBitsTest(target) & ";" & _
        HardRankBitsTest(maxLambda) & ";" & HardRankBitsTest(absoluteTolerance) & ";" & HardRankBitsTest(relativeTolerance) & ";" & CStr(iterations)
    WriteHardRankRowTest "LOAD-OFFSET;" & HardRankVectorTest(offset)
    WriteHardRankRowTest "LOAD-DIRECTION;" & HardRankVectorTest(direction)
    WriteHardRankRowTest "ORIGINAL-P;" & HardRankVectorTest(projection)
    ReplayHardNextTest = solver.RunHardNextReplayTest(history, projection, offset, direction, target, initialLambda, _
        maxLambda, absoluteTolerance, relativeTolerance, iterations)
End Function
