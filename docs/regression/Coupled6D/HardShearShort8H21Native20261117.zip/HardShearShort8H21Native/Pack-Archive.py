"""Упаковывает исходный отказ, направляющую пробу и точное повторное решение."""

from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_call, check_output
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from RankVerify import inputs, obj

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
PREFIX = "HardShearShort8H21Native"
ARCHIVE = HERE / f"{PREFIX}20261117.zip"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def serialized(x):
    return (json.dumps(x, indent=2, ensure_ascii=False) + "\n").encode()


def main():
    fixture = obj("Fixture.json")
    inputs(fixture)
    paths = {*fixture["inputs"], "Fixture.json", "Compile.log", "CompileClosure.json", "Run.ndjson",
             "docs/regression/CodeUpdate.json", "Verify-Archive.py", "Pack-Archive.py", "README-Archive.md"}
    paths.update(p.relative_to(HERE).as_posix() for p in (HERE / "Native").iterdir() if p.is_file() and p.suffix.lower() != ".xlsm")
    files = {name: (HERE / name).read_bytes() for name in paths}
    for name, expected in fixture["production"].items():
        raw = check_output(["git", "show", f"{fixture['source_revision']}:{name}"], cwd=REPO)
        assert digest(raw) == expected
        files[f"Baseline/{name}"] = raw
    prior = (HERE.parent / "hs-fold/Native/Verification.json").read_bytes()
    assert digest(prior) == fixture["source_shoulder_report_sha256"]
    files["Inputs/ShoulderVerification.json"] = prior
    log = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    saved = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", log, re.M)
    assert saved
    workbook = Path(saved[2]).resolve(strict=True)
    assert workbook.is_relative_to(HERE / "Temp")
    files["Audit.json"] = serialized({"results_reopen_sha256": saved[1], "saved_workbook_sha256": digest(workbook.read_bytes()),
                                      "native_report_sha256": digest(files["Native/Verification.json"])})
    files["SHA256SUMS.json"] = serialized({name: digest(raw) for name, raw in sorted(files.items())})
    with TemporaryDirectory(prefix="h21-proof-", dir=HERE) as directory:
        scratch = Path(directory)
        archive = scratch / ARCHIVE.name
        with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=9) as bundle:
            for name, raw in sorted(files.items()):
                entry = ZipInfo(f"{PREFIX}/{name}", date_time=(2026, 11, 17, 0, 0, 0))
                bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(archive) as bundle:
            assert bundle.testzip() is None and not any(name.lower().endswith(".xlsm") for name in bundle.namelist())
            bundle.extractall(scratch / "detached")
        cwd = scratch / "detached" / PREFIX
        cmd = [sys.executable, "-B", "-X", "utf8", "Verify-Archive.py"]
        check_call(cmd, cwd=cwd)
        check_call([*cmd, "--saved-workbook", str(workbook)], cwd=cwd)
        ARCHIVE.write_bytes(archive.read_bytes())
    checksum = digest(ARCHIVE.read_bytes())
    ARCHIVE.with_suffix(".zip.sha256").write_bytes(f"{checksum}  {ARCHIVE.name}\n".encode("ascii"))
    print("PORTABLE HARDSHEAR H21 VERIFIED", checksum, ARCHIVE.stat().st_size)


if __name__ == "__main__":
    main()
