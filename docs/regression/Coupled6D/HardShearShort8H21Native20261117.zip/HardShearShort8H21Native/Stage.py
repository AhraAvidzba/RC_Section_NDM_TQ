"""Замораживает один недостающий шаг от проверенной истории Short8."""

from hashlib import sha256
import json
from pathlib import Path
from struct import pack, unpack
from subprocess import check_output


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
RANK = HERE.parent / "hs-rank"
SWITCH = HERE.parent / "hs-switch"
FOLD = HERE.parent / "hs-fold"
CONT = "src/Solver/CCoupledDeformationContinuation.cls"
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
TEST = "tests/modTestCoupledElasticState.bas"
FOLD_SHA = "BB2D2FA462BB238E1EF28D69B87CD4A408B064B7EF14B57832B2215DB859FB7F"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def vba(text):
    assert max(map(len, text.splitlines())) <= 1023
    return text.rstrip().replace("\n", "\r\n").encode() + b"\r\n"


def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def unit(name):
    return (HERE / name).read_text(encoding="utf-8")


def bits(number):
    return pack(">d", number).hex().upper()


def value(data):
    return unpack(">d", bytes.fromhex(data))[0]


def frozen_history():
    raw = (FOLD / "Native/Verification.json").read_bytes()
    assert digest(raw) == FOLD_SHA
    record = json.loads(raw)
    short, = (arm for arm in record["arms"] if arm["id"][0] == "Short8")
    assert short["stop"] == "probe" and len(short["points"]) == 13 and short["points"][-1]["branch_consistent_mode"]
    path = short["prefix_bits"] + [point["field_bits"] for point in short["points"]]
    assert len(path) == 20
    middle, right = map(value, short["common"][1:3])
    target = middle + (right-middle)*6/8
    seed = short["points"][-1]["lambda"]
    assert bits(target) == "3F417AD5671C4BA4"
    src = ["' -------------------- ДЛЯ ТЕСТОВ --------------------",
           "' Замороженные поля H1–H20 и исходная цель отказавшего шага Short8.",
           "Private Sub HardNextInputTest(ByVal history As Collection, ByRef projection() As Double, _",
           "        ByRef target As Double, ByRef seedLambda As Double)",
           "    Dim field() As Double",
           f'    HardRankUnpackTest "{"".join(short["guide"])}", projection',
           f'    target = HardRankValueTest("{bits(target)}"): seedLambda = HardRankValueTest("{bits(seed)}")']
    for field in path:
        src.extend([f'    HardRankUnpackTest "{"".join(field)}", field', "    history.Add field"])
    src.append("End Sub")
    return "\n".join(src), {"seed_lambda": seed, "target": target, "previous": short["points"][-1],
                            "projection": short["guide"], "source_failure": short["reason"], "history": path}


def main():
    rank = json.loads((RANK / "Fixture.json").read_bytes())
    book = (REPO / rank["workbook"]).read_bytes()
    assert digest(book) == rank["source_workbook_sha256"]
    save(rank["workbook"], book)
    save("docs/regression/Diagnostic.xlsm", book)
    for directory in ("Temp", "Native"):
        (HERE / directory).mkdir(exist_ok=True)
    raw = (RANK / CONT).read_bytes()
    assert digest(raw) == rank["inputs"][CONT]
    text = raw.decode("utf-8").replace("\r\n", "\n")
    text = replace(text, "ReplayHardRankTest(mSolver, mOffset, mDirection)",
                   "ReplayHardNextTest(mSolver, mOffset, mDirection, mMaximumLambda, mAbsTol, mRelTol, mMaxIterations)")
    text = replace(text, "Диагностическая остановка после чтения касательных HardShear.",
                   "Диагностическая остановка после повторения одной пробы HardShear.")
    inputs = {CONT: save(CONT, vba(text))}
    for name in (NEWTON, TEST):
        raw = check_output(["git", "show", f"{rank['source_revision']}:{name}"], cwd=REPO)
        assert digest(raw) == rank["production"][name]
        base = raw.decode("utf-8-sig").replace("\r\n", "\n")
        if name == NEWTON:
            base = replace(base, "Private mConsistentControl As Boolean",
                           "Private mHardNextLaneTest As String\nPrivate mConsistentControl As Boolean")
            base = replace(base, """    If Not FirstYieldCrossing(field, ends, station) Then Exit Function
    mYieldRecoveryTried = True""", """    If Not FirstYieldCrossing(field, ends, station) Then Exit Function
    If Len(mHardNextLaneTest) > 0 Then
        WriteHardRankRowTest "CROSS;" & mHardNextLaneTest & ";" & CStr(station.Point) & ";" & CStr(station.Side) & ";" & _
            HardRankBitsTest(station.FromValue) & ";" & HardRankBitsTest(station.ToValue)
    End If
    mYieldRecoveryTried = True""")
            base += "\n" + unit("Newton.bas")
        else:
            native = (RANK / "Native.bas").read_text(encoding="utf-8")
            start = native.index("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Восстанавливает общие H1")
            finish = native.index("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Записывает диагностические", start)
            native = native[:start] + native[finish:]
            for before, after in (("RunTestHardShearRank", "RunTestHardShearNext"), ("HardRank.csv", "HardNext.csv"),
                                  ("HARDSHEAR-RANK;1", "HARDSHEAR-NEXT;1"), ("TOTAL_HARD_SHEAR_RANK", "TOTAL_HARD_SHEAR_NEXT")):
                native = native.replace(before, after)
            base = replace(base, "Option Explicit", """Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Флаги активны только при изолированной проверке Short8.
Public HardRankRequestedTest As Boolean, HardRankFinishedTest As Boolean

Private Type THardRankNumberTest
    Value As Double
End Type

Private Type THardRankWordsTest
    Low As Long
    High As Long
End Type""")
            embedded, expected = frozen_history()
            inputs["Expected.json"] = save("Expected.json", (json.dumps(expected, indent=2) + "\n").encode("utf-8"))
            base += "\n" + native + "\n" + unit("Native.bas") + "\n" + embedded
        inputs[name] = save(name, vba(base))
    for name, sha in rank["inputs"].items():
        if name.startswith("tools/build_workbook/") or name == "Guard-IsolatedOffice.ps1":
            raw = (RANK / name).read_bytes()
            assert digest(raw) == sha
            inputs[name] = save(name, raw)
    raw = (RANK / "Verify.py").read_bytes()
    assert digest(raw) == rank["inputs"]["Verify.py"]
    inputs["RankVerify.py"] = save("RankVerify.py", raw)
    runner = (SWITCH / "Run.ps1").read_text(encoding="utf-8")
    runner = runner.replace("HardShearSwitch", "HardShearNext").replace("HardSwitch.csv", "HardNext.csv")
    inputs["Run.ps1"] = save("Run.ps1", runner.encode("utf-8"))
    for name in ("Stage.py", "Verify.py", "Native.bas", "Newton.bas"):
        inputs[name] = digest((HERE / name).read_bytes())
    manifest = {"source_workbook_sha256": rank["source_workbook_sha256"], "source_revision": rank["source_revision"],
                "workbook": rank["workbook"], "production": rank["production"], "watchdog_seconds": 90,
                "source_shoulder_report_sha256": FOLD_SHA, "inputs": inputs}
    print(save("Fixture.json", (json.dumps(manifest, indent=2) + "\n").encode("utf-8")))


if __name__ == "__main__":
    main()
