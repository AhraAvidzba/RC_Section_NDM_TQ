' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет H21 из одной истории H1–H20. Материал проверяется без принятия.
Friend Function RunHardNextReplayTest(ByVal history As Collection, ByRef originalProjection() As Double, _
        ByRef offset() As Double, ByRef direction() As Double, ByVal target As Double, ByVal seedLambda As Double, _
        ByVal maxLambda As Double, ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double, _
        ByVal iterations As Long) As Boolean
    If history.Count <> 20 Or Not mUseSpatialHistory Then Exit Function
    If Not PrepareHardNextLaneTest(history, "A") Then Exit Function
    Dim factor As Double, solved As Boolean
    solved = TryDeformationStep(offset, direction, originalProjection, target, seedLambda, factor, _
        absoluteTolerance, relativeTolerance, iterations, consistentControl:=True)
    WriteHardNextOutcomeTest solved, maxLambda, absoluteTolerance, relativeTolerance

    If Not PrepareHardNextLaneTest(history, "B") Then Exit Function
    solved = TryDeformationStep(offset, direction, originalProjection, target, seedLambda, factor, _
        absoluteTolerance, relativeTolerance, iterations, recoverYieldControl:=True, consistentControl:=True)
    Dim guide() As Double, guidedField() As Double, measured() As Double, recovered As Boolean
    If solved Then
        recovered = CopyRecoveredControl(guide)
        If recovered Then CopyTrial guidedField, measured
    End If
    Dim certified As Boolean
    certified = WriteHardNextOutcomeTest(solved, maxLambda, absoluteTolerance, relativeTolerance)
    If Not recovered Or Not certified Then
        WriteHardRankRowTest "SKIP;C;no-certified-guide"
    Else
        If Not PrepareHardNextLaneTest(history, "C") Then Exit Function
        ' Восстановление истории не изменяет исходные базовые нагрузки и направление.
        mControlProjection = originalProjection: mTargetControl = target
        mControlActive = True: mConsistentControl = True
        Dim load(1 To COMPONENT_COUNT) As Double
        solved = SolveStep(load, factor, absoluteTolerance, relativeTolerance, iterations, initialField:=guidedField)
        WriteHardNextOutcomeTest solved, maxLambda, absoluteTolerance, relativeTolerance
    End If
    mHardNextLaneTest = vbNullString
    RunHardNextReplayTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит все принятые поля перед каждой сравниваемой пробой.
Private Function PrepareHardNextLaneTest(ByVal history As Collection, ByVal lane As String) As Boolean
    mHardNextLaneTest = lane
    If Not ReplayAcceptedFields(history, history.Count) Then Exit Function
    Dim field() As Double
    CopyAccepted field
    WriteHardRankRowTest "START;" & lane & ";" & CStr(history.Count) & ";" & HardRankVectorTest(field)
    PrepareHardNextLaneTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет решение в той мере, в которой завершилась текущая проба.
' Принятое поле и история сохраняются независимо от исхода.
Private Function WriteHardNextOutcomeTest(ByVal solved As Boolean, ByVal maxLambda As Double, _
        ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double) As Boolean
    Dim details As String
    details = Replace(Replace(Replace(mMeta.DiagnosticDetails, ";", "|"), vbCr, " "), vbLf, " ")
    WriteHardRankRowTest "SOLVER;" & mHardNextLaneTest & ";" & CStr(solved) & ";" & _
        CStr(mYieldRecoveryTried) & ";" & CStr(mMeta.ResultCode) & ";" & details
    If Not solved Then Exit Function
    Dim uncertainty As Double, verified As Boolean
    verified = TrialLambdaUncertainty(absoluteTolerance, relativeTolerance, uncertainty)
    If Not verified Then
        WriteHardRankRowTest "UNVERIFIED;" & mHardNextLaneTest & ";lambda-uncertainty"
        DiscardStep
        Exit Function
    End If
    Dim load(1 To COMPONENT_COUNT) As Double, reference As Double, residual As Double
    SetControlledLoad mTrialLambda, load
    reference = EquilibriumTolerance(absoluteTolerance, relativeTolerance)
    residual = EquilibriumNorm(load, mCandidate)
    Dim reinforcement As CCoupledReinforcedResponse: Set reinforcement = mResponse
    Dim steelUsage As Double: steelUsage = reinforcement.TrialSteelUtilization
    Dim gaugesOk As Boolean: gaugesOk = GaugesVerified(reference)
    Dim lab As String: lab = mHardNextLaneTest
    WriteHardRankRowTest "BALANCE;" & lab & ";" & HardRankBitsTest(mTrialLambda) & ";" & HardRankBitsTest(uncertainty) & ";" & _
        HardRankBitsTest(reference) & ";" & HardRankBitsTest(residual) & ";" & HardRankBitsTest(steelUsage) & ";" & _
        HardRankBitsTest(mTargetControl) & ";" & HardRankBitsTest(ControlResidual(mCandidate)) & ";" & CStr(gaugesOk)
    WriteHardRankRowTest "P;" & lab & ";" & HardRankVectorTest(mControlProjection)
    WriteHardRankRowTest "TARGET;" & lab & ";" & HardRankVectorTest(load)
    WriteHardRankRowTest "ACTUAL;" & lab & ";" & HardRankVectorTest(mTrialResultants)
    WriteHardRankRowTest "FIELD;" & lab & ";" & HardRankVectorTest(mCandidate)
    WriteHardRankRowTest "RESIDUAL;" & lab & ";" & HardRankVectorTest(mResidual)
    WriteHardNextOutcomeTest = (residual <= reference And gaugesOk And steelUsage <= 1# And mTrialLambda > 0# And mTrialLambda <= maxLambda)
    DiscardStep
End Function
