"""Повторно проверяет один штатный и два восстановительных расчёта H21."""

import argparse
from pathlib import Path

from RankVerify import digest, obj, val
from Verify import parse


HERE = Path(__file__).resolve().parent


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--saved-workbook", type=Path)
    args = cli.parse_args()
    sums = obj("SHA256SUMS.json")
    paths = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file() and p.name != "SHA256SUMS.json"}
    assert set(sums) == paths and all(digest(HERE / name) == sha for name, sha in sums.items())
    fixture = obj("Fixture.json")
    for name, expected in fixture["inputs"].items():
        assert sums[name] == expected
    for name, expected in fixture["production"].items():
        assert sums["Baseline/" + name] == expected
    assert sums["Inputs/ShoulderVerification.json"] == fixture["source_shoulder_report_sha256"]
    prior = obj("Inputs/ShoulderVerification.json")
    assert prior["source_workbook_sha256"] == fixture["source_workbook_sha256"]
    short, = [arm for arm in prior["arms"] if arm["id"][0] == "Short8"]
    expected = obj("Expected.json")
    assert expected["history"] == short["prefix_bits"] + [p["field_bits"] for p in short["points"]]
    assert expected["previous"] == short["points"][-1] and expected["projection"] == short["guide"]
    mid, end = map(val, short["common"][1:3])
    assert expected["target"] == mid+(end-mid)*6/8 and expected["seed_lambda"] == expected["previous"]["lambda"]
    compiler = obj("CompileClosure.json")
    update = obj("docs/regression/CodeUpdate.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    receipt = obj("Native/HardShear.txt.ProcessClosure.json")
    ending = receipt["Closure"]["FinalState"]
    assert compiler["State"] == ending["State"] == "Absent"
    assert f"OWNED_EXCEL: id={compiler['PID']}; utcStartTicks={compiler['StartTicksUTC']}" in (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    assert update["Compiled"] and not update["ProductionChanged"] and update["ProductionSHA256"] == fixture["source_workbook_sha256"]
    assert update["Modules"] == ["CCoupledDeformationContinuation", "CCoupledNewtonSolver", "modTestCoupledElasticState"]
    assert update["WorkbookSHA256"] == owner["SourceSHA256"]
    assert receipt["Passed"] and receipt["ChildExitCode"] == 0
    assert (owner["PID"], owner["StartTicksUTC"]) == (ending["PID"], ending["StartTicksUTC"])
    saved = obj("Audit.json")
    if args.saved_workbook:
        assert digest(args.saved_workbook) == saved["saved_workbook_sha256"]
    log = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_NEXT: passed=1; failed=0" in log
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    assert f"RESULTS_SAVE_REOPEN: before={saved['results_reopen_sha256']}; after={saved['results_reopen_sha256']}; equal=True" in log
    report = obj("Native/Verification.json")
    assert sums["Native/HardNext.csv"] == report["source_trace_sha256"]
    assert sums["Native/HardShear.txt"] == report["native_log_sha256"]
    assert sums["Native/Verification.json"] == saved["native_report_sha256"]
    cases, skipped = parse(HERE / "Native/HardNext.csv", expected)
    assert cases == report["cases"] and skipped == report["skipped"] == {}
    assert report["stock_failure_reproduced"] and not report["capacity_or_failure_certified"]
    assert not cases["A"]["solved"] and not cases["B"]["certified_at_original_target"]
    assert cases["B"]["certified_balanced_this_control"]
    assert (cases["B"]["crossings"][0]["fixture_point"], cases["B"]["crossings"][0]["axial_side"]) == (37, 1)
    assert cases["C"]["certified_at_original_target"] and not cases["C"]["yield_recovery_attempted"]
    print("HARDSHEAR H21 PORTABLE VERIFIED")


if __name__ == "__main__":
    main()
