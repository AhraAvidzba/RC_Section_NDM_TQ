"""ДЛЯ ТЕСТОВ: повторяет общее продолжение со спектральным восстановлением и точную цель около lambda=1."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory


def TestValidate(repo, root, phase, output):
    """Проверяет полные истории и отдельный точный НДС от исходных 143 состояний без поздней материальной истории."""
    here = Path(__file__).resolve().parent
    scale = 80679.2 if phase == 'Near143' else 75000.
    start = 74 if phase == 'Trace74' else 143
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch)
        main = scratch/'Main.json'
        run_path(str(here/'Validate-TestGeneralContinuation.py'))['TestValidate'](repo, root, phase, main, start, scale, phase != 'Near143')
        proof = {'continuation': json.loads(main.read_bytes()), 'physical_capacity_certified': False}
        if phase == 'Near143':
            prefix, native = scratch/'Prefix', scratch/'Design'
            prefix.mkdir(); native.mkdir()
            for target, source in (('Operators.csv', 'Trace74.Operators.csv'), ('MVTGaussMixed.csv', 'Trace74.csv'),
                                   ('MVTGaussMixed.Tensor.csv', 'Trace74.Tensor.csv')):
                (prefix/target).write_bytes((root/'Reference'/source).read_bytes())
            for target, source in (('Operators.csv', phase+'.Design.Operators.csv'), ('MVTGaussMixed.csv', phase+'.Design'),
                                   ('MVTGaussMixed.Tensor.csv', phase+'.Design.Tensor.csv')):
                (native/target).write_bytes((root/'Native'/source).read_bytes())
            result = scratch/'Design.json'
            run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo, native, result, prefix_native=prefix)
            design = json.loads(result.read_bytes())
            assert len(design['states']) == 144
            assert design['states'][-1]['label'] == 'ExactDesign'
            assert design['states'][-1]['target_N_Nmm'] == [0., -396.*scale, 0., 10510000., 0., scale]
            log = (root/'Native'/(phase+'.txt')).read_text('utf-8-sig')
            assert 'PRODUCTION_EXACT_DESIGN;80679.2;True' in log
            proof['exact_design_from_original_prefix'] = design
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('WORKING SIGN CONTINUATION AND EXACT TARGET VERIFIED', phase, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--phase', choices=('Trace74', 'Trace143', 'Near143'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestValidate(args.repo.resolve(), args.root.resolve(), args.phase, args.out.resolve())
