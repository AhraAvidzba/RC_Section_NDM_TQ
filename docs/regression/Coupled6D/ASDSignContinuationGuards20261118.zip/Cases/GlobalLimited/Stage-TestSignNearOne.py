"""ДЛЯ ТЕСТОВ: проверяет принятие материального перехода с малым изменением lambda и точное сочетание около единицы."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Добавляет только нормировку того же физического пути и отдельный экспорт точного НДС lambda=1."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestSignContinuation.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    name = 'tests/modTestMVT2ProductionASDTest.bas'
    code = (root/name).read_text('utf-8-sig')
    old = '        Case "Trace44", "Trace74", "Trace143"'
    assert code.count(old) == 1
    code = code.replace(old, '        Case "Near143"\n            completed = RunProductionContinuationTest(143, report, tracePath, 80679.2)\n'+old)
    (root/name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'
    code = (root/runner).read_text('utf-8-sig')
    assert code.count("'Trace143'") == 4
    code = code.replace("'Trace143'", "'Trace143','Near143'")
    old = "foreach ($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv'))"
    assert code.count(old) == 1
    code = code.replace(old, "foreach ($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv','.Design','.Design.Tensor.csv','.Design.Operators.csv'))")
    (root/runner).write_bytes(code.encode('utf-8-sig'))
    script = Path(__file__)
    (root/script.name).write_bytes(script.read_bytes())
    for relative in (name, runner, script.name):
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    prep['directed_scope']['traces'] = ['Trace74', 'Trace143', 'Near143']
    prep['directed_scope']['near_one_force_scale_N'] = 80679.2
    prep['directed_scope']['exact_design_fields_saved_separately'] = True
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
