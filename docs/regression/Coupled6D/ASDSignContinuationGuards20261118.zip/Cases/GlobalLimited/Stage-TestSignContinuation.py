"""ДЛЯ ТЕСТОВ: готовит штатное продолжение после знакового восстановления без инструментирования решателя."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestStage(repo, root):
    """Использует полную собственную историю 143 состояний; все дальнейшие поля решаются рабочими классами."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestFieldRecovery.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    raw = (repo/'docs/regression/Coupled6D/AnalyticASDTangent20261118.zip').read_bytes()
    digest = '5192BCB5A1A5FB91305ABA31BA1C06EFA2313E2B0F4A29E97E9128F773AA390F'
    assert sha256(raw).hexdigest().upper() == digest
    with ZipFile(BytesIO(raw)) as archive:
        for name in ('Trace74.csv', 'Trace74.Operators.csv', 'Trace74.Tensor.csv'):
            value = archive.read('Cases/Final/Native/'+name)
            target = root/'Reference'/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(value)
            prep['inputs']['Reference/'+name] = sha256(value).hexdigest().upper()
    loads, fields = {}, []
    for line in (root/'Reference/Trace74.Tensor.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME': loads[row[1]] = row[2:4]
    for line in (root/'Reference/Trace74.Operators.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'F': fields.append(';'.join([row[1], *loads[row[1]], *row[2:]]))
    assert len(fields) == 143
    (root/'AcceptedHistory.csv').write_bytes(('\r\n'.join(fields)+'\r\n').encode())
    name = 'tests/modTestMVT2ProductionASDTest.bas'
    code = (root/name).read_text('utf-8-sig')
    old = 'Case "Trace44", "Trace74"'
    assert code.count(old) == 1
    code = code.replace(old, 'Case "Trace44", "Trace74", "Trace143"')
    (root/name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'
    code = (root/runner).read_text('utf-8-sig')
    assert code.count("'Trace74'") == 4
    code = code.replace("'Trace74'", "'Trace74','Trace143'")
    (root/runner).write_bytes(code.encode('utf-8-sig'))
    script = Path(__file__)
    (root/script.name).write_bytes(script.read_bytes())
    for relative in ('AcceptedHistory.csv', name, runner, script.name):
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'traces': ['Trace74', 'Trace143'], 'maximum_probe_count': 96, 'observation_seconds': 480,
                              'continuation_prefix_states': 143, 'parent_archive_sha256': digest, 'full_acceptance': False}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('WORKING SIGN CONTINUATION READY; 143 OWN PREFIX STATES; SAME 96-PROBE BUDGET')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
