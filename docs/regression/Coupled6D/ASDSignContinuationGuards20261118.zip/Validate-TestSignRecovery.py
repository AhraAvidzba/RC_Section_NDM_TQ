"""ДЛЯ ТЕСТОВ: проверяет собственное равновесие, восстановленное у знаковой границы ASD."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestValidate(repo, root, output, expected_sign=-1):
    """Повторяет весь префикс и нативную пробу; проверяет действительную новую меру вместо исходной отклонённой."""
    here = Path(__file__).resolve().parent
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch)
        prefix, native = scratch/'Prefix', scratch/'Native'
        prefix.mkdir(); native.mkdir()
        for target, source in (('Operators.csv', 'ControlProbe.Operators.csv'), ('MVTGaussMixed.csv', 'ControlProbe.csv'),
                               ('MVTGaussMixed.Tensor.csv', 'ControlProbe.Tensor.csv')):
            (native/target).write_bytes((root/'Native'/source).read_bytes())
        for target, source in (('Operators.csv', 'Trace74.Operators.csv'), ('MVTGaussMixed.csv', 'Trace74.csv'),
                               ('MVTGaussMixed.Tensor.csv', 'Trace74.Tensor.csv')):
            (prefix/target).write_bytes((root/'Reference'/source).read_bytes())
        section, _, fields = run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo, native, scratch/'Proof.json', prefix_native=prefix)
        proof = json.loads((scratch/'Proof.json').read_bytes())
    assert len(fields) == 144
    rows = [line.split(';') for line in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    probe, = [row for row in rows if row[0] == 'CONTROL_PROBE']
    assert probe[1:3] == ['ShearY0.5', 'True']
    projection, = [row for row in rows if row[0] == 'SIGN_RECOVERED_PROJECTION']
    coordinate, = [row for row in rows if row[0] == 'SIGN_RECOVERED_COORDINATE']
    field = fields[-1][1]
    control_error = abs(30000.*(np.asarray(projection[2:], dtype=float)@field-float(coordinate[2])))
    assert control_error <= proof['states'][-1]['tolerance_MPa']
    assert abs(float(probe[4])*75000.-proof['states'][-1]['target_N_Nmm'][5]) < 1e-6
    restored, history, _, _, _, _ = run_path(str(here/'Solve-TestRejectedDirection.py'))['TestRestore'](repo, root)
    assert np.array_equal(section.b, restored.b)
    strain = (section.b@field)[2, 35]
    delta = strain-history[0][2, 35]
    trial = history[1][2, 35]+delta*np.array([25000.]*3+[12500.]*3)
    trial[:3] += (25000./3.)*sum(delta[:3])
    tensor = np.diag(trial[:3])
    for index, (a, b) in enumerate(((0, 1), (0, 2), (1, 2)), 3): tensor[a, b] = tensor[b, a] = trial[index]
    principal = np.linalg.eigvalsh(tensor)
    assert expected_sign*principal[0] > 0. and abs(principal[0]) < .125*proof['states'][-1]['tolerance_MPa']+2e-12
    proof.update({'prefix_states': 143, 'native_accepted_states': 1, 'maximum_control_error_MPa': float(control_error),
                  'boundary_point_ID': 36, 'boundary_station': -1, 'boundary_principal_index': 3,
                  'trial_principal_MPa': principal.tolist(), 'expected_boundary_sign': expected_sign,
                  'external_equilibrium_seed': False, 'physical_capacity_certified': False})
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE ASD SIGN RECOVERY ALL SIX EQUATIONS AND FULL HISTORY VERIFIED', proof['states'][-1]['target_N_Nmm'][5], flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--sign', type=int, choices=(-1, 1), default=-1)
    args = parser.parse_args()
    TestValidate(args.repo.resolve(), args.root.resolve(), args.out.resolve(), args.sign)
