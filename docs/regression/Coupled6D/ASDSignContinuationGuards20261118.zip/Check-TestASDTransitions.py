"""ДЛЯ ТЕСТОВ: проверяет точный VBA, спектральные переходы и фактическое продолжение при неизменном материале."""
from argparse import ArgumentParser
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import numpy as np


def TestRead(file):
    """Читает нативный JSON с сохранением числовых и строковых значений."""
    return json.loads(file.read_text('utf-8-sig'))


def TestTicks(value):
    """Преобразует DateTimeOffset в точные 100-нс тики без потери последней цифры через float."""
    match = re.fullmatch(r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.(\d{1,7}))?([+-]\d\d:\d\d|Z)', value)
    assert match
    whole = datetime.fromisoformat(match[1]+match[3].replace('Z', '+00:00')).astimezone(timezone.utc)
    delta = whole-datetime(1, 1, 1, tzinfo=timezone.utc)
    return (delta.days*86400+delta.seconds)*10000000+int((match[2] or '').ljust(7, '0'))


def TestNative(repo, root, output):
    """Декодирует все компоненты, проверяет закрытие собственных Excel и отделяет отказ пробы от выполнения диагностического набора."""
    shared = run_path(str(root/'Check-TestMaterialRoundoff.py'))
    shared['TestFiles'](root)
    source, _ = run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    cases = {}
    required = {'Direction': {'ControlProbe'}, 'First': {'ControlProbe', 'Tangent'}, 'Near': {'Near143'},
                'Opposite': {'ControlProbe'}, 'Rejected': {'Core', 'Trace143'}, 'GlobalLimited': {'Trace74'},
                'Final': {'Core', 'Material', 'Tangent', 'Stock', 'Trace74', 'Trace143', 'Near143'}}
    for key in TestRead(root/'Cases.json'):
        folder = root/'Cases'/key
        record = shared['TestSourceComparison'](repo, root, folder, source, original, helper, body, reader)
        imports = 22 if key == 'Direction' else 23
        assert record['components'] == 238 and record['imported'] == imports and record['unchanged'] == 238-imports
        compiler = TestRead(folder/'docs/regression/CodeUpdate.json')
        reports = {}
        for log in sorted((folder/'Native').glob('*.txt')):
            text = log.read_text('utf-8-sig'); phase = log.stem
            closure = TestRead(log.with_name(log.name+'.ProcessClosure.json'))
            owner = TestRead(log.with_name(log.name+'.Ownership.json'))
            assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['RunnerCleanupValid']
            assert closure['Closure']['FinalState']['State'] == 'Absent'
            identity = closure['Closure']['Identity']
            assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == compiler['WorkbookSHA256']
            assert 'SOURCE_UNCHANGED: True' in text and 'RUNTIME ERROR:' not in text
            totals = [tuple(map(int, row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', text, re.M)]
            assert totals and all(failed == 0 for passed, failed in totals)
            if phase == 'Core': assert sum(passed for passed, failed in totals) == 365
            if phase == 'Material': assert totals == [(368, 0)]
            if phase == 'Tangent': assert totals == [(274, 0)]
            if phase == 'Stock':
                assert totals == [(28, 0)]
                assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10460833943358; limit=;' in text
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;', text, re.M)
            if phase == 'ControlProbe':
                rows = [line.split(';') for line in text.splitlines() if line.startswith('CONTROL_PROBE;')]
                assert len(rows) == 1 and rows[0][1] == 'ShearY0.5'
                assert rows[0][2] == ('False' if key == 'Direction' else 'True')
            if phase in ('Trace74', 'Trace143', 'Near143'):
                count, = re.findall(r'^PRODUCTION_PATH_COUNT;(\d+)$', text, re.M)
                assert int(count) >= (74 if phase == 'Trace74' else 143)
                if key in ('Rejected', 'GlobalLimited'): assert int(count) == 143
                if key == 'Near': assert int(count) == 144
            reports[phase] = {'assertions': sum(passed for passed, failed in totals), 'physical_capacity_certified': False}
        assert set(reports) == required[key], (key, set(reports))
        protections = []
        if (folder/'ExternalExcelProtection.json').exists():
            values = TestRead(folder/'ExternalExcelProtection.json')
            protections = values if isinstance(values, list) else [values]
        blocked = 0; naturally_absent = 0
        safety = list(map(json.loads, (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()))
        for position, row in enumerate(safety):
            assert row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6
            unprotected = [item for item in row['excel'] if not item['ProtectedUser']]
            if unprotected:
                assert key == 'First' and row['phase'] in ('CompileWorkingASD', 'VerifyWorkingASDControlProbe')
                for item in unprotected:
                    pins = [p for p in protections if p['PID'] == item['Id'] and int(p['StartTicksUTC']) == TestTicks(item['StartTime'])]
                    if pins:
                        pin, = pins
                        assert pin['Class'] == 'ProtectedExternalPreexisting' and not pin['OwnerIsCurrentTask'] and not pin['CloseRequested']
                    else:
                        # Повтор до создания собственного Excel не обнаружил прежнюю точную личность стороннего экземпляра.
                        later = [r for r in safety[position+1:] if r['phase'] == row['phase'] and all(p['ProtectedUser'] for p in r['excel'])]
                        assert later and not any(p['Id'] == item['Id'] and TestTicks(p['StartTime']) == TestTicks(item['StartTime']) for p in later[0]['excel'])
                        naturally_absent += 1
                    assert TestTicks(item['StartTime']) < TestTicks(row['utc'])
                blocked += 1
        if key == 'First':
            assert blocked == 2 and len(protections) == 1 and naturally_absent == 1
            original_guard = (root/'Cases/Direction/Guard-IsolatedOffice.ps1').read_bytes()
            assert sha256(original_guard).hexdigest().upper() == protections[0]['InitialGuardSHA256']
            guard = (folder/'Guard-IsolatedOffice.ps1').read_bytes().decode('utf-8-sig')
            inserted = '$protected['+str(protections[0]['PID'])+']=[long]'+protections[0]['StartTicksUTC']+'\r\n'
            assert guard.count(inserted) == 1 and guard.replace(inserted, '') == original_guard.decode('utf-8-sig')
        record.update({'reports': reports, 'preflight_blocks_resolved_without_closing_external_excel': blocked,
                       'external_processes_absent_before_retry': naturally_absent,
                       'physical_capacity_certified': False})
        if key == 'Final':
            baseline = repo/'docs/regression/Coupled6D/AnalyticASDTangent20261118.zip'
            assert sha256(baseline.read_bytes()).hexdigest().upper() == '5192BCB5A1A5FB91305ABA31BA1C06EFA2313E2B0F4A29E97E9128F773AA390F'
            with ZipFile(baseline) as archive:
                for name in ('default.Native.csv', 'default.Probes.csv', 'ndm_uniaxial.Native.csv', 'ndm_uniaxial.Probes.csv'):
                    assert (folder/'Data'/name).read_bytes() == archive.read('Cases/Final/Data/'+name)
            prep = TestRead(folder/'Preparation.json')
            with TemporaryDirectory() as scratch:
                restored = Path(scratch)
                for name, digest in prep['inputs'].items():
                    raw = source if name == 'workbook/output/RC_Section_NDM.xlsm' else (folder/name).read_bytes()
                    assert sha256(raw).hexdigest().upper() == digest
                    target = restored/name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(raw)
                target = restored/'docs/regression/Diagnostic.xlsm'
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source)
            record['baseline_material_files_byte_equal'] = 4
            record['clean_input_restoration'] = {'inputs': len(prep['inputs']), 'compiled_or_calculated_state_reused': False, 'excel_started': False}
        cases[key] = record
    output.write_bytes((json.dumps({'cases': cases, 'installed_workbook_changed': False,
        'full_acceptance_completed': False, 'physical_capacity_certified': False}, indent=2, sort_keys=True)+'\n').encode())
    print('ASD TRANSITIONS EXACT VBA AND DIRECTED NATIVE REGRESSIONS VERIFIED; PHYSICAL LIMIT OPEN')


def TestResearch(repo, root, scratch):
    """Повторяет сохранённые положительные и отрицательные исследовательские пробы, не перезапуская недетерминированный оптимизатор."""
    section, history, _, _, _, _ = run_path(str(root/'Solve-TestRejectedDirection.py'))['TestRestore'](repo, root/'Cases/Direction')
    fields = [line.split(';') for line in (root/'Cases/Direction/AcceptedHistory.csv').read_text().splitlines()]
    current = np.asarray(fields[-1][3:], dtype=float)
    constant = np.array([0., 0., 0., 10510000., 0., 0.]); direction = np.array([0., -396.*75000., 0., 0., 0., 75000.])
    shear = np.einsum('p,pd->d', section.weight[:100], section.b[0, :100, 5])/57600.
    results = {}
    for name in ('AfterAnalyticPeakCritical20261118.json', 'AfterASDPeakFieldControl20261118.json'):
        proof = TestRead(root/'Research'/name); errors = []
        for record in proof['cases'].values():
            field = np.asarray(record['field']); load = constant+record['lambda']*direction
            evaluated = section.TestEvaluate(field, history, load)
            projection = np.asarray(record['projection'])
            target = record['base_control']+record['multiple']*record['control_spacing']
            norm = max(evaluated[1], abs(30000.*(projection@field-target)))
            assert abs(norm-record['norm_MPa']) < 8e-7
            assert bool(norm <= record['tolerance_MPa']) == record['solved']
            errors.append(float(norm))
        results[name] = {'cases': len(errors), 'equilibria': sum(record['solved'] for record in proof['cases'].values())}
    proof = TestRead(root/'Research/AfterASDPeakMerit20261118.json')
    _, _, _, _, projection, target = run_path(str(root/'Solve-TestRejectedDirection.py'))['TestRestore'](repo, root/'Cases/Direction')
    for method, record in proof.items():
        field = np.asarray(record['field']); evaluated = section.TestEvaluate(field, history, constant+record['lambda']*direction)
        norm = max(evaluated[1], abs(30000.*(projection@field-target)))
        assert abs(norm-record['norm_MPa']) < 8e-7 and not record['equilibrium_verified'] and norm > record['tolerance_MPa']
    results['merit'] = {'variants': 2, 'equilibria': 0, 'optimizer_rerun': False}
    proof = TestRead(root/'Research/AfterASDPeakContinuation20261118.json')
    assert proof['accepted_states'] == 2 and proof['attempts'] == 9
    accepted = 0
    for record in proof['trials']:
        field = np.asarray(record['field']); evaluated = section.TestEvaluate(field, history, constant+record['lambda']*direction)
        norm = max(evaluated[1], abs(30000.*(shear@field-record['target_control'])))
        assert abs(norm-record['norm_MPa']) < 8e-7 and bool(norm <= record['tolerance_MPa']) == record['solved']
        if record['solved']: history = evaluated[4]; accepted += 1
    assert accepted == 2
    results['adaptive'] = {'requested_states': 32, 'accepted_states': 2, 'native_implementation_verified': False}
    return results


def TestMechanics(repo, root, output):
    """Проверяет реальные материальные ветви и все шесть усилий принятых нативных путей."""
    run_path(str(root/'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    group = TestRead(root/'SourceCheckpoint.json')['group']; results = {}
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch)
        if group == 'probes':
            direction = root/'Cases/Direction'
            result = scratch/'Direction.json'
            run_path(str(root/'Analyze-TestRejectedDirection.py'))['TestAnalyze'](repo, direction, result)
            results['direction'] = TestRead(result)
            result = scratch/'Point36.json'
            run_path(str(root/'Analyze-TestLocalTransition.py'))['TestAnalyze'](repo, direction, result, 36)
            local = TestRead(result)
            assert len(local['states']) == 15
            for row in local['states']:
                if row['station'] == -1:
                    expected = 0 if row['fraction'] in (1./128., 1./256.) else 1
                    assert {t['negative_principal_count'] for t in row['closure_trace']} == {expected}
            results['point36'] = local
            for key, sign in (('First', -1), ('Opposite', 1)):
                result = scratch/(key+'.json')
                run_path(str(root/'Validate-TestSignRecovery.py'))['TestValidate'](repo, root/'Cases'/key, result, sign)
                results[key] = TestRead(result)
            result = scratch/'Boundaries.json'
            run_path(str(root/'Check-TestPrincipalBoundary.py'))['TestCheck'](root/'Cases/First', result)
            results['boundaries'] = TestRead(result)
            result = scratch/'Near.json'
            run_path(str(root/'Validate-TestSignContinuation.py'))['TestValidate'](repo, root/'Cases/Near', 'Near143', result)
            results['near'] = TestRead(result)
            results['research'] = TestResearch(repo, root, scratch)
        else:
            cases = (('Rejected', 'Trace143'), ('GlobalLimited', 'Trace74')) if group == 'guards' else tuple(('Final', phase) for phase in ('Trace74', 'Trace143', 'Near143'))
            for key, phase in cases:
                result = scratch/(key+phase+'.json')
                run_path(str(root/'Validate-TestSignContinuation.py'))['TestValidate'](repo, root/'Cases'/key, phase, result)
                results[key+phase] = TestRead(result)
            if group == 'final':
                for name, function in (('Check-TestPrincipalBoundary.py', 'TestCheck'), ('Check-TestNativeASDTangent.py', 'TestCheck')):
                    result = scratch/(name+'.json')
                    run_path(str(root/name))[function](root/'Cases/Final', result)
                    results[name] = TestRead(result)
    output.write_bytes((json.dumps({'group': group, 'cases': results, 'physical_capacity_certified': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n').encode())
    print('ASD TRANSITIONS MATERIAL BRANCHES AND ALL SIX EQUILIBRIA VERIFIED; PHYSICAL LIMIT OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True); parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(); (TestNative if args.scope == 'native' else TestMechanics)(args.repo.resolve(), args.root.resolve(), args.out.resolve())
