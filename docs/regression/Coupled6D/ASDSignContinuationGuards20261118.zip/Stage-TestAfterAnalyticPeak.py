"""ДЛЯ ТЕСТОВ: закрепляет 143 собственных состояния и сохраняет следующий заблокированный сдвиговый шаг."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestStage(repo, root):
    """Меняет только тестовый префикс и пробу; рабочие алгоритмы и принятый материал неизменны."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingASD.py'))['TestStage'](repo, root)
    raw = (repo/'docs/regression/Coupled6D/AnalyticASDTangent20261118.zip').read_bytes()
    digest = '5192BCB5A1A5FB91305ABA31BA1C06EFA2313E2B0F4A29E97E9128F773AA390F'
    assert sha256(raw).hexdigest().upper() == digest
    loads, fields = {}, []
    pins = {}
    with ZipFile(BytesIO(raw)) as archive:
        for name in ('Trace74.csv', 'Trace74.Operators.csv', 'Trace74.Tensor.csv'):
            value = archive.read('Cases/Final/Native/'+name)
            target = root/'Reference'/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(value)
            pins['Reference/'+name] = sha256(value).hexdigest().upper()
        for line in (root/'Reference/Trace74.Tensor.csv').read_text('cp1251').splitlines():
            row = line.split(';')
            if row[0] == 'FRAME': loads[row[1]] = row[2:4]
        for line in (root/'Reference/Trace74.Operators.csv').read_text('cp1251').splitlines():
            row = line.split(';')
            if row[0] == 'F': fields.append(';'.join([row[1], *loads[row[1]], *row[2:]]))
    assert len(fields) == 143
    (root/'AcceptedHistory.csv').write_bytes(('\r\n'.join(fields)+'\r\n').encode())
    name = 'tests/modTestMVT2ProductionASDTest.bas'
    full = (root/name).read_text('utf-8-sig')
    begin = full.index('Private Function RunControlProbesTest(')
    end = full.index('\nEnd Function', begin)+len('\nEnd Function')
    code = full[begin:end]
    replacements = {
        'If history.Count <> 74 Then': 'If history.Count <> 143 Then',
        'Для сравнительных проб нужны 74 принятых состояния.': 'Для сравнительных проб нужны 143 принятых состояния.',
        'For index = 1 To 6': 'For index = 1 To 8',
        'Case 5\n                mode = "Twist"': 'Case 5, 6\n                mode = "Twist"',
        'Case 6\n                Dim unused()': 'Case 7, 8\n                Dim unused()',
        'factor = 32#: If index = 1 Or index = 3 Then factor = 4#': 'factor = 0.25: If index Mod 2 = 0 Then factor = 0.5',
    }
    for old, new in replacements.items():
        assert code.count(old) == 1, old
        code = code.replace(old, new)
    (root/name).write_bytes((full[:begin]+code+full[end:]).replace('\n', '\r\n').encode('utf-8-sig'))
    prep = json.loads((root/'Preparation.json').read_bytes())
    prep['inputs'].update(pins)
    for relative in (name, 'AcceptedHistory.csv'):
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root/script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['probe_scope'] = {'prefix_states': 143, 'parent_archive_sha256': digest, 'external_field_seed': False,
                           'newton_iterations_per_trial': 32, 'physical_capacity_certified': False}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    run_path(str(here/'Stage-TestRejectedDirection.py'))['TestInstrument'](root, loop_count=8, first_index=8)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
