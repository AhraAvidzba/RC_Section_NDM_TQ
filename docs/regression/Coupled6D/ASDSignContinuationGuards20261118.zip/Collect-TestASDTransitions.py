"""ДЛЯ ТЕСТОВ: сохраняет спектральный переход, предохранители продолжения и окончательные проверки раздельными комплектами."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


TestGroups = {
    'probes': {'Direction': 'AfterASDPeakDirection20261118', 'First': 'ASDSignRecovery20261118',
               'Near': 'ASDSignCoordinate20261118', 'Opposite': 'ASDSignOpposite20261118'},
    'guards': {'Rejected': 'ASDSignContinuation20261118', 'GlobalLimited': 'ASDSignFinal20261118'},
    'final': {'Final': 'ASDSignRevision20261118'},
}


def TestCollect(repo, root, group):
    """Сохраняет точные CFB и протоколы; не дублирует исходную XLSM и не подменяет отрицательные пробы."""
    here = Path(__file__).resolve().parent
    shared = run_path(str(here/'Collect-TestFieldRecovery.py'))
    shared['TestCases'].clear(); shared['TestCases'].update(TestGroups[group])
    shared['TestCollect'](repo, root)
    names = ('Collect-TestASDTransitions.py', 'Check-TestASDTransitions.py', 'Stage-TestAfterAnalyticPeak.py',
             'Stage-TestASDSignRecovery.py', 'Stage-TestSignContinuation.py', 'Stage-TestSignNearOne.py',
             'TestAfterAnalyticPeak.py', 'Continue-TestAfterASDPeak.py', 'Analyze-TestLocalTransition.py',
             'Validate-TestSignRecovery.py', 'Validate-TestSignContinuation.py', 'Check-TestPrincipalBoundary.py',
             'Check-TestNativeASDTangent.py', 'Validate-TestGeneralContinuation.py')
    for name in names:
        if (root/name).exists():
            assert (root/name).read_bytes() == (here/name).read_bytes(), name
        else:
            shared['TestCopy'](here/name, root/name)
    if group == 'probes':
        for name in ('AfterAnalyticPeakCritical20261118.json', 'AfterASDPeakMerit20261118.json',
                     'AfterASDPeakFieldControl20261118.json', 'AfterASDPeakContinuation20261118.json'):
            shared['TestCopy'](here/name, root/'Research'/name)
    (root/'SourceCheckpoint.json').write_bytes((json.dumps({'base': 'd45ea75', 'group': group,
        'installed_workbook_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2)+'\n').encode())
    files = {p.relative_to(root).as_posix(): sha256(p.read_bytes()).hexdigest().upper()
             for p in root.rglob('*') if p.is_file() and p.name != 'Files.json'}
    (root/'Files.json').write_bytes((json.dumps(files, indent=2, sort_keys=True)+'\n').encode())
    print('ASD TRANSITION EVIDENCE COLLECTED', group, len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--group', choices=tuple(TestGroups), required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve(), args.group)
