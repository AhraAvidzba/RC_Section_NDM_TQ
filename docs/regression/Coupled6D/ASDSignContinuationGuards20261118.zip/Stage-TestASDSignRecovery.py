"""ДЛЯ ТЕСТОВ: проверяет сопровождение знаковой границы ASD на точной заблокированной пробе."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Разрешает рабочее восстановление только в отдельной пробе; внешний начальный НДС не передаётся."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestAfterAnalyticPeak.py'))['TestStage'](repo, root)
    name = 'tests/modTestMVT2ProductionASDTest.bas'
    code = (root/name).read_text('utf-8-sig')
    old = 'ATOL, RTOL, 32, consistentControl:=consistent, initialField:=initial)'
    assert code.count(old) == 1
    code = code.replace(old, 'ATOL, RTOL, 32, recoverYieldControl:=True, consistentControl:=consistent, initialField:=initial)')
    old = '            solver.CopyTrial trial, actual: solver.AcceptStep'
    assert code.count(old) == 1
    code = code.replace(old, '''            solver.CopyTrial trial, actual
            Dim recovered() As Double, recoveredCoordinate As Double
            If solver.CopyRecoveredControl(recovered) Then
                row = "SIGN_RECOVERED_PROJECTION;" & phase
                For i = 1 To UBound(recovered)
                    row = row & ";" & ExperimentNumberTest(recovered(i))
                    recoveredCoordinate = recoveredCoordinate + recovered(i) * trial(i)
                Next i
                AddExperimentTraceTest report, tracePath, row
                AddExperimentTraceTest report, tracePath, "SIGN_RECOVERED_COORDINATE;" & phase & ";" & ExperimentNumberTest(recoveredCoordinate)
            End If
            solver.AcceptStep''')
    (root/name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep = json.loads((root/'Preparation.json').read_bytes())
    prep['inputs'][name] = sha256((root/name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root/script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['probe_scope']['working_sign_recovery_enabled'] = True
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
