"""ДЛЯ ТЕСТОВ: прослеживает следующую собственную последовательность с неизменным сдвиговым управлением."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestRun(repo, output):
    """Проверяет до 32 новых шагов, фиксируя историю только после полного исходного равновесия."""
    here = Path(__file__).resolve().parent
    section, history, fields, prefix = run_path(str(here/'TestAfterAnalyticPeak.py'))['TestRestore'](repo)
    previous, current = (row[1] for row in fields[-2:])
    old_lambda, lam = (row['target_N_Nmm'][5]/75000. for row in prefix['states'][-2:])
    projection = np.einsum('p,pd->d', section.weight[:section.TestConcreteCount], section.b[0, :section.TestConcreteCount, 5])/57600.
    spacing = float(projection@(current-previous))
    assert spacing > 0.
    step = .25*spacing
    minimum, ceiling = step/64., 32.*step
    solve = run_path(str(here/'Solve-TestRejectedDirection.py'))['TestSolve']
    trials = []
    accepted = 0
    while accepted < 32 and len(trials) < 48 and step >= minimum:
        ratio = step/spacing
        target = float(projection@current)+step
        record = solve(section, history, current+ratio*(current-previous), lam+ratio*(lam-old_lambda), projection, target, 'local')
        record.update({'attempt': len(trials)+1, 'accepted_before_trial': accepted, 'step': step, 'target_control': target})
        trials.append(record)
        if record['solved']:
            field = np.asarray(record['field'])
            factor = record['lambda']
            load = np.array([0., -396.*75000.*factor, 0., 10510000., 0., 75000.*factor])
            verified = section.TestEvaluate(field, history, load)
            assert verified[1] <= record['tolerance_MPa']
            history = verified[4]
            previous, current = current, field
            old_lambda, lam = lam, factor
            spacing = float(projection@(current-previous))
            assert spacing > 0.
            accepted += 1
            step = min(ceiling, 1.25*step)
        else:
            step *= .5
        proof = {'prefix_states': 143, 'requested_states': 32, 'accepted_states': accepted, 'attempts': len(trials),
                 'trials': trials, 'native_implementation_verified': False, 'physical_capacity_certified': False}
        output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
        print(len(trials), record['solved'], record['Qy_N'], record['norm_MPa'], 'accepted', accepted, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.out.resolve())
