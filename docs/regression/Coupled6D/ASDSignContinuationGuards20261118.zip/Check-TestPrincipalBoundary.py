"""ДЛЯ ТЕСТОВ: независимо проверяет нативные знаковые координаты ASD через собственные векторы NumPy."""
from argparse import ArgumentParser
import json
from pathlib import Path
import numpy as np


def TestCheck(root, output):
    """Сверяет все главные значения и шесть производных до и после принятия материальной истории."""
    cases = []
    for name in ('default', 'ndm_uniaxial'):
        head = (root/'Data'/f'{name}.csv').read_text().splitlines()[0].split(';')
        assert head[0] == 'ASDFlow1'
        modulus, poisson = map(float, head[1:])
        shear = modulus/(2.*(1.+poisson))
        lame = 2.*shear*poisson/(1.-2.*poisson)
        elastic = np.diag([2.*shear]*3+[shear]*3)
        elastic[:3, :3] += lame
        for line in (root/'Data'/f'{name}.Boundary.csv').read_text('cp1251').splitlines():
            row = line.split(';')
            assert row[:2] == ['BOUNDARY', name] and len(row) == 29
            epoch, rank = map(int, row[2:4])
            values = np.asarray(row[4:], dtype=float)
            trial = values[12:18]+elastic@(values[:6]-values[6:12])
            tensor = np.diag(trial[:3])
            for i, (a, b) in enumerate(((0, 1), (0, 2), (1, 2)), 3): tensor[a, b] = tensor[b, a] = trial[i]
            eigen, axes = np.linalg.eigh(tensor)
            vector = axes[:, 3-rank]
            expected = np.r_[2.*shear*vector**2+lame, 2.*shear*vector[0]*vector[1],
                             2.*shear*vector[0]*vector[2], 2.*shear*vector[1]*vector[2]]
            value_error = abs(eigen[3-rank]-values[18])
            gradient_error = np.max(np.abs(expected-values[19:25]))
            assert value_error < 2e-11 and gradient_error < 3e-7, (row[:4], value_error, gradient_error)
            cases.append({'name': name, 'epoch': epoch, 'rank': rank, 'value_error_MPa': float(value_error),
                          'gradient_error_MPa': float(gradient_error)})
    assert len(cases) == 12
    output.write_bytes((json.dumps({'cases': cases, 'physical_capacity_certified': False}, indent=2, sort_keys=True)+'\n').encode())
    print('INDEPENDENT PRINCIPAL BOUNDARY VALUES AND GRADIENTS VERIFIED', len(cases), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestCheck(args.root.resolve(), args.out.resolve())
