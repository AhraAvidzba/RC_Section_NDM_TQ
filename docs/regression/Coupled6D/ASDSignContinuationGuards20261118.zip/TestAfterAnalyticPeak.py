"""ДЛЯ ТЕСТОВ: проверяет возможность продолжить последнюю собственную нисходящую ветвь с неизменным материалом."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import numpy as np


def TestRestore(repo):
    """Восстанавливает все 143 собственных состояния из закреплённого архива и проверяет исходные уравнения."""
    here = Path(__file__).resolve().parent
    raw = (repo/'docs/regression/Coupled6D/AnalyticASDTangent20261118.zip').read_bytes()
    assert sha256(raw).hexdigest().upper() == '5192BCB5A1A5FB91305ABA31BA1C06EFA2313E2B0F4A29E97E9128F773AA390F'
    with ZipFile(BytesIO(raw)) as archive, TemporaryDirectory() as scratch:
        scratch = Path(scratch)
        for target, source in (('Operators.csv', 'Trace74.Operators.csv'), ('MVTGaussMixed.csv', 'Trace74.csv'),
                               ('MVTGaussMixed.Tensor.csv', 'Trace74.Tensor.csv')):
            (scratch/target).write_bytes(archive.read('Cases/Final/Native/'+source))
        section, history, fields = run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo, scratch, scratch/'Replay.json')
        proof = json.loads((scratch/'Replay.json').read_bytes())
    assert len(fields) == 143
    return section, history, fields, proof


def TestRun(repo, output):
    """Сравнивает восемь одинаково ограниченных проб сдвига и полной физической секущей без изменения закона."""
    here = Path(__file__).resolve().parent
    section, history, fields, proof = TestRestore(repo)
    previous, current = (item[1] for item in fields[-2:])
    old_lambda, lam = (item['target_N_Nmm'][5]/75000. for item in proof['states'][-2:])
    change = current-previous
    shear = np.einsum('p,pd->d', section.weight[:section.TestConcreteCount], section.b[0, :section.TestConcreteCount, 5])/57600.
    weights = section.weight/(3.*np.sum(section.weight))
    metric = np.einsum('spki,p,k,spkj->ij', section.b, weights, np.array([1., 1., 1., .5, .5, .5]), section.b)
    secant = metric@change/np.sqrt(change@metric@change)
    result = {'prefix_states': len(fields), 'base_Qy_N': 75000.*lam, 'cases': {}, 'physical_capacity_certified': False}
    solve = run_path(str(here/'Solve-TestRejectedDirection.py'))['TestSolve']
    for name, projection in (('MeanShear', shear), ('FieldSecant', secant)):
        control = float(projection@current)
        spacing = float(projection@change)
        if spacing < 0.:
            projection, control, spacing = -projection, -control, -spacing
        assert spacing > 0.
        for multiple in (.25, .5, 1., 2.):
            seed = current+multiple*change
            factor = lam+multiple*(lam-old_lambda)
            record = solve(section, history, seed, factor, projection, control+multiple*spacing, 'local')
            record.update({'multiple': multiple, 'base_control': control, 'control_spacing': spacing,
                           'projection': projection.tolist()})
            result['cases'][name+str(multiple)] = record
            output.write_bytes((json.dumps(result, indent=2, sort_keys=True)+'\n').encode())
            print(name, multiple, record['solved'], record['Qy_N'], record['norm_MPa'], len(record['steps']), flush=True)
    failed = result['cases']['MeanShear0.5']
    anchor = np.asarray(failed['field'])
    direction = np.array([0., -396.*75000., 0., 0., 0., 75000.])
    matrix = run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix'](section, anchor, history)[0]
    n = len(current)
    augmented = np.zeros((n+1, n+1))
    augmented[:n, :n] = matrix
    augmented[:n, n] = -direction@section.l
    augmented[n, :n] = 30000.*shear
    augmented[:n] *= section.gauge_scale[:, None]
    units = 1./np.maximum(1e-20, np.max(np.abs(augmented), axis=0))
    _, singular, vh = np.linalg.svd(augmented*units)
    move = (vh[-1]*units)[:n]
    move[-4:] = 0.
    if move@metric@change < 0.: move = -move
    projection = metric@move/np.sqrt(move@metric@move)
    control, spacing = float(projection@current), float(projection@change)
    assert spacing > 0.
    result['critical_singular_values'] = singular.tolist()
    for multiple in (.25, .5, 1., 2.):
        record = solve(section, history, current+multiple*change, lam+multiple*(lam-old_lambda),
                       projection, control+multiple*spacing, 'local')
        record.update({'multiple': multiple, 'base_control': control, 'control_spacing': spacing,
                       'projection': projection.tolist()})
        result['cases']['CriticalField'+str(multiple)] = record
        output.write_bytes((json.dumps(result, indent=2, sort_keys=True)+'\n').encode())
        print('CriticalField', multiple, record['solved'], record['Qy_N'], record['norm_MPa'], len(record['steps']), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.out.resolve())
