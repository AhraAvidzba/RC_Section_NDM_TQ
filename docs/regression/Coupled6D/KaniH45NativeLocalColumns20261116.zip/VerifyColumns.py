"""Reassemble the native material-column comparison on the exact H45 fixture."""
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import runpy


ROOT = Path(__file__).resolve().parent
BOOK = 'A90C7A5E610C19D2C3CF0D7DB12831651DB12EEFD052E5DBED1378EE3C2C04FA'
CONCRETE = '3B9368A94209FA50E5E4EB4600A998E30C4E81CA00BBCC5A1F2CD7A9CCB6560A'
PREDICTION = '8B0BFA8D0C5AC7E55F5549A85A5D7242BC9C461FF34A529774449F6DD23C916D'
FIXTURE = 'E22E42CEAACC2D0DC0AA052377E0134F898F26BFF9693E49A3AD5A5971D8FFC1'


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def custody(arm):
    root = ROOT / arm
    native = root / 'Native'
    compiled = read(root / 'CodeUpdate.json')
    compile_owner = read(root / 'CompileClosure.json')
    owner = read(native / 'Columns.txt.Ownership.json')
    watch = read(native / 'Columns.txt.ProcessClosure.json')
    final = watch['Closure']['FinalState']
    assert compiled['Compiled'] and not compiled['ProductionChanged'] and compiled['ProductionSHA256'] == BOOK
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256'] == compiled['WorkbookSHA256']
    assert compile_owner['State'] == final['State'] == 'Absent'
    assert owner['PID'] == final['PID'] and str(owner['StartTicksUTC']) == str(final['StartTicksUTC'])
    assert compile_owner['PID'] != final['PID'] or compile_owner['StartTicksUTC'] != final['StartTicksUTC']
    modules = sorted(compiled['Modules'])
    assert modules == (['modTestKaniStage38'] if arm == 'A' else ['CCoupledConcreteResponse', 'modTestKaniStage38'])
    report = (native / 'Columns.txt').read_text(encoding='utf-8-sig')
    assert 'TOTAL_KANI_LOCAL_COLUMNS: passed=10; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in report
    assert f'SOURCE_SHA256: {compiled["WorkbookSHA256"]}' in report
    assert datetime.fromisoformat(final['ObservedUTC']).tzinfo
    inputs = read(root / 'Inputs.json')
    assert inputs['workbook/output/RC_Section_NDM.xlsm'] == BOOK and inputs['KaniLocalFixture.csv'] == FIXTURE
    if arm == 'C':
        assert inputs['src/Materials/CCoupledConcreteResponse.cls'] == CONCRETE
    return inputs, {'modules': modules, 'compiler': compile_owner, 'native': final,
                    'resultSHA256': sha(native / 'KaniLocalColumns.csv')}


def verify():
    assert sha(ROOT / 'LocalTangentAudit.json') == PREDICTION
    assert sha(ROOT / 'KaniLocalFixture.csv') == FIXTURE
    assert sha(ROOT / 'CCoupledConcreteResponse.cls') == CONCRETE
    a_inputs, a = custody('A')
    c_inputs, c = custody('C')
    assert all(c_inputs[key] == value for key, value in a_inputs.items())
    assert sha(ROOT / 'modTestKaniStage38.bas') == a_inputs['tests/modTestKaniStage38.bas']
    oracle = runpy.run_path(ROOT / 'Verify-LocalColumns.py')
    stock = oracle['history'](ROOT / 'A/Native/KaniLocalColumns.csv')
    updated = oracle['history'](ROOT / 'C/Native/KaniLocalColumns.csv')
    results = {
        'A': oracle['compare'](stock, 'A'),
        'C': oracle['compare'](updated, 'C', stock),
    }
    data = {
        'sourceSHA256': BOOK, 'sameFrozenHistoryAndTargetStrains': True, 'nativeStationsEach': 10,
        'sourceFixtureSHA256': FIXTURE, 'independentReferenceSHA256': PREDICTION,
        'verifiedSameNonSelectedColumns': True, 'acceptedHistoryUnchanged': True,
        'native': {'A': a, 'C': c}, 'tangents': results,
    }
    output = ROOT / 'ColumnsVerification.json'
    output.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
    print('PASS', sha(output), '10 stations per variant')


if __name__ == '__main__':
    verify()
