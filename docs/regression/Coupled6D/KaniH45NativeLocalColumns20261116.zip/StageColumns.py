"""Prepare the private native fixture for exact material-station comparisons."""
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile, copytree
import sys


root = Path(__file__).resolve().parents[2]
variant = sys.argv[1] if len(sys.argv) > 1 else 'C'
assert variant in ('A', 'C')
target = root / ('tmp/kcolA' if variant == 'A' else 'tmp/kcol')
comparison = root / 'tmp/kab'
audit = root / 'tmp/kani-refit/audit'
case = comparison / variant
book = Path('workbook/output/RC_Section_NDM.xlsm')
concrete = Path('src/Materials/CCoupledConcreteResponse.cls')
macro = Path('tests/modTestKaniStage38.bas')


def sha(contents):
    return sha256(contents).hexdigest().upper()


assert not target.exists()
manifest = json.loads((comparison / 'Preparation.json').read_text(encoding='utf-8-sig'))
files = {}
sources = (book, macro, Path('KaniV4Input.csv'), Path('KaniGaugeInput.csv'))
if variant == 'C':
    sources += (concrete,)
for name in sources:
    files[name] = (case / name).read_bytes()
    assert sha(files[name]) == manifest['frozen'][f'{variant}/{name.as_posix()}']
text = files[macro].decode('utf-8-sig').replace('\r\n', '\n')
start = text.index('    Dim history As New Collection,')
end = text.index('    Dim projectionX() As Double,', start)
setup = text[start:end]
new_call = '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Восстанавливает H45 и читает касательные десяти станций без изменения истории.
Public Function RunTestKaniLocalColumns(ByVal historyPath As String) As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга Kani."
''' + setup + '''    Dim rootPath As String: rootPath = Left$(historyPath, InStrRev(historyPath, "\\"))
    Dim entries As New Collection, historyFactors(38 To 45) As Double, state() As Double
    ReadKaniGaugeInputTest rootPath & "KaniGaugeInput.csv", entries, history, historyFactors
    If Not solver.ReplayAcceptedFields(history, 45) Then Err.Raise 5, , "Не восстановлена история H45."
    state = history(45)
    RequireKaniStage38FieldTest solver, state
    WriteTestKaniLocalColumns rootPath & "KaniLocalFixture.csv", ThisWorkbook.Path & "\\KaniLocalColumns.csv", materials, concrete
    RequireKaniStage38FieldTest solver, state
    RunTestKaniLocalColumns = "TOTAL_KANI_LOCAL_COLUMNS: passed=10; failed=0"
    Exit Function
Failed:
    RunTestKaniLocalColumns = "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function
'''
helper = (audit / 'KaniLocalColumns.bas.txt').read_text(encoding='utf-8-sig')
files[macro] = (text.rstrip() + new_call + '\n' + helper).replace('\n', '\r\n').encode('utf-8')
fixture = Path('KaniLocalFixture.csv')
files[fixture] = (audit / fixture).read_bytes()
assert sha(files[fixture]) == 'E22E42CEAACC2D0DC0AA052377E0134F898F26BFF9693E49A3AD5A5971D8FFC1'
for name, contents in files.items():
    path = target / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(contents)
for subfolder in ('Native', 'Temp', 'docs/regression', 'src'):
    (target / subfolder).mkdir(parents=True, exist_ok=True)
copyfile(target / book, target / 'docs/regression/Diagnostic.xlsm')
copytree(case / 'tools', target / 'tools')
copyfile(root / 'tmp/summaryproof/Candidate/Guard-IsolatedOffice.ps1', target / 'Guard-IsolatedOffice.ps1')
proof = {name.as_posix(): sha(contents) for name, contents in files.items()}
(target / 'Inputs.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
