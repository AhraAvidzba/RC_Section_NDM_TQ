# Измеряет касательные на десяти зафиксированных точках истории H45.
$ErrorActionPreference='Stop'
$previousTemp=$env:TEMP; $previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
Push-Location -LiteralPath $PSScriptRoot
try {
    . (Join-Path $PSScriptRoot 'Guard-IsolatedOffice.ps1')
    $protected[9552]=[long]639304334673501852
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    $draft='docs/regression/Diagnostic.xlsm'
    $book='workbook/output/RC_Section_NDM.xlsm'
    $report='Native/Columns.txt'
    $inputHashes=Get-Content -LiteralPath 'Inputs.json' -Raw | ConvertFrom-Json -AsHashtable
    foreach($name in $inputHashes.Keys){if((Get-FileHash -LiteralPath $name).Hash -cne $inputHashes[$name]){throw ('Изменился вход '+$name)}}
    if((Get-FileHash -LiteralPath $draft).Hash -cne $inputHashes[$book] -or (Test-Path -LiteralPath 'Compile.log')){throw 'Нужна исходная частная книга.'}
    Assert-IsolatedOfficeReady 'PreCompile'
    $modules=@('modTestKaniStage38')
    if($inputHashes.Contains('src/Materials/CCoupledConcreteResponse.cls')){$modules+='CCoupledConcreteResponse'}
    & 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $draft -ModuleNames $modules |
        Tee-Object -FilePath 'Compile.log'
    Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    if(!$compiled.Compiled -or $compiled.ProductionChanged -or $compiled.ProductionSHA256 -cne $inputHashes[$book] -or
       (Get-FileHash -LiteralPath $draft).Hash -cne $compiled.WorkbookSHA256 -or
       (($compiled.Modules|Sort-Object)-join ',') -cne (($modules|Sort-Object)-join ',')){throw 'Частная компиляция не подтверждена.'}
    Assert-IsolatedOfficeReady 'PreNative'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $draft `
        -ReportPath $report -Macro 'modTestKaniStage38.RunTestKaniLocalColumns' -MacroArgument1 (Join-Path $PSScriptRoot 'KaniV4Input.csv') `
        -TimeoutSeconds 110 -FailFast
    if($LASTEXITCODE -ne 0){throw 'Нативный контроль станции не завершён.'}
    $label=@(Get-Content -LiteralPath $report | Where-Object {$_ -like 'FIXTURE: *'})
    if($label.Count -ne 1){throw 'Частная книга не найдена.'}
    $folder=[IO.Path]::GetFullPath((Split-Path -Parent $label[0].Substring(9)))
    if(!$folder.StartsWith($env:TEMP+'\RC_NDM_ModeSuite_',[StringComparison]::OrdinalIgnoreCase)){throw 'Частный вывод находится вне временной книги.'}
    Copy-Item -LiteralPath (Join-Path $folder 'KaniLocalColumns.csv') -Destination 'Native/KaniLocalColumns.csv'
}
finally {
    $env:TEMP=$previousTemp; $env:TMP=$previousTmp
    Pop-Location
}
