"""Check the archived OpenSees continuation without importing the external model."""

from hashlib import sha256
import json
from math import isclose, sqrt
from pathlib import Path


def tabulated_force(x):
    left = int(x * 1000.) / 1000.
    right = left + .001
    y0 = 1.5 * left - .5 * left**3
    y1 = 1.5 * right - .5 * right**3
    return y0 + (x - left) / (right - left) * (y1 - y0)


def main():
    source = Path(__file__).with_name("OpenSeesFold.json")
    raw = source.read_bytes()
    assert sha256(raw).hexdigest().upper() == "093DBA6DEF77ED4DF7F41D695E9ACC411933755A36CBCD650EEA48E0EA6AF77C"
    result = json.loads(raw)
    assert result["maximum_analytical_lambda"] == .8 and result["opensees_version"] == "3.8.0"
    fixed = result["LoadControl"]
    arc = result["ArcLength"]
    x0 = fixed["preload_coordinate"]
    assert arc["preload_coordinate"] == x0 and isclose(tabulated_force(x0), .2, abs_tol=1.e-10)
    assert fixed["outcome"] == "solver rejected increment" and fixed["failed_code"] == -3
    assert arc["outcome"] == "passed to descending branch" and arc["failed_code"] == 0
    assert len(fixed["samples"]) == 38 and len(arc["samples"]) == 34
    stats = {}
    for label, branch in (("LoadControl", fixed), ("ArcLength", arc)):
        last = x0, .15 / 5., 0.
        residual = 0.
        for i, sample in enumerate(branch["samples"], 1):
            x, rotation, factor = (sample[key] for key in ("axial_coordinate", "rotation", "lambda"))
            assert sample["step"] == i and x > last[0]
            residual = max(residual, abs(tabulated_force(x) - (.2 + factor)), abs(5. * rotation - (.15 + factor)))
            if label == "ArcLength":
                ds = sqrt((x - last[0])**2 + (rotation - last[1])**2 + (.25 * (factor - last[2]))**2)
                assert isclose(ds, .035, abs_tol=1.e-10)
            else:
                assert isclose(factor, i * .021, abs_tol=1.e-10)
            last = x, rotation, factor
        assert residual < 1.e-9
        stats[label] = {"count": len(branch["samples"]), "final": last, "residual": residual}
    assert stats["LoadControl"]["final"][0] < 1. < stats["ArcLength"]["final"][0]
    assert stats["ArcLength"]["final"][-1] < .8
    print("OPENSEES FOLD EVIDENCE PASS", json.dumps(stats, sort_keys=True))


if __name__ == "__main__":
    main()
