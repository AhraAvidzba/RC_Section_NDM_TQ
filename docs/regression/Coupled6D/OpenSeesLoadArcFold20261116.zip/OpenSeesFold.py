"""Run OpenSees load and arc-length control on the same normalized N/T fold."""

from bisect import bisect_right
from hashlib import sha256
import json
from pathlib import Path

from openseespy import opensees as ops


HERE = Path(__file__).resolve().parent
ABSCISSA = [-2.] + [index / 1000. for index in range(2001)]
ORDINATE = [-3.] + [1.5 * x - .5 * x**3 for x in ABSCISSA[1:]]
BASE_N = .2
BASE_T = .15
STIFFNESS_T = 5.


def interpolated_force(strain):
    index = min(max(bisect_right(ABSCISSA, strain) - 1, 0), len(ABSCISSA) - 2)
    distance = (strain - ABSCISSA[index]) / (ABSCISSA[index + 1] - ABSCISSA[index])
    return ORDINATE[index] + distance * (ORDINATE[index + 1] - ORDINATE[index])


def setup(integrator, *arguments):
    ops.constraints("Plain")
    ops.numberer("Plain")
    ops.system("FullGeneral")
    ops.test("NormUnbalance", 1.e-10, 25, 0)
    ops.algorithm("Newton")
    ops.integrator(integrator, *arguments)
    ops.analysis("Static")


def run(integrator, *arguments):
    ops.wipe()
    ops.model("basic", "-ndm", 2, "-ndf", 3)
    ops.node(1, 0., 0.)
    ops.node(2, 0., 0.)
    ops.fix(1, 1, 1, 1)
    ops.fix(2, 0, 1, 0)
    ops.uniaxialMaterial("ElasticMultiLinear", 1, "-strain", *ABSCISSA, "-stress", *ORDINATE)
    ops.uniaxialMaterial("Elastic", 2, STIFFNESS_T)
    ops.element("zeroLength", 1, 1, 2, "-mat", 1, 2, "-dir", 1, 6)
    ops.timeSeries("Constant", 1)
    ops.pattern("Plain", 1, 1)
    ops.load(2, BASE_N, 0., BASE_T)
    setup("LoadControl", 1.)
    assert ops.analyze(1) == 0
    ops.loadConst("-time", 0.)
    x0 = ops.nodeDisp(2, 1)
    assert abs(interpolated_force(x0) - BASE_N) < 1.e-10
    ops.wipeAnalysis()
    ops.timeSeries("Linear", 2)
    ops.pattern("Plain", 2, 2)
    ops.load(2, 1., 0., 1.)
    setup(integrator, *arguments)

    samples = []
    outcome = "iteration cap"
    failed_code = 0
    for idx in range(1, 81):
        status = ops.analyze(1)
        if status:
            failed_code = status
            outcome = "solver rejected increment"
            break
        x, theta = ops.nodeDisp(2, 1), ops.nodeDisp(2, 3)
        factor = ops.getLoadFactor(2)
        wrench = tuple(ops.eleResponse(1, "force"))
        assert len(wrench) == 6
        internal_n, internal_t = wrench[3], wrench[5]
        residual = max(abs(interpolated_force(x) - (BASE_N + factor)),
                       abs(STIFFNESS_T * theta - (BASE_T + factor)),
                       abs(internal_n - (BASE_N + factor)), abs(internal_t - (BASE_T + factor)))
        assert residual < 2.e-9
        samples.append({"step": idx, "axial_coordinate": x, "rotation": theta, "lambda": factor,
                        "original_residual": residual, "iterations": ops.testIter()})
        if x >= 1.25:
            outcome = "passed to descending branch"
            break
    return {"preload_coordinate": x0, "outcome": outcome, "failed_code": failed_code, "samples": samples}


def main():
    version = ops.version()
    force = run("LoadControl", .021)
    arc = run("ArcLength", .035, .25)
    ops.wipe()
    assert force["preload_coordinate"] == arc["preload_coordinate"]
    assert force["failed_code"] and force["samples"][-1]["axial_coordinate"] < 1.
    assert not arc["failed_code"] and arc["samples"][-1]["axial_coordinate"] >= 1.25
    assert all(b["axial_coordinate"] > a["axial_coordinate"] for a, b in zip(arc["samples"], arc["samples"][1:]))
    assert arc["samples"][-1]["lambda"] < .8
    output = HERE / "OpenSeesFold.json"
    proof = {"opensees_version": version, "maximum_analytical_lambda": .8,
             "LoadControl": force, "ArcLength": arc}
    output.write_bytes((json.dumps(proof, indent=2) + "\n").encode())
    print("OPENSEES FOLD PASS", sha256(output.read_bytes()).hexdigest().upper(),
          len(force["samples"]), len(arc["samples"]), arc["samples"][-1])


if __name__ == "__main__":
    main()
