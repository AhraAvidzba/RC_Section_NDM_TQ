"""Install the verified sources, workbook and full export as one recoverable operation."""
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from tempfile import NamedTemporaryFile
import json
import os
import subprocess

root=Path(__file__).resolve().parent
repo=Path.cwd().resolve()
stage=root/"Candidate"
build=stage/"docs/regression/Audit03/DesignWitness"


def digest(data):
    return sha256(data).hexdigest().upper()


def stage_file(destination, content):
    with NamedTemporaryFile(dir=destination.parent, prefix=".ndm-shoulder-", suffix=".pending", delete=False) as stream:
        prepared=Path(stream.name)
        try:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        except BaseException:
            stream.close()
            prepared.unlink(missing_ok=True)
            raise
    return prepared


def main():
    proof=(root/"Verification.json").read_bytes()
    verification=json.loads(proof)
    assert verification["status"]=="PASS"
    prior_revision=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
    assert prior_revision==verification["source_git_revision"]
    workbook="workbook/output/RC_Section_NDM.xlsm"
    export="workbook/output/VBA_All_Code.txt"
    approved={workbook:verification["package"]["candidate_sha256"],export:verification["installed_export_sha256"],**verification["sources"]}
    assert not subprocess.check_output(["git","status","--porcelain","--",*approved],cwd=repo,text=True).strip()
    previous={name:(repo/name).read_bytes() for name in approved}
    assert digest(previous[workbook])==verification["package"]["base_sha256"]
    assert digest(previous[export])==verification["previous_export_sha256"]
    paths={workbook:build/Path(workbook).name,export:build/Path(export).name,
           **{name:stage/name for name in verification["sources"]}}
    pending={}
    replaced=[]
    receipt=root/"Publication.json"
    backup=root/"BeforePublication"
    assert not receipt.exists()
    backup.mkdir()
    try:
        for name,expected in approved.items():
            destination=repo/name
            assert destination.resolve(strict=True)==destination and destination.is_file()
            contents=paths[name].read_bytes()
            assert digest(contents)==expected
            retained=backup/name
            retained.parent.mkdir(parents=True,exist_ok=True)
            retained.write_bytes(previous[name])
            assert retained.read_bytes()==previous[name]
            pending[name]=stage_file(destination,contents)
            assert digest(pending[name].read_bytes())==expected
        for name,prepared in pending.items():
            destination=repo/name
            assert destination.read_bytes()==previous[name], f"File changed during prepare: {name}"
            os.replace(prepared,destination)
            replaced.append(name)
        assert all(digest((repo/name).read_bytes())==expected for name,expected in approved.items())
        result={"status":"PASS","time":datetime.now().astimezone().isoformat(),"source_git_revision":prior_revision,
                "verification_sha256":digest(proof),"installed":approved,
                "previous":{name:digest(content) for name,content in previous.items()}}
        with receipt.open("x",encoding="utf-8",newline="\n") as stream:
            json.dump(result,stream,ensure_ascii=False,indent=2)
            stream.write("\n")
    except BaseException:
        for name in reversed(replaced):
            destination=repo/name
            os.replace(stage_file(destination,previous[name]),destination)
        raise
    finally:
        for prepared in pending.values():
            prepared.unlink(missing_ok=True)
    print("PUBLISHED",digest(receipt.read_bytes()),approved[workbook],approved[export])


if __name__=="__main__":
    main()

