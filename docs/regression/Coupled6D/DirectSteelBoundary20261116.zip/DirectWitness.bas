' -------------------- ДЛЯ ТЕСТОВ --------------------
' Показывает знак вычисленной границы стали при прямых силовых пробах A2D.
Public Function RunTestCoupledDirectSteelWitness() As String
    Dim report As String, passed As Long, failed As Long, offset As Variant
    On Error GoTo Failed
    For Each offset In Array(-0.001, 0#, 0.001)
        TestDirectSteelWitnessAtForce 415920# + CDbl(offset), report, passed, failed
    Next offset
    RunTestCoupledDirectSteelWitness = report & "TOTAL_DIRECT_STEEL_WITNESS: passed=" & passed & "; failed=" & failed
    Exit Function
Failed:
    RunTestCoupledDirectSteelWitness = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Четыре равных силовых шага и проверка предельной деформации от их левого плеча.
Private Sub TestDirectSteelWitnessAtForce(ByVal force As Double, ByRef report As String, ByRef passed As Long, ByRef failed As Long)
    Const STEEL_LIMIT As Double = 0.0008, AREA As Double = 21600#
    Const SOLVE_TOL As Double = 0.0000005, EXACT_TOL As Double = 0.000000000001
    Dim section As CSectionModel: Set section = TestBuildSection(TestFixtureBox(180#, 120#))
    section.AddRebarElement 0#, 0#, Sqr(400# / GEOM_PI), 100#, "A400"
    Dim steel As New CCoupledSteelModel, models As Object
    steel.Initialize 200000#, 100#, 100#, 0#, 0#, STEEL_LIMIT, STEEL_LIMIT
    Set models = CreateObject("Scripting.Dictionary"): models.Add "A400", steel
    Dim operators As New CCoupledElasticState, concrete As New CTestCoupledPointResponse
    operators.PrepareModel section, 30000#, 0#, 1, 1, 5, steelModels:=models
    concrete.TestInitialize operators.PointCount: concrete.TestUseDescendingAxialLaw
    Dim material As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    material.Initialize operators, concrete, models
    solver.Initialize operators, material, 30000#

    Dim path As New CLoadPathVector, branch As New CCoupledLoadContinuation
    path.Initialize 0#, force, 0#, 0#, 0#, 0#
    branch.Initialize solver, path, 4, 64, 30, SOLVE_TOL, SOLVE_TOL, True
    If Not branch.Advance(1#) Then Err.Raise 5, , branch.ResultMeta.DiagnosticDetails
    TestRecord branch.SavedFieldCount = 4 And branch.RejectedAttempts = 0 And concrete.TestAcceptedSteps = 4, _
        "four direct force steps and no rejected step", passed, failed, report
    Dim history As Collection: Set history = branch.AcceptedFields
    Dim field() As Double, actual() As Double, i As Long, steps As String
    For i = 1 To history.Count
        field = history(i)
        steps = steps & ";" & TestOnsetNumber(field(1))
    Next i
    branch.CopyAccepted field, actual
    report = report & "DIRECT;" & TestOnsetNumber(force) & ";" & TestOnsetNumber(material.AcceptedSteelUtilization) & ";" & _
        TestOnsetNumber((actual(1) - force) / AREA) & ";" & TestOnsetNumber(actual(1)) & steps & vbCrLf

    If Not solver.ReplayAcceptedFields(history, 3) Then Err.Raise 5, , "Не восстановлено левое плечо силовой пробы."
    Dim baseLoad(1 To 6) As Double, direction(1 To 6) As Double, projection() As Double
    Dim limitLambda As Double, uncertainty As Double, left() As Double, restored() As Double
    solver.CopyAccepted left
    ReDim projection(1 To operators.DegreeCount): projection(1) = 1#: direction(1) = force
    If Not solver.TryDeformationStep(baseLoad, direction, projection, STEEL_LIMIT, 1#, limitLambda, EXACT_TOL, EXACT_TOL, 30) Then _
        Err.Raise 5, , "Не найдена проверочная предельная деформация. " & solver.ResultMeta.DiagnosticDetails
    If Not solver.TrialLambdaUncertainty(EXACT_TOL, EXACT_TOL, uncertainty) Then Err.Raise 5, , "Не найдена погрешность предельного множителя."
    solver.CopyTrial field, actual
    report = report & "BOUNDARY;" & TestOnsetNumber(force) & ";" & TestOnsetNumber(limitLambda) & ";" & _
        TestOnsetNumber(uncertainty) & ";" & TestOnsetNumber(field(1)) & ";" & TestOnsetNumber(actual(1)) & ";" & _
        TestOnsetNumber(material.TrialSteelUtilization) & vbCrLf
    solver.DiscardStep: solver.CopyAccepted restored
    TestRecord restored(1) = left(1) And concrete.TestAcceptedSteps = 3, "boundary probe restores the pre-target history", passed, failed, report

    If force <> 415920# Then Exit Sub
    Dim perturbation As Variant, seed As Variant
    For Each perturbation In Array(-5.46E-10, 5.46E-10)
        field = left: field(1) = STEEL_LIMIT * (1# + CDbl(perturbation)): seed = field
        If Not solver.TryStep(force, 0#, 0#, 0#, 0#, 0#, SOLVE_TOL, SOLVE_TOL, 30, seed) Then _
            Err.Raise 5, , "Не решена знаковая проба той же нагрузки."
        solver.CopyTrial field, actual
        report = report & "SEED;" & TestOnsetNumber(force) & ";" & TestOnsetNumber(CDbl(perturbation)) & ";" & _
            TestOnsetNumber(material.TrialSteelUtilization) & ";" & TestOnsetNumber((actual(1) - force) / AREA) & ";" & _
            TestOnsetNumber(field(1)) & vbCrLf
        solver.DiscardStep: solver.CopyAccepted restored
        TestRecord restored(1) = left(1) And concrete.TestAcceptedSteps = 3, "seeded probe restores the same history", passed, failed, report
    Next perturbation
End Sub
