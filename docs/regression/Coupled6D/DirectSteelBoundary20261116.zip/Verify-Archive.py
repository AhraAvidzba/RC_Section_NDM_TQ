"""Verify isolated direct-steel evidence without launching Excel."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
from tempfile import TemporaryDirectory

from Prepare import verify


HERE = Path(__file__).resolve().parent
FIXTURE_SHA = 'C74D661CD3B49E749565FEDCD2D401A96904ACFB0E8306D1DAF6258718053B3B'
REPORT_SHA = 'E8C200A5E4A8952DEFCF2B59138E4BCF146E855CED2BEC9BACDE4D7BD1CA9D7D'


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read_json(name):
    return json.loads((HERE/name).read_text(encoding='utf-8-sig'))


def main(repo):
    expected = read_json('SHA256SUMS.json')
    assert all(digest(HERE/name)==value for name,value in expected.items())
    assert digest(HERE/'Fixture.json')==FIXTURE_SHA
    assert digest(HERE/'Native/Direct.txt')==REPORT_SHA
    fixture = read_json('Fixture.json')
    installed = fixture['workbook_sha256']
    assert fixture['commit']=='f4741ae'
    for key in ('Prepare.py','Run-Direct.ps1','DirectWitness.bas','Guard-IsolatedOffice.ps1'):
        assert digest(HERE/key)==fixture['frozen'][key]
    if repo:
        module = 'tests/modTestCoupledElasticState.bas'
        source = check_output(['git','show',f"{fixture['commit']}:{module}"],cwd=repo).decode('utf-8-sig').rstrip()
        witness = (HERE/'DirectWitness.bas').read_text(encoding='utf-8')
        overlay = (source+'\n\n'+witness).replace('\n','\r\n').encode('utf-8')
        assert sha256(overlay).hexdigest().upper()==fixture['frozen'][module]
        for name, proof in read_json('SourceProof.json').items():
            blob = check_output(['git','show',f"{fixture['commit']}:{name}"],cwd=repo)
            assert sha256(blob).hexdigest().upper()==proof

    compiled = read_json('docs/regression/CodeUpdate.json')
    assert compiled['Compiled'] and not compiled['ProductionChanged'] and installed==compiled['ProductionSHA256']
    assert compiled['Modules']==['modTestCoupledElasticState'] and compiled['RetiredModules']==[]
    compiler_closure = read_json('CompileClosure.json')
    compiler_log = (HERE/'Compile.log').read_text(encoding='utf-8-sig')
    compiler_owner = re.search(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',compiler_log,re.M)
    assert compiler_closure['State']=='Absent' and compiler_owner
    assert (int(compiler_owner[1]),compiler_owner[2])==(compiler_closure['PID'],compiler_closure['StartTicksUTC'])
    native = (HERE/'Native/Direct.txt').read_text(encoding='utf-8-sig')
    assert f"SOURCE_SHA256: {compiled['WorkbookSHA256']}" in native
    owner = read_json('Native/Direct.txt.Ownership.json')
    closure = read_json('Native/Direct.txt.ProcessClosure.json')
    state = closure['Closure']['FinalState']
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256']==compiled['WorkbookSHA256'] and owner['BeforeWorkbookOpen']
    assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode']==0
    assert state['State']=='Absent' and (owner['PID'],owner['StartTicksUTC'])==(state['PID'],state['StartTicksUTC'])
    assert owner['PID']!=compiler_closure['PID'] or owner['StartTicksUTC']!=compiler_closure['StartTicksUTC']
    assert not closure['OrdinaryPathKilledAnything'] and closure['RunnerCleanupValid']

    with TemporaryDirectory() as folder:
        report = Path(folder)/'Direct.txt'
        copyfile(HERE/'Native/Direct.txt',report)
        verify(report)
        assert (report.parent/'Verification.json').read_bytes()==(HERE/'Native/Verification.json').read_bytes()
    confirmed = read_json('Native/Verification.json')
    assert [r['native_matches_analytic'] for r in confirmed['comparison']]==[True,True,False]
    print(f'DIRECT STEEL EVIDENCE PASS {REPORT_SHA}')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path)
    main(parser.parse_args().repo)
