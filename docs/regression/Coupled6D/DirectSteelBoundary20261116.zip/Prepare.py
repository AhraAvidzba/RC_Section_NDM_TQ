"""Freeze the isolated workbook and independently verify its direct steel witness."""

import argparse
from decimal import Decimal as D, getcontext
from hashlib import sha256
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BOOK = Path('workbook/output/RC_Section_NDM.xlsm')
MODULE = Path('tests/modTestCoupledElasticState.bas')
SHA = '8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF'
LIBRARY = Path('tools/build_workbook')
LIMIT = D('0.0008')
FORCE = D(415920)
AREA = D(21600)
TOL = D('5e-7')
TARGETS = [FORCE+D(x) for x in ('-.001','0','.001')]


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def prepare():
    assert digest(ROOT / BOOK) == SHA
    assert not (HERE/'Fixture.json').exists()
    sources = ('Update-PrivateWorkbookCode.ps1','Run-Audit03Watchdog.ps1','Run-Audit02ModeTests.ps1',
               'GeometryExampleSupport.ps1','SettingsCatalog.ps1','WorkbookLayout.ps1','WorkbookLayout.json',
               'NormativeFormulaImages.ps1','NormativeFormulaImages.json',
               'GeometryTables.ps1','GeometryTables.json','HelpSettingsDescriptions.json',
               'NormativeHelpReferences.json','HelpFormulaExplanations.json','NormativeHelpSources.json')
    inputs = [BOOK, *(LIBRARY/name for name in sources)]
    for path in inputs:
        destination = HERE/path
        destination.parent.mkdir(parents=True,exist_ok=True)
        copyfile(ROOT/path,destination)
    for name in ('src','tests','Temp','docs/regression','Native'):
        (HERE/name).mkdir(parents=True,exist_ok=True)
    baseline = check_output(['git','show',f'f4741ae:{MODULE.as_posix()}'],cwd=ROOT).decode('utf-8-sig').rstrip()
    assert 'RunTestCoupledDirectSteelWitness' not in baseline
    (HERE/MODULE).write_text(baseline+'\n\n'+(HERE/'DirectWitness.bas').read_text(encoding='utf-8'),encoding='utf-8',newline='\r\n')
    copyfile(HERE.parent/'mvt-next/Guard-IsolatedOffice.ps1', HERE/'Guard-IsolatedOffice.ps1')
    copyfile(HERE/BOOK,HERE/'docs/regression/Diagnostic.xlsm')
    inputs += [MODULE,Path('Guard-IsolatedOffice.ps1'),Path('DirectWitness.bas'),Path('Prepare.py'),Path('Run-Direct.ps1')]
    frozen = {'workbook_sha256':SHA,'commit':'f4741ae','frozen':{path.as_posix():digest(HERE/path) for path in inputs}}
    receipt = HERE/'Fixture.json'
    receipt.write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
    print(digest(receipt),frozen['frozen'][MODULE.as_posix()])


def wrench(strain):
    return D(21500)*(D(30000)*strain-D(10**10)*strain**3) + D(100)*min(D(200000)*strain,D(100))


def root(target):
    low, high = D('0'), D('.001')
    for _ in range(150):
        center = (low+high)/2
        if wrench(center) < target:
            low = center
        else:
            high = center
    return (low+high)/2


def verify(report):
    getcontext().prec = 48
    assert wrench(LIMIT) == FORCE
    raw = report.read_text(encoding='utf-8-sig')
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in raw
    assert 'TOTAL_DIRECT_STEEL_WITNESS: passed=8; failed=0' in raw
    records = [line.split(';') for line in raw.splitlines() if re.match(r'^(DIRECT|BOUNDARY|SEED);',line)]
    native = [list(map(D,line[1:])) for line in records if line[0]=='DIRECT']
    boundaries = [list(map(D,line[1:])) for line in records if line[0]=='BOUNDARY']
    assert [line[0] for line in native] == [line[0] for line in boundaries] == TARGETS
    comparison = []
    for ((force,utilization,residual,actual,*history),(_,limit_lambda,uncertainty,limit_strain,limit_force,limit_ratio)) in zip(native,boundaries,strict=True):
        assert len(history)==4 and D(0)<history[0]<history[1]<history[2]<history[3]<D('.001')
        for index,strain in enumerate(history,1):
            applied = force*index/4
            assert abs(wrench(strain)-applied)/AREA <= TOL*(1+abs(applied)/AREA)+D('1e-10')
        assert abs(history[-1]/LIMIT-utilization)<D('2e-13')
        assert abs((actual-force)/AREA-residual)<D('1e-11')
        assert abs(limit_strain-LIMIT)<D('1e-14') and abs(limit_ratio-1)<D('1e-10')
        assert abs(limit_force-FORCE)<D('1e-5')
        exact_limit_lambda = FORCE/force
        assert abs(limit_lambda-exact_limit_lambda)<=uncertainty
        assert (limit_lambda-uncertainty>1 if force<FORCE else limit_lambda+uncertainty<1 if force>FORCE else abs(limit_lambda-1)<=uncertainty)
        comparison.append({'target_N':str(force),'balanced_result_N':str(actual),'normalized_signed_residual_MPa':str(residual),
                           'raw_U':str(utilization),'analytic_U':str(root(force)/LIMIT if force!=FORCE else D(1)),
                           'raw_exceeds':utilization>1,'analytic_exceeds':force>FORCE,'native_matches_analytic':(utilization>1)==(force>FORCE),
                           'prescribed_strain_boundary_lambda':str(limit_lambda),'lambda_uncertainty':str(uncertainty),
                           'history_strains':[str(x) for x in history]})
    seeded = [list(map(D,line[1:])) for line in records if line[0]=='SEED']
    assert [(x[0],x[2]>1) for x in seeded]==[(FORCE,False),(FORCE,True)]
    for force,delta,utilization,residual,strain in seeded:
        assert abs(strain/LIMIT-1-delta)<D('1e-14')
        assert abs((wrench(strain)-force)/AREA-residual)<D('1e-11')
        assert abs(residual)<TOL
    data={'report_sha256':digest(report),'analytic_limit_N':str(FORCE),'analytic_limit_strain':str(LIMIT),
          'analytic_tangent_at_limit_N_per_unit_strain':'232200000','comparison':comparison,
          'dual_sign_seeded_at_exact_contact':[list(map(str,x)) for x in seeded]}
    (report.parent/'Verification.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(data,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify',type=Path)
    args=parser.parse_args()
    if args.verify:
        verify(args.verify)
    else:
        prepare()
