"""Seal the help catalogs required before the private VBA module imports."""
from pathlib import Path
from hashlib import sha256
from shutil import copyfile
import json


here = Path(__file__).resolve().parent
repo = here.parents[1]
receipt = here / 'Fixture.json'
fixture = json.loads(receipt.read_text(encoding='utf-8'))


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


assert not (here / 'Compile.log').exists()
assert digest(here / 'docs/regression/Diagnostic.xlsm') == fixture['workbook_sha256']
assert all(digest(here / name) == value for name, value in fixture['frozen'].items())
script = here / 'Prepare.py'
source = script.read_text(encoding='utf-8')
anchor = "'NormativeFormulaImages.ps1','GeometryTables.ps1','HelpSettingsDescriptions.json',"
assert source.count(anchor) == 1
script.write_text(source.replace(anchor, "'NormativeFormulaImages.ps1','NormativeFormulaImages.json',\n"
                          "               'GeometryTables.ps1','GeometryTables.json','HelpSettingsDescriptions.json',"),
                  encoding='utf-8')
fixture['frozen']['Prepare.py'] = digest(script)
for name in ('NormativeFormulaImages.json', 'GeometryTables.json'):
    relative = Path('tools/build_workbook') / name
    assert not (here / relative).exists()
    copyfile(repo / relative, here / relative)
    fixture['frozen'][relative.as_posix()] = digest(here / relative)
receipt.write_text(json.dumps(fixture, indent=2) + '\n', encoding='utf-8')
print('DIRECT_FIXTURE', digest(receipt))
