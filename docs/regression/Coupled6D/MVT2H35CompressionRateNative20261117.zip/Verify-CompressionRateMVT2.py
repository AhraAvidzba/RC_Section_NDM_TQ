"""Сверяет перенос калибровки H35 на равновесные поля MVT2 в Excel."""

from argparse import ArgumentParser
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
from zipfile import ZipFile

from H35CompressionRate import calculate_targets, solve_rate
from importlib.util import module_from_spec, spec_from_file_location


FOLLOW = ('MVT2NativePublicationCutFollow20261117.zip','9F55DE3FC0B1B652DD1ED9683507423ADE4DF6AB3B008D9590EE1D9327F9864E')
BASE = ('MVT2NativePublicationCutTimed20261117.zip','EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A')
PRIOR = ('MVT2NativePublicationCutDilation26Equilibrium20261117.zip','3ACA114CB255C978553604265B57040F2485317A88B6D08871F43D3FBABE1BD1')
MATERIAL_SHA = '92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C'
CLASS = 'src/Materials/CCoupledConcreteResponse.cls'
TEST = 'tests/modTestMVT2GaussSpan.bas'


def digest(raw):
    return sha256(raw).hexdigest().upper()


def archive(evidence, pin):
    path = evidence / pin[0]
    assert digest(path.read_bytes()) == pin[1]
    return ZipFile(path)


def process(root, report, book, follow):
    """Подтверждает состав частной книги и завершение принадлежащего ей процесса."""
    read=follow['read_json']
    compiler=read(root/'CodeUpdate.json')
    owner=read(root/'Native/MVTGaussMixed.txt.Ownership.json')
    closure=read(root/'Native/MVTGaussMixed.txt.ProcessClosure.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged']
    assert compiler['ProductionSHA256']==book and owner['SourceSHA256']==compiler['WorkbookSHA256']
    assert set(compiler['Modules'])=={'CCoupledElasticState','CCoupledSectionQuadrature',
                                     'CCoupledConcreteResponse','modTestMVT2GaussSpan'}
    assert read(root/'CompileClosure.json')['State']=='Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    assert f"TEST_EXCEL_PROCESS: id={owner['PID']}; startTicks={owner['StartTicksUTC']}" in report
    assert 'SOURCE_SHA256: '+owner['SourceSHA256'] in report and 'RUNTIME ERROR:' not in report
    if closure['Stage']=='AFTER_CHILD_EXIT':
        identity=closure['Closure']['Identity']
        assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['ChildExitCode']==0
        assert closure['Closure']['FinalState']['State']=='Absent'
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in report
        termination='completed'
    else:
        assert closure['Stage']=='TIMEOUT' and not closure['Passed']
        identity=closure['Identity']
        assert closure['After']['State']=='Absent' and closure['After']['PID']==owner['PID']
        assert int(closure['After']['StartTicksUTC'])==int(owner['StartTicksUTC'])
        assert closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout']
        assert 'WATCHDOG_FAILURE: timeout=165 sec;' in report and 'ownExcelState=Absent' in report
        termination='watchdog_timeout'
    assert identity['Valid'] and identity['PID']==owner['PID'] and identity['Ticks']==int(owner['StartTicksUTC'])
    return termination,owner['PID']


def check_preload(torsion,frames,rows,operators,mesh,reuse):
    """Проверяет семь номинальных целей и все принятые подшаги кручения."""
    nominal = (262750.,525500.,1051000.,2102000.,4204000.,6831500.,10510000.)
    trials = [(float(r[2])*1.e6,float(r[3])*1.e6,r[4:7]) for r in rows if r[0]=='MVT2_ADAPT_TRIAL']
    assert trials==[(x,x,['True','4','0']) for x in nominal]
    history=[(int(r[2]),float(r[3])*1.e6) for r in rows if r[0]=='MVT2_ADAPT_HISTORY']
    assert history==[(i,frames[name][0]) for i,name in enumerate(torsion,1)]
    assert all(frames[name][1]==0. for name in torsion)
    _,_,area,length=mesh[0]
    preload=[]
    for label in torsion:
        torque=frames[label][0]
        field=operators['F'][label]
        signed=reuse['integrate_preload'](field,frames[label][2],mesh,operators)
        error=max(abs(x-y)/(area*length if i in (1,2,3) else area)
                  for i,(x,y) in enumerate(zip(signed,(0.,0.,0.,torque,0.,0.),strict=True)))
        assert error <= 5e-6
        preload.append({'phase':label,'T_Nmm':torque,'twist_rad_per_m':1000.*field[3]/length,
                        'signed_resultants':signed,'max_residual_MPa':error})
    return preload


def verify(repo,root):
    evidence=repo/'docs/regression/Coupled6D'
    follow,reuse={'__name__':'__pinned__'},{'__name__':'__pinned__'}
    with archive(evidence,FOLLOW) as source:
        exec(compile(source.read('Verify-NativeFollow.py'),FOLLOW[0],'exec'),follow)
    with archive(evidence,PRIOR) as source:
        exec(compile(source.read('Verify-DilationEquilibrium.py'),PRIOR[0],'exec'),reuse)
    utility,recovery,_,_,_,mesh=follow['read_references'](repo)
    with archive(evidence,BASE) as source:
        base = json.loads(source.read('NativePublicationCutProof.json'))
        original = utility['read_operators'](source.read('Native/Operators.csv'))
        old_test=source.read('modTestMVT2GaussSpan.bas').decode('utf-8-sig').replace('\r\n','\n')
        driver=source.read('Run-Native.ps1').decode('utf-8')
    prep=follow['read_json'](root/'Preparation.json')
    assert prep['dilation_max_degrees']==32 and prep['compression_dilation_rate']=='0.241'
    for name in (CLASS,TEST,'Run-Native.ps1'):
        assert digest((root/name).read_bytes())==prep['inputs'][name]
    test=(root/TEST).read_text(encoding='utf-8-sig')
    test=test.replace('If branch.SavedFieldCount < 7 Or twist <= 0# Then _',
                      'If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _')
    assert test.replace('"MVT_PRELOAD_END;" & CStr(branch.SavedFieldCount) & ";10.51"','"MVT_PRELOAD_END;8;10.51"')==old_test
    assert (root/'Run-Native.ps1').read_text('utf-8').replace(",'CCoupledConcreteResponse'",'')==driver
    original_wire = (root/'UnmodifiedMaterial.cls').read_bytes()
    assert digest(original_wire)==MATERIAL_SHA==prep['material_base_sha256']
    stage=spec_from_file_location('stage_compression_rate',root/'Stage-CompressionRateMVT2.py')
    staged=module_from_spec(stage)
    stage.loader.exec_module(staged)
    assert (root/CLASS).read_bytes()==staged.material_wire(original_wire)

    h45=json.loads((root/'H45RateTargets.json').read_bytes())
    if (repo/'literature/Coupled6D/Osorio-Bustamante-2012-H45-Thesis.pdf').is_file():
        assert calculate_targets(repo)==h45
    calibration=solve_rate(repo,h45)
    assert calibration['compression_rate']==.241 and calibration['results']['H45']['stock']['lateral_RMS']>calibration['results']['H45']['modified']['lateral_RMS']
    native=root/'Native'
    report=(native/'MVTGaussMixed.txt').read_text('utf-8-sig')
    termination,pid=process(root,report,recovery['BOOK_SHA'],follow)
    rows=[row.split(';') for row in (native/'MVTGaussMixed.csv').read_text('cp1251').splitlines()]
    assert recovery['geometry'](rows)==mesh
    operators=utility['read_operators']((native/'Operators.csv').read_bytes())
    frames=utility['read_tensor_frames']((native/'MVTGaussMixed.Tensor.csv').read_bytes(),45)
    assert all(operators[key]==original[key] for key in 'GLBSR')
    assert list(operators['F'])==list(frames)
    _, n, preload_t, = next(r for r in rows if r[0]=='MVT_PRELOAD_END')
    assert float(preload_t)==10.51
    torsion=[f'R{i}' for i in range(1,int(n)+1)]
    assert list(frames)[:int(n)]==torsion
    preload=check_preload(torsion,frames,rows,operators,mesh,reuse)
    mixed=list(frames)[int(n):]
    assert mixed and set(operators['H'])==set(product(mixed,(-1,0,1),mesh[1]))
    confirmed, targets = {}, []
    for row in rows:
        if row[0]=='MVT2_CUT_INSERTED':
            confirmed[row[1]+'A'+row[2]]=float(row[2])
        elif row[0]=='MVT2_CUT_TRIAL':
            _,phase,t,q,m,ok,internal,code,*details=row
            assert float(t)==10510000. and float(m)==-396.*float(q)
            trial=follow['trial_work'](details,ok,internal,code)
            targets.append(trial|{'phase':phase,'Qy_N':float(q)})
            if trial['accepted']:
                confirmed[phase]=float(q)
    assert list(confirmed)==mixed and [r['Qy_N'] for r in targets]==[2500.*i for i in range(1,len(targets)+1)]
    baseline={r['Qy_N']:r for r in base['compared_same_six_force_states']}
    length=mesh[0][3]
    fields=[]
    for phase in mixed:
        torque,q,_=frames[phase]
        assert confirmed[phase]==q and torque==10510000.
        item={'phase':phase,'Qy_N':q,'twist_rad_per_m':1000.*operators['F'][phase][3]/length,
              'kappa_rad_per_m':1000.*operators['F'][phase][1]/length,
              'equilibrium':recovery['equations'](phase,frames[phase],operators,mesh)}
        if q in baseline:
            item['comparison']=baseline[q]
        fields.append(item)
    finish=[r for r in rows if r[0]=='CASE_FINISHED']
    assert bool(finish)==(termination=='completed')
    return {'termination':termination,'excel_pid':pid,'preload':preload,'targets':targets,'mixed':fields,
            'macro_seconds':float(finish[0][3]) if finish else None,
            'calibration':calibration,'physical_limit_confirmed':False}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args()
    report=verify(args.repo.resolve(),args.root.resolve())
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(report,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('MVT2 H35 COMPRESSION RATE OFFLINE PASS',len(report['mixed']))
