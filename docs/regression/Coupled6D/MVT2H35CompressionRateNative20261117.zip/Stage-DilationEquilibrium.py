"""Пересчитывает опубликованный путь MVT2 с заданным углом дилатансии."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from hashlib import sha256


ARCHIVE = 'MVT2NativePublicationCutTimed20261117.zip'
ARCHIVE_SHA = 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A'
TEST = 'tests/modTestMVT2GaussSpan.bas'


def stage(repo, root, angle):
    path = repo / 'docs/regression/Coupled6D' / ARCHIVE
    assert sha256(path.read_bytes()).hexdigest().upper() == ARCHIVE_SHA
    with TemporaryDirectory(dir=repo / 'tmp', prefix='mvt2-dilation-') as temp:
        base_file = Path(temp) / 'Stage-PublicationCut.py'
        with ZipFile(path) as archive:
            base_file.write_bytes(archive.read(base_file.name))
        base = run_path(str(base_file))
        base['stage'](repo, root)
    test = root / TEST
    text = test.read_text(encoding='utf-8-sig')
    anchor = 'gt, gc, LOCALIZATION_LENGTH'
    assert text.count(anchor) == 3
    text = text.replace(anchor + '\n', anchor + f', dilation:={angle}#\n')
    replay_anchor = 'peak, gt, gc, 125#'
    assert text.count(replay_anchor) == 1
    text = text.replace(replay_anchor + '\n', replay_anchor + f', dilation:={angle}#\n')
    assert text.count(f'dilation:={angle}#') == 4
    old = 'If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _'
    new = 'If branch.SavedFieldCount <> 8 Or twist <= 0# Then _'
    text = base['replace_once'](text, old, new)  # Угол меняет закручивание, силовые ступени проверяются отдельно.
    test.write_bytes(text.replace('\n', '\r\n').encode('utf-8-sig'))
    prep_file = root / 'Preparation.json'
    prep = json.loads(prep_file.read_bytes())
    prep['dilation_max_degrees'] = angle
    prep['inputs'][TEST] = base['digest'](test.read_bytes())
    prep_file.write_bytes((json.dumps(prep, indent=2) + '\n').encode('utf-8'))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--stage', required=True, type=Path)
    parser.add_argument('--angle', required=True, type=int, choices=(20, 26, 32, 40))
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve(), args.angle)
