"""Считывает эксперимент H35_01 с векторных кривых рис. 4-1 и 4-2(b)."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from statistics import median

import fitz


SOURCE = 'literature/Coupled6D/Osorio-Bustamante-2012-H45-Thesis.pdf'
SOURCE_SHA = '07153AC566681CB55797DCA3D0CDC7206FEE4122FC9FA20BA9D8DA52ABA7C18D'
CHECKPOINTS = (.00025,.0005,.00075,.001,.00125,.0015,.00165,.00175,.002,.0022,.0025,.00275)


def trace(drawings, indices):
    """Дискретизирует кубические кривые с единой сеткой параметра."""
    result = []
    for i in indices:
        row = drawings[i]
        assert row['dashes'] == '[] 0' and row['color'] == (0.,0.,0.)
        for kind, *points in row['items']:
            assert kind == 'c' and len(points) == 4
            a,b,c,d = points
            for t in (0., .25, .5, .75):
                s = 1.-t
                result.append(a*s**3+b*(3*s**2*t)+c*(3*s*t**2)+d*t**3)
        result.append(d)
    return result


def ordinate(line, x):
    """Интерполирует пересечения и сохраняет разброс при локальном возврате."""
    crossings = [a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0]) for a,b in zip(line,line[1:])
                 if min(a[0],b[0]) <= x < max(a[0],b[0])]
    assert crossings
    return median(crossings), max(crossings)-min(crossings)


def digitize(repo):
    """Читает деления осей из рисунков, положительное сжатие обращает в знак НДМ."""
    source = repo / SOURCE
    assert sha256(source.read_bytes()).hexdigest().upper() == SOURCE_SHA
    with fitz.open(source) as doc:
        stress, volume = (doc[i].get_drawings() for i in (67,68))
    sx = stress[10]['items']
    sy = stress[8]['items']
    sv = volume[38]['items']
    vx = volume[40]['items']
    x0, x_scale = sx[12][1].x, .012/(sx[24][1].x-sx[0][1].x)
    y0, y_scale = sy[0][1].y, 80./(sy[0][1].y-sy[16][1].y)
    vx0, vx_scale = vx[0][1].x, .004/(vx[20][1].x-vx[0][1].x)
    vy0, vy_scale = sv[10][1].y, .004/(sv[20][1].y-sv[0][1].y)
    stress_line = [((p.x-x0)*x_scale, (y0-p.y)*y_scale) for p in trace(stress,(11,12,13))]
    volume_line = [((p.x-vx0)*vx_scale, (vy0-p.y)*vy_scale) for p in trace(volume,(41,42))]
    axial_peak, fc = max((row for row in stress_line if row[0] > 0.), key=lambda row: row[1])
    lateral_line = [(s,-e) for e,s in stress_line if e < 0.]
    lateral_peak = max(range(len(lateral_line)), key=lambda i: lateral_line[i][0])
    assert 35.<fc<38. and .0015<axial_peak<.0018
    records = []
    for strain in CHECKPOINTS:
        sigma, stress_spread = ordinate(stress_line, strain)
        eps_volume, volume_spread = ordinate(volume_line, strain)
        # Левая половина рис. 4-1 имеет знак, обратный расширению.
        lateral_branch = lateral_line[lateral_peak:] if strain < axial_peak else lateral_line[:lateral_peak+1]
        lateral_at_sigma, lateral_spread = ordinate(lateral_branch, min(sigma,max(s for s,_ in lateral_branch)-1e-8))
        marker = {'axial_compression':strain, 'compressive_stress_MPa':sigma, 'volume_expansion':eps_volume,
                  'lateral_expansion':(eps_volume+strain)/2., 'lateral_at_stress_from_figure_4_1':lateral_at_sigma,
                  'stress_spread_MPa':stress_spread,'volume_spread':volume_spread,'lateral_spread':lateral_spread}
        records.append(marker)
    return {'specimen':'H35_01','source_sha256':SOURCE_SHA,'pdf_pages_1based':[68,69], 'printed_pages':[43,44],
            'approximate_peak_MPa':fc,'approximate_peak_axial_compression':axial_peak,
            'sign_convention':'compressive axial magnitude, positive volume and lateral expansion', 'checkpoints':records}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    result = digitize(args.repo.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print('OSORIO H35 FIGURES DIGITIZED', len(result['checkpoints']))
