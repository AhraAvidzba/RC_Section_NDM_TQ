"""Verify both attempts of the no-cache steel sensitivity evidence."""

from hashlib import sha256
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory


HERE=Path(__file__).resolve().parent
SUCCESS='B3BFB473F9D8E37B0B77627B55C8D7C43282DBD0BD5B1018D8AC0DCA1CCA39D7'
FAILURE='40705173C135E1E6292D0FB9DE877C740CD2A76056B7398F04F5C5C4DCA1C68D'
FIXTURE='C043985606765F0227FB9FCA68498A9EA0F48BD9C12782E6FA802BC31A222F29'
EDITED=('src/Solver/CCoupledNewtonSolver.cls','tests/modTestCoupledElasticState.bas')


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def data(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def receipts(lane,fixture,exit_code):
    code=data(lane/'docs/regression/CodeUpdate.json')
    owner=data(lane/'Native/Direct.txt.Ownership.json')
    close=data(lane/'Native/Direct.txt.ProcessClosure.json')
    compiler=data(lane/'CompileClosure.json')
    log=(lane/'Compile.log').read_text(encoding='utf-8-sig')
    claim=re.search(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',log,re.M)
    assert compiler['State']=='Absent' and claim
    assert (compiler['PID'],compiler['StartTicksUTC'])==(int(claim[1]),claim[2])
    assert code['Compiled'] and not code['ProductionChanged'] and code['ProductionSHA256']==fixture['workbook_sha256']
    assert sorted(code['Modules'])==fixture['modules']
    actor=close['Closure']['FinalState']
    assert close['Passed'] and close['ChildExitCode']==exit_code and close['RunnerCleanupValid']
    assert actor['State']=='Absent' and (actor['PID'],actor['StartTicksUTC'])==(owner['PID'],owner['StartTicksUTC'])
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256']==code['WorkbookSHA256']
    return compiler['PID'],owner['PID']


def main():
    for name,expected in data(HERE/'SHA256SUMS.json').items():
        assert digest(HERE/name)==expected
    assert digest(HERE/'Fixture.json')==FIXTURE
    fixture=data(HERE/'Fixture.json')
    failed=HERE/'Failure'; old=data(failed/'Fixture.json')
    assert fixture['base_fixture_sha256']==digest(failed/'Fixture.json')
    assert fixture['prior_failed_report_sha256']==FAILURE==digest(failed/'Native/Direct.txt')
    assert fixture['prior_failed_closure_sha256']==digest(failed/'Native/Direct.txt.ProcessClosure.json')
    assert fixture['workbook_sha256']==old['workbook_sha256']
    for module,expected in fixture['base_module_sha256'].items():
        assert old['frozen'][module]==expected
        if module in EDITED:
            assert digest(HERE/'Imported'/module)==fixture['frozen'][module]
            assert digest(failed/'Imported'/module)==expected
        else:
            assert fixture['frozen'][module]==expected
    assert digest(HERE/'Imported/src/Materials/CCoupledReinforcedResponse.cls')==fixture['frozen']['src/Materials/CCoupledReinforcedResponse.cls']
    failed_report=(failed/'Native/Direct.txt').read_text(encoding='utf-8-sig')
    assert 'FALLBACK_CASE;0;-.000000002;.99999797979798;0;1.1750297266257E-06' in failed_report
    assert 'отказов материала: 2; последняя точка отказа: 1' in failed_report
    processes=(*receipts(failed,old,1),*receipts(HERE,fixture,0))
    assert len(set(processes))==4
    report=HERE/'Native/Direct.txt'
    assert digest(report)==SUCCESS
    with TemporaryDirectory() as folder:
        copy=Path(folder)/report.name
        copyfile(report,copy)
        check_output([sys.executable,'-B','-X','utf8',str(HERE/'Verify.py'),str(copy)])
        assert copy.with_suffix('.Verification.json').read_bytes()==report.with_suffix('.Verification.json').read_bytes()
    print(f'NO SAVED TANGENT EVIDENCE PASS {SUCCESS}')


if __name__=='__main__':
    main()
