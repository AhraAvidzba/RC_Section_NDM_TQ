﻿# Компилирует и исполняет только проверку точной границы стали в отдельной книге.
param([switch]$Preflight)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../..')).Path
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$workbook='workbook/output/RC_Section_NDM.xlsm'
$isolated='docs/regression/Diagnostic.xlsm'
$report='Native/Direct.txt'
$beforeTEMP=$env:TEMP
$beforeTMP=$env:TMP
Push-Location -LiteralPath $root
try {
    $frozen=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    foreach($entry in $frozen.frozen.PSObject.Properties) {
        if ((Get-FileHash -LiteralPath $entry.Name).Hash -cne $entry.Value) {throw ('Изменился файл проверки '+$entry.Name)}
    }
    if ((Get-FileHash -LiteralPath (Join-Path $repo $workbook)).Hash -cne $frozen.workbook_sha256) {throw 'Сменилась установленная книга.'}
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {throw 'Путь пробы слишком длинный для Excel.'}
    Assert-IsolatedOfficeReady 'PreflightDirectSteel'
    if ($Preflight) {return}
    if (Test-Path -LiteralPath $report) {throw 'Сохраняется предыдущая проверка.'}
    if (!(Test-Path -LiteralPath 'docs/regression/CodeUpdate.json')) {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Get-FileHash -LiteralPath $isolated).Hash -cne $frozen.workbook_sha256) {throw 'Найдена непроверенная компиляция.'}
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $isolated -ModuleNames @('CBatchSectionCalculator','CCoupledElasticState','CCoupledLoadContinuation','CCoupledNewtonSolver','CCoupledReinforcedResponse','CCoupledSectionAnalysis','CNDMResultsWriter','CSectionPlotDataReader','CSectionStateResult','modAutoCADStressExport','modResultStatus','modTestCoupledElasticState') |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $closure.State -cne 'Absent' -or
        (($compiled.Modules | Sort-Object) -join ',') -cne 'CBatchSectionCalculator,CCoupledElasticState,CCoupledLoadContinuation,CCoupledNewtonSolver,CCoupledReinforcedResponse,CCoupledSectionAnalysis,CNDMResultsWriter,CSectionPlotDataReader,CSectionStateResult,modAutoCADStressExport,modResultStatus,modTestCoupledElasticState' -or $compiled.ProductionSHA256 -cne $frozen.workbook_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $isolated).Hash) {throw 'Не подтверждена изолированная компиляция.'}
    Assert-IsolatedOfficeReady 'PreNativeDirectSteel'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $isolated -ReportPath $report -Macro 'modTestCoupledElasticState.RunTestCoupledSteelWithoutSavedFactor' `
        -Mode No -TimeoutSeconds 140 -FailFast
    if ($LASTEXITCODE -ne 0) {throw 'Нативный запуск не завершён успешно.'}
    $ended=Get-Content -LiteralPath ($report+'.ProcessClosure.json') -Raw | ConvertFrom-Json
    if (!$ended.Passed -or $ended.Closure.FinalState.State -cne 'Absent') {throw 'Не подтверждено завершение дочернего Excel.'}
    & python -B -X utf8 'Verify.py' $report
    if ($LASTEXITCODE -ne 0) {throw 'Независимая проверка следа завершилась ошибкой.'}
} finally {
    $env:TEMP=$beforeTEMP
    $env:TMP=$beforeTMP
    Pop-Location
}
