"""Stage the retained-equilibrium fallback for unavailable steel sensitivity."""

from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
BASE=HERE.parent/'dsf'
BOOK='workbook/output/RC_Section_NDM.xlsm'
NEWTON='src/Solver/CCoupledNewtonSolver.cls'
STEEL='src/Materials/CCoupledReinforcedResponse.cls'
TEST='tests/modTestCoupledElasticState.bas'


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def replace(text,old,new):
    assert text.count(old)==1
    return text.replace(old,new)


assert not (HERE/'Fixture.json').exists()
source=json.loads((BASE/'Fixture.json').read_text(encoding='utf-8'))
assert digest(REPO/BOOK)==source['workbook_sha256']==digest(BASE/BOOK)
names=[name for name in source['frozen'] if name.startswith(('src/','tests/','tools/')) or name in (BOOK,'Guard-IsolatedOffice.ps1')]
for name in names:
    original=BASE/name
    assert digest(original)==source['frozen'][name]
    (HERE/name).parent.mkdir(exist_ok=True,parents=True)
    copyfile(original,HERE/name)
newton=(HERE/NEWTON).read_text(encoding='utf-8')
newton=replace(newton,'''    If ReadDirectCorrection(original, correction) Then
        If Not reinforcement.SteelBoundaryWithinCorrection(mSection, original, correction, point, unresolved) Then
            VerifyDirectSteelTrial = True
            Exit Function
        End If
    ElseIf estimated Then
        correction = screening
    Else
        unresolved = reinforcement.PresentSteelCriteria
        details = "Равновесие сохранено. Чувствительность предела стали не подтверждена."
        VerifyDirectSteelTrial = True
        Exit Function
    End If''','''    If Not estimated Then unresolved = reinforcement.PresentSteelCriteria
    ' Одна поправка задаёт начало строгой пробы. Кривизна ветви может
    ' менять остаток и знак после первой поправки при том же равновесии.
    If Not ReadDirectCorrection(original, correction) Then
        If estimated Then
            correction = screening
        Else
            details = "Равновесие сохранено. Чувствительность предела стали не подтверждена."
            VerifyDirectSteelTrial = True
            Exit Function
        End If
    End If''')
(HERE/NEWTON).write_text(newton,encoding='utf-8',newline='\r\n')
test=(HERE/TEST).read_text(encoding='utf-8')
marker="' -------------------- ДЛЯ ТЕСТОВ --------------------\n' У слабой касательной по осевой силе"
test=test[:test.index(marker)]+(HERE/'FallbackTest.txt').read_text(encoding='utf-8')
(HERE/TEST).write_text(test,encoding='utf-8',newline='\r\n')
for name in ('docs/regression','Temp','Native'):
    (HERE/name).mkdir(exist_ok=True,parents=True)
copyfile(HERE/BOOK,HERE/'docs/regression/Diagnostic.xlsm')
harness=(BASE/'Run.ps1').read_text(encoding='utf-8-sig')
(HERE/'Run.ps1').write_text(harness,encoding='utf-8-sig',newline='\r\n')
names+=['FallbackTest.txt','Stage.py','Verify.py','Run.ps1']
manifest={'workbook_sha256':source['workbook_sha256'],'base_fixture_sha256':digest(BASE/'Fixture.json'),
          'base_module_sha256':{name:source['frozen'][name] for name in names if name.startswith(('src/','tests/'))},
          'prior_failed_report_sha256':digest(BASE/'Native/Direct.txt'),
          'prior_failed_closure_sha256':digest(BASE/'Native/Direct.txt.ProcessClosure.json'),
          'frozen':{name:digest(HERE/name) for name in names},'modules':source['modules']}
(HERE/'Fixture.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(digest(HERE/'Fixture.json'))
