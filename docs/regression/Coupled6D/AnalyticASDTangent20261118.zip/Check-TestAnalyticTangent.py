"""ДЛЯ ТЕСТОВ: проверяет точный VBA аналитической касательной, тензоры и фактические пути равновесия."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


def TestRead(file):
    """Читает нативный протокол без нормализации ожиданий."""
    return json.loads(file.read_text('utf-8-sig'))


def TestNative(repo, root, output):
    """Декодирует все компоненты и проверяет обязательные направленные этапы, сохранение и закрытие Excel."""
    shared = run_path(str(root/'Check-TestMaterialRoundoff.py'))
    shared['TestFiles'](root)
    source, _ = run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    folder = root/'Cases/Final'
    record = shared['TestSourceComparison'](repo, root, folder, source, original, helper, body, reader)
    assert record['components'] == 238 and record['imported'] == 22 and record['unchanged'] == 216
    compiler = TestRead(folder/'docs/regression/CodeUpdate.json')
    reports = {}
    for log in sorted((folder/'Native').glob('*.txt')):
        text = log.read_text('utf-8-sig')
        phase = log.stem
        closure = TestRead(log.with_name(log.name+'.ProcessClosure.json'))
        owner = TestRead(log.with_name(log.name+'.Ownership.json'))
        assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['RunnerCleanupValid']
        assert closure['Closure']['FinalState']['State'] == 'Absent'
        identity = closure['Closure']['Identity']
        assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
        assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == compiler['WorkbookSHA256']
        assert 'SOURCE_UNCHANGED: True' in text and 'RUNTIME ERROR:' not in text
        totals = [tuple(map(int, row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', text, re.M)]
        assert totals and all(failed == 0 for passed, failed in totals)
        if phase == 'Material': assert totals == [(368, 0)]
        if phase == 'Tangent': assert totals == [(230, 0)]
        if phase == 'Core': assert sum(passed for passed, failed in totals) == 365
        if phase == 'Stock':
            assert totals == [(28, 0)]
            assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10460833943358; limit=;' in text
            assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;', text, re.M)
        reports[phase] = {'assertions': sum(passed for passed, failed in totals), 'physical_capacity_certified': False}
    assert set(reports) == {'Core', 'Material', 'Tangent', 'Stock', 'Trace44', 'Trace74'}
    pins = TestRead(root/'Reference/SourceArchive.json')
    for name, digest in pins['files'].items():
        assert sha256((root/'Reference'/name).read_bytes()).hexdigest().upper() == digest
        assert (folder/'Data'/name).read_bytes() == (root/'Reference'/name).read_bytes()
    failure = TestRead(root/'CompileFailure/CompileFailureClosure.json')
    assert failure['State'] == 'Absent' and not failure['Compiled']
    assert 'COMPILE_LOCATION: module=CCoupledASDTangent;' in (root/'CompileFailure/Compile.log').read_text('utf-8-sig')
    safety = [json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert safety and all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in safety)
    assert all(all(item['ProtectedUser'] for item in row['excel']) for row in safety)
    prep = TestRead(folder/'Preparation.json')
    with TemporaryDirectory() as scratch:
        restored = Path(scratch)
        for name, digest in prep['inputs'].items():
            raw = source if name == 'workbook/output/RC_Section_NDM.xlsm' else (folder/name).read_bytes()
            assert sha256(raw).hexdigest().upper() == digest
            file = restored/name
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_bytes(raw)
        (restored/'docs/regression').mkdir(parents=True, exist_ok=True)
        (restored/'docs/regression/Diagnostic.xlsm').write_bytes(source)
        restoration = {'inputs': len(prep['inputs']), 'compiled_or_calculated_state_reused': False, 'excel_started': False}
    record.update({'reports': reports, 'baseline_material_files_byte_equal': 4, 'physical_capacity_certified': False,
                   'clean_input_restoration': restoration})
    output.write_bytes((json.dumps(record, indent=2, sort_keys=True)+'\n').encode())
    print('EXACT NATIVE ANALYTIC TANGENT AND DIRECTED REGRESSIONS VERIFIED; PHYSICAL LIMIT OPEN')


def TestMechanics(repo, root, output):
    """Повторяет все производные через собственные векторы NumPy и обе нативные истории равновесия."""
    run_path(str(root/'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    results = {}
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch)
        result = scratch/'Tangent.json'
        run_path(str(root/'Check-TestNativeASDTangent.py'))['TestCheck'](root/'Cases/Final', result)
        results['tangent'] = TestRead(result)
        for phase, count in (('Trace44', 44), ('Trace74', 74)):
            result = scratch/(phase+'.json')
            run_path(str(root/'Validate-TestGeneralContinuation.py'))['TestValidate'](repo, root/'Cases/Final', phase, result, count)
            results[phase] = TestRead(result)
    output.write_bytes((json.dumps({'cases': results, 'physical_capacity_certified': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n').encode())
    print('INDEPENDENT NATIVE TANGENTS AND ALL SIX EQUILIBRIA VERIFIED; PHYSICAL LIMIT OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    (TestNative if args.scope == 'native' else TestMechanics)(args.repo.resolve(), args.root.resolve(), args.out.resolve())
