"""ДЛЯ ТЕСТОВ: независимо повторяет нативные ASD-касательные через numpy.eigh и полное правило цепочки."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from types import SimpleNamespace

import numpy as np


def TestInputs(root, name):
    """Читает фактические закреплённые таблицы частной книги без результатов или готового состояния."""
    prep = json.loads((root/'Preparation.json').read_bytes())
    raw = (root/'Data'/f'{name}.csv').read_bytes()
    assert sha256(raw).hexdigest().upper() == prep['inputs'][f'Data/{name}.csv']
    rows = iter(line.split(';') for line in raw.decode().splitlines())
    assert next(rows) == ['ASDFlow1', '30000', '0.2']
    curves = []
    for side in ('T', 'C'):
        head = next(rows)
        assert head[:2] == ['BRANCH', side]
        count = int(head[2])
        values = np.asarray([list(map(float, next(rows))) for _ in range(count)])
        x, nominal, effective = values.T
        tolerance = np.min(np.diff(x))*1e-6
        curves.append(SimpleNamespace(x=x, edges=x+tolerance, nominal=nominal, effective=effective, floor=float(head[3])))
    assert list(rows) == []
    return SimpleNamespace(curves=curves, ratio=max(5., max(curves[1].nominal)/max(curves[0].nominal)))


def TestCheck(root, output):
    """Проверяет исходные тензоры, координаты и все 36 производных каждого доступного нативного состояния."""
    helper = run_path(str(Path(__file__).with_name('TestClosedASDTangent.py')))
    evaluate = helper['TestConcrete']
    results = []
    for name in ('default', 'ndm_uniaxial'):
        material = TestInputs(root, name)
        rows = [line.split(';') for line in (root/'Data'/f'{name}.Tangent.csv').read_text('cp1251').splitlines()]
        states = [row for row in rows if row[0] == 'STATE']
        matrices = {}
        for row in rows:
            if row[0] == 'TANGENT':
                matrices.setdefault(tuple(row[1:4]), np.empty((6, 6)))[int(row[4])-1] = np.asarray(row[5:], dtype=float)
        assert len(states) == 111
        available = fallback = 0
        for row in states:
            assert len(row) == 39, len(row)
            values = np.asarray(row[5:], dtype=float)
            strain, old_strain, old_effective = [values[a:a+6].reshape(1, 1, 6) for a in (0, 6, 12)]
            old = values[18:20].reshape(2, 1, 1)
            nominal, effective = values[20:26], values[26:32]
            coordinates = values[32:34]
            moved = np.any(strain != old_strain)
            expected, history, tangent, iterations = evaluate(material, strain, (old_strain, old_effective, old), maximum_iterations=1024)
            stress_error = np.max(np.abs(expected.ravel()-nominal))
            effective_error = np.max(np.abs(history[1].ravel()-effective))
            coordinate_error = 30000.*np.max(np.abs(history[2].ravel()-coordinates))
            # Нулевая проба оболочки хранит принятую историю; экспорт чистого Flow всё равно замыкается повторно.
            assert max(stress_error, effective_error, coordinate_error) < 2e-7, (name, row[2:4], stress_error, effective_error, coordinate_error)
            record = {'name': name, 'path': row[2], 'step': int(row[3]), 'available': row[4] == 'True',
                      'stress_error_MPa': float(stress_error), 'effective_error_MPa': float(effective_error),
                      'coordinate_error_times_E_MPa': float(coordinate_error), 'closure_iterations': iterations}
            key = tuple(row[1:4])
            if record['available']:
                assert moved
                available += 1
                actual = matrices.pop(key)
                expected_tangent = tangent.reshape(6, 6)
                absolute = float(np.max(np.abs(actual-expected_tangent)))
                scale = max(1., float(np.max(np.abs(expected_tangent))))
                record['tangent_error_MPa'] = absolute
                record['tangent_error_relative'] = absolute/scale
                assert absolute < 1e-5+1e-7*scale, (record, actual, expected_tangent)
            else:
                fallback += 1
                assert key not in matrices
            results.append(record)
        assert available >= 25 and fallback >= 10 and not matrices, (name, available, fallback)
    proof = {'cases': results, 'states': len(results), 'available': sum(row['available'] for row in results),
             'physical_capacity_certified': False, 'full_acceptance': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('INDEPENDENT NATIVE TANGENT PASS', proof['states'], proof['available'],
          max(row.get('tangent_error_relative', 0.) for row in results), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestCheck(args.root.resolve(), args.out.resolve())
