"""ДЛЯ ТЕСТОВ: закрепляет аналитическую ASD-касательную, нативную книгу и независимые производные."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestCollect(repo, root):
    """Переиспользует сохранение фактического VBA; базовые тензоры извлекает только из закреплённого архива."""
    here = Path(__file__).resolve().parent
    shared = run_path(str(here/'Collect-TestFieldRecovery.py'))
    shared['TestCases'].clear()
    shared['TestCases']['Final'] = 'AnalyticASDTangent0220261118'
    shared['TestCollect'](repo, root)
    for name in ('Collect-TestAnalyticTangent.py', 'Check-TestAnalyticTangent.py', 'Check-TestNativeASDTangent.py'):
        shared['TestCopy'](here/name, root/name)
    raw = (repo/'docs/regression/Coupled6D/AcceptedRevisionContinuation20261118.zip').read_bytes()
    digest = '4C53BAF664BEF67F5486053F096D9E47B8F1439FFF53B663E972F67937353EFB'
    assert sha256(raw).hexdigest().upper() == digest
    pins = {}
    with ZipFile(BytesIO(raw)) as archive:
        for name in ('default.Native.csv', 'default.Probes.csv', 'ndm_uniaxial.Native.csv', 'ndm_uniaxial.Probes.csv'):
            value = archive.read('Cases/Final/Data/'+name)
            target = root/'Reference'/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(value)
            pins[name] = sha256(value).hexdigest().upper()
    (root/'Reference/SourceArchive.json').write_bytes((json.dumps({'archive_sha256': digest, 'files': pins}, indent=2)+'\n').encode())
    failure = Path('D:/CodexScratch/RC_Section_NDM_TQ/AnalyticASDTangent20261118')
    for name in ('Compile.log', 'CompileFailureClosure.json', 'Preparation.json', 'src/Materials/CCoupledASDTangent.cls'):
        shared['TestCopy'](failure/name, root/'CompileFailure'/name)
    (root/'SourceCheckpoint.json').write_bytes((json.dumps({'base': 'c0b09fc', 'installed_workbook_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2)+'\n').encode())
    files = {p.relative_to(root).as_posix(): sha256(p.read_bytes()).hexdigest().upper()
             for p in root.rglob('*') if p.is_file() and p.name != 'Files.json'}
    (root/'Files.json').write_bytes((json.dumps(files, indent=2, sort_keys=True)+'\n').encode())
    print('ANALYTIC TANGENT EVIDENCE COLLECTED', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
