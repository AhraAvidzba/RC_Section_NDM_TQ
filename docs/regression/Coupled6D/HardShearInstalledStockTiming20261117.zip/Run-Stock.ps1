# Запускает штатный связанный расчёт HardShear из точной копии установленной книги.
param([switch]$InputsOnly)

$ErrorActionPreference='Stop'
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
Push-Location -LiteralPath $PSScriptRoot
try {
    $plan=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    foreach ($entry in $plan.inputs.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $entry.Name).Hash -cne $entry.Value) {throw "Изменился вход $($entry.Name)."}
    }
    if ($InputsOnly) {Write-Output 'HARDSHEAR STOCK INPUTS: PASS'; return}
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    . './Guard-IsolatedOffice.ps1'
    $report='Native/Both.txt'
    if (Test-Path -LiteralPath $report) {throw 'Для этого прогона уже есть отчёт.'}
    Assert-IsolatedOfficeReady 'RunHardShearStockBoth'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook 'workbook/output/RC_Section_NDM.xlsm' -ReportPath $report `
        -Macro 'modTestCoupledElasticState.RunTestCoupledWorkbookTiming' -MacroArgument1 Both -MacroArgument2 Excel `
        -Mode No -TimeoutSeconds 170 -FailFast -VerifyResultsReopen
    if ($LASTEXITCODE) {throw "Штатный контроль завершился с кодом $LASTEXITCODE."}
    if ((Get-FileHash -LiteralPath 'workbook/output/RC_Section_NDM.xlsm').Hash -cne $plan.book_sha256) {
        throw 'Изменилась исходная копия книги.'
    }
    $details=Get-Content -LiteralPath $report -Encoding utf8
    $fixture=@($details | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixture.Count -ne 1) {throw 'Не подтверждён путь рабочей копии.'}
    $directory=Split-Path -Parent $fixture[0].Substring('FIXTURE: '.Length)
    if (!$directory.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь копии находится вне Temp.'}
    $execution=Join-Path $directory 'RC_Section_NDM_execution_report.txt'
    if (Test-Path -LiteralPath $execution) {Copy-Item -LiteralPath $execution -Destination 'Native/Both.Execution.txt'}
    $details | Where-Object {$_ -match '^(TIMING_(STATES|SECONDS|LIMIT_REASON)|TOTAL_COUPLED_WORKBOOK_TIMING)'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
