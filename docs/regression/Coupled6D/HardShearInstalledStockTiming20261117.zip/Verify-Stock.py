"""Check signed forces, search status, timing and ownership for the native stock workbook."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_output


HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
COMPONENTS = ("N", "Mx", "My", "T", "Qx", "Qy")
TARGET = (28000.0, 510000.0, 180000.0, 1500000.0, 17000.0, -7100.0)


def digest(raw):
    return sha256(raw).hexdigest().upper()


def verify(root, repo):
    plan = json.loads((root / "Fixture.json").read_bytes())
    assert plan["book_sha256"] == plan["inputs"][BOOK] == SHA
    book_path = repo / BOOK
    book = book_path.read_bytes() if book_path.is_file() else b""
    if digest(book) != SHA:
        book = check_output(["git", "-C", str(repo), "show", f"709e7dfa16c192748fc2c6d999925bdbf9948a4c:{BOOK}"])
    assert digest(book) == SHA
    for name, h in plan["inputs"].items():
        if name != BOOK:
            assert digest((root / name).read_bytes()) == h

    data = root / "Native/Both.txt"
    sink = data.read_text(encoding="utf-8-sig")
    owner = json.loads(data.with_suffix(".txt.Ownership.json").read_bytes())
    closed = json.loads(data.with_suffix(".txt.ProcessClosure.json").read_bytes())
    final = closed["Closure"]["FinalState"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == SHA
    assert (final["State"], final["PID"], final["StartTicksUTC"]) == ("Absent", owner["PID"], owner["StartTicksUTC"])
    assert closed["Passed"] and closed["ChildHasExited"] and closed["ChildExitCode"] == 0
    assert sink.count("TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0") == 1
    assert "SOURCE_UNCHANGED: True" in sink
    stages, = re.findall(r"^TIMING_SECONDS: ([\d.]+) \| Both \| Excel$", sink, flags=re.MULTILINE)
    state, = re.findall(r"^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([\d.]+); limit=; code=NUMERICAL_FAILURE$",
                        sink, flags=re.MULTILINE)
    before, after = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=([A-F0-9]{64}); equal=True;", sink,
                              flags=re.MULTILINE).groups()
    assert before == after
    components = dict(re.findall(r"^OK: direct (N|Mx|My|T|Qx|Qy) actual=([\d.E+-]+) expected=[^\n]+", sink, flags=re.MULTILINE))
    assert tuple(components) == COMPONENTS
    recovered = [float(components[component]) * (9806650.0 if 1 <= i <= 3 else 9806.65)
                 for i, component in enumerate(COMPONENTS)]
    assert max(abs(a - b) for a, b in zip(recovered, TARGET, strict=True)) < 1e-4
    assert re.findall(r"^OK: no unconfirmed limit component (.+)$", sink, flags=re.MULTILINE) == list(COMPONENTS)
    execution = root / "Native/Both.Execution.txt"
    trace = execution.read_text(encoding="utf-16")
    direct_s = float(re.search(r"^\[([\d.]+) с\] Связанное равновесие подтверждено по шести усилиям\.", trace,
                               flags=re.MULTILINE).group(1))
    capacity_s = float(re.search(r"^\[([\d.]+) с\] Подтверждён локальный максимум", trace, flags=re.MULTILINE).group(1))
    assert f"наибольший допустимый lambda: {state}; равновесие при lambda = 1 подтверждено: True; проб: 96;" in trace
    assert 0. < direct_s < capacity_s < float(stages)
    return {"book_sha256": SHA, "owner": owner["PID"], "closed": final["State"], "reopened_results_sha256": before,
            "direct_equilibrium_time_s": direct_s, "capacity_end_time_s": capacity_s,
            "time_between_direct_and_capacity_s": round(capacity_s - direct_s, 3), "macro_elapsed_s": float(stages),
            "signed_resultant_order": COMPONENTS, "recovered_resultants_N_Nmm": recovered,
            "direct_status": "OK", "capacity_status": "NumFail", "lower_confirmed_lambda": float(state),
            "report_sha256": digest(data.read_bytes()), "trace_sha256": digest(execution.read_bytes())}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=HERE)
    parser.add_argument("--repo", type=Path, required=True)
    args = parser.parse_args()
    proof = verify(args.root, args.repo)
    raw = (json.dumps(proof, indent=2, sort_keys=True) + "\n").encode()
    saved = HERE / "StockProof.json"
    if saved.is_file():
        assert saved.read_bytes() == raw
    else:
        saved.write_bytes(raw)
    print("HARDSHEAR STOCK NATIVE VERIFIED", digest(raw))
