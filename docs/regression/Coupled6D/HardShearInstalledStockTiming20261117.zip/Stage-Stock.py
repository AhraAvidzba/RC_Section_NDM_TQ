"""Prepare the unchanged installed workbook for the matched HardShear smoke case."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
STORAGE = Path("D:/CodexScratch/RC_Section_NDM_TQ")
HELPERS = STORAGE / "CompletedHardShearWorkbookV1_20261117"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def prepare(path):
    before = json.loads((HELPERS / "Fixture.json").read_bytes())["inputs"]
    files = {name: (HELPERS / name).read_bytes() for name in before if name.startswith("tools/") or name.startswith("Guard-")}
    assert all(digest(data) == before[name] for name, data in files.items())
    files[BOOK] = (REPO / BOOK).read_bytes()
    assert digest(files[BOOK]) == BOOK_SHA
    files["Run-Stock.ps1"] = (HERE / "Run-Stock.ps1").read_bytes()
    manifest = {"book_sha256": BOOK_SHA, "inputs": {name: digest(data) for name, data in sorted(files.items())}}
    path = path.resolve()
    assert path != STORAGE.resolve() and path.is_relative_to(STORAGE.resolve())
    path.mkdir()
    for subfolder in ("Temp", "Native", "docs/regression"):
        (path / subfolder).mkdir(parents=True)
    files["Fixture.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    for name, data in files.items():
        destination = path / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write(data)
    print("STOCK INPUTS", digest(files["Fixture.json"]))


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path, required=True)
    prepare(parser.parse_args().stage)
