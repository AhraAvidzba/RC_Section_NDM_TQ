"""ДЛЯ ТЕСТОВ: сохраняет точную заблокированную итерацию без изменения алгоритма Ньютона."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root):
    """Инструментирует только частные источники; рабочий исходник и установленная книга не меняются."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingASD.py'))['TestStage'](repo,root)
    prep=json.loads((root/'Preparation.json').read_bytes())
    relative='src/Solver/CCoupledNewtonSolver.cls'; original=(root/relative).read_bytes()
    code=original.decode('utf-8-sig').replace('\r\n','\n')
    marker='Private mSection As CCoupledElasticState'
    assert code.count(marker)==1
    code=code.replace(marker,"Private mTestCaptured As Boolean, mTestLambda As Double\nPrivate mTestField() As Double, mTestCorrection() As Double, mTestMatrix() As Double\n"+marker)
    marker='    mWrongControlDirection = False\n    mSameControlInitialFailure = vbNullString'
    assert code.count(marker)==1
    code=code.replace(marker,marker+'\n    mTestCaptured = False')
    marker='        If Not accepted Then\n            If useSteelCorrection'
    assert code.count(marker)==1
    code=code.replace(marker,'        If Not accepted Then\n            mTestField = current: mTestCorrection = correction: mTestMatrix = mMatrix\n            mTestLambda = currentLambda: mTestCaptured = True\n            If useSteelCorrection')
    code+='''\n' -------------------- ДЛЯ ТЕСТОВ --------------------
' Копирует последнюю отвергнутую итерацию без признания её равновесием.
Friend Function TestCopyRejectedDirection(ByRef field() As Double, ByRef correction() As Double, _
        ByRef matrix() As Double, ByRef lambda As Double) As Boolean
    If Not mTestCaptured Then Exit Function
    field = mTestField: correction = mTestCorrection: matrix = mTestMatrix: lambda = mTestLambda
    TestCopyRejectedDirection = True
End Function
'''
    (root/relative).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['test_only_instrumentation']={relative:{'before':sha256(original).hexdigest().upper(),'purpose':'Capture rejected iterate and correction only'}}
    relative='tests/modTestMVT2ProductionASDTest.bas'; code=(root/relative).read_text('utf-8-sig')
    marker='    For index = 1 To 6\n        If Not solver.ReplayAcceptedFields(history, history.Count) Then'
    assert code.count(marker)==1
    code=code.replace(marker,'    For index = 1 To 1\n        If Not solver.ReplayAcceptedFields(history, history.Count) Then')
    marker='        WriteMaterialFailureTest minusConcrete.LastFailure, phase, -1, report, tracePath'
    assert code.count(marker)==1
    code=code.replace(marker,marker+'\n        WriteRejectedDirectionTest solver, operators, phase, target, projection, report, tracePath')
    code+='\n'+(here/'TestNativeRejectedDirection.bas.txt').read_text('utf-8')
    (root/relative).write_bytes(code.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8-sig'))
    for relative in ('TestNativeRejectedDirection.bas.txt',Path(__file__).name):
        (root/relative).write_bytes((here/relative).read_bytes())
        prep['inputs'][relative]=sha256((root/relative).read_bytes()).hexdigest().upper()
    for relative in ('src/Solver/CCoupledNewtonSolver.cls','tests/modTestMVT2ProductionASDTest.bas'):
        prep['inputs'][relative]=sha256((root/relative).read_bytes()).hexdigest().upper()
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('REJECTED DIRECTION DIAGNOSTIC READY; SOLVER ALGORITHM UNCHANGED')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestStage(args.repo.resolve(),args.root.resolve())
