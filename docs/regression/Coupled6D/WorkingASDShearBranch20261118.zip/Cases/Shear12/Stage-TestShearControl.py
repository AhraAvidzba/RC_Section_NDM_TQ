"""ДЛЯ ТЕСТОВ: готовит собственное продолжение по уже подтверждённому среднему сдвигу."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root):
    """Использует неизменённый рабочий решатель; измеряет пригодность сдвиговой параметризации."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingASD.py'))['TestStage'](repo,root)
    prep=json.loads((root/'Preparation.json').read_bytes())
    relative='tests/modTestMVT2ProductionASDTest.bas'; code=(root/relative).read_text('utf-8-sig')
    marker='        Case "ControlProbe"'
    assert code.count(marker)==1
    code=code.replace(marker,'        Case "ShearControl"\n            completed = RunShearControlTest(report, tracePath)\n'+marker)
    code+='\n'+(here/'TestNativeShearControl.bas.txt').read_text('utf-8')
    (root/relative).write_bytes(code.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8-sig'))
    relative='Run-TestWorkingASD.ps1'; code=(root/relative).read_text('utf-8-sig')
    code=code.replace("'ControlProbe'","'ControlProbe','ShearControl'")
    (root/relative).write_text(code,encoding='utf-8-sig')
    for relative in ('TestNativeShearControl.bas.txt',Path(__file__).name):
        (root/relative).write_bytes((here/relative).read_bytes())
    for relative in ('tests/modTestMVT2ProductionASDTest.bas','Run-TestWorkingASD.ps1','TestNativeShearControl.bas.txt',Path(__file__).name):
        prep['inputs'][relative]=sha256((root/relative).read_bytes()).hexdigest().upper()
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('SHEAR CONTINUATION READY; WORKING SOLVER UNCHANGED; 12 CONTROLLED STATES REQUESTED')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestStage(args.repo.resolve(),args.root.resolve())
