"""ДЛЯ ТЕСТОВ: независимо проверяет фактическую производную на заблокированной итерации VBA."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestAnalyze(repo,root,output):
    """Не меняет историю и допуски; отличает локальную линеаризацию от переходов на конечной поправке."""
    here=Path(__file__).resolve().parent
    helper=run_path(str(here/'TestResolutionSection.py'))
    reference=run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        for a,b in (('Operators.csv','ControlProbe.Operators.csv'),('MVTGaussMixed.csv','ControlProbe.csv')):
            (scratch/a).write_bytes((root/'Native'/b).read_bytes())
        section=helper['TestResolutionSection'](scratch,reference,True)
    history=section.TestInitial(); maximum=0.
    for line in (root/'AcceptedHistory.csv').read_text().splitlines():
        row=line.split(';'); torque,q=map(float,row[1:3]); field=np.asarray(row[3:],float)
        target=np.array([0.,-396.*q,0.,torque,0.,q])
        result=section.TestEvaluate(field,history,target)
        tolerance=5e-7+5e-7*np.max(np.abs((target@section.l)[:-4]))
        assert result[1]<=tolerance,(row[0],result[1],tolerance)
        maximum=max(maximum,float(result[1])); history=result[4]
    rows=[line.split(';') for line in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    unique=lambda key:[row for row in rows if row[0]==key]
    base,=unique('REJECTED_BASE'); field,=unique('REJECTED_FIELD'); correction,=unique('REJECTED_CORRECTION'); projection,=unique('CONTROL_PROJECTION')
    field=np.asarray(field[2:],float); correction=np.asarray(correction[2:],float); projection=np.asarray(projection[2:],float)
    matrix=np.asarray([row[2:] for row in unique('REJECTED_MATRIX')],float).T
    lam,target_control=map(float,base[2:]); n=len(field)
    assert matrix.shape==(n,n) and len(correction)==n+1
    direction=np.array([0.,-396.*75000.,0.,0.,0.,75000.]); constant=np.array([0.,0.,0.,10510000.,0.,0.])
    zero=section.TestEvaluate(field,history,constant+lam*direction)
    action=matrix@correction[:n]-(direction@section.l)*correction[n]
    differential=run_path(str(here/'TestClosedASDTangent.py'))
    ad=differential['TestGlobalMatrix'](section,field,history)[0]
    ad_action=ad@correction[:n]-(direction@section.l)*correction[n]
    tangent=differential['TestConcrete'](section,section.b@field,history)[2]
    stress_direction=np.einsum('spij,spj->spi',tangent,section.b@correction[:n])
    stress_direction[:,section.TestConcreteCount:]*=-1.
    steel_direction=200000.*(section.a@correction[:n]).reshape(3,section.TestSteelCount)
    steel_direction*=np.abs(zero[-1])<section.bounds
    stress_direction[:,section.TestConcreteCount:]+=steel_direction[...,None]*section.directions
    point_action=np.einsum('pi,pi->p',section.s[:,:,79],stress_direction[0])
    point_action+=np.einsum('pi,pi->p',section.r[:,:,79],(stress_direction[1]-stress_direction[2])/section.double_dx)
    records=[]; native_error=0.; base_mask=np.abs(zero[-1])>=section.bounds
    for row in unique('DIRECTION_RESIDUAL'):
        fraction=float(row[1]); current=field+fraction*correction[:n]; load=constant+(lam+fraction*correction[n])*direction
        result=section.TestEvaluate(current,history,load)
        native_internal=np.asarray(row[2:],float)
        native_residual=native_internal-load@section.l
        error=float(np.max(np.abs(native_residual-result[0])))
        assert error<5e-7,(fraction,error)
        native_error=max(native_error,error)
        norm=max(float(result[1]),abs(float(30000.*(projection@current-target_control))))
        record={'fraction':fraction,'full_norm_MPa':norm,'row80_MPa':float(result[0][79]),
                'steel_branch_changes':int(np.sum((np.abs(result[-1])>=section.bounds)!=base_mask)),
                'native_residual_error_MPa':error}
        if fraction>0.:
            derivative=(result[0]-zero[0])/fraction
            record.update({'row80_directional_derivative_MPa':float(derivative[79]),
                           'native_matrix_direction_error_MPa':float(np.max(np.abs(derivative-action))),
                           'spectral_matrix_direction_error_MPa':float(np.max(np.abs(derivative-ad_action)))})
        records.append(record)
    contributions=[]
    for fraction in (1./128.,1./512.):
        target=constant+(lam+fraction*correction[n])*direction
        trial=section.TestEvaluate(field+fraction*correction[:n],history,target)
        stress_delta=(trial[3]-zero[3])/fraction
        point_delta=np.einsum('pi,pi->p',section.s[:,:,79],stress_delta[0])
        point_delta+=np.einsum('pi,pi->p',section.r[:,:,79],(stress_delta[1]-stress_delta[2])/section.double_dx)
        error=point_delta-point_action
        top=[]
        for point in np.argsort(np.abs(error))[-6:][::-1]:
            top.append({'point':int(point+1),'steel':bool(point>=section.TestConcreteCount),
                        'direction_difference_MPa':float(error[point]),
                        'prior_coordinates':history[2][:,:,point].tolist(),
                        'base_coordinates':zero[4][2][:,:,point].tolist(),
                        'trial_coordinates':trial[4][2][:,:,point].tolist()})
        contributions.append({'fraction':fraction,'points':top})
    result={'accepted_prefix_states':74,'prefix_max_norm_MPa':maximum,'base_lambda':lam,
            'row80_base_MPa':float(zero[0][79]),'row80_native_matrix_action_MPa':float(action[79]),
            'row80_spectral_matrix_action_MPa':float(ad_action[79]),'native_residual_error_MPa':native_error,
            'samples':records,'row80_point_contributions':contributions,'physical_capacity_certified':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('REJECTED ITERATE AND DIRECTION REPLAYED; ALL SIX LOADS RETAINED',flush=True)
    print('BASE',result['row80_base_MPa'],'MATRIX',action[79],'SPECTRAL',ad_action[79],flush=True)
    for row in records:
        print(row['fraction'],row['full_norm_MPa'],row.get('row80_directional_derivative_MPa'),row['steel_branch_changes'],flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True); args=parser.parse_args(); TestAnalyze(args.repo.resolve(),args.root.resolve(),args.out.resolve())
