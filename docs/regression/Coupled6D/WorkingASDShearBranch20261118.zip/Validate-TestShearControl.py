"""ДЛЯ ТЕСТОВ: независимо проверяет сдвиговую ветвь, все усилия и фактически заданную меру."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import numpy as np


def TestValidate(repo,root,output):
    """Повторяет материал по собственной полной истории; численный отказ не получает положительный статус набора."""
    here=Path(__file__).resolve().parent
    raw=(repo/'docs/regression/Coupled6D/ProductionGaussAndASD20261118.zip').read_bytes()
    assert sha256(raw).hexdigest().upper()=='322CBF36E5FD026CD3C7A2D852CF3BC0FF1E91A529B5FBBF8CD6186254B96395'
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch); prefixes=[]
        with ZipFile(BytesIO(raw)) as archive:
            for index,prefix in enumerate(('Prefix/Native/','NativeCase/Mechanics/')):
                folder=scratch/str(index); folder.mkdir(); prefixes.append(folder)
                for name in ('Operators.csv','MVTGaussMixed.csv','MVTGaussMixed.Tensor.csv'):
                    (folder/name).write_bytes(archive.read(prefix+name))
        native=scratch/'Native'; native.mkdir()
        for a,b in (('Operators.csv','ShearControl.Operators.csv'),('MVTGaussMixed.csv','ShearControl.csv'),
                    ('MVTGaussMixed.Tensor.csv','ShearControl.Tensor.csv')):
            (native/a).write_bytes((root/'Native'/b).read_bytes())
        section,history,fields=run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo,native,scratch/'Mechanics.json',prefix_native=prefixes)
        proof=json.loads((scratch/'Mechanics.json').read_bytes())
        projection=np.einsum('p,pd->d',section.weight[:section.TestConcreteCount],section.b[0,:section.TestConcreteCount,5,:])/57600.
        old,current=[np.asarray(row.split(';')[3:],float) for row in (root/'AcceptedHistory.csv').read_text().splitlines()[-2:]]
        sign=float(np.sign(projection@(current-old))); assert sign!=0.; projection*=sign
        rows=[line.split(';') for line in (root/'Native/ShearControl.txt').read_text('utf-8-sig').splitlines()]
        attempts=[row for row in rows if row[0]=='SHEAR_CONTROL_ATTEMPT']
        controls=[float(row[3]) for row in attempts if row[2]=='True']
        new_fields=[(label,field) for label,field in fields if label.startswith('ShearControl')]
        assert len(new_fields)==len(controls)>0
        control_errors=[]
        for (label,field),target in zip(new_fields,controls,strict=True):
            error=float(abs(30000.*(projection@field-target)))
            entry,=[row for row in proof['states'] if row['label']==label]
            assert error<=entry['tolerance_MPa'],(label,error)
            control_errors.append(error)
        prep=json.loads((root/'Preparation.json').read_bytes())
        expected=prep.get('shear_test_scope',{}).get('requested_states',12)
        proof.update({'new_states':len(new_fields),'attempts':len(attempts),'requested_states':expected,
                      'declared_scope_completed':len(new_fields)==expected,'control_error_MPa':max(control_errors),
                      'maximum_Qy_N':max(row['target_N_Nmm'][5] for row in proof['states'])})
        last_field=new_fields[-1][1]; strains=section.b@last_field
        concrete=strains[:,:section.TestConcreteCount]
        tensor=np.zeros((*concrete.shape[:-1],3,3))
        for index in range(3): tensor[...,index,index]=concrete[...,index]
        for index,(a,b) in enumerate(((0,1),(0,2),(1,2)),3):
            tensor[...,a,b]=tensor[...,b,a]=0.5*concrete[...,index]
        principal=np.linalg.eigvalsh(tensor); bars=(section.a@last_field).reshape(3,section.TestSteelCount)
        compression=section.curves[1]; peak=int(np.argmax(compression.nominal))
        proof['final_material_measures']={'compression_coordinate':float(np.max(history[2][1,:,:section.TestConcreteCount])),
            'compression_backbone_peak_coordinate':float(compression.x[peak]),
            'minimum_principal_concrete_strain':float(np.min(principal)),'maximum_principal_concrete_strain':float(np.max(principal)),
            'maximum_longitudinal_bar_strain':float(np.max(np.abs(bars[:,:4]))),'maximum_hoop_strain':float(np.max(np.abs(bars[:,4:])))}
    output.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('SHEAR CONTROL SIX RESULTANTS, THREE STATIONS AND ACTUAL CONTROL VERIFIED',proof['new_states'],proof['maximum_Qy_N'],proof['declared_scope_completed'])


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True); args=parser.parse_args(); TestValidate(args.repo.resolve(),args.root.resolve(),args.out.resolve())
