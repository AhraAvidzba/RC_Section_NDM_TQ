"""ДЛЯ ТЕСТОВ: сохраняет действительную сдвиговую ветвь и проверенные причины предшествующей остановки."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


TestCases={'Direction':'RejectedDirection0220261118','Damping':'AdaptiveControlDamping0220261118',
           'ShearFixed':'ShearControlContinuation20261118','Shear12':'ShearControlContinuation0220261118',
           'Shear32':'ShearControlContinuation3220261118'}


def TestCopy(source,target):
    """Копирует точные байты без подмены прежнего результата."""
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream: stream.write(source.read_bytes())


def TestCollect(repo,root):
    """Исключает временные полные XLSM; их фактический VBA и источники сохраняются явно."""
    scratch=Path('D:/CodexScratch/RC_Section_NDM_TQ'); root.mkdir()
    for key,directory in TestCases.items():
        source=scratch/directory; target=root/'Cases'/key
        prep=json.loads((source/'Preparation.json').read_bytes())
        for relative,expected in prep['inputs'].items():
            assert sha256((source/relative).read_bytes()).hexdigest().upper()==expected,(key,relative)
        for file in source.rglob('*'):
            if not file.is_file(): continue
            relative=file.relative_to(source)
            if relative.parts[0] in ('Temp','workbook') or file.suffix.lower()=='.xlsm': continue
            TestCopy(file,target/relative)
        for log in (target/'Native').glob('*.txt'):
            assert log.with_name(log.name+'.ProcessClosure.json').is_file(),(key,log)
        with ZipFile(source/'docs/regression/Diagnostic.xlsm') as book: raw=book.read('xl/vbaProject.bin')
        (target/'CompiledVBA.bin').write_bytes(raw)
        (target/'CompiledVBA.json').write_bytes((json.dumps({'bytes':len(raw),'sha256':sha256(raw).hexdigest().upper()},indent=2)+'\n').encode())
    failed=scratch/'AdaptiveControlDamping20261118'; target=root/'FailedCompile'
    for file in failed.rglob('*'):
        if not file.is_file(): continue
        relative=file.relative_to(failed)
        if relative.parts[0] in ('Temp','workbook') or file.suffix.lower()=='.xlsm': continue
        TestCopy(file,target/relative)
    here=Path(__file__).resolve().parent
    for name in ('Collect-TestShearBranch.py','Check-TestShearBranch.py','Validate-TestShearControl.py','Analyze-TestRejectedDirection.py',
                 'Solve-TestRejectedDirection.py','Probe-TestActualArc.py','TestResolutionSection.py','TestClosedASDTangent.py',
                 'Probe-TestASDClosure.py','Probe-TestASDMaterialSteps.py','Verify-TestReducedEvidence.py','Verify-TestASDResolution.py',
                 'Inspect-TestResolutionVBA.py','Check-TestMaterialRoundoff.py'):
        TestCopy(here/name,root/name)
    TestCopy(scratch/'WorkingForceSubspaceEvidence20261118/SourceBook.json',root/'SourceBook.json')
    (root/'Cases.json').write_bytes((json.dumps(TestCases,indent=2,sort_keys=True)+'\n').encode())
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper() for file in root.rglob('*') if file.is_file()}
    (root/'Files.json').write_bytes((json.dumps(files,indent=2,sort_keys=True)+'\n').encode())
    print('SHEAR BRANCH EVIDENCE COLLECTED',len(files))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestCollect(args.repo.resolve(),args.root.resolve())
