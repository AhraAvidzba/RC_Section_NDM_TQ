"""ДЛЯ ТЕСТОВ: проверяет точный VBA, нативные области и независимую механику сдвиговой ветви."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def TestRead(file):
    """Читает сохранённые числа и отрицательные статусы без нормализации."""
    return json.loads(file.read_text('utf-8-sig'))


def TestFiles(root):
    """Проверяет точность полного комплекта до вычислений."""
    for relative,expected in TestRead(root/'Files.json').items():
        assert sha256((root/relative).read_bytes()).hexdigest().upper()==expected,relative


def TestNative(repo,root,output):
    """Подтверждает изменённые только для теста компоненты, реальные статусы и закрытие каждого собственного Excel."""
    TestFiles(root)
    shared=run_path(str(root/'Check-TestMaterialRoundoff.py'))
    source,_=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _,original=reader(BytesIO(source)); records={}
    baseline=(repo/'docs/regression/Coupled6D/MaterialRoundoffContexts20261118.zip').read_bytes()
    assert sha256(baseline).hexdigest().upper()=='D3612530DD4E63751C5682F5B043939C662F59E642253A8BA337917824FB93C1'
    with ZipFile(BytesIO(baseline)) as archive:
        baseline_solver=archive.read('Cases/Final/src/Solver/CCoupledNewtonSolver.cls').decode('utf-8-sig').replace('\r\n','\n')
    for key in TestRead(root/'Cases.json'):
        folder=root/'Cases'/key
        record=shared['TestSourceComparison'](repo,root,folder,source,original,helper,body,reader)
        compiler=TestRead(folder/'docs/regression/CodeUpdate.json')
        for log in (folder/'Native').glob('*.txt'):
            text=log.read_text('utf-8-sig'); closure=TestRead(log.with_name(log.name+'.ProcessClosure.json'))
            owner=TestRead(log.with_name(log.name+'.Ownership.json'))
            assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['Closure']['FinalState']['State']=='Absent'
            identity=closure['Closure']['Identity']
            assert owner['PID']==identity['PID'] and int(owner['StartTicksUTC'])==identity['Ticks']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==compiler['WorkbookSHA256']
            assert 'SOURCE_UNCHANGED: True' in text and 'RUNTIME ERROR:' not in text
            totals=re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',text,re.M)
            assert len(totals)==1
            if key=='ShearFixed':
                assert totals==[('0','1')] and closure['ChildExitCode']==1
                assert len(re.findall(r'^SHEAR_CONTROL_ATTEMPT;\d+;True;',text,re.M))==4
            else:
                assert totals==[('1','0')] and closure['ChildExitCode']==0
            if key=='Direction':
                assert len(re.findall(r'^DIRECTION_RESIDUAL;',text,re.M))==28
                assert re.search(r'^CONTROL_PROBE;FirstBar4;False;',text,re.M)
            if key=='Damping':
                assert len(re.findall(r'^CONTROL_PROBE;[^;]+;True;',text,re.M))==1
                assert 'расширений диапазона демпфирования управляемого шага: 5' in text
            if key in ('Shear12','Shear32'):
                count=12 if key=='Shear12' else 32
                assert len(re.findall(r'^SHEAR_CONTROL_ATTEMPT;\d+;True;',text,re.M))==count
                assert f'SHEAR_CONTROL_SUMMARY;{count};' in text
            record['macro_seconds']=float(re.search(r'^CASE_FINISHED;[^;]+;[^;]+;([\d.E+-]+)',text,re.M)[1])
        safety=[json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB']>=6500 and row['freeCommitGiB']>=6 for row in safety)
        assert all(all(item['ProtectedUser'] for item in row['excel']) for row in safety)
        current=(folder/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
        if key.startswith('Shear'): assert current==baseline_solver
        if key=='Direction':
            current=current.replace('Private mTestCaptured As Boolean, mTestLambda As Double\nPrivate mTestField() As Double, mTestCorrection() As Double, mTestMatrix() As Double\n','')
            current=current.replace('    mTestCaptured = False\n','')
            current=current.replace('            mTestField = current: mTestCorrection = correction: mTestMatrix = mMatrix\n            mTestLambda = currentLambda: mTestCaptured = True\n','')
            marker="\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Копирует последнюю отвергнутую итерацию без признания её равновесием."
            assert current.count(marker)==1; current=current.split(marker)[0]
            assert current==baseline_solver
        records[key]=record
    failed=root/'FailedCompile'
    assert TestRead(failed/'CompileFailureClosure.json')['State']=='Absent'
    assert 'fraction >= STEEL_MIN_FRACTION' in (failed/'Compile.log').read_text('utf-8-sig')
    variants=TestRead(root/'Cases/Direction/CorrectionMethods.json'); arc=TestRead(root/'Cases/Direction/ActualArc.json')
    assert len(variants)==4 and all(not value['solved'] for value in variants.values())
    assert len(arc)==4 and all(not value['solved'] for value in arc.values())
    restored={}
    with TemporaryDirectory() as scratch:
        folder=root/'Cases/Shear32'; target=Path(scratch)/'Restored'; target.mkdir()
        prep=TestRead(folder/'Preparation.json')
        for relative,expected in prep['inputs'].items():
            raw=source if relative=='workbook/output/RC_Section_NDM.xlsm' else (folder/relative).read_bytes()
            file=target/relative; file.parent.mkdir(parents=True,exist_ok=True); file.write_bytes(raw)
            assert sha256(file.read_bytes()).hexdigest().upper()==expected
        (target/'Preparation.json').write_bytes((folder/'Preparation.json').read_bytes())
        for directory in ('Native','Temp','docs/regression'): (target/directory).mkdir(parents=True,exist_ok=True)
        (target/'docs/regression/Diagnostic.xlsm').write_bytes(source)
        assert sha256((target/'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper()==prep['source_book_sha256']
        restored={'inputs':len(prep['inputs']),'excel_started':False,'compiled_or_calculated_state_reused':False,
                  'preparation_restored':True,'clean_diagnostic_workbook_initialized':True}
    result={'cases':records,'clean_inputs_restoration':restored,'working_solver_changed':False,
            'physical_capacity_certified':False,'full_acceptance_completed':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('SHEAR BRANCH EXACT VBA, PRESERVED NEGATIVE CASES AND NATIVE SCOPES VERIFIED; CAPACITY OPEN')


def TestMechanics(repo,root,output):
    """Повторяет заблокированную итерацию и отдельные собственные сдвиговые истории, не смешивая их."""
    TestFiles(root); result={}
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        run_path(str(root/'Analyze-TestRejectedDirection.py'))['TestAnalyze'](repo,root/'Cases/Direction',scratch/'Direction.json')
        result['direction']=TestRead(scratch/'Direction.json')
        base=result['direction']['samples'][0]['full_norm_MPa']
        good=[row for row in result['direction']['samples'] if row['fraction']==1./512.]
        assert len(good)==1 and good[0]['full_norm_MPa']<base
        for key,expected in (('ShearFixed',4),('Shear12',12),('Shear32',32)):
            run_path(str(root/'Validate-TestShearControl.py'))['TestValidate'](repo,root/'Cases'/key,scratch/(key+'.json'))
            proof=TestRead(scratch/(key+'.json')); assert proof['new_states']==expected
            assert proof['declared_scope_completed']==(key!='ShearFixed')
            result[key]=proof
    result['physical_capacity_certified']=False
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('SHEAR BRANCH ALL SIX RESULTANTS, ACTUAL CONTROL AND SEPARATE MATERIAL HISTORIES VERIFIED; PHYSICAL LIMIT OPEN')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--scope',choices=('native','mechanics'),required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); (TestNative if args.scope=='native' else TestMechanics)(args.repo.resolve(),args.root.resolve(),args.out.resolve())
