"""ДЛЯ ТЕСТОВ: проверяет собственную псевдодугу без возврата к неразрешимой исходной мере."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestRun(repo,root,output):
    """Сохраняет все шесть нагрузок и материальную историю; меняется только параметризация ветви."""
    helper=run_path(str(Path(__file__).with_name('Solve-TestRejectedDirection.py')))
    section,history,*_=helper['TestRestore'](repo,root)
    rows=[line.split(';') for line in (root/'AcceptedHistory.csv').read_text().splitlines()]
    old,current=[np.asarray(row[3:],float) for row in rows[-2:]]
    old_lambda,current_lambda=[float(row[2])/75000. for row in rows[-2:]]
    delta=current-old; load_delta=current_lambda-old_lambda
    physical=len(current)-4; distance=np.linalg.norm(delta[:physical]); assert distance>0.
    weight=np.linalg.norm(current[:physical])/max(1.,abs(current_lambda))
    records={}
    for mode in ('secant','arc'):
        length=distance if mode=='secant' else np.sqrt(distance**2+(weight*load_delta)**2)
        projection=delta/length; projection[physical:]=0.
        load_projection=0. if mode=='secant' else weight**2*load_delta/length
        increment=float(projection@delta+load_projection*load_delta)
        for factor in (4.,32.):
            target=float(projection@current+load_projection*current_lambda+factor*increment)
            key=mode+str(int(factor))
            record=helper['TestSolve'](section,history,current+factor*delta,current_lambda+factor*load_delta,
                                       projection,target,'local',load_projection)
            record.update({'projection':projection.tolist(),'load_projection':float(load_projection),
                           'target_control':target,'factor':factor,'metric_weight':float(weight)})
            records[key]=record
            output.write_bytes((json.dumps(records,indent=2,sort_keys=True)+'\n').encode())
            print(key,record['solved'],record['Qy_N'],record['norm_MPa'],len(record['steps']),flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True); args=parser.parse_args(); TestRun(args.repo.resolve(),args.root.resolve(),args.out.resolve())
