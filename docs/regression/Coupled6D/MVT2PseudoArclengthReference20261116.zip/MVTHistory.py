"""Read the frozen H22-H24 path and independently compare secant metrics."""
import argparse
import csv
from hashlib import sha256
import json
from math import hypot, sqrt
from pathlib import Path
import sys


here = Path(__file__).resolve().parent


def direction(w, z):
    return tuple(y - x for x, y in zip(w, z, strict=True))


def cosine(x, y):
    return sum(a*b for a, b in zip(x, y, strict=True)) / hypot(*x) / hypot(*y)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence", type=Path, nargs="?", default=here.parent / "mvt-next/jetb")
    jet = parser.parse_args().evidence.resolve(strict=True)
    sys.path.insert(0, str(jet))
    import VerifyBase as v

    replay = jet / "Replay.csv"
    digest = sha256(replay.read_bytes()).hexdigest().upper()
    assert digest == "504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8"
    with replay.open(encoding="ascii", newline="") as lines:
        rows = list(csv.DictReader(lines, delimiter=";"))
    assert len(rows) == 24
    load_names = ("N_N", "Mx_Nmm", "My_Nmm", "T_Nmm", "Qx_N", "Qy_N")
    selected = {}
    for j, row in enumerate(rows[-3:], 22):
        q = [float(row[f"q{i}"]) for i in range(1, 61)]
        qy = float(row["lambda"])
        loads = [float(row[key]) for key in load_names]
        assert int(row["index"]) == j and float(row["offsetFraction"]) == 1.
        assert len(q) == 60 and hypot(*q) < 1.
        assert max(abs(x-y) for x, y in zip(loads, v.force(qy), strict=True)) <= 2e-9
        selected[j] = {"q": q, "qy_kN": qy, "loads_N_Nmm": loads}
    dq1 = direction(selected[22]["q"], selected[23]["q"])
    dq2 = direction(selected[23]["q"], selected[24]["q"])
    dload = selected[24]["qy_kN"] - selected[23]["qy_kN"]
    assert abs(dload - .8895275) <= 1e-12
    assert abs(selected[23]["qy_kN"] - selected[22]["qy_kN"] - dload) <= 1e-12
    native = jet / "JetNative.csv"
    assert v.digest(native) == "7CE6747FEE67165BB6642A710D10EA8F5471DFAF22893B7BEAB5AF58B67F276F"
    states, _ = v.verified_states(v.read_native(native))
    h24 = states["Base24"]
    assert h24 == states["Restored24"] and h24["field"] == tuple(selected[24]["q"])
    assert h24["q"] == selected[24]["qy_kN"]
    geo = h24["geometry"]
    total_weight = sum(area for _, _, area in geo.values())

    def strain_metric(q):
        values = []
        for (_, side), (x, y, area) in geo.items():
            block = v.operators(x, y)
            weight = sqrt(area / total_weight)
            values.extend(weight * strain / (1. if i < 3 else sqrt(2.))
                          for i, strain in enumerate(v.strain_at(q, block, side)))
        return tuple(values)

    physical = [strain_metric(x) for x in (dq1, dq2)]
    magnitudes = [hypot(*x) for x in physical]
    scale = magnitudes[-1] / dload
    combined = [(*x, scale * dload) for x in physical]
    norm = hypot(*combined[-1])
    # Explicit transpose of the weighted strain map, so all reactions get zero weight.
    q_normal = [v.dot(physical[-1], strain_metric(tuple(float(i == j) for i in range(60)))) / norm
                for j in range(60)]
    load_normal = scale * scale * dload / norm
    assert q_normal[56:] == [0.] * 4
    assert abs(v.dot(q_normal, dq2) + load_normal * dload - norm) <= 2e-20
    output = {"history_sha256": digest, "native_sha256": v.digest(native), "q_dimension": 60, "mechanical_dimension": 56,
              "integration_stations": len(geo), "accepted_points": selected, "exact_H24_restore": True,
              "raw_all60_cosine": cosine(dq1, dq2), "raw_first56_cosine": cosine(dq1[:56], dq2[:56]),
              "strain_metric_cosine": cosine(*physical), "weighted_augmented_cosine": cosine(*combined),
              "raw_gauge_norm_fraction": [hypot(*q[56:]) / hypot(*q) for q in (dq1, dq2)],
              "strain_norms": magnitudes, "strains_normalized_to_last_Qy_increment_per_kN": scale,
              "normal_q": q_normal, "normal_Qy_per_kN": load_normal, "last_secant_metric_norm": norm,
              "H24_native_norm_MPa": h24["norm_MPa"], "H24_native_tolerance_MPa": h24["tol_MPa"],
              "mvt_fold_identified": False}
    result = here / "MVTHistory.json"
    result.write_bytes((json.dumps(output, indent=2) + "\n").encode())
    control = here / "MVTNormal.csv"
    control.write_bytes((";".join(str(c) for c in (*q_normal, load_normal, norm)) + "\r\n").encode("ascii"))
    print(result)


if __name__ == "__main__":
    main()
