Continuation reference and MVT2 input check

Run with Python 3.10 or later and its standard library. To reproduce this
portable receipt, extract it into an isolated directory and run

    python -B -X utf8 VerifyPortable.py PATH/MVT2JointCenterGradientNative20261116.zip

The dependency is tracked under docs/regression/Coupled6D. Its exact history
and reconstruction code are loaded once from that archive. This receipt embeds
the later exact JetNative trace for the remeasured H24 anchor and restore.
The verifier runs both reports offline and checks the original SHA256 bytes.

For individual checks in a source directory:

    python -B -X utf8 Reference.py
    python -B -X utf8 MVTHistory.py

The history check takes an optional evidence directory containing the frozen
Replay.csv, JetNative.csv and VerifyBase.py from the MVT2 Jet stage.

The analytical spring system is the stationary point of
    V(x,y;lambda) = (y-g(x))^2/2 + x^2/2 - x^4/4 - lambda*x
    g(x) = x - 1.25*x^2.
At equilibrium y=g(x) and lambda=x-x^3. The Schur complement of the 2x2
displacement stiffness is 1-3*x^2. The first positive-loading loss of
positive definiteness therefore occurs at x=1/sqrt(3). All methods use the
same original residual tolerance, damping and two exact seed points.

The predictor is the normalized oriented secant. Pseudo-arclength freezes
this normal for the entire augmented Newton corrector and imposes
    p.dot(q - q_predictor) + k*(lambda-lambda_predictor) = 0.
The three scalar controls have fixed positive increments matched to the
projection of the same nominal step in the initial direction.
The reported residual excludes the supplementary control equation.
Operation counts compare different endpoint paths and are not wall times.

MVTNormal.csv contains the 60 normal coefficients p in archived q coordinates,
the load coefficient k per kN of Qy, and the norm of the last accepted secant.
The q metric is the area-weighted RMS Frobenius strain at 135 stations.
The load scale balances the last H23-to-H24 strain increment and Qy increment.
Gauge multipliers do not contribute to the metric or normal. They remain
unknowns of the mechanical augmented solve. For lambda=Qy/Qy_reference,
multiply the stored k by Qy_reference in kN.

The archive anchors are accepted and the last one is verified natively.
The analytical stiffness criterion does not determine an MVT2 concrete
limit. MVT2 needs actual additional accepted equilibria and a verified
physical limit criterion on its own history.
