"""Compare scalar and fixed-normal continuation on a smooth analytic fold."""
from dataclasses import asdict, dataclass
import json
from math import dist, fsum, hypot, sqrt
from pathlib import Path


TOL = 1e-12
STEP = .06
END_X = .90


def shape(x):
    return x - 1.25 * x * x


def load(x):
    return x - x**3


def exact(x):
    return x, shape(x), load(x)


def dot(a, b):
    return fsum(x * y for x, y in zip(a, b, strict=True))


def difference(a, b):
    return tuple(x - y for x, y in zip(a, b, strict=True))


def unit(values):
    return tuple(x / hypot(*values) for x in values)


def residual(z):
    x, y, lam = z
    g = shape(x)
    return load(x) + (g - y) * (1. - 2.5 * x) - lam, y - g


def augmented_jacobian(z, normal):
    x, y, _ = z
    gp = 1. - 2.5 * x
    return [(1. - 3. * x * x + gp * gp - 2.5 * (shape(x) - y), -gp, -1.),
            (-gp, 1., 0.),
            normal]


def pivot_solve(a, b):
    system = [list(row) + [rhs] for row, rhs in zip(a, b, strict=True)]
    for i in range(len(system)):
        j = max(range(i, len(system)), key=lambda k: abs(system[k][i]))
        if abs(system[j][i]) < 1e-13:
            return None
        system[i], system[j] = system[j], system[i]
        pivot = system[i][i]
        system[i] = [x / pivot for x in system[i]]
        for k, row in enumerate(system):
            if k != i:
                scale = row[i]
                system[k] = [x - scale*y for x, y in zip(row, system[i], strict=True)]
    return tuple(row[-1] for row in system)


@dataclass
class Counts:
    residual: int = 0
    jacobian: int = 0
    solve: int = 0
    rejected_damping: int = 0


def correct(predictor, previous, direction, normal, constraint, counts):
    """Freeze the normal for every corrector iteration and evaluate the original R."""
    def functions(z):
        counts.residual += 1
        return (*residual(z), dot(normal, z) - constraint)

    def norm(vector):
        return max(map(abs, vector))

    z = predictor
    values = functions(z)
    for _ in range(16):
        if norm(values) <= TOL:
            ds = difference(z, previous)
            if dot(ds, direction) > 0. and hypot(*ds) < 2. * STEP:
                return z
            return None
        counts.jacobian += 1
        counts.solve += 1
        correction = pivot_solve(augmented_jacobian(z, normal), tuple(-x for x in values))
        if correction is None:
            return None
        for reduction in range(9):
            weight = .5**reduction
            candidate = tuple(x + weight*dx for x, dx in zip(z, correction, strict=True))
            tested = functions(candidate)
            if norm(tested) < norm(values):
                z, values = candidate, tested
                break
            counts.rejected_damping += 1
        else:
            return None
    return None


def follow(coordinate):
    path = [exact(0.), exact(.04)]
    initial = unit(difference(path[1], path[0]))
    calls = Counts()
    attempted = 0
    failed_value = None
    status = "requested displacement reached"
    while path[-1][0] < END_X and attempted < 50:
        last, previous = path[-1], path[-2]
        direction = unit(difference(last, previous))
        predictor = tuple(x + STEP * dx for x, dx in zip(last, direction, strict=True))
        if coordinate is None:
            normal = direction
            target = dot(normal, predictor)
        else:
            normal = tuple(float(i == coordinate) for i in range(3))
            target = last[coordinate] + STEP * initial[coordinate]
        attempted += 1
        result = correct(predictor, last, direction, normal, target, calls)
        if result is None:
            status = "no local continued root for the next control target"
            failed_value = target
            break
        path.append(result)
    physical = [max(map(abs, residual(z))) for z in path]  # Independent of solver call counts.
    branch_error = [dist(z, exact(z[0])) for z in path]
    assert max(physical) <= TOL and max(branch_error) <= 2. * TOL
    stable_x = 1. / sqrt(3.)
    stable_bracket = next(([a, b] for a, b in zip(path, path[1:]) if a[0] < stable_x < b[0]), None)
    flips = [any(a[i] > b[i] for a, b in zip(path, path[1:])) for i in (0, 1, 2)]
    return {"status": status, "target_on_first_failed_step": failed_value, "attempted_steps": attempted,
            "accepted_steps": len(path) - 2, "residual_max_original": max(physical), "exact_curve_max_error": max(branch_error),
            "counts": asdict(calls), "numerical_peak_load": max(x[2] for x in path), "last_xyz": path[-1],
            "control_reversals_occurred_x_y_lambda": flips, "stable_fold_bracket": stable_bracket, "path": path}


def run():
    systems = {name: follow(coordinate) for name, coordinate in (("Load", 2), ("DisplacementY", 1),
               ("DisplacementX", 0), ("PseudoArclength", None))}
    stable_x = 1. / sqrt(3.)
    exact_peak = 2. / (3. * sqrt(3.))
    assert systems["Load"]["target_on_first_failed_step"] > exact_peak
    assert systems["DisplacementY"]["target_on_first_failed_step"] > shape(.4)
    for method in ("DisplacementX", "PseudoArclength"):
        result = systems[method]
        assert result["last_xyz"][0] > END_X and result["stable_fold_bracket"] is not None
        assert result["control_reversals_occurred_x_y_lambda"] == [False, True, True]
        assert result["numerical_peak_load"] < exact_peak
    return {"convention": "dimensionless fixed normal in x,y,lambda", "tolerance": TOL, "nominal_step": STEP,
            "exact_first_loss_of_positive_definite_stiffness": exact(stable_x),
            "exact_displacement_control_peak": exact(.4), "results": systems}


if __name__ == "__main__":
    output = Path(__file__).resolve().parent / "Reference.json"
    output.write_bytes((json.dumps(run(), indent=2) + "\n").encode())
    print(output)
