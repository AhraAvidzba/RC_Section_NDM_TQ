"""Replay and compare the analytic reference and the frozen MVT input report."""
import argparse
from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import subprocess
import sys
import tempfile
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
TRACKED = "47B975208823EF5563F76CB759F4FAED557529D0BCEA90CE4F503BCC1BE2029C"
FROZEN = {
    "Reference.py": "2B800E0B671F20A39D2BB3EA0699E08C48F1411C4996023D01CDF696F23FD3D9",
    "MVTHistory.py": "34269DEDEAE62FBDD713D36A2B074622B5C113A56106A0B88D86C793B57F1D6E",
    "Reference.json": "E0C790878C3B99001372330B380C651616A29E8EBF9914F28C04F2D94F6F8731",
    "MVTHistory.json": "BCF342375610108EE54AB9B4E9B3BA89602D4183F4A5B7800A9F87DFEC6FA97F",
    "MVTNormal.csv": "97626F4FC7D9F97DD0667F9388B712D6960F94AB3453F0A6DF2563611BB82A6F",
    "JetNative.csv": "7CE6747FEE67165BB6642A710D10EA8F5471DFAF22893B7BEAB5AF58B67F276F",
}
DEPENDENCIES = {
    "Replay.csv": "504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8",
    "VerifyBase.py": "C416F562CBD73E1277085C1B0013D586AA1337E8D96A95B0FD6598C054BCFA5C",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("joint_archive", type=Path, help="tracked MVT2JointCenterGradientNative20261116.zip")
    args = parser.parse_args()
    assert digest(args.joint_archive.read_bytes()) == TRACKED
    for name, expected in FROZEN.items():
        assert digest((ROOT / name).read_bytes()) == expected, name
    with tempfile.TemporaryDirectory() as directory:
        target = Path(directory)
        for name in ("Reference.py", "MVTHistory.py", "JetNative.csv"):
            copyfile(ROOT / name, target / name)
        with ZipFile(args.joint_archive) as pending:
            for name, expected in DEPENDENCIES.items():
                archived = pending.read(name)
                assert digest(archived) == expected, name
                (target / name).write_bytes(archived)
        for tool, parameters in (("Reference.py", ()), ("MVTHistory.py", (str(target),))):
            subprocess.run([sys.executable, "-B", "-X", "utf8", str(target / tool), *parameters],
                           cwd=target, check=True, capture_output=True)
        for name in ("Reference.json", "MVTHistory.json", "MVTNormal.csv"):
            calculated = digest((target / name).read_bytes())
            assert calculated == FROZEN[name], name
            print("REPLAY PASS", name, calculated)


if __name__ == "__main__":
    run()
