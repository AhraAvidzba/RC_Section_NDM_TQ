"""Freeze paired native witnesses for the stale direct steel screening factor."""

from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from subprocess import check_output


HERE = Path(__file__).resolve().parent
DSI = HERE.parent / "dsi"
CORRECTED = HERE.parent / "dsl"
REPO = HERE.parents[1]
SOLVER = "src/Solver/CCoupledNewtonSolver.cls"
TEST = "tests/modTestCoupledElasticState.bas"
FAKE = "tests/CTestCoupledPointResponse.cls"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
BASE_FAKE = "f4741ae638f3c17bc19b39e02d177698c247bd86"
GIT_FAKE_SHA = "2386B252E1C6C79587D47D314CF1D970473C87BB997D30801488F42CC8615EA1"
FAKE_SHA = "A4DDA93E2DF69D0F8B6E3F0EDB0E78EE7780A9A87A6187ECA902359418624982"
DSI_SHA = "988715E00C30D2306F01E11B9149244D903C7CE75721114F134DA0CECA2F933F"
CORRECTED_SHA = "2A091D6AEE33AF66E02D78BD466C02EF0E945A78609653358F66E402E66A99A9"


def digest(data):
    return sha256(data).hexdigest().upper()


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    copyfile(source, target)


def decode(data):
    return data.decode("utf-8").replace("\r\n", "\n")


def once(text, expected, replacement):
    assert text.count(expected) == 1, expected
    return text.replace(expected, replacement)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((value.rstrip() + "\n").replace("\n", "\r\n").encode("utf-8"))


def main():
    fixture = DSI / "Fixture.json"
    assert digest(fixture.read_bytes()) == DSI_SHA
    base = json.loads(fixture.read_bytes())
    corrected = (CORRECTED / SOLVER).read_bytes()
    assert digest(corrected) == CORRECTED_SHA
    original_fake = check_output(["git", "show", f"{BASE_FAKE}:{FAKE}"], cwd=REPO)
    assert digest(original_fake) == GIT_FAKE_SHA
    assert digest(original_fake.replace(b"\n", b"\r\n")) == FAKE_SHA
    assert digest((REPO / BOOK).read_bytes()) == base["workbook_sha256"]
    relevant = [name for name in base["frozen"] if name.startswith(("src/", "tools/"))]
    relevant.extend((BOOK, TEST, "Guard-IsolatedOffice.ps1"))
    for lane in ("Old", "Corrected"):
        lane_root = HERE / lane
        assert not (lane_root / "Fixture.json").exists()
        for name in relevant:
            assert digest((DSI / name).read_bytes()) == base["frozen"][name]
            copy(DSI / name, lane_root / name)
        exact = corrected if lane == "Corrected" else (DSI / SOLVER).read_bytes()
        diagnostic = (HERE / "CacheTest.txt").read_text(encoding="utf-8").strip()
        if lane == "Corrected":
            diagnostic = once(diagnostic, " = mDirectProofFactor", " = False")
        write(lane_root / SOLVER, decode(exact).rstrip() + "\n\n" + diagnostic)
        copy(HERE / "Verify.py", lane_root / "Verify.py")
        write(lane_root / TEST, (DSI / TEST).read_text(encoding="utf-8").rstrip() + "\n\n" +
              (HERE / "DirectTest.txt").read_text(encoding="utf-8").strip())
        fake = decode(original_fake)
        field = "Private mFrozenAxialTail As Double"
        fake = once(fake, field, field + "\nPrivate mStaleSteelTransition As Double")
        reset = "    mFrozenAxialTail = 0#"
        fake = once(fake, reset, reset + "\n    mStaleSteelTransition = 0#")
        branch = "    If mTwinPeaks Then\n        TestTwinPeakStress e, stress(3), tangent(3, 3)"
        fake = once(fake, branch,
                    "    If mStaleSteelTransition > 0# Then\n"
                    "        TestStaleSteelFactorStress e, stress(3), tangent(3, 3)\n"
                    "    ElseIf mTwinPeaks Then\n        TestTwinPeakStress e, stress(3), tangent(3, 3)")
        write(lane_root / FAKE, fake.rstrip() + "\n\n" + (HERE / "ConstitutiveTest.txt").read_text(encoding="utf-8").strip())
        copy(lane_root / BOOK, lane_root / "docs/regression/Diagnostic.xlsm")
        for folder in ("Native", "Temp"):
            (lane_root / folder).mkdir(exist_ok=True)
        items = (*relevant, FAKE, "Verify.py")
        receipt = {
            "lane": lane,
            "workbook_sha256": base["workbook_sha256"],
            "tested_production_solver_sha256": digest(exact),
            "fake_base_sha256": FAKE_SHA,
            "base_dsi_fixture_sha256": DSI_SHA,
            "modules": sorted((*base["modules"], Path(FAKE).stem)),
            "frozen": {name: digest((lane_root / name).read_bytes()) for name in items},
        }
        path = lane_root / "Fixture.json"
        path.write_bytes((json.dumps(receipt, indent=2) + "\n").encode("utf-8"))
        print(lane, digest(path.read_bytes()), "runtime", digest(exact))


if __name__ == "__main__":
    main()
