"""Replay the paired stale-factor reports and check the exact VBA inputs."""

from hashlib import sha256
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory

import Stage


HERE = Path(__file__).resolve().parent
LANES = {
    "Old": ("69A2CDFD24BDF75C6CD0D22C6D3A5DF30425C4B545BE79C4B7D9A7EE39CB7070", 1,
            "5CAD6D4E4498168D5212803AA0EA4B1BC2C164B2DA12B962D53158D457D6E0B9"),
    "Corrected": ("D2A2DDA5C21D5C65BE21CDE9D89806D3D3A325ADAF72D86457EB8F1344488328", 0,
                  "72A775D1B2449EE3BB9A6EE6E3E47230FE7D76E47B7D4C618BE9F85A888E9935"),
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_bytes())


def code(text):
    return (text.rstrip() + "\n").replace("\n", "\r\n").encode("utf-8")


def verify_sources(lane, fixture):
    target = HERE / lane
    dsi = read(HERE / "Baseline/Fixture.json")
    assert digest(HERE / "Baseline/Fixture.json") == fixture["base_dsi_fixture_sha256"] == Stage.DSI_SHA
    assert fixture["lane"] == lane and fixture["workbook_sha256"] == dsi["workbook_sha256"]
    assert fixture["modules"] == sorted((*dsi["modules"], Path(Stage.FAKE).stem))
    for name, expected in fixture["frozen"].items():
        if name == Stage.BOOK:
            assert expected == fixture["workbook_sha256"]
            continue
        path = target / name
        assert digest(path if path.exists() else HERE / name) == expected, name
        if name in dsi["frozen"] and name not in (Stage.SOLVER, Stage.TEST):
            assert dsi["frozen"][name] == expected
    solver = (target / "ExactRuntime.cls").read_bytes()
    assert Stage.digest(solver) == fixture["tested_production_solver_sha256"]
    expected = dsi["frozen"][Stage.SOLVER] if lane == "Old" else Stage.CORRECTED_SHA
    assert Stage.digest(solver) == expected
    diagnostic = (HERE / "CacheTest.txt").read_text(encoding="utf-8").strip()
    if lane == "Corrected":
        diagnostic = Stage.once(diagnostic, " = mDirectProofFactor", " = False")
    assert code(Stage.decode(solver).rstrip() + "\n\n" + diagnostic) == (target / Stage.SOLVER).read_bytes()
    dsi_test = HERE / "Baseline" / Stage.TEST
    assert digest(dsi_test) == dsi["frozen"][Stage.TEST]
    direct = dsi_test.read_text(encoding="utf-8").rstrip() + "\n\n" + (HERE / "DirectTest.txt").read_text(encoding="utf-8").strip()
    assert code(direct) == (target / Stage.TEST).read_bytes()
    previous = (HERE / "Baseline" / Stage.FAKE).read_bytes()
    assert Stage.digest(previous) == Stage.GIT_FAKE_SHA
    assert Stage.digest(previous.replace(b"\n", b"\r\n")) == Stage.FAKE_SHA == fixture["fake_base_sha256"]
    fake = Stage.decode(previous)
    field = "Private mFrozenAxialTail As Double"
    fake = Stage.once(fake, field, field + "\nPrivate mStaleSteelTransition As Double")
    reset = "    mFrozenAxialTail = 0#"
    fake = Stage.once(fake, reset, reset + "\n    mStaleSteelTransition = 0#")
    old = "    If mTwinPeaks Then\n        TestTwinPeakStress e, stress(3), tangent(3, 3)"
    fake = Stage.once(fake, old, "    If mStaleSteelTransition > 0# Then\n"
                      "        TestStaleSteelFactorStress e, stress(3), tangent(3, 3)\n"
                      "    ElseIf mTwinPeaks Then\n        TestTwinPeakStress e, stress(3), tangent(3, 3)")
    fake = fake.rstrip() + "\n\n" + (HERE / "ConstitutiveTest.txt").read_text(encoding="utf-8").strip()
    assert code(fake) == (target / Stage.FAKE).read_bytes()


def verify_native(lane, fixture, exit_code, raw_sha):
    root = HERE / lane
    compiler = read(root / "CompileClosure.json")
    receipt = read(root / "docs/regression/CodeUpdate.json")
    compiled = receipt["WorkbookSHA256"]
    assert receipt["Compiled"] and not receipt["ProductionChanged"]
    assert receipt["ProductionSHA256"] == fixture["workbook_sha256"]
    assert sorted(receipt["Modules"]) == fixture["modules"]
    log = (root / "Compile.log").read_text(encoding="utf-8-sig")
    pid, ticks = re.search(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", log, re.M).groups()
    assert compiler["State"] == "Absent" and (str(compiler["PID"]), compiler["StartTicksUTC"]) == (pid, ticks)
    directory = root / "Native"
    report = directory / "Stale.txt"
    raw = report.read_text(encoding="utf-8-sig")
    assert digest(report) == raw_sha
    assert re.search(r"^SOURCE_SHA256: " + compiled + "$", raw, re.M)
    assert f"WATCHDOG_COMPLETED: exit={exit_code}; source unchanged=True" in raw
    owner = read(directory / "Stale.txt.Ownership.json")
    assert owner["SourceSHA256"] == compiled and owner["BeforeWorkbookOpen"] and owner["VerifiedNewOwner"]
    pid, ticks = re.search(r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$", raw, re.M).groups()
    closure = read(directory / "Stale.txt.ProcessClosure.json")
    assert closure["Passed"] and closure["ChildExitCode"] == exit_code and closure["ChildHasExited"]
    final = closure["Closure"]["FinalState"]
    assert final["State"] == "Absent"
    assert (str(final["PID"]), final["StartTicksUTC"]) == (str(owner["PID"]), owner["StartTicksUTC"]) == (pid, ticks)
    with TemporaryDirectory(prefix="stale-proof-") as folder:
        target = Path(folder)
        for name in ("Stale.txt", "Stale.txt.ProcessClosure.json", "Exit.json"):
            copyfile(directory / name, target / name)
        check_output([sys.executable, "-B", "-X", "utf8", str(HERE / "Verify.py"), lane, str(target / report.name)])
        result = read(target / "Stale.Verification.json")
    assert result == read(directory / "Stale.Verification.json")
    print("PASS STALE ARCHIVE", lane, raw_sha, result["analytic_fixed_torque_capacity_factor"])


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions")
    for name, expected in read(HERE / "SHA256SUMS.json").items():
        assert digest(HERE / name) == expected
    for lane, (fixture_sha, exit_code, native_sha) in LANES.items():
        path = HERE / lane / "Fixture.json"
        assert digest(path) == fixture_sha
        fixture = read(path)
        verify_sources(lane, fixture)
        verify_native(lane, fixture, exit_code, native_sha)


if __name__ == "__main__":
    main()
