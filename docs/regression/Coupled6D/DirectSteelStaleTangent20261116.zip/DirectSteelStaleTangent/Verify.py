"""Verify axial equilibrium, torsion-preserving load-path capacity and the stale screen."""

from decimal import Decimal as D, getcontext
from hashlib import sha256
import json
from pathlib import Path
import sys


def main(lane, report):
    getcontext().prec = 45
    path = Path(report)
    raw = path.read_text(encoding="utf-8-sig")
    assert "SOURCE_UNCHANGED: True" in raw
    result = {"Old": (4, 2, 1), "Corrected": (6, 0, 0)}
    passed, failed, exit_code = result[lane]
    assert f"TOTAL_STALE_DIRECT_FACTOR: passed={passed}; failed={failed}" in raw
    native = json.loads(path.with_name("Exit.json").read_bytes())
    closure = json.loads(path.with_suffix(".txt.ProcessClosure.json").read_bytes())
    assert native == {"lane": lane, "exit_code": exit_code}
    assert closure["Passed"] and closure["ChildExitCode"] == exit_code
    assert closure["Closure"]["FinalState"]["State"] == "Absent"

    seed = D(".00099")
    high, low = D(30000), D(300)
    delta = D(".00004")
    kink = seed + D(".8") * delta / high
    provisional = seed + delta / high
    limit = provisional + D(".000000004")
    exact = kink + (delta - high * (kink - seed)) / low
    target = (high * seed + delta) * D(21500) + D(10000)
    limit_load = (high * kink + low * (limit - kink)) * D(21500) + D(10000)
    factor = limit_load / target
    moment = D(300000)
    norm = (high * seed + delta - high * kink - low * (provisional - kink)) * D(21500) / D(21600)
    assert D(0) < provisional < limit < exact and D(0) < factor < D(1)
    ref = [line.split(";")[1:] for line in raw.splitlines() if line.startswith("STALE_FACTOR;")]
    assert [D(row[0]) for row in ref] == [-1, 1]
    for signed, cache, provisional_raw, provisional_u, residual, final_raw, final_u, final_residual, unknown, lambda_raw, limit_residual in ref:
        assert cache == ("1" if lane == "Old" else "0") and unknown == "0"
        assert abs(D(provisional_raw) * D(signed) - provisional) < D("1e-13")
        assert abs(D(provisional_u) - provisional / limit) < D("1e-10")
        assert D(provisional_u) < 1 and abs(D(residual) - norm) < D("1e-9")
        assert abs(D(lambda_raw) - factor) < D("1e-10") and D(limit_residual) < D("1e-9")
        if lane == "Old":
            assert D(final_raw) == D(provisional_raw) and D(final_u) == D(provisional_u) and D(final_residual) == D(residual)
        else:
            assert abs(D(final_raw) * D(signed) - exact) < D("1e-12") and D(final_u) > 1
            assert abs(D(final_u) - exact / limit) < D("1e-9") and D(final_residual) < D("1e-9")
    proof = {
        "lane": lane,
        "report_sha256": sha256(path.read_bytes()).hexdigest().upper(),
        "target_axial_force_N_absolute": str(target),
        "fixed_torsion_Nmm": str(moment),
        "analytic_provisional_strain_absolute": str(provisional),
        "steel_limit_strain_absolute": str(limit),
        "analytic_target_strain_absolute": str(exact),
        "analytic_limit_axial_force_N_absolute": str(limit_load),
        "analytic_fixed_torque_capacity_factor": str(factor),
        "analytic_provisional_force_residual_MPa": str(norm),
        "native_rows": ref,
    }
    path.with_suffix(".Verification.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
    print("PASS STALE FACTOR", lane, proof["report_sha256"], "capacity", factor)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
