#If VBA7 Then
Public Declare PtrSafe Function HardPerfCounterTest Lib "kernel32" Alias "QueryPerformanceCounter" (ByRef ticks As Currency) As Long
Private Declare PtrSafe Function HardPerfFrequencyTest Lib "kernel32" Alias "QueryPerformanceFrequency" (ByRef ticks As Currency) As Long
#Else
Public Declare Function HardPerfCounterTest Lib "kernel32" Alias "QueryPerformanceCounter" (ByRef ticks As Currency) As Long
Private Declare Function HardPerfFrequencyTest Lib "kernel32" Alias "QueryPerformanceFrequency" (ByRef ticks As Currency) As Long
#End If
Private mHardPerfTicksTest(0 To 13) As Currency
Private mHardPerfCountTest(0 To 13) As Long

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает интервал монотонного счётчика для указанного участка диагностической сборки.
Public Sub HardPerfFinishTest(ByVal slot As Long, ByVal started As Currency)
    Dim finished As Currency
    HardPerfCounterTest finished
    mHardPerfTicksTest(slot) = mHardPerfTicksTest(slot) + finished - started
    mHardPerfCountTest(slot) = mHardPerfCountTest(slot) + 1
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запускает штатный замер HardShear в копии с временными счётчиками.
Public Function RunTestHardShearProfile() As String
    Dim frequency As Currency, entered As Currency, finished As Currency
    If HardPerfFrequencyTest(frequency) = 0 Or frequency <= 0@ Then Err.Raise 5, , "Недоступен монотонный счётчик."
    Erase mHardPerfTicksTest: Erase mHardPerfCountTest
    HardPerfCounterTest entered
    Dim report As String: report = RunTestCoupledWorkbookTiming("Both", "Excel")
    HardPerfCounterTest finished
    report = report & vbCrLf & "PROFILE: outer;1;" & Str$((finished - entered) / frequency)

    Dim labels As Variant
    labels = Array("eq_matrix", "eq_residual", "responses_matrix", "responses_residual", _
        "base_full", "base_axial", "base_stress", "base_branch", "base_refined", _
        "tangent_full", "tangent_axial", "tangent_stress", "tangent_branch", "tangent_refined")
    Dim slot As Long
    For slot = 0 To UBound(labels)
        report = report & vbCrLf & "PROFILE: " & labels(slot) & ";" & CStr(mHardPerfCountTest(slot)) & _
            ";" & Str$(mHardPerfTicksTest(slot) / frequency)
    Next slot
    RunTestHardShearProfile = report
End Function
