"""Verify the unchanged HardShear work and derive non-overlapping profiling totals."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
LABELS = {'outer', 'eq_matrix', 'eq_residual', 'responses_matrix', 'responses_residual',
          'base_full', 'base_axial', 'base_stress', 'base_branch', 'base_refined',
          'tangent_full', 'tangent_axial', 'tangent_stress', 'tangent_branch', 'tangent_refined'}


def digest(path):
    return sha256((ROOT/path).read_bytes()).hexdigest().upper()


def read(path):
    return (ROOT/path).read_text(encoding='utf-8-sig')


def line(text, prefix):
    rows = [current for current in text.splitlines() if current.startswith(prefix)]
    assert len(rows) == 1, prefix
    return rows[0]


def verify_inputs(plan):
    assert all(digest(name) == expected for name, expected in plan['inputs'].items())
    if (ROOT/plan['workbook']).exists():
        assert digest(plan['workbook']) == plan['source_workbook_sha256']


def verify_run(plan):
    stock, native = read('Stock/Both.txt'), read('Native/Report.txt')
    assert line(stock,'SOURCE_SHA256: ') == 'SOURCE_SHA256: ' + plan['source_workbook_sha256']
    for prefix in ('TIMING_STATES:', 'TIMING_LIMIT_REASON:', 'TOTAL_COUPLED_WORKBOOK_TIMING:'):
        assert line(stock,prefix) == line(native,prefix)
    assert line(native,'TOTAL_COUPLED_WORKBOOK_TIMING:') == 'TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0'
    assert [row for row in stock.splitlines() if row.startswith('OK: ')] == [row for row in native.splitlines() if row.startswith('OK: ')]
    for report in (stock,native):
        before, after = re.search(r'^RESULTS_SAVE_REOPEN: before=([\dA-F]{64}); after=([\dA-F]{64}); equal=True;',report,re.M).groups()
        assert before == after
        assert line(report,'SOURCE_UNCHANGED:') == 'SOURCE_UNCHANGED: True'
    compiled = json.loads(read('docs/regression/CodeUpdate.json'))
    closure = json.loads(read('CompileClosure.json'))
    assert compiled['Compiled'] and not compiled['ProductionChanged'] and closure['State'] == 'Absent'
    assert sorted(compiled['Modules']) == sorted(plan['modules'])
    assert line(native,'SOURCE_SHA256: ') == 'SOURCE_SHA256: ' + compiled['WorkbookSHA256']
    for path in ('Stock/Both.Execution.txt','Native/Execution.txt'):
        trace = [row for row in read(path).splitlines() if '| Мера деформации:' in row]
        assert len(trace)==1
        trace = trace[0].split('] ',1)[1]
        if path.startswith('Stock'):
            baseline_trace = trace
        else:
            assert trace == baseline_trace
    ticks = {label: {'calls': int(count), 'seconds':float(duration.strip())}
             for label, count, duration in re.findall(r'^PROFILE: (\w+);(\d+);([^\n]+)', native, re.M)}
    assert ticks.keys() == LABELS and all(item['seconds'] >= 0 for item in ticks.values())
    total = {label: sum(item['seconds'] for name,item in ticks.items() if name.startswith(prefix))
             for label,prefix in [('equations','eq_'),('responses','responses_'),('base_concrete','base_'),('nonlinear_tangent','tangent_')]}
    assert 0 < total['base_concrete'] + total['nonlinear_tangent'] <= total['responses'] <= total['equations'] <= ticks['outer']['seconds']
    total.update({'outside_equations':ticks['outer']['seconds']-total['equations'],
                  'equations_without_point_response':total['equations']-total['responses'],
                  'others_inside_point_response':total['responses']-total['base_concrete']-total['nonlinear_tangent']})
    return {'status':'PASS','stock_report_sha256':digest('Stock/Both.txt'),'report_sha256':digest('Native/Report.txt'),
            'timing_measurements':ticks,'combined_seconds':total,'limits_and_signed_forces_identical':True,
            'scope':'nested wall times inside one matched run, including timing instrumentation overhead'}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', action='store_true')
    parser.add_argument('--stdout', action='store_true')
    args = parser.parse_args()
    plan = json.loads(read('Fixture.json'))
    verify_inputs(plan)
    if args.inputs:
        print('HARDSHEAR_PROFILE_INPUTS: PASS')
    else:
        data = json.dumps(verify_run(plan), indent=2) + '\n'
        if not args.stdout:
            (ROOT/'Native/Verification.json').write_text(data, encoding='utf-8')
        print(data,end='')
