"""Prepare candidate source and unchanged native controls in a private workbook."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
STORAGE=Path('D:/CodexScratch/RC_Section_NDM_TQ')
STOCK=STORAGE/'HardStockNow'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'
CONTINUATION='src/Solver/CCoupledDeformationContinuation.cls'
TEST='tests/modTestCoupledElasticState.bas'
BOOK='workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA='245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'


def source(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def digest(raw):
    return sha256(raw).hexdigest().upper()


def one(code,past,new):
    assert code.count(past)==1, past
    return code.replace(past,new)


def solver(code):
    marker="' Возвращает новую линейную меру только для подтверждённой пробы восстановления."
    code=one(code,marker,source((HERE/'Solver.bas').read_bytes()).rstrip()+'\n\n'+marker)
    return one(code,'    If IsMissing(initialField) Then','    If IsMissing(initialField) Or IsEmpty(initialField) Then')


def continuation(code):
    edits=(
        ('Private mPostPeakWidePoints As Long\n',
         'Private mPostPeakWidePoints As Long\n'
         'Private mStrainControlActive As Boolean, mStrainControlPoints As Long\n'
         'Private mStrainControlCoefficients() As Double\n'),
        ('    mPostPeakWidePoints = 0\n',
         '    mPostPeakWidePoints = 0\n'
         '    mStrainControlActive = False: mStrainControlPoints = 0: Erase mStrainControlCoefficients\n'),
        ('    Dim targetCoordinate As Double\n',
         '    Dim targetCoordinate As Double, probeLambda As Double, seed As Variant\n'),
        ('            If Not TryChangePostPeakControl(history, left, current, nominal, increment, minimum, lastNoProgress) Then Exit For\n',
         '            If Not TryChangePostPeakControl(history, left, current, nominal, increment, minimum, lastNoProgress) Then\n'
         '                If Not TryChangePostPeakControl(history, left, current, nominal, increment, minimum, lastNoProgress, True) Then Exit For\n'
         '            End If\n'
         '        ElseIf mProbeCount >= PROBE_LIMIT - 6 And (lastProbeFailed Or lastNoProgress) Then\n'
         '            TryChangePostPeakControl history, left, current, nominal, increment, minimum, lastNoProgress, True\n'),
        ('        probed = Probe(trial, current.Lambda, mYieldRecoveryProbes < YIELD_RECOVERY_LIMIT And Not mFollowingLocalPeak, _\n'
         '            arcFields:=arcFields)',
         '        probeLambda = current.Lambda: seed = Empty\n'
         '        If mStrainControlActive Then StrainSecantPredictor history, left, current, targetCoordinate, seed, probeLambda\n'
         '        probed = Probe(trial, probeLambda, mYieldRecoveryProbes < YIELD_RECOVERY_LIMIT And Not mFollowingLocalPeak, _\n'
         '            arcFields:=arcFields, initialField:=seed)'),
        ('            lastNoProgress = Not probed\n',
         '            If probed And mStrainControlActive Then\n'
         '                probed = mSolver.IsLocalStrainSecantTrial(mStrainControlCoefficients, mProjection, increment)\n'
         '                If Not probed Then mSolver.DiscardStep\n'
         '            End If\n'
         '            lastNoProgress = Not probed\n'),
        ('                If mPostPeakControlPoints = 0 Then mControlName = mPostPeakControlName\n',
         '                If mPostPeakControlPoints = 0 Or mStrainControlActive Then mControlName = mPostPeakControlName\n'
         '                If mStrainControlActive Then mStrainControlPoints = mStrainControlPoints + 1\n'),
        ("' Один раз выбирает другую меру, если после подтверждённого спада\n"
         "' численная проба потребовала шаг ниже минимального. Сохраняет принятое\n"
         "' поле, историю и одностороннюю материальную касательную.",
         "' Меняет меру после подтверждённого спада и численной остановки.\n"
         "' Обе меры сохраняют принятое поле, историю и материальные законы."),
        ('        ByVal stalledOnCoordinate As Boolean) As Boolean\n'
         '    If Len(mPostPeakControlName) > 0 Or Not mFollowingLocalPeak Or Not mUsesYieldControl Then Exit Function',
         '        ByVal stalledOnCoordinate As Boolean, Optional ByVal useStrainSecant As Boolean = False) As Boolean\n'
         '    If Not mFollowingLocalPeak Or Not mUsesYieldControl Then Exit Function\n'
         '    If useStrainSecant Then\n'
         '        If mStrainControlActive Or mPostPeakControlPoints = 0 Then Exit Function\n'
         '    ElseIf Len(mPostPeakControlName) > 0 Then\n'
         '        Exit Function\n'
         '    End If'),
        ('    If Not mSolver.SelectDeformationControl(previous, currentField, alternate, currentCoordinate, currentSpacing, name) Then Exit Function',
         '    If useStrainSecant Then\n'
         '        If Not mSolver.SelectStrainSecantControl(previous, currentField, alternate, mStrainControlCoefficients, currentCoordinate) Then Exit Function\n'
         '        name = "проекция по тензору деформаций"\n'
         '    Else\n'
         '        If Not mSolver.SelectDeformationControl(previous, currentField, alternate, currentCoordinate, currentSpacing, name) Then Exit Function\n'
         '    End If'),
        ('    nominal = spacing: increment = 0.5 * spacing: minimum = increment * MIN_STEP_RATIO\n',
         '    nominal = spacing: increment = 0.5 * spacing\n'
         '    If useStrainSecant Then\n'
         '        mStrainControlActive = True\n'
         '        increment = 0.125 * (currentCoordinate - previousCoordinate)\n'
         '    End If\n'
         '    minimum = increment * MIN_STEP_RATIO\n'),
        ('        Optional ByVal arcFields As Collection = Nothing) As Boolean\n',
         '        Optional ByVal arcFields As Collection = Nothing, Optional ByRef initialField As Variant) As Boolean\n'),
        ('recoverSameControl = keepYieldControl And mUsesYieldControl And mFixedYieldRecoveryProbes < FIXED_YIELD_RECOVERY_LIMIT',
         'recoverSameControl = keepYieldControl And mUsesYieldControl And Not mStrainControlActive And _\n'
         '        mFixedYieldRecoveryProbes < FIXED_YIELD_RECOVERY_LIMIT'),
        ('        point.Lambda, mAbsTol, mRelTol, mMaxIterations, recoverYieldControl, mUsesYieldControl, recoverSameControl)',
         '        point.Lambda, mAbsTol, mRelTol, mMaxIterations, recoverYieldControl, mUsesYieldControl, recoverSameControl, initialField)'),
        ('        "; принято полей после максимума в новой мере: " & CStr(mPostPeakControlPoints)',
         '        "; принято полей после максимума в новой мере: " & CStr(mPostPeakControlPoints)\n'
         '    If mStrainControlActive Then Details = Details & "; принято полей по тензорной мере: " & CStr(mStrainControlPoints)'),
    )
    for earlier,change in edits:
        code=one(code,earlier,change)
    marker="' Сравнивает приращения на двух соседних шагах одной нисходящей ветви."
    return one(code,marker,source((HERE/'Continuation.bas').read_bytes()).rstrip()+'\n\n'+marker)


def test(code):
    return code.rstrip()+'''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет HardShear и основные маршруты деформационного продолжения.
Public Function RunTestHardPhysicalControlCandidate() As String
    Dim report As String
    report = RunTestCoupledWorkbookTiming("Both", "Excel") & vbCrLf
    report = report & RunTestCoupledDeformationControl() & vbCrLf
    RunTestHardPhysicalControlCandidate = report & RunTestCoupledDeformationSteelCrossing()
End Function
'''


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,required=True)
    args=cli.parse_args()
    folder=args.destination.resolve()
    assert folder.is_relative_to(STORAGE.resolve()) and folder!=STORAGE.resolve()
    plan=json.loads((STOCK/'Fixture.json').read_bytes())
    stock=(REPO/BOOK).read_bytes()
    assert plan['book_sha256']==digest(stock)==BOOK_SHA
    files={name:(STOCK/name).read_bytes() for name in plan['inputs'] if name.startswith(('tools/','Guard-'))}
    assert all(digest(raw)==plan['inputs'][name] for name,raw in files.items())
    conversions={SOLVER:solver,CONTINUATION:continuation,TEST:test}
    source_hash={}
    for name,convert in conversions.items():
        original=(REPO/name).read_bytes()
        source_hash[name]=digest(original)
        result=convert(source(original))
        assert max(map(len,result.splitlines()))<1024
        files[name]=result.replace('\n','\r\n').encode()
    for name in ('Both.txt','Both.Execution.txt'):
        files['Stock/'+name]=(STOCK/'Native'/name).read_bytes()
    for name in ('Stage.py','Solver.bas','Continuation.bas','Verify.py'):
        files[name]=(HERE/name).read_bytes()
    runner=(HERE.parent/'hs-perf/Run.ps1').read_text(encoding='utf-8')
    runner=runner.replace('RunTestHardShearProfile','RunTestHardPhysicalControlCandidate').replace('HardShearProfile','HardPhysicalControl')
    runner=runner.replace('TimeoutSeconds 170','TimeoutSeconds 220')
    files['Run.ps1']=runner.encode()
    manifest={'workbook':BOOK,'source_workbook_sha256':BOOK_SHA,'original_sources':source_hash,
              'modules':[Path(name).stem for name in conversions], 'inputs':{name:digest(raw) for name,raw in files.items()}}
    folder.mkdir()
    for name in ('Temp','Native'):
        (folder/name).mkdir()
    files.update({BOOK:stock,'docs/regression/Diagnostic.xlsm':stock,'Fixture.json':(json.dumps(manifest,indent=2)+'\n').encode()})
    for name,data in files.items():
        path=folder/name
        path.parent.mkdir(exist_ok=True,parents=True)
        with path.open('xb') as stream:
            stream.write(data)
    print('HARDSHEAR PHYSICAL CONTROL INPUTS',digest(files['Fixture.json']))


if __name__=='__main__':
    main()
