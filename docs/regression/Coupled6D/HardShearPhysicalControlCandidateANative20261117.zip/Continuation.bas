' Готовит прогноз по двум последним полям в выбранной физической мере.
' Множители связей остаются равными последнему принятому полю.
Private Sub StrainSecantPredictor(ByVal history As Collection, ByRef left As TBranchPoint, _
        ByRef current As TBranchPoint, ByVal target As Double, ByRef seed As Variant, ByRef lambda As Double)
    If left.HistoryIndex <> current.HistoryIndex - 1 Then Exit Sub
    Dim spacing As Double: spacing = current.Coordinate - left.Coordinate
    If spacing <= 0# Then Exit Sub
    Dim ratio As Double: ratio = (target - current.Coordinate) / spacing
    If ratio <= 0# Or ratio > 2# Then Exit Sub
    Dim previous() As Double, predicted() As Double, i As Long
    previous = history(left.HistoryIndex): predicted = history(current.HistoryIndex)
    For i = 1 To mSolver.PhysicalDegreeCount
        predicted(i) = predicted(i) + ratio * (predicted(i) - previous(i))
    Next i
    seed = predicted
    lambda = current.Lambda + ratio * (current.Lambda - left.Lambda)
End Sub
