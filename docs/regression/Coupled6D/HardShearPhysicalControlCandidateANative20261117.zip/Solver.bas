' Строит линейную меру по секущей в тензорной норме деформаций.
' Вызывается на принятой истории. Множители связей не входят в метрику.
Friend Function SelectStrainSecantControl(ByRef previous() As Double, ByRef current() As Double, _
        ByRef projection() As Double, ByRef coefficients() As Double, ByRef coordinate As Double) As Boolean
    If Not mUseSpatialHistory Then Exit Function
    If LBound(previous) <> 1 Or UBound(previous) <> mDegreeCount Or _
            LBound(current) <> 1 Or UBound(current) <> mDegreeCount Then Exit Function
    Dim movement() As Double, i As Long, length As Double
    ReDim movement(1 To mDegreeCount)
    For i = 1 To mDegreeCount
        If current(i) <> mAccepted(i) Then Exit Function
        If i < mGaugeStart Then movement(i) = current(i) - previous(i)
    Next i
    mSection.CopySpatialStrainCoefficients SPATIAL_HALF_STEP, coefficients
    length = Sqr(ArcPhysicalSquare(coefficients, movement, projection, True))
    If length <= 0# Then Exit Function
    coordinate = 0#
    For i = 1 To mGaugeStart - 1
        projection(i) = projection(i) / length
        coordinate = coordinate + projection(i) * current(i)
    Next i
    SelectStrainSecantControl = True
End Function

' Сверяет фактические знак и размер равновесного шага в физической мере.
Friend Function IsLocalStrainSecantTrial(ByRef coefficients() As Double, ByRef projection() As Double, _
        ByVal increment As Double) As Boolean
    If Not mCandidateReady Or increment <= 0# Then Exit Function
    Dim i As Long, projectedStep As Double
    For i = 1 To mGaugeStart - 1
        projectedStep = projectedStep + projection(i) * (mCandidate(i) - mAccepted(i))
    Next i
    If Abs(projectedStep - increment) > 0.125 * increment Then Exit Function
    IsLocalStrainSecantTrial = ArcFieldIsLocal(coefficients, projection, 0#, 0#, increment, mCandidate, 0#, mTrialLambda)
End Function
