"""Seal the private native reports and re-run their offline checks from the sealed archive."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('root', type=Path)
    cli.add_argument('archive', type=Path)
    cli.add_argument('--candidate', action='store_true')
    options = cli.parse_args()
    root = options.root.resolve()
    plan = json.loads((root/'Fixture.json').read_bytes())
    files = {name:(root/name).read_bytes() for name in plan['inputs']}
    assert all(sha256(data).hexdigest().upper() == plan['inputs'][name] for name,data in files.items())
    required = ('Fixture.json','Compile.log','CompileClosure.json','Run.ndjson','docs/regression/CodeUpdate.json',
                'Native/Report.txt','Native/Execution.txt','Native/Report.txt.Ownership.json',
                'Native/Report.txt.ProcessClosure.json','Native/Report.txt.RunnerCleanup.json','Native/Report.txt.memory.json')
    files.update({name:(root/name).read_bytes() for name in required})
    if options.candidate:
        verifier = 'Verify.py'
        flags = []
        files['Native/Verification.json'] = (root/'Native/Verification.json').read_bytes()
    else:
        verifier = 'Verify-Portable.py'
        flags = ['--stdout']
        files[verifier] = (HERE/'Verify.py').read_bytes()
    files['Pack.py'] = (HERE/'Pack.py').read_bytes()
    files['README.md'] = (
        '# Проверка HardShear в изолированной копии Excel\n\n'
        'В архиве сохранены манифест, изменённые модули, нативные квитанции, отчёт расчёта и исходный контроль. '
        'Автономная сверка проверяет материалы запуска и совпадение шести усилий, статусов и диагностических счётчиков.\n\n'
        f'После распаковки выполните `python -B -X utf8 {verifier} {" ".join(flags)}`. '
        'Сверка не запускает Excel. Исходная книга имеет SHA-256 `' + plan['source_workbook_sha256'] + '`.\n'
    ).encode()
    destination = options.archive.resolve()
    destination.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(destination, 'x', compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name,data in sorted(files.items()):
            archive.writestr(name,data)
    with TemporaryDirectory(prefix='hardperf-check-',dir=HERE) as scratch, ZipFile(destination) as archive:
        archive.extractall(scratch)
        root = Path(scratch)
        result = subprocess.check_output([sys.executable,'-B','-X','utf8',str(root/verifier),*flags],cwd=root,text=True,encoding='utf-8')
        if options.candidate:
            assert (root/'Native/Verification.json').read_bytes() == files['Native/Verification.json']
            print(result.strip())
        else:
            verification = json.loads(result)
            print(verification['status'],verification['combined_seconds'])
    print(destination,sha256(destination.read_bytes()).hexdigest().upper())


if __name__ == '__main__':
    main()
