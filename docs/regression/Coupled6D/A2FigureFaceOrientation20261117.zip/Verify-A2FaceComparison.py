"""Сопоставляет сохранённые векторы карты трещин и расчётные деформации A2."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import atan, degrees, radians, tan
from pathlib import Path
from runpy import run_path
from statistics import mean


HERE = Path(__file__).resolve().parent
VECTORS_SHA = '97AC8049694F3DE1416F221547A9B408074393951C1DE8F4FD39C1CCA42C2442'
TORQUE_TARGETS = (239.4, 247.1, 254.8)


def limits(values):
    """Возвращает нижнюю и верхнюю границу выбранных данных."""
    return [min(values), max(values)]


def angle_after_rescaling(angles, ratio):
    """Находит средний угол при изменении отношения вертикального масштаба к продольному."""
    return mean(degrees(atan(ratio * tan(radians(angle)))) for angle in angles)


def compare(figure, mechanics):
    """Сохраняет наблюдения по каждой грани и явную неполноту сравнения."""
    states = mechanics['accepted_kinematics']
    first = states[:5]
    model = {}
    picture = {}
    fractions = (.95, 1., 1.05)
    for face in ('left','upper','right'):
        data = figure['top' if face == 'upper' else face]
        angles = [row['angle_deg'][1] for row in data['curves'] if row['class'] == 'retained']
        picture[face] = {'number_visible_traces': len(angles), 'mean_raw_degrees': mean(angles),
                         'range_raw_degrees': limits(angles), 'mean_over_three_windows_degrees': data['mean_by_window_deg'],
                         'mean_over_three_assumed_scale_ratios_degrees': [angle_after_rescaling(angles,f) for f in fractions]}
        mid = [s['outer_midface'][face]['strain_normal_trace_degrees'] for s in first]
        band = [p for s in first for p in s['outer_central_150mm'][face]]
        model[face] = {'midface_degrees': limits(mid),
                       'central_150mm_degrees': limits([p['strain_normal_trace_degrees'] for p in band]),
                       'minimum_eigenvalue_gap': min(p['principal_strain_separation'] for p in band),
                       'minimum_tensile_eigenvalue': min(p['max_in_plane_strain'] for p in band),
                       'midface_at_later_local_peak_degrees': states[-1]['outer_midface'][face]['strain_normal_trace_degrees']}
    differences = [left - right for left, right in zip(picture['left']['mean_over_three_assumed_scale_ratios_degrees'],
                    picture['right']['mean_over_three_assumed_scale_ratios_degrees'], strict=True)]
    assert min(differences) > 5.7 and max(differences) < 6.1
    model_differences = [s['outer_midface']['left']['strain_normal_trace_degrees']
                         - s['outer_midface']['right']['strain_normal_trace_degrees'] for s in states]
    assert max(map(abs, model_differences)) < 3e-8
    assert min(item['minimum_eigenvalue_gap'] for item in model.values()) > .009
    assert 47. < figure['pooled_means_if_vertical_to_axial_unit_ratio_varies']['0.95'] < 47.6 < figure['pooled_mean_deg'] < 49.
    brackets = {moment: [a['accepted_index'], b['accepted_index']] for a, b in zip(first, first[1:])
                for moment in TORQUE_TARGETS if a['torque_kNm'] <= moment <= b['torque_kNm']}
    assert brackets == {239.4:[39,40],247.1:[41,42],254.8:[42,43]}
    return {'published_pooled_degrees': 47.6, 'digitized_pooled_degrees': figure['pooled_mean_deg'],
            'assumed_axis_ratio': fractions, 'left_right_difference_at_each_ratio_degrees': differences,
            'figure': picture, 'model': model, 'accepted_brackets_around_measured_torque': brackets,
            'published_cracks_longitudinal_registration_available': False,
            'physical_limit_established': False}


def main(repo):
    """Повторяет вычисления по закреплённым архивам и проверенному PDF."""
    figure = run_path(str(HERE / 'Read-A2CrackFigure.py'))
    mechanics = run_path(str(HERE / 'A2FaceMechanics.py'))
    pdf = repo / 'literature/Coupled6D/Lopes-Bernardo-2014-TorsionFailure.pdf'
    if pdf.exists():
        assert sha256(pdf.read_bytes()).hexdigest().upper() == figure['PDF_SHA']
    vector_data = (HERE / 'A2Fig15Vectors.json').read_bytes()
    assert sha256(vector_data).hexdigest().upper() == VECTORS_SHA
    loaded = {int(key): val for key,val in json.loads(vector_data).items()}
    observations = figure['measure'](loaded)
    model = mechanics['main'](repo)
    return {'literature_sha256': figure['PDF_SHA'], 'figure_vectors_sha256': VECTORS_SHA,
            'summary': compare(observations,model), 'all_figure_traces': observations, 'all_model_fields': model}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--report', type=Path, required=True)
    arguments = parser.parse_args()
    report = main(arguments.repo.resolve())
    with arguments.report.open('x', encoding='utf-8', newline='\n') as out:
        json.dump(report, out, indent=2, sort_keys=True, allow_nan=False)
        out.write('\n')
    print('A2 FACE CRACK DIRECTION CONTROL OFFLINE PASS')
