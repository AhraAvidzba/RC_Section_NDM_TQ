"""Read the visible A2 crack traces in Fig. 15 of Lopes and Bernardo (2014).

Use numbered vector chains from the exploratory endpoint-joining pass.
The output contains the trial chains as well as the retained angles.
All coordinates are PDF points from the top-left of printed page 174.
"""
from argparse import ArgumentParser
from hashlib import sha256
from json import dumps, loads
from math import atan, atan2, degrees, hypot, radians, tan
from pathlib import Path
from statistics import mean, median

PDF_SHA = "C5ACB30732F7EBA9300798173B94CA0AE47FF60F569935A2D7F1C55F707313A1"
PDF = Path(__file__).resolve().parents[2] / "literature/Coupled6D/Lopes-Bernardo-2014-TorsionFailure.pdf"
FACES = (
    ("left", 421.19000, 453.41589,
     ((27,), (31,), (33,), (38,), (49,), (56,), (44,), (45,), (48,), (62,), (64,), (77,))),
    ("top", 474.89999, 507.12488,
     ((460, 497), (461, 501), (422, 470), (425, 471), (439, 482), (453, 493))),
    ("right", 528.60999, 560.85889,
     ((1032,), (1014, 1091), (1024, 1095), (1045, 1110), (1050, 1116), (1077, 1130))),
)
WINDOWS = (2.5, 4.0, 6.0)


def curve_point(points, t):
    if len(points) == 2:
        return tuple((1 - t) * a + t * b for a, b in zip(*points))
    return tuple((1 - t)**3 * a + 3 * t * (1 - t)**2 * b + 3 * t**2 * (1 - t) * c + t**3 * d
                 for a, b, c, d in zip(*points))


def segments(path, close):
    result = []
    for kind, *points in path["items"]:
        if kind not in ("l", "c"):
            return []
        subdivisions = 1 if kind == "l" else 28
        sampled = [curve_point(points, index / subdivisions) for index in range(subdivisions + 1)]
        result.extend(zip(sampled, sampled[1:]))
    if close and result and result[0][0] != result[-1][1]:
        result.append((result[-1][1], result[0][0]))
    return result


def crossing(wire, y):
    return [a[0] + (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1])
            for a, b in wire if min(a[1], b[1]) <= y < max(a[1], b[1])]


def in_spall(fills, x, y):
    for rect, edges in fills:
        left, top, right, bottom = rect
        if top <= y < bottom and left - 0.30 <= x <= right + 0.30:
            xs = sorted(crossing(edges, y))
            if len(xs) >= 2 and xs[0] - 0.30 <= x <= xs[-1] + 0.30:
                return True
    return False


def joined_gap(source):
    if len(source) == 1:
        return 0.0
    assert len(source) == 2
    ends = [(path["items"][0][1], path["items"][-1][-1]) for path in source]
    return min(hypot(a[0] - b[0], a[1] - b[1]) for a in ends[0] for b in ends[1])


def face(paths, low, high, sequence):
    middle = 0.5 * (low + high)
    fills = [(p["rect"], segments(p, True)) for p in paths.values()
             if p.get("fill") and max(p["fill"]) < 0.30
             and 124.29 <= p["rect"][0] <= p["rect"][2] <= 282.33
             and low - 0.04 <= p["rect"][1] <= p["rect"][3] <= high + 0.04]
    records = []
    for chain in sequence:
        source = [paths[index] for index in chain]
        assert all(p["type"] == "s" and abs(p["width"] - 0.4) < 0.01 for p in source)
        gap = joined_gap(source)
        assert gap <= 0.012
        wire = [item for path in source for item in segments(path, False)]
        height = (max(p["rect"][3] for p in source) - min(p["rect"][1] for p in source)) / (high - low)
        center, = crossing(wire, middle)
        hits = [index / 2 for index in range(-12, 13) for x in crossing(wire, middle + index / 2)
                if in_spall(fills, x, middle + index / 2)]
        angles = []
        for window in WINDOWS:
            x0, = crossing(wire, middle - window)
            x1, = crossing(wire, middle + window)
            assert x1 > x0
            angles.append(degrees(atan2(2 * window, x1 - x0)))
        reason = "spall edge" if hits else "short" if height < 0.65 else "retained"
        records.append({"seq": chain, "x_mid": center, "span_fraction": height,
                        "angle_deg": angles, "join_gap_pt": gap, "spall_hit_y_offsets": hits, "class": reason})
    retained = [record for record in records if record["class"] == "retained"]
    return {"middle_y": middle, "curves": records, "count": len(retained),
            "mean_by_window_deg": [mean(row["angle_deg"][j] for row in retained) for j in range(3)],
            "median_midwindow_deg": median(row["angle_deg"][1] for row in retained),
            "range_midwindow_deg": [f(row["angle_deg"][1] for row in retained) for f in (min, max)]}


def extract_vectors(path):
    """Сохраняет координаты выбранных векторных объектов в переносимом виде."""
    import fitz

    assert sha256(path.read_bytes()).hexdigest().upper() == PDF_SHA
    selection = {index for _, _, _, table in FACES for seq in table for index in seq}
    with fitz.open(path) as pdf:
        records = pdf[11].get_drawings()
    paths = {}
    for item in records:
        left, top, right, bottom = rect = list(item["rect"])
        fill = item.get("fill")
        dark = fill and max(fill) < .30 and 124.29 <= left <= right <= 282.33
        include_fill = dark and any(low - .04 <= top <= bottom <= high + .04 for _, low, high, _ in FACES)
        if item['seqno'] in selection or include_fill:
            paths[item['seqno']] = {"rect": rect, "type": item["type"], "width": item["width"], "fill": fill,
                                    "items": [[key, *[list(p) for p in points]] if key in ('l','c') else [key]
                                              for key, *points in item['items']]}
    return paths


def measure(paths):
    """Восстанавливает углы в трёх окнах по неизменным наборам линий."""
    result = {name: face(paths, low, high, sequence) for name, low, high, sequence in FACES}
    assert [result[name]["count"] for name in result] == [8, 5, 5]
    observed = [row["angle_deg"][1] for f in result.values() for row in f["curves"] if row["class"] == "retained"]
    result["pooled_mean_deg"] = mean(observed)
    result["pooled_means_if_vertical_to_axial_unit_ratio_varies"] = {
        str(ratio): mean(degrees(atan(ratio * tan(radians(angle)))) for angle in observed)
        for ratio in (0.95, 1.0, 1.05)
    }
    return result


def main():
    """Читает PDF или независимо повторяет измерение по сохранённым векторам."""
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", type=Path, default=PDF)
    parser.add_argument("--vectors", type=Path)
    parser.add_argument("--write-vectors", type=Path)
    args = parser.parse_args()
    assert sha256(args.pdf.read_bytes()).hexdigest().upper() == PDF_SHA
    if args.vectors:
        paths = {int(k): v for k,v in loads(args.vectors.read_bytes()).items()}
    else:
        paths = extract_vectors(args.pdf)
    if args.write_vectors:
        with args.write_vectors.open('x', encoding='utf-8', newline='\n') as sink:
            sink.write(dumps(paths, separators=(',', ':'), sort_keys=True))
    print(dumps(measure(paths), indent=2))


if __name__ == "__main__":
    main()
