"""Восстанавливает направление главного растяжения на гранях опытного сечения A2."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import atan2, degrees, fsum, hypot
from pathlib import Path
from zipfile import ZipFile


ARCHIVE = 'A2BPostAnchorNativePortable.zip'
ARCHIVE_SHA = 'D3DF2D73D31B4E2C423C02609F2D3D452E3A2DA38055D2EBB2C9E0ED508041E1'
EXACT = 'A2LaneABExactNative20261116.zip'
EXACT_SHA = 'CA2C750095DBB1F3DB62D5CC2EE046638E86D79D8CADCD3EF821EFF8DD31AF53'
TENSORS = 'A2FieldSeedPairPortable.zip'
TENSORS_SHA = '229FC672AEC273083B544C7B8B47234C28EB1D7037CEDE905B7073A90B01E49D'
LENGTH = 407.293505963451
OUTER = 300.
PROFILES = {'lower': (0, -1), 'right': (1, 0), 'upper': (0, 1), 'left': (-1, 0)}


def open_archive(repo, name, digest):
    """Открывает только архив указанной контрольной суммы."""
    path = repo / 'docs/regression/Coupled6D' / name
    assert sha256(path.read_bytes()).hexdigest().upper() == digest
    return ZipFile(path)


def read_table(packet, filename):
    """Читает строки исходного протокола VBA."""
    return [line.split(';') for line in packet.read(filename).decode('cp1251').splitlines()]


def bernstein(coordinate):
    """Возвращает кубический базис на одном интервале и производную по мм."""
    t = (coordinate + OUTER) / (2 * OUTER)
    s = 1. - t
    assert 0. <= t <= 1.
    return (s**3, 3 * t * s**2, 3 * t**2 * s, t**3), tuple(3. * val / (2 * OUTER)
             for val in (-s**2, s**2 - 2*t*s, 2*t*s - t**2, t**2))


def strain(x, y, field, station=0):
    """Вычисляет инженерные деформации в центральном сечении, включая поверхность."""
    bx, dx = bernstein(x)
    by, dy = bernstein(y)
    plane = [field[i] + station * .001 * field[52 + i] for i in range(4)]
    result = [[], [], [plane[0], y / LENGTH * plane[1], x / LENGTH * plane[2]], [],
              [-y / LENGTH * plane[3]], [x / LENGTH * plane[3]]]
    for j in range(4):
        for i in range(4):
            u, v, w = field[4 + 3 * (4*j+i):7 + 3 * (4*j+i)]
            gx, gy = LENGTH * dx[i] * by[j], LENGTH * bx[i] * dy[j]
            for destination, terms in zip(result, ((gx*u,), (gy*v,), (), (gy*u, gx*v), (gx*w,), (gy*w,)), strict=True):
                destination.extend(terms)
    return list(map(fsum, result))


def angle(axial, lateral, engineering_shear):
    """Возвращает острый угол следа, ортогонального главному растяжению в плоскости."""
    return 90. - .5 * abs(degrees(atan2(engineering_shear, axial - lateral)))


def profile(field, distance, coordinate, normal):
    """Берёт две нормальные и одну инженерную сдвиговую компоненту вдоль грани."""
    nx, ny = normal
    x, y = distance * nx + abs(ny)*coordinate, distance * ny + abs(nx)*coordinate
    xx, yy, zz, _, xz, yz = strain(x, y, field)
    lateral, shear = (yy, yz) if nx else (xx, xz)
    gap = hypot(zz - lateral, shear)
    return {'xy_mm': [x,y], 'axial': zz, 'in_plane_transverse': lateral, 'engineering_shear': shear,
            'principal_strain_separation': gap, 'max_in_plane_strain': (zz + lateral + gap) / 2.,
            'strain_normal_trace_degrees': angle(zz, lateral, shear)}


def stored_fields(packet):
    """Читает 43 принятых поля с 60 коэффициентами и проверяет масштаб закручивания."""
    rows = read_table(packet, 'B43.csv')
    assert rows[0] == ['43', '0.001', 'B'] and len(rows) == 44
    fields = {}
    for point, row in enumerate(rows[1:], 1):
        assert int(row[0]) == point and len(row) == 68
        field = list(map(float, row[8:]))
        twist = float(row[1])
        assert abs(field[3] * 1000. / LENGTH - twist) < 3e-16
        fields[point] = (float(row[5])/1e6, twist, field)
    return fields


def accepted_post_points(packet):
    """Берёт сохранённые поля после 43-й точки для проверки деформации стали."""
    raw = [row for row in read_table(packet, 'Native/B-Post.csv') if row[0] == 'FIELD']
    selected = {}
    for entry in raw:
        point = int(entry[1])
        field = list(map(float, entry[-60:]))
        twist = float(entry[4])
        assert abs(field[3] * 1000. / LENGTH - twist) < 4e-16
        selected[point] = (float(entry[13])/1e6, twist, field)
    return selected


def check_native_kinematics(repo):
    """Сверяет независимый базис на трёх станциях каждой из 88 нативных точек."""
    with open_archive(repo, TENSORS, TENSORS_SHA) as packet:
        rows = read_table(packet, 'Native/A2FieldSeedPair.csv')
    coords = {int(row[1]): list(map(float, row[2:4])) for row in rows if row[0] == 'GEOMETRY'}
    fields = {row[1]: list(map(float, row[2:])) for row in rows if row[0] == 'RIGHT'}
    assert set(fields) == {'DefaultCurrent', 'FieldSecant'} and len(coords) == 88
    result = {}
    for name, field in fields.items():
        samples = {(int(r[2]), int(r[3])): list(map(float, r[7:13])) for r in rows if r[:2] == ['BRANCH',name]}
        assert len(field) == 60 and len(samples) == 264
        errors = [abs(a-b) for (station, point), vector in samples.items()
                  for a, b in zip(strain(*coords[point], field, station), vector, strict=True)]
        error = max(errors)
        assert len(errors) == 1584 and error < 3e-17
        result[name] = {'components_checked': len(errors), 'max_error': error}
    return result


def exact_stress_directions(packet):
    """Берёт ортогональ к главному растяжению по напряжениям в центрах бетонных ячеек."""
    report = {}
    for lane in ('A', 'B'):
        rows = read_table(packet, f'Native/{lane}-1-Exact.csv')
        anchors = {r[1]: float(r[2]) for r in rows if r[0] == 'ANCHOR'}
        ranges = {moment: {} for moment in anchors.values()}
        for r in rows:
            if r[0] != 'POINT' or r[2] not in ('5','27','30','52'):
                continue
            x, y = map(float,r[4:6])
            face = ('right' if x > 0 else 'left') if abs(x) > abs(y) else ('upper' if y > 0 else 'lower')
            xx, yy, zz, _, xz, yz = map(float,r[11:17])
            t, shear = (yy,yz) if face in ('left', 'right') else (xx,xz)
            alpha = angle(zz, t, 2. * shear)
            ranges[anchors[r[1]]][face] = alpha
        assert all(set(group) == set(PROFILES) for group in ranges.values())
        report[lane] = ranges
    return report


def main(repo):
    """Измеряет поверхностную ориентацию на непрерывном сохранённом участке расчёта."""
    with open_archive(repo, ARCHIVE, ARCHIVE_SHA) as packet:
        accepted = stored_fields(packet)
        post = accepted_post_points(packet)
        profile_indices = (39,40,41,42,43)
        path = [accepted[index][0] for index in profile_indices]
        assert all(a < b for a, b in zip(path, path[1:])) and path[0] < 239.4 < 247.1 < 254.8 < path[-1]
    result = []
    for index in (*profile_indices, 51):
        torque, twist, field = (accepted if index < 44 else post)[index]
        result.append({'accepted_index': index, 'torque_kNm': torque, 'twist_coefficient_rad_m': twist,
                       'outer_midface': {face: profile(field, OUTER, 0., normal) for face, normal in PROFILES.items()},
                       'outer_central_150mm': {face: [profile(field, OUTER, coordinate, normal) for coordinate in range(-75,76,15)]
                                                  for face, normal in PROFILES.items()},
                       'outer_row_center': {face: profile(field, 266.666666666667, 0., normal)
                                            for face, normal in PROFILES.items()}})
    with open_archive(repo, EXACT, EXACT_SHA) as exact:
        stress = exact_stress_directions(exact)
    return {'accepted_kinematics': result, 'exact_target_cell_stress_angles': stress,
            'archive_native_kinematics_check': check_native_kinematics(repo),
            'physical_limit_established': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--report', type=Path, required=True)
    arguments = parser.parse_args()
    result = main(arguments.repo.resolve())
    with arguments.report.open('x', encoding='utf-8', newline='\n') as out:
        json.dump(result, out, indent=2, sort_keys=True, allow_nan=False)
        out.write('\n')
    print('A2 ACCEPTED FACE FIELD VERIFIED')
