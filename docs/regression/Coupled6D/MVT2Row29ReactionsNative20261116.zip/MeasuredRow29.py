"""Independently replay full fixed-history native actions and bound their affine reuse."""
import argparse
import csv
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from scipy.optimize import linprog

from ArchiveDirections import (
    AREA, LENGTH, MODULUS, PREFIX, QY, SCALES, diff, digest, loading, operators, parse,
    load_traces, reconstruct, select_states, strain_at, tensor_radius,
)
from hashlib import sha256


EXTRA = {
    "349": ("MVT2Step3Native20261116.zip","FDCB0C512B54989A19793F0A1B449ADB743779C406AA1A6A49972C6E5E789CB7"),
    "354": ("MVT2PureTwistNative20261116.zip","4920B773CAF518ABDC3B7B553472C66B815E1E203C6FAF8A6577916C01F87962"),
    "361": ("MVT2MixedRobustNative20261116.zip","4B2A9123F9080B8FEE4914541CEBF0FF34E8A8044799DE25DD545019B0A6F1B1"),
}
TAU = 5e-7*(1+max(map(abs,loading(QY))))
RADIUS = 1.e-8
ROUND_OFF = 8e-10


def input_states(evidence):
    traces, hashes = load_traces(evidence)
    for label, (name, expected) in EXTRA.items():
        path = evidence / name
        assert digest(path) == expected, path
        with ZipFile(path) as archive:
            assert sha256(archive.read("Replay.csv")).hexdigest().upper() == PREFIX
            raw = archive.read("Native/MVT2.csv")
        traces[label] = parse(raw)
        hashes[label] = sha256(raw).hexdigest().upper()
    states = {key+":"+label: state for key, trace in traces.items() for label, state in select_states(trace).items()}
    return states, hashes


def response(state):
    r, actual, err = reconstruct(state["field"],QY,state["stress_rows"])
    return np.r_[r[:56],np.array(state["six_N_Nmm"])/SCALES,MODULUS*np.array(r[-4:])]


def station_components(dq, geometry):
    return np.array([value for (_,side),(x,y,_) in geometry.items()
                     for value in strain_at(dq,operators(x,y),side)])


def row29_decomposition(state):
    station = state["stress_rows"]
    q = state["field"]
    parts = []
    for j in range(1,46):
        x,y,area = station[j,0][:3]
        cols,shape,_,yn = operators(x,y)
        ex,ey = (coef for _,coef in cols[28])
        b = shape[8]
        w = area/AREA
        sx = station[j,0][13]
        sxy = station[j,0][16]
        sxz_z = (station[j,1][17]-station[j,-1][17])/.002
        gauge = w*b*(q[56]-yn*q[59]) if j<=25 else 0.
        part = (w*ex*sx,w*ey*sxy,-w*b*sxz_z,gauge)
        parts.append((j,x,y,part))
    sums = np.sum([part for _,_,_,part in parts],axis=0)
    assert abs(sum(sums)-response(state)[28])<4e-10
    return {
        "in_plane_normal_MPa":sums[0],"in_plane_shear_MPa":sums[1],
        "longitudinal_shear_gradient_MPa":sums[2],"gauge_reactions_MPa":sums[3],
        "largest_station_terms":[{"point":j,"x_mm":x,"y_mm":y,"terms_MPa":part,"sum_MPa":sum(part)}
                                 for j,x,y,part in sorted(parts,key=lambda x:abs(sum(x[-1])),reverse=True)[:6]],
    }


def reaction_basis(geometry):
    result = np.zeros((66,4))
    for j in range(1,26):
        x,y,area = geometry[j,0]
        _,shape,xn,yn = operators(x,y)
        for node,b in enumerate(shape):
            u = 4+3*node
            for axis in range(3):
                result[u+axis,axis] += area/AREA*b
            result[u,3] -= area/AREA*b*yn
            result[u+1,3] += area/AREA*b*xn
    return result


def solve_lp(items, r, caps, reactions=None):
    n = len(items)
    names, d_r, d_q, d_e, radii = zip(*items) if items else ((),(),(),(),())
    scale = 1e5
    action = np.array(d_r).T*scale if n else np.zeros((r.size,0))
    strain = np.array(d_e).T/RADIUS if n else np.zeros((135*6,0))
    hull = np.ones((1,n))
    if reactions is not None:
        # Multipliers are coordinate reactions. They enter weak rows exactly
        # linearly and leave point strains, full centre forces and gauges fixed.
        action = np.c_[action,reactions]
        strain = np.c_[strain,np.zeros((strain.shape[0],4))]
        hull = np.c_[hull,np.zeros((1,4))]
    effort = action[56:62]
    g = np.vstack([action,-action,effort,-effort,hull,strain,-strain])
    auxiliary = np.r_[-np.ones(2*r.size),np.zeros(2*caps.size+1+2*strain.shape[0])]
    u = np.r_[-r*scale,r*scale,(caps-r[56:62])*scale,(caps+r[56:62])*scale,
              1,np.ones(2*strain.shape[0])]
    c = np.r_[np.zeros(g.shape[1]),1]
    model = np.c_[g,auxiliary]
    bounds = [(0,None)]*n+([(None,None)]*4 if reactions is not None else [])+[(0,None)]
    solution = linprog(c,A_ub=model,b_ub=u,bounds=bounds,method="highs",
                       options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
    assert solution.success, solution.message
    x = solution.x[:n]
    slack = np.max(model@solution.x-u)
    dual_obj = float(u@solution.ineqlin.marginals)
    reduced = c-model.T@solution.ineqlin.marginals
    dual_min = float(min(reduced))
    assert slack<1e-8 and dual_min>=-1e-8 and abs(dual_obj-solution.fun)<1e-8
    if reactions is not None:
        assert max(abs(reduced[n:n+4])) < 1e-8
    result = r+action@solution.x[:-1]/scale
    deformation = strain@solution.x[:-1]*RADIUS
    dq = np.array(d_q).T @ x if n else np.zeros(60)
    if reactions is not None:
        dq[56:60] += solution.x[n:n+4]/scale
    norm = float(np.max(np.abs(result)))
    return {
        "endpoint_count":n,"maximum_endpoint_radius":max(radii,default=0.),"norm_MPa":norm,
        "gain_MPa":float(np.max(np.abs(r))-norm),"gain_over_tau":float((np.max(np.abs(r))-norm)/TAU),
        "maximum_physical_component_strain":float(max(abs(deformation))),
        "active_weights":{name:float(w) for name,w in zip(names,x,strict=True) if abs(w)>1e-10},
        "largest_weak_rows":[(int(i)+1,float(result[i])) for i in np.argsort(-np.abs(result[:56]))[:4]],
        "six_N_Nmm":list(result[56:62]*SCALES),"signed_margin_MPa":list(caps-np.abs(result[56:62])),
        "predicted_gauges_MPa":list(result[-4:]),
        "predicted_all66_MPa":list(result),
        "dual_lower_bound_MPa":dual_obj/scale,
        "dual_reduced_cost_min":dual_min,"largest_scaled_primal_violation":float(slack),
        "dq":list(dq),
    }


def fixed_mix(evidence,states):
    path = evidence/"MVT2MeasuredTwistFeasibility20261116.zip"
    assert digest(path)=="46A2CB10379A4B5C33FA5296356C60EF99925B17A21E27938B0CEF3EC981B626"
    with ZipFile(path) as archive:
        source = json.loads(archive.read("TwistFeasibility.json"))
    model = source["reflected_sign_minimum"]
    ref = states["361:MeasuredRobust"]
    assert max(abs(diff(model["coordinates"],ref["field"])[j]) for j in range(60))<3e-15
    anchor = response(states["361:Anchor"])
    prediction = anchor.copy()
    for name, coeff in zip(model["axes"],model["coefficients"],strict=True):
        prediction += coeff*(response(states["361:"+name])-anchor)
    error = max(abs(response(ref)-prediction))
    assert abs(error-4.40234092996e-8)<4e-10
    return float(error)


def audit(evidence, plan_dir=None):
    all_states, hashes = input_states(evidence)
    old = all_states["361:Anchor"]
    ref = all_states["361:MeasuredRobust"]
    r = response(ref)
    original_caps = np.maximum(TAU,np.abs(response(old)[56:62]))
    strict_caps = np.minimum(original_caps,np.maximum(TAU,np.abs(r[56:62])))
    assert r[28]>0 and np.argmax(np.abs(r))==28
    assert abs(r[0]-r[56])<1e-12
    old_names = list(sorted(name for name in all_states if name.startswith(("354:","361:")))) + ["338:AxialCompMinus","361:Anchor"]
    subjects = dict(sorted(all_states.items()))
    for name in old_names:
        if name in subjects:
            subjects[name] = subjects.pop(name) # Give raw current anchors duplicate precedence.
    items = {}
    for name,state in subjects.items():
        assert ref["geometry"] == state["geometry"]
        dq = np.array(diff(state["field"],ref["field"]))
        de = station_components(dq,ref["geometry"])
        radius = float(np.max(np.abs(de)))
        if max(abs(dq))>1e-15:
            duplicates = [key for key in items if max(abs(np.array(key)-state["field"]))<=1e-15]
            for key in duplicates:
                assert max(abs(items[key][1]-response(state)+r))<4e-10
                del items[key]
            items[state["field"]] = (name,response(state)-r,dq,de,radius)
    current_neighborhood = [item for item in items.values() if item[4]<=RADIUS]
    measured_simplex = [item for item in items.values() if item[0].startswith("361:")]
    reaction = reaction_basis(ref["geometry"])
    nonlinear_guard = fixed_mix(evidence,all_states)+ROUND_OFF
    guarded = solve_lp(current_neighborhood,r,original_caps-nonlinear_guard,reaction)
    changed = r+sum((w*(response(all_states[name])-r) for name,w in guarded["active_weights"].items()),np.zeros(r.size))
    assert guarded["gain_MPa"]-nonlinear_guard>TAU
    # Native comparison pair with identical physical coordinates and only four
    # reaction entries differing. Both use already measured positive actions.
    q_after = np.array(ref["field"])+guarded["dq"]
    q_before = q_after.copy()
    q_before[56:] = np.array(ref["field"])[56:]+sum(
        (w*(np.array(all_states[name]["field"][56:])-ref["field"][56:])
         for name,w in guarded["active_weights"].items()),np.zeros(4))
    reaction_delta = reaction@(q_after[56:]-q_before[56:])
    assert max(abs(changed+reaction_delta-guarded["predicted_all66_MPa"]))<1e-12
    candidate = {
        "names":["SameStrain","Reacted"],"baseline":"MeasuredRobust","load_Qy_kN":QY,"tau_MPa":TAU,
        "before":list(q_before),"after":list(q_after),
        "before_predicted_all66_MPa":list(changed),"after_predicted_all66_MPa":guarded["predicted_all66_MPa"],
        "before_predicted_norm_MPa":float(max(abs(changed))),"after_predicted_norm_MPa":guarded["norm_MPa"],
        "exact_reaction_action_all66_MPa":list(reaction_delta),
        "reactions_delta_MPa":list(q_after[56:]-q_before[56:]),
        "expected_lower_bound_on_improvement_after_empirical_padding_MPa":guarded["gain_MPa"]-nonlinear_guard,
        "empirical_padding_MPa":nonlinear_guard,"archive_vector_guard_MPa":ROUND_OFF,
        "original_caps_MPa":list(original_caps),"current_six_caps_MPa":list(strict_caps),
        "solved_relative_radius_cap":RADIUS,"predicted_relative_physical_radius":guarded["maximum_physical_component_strain"],
        "archived_combination_weights":guarded["active_weights"],"lower_norm_gate_MPa":float(max(abs(r))-TAU),
    }
    exact = []
    for name,entry in subjects.items():
        measured = response(entry)
        if max(abs(measured[56:62])-original_caps)>4e-10:
            continue
        result = solve_lp([],measured,original_caps,reaction)
        exact.append({
            "endpoint":name,"norm_before_MPa":float(max(abs(measured))),
            "gain_from_mixed_MPa":float(max(abs(r))-result["norm_MPa"]),
            **result,
        })
    lp = {
        "current_positive_simplex_old_caps":solve_lp(measured_simplex,r,original_caps),
        "current_positive_simplex_current_caps":solve_lp(measured_simplex,r,strict_caps),
        "local_all_complete_old_caps":solve_lp(current_neighborhood,r,original_caps),
        "local_all_complete_current_caps":solve_lp(current_neighborhood,r,strict_caps),
        "local_with_exact_gauge_reactions_old_caps":solve_lp(current_neighborhood,r,original_caps,reaction),
        "local_with_exact_gauge_reactions_padded_old_caps":guarded,
        "local_with_exact_gauge_reactions_current_caps":solve_lp(current_neighborhood,r,strict_caps,reaction),
        "wide_convex_action_screen_only_old_caps":solve_lp(list(items.values()),r,original_caps),
    }
    summary = {
        "trace_sha256":hashes,"fixed_Qy_kN":QY,"H24_sha256":PREFIX,"tau_MPa":TAU,
        "all_complete_measurements":len(all_states),"unique_nonzero_actions_after_merge":len(items),
        "mixed_norm_MPa":float(max(abs(r))),"mixed_governing_weak_row":int(np.argmax(np.abs(r))+1),
        "first_and_29th_rows_MPa":[r[0],r[28]],"mixed_six_N_Nmm":list(r[56:62]*SCALES),
        "old_caps_N_Nmm":list(original_caps*SCALES),"current_caps_N_Nmm":list(strict_caps*SCALES),
        "ceiling_on_gain_if_center_retained_MPa":float(max(abs(r))-abs(r[0])),
        "row29_mechanical_balance":row29_decomposition(ref),"lp":lp,
        "best_exact_analytic_reaction_endpoints":sorted(exact,key=lambda x:x["norm_MPa"])[:8],
        "frozen_candidate":candidate,
        "screened_station_shape_component_cap":RADIUS,
        "predicted_fields_require_exact_native_replay":True,
        "physical_limit_confirmed":False,
    }
    if plan_dir is not None:
        stage_inputs(evidence,plan_dir,candidate,all_states)
    return summary


def stage_inputs(evidence,folder,candidate,states):
    folder.mkdir(parents=True,exist_ok=True)
    path = evidence/EXTRA["361"][0]
    with ZipFile(path) as archive:
        raw=archive.read("Native/MVT2.csv")
    assert sha256(raw).hexdigest().upper()=="BBED466B3FE47158E0EC894AADBAB5054A68FBB056A032354F552A89245F5AE6"
    (folder/"PreviousNative.csv").write_bytes(raw)
    tags=parse(raw)
    old_native={name:list(map(float,values)) for name,*values in tags["B_TANGENT_RESIDUAL"]}
    def emit(name,rows):
        with (folder/name).open("w",encoding="ascii",newline="") as file:
            csv.writer(file,delimiter=";",lineterminator="\r\n").writerows(rows)
    anchor_names=("Anchor","Large","AxialPlus","MeasuredRobust")
    rows=[]
    for name in anchor_names:
        entry=states["361:"+name]; res=old_native[name]
        rows.append((name,QY,*entry["field"],*res[:56],*(v*MODULUS for v in res[56:]),
                     *(np.array(entry["six_N_Nmm"])/SCALES)))
    emit("Anchors.csv",[["field_label","Qy_kN",*range(1,127)],*rows])
    emit("AnchorField.csv",[states["361:Anchor"]["field"]])
    emit("CandidateFields.csv",
         [["field_label","Qy_kN","predicted_residual_MPa",*(f"q{i}" for i in range(1,61))],
          ["SameStrain",QY,candidate["before_predicted_norm_MPa"],*candidate["before"]],
          ["Reacted",QY,candidate["after_predicted_norm_MPa"],*candidate["after"]]])
    (folder/"Row29Plan.json").write_text(json.dumps(candidate,indent=2)+"\n",encoding="utf8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--stage",type=Path)
    opts = parser.parse_args()
    report = audit(opts.evidence,opts.stage)
    opts.output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
    for label,result in report["lp"].items():
        print(label,result["gain_over_tau"],result["active_weights"])
    print({name:report[name] for name in ("all_complete_measurements","unique_nonzero_actions_after_merge",
                                          "first_and_29th_rows_MPa","ceiling_on_gain_if_center_retained_MPa",
                                          "row29_mechanical_balance")})
    print(opts.output,digest(opts.output))
