"""Read the exact native trace and attest signed efforts, paired stations and history."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys


def sha(data):
    return hashlib.sha256(data).hexdigest().upper()


def main(directory):
    sys.path.insert(0,str(directory))
    from VerifyBase import EFFORT_NAMES, SCALES, diff, force, peak, read_native, reconstruct, verified_states
    run=json.loads((directory/"Verification.json").read_text(encoding="utf8"))
    plan=json.loads((directory/"Row29Plan.json").read_text(encoding="utf8"))
    trace=directory/"Native/MVT2.csv"
    assert run["trace_sha256"]==sha(trace.read_bytes())
    tags=read_native(trace)
    states,stations=verified_states(tags)
    q=run["q_trial_kN"]
    tau=run["tau_MPa"]
    assert q==18.5720088671875 and q==plan["load_Qy_kN"]
    replay=directory/"Replay.csv"
    assert run["H24_sha256"]==sha(replay.read_bytes())
    rows=list(csv.reader(replay.read_text().splitlines(),delimiter=";"))
    assert len(rows)==25 and abs(float(rows[-1][2])-run["q_base_kN"])<2e-13
    assert run["exact_H24_restore"] and not run["history_published"]
    result={"trace_sha256":run["trace_sha256"],"H24_sha256":run["H24_sha256"],
            "target_Qy_kN":q,"last_accepted_Qy_kN":run["q_base_kN"],
            "exact_input_efforts_N_Nmm":dict(zip(EFFORT_NAMES,force(q),strict=True)),
            "tau_MPa":tau,"original_caps_N_Nmm":dict(zip(EFFORT_NAMES,
                (cap*scale for cap,scale in zip(plan["original_caps_MPa"],SCALES,strict=True)),strict=True)),
            "exact_H24_restore":True,"history_published":False,
            "deferred_due_to_changed_archive":run["deferred"]}
    if not run["deferred"]:
        names=("MeasuredRobust","SameStrain","Reacted")
        for name in names:
            if name not in states:
                continue
            state=states[name]
            reconstructed,actual,_=reconstruct(state["field"],q,stations[name])
            measured=state["signed_force_N_Nmm"]
            assert peak(diff(measured,diff(actual,force(q))))<4e-10
            assert state["q"]==q
            comparisons={
                key:{"actual_N_Nmm":value,"signed_residual_N_Nmm":resid,"original_cap_N_Nmm":cap,
                     "original_cap_margin_N_Nmm":cap-abs(resid)}
                for key,value,resid,cap in zip(EFFORT_NAMES,actual,measured,result["original_caps_N_Nmm"].values(),strict=True)
            }
            result[name]={"actual_norm_MPa":state["norm_MPa"],"row29_MPa":reconstructed[28],
                          "row53_MPa":reconstructed[52],"four_gauges_MPa":[v*30000. for v in reconstructed[-4:]],
                          "six":comparisons,"equilibrium":max(state["norm_MPa"],state["gauge_MPa"])<=tau}
            if name in ("SameStrain","Reacted"):
                decision=run["candidates"][name]
                result[name]["fails_caps"]=decision["fails_original_caps"]
                result[name]["fails_no_worsening_vs_mixed"]=decision["fails_no_worsening_vs_mixed"]
                result[name]["drops_at_least_tau_and_preserves_all_original_caps"]=decision["passes_tau_and_six_progress_gate"]
                result[name]["model_error_MPa"]=decision["actual_predictor_error_MPa"]
        assert all(states[k]==states["Base24"] and stations[k]==stations["Base24"] for k in
                   ("SameStrain/Rollback","Reacted/Rollback","Restored24"))
        if "SameStrain" in result and "Reacted" in result:
            before,after=result["SameStrain"],result["Reacted"]
            assert states["SameStrain"]["field"][:56]==states["Reacted"]["field"][:56]
            assert stations["SameStrain"]==stations["Reacted"] and before["six"]==after["six"]
            assert before["four_gauges_MPa"]==after["four_gauges_MPa"]
            action=tuple(a-b for a,b in zip(run["candidates"]["Reacted"]["actual_all66_MPa"],
                run["candidates"]["SameStrain"]["actual_all66_MPa"],strict=True))
            closure=peak(diff(action,plan["exact_reaction_action_all66_MPa"]))
            assert action[52]==0. and all(v==0. for v in action[56:])
            assert closure<=plan["archive_vector_guard_MPa"]
            improvement=result["MeasuredRobust"]["actual_norm_MPa"]-after["actual_norm_MPa"]
            result["pair"]={"same_full_station_records":len(stations["SameStrain"]),"identical_first56":True,
                "identical_all_six_and_all_four_gauges":True,"row29_actual_action_MPa":action[28],
                "row29_predicted_action_MPa":plan["exact_reaction_action_all66_MPa"][28],
                "row53_action_MPa":action[52],"maximum_exact_action_error_MPa":closure,
                "norm_drop_from_mixed_MPa":improvement,"norm_drop_from_mixed_over_tau":improvement/tau}
    out=directory/"Comparison.json"
    data=(json.dumps(result,indent=2)+"\n").encode("utf8")
    out.write_bytes(data)
    print(out,sha(data))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("probe",type=Path)
    main(parser.parse_args().probe.resolve(strict=True))
