"""Offline proof of the three doubled-radius fixed-history nonlinear probes."""
from argparse import ArgumentParser
from hashlib import sha256
from math import copysign
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
EXPANDED='CBE12AC774EFEA4698B001918E1748DE7A1132FDF30115B78F8F3973FE7D143B'
PREVIOUS=('MVT2GaussASDNominalTransverse20261117','151F9399FBC40330A38C825B1BE40DF9B56A9BBA8DFF86719E4A5C490FA23938')
FLAGS=((20,1),(20,-1),(10,-1))


def sha(b):
    return sha256(b).hexdigest().upper()


def archive(repo,pins):
    name,expected=pins
    path=repo/'docs/regression/Coupled6D'/(name+'.zip')
    assert sha(path.read_bytes())==expected
    return ZipFile(path)


def distance(a,b):
    return [x-y for x,y in zip(a,b,strict=True)]


def check_vectors(data,before,third,prior,watch,past,guard,op,geo,area,length):
    assert data['exact_prefix_sha256']==prior['FOLLOW']
    assert data['center']=='first_rejected_trial'
    assert data['history_count_before']==data['history_count_after']==53
    assert data['status']=='bounded_attempts_no_new_equilibrium' and 'next_original_nominal_target' not in data
    initial=third['iterations'][-1]['trials'][-1]
    x=data['initial_field']; raw=data['initial_section']; indicators=data['initial_cell_indicators']
    assert x==initial['field'] and raw==initial['section'] and indicators==initial['indicators']
    norm=raw['norm_MPa']; before_r=initial['all66']
    origin=before['first_rejected_trial']; approved=before['last_accepted_field']
    target=before['target']
    assert data['initial_target']==[0.,-33140625.,0.,10510000.,0.,55234.375]==target
    tensor=past['tensor']
    def strain(delta):
        return max(abs(v) for p in range(45) for side in (0,1,-1) for v in tensor(op,delta,p,side))

    total=strain(distance(before['original_predictor'],approved))
    actual_origin=strain(distance(x,origin))
    displacement_from_H53=strain(distance(x,approved))
    assert abs(total-data['total_cap'])<4e-18
    assert abs(actual_origin-data['displacement_from_chosen_center'])<4e-18
    assert abs(displacement_from_H53-data['displacement_from_accepted_H53'])<4e-18
    cap=data['maximum_local_radius']
    assert cap==2.*before['plan']['radius'] and data['maximum_trial_count']==3
    nearest_allowed_at_wrong_center=displacement_from_H53-3.*cap
    assert nearest_allowed_at_wrong_center>total
    signs=prior['active'](indicators)
    signature=raw['steel_active_flags']
    report=[]
    for k,trial in enumerate(data['trials'],1):
        assert trial['number']==k and trial['base_field']==x
        assert trial['base_indicators']==indicators and trial['base_all66']==before_r
        assert trial['admissible_reduction'] and trial['status']=='reduced_uncommitted_residual'
        linear=trial['plan']; actual=trial['candidate']; delta=linear['delta_field']; to=actual['field']
        assert linear['radius']==cap
        assert to==[h+d for h,d in zip(x,delta,strict=True)]
        local=strain(delta)
        from_origin=strain(distance(to,origin))
        from_H53=strain(distance(to,approved))
        assert abs(local-cap)<4e-18 and from_origin<total
        assert abs(actual['local_strain']-local)<4e-18
        assert abs(actual['strain_from_budget_center']-from_origin)<4e-18
        assert abs(actual['strain_from_accepted_H53']-from_H53)<4e-18
        base={'all66':before_r,'indicators':indicators}
        pred_r,pred_m=prior['prediction'](trial['finite_difference'],base,delta,op)
        predicted=max(map(abs,pred_r))
        assert abs(predicted-linear['predicted_norm_MPa'])<5e-15
        assert prior['error'](pred_m,linear['predicted_indicators'])<2e-18
        assert prior['active'](pred_m)==signs
        for u,v in zip(pred_m,indicators,strict=True):
            assert abs(u)>=.5*abs(v)-2e-18
        state=actual['section']; r=actual['all66']; marker=actual['markers']
        matrix_residual=watch['check_whole'](state,to,target,op,geo,area,length,guard['signed_forces'])
        assert abs(matrix_residual-actual['independent_norm_MPa'])<3e-12
        assert abs(matrix_residual-max(map(abs,r)))<3e-12
        tau=trial['tolerance_MPa']
        assert tau==raw['tolerance_MPa']==state['tolerance_MPa']<matrix_residual<norm
        ratio=(norm-matrix_residual)/(norm-predicted)
        # The runtime uses its current residual norm at the start of the
        # step, and the independent norm for the candidate in the ratio.
        engine_ratio=(max(map(abs,trial['base_all66']))-matrix_residual)/(max(map(abs,trial['base_all66']))-predicted)
        assert abs(engine_ratio-actual['observed_ratio'])<1e-8 and abs(ratio-engine_ratio)<1e-6
        assert ratio>=data['prediction_ratio_minimum']==.5
        assert actual['no_branch_or_steel_flag_change'] and state['steel_active_flags']==signature
        assert prior['active'](marker)==signs
        for (point,side),feature in zip(FLAGS,marker[:3],strict=True):
            observed=watch['eigen'](state['net_stresses_MPa'][(0,1,-1).index(side)][point-1])[1]
            assert abs(observed-feature)<2e-13 and copysign(1.,observed)==copysign(1.,feature)
        x,norm,indicators,before_r=to,matrix_residual,marker,r
        report.append({'move':k,'predicted_MPa':predicted,'independent_MPa':norm,'reduction_ratio':ratio,
                       'step_strain':local,'distance_from_first_rejected_trial':from_origin,
                       'distance_from_accepted_H53':from_H53,'branches':marker,'signed_6_N_Nmm':state['signed_6'],
                       'governing_rows':prior['key_indices'](r),
                       'binding_active_cell_constraints':[j-1752 for j in linear['active_constraints'] if j>1752]})
    assert len(report)==3 and 4.2<norm/raw['tolerance_MPa']<4.21
    return {'status':'PASS','frozen_H53_count':53,'Qy_attempted_N':target[5],'Qy_last_accepted_N':55156.25,
            'radii':{'cap_from_first_rejected_trial':total,'max_doubled_local':cap,
                     'initial_stage3_distance_from_H53':displacement_from_H53,
                     'minimum_excess_if_center_were_H53':nearest_allowed_at_wrong_center-total},
            'initial_MPa':raw['norm_MPa'],'final_MPa':norm,'original_tolerance_MPa':raw['tolerance_MPa'],
            'ratio_to_original_tolerance':norm/raw['tolerance_MPa'],'trials':report,
            'new_equilibrium':False,'physical_limit_established':False}


def main(repo):
    payload=(HERE/'ConeExpandedWire.json.gz').read_bytes()
    assert sha(payload)==EXPANDED
    data=json.loads(gzip.decompress(payload))
    with tempfile.TemporaryDirectory(prefix='MVTExpandedOffline_') as directory, archive(repo,PREVIOUS) as saved:
        root=Path(directory)
        (root/'Verify-Cone.py').write_bytes(saved.read('Verify-Cone.py'))
        prior=runpy.run_path(str(root/'Verify-Cone.py'))
        base=saved.read('ConeWire.json.gz'); third=saved.read('ConeContinueWire.json.gz')
        assert sha(base)==prior['WIRE'] and sha(third)==prior['FOLLOW']
        before,continuation=[json.loads(gzip.decompress(q)) for q in (base,third)]
        with archive(repo,prior['STATION']) as p:
            (root/'Verify-Stations.py').write_bytes(p.read('Verify-Stations.py'))
        watch=runpy.run_path(str(root/'Verify-Stations.py'))
        with archive(repo,watch['BASE']) as z:
            (root/'Verify-VectorEvidence.py').write_bytes(z.read('Verify-VectorEvidence.py'))
        history=runpy.run_path(str(root/'Verify-VectorEvidence.py'))
        accepted,n,_,_,_=history['history'](repo)
        assert accepted['Q_target_N']==55156.25 and accepted['field']==before['last_accepted_field']
        assert n<accepted['tolerance_MPa']
        with archive(repo,history['POST']) as z:
            (root/'Verify-Postyield.py').write_bytes(z.read('Verify-Postyield.py'))
        past=runpy.run_path(str(root/'Verify-Postyield.py'))
        with archive(repo,past['AUTH']) as z:
            for leaf in ('Verify-Authoritative.py','Operators.py','Reequilibrate.py'):
                (root/leaf).write_bytes(z.read(leaf))
        sys.path.insert(0,str(root))
        guard=runpy.run_path(str(root/'Verify-Authoritative.py'))
        operator,source=guard['unpack'](root,repo)
        model=runpy.run_path(str(root/'Reequilibrate.py'))
        _,_,geo,dirs,area,length,op,_,_,identity=model['read_inputs'](operator,root,source)
    assert identity==data['source_operator_identity']==before['operator_source']
    return check_vectors(data,before,continuation,prior,watch,past,guard,op,geo,area,length)


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=Path.cwd())
    cli.add_argument('--report',type=Path)
    args=cli.parse_args()
    result=main(args.repo)
    raw=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if args.report:
        with args.report.open('xb') as stream: stream.write(raw)
    print('MVT2 EXPANDED TRANSVERSE TRUST OFFLINE PASS',sha(raw),result['ratio_to_original_tolerance'])
