"""Bounded trust expansion from the exact third transverse relinearization."""
from argparse import ArgumentParser
from pathlib import Path
from time import perf_counter
import gzip
import importlib.util
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('continuation',HERE/'Continue-Cone.py')
follow=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(follow)
cone=follow.cone
STAGE3='61F969F7BBCD355CC627551C3CB460477A8A4C07BDC89FE52DB9ABFD5F96F1AF'
REPEAT=3
PREDICTIVE_REDUCTION_FRACTION=.5


def read_wire(name,pin):
    raw=(HERE/name).read_bytes()
    assert cone.digest(raw)==pin
    return json.loads(gzip.decompress(raw))


def physical(np,section,d):
    return float(np.max(np.abs(section.strain@d)))


def verify_reference(np,section,probe,vector,field,load,threshold,old):
    snap=probe.raw_section(section,field,load)
    assert snap==old['section'] and section.committed==53
    r=cone.witness(np,section,field,load,vector,threshold)
    assert r[1].tolist()==old['all66'] and r[3].tolist()==old['indicators']
    return r,snap


def expand(np,ops,section,probe,vector,receipt,watch,x,original,accepted,load,threshold,
           initial,baseline,local_cap,total,legacy):
    origin=original if legacy else accepted
    local_radius=local_cap
    signs=np.sign(initial[3])
    steels=initial[2].copy()
    grids=np.max(np.abs(section.strain),axis=(0,1,2))
    proof={'center':'first_rejected_trial' if legacy else 'accepted_H53','total_cap':total,
           'original_local_radius':local_cap/2.,'maximum_local_radius':local_cap,'maximum_trial_count':REPEAT,
           'prediction_ratio_minimum':PREDICTIVE_REDUCTION_FRACTION,'history_count_before':section.committed,
           'initial_field':x.tolist(),'initial_section':baseline,
           'initial_cell_indicators':initial[3].tolist(),'initial_target':load.tolist(),
           'displacement_from_chosen_center':physical(np,section,x-origin),
           'displacement_from_accepted_H53':physical(np,section,x-accepted),
           'displacement_from_original_trial':physical(np,section,x-original),'trials':[]}
    if proof['displacement_from_chosen_center']>total+REPEAT*local_cap:
        proof['status']='no_admissible_move_sequence_by_triangle_inequality'
        proof['minimum_excess_epsilon_after_three_moves']=proof['displacement_from_chosen_center']-total-REPEAT*local_cap
        assert probe.raw_section(section,x,load)==baseline
        proof['history_count_after']=section.committed
        return proof

    start=x.copy()
    initial_frame=baseline
    committed=False
    for k in range(1,REPEAT+1):
        # Use the triangle-inequality bound around the requested total center.
        # This guarantees every candidate remains admissible in physical strain
        # even before evaluating the exact norm of its new field.
        remaining=total-physical(np,section,x-origin)
        local_radius=min(remaining,local_radius)
        if local_radius<=0.:
            break
        base=cone.witness(np,section,x,load,vector,threshold)
        J,K,columns=cone.sample_columns(np,section,x,load,base,vector,threshold,grids)
        trial={'number':k,'base_field':x.tolist(),'base_all66':base[1].tolist(),
               'base_indicators':base[3].tolist(),'finite_difference':columns}
        proof['trials'].append(trial)
        if J is None:
            trial['status']='measured_derivative_unavailable'
            break
        delta,plan=cone.proposed_step(np,section,x,base,J,K,2.*local_radius,grids)
        trial['plan']=plan
        if delta is None or plan['predicted_norm_MPa']>=base[0][4]:
            trial['status']='no_predicted_reduction'
            break
        y=x+delta
        result,r,steel,markers=cone.witness(np,section,y,load,vector,threshold)
        frame=probe.raw_section(section,y,load)
        independent=follow.independent(section,watch,frame,y,load)
        known=base[0][4]-plan['predicted_norm_MPa']
        observed=base[0][4]-independent
        ratio=observed/known
        movement=physical(np,section,y-x)
        budget=physical(np,section,y-origin)
        same_material=np.array_equal(np.sign(markers),signs) and np.array_equal(steel,steels)
        admissible=bool(same_material and movement<=local_cap*(1.+3e-9) and budget<=total and ratio>=PREDICTIVE_REDUCTION_FRACTION)
        trial.update({'candidate':{'field':y.tolist(),'all66':r.tolist(),'section':frame,
                                   'independent_norm_MPa':independent,'observed_ratio':ratio,
                                   'no_branch_or_steel_flag_change':bool(same_material),'markers':markers.tolist(),
                                   'local_strain':movement,'strain_from_budget_center':budget,
                                   'strain_from_accepted_H53':physical(np,section,y-accepted)},
                      'tolerance_MPa':result[5],'admissible_reduction':admissible})
        if not admissible:
            trial['status']='rejected_exact_trial'
            local_radius*=.5
            continue
        x=y
        if result[4]>result[5] or independent>result[5]:
            trial['status']='reduced_uncommitted_residual'
            continue
        assert probe.raw_section(section,x,load)==frame
        trial['steel_committing']=follow.steel_wire(np,section)
        section.accepted_stresses.append(result[2].tolist()); section.commit()
        trial['status']='accepted_exact_equilibrium'
        committed=True
        print('ACCEPTED AT ORIGINAL TOLERANCE',float(load[5]), independent,flush=True)
        break

    if committed:
        # Cold rebuild the exact accepted H53 and commit only the accepted
        # trial. Match all station stress and steel buffers before advancing.
        old_count=section.committed
        frame=trial['candidate']['section']
        np2,ops2,fresh,_,identity,fresh_load,_=probe.exact_replay(vector,receipt)
        exact=probe.raw_section(fresh,x,fresh_load)
        assert np2 is np and ops2 is ops and np.array_equal(load,fresh_load) and exact==frame
        assert follow.steel_wire(np,fresh)==trial['steel_committing']
        assert follow.independent(fresh,watch,exact,x,load)<=result[5]
        fresh.accepted_stresses.append(exact['net_stresses_MPa']); fresh.commit()
        assert old_count==fresh.committed==54
        proof['fresh_exact_H54_replay']=True
        proof['next_original_nominal_target']=follow.next_nominal(np,probe,fresh,watch,x,accepted,load)
        proof['history_count_after']=fresh.committed
        proof['status']='advanced_to_balanced_trial'
    else:
        assert probe.raw_section(section,start,load)==initial_frame and section.committed==53
        proof['history_count_after']=section.committed
        proof['status']='bounded_attempts_no_new_equilibrium'
    return proof


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--legacy-rejected-center',action='store_true')
    cli.add_argument('--output',type=Path,required=True)
    args=cli.parse_args()
    output=args.output.resolve()
    assert output.parent==HERE and not output.exists()
    started=perf_counter()
    baseline=read_wire('ConeWire.json.gz',follow.PRIOR)
    third=read_wire('ConeContinueWire.json.gz',STAGE3)
    anchor=third['iterations'][-1]['trials'][-1]
    assert len(third['iterations'])==3 and third['history_final']==53
    assert third['iterations'][-1]['selected_factor']==1.
    probe=cone.load_pinned('station_probe',cone.PRIOR/'station/Probe-Stations.py',cone.STATION_SRC)
    vector,receipt=probe.exact_reference()
    np,ops,section,material,identity,load,_=probe.exact_replay(vector,receipt)
    watch=runpy.run_path(str(cone.PRIOR/'station/Verify-Stations.py'))
    assert identity==baseline['operator_source'] and material==baseline['material']
    accepted=np.array(baseline['last_accepted_field']); original=np.array(baseline['first_rejected_trial'])
    x=np.array(anchor['field']); threshold=baseline['tensile_threshold']
    total=physical(np,section,np.array(baseline['original_predictor'])-accepted)
    assert total==third['original_radius']
    cap=2.*baseline['plan']['radius']
    initial,raw=verify_reference(np,section,probe,vector,x,load,threshold,anchor)
    report=expand(np,ops,section,probe,vector,receipt,watch,x,original,accepted,load,threshold,initial,raw,
                  cap,total,args.legacy_rejected_center)
    ops.wipe()
    report['exact_prefix_sha256']=STAGE3
    report['source_operator_identity']=identity
    wire=gzip.compress(vector.raw_json(report),compresslevel=9,mtime=0)
    with output.open('xb') as stream: stream.write(wire)
    print('MVT2 ASD EXPANDED TRUST WIRE',cone.digest(wire),len(wire),'seconds',perf_counter()-started,
          report['status'],flush=True)


if __name__=='__main__':
    main()
