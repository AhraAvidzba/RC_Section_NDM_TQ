"""Compare the E-only run against validated D and the independently measured 1/2048 field."""
from argparse import ArgumentParser
from pathlib import Path
import json
import re
import runpy

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')


def verify(repo):
    prep=P['check'](repo)
    f=H/'Verify-Alt.py'
    source=f.read_text(encoding='utf-8-sig')
    key="assert book['Modules'] == ['modTestKaniStage38']"
    assert source.count(key)==1
    src=source.replace(key,f"assert sorted(book['Modules']) == {sorted(prep['modules'])!r}")
    n={'__name__':'short_E_verifier','__file__':str(f)}
    exec(compile(src,str(f),'exec'),n)
    n['P']['check']=P['check']
    e=n['verify'](repo)
    d=json.loads((H/'SectionComparison.json').read_text(encoding='utf8'))['variants']['D']
    measure=json.loads((H/'D-DampingAssessment.json').read_text(encoding='utf8'))
    for tag in ('Base45','Zero45','End45','Restore45'):
        assert d['fullEvidence']['comparison89PlusFive'][tag]==e['comparison89PlusFive'][tag]
    log=e['rightShoulder']['diagnostic']
    pattern=r'короткая проба 1/2048 (\d+), исходная невязка, МПа:\s*([+-]?\d[^ ,|]*), невязка, МПа:\s*([+-]?\d[^ ,|]*), множитель:\s*([+-]?\d[^ ,|]*)(, принята поправка)?'
    entries=[{'probe':int(i),'beforeMPa':float(b),'afterMPa':float(a),'lambda':float(l),'accepted':bool(p)}
             for i,b,a,l,p in re.findall(pattern,log)]
    attempts=list(map(int,re.findall(r'короткая проба 1/2048 (\d+)',log)))
    assert attempts and attempts==list(range(1,len(attempts)+1)) and len(attempts)<=prep['totalShortProbeCap']
    first=entries[0]
    assert first['probe']==1 and first['accepted']
    suffix=measure['independentSectionStates']
    assert abs(first['beforeMPa']-suffix['Base']['normMPa'])<2e-10
    assert abs(first['afterMPa']-suffix['Plus16']['normMPa'])<2e-10
    assert abs(first['lambda']-suffix['Plus16']['lambda'])<2e-14
    assert first['afterMPa'] < first['beforeMPa']*(1-1e-4/2048)
    result={'D':d['rightResult'],'E':e,'shortProbeAttempts':attempts,'shortEvaluations':entries,
            'firstShortMatchesMeasuredD':True,'H45ExactAcrossDandE':True,'unchangedAbsoluteRelativeTolerance':True}
    saved=H/'ShortDampingEComparison.json'
    saved.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print('SHORT_E_PASS',P['sha'](saved),first)
    return result


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    verify(a.repo_root.resolve())
