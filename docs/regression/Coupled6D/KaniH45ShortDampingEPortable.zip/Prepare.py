"""Prepare a single private E variant with one witnessed short damping trial per stall."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import subprocess

H=Path(__file__).resolve().parent
TIP='6d42af5'
BOOK='workbook/output/RC_Section_NDM.xlsm'
BOOK_HASH='475E57DE58848B3F83DA8C79B1A10EC05B3726CC52B0C904E5B975F4CFBDFB18'
DRAFT='docs/regression/Diagnostic.xlsm'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'
CONCRETE='src/Materials/CCoupledConcreteResponse.cls'
MACRO='tests/modTestKaniStage38.bas'
PAIR='KaniH45ElasticDamageSectionPortable.zip'
PAIR_HASH='E4F57928BA1FEAA08E737642FB340F2B9A547B7A938A9D59FD60013B52911C51'
WITNESS='KaniH45DLastDirectionPortable.zip'
WITNESS_HASH='648CEB7D037BD9E95D86BFF222EB9CEEB68BE914A61F085FACFBD67B96A9250B'
ART='docs/regression/Coupled6D'
KEEP=('DiscriminatingH45Measurement.json','H45DiscriminatingControl.csv','KaniGaugeInput.csv','KaniV4Input.csv',CONCRETE,MACRO)


def sha(x):
    return sha256(x.read_bytes() if isinstance(x,Path) else x).hexdigest().upper()


def blob(repo,n):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',TIP+':'+n])


def put(n,b):
    dst=H/n; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(b)
    return sha(b)


def solver(raw):
    s=raw.decode('utf8').replace('\r\n','\n')

    def one(a,b):
        nonlocal s
        assert s.count(a)==1,a
        s=s.replace(a,b)

    anchor='Private Const MIN_FRACTION As Double = 0.0078125'
    one(anchor,anchor+"""
Private Const SHORT_STALL_FRACTION As Double = 0.00048828125 ' Доля 1/2048 воспроизведена на архивном направлении Kani D.
Private Const SHORT_STALL_PROBE_LIMIT As Long = 4 ' Не более одной пробы на каждый отказ демпфирования.""")

    anchor='Private mFailureCode As ESolverFailureCode'
    one(anchor,anchor+"""
Private mShortStallProbes As Long
Private mShortStallDetails As String""")
    anchor='    mLastNorm = 0#: mMinimumPivot = 0#'
    one(anchor,anchor+"""
    mShortStallProbes = 0: mShortStallDetails = vbNullString""")

    anchor='            mMeta.DiagnosticDetails = details\n            If recoverYieldControl'
    one(anchor,"""            mMeta.DiagnosticDetails = details
            If mControlActive And mConsistentControl And mUseSpatialHistory And Len(mismatch) > 0 And _
                    norm > SMALL_STRAIN_MAX_NORM * tolerance And mShortStallProbes < SHORT_STALL_PROBE_LIMIT Then
                If Abs(trialEquation - baseEquation) > tolerance Then
                    Dim beforeShortFailure As ESolverFailureCode, shortSummaryBefore As String
                    beforeShortFailure = mFailureCode: shortSummaryBefore = DiagnosticSummary()
                    If TryShortStallProbe(current, currentLambda, correction, load, norm, absoluteTolerance, relativeTolerance, _
                            candidateLambda, candidateNorm, candidateTolerance) Then GoTo AcceptDampedTrial
                    If mFailureCode <> sfcNone And mFailureCode <> sfcNumericalFailure And mFailureCode <> sfcSingularTangent Then
                        RecordFailure mFailureCode, "Материальная ошибка короткой пробы после отказа демпфирования."
                        Exit Function
                    End If
                    mFailureCode = beforeShortFailure
                    mMeta.DiagnosticDetails = DiagnosticSummary() & Mid$(details, Len(shortSummaryBefore) + 1)
                End If
            End If
            If recoverYieldControl""")
    anchor='''        End If
        mIterations = mIterations + 1
        If candidateNorm <= candidateTolerance And GaugesVerified(candidateTolerance) Then'''
    one(anchor,anchor.replace('        mIterations', 'AcceptDampedTrial:\n        mIterations'))
    anchor="' Проверяет поправку служебного множителя без записи материальной пробы."
    helper=(H/'ShortProbeMethod.cls.txt').read_text(encoding='utf-8-sig').strip()
    one(anchor,helper+'\n\n'+anchor)
    anchor='    If mGradientBuilds > 0 Then DiagnosticSummary = DiagnosticSummary & "; уточнений касательной: " & CStr(mGradientBuilds)'
    one(anchor,anchor+'\n    If mShortStallProbes > 0 Then DiagnosticSummary = DiagnosticSummary & mShortStallDetails')
    return s.replace('\n','\r\n').encode('utf8')


def find(repo,n,fallback):
    p=repo/ART/n
    return p if p.is_file() else fallback


def check(repo):
    r=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert r['bookSHA256']==BOOK_HASH==sha(blob(repo,BOOK))==sha(H/BOOK)
    assert r['sectionPairSHA256']==PAIR_HASH and r['directionWitnessSHA256']==WITNESS_HASH
    assert r['candidateSolverSHA256']==sha(H/SOLVER)==sha(solver(blob(repo,SOLVER)))
    assert all(sha(H/n)==v for n,v in r['frozen'].items())
    assert all(sha(repo/ART/n)==v for n,v in r['supportArchives'].items())
    assert {f.stem for d in ('src','tests') for f in (H/d).rglob('*') if f.is_file()}==set(r['modules'])
    return r


def stage(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    assert not (H/'Preparation.json').exists()
    pair=find(repo,PAIR,H.parent/'ksec'/'Portable'/PAIR)
    wit=find(repo,WITNESS,H.parent/'kdr'/'Portable'/WITNESS)
    assert sha(pair)==PAIR_HASH and sha(wit)==WITNESS_HASH
    book=blob(repo,BOOK)
    assert sha(book)==BOOK_HASH
    frozen={}
    with ZipFile(pair) as p,ZipFile(wit) as w:
        old=json.loads(p.read('Preparation.json'))
        man=json.loads(p.read('Manifest.json'))['files']
        data={n:p.read('D/'+n) for n in KEEP}
        assert all(sha(b)==man['D/'+n] for n,b in data.items())
        assert sha(data[CONCRETE])==old['candidateMaterialSHA256']
        for n in ('Verify-Alt.py','Prepare-Alt.py','SectionComparison.json'):
            data[n]=p.read(n)
        for n in ('D-DampingAssessment.json','ShortDampingWitness.csv'):
            data[n]=w.read(n)
        for n,v in old['frozen'].items():
            if n.startswith('D/tools/'):
                name=n[2:]
                b=(repo/name).read_bytes()
                assert sha(b)==v and b.replace(b'\r\n',b'\n')==blob(repo,name).replace(b'\r\n',b'\n')
                data[name]=b
        data[BOOK]=book
        data[SOLVER]=solver(blob(repo,SOLVER))
        for n,b in data.items():
            frozen[n]=put(n,b)
        put(DRAFT,book)
    for n in ('Native','Temp'):
        (H/n).mkdir(exist_ok=True)
    for n in ('Prepare.py','ShortProbeMethod.cls.txt','Run.ps1','Verify.py','README.md'):
        frozen[n]=sha(H/n)
    r={'sourceGit':TIP,'bookSHA256':BOOK_HASH,'sectionPairSHA256':PAIR_HASH,'directionWitnessSHA256':WITNESS_HASH,
       'candidateSolverSHA256':frozen[SOLVER],'candidateMaterialSHA256':frozen[CONCRETE],
       'originalTauMPa':5.59190995944018e-7,'shortFraction':1/2048,'totalShortProbeCap':4,
       'sectionTimeoutSeconds':180,'modules':['CCoupledConcreteResponse','CCoupledNewtonSolver','modTestKaniStage38'],
       'supportArchives':old['supportArchives'],'frozen':dict(sorted(frozen.items()))}
    put('Preparation.json',(json.dumps(r,indent=2)+'\n').encode())
    return check(repo)


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    p.add_argument('--check',action='store_true')
    a=p.parse_args()
    (check if a.check else stage)(a.repo_root.resolve())
    print('SEALED_E',sha(H/'Preparation.json'))
