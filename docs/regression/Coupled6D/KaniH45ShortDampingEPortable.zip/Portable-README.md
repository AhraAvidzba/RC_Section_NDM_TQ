# Проверка четырёх коротких поправок Kani H45

Архив содержит штатное левое поле H45, нативные журналы варианта E,
разбор первой короткой поправки и контрольный вариант D. Четыре
поправки приняты по критерию уменьшения остатка. Правое равновесие
по неизменному допуску не найдено. История H45 восстановлена точно.

```powershell
$env:PYTHONPATH='D:/CodexScratch/RC_Section_NDM_TQ/FocusedVerifierDeps'
$case=(New-Item -ItemType Directory -Path 'tmp/ke/PortableReplay').FullName
Expand-Archive -LiteralPath 'tmp/ke/Portable/KaniH45ShortDampingEPortable.zip' -DestinationPath $case
python -B -X utf8 (Join-Path $case 'Replay-E.py') --repo-root (Get-Location).Path
```

Исходная книга проверяется по Git 6d42af5. Книги Excel в архив не
вложены. Воспроизведение сверяет два подтверждения хеша частной
книги, независимо собирает 89 силовых и пять кинематических
уравнений на исходных полях и проверяет все зарегистрированные
короткие пробы. Данные первой пробы сопоставляются с измеренным
полем варианта D. Текущая установленная книга не используется.
