"""Rebuild the E-vs-D result offline using historical Git and binary-free receipts."""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import json
import runpy

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')


def sha(b):
    return sha256(b.read_bytes() if isinstance(b,Path) else b).hexdigest().upper()


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def once(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)


def preparation(repo):
    m=read(H/'Manifest.json')
    p=read(H/'Preparation.json')
    assert m['schema']=='KaniH45WitnessedE/v1'
    assert p['bookSHA256']==m['bookSHA256']==sha(P['blob'](repo,P['BOOK']))
    assert p['candidateSolverSHA256']==m['candidateSolverSHA256']==sha(H/P['SOLVER'])
    assert p['candidateSolverSHA256']==sha(P['solver'](P['blob'](repo,P['SOLVER'])))
    assert p['candidateMaterialSHA256']==sha(H/P['CONCRETE'])
    assert all(sha(H/n)==d for n,d in m['files'].items())
    for n,d in p['frozen'].items():
        if n in m['files']:
            assert m['files'][n]==d
        elif n==P['BOOK']:
            assert d==m['bookSHA256']
        else:
            assert n.startswith('tools/')
            raw=P['blob'](repo,n)
            lf=raw.replace(b'\r\n',b'\n')
            assert d in {sha(raw),sha(lf),sha(lf.replace(b'\n',b'\r\n'))}
    for n,d in p['supportArchives'].items():
        assert sha(repo/P['ART']/n)==d
    proof=read(H/'docs/regression/CodeUpdate.json')
    owned=read(H/'Native/KaniV4.txt.Ownership.json')
    assert proof['WorkbookSHA256']==owned['SourceSHA256']==m['compiledPrivateBookSHA256']
    assert p['sectionPairSHA256']==m['sectionPairSHA256'] and p['directionWitnessSHA256']==m['directionWitnessSHA256']
    for n,expected in ((P['PAIR'],p['sectionPairSHA256']),(P['WITNESS'],p['directionWitnessSHA256'])):
        source=repo/P['ART']/n
        if source.exists():
            assert sha(source)==expected
    return p


def detached_closure(s):
    a="    assert book['WorkbookSHA256'] == P['sha'](H / P['draft']) == own['SourceSHA256']"
    b="""    assert book['WorkbookSHA256'] == own['SourceSHA256']
    if (H / P['draft']).exists():
        assert book['WorkbookSHA256'] == P['sha'](H / P['draft'])"""
    return once(once(s,a,b),"'AlternateVerification.json'","'Replay-AlternateVerification.json'")


def replay(repo):
    p=preparation(repo)
    f=H/'Verify.py'
    s=f.read_text(encoding='utf-8-sig')
    at="    n={'__name__':'short_E_verifier','__file__':str(f)}"
    s=once(s,at,'    src=detached_closure(src)\n'+at)
    s=once(s,"'ShortDampingEComparison.json'","'Replay-ShortDampingEComparison.json'")
    n={'__name__':'damping_E_detached','__file__':str(f),'detached_closure':detached_closure}
    exec(compile(s,str(f),'exec'),n)
    n['P']['check']=lambda _:p
    result=n['verify'](repo)
    assert result==read(H/'ShortDampingEComparison.json')
    print('DETACHED_SHORT_E_PASS',sha(H/'Replay-ShortDampingEComparison.json'))
    return result


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    replay(a.repo_root.resolve())
