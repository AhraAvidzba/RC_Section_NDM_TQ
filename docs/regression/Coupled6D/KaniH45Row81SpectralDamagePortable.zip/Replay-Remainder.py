"""Decompose the exact Kani Newton witness on side stations outside the calibrated apex replay."""
from argparse import ArgumentParser
from collections import Counter
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import runpy

import numpy as np

WITNESS='KaniH45Row81DirectionPortable.zip'
WITNESS_SHA='4B65725C0977E6855720BFBD0F9CA7D5D3FCF0AD3F4C1C0A8FA68F73DECDA701'
PRIOR='KaniH45LocalTangentGuardPortable.zip'
PRIOR_SHA='B0424BBEEDF7DAFE7602BA8882527A2FCB16BD001FEA8AC3F6E3CFED71E8D6D0'
PAIRS=('4','16')
MODULUS=25600.
FORCE=1e5


def sha(data):
    return sha256(data).hexdigest().upper()


def decode(path):
    return json.loads(path.read_text(encoding='utf8'))


def inputs(repo, workspace):
    d=repo/'docs/regression/Coupled6D'
    assert sha((d/WITNESS).read_bytes())==WITNESS_SHA
    assert sha((d/PRIOR).read_bytes())==PRIOR_SHA
    with ZipFile(d/WITNESS) as z:
        manifest=z.read('Manifest.json')
    assert (workspace/'Manifest.json').read_bytes()==manifest
    for n,g in json.loads(manifest)['files'].items():
        assert sha((workspace/n).read_bytes())==g,n
    with ZipFile(d/PRIOR) as z:
        previous=json.loads(z.read('LocalTangentAudit.json'))
    api=runpy.run_path(workspace/'Replay-Row.py')['row_api'](portable=True)
    apex,g=runpy.run_path(workspace/'Classify-Row.py')['inputs'](repo)
    context=runpy.run_path(workspace/'AltVerifier.py')
    historical,accepted,operator,_=context['archived_inputs'](repo)
    assert np.array_equal(g[:,:3],historical['geometry'])
    return api,apex,g,historical,accepted,operator,previous


def pos_share(eigs):
    return float(np.maximum(eigs,0.).sum()/abs(eigs).sum())


def damage_direction(effective,d_effective,dt,dc_one):
    eigs,vectors=np.linalg.eigh(effective)
    if min(abs(eigs))<1e-12:
        raise ValueError('Principal stress too close to the sign boundary for classical derivative')
    eigs_d=np.diag(vectors.T@d_effective@vectors)
    t=float(np.maximum(eigs,0.).sum())
    all_e=float(abs(eigs).sum())
    d_t=float(eigs_d[eigs>0].sum())
    d_all=float(np.sign(eigs)@eigs_d)
    chi=(d_t*all_e-t*d_all)/(all_e*all_e)
    return dc_one*((1-dt*t/all_e)*d_effective-dt*chi*effective)


def stress_section(h,shape,g,phy,area,scale,geo,control,requested,x,s,lam):
    ds=(s[2]-s[0])/.002
    w=np.einsum('nij,ni,n->j',h,s[1],area)+g.T@x[83:]
    w[4:]-=np.einsum('nk,na,n->ka',shape,ds[:,[4,5,2]],area).ravel()
    long=np.einsum('nij,ni,n->j',h[:,:,:4],ds,area)
    long[1]-=lam*FORCE/scale[0]
    forces=np.einsum('nij,nj,n->i',phy,s[1],geo[:,2])
    r=np.r_[w,long,(forces-np.r_[np.zeros(5),lam*FORCE])/scale]
    k=MODULUS*np.r_[g@x[:79],control@x-requested]
    return float(max(max(abs(r)),max(abs(k)))),r,k,forces


def analyze(repo, work):
    api,apex,geo,arc,cert,operator,prior=inputs(repo,work)
    reference=decode(work/'KaniRowVerification.json')
    raw,stress,tangent,x,fracs,st,errors=api['parse']()
    assert not errors
    known={(y['side']+1,y['point']-1) for y in prior['qualifiers']}
    remaining={(i,j) for i in (0,2) for j in range(184)}-known
    assert len(known)==70 and len(remaining)==298
    base_stress=stress['BASE_STRESS']
    full=(stress['LAST_STRESS']-base_stress)/fracs['Last']
    h,shape,g,phy,area,scale=operator(geo[:,:3],float(arc['length']))
    dq=raw['CORRECTION'][:87]
    dlam=float(raw['CORRECTION'][-1])
    local_dir=h@dq[:79]+np.array([-.001,0.,.001])[:,None,None]*(h[:,:,:4]@dq[79:83])[None]
    weights=np.array([-1.,0.,1.])[:,None]*area[None,:]*geo[None,:,1]/(float(arc['length'])*.002)
    last=weights*full[:,:,2]
    derivative=np.zeros_like(weights)
    for i in (0,2):
        derivative[i]=weights[i]*np.einsum('ni,ni->n',tangent[i],local_dir[i])
    sum_on=lambda arr,keys:float(sum(arr[i,j] for i,j in sorted(keys)))
    sign_pairs={}
    for p in PAIRS:
        plus='Plus'+p
        minus='Minus'+p
        f=fracs[plus]
        assert f==-fracs[minus]
        assert np.array_equal(st['Base'][:,:,:3],st[plus][:,:,:3]) and np.array_equal(st['Base'][:,:,:3],st[minus][:,:,:3])
        sp=st[plus][:,:,12]
        sm=st[minus][:,:,12]
        signedp=weights*(sp-base_stress[:,:,2])/f
        signedm=-weights*(sm-base_stress[:,:,2])/f
        sign_pairs[p]=(signedp,signedm,(signedp+signedm)*.5)
    short=sign_pairs['16'][2]
    local_error=short-derivative
    finite_curvature=last-short
    assert abs(float((last-derivative).sum())-reference['actualMinusPredictedMPa'])<2e-9
    center_index=list(arc['names']).index('Committed45')
    committed=arc['stations'][arc['station_index'][center_index]]
    energies=np.array(cert['energiesByStation_minus0plus']['Committed45'])
    dirs=np.zeros((len(geo),6))
    dirs[144:,:4]=geo[144:,3:]
    elastic_valid={}
    skipped=Counter()
    lhs_columns=(2e-9,2e-9/64.)

    for i,j in sorted(remaining):
        b=st['Base'][i,j]
        if b[0]!=0 or b[2]!=1 or b[3]>=0.:
            skipped['NotSingleStepNegativeYieldElastic']+=1
            continue
        k_t,k_c=energies[i,j]
        cc,m0=apex['compression_history'](k_c)
        steel=dirs[j]
        isbar=j>=144

        def steel_stress(strain):
            axial=2e5*np.dot(strain,steel)
            if isbar and abs(axial)>=400.:
                raise ValueError('Rebar outside verified elastic range')
            return axial*steel

        source=committed[i,j]
        seed=steel_stress(source[:6])-source[6:] if isbar else source[6:]
        seed=apex['matrix'](seed)
        fraction=m0*(1-k_t*pos_share(np.linalg.eigvalsh(seed)))
        e0=seed/fraction

        def response(strain):
            effective=e0+apex['elastic'](strain-source[:6])
            eig=np.linalg.eigvalsh(effective)
            tr=float(np.trace(effective))
            q=apex['invariant'](effective)[2]
            beta=(cc/1.75*.88-1.12) if eig[-1]>0. else 3.
            yield_trial=(.12*tr+q+beta*eig[-1])/.88-cc
            nominal=apex['vector'](m0*(1-k_t*pos_share(eig))*effective)
            ss=steel_stress(strain)-nominal if isbar else np.array(nominal)
            return ss,yield_trial,effective,eig

        max_stress=0.
        max_F=0.
        states=[]
        try:
            for s, t in st.items():
                r=t[i,j]
                sigma,F,_,pr=response(r[4:10])
                max_stress=max(max_stress,float(max(abs(sigma-r[10:]))))
                max_F=max(max_F,abs(float(F-r[3])))
                if F>=0. or r[0]!=0 or r[2]!=1:
                    raise ValueError('Witness not fully elastic')
                states.append((s,np.sign(pr).astype(int).tolist()))
            if max_stress>2e-10 or max_F>2e-9:
                raise ValueError('Stress or yield replay outside checked accuracy')
            base,_,effective,eigs=response(b[4:10])
            control_signs=np.sign(eigs).astype(int)
            d_sigma=damage_direction(effective,apex['elastic'](local_dir[i,j]),k_t,m0)
            derivative_exact=steel_stress(local_dir[i,j])[2]-d_sigma[2,2] if isbar else d_sigma[2,2]
            row_exact=float(weights[i,j]*derivative_exact)
        except ValueError as e:
            skipped[str(e)]+=1
            continue
        wide={}
        for amp in lhs_columns:
            columns=[]
            probes=[]
            for k,u in enumerate(np.eye(6)):
                dh=amp*(1+abs(b[4+k]))
                sigmap,Fp,_,eigp=response(b[4:10]+dh*u)
                sigmam,Fm,_,eigm=response(b[4:10]-dh*u)
                plus_sign=np.sign(eigp).astype(int)
                minus_sign=np.sign(eigm).astype(int)
                if Fp>=0. or Fm>=0. or plus_sign[-1]!=control_signs[-1] or minus_sign[-1]!=control_signs[-1]:
                    columns.append(None)
                else:
                    columns.append(float((sigmap[2]-sigmam[2])/(2*dh)))
                probes.append({'column':k+1,'Fp':float(Fp),'Fm':float(Fm),'eigenSignsPlus':plus_sign.tolist(),
                               'eigenSignsMinus':minus_sign.tolist(),
                               'crossesAnyPrincipalSign':bool(np.any(plus_sign!=control_signs)|np.any(minus_sign!=control_signs))})
            finite=all(q is not None for q in columns)
            wide[str(amp)]={'ZzColumnsMPa':columns,'row81ActionMPa':float(weights[i,j]*np.dot(columns,local_dir[i,j])) if finite else None,
                            'probes':probes}
        elastic_valid[i,j]={'point':j+1,'side':i-1,'isRebarReplacement':isbar,'effectivePrincipalStressMPa':eigs.tolist(),
              'stressReplayMismatchMPa':max_stress,'predictorReplayMismatchMPa':max_F,'witnessSignatures':dict(states),
              'installedRow81ActionMPa':float(derivative[i,j]),'nearRow81ActionMPa':float(short[i,j]),
              'exactDamageRow81ActionMPa':row_exact,'lastRow81ActionMPa':float(last[i,j]),
              'coarseCoordinateBrackets':wide,'fixedInputs':{
                  'exactPreviousHistoryStrain':source[:6].tolist(),'exactPreviousHistoryNominalStressMPa':source[6:].tolist(),
                  'exactPreviousTensionCompressionEnergy':[float(k_t),float(k_c)],
                  'trialBaseEngineeringStrain':b[4:10].tolist(),'NewtonDirectionEngineeringStrain':local_dir[i,j].tolist()}}

    assert len(elastic_valid)==16
    for key in ((2,134),(0,9)):
        station=elastic_valid[key]
        assert station['effectivePrincipalStressMPa'][0]<0<station['effectivePrincipalStressMPa'][1]
        assert all(sign==[-1,1,1] for sign in station['witnessSignatures'].values())
        stock=station['coarseCoordinateBrackets']['2e-09']
        small=station['coarseCoordinateBrackets']['3.125e-11']
        assert [x['column'] for x in stock['probes'] if x['crossesAnyPrincipalSign']]==[2]
        assert stock['probes'][1]['eigenSignsPlus']==[1,1,1] and stock['probes'][1]['eigenSignsMinus']==[-1,1,1]
        assert all(x['Fp']<0 and x['Fm']<0 for x in stock['probes'])
        assert not any(x['crossesAnyPrincipalSign'] for x in small['probes'])
        assert abs(stock['row81ActionMPa']-station['installedRow81ActionMPa'])<2e-14
        assert abs(small['row81ActionMPa']-station['exactDamageRow81ActionMPa'])<4e-13
        assert abs(station['nearRow81ActionMPa']-station['exactDamageRow81ActionMPa'])<7e-12
    unsupported=remaining-elastic_valid.keys()
    candidates={}
    coeffs=(work/'H45DiscriminatingControl.csv').read_text(encoding='ascii').strip().split(';')
    goal=float(coeffs[3]); control=np.array(coeffs[5:],float)
    lam0=float(raw['FAIL'][5])
    for label in ('Base','Plus4','Minus4','Plus16','Minus16','Last'):
        lam=lam0+fracs[label]*dlam
        value,r,k,forces=stress_section(h,shape,g,phy,area,scale,geo[:,:3],control,goal,x[label],st[label][:,:,10:],lam)
        candidates[label]={'norm89Plus5MPa':value,'row81MPa':float(r[80]),'secondLargestForceRow':int(np.argsort(abs(r))[-2]+1),
                           'secondLargestForceResidualMPa':float(np.sort(abs(r))[-2]),'Qy_N':float(lam*FORCE),
                           'maxControlsMPa':float(max(abs(k))),'externalPhysicalEfforts_NNmm':forces.tolist()}
    partition={}
    for name,keys in (('Known70',known),('Remaining298',remaining),('IndependentElasticDamage',elastic_valid.keys()),('StillUnsupported',unsupported)):
        partition[name]={'count':len(keys),'nativeFullMinusInstalledMPa':sum_on(last-derivative,keys),
                         'localSmallSecantMinusInstalledMPa':sum_on(local_error,keys),
                         'localSmallSecantMinusInstalledAbsMPa':sum_on(abs(local_error),keys),
                         'finiteFullMinusSmallSecantMPa':sum_on(finite_curvature,keys),
                         'positiveMinusNegativeGap16MPa':sum_on(sign_pairs['16'][0]-sign_pairs['16'][1],keys),
                         'smallSecant16Minus4MPa':sum_on(short-sign_pairs['4'][2],keys)}
    ordered=sorted(remaining,key=lambda ij:abs(local_error[ij]),reverse=True)
    rank=[{'point':j+1,'side':i-1,'nativeLimitedSecantErrorMPa':float(local_error[i,j]),
           'finiteCurvatureMPa':float(finite_curvature[i,j]),'nativeBaseFlags':st['Base'][i,j,:3].astype(int).tolist(),
           'nativeFBaseMPa':float(st['Base'][i,j,3]),'independentElastic':elastic_valid.get((i,j))} for i,j in ordered[:12]]
    return {'referenceSHA256':WITNESS_SHA,'apexGuardArchiveSHA256':PRIOR_SHA,
            'fixedDirectionStressComponent':'axial sigmaZZ, z-side weight of dMx/dz',
            'remainingPartition':partition,'localElasticReturnExcluded':dict(skipped),
            'independentElasticDamage':list(elastic_valid.values()),'largestPreviouslyUnresolved':rank,
            'actualSectionProbes':candidates,
            'interpretation':['Exact fixed-committed elastic damage is used only for all six native one-step elastic probes with negative effective yield.',
                              'Stable directional secants diagnose the archived Newton direction only. All six-force and continuity acceptance still depend on native equilibrium.']}


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',required=True,type=Path)
    p.add_argument('--witness-root',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    p.add_argument('--fixture-out',type=Path)
    a=p.parse_args()
    result=analyze(a.repo_root.resolve(),a.witness_root.resolve())
    a.out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    if a.fixture_out:
        lines=['KANI_SPECTRAL_DAMAGE;2']
        ranked={(r['point'],r['side']):r for r in result['independentElasticDamage']}
        for point,side in ((135,1),(10,-1)):
            r=ranked[point,side]['fixedInputs']
            lines.append(';'.join([str(point),str(side),*(format(float(s),'.17g') for s in r['trialBaseEngineeringStrain'])]))
        a.fixture_out.write_bytes(('\r\n'.join(lines)+'\r\n').encode('ascii'))
        print(a.fixture_out,sha(a.fixture_out.read_bytes()))
    print(a.out,sha(a.out.read_bytes()))
    print(json.dumps(result['remainingPartition'],indent=2))
