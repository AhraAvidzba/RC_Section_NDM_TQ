"""Screen a joint center/longitudinal-gradient step inside the measured MVT2 sign cell."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import linprog

PIN="60DE46B7044294109413E368C03418A5D0FE4B4F8EEB1C5F035E5E08CDA515C7"
EVENT="CE82F4DED6CADFAE3641CA1C58991F0049A0F9F563000359FABED96CD7A31F96"
NORMAL="11BC995BCE708919D632A441162AED37A6896A79F6083836191F0E44806EF4C7"
FORCE="8E759775518EF15D8ACC186E6D0A4AA9FA17BB1966E30FB09270A48FDEE4A2B9"
HERE=Path(__file__).resolve().parent


def physical(v,q,s):
    r,_,_=v.reconstruct(q["field"],q["q"],s)
    return np.r_[q["r"],np.multiply(r[-4:],v.MODULUS)]


def load(v,folder,name,file,identity):
    path=folder/file
    assert v.digest(path)==identity
    tags=v.read_native(path)
    states,stations=v.verified_states(tags)
    state=states[name]
    return state,stations[name],physical(v,state,stations[name])


def solve(data,radius,parts,ultimate=False):
    v,J,r,G,S,surfaces,cap,err,tau=data
    step=np.r_[np.full(56,1e-9),np.full(4,1e-3)]
    g=-r[-4:]/v.MODULUS/1e-9
    eq=np.c_[G*step/1e-9,np.zeros(4)]
    stress=1e-4
    X=np.vstack(list(J.values()))*step/stress
    p=np.tile(r,len(J))/stress
    error=np.tile(err,len(J))/stress
    ub=[]
    b=[]
    if ultimate:
        ub.extend(np.c_[X,np.zeros(len(X))])
        ub.extend(np.c_[-X,np.zeros(len(X))])
        b.extend(tau/stress-p-error)
        b.extend(tau/stress+p-error)
    else:
        ub.extend(np.c_[X,-np.ones(len(X))])
        ub.extend(np.c_[-X,-np.ones(len(X))])
        b.extend(-p-error)
        b.extend(p-error)
    efforts=np.vstack([M[56:62] for M in J.values()])*step/stress
    ub.extend(np.c_[efforts,np.zeros(len(efforts))])
    ub.extend(np.c_[-efforts,np.zeros(len(efforts))])
    b.extend(np.tile(cap-r[56:62]-err[56:62],len(J))/stress)
    b.extend(np.tile(cap+r[56:62]-err[56:62],len(J))/stress)
    masks=[np.ones(60)]
    center=np.r_[np.ones(52),np.zeros(4),np.ones(4)]
    grad=1-center
    if parts:
        masks.extend((center,grad))
    for mask in masks:
        if radius is not None or ultimate:
            sh=S*(step*mask)/1e-9
            column=-np.ones(len(S)) if ultimate else np.zeros(len(S))
            ub.extend(np.c_[sh,column])
            ub.extend(np.c_[-sh,column])
            b.extend(np.full(2*len(S),0. if ultimate else radius/1e-9))
        for key,F,n in surfaces:
            # Retain half the measured signed distance to the surface, independently for the split probes.
            mat=-np.sign(F)*n*step*mask/.001
            ub.append(np.r_[mat,0.])
            b.append((.5*abs(F)-2.1e-8)/.001)
    objective=np.r_[np.zeros(60),1.]
    result=linprog(objective,A_ub=np.array(ub),b_ub=np.array(b),A_eq=eq,b_eq=g,
                   bounds=[(None,None)]*60+[(0,None)],method="highs",
                   options={"dual_feasibility_tolerance":1e-9,"primal_feasibility_tolerance":1e-9})
    if not result.success:
        return {"radius":radius,"parts":parts,"ultimate":ultimate,"status":result.message}
    x=result.x[:-1]*step
    evaluated={name:r+M@x for name,M in J.items()}
    if ultimate:
        return {"ultimate":True,"parts":parts,"minimum_component_strain_radius":float(result.fun*1e-9),
            "condition_of_estimate":"local four-model algebraic screen, no certified reachable physical path"}
    amount=max(max(abs(z)+err) for z in evaluated.values())
    wide=float((max(abs(r))-amount)/tau)
    if abs(amount-result.fun*stress)>=5e-12:
        return {"radius":radius,"parts":parts,"status":"linear optimizer postcheck failure",
                "primal_norm_mismatch_MPa":float(amount-result.fun*stress)}
    directions={"center":x*center,"gradient":x*grad,"joint":x}
    effect={}
    for tag,d in directions.items():
        vectors={name:list(r+M@d) for name,M in J.items()}
        effect[tag]={"dq":list(d),"predictions":vectors,"radius":float(max(abs(S@d))),
             "base_55_change_MPa":list((M@d)[54] for M in J.values()),
             "base_N_change_N":list((M@d)[56]*v.AREA for M in J.values())}
    return {"radius":radius,"parts":parts,"upper_norm_MPa":float(amount),"gain_over_tau":wide,"predicted":effect}


def main(root,out):
    evt=root/"event"
    sys.path[:0]=[str(evt),str(root/"force-lock/Run")]
    import VerifyBase as v
    import PlanFresh as model
    assert v.digest(evt/"MVT2SeparatedEventsNative20261116.zip")==PIN
    event,stations,r=load(v,evt,"NormalsHalf","NativeHalf/MVT2.csv",EVENT)
    bg,p,rp=load(v,root/"forceN","ForceHalf","NativeHalf/MVT2.csv",NORMAL)
    older,ox,ro=load(v,root/"force15","LockedFull","NativeHalf/MVT2.csv",FORCE)
    n=v.read(root/"forceN/VerificationHalf.json")
    cfg=v.read(root/"forceN/ForceProbe.json")
    assert event["q"]==bg["q"]==older["q"]
    tg=v.read_native(root/"force-lock/Run/NativeA/MVT2.csv")
    old,ost=v.verified_states(tg)
    stock=old["Reacted"]
    S=model.strain_matrix(event["geometry"])
    original,G,_=model.assembled(tg,physical(v,stock,ost["Reacted"]),stock,event["geometry"],event["q"])
    modes={name:original[name] for name in ("Consistent","Refined")}
    D=np.stack([v.diff(bg["field"],older["field"]),v.diff(event["field"],bg["field"])]).T
    Y=np.stack([rp-ro,r-rp]).T
    W=S@D
    K=np.linalg.pinv(W,rcond=1e-10)@S
    SC=S[:,:52]
    KC=np.linalg.pinv(SC@D[:52],rcond=1e-10)@SC
    for key,M in tuple(modes.items()):
        A=M+(Y-M@D)@K
        A[56:62,:52]=M[56:62,:52]+(Y[56:62]-M[56:62,:52]@D[:52])@KC
        A[56:62,52:]=0.
        assert max(abs((A@D-Y).ravel()))<2e-12
        modes[key+"MeasuredSecants"]=A
    # Exact six-effort invariance for a pure spatial gradient is imposed on every model.
    for key,A in tuple(modes.items()):
        assert np.max(abs(A[56:62,52:]))<4e-7
        A[56:62,52:]=0.
    lookup={key:i for i,key in enumerate(event["geometry"])}
    surf=[]
    for row in n["station_branch_gradients"]:
        k=row["point"],row["side"]
        s=S[6*lookup[k]:6*(lookup[k]+1)].copy()
        s[3:]*=np.sqrt(2.)
        surface=float(stations[k][6])
        assert abs(surface-row["F_after_MPa"])<8e-10
        surf.append((k,surface,np.asarray(row["gradient_after"])@s))
    caps=np.array(cfg["original_caps_MPa"])
    defect=np.max([abs(r-np.array(a)) for a in cfg["predicted_half_all66_MPa"].values()],axis=0)
    clip=np.maximum(8e-10,defect)
    data=v,modes,r,G,S,surf,caps,clip,event["tol_MPa"]
    tries=[solve(data,bound,parts) for parts in (False,True) for bound in (5e-9,1e-8,2e-8,5e-8)]
    limit=[solve(data,None,parts,ultimate=True) for parts in (False,True)]
    screens={}
    for name,subset,sign,charge in (
        ("joint_4_modes_known_signs",modes,surf,clip),
        ("joint_4_modes_without_sign_constraints",modes,(),clip),
        ("one_consistent_mode_known_signs",{"Consistent":modes["Consistent"]},surf,clip),
        ("one_secant_mode_known_signs",{"ConsistentMeasuredSecants":modes["ConsistentMeasuredSecants"]},surf,clip),
    ):
        test=v,subset,r,G,S,sign,caps,charge,event["tol_MPa"]
        screens[name]={"minimum_norm":solve(test,1e-6,False),"minimum_radius_for_tau":solve(test,None,False,ultimate=True)}
    accepted=[]
    for item in tries:
        if item.get("parts") and item["radius"]<=2e-8 and item.get("gain_over_tau",0.)>=8.:
            c=item["predicted"]["center"]
            g=item["predicted"]["gradient"]
            if min(c["base_N_change_N"])>=5*event["tol_MPa"]*v.AREA and max(g["base_55_change_MPa"])<=-5*event["tol_MPa"]:
                accepted.append(item)
    choice=max(accepted,key=lambda x:x["gain_over_tau"],default=None)
    result={"source_event_trace_sha256":EVENT,"base_label":"NormalsHalf","base_field":event["field"],"base_norm_MPa":float(max(abs(r))),
        "base_all66_MPa":list(r),"q_trial_kN":event["q"],"q_accepted_kN":18.55811,"tau_MPa":event["tol_MPa"],
        "original_caps_MPa":list(caps),"history_prefix":v.digest(evt/"Replay.csv"),
        "measured_physical_direction_singular_values":list(np.linalg.svd(W,compute_uv=False)),
        "last_full_vector_actual_defect_MPa":list(clip),"tested_lot":tries,"local_tau_feasibility":limit,
        "wide_linear_screen_only":screens,
        "selected_joint_experiment":choice,"structure_obstruction_certified":False}
    out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(out,v.digest(out))
    for a in tries:
        print(a["parts"],a["radius"],a.get("gain_over_tau"),a.get("status"))
    print("limit",limit)
    if choice:
        print("N motion",choice["predicted"]["center"]["base_N_change_N"],"gradient row55 motion",choice["predicted"]["gradient"]["base_55_change_MPa"])


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    main(args.workspace.resolve(),args.output.resolve())
