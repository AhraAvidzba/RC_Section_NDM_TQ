MVT2 B HalfJoint: derivative identification and exact bounded trial

Stage A contains exact H24 accepted fields, the HalfJoint anchor and its
previous authoritative native trace, the 3 full native Jacobians and 75 signed
concrete surface gradients, two measured holdout actions, and exact gauge
projection. The concrete and steel parameter calls, geometry, stations and
history replay occur in the included native VBA modules.

Stage B contains the sealed candidate fields, predicted signed 66-row envelopes,
the original six force caps and prior discrepancy pads, the complete measured
weak residuals and stress/strain fields, plus the native force/branch gate.
The accepted H24 material state is replayed and restored exactly, so the tested
Qy=18.5720088671875 kN is a fixed trial and the last accepted Qy remains 18.55811
kN. None of these measurements imply an ultimate load or a changed material law.

Extract the archive to its own directory, then run:
    python -B -X utf8 VerifyPortable.py

Python standard library only. The script restores file aliases in a private
temporary directory, reruns the independent checks and requires exact report
values for each native stage. The zip stores each frozen byte sequence once.
The workbook itself is omitted. Replay uses the compiler/runner receipts for
the executed workbook identity. Re-execution of native macros additionally
requires the exact historical input workbook listed in Manifest.json, and a
authorized isolated Office slot. No input or output changes the material history.
