"""Reconstruct the two isolated evidence directories from the deduplicated bundle."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def execute(stage, suffix, expected, source):
    """Run exact checkers with the installed-workbook read replaced by owner receipts."""
    path = stage / "Verify-MVT2ShearControlled.py"
    script = path.read_text(encoding="utf-8")
    original = ('    assert v.digest(HERE/"workbook/output/RC_Section_NDM.xlsm")==prep["book_sha256"]'
                if suffix == "A" else
                '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]')
    assert script.count(original) == 1
    # The isolated compile and ownership receipts, checked by verify(), retain
    # both workbook SHA-256 values. The workbook bytes are outside the bundle.
    script = script.replace(original, f'    assert prep["book_sha256"] == "{source}"')
    environment = {"__file__": str(path), "__name__": "portable_verifier"}
    sys.path.insert(0, str(stage))
    sys.modules.pop("VerifyBase", None)
    try:
        exec(compile(script, str(path), "exec"), environment)
        report = environment["verify"](*environment["prepare"]())
    finally:
        sys.path.pop(0)
    actual = json.dumps(report, indent=2) + "\n"
    canonical = expected.read_text(encoding="utf-8")
    assert actual == canonical, expected
    print(f"Stage {suffix}: reproduced exact canonical report {digest(expected.read_bytes())}")


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "Manifest.json").read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory() as folder:
        scratch = Path(folder)
        for logical, record in manifest["logical_files"].items():
            source = root / record["stored_path"]
            assert digest(source.read_bytes()) == record["sha256"], source
            target = scratch / logical
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
        for folder, suffix, report in (("jet", "A", "VerificationA.json"), ("jetb", "B", "VerificationHalf.json")):
            stage = scratch / folder
            execute(stage, suffix, stage / report, manifest["source_book_sha256"])


if __name__ == "__main__":
    main()
