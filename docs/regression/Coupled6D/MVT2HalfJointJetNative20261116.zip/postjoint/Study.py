"""Quantify the remaining HalfJoint barrier with measured branch-cell actions."""
import argparse
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import sys
from zipfile import ZipFile

import numpy as np
from scipy.optimize import linprog

JOINT="47B975208823EF5563F76CB759F4FAED557529D0BCEA90CE4F503BCC1BE2029C"
NATIVE="E148698E4BD763828EB7131F49BE333424BC8B06EFF520674A9AAD5FAB763DB3"
NORMAL="84DAF40599AD0FE9A0AE1C2EBA2CF2F72DED306F0F47B222F1A0528216D50A86"
FORCE="AAF97ABED8510F390488F2A5C515E57431BED7ED56694181D2CD763F35A8900F"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def sources(work,out):
    output=out/"Files"
    output.mkdir(parents=True,exist_ok=True)
    for dirname,member,expected,files in (
        ("joint2","MVT2JointCenterGradientNative20261116.zip",JOINT,(
            ("VerifyBase.py","VerifyBase.py"),("JointPlan.json","JointPlan.json"),("NativeHalf/MVT2.csv","Joint.csv"))),
        ("forceN","MVT2MeasuredNormalsNative20261116.zip",NORMAL,(("NativeHalf/MVT2.csv","Normal.csv"),("VerificationHalf.json","NormalReport.json"))),
        ("force15","MVT2Force15Native20261116.zip",FORCE,(("NativeHalf/MVT2.csv","Force.csv"),)),
    ):
        inp=work/dirname/member
        assert digest(inp.read_bytes())==expected
        with ZipFile(inp) as archive:
            for original,dest in files:
                (output/dest).write_bytes(archive.read(original))
    assert digest((output/"Joint.csv").read_bytes())==NATIVE
    return output


def decode(v,where):
    current={}
    for identity,name in (("Joint","Joint.csv"),("Normal","Normal.csv"),("Force","Force.csv")):
        states,stations=v.verified_states(v.read_native(where/name))
        assert states["Base24"]==states["Restored24"] and stations["Base24"]==stations["Restored24"]
        for tag,state in states.items():
            if tag.endswith("24"):
                continue
            st=stations[tag]
            weak,_,_=v.reconstruct(state["field"],state["q"],st)
            rr=np.r_[state["r"],np.divide(weak[-4:],1./v.MODULUS)]
            current[identity+":"+tag]=(np.array(state["field"]),rr,st,state)
    return current


def strain(v,geometry):
    unit=np.eye(60)
    rows=[]
    g=np.zeros((4,60))
    for (p,side),(x,y,a) in geometry.items():
        operators=v.operators(x,y)
        local=np.array([v.strain_at(e,operators,side) for e in unit]).T
        local[3:]/=np.sqrt(2.)
        rows.extend(local)
        if side==0 and p<=25:
            _,B,xn,yn=operators
            for j,b in enumerate(B):
                w=a*b/v.AREA
                k=4+3*j
                for i in range(3):
                    g[i,k+i]+=w
                g[3,k]-=yn*w
                g[3,k+1]+=xn*w
    return np.asarray(rows),g


def actions(v,raw):
    surfaces=tuple(key for key in raw["Joint:HalfJoint"][2] if key[0]<=25)
    out={}
    pairs={
        "CenterFromGradient":("Joint:HalfGradient","Joint:HalfJoint"),
        "GradientFromCenter":("Joint:HalfCenter","Joint:HalfJoint"),
        "CenterFromBase":("Joint:NormalsHalf","Joint:HalfCenter"),
        "GradientFromBase":("Joint:NormalsHalf","Joint:HalfGradient"),
        "PreviousNormals":("Normal:ForceHalf","Normal:NormalsHalf"),
        "PreviousForce":("Force:LockedFull","Force:ForceHalf"),
    }
    for name,(a,b) in pairs.items():
        q,x,s,_=raw[a]
        t,y,sp,_=raw[b]
        flags=[key for key in surfaces if s[key][3:6]!=sp[key][3:6] or s[key][6]*sp[key][6]<=0.]
        out[name]=(t-q,y-x,np.array([sp[key][6]-s[key][6] for key in surfaces]),flags)
    return surfaces,out


def optimise(name,axes,records,S,G,r,F,caps,tau,radius,sign_reserve,safety,allow_reverse,stations):
    K=np.array([records[a][0] for a in axes]).T
    R=np.array([records[a][1] for a in axes]).T
    D=np.array([records[a][2] for a in axes]).T
    n=len(axes)
    scale=1e4
    reactions=np.zeros((66,4))
    reactions[:56]=G[:,:56].T
    # The two edge choices bound local interaction observed across the exact
    # previously measured center x gradient rectangle. Branch derivatives used
    # here come from the matching edge, not a tangent of the wrong material side.
    E=np.zeros_like(R)
    P=np.zeros_like(D)
    for k,a in enumerate(axes):
        if a=="CenterFromGradient":
            other="CenterFromBase"
        elif a=="GradientFromCenter":
            other="GradientFromBase"
        else:
            continue
        E[:,k]=abs(R[:,k]-records[other][1])
        P[:,k]=abs(D[:,k]-records[other][2])
    R0=np.c_[R, -R, reactions/scale] *scale
    err=np.c_[E,E,np.zeros((66,4))]*scale*safety
    physical=np.c_[S@K,-S@K,np.zeros((len(S),4))]/1e-9
    signed=np.c_[D,-D,np.zeros((len(F),4))]
    signed_error=np.c_[P,P,np.zeros((len(F),4))]*safety
    force=R0[56:62]
    force_err=err[56:62]
    a=np.r_[R0+err,-R0+err,force+force_err,-force+force_err,physical,-physical]
    b=np.r_[-r*scale,r*scale,(caps-r[56:62])*scale,(caps+r[56:62])*scale,
            np.repeat(radius/1e-9,2*len(S))]
    surface_start=len(b)
    if sign_reserve is not None:
        a=np.r_[a,(-np.sign(F)[:,None]*signed+signed_error)/.001]
        b=np.r_[b,(np.abs(F)*(1-sign_reserve)-8e-10)/.001]
    epi=np.r_[-np.ones(2*len(r)),np.zeros(len(b)-2*len(r))]
    A=np.c_[a,epi]
    objective=np.r_[np.zeros(2*n+4),1.]
    bounds=[(0.,None)]*n+([(0.,None)]*n if allow_reverse else [(0.,0.)]*n)+[(None,None)]*4+[(0.,None)]
    solved=linprog(objective,A_ub=A,b_ub=b,bounds=bounds,method="highs",
                   options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
    if not solved.success:
        return {"name":name,"terminal":solved.message}
    assert max(A@solved.x-b)<1e-8 and abs(solved.fun-b@solved.ineqlin.marginals)<1e-8
    z=solved.x[:-1]
    weights=z[:n]-z[n:2*n]
    q=K@weights
    q[56:]+=z[2*n:]/scale
    f=F+D@weights
    predicted=r+R0@z/scale
    norm=max(abs(predicted)+err@z/scale)
    assert abs(norm-solved.fun/scale)<4e-12
    dual=solved.ineqlin.marginals
    active=[] if sign_reserve is None else [
        {"station":point,"shadow_modal_weight":float(d),"F_current_MPa":F[i],"F_model_next_MPa":f[i]}
        for i,(point,d) in enumerate(zip(stations,dual[surface_start:],strict=True)) if abs(d)>1e-9]
    lo,hi=dual[2*len(r):2*len(r)+6],dual[2*len(r)+6:2*len(r)+12]
    return {"name":name,"trust_radius":radius,"surface_reserve_fraction":sign_reserve,
            "bounds":"signed trial surface at all 75 concrete stations, all six caps, exact strain map",
            "norm_MPa":float(norm),"remaining_tau":float(norm/tau),"gain_tau":float((max(abs(r))-norm)/tau),
            "total_coefficients_abs":float(sum(abs(weights))),
            "weights":{a:float(c) for a,c in zip(axes,weights,strict=True) if abs(c)>1e-10},
            "physical_radius":float(max(abs(S@q))),"dq":list(q),
            "minimum_scaled_signed_surface_margin":float(min(f*np.sign(F)/abs(F))),
            "force_caps_reserve_MPa":list(caps-abs(predicted[56:62])-force_err@z/scale),
            "active_signed_station_limits":active,"active_force_cap_duals":[[i+1,a,b] for i,(a,b) in
             enumerate(zip(lo,hi,strict=True)) if max(abs(a),abs(b))>1e-9],
            "active_equations":[(int(k)+1,float(predicted[k])) for k in np.argsort(-np.abs(predicted))[:8]]}


def main(work,out):
    prepared=sources(work,out)
    sys.path.insert(0,str(prepared))
    import VerifyBase as v
    raw=decode(v,prepared)
    keys,record=actions(v,raw)
    Q,r,station,base=raw["Joint:HalfJoint"]
    assert np.argmax(np.abs(r))==56 and abs(r[0]-r[56])<1e-12
    S,G=strain(v,base["geometry"])
    F=np.array([station[key][6] for key in keys])
    cap=np.array(v.read(prepared/"JointPlan.json")["original_caps_MPa"])
    n=base["tol_MPa"]
    first=("CenterFromGradient","GradientFromCenter")
    extended=(*first,"PreviousNormals","PreviousForce")
    ret={}
    for radius in (1.e-8,2.e-8,4.e-8,8.e-8):
        for label,subset,reverse in (("measured_rect",first,False),("four_action",extended,True)):
            risk={k:record[k][3] for k in subset}
            assert not any(risk.values()),risk
            key=f"{label}:{radius:g}"
            ret[key]=optimise(key,subset,record,S,G,r,F,cap,n,radius,.5,1.,reverse,keys)
    for mode in (0.,None):
        key=f"four_action:80e-9:branch_reserve_{mode}"
        ret[key]=optimise(key,extended,record,S,G,r,F,cap,n,8e-8,mode,1.,True,keys)
    opposite={key:{"plus_minus_signed_actions":list(record[key][1][56:62]*v.SCALES),
        "q55_effect_MPa":float(record[key][1][54]),"branches_changed":record[key][3]} for key in record}
    rows=[{"index":int(i)+1,"signed_MPa":float(r[i])} for i in np.argsort(-np.abs(r))[:18]]
    result={"base_trace_sha256":NATIVE,"force_target_Qy_kN":base["q"],"tau_MPa":n,"full_norm_MPa":float(max(abs(r))),
        "floor_when_only_spatial_gradients_and_gauge_reactions_change_MPa":float(max(abs(r[56:62]))),
        "active_native_rows":rows,"action_records":opposite,
        "axial_center_increase_required_for_15tau_N":float(15*n*v.AREA),
        "current_branch_all_75_measured_action_feasibility":ret,
        "structural_failure_claimed":False}
    dest=out/"Study.json"
    dest.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(dest,digest(dest.read_bytes()))
    for key,item in ret.items():
        print(key,item.get("gain_tau"),item.get("weights"),item.get("terminal"))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("scratch_observations",type=Path)
    p.add_argument("out",type=Path)
    a=p.parse_args()
    main(a.scratch_observations.resolve(),a.out.resolve())
