"""Verify the bounded native Jet measurements, including the conditional second probe."""
import argparse
import json
from pathlib import Path

import VerifyBase as v


here = Path(__file__).resolve().parent
native = here / "NativeHalf"
labels = ("JetFirst", "JetNext")


def read_rows(name):
    return [line.split(";") for line in (here / name).read_text(encoding="ascii").splitlines()]


def prepare():
    prep = v.read(here / "Preparation.json")
    assert all(v.digest(here / name) == expected for name, expected in prep["inputs"].items())
    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]
    assert v.digest(here / "Replay.csv") == prep["replay_sha256"]
    screen = v.read(here / "JetScreen.json")
    identified = v.read(here / "JetIdentification.json")
    assert v.digest(here / "JetNative.csv") == screen["native_trace_sha256"] == identified["trace_sha256"]
    assert identified["exact_H24_rollback"] and not identified["history_published"]
    prior = v.read(here / "JointPlan.json")
    assert screen["original_cap_MPa"] == prior["original_caps_MPa"]
    assert identified["H24_sha256"] == prep["replay_sha256"]
    [gate] = read_rows("Gate.csv")
    tau, witness, *limits = map(float, gate)
    caps = limits[:6]
    pads = limits[6:]
    assert tau == screen["original_tau_MPa"] and witness == screen["witness_tangent_error_MPa"]
    assert caps == screen["original_cap_MPa"] and pads == prior["last_full_vector_actual_defect_MPa"][:62] + [0.] * 4
    anchors, stations = v.verified_states(v.read_native(here / "JetNative.csv"))
    anchor = anchors["HalfJoint"]
    [old] = read_rows("AnchorField.csv")
    assert tuple(map(float, old)) == anchor["field"]
    assert anchor["q"] == screen["anchor_q_kN"] == 18.5720088671875
    assert abs(max(map(abs, full(anchor, stations["HalfJoint"]))) - identified["base_norm_MPa"]) < 2e-14
    candidates = {}
    for name, radius in zip(labels, (1e-8, 2e-8), strict=True):
        [trial] = [item for item in screen["trials"] if item["radius"] == radius]
        pred = trial["predicted"]["joint"]
        [[label, radius_text, *terms]] = read_rows(name + ".csv")
        assert name == label and float(radius_text) == radius and list(map(float, terms)) == pred["dq"]
        dq = tuple(map(float, terms))
        peak = v.tensor_radius(dq, anchor["geometry"])
        assert abs(peak - radius) <= 4e-16
        bounds = [tuple(map(float, row)) for row in read_rows(name + "Envelope.csv")]
        assert bounds == [(min(a, b), max(a, b)) for a, b in zip(pred["predictions"]["Consistent"], pred["predictions"]["Refined"], strict=True)]
        candidates[name] = (dq, bounds)
    return prep, anchor, tau, witness, caps, pads, candidates


def full(state, stations):
    rows, _, _ = v.reconstruct(state["field"], state["q"], stations)
    return (*state["r"], *(v.MODULUS * term for term in rows[-4:]))


def verify(prep, anchor, tau, witness, caps, pads, candidates):
    build = v.read(here / "docs/regression/CodeUpdate.json")
    compiler = v.read(here / "CompileClosure.json")
    owner = v.read(native / "MVT2.txt.Ownership.json")
    watcher = v.read(native / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(native / "RunReceipt.json")
    final = watcher["Closure"]["FinalState"]
    assert build["Compiled"] and build["Modules"] == ["modTestCoupledExperiment"] and not build["ProductionChanged"]
    assert build["ProductionSHA256"] == prep["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == build["WorkbookSHA256"]
    assert watcher["Passed"] and watcher["ChildExitCode"] == receipt["native_exit"] == 0 and watcher["ChildHasExited"]
    assert final["State"] == "Absent" and final["PID"] == owner["PID"] and final["StartTicksUTC"] == owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (native / "MVT2.txt").read_text(encoding="utf-8-sig")

    trace = native / "MVT2.csv"
    tags = v.read_native(trace)
    states, stations = v.verified_states(tags)
    history = v.vec(tags, "MVT2_CONTROL_FIELD")
    for i, replay in enumerate(read_rows("Replay.csv")[1:], 1):
        assert int(replay[0]) == i and v.peak(v.diff(tuple(map(float, replay[9:])), history[f"Replay{i}"])) < 1e-15
    assert i == len(history) == 24
    assert states["Restored24"] == states["Base24"] and stations["Restored24"] == stations["Base24"]
    assert states["Base24"]["field"] == history["Replay24"]
    assert states["HalfJoint"]["field"] == anchor["field"]
    assert states["HalfJoint"]["q"] == anchor["q"] and states["Base24"]["q"] == 18.55811
    assert tags["B_FRESH_PHASE"] == [["Half"]]
    steel = v.verify_steel(tags, states, stations, history)
    reference = full(states["HalfJoint"], stations["HalfJoint"])
    baseline_norm = v.peak(reference)

    def changes(name):
        original = stations["HalfJoint"]
        revised = stations[name]
        return [key for key in original if key[0] <= 25 and
                (original[key][3:6] != revised[key][3:6] or original[key][6] * revised[key][6] <= 0.)]

    report = {}
    for name in labels:
        if name not in states:
            continue
        solution = states[name]
        assert solution["q"] == anchor["q"] and solution["geometry"] == anchor["geometry"]
        dq, bounds = candidates[name]
        assert v.peak(v.diff(solution["field"], tuple(a + b for a, b in zip(anchor["field"], dq, strict=True)))) < 3e-15
        residual = full(solution, stations[name])
        defects = [max(0., lo - x, x - hi) for x, (lo, hi) in zip(residual, bounds, strict=True)]
        report[name] = {"all66_MPa": residual, "norm_MPa": v.peak(residual), "signed_six_N_Nmm": solution["signed_force_N_Nmm"],
                        "all_six_caps": all(abs(x) <= cap for x, cap in zip(residual[56:62], caps, strict=True)),
                        "beyond_predicted_envelope_MPa": defects, "changed_branches": changes(name), "steel_max_MPa": steel[name],
                        "gain_over_original_tau": (baseline_norm - v.peak(residual)) / tau}
    [[norm, branch, cap_ok, first_defect]] = tags["B_JET_FIRST"]
    first = report.get("JetFirst")
    if first is None:
        assert float(norm) < 0 and int(branch) == int(cap_ok) == 0
    else:
        assert abs(float(norm) - first["norm_MPa"]) <= 4e-10
        assert (int(branch) == 1) == (not first["changed_branches"])
        assert (int(cap_ok) == 1) == first["all_six_caps"]
        assert abs(float(first_defect) - max(first["beyond_predicted_envelope_MPa"])) <= 4e-10
    defects = first["beyond_predicted_envelope_MPa"] if first else [0.] * 66
    next_envelope = candidates["JetNext"][1]
    upper = [max(abs(lo), abs(hi)) + max(pad, 2. * defect)
             for (lo, hi), pad, defect in zip(next_envelope, pads, defects, strict=True)]
    [[opened, forecast, cap_ratio, next_branch]] = tags["B_JET_GATE"]
    assert abs(float(forecast) - max(upper)) <= 8e-10
    assert abs(float(cap_ratio) - max(x / cap for x, cap in zip(upper[56:62], caps, strict=True))) <= 8e-10 / min(caps)
    qualifies = (first is not None and int(branch) and int(cap_ok) and float(norm) <= baseline_norm - 5 * tau + 4e-10
                 and float(first_defect) <= witness and float(cap_ratio) <= 1 and float(forecast) <= float(norm) - tau)
    assert bool(int(opened)) == bool(qualifies and int(next_branch))
    if int(opened):
        assert "JetNext" in report or ["JetNext", "Residual"] in tags["B_TANGENT_UNAVAILABLE"]
    else:
        assert "JetNext" not in report and ["JetNext", "Residual"] not in tags["B_TANGENT_UNAVAILABLE"]
    q_probed = anchor["q"]
    return {"source_book_sha256": prep["book_sha256"], "trace_sha256": v.digest(trace), "H24_sha256": prep["replay_sha256"],
            "history_exactly_restored": True, "history_published": False, "tested_Qy_kN": q_probed, "wall_seconds": receipt["wall_seconds"],
            "compiler": compiler, "owner_closed": final, "baseline_norm_MPa": baseline_norm, "original_tau_MPa": tau,
            "original_caps_MPa": caps, "second_gate": bool(int(opened)), "gate_projected_upper_MPa": float(forecast),
            "gate_projected_cap_ratio": float(cap_ratio), "candidate_measures": report, "capacity_claimed": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Half"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS", v.digest(here / "Preparation.json"))
    else:
        assert args.phase == "Half"
        output = here / "VerificationHalf.json"
        output.write_text(json.dumps(verify(*frozen), indent=2) + "\n", encoding="utf-8")
        print(output, v.digest(output))
