
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает первый фактический отклик. Второе поле допускается после проверки
' исходных шести невязок, ветвей и двух независимых линейных прогнозов.
Private Sub ProbeWangJetFieldsTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByRef anchor() As Double, ByVal factor As Double, ByVal originNorm As Double)
    Dim raw As String, values As Variant, file As Integer, k As Long
    Dim gateTau As Double, witnessError As Double, area As Double, length As Double
    Dim demand(1 To 6) As Double, effortScale(1 To 6) As Double, cap(1 To 6) As Double
    Dim pad(1 To 66) As Double, defects(1 To 66) As Double
    file = FreeFile
    Open folder & "Gate.csv" For Input As #file
    Line Input #file, raw
    If Not EOF(file) Then Err.Raise 5, , "Лишняя строка критерия MVT2."
    Close #file
    values = Split(raw, ";")
    If UBound(values) <> 73 Then Err.Raise 5, , "Неполный критерий второго поля MVT2."
    gateTau = Val(values(0)): witnessError = Val(values(1))
    operators.CopyResultantResidualScales area, length
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For k = 1 To 6
        cap(k) = Val(values(1 + k)): effortScale(k) = area
        If k >= 2 And k <= 4 Then effortScale(k) = area * length
    Next k
    For k = 1 To 66: pad(k) = Val(values(7 + k)): Next k

    Dim field() As Double, actual() As Double, weak() As Double
    Dim firstLo(1 To 66) As Double, firstHi(1 To 66) As Double
    ReadWangJointInputTest output, folder & "JetFirst.csv", "JetFirst", operators, anchor, field
    ReadWangJetEnvelopeTest folder & "JetFirstEnvelope.csv", firstLo, firstHi
    RestoreWangShearBaselineTest solver, history, base
    Dim firstNorm As Double, branchOK As Boolean, forceOK As Boolean, firstDefect As Double, term As Double
    firstNorm = RecordWangTangentStateTest(output, "JetFirst", 24, factor, solver, operators, materials, responses, field, actual, weak)
    If firstNorm >= 0# Then
        branchOK = CheckWangJointBranchesTest(operators, materials, anchor, field)
        forceOK = True
        For k = 1 To 66
            Select Case k
                Case 1 To 56: term = weak(k)
                Case 57 To 62
                    term = (actual(k - 56) - demand(k - 56)) / effortScale(k - 56)
                    If Abs(term) > cap(k - 56) Then forceOK = False
                Case Else: term = 30000# * weak(k - 6)
            End Select
            defects(k) = GeomMax(0#, GeomMax(firstLo(k) - term, term - firstHi(k)))
            firstDefect = GeomMax(firstDefect, defects(k))
        Next k
    End If
    RequireWangAcceptedFieldTest solver, base
    Print #output, "B_JET_FIRST;" & ExperimentNumberTest(firstNorm) & ";" & _
        CStr(Abs(CLng(branchOK))) & ";" & CStr(Abs(CLng(forceOK))) & ";" & ExperimentNumberTest(firstDefect)

    Dim secondLo(1 To 66) As Double, secondHi(1 To 66) As Double
    Dim upper As Double, forecastNorm As Double, forecastCapRatio As Double, adjusted As Double, secondBranch As Boolean
    ReadWangJetEnvelopeTest folder & "JetNextEnvelope.csv", secondLo, secondHi
    For k = 1 To 66
        adjusted = GeomMax(pad(k), 2# * defects(k)) ' Радиус второго поля удвоен, запас проверяется по каждой строке.
        upper = GeomMax(Abs(secondLo(k)), Abs(secondHi(k))) + adjusted
        forecastNorm = GeomMax(forecastNorm, upper)
        If k >= 57 And k <= 62 Then forecastCapRatio = GeomMax(forecastCapRatio, upper / cap(k - 56))
    Next k
    Dim openNext As Boolean
    openNext = (firstNorm >= 0# And firstNorm <= originNorm - 5# * gateTau And branchOK And forceOK And _
        firstDefect <= witnessError And forecastCapRatio <= 1# And forecastNorm <= firstNorm - gateTau)
    If openNext Then
        ReadWangJointInputTest output, folder & "JetNext.csv", "JetNext", operators, anchor, field
        RestoreWangShearBaselineTest solver, history, base
        secondBranch = CheckWangJointBranchesTest(operators, materials, anchor, field)
        openNext = secondBranch
    End If
    Print #output, "B_JET_GATE;" & CStr(Abs(CLng(openNext))) & ";" & ExperimentNumberTest(forecastNorm) & ";" & _
        ExperimentNumberTest(forecastCapRatio) & ";" & CStr(Abs(CLng(secondBranch)))
    If openNext Then
        Dim nextNorm As Double
        nextNorm = RecordWangTangentStateTest(output, "JetNext", 24, factor, solver, operators, materials, responses, field, actual, weak)
        RequireWangAcceptedFieldTest solver, base
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает два независимых прогноза с общими единицами для всех 66 строк.
Private Sub ReadWangJetEnvelopeTest(ByVal path As String, ByRef lower() As Double, ByRef upper() As Double)
    Dim file As Integer, raw As String, values As Variant, k As Long
    file = FreeFile: Open path For Input As #file
    For k = 1 To 66
        Line Input #file, raw
        values = Split(raw, ";")
        If UBound(values) <> 1 Then Err.Raise 5, , "Неполный прогноз невязки MVT2."
        lower(k) = Val(values(0)): upper(k) = Val(values(1))
        If lower(k) > upper(k) Then Err.Raise 5, , "Неверные границы прогноза MVT2."
    Next k
    If Not EOF(file) Then Err.Raise 5, , "Лишние строки прогноза MVT2."
    Close #file
End Sub
