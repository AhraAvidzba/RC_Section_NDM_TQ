"""Seal the two permitted HalfJoint fields from the independently verified local screen."""
from hashlib import sha256
import json
from pathlib import Path


here = Path(__file__).resolve().parent
jet = here.parent / "jet"
joint = here.parent / "joint2"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, raw):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def row(values):
    return (";".join(str(x) for x in values) + "\r\n").encode("ascii")


pins = {
    "JetScreen.json": (jet / "JetScreen.json", "601C971098FCD484A951EEF0F280CCD9E08A2423487463B8710920520C692512"),
    "JetIdentification.json": (jet / "VerificationA.json", "4956ABC4270797927AAC8ACDBC2A105DA3FF33F37A8306BACD67B647F039990E"),
    "JetNative.csv": (jet / "NativeA/MVT2.csv", "7CE6747FEE67165BB6642A710D10EA8F5471DFAF22893B7BEAB5AF58B67F276F"),
    "JointPlan.json": (joint / "JointPlan.json", "94793E28775B91FD46CCBE9F552A911D83773DB9A32006FBA436F758A0D4FB20"),
}
inputs = {}
for name, (source, expected) in pins.items():
    raw = source.read_bytes()
    assert digest(raw) == expected, source
    inputs[name] = save(name, raw)
prep = json.loads((jet / "Preparation.json").read_text(encoding="utf-8"))
for name in ("Replay.csv", "VerifyBase.py", "Guard-IsolatedOffice.ps1", "AnchorField.csv", "ArchiveOrigin.csv",
             *(name for name in prep["inputs"] if name.startswith("tools/"))):
    raw = (jet / name).read_bytes()
    assert digest(raw) == prep["inputs"][name], name
    inputs[name] = save(name, raw)

book = "workbook/output/RC_Section_NDM.xlsm"
raw = (jet / book).read_bytes()
assert digest(raw) == prep["book_sha256"]
save(book, raw)
save("docs/regression/Diagnostic.xlsm", raw)
for name in ("src", "Temp", "NativeHalf"):
    (here / name).mkdir(exist_ok=True)

screen = json.loads((here / "JetScreen.json").read_text(encoding="utf-8"))
prior = json.loads((here / "JointPlan.json").read_text(encoding="utf-8"))
pads = prior["last_full_vector_actual_defect_MPa"][:]
pads[-4:] = [0.] * 4
inputs["Gate.csv"] = save("Gate.csv", row((screen["original_tau_MPa"], screen["witness_tangent_error_MPa"],
                                          *screen["original_cap_MPa"], *pads)))
for name, radius, minimum_gain in (("JetFirst", 1e-8, 5.), ("JetNext", 2e-8, 7.)):
    [trial] = [item for item in screen["trials"] if item["radius"] == radius]
    assert not trial["parts"] and trial["gain_over_tau"] >= minimum_gain
    assert trial["minimum_retained_surface_fraction"] >= .5
    data = trial["predicted"]["joint"]
    inputs[name + ".csv"] = save(name + ".csv", row((name, radius, *data["dq"])))
    pairs = zip(data["predictions"]["Consistent"], data["predictions"]["Refined"], strict=True)
    envelope = b"".join(row((min(a, b), max(a, b))) for a, b in pairs)
    assert envelope.count(b"\r\n") == 66
    inputs[name + "Envelope.csv"] = save(name + "Envelope.csv", envelope)

control = (jet / "Control.bas").read_text(encoding="utf-8")
assert digest((jet / "Control.bas").read_bytes()) == prep["inputs"]["Control.bas"]
old = "    ProcessWangFreshReactedTest output, folder, phase, history, solver, operators, materials, responses, base, anchor, qTrial"
assert control.count(old) == 1
control = control.replace(old, '''    If phase <> "Half" Then Err.Raise 5, , "Неизвестная фаза измерения MVT2."
    ProbeWangJetFieldsTest output, folder, history, solver, operators, materials, responses, base, anchor, qTrial, norm''')
start = control.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, control.index("Private Sub ProcessWangFreshReactedTest"))
end = control.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, control.index("Private Sub CheckWangEventOriginTest"))
control = control[:start] + control[end:]
joint_source = (joint / "NativeJoint.bas").read_bytes()
assert digest(joint_source) == "319CC216C008260BFE9D135EAD42AA85315A91C292F595F418CF372A5B3F1052"
tail = joint_source.decode("utf-8").replace("\r\n", "\n")
start = tail.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, tail.index("Private Sub ReadWangJointInputTest"))
control += (here / "Probe.bas").read_text(encoding="utf-8") + tail[start:]
inputs["Control.bas"] = save("Control.bas", control.encode("utf-8"))
source = "tests/modTestCoupledExperiment.bas"
raw = (jet / source).read_bytes()
assert digest(raw) == prep["inputs"][source]
module = raw.decode("utf-8").replace("\r\n", "\n")
start = module.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, module.index("Public Function RunTestWangShearControlled("))
inputs[source] = save(source, (module[:start] + control).replace("\n", "\r\n").encode("utf-8"))
runner = (joint / "Run-MVT2ShearControlled.ps1").read_text(encoding="utf-8")
inputs["Run-MVT2ShearControlled.ps1"] = save("Run-MVT2ShearControlled.ps1", runner.encode("utf-8"))
for name in ("Stage.py", "Probe.bas", "Verify-MVT2ShearControlled.py"):
    inputs[name] = digest((here / name).read_bytes())
output = {"inputs": inputs, "book_sha256": prep["book_sha256"], "replay_sha256": prep["replay_sha256"],
          "watchdog_seconds": 110}
print(save("Preparation.json", (json.dumps(output, indent=2) + "\n").encode("utf-8")))
