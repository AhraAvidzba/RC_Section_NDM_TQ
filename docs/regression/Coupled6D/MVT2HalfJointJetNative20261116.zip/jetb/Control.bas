' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает одинаковые деформации с двумя наборами множителей после проверки архивных полей MVT2 B.
Public Function RunTestWangShearControlled(ByVal replayPath As String, ByVal phase As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Const EC As Double = 30000#, NU As Double = 0.2, FT As Double = 2.10667357864589
    Const PEAK_STRAIN As Double = 0.0022, LOCALIZATION_LENGTH As Double = 125#
    concrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    plusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    response.Initialize operators, concrete, steel
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, response, EC, plusSide, minusSide
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim materials(-1 To 1) As CCoupledConcreteResponse, responses(-1 To 1) As ICoupledPointResponse
    Set materials(0) = concrete: Set materials(1) = plusConcrete: Set materials(-1) = minusConcrete
    Set responses(0) = response: Set responses(1) = plusSide: Set responses(-1) = minusSide
    Dim base() As Double, anchor() As Double, qBase As Double, qTrial As Double, norm As Double, folder As String
    Dim actual() As Double, referenceForces() As Double, residual() As Double
    folder = Left$(replayPath, InStrRev(replayPath, "\"))
    ReadWangFreshAnchorTest folder & "AnchorField.csv", anchor
    base = history(24): qBase = factors(24): qTrial = qBase + (qBase - factors(23)) / 64#
    Dim output As Integer: output = FreeFile
    Open tracePath For Append As #output
    Print #output, "B_TANGENT_LOAD;" & ExperimentNumberTest(qBase) & ";" & ExperimentNumberTest(qTrial)
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Base24", 24, qBase, solver, operators, materials, responses, base, actual, residual)
    Print #output, "B_FRESH_PHASE;" & phase
    norm = RecordWangTangentStateTest(output, "HalfJoint", 24, qTrial, solver, operators, materials, responses, anchor, referenceForces, residual)
    If norm <= 0# Then Err.Raise 5, , "Не воспроизведено измеренное исходное поле HalfJoint."
    CheckWangEventOriginTest output, folder & "ArchiveOrigin.csv", operators, residual, referenceForces, qTrial
    If phase <> "Half" Then Err.Raise 5, , "Неизвестная фаза измерения MVT2."
    ProbeWangJetFieldsTest output, folder, history, solver, operators, materials, responses, base, anchor, qTrial, norm
    RequireWangAcceptedFieldTest solver, base
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Restored24", 24, qBase, solver, operators, materials, responses, base, actual, residual)
    Print #output, "B_TANGENT_END;24;" & ExperimentNumberTest(qBase)
    Close #output
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    Dim problem As String: problem = Err.Source & " " & Err.Description
    On Error Resume Next
    If output > 0 Then Close #output
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Масштабирует одно и то же направление без изменения принятого поля решателя.
Private Sub AddWangTangentDirectionTest(ByRef base() As Double, ByRef direction() As Double, _
        ByVal amount As Double, ByRef target() As Double)
    Dim j As Long
    ReDim target(1 To UBound(base))
    For j = 1 To UBound(base): target(j) = base(j) + amount * direction(j): Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает вектор в инвариантной форме для независимой проверки.
Private Sub EmitWangTangentVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef values() As Double)
    Dim row As String, j As Long
    row = prefix
    For j = 1 To UBound(values): row = row & ";" & ExperimentNumberTest(values(j)): Next j
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет независимые центральные и боковые напряжения, признаки ветви и слабые строки.
Private Function RecordWangTangentStateTest(ByVal output As Integer, ByVal label As String, ByVal historyCount As Long, _
        ByVal factor As Double, ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef field() As Double, _
        ByRef actual() As Double, ByRef residual() As Double) As Double
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double
    Dim gradientRow As String, componentIndex As Long
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, grad(1 To 6) As Double
    Dim matrix() As Double, external() As Double, row As String, flag As Long
    Dim yielding As Boolean, principal As Long, substeps As Long, yieldValue As Double
    Dim concretePoint As ICoupledPointResponse, concreteStress(1 To 6) As Double, component As Long
    EmitWangTangentVectorTest output, "B_TANGENT_FIELD;" & label & ";" & CStr(historyCount) & ";" & _
        ExperimentNumberTest(factor), field
    RecordWangTangentStateTest = -1#
    If Not solver.TestEquilibriumLinearization(field, False, False, residual, matrix) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";Residual"
        Exit Function
    End If
    operators.LoadEquations 0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, external
    For i = 1 To UBound(residual): residual(i) = residual(i) - external(i): Next i
    EmitWangTangentVectorTest output, "B_TANGENT_RESIDUAL;" & label, residual
    Dim norm As Double, value As Double, demand(1 To 6) As Double
    ReDim actual(1 To 6)
    For i = 1 To UBound(residual)
        value = Abs(residual(i))
        If i > solver.PhysicalDegreeCount Then value = value * 30000#
        norm = GeomMax(norm, value)
    Next i
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For point = 1 To operators.PointCount
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, slope
        For side = -1 To 1
            For i = 1 To 6: station(i) = strain(i) + side * 0.001 * slope(i): Next i
            If responses(side).EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Не подтвержден станционный отклик MVT2 B. " & label
            If side = 0 Then
                actual(1) = actual(1) + area * stress(3)
                actual(2) = actual(2) + area * stress(3) * y
                actual(3) = actual(3) + area * stress(3) * x
                actual(4) = actual(4) + area * (x * stress(6) - y * stress(5))
                actual(5) = actual(5) + area * stress(5)
                actual(6) = actual(6) + area * stress(6)
            End If
            If point > operators.ConcretePointCount Then
                Set concretePoint = materials(side)
                If concretePoint.EvaluatePoint(point, station, concreteStress, tangent, ctmStressOnly, False) <> sfcNone Then _
                    Err.Raise 5, , "Не подтверждён бетон в поправке замещения арматуры MVT2 B. " & label
                component = 3 ' Продольные стержни имеют ось z.
                If point > operators.ConcretePointCount + 4 Then
                    If Abs(x) > Abs(y) Then component = 2 Else component = 1 ' Ось ветви параллельна стенке квадрата.
                End If
                Print #output, "B_BOUND_STEEL;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & CStr(component) & ";" & _
                    ExperimentNumberTest(station(component)) & ";" & ExperimentNumberTest(concreteStress(component)) & ";" & _
                    ExperimentNumberTest(stress(component) + concreteStress(component))
            End If
            flag = -1: principal = 0: substeps = -1: yieldValue = 0#
            If point <= operators.ConcretePointCount Then
                If Not materials(side).TryReadConcreteBranch(point, station, yielding, principal, substeps) Then _
                    Err.Raise 5, , "Недоступна ветвь бетона MVT2 B. " & label
                If Not materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=False) Then _
                    Err.Raise 5, , "Недоступна пробная поверхность бетона MVT2 B. " & label
                flag = Abs(CLng(yielding))
                If label = "HalfJoint" Then
                    gradientRow = "B_JET_SURFACE;" & CStr(point) & ";" & CStr(side)
                    If materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=True) Then
                        gradientRow = gradientRow & ";1;" & ExperimentNumberTest(yieldValue)
                        For componentIndex = 1 To 6
                            gradientRow = gradientRow & ";" & ExperimentNumberTest(grad(componentIndex))
                        Next componentIndex
                    Else
                        gradientRow = gradientRow & ";0;" & ExperimentNumberTest(yieldValue)
                    End If
                    Print #output, gradientRow
                End If
            End If
            row = "B_TANGENT_STATION;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area) & ";" & _
                CStr(flag) & ";" & CStr(principal) & ";" & CStr(substeps) & ";" & ExperimentNumberTest(yieldValue)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(station(i)): Next i
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(i)): Next i
            Print #output, row
        Next side
    Next point
    EmitWangTangentVectorTest output, "B_BOUND_ACTUAL;" & label, actual
    RecordWangTangentStateTest = GeomMax(norm, operators.ResultantResidualNorm(actual, demand))
    Print #output, "B_BOUND_NORM;" & label & ";" & ExperimentNumberTest(RecordWangTangentStateTest)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает наибольшую взвешенную компоненту тензора на всех 135 станциях.
Private Function WangBoundedTensorPeakTest(ByVal operators As CCoupledElasticState, ByRef direction() As Double) As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double
    Dim point As Long, side As Long, j As Long, s As Double, peak As Double
    For point = 1 To operators.PointCount
        operators.PointStrain point, direction, strain
        operators.AxialGradientAtPoint point, direction, slope
        For side = -1 To 1
            For j = 1 To 6
                s = Abs(strain(j) + side * 0.001 * slope(j))
                If j > 3 Then s = s / Sqr(2#)
                peak = GeomMax(peak, s)
            Next j
        Next side
    Next point
    WangBoundedTensorPeakTest = peak
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает 60 архивных координат BothSmall без добавления поля в историю.
Private Sub ReadWangFreshAnchorTest(ByVal path As String, ByRef field() As Double)
    Dim file As Integer, row As String, values As Variant, k As Long
    file = FreeFile: Open path For Input As #file
    Line Input #file, row
    Close #file
    values = Split(row, ";")
    If UBound(values) <> 59 Then Err.Raise 5, , "Неверный архив поля BothSmall."
    ReDim field(1 To 60)
    For k = 1 To 60: field(k) = Val(values(k - 1)): Next k
End Sub


' -------------------- ДЛЯ ТЕСТОВ --------------------
' Останавливает направленные пробы при расхождении отклика установленной книги с точным NormalsHalf.
Private Sub CheckWangEventOriginTest(ByVal output As Integer, ByVal path As String, ByVal operators As CCoupledElasticState, _
        ByRef residual() As Double, ByRef efforts() As Double, ByVal factor As Double)
    Dim file As Integer, row As String, values As Variant, i As Long, area As Double, sectionLength As Double
    Dim scales(1 To 6) As Double, demand(1 To 6) As Double, discrepancy As Double
    file = FreeFile: Open path For Input As #file
    Line Input #file, row
    If Not EOF(file) Then Err.Raise 5, , "Неверное число строк архивного отклика."
    Close #file
    values = Split(row, ";")
    If UBound(values) <> 65 Then Err.Raise 5, , "Неполный архив отклика NormalsHalf."
    operators.CopyResultantResidualScales area, sectionLength
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For i = 1 To 56
        discrepancy = GeomMax(discrepancy, Abs(residual(i) - Val(values(i - 1))))
    Next i
    For i = 1 To 6
        scales(i) = area
        If i >= 2 And i <= 4 Then scales(i) = area * sectionLength
        discrepancy = GeomMax(discrepancy, Abs((efforts(i) - demand(i)) / scales(i) - Val(values(55 + i))))
    Next i
    For i = 1 To 4
        discrepancy = GeomMax(discrepancy, Abs(30000# * residual(56 + i) - Val(values(61 + i))))
    Next i
    Print #output, "B_EVENT_ORIGIN;" & ExperimentNumberTest(discrepancy)
    If discrepancy > 0.0000000008 Then Err.Raise 5, , "Отклик установленной книги не совпал с точным NormalsHalf."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает первый фактический отклик. Второе поле допускается после проверки
' исходных шести невязок, ветвей и двух независимых линейных прогнозов.
Private Sub ProbeWangJetFieldsTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByRef anchor() As Double, ByVal factor As Double, ByVal originNorm As Double)
    Dim raw As String, values As Variant, file As Integer, k As Long
    Dim gateTau As Double, witnessError As Double, area As Double, length As Double
    Dim demand(1 To 6) As Double, effortScale(1 To 6) As Double, cap(1 To 6) As Double
    Dim pad(1 To 66) As Double, defects(1 To 66) As Double
    file = FreeFile
    Open folder & "Gate.csv" For Input As #file
    Line Input #file, raw
    If Not EOF(file) Then Err.Raise 5, , "Лишняя строка критерия MVT2."
    Close #file
    values = Split(raw, ";")
    If UBound(values) <> 73 Then Err.Raise 5, , "Неполный критерий второго поля MVT2."
    gateTau = Val(values(0)): witnessError = Val(values(1))
    operators.CopyResultantResidualScales area, length
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For k = 1 To 6
        cap(k) = Val(values(1 + k)): effortScale(k) = area
        If k >= 2 And k <= 4 Then effortScale(k) = area * length
    Next k
    For k = 1 To 66: pad(k) = Val(values(7 + k)): Next k

    Dim field() As Double, actual() As Double, weak() As Double
    Dim firstLo(1 To 66) As Double, firstHi(1 To 66) As Double
    ReadWangJointInputTest output, folder & "JetFirst.csv", "JetFirst", operators, anchor, field
    ReadWangJetEnvelopeTest folder & "JetFirstEnvelope.csv", firstLo, firstHi
    RestoreWangShearBaselineTest solver, history, base
    Dim firstNorm As Double, branchOK As Boolean, forceOK As Boolean, firstDefect As Double, term As Double
    firstNorm = RecordWangTangentStateTest(output, "JetFirst", 24, factor, solver, operators, materials, responses, field, actual, weak)
    If firstNorm >= 0# Then
        branchOK = CheckWangJointBranchesTest(operators, materials, anchor, field)
        forceOK = True
        For k = 1 To 66
            Select Case k
                Case 1 To 56: term = weak(k)
                Case 57 To 62
                    term = (actual(k - 56) - demand(k - 56)) / effortScale(k - 56)
                    If Abs(term) > cap(k - 56) Then forceOK = False
                Case Else: term = 30000# * weak(k - 6)
            End Select
            defects(k) = GeomMax(0#, GeomMax(firstLo(k) - term, term - firstHi(k)))
            firstDefect = GeomMax(firstDefect, defects(k))
        Next k
    End If
    RequireWangAcceptedFieldTest solver, base
    Print #output, "B_JET_FIRST;" & ExperimentNumberTest(firstNorm) & ";" & _
        CStr(Abs(CLng(branchOK))) & ";" & CStr(Abs(CLng(forceOK))) & ";" & ExperimentNumberTest(firstDefect)

    Dim secondLo(1 To 66) As Double, secondHi(1 To 66) As Double
    Dim upper As Double, forecastNorm As Double, forecastCapRatio As Double, adjusted As Double, secondBranch As Boolean
    ReadWangJetEnvelopeTest folder & "JetNextEnvelope.csv", secondLo, secondHi
    For k = 1 To 66
        adjusted = GeomMax(pad(k), 2# * defects(k)) ' Радиус второго поля удвоен, запас проверяется по каждой строке.
        upper = GeomMax(Abs(secondLo(k)), Abs(secondHi(k))) + adjusted
        forecastNorm = GeomMax(forecastNorm, upper)
        If k >= 57 And k <= 62 Then forecastCapRatio = GeomMax(forecastCapRatio, upper / cap(k - 56))
    Next k
    Dim openNext As Boolean
    openNext = (firstNorm >= 0# And firstNorm <= originNorm - 5# * gateTau And branchOK And forceOK And _
        firstDefect <= witnessError And forecastCapRatio <= 1# And forecastNorm <= firstNorm - gateTau)
    If openNext Then
        ReadWangJointInputTest output, folder & "JetNext.csv", "JetNext", operators, anchor, field
        RestoreWangShearBaselineTest solver, history, base
        secondBranch = CheckWangJointBranchesTest(operators, materials, anchor, field)
        openNext = secondBranch
    End If
    Print #output, "B_JET_GATE;" & CStr(Abs(CLng(openNext))) & ";" & ExperimentNumberTest(forecastNorm) & ";" & _
        ExperimentNumberTest(forecastCapRatio) & ";" & CStr(Abs(CLng(secondBranch)))
    If openNext Then
        Dim nextNorm As Double
        nextNorm = RecordWangTangentStateTest(output, "JetNext", 24, factor, solver, operators, materials, responses, field, actual, weak)
        RequireWangAcceptedFieldTest solver, base
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает два независимых прогноза с общими единицами для всех 66 строк.
Private Sub ReadWangJetEnvelopeTest(ByVal path As String, ByRef lower() As Double, ByRef upper() As Double)
    Dim file As Integer, raw As String, values As Variant, k As Long
    file = FreeFile: Open path For Input As #file
    For k = 1 To 66
        Line Input #file, raw
        values = Split(raw, ";")
        If UBound(values) <> 1 Then Err.Raise 5, , "Неполный прогноз невязки MVT2."
        lower(k) = Val(values(0)): upper(k) = Val(values(1))
        If lower(k) > upper(k) Then Err.Raise 5, , "Неверные границы прогноза MVT2."
    Next k
    If Not EOF(file) Then Err.Raise 5, , "Лишние строки прогноза MVT2."
    Close #file
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает замороженное приращение и проверяет его станционные тензоры.
Private Sub ReadWangJointInputTest(ByVal output As Integer, ByVal path As String, ByVal label As String, _
        ByVal operators As CCoupledElasticState, ByRef anchor() As Double, ByRef field() As Double)
    Dim file As Integer, row As String, values As Variant, k As Long
    Dim delta(1 To 60) As Double, radius As Double, actual As Double
    file = FreeFile: Open path For Input As #file
    Line Input #file, row
    If Not EOF(file) Then Err.Raise 5, , "Лишняя строка раздельной пробы."
    Close #file
    values = Split(row, ";")
    If UBound(values) <> 61 Or values(0) <> label Then Err.Raise 5, , "Неверное поле раздельной пробы."
    radius = Val(values(1))
    For k = 1 To 60: delta(k) = Val(values(1 + k)): Next k
    actual = WangBoundedTensorPeakTest(operators, delta)
    If actual > radius + 0.0000000000000004 Or radius > 0.0000000200000004 Then _
        Err.Raise 5, , "Приращение выходит за измеряемое поле."
    AddWangTangentDirectionTest anchor, delta, 1#, field
    Print #output, "B_JOINT_INPUT;" & label & ";" & ExperimentNumberTest(radius) & ";" & ExperimentNumberTest(actual)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет знаки пробной поверхности и фактические ветви по всем бетонным станциям.
Private Function CheckWangJointBranchesTest(ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef anchor() As Double, ByRef field() As Double) As Boolean
    Dim p As Long, side As Long, k As Long, f0 As Double, f1 As Double, plastic0 As Boolean, plastic1 As Boolean
    Dim sign0 As Long, sign1 As Long, sub0 As Long, sub1 As Long
    Dim a(1 To 6) As Double, da(1 To 6) As Double, b(1 To 6) As Double, db(1 To 6) As Double
    Dim pa(1 To 6) As Double, pb(1 To 6) As Double, unused(1 To 6) As Double
    For p = 1 To operators.ConcretePointCount
        operators.PointStrain p, anchor, a
        operators.AxialGradientAtPoint p, anchor, da
        operators.PointStrain p, field, b
        operators.AxialGradientAtPoint p, field, db
        For side = -1 To 1
            For k = 1 To 6
                pa(k) = a(k) + side * 0.001 * da(k): pb(k) = b(k) + side * 0.001 * db(k)
            Next k
            If Not materials(side).TryReadTrialYield(p, pa, f0, unused, needGradient:=False) Then Exit Function
            If Not materials(side).TryReadTrialYield(p, pb, f1, unused, needGradient:=False) Then Exit Function
            If f0 * f1 <= 0# Then Exit Function
            If Not materials(side).TryReadConcreteBranch(p, pa, plastic0, sign0, sub0) Then Exit Function
            If Not materials(side).TryReadConcreteBranch(p, pb, plastic1, sign1, sub1) Then Exit Function
            If plastic0 <> plastic1 Or sign0 <> sign1 Or sub0 <> sub1 Then Exit Function
        Next side
    Next p
    CheckWangJointBranchesTest = True
End Function
