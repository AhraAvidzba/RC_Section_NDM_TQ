"""Compare feasible local corrections using the freshly measured HalfJoint Jacobians."""

from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for dependency in ("postjoint", "joint2"):
    sys.path.append(str(ROOT / dependency))

from PlanJoint import solve
from Study import strain
import VerifyBase as v


def main():
    recorded = v.read(HERE / "VerificationA.json")
    tags = v.read_native(HERE / "NativeA/MVT2.csv")
    trace = HERE / "NativeA/MVT2.csv"
    assert v.digest(trace) == recorded["trace_sha256"]
    assert recorded["exact_H24_rollback"] and not recorded["history_published"]
    assert not (recorded["unavailable_tangents"] or recorded["unavailable_surface_gradients"])
    verify = runpy.run_path(str(HERE / "Verify-MVT2ShearControlled.py"))
    states, stations = v.verified_states(tags)
    base = states["HalfJoint"]
    tensors, gauges = strain(v, base["geometry"])
    projection = np.array([list(map(float, row[1:])) for row in tags["B_FRESH_PROJECTION"]])
    base_residual = np.array(verify["full"](base, stations["HalfJoint"]))
    assert max(abs(base_residual)) == recorded["base_norm_MPa"]

    matrices = {}
    for name, index, *row in tags["B_FRESH_MATRIX"]:
        matrices.setdefault(name, {})[int(index)] = tuple(map(float, row))
    robust = {}
    for name in ("Consistent", "Refined"):
        matrix = np.array([matrices[name][index] for index in range(1, 61)])
        robust[name] = np.vstack((matrix[:56], projection @ matrix[:56], matrix[56:] * v.MODULUS))

    positions = {key: index for index, key in enumerate(base["geometry"])}
    surfaces = []
    for p, side, valid, origin, *components in tags["B_JET_SURFACE"]:
        key = int(p), int(side)
        ix = positions[key]
        assert int(valid) and abs(float(origin) - stations["HalfJoint"][key][6]) < 4e-10
        operator = tensors[6 * ix:6 * (ix + 1)].copy()
        operator[3:] *= np.sqrt(2.)
        surfaces.append((key, float(origin), np.asarray(components, dtype=float) @ operator))
    assert len(surfaces) == 75

    prior = v.read(ROOT / "joint2/JointPlan.json")
    caps = np.asarray(prior["original_caps_MPa"])
    # Keep the original signed force padding and add measured witness error.
    # These local observations bound the forecast design, not a new physical branch.
    available = recorded["available_native_tangents"]
    max_check_error = max(check["max66_error_MPa"] for name in robust
                          for check in available[name]["two_witness_errors"].values())
    uncertainty = np.maximum(max_check_error, np.asarray(prior["last_full_vector_actual_defect_MPa"]))
    uncertainty[-4:] = 0.  # The gauge operators are exact linear equations.
    basis = v, robust, base_residual, gauges, tensors, surfaces, caps, uncertainty, base["tol_MPa"]
    trials = [solve(basis, radius, False) for radius in (2.5e-9, 5e-9, 1e-8, 2e-8, 4e-8, 8e-8)]
    for trial in trials:
        if "predicted" in trial:
            update = np.asarray(trial["predicted"]["joint"]["dq"])
            trial["minimum_retained_surface_fraction"] = float(min((value + normal @ update) / value
                                                                   for _, value, normal in surfaces))
        print(trial["radius"], trial.get("gain_over_tau"), trial.get("upper_norm_MPa"), trial.get("status"))
    report = {"native_trace_sha256": recorded["trace_sha256"], "anchor_q_kN": base["q"],
              "original_tau_MPa": base["tol_MPa"], "original_cap_MPa": caps.tolist(),
              "witness_tangent_error_MPa": max_check_error, "trials": trials,
              "actual_new_equilibrium_tested": False}
    output = HERE / "JetScreen.json"
    output.write_bytes((json.dumps(report, indent=2) + "\n").encode())
    print(sha256(output.read_bytes()).hexdigest().upper())


if __name__ == "__main__":
    main()
