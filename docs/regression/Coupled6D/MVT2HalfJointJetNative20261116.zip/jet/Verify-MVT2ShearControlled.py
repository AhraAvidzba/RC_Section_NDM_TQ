"""Audit the fresh HalfJoint matrix, all 75 signed surfaces and two exact holdout actions."""
import argparse
import csv
import json
from pathlib import Path

import VerifyBase as v

HERE=Path(__file__).resolve().parent
NATIVE=HERE/"NativeA"
WITNESSES=("WitnessCenter","WitnessGradient")


def full(state,X):
    weak,_,_=v.reconstruct(state["field"],state["q"],X)
    return (*state["r"],*(x*v.MODULUS for x in weak[-4:]))


def grid(name):
    raw=(HERE/name).read_bytes()
    assert raw.count(b"\r\n")==raw.count(b"\n")
    return list(csv.reader(raw.decode("ascii").splitlines(),delimiter=";"))


def prepare():
    prep=v.read(HERE/"Preparation.json")
    assert all(v.digest(HERE/name)==identity for name,identity in prep["inputs"].items())
    assert v.digest(HERE/"workbook/output/RC_Section_NDM.xlsm")==prep["book_sha256"]
    assert v.digest(HERE/"Replay.csv")==prep["replay_sha256"]
    assert v.digest(HERE/"PreviousNative.csv")==prep["native_previous_sha256"]
    states,stations=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    r=states["HalfJoint"]
    assert r["q"]==18.5720088671875
    assert tuple(map(float,grid("AnchorField.csv")[0]))==r["field"]
    assert v.peak(v.diff(tuple(map(float,grid("ArchiveOrigin.csv")[0])),full(r,stations["HalfJoint"])))<4e-15
    witness={}
    for (name,radius,flag,*terms),label in zip(grid("Witness.csv"),("HalfGradient","HalfCenter"),strict=True):
        dq=tuple(map(float,terms))
        assert name in WITNESSES and float(flag)==0. and len(dq)==60
        assert dq==tuple(.5*(x-y) for x,y in zip(states[label]["field"],r["field"],strict=True))
        assert v.tensor_radius(dq,r["geometry"])<=float(radius)+4e-16<1e-8
        witness[name]=dq
    assert list(witness)==list(WITNESSES)
    return prep,r,stations["HalfJoint"],witness


def exact_gauges(geometry):
    G=[[0.]*60 for _ in range(4)]
    for p in range(1,26):
        x,y,area=geometry[p,0]
        _,B,xn,yn=v.operators(x,y)
        for j,b in enumerate(B):
            w=area*b/v.AREA
            k=4+3*j
            for axis in range(3):
                G[axis][k+axis]+=w
            G[3][k]-=yn*w
            G[3][k+1]+=xn*w
    return G


def verify(prep,archived,old_stations,witness):
    build=v.read(HERE/"docs/regression/CodeUpdate.json")
    compiler=v.read(HERE/"CompileClosure.json")
    owner=v.read(NATIVE/"MVT2.txt.Ownership.json")
    watcher=v.read(NATIVE/"MVT2.txt.ProcessClosure.json")
    run=v.read(NATIVE/"RunReceipt.json")
    assert build["Compiled"] and sorted(build["Modules"])==["CCoupledNewtonSolver","modTestCoupledExperiment"]
    assert not build["ProductionChanged"] and build["ProductionSHA256"]==prep["book_sha256"] and compiler["State"]=="Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert watcher["Passed"] and watcher["ChildExitCode"]==run["native_exit"]==0 and watcher["ChildHasExited"]
    final=watcher["Closure"]["FinalState"]
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (NATIVE/"MVT2.txt").read_text(encoding="utf-8-sig")
    path=NATIVE/"MVT2.csv"
    tags=v.read_native(path)
    states,stations=v.verified_states(tags)
    [[qb,q]]=tags["B_TANGENT_LOAD"]
    assert (float(qb),float(q))==(18.55811,18.5720088671875) and tags["B_FRESH_PHASE"]==[["A"]]
    history=v.vec(tags,"MVT2_CONTROL_FIELD")
    rec=grid("Replay.csv")[1:]
    assert len(rec)==len(history)==24
    for i,row in enumerate(rec,1):
        assert int(row[0])==i and v.peak(v.diff(tuple(map(float,row[9:])),history[f"Replay{i}"]))<1e-15
    assert states["Restored24"]==states["Base24"] and stations["Restored24"]==stations["Base24"]
    assert states["Base24"]["field"]==history["Replay24"]
    steel=v.verify_steel(tags,states,stations,history)
    base=states["HalfJoint"]
    X=stations["HalfJoint"]
    r0=full(base,X)
    drift=v.peak(v.diff(r0,full(archived,old_stations)))
    assert drift<=8e-10
    assert v.peak(v.diff(base["field"],archived["field"]))<3e-15
    G=exact_gauges(base["geometry"])
    P=[tuple(map(float,row[1:])) for row in tags["B_FRESH_PROJECTION"]]
    assert len(P)==6 and all(len(a)==56 for a in P)
    assert v.peak(v.diff(tuple(v.dot(row,r0[:56]) for row in P),r0[56:62]))<4e-10
    native_normals={}
    for p,side,ok,F,*grad in tags["B_JET_SURFACE"]:
        key=int(p),int(side)
        assert key not in native_normals and 1<=key[0]<=25 and key[1] in (-1,0,1)
        assert abs(float(F)-X[key][6])<4e-10 and len(grad)==(6 if int(ok) else 0)
        native_normals[key]=tuple(map(float,grad)) if int(ok) else None
    assert len(native_normals)==75
    norm_checks={}
    differences={}
    for label,dq in witness.items():
        if label not in states:
            assert [label,"Residual"] in tags["B_TANGENT_UNAVAILABLE"]
            norm_checks[label]={"available":False}
            continue
        state=states[label]
        assert state["q"]==base["q"] and state["geometry"]==base["geometry"]
        assert v.peak(v.diff(state["field"],tuple(a+b for a,b in zip(base["field"],dq,strict=True))))<3e-15
        X1=stations[label]
        comparisons=[(key,float(row[6]-X[key][6]),v.dot(g,v.diff(row[7:13],X[key][7:13])))
                     for key,g in native_normals.items() if g is not None for row in (X1[key],)]
        changes=[key for key in native_normals if X[key][3:6]!=X1[key][3:6] or X[key][6]*X1[key][6]<=0.]
        actual=v.diff(full(state,X1),r0)
        differences[label]=actual
        norm_checks[label]={"available":True,"actual_all66_action_MPa":actual,"surface_comparisons":comparisons,
            "surface_prediction_error_MPa":max((abs(a-b) for _,a,b in comparisons),default=None),
            "branch_changes":changes,"signed_actual_six_N_Nmm":state["signed_force_N_Nmm"],"peak_steel_MPa":steel[label]}
    output={}
    rawmatrix={}
    for name,i,*row in tags["B_FRESH_MATRIX"]:
        rawmatrix.setdefault(name,{})[int(i)]=tuple(map(float,row))
    assert set(rawmatrix).union(x[0] for x in tags["B_FRESH_MATRIX_UNAVAILABLE"])=={"Stock","Consistent","Refined"}
    law=v.vec(tags,"B_FRESH_INTERNAL")
    for name,raw in rawmatrix.items():
        M=[raw[i] for i in range(1,61)]
        assert all(len(row)==60 for row in M)
        error_g=max(v.peak(v.diff(x,y)) for x,y in zip(M[-4:],G,strict=True))
        error_r=max(abs(M[i][56+j]-G[j][i]) for i in range(56) for j in range(4))
        assert max(error_g,error_r)<2e-12
        demand=v.loading(base["q"])
        weak=v.diff(law[name],demand)
        defect=v.peak(v.diff((*weak[:56],*(v.dot(a,weak[:56]) for a in P),*(a*v.MODULUS for a in weak[-4:])),r0))
        reference={}
        for label,dq in witness.items():
            if label not in differences:
                continue
            predict=[v.dot(x,dq) for x in M]
            exact=(*predict[:56],*(v.dot(a,predict[:56]) for a in P),*(a*v.MODULUS for a in predict[-4:]))
            miss=v.diff(differences[label],exact)
            reference[label]={"max66_error_MPa":v.peak(miss),"signed_N_error_N":miss[56]*v.AREA,
                              "weak_row1_55_56_error_MPa":[miss[i-1] for i in (1,55,56)]}
        output[name]={"anchor_consistency_error_MPa":defect,"exact_gauge_matrix_error":error_g,
            "exact_reaction_columns_error":error_r,"two_witness_errors":reference}
    return {"source_book_sha256":prep["book_sha256"],"H24_sha256":prep["replay_sha256"],
            "trace_sha256":v.digest(path),"base_norm_MPa":v.peak(r0),"drift_from_archived_HalfJoint_MPa":drift,
            "exact_H24_rollback":True,"history_published":False,"q_trial_kN":float(q),"Qy_accepted_kN":float(qb),
            "native_wall_s":run["wall_seconds"],"compiler":compiler,"owner":final,
            "all_75_surface_normals":{str(k):a for k,a in native_normals.items()},
            "available_native_tangents":output,"unavailable_tangents":tags["B_FRESH_MATRIX_UNAVAILABLE"],
            "unavailable_surface_gradients":[k for k,d in native_normals.items() if d is None],
            "witnesses":norm_checks,"capacity_claimed":False}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--phase",choices=("A",))
    p.add_argument("--inputs-only",action="store_true")
    args=p.parse_args()
    frozen=prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert args.phase=="A"
        report=verify(*frozen)
        out=HERE/"VerificationA.json"
        out.write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
        print(out,v.digest(out))
