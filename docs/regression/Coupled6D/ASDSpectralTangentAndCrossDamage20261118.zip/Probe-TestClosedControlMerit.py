"""ДЛЯ ТЕСТОВ: сравнивает квадратную меру невязки с исходной проверкой максимума."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np
from scipy.optimize import least_squares


def TestProbe(repo, native, pilot, output):
    """Меняет способ выбора поправки, сохраняя материал, принятую историю и приёмочный допуск."""
    helper = run_path(str(Path(__file__).with_name('Trace-TestClosedASDControl.py')))
    section, history, _, _ = helper['TestRestore'](repo, native)
    data = json.loads(pilot.read_bytes())['variants']['bar26']
    for row in data['trials']:
        if row['accepted']:
            field = np.asarray(row['field'])
            target = np.array([0., -396.*row['Qy_N'], 0., 10510000., 0., row['Qy_N']])
            result = section.evaluate(field, history, target)
            assert result[1] <= row['tolerance_MPa']
            history = result[4]
    failed = data['trials'][-1]
    projection = np.asarray(data['projection'])
    origin = np.r_[failed['field'], failed['Qy_N']/1000.]
    target_control = failed['control_target']
    base = np.array([0., 0., 0., 10510000., 0., 0.])
    direction = np.array([0., -396000., 0., 0., 0., 1000.])

    def TestResidual(x):
        """Возвращает точные слабые строки, связи и меру управления в шкале МПа."""
        result = section.evaluate(x[:60], history, base+x[60]*direction)
        return np.r_[result[0]*section.gauge_scale, 30000.*(projection@x[:60]-target_control)]

    def TestJacobian(x):
        """Собирает разностные столбцы поля и аналитическую производную внешней нагрузки."""
        matrix = np.zeros((61, 61))
        for j, unit in enumerate(np.eye(61)[:60]):
            matrix[:, j] = (TestResidual(x+2e-10*unit)-TestResidual(x-2e-10*unit))/(4e-10)
        matrix[:60, 60] = -(direction@section.l)*section.gauge_scale
        matrix[60, :60] = 30000.*projection
        return matrix

    initial_matrix = TestJacobian(origin)
    scales = np.max(np.abs(initial_matrix), axis=0)
    initial = TestResidual(origin)
    results = {}
    for method in ('trf', 'dogbox'):
        trace = []

        def TestFunction(y):
            """Записывает действительную норму каждой пробы без подмены результата оптимизатора."""
            residual = TestResidual(origin+y/scales)
            trace.append([float(np.max(np.abs(residual))), float(np.linalg.norm(residual))])
            return residual

        solution = least_squares(TestFunction, np.zeros(61), jac=lambda y: TestJacobian(origin+y/scales)/scales,
                                 method=method, max_nfev=80, xtol=1e-13, ftol=1e-13, gtol=1e-13)
        x = origin+solution.x/scales
        target = base+x[60]*direction
        result = section.evaluate(x[:60], history, target)
        control_error = abs(30000.*(projection@x[:60]-target_control))
        norm = max(float(result[1]), float(control_error))
        tolerance = 5e-7+5e-7*np.max(np.abs((target@section.l)[:56]))
        results[method] = {'optimizer_success': bool(solution.success), 'optimizer_message': solution.message,
                           'accepted': bool(norm <= tolerance), 'norm_MPa': norm, 'tolerance_MPa': float(tolerance),
                           'Qy_N': float(x[60]*1000.), 'field': x[:60].tolist(), 'trace_inf_l2_MPa': trace}
        print(method, results[method]['accepted'], norm, 'Q', x[60]*1000., 'evaluations', solution.nfev, flush=True)
    output.write_bytes((json.dumps({'initial_inf_l2_MPa': [float(np.max(np.abs(initial))), float(np.linalg.norm(initial))],
                                  'results': results, 'physical_capacity_certified': False}, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--pilot', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestProbe(args.repo.resolve(), args.native.resolve(), args.pilot.resolve(), args.out.resolve())
