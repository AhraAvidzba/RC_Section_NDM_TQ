"""ДЛЯ ТЕСТОВ: сохраняет диагностические пробы и исправление внешнего сравнения."""

from pathlib import Path
from runpy import run_path
from hashlib import sha256
import json


def TestCollect():
    """Фиксирует фактические входы, полный отрицательный результат и неизменность установленной книги."""
    repo = Path.cwd()
    folder = Path(__file__).resolve().parent
    target = folder/'SpectralEvidenceBundle'
    target.mkdir()
    scripts = ('Probe-TestASDMaterialSteps.py', 'Probe-TestASDClosure.py', 'Solve-TestASDClosure.py',
               'Trace-TestClosedASDControl.py', 'Diagnose-TestClosedControl.py', 'Probe-TestClosedControlMerit.py',
               'TestClosedASDTangent.py', 'Diagnose-TestClosedADDirection.py', 'Trace-TestClosedASDPrincipal.py',
               'Trace-TestClosedASDMode.py', 'Solve-TestSingleASDTangent.py', 'Check-TestASDSourceBehavior.py',
               'Replay-TestASDIntegration.py', 'Check-TestASDCrossDamage.py',
               'Collect-TestASDSpectralEvidence.py', 'Verify-TestASDSpectralEvidence.py')
    data = ('ClosedControlPilot.json', 'ClosedControlDiagnosis.json', 'ClosedControlRefined.json',
            'ClosedControlMerit.json', 'ClosedToleranceProbe.json', 'ClosedArcPilot.json', 'ClosedADChecks.json',
            'ClosedADControl.json', 'ClosedADDirection.json', 'ClosedADBranchTrace.json',
            'ClosedPrincipalControl.json', 'ClosedModeControl.json', 'ClosedSpectralTangentSides.json',
            'SingleADNdmReplay.json', 'SingleADNdmCold.json', 'SingleADDefaultCold.json',
            'CrossDamageOpenSees.json.gz', 'CrossDamageChecks.json', 'GitHub-header.json')
    for name in (*scripts, *data):
        (target/name).write_bytes((folder/name).read_bytes())
    helper = run_path(str(folder/'Probe-TestASDMaterialSteps.py'))
    with helper['TestArchive'](repo, ('ASDMaterialHistoryClosure20261117.zip',
            'EEE550619B11A852744B8194608249FC654F9B3133789CB2115D360BBAF6251E')) as archive:
        (target/'Native').mkdir()
        for name in ('Operators.csv', 'MVTGaussMixed.Tensor.csv'):
            (target/'Native'/name).write_bytes(archive.read('Full/Native/'+name))
    identities = {}
    for name, expected in (
        ('workbook/output/RC_Section_NDM.xlsm', 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'),
        ('workbook/output/VBA_All_Code.txt', 'DB8023F9384B0059E1D1C51D59FE0E62F9B8CD94AC4D9B329DD0EE810AF676CC'),
        ('src/Solver/CCoupledNewtonSolver.cls', 'E960D4DDFB01B4FECA54472901A3A9A4E5BD9B7765CEA780E621E15BFC9600A7')):
        value = sha256((repo/name).read_bytes()).hexdigest().upper()
        assert value == expected, (name, value)
        identities[name] = value
    (target/'ProductionUnchanged.json').write_bytes((json.dumps(identities, indent=2, sort_keys=True)+'\n').encode())
    (target/'README.txt').write_text('''ДЛЯ ТЕСТОВ. Этап 592. Исследовательские материалы, не установленный расчётный модуль.
База Git: e7c1232. Дата: 18.11.2026. Новых запусков Excel нет.
Native/ содержит точные 35 принятых полей из закреплённого архива §591.
Контрольные меры: стержень 26, закручивание, секущая, длина дуги,
главное направление элемента 12 отрицательной станции, сингулярная мода.
Все усилия и история исходного префикса сохранены. Остановка около 61,8 кН
остаётся численной: физический максимум не удостоверен. Формулы материала
между однократным обновлением и замыканием различаются; варианты явно обозначены.
Производные вычислены по спектральным значениям с учётом поворота главных осей.
Сверка касательных ограничена тремя пробами около остановки; полная верификация
для возможного рабочего применения ещё нужна. Код ядра книги не менялся.
Исходный дополнительный прогноз §591 не учитывал R(cdf). Исправленная сверка
96 обновлений подтверждает исходник в выбранном режиме с cdf по умолчанию,
а также с явными cdf=0,1,10. Это не доказательство всех режимов библиотеки.
Проверка: python -B -X utf8 Verify-TestASDSpectralEvidence.py --repo <repo> --root . --out SpectralChecks.json
Примеры повторного поиска:
python -B -X utf8 Trace-TestClosedASDControl.py --native Native --out Control.json --steps 16 --projections bar26 --tangent closed-ad
python -B -X utf8 Trace-TestClosedASDPrincipal.py --native Native --pilot ClosedADControl.json --out Principal.json
python -B -X utf8 Trace-TestClosedASDMode.py --native Native --pilot ClosedADControl.json --direction ClosedADDirection.json --out Mode.json
Нативная сверка материала: Check-TestASDCrossDamage.py --capture Cross.json.gz --python <OpenSeesPython>
Перед каждым дочерним процессом проверяются свободная RAM и запас commit.
''' , encoding='utf-8')
    print('ASD SPECTRAL EVIDENCE COLLECTED', len(scripts), len(data))


if __name__ == '__main__':
    TestCollect()
