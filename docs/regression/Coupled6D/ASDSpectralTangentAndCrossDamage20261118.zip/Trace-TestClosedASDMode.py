"""ДЛЯ ТЕСТОВ: проверяет переключение внутренней моды у спектрального излома бетона."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestRun(repo, native, pilot, direction_file, output):
    """Выбирает меру по правому сингулярному вектору собственного поля, без внешних прогнозов."""
    here = Path(__file__).resolve().parent
    helper = run_path(str(here/'Trace-TestClosedASDControl.py'))
    tangent = run_path(str(here/'TestClosedASDTangent.py'))
    section, history, points, replay = helper['TestRestore'](repo, native)
    rows = json.loads(pilot.read_bytes())['variants']['bar26']['trials']
    for row in rows:
        if row['accepted']:
            field, q = np.asarray(row['field']), row['Qy_N']/1000.
            target = np.array([0., -396000.*q, 0., 10510000., 0., 1000.*q])
            result = section.evaluate(field, history, target)
            assert result[1] <= row['tolerance_MPa']
            history = result[4]
            points.append((q, field))
    rejected = np.asarray(rows[-1]['field'])
    look_ahead = np.asarray(json.loads(direction_file.read_bytes())['correction'])[:60]
    matrix = tangent['TestGlobalMatrix'](section, rejected+.001*look_ahead, history)[0]*section.gauge_scale[:, None]
    scales = np.max(np.abs(matrix), axis=0)
    u, singular, vh = np.linalg.svd(matrix/scales)
    mode = vh[-1]/scales
    mode[56:] = 0.
    mode /= np.linalg.norm(mode)
    previous_q, previous = points[-2]
    if mode@(field-previous) < 0.:
        mode *= -1.
    q, field = points[-1]
    control = float(mode@field)
    rows = []
    for increment in (1e-7, -1e-7, 1e-6, -1e-6, 1e-5, -1e-5):
        seed = field+increment*mode
        candidate, value, proposed, record = helper['TestControlledStep'](
            section, history, mode, control+increment, seed, q, tangent_function=tangent['TestGlobalMatrix'])
        record['increment'] = increment
        rows.append(record)
        print(increment, record['accepted'], record['Qy_N'], record['norms_MPa'][-1], flush=True)
    proof = {'native_replay': replay, 'mode': mode.tolist(), 'scaled_singular_values': singular.tolist(),
             'committed_control': control, 'trials': rows,
             'integration_modified': True, 'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--pilot', type=Path, required=True)
    parser.add_argument('--direction', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.native.resolve(), args.pilot.resolve(), args.direction.resolve(), args.out.resolve())
