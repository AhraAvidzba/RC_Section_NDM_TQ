"""ДЛЯ ТЕСТОВ: продолжает равновесие по линейной мере пробного главного напряжения, делённого на E."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestRun(repo, native, pilot, output, steps):
    """Строит меру из собственного отклонённого поля; внешние решения не использует."""
    here = Path(__file__).resolve().parent
    helper = run_path(str(here/'Trace-TestClosedASDControl.py'))
    tangent = run_path(str(here/'TestClosedASDTangent.py'))
    section, history, points, native_replay = helper['TestRestore'](repo, native)
    rows = json.loads(pilot.read_bytes())['variants']['bar26']['trials']
    for row in rows:
        if row['accepted']:
            field, q = np.asarray(row['field']), row['Qy_N']/1000.
            load = np.array([0., -396000.*q, 0., 10510000., 0., 1000.*q])
            result = section.evaluate(field, history, load)
            assert result[1] <= row['tolerance_MPa']
            history = result[4]
            points.append((q, field))
    rejected = np.asarray(rows[-1]['field'])
    elastic = np.diag([25000.]*3+[12500.]*3)
    elastic[:3, :3] += 25000./3.
    trial = history[1]+(section.b@rejected-history[0])@elastic.T
    values, axes = np.linalg.eigh(tangent['TestTensorize'](trial))
    side, point, principal = 2, 11, 0
    axis = axes[side, point, :, principal]
    weights = np.array([axis[0]**2, axis[1]**2, axis[2]**2,
                        2.*axis[0]*axis[1], 2.*axis[0]*axis[2], 2.*axis[1]*axis[2]])
    projection = weights@elastic@section.b[side, point]/30000.
    previous_q, previous = points[-2]
    q, field = points[-1]
    old, control = float(projection@previous), float(projection@field)
    increment = .5*(control-old)
    original_increment = increment
    assert increment != 0.
    probes = []
    print('projection increment', increment, 'rejected eigenvalue', values[side, point, principal], flush=True)
    for index in range(steps):
        step = increment
        for attempt in range(9):
            target = control+step
            ratio = step/(control-old)
            seed = field+ratio*(field-previous)
            multiplier = q+ratio*(q-previous_q)
            candidate, value, proposed, record = helper['TestControlledStep'](
                section, history, projection, target, seed, multiplier, tangent_function=tangent['TestGlobalMatrix'])
            record['step_index'], record['attempt'] = index, attempt
            record['projection'] = projection.tolist()
            record['committed_minimum_principal_stress_MPa'] = float(np.linalg.eigvalsh(
                tangent['TestTensorize'](proposed[1]))[side, point, principal])
            probes.append(record)
            print(index, attempt, record['accepted'], record['Qy_N'], record['norms_MPa'][-1],
                  record['committed_minimum_principal_stress_MPa'], flush=True)
            if record['accepted']:
                previous, previous_q, old = field, q, control
                field, q, control, history = candidate, value, target, proposed
                increment = np.sign(original_increment)*min(abs(original_increment), 2.*abs(step))
                break
            step *= .5
        else:
            break
    proof = {'native_replay': native_replay, 'source_pilot': pilot.name, 'projection': projection.tolist(),
             'critical_station_point_principal_zero_based': [side, point, principal],
             'axis': axis.tolist(), 'rejected_eigenvalue_MPa': float(values[side, point, principal]),
             'original_increment': float(original_increment), 'trials': probes,
             'integration_modified': True, 'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--pilot', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--steps', type=int, default=16)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.native.resolve(), args.pilot.resolve(), args.out.resolve(), args.steps)
