"""ДЛЯ ТЕСТОВ: проверяет локальную непрерывность на направлении точного шага Ньютона."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestRun(repo, native, pilot, output):
    """Повторяет принятую историю, не фиксируя ни одной диагностической пробы."""
    here = Path(__file__).resolve().parent
    helper = run_path(str(here/'Trace-TestClosedASDControl.py'))
    tangent = run_path(str(here/'TestClosedASDTangent.py'))
    section, history, _, _ = helper['TestRestore'](repo, native)
    rows = json.loads(pilot.read_bytes())['variants']['bar26']['trials']
    for row in rows:
        if row['accepted']:
            load = np.array([0., -396.*row['Qy_N'], 0., 10510000., 0., row['Qy_N']])
            state = section.evaluate(np.asarray(row['field']), history, load)
            assert state[1] <= row['tolerance_MPa']
            history = state[4]
    row = rows[-1]
    assert not row['accepted']
    field, multiplier = np.asarray(row['field']), row['Qy_N']/1000.
    projection = np.asarray(row['projection'])
    base = np.array([0., 0., 0., 10510000., 0., 0.])
    direction = np.array([0., -396000., 0., 0., 0., 1000.])

    def TestResidual(current, value):
        """Оставляет исходные усилия, связи, управление и меру невязки."""
        load = base+value*direction
        state = section.evaluate(current, history, load)
        residual = np.r_[state[0]*section.gauge_scale, 30000.*(projection@current-row['control_target'])]
        return residual, max(float(state[1]), abs(float(residual[-1]))), state

    residual, norm, original = TestResidual(field, multiplier)
    matrix = np.zeros((61, 61))
    matrix[:60, :60] = tangent['TestGlobalMatrix'](section, field, history)[0]*section.gauge_scale[:, None]
    matrix[:60, 60] = -(direction@section.l)*section.gauge_scale
    matrix[60, :60] = 30000.*projection
    scales = np.max(np.abs(matrix), axis=0)
    correction = np.linalg.solve(matrix/scales, -residual)/scales
    _, _, concrete_tangent, _ = tangent['TestConcrete'](section, section.b@field, history)
    expected_concrete = concrete_tangent@(section.b@correction[:60])[..., None]
    expected_concrete = expected_concrete[..., 0]
    expected_concrete[:, 25:] *= -1.
    other = []
    for exponent in range(31):
        fraction = 2.**-exponent
        r, n, state = TestResidual(field+fraction*correction[:60], multiplier+fraction*correction[60])
        concrete_change = state[3]-original[3]
        expected_steel = 200000.*(section.a@correction[:60]).reshape(3, 20)
        concrete_change[:, 25:] -= fraction*expected_steel[..., None]*section.directions
        point_error = concrete_change/fraction-expected_concrete
        location = np.unravel_index(np.argmax(np.abs(point_error)), point_error.shape)
        other.append({'fraction': fraction, 'norm_MPa': n, 'l2_norm': float(np.linalg.norm(r)),
                      'linearization_error_per_fraction_MPa': float(np.max(np.abs((r-residual)/fraction-matrix@correction))),
                      'material_direction_error_MPa': float(np.max(np.abs(point_error))),
                      'material_location': [int(i) for i in location],
                      'material_change_MPa': float(concrete_change[location]),
                      'material_prediction_MPa': float(fraction*expected_concrete[location])})
    alternatives = []
    for ahead in (1., .1, .01, .001):
        alternate = matrix.copy()
        alternate[:60, :60] = tangent['TestGlobalMatrix'](section, field+ahead*correction[:60], history)[0]*section.gauge_scale[:, None]
        alternate_scales = np.max(np.abs(alternate), axis=0)
        step = np.linalg.solve(alternate/alternate_scales, -residual)/alternate_scales
        candidates = []
        for exponent in range(17):
            fraction = 2.**-exponent
            _, other_norm, _ = TestResidual(field+fraction*step[:60], multiplier+fraction*step[60])
            candidates.append({'fraction': fraction, 'norm_MPa': other_norm})
        best = min(candidates, key=lambda p:p['norm_MPa'])
        alternatives.append({'look_ahead_fraction': ahead, 'probes': candidates, 'best': best})
        print('alternate', ahead, best, flush=True)
    result = {'initial_norm_MPa': norm, 'initial_residual': residual.tolist(), 'correction': correction.tolist(),
              'initial_material_tangent': concrete_tangent.tolist(), 'probes': other,
              'scaled_singular_values': np.linalg.svd(matrix/scales, compute_uv=False).tolist(), 'alternate_branches': alternatives,
              'physical_capacity_certified': False}
    output.write_bytes((json.dumps(result, indent=2, sort_keys=True)+'\n').encode())
    for row in other:
        print(json.dumps(row), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--pilot', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.native.resolve(), args.pilot.resolve(), args.out.resolve())
