"""ДЛЯ ТЕСТОВ: проверяет точную касательную одного ASD-обновления без локального замыкания."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestCorrection(section, field, history, result, tangent):
    """Сохраняет исходный перебор ветвей стали и меняет только производную бетона."""
    matrix = tangent(section, field, history, single_update=True, include_steel=False)[0]
    trial = result[-1].ravel()
    bounds = np.tile(section.bounds, 3)
    clipped = np.clip(trial, -bounds, bounds)
    mask, visited = np.sign(trial-clipped), set()
    for iteration in range(1, 9):
        visited.add(mask.tobytes())
        elastic = mask == 0.
        complete = matrix+(section.scatter[:, elastic]*200000.)@section.a[elastic]
        right = -result[0]-section.scatter@(np.where(elastic, trial, mask*bounds)-clipped)
        scales = np.max(np.abs(complete), axis=0)
        step = np.linalg.solve(complete/scales, right)/scales
        predicted = trial+200000.*(section.a@step)
        new_mask = np.sign(predicted-np.clip(predicted, -bounds, bounds))
        if new_mask.tobytes() in visited:
            return step, iteration
        mask = new_mask
    return step, iteration


def TestRun(repo, mode, replay_prefix, output):
    """Сравнивает неизменённый номинальный закон с однократной спектральной производной."""
    here = Path(__file__).resolve().parent
    sections, fields, _ = run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)
    section = sections[mode]
    tangent = run_path(str(here/'TestClosedASDTangent.py'))
    solve = run_path(str(here/'Solve-TestASDClosure.py'))['TestSolve']
    section.correction = lambda field, history, result, method, h: TestCorrection(section, field, history, result, tangent['TestGlobalMatrix'])
    history, field, preload, errors = section.initial(), np.zeros(60), [], []
    torques = [262750., 525500., 1051000., 2102000., 4204000., 6831500., 8670750., 10510000.]
    good = True
    for (phase, native_field), torque in zip(fields, torques, strict=True):
        load = np.array([0., 0., 0., torque, 0., 0.])
        if replay_prefix:
            candidate = native_field
            result = section.evaluate(candidate, history, load)
            tolerance = float(5e-7+5e-7*np.max(np.abs((load@section.l)[:56])))
            record = {'phase': phase, 'accepted': bool(result[1] <= tolerance), 'norms_MPa': [float(result[1])],
                      'tolerance_MPa': tolerance, 'field': candidate.tolist(), 'target': load.tolist()}
            proposed = result[4]
        else:
            candidate, proposed, record = solve(section, load, field, history)
            record['phase'] = phase
        original = section.nominal(candidate, history)
        ad = tangent['TestConcrete'](section, section.b@candidate, history, single_update=True)
        expected = original[0].copy()
        expected[:, 25:] *= -1.
        error = float(np.max(np.abs(ad[0]-expected)))
        assert error < 8e-8, error
        errors.append(error)
        preload.append(record)
        print(mode, phase, record['accepted'], record['norms_MPa'][-1], flush=True)
        if not record['accepted']:
            good = False
            break
        field, history = candidate, proposed
    mixed = []
    if good:
        for q in (2500., 1250., 625., 312.5, 0.):
            load = np.array([0., -396.*q, 0., 10510000., 0., q])
            candidate, proposed, record = solve(section, load, field, history)
            mixed.append(record)
            print(mode, 'Q', q, record['accepted'], record['norms_MPa'][-1], flush=True)
            if record['accepted'] and q > 0.:
                break
    proof = {'mode': mode, 'replay_prefix': replay_prefix, 'single_library_update': True,
             'closure_used': False, 'nominal_projection_error_MPa': errors,
             'preload': preload, 'mixed': mixed, 'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--mode', choices=('ndm_uniaxial', 'default'), default='ndm_uniaxial')
    parser.add_argument('--replay-prefix', action='store_true')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.mode, args.replay_prefix, args.out.resolve())
