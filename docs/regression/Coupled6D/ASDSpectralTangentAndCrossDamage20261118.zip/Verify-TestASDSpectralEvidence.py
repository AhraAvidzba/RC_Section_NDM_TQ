"""ДЛЯ ТЕСТОВ: повторяет спектральные пробы и исправленную сверку cdf без запуска Excel."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestRead(path):
    """Читает закреплённые численные записи без изменения точности или разделителей."""
    return json.loads(path.read_text('utf-8-sig'))


def TestRows(section, history, rows, projection=None):
    """Заново проверяет усилия, слабые уравнения, связи и меру каждой принятой и отклонённой пробы."""
    accepted, rejected, maximum = 0, 0, 0.
    for row in rows:
        field = np.asarray(row['field'])
        target = np.asarray(row['target']) if 'target' in row else np.array([
            0., -396.*row['Qy_N'], 0., 10510000., 0., row['Qy_N']])
        result = section.evaluate(field, history, target)
        norm = float(result[1])
        measure = row.get('projection', projection)
        if measure is not None:
            control = 30000.*(np.asarray(measure)@field+row.get('load_projection', 0.)*row['Qy_N']/1000.-row['control_target'])
            norm = max(norm, abs(float(control)))
        tolerance = float(5e-7+5e-7*np.max(np.abs((target@section.l)[:56])))
        assert abs(tolerance-row['tolerance_MPa']) < 1e-15
        assert bool(norm <= tolerance) == row['accepted'], (row.get('Qy_N'), norm, tolerance)
        assert abs(norm-row['norms_MPa'][-1]) < 5e-9, (norm, row['norms_MPa'][-1])
        if row['accepted']:
            maximum = max(maximum, norm/tolerance)
            history = result[4]
            accepted += 1
        else:
            rejected += 1
    return history, {'accepted': accepted, 'rejected': rejected, 'maximum_accepted_norm_ratio': maximum}


def TestVerify(repo, root, output):
    """Проверяет область результата; физический максимум и рабочая установка не объявляются."""
    helper = run_path(str(root/'Probe-TestASDMaterialSteps.py'))
    controls = run_path(str(root/'Trace-TestClosedASDControl.py'))
    tangent = run_path(str(root/'TestClosedASDTangent.py'))
    cross = run_path(str(root/'Check-TestASDCrossDamage.py'))
    prefix = ('ASDMaterialHistoryClosure20261117.zip', 'EEE550619B11A852744B8194608249FC654F9B3133789CB2115D360BBAF6251E')
    with helper['TestArchive'](repo, prefix) as archive:
        for name in ('Operators.csv', 'MVTGaussMixed.Tensor.csv'):
            assert archive.read('Full/Native/'+name) == (root/'Native'/name).read_bytes()
    summaries = {}
    for name in ('ClosedControlPilot', 'ClosedControlRefined', 'ClosedArcPilot', 'ClosedADControl'):
        data = TestRead(root/(name+'.json'))
        assert data['integration_modified'] and not data['physical_capacity_certified']
        summaries[name] = {}
        for key, variant in data['variants'].items():
            section, history, _, records = controls['TestRestore'](repo, root/'Native')
            assert len(records) == 35
            _, summary = TestRows(section, history, variant['trials'], variant['projection'])
            assert summary['accepted'] > 0 and summary['rejected'] > 0
            summaries[name][key] = summary
    principal = TestRead(root/'ClosedPrincipalControl.json')
    mode = TestRead(root/'ClosedModeControl.json')
    for name, data, projection in (('principal', principal, principal['projection']), ('mode', mode, mode['mode'])):
        section, history, _, _ = controls['TestRestore'](repo, root/'Native')
        history, _ = TestRows(section, history, TestRead(root/'ClosedADControl.json')['variants']['bar26']['trials'])
        _, summary = TestRows(section, history, data['trials'], projection)
        summaries[name] = summary
    assert summaries['principal']['accepted'] == 2 and summaries['mode']['accepted'] == 0
    singles = {}
    for name in ('SingleADNdmReplay', 'SingleADNdmCold', 'SingleADDefaultCold'):
        data = TestRead(root/(name+'.json'))
        assert data['single_library_update'] and not data['closure_used'] and not data['physical_capacity_certified']
        sections, _, _ = helper['TestInputs'](repo)
        section = sections[data['mode']]
        history, first = TestRows(section, section.initial(), data['preload'])
        # Все первые совместные пробы начинаются из одного принятого префикса, без фиксации отказов.
        _, second = TestRows(section, history, data['mixed'])
        assert max(data['nominal_projection_error_MPa']) < 8e-8
        singles[name] = {'preload': first, 'mixed': second}
    assert singles['SingleADDefaultCold']['mixed']['accepted'] == 1
    assert singles['SingleADNdmReplay']['mixed']['accepted'] == singles['SingleADNdmCold']['mixed']['accepted'] == 0
    with TemporaryDirectory(dir=output.parent) as directory:
        temp = Path(directory)
        tangent['TestCheck'](repo, root/'Native', root/'ClosedControlPilot.json', temp/'Tangent.json')
        actual = TestRead(temp/'Tangent.json')
        saved = TestRead(root/'ClosedADChecks.json')
        assert len(actual['samples']) == len(saved['samples']) == 3
        for row in actual['samples']:
            assert row['nominal_error_MPa'] < 8e-8 and row['effective_error_MPa'] < 8e-8
            assert row['point_tangents'][-1]['scaled_error'] < 1e-6
            assert row['point_tangents'][0]['scaled_error'] > .04
            assert row['global_tangent_relative_error'] < 2e-5
        cross['TestVerify'](repo, root, root/'CrossDamageOpenSees.json.gz', temp/'Cross.json')
        assert (temp/'Cross.json').read_bytes() == (root/'CrossDamageChecks.json').read_bytes()
    section, history, _, _ = controls['TestRestore'](repo, root/'Native')
    rows = TestRead(root/'ClosedADControl.json')['variants']['bar26']['trials']
    history, _ = TestRows(section, history, rows)
    field = np.asarray(rows[-1]['field'])
    projection = np.asarray(rows[-1]['projection'])
    q = rows[-1]['Qy_N']/1000.
    target = np.array([0., -396000.*q, 0., 10510000., 0., 1000.*q])
    result = section.evaluate(field, history, target)
    residual = np.r_[result[0]*section.gauge_scale, 30000.*(projection@field-rows[-1]['control_target'])]
    matrix = np.zeros((61, 61))
    matrix[:60, :60] = tangent['TestGlobalMatrix'](section, field, history)[0]*section.gauge_scale[:, None]
    matrix[:60, 60] = -(np.array([0., -396000., 0., 0., 0., 1000.])@section.l)*section.gauge_scale
    matrix[60, :60] = 30000.*projection
    scales = np.max(np.abs(matrix), axis=0)
    correction = np.linalg.solve(matrix/scales, -residual)/scales
    assert np.max(np.abs(correction-TestRead(root/'ClosedADDirection.json')['correction'])) < 1e-12
    sides = TestRead(root/'ClosedSpectralTangentSides.json')
    for row in sides:
        local = tangent['TestGlobalMatrix'](section, field+row['fraction']*correction[:60], history)[0]
        sign = np.linalg.slogdet(local/np.max(np.abs(local), axis=0))[0]
        assert sign == row['determinant_sign']
    assert sides[0]['determinant_sign'] == 1 and sides[-1]['determinant_sign'] == -1
    trace = TestRead(root/'ClosedADBranchTrace.json')
    for fraction, saved in trace.items():
        captured = []
        tangent['TestConcrete'](section, section.b@(field+float(fraction)*correction[:60]), history, trace=captured)
        assert len(captured) == len(saved)
        for a, b in zip(captured, saved, strict=True):
            assert np.max(np.abs(np.asarray(a['principal'])-b['principal'])) < 1e-10
    assert trace['0.0'][0]['principal'][0] < 0. and trace['1.0'][0]['principal'][0] > 0.
    # Знак определителя относится к неравновесным диагностическим полям; это не критерий разрушения.
    proof = {'controlled_replay': summaries, 'single_update_replay': singles,
             'tangent_samples_verified': 3, 'cross_damage': TestRead(root/'CrossDamageChecks.json'),
             'new_native_excel_runs': 0, 'candidate_installed': False,
             'physical_capacity_certified': False, 'full_acceptance_completed': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('ASD SPECTRAL TANGENTS AND CORRECTED CROSS DAMAGE VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestVerify(args.repo.resolve(), args.root.resolve(), args.out.resolve())
