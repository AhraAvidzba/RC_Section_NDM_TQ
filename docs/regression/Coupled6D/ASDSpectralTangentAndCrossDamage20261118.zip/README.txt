ДЛЯ ТЕСТОВ. Этап 592. Исследовательские материалы, не установленный расчётный модуль.
База Git: e7c1232. Дата: 18.11.2026. Новых запусков Excel нет.
Native/ содержит точные 35 принятых полей из закреплённого архива §591.
Контрольные меры: стержень 26, закручивание, секущая, длина дуги,
главное направление элемента 12 отрицательной станции, сингулярная мода.
Все усилия и история исходного префикса сохранены. Остановка около 61,8 кН
остаётся численной: физический максимум не удостоверен. Формулы материала
между однократным обновлением и замыканием различаются; варианты явно обозначены.
Производные вычислены по спектральным значениям с учётом поворота главных осей.
Сверка касательных ограничена тремя пробами около остановки; полная верификация
для возможного рабочего применения ещё нужна. Код ядра книги не менялся.
Исходный дополнительный прогноз §591 не учитывал R(cdf). Исправленная сверка
96 обновлений подтверждает исходник в выбранном режиме с cdf по умолчанию,
а также с явными cdf=0,1,10. Это не доказательство всех режимов библиотеки.
Проверка: python -B -X utf8 Verify-TestASDSpectralEvidence.py --repo <repo> --root . --out SpectralChecks.json
Примеры повторного поиска:
python -B -X utf8 Trace-TestClosedASDControl.py --native Native --out Control.json --steps 16 --projections bar26 --tangent closed-ad
python -B -X utf8 Trace-TestClosedASDPrincipal.py --native Native --pilot ClosedADControl.json --out Principal.json
python -B -X utf8 Trace-TestClosedASDMode.py --native Native --pilot ClosedADControl.json --direction ClosedADDirection.json --out Mode.json
Нативная сверка материала: Check-TestASDCrossDamage.py --capture Cross.json.gz --python <OpenSeesPython>
Перед каждым дочерним процессом проверяются свободная RAM и запас commit.
