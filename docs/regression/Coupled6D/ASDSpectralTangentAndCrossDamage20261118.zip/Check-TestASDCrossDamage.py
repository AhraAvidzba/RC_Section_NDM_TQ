"""ДЛЯ ТЕСТОВ: учитывает cdf и R при сверке смешения повреждений ASDConcrete3D."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha1, sha256
import json
from pathlib import Path
from runpy import run_path
from subprocess import run, PIPE
from tempfile import TemporaryDirectory
import sys

import numpy as np


TestBinary = '25BA42E1672526137D765D9C3631D1403E091F54F5AFCDB9242F9243C63C3A96'


def TestInputs(repo, folder):
    """Повторяет прежние три истории и рассчитывает полный множитель R*aux_damage."""
    helper = run_path(str(folder/'Probe-TestASDMaterialSteps.py'))
    selector = run_path(str(folder/'Check-TestASDSourceBehavior.py'))
    command, strain, baseline, old_incomplete_prediction, positions = selector['TestPointData'](repo)
    sections, fields, _ = helper['TestInputs'](repo)
    section = sections['ndm_uniaxial']
    coordinates = [((0, 1, -1).index(side), point-1) for side, point in positions]
    history = section.initial()
    tensors = run_path(str(folder/'TestClosedASDTangent.py'))
    prediction = {name: [] for name in ('default', 'cdf0', 'cdf1', 'cdf10')}
    coefficients = {name: [] for name in prediction}
    elastic = np.diag([25000.]*3+[12500.]*3)
    elastic[:3, :3] += 25000./3.
    plastic_cancellation = 0.
    for _, field in fields:
        trial = history[1]+(section.b@field-history[0])@elastic.T
        principal = np.linalg.eigvalsh(tensors['TestTensorize'](trial))
        positive = np.maximum(principal, 0.).sum(axis=-1)
        negative = np.maximum(-principal, 0.).sum(axis=-1)
        response = section.nominal(field, history)
        nominal = response[0].copy()
        nominal[:, 25:] *= -1.
        stress = tensors['TestTensorize'](nominal)
        values, axes = np.linalg.eigh(stress)
        compressed = np.einsum('...ik,...k,...jk->...ij', axes, np.minimum(values, 0.), axes)
        x = response[3][2][0]*section.ratio
        curve = section.curves[1]
        y, q = curve.value(x, curve.nominal), curve.value(x, curve.effective)
        aux_damage = 1.-y/q
        aux_plastic = x-q/30000.
        aux_denominator = (x-aux_plastic)*30000.
        plastic_cancellation = max(plastic_cancellation, float(np.max(np.abs(1.-q/aux_denominator))))
        for name, cdf in (('default', 0.), ('cdf0', 0.), ('cdf1', 1.), ('cdf10', 10.)):
            denominator = cdf*positive+negative
            ratio = np.divide(cdf*positive, denominator, out=np.zeros_like(positive), where=denominator > 0.)
            expected = tensors['TestPack'](stress-(ratio*aux_damage)[..., None, None]*compressed)
            prediction[name].append([expected[s, p].tolist() for s, p in coordinates])
            coefficients[name].append([float(ratio[s, p]) for s, p in coordinates])
        history = response[3]
    assert np.max(np.abs(np.asarray(prediction['default'])-baseline)) < 1e-12
    return command, strain, prediction, coefficients, positions, plastic_cancellation


def TestCapture(repo, folder, interpreter, output):
    """Проверяет именно загруженный нативный модуль и оба значения параметра, включая умолчание."""
    helper = run_path(str(folder/'Probe-TestASDMaterialSteps.py'))
    replay = run_path(str(folder/'Check-TestASDSourceBehavior.py'))['REPLAY']
    memory = run_path(str(folder/'Replay-TestASDIntegration.py'))['TestMemory']
    command, strain, _, _, positions, _ = TestInputs(repo, folder)
    with helper['TestArchive'](repo, replay) as archive:
        worker = archive.read('Replay-NativeBarOpenSees.py').decode('utf-8-sig').replace('\r\n', '\n')
    needle = '    import openseespy.opensees as ops\n'
    assert worker.count(needle) == 1
    worker = worker.replace(needle, needle+'''    import openseespywin.opensees as native
    from hashlib import sha256
    assert ops.NDTest is native.NDTest
    assert sha256(Path(native.__file__).read_bytes()).hexdigest().upper() == "'''+TestBinary+'"\n')
    records, resources = {}, []
    with TemporaryDirectory(dir=output.parent) as directory:
        temp = Path(directory)
        (temp/'Worker.py').write_bytes(worker.encode())
        for name, options in (('default', []), ('cdf0', ['-cdf', 0.]), ('cdf1', ['-cdf', 1.]), ('cdf10', ['-cdf', 10.])):
            resources.append(memory())
            target = temp/'Output.json'
            process = run([str(interpreter), '-B', '-X', 'utf8', str(temp/'Worker.py'), '--worker', str(target)],
                          input=json.dumps([command+options, strain]).encode(), stdout=PIPE, stderr=PIPE,
                          timeout=45, check=True, creationflags=0x08000000 if sys.platform == 'win32' else 0)
            records[name] = {'command': command+options, 'stress': json.loads(target.read_bytes()),
                             'stderr': process.stderr.decode('utf-8', errors='replace')}
    data = {'cases': records, 'strain_sha256': sha256(json.dumps(strain).encode()).hexdigest().upper(),
            'positions': positions, 'binary_sha256': TestBinary, 'resources': resources,
            'worker_sha256': sha256(worker.encode()).hexdigest().upper()}
    output.write_bytes(compress(json.dumps(data, separators=(',', ':')).encode(), mtime=0))


def TestVerify(repo, folder, wire, output):
    """Отделяет исправленную сверку выбранного режима от тождества всех ветвей исходника и бинарника."""
    command, strain, expected, coefficients, positions, cancellation = TestInputs(repo, folder)
    data = json.loads(decompress(wire.read_bytes()))
    assert data['binary_sha256'] == TestBinary and data['positions'] == [list(p) for p in positions]
    assert data['strain_sha256'] == sha256(json.dumps(strain).encode()).hexdigest().upper()
    errors = {}
    for name, options in (('default', []), ('cdf0', ['-cdf', 0.]), ('cdf1', ['-cdf', 1.]), ('cdf10', ['-cdf', 10.])):
        assert data['cases'][name]['command'] == command+options
        errors[name] = float(np.max(np.abs(np.asarray(data['cases'][name]['stress'])-expected[name])))
        assert errors[name] < 8e-7, (name, errors[name])
    assert np.max(np.abs(coefficients['default'])) == 0.
    difference = float(np.max(np.abs(np.asarray(data['cases']['cdf1']['stress'])-data['cases']['default']['stress'])))
    assert difference > .1 and cancellation < 1e-10
    source = repo/'literature/Coupled6D'
    cpp = (source/'OpenSees-3.8.0-ASDConcrete3DMaterial.cpp').read_bytes()
    header = (source/'OpenSees-3.8.0-ASDConcrete3DMaterial.h').read_bytes()
    api = json.loads((folder/'GitHub-header.json').read_text('utf-8-sig'))
    assert sha1(b'blob '+str(len(header)).encode()+b'\0'+header).hexdigest() == api['sha']
    assert sha256(cpp).hexdigest().upper() == '210EADE9C167DA38FB5A7894570C64BA0CA35D9D9307A9818FDE485435EBEA31'
    text = cpp.decode()
    assert 'double cdf = 0.0;' in text and 'if (Sj > 0.0) Sj *= cdf;' in text
    assert '(1.0 - alpha * D.R * dt)' in text and 'return x - q / E;' in header.decode()
    proof = {'corrected_prediction_errors_MPa': errors, 'native_updates': len(strain)*len(positions)*4,
             'cdf1_difference_from_default_MPa': difference, 'aux_plastic_cancellation': cancellation,
             'default_R': 0., 'header_git_blob': api['sha'], 'header_sha256': sha256(header).hexdigest().upper(),
             'configured_source_mode_correspondence_established': True,
             'entire_binary_all_options_verified': False, 'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('ASD CROSS DAMAGE FACTOR AND DEFAULT VERIFIED', json.dumps(proof), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--folder', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--capture', type=Path)
    parser.add_argument('--python', type=Path)
    parser.add_argument('--wire', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.capture:
        TestCapture(args.repo.resolve(), args.folder.resolve(), args.python.resolve(), args.capture.resolve())
    else:
        TestVerify(args.repo.resolve(), args.folder.resolve(), args.wire.resolve(), args.out.resolve())
