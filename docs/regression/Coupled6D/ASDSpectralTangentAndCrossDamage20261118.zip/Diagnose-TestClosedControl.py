"""ДЛЯ ТЕСТОВ: сравнивает касательные и демпфирование точной отклонённой контролируемой пробы."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestDiagnose(repo, native, pilot, output):
    """Не меняет принятый буфер и допуски; все различия относятся к одной и той же пробе."""
    section, history, _, _ = run_path(str(Path(__file__).with_name('Trace-TestClosedASDControl.py')))['TestRestore'](repo, native)
    data = json.loads(pilot.read_bytes())['variants']['bar26']
    projection = np.asarray(data['projection'])
    for row in data['trials']:
        if row['accepted']:
            field = np.asarray(row['field'])
            target = np.array([0., -396.*row['Qy_N'], 0., 10510000., 0., row['Qy_N']])
            result = section.evaluate(field, history, target)
            assert result[1] <= row['tolerance_MPa']
            history = result[4]
    row = data['trials'][-1]
    assert not row['accepted']
    field, multiplier = np.asarray(row['field']), row['Qy_N']/1000.
    target_control = row['control_target']
    direction = np.array([0., -396000., 0., 0., 0., 1000.])
    base = np.array([0., 0., 0., 10510000., 0., 0.])

    def TestResidual(current, value):
        """Считает полный остаток с исходными связями и точным управлением стержнем."""
        force = base+value*direction
        result = section.evaluate(current, history, force)
        control = 30000.*(projection@current-target_control)
        tolerance = 5e-7+5e-7*np.max(np.abs((force@section.l)[:56]))
        return np.r_[result[0]*section.gauge_scale, control], max(result[1], abs(control)), tolerance

    residual, original_norm, original_tolerance = TestResidual(field, multiplier)
    assert abs(original_norm-row['norms_MPa'][-1]) < 1e-8
    trials = []
    for h in (2e-8, 2e-9, 2e-10, 2e-11):
        matrix = np.zeros((61, 61))
        for j, unit in enumerate(np.eye(60)):
            matrix[:, j] = (TestResidual(field+h*unit, multiplier)[0]-TestResidual(field-h*unit, multiplier)[0])/(2*h)
        matrix[:60, 60] = -(direction@section.l)*section.gauge_scale
        matrix[60, :60] = 30000.*projection
        scales = np.max(np.abs(matrix), axis=0)
        scaled = matrix/scales
        u, singular, vh = np.linalg.svd(scaled)
        correction = np.linalg.solve(scaled, -residual)/scales
        curve, failures = [], 0
        for exponent in range(25):
            fraction = 2.**-exponent
            try:
                value, norm, tolerance = TestResidual(field+fraction*correction[:60], multiplier+fraction*correction[60])
            except ArithmeticError:
                failures += 1
                continue
            curve.append({'fraction': fraction, 'norm_MPa': float(norm), 'tolerance_MPa': float(tolerance),
                          'accepted': bool(norm <= tolerance), 'progress': bool(norm < original_norm),
                          'linear_prediction_norm_MPa': float(np.max(np.abs(residual+fraction*matrix@correction)))})
        best = min(curve, key=lambda r:r['norm_MPa'])
        trials.append({'difference_step': h, 'scaled_singular_values': singular.tolist(),
                       'left_load_coupling': float(u[:, -1]@matrix[:, 60]),
                       'control_mode_coupling': float(projection@(vh[-1, :60]/scales[:60])),
                       'material_failures': failures, 'line_search': curve,
                       'best_field': (field+best['fraction']*correction[:60]).tolist(),
                       'best_lambda': float(multiplier+best['fraction']*correction[60])})
        print(h, 'smallest singular', singular[-1], 'best', best['norm_MPa'], 'fraction', best['fraction'], 'failures', failures, flush=True)
    output.write_bytes((json.dumps({'base_norm_MPa': float(original_norm), 'base_tolerance_MPa': float(original_tolerance),
                                  'trials': trials, 'physical_capacity_certified': False}, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--pilot', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestDiagnose(args.repo.resolve(), args.native.resolve(), args.pilot.resolve(), args.out.resolve())
