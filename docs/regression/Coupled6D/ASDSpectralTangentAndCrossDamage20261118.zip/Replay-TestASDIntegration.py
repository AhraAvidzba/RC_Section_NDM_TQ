"""ДЛЯ ТЕСТОВ: сверяет дробление и замыкание ASD с фактическим модулем OpenSees."""

from argparse import ArgumentParser
import ctypes
from gzip import compress, decompress
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from subprocess import run, PIPE
from tempfile import TemporaryDirectory
import sys

import numpy as np


BINARY = '25BA42E1672526137D765D9C3631D1403E091F54F5AFCDB9242F9243C63C3A96'


def TestInputs(repo, folder):
    """Задаёт точные входы и фиксирует каждое внутреннее принятие материального шага."""
    helper = run_path(str(folder/'Probe-TestASDMaterialSteps.py'))
    close = run_path(str(folder/'Probe-TestASDClosure.py'))['TestClosure']
    selector = run_path(str(folder/'Check-TestASDSourceBehavior.py'))
    sections, fields, _ = helper['TestInputs'](repo)
    ndm_command = selector['TestPointData'](repo)[0]
    default_command = ['ASDConcrete3D', 30000., .2, '-fc', 34.0277777777778, '-ft', 2.10667357864589, '-tangent']
    cases = {}
    for mode, kind in (('ndm_uniaxial', 'micro16'), ('default', 'micro16'),
                       ('ndm_uniaxial', 'closed'), ('default', 'closed_force'), ('default', 'native_closed_force'),
                       ('default', 'native_full_closed_force')):
        sections, _, _ = helper['TestInputs'](repo)
        section = sections[mode]
        base = section.nominal
        history = section.initial()
        native_centers, native_net = {}, {}
        native_error = 0.
        if kind.endswith('closed_force'):
            if kind == 'closed_force':
                force_data = json.loads((folder/'ClosedForceDefault.json').read_bytes())
                records = force_data['preload']+force_data['mixed_trials']
                assert all(row['accepted'] for row in records)
                path = [(str(i), np.asarray(row['field']), np.asarray(row['target'])) for i, row in enumerate(records)]
            else:
                loads = {}
                native_folder = folder/('Full/Native' if kind == 'native_full_closed_force' else 'Native')
                for line in (native_folder/'MVTGaussMixed.Tensor.csv').read_text('cp1251').splitlines():
                    row = line.split(';')
                    if row[0] == 'FRAME':
                        label = row[1]
                        torque, q = float(row[2]), float(row[3])
                        loads[label] = np.array([0., -396.*q, 0., torque, 0., q])
                        native_centers[label] = np.zeros((45, 6))
                    elif row[0] == 'POINT':
                        native_centers[label][int(row[1])-1] = np.array(row[8:], dtype=float)
                path = []
                for line in (native_folder/'Operators.csv').read_text('cp1251').splitlines():
                    row = line.split(';')
                    if row[0] == 'F':
                        path.append((row[1], np.array(row[2:], dtype=float), loads[row[1]]))
                    elif row[0] == 'H':
                        native_net.setdefault(row[1], np.zeros((3, 45, 6)))[(0, 1, -1).index(int(row[2])), int(row[3])-1] = np.array(row[4:], dtype=float)
                if kind == 'native_full_closed_force':
                    assert len(path) == 35 and path[-1][0] == 'S27A61718.75'
                else:
                    assert [row[0] for row in path] == [*(f'R{i}' for i in range(1, 9)), 'S2']
            path += [('null1', path[-1][1], path[-1][2]), ('null2', path[-1][1], path[-1][2])]
            positions = [(side, point) for side in range(3) for point in range(45)]
        else:
            path = [(name, field, None) for name, field in fields]
            positions = [(0, 10), (0, 35), (1, 14)]
        strain_frames, stress_frames, endpoints = [], [], []

        def TestRecord(field, old):
            """Сохраняет независимо проверяемые тензоры одного вызова с фиксацией его результата."""
            response = base(field, old)
            concrete = response[0].copy()
            concrete[:, 25:] *= -1.
            strain_frames.append([response[3][0][s, p].tolist() for s, p in positions])
            stress_frames.append([concrete[s, p].tolist() for s, p in positions])
            return response

        section.TestOriginalNominal = TestRecord
        section.TestClosureIterations = 0
        previous = np.zeros(60)
        for name, field, target in path:
            if kind == 'micro16':
                for j in range(1, 17):
                    current = field if j == 16 else previous+(j/16.)*(field-previous)
                    response = TestRecord(current, history)
                    history = response[3]
            else:
                response = close(section, field, history)
                history = response[3]
            previous = field
            if name in native_centers:
                concrete = response[0][0].copy()
                concrete[25:] *= -1.
                native_error = max(native_error, float(np.max(np.abs(concrete-native_centers[name]))))
                if name in native_net:
                    net = response[0].copy()
                    net[:, 25:] += response[1][..., None]*section.directions
                    native_error = max(native_error, float(np.max(np.abs(net-native_net[name]))))
            endpoints.append({'name': name, 'frame': len(strain_frames)-1, 'field': field.tolist(),
                              'target': None if target is None else target.tolist()})
        if kind == 'micro16':
            TestRecord(previous, history)
        cases[mode+';'+kind] = {'command': ndm_command if mode == 'ndm_uniaxial' else default_command,
                              'strain': strain_frames, 'expected': stress_frames, 'endpoints': endpoints,
                              'positions': positions}
        if native_centers:
            assert native_error < 8e-7, native_error
            cases[mode+';'+kind]['native_tensor_error_MPa'] = native_error
    return cases, section


def TestMemory():
    """Проверяет физическую память и системный commit перед каждым дочерним процессом."""
    class TestPerformance(ctypes.Structure):
        _fields_ = [('cb', ctypes.c_ulong)]+[(key, ctypes.c_size_t) for key in
            ('CommitTotal', 'CommitLimit', 'CommitPeak', 'PhysicalTotal', 'PhysicalAvailable', 'SystemCache',
             'KernelTotal', 'KernelPaged', 'KernelNonpaged', 'PageSize')]+[(key, ctypes.c_ulong) for key in
            ('HandleCount', 'ProcessCount', 'ThreadCount')]
    state = TestPerformance()
    state.cb = ctypes.sizeof(state)
    assert ctypes.windll.psapi.GetPerformanceInfo(ctypes.byref(state), state.cb)
    free_ram = state.PhysicalAvailable*state.PageSize/2**20
    free_commit = (state.CommitLimit-state.CommitTotal)*state.PageSize/2**30
    assert free_ram >= 6500 and free_commit >= 6, (free_ram, free_commit)
    return {'ramMiB': free_ram, 'freeCommitGiB': free_commit}


def TestCapture(repo, folder, interpreter, output):
    """Читает полный ответ выбранных историй; каждая партия использует новый собственный процесс."""
    cases, _ = TestInputs(repo, folder)
    helper = run_path(str(folder/'Probe-TestASDMaterialSteps.py'))
    reference = run_path(str(folder/'Check-TestASDSourceBehavior.py'))['REPLAY']
    with helper['TestArchive'](repo, reference) as archive:
        worker = archive.read('Replay-NativeBarOpenSees.py').decode('utf-8-sig').replace('\r\n', '\n')
    needle = '    import openseespy.opensees as ops\n'
    assert worker.count(needle) == 1
    worker = worker.replace(needle, needle+'''    import openseespywin.opensees as native
    from hashlib import sha256
    assert ops.NDTest is native.NDTest
    assert sha256(Path(native.__file__).read_bytes()).hexdigest().upper() == "'''+BINARY+'"\n')
    captured, resources = {}, []
    with TemporaryDirectory(dir=output.parent) as directory:
        temp = Path(directory)
        (temp/'Worker.py').write_bytes(worker.encode())
        for name, case in cases.items():
            values = [[] for _ in case['strain']]
            update_limit = 600 if name.endswith('native_full_closed_force') else 500
            batch = min(3, update_limit//len(case['strain']))
            assert batch > 0
            for first in range(0, len(case['positions']), batch):
                resources.append(TestMemory())
                chunk = [frame[first:first+batch] for frame in case['strain']]
                assert sum(len(frame) for frame in chunk) <= update_limit
                target = temp/'Output.json'
                process = run([str(interpreter), '-B', '-X', 'utf8', str(temp/'Worker.py'), '--worker', str(target)],
                              input=json.dumps([case['command'], chunk], separators=(',', ':')).encode(),
                              stdout=PIPE, stderr=PIPE, timeout=45, check=True,
                              creationflags=0x08000000 if sys.platform == 'win32' else 0)
                assert process.returncode == 0
                for row, part in zip(values, json.loads(target.read_bytes()), strict=True):
                    row.extend(part)
            captured[name] = {'stress': values, 'strain_sha256': sha256(json.dumps(case['strain']).encode()).hexdigest().upper()}
            print('CAPTURED', name, len(values), len(case['positions']), flush=True)
    output.write_bytes(compress(json.dumps({'cases': captured, 'resources': resources, 'binary_sha256': BINARY,
                                            'worker_sha256': sha256(worker.encode()).hexdigest().upper()},
                                           separators=(',', ':')).encode(), mtime=0))


def TestVerify(repo, folder, wire, output):
    """Проверяет материал, а для девяти силовых полей и двух повторов — все уравнения и усилия."""
    cases, section = TestInputs(repo, folder)
    data = json.loads(decompress(wire.read_bytes()))
    assert data['binary_sha256'] == BINARY and set(data['cases']) == set(cases)
    assert all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in data['resources'])
    results = {}
    for name, case in cases.items():
        captured = data['cases'][name]
        assert captured['strain_sha256'] == sha256(json.dumps(case['strain']).encode()).hexdigest().upper()
        observed = np.asarray(captured['stress'])
        error = float(np.max(np.abs(observed-case['expected'])))
        assert error < 8e-7, (name, error)
        result = {'updates': int(np.prod(observed.shape[:2])), 'maximum_stress_error_MPa': error}
        if 'native_tensor_error_MPa' in case:
            result['native_tensor_error_MPa'] = case['native_tensor_error_MPa']
        if name.endswith('closed_force'):
            plastic = np.zeros((3, 20))
            states = []
            for endpoint in case['endpoints']:
                field, target = np.asarray(endpoint['field']), np.asarray(endpoint['target'])
                stress = observed[endpoint['frame']].reshape(3, 45, 6).copy()
                stress[:, 25:] *= -1.
                eps = (section.a@field).reshape(3, 20)
                steel = np.clip(200000.*(eps-plastic), -section.bounds, section.bounds)
                plastic = eps-steel/200000.
                stress[:, 25:] += steel[..., None]*section.directions
                weak = section.g@field+np.einsum('pij,pi->j', section.s, stress[0])+np.einsum('pij,pi->j', section.r, (stress[1]-stress[2])/section.double_dx)-target@section.l
                forces = section.loads(stress[0])
                norm = max(float(np.max(np.abs(weak*section.gauge_scale))), float(np.max(np.abs(forces-target)/section.force_scale)))
                tolerance = 5e-7+5e-7*np.max(np.abs((target@section.l)[:56]))
                assert norm <= tolerance, (endpoint['name'], norm, tolerance)
                states.append({'name': endpoint['name'], 'norm_MPa': norm, 'tolerance_MPa': float(tolerance), 'forces_N_Nmm': forces.tolist()})
            result['equilibria'] = states
        results[name] = result
    output.write_bytes((json.dumps({'cases': results, 'binary_sha256': BINARY, 'physical_capacity_certified': False},
                                  indent=2, sort_keys=True)+'\n').encode())
    print('ASD INTEGRATION REPLAY VERIFIED', sum(row['updates'] for row in results.values()))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--capture', type=Path)
    parser.add_argument('--python', type=Path)
    parser.add_argument('--wire', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.capture:
        TestCapture(args.repo.resolve(), args.root.resolve(), args.python.resolve(), args.capture.resolve())
    else:
        TestVerify(args.repo.resolve(), args.root.resolve(), args.wire.resolve(), args.out.resolve())
