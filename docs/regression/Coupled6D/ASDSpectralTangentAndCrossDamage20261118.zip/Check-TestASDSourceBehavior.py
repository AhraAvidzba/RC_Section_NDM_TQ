"""ДЛЯ ТЕСТОВ: различает раздельный ASD-ответ и дополнительное смешение повреждений в исходнике."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from subprocess import run, PIPE
from tempfile import TemporaryDirectory
import sys

import numpy as np


REPLAY = ('MVT2NativeBarOpenSeesReplay20261117.zip', '3FC1E30F23F2410CCF8C3C716D5B8554E385BB59F21DC14DE69CE53DD9301DFE')


def TestPointData(repo):
    """Готовит три истории с существенным дополнительным повреждением сжатия."""
    helper = run_path(str(Path(__file__).with_name('Probe-TestASDMaterialSteps.py')))
    sections, fields, _ = helper['TestInputs'](repo)
    section = sections['ndm_uniaxial']
    history = section.initial()
    expected, mixed, strains, damages = [], [], [], []
    for _, field in fields:
        response = section.nominal(field, history)
        history = response[3]
        concrete = response[0].copy()
        concrete[:, 25:] *= -1.
        x = history[2][0]*section.ratio
        law = section.curves[1]
        aux_damage = 1.-law.value(x, law.nominal)/law.value(x, law.effective)
        tensor = np.zeros((3, 45, 3, 3))
        for k, (i, j) in enumerate(((0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2))):
            tensor[..., i, j] = tensor[..., j, i] = concrete[..., k]
        eig, axes = np.linalg.eigh(tensor)
        negative = np.einsum('...ik,...k,...jk->...ij', axes, np.minimum(eig, 0.), axes)
        alternate = tensor-aux_damage[..., None, None]*negative
        alternate = np.stack([alternate[..., i, j] for i, j in ((0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2))], axis=-1)
        expected.append(concrete)
        mixed.append(alternate)
        strains.append(history[0])
        damages.append(aux_damage)
    positions = sorted({np.unravel_index(np.argmax(damages[-1]), damages[-1].shape), (1, 14), (0, 35)})
    select = lambda frames: [[np.asarray(frame[side, point]).tolist() for side, point in positions] for frame in frames]
    with helper['TestArchive'](repo, helper['NDM']) as archive:
        command = json.loads(decompress(archive.read('NdmCurveNullOpenSees.json.gz')))['commands']
    return command, select(strains), select(expected), select(mixed), [((0, 1, -1)[s], int(p)+1) for s, p in positions]


def TestCapture(repo, interpreter, output):
    """Передаёт фактической библиотеке только команды материала и последовательности деформаций."""
    helper = run_path(str(Path(__file__).with_name('Probe-TestASDMaterialSteps.py')))
    command, strains, _, _, positions = TestPointData(repo)
    with TemporaryDirectory(dir=output.parent) as directory:
        temp = Path(directory)
        with helper['TestArchive'](repo, REPLAY) as archive:
            (temp/'Replay.py').write_bytes(archive.read('Replay-NativeBarOpenSees.py'))
        target = temp/'Stress.json'
        result = run([str(interpreter), '-B', '-X', 'utf8', str(temp/'Replay.py'), '--worker', str(target)],
                     input=json.dumps([command, strains]).encode(), stdout=PIPE, stderr=PIPE, timeout=45,
                     creationflags=0x08000000 if sys.platform == 'win32' else 0, check=True)
        response = json.loads(target.read_bytes())
    record = {'commands': command, 'strain_sha256': sha256(json.dumps(strains).encode()).hexdigest().upper(),
              'stress': response, 'positions': positions, 'engine': 'OpenSees 3.8.0',
              'worker_stderr': result.stderr.decode('utf-8', errors='replace')}
    output.write_bytes(compress(json.dumps(record, separators=(',', ':')).encode(), mtime=0))


def TestVerify(repo, wire, output):
    """Сопоставляет две реализации без изменения одного из ожидаемых результатов."""
    command, strains, expected, mixed, positions = TestPointData(repo)
    data = json.loads(decompress(wire.read_bytes()))
    assert data['commands'] == command and data['positions'] == [list(p) for p in positions]
    assert data['strain_sha256'] == sha256(json.dumps(strains).encode()).hexdigest().upper()
    observed = np.asarray(data['stress'])
    separate_error = float(np.max(np.abs(observed-expected)))
    mixed_error = float(np.max(np.abs(observed-mixed)))
    proof = {'points': positions, 'states': len(strains)*len(positions),
             'separate_prediction_error_MPa': separate_error, 'additional_mixing_prediction_error_MPa': mixed_error,
             'captured_engine': data['engine'], 'source_behavior_correspondence_established': mixed_error < 8e-7}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print(json.dumps(proof, indent=2))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--capture', type=Path)
    parser.add_argument('--python', type=Path)
    parser.add_argument('--wire', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.capture:
        TestCapture(args.repo.resolve(), args.python.resolve(), args.capture.resolve())
    else:
        TestVerify(args.repo.resolve(), args.wire.resolve(), args.out.resolve())
