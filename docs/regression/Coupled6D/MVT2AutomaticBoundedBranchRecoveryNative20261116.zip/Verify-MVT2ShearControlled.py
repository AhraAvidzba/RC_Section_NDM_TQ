"""Check equal-history MVT2 force and pseudo-arc probes without assuming convergence."""
import argparse
from decimal import Decimal, localcontext
import json
from math import fsum, hypot, sqrt
from pathlib import Path

import VerifyBase as v


here = Path(__file__).resolve().parent
native = here / "NativeCompare"
labels = ("Stock", "Fallback")


def normal_wire_precision(tags, normal):
    [[label, *wire]] = tags["B_ARC_PROJECTION"]
    assert label == "Normal" and len(wire) == len(normal) == 60
    records = []
    with localcontext() as arithmetic:
        arithmetic.prec = 100
        for index, (coefficient, token) in enumerate(zip(normal, wire, strict=True), 1):
            pinned = Decimal.from_float(coefficient)
            serialized = Decimal(token)
            assert pinned.is_finite() and serialized.is_finite()
            if not pinned:
                assert serialized == 0, index
                continue
            # VBA Str$ writes 15 significant decimal digits and strips trailing zeros.
            # Its half-unit at decimal exponent e is 0.5*10**(e-14).
            quantum = Decimal(1).scaleb(pinned.copy_abs().adjusted() - 14)
            defect = abs(pinned - serialized)
            bound = quantum / 2
            assert pinned.quantize(quantum) == serialized and defect <= bound, (index, pinned, token)
            records.append((index, defect, bound, defect / bound))
    worst = max(records, key=lambda row: row[1])
    closest = max(records, key=lambda row: row[3])
    return {"wire_function": "Trim$(Str$(value))", "significant_decimal_digits": 15,
            "exactly_nearest_nonzero_coefficients": len(records), "exact_zero_coefficients": len(normal)-len(records),
            "strict_original_cutoff_failures": sum(row[1] >= Decimal("3e-17") for row in records),
            "max_abs_error": str(worst[1]), "max_abs_error_index": worst[0],
            "max_abs_error_analytic_bound": str(worst[2]), "max_fraction_of_rounding_bound": float(closest[3]),
            "max_fraction_index": closest[0]}


def rows(name):
    return [line.split(";") for line in (here / name).read_text(encoding="ascii").splitlines()]


def metric_field(field, geometry):
    total = fsum(area for _, _, area in geometry.values())
    return tuple(sqrt(area / total) * strain / (1. if i < 3 else sqrt(2.))
                 for (_, side), (x, y, area) in geometry.items()
                 for i, strain in enumerate(v.strain_at(field, v.operators(x, y), side)))


def prepare():
    prep = v.read(here / "Preparation.json")
    assert all(v.digest(here / name) == expected for name, expected in prep["inputs"].items())
    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]
    assert v.digest(here / "Replay.csv") == prep["replay_sha256"]
    evidence = v.read(here / "MVTHistory.json")
    assert evidence["history_sha256"] == prep["replay_sha256"] and evidence["native_sha256"] == v.digest(here / "JetNative.csv")
    [normal] = rows("MVTNormal.csv")
    values = list(map(float, normal))
    p, k, ds = tuple(values[:60]), values[60], values[61] / 64.
    assert p == tuple(evidence["normal_q"]) and p[-4:] == (0.,) * 4
    assert k == evidence["normal_Qy_per_kN"] and ds == evidence["last_secant_metric_norm"] / 64.
    trace = rows("Replay.csv")[1:]
    assert len(trace) == 24
    history_q = [tuple(map(float, line[9:])) for line in trace]
    qy0 = float(trace[-1][2])
    assert qy0 == 18.55811
    qy_trial = qy0 + (qy0 - float(trace[-2][2])) / 64.
    assert qy_trial == 18.5720088671875
    prior, old_stations = v.verified_states(v.read_native(here / "JetNative.csv"))
    assert prior["Restored24"] == prior["Base24"] and old_stations["Restored24"] == old_stations["Base24"]
    assert prior["Base24"]["field"] == history_q[-1]
    predictor = tuple(a + (a - b) / 64. if index < 56 else a
                      for index, (a, b) in enumerate(zip(history_q[-1], history_q[-2], strict=True)))
    assert abs(v.dot(p, v.diff(predictor, history_q[-1])) + k * (qy_trial - qy0) - ds) < 1e-17
    return prep, history_q, prior["Base24"], old_stations["Base24"], p, k, ds, qy_trial, predictor


def verify(prep, history_input, archived, old_stations, p, k, ds, qy_trial, predictor):
    build = v.read(here / "docs/regression/CodeUpdate.json")
    compiler = v.read(here / "CompileClosure.json")
    owner = v.read(native / "MVT2.txt.Ownership.json")
    watch = v.read(native / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(native / "RunReceipt.json")
    final = watch["Closure"]["FinalState"]
    assert build["Compiled"] and sorted(build["Modules"]) == ['CCoupledConcreteResponse', 'CCoupledNewtonSolver', 'CCoupledReinforcedResponse', 'modCoupledConcreteTensor', 'modTestCoupledExperiment']
    assert not build["ProductionChanged"] and build["ProductionSHA256"] == prep["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == build["WorkbookSHA256"]
    assert watch["Passed"] and watch["ChildExitCode"] == receipt["native_exit"] == 0 and watch["ChildHasExited"]
    assert final["State"] == "Absent" and final["PID"] == owner["PID"] and final["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    path = native / "MVT2.csv"
    tags = v.read_native(path)
    states, stations = v.verified_states(tags)
    history = v.vec(tags, "MVT2_CONTROL_FIELD")
    assert len(history) == 24
    for i, q in enumerate(history_input, 1):
        assert v.peak(v.diff(q, history[f"Replay{i}"])) < 1e-15
    assert tags["B_FRESH_PHASE"] == [["Compare"]]
    load_pair = tuple(map(float, tags["B_TANGENT_LOAD"][0]))
    assert load_pair == (18.55811, qy_trial)
    base = states["Base24"]
    assert base == states["Restored24"] == archived
    assert stations["Base24"] == stations["Restored24"] == old_stations
    steel = v.verify_steel(tags, states, stations, history)
    wire_precision = normal_wire_precision(tags, p)
    assert v.peak(v.diff(v.vec(tags, "B_ARC_PREDICTOR")["Shared"], predictor)) < 3e-15

    [(read_k, read_ds, read_target, atol, rtol, limit)] = [tuple(map(float, row)) for row in tags["B_ARC_PLANE"]]
    target = v.dot(p, base["field"]) + k * base["q"] + ds
    assert abs(read_k - k) < 3e-17 and abs(read_ds - ds) < 3e-17 and abs(read_target - target) < 3e-17
    assert atol == rtol == 5e-7 and limit == 26
    saved = dict((name, tuple(map(float, data))) for name, *data in tags["B_ARC_HISTORY"])
    assert set(saved) == {"Before", "ReplayStock", "ReplayFallback", "AfterStock", "AfterFallback", "Final"}
    assert all(data == saved["Before"] for data in saved.values()) and len(saved["Before"]) == 1080
    for station_side in (-1, 0, 1):
        for point in range(1, 26):
            index = 8 * ((station_side + 1) * 45 + point - 1)
            assert v.peak(v.diff(saved["Before"][index:index+6], old_stations[(point, station_side)][13:19])) < 4e-10
    returned = {name: tuple(map(float, data)) for name, *data in tags["B_ARC_SOLVER_ACTUAL"]}
    status = {name: row for name, *row in tags["B_ARC_STATUS"]}
    assert tuple(status) == labels and len(status) == len(tags["B_ARC_STATUS"])

    results = {}
    for name in labels:
        flag, factor, internal, code, seconds = status[name]
        diagnostics = [row[1:] for row in tags["B_ARC_DIAG"] if row[0] == name]
        assert len(diagnostics) == 1
        result = {"newton_equilibrium_returned": flag == "1", "internal_status": int(internal), "result_code": int(code),
                  "solver_wall_seconds": float(seconds), "diagnostic": ";".join(diagnostics[0])}
        if flag == "0":
            assert factor == "-" and name not in states and name not in returned
        else:
            assert flag == "1" and name in states and name in returned
            sample = states[name]
            lam = float(factor)
            assert sample["q"] == lam
            original, loads, _ = v.reconstruct(sample["field"], lam, stations[name])
            assert len(returned[name]) == 6
            assert max(abs(a-b)/s for a,b,s in zip(loads, returned[name], v.SCALES, strict=True)) < 4e-12
            plane = v.dot(p, sample["field"]) + k * lam - target
            control_error = abs(plane) * v.MODULUS
            assert control_error <= sample["tol_MPa"] + 4e-10
            assert max(sample["norm_MPa"], sample["gauge_MPa"]) <= sample["tol_MPa"] + 4e-10
            delta_q = v.diff(sample["field"], base["field"])
            delta_lambda = lam - base["q"]
            scale_qy = v.read(here / "MVTHistory.json")["strains_normalized_to_last_Qy_increment_per_kN"]
            physical_length = hypot(*metric_field(delta_q, base["geometry"]), scale_qy * delta_lambda)
            branch_changes = [list(key) for key, row in stations[name].items() if key[0] <= 25 and
                              (row[3:6] != old_stations[key][3:6] or row[6] * old_stations[key][6] < 0.)]
            result.update({"returned_Qy_parameter_kN": lam, "delta_Qy_parameter_kN": delta_lambda,
                           "requested_six_N_Nmm": v.force(lam), "actual_six_N_Nmm": loads,
                           "signed_six_errors_N_Nmm": sample["signed_force_N_Nmm"], "weak56_MPa": original[:56],
                           "gauges4_MPa": [x * v.MODULUS for x in original[-4:]], "original_force_weak_norm_MPa": sample["norm_MPa"],
                           "arc_plane_residual_strain": plane, "tolerance_MPa": sample["tol_MPa"],
                           "physical_arc_norm_over_nominal_step": physical_length / ds, "within_local_radius": physical_length <= 3 * ds,
                           "yield_surface_changes_relative_to_H24": branch_changes, "steel_max_MPa": steel[name]})
        results[name] = result
    assert not results["Stock"]["newton_equilibrium_returned"]
    assert results["Stock"]["internal_status"] == 6 and results["Stock"]["result_code"] == 10
    [[row, norm, tolerance, factor]] = tags["B_FB_START"]
    assert int(row) == 53
    assert abs(float(norm) - 7.22225739794488e-5) < 4e-10
    assert abs(float(factor) - 18.5708155282075) < 1e-11
    assert .5e-6 < float(tolerance) < 2.e-6
    optimizers = [tuple(map(int, item)) for item in tags["B_FB_OPT"]]
    trial_rows = [tuple(map(float, item)) for item in tags["B_FB_TRIAL"]]
    radius_rows = [tuple(map(float, item)) for item in tags["B_FB_RADIUS"]]
    assert len(optimizers) <= 2 and all(1 <= i <= 2 and 0 <= solves <= 280 for i, _, solves in optimizers)
    assert len(trial_rows) <= len(radius_rows) <= len(optimizers)
    assert all(actual < start for _, start, actual, _, _, _ in trial_rows[:-1])
    successful = results["Fallback"]["newton_equilibrium_returned"]
    if successful:
        assert trial_rows and trial_rows[-1][2] <= trial_rows[-1][4]
        assert all(incremental <= cap and full <= cap for _, incremental, full, cap in radius_rows)
        assert results["Fallback"]["within_local_radius"]
        assert not tags["B_FB_STOP"]
    else:
        assert len(tags["B_FB_STOP"]) == 1
    fallback = {"starting_row_and_norm": [int(row), float(norm)], "linear_solves": optimizers,
                "original_law_trials": trial_rows, "tensors_radii": radius_rows,
                "failed_at": tags["B_FB_STOP"]}
    return {"book_sha256": prep["book_sha256"], "H24_replay_sha256": prep["replay_sha256"], "trace_sha256": v.digest(path),
            "frozen_H24_Qy_kN": base["q"], "ordinary_force_target_Qy_kN": qy_trial, "arc_predictor_Qy_kN": qy_trial,
            "normal_load_coefficient_per_Qy_kN": k, "nominal_arc_increment_strain": ds,
            "projection_wire_precision": wire_precision, "same_initial_field": True, "same_initial_history": True, "same_unmodified_material_law": True,
            "accepted_field_exact": True, "accepted_stresses_and_damage_energy_snapshot_exact": True,
            "history_published": False, "physical_limit_claimed": False, "outcomes": results, "fallback": fallback,
            "compiler": compiler, "owner_closed": final, "total_native_wall_seconds": receipt["wall_seconds"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Compare"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS", v.digest(here / "Preparation.json"))
    else:
        assert args.phase == "Compare"
        output = here / "VerificationCompare.json"
        output.write_bytes((json.dumps(verify(*frozen), indent=2) + "\n").encode("utf-8"))
        print(output, v.digest(output))
