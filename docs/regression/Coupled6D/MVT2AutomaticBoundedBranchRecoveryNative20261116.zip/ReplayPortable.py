"""Replay the native automatic MVT2 fallback and independently verify its radius."""
import argparse
import csv
from collections import defaultdict
from hashlib import sha256
import json
from math import acos, degrees, hypot
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
REPORT = "CC64D1BB52C21D5B3A247D12E771D6945BAF66CC135FACAD02098D79A3DDD7CD"
RAW_NATIVE = "515A3821B7E159372678BDB6D7C6455A85C2D2C83314FA92D9B1BB754DEE231F"
SOURCES = {"stock_branch": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422",
           "same_ray": "E6FCD67D16C2637EF7992AB67CE6DB71AA7E63EE41F15CD33E8CB198A586304D"}
RAY_STOP = "E5C66278C8971BBDEC157D80557F0C1296193059B61B5BA76F4357AD7F8130F2"
RAY_TRACE = "7B36BD0EE4173093C26224831461BDD7FD89D09CBB85B5C52C1941695976C8EB"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def contained(root, name):
    return root / (root / name).resolve().relative_to(root.resolve())


def read_tags(raw):
    tags = defaultdict(list)
    for marker, *row in csv.reader(raw.decode("cp1251").splitlines(), delimiter=";"):
        tags[marker].append(row)
    return tags


def recompute_radius(scope, direct, same_ray):
    v, here = scope["v"], scope["here"]
    original, original_stations = v.verified_states(read_tags(same_ray.read("NativeHalf/MVT2.csv")))
    raw = (here / "NativeCompare/MVT2.csv").read_bytes()
    assert digest(raw) == RAW_NATIVE
    current, actual_stations = v.verified_states(read_tags(raw))
    stop_wire = same_ray.read("RayStop.csv")
    assert digest(stop_wire) == RAY_STOP and digest(same_ray.read("NativeHalf/MVT2.csv")) == RAY_TRACE
    *start, start_factor = map(float, stop_wire.decode("ascii").strip().split(";"))
    assert tuple(start) == original["RayZero"]["field"] and start_factor == original["RayZero"]["q"]
    assert current["Base24"] == original["Base24"] == current["Restored24"]
    assert actual_stations["Base24"] == original_stations["Base24"] == actual_stations["Restored24"]
    final = current["Fallback"]
    material_stations = final["geometry"]
    assert material_stations == original["RayZero"]["geometry"]
    q, factor = final["field"], final["q"]
    move = v.diff(q, start)
    original_field = original["Base24"]["field"]
    original_factor = original["Base24"]["q"]
    total_radius = v.strain_extent(move, material_stations)
    _, incremental_recorded, full_recorded, full_limit = direct["fallback"]["tensors_radii"][-1]
    assert abs(total_radius - full_recorded) < 3e-15 and total_radius < full_limit
    evidence = v.read(here / "MVTHistory.json")
    param_scale = evidence["strains_normalized_to_last_Qy_increment_per_kN"]
    columns = [list(map(float, line)) for line in scope["rows"]("MVTNormal.csv")]
    [normal] = columns
    target_step = normal[61] / 64.
    advance = (*scope["metric_field"](v.diff(q, original_field), material_stations), param_scale * (factor - original_factor))
    signed_projection = v.dot(normal[:60], v.diff(q, original_field)) + normal[60] * (factor - original_factor)
    length = hypot(*advance)
    angle = degrees(acos(signed_projection / length))
    assert abs(signed_projection - target_step) * v.MODULUS < final["tol_MPa"]
    assert abs(length / target_step - direct["outcomes"]["Fallback"]["physical_arc_norm_over_nominal_step"]) < 1e-12
    assert 0 < signed_projection and length <= 3 * target_step
    states = actual_stations["Fallback"]
    stop_stations = original_stations["RayZero"]
    changes = [list(key) for key in sorted(states) if key[0] <= 25 and
               (states[key][3:6] != stop_stations[key][3:6] or states[key][6] * stop_stations[key][6] < 0.)]
    return {"native_trace_sha256": RAW_NATIVE, "reference_stop_sha256": RAY_STOP,
            "original_H24_exact": True, "committed_station_count": len(actual_stations["Base24"]),
            "final_total_tensor_radius_independent": total_radius, "final_total_tensor_radius_native": full_recorded,
            "last_increment_radius_native_only": incremental_recorded, "final_total_tensor_limit": full_limit,
            "arc_progress_projection": signed_projection, "target_arc_projection": target_step,
            "actual_arc_length_over_nominal": length / target_step, "section_arc_angle_degrees": angle,
            "Qy_gain_over_H24_N": 1000.*(factor - original_factor), "Qy_change_from_stall_N": 1000.*(factor - start_factor),
            "concrete_flags_changed_between_archived_stall_and_final": changes}


def run(work, same_ray):
    verifier = work / "Verify-MVT2ShearControlled.py"
    source = verifier.read_text(encoding="utf-8")
    substitutions = {
        'for name, expected in prep["inputs"].items())':
            f'for name, expected in prep["inputs"].items() if name != "{BOOK}")',
        f'    assert v.digest(here / "{BOOK}") == prep["book_sha256"]':
            f'    assert prep["book_sha256"] == "{WORKBOOK}" and prep["inputs"]["{BOOK}"] == "{WORKBOOK}"',
    }
    for original, replacement in substitutions.items():
        assert source.count(original) == 1
        source = source.replace(original, replacement)
    assert not (work / BOOK).exists()
    scope = {"__name__": "native_archive_replay", "__file__": str(verifier)}
    sys.path.insert(0, str(work))
    exec(compile(source, str(verifier), "exec"), scope)
    direct = scope["verify"](*scope["prepare"]())
    assert digest((json.dumps(direct, indent=2) + "\n").encode()) == REPORT
    assert digest((work / "VerificationCompare.json").read_bytes()) == REPORT
    assert direct["outcomes"]["Fallback"]["newton_equilibrium_returned"]
    assert direct["accepted_field_exact"] and direct["accepted_stresses_and_damage_energy_snapshot_exact"]
    return recompute_radius(scope, direct, same_ray)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stock_branch", type=Path)
    parser.add_argument("same_ray", type=Path)
    parser.add_argument("--radius-output", type=Path)
    args = parser.parse_args()
    manifest = json.loads((HERE / "PortableManifest.json").read_bytes())
    assert manifest["omitted_workbook"] == {"path": BOOK, "sha256": WORKBOOK}
    assert manifest["sources"] == SOURCES
    for key, expected in SOURCES.items():
        assert digest(getattr(args, key).read_bytes()) == expected
    with TemporaryDirectory() as temp, ZipFile(args.stock_branch) as stock, ZipFile(args.same_ray) as ray:
        work = Path(temp)
        for name, expected in manifest["files"].items():
            blob = contained(HERE, name).read_bytes()
            assert digest(blob) == expected, name
            target = contained(work, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(blob)
        for name, (member, expected) in manifest["stock_dependencies"].items():
            blob = stock.read(member)
            assert digest(blob) == expected, name
            target = contained(work, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(blob)
        radius = run(work, ray)
        output = (json.dumps(radius, indent=2) + "\n").encode()
        if args.radius_output is not None:
            args.radius_output.write_bytes(output)
        if "RadiusDirection.json" in manifest["files"]:
            assert digest(output) == manifest["files"]["RadiusDirection.json"]
        print("MVT2 AUTOMATIC FALLBACK", REPORT, "RADIUS/DIRECTION", digest(output))


if __name__ == "__main__":
    main()
