Native automatic bounded branch recovery from the MVT2 H24 stall

From the extracted directory run with Python 3.10 or later
    python -B -X utf8 ReplayPortable.py PATH/MVT2StockBranchArcNative20261116.zip PATH/MVT2SameRayDerivativeNative20261116.zip

Both dependencies are tracked under docs/regression/Coupled6D. This package
contains the frozen VBA source overlay, raw original-law data and process
receipts. It excludes workbook bytes and can be verified without Excel or
external Python libraries. Book identity is checked via the pinned source,
compiler and owned-before-open receipts. The offline replay does not recompile
the workbook. Its canonical JSON and radius/direction audit are hash checked.

Both arms start from exact original H24 at Qy=18.55811 kN, with identical
raw 1/64 arc plane and predicted field. The stock case returns NumFail.
The fallback detects the wrong-signed action of weak axial gradient row 53.
It assembles one read-only adaptive tangent and uses existing optimizer twice.
No section-specific station IDs are used. Both trials use the original
material law and original tolerance. The first maximum norm is 6.72922e-6 MPa
and the final is 8.41044e-7 MPa against tolerance 1.12176e-6 MPa. Final direct
six-force norm is 8.35685e-7 MPa. The returned Qy is 18.5708039839326 kN.

The final strain excursion from the exact archived stall is independently
verified against the native 8.93685534e-9 value and the 9.62967653e-9 limit.
The intermediate field was not exported, so its radius and continuation
direction rely on the native instrumentation. The final direction is checked
against the nominal plane and its physical arc length independently.
Every accepted H24 coordinate and all 1080 station stress/damage entries were
preserved exactly before and after the tests. The returned trial was discarded.
This acceptance applies to the isolated calculation, with no claimed strength
limit or production continuation coverage.
