# Выполняет одну траекторию MVT2 в отдельной книге с контролем процессов Excel.
param([ValidateSet('Compare')][string]$Phase='Compare',[switch]$CompiledOnly)
$ErrorActionPreference='Stop'
$repo=(Get-Location).Path
$root=$PSScriptRoot
$tempBefore=$env:TEMP
$tmpBefore=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$report="Native$Phase/MVT2.txt"
python -B -X utf8 (Join-Path $root 'Verify-MVT2ShearControlled.py') --inputs-only
if($LASTEXITCODE -ne 0){throw 'Входы MVT2 не подтверждены.'}
Push-Location -LiteralPath $root
try {
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    if (Test-Path -LiteralPath $report){throw 'Протокол этого запуска уже существует.'}
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Путь к временной книге превышает допустимый для Excel.'
    }
    if (!$CompiledOnly) {
        if (Test-Path -LiteralPath 'Compile.log'){throw 'Предыдущая компиляция требует сверки.'}
        if ((Get-FileHash -LiteralPath $draft).Hash -cne $prep.book_sha256){throw 'Приватная книга изменилась.'}
        Assert-IsolatedOfficeReady 'PreCompileMVT2'
        & (Join-Path $root 'tools/build_workbook/Update-IsolatedOptimizerCode.ps1') -WorkbookPath $draft -ModuleNames @('CCoupledConcreteResponse','CCoupledNewtonSolver','CCoupledReinforcedResponse','modCoupledConcreteTensor','modTestCoupledExperiment') |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or
        (($compiled.Modules | Sort-Object) -join ',') -cne 'CCoupledConcreteResponse,CCoupledNewtonSolver,CCoupledReinforcedResponse,modCoupledConcreteTensor,modTestCoupledExperiment' -or
        $compiled.ProductionSHA256 -cne $prep.book_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or $closure.State -cne 'Absent') {
        throw 'Компиляция тестового модуля или закрытие Excel не подтверждены.'
    }
    Assert-IsolatedOfficeReady ("BeforeMVT2Fresh"+$Phase)
    $args=@(
        '-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-FocusedKaniWatchdog.ps1'
        '-SourceWorkbook',$draft,'-ReportPath',$report,'-Macro','modTestCoupledExperiment.RunTestWangShearControlled'
        '-MacroArgument1',(Join-Path $root 'Replay.csv'),'-MacroArgument2',$Phase,'-Mode','No','-TimeoutSeconds',$prep.watchdog_seconds,'-FailFast'
    )
    $clock=[Diagnostics.Stopwatch]::StartNew()
    try {
        & $legacy @args
        $runExit=$LASTEXITCODE
    }
    finally {
        if (Test-Path -LiteralPath $report) {
            $fixture=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
            if ($fixture.Count -ne 1){throw 'Нет однозначного пути к приватной копии.'}
            $folder=Split-Path -Parent $fixture[0].Substring('FIXTURE: '.Length)
            if (!(Split-Path -Leaf $folder).StartsWith('RC_NDM_ModeSuite_',[StringComparison]::Ordinal) -or
                !$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {
                throw 'Путь протокола вне приватной копии.'
            }
            $csv=Join-Path $folder 'WangShearControlled.csv'
            if (Test-Path -LiteralPath $csv){Copy-Item -LiteralPath $csv -Destination "Native$Phase/MVT2.csv"}
        }
    }
    $clock.Stop()
    [ordered]@{native_exit=$runExit;wall_seconds=$clock.Elapsed.TotalSeconds} | ConvertTo-Json |
        Set-Content -LiteralPath "Native$Phase/RunReceipt.json" -Encoding utf8
    & python -B -X utf8 (Join-Path $root 'Verify-MVT2ShearControlled.py') --phase $Phase
    if ($LASTEXITCODE -ne 0){throw 'Независимая проверка MVT2 завершилась ошибкой.'}
    if ($runExit -ne 0){throw 'Нативный прогон MVT2 ограничен, см. подтверждённые поля.'}
}
finally {
    $env:TEMP=$tempBefore
    $env:TMP=$tmpBefore
    Pop-Location
}
