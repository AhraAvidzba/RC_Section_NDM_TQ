"""Seal and independently replay the reusable native fallback evidence."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import ReplayPortable as replay


HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[1] / "docs/regression/Coupled6D"
DEPS = {"stock_branch": REGRESSION / "MVT2StockBranchArcNative20261116.zip",
        "same_ray": REGRESSION / "MVT2SameRayDerivativeNative20261116.zip"}
RESULT = HERE / "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip"


def archive(content, deps):
    manifest = {"files": {name: replay.digest(raw) for name, raw in sorted(content.items())},
                "stock_dependencies": deps, "sources": replay.SOURCES,
                "omitted_workbook": {"path": replay.BOOK, "sha256": replay.WORKBOOK}}
    items = {**content, "PortableManifest.json": (json.dumps(manifest, indent=2) + "\n").encode()}
    assert all(not name.casefold().endswith(".xlsm") for name in (*items, *deps))
    with ZipFile(RESULT, "w", compression=ZIP_DEFLATED, compresslevel=9) as output:
        for name, data in sorted(items.items()):
            member = ZipInfo(name)
            member.compress_type = ZIP_DEFLATED
            output.writestr(member, data)


def detached(*extra):
    with TemporaryDirectory(dir=HERE / "Temp") as folder, ZipFile(RESULT) as contents:
        assert contents.testzip() is None
        contents.extractall(folder)
        subprocess.run((sys.executable, "-B", "-X", "utf8", "ReplayPortable.py", *map(str, DEPS.values()), *extra),
                       cwd=folder, check=True)


def main():
    prep = json.loads((HERE / "Preparation.json").read_bytes())
    assert replay.digest((HERE / "VerificationCompare.json").read_bytes()) == replay.REPORT
    assert prep["inputs"][replay.BOOK] == prep["book_sha256"] == replay.WORKBOOK
    for name, path in DEPS.items():
        assert replay.digest(path.read_bytes()) == replay.SOURCES[name]
    with ZipFile(DEPS["stock_branch"]) as prior:
        indexed = {replay.digest(prior.read(name)): name for name in prior.namelist()}
    local, dependencies = {}, {}
    for name, expected in prep["inputs"].items():
        if name == replay.BOOK:
            continue
        raw = (HERE / name).read_bytes()
        assert replay.digest(raw) == expected, name
        if expected in indexed:
            dependencies[name] = (indexed[expected], expected)
        else:
            local[name] = raw
    receipts = ("Preparation.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json",
                "VerificationCompare.json", "ReplayPortable.py", "PackRecovery.py", "PortableREADME.txt")
    native = tuple(f"NativeCompare/{item.name}" for item in (HERE / "NativeCompare").iterdir()
                   if item.is_file() and not item.name.endswith((".stdout.log", ".stderr.log")))
    for name in (*receipts, *native):
        local[name] = (HERE / name).read_bytes()
    archive(local, dependencies)
    radii = HERE / "RadiusDirection.json"
    detached("--radius-output", str(radii))
    local[radii.name] = radii.read_bytes()
    archive(local, dependencies)
    detached()
    print(RESULT, RESULT.stat().st_size, replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
