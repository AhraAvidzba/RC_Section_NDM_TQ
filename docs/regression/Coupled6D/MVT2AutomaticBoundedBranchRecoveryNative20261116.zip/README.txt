Private MVT2 bounded correction fallback A/B. Workbook c9e7268.

Input seal and independent verification from repository root
    python -B -X utf8 tmp/mvgf/Verify-MVT2ShearControlled.py --inputs-only

After assigning the exclusive Office slot and checking resources
    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mvgf/Run-MVT2ShearControlled.ps1

Stock and Fallback share H24, the exact 1/64 pseudo-arc target, the same
predictor, and the original material response. The fallback is enabled only
on the second arm and uses no station IDs. The signed mismatch must indicate
that the governing row grew in absolute value along a Newton ray that should
have improved it. Every column whose normal difference pairs stay on the base
branch retains its normal estimate. Columns with different branch flags or
substeps attempt h/4 once. The same side of the base material branch must be
available, or the tangent attempt fails without publishing a result.

One tangent build and up to two existing optimizer calls are allowed. The
linear objective minimizes maximal weighted strain components (each engineering
shear is weighted by 1/sqrt(2)). The actual station tensor norm is verified
separately. The six physical force rows retain weight 1 and force cap 0.75 tau.
The first weak row cap is max(0.75 tau, min(initial norm/8, 6 tau)) when a
second correction is useful. The second cap is 0.75 tau for all rows. Gauges
and the original control remain exact linear equalities. Both attempts have
the initial column-scaled box 2.5*initial norm. Original nonlinear residuals
and geometric bounds decide acceptance. Partial improvement may seed only
one trial, with the same original committed material. Failure restores
control, equations and original solver status. Fixed material or physical
limits do not follow from this diagnostic.
