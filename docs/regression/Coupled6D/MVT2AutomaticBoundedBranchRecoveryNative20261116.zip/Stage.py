"""Build the private generic bounded recovery A/B from the c9e7268 workbook."""
from hashlib import sha256
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = HERE.parent / "mvca"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
CONCRETE = "src/Materials/CCoupledConcreteResponse.cls"
REINFORCED = "src/Materials/CCoupledReinforcedResponse.cls"
TENSOR = "src/Materials/modCoupledConcreteTensor.bas"
TEST = "tests/modTestCoupledExperiment.bas"
RUNNER = "Run-MVT2ShearControlled.ps1"
VERIFY = "Verify-MVT2ShearControlled.py"
BOOK_SHA = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
BASE_PREPARATION = "5E7A69D009D5DBECFD95F18BBB21CCFEBC96C6BAF48B8B2A8232B6CDAA147549"
SOURCE_PINS = {
    CONCRETE: "92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C",
    REINFORCED: "06A82B613BB90A685E7374A0CA623B187C599A70D824E88070C99E1BCF3A7822",
    TENSOR: "E7739A8C9200C6F5F56AF5AEA5E226101AF48DE6FDA00ADD29AFB7799F29C30B",
}
MODULES = ("CCoupledConcreteResponse", "CCoupledNewtonSolver", "CCoupledReinforcedResponse", "modCoupledConcreteTensor",
           "modTestCoupledExperiment")


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def decode(raw):
    return raw.decode("utf-8-sig").replace("\r\n", "\n")


def vba(source):
    assert max(map(len, source.splitlines())) < 1023
    return source.replace("\n", "\r\n").encode("utf-8")


def overlay_newton(source):
    anchor = "Private mReferenceModulus As Double, mLastNorm As Double, mMinimumPivot As Double\n"
    source = once(source, anchor, anchor + "Private mBoundedTraceTest As Integer ' Ненулевой канал только в изолированной пробе.\n")
    anchor = "            If recoverYieldControl And Len(mismatch) > 0 And mUseSpatialHistory Then\n"
    hook = '''            If mBoundedTraceTest > 0 And mUseSpatialHistory And mControlActive And Len(mismatch) > 0 And _
                    Abs(trialEquation - baseEquation) > tolerance * 0.001 Then
                Dim boundedUsed As Long
                Print #mBoundedTraceTest, "B_FB_START;" & CStr(governingRow) & ";" & Trim$(Str$(norm)) & ";" & _
                    Trim$(Str$(tolerance)) & ";" & Trim$(Str$(currentLambda))
                If TryBoundedRecoveryTest(current, currentLambda, load, norm, tolerance, _
                        absoluteTolerance, relativeTolerance, candidateLambda, boundedUsed) Then
                    mIterations = mIterations + boundedUsed
                    PublishCandidate candidateLambda
                    SolveStep = True
                    Exit Function
                End If
            End If
'''
    source = once(source, anchor, hook + anchor)
    anchor = "Optional ByVal consistentBranch As Boolean = False, Optional ByVal refinedBranch As Boolean = False) As Boolean"
    source = once(source, anchor, "Optional ByVal consistentBranch As Boolean = False, Optional ByVal refinedBranch As Boolean = False, _\n"
                                  "        Optional ByVal matchedFallbackTest As Boolean = False) As Boolean")
    anchor = "    If withMatrix And refinedBranch Then tangentMode = ctmRefinedBranchConsistent\n"
    source = once(source, anchor, anchor + "    If withMatrix And matchedFallbackTest Then tangentMode = ctmMatchedFallbackTest\n")
    return source.rstrip() + "\n" + (HERE / "RecoverySolver.txt").read_text(encoding="utf-8")


def overlay_material(name, source):
    if name == TENSOR:
        anchor = "    ctmRefinedBranchConsistent = 4"
        line = next(line for line in source.splitlines() if line.startswith(anchor))
        return once(source, line + "\n", line + "\n    ctmMatchedFallbackTest = 5 ' ДЛЯ ТЕСТОВ: уточняет только столбцы со сменой ветви.\n")
    if name == REINFORCED:
        anchor = "    If (tangentMode = ctmFullBranchConsistent Or tangentMode = ctmRefinedBranchConsistent) And recordTrial Then\n"
        return once(source, anchor, "    If (tangentMode = ctmFullBranchConsistent Or tangentMode = ctmRefinedBranchConsistent Or _\n"
                                    "            tangentMode = ctmMatchedFallbackTest) And recordTrial Then\n")
    anchor = "    branchConsistent = (tangentMode = ctmFullBranchConsistent Or tangentMode = ctmRefinedBranchConsistent)\n"
    source = once(source, anchor, "    branchConsistent = (tangentMode = ctmFullBranchConsistent Or tangentMode = ctmRefinedBranchConsistent Or _\n"
                                  "        tangentMode = ctmMatchedFallbackTest)\n")
    anchor = "    branchConsistent = (mode = ctmFullBranchConsistent Or mode = ctmRefinedBranchConsistent)\n"
    source = once(source, anchor, "    Dim matchedFallback As Boolean: matchedFallback = (mode = ctmMatchedFallbackTest)\n"
                                  "    branchConsistent = (mode = ctmFullBranchConsistent Or mode = ctmRefinedBranchConsistent Or matchedFallback)\n")
    anchor = "                    If plusOk Or minusOk Then Exit For\n                    If attempt = 3 And atAcceptedPosition Then\n"
    replacement = '''                    If matchedFallback Then
                        If plusOk And minusOk Then Exit For ' Штатная разность при совпадении обеих ветвей.
                        If attempt = 2 Then Exit For ' На h/4 допускается только сторона той же ветви.
                    ElseIf plusOk Or minusOk Then
                        Exit For
                    End If
                    If attempt = 3 And atAcceptedPosition Then
'''
    return once(source, anchor, replacement)


def overlay_macro(source):
    source = once(source, '    For Each mode In Array("Stock", "Branch")', '    For Each mode In Array("Stock", "Fallback")')
    source = once(source, '        lambda = qTrial: started = Timer',
                  '        If mode = "Fallback" Then solver.EnableBoundedRecoveryTest output\n'
                  '        lambda = qTrial: started = Timer')
    source = once(source, '            ABS_TOL, REL_TOL, MAX_ITERATIONS, consistentControl:=(mode = "Branch"), initialField:=seed, loadProjection:=loadProjection)',
                  '            ABS_TOL, REL_TOL, MAX_ITERATIONS, consistentControl:=False, initialField:=seed, loadProjection:=loadProjection)\n'
                  '        If mode = "Fallback" Then solver.EnableBoundedRecoveryTest 0')
    return source


def overlay_verifier(source):
    source = once(source, 'labels = ("Stock", "Branch")', 'labels = ("Stock", "Fallback")')
    source = once(source, '"ReplayBranch"', '"ReplayFallback"')
    source = once(source, '"AfterBranch"', '"AfterFallback"')
    source = once(source, '["CCoupledNewtonSolver", "modTestCoupledExperiment"]', str(list(MODULES)))
    anchor = '    return {"book_sha256": prep["book_sha256"], "H24_replay_sha256": prep["replay_sha256"], "trace_sha256": v.digest(path),'
    addition = '''    assert not results["Stock"]["newton_equilibrium_returned"]
    assert results["Stock"]["internal_status"] == 6 and results["Stock"]["result_code"] == 10
    [[row, norm, tolerance, factor]] = tags["B_FB_START"]
    assert int(row) == 53
    assert abs(float(norm) - 7.22225739794488e-5) < 4e-10
    assert abs(float(factor) - 18.5708155282075) < 1e-11
    assert .5e-6 < float(tolerance) < 2.e-6
    optimizers = [tuple(map(int, item)) for item in tags["B_FB_OPT"]]
    trial_rows = [tuple(map(float, item)) for item in tags["B_FB_TRIAL"]]
    radius_rows = [tuple(map(float, item)) for item in tags["B_FB_RADIUS"]]
    assert len(optimizers) <= 2 and all(1 <= i <= 2 and 0 <= solves <= 280 for i, _, solves in optimizers)
    assert len(trial_rows) <= len(radius_rows) <= len(optimizers)
    assert all(actual < start for _, start, actual, _, _, _ in trial_rows[:-1])
    successful = results["Fallback"]["newton_equilibrium_returned"]
    if successful:
        assert trial_rows and trial_rows[-1][2] <= trial_rows[-1][4]
        assert all(incremental <= cap and full <= cap for _, incremental, full, cap in radius_rows)
        assert results["Fallback"]["within_local_radius"]
        assert not tags["B_FB_STOP"]
    else:
        assert len(tags["B_FB_STOP"]) == 1
    fallback = {"starting_row_and_norm": [int(row), float(norm)], "linear_solves": optimizers,
                "original_law_trials": trial_rows, "tensors_radii": radius_rows,
                "failed_at": tags["B_FB_STOP"]}
'''
    source = once(source, anchor, addition + anchor)
    return once(source, '"history_published": False, "physical_limit_claimed": False, "outcomes": results,',
                '"history_published": False, "physical_limit_claimed": False, "outcomes": results, "fallback": fallback,')


def overlay_runner(source):
    old = "@('CCoupledNewtonSolver','modTestCoupledExperiment')"
    source = once(source, old, "@(" + ",".join(f"'{name}'" for name in MODULES) + ")")
    return once(source, "'CCoupledNewtonSolver,modTestCoupledExperiment'", "'" + ",".join(MODULES) + "'")


def main():
    base = (BASE / "Preparation.json").read_bytes()
    assert digest(base) == BASE_PREPARATION
    frozen = json.loads(base)
    book = (ROOT / BOOK).read_bytes()
    assert digest(book) == frozen["book_sha256"] == BOOK_SHA
    inputs = {BOOK: put(BOOK, book)}
    put("docs/regression/Diagnostic.xlsm", book)
    for folder in ("NativeCompare", "Temp"):
        (HERE / folder).mkdir(exist_ok=True)
    for name, expected in frozen["inputs"].items():
        raw = (BASE / name).read_bytes()
        assert digest(raw) == expected
        if name == "Stage.py":
            continue
        if name == NEWTON:
            raw = vba(overlay_newton(decode(raw)))
        elif name == TEST:
            raw = vba(overlay_macro(decode(raw)))
        elif name == RUNNER:
            raw = overlay_runner(decode(raw)).encode("utf-8")
        elif name == VERIFY:
            raw = overlay_verifier(decode(raw)).encode("utf-8")
        inputs[name] = put(name, raw)
    for name, expected in SOURCE_PINS.items():
        raw = (ROOT / name).read_bytes()
        assert digest(raw) == expected
        inputs[name] = put(name, vba(overlay_material(name, decode(raw))))
    for name in ("Stage.py", "RecoverySolver.txt", "README.txt"):
        inputs[name] = digest((HERE / name).read_bytes())
    result = {"inputs": inputs, "book_sha256": BOOK_SHA, "replay_sha256": frozen["replay_sha256"],
              "watchdog_seconds": 150, "baseline_native_preparation_sha256": BASE_PREPARATION, "material_source_pins": SOURCE_PINS}
    print(put("Preparation.json", (json.dumps(result, indent=2) + "\n").encode("utf-8")))


if __name__ == "__main__":
    main()
