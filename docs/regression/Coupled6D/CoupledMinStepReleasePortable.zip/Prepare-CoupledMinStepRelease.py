"""Freeze the coupled solver and directed tests in a copy of the built workbook."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
BASE_DIR = Path('workbook/output')
BOOK = 'RC_Section_NDM.xlsm'
EXPORT = 'VBA_All_Code.txt'
EXPECTED = {BOOK:'52E2CB3A1AB371B323B8B4E3DD4FF64B572A7A438AEF478C981F09EB9FCA7BA3',
            EXPORT:'E37BA80AB10E79FDEBB92216B7C57CACF9B05BE68BDBC17B83BA6531B8B85A0A'}
TOOLS = ('Update-PrivateWorkbookCode.ps1','GeometryExampleSupport.ps1','SettingsCatalog.ps1','Run-Audit03Watchdog.ps1',
         'Run-Audit02ModeTests.ps1','WorkbookLayout.ps1','NormativeFormulaImages.ps1','GeometryTables.ps1',
         'WorkbookLayout.json','NormativeFormulaImages.json','GeometryTables.json','HelpSettingsDescriptions.json',
         'NormativeHelpReferences.json','HelpFormulaExplanations.json','NormativeHelpSources.json')
REFERENCE = Path('docs/regression/Audit03/CoupledSteelEventResults20261116')
HARDENED = Path('docs/regression/Audit03/LocalGradientDerivative20261115/PhysicalGaugeReview20261116/MVT2SourceControl/PairedColdNative')
STAGED_SOURCES = (Path('src/Solver/CCoupledLoadContinuation.cls'), Path('tests/modTestCoupledElasticState.bas'))
CONTROL_FILES = ('Prepare-CoupledMinStepRelease.py','Verify-CoupledMinStepRelease.py','Run-CoupledMinStepRelease.ps1',
                 'Publish-VerifiedWorkbook.py','NativeSuites.json')
SOURCE_NAMES = tuple(source.stem for source in STAGED_SOURCES)
DRAFT = Path('docs/regression/Compiled.xlsm')
CANDIDATE = Path('docs/regression',BOOK)
RECEIPT = HERE/'Preparation.json'


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def require_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before,after,1)


def direct_copies(repo):
    return {**{BASE_DIR/name:repo/BASE_DIR/name for name in EXPECTED},
            **{source:repo/source for source in STAGED_SOURCES},
            **{Path('tools/build_workbook',name):repo/'tools/build_workbook'/name for name in TOOLS},
            Path('tools/build_workbook/Update-IsolatedOptimizerCode.ps1'):
                repo/HARDENED/'tools/build_workbook/Update-PairedColdPrivateCode.ps1',
            Path('tools/build_workbook/Verify-ExportDifference.py'):repo/REFERENCE/'Verify-ExportDifference.py'}


def scripts(repo):
    saved_export = (repo/REFERENCE/'Export-VerifiedVBA.ps1').read_text(encoding='utf-8-sig')
    saved_export = require_once(saved_export, '$ownedPid=0;$ownedTicks=0',
                                '$ownedPid=0;$ownedTicks=0\n$preexisting=@(Get-Process Excel -ErrorAction SilentlyContinue)')
    saved_export = require_once(saved_export, '$ownedPid=[int]$id;$ownedTicks=(Get-Process -Id $ownedPid).StartTime.ToUniversalTime().Ticks',
                                "$owner=Get-Process -Id $id -ErrorAction Stop\n    if ($id -le 0 -or $id -in $preexisting.Id -or $owner.ProcessName -ine 'EXCEL') { throw 'Export requires a verified new Excel instance.' }\n    $ownedPid=[int]$id;$ownedTicks=$owner.StartTime.ToUniversalTime().Ticks")
    marker = '    $excel.Visible = $false\n    $excel.DisplayAlerts = $false\n    $excel.AutomationSecurity = 3\n    $excel.EnableEvents=$false\n'
    saved_export = require_once(saved_export,marker,'')
    saved_export = require_once(saved_export, "    Write-Output 'EXPORT_OPEN_START'", marker + "    Write-Output 'EXPORT_OPEN_START'")
    saved_export = require_once(saved_export,'        $excel.Quit()','        if ($ownedPid) {$excel.Quit()}')
    source_verify = (repo/REFERENCE/'Verify-Source.ps1').read_text(encoding='utf-8-sig')
    source_verify = require_once(source_verify,'docs/regression/Audit03/CoupledSteelEventResults20261116','docs/regression')
    source_verify = require_once(source_verify,'$extra=@($components.Keys | Where-Object {-not $sourceNames.ContainsKey($_) -and $types[$_] -ne 100})',
                                 '$extra=@() # Остальные компоненты проверяются по исходной выгрузке отдельной сверкой.')
    return {Path('tools/build_workbook/Export-VerifiedVBA.ps1'):saved_export.encode('utf-8-sig'),
            Path('tools/build_workbook/Verify-SolverSource.ps1'):source_verify.encode('utf-8-sig')}


def validate_baseline():
    assert all(digest(HERE/BASE_DIR/name) == expected for name,expected in EXPECTED.items())
    with ZipFile(HERE/BASE_DIR/BOOK) as book:
        parts = book.namelist()
        assert len(parts) == 122 and len(set(parts)) == len(parts) and 'xl/vbaProject.bin' in parts
        assert not any('signature' in part.lower() for part in parts)
        assert book.testzip() is None
        signatures = {part:sha256(book.read(part)).hexdigest().upper() for part in parts}
    return signatures


def native_plan():
    plan = json.loads((HERE/'NativeSuites.json').read_text(encoding='utf-8-sig'))
    assert isinstance(plan,list) and plan
    for suite in plan:
        assert set(suite) == {'macro','total','passed'}
        assert re.fullmatch(r'modTest[A-Za-z0-9_]+\.[A-Za-z0-9_]+',suite['macro'])
        assert re.fullmatch(r'TOTAL_[A-Z0-9_]+',suite['total'])
        assert type(suite['passed']) is int and suite['passed'] > 0
    assert len({suite['macro'] for suite in plan}) == len(plan)
    assert len({suite['total'] for suite in plan}) == len(plan)
    return plan


def stage(repo, required_commit):
    head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
    assert re.fullmatch(r'[0-9a-f]{40}', required_commit or '') and head == required_commit, (required_commit, head)
    assert not subprocess.check_output(['git','status','--porcelain'], cwd=repo, text=True).strip(), 'Release source tree must be clean'
    for name, expected in EXPECTED.items():
        assert digest(repo/BASE_DIR/name) == expected, name
    assert not any((HERE/path).exists() for path in (DRAFT,CANDIDATE,RECEIPT))
    plan = native_plan()
    assert any(suite['total'] == 'TOTAL_COUPLED_MINIMUM_LOAD_STEP' for suite in plan), 'Minimum load-step regression is not registered'
    baseline_commit = '7606436'
    for source in STAGED_SOURCES:
        baseline = subprocess.check_output(['git','show',f'{baseline_commit}:{source.as_posix()}'],cwd=repo)
        # Git normalizes working-tree line endings in some checkouts.
        assert (repo/source).read_bytes().replace(b'\r\n',b'\n') != baseline.replace(b'\r\n',b'\n'), source
    for suite in plan:
        module,function = suite['macro'].split('.')
        matching = [source for source in STAGED_SOURCES if source.stem == module]
        for source in matching:
            content = (repo/source).read_text(encoding='utf-8-sig')
            assert re.search(rf'^Public Function {function}\(',content,re.M), suite['macro']
            assert suite['total'] in content, suite['total']
    frozen = direct_copies(repo)
    generated = scripts(repo)
    for name, original in frozen.items():
        assert original.is_file(), original
        target = HERE/name
        assert not target.exists(), target
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(original,target)
        assert digest(original) == digest(target), original
    for name, contents in generated.items():
        target = HERE/name
        assert not target.exists(), target
        target.write_bytes(contents)
    # Только компилятор открывает эту копию на запись; кандидат образуется отдельной упаковкой.
    (HERE/DRAFT).parent.mkdir(parents=True,exist_ok=True)
    (HERE/'tests').mkdir(exist_ok=True)
    shutil.copyfile(HERE/BASE_DIR/BOOK,HERE/DRAFT)
    manifest = {'base_sha256':EXPECTED,'baseline_package_parts':validate_baseline(),
                'modules':list(SOURCE_NAMES),'sources':[source.as_posix() for source in STAGED_SOURCES],
                'source_git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
                'native_plan':plan,
                'controls':{name:digest(HERE/name) for name in CONTROL_FILES},
                'frozen':{name.as_posix():digest(HERE/name) for name in (*frozen,*generated)}}
    for source in STAGED_SOURCES:
        text = (HERE/source).read_text(encoding='utf-8-sig')
        assert re.search(rf'^Attribute VB_Name = "{source.stem}"$',text,re.M) and re.search(r'^Option Explicit$',text,re.M)
    RECEIPT.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(digest(RECEIPT))


def check(repo=None):
    manifest = json.loads(RECEIPT.read_text(encoding='utf-8'))
    assert manifest['baseline_package_parts'] == validate_baseline()
    assert manifest['modules'] == list(SOURCE_NAMES)
    assert manifest['sources'] == [source.as_posix() for source in STAGED_SOURCES]
    assert manifest['native_plan'] == native_plan()
    assert manifest['controls'] == {name:digest(HERE/name) for name in CONTROL_FILES}
    for name, expected in manifest['frozen'].items():
        assert digest(HERE/name) == expected, name
    if repo is not None:
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() == manifest['source_git_head']
        for name in (*STAGED_SOURCES,*(BASE_DIR/name for name in EXPECTED)):
            assert digest(repo/name) == manifest['frozen'][name.as_posix()], name
    print(digest(RECEIPT))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage-from',type=Path)
    parser.add_argument('--check-current',type=Path)
    parser.add_argument('--source-commit')
    options = parser.parse_args()
    if options.stage_from is not None:
        stage(options.stage_from.resolve(strict=True), options.source_commit)
    check(options.check_current)
