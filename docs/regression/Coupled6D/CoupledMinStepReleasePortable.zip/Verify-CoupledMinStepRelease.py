"""Assemble or verify the isolated candidate and the reopened Excel export."""

import argparse
from copy import copy
from hashlib import sha256
import json
from pathlib import Path
import re
import runpy
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
BASE = HERE/'workbook/output'
OUT = HERE/'docs/regression'
BOOK = 'RC_Section_NDM.xlsm'
EXPORT = 'VBA_All_Code.txt'
VBA = 'xl/vbaProject.bin'
PREP = HERE/'Preparation.json'
COMPILED = OUT/'Compiled.xlsm'
PACKAGE = OUT/'PackageChecks.json'


def digest(value):
    return sha256(value if isinstance(value,bytes) else value.read_bytes()).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write_json(path, data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')


def package():
    prep = read_json(PREP)
    compile_receipt = read_json(OUT/'CodeUpdate.json')
    assert compile_receipt['Compiled'] and not compile_receipt['ProductionChanged']
    assert compile_receipt['ProductionSHA256'] == prep['base_sha256'][BOOK] == digest(BASE/BOOK)
    assert compile_receipt['WorkbookSHA256'] == digest(COMPILED)
    assert set(compile_receipt['Modules']) == set(prep['modules']) and len(compile_receipt['Modules']) == len(prep['modules']) == 2
    assert read_json(OUT/'CompileClosure.json')['State'] == 'Absent'
    candidate = OUT/BOOK
    with ZipFile(BASE/BOOK) as baseline, ZipFile(COMPILED) as compiled:
        updated_code = compiled.read(VBA)
        assert baseline.read(VBA) != updated_code
        if not candidate.exists():
            pending = candidate.with_suffix('.pending')
            assert not pending.exists()
            with ZipFile(pending,'x') as output:
                output.comment = baseline.comment
                for entry in baseline.infolist():
                    content = updated_code if entry.filename == VBA else baseline.read(entry)
                    output.writestr(copy(entry),content)
            check_parts(baseline,pending,updated_code,prep)
            pending.rename(candidate)
        check_parts(baseline,candidate,updated_code,prep)
    receipt = {'status':'PASS','baseline_sha256':prep['base_sha256'][BOOK],'preparation_sha256':digest(PREP),
               'compiled_sha256':digest(COMPILED),'candidate_sha256':digest(candidate),'vba_sha256':digest(updated_code),
               'changed_parts':[VBA],'identical_parts':len(prep['baseline_package_parts'])-1,'modules':prep['modules']}
    if PACKAGE.exists():
        assert read_json(PACKAGE) == receipt
    else:
        write_json(PACKAGE,receipt)
    print(f"PACKAGE_VERIFIED: {receipt['candidate_sha256']}")
    return receipt


def check_parts(baseline, candidate, updated, prep):
    with ZipFile(candidate) as result:
        assert result.testzip() is None and result.comment == baseline.comment
        assert result.namelist() == baseline.namelist()
        actual = {entry:digest(result.read(entry)) for entry in result.namelist()}
        expected = prep['baseline_package_parts']
        assert [entry for entry in result.namelist() if actual[entry] != expected[entry]] == [VBA]
        assert actual[VBA] == digest(updated)


def native_proof(candidate_hash):
    report = OUT/'DirectedNative.txt'
    text = report.read_text(encoding='utf-8-sig')
    plan = read_json(PREP)['native_plan']
    expected = [(item['total'],str(item['passed']),'0') for item in plan]
    actual = re.findall(r'^(TOTAL_[A-Z0-9_]+): passed=(\d+); failed=(\d+)$',text,re.M)
    assert actual == expected, {'expected':expected,'actual':actual}
    expected_macros = [item['macro'] for item in plan]
    assert re.findall(r'^SUITE_STARTED: ([^;]+);',text,re.M) == expected_macros
    assert re.findall(r'^SUITE_FINISHED: ([^;]+);',text,re.M) == expected_macros
    assert 'SOURCE_UNCHANGED: True' in text and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    closure = read_json(report.with_suffix('.txt.ProcessClosure.json'))
    owner = read_json(report.with_suffix('.txt.Ownership.json'))
    assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0 and closure['RunnerCleanupValid']
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == candidate_hash
    identity = closure['Closure']['Identity']
    final = closure['Closure']['FinalState']
    assert not closure['OrdinaryPathKilledAnything']
    assert identity['Valid'] and identity['PID'] == owner['PID'] and str(identity['Ticks']) == str(owner['StartTicksUTC'])
    assert final['State'] == 'Absent' and final['PID'] == owner['PID']
    assert str(final['StartTicksUTC']) == str(owner['StartTicksUTC'])
    return {'report_sha256':digest(report),'totals':{item['total']:item['passed'] for item in plan},
            'owned_pid':owner['PID'],'owned_ticks':owner['StartTicksUTC']}


def export_proof(candidate_hash, requested):
    known = runpy.run_path(str(HERE/'tools/build_workbook/Verify-ExportDifference.py'))
    baseline,candidate = (known['modules'](file) for file in (BASE/EXPORT,OUT/EXPORT))
    assert len(baseline) == 225 and set(candidate) == set(baseline)
    assert all(baseline[name][0] == candidate[name][0] for name in baseline)
    code_case = known['code_case']
    raw = sorted(name for name in baseline if baseline[name] != candidate[name])
    changes = [name for name in raw if list(map(code_case,baseline[name][1])) != list(map(code_case,candidate[name][1]))]
    assert set(changes) == set(requested) and len(changes) == len(requested)
    selected = read_json(OUT/'SolverSourceEquality.json')
    assert selected['Passed'] and selected['SourceComponents'] == len(requested) and selected['ExportComponents'] == len(candidate)
    assert {record['Name'] for record in selected['Components'] if record['Equal']} == set(requested)
    prep = read_json(PREP)
    paths = {Path(source).stem:source for source in prep['sources']}
    assert all(record['SourceSHA256'] == prep['frozen'][paths[record['Name']]] for record in selected['Components'])
    export_log = (OUT/'Export.log').read_text(encoding='utf-8-sig')
    assert len(re.findall(rf'VBA_READ_ONLY_EXPORT: components={len(candidate)}; sourceSHA256={candidate_hash}; sourceUnchanged=True;',export_log)) == 1
    export_closure = read_json(OUT/'ExportClosure.json')
    assert export_closure['State'] == 'Absent'
    return {'components':len(candidate),'semantic_changed':changes,
            'case_only':sorted(set(raw)-set(changes)),'export_sha256':digest(OUT/EXPORT),
            'owned_pid':export_closure['PID'],'owned_ticks':export_closure['StartTicksUTC']}


def verify():
    pack = package()
    native = native_proof(pack['candidate_sha256'])
    export = export_proof(pack['candidate_sha256'],pack['modules'])
    compile_close = read_json(OUT/'CompileClosure.json')
    identities = {(compile_close['PID'],compile_close['StartTicksUTC']),
                  (native['owned_pid'],native['owned_ticks']),(export['owned_pid'],export['owned_ticks'])}
    assert len(identities) == 3
    proof = {'status':'PASS','package':pack,'scoped_native':native,'reopened_export':export}
    write_json(OUT/'ReleaseVerification.json',proof)
    print(f"DIRECTED_RELEASE_VERIFIED: {digest(OUT/'ReleaseVerification.json')}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('package','verify'))
    actions = {'package':package,'verify':verify}
    actions[parser.parse_args().stage]()
