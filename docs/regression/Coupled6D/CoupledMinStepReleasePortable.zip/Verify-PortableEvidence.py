"""Check the archived release evidence and compare both supplied workbook pairs."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import runpy
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
EVIDENCE=HERE/"docs/regression"
BOOK="RC_Section_NDM.xlsm"
EXPORT="VBA_All_Code.txt"
VBA="xl/vbaProject.bin"

def digest(value):
    return sha256(value if isinstance(value, bytes) else value.read_bytes()).hexdigest().upper()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def require(condition, label):
    if not condition:
        raise ValueError(label)

def archive():
    files=read(HERE/"ArchiveInputs.json")
    for name,wanted in files.items():
        path=(HERE/name).resolve(strict=True)
        require(path.is_relative_to(HERE) and digest(path)==wanted, "Archive input mismatch: "+name)
    return files

def compare_books(before, after, prep, package):
    require(digest(before)==prep["base_sha256"][BOOK], "Wrong baseline workbook")
    require(digest(after)==package["candidate_sha256"], "Wrong candidate workbook")
    with ZipFile(before) as baseline, ZipFile(after) as candidate:
        names=baseline.namelist()
        require(len(names)==len(set(names))==122 and candidate.namelist()==names, "Workbook part list changed")
        require(baseline.testzip() is None and candidate.testzip() is None, "Workbook CRC failure")
        require(baseline.comment==candidate.comment, "Workbook archive comment changed")
        base_parts={name:digest(baseline.read(name)) for name in names}
        candidate_parts={name:digest(candidate.read(name)) for name in names}
        require(base_parts==prep["baseline_package_parts"], "Baseline package hashes differ")
        changed=[name for name in names if base_parts[name]!=candidate_parts[name]]
        require(changed==package["changed_parts"]==[VBA] and package["identical_parts"]==121,
                "A workbook part outside VBA changed")
        require(candidate_parts[VBA]==package["vba_sha256"], "VBA package hash differs")
    return {"candidate_parts":len(names), "parts_with_same_bytes":len(names)-len(changed), "changed_parts":changed}

def compare_exports(before,after,prep,expected):
    require(digest(before)==prep["base_sha256"][EXPORT], "Wrong baseline export")
    require(digest(after)==expected["export_sha256"], "Wrong candidate export")
    parser=runpy.run_path(str(HERE/"tools/build_workbook/Verify-ExportDifference.py"))
    first,last=(parser["modules"](path) for path in (before,after))
    require(len(first)==len(last)==225 and first.keys()==last.keys(), "VBA module inventory differs")
    require(all(first[name][0]==last[name][0] for name in first), "VBA module type differs")
    raw=sorted(name for name in first if first[name]!=last[name])
    changed=[name for name in raw if list(map(parser["code_case"],first[name][1]))!=list(map(parser["code_case"],last[name][1]))]
    require(changed==expected["semantic_changed"] and set(changed)==set(prep["modules"]), "Unexpected VBA code changes")
    require(sorted(set(raw)-set(changed))==expected["case_only"], "Unexpected VBA case-only changes")
    return {"components":len(first),"semantic_changed":changed,"case_only":sorted(set(raw)-set(changed))}

def check_sources(source,prep,release):
    equality=read(EVIDENCE/"SolverSourceEquality.json")
    require(equality["Passed"] and equality["SourceComponents"]==len(prep["sources"])
            and equality["ExportComponents"]==225,"Archived source equality did not pass")
    components={row["Name"]:row for row in equality["Components"]}
    require(set(components)==set(prep["modules"]), "Source equality module mismatch")
    for source_name in prep["sources"]:
        found=digest(source/source_name)
        row=components[Path(source_name).stem]
        require(found==prep["frozen"][source_name]==row["SourceSHA256"] and row["Equal"],
                "Frozen source hash mismatch: "+source_name)
    require(release["reopened_export"]["export_sha256"]==equality["ExportSHA256"], "Archived equality export mismatch")
    return sorted(components)

def check_owned(stage,expected_owner):
    receipt=read(EVIDENCE/(stage+"Closure.json"))
    log=(EVIDENCE/(stage+".log")).read_text(encoding="utf-8-sig")
    owners=re.findall(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$",log,re.M)
    require(receipt["State"]=="Absent" and owners==[(str(receipt["PID"]),receipt["StartTicksUTC"])],
            stage+" process identity differs")
    owner=(receipt["PID"],receipt["StartTicksUTC"])
    if expected_owner:
        require(owner==expected_owner,stage+" process identity differs from release proof")
    return owner

def check_native(prep,proof,pack):
    path=EVIDENCE/"DirectedNative.txt"
    content=path.read_text(encoding="utf-8-sig")
    require(digest(path)==proof["report_sha256"], "Archived test report hash differs")
    suites=prep["native_plan"]
    expected=[(row["total"],str(row["passed"]),"0") for row in suites]
    require(re.findall(r"^(TOTAL_[A-Z0-9_]+): passed=(\d+); failed=(\d+)$",content,re.M)==expected,
            "Archived test totals do not match plan")
    for signal in ("STARTED","FINISHED"):
        require(re.findall(rf"^SUITE_{signal}: ([^;]+);",content,re.M)==[row["macro"] for row in suites],
                "Archived suite " + signal + " order differs")
    require("WATCHDOG_COMPLETED: exit=0; source unchanged=True" in content,"Native watchdog failed")
    require(proof["totals"]=={row["total"]:row["passed"] for row in suites},"Release totals do not match plan")
    owner=read(EVIDENCE/"DirectedNative.txt.Ownership.json")
    require(owner["ProcessName"]=="EXCEL" and owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"]
            and owner["SourceSHA256"]==pack["candidate_sha256"],"Native owner not linked to the candidate")
    ident=(owner["PID"],owner["StartTicksUTC"])
    require(ident==(proof["owned_pid"],proof["owned_ticks"]),"Native owner differs from release proof")
    closed=read(EVIDENCE/"DirectedNative.txt.ProcessClosure.json")
    identity=closed["Closure"]["Identity"]
    final=closed["Closure"]["FinalState"]
    require(closed["Passed"] and closed["ChildHasExited"] and closed["ChildExitCode"]==0
            and closed["RunnerCleanupValid"] and not closed["OrdinaryPathKilledAnything"]
            and identity["Valid"] and (identity["PID"],str(identity["Ticks"]))==ident
            and final["State"]=="Absent" and (final["PID"],final["StartTicksUTC"])==ident,"Native owner closure differs")
    cleanup=read(EVIDENCE/"DirectedNative.txt.RunnerCleanup.json")
    require(cleanup==closed["RunnerCleanup"] and cleanup["OwnerVerified"] and not cleanup["Failed"],
            "Archived runner cleanup differs")
    return ident, {"suites":len(suites),"assertions":sum(row["passed"] for row in suites)}

def main(before,after,source):
    archived=archive()
    prep=read(HERE/"Preparation.json")
    suite_plan=read(HERE/"NativeSuites.json")
    require(prep["native_plan"]==suite_plan,"Suite control differs from preparation")
    for name,wanted in prep["controls"].items():
        require(archived[name]==wanted, "Archived control differs: "+name)
    release=read(EVIDENCE/"ReleaseVerification.json")
    pack=release["package"]
    export=release["reopened_export"]
    require(release["status"]=="PASS" and pack==read(EVIDENCE/"PackageChecks.json")
            and pack["preparation_sha256"]==digest(HERE/"Preparation.json"),"Wrong release receipt")
    compiler=read(EVIDENCE/"CodeUpdate.json")
    require(compiler["Compiled"] and not compiler["ProductionChanged"]
            and compiler["ProductionSHA256"]==prep["base_sha256"][BOOK]
            and compiler["WorkbookSHA256"]==pack["compiled_sha256"]
            and set(compiler["Modules"])==set(prep["modules"]),"Archived compiler receipt differs")
    books=compare_books(before/BOOK,after/BOOK,prep,pack)
    exports=compare_exports(before/EXPORT,after/EXPORT,prep,export)
    sources=check_sources(source,prep,release)
    native, counts=check_native(prep,release["scoped_native"],pack)
    compiler_owner=check_owned("Compile",None)
    export_owner=check_owned("Export",(export["owned_pid"],export["owned_ticks"]))
    log=(EVIDENCE/"Export.log").read_text(encoding="utf-8-sig")
    require(len(re.findall(rf"VBA_READ_ONLY_EXPORT: components=225; sourceSHA256={pack['candidate_sha256']}; sourceUnchanged=True;",log))==1,
            "Archived readonly export is not bound to the candidate")
    require(len({compiler_owner,native,export_owner})==3,"Release did not record three separate Excel instances")
    return {
        "status":"PASS",
        "source_revision":prep["source_git_head"],
        "verified_files_in_archive":len(archived),
        "recomputed":{"workbook_package":books,"export_comparison":exports,"source_files":sources},
        "archived_receipts":{"directed_native":counts,"closed_owner_identities":[compiler_owner,native,export_owner]},
        "vba_and_excel_executed":False,
    }

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline",type=Path,required=True)
    parser.add_argument("--candidate",type=Path,required=True)
    parser.add_argument("--source",type=Path,required=True)
    args=parser.parse_args()
    result=main(*(path.resolve(strict=True) for path in (args.baseline,args.candidate,args.source)))
    print(json.dumps(result,indent=2,ensure_ascii=False))