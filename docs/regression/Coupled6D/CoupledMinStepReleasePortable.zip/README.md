# Повтор направленной проверки минимального подшага

Версия исходников b601a71fa5bfb0b74698d305eabfca15ae82655d. Исходная пара XLSM и VBA из 7606436. В подготовке сохранены SHA-256 исходной пары, VBA-компонентов, сценариев и отдельных частей XLSM. Направленный план состоит из девяти макросов и 707 проверок.

## Повтор сборки и нативного прогона

Команды выполняются из корня рабочей копии исходной версии b601a71. Распакуйте сценарии в новый короткий каталог на диске с достаточным свободным местом и без одноимённых результатов прежней сборки.

    $repo = (Get-Location).Path
    $release = 'D:/CodexScratch/RC_Section_NDM_TQ/CoupledMinStepReplay'
    python -B -X utf8 "$release/Prepare-CoupledMinStepRelease.py" --stage-from $repo --source-commit b601a71fa5bfb0b74698d305eabfca15ae82655d --check-current $repo
    & "$release/Run-CoupledMinStepRelease.ps1" -Stage All

Подготовка фиксирует два изменённых компонента. Упаковка переносит только xl/vbaProject.bin. Проверочный Excel открывает отдельную копию кандидата. Ещё один экземпляр открывает такую же копию только для чтения и выгружает 225 компонентов. Сценарий сохраняет сведения о ресурсах, идентичности и завершении трёх собственных процессов.

## Офлайн-проверка

Распакуйте архив в новый каталог. Подготовьте предыдущую пару, проверенный кандидат и снимок исходников версии b601a71fa5bfb0b74698d305eabfca15ae82655d. Кандидат после установки находится в workbook/output. Книги и выгрузки предоставляются отдельно.

    git archive --format=zip -o MinStepBaseline.zip 7606436 -- workbook/output/RC_Section_NDM.xlsm workbook/output/VBA_All_Code.txt
    git archive --format=zip -o MinStepSource.zip b601a71fa5bfb0b74698d305eabfca15ae82655d -- src/Solver/CCoupledLoadContinuation.cls tests/modTestCoupledElasticState.bas
    Expand-Archive -LiteralPath MinStepBaseline.zip -DestinationPath MinStepBaseline
    Expand-Archive -LiteralPath MinStepSource.zip -DestinationPath MinStepSource
    python -B -X utf8 MinStepEvidence/Verify-PortableEvidence.py --baseline MinStepBaseline/workbook/output --candidate workbook/output --source MinStepSource

Проверка пересчитывает контрольные суммы архивных и предоставляемых файлов, CRC, состав и байты частей XLSM. Она заново сопоставляет тип и тело каждого компонента двух экспортов. Выполнение 707 утверждений, закрытие Excel и связь отчётов с исходниками сверяются по нативным квитанциям. Офлайн-проверка не запускает Excel.