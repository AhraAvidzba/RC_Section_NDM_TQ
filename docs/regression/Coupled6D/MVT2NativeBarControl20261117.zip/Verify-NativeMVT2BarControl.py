"""Сверяет продолжение MVT2 в VBA скалярным расчётом материалов и всех уравнений."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum, isclose
from pathlib import Path
import re
from tempfile import TemporaryDirectory
from zipfile import ZipFile


PREF = ('MVT2IntegratedSteelCorrection20261117.zip','20D400686306651D3605A60FEF7B81D4838BF3A368591264243F74434AFC88DC')
FLOW = ('MVT2TabulatedActiveSteel20261117.zip','12AC8259874E45568C5B04BB110F4C17D18FDEBD617532A30DE34C262B999792')
BOOK = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'


def digest(data):
    """Возвращает точный отпечаток входа или исходника."""
    return sha256(data).hexdigest().upper()


def read(file):
    """Читает нативную квитанцию, допускающую UTF-8 BOM."""
    return json.loads(file.read_text('utf-8-sig'))


def sealed(repo, entry):
    """Открывает закреплённые данные самостоятельного расчёта VBA."""
    path=repo/'docs/regression/Coupled6D'/entry[0]
    assert digest(path.read_bytes())==entry[1]
    return ZipFile(path)


def script(z, name):
    """Подключает сохранённую скалярную реализацию из проверенного пакета."""
    env={'__name__':'__pinned__','__file__':name}
    exec(compile(z.read(name),name,'exec'),env)
    return env


def references(repo,temp):
    """Восстанавливает геометрию, материал и исходный префикс 38 совместных полей."""
    with sealed(repo,FLOW) as z:
        helper=script(z,'Verify-MVT2TabulatedContinuation.py')
    old,_,mesh,support,eq=helper['load'](repo,temp)
    with helper['archive'](repo,helper['OPERATORS']) as z:
        utilities=script(z,'Verify-NativeFollow.py')['read_references'](repo)[0]
    with sealed(repo,PREF) as z:
        prep=json.loads(z.read('Preparation.json'))
        tables=utilities['read_operators'](z.read('Native/Operators.csv'))
        frames=utilities['read_tensor_frames'](z.read('Native/MVTGaussMixed.Tensor.csv'),45)
    assert all(old[k]==tables[k] for k in 'GLBSR')
    return utilities,helper['material'],mesh,support,eq,prep,tables,frames


def process(root, expected):
    """Проверяет точные исходники, отдельную компиляцию, резерв памяти и завершение Excel."""
    prep=read(root/'Preparation.json')
    assert prep['force_schedule']=='MVT2BarControl' and prep['source_book_sha256']==BOOK
    assert prep['source_core']==expected['source_core']
    for name,stamp in prep['inputs'].items():
        if (root/name).exists():assert digest((root/name).read_bytes())==stamp,name
    for name in prep['source_core']:assert digest((root/name).read_bytes())==prep['source_core'][name]
    assert not prep['consistent_bar_control']
    compiler=read(root/'CodeUpdate.json')
    modules={'CCoupledSectionQuadrature','CCoupledElasticState','modTestMVT2GaussSpan','CCoupledConcreteResponse',
             'CTestConcreteBackbone','CTestTabulatedConcreteFlow','CCoupledNewtonSolver','CCoupledSteelCorrection',
             'CCoupledReinforcedResponse'}
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256']==BOOK
    assert set(compiler['Modules'])==modules and read(root/'CompileClosure.json')['State']=='Absent'
    native=root/'Native'
    owner=read(native/'MVTGaussMixed.txt.Ownership.json')
    close=read(native/'MVTGaussMixed.txt.ProcessClosure.json')
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==compiler['WorkbookSHA256']
    assert close['Passed'] and close['RunnerCleanupValid'] and close['ChildExitCode']==0
    identity=close['Closure']['Identity']
    assert identity['Valid'] and identity['PID']==owner['PID'] and identity['Ticks']==int(owner['StartTicksUTC'])
    assert close['Closure']['FinalState']['State']=='Absent'
    log=(native/'MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'RUNTIME ERROR:' not in log and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
    for row in (root/'Run.ndjson').read_text('utf-8-sig').splitlines():
        memory=json.loads(row)
        assert memory['freeCommitGiB']>=6 and memory['ramMiB']>=6500
        assert all(x['ProtectedUser'] and x['Id']!=owner['PID'] for x in memory['excel'])
    return prep


def variant(root, refs):
    """Проверяет поля управляемой стали и фактическую последовательность отклонений."""
    utilities,material,mesh,support,eq,base_prep,old,base=refs
    prep=process(root,base_prep)
    native=root/'Native'
    tables=utilities['read_operators']((native/'Operators.csv').read_bytes())
    frames=utilities['read_tensor_frames']((native/'MVTGaussMixed.Tensor.csv').read_bytes(),45)
    assert all(tables[k]==old[k] for k in 'GLBSR')
    assert list(frames)[:len(base)]==list(base)
    assert all(frames[p]==base[p] and tables['F'][p]==old['F'][p] for p in base)
    zero=(0.,)*6
    history={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
    tensor_error=0.
    for phase,frame in base.items():
        history,net,_=material(tables['F'][phase],tables,mesh[1],support,history)
        if phase.startswith('S'):
            eq(phase,frame,tables,mesh)
    wire=(native/'MVTGaussMixed.csv').read_text('cp1251')
    first,=re.findall(r'^MVT2_BAR_CONTROL_START;26;([^\n]+)',wire,re.M)
    origin=control=float(first)
    assert abs(fsum(e*d for e,d in zip(history[0,26][0],mesh[1][26][3:],strict=True))-control)<2e-17
    text=(root/'tests/modTestMVT2GaussSpan.bas').read_text('utf-8-sig')
    assert 'ReadActiveSteelSeedTest' not in text and not (root/'ActiveSteel.Seeds.csv').is_file()
    assert 'guessed(k) = field(k) + multiplier * (field(k) - before(k))' in text
    rows=[line.split(';',5)[1:] for line in wire.splitlines() if line.startswith('MVT2_BAR_CONTROL_TRIAL;')]
    step=1e-7
    proved=[]
    rejected=0
    last_q=77625.
    utility,_,rotation,_=support
    for i,(phase,x,solved,raw_lambda,detail) in enumerate(rows,1):
        assert phase=='Bar'+str(i)
        target=float(x)
        adaptive=prep.get('adaptive_bar_control',False)
        expected=control+step if adaptive else origin+step*i
        assert abs(target-expected)<2e-17
        if adaptive:
            printed,detail=detail.split(';',1)
            assert abs(float(printed.removeprefix('шаг: '))-step)<2e-20
        norms=re.match(r'Итерации: (\d+); пробы: (\d+); невязка, МПа: ([\d.Ee+-]+);',detail)
        assert norms
        if solved=='False':
            assert phase not in frames
            rejected+=1
            if adaptive:step*=.5
            else:assert i==len(rows)
            continue
        assert solved=='True'
        frame=frames[phase]
        assert frame[0]==10510000. and isclose(frame[1],1000.*float(raw_lambda),rel_tol=0.,abs_tol=6e-10)
        field=tables['F'][phase]
        proposal,net,_=material(field,tables,mesh[1],support,history)
        e=fsum(a*d for a,d in zip(proposal[0,26][0],mesh[1][26][3:],strict=True))
        tensor_error=max(tensor_error,*(abs(a-b) for (s,p),t in net.items() for a,b in zip(t,tables['H'][phase,s,p],strict=True)))
        result=eq(phase,frame,tables,mesh)
        assert 30000.*abs(e-target)<=result['tolerance_MPa']+2e-12
        norm=max(result[k] for k in ('weak_MPa','gauge_MPa','resultant_MPa'))
        assert abs(norm-float(norms[3]))<3e-8
        smallest=0.
        for s in (0,1,-1):
            for p in range(1,26):
                eps=proposal[s,p][0]
                principal,_=utility['spectral']((*eps[:3],*(x*.5 for x in eps[3:])),rotation)
                smallest=min(smallest,*principal)
        proved.append({'Qy_N':frame[1],'control':e,'norm_MPa':norm,'tol_MPa':result['tolerance_MPa'],
                       'twist_rad_per_m':1000.*field[3]/mesh[0][3],
                       'minimum_concrete_principal_strain':smallest,
                       'maximum_equivalent_compressive_strain':max(value[2][1] for value in proposal.values())})
        history,control,last_q=proposal,target,frame[1]
        if adaptive:step=min(prep.get('maximum_bar_step',2e-5) if control>.002495 else 1e-7,2.*step)
    assert tensor_error<8e-7
    assert len(frames)==len(base)+len(proved) and len(tables['H'])==135*(38+len(proved))
    finish,seconds=re.findall(r'^CASE_FINISHED;MVTGaussMixed;(True|False);([^\n]+)',wire,re.M)[0]
    if not prep.get('adaptive_bar_control',False):assert finish=='True' and len(proved)==12 and rejected==0
    return {'accepted':proved,'rejected':rejected,'seconds':float(seconds),'tensor_error_MPa':tensor_error,
            'last_Qy_N':last_q,'max_Qy_N':max(x['Qy_N'] for x in proved),'target_reached':finish=='True'}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    with TemporaryDirectory(dir=a.out.resolve().parent) as folder:
        refs=references(a.repo,Path(folder))
        proof={name:variant(a.root/name,refs) for name in ('Fixed','Adaptive','Half','Quarter') if (a.root/name).is_dir()}
    a.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('NATIVE MVT2 BAR CONTROL VERIFIED',*(len(x['accepted']) for x in proof.values()))
