"""Готовит частную книгу для деформационного продолжения MVT2 после второго стержня."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
TEMPLATE = Path('D:/CodexScratch/RC_Section_NDM_TQ/VBAFlowIntegratedCore')
PROOF = ('MVT2IntegratedSteelCorrection20261117.zip','20D400686306651D3605A60FEF7B81D4838BF3A368591264243F74434AFC88DC')
TEST = 'tests/modTestMVT2GaussSpan.bas'


def digest(data):
    """Возвращает отпечаток копируемого исходника."""
    return sha256(data).hexdigest().upper()


def once(source, before, after):
    """Ограничивает изменение единственным зафиксированным фрагментом макроса."""
    assert source.count(before)==1, before
    return source.replace(before,after)


def adaptive_control(source, maximum_step):
    """Делит отклонённый шаг и расширяет его после прохождения текучести станций."""
    source=once(source,'Const STEPS As Long = 12, INCREMENT As Double = 0.0000001',
                       'Const STEPS As Long = 160, INCREMENT As Double = 0.0000001, MINIMUM As Double = 0.000000003125')
    source=once(source,'    Dim i As Long, k As Long, phase As String, solved As Boolean, norm As Double',
                       '    Dim i As Long, k As Long, phase As String, solved As Boolean, norm As Double\n    Dim stepControl As Double, maximum As Double')
    source=once(source,'    origin = control: lambda = 77.625: beforeLambda = 77.5',
                       '    origin = control: lambda = 77.625: beforeLambda = 77.5\n    stepControl = INCREMENT')
    source=once(source,'        target = origin + INCREMENT * i','        target = control + stepControl')
    source=once(source,'        solved = solver.TryDeformationStep',
                       '        solvedLambda = 0#\n        solved = solver.TryDeformationStep')
    source=once(source,'            solver.ResultMeta.DiagnosticDetails','            "шаг: " & ExperimentNumberTest(stepControl) & ";" & solver.ResultMeta.DiagnosticDetails')
    source=once(source,'            solver.DiscardStep\n            Exit Function',
                       '            solver.DiscardStep\n            stepControl = stepControl * 0.5\n            If stepControl < MINIMUM Then Exit Function\n            GoTo NextBarAttempt')
    source=once(source,'        WriteMVT2FullFrameTest operators, field, phase, forces(4), forces(6), tracePath, stations\n    Next i\n    TestFollowMVT2BarControl = True',
                       '''        WriteMVT2FullFrameTest operators, field, phase, forces(4), forces(6), tracePath, stations
        If control >= 0.004 Then
            TestFollowMVT2BarControl = True
            Exit Function
        End If
        maximum = INCREMENT
        If control > 0.002495 Then maximum = 0.00002
        stepControl = GeomMin(maximum, 2# * stepControl)
NextBarAttempt:
    Next i''')
    return once(source,'If control > 0.002495 Then maximum = 0.00002',
                f'If control > 0.002495 Then maximum = {maximum_step:.8f}#')


def stage(repo, root, consistent, adaptive, maximum_step):
    """Сохраняет проверенный префикс и добавляет только чтение деформационного пути."""
    reference=repo/'docs/regression/Coupled6D'/PROOF[0]
    assert digest(reference.read_bytes())==PROOF[1]
    prep=json.loads((TEMPLATE/'Preparation.json').read_bytes())
    with ZipFile(reference) as z:
        assert prep==json.loads(z.read('Preparation.json'))
    assert not root.exists()
    root.mkdir()
    for directory in ('Native','Temp','tests','src'):
        (root/directory).mkdir()
    for name,stamp in prep['inputs'].items():
        old=(TEMPLATE/name).read_bytes()
        assert digest(old)==stamp,name
        path=root/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(old)
    draft=root/'docs/regression/Diagnostic.xlsm'
    draft.parent.mkdir(parents=True,exist_ok=True)
    draft.write_bytes((root/'workbook/output/RC_Section_NDM.xlsm').read_bytes())
    for file, stamp in prep['source_core'].items():
        assert digest((repo/file).read_bytes())==stamp,file
    code=(root/TEST).read_text('utf-8-sig')
    code=once(code,'    Dim goals As Variant, i As Long, qy As Double, previousQ As Double, solved As Boolean, phase As String',
                   '    Dim goals As Variant, i As Long, qy As Double, previousQ As Double, solved As Boolean, phase As String\n    Dim beforeBar() As Double')
    code=once(code,'        solver.CopyTrial field, actual\n        residual = operators.ResultantResidualNorm(actual, expected)',
                   '        If qy = 77625# Then beforeBar = field\n        solver.CopyTrial field, actual\n        residual = operators.ResultantResidualNorm(actual, expected)')
    code=once(code,'    RunMVT2ShearAfterPreloadTest = True','    RunMVT2ShearAfterPreloadTest = TestFollowMVT2BarControl(operators, solver, beforeBar, atol, rtol, report, tracePath, stations)')
    addition=(HERE/'MVT2BarControl.bas.txt').read_text('utf-8')
    if consistent:
        addition=once(addition,'consistentControl:=False','consistentControl:=True')
    if adaptive:
        addition=adaptive_control(addition,maximum_step)
    code+=addition
    (root/TEST).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][TEST]=digest((root/TEST).read_bytes())
    prep['force_schedule']='MVT2BarControl'
    prep['consistent_bar_control']=consistent
    prep['adaptive_bar_control']=adaptive
    prep['maximum_bar_step']=maximum_step
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2)+'\n').encode())
    print('MVT2 BAR CONTROL PREPARED',root,consistent)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--consistent',action='store_true')
    p.add_argument('--adaptive',action='store_true')
    p.add_argument('--maximum-step',type=float,default=2e-5,choices=(2e-5,1e-5,5e-6))
    a=p.parse_args()
    stage(a.repo.resolve(),a.root.resolve(),a.consistent,a.adaptive,a.maximum_step)
