"""Independently audit the A2 continuation sequence and its optional exact force anchors."""
import argparse
import csv
from hashlib import sha256
from io import StringIO
import json
from math import fsum, isfinite
from pathlib import Path
import re

from dataclasses import dataclass


AREA=216004.
LENGTH=407.293505963451
SCALES=(AREA,AREA*LENGTH,AREA*LENGTH,AREA*LENGTH,AREA,AREA)
TEMPS=5e-13
GOALS=(239.4,247.1,254.8)
TMAX=.035
INCR_MIN=.000001953125


@dataclass
class State:
    i:int
    attempt:int
    twist:float
    error:float
    forces:tuple
    q:tuple
    method:str
    steel:tuple=()
    seconds:float=0.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def rows(path):
    raw=path.read_bytes()
    assert raw.endswith(b"\n"),("incomplete terminal row",path.name)
    return [row for row in csv.reader(StringIO(raw.decode("cp1251")),delimiter=";") if row]


def yes(x,y,tol):
    assert abs(x-y)<=tol,(x,y,tol)


def read_state(row,kind):
    if kind=="cold":
        assert len(row)==71
        tag,i,attempt,twist,error,*data=row
        method="Cold"
        steel=()
        seconds=0.
    else:
        assert len(row)==76
        tag,i,attempt,method,twist,error,hoop,longitudinal,damage,seconds,*data=row
        assert method in ("LoadSecant","AcceptedField")
        steel=float(hoop),float(longitudinal)
        assert 0.<=steel[0]<=696.+1e-7 and 0.<=steel[1]<=672.+1e-7
        assert 0.<=float(damage)<=1.
        seconds=float(seconds)
        assert seconds>=0.
    assert tag=="FIELD" and len(data)==66
    values=tuple(map(float,data))
    assert all(map(isfinite,values))
    return State(int(i),int(attempt),float(twist),float(error),values[:6],values[6:],method,steel,seconds)


def audit_force(s):
    actual_torque=s.forces[3]/1.e6
    force_bound=max(abs(s.forces[i])/SCALES[i] for i in (0,1,2,4,5))
    assert 0<=force_bound<=s.error+5e-13 and 0<=s.error<=5.e-6
    yes(s.twist,s.q[3]*1000./LENGTH,1e-14)
    # Exact target lambda is absent in FIELD. Using measured torque here poses an
    # order-of-roundoff approximation to the much looser relative solver limit.
    provisional=5.e-7+2.e-8*abs(s.forces[3])/SCALES[3]+1.e-11
    return force_bound,actual_torque,s.error>provisional


def check_owner(path):
    result=json.loads(path.read_text(encoding="utf-8-sig"))
    if result["Passed"]:
        assert result["ChildHasExited"] and result["ChildExitCode"]==0
        x=result["Closure"]["FinalState"]
        assert x["State"]=="Absent"
        return {"terminal":"completed","pid":x["PID"],"start_ticks":str(x["StartTicksUTC"])}
    assert result["Stage"]=="TIMEOUT" and result["After"]["State"]=="Absent"
    x=result["After"]
    identity=result["Identity"]
    assert identity["Valid"] and identity["PID"]==x["PID"] and str(identity["Ticks"])==str(x["StartTicksUTC"])
    return {"terminal":"watchdog_timeout","pid":x["PID"],"start_ticks":str(x["StartTicksUTC"])}


def vec_from(source):
    return tuple(float(a) for a in source)


def reconstructed_prefix(cold,prefix,law):
    cold_raw=rows(cold)
    assert ["COLD","9","56"] in cold_raw
    match=next(r[0] for r in cold_raw if r[0].startswith("A2_PARAMETERS:"))
    param=re.search(r"Ec (\S+) \| Ft (\S+) \| Gt (\S+) \| Gc (\S+)",match)
    assert param
    for x,y in zip(map(float,param.groups()),law,strict=True):
        yes(x,y,abs(y)*1e-13)
    cold_states=[read_state(line,"cold") for line in cold_raw if line[0]=="FIELD"]
    assert [s.i for s in cold_states]==list(range(1,len(cold_states)+1))
    assert all(b.twist>a.twist for a,b in zip(cold_states,cold_states[1:]))
    for s in cold_states:
        audit_force(s)
    raw=rows(prefix)
    n,step,case=raw[0]
    assert int(n)==len(cold_states)==len(raw)-1 and case=="A"
    a,b=cold_states[-2:]
    yes(float(step),min(.001,1.25*(b.twist-a.twist)),1e-16)
    for line,s in zip(raw[1:],cold_states,strict=True):
        assert len(line)==68
        assert vec_from(line)==(float(s.i),s.twist,*s.forces,*s.q)
    return cold_states,float(step)


def secant_guard(previous,current,native,scale):
    d0=tuple(b-a for a,b in zip(previous.q[:56],current.q[:56],strict=True))
    d1=tuple(b-a for a,b in zip(current.q[:56],native.q[:56],strict=True))
    ss0=fsum(a*a for a in d0)
    ss1=fsum(a*a for a in d1)
    projected=fsum(a*b for a,b in zip(d0,d1,strict=True))
    ratio=(ss1/ss0)**.5/scale
    cosine=projected/(ss0*ss1)**.5
    return projected>0. and ratio<=3.+2e-9,cosine,ratio


def resumed(cold,inc,records,law,receipt):
    start=list(cold)
    tags=[item[0] for item in records]
    assert tags[:3]==["RESUME","RESUME_LAW","REPLAY"]
    assert records[0]==["RESUME","9",str(len(cold)),"56"]
    assert records[1][1]=="A"
    for val,want in zip(map(float,records[1][2:]),law[2:],strict=True):
        yes(val,want,abs(want)*1e-13)
    weak,error,*forces=map(float,records[2][1:])
    assert len(forces)==6 and 0<=weak<=5e-6 and 0<=error<=5e-6
    force_delta=max(abs(a-b)/s for a,b,s in zip(forces,cold[-1].forces,SCALES,strict=True))
    yes(force_delta,error,5e-13)
    stop=None
    methods=[]
    attempt=0
    rejected=[]
    for row in records[3:]:
        if row[0]=="STOP":
            assert stop is None and len(row)==3
            stop=row[1]
            assert int(row[2])==len(start)-len(cold)
            continue
        assert stop is None and row[0] in ("FIELD","REJECT")
        attempt+=1
        previous,current=start[-2:]
        requested=min(TMAX,current.twist+inc)
        if row[0]=="REJECT":
            assert int(row[1])==attempt
            yes(float(row[2]),requested,5e-13)
            rejected.append({"attempt":attempt,"requested_twist_rad_m":float(row[2]),"message":row[3]})
            inc*=.5
            continue
        state=read_state(row,"resume")
        assert state.i==len(start)+1 and state.attempt==attempt and state.twist>current.twist
        yes(state.twist,requested,2.5e-11)
        direction=(state.twist-current.twist)/(current.twist-previous.twist)
        good,cosine,ratio=secant_guard(previous,current,state,direction)
        if state.method=="LoadSecant":
            assert 0.<direction<=1.25000001+1e-9 and good
        force,torque,loose=audit_force(state)
        methods.append({"field":state.i,"attempt":attempt,"method":state.method,"direction_guard_pass":good,
                  "field_cosine":cosine,"increment_ratio_to_predicted":ratio,"twist_rad_m":state.twist,"T_kNm":torque,
                  "force_error_MPa":state.error,"off_torque_error_MPa":force,"greater_than_approx_solver_force_bound":loose,
                  "steel_stress_MPa":state.steel,"seconds":state.seconds})
        start.append(state)
        inc=min(.001,1.25*inc)
    if receipt["terminal"]=="completed":
        assert stop in ("MeasuredTorqueBracketed","TwistLimit","SteelStrainBracket","AttemptLimit","MinimumTwistIncrement")
    if stop=="MeasuredTorqueBracketed":
        assert start[-1].forces[3]/1e6>=GOALS[-1]-start[-1].error*SCALES[3]/1e6
    if stop=="TwistLimit":
        yes(start[-1].twist,TMAX,1e-13)
    if stop=="MinimumTwistIncrement":
        assert rejected[-1]["attempt"]==attempt and inc<INCR_MIN
    if stop=="AttemptLimit":
        assert attempt==125
    return start,{"replayed_off_field_force_error_MPa":force_delta,"replayed_weak_error_MPa":weak,"stop":stop,
            "complete_prefix_count":len(start),"native_new_fields":methods,"rejected_attempts":rejected,
            "methods_without_direction_guard":[m["field"] for m in methods if m["method"]=="AcceptedField" and not m["direction_guard_pass"]],
            "maximum_of_accepted_samples_kNm":max(x.forces[3]/1e6 for x in start),
            "physical_limit_certified":False}


def exact_fit(anchors,records,fields):
    assert len(anchors)==len(records)>0
    separate=[]
    for row,(goal,left) in zip(records,anchors,strict=True):
        assert row[0]=="ANCHOR" and int(row[3])==left and float(row[2])==goal
        twist=float(row[4])
        assert fields[left-1].twist-1e-14<=twist<=fields[left].twist+1e-14
        assert row[6] in ("Force","ControlSeed")
        separate.append({"target_T_kNm":goal,"twist_rad_m":twist,"method":row[6],
            "actual_left_field":left,"T_bracket_kNm":[s.forces[3]/1e6 for s in fields[left-1:left+1]],
            "twist_bracket_rad_m":[s.twist for s in fields[left-1:left+1]]})
    return separate


def exact_verify(input_file,trace_file,fields):
    raw=rows(input_file)
    q,n,anch=map(int,raw[0]); assert q==9 and 1<=anch<=3
    assert len(raw)==1+n+anch
    for row,s in zip(raw[1:n+1],fields[:n],strict=True):
        assert len(row)==62 and int(row[0])==s.i and float(row[1])==s.forces[3]/1.e6 and vec_from(row[2:])==s.q
    anchors=[(float(row[0]),int(row[1])) for row in raw[n+1:]]
    expected=[(goal,a.i) for goal in GOALS for a in fields[1:-1]
            if a.forces[3]/1.e6<goal<=fields[a.i].forces[3]/1.e6]
    first={}
    for goal,i in expected:
        first.setdefault(goal,i)
    assert anchors==list(first.items())
    traces=rows(trace_file)
    assert traces[0]==["GRID","9","56",str(n)]
    accept=[row for row in traces if row[0]=="ANCHOR"]
    failed=[row for row in traces if row[0]=="FAILED"]
    assert not failed
    result=exact_fit(anchors,accept,fields)
    for each,line in zip(result,accept,strict=True):
        target=each["target_T_kNm"]*1.e6
        anchor=line[1]
        points=[row for row in traces if row[:2]==["POINT",anchor]]
        assert len(points)==88 and [int(p[2]) for p in points]==list(range(1,89))
        actual=[[] for _ in SCALES]
        for point in points:
            x,y,area,steel,strain=map(float,point[4:9])
            sign=1. if point[3]=="Concrete" else -1.
            a=vec_from(point[11:17]); direction=vec_from(point[17:23])
            assert area>0. and abs(strain)<=.05+1e-9
            sigma=tuple(sign*c+steel*d for c,d in zip(a,direction,strict=True))
            for parts,value in zip(actual,(sigma[2],y*sigma[2],x*sigma[2],x*sigma[5]-y*sigma[4],sigma[4],sigma[5]),strict=True):
                parts.append(value*area)
        effort=tuple(map(fsum,actual))
        norm=max(abs(a-b)/s for a,b,s in zip(effort,(0.,0.,0.,target,0.,0.),SCALES,strict=True))
        extent=max(abs(a-b)/s for a,b,s in zip(effort,map(float,line[7:]),SCALES,strict=True))
        assert extent<=5e-9 and norm<=5e-7+2e-8*abs(target)/SCALES[3]+1e-11
        each.update(signed_integrated_N_Nmm=effort,independent_target_error_MPa=norm,difference_from_VBA_MPa=extent)
    return result


def main(args):
    base=args.work_root
    native=base/"Native"
    cold=args.cold
    end=native/(args.stem+"-Resume.txt.ProcessClosure.json")
    resume=native/(args.stem+"-Resume.csv")
    if not end.is_file() or not resume.is_file():
        print("A2 continuation still has no complete captured terminal record; nothing reported from live trace.")
        return
    resume_owner=check_owner(end)
    m=json.loads((base/"Manifest.json").read_text(encoding="utf8"))
    law=(36100.,3.5,m["Gt_A_N_per_mm"],m["Gc_both_N_per_mm"])
    prefix=native/(args.stem+"-Prefix.csv")
    initial,step=reconstructed_prefix(cold,prefix,law)
    fields,result=resumed(initial,step,rows(resume),law,resume_owner)
    x_file=native/(args.stem+"-ExactInput.csv")
    x_trace=native/(args.stem+"-Exact.csv")
    x_end=native/(args.stem+"-Exact.txt.ProcessClosure.json")
    exact=None
    if x_file.is_file() and x_trace.is_file() and x_end.is_file():
        final=check_owner(x_end)
        assert final["terminal"]=="completed"
        exact=exact_verify(x_file,x_trace,fields)
    proof={"cold_trace_sha256":digest(cold),"accepted_prefix_sha256":digest(prefix),"resume_trace_sha256":digest(resume),
            "resume_receipt":resume_owner,"material_constants":[*law],
            "units":{"torque_stored":"N mm","comparison_torque":"kN m","twist":"rad/m"},
            "exact_anchor_status":"attested" if exact is not None else "none completed","exact_native_anchors":exact,
            **result}
    args.out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+"\n",encoding="utf8")
    print(args.out,digest(args.out))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("work_root",type=Path)
    p.add_argument("cold",type=Path)
    p.add_argument("out",type=Path)
    p.add_argument("--stem",default="A-1")
    main(p.parse_args())
