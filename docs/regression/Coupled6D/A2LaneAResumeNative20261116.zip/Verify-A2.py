"""Audit the diagnostic A2 cold trace and integrate exact native point tensors."""

import argparse
from collections import Counter
import csv
import json
from math import fsum, isclose
from pathlib import Path
import re

from PeakReference import principal_stresses
from Prepare import ANCHORS, HERE, digest


def rows(path):
    with path.open(encoding='cp1251', newline='') as source:
        return [row for row in csv.reader(source, delimiter=';') if row]


def cold_gate(path, lane):
    raw = path.read_text(encoding='cp1251')
    manifest = json.loads((HERE / 'Manifest.json').read_text(encoding='utf-8'))
    declared = re.search(r'^A2_PARAMETERS: Ec (\S+) \| Ft (\S+) \| Gt (\S+) \| Gc (\S+)', raw, re.M)
    if declared is None:
        raise ValueError('Cold trace material line missing.')
    expected = 36100, 3.5, manifest[f'Gt_{lane}_N_per_mm'], manifest['Gc_both_N_per_mm']
    for value, target in zip(map(float, declared.groups()), expected, strict=True):
        assert isclose(value, target, rel_tol=1.e-13)
    trace = rows(path)
    assert ['COLD', '9', '56'] in trace
    states = [row for row in trace if row[0] == 'FIELD']
    assert states
    coords = [float(row[3]) for row in states]
    assert all(right > left for left, right in zip(coords, coords[1:]))
    stop = re.search(r'^A2_STOP: (.+)$', raw, re.M)
    return {'trace_sha256': digest(path), 'mat': list(expected), 'cold_states': len(states),
            'cold_final_twist_rad_m': coords[-1], 'cold_max_T_kNm': max(float(row[8]) for row in states) / 1.e6,
            'cold_stop': stop[1].strip() if stop else 'no_stop_receipt'}


def wrench(stress, x, y):
    _, _, zz, _, xz, yz = stress
    return zz, y*zz, x*zz, x*yz-y*xz, xz, yz


def hoop_maximum(hoop):
    """Fit through three points on each leg, then check the fourth."""
    half = 269., 265.5
    maxima = []
    for fixed in (0, 1):
        free = 1-fixed
        scale = half[free]
        for sign in (-1, 1):
            samples = sorted((xy[free]/scale, strain) for xy, strain in hoop
                             if abs(xy[fixed] - sign*half[fixed]) < 1.e-8)
            assert len(samples) == 4
            (x0, y0), (x1, y1), (x2, y2), (x3, y3) = samples
            d01 = (y1-y0)/(x1-x0)
            a = ((y2-y1)/(x2-x1) - d01)/(x2-x0)
            b = d01-a*(x0+x1)
            c = y0-(a*x0+b)*x0

            def strain_at(x):
                return (a*x+b)*x+c

            assert abs(strain_at(x3)-y3) < 5.e-12
            roots = [-1., 1.]
            if a < 0. and -1. < -b/(2.*a) < 1.:
                roots.append(-b/(2.*a))
            maxima.append(max(map(strain_at, roots)))
    return max(maxima)


def exact_gate(path, targets):
    trace = rows(path)
    assert trace[0][:3] == ['GRID', '9', '56'] and trace[1][0] == 'SCALES'
    area, length = map(float, trace[1][1:])
    assert abs(area-216004.) < 1.e-6 and abs(length-407.293505963451) < 1.e-6
    scales = area, area*length, area*length, area*length, area, area
    output = []
    anchors = [row for row in trace if row[0] == 'ANCHOR']
    assert [float(row[2]) for row in anchors] == targets
    for anchor in anchors:
        _, index, target_text, left, twist, native_residual, method, *force = anchor
        assert method in ('Force', 'ControlSeed')
        target = float(target_text) * 1.e6
        steel_stress, torque_positive, torque_negative = [], [], []
        integrated = [[] for _ in scales]
        point_rows = [row for row in trace if row[:2] == ['POINT', index]]
        assert [int(p[2]) for p in point_rows] == list(range(1, 89))
        assert Counter(p[3] for p in point_rows) == {'Concrete':56, 'Hoop':16, 'LongitudinalCorner':4, 'LongitudinalSide':12}
        hoop, corner = [], []
        for p in point_rows:
            family = p[3]
            x, y, weight, sigma, strain = map(float, p[4:9])
            concrete = list(map(float, p[11:17]))
            rod = list(map(float, p[17:23]))
            xx, yy, zz, xy, xz, yz = concrete
            sign = 1. if family == 'Concrete' else -1.
            eigenvalues, eigenvectors, _ = principal_stresses([[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]])
            factors = [sign*weight*eigenvectors[2][i]*(x*eigenvectors[1][i]-y*eigenvectors[0][i]) for i in range(3)]
            torque_positive.append(fsum(f*max(0., s) for f, s in zip(factors, eigenvalues, strict=True)))
            torque_negative.append(fsum(f*min(0., s) for f, s in zip(factors, eigenvalues, strict=True)))
            if family != 'Concrete':
                fy = 696. if family == 'Hoop' else 672.
                assert abs(sigma-max(-fy, min(fy, 2.e5*strain))) < 2.e-8
                steel_stress.append((family, sigma))
                if family == 'Hoop':
                    hoop.append(((x, y), strain))
                elif family == 'LongitudinalCorner':
                    corner.append(strain)
            for group, value in zip(integrated, wrench([sign*c+sigma*r for c, r in zip(concrete, rod, strict=True)], x, y), strict=True):
                group.append(weight*value)
        measured = list(map(fsum, integrated))
        target_vector = 0., 0., 0., target, 0., 0.
        normalized = max(abs(v-e)/s for v,e,s in zip(measured, target_vector, scales, strict=True))
        assert normalized < 5.e-7 + 2.e-8*abs(target)/scales[3] + 1.e-11
        assert abs(normalized-float(native_residual)) < 5.e-9
        assert max(abs(v-e)/s for v,e,s in zip(measured,map(float,force),scales,strict=True)) < 5.e-9
        positive, negative = fsum(torque_positive), fsum(torque_negative)
        assert abs(measured[3]-positive-negative) < 1.e-4
        output.append({'target_kNm':target/1.e6, 'history_left':int(left), 'method':method,
                       'twist_rad_m':float(twist), 'equilibrium_error_MPa':normalized,
                       'independent_resultants_N_Nmm':measured,
                       'positive_principal_T_kNm':positive/1.e6, 'negative_principal_T_kNm':negative/1.e6,
                       'corner_long_max_microstrain':1.e6*max(corner),
                       'longitudinal_max_MPa':max(s for k,s in steel_stress if k!='Hoop'),
                       'hoop_quadrature_max_MPa':max(s for k,s in steel_stress if k=='Hoop'),
                       'hoop_leg_max_microstrain':1.e6*hoop_maximum(hoop)})
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lane', choices=('A', 'B'))
    parser.add_argument('--cold-only', action='store_true')
    arguments = parser.parse_args()
    lane = arguments.lane
    cold = HERE / f'Native/{lane}-Cold.csv'
    checks = cold_gate(cold, lane)
    if not arguments.cold_only:
        exact = HERE / f'Native/{lane}-Exact.csv'
        inputs = HERE / f'Native/{lane}-Input.csv'
        count = int(rows(inputs)[0][2])
        targets = [float(row[0]) for row in rows(inputs)[-count:]]
        checks.update(anchors=exact_gate(exact,targets), exact_trace_sha256=digest(exact), exact_input_sha256=digest(inputs),
                      all_anchors_verified=tuple(targets)==ANCHORS)
        (HERE/f'Native/{lane}-Checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(checks, indent=2))


if __name__ == '__main__':
    main()
