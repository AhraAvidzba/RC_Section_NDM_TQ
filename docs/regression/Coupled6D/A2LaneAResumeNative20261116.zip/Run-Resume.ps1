# Продолжает принятую историю A2 и проверяет силовые точки в отдельной книге.
param([ValidateSet('A','B')][string]$Lane='A',[string]$ColdTrace,[string[]]$PreviousResume=@(),
    [ValidatePattern('^[a-zA-Z0-9]+$')][string]$Label='1',[switch]$Preflight)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../..')).Path
if (!$ColdTrace) {$ColdTrace=Join-Path $root "../a2ab/Native/$Lane-Cold.csv"}
$ColdTrace=(Resolve-Path -LiteralPath $ColdTrace).Path
$PreviousResume=@($PreviousResume | ForEach-Object {(Resolve-Path -LiteralPath $_).Path})
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$installed='workbook/output/RC_Section_NDM.xlsm'
$private='docs/regression/Diagnostic.xlsm'
$oldTemp=$env:TEMP
$oldTmp=$env:TMP
Push-Location -LiteralPath $root
try {
    $fixture=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    foreach ($entry in $fixture.frozen.PSObject.Properties) {
        if ((Get-FileHash -LiteralPath $entry.Name).Hash -cne $entry.Value) {throw ('Изменился файл '+$entry.Name)}
    }
    if ((Get-FileHash -LiteralPath (Join-Path $repo $installed)).Hash -cne $fixture.workbook_sha256) {throw 'Сменилась установленная книга.'}
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {throw 'Путь пробной книги слишком длинный.'}
    Assert-IsolatedOfficeReady 'PreflightA2Resume'
    if ($Preflight) {return}

    $stem="$Lane-$Label"
    $prefix=Join-Path $root "Native/$stem-Prefix.csv"
    $exact=Join-Path $root "Native/$stem-ExactInput.csv"
    $runInput=@('--cold',$ColdTrace,'--lane',$Lane)
    foreach($path in $PreviousResume) {$runInput+=@('--resume',$path)}
    & python -B -X utf8 'Prepare.py' @runInput --output $prefix
    if ($LASTEXITCODE -ne 0) {throw 'Численные и материальные параметры префикса не подтверждены.'}

    if (!(Test-Path -LiteralPath 'docs/regression/CodeUpdate.json')) {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Get-FileHash -LiteralPath $private).Hash -cne $fixture.workbook_sha256) {throw 'Найдена непроверенная компиляция.'}
        Assert-IsolatedOfficeReady 'PreCompileA2Resume'
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $private -ModuleNames @('modTestCoupledExperiment') |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $comp=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$comp.Compiled -or $comp.ProductionChanged -or ($comp.Modules -join ',') -cne 'modTestCoupledExperiment' -or
        $closure.State -cne 'Absent' -or $comp.ProductionSHA256 -cne $fixture.workbook_sha256 -or
        $comp.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $private).Hash) {throw 'Компиляция не подтверждена.'}

    function Invoke-A2ResumeMacro([string]$name,[string]$macro,[string]$inputPath,[string]$trace,[int]$timeout) {
        $report="Native/$name.txt"
        if (Test-Path -LiteralPath $report) {throw 'Предыдущий протокол сохраняется.'}
        Assert-IsolatedOfficeReady ("Before$name")
        $commandArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-Audit03Watchdog.ps1','-SourceWorkbook',$private,
            '-ReportPath',$report,'-Macro',"modTestCoupledExperiment.$macro",'-MacroArgument1',$inputPath,'-MacroArgument2',$Lane,
            '-Mode','No','-TimeoutSeconds',$timeout,'-FailFast')
        & $legacy @commandArgs
        $exit=$LASTEXITCODE
        $entry=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
        if ($entry.Count -ne 1) {throw 'Не найден путь пробной книги.'}
        $parent=Split-Path -Parent $entry[0].Substring('FIXTURE: '.Length)
        if (!(Split-Path -Leaf $parent).StartsWith('RC_NDM_ModeSuite_',[StringComparison]::Ordinal) -or
            !$parent.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь следа вне частной копии.'}
        $tracePath=Join-Path $parent $trace
        if (Test-Path -LiteralPath $tracePath) {Copy-Item -LiteralPath $tracePath -Destination "Native/$name.csv"}
        $done=Get-Content -LiteralPath ($report+'.ProcessClosure.json') -Raw | ConvertFrom-Json
        if ($exit -eq 0 -and (!$done.Passed -or $done.Closure.FinalState.State -cne 'Absent')) {throw 'Закрытие пробного Excel не подтверждено.'}
        if ($exit -ne 0 -and $done.After.State -cne 'Absent') {throw 'Завершение остановленной пробы не подтверждено.'}
        if (!(Test-Path -LiteralPath "Native/$name.csv")) {throw 'Нативный след отсутствует.'}
    }

    Invoke-A2ResumeMacro "$stem-Resume" 'RunTestA2ResumeRefined' $prefix 'A2RefinedResume.csv' $fixture.resume_seconds_cap
    & python -B -X utf8 'Prepare.py' @runInput --resume "Native/$stem-Resume.csv" --exact --output $exact
    if ($LASTEXITCODE -ne 0) {throw 'Принятые поля продолжения не подтверждены.'}
    if (!(Test-Path -LiteralPath $exact)) {
        Write-Output 'Опытные моменты остаются за пределами принятого участка.'
        return
    }
    Invoke-A2ResumeMacro "$stem-Exact" 'RunTestA2RefinedExactTorque' $exact 'A2RefinedExact.csv' $fixture.exact_seconds_cap
    $exactReport=Get-Content -LiteralPath "Native/$stem-Exact.txt" -Raw -Encoding UTF8
    if ($exactReport -notmatch [regex]::Escape('WATCHDOG_COMPLETED: exit=0; source unchanged=True')) {throw 'Точные силовые пробы не подтверждены.'}
    & python -B -X utf8 'Prepare.py' --cold $ColdTrace --lane $Lane --verify "Native/$stem-Exact.csv" --output $exact
    if ($LASTEXITCODE -ne 0) {throw 'Независимая проверка шести усилий и стали не пройдена.'}
} finally {
    $env:TEMP=$oldTemp
    $env:TMP=$oldTmp
    Pop-Location
}
