"""Replay the one completed A lane and compare exact A2 anchors from six point integrals."""
from argparse import Namespace
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path

import AuditResume as independent

HERE=Path(__file__).resolve().parent
COL=HERE/"Cold"
NATIVE=HERE/"Native"


def read(name):
    return json.loads((HERE/name).read_text(encoding="utf-8-sig"))


def compare_receipt(prefix,name):
    closure=independent.check_owner(prefix/(name+".txt.ProcessClosure.json"))
    owner=json.loads((prefix/(name+".txt.Ownership.json")).read_text(encoding="utf-8-sig"))
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["ProcessName"]=="EXCEL"
    assert closure["pid"]==owner["PID"] and closure["start_ticks"]==owner["StartTicksUTC"]
    report=(prefix/(name+".txt")).read_text(encoding="utf-8-sig")
    assert f"SOURCE_SHA256: {owner['SourceSHA256']}" in report
    if closure["terminal"]=="completed":
        assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in report
    else:
        assert "WATCHDOG_FAILURE: timeout=" in report and "ownExcelState=Absent" in report
    return closure,owner["SourceSHA256"]


def main():
    locked=read("ReplayInputs.json")
    assert all(independent.digest(HERE/name)==expect for name,expect in locked["files"].items())
    independent.main(Namespace(work_root=HERE,cold=COL/"A-Cold.csv",out=HERE/"IndependentReplay.json",stem="A-1"))
    numeric=read("IndependentReplay.json")
    assert numeric["exact_anchor_status"]=="attested" and numeric["resume_receipt"]["terminal"]=="completed"
    cold,cold_sha=compare_receipt(COL,"A-Cold")
    resume,resume_sha=compare_receipt(NATIVE,"A-1-Resume")
    exact,exact_sha=compare_receipt(NATIVE,"A-1-Exact")
    assert cold["terminal"]=="watchdog_timeout" and resume["terminal"]==exact["terminal"]=="completed"
    book=read("Fixture.json")["workbook_sha256"]
    compiler=read("CompileClosure.json")
    code=read("docs/regression/CodeUpdate.json")
    assert compiler["State"]=="Absent" and code["Compiled"] and code["Modules"]==["modTestCoupledExperiment"]
    assert code["ProductionSHA256"]==book and not code["ProductionChanged"]
    assert code["WorkbookSHA256"]==resume_sha==exact_sha and cold_sha!=resume_sha
    artifact=run_path(str(HERE/"Verify-A2.py"))
    native=artifact["exact_gate"](NATIVE/"A-1-Exact.csv",list(independent.GOALS))
    stated=read("Native/A-1-Exact-Verification.json")
    assert stated["all_anchors_verified"] and stated["anchors"]==native
    assert stated["exact_trace_sha256"]==independent.digest(NATIVE/"A-1-Exact.csv")
    assert stated["exact_input_sha256"]==independent.digest(NATIVE/"A-1-ExactInput.csv")
    assert [row["target_kNm"] for row in native]==[row["target_T_kNm"] for row in numeric["exact_native_anchors"]]
    for current,other in zip(native,numeric["exact_native_anchors"],strict=True):
        assert tuple(current["independent_resultants_N_Nmm"])==tuple(other["signed_integrated_N_Nmm"])
        assert current["history_left"]==other["actual_left_field"] and current["method"]==other["method"]
        assert current["twist_rad_m"]==other["twist_rad_m"]
    result={"scope":"A lane, saved cold prefix, accepted continuation and three exact prescribed anchors",
            "matched_experimental_historical_force_anchors_only":True,"A_B_comparative_validation":False,
            "maximum_physically_certified":False,"book_sha256":book,"cold_owners":cold,"resume_owner":resume,"exact_owner":exact,
            "compiler":compiler,"replay_audit_sha256":independent.digest(HERE/"IndependentReplay.json"),
            "original_exact_receipt_sha256":independent.digest(NATIVE/"A-1-Exact-Verification.json"),
            "raw_trace_digests":{
                "cold":independent.digest(COL/"A-Cold.csv"),"resume":independent.digest(NATIVE/"A-1-Resume.csv"),
                "exact":independent.digest(NATIVE/"A-1-Exact.csv"),"exact_input":independent.digest(NATIVE/"A-1-ExactInput.csv")},
            "verified_exact_anchors":native,"continuation_max_accepted_T_kNm":numeric["maximum_of_accepted_samples_kNm"],
            "continuation_stop":numeric["stop"],"fallback_direction_gaps_observed":numeric["methods_without_direction_guard"]}
    out=HERE/"PortableReplay.json"
    out.write_bytes((json.dumps(result,indent=2)+"\n").encode("utf8"))
    print(out.name,sha256(out.read_bytes()).hexdigest().upper())


if __name__=="__main__":
    main()
