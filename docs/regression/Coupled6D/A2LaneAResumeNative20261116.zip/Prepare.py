"""Prepare a verified continuation of an isolated A2 cold-force history."""

import argparse
import csv
from hashlib import sha256
from io import StringIO
import json
from math import isfinite
from pathlib import Path
import re
from shutil import copyfile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LIVE = HERE.parent/'a2ab'
MODULE = Path('tests/modTestCoupledExperiment.bas')
BOOK = Path('workbook/output/RC_Section_NDM.xlsm')
ANCHORS = (239.4,247.1,254.8)
SCALE_AREA = 216004.
SCALE_LENGTH = 407.293505963451


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f'Resume source does not match {old!r}.')
    return text.replace(old,new)


def resume_macro():
    archive = ROOT/'docs/regression/Audit03/LocalGradientDerivative20261115/A2ColdQuadrature20261116/Resume'/MODULE
    marker = "' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Продолжает послетрещинную ветвь A2"
    source = archive.read_text(encoding='utf-8-sig')
    macro = source[source.index(marker):]
    assert macro.rstrip().endswith('End Sub')
    macro = replace_once(macro,'RunTestA2ResumeRefined(ByVal inputPath As String, ByVal sampling As String)',
                         'RunTestA2ResumeRefined(ByVal inputPath As String, ByVal lane As String)')
    macro = replace_once(macro,'    If sampling <> "7" And sampling <> "9" Then Err.Raise 5, , "Неизвестная квадратура."',
                         '    Const sampling As String = "9"\n    Dim tensileScale As Double: tensileScale = LopesA2TensileEnergyScaleTest(lane)')
    macro = replace_once(macro,'    Line Input #handle, line: n = CLng(line)',
                         '    Line Input #handle, line: values = Split(line, ";")\n'
                         '    If UBound(values) <> 2 Then Err.Raise 5, , "Отсутствует идентификатор истории A2."\n'
                         '    If values(2) <> lane Then Err.Raise 5, , "Постановка истории A2 не совпадает."\n'
                         '    n = CLng(values(0))\n    Dim nextStep As Double: nextStep = Val(values(1))\n'
                         '    If nextStep <= 0# Or nextStep > 0.001 Then Err.Raise 5, , "Неверный шаг продолжения A2."')
    macro = replace_once(macro,'EC, NU, FC, FT, 0.002, gt, (FC / FT) ^ 2 * gt, True',
                         'EC, NU, FC, FT, 0.002, gt * tensileScale, (FC / FT) ^ 2 * gt, True')
    macro = replace_once(macro,'    VerifyA2ResumePrefixTest solver, operators, concrete, response, field, saved, report, trace',
                         '    AddExperimentTraceTest report, trace, "RESUME_LAW;" & lane & ";" & _\n'
                         '        ExperimentNumberTest(gt * tensileScale) & ";" & ExperimentNumberTest((FC / FT) ^ 2 * gt)\n'
                         '    VerifyA2ResumePrefixTest solver, operators, concrete, response, field, saved, report, trace')
    macro = replace_once(macro,'torque(n) / 100000000#, n, report, trace)',
                         'torque(n) / 100000000#, n, nextStep, report, trace)')
    macro = replace_once(macro,'ByVal previousLambda As Double, ByVal lambda As Double, ByVal prefix As Long, _',
                         'ByVal previousLambda As Double, ByVal lambda As Double, ByVal prefix As Long, ByVal initialStep As Double, _')
    macro = replace_once(macro,'Const MAX_TWIST As Double = 0.043','Const MAX_TWIST As Double = 0.035')
    macro = replace_once(macro,'Dim increment As Double: increment = GeomMin(MAX_STEP, (twist - previousTwist) * 1.25)',
                         'Dim increment As Double: increment = initialStep')
    macro = replace_once(macro,'Dim guess() As Double, actual() As Double, found() As Double, seed As Variant',
                         'Dim actual() As Double, found() As Double')
    start = macro.index('            If lambdaGuess > 0# Then')
    end = macro.index('                If accepted Then',start)
    macro = macro[:start]+'''            If lambdaGuess > 0# And lambdaGuess <> lambda Then
                accepted = solver.TryDeformationStep(offset, direction, projection, target, lambdaGuess, trialLambda, _
                    ABS_TOL, REL_TOL, 24, consistentControl:=True)
'''+macro[end:]
    macro = replace_once(macro,'route = "Secant"','route = "LoadSecant"')
    macro = replace_once(macro,'            RecordA2ResumeFieldTest operators, concrete, response, found, actual, trialTwist, norm, route, _',
                         '            trialTwist = found(4) * 1000# / sectionLength\n'
                         '            If trialTwist <= twist Then Err.Raise 5, , "Nuance: контроль не продвинулся."\n'
                         '            RecordA2ResumeFieldTest operators, concrete, response, found, actual, trialTwist, norm, route, _')
    return macro.replace('Nuance: контроль не продвинулся.', 'Контролируемое закручивание не продвинулось.')


def stage():
    original = json.loads((LIVE/'Fixture.json').read_text(encoding='utf-8'))
    assert digest(ROOT/BOOK)==original['workbook_sha256']==digest(LIVE/BOOK)
    assert not (HERE/'Fixture.json').exists()
    copied = [Path(name) for name in original['frozen'] if name.startswith('tools/') or name==BOOK.as_posix()]
    for relative in copied:
        assert digest(LIVE/relative)==original['frozen'][relative.as_posix()]
        (HERE/relative).parent.mkdir(parents=True,exist_ok=True)
        copyfile(LIVE/relative,HERE/relative)
    for literal in ('Guard-IsolatedOffice.ps1','Verify-A2.py','Manifest.json','PeakReference.py'):
        copyfile(LIVE/literal,HERE/literal)
        copied.append(Path(literal))
    for directory in ('src','tests','Native','Temp','docs/regression'):
        (HERE/directory).mkdir(parents=True,exist_ok=True)
    assert digest(LIVE/MODULE)==original['frozen'][MODULE.as_posix()]
    source = (LIVE/MODULE).read_text(encoding='utf-8-sig')
    (HERE/MODULE).write_text(source.rstrip()+'\n\n'+resume_macro(),encoding='utf-8',newline='\r\n')
    copyfile(HERE/BOOK,HERE/'docs/regression/Diagnostic.xlsm')
    copied.extend([MODULE,Path('Run-Resume.ps1'),Path('Prepare.py')])
    frozen={'workbook_sha256':original['workbook_sha256'],'cold_overlay_sha256':original['frozen'][MODULE.as_posix()],
            'frozen':{key.as_posix():digest(HERE/key) for key in copied},'resume_seconds_cap':780,'exact_seconds_cap':150}
    (HERE/'Fixture.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8')
    print(digest(HERE/'Fixture.json'),digest(HERE/MODULE))


def read_rows(path):
    raw = path.read_bytes()
    complete = raw if not raw or raw.endswith(b'\n') else raw[:raw.rfind(b'\n')+1]
    return [r for r in csv.reader(StringIO(complete.decode('cp1251')),delimiter=';') if r], sha256(complete).hexdigest().upper()


def check_law(cold_rows,lane):
    manifest = json.loads((HERE/'Manifest.json').read_text(encoding='utf-8'))
    params = next(row[0] for row in cold_rows if row[0].startswith('A2_PARAMETERS:'))
    expected = (manifest[f'Gt_{lane}_N_per_mm'],manifest['Gc_both_N_per_mm'])
    match = re.search(r'Gt (\S+) \| Gc (\S+)',params)
    assert match and all(abs(float(x)-y)<=abs(y)*1.e-13 for x,y in zip(match.groups(),expected,strict=True))
    return expected


def combined(cold,lane,resumes):
    rows, original_sha = read_rows(cold)
    assert ['COLD','9','56'] in rows
    expected = check_law(rows,lane)
    fields = [r for r in rows if r[0]=='FIELD']
    assert len(fields)>=3
    traces = {str(cold):original_sha}
    for replay in resumes:
        entries, replay_sha = read_rows(replay)
        replay_meta = next(r for r in entries if r[0]=='RESUME')
        assert replay_meta == ['RESUME','9',str(len(fields)),'56']
        law = next(r for r in entries if r[0]=='RESUME_LAW')
        assert law[1]==lane and all(abs(float(x)-y)<=abs(y)*1.e-13 for x,y in zip(law[2:],expected,strict=True))
        weak = next(r for r in entries if r[0]=='REPLAY')
        assert float(weak[1])<5.e-6 and float(weak[2])<5.e-6
        for field in (r for r in entries if r[0]=='FIELD'):
            assert len(field)==76
            fields.append([*field[:3],*field[4:6],*field[10:]])
        traces[str(replay)] = replay_sha
    assert [int(r[1]) for r in fields]==list(range(1,len(fields)+1))
    weak_force, affine = 0., 0.
    tw = 0.
    for row in fields:
        assert len(row)==71 and all(isfinite(float(x)) for x in row[1:])
        twist, norm = map(float,row[3:5])
        assert twist>tw and 0<=norm<5.e-6
        tw=twist
        force = list(map(float,row[5:11]))
        norm_off = max(abs(force[i])/(SCALE_AREA*SCALE_LENGTH if i in (1,2) else SCALE_AREA) for i in (0,1,2,4,5))
        assert norm_off<=norm+5.e-13
        weak_force=max(weak_force,norm_off)
        affine=max(affine,abs(twist-float(row[14])*1000./SCALE_LENGTH))
    assert affine<1.e-14
    return fields, {'fields':len(fields),'lane':lane,'last_T_kNm':float(fields[-1][8])/1.e6,'last_twist_rad_m':tw,
                    'max_off_path_force_error_MPa':weak_force,'max_twist_affine_error_rad_m':affine,'traces_sha256':traces}


def output(cold,lane,resumes,destination,exact):
    fields, proof = combined(cold,lane,resumes)
    if exact:
        moments = [float(row[8])/1.e6 for row in fields]
        anchors = [(moment,i+1) for moment in ANCHORS for i in [next((j for j in range(1,len(fields)-1)
                   if moments[j]<moment<=moments[j+1]),None)] if i is not None]
        proof['shapes']=anchors
        if anchors:
            ceiling=max(left+1 for _,left in anchors)
            data=[['9',str(ceiling),str(len(anchors))],*[[row[1],format(t,'.17g'),*row[11:]] for t,row in zip(moments[:ceiling],fields[:ceiling],strict=True)],*anchors]
        else:
            data=[]
    else:
        step=min(.001,1.25*(float(fields[-1][3])-float(fields[-2][3])))
        data=[[len(fields),format(step,'.17g'),lane],*[[row[1],row[3],*row[5:]] for row in fields]]
    if data:
        with destination.open('x',encoding='ascii',newline='') as result:
            csv.writer(result,delimiter=';',lineterminator='\r\n').writerows(data)
        proof['output_file_sha256']=digest(destination)
    destination.with_suffix('.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cold',type=Path)
    parser.add_argument('--resume',type=Path,action='append',default=[])
    parser.add_argument('--lane',choices=('A','B'))
    parser.add_argument('--output',type=Path)
    parser.add_argument('--exact',action='store_true')
    parser.add_argument('--verify',type=Path)
    args=parser.parse_args()
    if args.verify:
        from runpy import run_path
        verifier = run_path(str(HERE/'Verify-A2.py'))
        checks = verifier['cold_gate'](args.cold,args.lane)
        rows, input_sha = read_rows(args.output)
        targets = [float(row[0]) for row in rows[-int(rows[0][2]):]]
        checks.update(anchors=verifier['exact_gate'](args.verify,targets), exact_trace_sha256=digest(args.verify),
                      exact_input_sha256=input_sha, all_anchors_verified=tuple(targets)==ANCHORS)
        args.verify.with_name(args.verify.stem+'-Verification.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(checks,indent=2))
    elif args.cold:
        output(args.cold,args.lane,args.resume,args.output,args.exact)
    else:
        stage()
