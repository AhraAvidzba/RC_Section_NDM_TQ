"""Reconstruct and minimize measured signed action cones for MVT2 B."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import argparse
import csv
import json
import math

import numpy as np
from scipy.optimize import linprog

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def read_native(path,encoding="cp1251"):
    tables=defaultdict(list)
    for marker,*row in csv.reader(path.read_text(encoding=encoding).splitlines(),delimiter=";"):
        tables[marker].append(row)
    return tables


def verified_states(tags):
    fields, stations = {}, defaultdict(dict)
    for name, history, q, *x in tags["B_TANGENT_FIELD"]:
        assert name not in fields and len(x) == 60
        fields[name] = (int(history), float(q), tuple(map(float, x)))
    for name, point, side, *row in tags["B_TANGENT_STATION"]:
        key = int(point), int(side)
        assert key not in stations[name] and len(row) == 19
        stations[name][key] = tuple(map(float, row))
    raw_r = vec(tags, "B_TANGENT_RESIDUAL")
    raw_force = {name: tuple(map(float, row)) for name, *row in tags["B_BOUND_ACTUAL"]}
    raw_norm = {name: float(value) for name, value in tags["B_BOUND_NORM"]}
    output = {}
    assert set(fields) == set(stations) == set(raw_r) == set(raw_force) == set(raw_norm)
    for name, (history, q, x) in fields.items():
        assert history == 24 and len(stations[name]) == 135
        rows, actual, strain_error = reconstruct(x, q, stations[name])
        error = peak(diff(rows, raw_r[name]))
        assert strain_error < 4e-15 and error < 3e-10
        assert max(abs(a-b)/s for a,b,s in zip(actual, raw_force[name], SCALES, strict=True)) < 4e-12
        signed = diff(actual, force(q))
        efforts = tuple(r/s for r, s in zip(signed, SCALES, strict=True))
        residual = (*rows[:56], *efforts)
        gauge_norm = MODULUS*peak(rows[56:])
        tol = 5e-7*(1.+peak(loading(q)))
        near(max(peak(residual), gauge_norm),raw_norm[name], 4e-10)
        assert gauge_norm <= tol
        output[name] = {"q": q, "field": x, "r": residual, "gauge_MPa": gauge_norm, "tol_MPa": tol,
            "signed_force_N_Nmm": signed, "norm_MPa": peak(residual), "reconstruction_error_MPa": error,
            "geometry": {key: row[:3] for key, row in stations[name].items()}}
    return output, stations


def tensor_radius(field, geometry):
    maximum = 0.
    for (_, side), (x, y, _) in geometry.items():
        strain = strain_at(field, operators(x, y), side)
        maximum = max(maximum, peak(s/(1. if i < 3 else math.sqrt(2.)) for i, s in enumerate(strain)))
    return maximum


SOURCES = {
    "gradient": ("MVT2GradientCorrection20261116.zip", "FA407B0A7625E2CC09C240470D205A5C70CE86BDC67AE04443C3B5306B323CA9", "NativeB/MVT2.csv"),
    "measured": ("MVT2MeasuredNative20261116.zip", "0D19814EB74BA458E56B40BF7E5D2E58CE057FDC724CB79A610DC6D56A77BA5E", "Native/MVT2.csv"),
    "axial": ("MVT2AxialNative20261116.zip", "82B8388B418852B9966D02DDCA7A4229A94AE141E7FB97B560F8D9241EB8AA91", "Native/MVT2.csv"),
}


def archive_states(folder, key):
    filename, identity, trace_file = SOURCES[key]
    archive=folder/filename
    assert digest(archive)==identity
    with ZipFile(archive) as evidence:
        trace=evidence.read(trace_file)
    tables=defaultdict(list)
    for tag,*row in csv.reader(trace.decode("cp1251").splitlines(),delimiter=";"):
        tables[tag].append(row)
    return verified_states(tables),sha256(trace).hexdigest().upper()


def tensor(field, geometry):
    return np.array([value/(1. if i<3 else math.sqrt(2.)) for (_,side),(x,y,_) in geometry.items()
        for i,value in enumerate(strain_at(field,operators(x,y),side))])


def evaluate_pair(reference, directions, secant, axial, reflected_axial):
    r=reference["r"]
    tol=reference["tol_MPa"]
    caps=np.maximum(abs(r[56:]),tol)
    actions=[np.stack([directions[secant]["r"],directions[axial]["r"]],axis=1)]
    if reflected_axial is not None:
        actions.append(np.stack([directions[secant]["r"],-directions[reflected_axial]["r"]],axis=1))
    scale=1e4
    rows=[]
    right=[]
    for action in actions:
        a=scale*action
        force=np.c_[a[56:],np.zeros(6)]
        rows.extend((np.c_[a,-np.ones(62)],np.c_[-a,-np.ones(62)],force,-force))
        right.extend((-scale*r,scale*r,scale*(caps-r[56:]),scale*(caps+r[56:])))
    rows.append(np.array([[1.,1.,0.]]))
    right.append(np.array([1.]))
    result=linprog([0.,0.,1.],A_ub=np.vstack(rows),b_ub=np.concatenate(right),bounds=[(0.,1.),(0.,1.),(0.,None)],
        method="highs",options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
    assert result.success,result.message
    a,b=(max(0.,x) for x in result.x[:2])
    assert a+b<=1.+1e-12
    predictions=[]
    for scenario,action in enumerate(actions):
        residual=r+action@np.array([a,b])
        assert np.all(abs(residual[56:])<=caps+5e-12)
        peaks=max(abs(residual))
        predictions.append({"model":axial if scenario==0 else f"reflected {reflected_axial}","max_MPa":float(peaks),
            "row1_MPa":float(residual[0]),"row53_MPa":float(residual[52]),
            "six_N_Nmm":(residual[56:]*np.asarray(SCALES)).tolist(),"governing_row":int(np.argmax(abs(residual))+1)})
    optimum=max(x["max_MPa"] for x in predictions)
    near(optimum,float(result.fun/scale),6e-12)
    movement=a*directions[secant]["q"]+b*directions[axial]["q"]
    radius=tensor_radius(movement,reference["geometry"])
    assert radius<=max(directions[label]["tensor_radius"] for label in (secant,axial))+2e-15
    difference=float(max(abs(r))-optimum)
    return {"secant":secant,"axial":axial,"included_reflected_action":reflected_axial,"coefficient":[float(a),float(b)],
        "best_linear_norm_MPa":optimum,"predicted_decrease_MPa":difference,"predicted_decrease_over_tol":difference/tol,
        "tensor_radius":radius,"predictions":predictions}


def proof_from_principal_rows(reference,directions):
    r=reference["r"]
    bb=directions["Large"]["r"]
    pp=directions["AxialPlus"]["r"]
    mm=directions["AxialMinus"]["r"]
    ll=directions["Line"]["r"]
    assert ll[57]<0. and pp[57]<0. and ll[56]<0. and mm[56]<0.
    assert r[0]<0. and r[52]>0. and r[59]<0.
    a=-r[0]; gap=a-r[52]; assert gap>0.
    assert bb[59]>0. and pp[59]<0.
    ratio_plus=bb[59]/(-pp[59])
    ratio_minus=bb[0]/(-mm[0])
    ratio_required_for_gradient=bb[52]/(-mm[52])
    assert 0.<ratio_minus<ratio_required_for_gradient
    assert bb[52]>0. and pp[52]>0.
    # Absolute residuals are bounded below by -row1 and +row53 even if their signs change.
    # For fixed beta/alpha, their affine envelope is smallest at their intersection.
    def lower_bound(axial, beta_per_alpha):
        n=bb[0]+beta_per_alpha*axial[0]
        g=bb[52]+beta_per_alpha*axial[52]
        assert g>=0. and n+g>0.
        alpha=gap/(n+g)
        improvement=alpha*n
        return {"alpha":float(alpha),"beta":float(beta_per_alpha*alpha),"max_possible_decrease_MPa":float(improvement),
            "min_possible_max_residual_MPa":float(a-improvement)}
    assert pp[0]*bb[52]-pp[52]*bb[0]>0.   # n/g increases with beta/alpha for the positive axial action.
    assert mm[0]*bb[52]-mm[52]*bb[0]<0.   # n/g decreases with beta/alpha for the negative action.
    return {"line_plus_all_effort_feasible_only_zero_blocked_by":"Mx",
        "line_minus_all_effort_feasible_only_zero_blocked_by":"N",
        "large_plus_T_bound_for_beta_per_alpha":float(ratio_plus),
        "large_minus_N_bound_for_beta_per_alpha":float(ratio_minus),
        "large_minus_ratio_needed_to_keep_row53_from_increasing":float(ratio_required_for_gradient),
        "large_plus_envelope_from_N_row53_T":lower_bound(pp,ratio_plus),
        "large_minus_envelope_from_N_row53":lower_bound(mm,0.),
        "certificate_scope":"Affine measured signed-action cone. Bounds use sign and inequality information only; no fitted acceptance threshold."}


def run(evidence, output):
    (grad,_), grad_hash=archive_states(evidence,"gradient")
    (measured,_), measured_hash=archive_states(evidence,"measured")
    (axial,station), axial_hash=archive_states(evidence,"axial")
    centre=axial["Anchor"]
    for label in ("AxialCompPlus/Rollback","AxialCompMinus/Rollback","Restored24"):
        assert axial[label]==axial["Base24"] and station[label]==station["Base24"]
    original=measured["MeasuredCombination"]
    assert peak(diff(original["field"],centre["field"]))<3e-15
    assert peak(diff(original["r"],centre["r"]))<4e-10
    centre={**centre,"r":np.array(centre["r"]),"field":np.array(centre["field"])}
    directions={}
    endpoints={"Line":measured["MeasuredLine"],"Large":grad["BothBest"],
               "AxialPlus":axial["AxialCompPlus"],"AxialMinus":axial["AxialCompMinus"]}
    for name,endpoint in endpoints.items():
        assert endpoint["q"]==centre["q"] and endpoint["geometry"]==centre["geometry"]
        dq=np.array(endpoint["field"])-centre["field"]
        dr=np.array(endpoint["r"])-centre["r"]
        directions[name]={"tensor_radius": tensor_radius(dq,centre["geometry"]),"q":dq,"r":dr,"N_delta_N":float(dr[56]*AREA)}
    measured_true_axes={}
    for name,vector in directions.items():
        axis=tensor(vector["q"],centre["geometry"])
        axial_axis=tensor(directions["AxialPlus"]["q"],centre["geometry"])
        angle=float(axis@axial_axis/np.linalg.norm(axis)/np.linalg.norm(axial_axis))
        measured_true_axes[name]={"tensor_radius":vector["tensor_radius"],"cosine_to_positive_axial_direction":angle,
            "weak_action_row1_MPa":float(vector["r"][0]),"weak_action_row53_MPa":float(vector["r"][52]),
            "effort_changes_N_Nmm":(vector["r"][56:]*np.asarray(SCALES)).tolist(),"action_MPa":vector["r"].tolist()}
    assert abs(measured_true_axes["Large"]["cosine_to_positive_axial_direction"])<.99
    dplus=directions["AxialPlus"]["r"]
    dminus=directions["AxialMinus"]["r"]
    axial_even=dplus+dminus
    results=[]
    for side in ("Line","Large"):
        for sign,other in (("AxialPlus","AxialMinus"),("AxialMinus","AxialPlus")):
            results.append(evaluate_pair(centre,directions,side,sign,None))
            results.append(evaluate_pair(centre,directions,side,sign,other))
    bounds=proof_from_principal_rows(centre,directions)
    nominal=[item for item in results if item["included_reflected_action"] is None]
    for result in nominal:
        side=result["secant"]
        if side=="Line":
            near(peak(result["coefficient"]),0.,5e-12)
            near(result["predicted_decrease_MPa"],0.,5e-12)
        else:
            face=bounds["large_plus_envelope_from_N_row53_T"] if result["axial"]=="AxialPlus" else bounds["large_minus_envelope_from_N_row53"]
            near(face["min_possible_max_residual_MPa"],result["best_linear_norm_MPa"],5e-12)
    best=max(nominal,key=lambda x:x["predicted_decrease_MPa"])
    assert 0.<best["predicted_decrease_over_tol"]<1.
    summary={"archive_trace_sha256":{"325":grad_hash,"334":measured_hash,"338":axial_hash},
        "history":24,"target_Qy_kN":centre["q"],"centre_norm_MPa":centre["norm_MPa"],
        "centre_row53_MPa":float(centre["r"][52]),"centre_row1_MPa":float(centre["r"][0]),"tolerance_MPa":centre["tol_MPa"],
        "centre_signed_effort_N_Nmm":centre["signed_force_N_Nmm"],"true_measured_axis_actions":measured_true_axes,
        "nominal_and_two_axial_action_envelopes":results,"analytic_cone_certificate":bounds,
        "best_measured_affine_model":best,"max_observed_axial_sign_reflection_error_MPa":float(max(abs(axial_even))),
        "worst_signed_reflection_error_row":int(np.argmax(abs(axial_even))+1),
        "measured_cone_predicts_decrease_by_one_original_tolerance":False,
        "mixed_nonlinear_interaction_measured":False,
        "scope":"Reflected sign envelopes test axial-action sensitivity. They do not bound mixed material response. No new field chosen."}
    output.write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    print(output.name,digest(output))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence_directory",type=Path)
    parser.add_argument("output_json",type=Path)
    args=parser.parse_args()
    run(args.evidence_directory,args.output_json)
