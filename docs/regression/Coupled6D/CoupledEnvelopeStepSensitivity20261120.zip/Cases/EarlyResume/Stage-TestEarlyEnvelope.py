"""ДЛЯ ТЕСТОВ. Подготавливает единственный рабочий контроллер с ранней одной материальной пробой после численного отказа."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, parent):
    """Остальные 253 компонента берёт из проверенной компиляции; штатный расчёт начинает историю с нуля."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestStockYieldEvent.py'))['TestStage'](repo, root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = Path(__file__).name
    (root / name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='EarlySingleEnvelopeRecovery',
        actual_import_this_pass=['CCoupledDeformationContinuation'], fresh_compilation_claimed=True,
        one_early_H_target_per_failed_spatial_probe=True, original_force_and_material_tolerances=True,
        steel_design_and_loadpath_checks_unchanged=True, physical_capacity_certified=False,
        component_count_expected=254, other_parent_components_expected=253)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('EARLY SINGLE H RECOVERY READY; ONE WORKING CONTROLLER IMPORT; ORIGINAL TOLERANCES')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=Path.cwd())
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    a = p.parse_args()
    TestStage(a.repo.resolve(), a.root.resolve(), a.parent.resolve())
