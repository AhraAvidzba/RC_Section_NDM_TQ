"""ДЛЯ ТЕСТОВ. Готовит направленный штатный расчёт и регрессии с неизменной уже проверенной рабочей компиляцией."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root, parent):
    """Не компилирует повторно неизменный код; отдельные нативные запуски создают собственную историю с нуля."""
    here = Path(__file__).resolve().parent
    compilation = json.loads((parent / 'docs/regression/CodeUpdate.json').read_bytes())
    imports = sorted(('CCoupledConcreteResponse', 'CCoupledReinforcedResponse', 'CCoupledNewtonSolver',
        'CCoupledDeformationContinuation', 'CCoupledEnvelopeEquations', 'modTestCoupledElasticState'))
    assert sorted(compilation['Modules']) == imports
    audit = json.loads((parent / 'PointTraceSourceComposition.json').read_bytes())
    assert len(audit['other_actual_components_exact_parent_except_identifier_case']) == 248
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    code = (parent / 'Run-TestStockYield.ps1').read_text('utf-8-sig')
    before = "(Compare-Object @('CCoupledDeformationContinuation') ($compile.Modules|Sort-Object))"
    assert code.count(before) == 1
    after = '(Compare-Object @(' + ','.join("'" + name + "'" for name in imports) + ') ($compile.Modules|Sort-Object))'
    code = code.replace(before, after, 1)
    name = 'Run-TestWorkingEnvelopeStock.ps1'
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = Path(__file__).name
    (root / name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingEnvelopeStockAndDirectedRegression',
        fresh_native_history_from_zero=True, compiled_code_reused_without_mutable_state=True,
        fresh_compilation_claimed=False, source_workbook_sha256=compilation['WorkbookSHA256'],
        no_prescribed_material_point_or_level=True, native_timeout_seconds=600,
        results_saved_reopened_required=True, physical_capacity_certified=False,
        installed_workbook_changed=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING ENVELOPE STOCK READY; SAME CHECKED COMPILED CODE; FRESH NATIVE HISTORIES')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    a = p.parse_args()
    TestStage(a.root.resolve(), a.parent.resolve())
