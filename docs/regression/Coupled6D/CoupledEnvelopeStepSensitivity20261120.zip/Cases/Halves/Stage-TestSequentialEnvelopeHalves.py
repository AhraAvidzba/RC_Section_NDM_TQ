"""ДЛЯ ТЕСТОВ. Готовит сравнение полного материального шага с двумя последовательными полушагами на проверенном ядре."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root, parent):
    """Не меняет рабочие компоненты или физические данные; заменяет один тестовый вызов."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestSequentialEnvelopeHalves.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body, code)
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name, 'TestSequentialEnvelopeHalves.bas.txt'):
        (root / name).write_bytes((here / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ActualSequentialEnvelopeHalves',
        actual_intermediate_material_history_committed=True,
        full_and_two_half_paths_start_at_same_accepted_history=True,
        working_components_unchanged_from_checkpoint637=True,
        original_force_and_material_tolerances=True, actual_working_Trace_API=False,
        physical_capacity_certified=False, actual_import_this_pass=['modTestCoupledElasticState'])
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('SEQUENTIAL H HALVES READY; ACTUAL INTERMEDIATE COMMIT; ONE TEST IMPORT')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    a = p.parse_args()
    TestStage(a.root.resolve(), a.parent.resolve())
