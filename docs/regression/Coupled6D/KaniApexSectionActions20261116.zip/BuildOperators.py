import numpy as np
from scipy.interpolate import BSpline

def operators(geometry, L):
    x,y,area=geometry.T
    normalized=area/(305.*610.)
    gx_knots=np.array([-152.5]*4+[0.]+[152.5]*4)
    gy_knots=np.array([-305.]*4+[0.]+[305.]*4)
    basis=np.eye(5)
    spline_x=BSpline(gx_knots,basis,3,extrapolate=False)
    spline_y=BSpline(gy_knots,basis,3,extrapolate=False)
    nx,ny=spline_x(x),spline_y(y)
    dx,dy=spline_x.derivative()(x),spline_y.derivative()(y)
    def pair(a,b):
        return (a[:,:,None]*b[:,None,:]).reshape((len(x),25))
    shape=pair(ny,nx)
    slope_x=L*pair(ny,dx)
    slope_y=L*pair(dy,nx)
    h=np.zeros((184,6,79))
    u=slice(4,79,3)
    v=slice(5,79,3)
    w=slice(6,79,3)
    h[:,2,0]=1.
    h[:,2,1]=y/L
    h[:,2,2]=x/L
    h[:,4,3]=-y/L
    h[:,5,3]=x/L
    h[:,0,u]=slope_x
    h[:,1,v]=slope_y
    h[:,3,u]=slope_y
    h[:,3,v]=slope_x
    h[:,4,w]=slope_x
    h[:,5,w]=slope_y
    c=np.zeros((4,79))
    concrete=slice(144)
    shape_weight=shape[concrete]*normalized[concrete,None]
    c[0,u]=c[1,v]=c[2,w]=shape_weight.sum(axis=0)
    c[3,u]=(-y[concrete,None]/L*shape_weight).sum(axis=0)
    c[3,v]=(x[concrete,None]/L*shape_weight).sum(axis=0)
    resultants=np.zeros((184,6,6))
    resultants[:,0,2]=1.
    resultants[:,1,2]=y
    resultants[:,2,2]=x
    resultants[:,3,4]=-y
    resultants[:,3,5]=x
    resultants[:,4,4]=1.
    resultants[:,5,5]=1.
    scales=305.*610.*np.array([1.,L,L,L,1.,1.])
    return h, shape, c, resultants, normalized, scales

