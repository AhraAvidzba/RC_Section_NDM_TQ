Attribute VB_Name = "modTestCoupledApexActions"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает действие штатной касательной с направленным откликом у вершины.
' Обе сборки используют один принятый буфер, одинаковые силы и геометрию.

Private Const TEST_COMPONENT_COUNT As Long = 6
Private Const TEST_SPATIAL_HALF_STEP As Double = 0.001

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вычисляет два внутренних действия по полю d в одном и том же состоянии.
' Силовые строки (МПа) и шесть интегральных усилий собирает рабочая геометрия.
Public Function TryAssembleApexActionsTest(ByVal section As CCoupledElasticState, _
        ByVal center As CCoupledReinforcedResponse, ByVal plus As CCoupledReinforcedResponse, _
        ByVal minus As CCoupledReinforcedResponse, ByVal centerConcrete As CCoupledConcreteResponse, _
        ByVal plusConcrete As CCoupledConcreteResponse, ByVal minusConcrete As CCoupledConcreteResponse, _
        ByRef field() As Double, ByRef direction() As Double, ByVal mode As ECoupledTangentMode, _
        ByRef stock() As Double, ByRef hybrid() As Double, ByRef stockEfforts() As Double, _
        ByRef hybridEfforts() As Double, ByRef changedStations As Long) As Boolean
    If mode <> ctmFull And mode <> ctmFullBranchConsistent And mode <> ctmRefinedBranchConsistent Then Exit Function
    Dim operators(0 To 2) As ICoupledPointResponse, concrete(0 To 2) As CCoupledConcreteResponse
    Set operators(0) = center: Set operators(1) = plus: Set operators(2) = minus
    Set concrete(0) = centerConcrete: Set concrete(1) = plusConcrete: Set concrete(2) = minusConcrete
    Dim zero() As Double, unusedMatrix() As Double, unusedTangent() As Double
    ReDim zero(1 To section.DegreeCount)
    section.StartEquations direction, zero, stock, unusedMatrix, False
    hybrid = stock ' Реакции и сами уравнения связей одинаковы в обеих сборках.
    ReDim stockEfforts(1 To TEST_COMPONENT_COUNT), hybridEfforts(1 To TEST_COMPONENT_COUNT)
    changedStations = 0

    Dim point As Long, side As Long, component As Long, replacement As Boolean, changed As Boolean
    Dim strain(1 To TEST_COMPONENT_COUNT) As Double, strainGradient(1 To TEST_COMPONENT_COUNT) As Double
    Dim increment(1 To TEST_COMPONENT_COUNT) As Double, incrementGradient(1 To TEST_COMPONENT_COUNT) As Double
    Dim atSide(1 To TEST_COMPONENT_COUNT) As Double, alongSide(1 To TEST_COMPONENT_COUNT) As Double
    Dim current(1 To TEST_COMPONENT_COUNT) As Double, adjusted(1 To TEST_COMPONENT_COUNT) As Double
    Dim sideStock(1 To TEST_COMPONENT_COUNT, 0 To 2) As Double, sideNew(1 To TEST_COMPONENT_COUNT, 0 To 2) As Double
    Dim stockCenter(1 To TEST_COMPONENT_COUNT) As Double, hybridCenter(1 To TEST_COMPONENT_COUNT) As Double
    Dim stockSlope(1 To TEST_COMPONENT_COUNT) As Double, hybridSlope(1 To TEST_COMPONENT_COUNT) As Double
    Dim offset As Double
    For point = 1 To section.PointCount
        replacement = (point > section.ConcretePointCount)
        section.PointStrain point, field, strain
        section.AxialGradientAtPoint point, field, strainGradient
        section.PointStrain point, direction, increment
        section.AxialGradientAtPoint point, direction, incrementGradient
        For side = 0 To 2
            offset = 0#
            If side = 1 Then offset = TEST_SPATIAL_HALF_STEP
            If side = 2 Then offset = -TEST_SPATIAL_HALF_STEP
            For component = 1 To TEST_COMPONENT_COUNT
                atSide(component) = strain(component) + offset * strainGradient(component)
                alongSide(component) = increment(component) + offset * incrementGradient(component)
            Next component
            changed = False
            If Not TryApexStationActionsTest(operators(side), concrete(side), point, atSide, alongSide, mode, _
                    replacement, current, adjusted, changed) Then Exit Function
            If changed Then changedStations = changedStations + 1
            For component = 1 To TEST_COMPONENT_COUNT
                sideStock(component, side) = current(component)
                sideNew(component, side) = adjusted(component)
            Next component
        Next side
        For component = 1 To TEST_COMPONENT_COUNT
            stockCenter(component) = sideStock(component, 0)
            hybridCenter(component) = sideNew(component, 0)
            stockSlope(component) = (sideStock(component, 1) - sideStock(component, 2)) / (2# * TEST_SPATIAL_HALF_STEP)
            hybridSlope(component) = (sideNew(component, 1) - sideNew(component, 2)) / (2# * TEST_SPATIAL_HALF_STEP)
        Next component
        section.AddSpatialPointEquilibrium point, stockCenter, unusedTangent, stockSlope, unusedTangent, _
            unusedTangent, stock, unusedMatrix, False, stockEfforts
        section.AddSpatialPointEquilibrium point, hybridCenter, unusedTangent, hybridSlope, unusedTangent, _
            unusedTangent, hybrid, unusedMatrix, False, hybridEfforts
    Next point
    TryAssembleApexActionsTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет одноосный вклад стали. В её точке положительное
' изменение тензора вытесненного бетона вычитается.
Private Function TryApexStationActionsTest(ByVal composite As ICoupledPointResponse, ByVal concrete As CCoupledConcreteResponse, _
        ByVal point As Long, ByRef strain() As Double, ByRef increment() As Double, ByVal mode As ECoupledTangentMode, _
        ByVal replacement As Boolean, ByRef stock() As Double, ByRef adjusted() As Double, ByRef changed As Boolean) As Boolean
    Dim stress(1 To TEST_COMPONENT_COUNT) As Double, tangent(1 To TEST_COMPONENT_COUNT, 1 To TEST_COMPONENT_COUNT) As Double
    If composite.EvaluatePoint(point, strain, stress, tangent, mode, recordTrial:=False) <> sfcNone Then Exit Function
    MaterialActionTest tangent, increment, stock
    Dim candidate(1 To TEST_COMPONENT_COUNT) As Double, row As Long
    changed = concrete.TryEvaluateApexDirection(point, strain, increment, candidate)
    For row = 1 To TEST_COMPONENT_COUNT: adjusted(row) = stock(row): Next row
    If changed Then
        If replacement Then
            Dim concreteModel As ICoupledPointResponse: Set concreteModel = concrete
            If concreteModel.EvaluatePoint(point, strain, stress, tangent, mode, recordTrial:=False) <> sfcNone Then Exit Function
            Dim previousConcrete(1 To TEST_COMPONENT_COUNT) As Double
            MaterialActionTest tangent, increment, previousConcrete
            For row = 1 To TEST_COMPONENT_COUNT
                adjusted(row) = stock(row) + previousConcrete(row) - candidate(row)
            Next row
        Else
            For row = 1 To TEST_COMPONENT_COUNT: adjusted(row) = candidate(row): Next row
        End If
    End If
    TryApexStationActionsTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Умножает материальную касательную на инженерный вектор деформаций.
Private Sub MaterialActionTest(ByRef tangent() As Double, ByRef increment() As Double, ByRef action() As Double)
    Dim row As Long, column As Long
    For row = 1 To TEST_COMPONENT_COUNT
        action(row) = 0#
        For column = 1 To TEST_COMPONENT_COUNT
            action(row) = action(row) + tangent(row, column) * increment(column)
        Next column
    Next row
End Sub
