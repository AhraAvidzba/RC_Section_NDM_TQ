"""Verify native apex section tangent actions from all three actual station fields."""
from collections import defaultdict
from hashlib import sha256
from io import BytesIO
import csv
import json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
from BuildOperators import operators

H = Path(__file__).resolve().parent
NATIVE = H/"Native"
SOURCE = "A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def peak(vector):
    return float(np.linalg.norm(vector, np.inf))


def generate():
    prep = read(H/"Preparation.json")
    for p, expected in prep["frozen"].items():
        assert digest(H/p)==expected,p
    report=NATIVE/"KaniV4.txt"
    build=read(H/"docs/regression/CodeUpdate.json")
    compile_gone=read(NATIVE/"CompileClosure.json")
    run_gone=read(NATIVE/"KaniV4.txt.ProcessClosure.json")
    owner=read(NATIVE/"KaniV4.txt.Ownership.json")
    assert compile_gone["State"]=="Absent"
    assert run_gone["Passed"] and run_gone["ChildExitCode"]==0
    final=run_gone["Closure"]["FinalState"]
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert build["Compiled"] and not build["ProductionChanged"] and build["ProductionSHA256"]==SOURCE
    assert sorted(build["Modules"])==prep["modules"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert "TOTAL_KANI_V4_STAGE38: passed=1; failed=0" in report.read_text(encoding="utf-8-sig")

    geometric=np.loadtxt(H/"KaniApexGeometry.csv",delimiter=";")
    length=float((H/"KaniApexLength.txt").read_text("ascii"))
    h,shape,c,qmat,weights,scales=operators(geometric,length)
    field_rows={}
    for row in csv.reader((H/"ApexSectionFields.csv").open(encoding="ascii",newline=""),delimiter=";"):
        field_rows[row[0]]=(float(row[1]),np.asarray(row[2:89],float),np.asarray(row[89:],float))
    signed={}
    native_files=[NATIVE/x for x in ("KaniV4Trace.csv","KaniV4Stations.csv","KaniV4Tangents.csv")]
    actions={}
    vectors={}
    states={}
    fields={}
    station_data=defaultdict(lambda:np.full((3,184,12),np.nan))
    flags=defaultdict(lambda:np.full((3,184,3),-9,dtype=int))
    for path in native_files:
        with path.open(encoding="cp1251",newline="") as file:
            for tag,label,*row in csv.reader(file,delimiter=";"):
                if tag=="ACTION": actions[label]=(int(row[0]),float(row[1]),int(row[2]))
                elif tag=="APEX_VECTOR": vectors[label]=np.asarray(row,float)
                elif tag=="K59C_VECTOR": fields[label]=np.asarray(row,float)
                elif tag=="K59C_STATE": states[label]=np.asarray(row,float)
                elif tag=="K59C_STATION":
                    point,side,*values=row
                    station_data[label][int(side)+1,int(point)-1]=np.asarray(values,float)
                elif tag=="BRANCH":
                    point,side,*values=row
                    flags[label][int(side)+1,int(point)-1]=np.asarray(values,int)

    def recompute(label):
        trace=states[label]
        fld=fields[label]
        coord=fld[2:81]
        depth=fld[81:85]
        mu=fld[85:]
        s=station_data[label]
        assert np.isfinite(s).all()
        strains=h@coord
        slopes=h[:,:,:4]@depth
        expected=np.stack([strains+side*.001*slopes for side in (-1,0,1)])
        assert np.max(abs(expected-s[:,:,:6]))<6e-14
        stresses=s[1,:,6:]
        spatial=(s[2,:,6:]-s[0,:,6:])/.002
        physical=np.einsum("nij,ni,n->j",h,stresses,weights)
        physical[4:]-=np.einsum("nk,na,n->ka",shape,spatial[:,[4,5,2]],weights).ravel()
        physical+=c.T@mu
        axial=np.einsum("nij,ni,n->j",h[:,:,:4],spatial,weights)
        axial[1]-=1e5*fld[0]/scales[0]
        force=np.einsum("nij,nj,n->i",qmat,stresses,geometric[:,2])
        gauge=c@coord
        assert peak(np.r_[physical,axial,gauge]-trace[12:])<2e-10
        assert peak((force-trace[6:12])/scales)<3e-10
        return np.r_[physical,axial,gauge],force

    for label,(count,factor,mode) in actions.items():
        step,origin,direction=field_rows[label]
        assert step==factor and count>0 and mode in (0,3)
        lp, lm = label+"/Plus", label+"/Minus"
        assert peak(origin+step*direction-fields[lp][2:])<4e-16
        assert peak(origin-step*direction-fields[lm][2:])<4e-16
        rp,wp=recompute(lp)
        rm,wm=recompute(lm)
        actual=(rp-rm)/(2*step)
        actual_force=(wp-wm)/(2*step)
        changes=int(np.count_nonzero(np.any(flags[lp]!=flags[lm],axis=2)))
        checks={}
        for variant in ("Stock","Hybrid"):
            calc=vectors[label+"/"+variant]
            efforts=vectors[label+"/"+variant+"Efforts"]
            assert len(calc)==87 and len(efforts)==6
            error=peak(np.r_[calc[:83]-actual[:83],(efforts-actual_force)/scales])
            assert peak(calc[83:]-actual[83:])<2e-15
            checks[variant]={"maxError_MPa":error,"effortErrors_N_Nmm":(efforts-actual_force).tolist(),
                             "maxPhysicalAction_MPa":peak(calc[:83])}
        signed[label]={"analyticStations":count,"stockTangentMode":mode,"sampleFlagChanges":changes,"sampleAction_MPa":peak(actual[:83]),
                       "actualEfforts_N_Nmm":actual_force.tolist(),"models":checks}
    assert set(signed)==set(field_rows)=={"NearRefit","PlusApex","MinusApex"}
    assert np.array_equal(fields["BaseAccepted"],fields["EndAccepted"])
    assert np.array_equal(station_data["BaseAccepted"],station_data["EndAccepted"])
    assert np.array_equal(fields["Original43"],fields["Restore43"])
    assert np.array_equal(station_data["Original43"],station_data["Restore43"])
    result={"installedWorkBook":SOURCE,"tests":signed,"process":final,
            "rawHashes":{p.name:digest(p) for p in native_files}}
    path=H/"ApexSectionVerification.json"
    path.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(path,digest(path))
    for name, values in signed.items():
        print(name,values["analyticStations"],values["sampleFlagChanges"],
              [m["maxError_MPa"] for m in values["models"].values()])


if __name__=="__main__":
    generate()
