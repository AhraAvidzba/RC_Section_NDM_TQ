"""Prepare a private native test of assembled apex tangent actions."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from shutil import copy2
from zipfile import ZipFile
import numpy as np

H = Path(__file__).resolve().parent
REFIT = H.parent / "KaniRefitNear47"
ZIP = "docs/regression/Coupled6D/"
NAMES = ["CCoupledConcreteResponse", "CCoupledElasticState", "CCoupledNewtonSolver",
         "modTestCoupledApexActions", "modTestKaniStage38"]


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def load_samples(repo, name, fingerprint):
    archive = repo / ZIP / name
    assert digest(archive) == fingerprint, name
    with ZipFile(archive) as pack:
        data = pack.read("MeasuredSamples.npz")
    with np.load(BytesIO(data), allow_pickle=False) as samples:
        return {name: p[2:] for name, p in zip(samples["names"], samples["fields"], strict=True)}


def prepare(repo, material):
    assert not (H / "Preparation.json").exists()
    assets = json.loads((REFIT / "Preparation.json").read_text("utf8"))
    for rel, expected in assets["frozen"].items():
        if not (rel.startswith(("src/","tools/")) or rel in ("KaniGaugeInput.csv","KaniV4Input.csv")):
            continue
        src = REFIT / rel
        assert digest(src) == expected, rel
        path = H / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        copy2(src, path)
    book = repo / "workbook/output/RC_Section_NDM.xlsm"
    assert digest(book) == assets["workbook_sha256"]
    for rel in ("workbook/output/RC_Section_NDM.xlsm", "docs/regression/Diagnostic.xlsm"):
        target = H / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        copy2(book, target)
    src = (REFIT / "tests/modTestKaniStage38.bas").read_text("utf8")
    marker = '    WriteKaniTrialYieldTest "BaseAccepted", operators, concrete, accepted, tangents\n'
    assert src.count(marker) == 1
    call = ('    RunKaniApexActionsTest rootPath & "ApexSectionFields.csv", operators, solver, materials, _\n'
            '        concrete, projection, lambdaAccepted, trace, stations, tangents\n')
    src = src.replace(marker, marker + call)
    (H / "tests").mkdir(exist_ok=True)
    (H / "tests/modTestKaniStage38.bas").write_text(src + "\n" + (H / "SectionWitness.bas.txt").read_text("utf8"), encoding="utf8")
    copy2(H/"modTestCoupledApexActions.bas", H/"tests/modTestCoupledApexActions.bas")
    copy2(material, H/"src/CCoupledConcreteResponse.cls")
    first = load_samples(repo, "KaniPracticalProbe45Portable.zip",
                         "4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113")
    refit = load_samples(repo, "KaniRefitNear47Portable.zip",
                         "409609AC8C79261DF38EE37A1B450B2BBD5CCDAB50142398B5DF61F274834122")
    root = first["BaseAccepted"]
    assert np.array_equal(root, refit["BaseAccepted"])
    pairs = [
        ("NearRefit", refit["NearOriginal"], refit["NearFull"]-refit["NearOriginal"], .5),
        ("PlusApex", first["LoadShape00Plus"], (first["PriorSecant01Plus"]-root)*.001, .05),
        ("MinusApex", first["LoadShape00Minus"], (first["TangentContrast01Plus"]-root)*.001, .05),
    ]
    lines = [";".join((label, str(scale), *(format(v, ".17g") for v in a), *(format(v, ".17g") for v in d)))
             for label, a, d, scale in pairs]
    (H/"ApexSectionFields.csv").write_bytes(("\r\n".join(lines)+"\r\n").encode("ascii"))
    runner = (REFIT/"Run-Near47.ps1").read_text(encoding="utf-8-sig")
    runner = runner.replace("Prepare-Near47.py", "Prepare-ApexSection.py").replace("Verify-Near47.py", "Verify-ApexSection.py")
    runner = runner.replace("@('modTestKaniStage38','CCoupledNewtonSolver','CCoupledElasticState')", repr(NAMES).replace("[","@(").replace("]",")"))
    runner = runner.replace("'CCoupledElasticState,CCoupledNewtonSolver,modTestKaniStage38'", repr(",".join(NAMES)))
    assert "CCoupledConcreteResponse" in runner
    (H/"Run-ApexSection.ps1").write_text(runner, encoding="utf-8-sig")
    for name in ("Native", "Temp"):
        (H/name).mkdir(exist_ok=True)
    frozen = [p for p in H.rglob("*") if p.is_file() and p.parent.name not in ("Native", "Temp")]
    frozen = [p for p in frozen if p.name != "Diagnostic.xlsm"]
    receipt = {"workbook_sha256": assets["workbook_sha256"], "modules": NAMES,
               "frozen": {p.relative_to(H).as_posix():digest(p) for p in sorted(frozen)}}
    (H/"Preparation.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf8")


def check():
    receipt = json.loads((H/"Preparation.json").read_text("utf8"))
    for name, expected in receipt["frozen"].items():
        assert digest(H/name) == expected, name
    return receipt["workbook_sha256"]


if __name__ == "__main__":
    cli = ArgumentParser()
    cli.add_argument("--check", action="store_true")
    cli.add_argument("--repo", type=Path)
    cli.add_argument("--material", type=Path)
    args = cli.parse_args()
    if not args.check:
        prepare(args.repo, args.material)
    print(check())
