Attribute VB_Name = "modTestKaniStage38"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продолжает Kani 37 на штатном решателе V4 из проверенной материальной истории.
Private Const KaniEcTest As Double = 25600#
Private Const KaniForceTest As Double = 100000#
Private Const KaniAbsTest As Double = 0.0000005
Private Const KaniRelTest As Double = 0.00000002
Private Const KaniSizeTest As Long = 87
Private Const KaniPhysicalTest As Long = 83
Private Const KaniPointsTest As Long = 184

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прямой и двухшаговый маршруты используют одно восстановленное состояние 37.
Public Function RunTestKaniStage38(ByVal historyPath As String) As String
    Dim trace As Integer, stations As Integer, tangents As Integer
    Dim status As String, label As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга Kani V4."

    Dim history As New Collection, gamma() As Double, factors() As Double, target As Double
    ReadKaniStage38InputTest historyPath, history, gamma, factors, target
    Dim section As CSectionModel, layout As CTransverseRebarLayout, steel As Object
    Set section = BuildKaniStage38SectionTest(layout, steel)
    Dim operators As New CCoupledElasticState, solver As New CCoupledNewtonSolver
    Dim concrete(-1 To 1) As CCoupledConcreteResponse, materials(-1 To 1) As CCoupledReinforcedResponse
    operators.PrepareModel section, KaniEcTest, 0.2, 2, 2, 6, layout, steelModels:=steel
    If operators.DegreeCount <> KaniSizeTest Or operators.PointCount <> KaniPointsTest Or operators.ConcretePointCount <> 144 Then _
        Err.Raise 5, , "Квадратура Kani V4 не совпадает с контрольной."
    Dim side As Long, gt As Double
    gt = 0.073 * 28.2 ^ 0.18
    For side = -1 To 1
        Set concrete(side) = New CCoupledConcreteResponse
        concrete(side).Initialize KaniPointsTest, KaniEcTest, 0.2, 0.6 * 28.2, 28.2, 1.75, 0.0022, gt, (28.2 / 1.75) ^ 2 * gt, 125#
        Set materials(side) = New CCoupledReinforcedResponse
        materials(side).Initialize operators, concrete(side), steel
    Next side
    solver.Initialize operators, materials(0), KaniEcTest, materials(1), materials(-1)
    Dim projectionX() As Double, projection() As Double
    operators.MeanShearProjections projectionX, projection

    trace = FreeFile: Open ThisWorkbook.Path & "\KaniV4Trace.csv" For Output As #trace
    stations = FreeFile: Open ThisWorkbook.Path & "\KaniV4Stations.csv" For Output As #stations
    tangents = FreeFile: Open ThisWorkbook.Path & "\KaniV4Tangents.csv" For Output As #tangents
    Dim rootPath As String: rootPath = Left$(historyPath, InStrRev(historyPath, "\"))
    Dim entries As New Collection, historyFactors(38 To 43) As Double
    ReadKaniGaugeInputTest rootPath & "KaniGaugeInput.csv", entries, history, historyFactors
    If solver.PhysicalDegreeCount <> KaniPhysicalTest Then Err.Raise 5, , "Не совпадает число механических координат."
    Dim names As Variant
    names = Array("Accepted19of512", "NearOriginal", "NearHalf", "NearFull")
    Dim actual(1 To 6) As Double, offset(1 To 6) As Double, direction(1 To 6) As Double
    direction(6) = KaniForceTest
    Dim index As Long, inputRow As Variant, values() As Double, field() As Double, expected() As Double, original() As Double
    Dim accepted() As Double, trialField() As Double, resultants() As Double, trialInput As Variant
    Dim rawNorm As Double, tau As Double, returned As Double, gammaAccepted As Double, lambdaAccepted As Double
    Dim diagnostic As String, admitted As Boolean, exact As Boolean
    WriteKaniChartVectorTest trace, "PROJECTION;Mean", projection
    If Not solver.ReplayAcceptedFields(history, 43) Then Err.Raise 5, , "Не восстановлена исходная история 43."
    original = history(43)
    RequireKaniStage38FieldTest solver, original
    rawNorm = SnapshotKaniStage38Test("Original43", operators, solver, materials, projection, original, _
              KaniChartCoordinateTest(projection, original), historyFactors(43), 0#, False, trace, stations, tangents, actual)
    If rawNorm > KaniStage38ToleranceTest(operators, historyFactors(43)) Then Err.Raise 5, , "Изменилось исходное равновесие 43."
    WriteKaniAcceptedDamageTest "Original43", concrete, tangents
    inputRow = entries(1): values = inputRow(1): expected = inputRow(0)
    gammaAccepted = values(0): lambdaAccepted = values(1): trialInput = expected
    tau = KaniStage38ToleranceTest(operators, lambdaAccepted)
    If Not solver.TryTestKaniDeformationStepWithInitial(offset, direction, projection, gammaAccepted, lambdaAccepted, _
            returned, KaniAbsTest, KaniRelTest, 1, trialInput, consistentControl:=True) Then _
            Err.Raise 5, , "Поле 19/512 не принято повторно."
    diagnostic = solver.ResultMeta.DiagnosticDetails
    solver.CopyTrial accepted, resultants
    If Not MechanicsExactFieldTest(accepted, expected, returned, lambdaAccepted, diagnostic) Then _
            Err.Raise 5, , "Изменились координаты принятого поля 19/512."
    For index = -1 To 1
        If materials(index).TrialSteelUtilization > 1# Then Err.Raise 5, , "Превышен предел стали."
    Next index
    solver.AcceptStep
    RequireKaniStage38FieldTest solver, expected
    rawNorm = SnapshotKaniStage38Test("BaseAccepted", operators, solver, materials, projection, accepted, _
              gammaAccepted, lambdaAccepted, 0#, False, trace, stations, tangents, actual)
    If rawNorm > tau Then Err.Raise 5, , "После принятия изменилось равновесие 19/512."
    WriteKaniAcceptedDamageTest "BaseAccepted", concrete, tangents
    WriteKaniTrialYieldTest "BaseAccepted", operators, concrete, accepted, tangents
    RunKaniApexActionsTest rootPath & "ApexSectionFields.csv", operators, solver, materials, _
        concrete, projection, lambdaAccepted, trace, stations, tangents
    For index = 2 To entries.Count
        inputRow = entries(index): values = inputRow(1): field = inputRow(0)
        label = CStr(names(index - 1))
        rawNorm = SnapshotKaniStage38Test(label, operators, solver, materials, projection, field, _
                  values(0), values(1), 0#, False, trace, stations, tangents, actual)
        WriteKaniTrialYieldTest label, operators, concrete, field, tangents
        admitted = False: exact = False
        If index = 4 And rawNorm <= KaniStage38ToleranceTest(operators, values(1)) Then
            trialInput = field
            admitted = solver.TryTestKaniDeformationStepWithInitial(offset, direction, projection, values(0), values(1), _
                       returned, KaniAbsTest, KaniRelTest, 1, trialInput, consistentControl:=True)
            If admitted Then
                solver.CopyTrial trialField, resultants
                exact = MechanicsExactFieldTest(trialField, field, returned, values(1), solver.ResultMeta.DiagnosticDetails)
                rawNorm = SnapshotKaniStage38Test(label & "/Admitted", operators, solver, materials, projection, trialField, _
                          values(0), returned, 0#, False, trace, stations, tangents, actual)
            End If
            solver.DiscardStep
        End If
        Print #trace, "OUTCOME;" & label & ";" & CStr(Abs(CLng(admitted))) & ";" & CStr(Abs(CLng(exact)))
        RequireKaniStage38FieldTest solver, expected
    Next index
    rawNorm = SnapshotKaniStage38Test("EndAccepted", operators, solver, materials, projection, accepted, _
              gammaAccepted, lambdaAccepted, 0#, False, trace, stations, tangents, actual)
    If rawNorm > tau Then Err.Raise 5, , "Материальная проба изменила принятое состояние."
    WriteKaniAcceptedDamageTest "EndAccepted", concrete, tangents
    WriteKaniTrialYieldTest "EndAccepted", operators, concrete, accepted, tangents
    If Not solver.ReplayAcceptedFields(history, 43) Then Err.Raise 5, , "Не восстановлена история 43 после проб."
    RequireKaniStage38FieldTest solver, original
    rawNorm = SnapshotKaniStage38Test("Restore43", operators, solver, materials, projection, original, _
              KaniChartCoordinateTest(projection, original), historyFactors(43), 0#, False, trace, stations, tangents, actual)
    If rawNorm > KaniStage38ToleranceTest(operators, historyFactors(43)) Then Err.Raise 5, , "Откат нарушил равновесие 43."
    WriteKaniAcceptedDamageTest "Restore43", concrete, tangents
    Close #tangents: tangents = 0
    Close #stations: stations = 0
    Close #trace: trace = 0
    RunTestKaniStage38 = "TOTAL_KANI_V4_STAGE38: passed=1; failed=0"
    Exit Function
Failed:
    status = Err.Source & " " & Err.Description
    On Error Resume Next
    If tangents > 0 Then Close #tangents
    If stations > 0 Then Close #stations
    If trace > 0 Then Close #trace
    RunTestKaniStage38 = "RUNTIME ERROR: " & status
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает последовательность исходных полей с точными контрольными деформациями.
Private Sub ReadKaniStage38InputTest(ByVal path As String, ByVal history As Collection, ByRef gamma() As Double, _
        ByRef factors() As Double, ByRef target As Double)
    Dim file As Integer, line As String, parts() As String, index As Long, i As Long
    Dim errorNumber As Long, errorText As String
    On Error GoTo Failed
    ReDim gamma(1 To 37): ReDim factors(1 To 37)
    file = FreeFile: Open path For Input As #file
    Line Input #file, line
    parts = Split(line, ";")
    If UBound(parts) <> 2 Or parts(0) <> "KANI_V4" Or parts(1) <> "37" Then Err.Raise 5, , "Неверная шапка истории Kani."
    target = Val(parts(2))
    For index = 1 To 37
        Line Input #file, line
        parts = Split(line, ";")
        If UBound(parts) <> KaniSizeTest + 3 Or parts(0) <> "FIELD" Or CLng(parts(1)) <> index Then _
            Err.Raise 5, , "Неверный порядок полей Kani."
        gamma(index) = Val(parts(2)): factors(index) = Val(parts(3))
        If gamma(index) <= 0# Or factors(index) <= 0# Then Err.Raise 5, , "Неверная контрольная нагрузка Kani."
        If index > 1 Then
            If gamma(index) <= gamma(index - 1) Then Err.Raise 5, , "Сдвиг Kani перестал возрастать."
        End If
        Dim field() As Double, item As Variant
        ReDim field(1 To KaniSizeTest)
        For i = 1 To KaniSizeTest: field(i) = Val(parts(i + 3)): Next i
        item = field
        history.Add item
    Next index
    If Not EOF(file) Or target <= gamma(37) Then Err.Raise 5, , "Неполный маршрут Kani."
    Close #file
    Exit Sub
Failed:
    errorNumber = Err.Number: errorText = Err.Description
    If file > 0 Then Close #file
    Err.Raise errorNumber, "ReadKaniStage38InputTest", errorText
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет, что исходное принятое поле сохранилось после повтора или сброса.
Private Sub RequireKaniStage38FieldTest(ByVal solver As CCoupledNewtonSolver, ByRef expected() As Double)
    Dim actual() As Double, i As Long
    solver.CopyAccepted actual
    For i = 1 To KaniSizeTest
        If actual(i) <> expected(i) Then Err.Raise 5, , "Принятое поле Kani изменилось."
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет слабые уравнения и интегралы. Для сопряжённой сверки сохраняет штатную диагностическую матрицу до принятия.
Private Function SnapshotKaniStage38Test(ByVal label As String, ByVal operators As CCoupledElasticState, _
        ByVal solver As CCoupledNewtonSolver, ByRef materials() As CCoupledReinforcedResponse, _
        ByRef projection() As Double, ByRef field() As Double, ByVal target As Double, ByVal lambda As Double, _
        ByVal bound As Double, ByVal bounded As Boolean, ByVal trace As Integer, ByVal stations As Integer, _
        ByVal tangents As Integer, ByRef forces() As Double, Optional ByRef equations As Variant) As Double
    Dim residual() As Double, matrix() As Double, applied() As Double, expected(1 To 6) As Double
    Dim recordMatrix As Boolean: recordMatrix = Right$(label, 6) = "/Trial"
    If Not solver.TestEquilibriumLinearization(field, recordMatrix, False, residual, matrix) Then _
        Err.Raise 5, , "Не вычислено повторное равновесие " & label
    If recordMatrix Then WriteKaniStage38MatrixTest label, matrix, projection, operators, tangents

    Dim material As ICoupledPointResponse, strain(1 To 6) As Double, gradient(1 To 6) As Double, stationStrain(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double, row As String
    Dim plasticIncrement As Boolean, principalSign As Long, substeps As Long
    For i = 1 To 6: forces(i) = 0#: Next i
    For point = 1 To KaniPointsTest
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, gradient
        For side = -1 To 1
            Set material = materials(side)
            For i = 1 To 6: stationStrain(i) = strain(i) + CDbl(side) * 0.001 * gradient(i): Next i
            If material.EvaluatePoint(point, stationStrain, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Недоступна материальная точка Kani " & CStr(point)
            row = "K59C_STATION;" & label & ";" & CStr(point) & ";" & CStr(side)
            For i = 1 To 6: row = row & ";" & Str$(stationStrain(i)): Next i
            For i = 1 To 6: row = row & ";" & Str$(stress(i)): Next i
            Print #stations, row
            If Not materials(side).TryReadConcreteBranch(point, stationStrain, plasticIncrement, principalSign, substeps) Then _
                Err.Raise 5, , "Не определена ветвь бетона в материальной станции " & CStr(point)
            Print #tangents, "BRANCH;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                             CStr(Abs(CLng(plasticIncrement))) & ";" & CStr(principalSign) & ";" & CStr(substeps)
            If side = 0 Then
                forces(1) = forces(1) + area * stress(3)
                forces(2) = forces(2) + area * y * stress(3)
                forces(3) = forces(3) + area * x * stress(3)
                forces(4) = forces(4) + area * (x * stress(6) - y * stress(5))
                forces(5) = forces(5) + area * stress(5)
                forces(6) = forces(6) + area * stress(6)
            End If
        Next side
    Next point
    expected(6) = KaniForceTest * lambda
    operators.LoadEquations 0#, 0#, 0#, 0#, 0#, expected(6), applied
    Dim control As Double, tolerance As Double, norm As Double, gauges As Boolean, value As Double
    tolerance = KaniStage38ToleranceTest(operators, lambda)
    norm = operators.ResultantResidualNorm(forces, expected): gauges = True
    control = -target
    For i = 1 To KaniSizeTest
        residual(i) = residual(i) - applied(i)
        value = Abs(residual(i))
        If i <= KaniPhysicalTest Then
            control = control + projection(i) * field(i)
            If value > norm Then norm = value
        ElseIf value > tolerance / KaniEcTest Then
            gauges = False
        End If
    Next i
    control = control * KaniEcTest
    If Abs(control) > norm Then norm = Abs(control)
    If Not gauges Then Err.Raise 5, , "Нарушены кинематические связи " & label

    row = "K59C_STATE;" & label & ";" & Str$(target) & ";" & Str$(lambda) & ";" & Str$(norm) & _
        ";" & Str$(tolerance) & ";" & Str$(control) & ";" & CStr(Abs(CLng(gauges)))
    For i = 1 To 6: row = row & ";" & Str$(forces(i)): Next i
    For i = 1 To KaniSizeTest: row = row & ";" & Str$(residual(i)): Next i
    Print #trace, row
    row = "K59C_VECTOR;" & label & ";" & Str$(lambda) & ";" & Str$(target)
    For i = 1 To KaniSizeTest: row = row & ";" & Str$(field(i)): Next i
    Print #trace, row
    Dim center As CCoupledReinforcedResponse, hoop As Long, hoopStress As Double
    Set center = materials(0): hoop = center.AcceptedTransverseCriticalPoint
    If hoop > 0 Then hoopStress = center.AcceptedSteelStress(hoop)
    Print #trace, "CHECK;" & label & ";" & CStr(Abs(CLng(bounded))) & ";" & Str$(bound) & ";" & _
        Str$(hoopStress) & ";" & Str$(center.AcceptedSteelUtilization)
    If Not IsMissing(equations) Then equations = residual
    SnapshotKaniStage38Test = norm
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Добавляет к касательной столбец нагрузки и строку среднего сдвига.
Private Sub WriteKaniStage38MatrixTest(ByVal label As String, ByRef matrix() As Double, _
        ByRef projection() As Double, ByVal operators As CCoupledElasticState, ByVal file As Integer)
    Dim direction() As Double: operators.LoadEquations 0#, 0#, 0#, 0#, 0#, KaniForceTest, direction
    Dim row As String, i As Long, j As Long, rowScale As Double
    For i = 1 To KaniSizeTest
        rowScale = 1#
        If i > KaniPhysicalTest Then rowScale = KaniEcTest
        row = "MATRIX;" & label & ";" & CStr(i)
        For j = 1 To KaniSizeTest: row = row & ";" & Str$(rowScale * matrix(j, i)): Next j
        Print #file, row & ";" & Str$(-rowScale * direction(i))
    Next i
    row = "MATRIX;" & label & ";" & CStr(KaniSizeTest + 1)
    For j = 1 To KaniSizeTest: row = row & ";" & Str$(KaniEcTest * projection(j)): Next j
    Print #file, row & ";0"
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вычисляет допуск возле подтверждённой силы для данной квадратуры.
Private Function KaniStage38ToleranceTest(ByVal operators As CCoupledElasticState, ByVal lambda As Double) As Double
    Dim area As Double, lengthScale As Double
    operators.CopyResultantResidualScales area, lengthScale
    KaniStage38ToleranceTest = KaniAbsTest + KaniRelTest * Abs(lambda) * KaniForceTest / area
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит геометрию Kani из исходного контрольного расчёта.
Private Function BuildKaniStage38SectionTest(ByRef layout As CTransverseRebarLayout, ByRef steel As Object) As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("Kani_Outer", Array(Array(-152.5, -305#, 305#, 610#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Dim i As Long, x As Double
    For i = 0 To 3
        x = -105# + 70# * i
        section.AddRebarElement x, -254#, 25#, GEOM_PI * 156.25, "KANI_LONG"
        section.AddRebarElement x, 254#, 25#, GEOM_PI * 156.25, "KANI_LONG"
    Next i
    Set layout = New CTransverseRebarLayout
    layout.AddContourGroup section, "KANI_HOOP", vbNullString, 10#, 100#, 25#, "KANI_HOOP"
    Set steel = CreateObject("Scripting.Dictionary")
    Dim longitudinal As New CCoupledSteelModel, hoop As New CCoupledSteelModel
    longitudinal.Initialize 200000#, 442#, 442#, 0#, 0#, 0.05, 0.05
    hoop.Initialize 200000#, 400#, 400#, 0#, 0#, 0.05, 0.05
    steel.Add "KANI_LONG", longitudinal
    steel.Add "KANI_HOOP", hoop
    Set BuildKaniStage38SectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает четыре заранее заданных абсолютных поля общей поправки minimax.
Private Sub ReadKaniBoundedSeedsTest(ByVal path As String, ByVal seeds As Collection, _
        ByRef fractions() As Double, ByRef factors() As Double)
    Dim file As Integer, line As String, parts() As String, i As Long, j As Long
    Dim field() As Double, item As Variant, errorNumber As Long, errorText As String
    On Error GoTo Failed
    ReDim fractions(1 To 4), factors(1 To 4)
    file = FreeFile: Open path For Input As #file
    Line Input #file, line
    If line <> "KANI_BOUNDED;4;87" Then Err.Raise 5, , "Неверный заголовок набора minimax."
    For i = 1 To 4
        Line Input #file, line
        parts = Split(line, ";")
        If UBound(parts) <> 90 Or parts(0) <> "SEED" Or CLng(parts(1)) <> i Then _
            Err.Raise 5, , "Неверный порядок долей minimax."
        fractions(i) = Val(parts(2)): factors(i) = Val(parts(3))
        If fractions(i) <> 2# ^ (1 - i) Or factors(i) <= 0# Then Err.Raise 5, , "Неверная доля minimax."
        ReDim field(1 To KaniSizeTest)
        For j = 1 To KaniSizeTest: field(j) = Val(parts(j + 3)): Next j
        item = field
        seeds.Add item
    Next i
    If Not EOF(file) Then Err.Raise 5, , "В наборе minimax остались непрочитанные строки."
    Close #file
    Exit Sub
Failed:
    errorNumber = Err.Number: errorText = Err.Description
    If file > 0 Then Close #file
    Err.Raise errorNumber, "ReadKaniBoundedSeedsTest", errorText
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет направление и размер приращения по физическим 83 координатам.
Private Function ForwardKaniBoundedSeedTest(ByRef previous() As Double, ByRef current() As Double, _
        ByRef proposed() As Double, ByVal ratio As Double) As Boolean
    Dim i As Long, a As Double, b As Double, product As Double, previous2 As Double, proposed2 As Double
    For i = 1 To KaniPhysicalTest
        a = current(i) - previous(i): b = proposed(i) - current(i)
        product = product + a * b: previous2 = previous2 + a * a: proposed2 = proposed2 + b * b
    Next i
    ForwardKaniBoundedSeedTest = product > 0# And proposed2 <= 9# * ratio * ratio * previous2
End Function


' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает зафиксированный прогноз, множитель и эквивалентно масштабированную строку.
Private Sub ReadKaniChartInputTest(ByVal path As String, ByRef seed() As Double, ByRef lambda As Double, ByRef control() As Double)
    Dim file As Integer, rowText As String, parts() As String, i As Long
    Dim errorNumber As Long, errorText As String
    On Error GoTo Failed
    ReDim seed(1 To KaniSizeTest): ReDim control(1 To KaniSizeTest)
    file = FreeFile: Open path For Input As #file
    Line Input #file, rowText: parts = Split(rowText, ";")
    If UBound(parts) <> 88 Or parts(0) <> "PREDICTOR" Then Err.Raise 5, , "Неверный паспорт поля."
    lambda = Val(parts(1))
    If lambda <= 0# Then Err.Raise 5, , "Неверный множитель предиктора."
    For i = 1 To KaniSizeTest: seed(i) = Val(parts(i + 1)): Next i
    Line Input #file, rowText: parts = Split(rowText, ";")
    If UBound(parts) <> 87 Or parts(0) <> "PROJECTION" Then Err.Raise 5, , "Неверный паспорт проекции."
    For i = 1 To KaniSizeTest
        control(i) = Val(parts(i))
        If i > KaniPhysicalTest And control(i) <> 0# Then Err.Raise 5, , "Проекция затрагивает множитель связей."
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Остались непрочитанные строки."
    Close #file
    Exit Sub
Failed:
    errorNumber = Err.Number: errorText = Err.Description
    If file > 0 Then Close #file
    Err.Raise errorNumber, "ReadKaniChartInputTest", errorText
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает выбранную линейную координату по физическим компонентам поля.
Private Function KaniChartCoordinateTest(ByRef control() As Double, ByRef field() As Double) As Double
    Dim i As Long
    For i = 1 To KaniPhysicalTest: KaniChartCoordinateTest = KaniChartCoordinateTest + control(i) * field(i): Next i
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет фактический переданный вектор в инвариантной записи.
Private Sub WriteKaniChartVectorTest(ByVal file As Integer, ByVal label As String, ByRef values() As Double)
    Dim i As Long, rowText As String: rowText = label
    For i = LBound(values) To UBound(values): rowText = rowText & ";" & Str$(values(i)): Next i
    Print #file, rowText
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет фазу от одинакового прогноза без фиксации материала до общей сверки.
Private Function TryKaniChartTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledReinforcedResponse, ByRef control() As Double, ByRef prior() As Double, ByRef base() As Double, _
        ByRef seed() As Double, ByVal lambda As Double, ByVal requested As Double, ByVal referenceLambda As Double, ByVal label As String, _
        ByRef candidate() As Double, ByRef actualLambda As Double, ByVal trace As Integer, ByVal stations As Integer, _
        ByVal tangents As Integer) As Boolean
    Dim direction(1 To 6) As Double, offset(1 To 6) As Double, initial As Variant
    direction(6) = KaniForceTest
    initial = seed
    Dim succeeded As Boolean, forward As Boolean, trialForces() As Double, rebuild(1 To 6) As Double, j As Long, norm As Double
    actualLambda = 0#
    succeeded = solver.TryTestKaniDeformationStepWithInitial(offset, direction, control, requested, lambda, actualLambda, _
        KaniAbsTest, KaniRelTest, 24, initial, consistentControl:=True)
    Print #trace, "ATTEMPT;" & label & ";" & Str$(requested) & ";" & Str$(lambda) & ";" & CStr(Abs(CLng(succeeded))) & ";" & _
        CStr(solver.ResultMeta.ResultCode)
    Print #trace, "DETAIL;" & label & ";" & Replace(Replace(solver.ResultMeta.DiagnosticDetails, vbCr, " "), vbLf, " ")
    RequireKaniStage38FieldTest solver, base
    If Not succeeded Then Exit Function
    solver.CopyTrial candidate, trialForces
    forward = actualLambda > 0# And ForwardKaniBoundedSeedTest(prior, base, candidate, 0.5)
    For j = -1 To 1
        If materials(j).TrialSteelUtilization > 1# Then forward = False
    Next j
    norm = SnapshotKaniStage38Test(label & "/Trial", operators, solver, materials, control, candidate, requested, _
        actualLambda, 0#, False, trace, stations, tangents, rebuild)
    Dim admitted As Boolean
    admitted = forward And norm <= KaniStage38ToleranceTest(operators, referenceLambda) And _
        operators.ResultantResidualNorm(rebuild, trialForces) < 0.0000000001
    Print #trace, "ADMISSION;" & label & ";" & Str$(actualLambda) & ";" & Str$(norm) & ";" & _
        CStr(Abs(CLng(forward))) & ";" & CStr(Abs(CLng(admitted)))
    TryKaniChartTest = admitted
End Function


' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает локальные испытываемые поля, множители и точное новое состояние истории.
Private Sub ReadKaniGaugeInputTest(ByVal path As String, ByVal entries As Collection, _
        ByVal history As Collection, ByRef historyFactors() As Double)
    Dim number As Integer: number = FreeFile
    Dim rowText As String, terms As Variant, i As Long
    Dim field() As Double, levels() As Double, state As Long, entry As Variant
    Open path For Input As #number
    Do Until EOF(number)
        Line Input #number, rowText
        terms = Split(rowText, ";")
        If UBound(terms) <> 91 Or terms(0) <> "KANI_B_FIELD" Then
            Close #number
            Err.Raise 5, , "Некорректная строка входа испытания."
        End If
        ReDim field(1 To KaniSizeTest)
        ReDim levels(0 To 1)
        levels(0) = Val(terms(3)): levels(1) = Val(terms(91))
        For i = 1 To KaniSizeTest
            field(i) = Val(terms(i + 3))
        Next i
        If Left$(terms(1), 7) = "History" Then
            state = CLng(Mid$(terms(1), 8))
            If state <> history.Count + 1 Then Err.Raise 5, , "Нарушен порядок принятых состояний."
            entry = field: history.Add entry: historyFactors(state) = levels(1)
        Else
            entries.Add Array(field, levels)
        End If
    Loop
    Close #number
    If entries.Count <> 4 Or history.Count <> 43 Then Err.Raise 5, , "Не совпадает число контрольных полей."
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подтверждает совпадение всех заданных координат и множителя после допуска без итераций.
Private Function MechanicsExactFieldTest(ByRef trial() As Double, ByRef field() As Double, ByVal trialLambda As Double, _
        ByVal suppliedLambda As Double, ByVal diagnostic As String) As Boolean
    Dim index As Long
    If trialLambda <> suppliedLambda Or InStr(1, diagnostic, "Итерации: 0;", vbBinaryCompare) <> 1 Then Exit Function
    For index = 1 To KaniSizeTest
        If trial(index) <> field(index) Then Exit Function
    Next index
    MechanicsExactFieldTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает две нормированные энергии принятой точки, включая бетон, вытесненный сталью.
Private Sub WriteKaniAcceptedDamageTest(ByVal label As String, ByRef concrete() As CCoupledConcreteResponse, ByVal file As Integer)
    Dim point As Long, side As Long, tensionEnergy As Double, compressionEnergy As Double
    For side = -1 To 1
        For point = 1 To KaniPointsTest
            concrete(side).AcceptedPointDamage point, tensionEnergy, compressionEnergy
            Print #file, "ENERGY;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                         Str$(tensionEnergy) & ";" & Str$(compressionEnergy)
        Next point
    Next side
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает критерий по упругому предиктору от той же принятой истории, без вычисления градиента.
Private Sub WriteKaniTrialYieldTest(ByVal label As String, ByVal operators As CCoupledElasticState, _
        ByRef concrete() As CCoupledConcreteResponse, ByRef field() As Double, ByVal file As Integer)
    Dim point As Long, side As Long, i As Long, yieldValue As Double, unused() As Double
    Dim strain(1 To 6) As Double, gradient(1 To 6) As Double, localStrain(1 To 6) As Double
    For point = 1 To KaniPointsTest
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, gradient
        For side = -1 To 1
            For i = 1 To 6: localStrain(i) = strain(i) + CDbl(side) * 0.001 * gradient(i): Next i
            If Not concrete(side).TryReadTrialYield(point, localStrain, yieldValue, unused, needGradient:=False) Then _
                Err.Raise 5, , "Не записан критерий упругого предиктора " & CStr(point)
            Print #file, "YIELD;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & Str$(yieldValue)
        Next side
    Next point
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сопоставляет действие по конечной секущей на одинаковой принятой истории.
' Нагрузка одинакова на обеих сторонах каждой пробы, поэтому действие
' внешнего столбца сокращается. Принятое поле не публикуется.
Private Sub RunKaniApexActionsTest(ByVal fixture As String, ByVal operators As CCoupledElasticState, _
        ByVal solver As CCoupledNewtonSolver, ByRef materials() As CCoupledReinforcedResponse, _
        ByRef concrete() As CCoupledConcreteResponse, ByRef projection() As Double, _
        ByVal lambda As Double, ByVal trace As Integer, ByVal stations As Integer, ByVal tangents As Integer)
    Dim file As Integer: file = FreeFile
    Open fixture For Input As #file
    Dim line As String, parts() As String, label As String, probeFraction As Double, i As Long, count As Long
    Dim field(1 To KaniSizeTest) As Double, direction(1 To KaniSizeTest) As Double, trial(1 To KaniSizeTest) As Double
    Dim stock() As Double, hybrid() As Double, stockEfforts() As Double, hybridEfforts() As Double
    Dim efforts(1 To 6) As Double, norm As Double, changed As Long
    Do While Not EOF(file)
        Line Input #file, line
        parts = Split(line, ";")
        If UBound(parts) <> 2 * KaniSizeTest + 1 Then
            Close #file
            Err.Raise 5, , "Неверная длина входного поля направленной пробы."
        End If
        label = parts(0): probeFraction = Val(parts(1))
        For i = 1 To KaniSizeTest
            field(i) = Val(parts(i + 1)): direction(i) = Val(parts(KaniSizeTest + i + 1))
            trial(i) = field(i) + probeFraction * direction(i)
        Next i
        Dim mode As ECoupledTangentMode: mode = ctmFullBranchConsistent
        If Not TryAssembleApexActionsTest(operators, materials(0), materials(1), materials(-1), _
                concrete(0), concrete(1), concrete(-1), field, direction, mode, _
                stock, hybrid, stockEfforts, hybridEfforts, changed) Then
            mode = ctmFull ' Как в штатном решателе, обе сборки переходят к обычной матрице.
            If Not TryAssembleApexActionsTest(operators, materials(0), materials(1), materials(-1), _
                    concrete(0), concrete(1), concrete(-1), field, direction, mode, _
                    stock, hybrid, stockEfforts, hybridEfforts, changed) Then
                Close #file
                Err.Raise 5, , "Обе штатные касательные недоступны в секционной пробе " & label
            End If
        End If
        If changed <= 0 Then
            Close #file
            Err.Raise 5, , "Условия направленной производной не выполнены ни на одной станции " & label
        End If
        Print #trace, "ACTION;" & label & ";" & CStr(changed) & ";" & Str$(probeFraction) & ";" & CStr(mode)
        WriteKaniChartVectorTest trace, "APEX_VECTOR;" & label & "/Stock", stock
        WriteKaniChartVectorTest trace, "APEX_VECTOR;" & label & "/Hybrid", hybrid
        WriteKaniChartVectorTest trace, "APEX_VECTOR;" & label & "/StockEfforts", stockEfforts
        WriteKaniChartVectorTest trace, "APEX_VECTOR;" & label & "/HybridEfforts", hybridEfforts
        norm = SnapshotKaniStage38Test(label & "/Plus", operators, solver, materials, projection, trial, _
            KaniChartCoordinateTest(projection, trial), lambda, 0#, False, trace, stations, tangents, efforts)
        For i = 1 To KaniSizeTest: trial(i) = field(i) - probeFraction * direction(i): Next i
        norm = SnapshotKaniStage38Test(label & "/Minus", operators, solver, materials, projection, trial, _
            KaniChartCoordinateTest(projection, trial), lambda, 0#, False, trace, stations, tangents, efforts)
        count = count + 1
    Loop
    Close #file
    If count <> 3 Then Err.Raise 5, , "Не прочитаны три контрольных направления."
End Sub
