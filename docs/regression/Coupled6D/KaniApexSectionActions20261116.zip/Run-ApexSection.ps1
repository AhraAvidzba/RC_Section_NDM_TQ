﻿# Изолированная проверка связанных строк Kani при приращении 0,10 Н.
param([switch]$CompiledOnly)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$env:TEMP = Join-Path $PSScriptRoot 'Temp'
$env:TMP = $env:TEMP
$privateFixture = Join-Path $env:TEMP ('RC_NDM_ModeSuite_' + ('0' * 32) + '\RC_Section_NDM.xlsm')
if (!$PSScriptRoot.StartsWith('D:\',[StringComparison]::OrdinalIgnoreCase) -or $privateFixture.Length -gt 210) {
    throw 'Книга проверки должна находиться на диске D по короткому физическому пути.'
}
& python -B -X utf8 "$PSScriptRoot/Prepare-ApexSection.py" --check
if ($LASTEXITCODE) { throw 'История Kani V4 не прошла проверку.' }
$receipt = Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
$book = 'docs/regression/Diagnostic.xlsm'
$source = 'workbook/output/RC_Section_NDM.xlsm'
$report = 'Native/KaniV4.txt'
$legacy = Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$compiler = 'tools/build_workbook/Update-IsolatedOptimizerCode.ps1'
$compilerSha = 'D4CA349FF9859F76DD0FFF867C984C02EB5F8F715AADC2223635507502B365B9'
if ((Get-FileHash -LiteralPath $compiler).Hash -cne $compilerSha) { throw 'Изменился проверенный защищённый компилятор.' }
if (Test-Path -LiteralPath $report) { throw 'Протокол уже существует. Для нового запуска нужна отдельная копия.' }

# Защищает существующие экземпляры пользователей по идентичности процесса.
$protected = @{25900=[long]639301894503450644;32172=[long]639304180394977771}
function Assert-Stage38Reserve([string]$stage) {
    $excel = @(Get-Process Excel -ErrorAction SilentlyContinue)
    foreach ($p in $excel) {
        $ticks = $p.StartTime.ToUniversalTime().Ticks
        if ($protected.ContainsKey($p.Id) -and $protected[$p.Id] -eq $ticks) { continue }
        $proc = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $p.Id)
        if (!$proc -or !$p.MainWindowHandle -or [math]::Abs(($proc.CreationDate - $p.StartTime).TotalMilliseconds) -ge 100) { continue }
        $parent = Get-Process -Id $proc.ParentProcessId -ErrorAction SilentlyContinue
        if ($parent -and $parent.ProcessName -ieq 'explorer' -and $p.SessionId -eq $parent.SessionId -and
            $parent.StartTime -lt $p.StartTime -and $proc.CommandLine -notmatch '[/\-]embedding(?:\s|$)') {
            $protected[$p.Id] = $ticks
        }
    }
    $other = @($excel | Where-Object { !$protected.ContainsKey($_.Id) -or $protected[$_.Id] -ne $_.StartTime.ToUniversalTime().Ticks })
    $memory = Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
    $sample = [ordered]@{
        Stage=$stage;Utc=[DateTimeOffset]::UtcNow.ToString('o')
        AvailableMiB=$memory.AvailableMBytes;FreeCommitGiB=($memory.CommitLimit-$memory.CommittedBytes)/1GB
        CFreeMiB=(Get-PSDrive C).Free/1MB;DFreeGiB=(Get-PSDrive D).Free/1GB
        Excel=@($excel | Select-Object Id,StartTime,MainWindowTitle)
    }
    $sample | ConvertTo-Json -Depth 4 -Compress | Add-Content -LiteralPath 'Native/Preflight.ndjson' -Encoding utf8
    if ($other.Count -or $sample.AvailableMiB -lt 6500 -or $sample.FreeCommitGiB -lt 8 -or
        $sample.CFreeMiB -lt 80 -or $sample.DFreeGiB -lt 4) {
        throw "Для Kani V4 нет свободного изолированного окна или ресурса $stage."
    }
}

if (!$CompiledOnly) {
    Assert-Stage38Reserve 'PreCompile'
    if (Test-Path -LiteralPath 'docs/regression/CodeUpdate.json') { throw 'Компиляция уже зафиксирована.' }
    if ((Get-FileHash -LiteralPath $book).Hash -cne $receipt.workbook_sha256) { throw 'Изменилась начальная копия книги V4.' }
    & ".\$compiler" -WorkbookPath $book -ModuleNames @('CCoupledConcreteResponse', 'CCoupledElasticState', 'CCoupledNewtonSolver', 'modTestCoupledApexActions', 'modTestKaniStage38') |
        Tee-Object -FilePath 'Native/Compile.log'
    $compileOwner = @(Get-Content -LiteralPath 'Native/Compile.log' | Where-Object {$_ -match '^OWNED_EXCEL: id=[0-9]+; utcStartTicks=[0-9]+$'})
    if ($compileOwner.Count -ne 1 -or $compileOwner[0] -notmatch '^OWNED_EXCEL: id=([0-9]+); utcStartTicks=([0-9]+)$') {
        throw 'Нет подтверждённой идентичности экземпляра компиляции.'
    }
    $ownerId = [int]$Matches[1]
    $ownerStart = [long]$Matches[2]
    $owner = Get-Process -Id $ownerId -ErrorAction SilentlyContinue
    if ($owner -and $owner.StartTime.ToUniversalTime().Ticks -eq $ownerStart) { throw 'Экземпляр компиляции ещё работает.' }
    [ordered]@{State='Absent';PID=$ownerId;StartTicksUTC=$ownerStart} |
        ConvertTo-Json | Set-Content -LiteralPath 'Native/CompileClosure.json' -Encoding utf8
}
$compiled = Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
$closed = Get-Content -LiteralPath 'Native/CompileClosure.json' -Raw | ConvertFrom-Json
if (!$compiled.Compiled -or $compiled.ProductionChanged -or $closed.State -ne 'Absent' -or
    $compiled.ProductionSHA256 -cne $receipt.workbook_sha256 -or $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $book).Hash -or
    (($compiled.Modules | Sort-Object) -join ',') -cne 'CCoupledConcreteResponse,CCoupledElasticState,CCoupledNewtonSolver,modTestCoupledApexActions,modTestKaniStage38') {
    throw 'Частная сборка не содержит ожидаемый тестовый модуль.'
}

Assert-Stage38Reserve 'PreNative'
$arguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-Audit03Watchdog.ps1',
    '-SourceWorkbook',$book,'-ReportPath',$report,'-Macro','modTestKaniStage38.RunTestKaniStage38',
    '-MacroArgument1',(Join-Path $PSScriptRoot 'KaniV4Input.csv'),'-TimeoutSeconds',95,'-FailFast')
& $legacy @arguments
$exitCode = $LASTEXITCODE
$fixtureLine = @(Get-Content -LiteralPath $report | Where-Object {$_ -like 'FIXTURE: *'})
if ($fixtureLine.Count -eq 1) {
    $directory = [IO.Path]::GetFullPath((Split-Path -Parent $fixtureLine[0].Substring(9)))
    if (!$directory.StartsWith($env:TEMP + '\RC_NDM_ModeSuite_',[StringComparison]::OrdinalIgnoreCase)) {
        throw 'Путь записей проверки вышел из каталога частной книги.'
    }
    foreach ($csv in @('KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv')) {
        $path = Join-Path $directory $csv
        if (Test-Path -LiteralPath $path) { Copy-Item -LiteralPath $path -Destination (Join-Path 'Native' $csv) }
    }
}
if ($exitCode) { throw "Нативный запуск прервался с кодом $exitCode." }
if ((Get-FileHash -LiteralPath $source).Hash -cne $receipt.workbook_sha256) { throw 'Изменилась замороженная книга V4.' }
& python -B -X utf8 "$PSScriptRoot/Verify-ApexSection.py"
if ($LASTEXITCODE) { throw 'Сверка уточнённого поля Kani не пройдена.' }
