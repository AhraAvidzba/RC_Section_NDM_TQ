"""Up to three fresh active-cell corrections following the verified transverse step."""
from math import fsum
from pathlib import Path
from time import perf_counter
import gzip
import importlib.util
import json
import runpy
import sys

sys.dont_write_bytecode = True
HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('cone',HERE/'Probe-Cone.py')
cone=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(cone)
PRIOR='0CCEB19B987215830011170A744DEDD45AD63024CCEDDD27ECFBAFA913750793'
NEXT_Q=55312.5


def independent(section,watch,raw,x,load):
    op={'S':section.original_S,'R':section.original_R,'G':section.G,'L':section.L}
    def force(center,geo):
        terms=[(w*s[2], y*w*s[2], x*w*s[2],w*(x*s[5]-y*s[4]),w*s[4],w*s[5])
               for s,(x,y,w) in zip(center,geo,strict=True)]
        return [fsum(a) for a in zip(*terms,strict=True)]
    return watch['check_whole'](raw,x,load,op,section.geo,section.area,section.length,force)


def steel_wire(np,section):
    return np.stack(section.next_steel,axis=-1).tolist()


def next_nominal(np,probe,section,watch,x,last,old):
    fixture=runpy.run_path(str(cone.PRIOR/'Postyield.py'))
    program=runpy.run_path(str(fixture['SRC']/'Reequilibrate.py'))
    stock=program['try_correct']
    stock.__globals__['loads']=lambda arrays,t,q:arrays.array((0.,-600.*q,0.,t,0.,q))
    target=stock.__globals__['loads'](np,10510000.,NEXT_Q)
    expected=section.committed
    seed=x+(x-last)
    equation,commit=section.equations,section.commit
    latest=[]; output={'Qy_N':NEXT_Q,'initial_field':seed.tolist(),'target':target.tolist()}

    def capture(field,load,matrix=False):
        result=equation(field,load,matrix)
        latest[:]=[field.copy(),load.copy(),result]
        return result

    def confirm():
        field,load,r=latest
        assert np.array_equal(load,target)
        frame=probe.raw_section(section,field,load)
        value=independent(section,watch,frame,field,load)
        assert value<=r[5] and np.array_equal(frame['net_stresses_MPa'],r[2])
        output.update({'independent_norm_MPa':value,'final_field':field.tolist(),
                       'accepted_section':frame,'accepted_steel':steel_wire(np,section)})
        commit()

    section.equations=capture; section.commit=confirm
    try:
        accepted,status=stock(section,seed,10510000.,NEXT_Q)
    finally:
        section.equations=equation; section.commit=commit
    output['stock_status']=status
    assert section.committed==expected+(1 if accepted is not None else 0)
    if accepted is None:
        # Probe the exact already committed state, then revisit it to show the
        # failed next target left the accepted field's material trial unchanged.
        first=probe.raw_section(section,x,old)
        assert probe.raw_section(section,x,old)==first
        output['committed_anchor_recheck']=first
    return output


def main():
    started=perf_counter()
    old_wire=(HERE/'ConeWire.json.gz').read_bytes()
    assert cone.digest(old_wire)==PRIOR
    state=json.loads(gzip.decompress(old_wire))
    assert len(state['actual_trials'])==1 and state['selected_factor']==1.
    prior=state['actual_trials'][0]
    probe=cone.load_pinned('station_probe',cone.PRIOR/'station/Probe-Stations.py',cone.STATION_SRC)
    vector,receipt=probe.exact_reference()
    np,ops,section,material,identity,load,_=probe.exact_replay(vector,receipt)
    watch=runpy.run_path(str(cone.PRIOR/'station/Verify-Stations.py'))
    assert identity==state['operator_source'] and material==state['material'] and load.tolist()==state['target']
    threshold=state['tensile_threshold']
    x=np.array(state['field'])+np.array(state['plan']['delta_field'])
    x0=x.copy()
    last=np.array(state['last_accepted_field'])
    original=np.array(state['first_rejected_trial'])
    radius=float(np.max(np.abs(section.strain@(np.array(state['original_predictor'])-last))))
    frame=probe.raw_section(section,x,load)
    assert frame==prior['section'] and section.committed==53
    first=cone.witness(np,section,x,load,vector,threshold)
    assert first[1].tolist()==prior['all66'] and first[3].tolist()==prior['indicators']
    steel0=first[2].copy(); sign0=np.sign(first[3])
    assert independent(section,watch,frame,x,load)>frame['tolerance_MPa']
    physical=np.max(np.abs(section.strain),axis=(0,1,2))
    output={'prefix_wire_sha256':PRIOR,'initial_exact_field':x.tolist(),'initial_exact_section':frame,
            'target':load.tolist(),'original_radius':radius,'same_frozen_H53_before_relinearization':True,
            'iterations':[],'initial_history_count':section.committed}
    committed=False
    for number in range(1,4):
        initial=cone.witness(np,section,x,load,vector,threshold)
        J,K,columns=cone.sample_columns(np,section,x,load,initial,vector,threshold,physical)
        step={'number':number,'initial_indicators':initial[3].tolist(),
              'initial_all66':initial[1].tolist(),'finite_difference':columns,'trials':[],
              'initial_field':x.tolist()}
        output['iterations'].append(step)
        if J is None:
            break
        delta,plan=cone.proposed_step(np,section,x,initial,J,K,state['nearest_previous_stock_event_global_strain'],physical)
        step['plan']=plan
        if delta is None or plan['predicted_norm_MPa']>=initial[0][4]:
            break
        for factor in (1.,.5,.25,.125,.0625):
            y=x+factor*delta
            evaluated,rr,steel,ind=cone.witness(np,section,y,load,vector,threshold)
            same=np.array_equal(np.sign(ind),sign0) and np.array_equal(steel,steel0)
            movement=float(np.max(np.abs(section.strain@(y-x))))
            accumulated=float(np.max(np.abs(section.strain@(y-original))))
            safe=same and movement<=plan['radius']*(1.+3e-9) and accumulated<=radius
            proof=probe.raw_section(section,y,load)
            trial={'factor':factor,'field':y.tolist(),'section':proof,'all66':rr.tolist(),'indicators':ind.tolist(),
                   'same_signs_and_steel':bool(same),'strain':movement,'strain_from_original':accumulated,
                   'within_original_scope':bool(safe)}
            step['trials'].append(trial)
            if not safe or evaluated[4]>=initial[0][4]:
                continue
            x=y
            step['selected_factor']=factor
            trial['independent_norm_MPa']=independent(section,watch,proof,x,load)
            if evaluated[4]<=evaluated[5] and trial['independent_norm_MPa']<=evaluated[5]:
                assert probe.raw_section(section,x,load)==proof and section.committed==53
                trial['steel_committing']=steel_wire(np,section)
                section.accepted_stresses.append(evaluated[2].tolist())
                section.commit(); committed=True
                print('ACCEPTED',float(load[5]),trial['independent_norm_MPa'],flush=True)
            break
        if committed or 'selected_factor' not in step:
            break
    output['history_after_relinearization']=section.committed
    if committed:
        output['next_original_nominal_target']=next_nominal(np,probe,section,watch,x,last,load)
    else:
        assert probe.raw_section(section,x0,load)==frame
        assert section.committed==53
    output['history_final']=section.committed
    ops.wipe()
    wire=gzip.compress(vector.raw_json(output),compresslevel=9,mtime=0)
    with (HERE/'ConeContinueWire.json.gz').open('xb') as sink:sink.write(wire)
    print('MVT2 ASD CONE CONTINUATION WIRE',cone.digest(wire),len(wire),'seconds',perf_counter()-started,flush=True)


if __name__=='__main__':
    main()
