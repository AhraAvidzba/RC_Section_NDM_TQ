"""One bounded residual-minimizing active-cell correction on the exact H53 anchor."""
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import importlib.util
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent
STATION_SRC='BE460B4840A3D9F18A3C478559FE492933E7A881F8E838A8C13C4E5A674C3DF5'
BUNDLE_SRC='4DA2593A5A9F0B8EBE37C6CB90A3E5AC00138B8EFBC5965D4037E05B8D54452C'
STATION_ZIP='995411807958875B23F169688738FEE6E4EBDEDAF8EAE63789A1EE2BA7AF899A'
CELL=((20,1),(20,-1),(10,-1),(7,-1))
NORMAL_STATION_STEP=5e-11


def digest(b):
    return sha256(b).hexdigest().upper()


def load_pinned(name,path,seal):
    assert digest(path.read_bytes())==seal
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def previous_receipt():
    path=PRIOR.parents[1]/'docs/regression/Coupled6D/MVT2GaussASDNominalStationEvents20261117.zip'
    assert digest(path.read_bytes())==STATION_ZIP
    with ZipFile(path) as z:
        data=json.loads(z.read('StationEventProof.json'))
    events=data['anchors']['stock_iterate']
    distance=min(row['global_max_strain_to_event'] for row in events)
    tensile=next(row['tensile_threshold'] for row in events if row['point']==7)
    return distance,tensile


def reidentify_terminal(np, section, vector, bundle, proof, loads):
    fixture=runpy.run_path(str(PRIOR/'Postyield.py'))
    program=runpy.run_path(str(fixture['SRC']/'Reequilibrate.py'))
    stock=program['try_correct']
    stock.__globals__['loads']=lambda arrays,t,q:arrays.array((0.,-600.*q,0.,t,0.,q))
    fields,_,_,_=vector.read_seed()
    last=np.array(fields[-1]['field']); seed=last+.5*(last-np.array(fields[-2]['field']))
    old=section.equations
    stock_samples=[]

    def stock_capture(x,load,matrix=False):
        value=old(x,load,matrix)
        if not matrix:
            stock_samples.append((value[4],x.copy()))
        return value

    section.equations=stock_capture
    try:
        found,status=stock(section,seed,10510000.,vector.FIRST)
    finally:
        section.equations=old
    assert found is None and status==proof['all_attempts'][0]['stock']
    first=min(stock_samples,key=lambda q:q[0])[1]
    found_fields=[]
    accepted_trace=proof['all_attempts'][0]['same_model_vector']
    target_norm=accepted_trace[-1]['row_norm_before_MPa']

    def terminal_capture(x,load,matrix=False):
        value=old(x,load,matrix)
        if value[4]==target_norm:
            found_fields.append(x.copy())
        return value

    section.equations=terminal_capture
    bundle.MAX_CYCLES=24
    try:
        result,steps=bundle.staged_recovery(np,section,program,first,loads,last,seed)
    finally:
        section.equations=old
    assert result is None and steps==accepted_trace and found_fields and section.committed==53
    assert all(np.array_equal(found_fields[0],x) for x in found_fields)
    return found_fields[0],first,seed,last


def flags(np,section,net,tensile_threshold):
    values=[]
    for point,side in CELL:
        sid=(0,1,-1).index(side)
        if point==7:
            tag=1+sid*45+point-1
            eps=section.last_tensor[sid,point-1]
            assert tuple(net[sid,point-1])==section.trial(tag,eps)
            response=section.ops.NDTest('GetResponse',tag,'equivalentTotalStrain')
            assert len(response)==2 and np.all(np.isfinite(response))
            values.append(response[0]-tensile_threshold)
            continue
        a,b,c,d,e,f=net[sid,point-1]
        values.append(float(np.linalg.eigvalsh([[a,d,e],[d,b,f],[e,f,c]])[1]))
    return np.array(values)


def witness(np,section,x,load,vector,threshold):
    record=section.equations(x,load,False)
    r=vector.coordinates(np,section,load,record)
    active=section.next_steel[2]==0.
    indicators=flags(np,section,record[2],threshold)
    return record,r,active,indicators


def sample_columns(np,section,x,load,base,vector,threshold,physical):
    _,zero,steel,signs=base
    n=60
    row=np.empty((66,n)); margins=np.zeros((4,n))
    cells=[]
    for j in range(n):
        if physical[j]==0.:
            row[:,j]=np.r_[section.G[:,j]*section.scale,np.zeros(6)]
            continue
        for reduction in (1.,.25,.0625):
            step=reduction*NORMAL_STATION_STEP/physical[j]
            direction=np.zeros(n); direction[j]=step
            _,rp,sp,mp=witness(np,section,x+direction,load,vector,threshold)
            _,rm,sm,mm=witness(np,section,x-direction,load,vector,threshold)
            vp=np.array_equal(sp,steel) and np.array_equal(np.sign(mp),np.sign(signs))
            vm=np.array_equal(sm,steel) and np.array_equal(np.sign(mm),np.sign(signs))
            if vp or vm:
                break
        if not vp and not vm:
            return None,None,{'invalid_column':j+1,'margins':signs.tolist()}
        drp=(rp-zero)/step; drm=(zero-rm)/step
        dmp=(mp-signs)/step; dmm=(signs-mm)/step
        if vp and vm:
            row[:,j]=(drp+drm)/2.; margins[:,j]=(dmp+dmm)/2.
        else:
            row[:,j]=drp if vp else drm; margins[:,j]=dmp if vp else dmm
        cells.append({'column':j+1,'step':step,'plus':bool(vp),'minus':bool(vm),
                      'r_plus':rp.tolist(),'r_minus':rm.tolist(),'m_plus':mp.tolist(),'m_minus':mm.tolist()})
    return row,margins,{'columns':cells}


def proposed_step(np,section,x,base,matrix,derivatives,old_crossing,physical):
    from scipy.optimize import linprog
    _,r,_,m=base
    radius=.5*old_crossing
    residual_scale=float(np.max(np.abs(r)))
    # Calibration x = x0 + scale*y makes each individual non-gauge field
    # coordinate dimensionless in the engineering-strain metric.
    scale=np.divide(radius,physical,out=np.zeros(60),where=physical>0.)
    gauge=physical==0.
    scale[gauge]=residual_scale/np.max(np.abs(matrix[:,gauge]),axis=0)
    d=matrix*scale/residual_scale
    u=np.reshape(section.strain*scale/radius,(-1,60))
    signed_gradient=np.sign(m)[:,None]*derivatives*scale
    branch_scale=np.maximum(np.abs(m),np.max(np.abs(signed_gradient),axis=1))
    assert np.all(branch_scale>0.) and np.all(np.abs(m)>0.)
    mtx=np.vstack((np.column_stack((d,-np.ones(66))),np.column_stack((-d,-np.ones(66))),
                   np.column_stack((u,np.zeros(len(u)))),np.column_stack((-u,np.zeros(len(u)))),
                   np.column_stack((-signed_gradient/branch_scale[:,None],np.zeros(4)))))
    # Put the residual model inside one measured material sign cell. Half the
    # signed anchor distance is reserved for local linearization error; the
    # unchanged material must then verify the actual candidate signs.
    rhs=np.r_[-r/residual_scale,r/residual_scale,np.ones(2*len(u)),.5*np.abs(m)/branch_scale]
    optimum=linprog(np.r_[np.zeros(60),1.],A_ub=mtx,b_ub=rhs,
                    bounds=[(None,None)]*60+[(0.,None)],method='highs',
                    options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    out={'radius':radius,'parameter_scale':scale.tolist(),'linear_status':int(optimum.status),'roundoff_margin_half_anchor':True}
    if not optimum.success:
        return None,out
    delta=optimum.x[:60]*scale
    out.update({'delta_field':delta.tolist(),'predicted_norm_MPa':float(np.max(np.abs(r+matrix@delta))),
                'predicted_indicators':(m+derivatives@delta).tolist(),
                'physical_step':float(np.max(np.abs(section.strain@delta))),
                'active_constraints':(np.flatnonzero(np.abs(optimum.ineqlin.residual)<1e-9)+1).tolist()})
    assert out['physical_step']<=radius*(1.+3e-9)
    return delta,out


def main():
    started=perf_counter()
    probe=load_pinned('station_probe',PRIOR/'station/Probe-Stations.py',STATION_SRC)
    bundle=load_pinned('prior_bundle',PRIOR/'Recover-Bundle.py',BUNDLE_SRC)
    vector,proof=probe.exact_reference()
    old_distance,threshold=previous_receipt()
    np,ops,section,material,identity,load,_=probe.exact_replay(vector,proof)
    x,original,seed,last=reidentify_terminal(np,section,vector,bundle,proof,load)
    first=witness(np,section,x,load,vector,threshold)
    physical=np.max(np.abs(section.strain),axis=(0,1,2))
    result={'operator_source':identity,'target':load.tolist(),'fixed_station_archive_sha256':STATION_ZIP,
            'history_before':section.committed,'field':x.tolist(),'material':material,
            'station_flags_order':CELL,'tensile_threshold':threshold,'nearest_previous_stock_event_global_strain':old_distance,
            'first_rejected_trial':original.tolist(),'original_predictor':seed.tolist(),'last_accepted_field':last.tolist(),
            'adaptation_signed_cell_only':True,'actual_trials':[]}
    initial,s0,st0,m0=first
    result['anchor']={'section':probe.raw_section(section,x,load),'all66':s0.tolist(),'indicators':m0.tolist()}
    J,K,receipt=sample_columns(np,section,x,load,first,vector,threshold,physical)
    result['finite_difference']=receipt
    choice=None
    if J is not None:
        delta,plan=proposed_step(np,section,x,first,J,K,old_distance,physical)
        result['plan']=plan
        if delta is not None and plan['predicted_norm_MPa']<initial[4]:
            for factor in (1.,.5,.25,.125,.0625):
                at=x+factor*delta
                new,r,st,vals=witness(np,section,at,load,vector,threshold)
                inside=np.array_equal(np.sign(vals),np.sign(m0)) and np.array_equal(st,st0)
                movement=float(np.max(np.abs(section.strain@(at-x))))
                global_movement=float(np.max(np.abs(section.strain@(at-original))))
                original_radius=float(np.max(np.abs(section.strain@(seed-last))))
                safe=inside and movement<=plan['radius']*(1.+3e-9) and global_movement<=original_radius
                row={'factor':factor,'all66':r.tolist(),'indicators':vals.tolist(),'inside_measured_cell':bool(inside),
                     'actual_movement':movement,'cumulative_movement_from_original_trial':global_movement,
                     'original_trust_bound':original_radius,'original_scope_safe':bool(safe),
                     'balanced':bool(safe and new[4]<=new[5]),'section':probe.raw_section(section,at,load)}
                result['actual_trials'].append(row)
                if safe and new[4]<initial[4]:
                    choice=row
                    if row['balanced']:
                        assert probe.raw_section(section,at,load)==row['section']
                        section.accepted_stresses.append(new[2].tolist()); section.commit()
                    break
    if choice is None or not choice['balanced']:
        assert probe.raw_section(section,x,load)==result['anchor']['section'] and section.committed==53
    result['selected_factor']=choice['factor'] if choice else None
    result['history_after']=section.committed
    ops.wipe()
    data=gzip.compress(vector.raw_json(result),compresslevel=9,mtime=0)
    with (HERE/'ConeWire.json.gz').open('xb') as sink:sink.write(data)
    print('MVT2 ASD CONE WIRE',digest(data),len(data),'seconds',perf_counter()-started,flush=True)


if __name__=='__main__':
    main()
