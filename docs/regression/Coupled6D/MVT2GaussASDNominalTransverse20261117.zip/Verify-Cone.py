"""Independent signed equilibrium and active-cell replay for the H53 transverse step."""
from argparse import ArgumentParser
from hashlib import sha256
from math import copysign, fsum
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WIRE='0CCEB19B987215830011170A744DEDD45AD63024CCEDDD27ECFBAFA913750793'
FOLLOW='61F969F7BBCD355CC627551C3CB460477A8A4C07BDC89FE52DB9ABFD5F96F1AF'
STATION=('MVT2GaussASDNominalStationEvents20261117','995411807958875B23F169688738FEE6E4EBDEDAF8EAE63789A1EE2BA7AF899A')
CELLS=[[20,1],[20,-1],[10,-1],[7,-1]]


def sha(x):
    return sha256(x).hexdigest().upper()


def archive(repo, pin):
    name, expected=pin
    path=repo/'docs/regression/Coupled6D'/(name+'.zip')
    assert sha(path.read_bytes())==expected
    return ZipFile(path)


def wire(core,file,pin=WIRE):
    raw=(core/file).read_bytes()
    assert sha(raw)==pin
    return json.loads(gzip.decompress(raw))


def error(a,b):
    return max(abs(x-y) for x,y in zip(a,b,strict=True))


def active(margins):
    return [copysign(1.,v) for v in margins]


def key_indices(vec):
    return [i+1 for i in sorted(range(len(vec)),key=lambda k:-abs(vec[k]))[:4]]


def prediction(receipt, anchor, step, op):
    dr=[[] for _ in range(66)]
    dm=[[] for _ in range(4)]
    scale=[1.]*56+[30000.]*4
    columns=receipt['columns']
    assert [col['column'] for col in columns]==list(range(1,57))
    orig=anchor['all66']
    m0=anchor['indicators']
    for col in columns:
        j=col['column']-1
        h=col['step']
        assert h>0. and col['plus'] and col['minus']
        assert active(col['m_plus'])==active(m0)==active(col['m_minus'])
        for target,a,b in zip(dr,col['r_plus'],col['r_minus'],strict=True):
            target.append((a-b)/(2*h)*step[j])
        for target,a,b in zip(dm,col['m_plus'],col['m_minus'],strict=True):
            target.append((a-b)/(2*h)*step[j])
    for k,row in enumerate(dr[:60]):
        row.extend(op['G'][k][j]*scale[k]*step[j] for j in range(56,60))
    return ([v+fsum(du) for v,du in zip(orig,dr,strict=True)],
            [v+fsum(du) for v,du in zip(m0,dm,strict=True)])


def evaluate(data, watch, old_proof, guard, past, op, geo, area, length):
    a=data['anchor']; x=data['field']; demand=data['target']; initial=a['section']
    eq=watch['check_whole']; tensor=past['tensor']; signed=guard['signed_forces']
    expected=eq(initial,x,demand,op,geo,area,length,signed)
    assert data['station_flags_order']==CELLS and active(a['indicators'])==[-1.,1.,1.,-1.]
    assert expected>initial['tolerance_MPa']
    assert abs(expected-old_proof['all_attempts'][0]['same_model_vector'][-1]['row_norm_before_MPa'])<3e-12
    before_prior=old_proof['all_attempts'][0]['same_model_vector'][-2]['physical_move_from_first_trial']
    move=lambda delta:max(abs(f) for p in range(45) for side in (0,1,-1) for f in tensor(op,delta,p,side))
    assert abs(move([b-u for b,u in zip(x,data['first_rejected_trial'],strict=True)])-before_prior)<4e-18
    plan=data['plan']; delta=plan['delta_field']; factor=data['selected_factor']
    assert factor==1. and data['history_before']==data['history_after']==53
    assert move(delta)<=plan['radius']+4e-18
    assert abs(plan['radius']-.5*data['nearest_previous_stock_event_global_strain'])<1e-20
    for row in data['finite_difference']['columns']:
        coordinate=[0.]*60; coordinate[row['column']-1]=row['step']
        assert abs(move(coordinate)-5e-11)<1e-23
    predicted,m=prediction(data['finite_difference'],a,delta,op)
    assert abs(max(map(abs,predicted))-plan['predicted_norm_MPa'])<5e-15
    assert error(m,plan['predicted_indicators'])<2e-18
    assert active(m)==active(a['indicators']) and all(abs(v)>=.5*abs(w) for v,w in zip(m,a['indicators'],strict=True))
    assert len(data['actual_trials'])==1
    t=data['actual_trials'][0]; raw=t['section']
    actual=eq(raw,[q+v for q,v in zip(x,delta,strict=True)],demand,op,geo,area,length,signed)
    assert abs(actual-max(map(abs,t['all66'])))<3e-12
    # The offline replay rebuilds the middle three principal stresses from raw
    # station stresses. The tensile equivalent strain indicator is engine output.
    for frame,margins in ((initial,a['indicators']),(raw,t['indicators'])):
        for (p,side),marker in zip(CELLS[:3],margins[:3],strict=True):
            middle=watch['eigen'](frame['net_stresses_MPa'][(0,1,-1).index(side)][p-1])[1]
            assert abs(middle-marker)<2e-13 and copysign(1.,middle)==copysign(1.,marker)
    assert raw['steel_active_flags']==initial['steel_active_flags']
    assert active(t['indicators'])==active(a['indicators']) and t['original_scope_safe']
    assert not t['balanced'] and 13.<actual/raw['tolerance_MPa']<14.
    for result,r in ((initial,a['all66']),(raw,t['all66'])):
        independent_force_residual=[(v-w)/s for v,w,s in zip(result['signed_6'],demand,(area,area*length,area*length,area*length,area,area),strict=True)]
        assert error(independent_force_residual,r[60:])<5e-15
        assert error(result['normalized_60'],r[:60])<5e-15
    return {'status':'PASS','considered_Qy_N':55234.375,'last_accepted_Qy_N':55156.25,
            'section_tolerance_MPa':raw['tolerance_MPa'],'before_MPa':expected,'actual_MPa':actual,
            'predicted_MPa':plan['predicted_norm_MPa'],'actual_to_tolerance':actual/raw['tolerance_MPa'],
            'actual_signed_6_N_Nmm':raw['signed_6'],'step_engineering_strain':move(delta),
            'dominant_rows_initial':key_indices(a['all66']),'dominant_rows_final':key_indices(t['all66']),
            'four_actual_branch_indicators':t['indicators'],'steel_flags_and_history_unchanged':True,
            'physical_limit_established':False}


def verify_follow(data, follow, watch, guard, past, op, geo, area, length):
    assert follow['prefix_wire_sha256']==WIRE and follow['same_frozen_H53_before_relinearization']
    assert follow['initial_history_count']==follow['history_after_relinearization']==follow['history_final']==53
    assert 'next_original_nominal_target' not in follow
    assert follow['target']==data['target']
    x=[a+b for a,b in zip(data['field'],data['plan']['delta_field'],strict=True)]
    assert x==follow['initial_exact_field']
    f0=data['actual_trials'][0]['section']
    assert follow['initial_exact_section']==f0
    prior=data['actual_trials'][0]['all66']
    margins=data['actual_trials'][0]['indicators']
    initial_norm=f0['norm_MPa']
    results=[]
    tensor=past['tensor']; eq=watch['check_whole']

    def movement(delta):
        return max(abs(f) for p in range(45) for side in (0,1,-1) for f in tensor(op,delta,p,side))

    delta=[a-b for a,b in zip(data['original_predictor'],data['last_accepted_field'],strict=True)]
    assert abs(movement(delta)-follow['original_radius'])<4e-18
    assert [c['number'] for c in follow['iterations']]==[1,2,3]
    for record in follow['iterations']:
        assert record['initial_field']==x and record['initial_all66']==prior and record['initial_indicators']==margins
        p=record['plan']; trial,=record['trials']
        assert trial['factor']==record['selected_factor']==1.
        d=p['delta_field']
        assert trial['field']==[a+b for a,b in zip(x,d,strict=True)]
        x=trial['field']
        curr=trial['section']
        m=trial['indicators']; r=trial['all66']
        pred_r,pred_m=prediction(record['finite_difference'],{'all66':prior,'indicators':margins},d,op)
        assert abs(max(map(abs,pred_r))-p['predicted_norm_MPa'])<5e-15
        assert error(pred_m,p['predicted_indicators'])<2e-18
        assert all(abs(v)>=.5*abs(w) and a==b for v,w,a,b in zip(pred_m,margins,active(pred_m),active(margins),strict=True))
        assert active(m)==active(margins) and curr['steel_active_flags']==f0['steel_active_flags']
        assert trial['same_signs_and_steel'] and trial['within_original_scope']
        actual=eq(curr,x,data['target'],op,geo,area,length,guard['signed_forces'])
        assert p['radius']==data['plan']['radius'] and abs(movement(d)-p['radius'])<4e-18
        assert movement([b-u for b,u in zip(x,data['first_rejected_trial'],strict=True)])<=follow['original_radius']
        assert abs(actual-trial['independent_norm_MPa'])<3e-12
        assert abs(actual-max(map(abs,r)))<3e-12 and curr['tolerance_MPa']<actual<initial_norm
        assert abs(actual-p['predicted_norm_MPa'])<4e-7
        for (point,side),marker in zip(CELLS[:3],m[:3],strict=True):
            calc=watch['eigen'](curr['net_stresses_MPa'][(0,1,-1).index(side)][point-1])[1]
            assert abs(calc-marker)<2e-13 and copysign(1.,calc)==copysign(1.,marker)
        prior,margins,initial_norm=r,m,actual
        results.append({'iteration':record['number'],'actual_MPa':actual,'predicted_MPa':p['predicted_norm_MPa'],
                        'dominant_rows':key_indices(r),'signed_6_N_Nmm':curr['signed_6'],
                        'physical_trust_saturated':True,'branch_indicators':m,
                        'active_branch_linear_constraints':[k for k in p['active_constraints'] if k>1752]})
    assert 6.<initial_norm/f0['tolerance_MPa']<6.2
    return {'same_history_retained':True,'all_relinearizations':results,'next_original_nominal_target_tried':False,
            'final_true_norm_MPa':initial_norm,'final_norm_to_original_tolerance':initial_norm/f0['tolerance_MPa'],
            'physical_limit_established':False}


def main(repo,has_follow=False):
    data=wire(HERE,'ConeWire.json.gz')
    assert data['fixed_station_archive_sha256']==STATION[1]
    with tempfile.TemporaryDirectory(prefix='MVTConeOffline_') as folder, archive(repo,STATION) as saved:
        root=Path(folder)
        (root/'Verify-Stations.py').write_bytes(saved.read('Verify-Stations.py'))
        watch=runpy.run_path(str(root/'Verify-Stations.py'))
        predecessors=json.loads(saved.read('StationEventProof.json'))['anchors']['stock_iterate']
        assert data['tensile_threshold']==next(e['tensile_threshold'] for e in predecessors if e['point']==7)
        assert data['nearest_previous_stock_event_global_strain']==min(e['global_max_strain_to_event'] for e in predecessors)
        with archive(repo,watch['BASE']) as p:
            (root/'Verify-VectorEvidence.py').write_bytes(p.read('Verify-VectorEvidence.py'))
            old=json.loads(p.read('bundle24-output/VectorNominal.json'))
        controls=runpy.run_path(str(root/'Verify-VectorEvidence.py'))
        accepted,n,_,_,_=controls['history'](repo)
        assert accepted['Q_target_N']==55156.25 and n<accepted['tolerance_MPa'] and data['last_accepted_field']==accepted['field']
        assert data['target']==[0.,-33140625.,0.,10510000.,0.,55234.375]
        with archive(repo,controls['POST']) as p:
            (root/'Verify-Postyield.py').write_bytes(p.read('Verify-Postyield.py'))
        past=runpy.run_path(str(root/'Verify-Postyield.py'))
        with archive(repo,past['AUTH']) as p:
            for leaf in ('Verify-Authoritative.py','Operators.py','Reequilibrate.py'):
                (root/leaf).write_bytes(p.read(leaf))
        sys.path.insert(0,str(root))
        guard=runpy.run_path(str(root/'Verify-Authoritative.py'))
        operator,source=guard['unpack'](root,repo)
        model=runpy.run_path(str(root/'Reequilibrate.py'))
        _,_,geo,dirs,area,length,op,_,_,identity=model['read_inputs'](operator,root,source)
    assert data['operator_source']==identity
    report=evaluate(data,watch,old,guard,past,op,geo,area,length)
    if has_follow:
        report['three_relinearizations']=verify_follow(data,wire(HERE,'ConeContinueWire.json.gz',FOLLOW),watch,guard,past,op,geo,area,length)
    return report


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=Path.cwd())
    cli.add_argument('--report',type=Path)
    cli.add_argument('--follow',action='store_true')
    opts=cli.parse_args()
    result=main(opts.repo,opts.follow)
    raw=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if opts.report:
        with opts.report.open('xb') as stream: stream.write(raw)
    print('MVT2 ASD CONE OFFLINE PASS',sha(raw),result['actual_to_tolerance'])
