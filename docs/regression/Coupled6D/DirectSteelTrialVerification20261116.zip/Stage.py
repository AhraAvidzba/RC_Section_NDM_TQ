"""Stage the private final direct steel test against the frozen installed workbook."""

from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from shutil import copyfile


HERE=Path(__file__).resolve().parent
WITNESS=HERE.parent/'direct-steel-proof'
REPO=HERE.parents[1]
BOOK='workbook/output/RC_Section_NDM.xlsm'


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


run_path(str(HERE/'Compose.py'),run_name='__main__')
source=json.loads((WITNESS/'Fixture.json').read_text(encoding='utf-8'))
assert digest(REPO/BOOK)==source['workbook_sha256']
assert not (HERE/'Fixture.json').exists()
files=[name for name in source['frozen'] if name.startswith('tools/') or name in (BOOK,'Guard-IsolatedOffice.ps1')]
for name in files:
    assert digest(WITNESS/name)==source['frozen'][name]
    (HERE/name).parent.mkdir(exist_ok=True,parents=True)
    copyfile(WITNESS/name,HERE/name)
for name in ('docs/regression','Temp','Native'):
    (HERE/name).mkdir(exist_ok=True,parents=True)
copyfile(HERE/BOOK,HERE/'docs/regression/Diagnostic.xlsm')
changes=json.loads((HERE/'SourceManifest.json').read_text(encoding='utf-8'))['changes']
modules=sorted(Path(name).stem for name in changes)
harness=(WITNESS/'Run-Direct.ps1').read_text(encoding='utf-8')
harness=harness.replace("@('modTestCoupledElasticState')",'@('+','.join(repr(name) for name in modules)+')')
harness=harness.replace("($compiled.Modules -join ',') -cne 'modTestCoupledElasticState'",
                        "(($compiled.Modules | Sort-Object) -join ',') -cne '"+','.join(modules)+"'")
harness=harness.replace('RunTestCoupledDirectSteelWitness','RunTestCoupledDirectSteelVerification')
harness=harness.replace("'Prepare.py' --verify $report","'Verify-Candidate.py' $report")
harness=harness.replace('-TimeoutSeconds 100','-TimeoutSeconds 110')
(HERE/'Run-Candidate.ps1').write_text(harness,encoding='utf-8-sig',newline='\r\n')
files.extend(changes)
files.extend(('Run-Candidate.ps1','Verify-Candidate.py','Stage.py','SourceManifest.json'))
report={'workbook_sha256':source['workbook_sha256'],'frozen':{key:digest(HERE/key) for key in files},'modules':modules}
(HERE/'Fixture.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('DIRECT_CANDIDATE',digest(HERE/'Fixture.json'))
