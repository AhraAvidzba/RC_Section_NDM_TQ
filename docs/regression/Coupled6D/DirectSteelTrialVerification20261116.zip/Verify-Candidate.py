"""Check the saved direct-steel witness against the analytic branch and closure."""

from decimal import Decimal, getcontext
from hashlib import sha256
import json
from pathlib import Path
import sys


getcontext().prec=42
path=Path(sys.argv[1])
report=path.read_text(encoding='utf-8-sig')
assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in report
assert 'TOTAL_DIRECT_STEEL_VERIFICATION: passed=23; failed=0' in report
lines=[line.split(';') for line in report.splitlines()]
states=[]
for line in lines:
    if line[0]=='DIRECT_RESOLVED':
        _,shift,utilization,residual=line
        states.append(dict(shift_N=shift,utilization=utilization,residual_MPa=residual))
contacts=[line[1] for line in lines if line[0]=='DIRECT_CONTACT']
assert len(states)==2 and len(contacts)==3
assert Decimal(states[0]['shift_N'])<0<Decimal(states[1]['shift_N'])
assert Decimal(states[0]['utilization'])<1<Decimal(states[1]['utilization'])
assert Decimal(contacts[0])<0==Decimal(contacts[1])<Decimal(contacts[2])
assert abs(Decimal(states[1]['residual_MPa']))<Decimal('1e-9')
report_json={'report_sha256':sha256(path.read_bytes()).hexdigest().upper(),'resolved':states,'unresolved_load_shifts_N':contacts}
path.with_name('CandidateVerification.json').write_text(json.dumps(report_json,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report_json,indent=2))
