"""Verify direct steel candidate evidence without Office or a workbook."""

import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory


HERE=Path(__file__).resolve().parent
NATIVE_SHA='6D1871B308FC6690DC44BD74F5C193DD6A1B521C9373181E756AB9FE49251148'
FIXTURE_SHA='390044BEF5CFA8BDA8EAA51897A05B05CCC3561007876B8B343F4AEC4135759D'
FAIL_LOG_SHA='9D903CA1A8AE19588C920749179DA4322385EF7B60FE20291D9F0A8317511741'


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read_json(name):
    return json.loads((HERE/name).read_text(encoding='utf-8-sig'))


def verify_source(repo, success, failure):
    manifest=read_json('SourceManifest.json')
    assert manifest['base']=='abcfa53'
    spec=spec_from_file_location('compose_candidate',HERE/'Compose.py')
    composer=module_from_spec(spec); spec.loader.exec_module(composer)
    changes={'CCoupledLoadContinuation.cls':composer.continuation, 'CCoupledSectionAnalysis.cls':composer.section,
             'CCoupledNewtonSolver.cls':composer.newton, 'CCoupledElasticState.cls':lambda s:composer.append(s,'Projection.txt'),
             'CCoupledReinforcedResponse.cls':lambda s:composer.append(s,'Steel.txt'),
             'modTestCoupledElasticState.bas':lambda s:composer.append(s,'Test.txt')}
    test='tests/modTestCoupledElasticState.bas'
    for name, hashes in manifest['changes'].items():
        assert hashes['private_sha256']==success['frozen'][name]
        if name!=test:
            assert hashes['private_sha256']==failure['frozen'][name]
        if repo:
            raw=check_output(['git','show',f"{manifest['base']}:{name}"],cwd=repo)
            assert sha256(raw).hexdigest().upper()==hashes['base_sha256']
            source=raw.decode('utf-8-sig').replace('\r\n','\n')
            modified=changes[Path(name).name](source).replace('\n','\r\n').encode('utf-8')
            assert sha256(modified).hexdigest().upper()==hashes['private_sha256']
            if name==test:
                original=(HERE/'Failure/Test.txt').read_text(encoding='utf-8')
                error=(source.rstrip()+'\n\n'+original).replace('\n','\r\n').encode('utf-8')
                assert sha256(error).hexdigest().upper()==failure['frozen'][name]


def verify_closures(fixture):
    failure_receipt=read_json('Failure/CompileClosureObserved.json')
    failure_text=(HERE/'Failure/Compile.log').read_text(encoding='utf-8-sig')
    failure_owner=re.search(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',failure_text,re.M)
    assert failure_receipt['State']=='Absent' and failure_owner
    assert (int(failure_owner[1]),failure_owner[2])==(failure_receipt['PID'],failure_receipt['StartTicksUTC'])
    assert 'line=4984' in failure_text and 'TestRecord (response.AcceptedSteelUtilization > 1#) = (shift > 0#)' in failure_text
    compile_receipt=read_json('CompileClosure.json')
    compile_text=(HERE/'Compile.log').read_text(encoding='utf-8-sig')
    compile_owner=re.search(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',compile_text,re.M)
    assert compile_receipt['State']=='Absent' and compile_owner
    assert (int(compile_owner[1]),compile_owner[2])==(compile_receipt['PID'],compile_receipt['StartTicksUTC'])
    compile_code=read_json('docs/regression/CodeUpdate.json')
    assert compile_code['Compiled'] and not compile_code['ProductionChanged']
    assert compile_code['ProductionSHA256']==fixture['workbook_sha256']
    assert sorted(compile_code['Modules'])==fixture['modules']
    native_owner=read_json('Native/Direct.txt.Ownership.json')
    close=read_json('Native/Direct.txt.ProcessClosure.json')
    state=close['Closure']['FinalState']
    assert close['Passed'] and close['ChildHasExited'] and close['ChildExitCode']==0 and close['RunnerCleanupValid']
    assert not close['OrdinaryPathKilledAnything'] and state['State']=='Absent' and native_owner['VerifiedNewOwner']
    assert (state['PID'],state['StartTicksUTC'])==(native_owner['PID'],native_owner['StartTicksUTC'])
    assert compile_code['WorkbookSHA256']==native_owner['SourceSHA256']
    native=(HERE/'Native/Direct.txt').read_text(encoding='utf-8-sig')
    assert f"SOURCE_SHA256: {compile_code['WorkbookSHA256']}" in native
    assert len({receipt['PID'] for receipt in (failure_receipt,compile_receipt,native_owner)})==3


def main(repo):
    expected=read_json('SHA256SUMS.json')
    assert all(digest(HERE/name)==value for name,value in expected.items())
    assert digest(HERE/'Native/Direct.txt')==NATIVE_SHA
    assert digest(HERE/'Fixture.json')==FIXTURE_SHA
    assert digest(HERE/'Failure/Compile.log')==FAIL_LOG_SHA
    passed=read_json('Fixture.json'); failed=read_json('Failure/Fixture.json')
    assert passed['workbook_sha256']==failed['workbook_sha256']
    verify_source(repo,passed,failed)
    verify_closures(passed)
    with TemporaryDirectory() as directory:
        copy=Path(directory)/'Direct.txt'
        copyfile(HERE/'Native/Direct.txt',copy)
        check_output([sys.executable,'-B','-X','utf8',str(HERE/'Verify-Candidate.py'),str(copy)])
        assert (copy.parent/'CandidateVerification.json').read_bytes()==(HERE/'Native/CandidateVerification.json').read_bytes()
    print(f'DIRECT STEEL CANDIDATE EVIDENCE PASS {NATIVE_SHA}')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path)
    main(parser.parse_args().repo)
