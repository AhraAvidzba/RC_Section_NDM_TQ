"""Verify published signed local and nominal preyield rays using archived section data."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
from CheckRay import check

HERE=Path(__file__).resolve().parent
AUTH="MVT2GaussReequilibratedASD20261117"
AUTH_SHA="FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E"
CHECKS={
    "Extension.json":"F135B5535CEF5B2590E47C631FCDEB3A4FCC6843732392C228D2A64D5CECE904",
    "Extension.stress.json.gz":"CB87D22903787D5800EA2AC44D6B138765C548B4BABEA20CB2F80C0D7CF10897",
    "Midspan.json":"B97E758EA13DEF84BCFA2F0D86AF6DB8CBF28F25A8CA672047B83C45A772D314",
    "Midspan.stress.json.gz":"4EAA8332CC24B86C13C222C535423E190D95D800A8D0C1D0F6D8F596450AC670",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def manifest():
    names=set()
    for line in (HERE/"SHA256SUMS").read_text(encoding="ascii").splitlines():
        expected,name=line.split("  ",1)
        path=PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts and name not in names
        raw=(HERE/name).read_bytes()
        assert digest(raw)==expected and CHECKS.get(name,expected)==expected
        names.add(name)
    assert names=={p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file() and p.name!="SHA256SUMS"}


def main(repo):
    manifest()
    authority=repo/"docs/regression/Coupled6D"/(AUTH+".zip")
    assert digest(authority.read_bytes())==AUTH_SHA
    with tempfile.TemporaryDirectory(prefix="MVTASDReadRays_") as td:
        temporary=Path(td)
        with ZipFile(authority) as prior:
            for leaf in ("Verify-Authoritative.py","Reequilibrate.py","Operators.py"):
                (temporary/leaf).write_bytes(prior.read(leaf))
        sys.path.insert(0,str(temporary))
        guard=runpy.run_path(str(temporary/"Verify-Authoritative.py"))
        op_path,source=guard["unpack"](temporary,repo)
        executor=runpy.run_path(str(temporary/"Reequilibrate.py"))
        _,native,geom,dirs,area,length,op,_,_,identity=executor["read_inputs"](op_path,temporary,source)
        result={}
        for hand in ("Extension","Midspan"):
            wire=(HERE/(hand+".stress.json.gz")).read_bytes()
            data=json.loads((HERE/(hand+".json")).read_bytes())
            saved=json.loads(gzip.decompress(wire))
            assert data["engine"]=="3.8.0" and data["numpy"]=="2.3.5" and data["operators_identity"]==identity
            assert data["source_section_reference_sha256"]==AUTH_SHA and not data["physical_limit_established"]
            assert not data["experimental_capacity_established_by_this_control"]
            if hand=="Extension":
                arm=330.; rows=data["records_past_Q15"]
                assert data["original_26_prefix_bit_exact"] and data["terminal"] is None
                assert len(rows)==26 and [r["Q_target_N"] for r in rows]==list(range(17500,80001,2500))
                assert all(row["subdivision"]==0 for row in rows)
                assert data["new_three_stations_tensor_wire_sha256"]==digest(wire)
            else:
                arm=600.; rows=data["new_after_pure_torsion"]
                assert data["pure_T_prefix_fields_and_stresses_bit_exact"]==8 and len(rows)==34
                assert data["terminal"]["phase"]=="MidspanQ52.5"
                assert data["terminal"]["last_reached_Q_N"]==51562.5
                assert data["attempts_after_pure_torsion"][-1]["Q_N"]==51640.625
                assert len(data["rejected_material_guard_probes"])==6
                assert all(v["maximum_yield_fraction"]>1. for v in data["rejected_material_guard_probes"])
                assert data["three_station_stresses_SHA256"]==digest(wire)
            assert all(r["T_target_Nmm"]==10510000. for r in rows)
            assert all(a["Q_target_N"]<b["Q_target_N"] for a,b in zip(rows,rows[1:]))
            all_checks=[check(net,row,geom,dirs,area,length,op,arm) for net,row in zip(saved,rows,strict=True)]
            result[hand]={"accepted_new_mixed":len(rows),"last_Q_N":rows[-1]["Q_target_N"],
                          "last_Mx_Nmm":rows[-1]["resultants_N_Nmm"][1],
                          "last_steel":all_checks[-1]["maximum_steel_use"],
                          "maximum_residual_MPa":max(rec["max_norm_MPa"] for rec in all_checks)}
            if hand=="Midspan":
                assert all_checks==[{k:v for k,v in x.items() if k not in ("phase","T_kNm","Qy_kN","nominal_Mx_kNm")}
                                    for x in data["independent_checks"]]
        print("MVT2 ASD TWO RAYS OFFLINE PASS",result)


if __name__=="__main__":
    p=ArgumentParser()
    p.add_argument("--repo",type=Path,default=Path.cwd())
    main(p.parse_args().repo)
