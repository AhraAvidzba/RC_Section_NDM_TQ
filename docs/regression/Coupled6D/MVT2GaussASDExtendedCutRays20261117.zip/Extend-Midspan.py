"""A separate nominal one-sided midspan ray with the same steel guard."""
from argparse import ArgumentParser
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
from CheckRay import check
from importlib.machinery import SourceFileLoader

HERE=Path(__file__).resolve().parent
BASE=runpy.run_path(str(HERE/"Extend-RightCut.py"))


def run(output,raw_path):
    get=BASE["digest"]
    assert get(BASE["ASD"].read_bytes())==BASE["ASD_SHA"] and get(BASE["OP"].read_bytes())==BASE["OP_SHA"]
    with ZipFile(BASE["ASD"]) as archive:
        for leaf in ("Reequilibrate.py","Operators.py"):
            assert (BASE["SRC"]/leaf).read_bytes()==archive.read(leaf)
        report_raw=archive.read("Authoritative.json")
        stresses_raw=archive.read("Authoritative.stress.json.gz")
    assert get(report_raw)==BASE["ASD_REPORT"] and get(stresses_raw)==BASE["ASD_STRESS"]
    control=json.loads(report_raw)["modes"]["default"]
    control_stress=json.loads(gzip.decompress(stresses_raw))["default"]
    sys.path.insert(0,str(BASE["NUMPY"]))
    sys.path.insert(0,str(BASE["SRC"]))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0" and np.__version__=="2.3.5"
    program=runpy.run_path(str(BASE["SRC"]/"Reequilibrate.py"))
    sh,native,geom,dirs,area,length,operators,seeds,observed,identity=program["read_inputs"](BASE["OP"],BASE["NATIVE_ROOT"])
    solve=program["simulate"]
    globals_=solve.__globals__
    reference_rollback=globals_["test_discard"]
    globals_["test_discard"]=lambda engine,cmd,point,stages:reference_rollback(engine,cmd,point,stages[:26])
    globals_["loads"]=lambda arrays,t,q:arrays.array((0.,-600.*q,0.,t,0.,q))
    section=globals_["Section"]
    original_components=section.components
    guard_hits=[]
    steel_caps=np.array([498.]*4+[450.]*16)
    def audited_components(self,field):
        try:
            return original_components(self,field)
        except ArithmeticError as error:
            if "steel elastic range" in str(error):
                strains=self.strain@field
                axial=2e5*np.einsum("spi,pi->sp",strains[:,25:,:],self.dirs[25:])
                utilization=np.abs(axial)/steel_caps
                side,point=np.unravel_index(np.argmax(utilization),utilization.shape)
                guard_hits.append({"accepted_fields_before_trial":self.committed,
                                   "maximum_yield_fraction":float(utilization[side,point]),
                                   "point":int(point+26),"side":(0,1,-1)[side],"stress_MPa":float(axial[side,point])})
            raise
    section.components=audited_components
    tail=[{"phase":f"MidspanQ{q/1000:g}","T_Nmm":BASE["TORQUE"],"Qy_N":q} for q in BASE["NEW_Q"]]
    report={**native,"frames":[*native["frames"],*tail]}
    args=program["commands"](sh,native,("default",))["default"]
    print("START exact 8 pure torsion states then nominal midspan Mx=-0.600Qy",flush=True)
    try:
        outcome,sigmas=solve(np,ops,sh,report,geom,dirs,area,length,operators,seeds,"default",args,
                            perf_counter()+65.,len(report["frames"]))
    finally:
        ops.wipe()
    assert outcome["accepted"][:8]==control["accepted"][:8]
    assert outcome["attempts"][:8]==control["attempts"][:8] and sigmas[:8]==control_stress[:8]
    independent=[]
    for raw,row in zip(sigmas[8:],outcome["accepted"][8:],strict=True):
        checks=check(raw,row,geom,dirs,area,length,operators,600.)
        independent.append({"phase":row["phase"],"T_kNm":row["T_target_Nmm"]/1e6,"Qy_kN":row["Q_target_N"]/1000.,
                            "nominal_Mx_kNm":-600.*row["Q_target_N"]/1e6,**checks})
    assert outcome["rejected_trial_interleaving_max_MPa"]==0.
    assert all(a["Qy_kN"]<b["Qy_kN"] for a,b in zip(independent,independent[1:]))
    compressed=gzip.compress(json.dumps(sigmas[8:],separators=(",",":"),allow_nan=False).encode(),
                             mtime=0,compresslevel=9)
    data={"status":"completed_bounded_control","engine":ops.version(),"numpy":np.__version__,
          "scope":"nominal one-sided midspan local section idealization; no whole beam equilibrium",
          "source_section_reference_sha256":BASE["ASD_SHA"],"operators_identity":identity,
          "arm_mm":600.,"observed_beam_max_Qy_kN":80.,"observed_beam_max_nominal_abs_Mx_kNm":48.,
          "pure_T_prefix_fields_and_stresses_bit_exact":8,"new_after_pure_torsion":outcome["accepted"][8:],
          "attempts_after_pure_torsion":outcome["attempts"][8:],"independent_checks":independent,
          "rejected_material_guard_probes":guard_hits,"terminal":outcome["terminal"],
          "physical_limit_established":False,"experimental_capacity_established_by_this_control":False,
          "three_station_stresses_SHA256":get(compressed)}
    with raw_path.open("xb") as f:
        f.write(compressed)
    report=(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with output.open("xb") as f:
        f.write(report)
    print("PASS",get(report),get(compressed),outcome["last_confirmed"],outcome["terminal"],
          "rejected-steel-guard",len(guard_hits))


if __name__=="__main__":
    cli=ArgumentParser(description=__doc__)
    cli.add_argument("--out",type=Path,default=HERE/"Midspan.json")
    cli.add_argument("--raw",type=Path,default=HERE/"Midspan.stress.json.gz")
    a=cli.parse_args()
    run(a.out,a.raw)
