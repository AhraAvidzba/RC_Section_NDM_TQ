"""One bounded ASD continuation on the existing right-window force ray."""
from argparse import ArgumentParser
from hashlib import sha256
from math import hypot
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
SRC=HERE.parent/"mvt-asd-equilibrium"
ASD=REPO/"docs/regression/Coupled6D/MVT2GaussReequilibratedASD20261117.zip"
ASD_SHA="FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E"
ASD_REPORT="393EA5BED46723E5AA37544B6E8334D982ED15545D1E31F88D1A5716D506C463"
ASD_STRESS="3CD17995A5AA1056787D26E3479EA55D2BF7EDB5B9A155D12DAB3EBD19121CA1"
OP=Path("D:/CodexScratch/RC_Section_NDM_TQ/MVTGauss25Operators/Native/Operators.csv")
OP_SHA="3E8C00B7AC650B9FF6BBF55C412AED9A18A258BCEE3083D58ECEA9B7A07B653A"
NATIVE_ROOT=Path("D:/CodexScratch/RC_Section_NDM_TQ/MVTGauss25Tensors")
NUMPY=Path("D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython")
NEW_Q=tuple(range(17500,80001,2500))
TORQUE=10510000.


def digest(raw):
    return sha256(raw).hexdigest().upper()


def run(report_path,raw_path):
    assert digest(ASD.read_bytes())==ASD_SHA and digest(OP.read_bytes())==OP_SHA
    with ZipFile(ASD) as archive:
        for filename in ("Operators.py","Reequilibrate.py","Verify-Authoritative.py"):
            assert (SRC/filename).read_bytes()==archive.read(filename)
        report_raw=archive.read("Authoritative.json")
        stress_raw=archive.read("Authoritative.stress.json.gz")
    assert digest(report_raw)==ASD_REPORT and digest(stress_raw)==ASD_STRESS
    reference=json.loads(report_raw)["modes"]["default"]
    reference_stress=json.loads(gzip.decompress(stress_raw))["default"]
    sys.path.insert(0,str(NUMPY))
    sys.path.insert(0,str(SRC))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0" and np.__version__=="2.3.5"
    source=runpy.run_path(str(SRC/"Reequilibrate.py"))
    checker=runpy.run_path(str(SRC/"Verify-Authoritative.py"))["check"]
    shared,native,geom,dirs,area,length,operators,seeds,accepted_native,identity=source["read_inputs"](OP,NATIVE_ROOT)
    assert len(native["frames"])==len(reference["accepted"])==26
    tail=tuple({"phase":f"RightQ{q/1000:g}","T_Nmm":TORQUE,"Qy_N":q} for q in NEW_Q)
    # The rejected-probe history check keeps the 26 measured native tensors.
    # New load targets add no fabricated kinematics and start from the live accepted ASD history.
    simulate=source["simulate"]
    context=simulate.__globals__
    rollback=context["test_discard"]
    context["test_discard"]=lambda engine,command,replay,stages:rollback(engine,command,replay,stages[:26])
    extended={**native,"frames":[*native["frames"],*tail]}
    command=source["commands"](shared,native,("default",))["default"]
    print("START exact 26 accepted states then fixed T, Mx=-0.330Qy, Q 17.5..80 kN",flush=True)
    try:
        test,stresses=simulate(np,ops,shared,extended,geom,dirs,area,length,operators,seeds,
                              "default",command,perf_counter()+55.,len(extended["frames"]))
    finally:
        ops.wipe()
    first=test["accepted"][:26]
    assert first==reference["accepted"] and stresses[:26]==reference_stress
    assert test["attempts"][:26]==reference["attempts"]
    assert test["rejected_trial_interleaving_max_MPa"]==0.
    later=test["accepted"][26:]
    assert later
    independent=[]
    for stage,s in zip(later,stresses[26:],strict=True):
        assert stage["T_target_Nmm"]==TORQUE
        norm,steel=checker(s,stage,geom,dirs,area,length,operators)
        q=stage["Q_target_N"]
        independent.append({"phase":stage["phase"],"Qy_kN":q/1000.,
                            "right_section_Mx_kNm":-.330*q/1000.,
                            "right_window_Mx_endpoints_kNm":[-.360*q/1000.,-.300*q/1000.],
                            "beam_nominal_midspan_abs_Mx_if_same_Q_kNm":.600*q/1000.,
                            "max_independent_60_row_and_resultant_norm_MPa":norm,
                            "maximum_steel_elastic_range_fraction":steel})
    assert all(b["Qy_kN"]>a["Qy_kN"] for a,b in zip(independent,independent[1:]))
    compressed=gzip.compress(json.dumps(stresses[26:],separators=(",",":"),allow_nan=False).encode(),
                             mtime=0,compresslevel=9)
    result={"status":"completed_bounded_control","engine":ops.version(),"numpy":np.__version__,
            "scope":"fixed-T right-window center section ray; not a beam resistance check",
            "source_section_reference_sha256":ASD_SHA,"operators_identity":identity,
            "original_26_prefix_bit_exact":True,"new_nominal_Qy_targets_kN":[x/1000. for x in NEW_Q],
            "extrapolated_local_target":"T=10.51 kN·m; Mx=-0.330 Qy kN·m for Qy in kN; N=My=Qx=0",
            "primary_test_anchors":{"paper":"https://doi.org/10.1371/journal.pone.0175834",
                   "longitudinal_steel_yield_indication_Qy_kN":67.5,"beam_crushing_and_peak_Qy_kN":80.,
                   "peak_nominal_midspan_abs_Mx_kNm":48.},
            "experimental_capacity_established_by_this_control":False,
            "physical_limit_established":False,"original_routine_limits_preserved":True,
            "records_past_Q15":later,"attempts_past_Q15":test["attempts"][26:],
            "independent_checks":independent,"terminal":test["terminal"],
            "new_three_stations_tensor_wire_sha256":digest(compressed)}
    with raw_path.open("xb") as f:
        f.write(compressed)
    out=(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with report_path.open("xb") as f:
        f.write(out)
    print("PASS",digest(out),digest(compressed),"last confirmed",test["last_confirmed"],"terminal",test["terminal"])


if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=HERE/"Extension.json")
    parser.add_argument("--raw",type=Path,default=HERE/"Extension.stress.json.gz")
    args=parser.parse_args()
    run(args.out,args.raw)
