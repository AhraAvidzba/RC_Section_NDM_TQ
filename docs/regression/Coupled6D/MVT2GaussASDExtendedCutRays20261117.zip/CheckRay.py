"""Independent physical section forces and weak rows for a chosen lever arm."""
from math import fsum, isfinite


def check(net,record,geom,dirs,area,length,op,arm_mm):
    field=record["field"]
    assert len(field)==60 and all(map(isfinite,field))
    assert len(net)==3 and all(len(side)==45 for side in net)
    assert all(len(v)==6 and all(map(isfinite,v)) for side in net for v in side)
    t,q=record["T_target_Nmm"],record["Q_target_N"]
    demanded=(0.,-arm_mm*q,0.,t,0.,q)
    expected=[fsum(a[j]*x for a,x in zip(op["L"],demanded,strict=True)) for j in range(60)]
    delta=[[500.*(a-b) for a,b in zip(p,n,strict=True)] for p,n in zip(net[1],net[2],strict=True)]
    residual=[]
    for j in range(60):
        center=(a[j]*x for matrix,sigma in zip(op["S"],net[0],strict=True)
                  for a,x in zip(matrix,sigma,strict=True))
        gradient=(a[j]*x for matrix,d in zip(op["R"],delta,strict=True)
                    for a,x in zip(matrix,d,strict=True))
        gauges=(g*x for g,x in zip(op["G"][j],field,strict=True))
        residual.append(fsum((*center,*gradient,*gauges))-expected[j])
    weak=max(map(abs,residual[:56]))
    gauge=30000.*max(map(abs,residual[56:]))
    force=[[],[],[],[],[],[]]
    for (x,y,w),s in zip(geom,net[0],strict=True):
        n,xz,yz=w*s[2],w*s[4],w*s[5]
        for group,num in zip(force,(n,y*n,x*n,x*yz-y*xz,xz,yz),strict=True):
            group.append(num)
    force=list(map(fsum,force))
    caps=[area*(length if 1<=j<=3 else 1.) for j in range(6)]
    force_error=max(abs(a-b)/c for a,b,c in zip(force,demanded,caps,strict=True))
    tol=5e-7+5e-7*max(map(abs,expected))
    norm=max(weak,gauge,force_error)
    assert norm<=tol and abs(record["tolerance_MPa"]-tol)<2e-14
    assert abs(record["all_weak_and_force_max_MPa"]-norm)<3e-12
    assert abs(record["weak_norm_MPa"]-weak)<3e-12
    assert abs(record["gauge_scaled_norm_MPa"]-gauge)<3e-12
    assert max(abs(a-b) for a,b in zip(force,record["resultants_N_Nmm"],strict=True))<3e-8
    assert abs(1000.*field[3]/length-record["twist_rad_per_m"])<2e-17

    steel={}
    for family,first,last,yield_mpa in (("longitudinal",25,29,498.),("hoop",29,45,450.)):
        max_record=(-1.,None,None,None)
        for j in range(first,last):
            for side in (-1,0,1):
                strains=[fsum((a+side*.001*b)*f for a,b,f in zip(br,g,field,strict=True))
                        for br,g in zip(op["B"][j],op["Z"][j],strict=True)]
                stress=200000.*fsum(a*b for a,b in zip(strains,dirs[j],strict=True))
                item=(abs(stress)/yield_mpa,j+1,side,stress)
                if item[0]>max_record[0]:
                    max_record=item
        steel[family]={"yield_fraction":max_record[0],"point":max_record[1],"side":max_record[2],"stress_MPa":max_record[3]}
        assert max_record[0]<1.
    return {"resultants_N_Nmm":force,"weak_max_MPa":weak,"scaled_gauges_max_MPa":gauge,
            "normalized_six_resultant_max_MPa":force_error,"max_norm_MPa":norm,
            "tolerance_MPa":tol,"maximum_steel_use":steel}
