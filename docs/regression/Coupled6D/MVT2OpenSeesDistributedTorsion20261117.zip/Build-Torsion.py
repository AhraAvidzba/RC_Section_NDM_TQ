"""Pack native torsion proof, verifier and exact source using deterministic ZIP records."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parent
MANIFEST = ("Build-Torsion.py","Continuation-Pilot.md","MVT2PadsContinue.py","NonlinearDistributedContinue.json",
            "NonlinearDistributedContinue.stderr.log","NonlinearDistributedContinue.stdout.log","Torsion-Proof.md",
            "TorsionPadsReceipt.json","VerificationTorsionPads.json","Verify-Pads.py","Verify-Torsion.py")
OUT = ROOT / "MVT2OpenSeesDistributedTorsion20261117.zip"


def write_item(archive,name,body):
    item = ZipInfo(name,(2026,11,17,0,0,0))
    item.create_system = 3
    item.external_attr = 0o100644 << 16
    item.compress_type = ZIP_STORED
    archive.writestr(item,body)


def main():
    checksums = []
    with ZipFile(OUT,"w") as archive:
        for name in MANIFEST:
            payload = (ROOT/name).read_bytes()
            checksums.append(f"{sha256(payload).hexdigest()}  {name}\n")
            write_item(archive,name,payload)
        write_item(archive,"SHA256SUMS","".join(checksums).encode("ascii"))
    print(sha256(OUT.read_bytes()).hexdigest().upper())


if __name__ == "__main__":
    main()
