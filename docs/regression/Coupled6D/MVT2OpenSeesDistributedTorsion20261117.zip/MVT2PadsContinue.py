"""Replay the first three distributed MVT2 points, then probe pure torsion up to 10.51 kNm."""
import argparse
from hashlib import sha256
import json
from math import acos, cos, isfinite, pi, sqrt
from pathlib import Path
import subprocess
import sys
from time import monotonic
from types import SimpleNamespace


sys.dont_write_bytecode = True
import MVT2PadStartup as startup


HERE = Path(__file__).resolve().parent
ORIGINAL, RIG = startup.original, startup.RIG
BASE_SHA = "855850BA1E688D4FEF9C3E6C16908C8E66CE45996BCAD6DBD41ECC0B012C59D7"
RAW_SHA = "39BEF7A4038A921614EACE7FDDC0FE96F0942D19C9DDB812B6560A414B0F1717"
REFERENCE = HERE/"NonlinearDistributedStartup.json"
RESULT = HERE/"NonlinearDistributedContinue.json"
LEVELS = (.025,.05,.1,.2,.4,.65,1.)
ATTEMPT_CAP = 15
REPLAY_TOL = {"balance":5e-8,"displacement":1e-10,"materials":1e-12}


def replay_error(expected,actual,tol,path):
    if type(expected) is not type(actual):
        raise ValueError(f"Replay changed value type at {path}")
    if isinstance(expected,dict):
        if set(expected)!=set(actual):
            raise ValueError(f"Replay changed fields at {path}")
        return max((replay_error(v,actual[key],tol,f"{path}/{key}") for key,v in expected.items()),default=0.)
    if isinstance(expected,list):
        return max((replay_error(a,b,tol,f"{path}/{i}") for i,(a,b) in enumerate(zip(expected,actual,strict=True))),default=0.)
    if isinstance(expected,float):
        diff = abs(actual-expected)
        if not isfinite(diff) or diff>tol:
            raise ValueError(f"Replay changed {path} by {diff:.12g}, tolerance {tol}")
        return diff
    if expected!=actual:
        raise ValueError(f"Replay changed {path}: {expected} to {actual}")
    return 0.


def principal_extrema(s):
    x,y,z,xy,yz,xz = s
    mean = (x+y+z)/3.
    x,y,z = x-mean,y-mean,z-mean
    radius = sqrt((x*x+y*y+z*z+2.*(xy*xy+yz*yz+xz*xz))/6.)
    if radius==0.:
        return mean,mean
    x,y,z,xy,yz,xz = (value/radius for value in (x,y,z,xy,yz,xz))
    half_determinant = (x*y*z+2.*xy*yz*xz-x*yz*yz-y*xz*xz-z*xy*xy)/2.
    angle = acos(max(-1.,min(1.,half_determinant)))/3.
    return mean+2.*radius*cos(angle+2.*pi/3.),mean+2.*radius*cos(angle)


def stress_by_band(model):
    result = {}
    for layer in model.bricks:
        for tag,nodes in layer:
            xyz = [model.coords[node] for node in nodes]
            bounds = [(min(p[i] for p in xyz),max(p[i] for p in xyz)) for i in range(3)]
            for gp in range(1,9):
                stress = tuple(model.ops.eleResponse(tag,"material",gp,"stress"))
                if len(stress)!=6 or not all(map(isfinite,stress)):
                    raise ValueError(("Invalid ASD concrete stress tensor",tag,gp,stress))
                local = [RIG.GAUSS[((gp-1)//stride)%2] for stride in (4,2,1)]
                x,y,z = coords = tuple((lo+hi+(hi-lo)*xi)/2. for (lo,hi),xi in zip(bounds,local,strict=True))
                band = ORIGINAL.zone(z)
                location = "perimeter_25mm" if 120.-max(abs(x),abs(y))<25. else "interior"
                fields = result.setdefault(band,{}).setdefault(location,{})
                minimum,maximum = principal_extrema(stress)
                sxz,syz = stress[5],stress[4]
                targets = (("minimum_principal_MPa",minimum,-1.),("maximum_principal_MPa",maximum,1.),
                           ("maximum_abs_z_shear_MPa",sqrt(sxz*sxz+syz*syz),1.))
                for name,value,direction in targets:
                    if name not in fields or direction*value>direction*fields[name]["value"]:
                        fields[name] = {"value":value,"element":tag,"gauss":gp,"xyz_mm":coords,
                                        "signed_tensor_11_22_33_12_23_13_MPa":stress}
    return result


def inputs(opts):
    if sha256((HERE/"MVT2PadStartup.py").read_bytes()).hexdigest().upper()!=BASE_SHA or sha256(REFERENCE.read_bytes()).hexdigest().upper()!=RAW_SHA:
        raise ValueError("Frozen distributed startup source or native fields changed")
    loaded,meta = startup.inputs(opts)
    raw = json.loads(REFERENCE.read_bytes())
    receipt = [(item["observed_scale"],item["solver_code"],item["iterations"]) for item in raw["candidates"]]
    if receipt!=[(.025,0,3),(.05,0,2),(.1,0,3)] or len(raw["states"])!=3 or raw["termination"]!="bounded_run_budget":
        raise ValueError("Original accepted sequence not available")
    if max(abs(a-b) for a,b in zip(principal_extrema((0.,0.,0.,0.,0.,2.)),(-2.,2.),strict=True))>1e-12:
        raise ValueError("Pure shear check of signed stress tensor")
    meta.update(torque_knots_kNm=[x*RIG.TORQUE/1e6 for x in LEVELS],shear_knots_kN=[],max_attempts=ATTEMPT_CAP,
                replay_source_sha256=RAW_SHA,replay_component_absolute_tolerances=REPLAY_TOL,states=[],candidates=[],
                scope="exact cold replay followed by pure torsion only",replay_passed=False,
                detailed_concrete_stress="Gauss peak signed principal and z-shear by longitudinal and perimeter band")
    return loaded,meta,raw


def save(report):
    part = RESULT.with_suffix(".json.part")
    part.write_text(json.dumps(report,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    part.replace(RESULT)


def run(opts, geometry, report, reference):
    sys.path.insert(0,str(RIG.UTILITY.parent))
    import validate_opensees_hardshear as utility

    ops = utility.ops
    commands = ORIGINAL.MaterialCommands(ops,"default")
    deadline = monotonic()+opts.wall_seconds-15.
    model = startup.PadModel(geometry,SimpleNamespace(ops=commands,Prism=utility.Prism))
    ops.timeSeries("Linear",1)
    ops.pattern("Plain",1,1)
    for tag,force in geometry.torque_unit.items():
        ops.load(tag,*RIG.scale(RIG.TORQUE,force))
    ops.constraints("Transformation")
    ops.numberer("RCM")
    ops.system("UmfPack")
    ops.test("NormUnbalance",1e-5,12)
    ops.algorithm("Newton")
    ops.integrator("LoadControl",.1)
    ops.analysis("Static")
    report.update(termination="running",opensees_version=ops.version())
    save(report)

    def follow():
        for number,goal in enumerate(LEVELS):
            replay = number<3
            increment = goal-ops.getTime()
            while goal-ops.getTime()>2e-12:
                if monotonic()>=deadline or len(report["candidates"])>=ATTEMPT_CAP:
                    return "bounded_run_budget"
                prior = ORIGINAL.rollback_sample(model)
                step = min(increment,goal-prior[0])
                if step<.002:
                    return "step_floor_after_failed_equilibrium"
                ops.integrator("LoadControl",step)
                code = ops.analyze(1)
                arrived = ops.getTime()
                candidate = {"from_scale":prior[0],"attempted_scale":prior[0]+step,"observed_scale":arrived,
                             "code":code,"iterations":ops.testIter(),"replay":replay}
                report["candidates"].append(candidate)
                if code:
                    again = ORIGINAL.rollback_sample(model)
                    candidate.update(rollback_load_time_exact=again[0]==prior[0],rollback_all_nodes_exact=again[1]==prior[1],
                                     rollback_sampled_damage_exact=again[2]==prior[2])
                    save(report)
                    if replay:
                        return "replay_solver_mismatch"
                    if not (again[0]==prior[0] and again[1]==prior[1] and again[2]==prior[2]):
                        return "unverified_solver_rollback"
                    increment = step/2.
                    continue
                if abs(arrived-prior[0]-step)>1e-12:
                    return "committed_load_time_mismatch"
                balance = model.inspect(arrived*RIG.TORQUE,0.)
                displacement = startup.physical_displacements(model)
                row = {"load_scale":arrived,"replay":replay,"nominal_milestone":abs(arrived-goal)<=2e-12,
                       "rig_balance":balance,"displacement":displacement}
                if replay:
                    old = reference["states"][number]
                    if arrived!=goal or candidate["iterations"]!=reference["candidates"][number]["iterations"]:
                        return "replay_reference_iteration_or_load_mismatch"
                    material = ORIGINAL.field_summary(model)
                    comparisons = {"balance":(old["rig_balance"],balance),"displacement":(old["displacement"],displacement),
                                   "materials":({key:old[key] for key in material},material)}
                    row["replay_max_errors"] = {
                        key:replay_error(want,json.loads(json.dumps(have)),REPLAY_TOL[key],key)
                        for key,(want,have) in comparisons.items()}
                    row.update(material)
                    report["replay_passed"] = number==2
                report["states"].append(row)
                save(report)
                if not replay and row["nominal_milestone"]:
                    row.update(ORIGINAL.field_summary(model))
                    row["concrete_peak_stress_by_longitudinal_and_surface_band"] = stress_by_band(model)
                    save(report)
        return "pure_torsion_target_reached"

    try:
        report["termination"] = follow()
    except Exception as problem:
        report.update(termination="verification_or_engine_exception",detail=str(problem))
        raise
    finally:
        save(report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs",action="store_true")
    mode.add_argument("--start",action="store_true")
    mode.add_argument("--child",action="store_true",help=argparse.SUPPRESS)
    parser.add_argument("--wall-seconds",type=int,default=140)
    opts = parser.parse_args()
    if not 45<=opts.wall_seconds<=180:
        parser.error("Use 45–180 seconds.")
    loaded,report,reference = inputs(opts)
    if opts.check_inputs:
        print("MVT2_PADS_CONTINUATION_INPUTS_OK",json.dumps(report,allow_nan=False))
        return 0
    if RESULT.exists() or RESULT.with_suffix(".json.part").exists():
        raise FileExistsError(RESULT)
    if opts.child:
        run(opts,loaded,report,reference)
        print("MVT2_PADS_CONTINUATION",report["termination"],len(report["states"]),RESULT.name)
        return 0
    args = [sys.executable,"-B","-X","utf8",str(Path(__file__).resolve()),"--child","--wall-seconds",str(opts.wall_seconds)]
    with RESULT.with_suffix(".stdout.log").open("xb") as stdout,RESULT.with_suffix(".stderr.log").open("xb") as stderr:
        try:
            code = subprocess.run(args,stdout=stdout,stderr=stderr,timeout=opts.wall_seconds).returncode
        except subprocess.TimeoutExpired:
            print(f"MVT2_PADS_CONTINUATION_WATCHDOG {opts.wall_seconds}s; see {RESULT.name} if created")
            return 124
    print(f"MVT2_PADS_CONTINUATION_CLOSED code={code} result={RESULT.name}")
    return code


if __name__ == "__main__":
    sys.exit(main())
