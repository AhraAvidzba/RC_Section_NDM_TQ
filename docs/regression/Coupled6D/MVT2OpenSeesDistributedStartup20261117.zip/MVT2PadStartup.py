"""Short nonlinear startup control on the verified distributed MVT2 support."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace


HERE = Path(__file__).resolve().parent
BASE = HERE.parent
sys.dont_write_bytecode = True
sys.path.insert(0,str(BASE))
import MVT2DistributedPads as distributed
import MVT2NonlinearPilot as original


RIG = original.rig
BASE_MODEL = RIG.Model
BASE_PROBE = original.control_displacements
RECEIPTS = {
    HERE / "MVT2DistributedPads.py": "3B341EB7F76226C06303C5A4E24AEC76D9A8E4759017872A941F4E05B00E5136",
    HERE / "ElasticDistributedResult.json": "4A8CCD2FAE474DEC5923D7DD92EEBB1A446353E2A7F59D08D1E179D0972A2463",
    BASE / "MVT2NonlinearPilot.py": "D5E37F6DE0964AAF942DF541E77482AF4988C3CBC9E2F714A20CEAF0AB0B5E68",
}
INITIAL = (.025,.05,.1)
RESULT = HERE / "NonlinearDistributedStartup.json"


def physical_load_basis(geometry,pads,t,p):
    return distributed.combine_maps(*distributed.load_fields(geometry,pads,t,p))


class ForceGeometry:
    """Keeps original external loads available for force balance while assembling the pad forces once."""
    def __init__(self,raw,pads):
        self.raw,self.pads = raw,pads
        self.torque_unit = physical_load_basis(raw,pads,1.,0.)
        self.vertical_unit = physical_load_basis(raw,pads,0.,1.)


class PadModel(BASE_MODEL):
    """Preserves geometrically linear element kinematics and all four numerical gauge nodes."""
    def __init__(self,geometry,utility):
        super().__init__(geometry.raw,utility)
        self.pads = geometry.pads
        self.gauge_rotation = None

    def inspect(self,t,p):
        state = distributed.inspect(self,self.pads,t,p)
        self.gauge_rotation = tuple(state["recovered_kinematics"]["gauge_rotation_about_x_and_z_rad"])
        return state


def physical_displacements(model):
    if model.gauge_rotation is None:
        raise ValueError("Missing validated rigid correction")

    def node_disp(tag):
        correction = distributed.rigid_displacement(model.coords[tag],*model.gauge_rotation)
        return RIG.combine(model.ops.nodeDisp(tag),correction)

    return BASE_PROBE(SimpleNamespace(geometry=model.geometry,ops=SimpleNamespace(nodeDisp=node_disp)))


def inputs(opts):
    for path,sha in RECEIPTS.items():
        if sha256(path.read_bytes()).hexdigest().upper() != sha:
            raise ValueError(f"Unqualified input {path.name}")
    opts.variant = "default"
    opts.max_attempts = len(INITIAL)
    opts.seconds = opts.wall_seconds-15.
    original.TORQUE_KNOTS = (*INITIAL,*original.TORQUE_KNOTS)
    geometry,meta = original.inputs(opts)
    pads = (distributed.pad_weights(geometry,-96.,-120.),distributed.pad_weights(geometry,96.,120.))
    distributed.precision_basis(geometry,pads)
    loaded = ForceGeometry(geometry,pads)
    for field in (loaded.torque_unit,loaded.vertical_unit):
        RIG.require_balance("assembled pure load and both support reactions",geometry.sum_wrench(field,1100.),(0.,)*6,1e-10)
    meta.update(support_mode="opposed weighted traction pads with six zero-reaction gauges",
                asd_linearization="numerical tangent", scaled_start_levels=INITIAL,
                max_attempts=opts.max_attempts, Newton_iteration_cap=12, norm_unbalance_force=1e-5,
                kinematics="infinitesimal and geometrically linear",pad_xz_size_mm=[48.,80.],
                validated_input_sha256={path.name:sha for path,sha in RECEIPTS.items()})
    return loaded,meta


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs",action="store_true")
    mode.add_argument("--start",action="store_true")
    mode.add_argument("--child",action="store_true",help=argparse.SUPPRESS)
    parser.add_argument("--wall-seconds",type=int,default=90)
    opts = parser.parse_args()
    if not 30<=opts.wall_seconds<=120:
        parser.error("Use 30–120 watchdog seconds.")
    loaded,meta = inputs(opts)
    if opts.check_inputs:
        print("MVT2_DISTRIBUTED_STARTUP_INPUTS_OK",json.dumps(meta,allow_nan=False))
        return 0
    if RESULT.exists() or RESULT.with_suffix(".json.part").exists():
        raise FileExistsError(RESULT)
    if opts.child:
        RIG.Model = PadModel
        original.control_displacements = physical_displacements
        original.run(opts,loaded,RESULT,meta)
        if any(row["rig_balance"]["P_N"] != 0. for row in meta["states"]):
            raise ValueError("Startup control reached an unauthorized phase")
        print("MVT2_DISTRIBUTED_STARTUP",meta["termination"],len(meta["states"]),RESULT.name)
        return 0
    argv = [sys.executable,"-B","-X","utf8",str(Path(__file__).resolve()),"--child","--wall-seconds",str(opts.wall_seconds)]
    with RESULT.with_suffix(".stdout.log").open("xb") as stdout, RESULT.with_suffix(".stderr.log").open("xb") as stderr:
        try:
            code = subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=opts.wall_seconds).returncode
        except subprocess.TimeoutExpired:
            print(f"MVT2_DISTRIBUTED_STARTUP_WATCHDOG {opts.wall_seconds}s; see {RESULT.name} if created")
            return 124
    print(f"MVT2_DISTRIBUTED_STARTUP_CLOSED code={code} result={RESULT.name}")
    return code


if __name__ == "__main__":
    sys.exit(main())
