"""Pack the distributed nonlinear startup control and detached comparison."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
MANIFEST = ("Build-StartupPads.py","MVT2PadStartup.py","NonlinearDistributedStartup.json","NonlinearDistributedStartup.stderr.log",
            "NonlinearDistributedStartup.stdout.log","Startup-Comparison.md","Startup-Pilot.md","StartupPadsReceipt.json",
            "VerificationStartupPads.json","Verify-Pads.py","Verify-StartupPads.py")
OUT = HERE / "MVT2OpenSeesDistributedStartup20261117.zip"


def add(archive,name,payload):
    entry = ZipInfo(name,(2026,11,17,0,0,0))
    entry.create_system = 3
    entry.external_attr = 0o100644 << 16
    entry.compress_type = ZIP_STORED
    archive.writestr(entry,payload)


def main():
    checksums = []
    with ZipFile(OUT,"w") as archive:
        for name in MANIFEST:
            payload = (HERE/name).read_bytes()
            checksums.append(f"{sha256(payload).hexdigest()}  {name}\n")
            add(archive,name,payload)
        add(archive,"SHA256SUMS","".join(checksums).encode("ascii"))
    print(sha256(OUT.read_bytes()).hexdigest().upper())


if __name__ == "__main__":
    main()
