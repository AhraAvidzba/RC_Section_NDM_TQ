"""Compare the nonlinear distributed MVT2 startup against the pinned point and elastic controls."""
import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
POINT = "EE2B69A04C7E60FF20664B372BEDF249936BBE461EFBB4216F3FB9FD5B3CD459"
ELASTIC = "807E5B0B7EAEEB11D2159C10B0EA2D07C18FFF6A6E72616FFBE2324678271E89"
INPUTS = {
    "NonlinearDistributedStartup.json":"39BEF7A4038A921614EACE7FDDC0FE96F0942D19C9DDB812B6560A414B0F1717",
    "NonlinearDistributedStartup.stdout.log":"A844DD0189722891CB9A06824F04A4E6567AE7671529618252164E18EED05900",
    "NonlinearDistributedStartup.stderr.log":"CB6EC5631D05EBCF718EF918A32E942A653B946B22C84A782976EE5CE5A02154",
    "MVT2PadStartup.py":"855850BA1E688D4FEF9C3E6C16908C8E66CE45996BCAD6DBD41ECC0B012C59D7",
}


def require(condition,label):
    if not condition:
        raise ValueError(label)


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def material(state):
    local = {}
    for band in ("reinforced_end","support_band","central_clear","load_band"):
        concrete = state["concrete_damage_by_station_band"][band]
        damage = {mode:concrete[mode]["damage"] for mode in ("tension","compression")}
        require(damage == {"tension":0.,"compression":0.},f"zero recorded damage in {band}")
        steel = state["steel_signed_extrema_by_band"][band]
        stresses = {}
        for kind,surfaces in steel.items():
            ordered = [surfaces[limit]["axial_strain"] for limit in ("min","max")]
            limit = .00249 if kind=="long" else .00225
            require(all(surfaces[side]["yield_strain_magnitude"]==limit for side in ("min","max")),"experimental steel strengths")
            require(-limit<ordered[0]<=ordered[1]<limit,"all sampled bar strains elastic")
            stresses[kind] = {side:{"stress_MPa":200_000.*surfaces[side]["axial_strain"],"z_mm":surfaces[side]["z_mm"],
                                      "tag":surfaces[side]["tag"]} for side in ("min","max")}
        local[band] = {"measured_damage_max":damage,"signed_elastic_steel_stress_extrema":stresses}
    return local


def verify(point,elastic):
    require(digest(point)==POINT and digest(elastic)==ELASTIC,"pinned earlier archives")
    for name,sha in INPUTS.items():
        require(digest(HERE/name)==sha,f"identity of {name}")
    terminal = json.loads((HERE/"StartupPadsReceipt.json").read_bytes())
    require(terminal=={"outer_tool_exit_code":0,"outer_tool_stdout":"MVT2_DISTRIBUTED_STARTUP_CLOSED code=0 result=NonlinearDistributedStartup.json"},"outer process closure")
    with ZipFile(elastic) as saved:
        verified_elastic = json.loads(saved.read("VerificationPads.json"))
        require(verified_elastic["checks"]=="PASS" and len(verified_elastic["states"])==4,"earlier four elastic steps")
        require(sha256((HERE/"Verify-Pads.py").read_bytes()).digest()==sha256(saved.read("Verify-Pads.py")).digest(),"independent balance routine identity")
    spec = spec_from_file_location("distributed_equilibrium",HERE/"Verify-Pads.py")
    pads = module_from_spec(spec)
    spec.loader.exec_module(pads)
    with ZipFile(point) as saved:
        pt = json.loads(saved.read("Startup-tangent.json"))
        proof_point = json.loads(saved.read("VerificationStartup.json"))
    require(proof_point["checks"]=="PASS" and not proof_point["physical_limit_established"],"independent point startup receipt")
    raw = json.loads((HERE/"NonlinearDistributedStartup.json").read_bytes())
    require(raw["termination"]=="bounded_run_budget" and not raw["physical_limit_established"] and raw["opensees_version"]==pt["opensees_version"]=="3.8.0","same runtime and phase scope")
    require(raw["scaled_start_levels"]==pt["scaled_start_levels"]==[.025,.05,.1] and raw["max_attempts"]==pt["max_attempts"]==3,"shared step and attempt protocol")
    for key in ("E_MPa","nu","fc_MPa","ft_MPa","steel_E_MPa","steel_yield_MPa","steel_post_yield_slope_MPa","norm_unbalance_force","Newton_iteration_cap","elastic_rig_sha256","elastic_result_sha256","integrator_sha256"):
        require(raw[key]==pt[key],f"same {key}")
    require(raw["asd_linearization"]=="numerical tangent" and pt["asd_linearization"]=="tangent" and pt["cut_balance_N_equivalent"]==.05,"same tangent and cut tolerance")
    require(b"bounded_run_budget 3 NonlinearDistributedStartup.json" in (HERE/"NonlinearDistributedStartup.stdout.log").read_bytes(),"child completion marker")
    observed = []
    prior = 0.
    for attempt,state,target,iterations in zip(raw["candidates"],raw["states"],(.025,.05,.1),(3,2,3),strict=True):
        require(attempt=={"phase":"torsion","from_scale":prior,"attempted_scale":target,"observed_scale":target,
                          "solver_code":0,"iterations":iterations},"uninterrupted exact replayable startup history")
        require(state["phase"]=="torsion" and state["nominal_milestone"],"full concrete station survey was requested")
        balance = pads.verify_state(state["rig_balance"],target*10510000.,0.)
        balance.update(iterations=iterations,clear_twist_rad_per_m=state["displacement"]["clear_twist_rad_per_m"],materials=material(state))
        observed.append(balance)
        prior = target
    pt_match = pt["states"][0]
    pt_turn = pt_match["displacement"]["clear_twist_rad_per_m"]
    dist_turn = observed[0]["clear_twist_rad_per_m"]
    require(pt_match["rig_balance"]["T_Nmm"]==262750. and observed[0]["T_kNm"]==.26275,"exact common torque")
    return {"checks":"PASS","outer_closure":terminal,"distributed_accepted":observed,
            "point_accepted_kNm":[row["rig_balance"]["T_Nmm"]/1e6 for row in pt["states"]],
            "point_rejected_scale":[row["attempted_scale"] for row in pt["candidates"] if row["solver_code"]],
            "matched_T_0_26275_kNm":{"point_twist_rad_per_m":pt_turn,"distributed_twist_rad_per_m":dist_turn,
                                    "relative_twist_difference":{k:abs(dist_turn[k]/pt_turn[k]-1.) for k in pt_turn},
                                    "point_materials":material(pt_match)},
            "concrete_stress_tensor_available":False,"physical_limit_established":False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("point",type=Path)
    parser.add_argument("elastic",type=Path)
    parser.add_argument("--out",type=Path)
    opts = parser.parse_args()
    proof = verify(opts.point,opts.elastic)
    if opts.out:
        opts.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True,allow_nan=False)+"\n").encode("utf-8"))
    print("MVT2_DISTRIBUTED_STARTUP_DETACHED_PASS",len(proof["distributed_accepted"]),len(proof["point_accepted_kNm"]))


if __name__ == "__main__":
    main()
