"""Воспроизводит проверку двух нативных проб MVT2 без запуска Excel."""

import argparse
import json
from hashlib import sha256
from pathlib import Path


here = Path(__file__).resolve().parent
expected = "2FA20A8E01119EC497963A34FDC6597110C42761A08353493826A348CEA3B980"
installed = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"


def digest(data):
    return sha256(data).hexdigest().upper()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook", type=Path)
    args = parser.parse_args()
    checksums = json.loads((here / "SHA256SUMS.json").read_bytes())
    for name, fingerprint in checksums.items():
        assert digest((here / name).read_bytes()) == fingerprint, name
    if args.workbook is not None:
        assert digest(args.workbook.read_bytes()) == installed
    verifier = here / "Verify-MVT2ShearControlled.py"
    source = verifier.read_text(encoding="utf-8")
    book_line = '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]'
    assert source.count(book_line) == 1
    source = source.replace(book_line, f'    assert prep["book_sha256"] == "{installed}"')
    scope = {"__name__": "archive_replay", "__file__": str(verifier)}
    exec(compile(source, str(verifier), "exec"), scope)
    result = scope["verify"](*scope["prepare"]())
    assert digest((json.dumps(result, indent=2) + "\n").encode("utf-8")) == expected
    assert [result["outcomes"][name]["internal_status"] for name in ("Stock", "Branch")] == [6, 6]
    assert result["accepted_field_exact"] and result["accepted_stresses_and_damage_energy_snapshot_exact"]
    print("MVT2 STOCK AND BRANCH NATIVE PASS", expected)


if __name__ == "__main__":
    assert __debug__
    main()
