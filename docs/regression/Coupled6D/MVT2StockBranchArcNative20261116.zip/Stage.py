"""Готовит сравнение штатной и согласованной касательных на одной псевдодуге."""

import json
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[1]
old = root.parent / "mvt-next/arc-ab"
arc = root.parent / "arcv"
book = "workbook/output/RC_Section_NDM.xlsm"
solver = "src/Solver/CCoupledNewtonSolver.cls"
test = "tests/modTestCoupledExperiment.bas"
runner = "Run-MVT2ShearControlled.ps1"
validator = "Verify-MVT2ShearControlled.py"


def digest(data):
    return sha256(data).hexdigest().upper()


def put(name, data):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        path.write_bytes(data)
    return digest(data)


def replace(text, left, right):
    assert text.count(left) == 1, left
    return text.replace(left, right)


def crlf(text):
    return text.strip().replace("\n", "\r\n").encode("utf-8") + b"\r\n"


base = (repo / book).read_bytes()
assert digest(base) == "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
assert digest((repo / solver).read_bytes()) == "2A091D6AEE33AF66E02D78BD466C02EF0E945A78609653358F66E402E66A99A9"
frozen = json.loads((old / "Preparation.json").read_bytes())
inputs = {}
for name in ("Replay.csv", "VerifyBase.py", "Guard-IsolatedOffice.ps1", "MVTHistory.json", "MVTNormal.csv", "JetNative.csv", runner,
             *(name for name in frozen["inputs"] if name.startswith("tools/"))):
    data = (old / name).read_bytes()
    assert digest(data) == frozen["inputs"][name]
    inputs[name] = put(name, data)
put(book, base)
put("docs/regression/Diagnostic.xlsm", base)
for folder in ("Temp", "NativeCompare"):
    (root / folder).mkdir(exist_ok=True)

# Метод плоскости, уже проверенный на текущих уравнениях равновесия.
spec = spec_from_file_location("arc_vba", arc / "Prepare.py")
engine = module_from_spec(spec)
spec.loader.exec_module(engine)
overlay = engine.compose_newton()
inputs[solver] = put(solver, crlf(overlay))
assert "Private Function ReadDirectScreen(ByRef field()" in overlay

control = (old / test).read_text(encoding="utf-8-sig")
start = control.index('    For Each mode In Array("Force", "PseudoArc")')
end = control.index('        elapsed = Timer - started:', start)
saved_calls = control[start:end]
first = saved_calls.index('        If mode = "Force" Then')
control = control[:start] + saved_calls[:first].replace('Array("Force", "PseudoArc")', 'Array("Stock", "Branch")') + '''        solved = solver.TryDeformationStep(baseLoad, direction, projection, planeTarget, qTrial, lambda, _
            ABS_TOL, REL_TOL, MAX_ITERATIONS, consistentControl:=(mode = "Branch"), initialField:=seed, loadProjection:=loadProjection)
''' + control[end:]
inputs[test] = put(test, crlf(control))

verify = (old / validator).read_text(encoding="utf-8")
verify = replace(verify, 'labels = ("Force", "PseudoArc")', 'labels = ("Stock", "Branch")')
start = verify.index('    arc = v.read(here / "ArcFixture.json")')
end = verify.index('    assert v.digest(here / "Replay.csv")', start)
verify = verify[:start] + verify[end:]
verify = replace(verify, '{"Before", "ReplayForce", "ReplayPseudoArc", "AfterForce", "AfterPseudoArc", "Final"}',
                 '{"Before", "ReplayStock", "ReplayBranch", "AfterStock", "AfterBranch", "Final"}')
verify = verify.replace('            if name == "Force":\n                assert lam == qy_trial\n', '')
verify = verify.replace('            if name == "PseudoArc":\n                assert control_error <= sample["tol_MPa"] + 4e-10\n',
                        '            assert control_error <= sample["tol_MPa"] + 4e-10\n')
precision = (old / "ReplayPrecision.py").read_text(encoding="utf-8")
verify = replace(verify, 'import argparse\n', 'import argparse\nfrom decimal import Decimal, localcontext\n')
verify = replace(verify, 'def rows(name):', precision[precision.index('def normal_wire_precision('):precision.index('def main():')] + 'def rows(name):')
verify = replace(verify, '    assert v.peak(v.diff(v.vec(tags, "B_ARC_PROJECTION")["Normal"], p)) < 3e-17',
                 '    wire_precision = normal_wire_precision(tags, p)')
verify = replace(verify, '"same_initial_field": True,', '"projection_wire_precision": wire_precision, "same_initial_field": True,')
verify = replace(verify, '"physical_arc_norm_over_nominal_step": physical_length / ds,',
                 '"physical_arc_norm_over_nominal_step": physical_length / ds, "within_local_radius": physical_length <= 3 * ds,')
inputs[validator] = put(validator, verify.encode("utf-8"))
inputs["Stage.py"] = digest((root / "Stage.py").read_bytes())
record = {"inputs": inputs, "book_sha256": digest(base), "replay_sha256": frozen["replay_sha256"], "watchdog_seconds": 110}
print(put("Preparation.json", (json.dumps(record, indent=2) + "\n").encode("utf-8")))
