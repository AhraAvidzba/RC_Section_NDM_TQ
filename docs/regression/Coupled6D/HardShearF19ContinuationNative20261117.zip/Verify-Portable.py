"""Повторяет проверку полей, путей, интервалов и подтверждённого закрытия Excel."""

import json
from pathlib import Path
from subprocess import PIPE, run
import sys

import FineVerify as fine
import PriorVerify as prior
import Verify as native


HERE = Path(__file__).resolve().parent
NATIVE = '48E5B874F9BDC62B87EC9AC3240C295674FE23C6C81D7F9E45FA36F9E1D7838D'


def analysis():
    folder = HERE/'Native/Order10'
    result = prior.read(folder/'Verification.json')
    tags, points, snapshots, rows = native.parse(folder/'HardF19.csv')
    plan = prior.read(HERE/'Fixture.json')
    area, length, modulus, _ = prior.verify_geometry(plan,10,tags,points)
    direction,projection = (prior.numbers(tags[k]) for k in ('DIRECTION','PROJECTION'))
    for sample in rows:
        fine.verify_row(sample,projection,direction,area,length,modulus)
    _,_,old = fine.parse(HERE/'Prior/HardFineResume.csv')
    original = old[-1]
    replay = rows[19:]
    first = replay[0]
    accepted = [row for row in replay if row['ready']]
    best = max(accepted,key=lambda row:row['factor'])
    anchor = rows[18]
    assert original['label'] == 'F20' and not original['ready']
    assert first['label'] == 'G1' and first['control'] == original['control'] and first['SEED'] == original['SEED']
    assert first['seed_factor'] == original['seed_factor'] and original['SOLVER'][-1] in first['SOLVER'][-1]
    assert first['RECOVERY'] == ['True','True','False'] and not first['ready']
    assert result['exact_prefix_fields'] == 19 and len(result['history_snapshots']) == 3
    assert all(row['values'] == 9744 and row['bit_identical'] for row in result['history_snapshots'].values())
    assert len(replay) == 14 and len(accepted) == 6 and result['outcome'] == 'MINIMUM_STEP'
    assert all(not row['ready'] for row in replay if row['RECOVERY'][0] == 'True')
    assert not result['first_same_F20'] and result['first_beyond_F20'] is None and best['coordinate'] < first['control']
    assert result['positive_intervals'] == result['negative_intervals'] == 0
    net = fine.derivative(anchor,best)
    assert net['sign'] == 1 and all(term['sign'] == 0 for term in result['secants'])
    return {'exact_first_F20_attempt':native.report_row(first),'smallest_accepted_step_c': min(b['coordinate']-a['coordinate'] for a,b in zip([anchor]+accepted[:-1],accepted,strict=True)),
            'accepted_history_values':result['history_snapshots'],'largest_verified_sample':native.report_row(best),
            'largest_sample_lambda_interval':[best['factor']-best['uncertainty'],best['factor']+best['uncertainty']],
            'unreached_control_distance':first['control']-best['coordinate'],
            'adjacent_slope_intervals':result['secants'],'aggregate_slope_interval':net,'outcome':result['outcome'],
            'physical_limit_certified':False}


def main():
    manifest = prior.read(HERE/'SHA256SUMS.json')
    files = {path.relative_to(HERE).as_posix() for path in HERE.rglob('*') if path.is_file()}
    assert files == set(manifest)|{'SHA256SUMS.json'}
    for name,value in manifest.items():
        assert not name.lower().endswith('.xlsm') and prior.file_hash(HERE/name) == value
    plan = prior.read(HERE/'Fixture.json')
    for name,value in plan['production'].items():
        assert prior.file_hash(HERE/'Production'/name) == value
    report = HERE/'Native/Order10/Verification.json'
    assert prior.file_hash(report) == NATIVE
    closed = prior.read(report.with_name('HardShear.txt.ProcessClosure.json'))
    assert closed['Passed'] and closed['ChildExitCode'] == 0 and not closed['OrdinaryPathKilledAnything']
    assert closed['Closure']['FinalState']['State'] == 'Absent'
    reply = run([sys.executable,'-B','-X','utf8','Verify.py','--order','10'],cwd=HERE,stdout=PIPE,check=True)
    print(reply.stdout.decode('utf-8').strip())
    print(json.dumps(analysis(),indent=2,ensure_ascii=False))
    print('HARDSHEAR_F19_PORTABLE: VERIFIED_EVIDENCE; MINIMUM_STEP; physical_limit_certified=False')


if __name__ == '__main__':
    main()
