"""Собирает изолированное продолжение HardShear от подтверждённого F19."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = REPO / "docs/regression/Coupled6D/HardShearFineResumeNative20261117.zip"
BASE_SHA = "9143FD1E28C70100FB5EC631D5E8C87A4D2D6BA8C3416B5F09BCFA834B2E7DF4"
REPORT_SHA = "94A3EAD5FDF54784BF7915BB7A16040A5A8A671681CB1E379FCDA5AF138E6BC0"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
SOLVER = "src/Solver/CCoupledNewtonSolver.cls"
CONCRETE = "src/Materials/CCoupledConcreteResponse.cls"
REBAR = "src/Materials/CCoupledReinforcedResponse.cls"
TEST = "tests/modTestCoupledElasticState.bas"
FIELDS = ("FIELD", "TARGET", "ACTUAL", "RESIDUAL", "BALANCE", "CONTROL", "SEED")


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode("utf-8-sig").replace("\r\n", "\n")


def encoded(source):
    assert max(map(len, source.splitlines())) < 1024
    return (source.rstrip().replace("\n", "\r\n") + "\r\n").encode("utf-8")


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def seal(directory, path, raw):
    target = directory / path
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, path
    else:
        target.write_bytes(raw)
    return sha(raw)


def data(raw):
    prior = {}
    fields = []
    current = None
    rows = raw.decode("cp1251").splitlines()
    assert rows[0] == "HARDSHEAR-FINE-RESUME;1"
    for line in rows[1:]:
        name, *parts = line.split(";")
        if name in ("OFFSET", "DIRECTION", "PROJECTION"):
            assert name not in prior
            prior[name] = parts
        elif name == "BEGIN":
            assert current is None and parts[3] == "True"
            current = {"label": parts[0], "control": parts[1], "estimate": parts[2]}
        elif name == "END":
            assert current is not None and current["label"] == parts[0]
            if parts[1] == "True":
                assert set(FIELDS) <= set(current)
                fields.append(current)
            elif parts[0] == "F20":
                assert "FIELD" not in current
                prior["failed_F20"] = current
            current = None
        elif current is not None and name in (*FIELDS, "SOLVER"):
            assert name not in current
            current[name] = parts
    expected = ("P1", "P2", "P3", "P4", "P5", "I6", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F9", "F12", "F15", "F17", "F18", "F19")
    assert tuple(s["label"] for s in fields) == expected
    assert prior["failed_F20"]["SOLVER"][0] == "False"
    return fields, prior


def vectors(tokens, name):
    payload = ''.join(tokens)
    assert len(payload) == 960
    chunks = [payload[i:i+192] for i in range(0, 960, 192)]
    return '\n'.join([f'    packed = "{chunks[0]}"', *(f'    packed = packed & "{c}"' for c in chunks[1:]),
                      f'    HardRankUnpackTest packed, {name}']) + '\n'


def test_source(inherited, expected):
    code = text(inherited)
    code = once(code, "HARDSHEAR-FINE-RESUME;1", "HARDSHEAR-F19;1")
    code = once(code, "HardFineResume.csv", "HardF19.csv")
    signature = code.index("Public Function ReplayHardYieldGateTest(")
    start = code.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, signature)
    end = code.index("\nEnd Function", signature) + len("\nEnd Function")
    body = '''' -------------------- ДЛЯ ТЕСТОВ --------------------
' Закрепляет только фактически принятые поля 100-точечной ветви до F19.
Public Function ReplayHardYieldGateTest(ByVal solver As CCoupledNewtonSolver, ByRef offset() As Double, _
        ByRef direction() As Double) As Boolean
    Dim history As New Collection, field() As Double, projection() As Double, packed As String
    Dim controls(1 To 19) As Double, factors(1 To 19) As Double, labels(1 To 19) As String
'''
    for idx, row in enumerate(expected["fields"], 1):
        body += vectors(row["FIELD"], "field")
        body += '    history.Add field\n'
        body += f'    controls({idx}) = HardRankValueTest("{row["control"]}")\n'
        body += f'    factors({idx}) = HardRankValueTest("{row["BALANCE"][0]}")\n'
        body += f'    labels({idx}) = "{row["label"]}"\n'
    body += vectors(expected["prior"]["PROJECTION"], "projection")
    body += '    ReplayHardYieldGateTest = solver.TraceHardFineResumeTest(history, controls, factors, labels, projection, _\n'
    body += f'        {expected["max_control"]:.17g}#, HardRankValueTest("{expected["prior"]["failed_F20"]["control"]}"), offset, direction)\nEnd Function'
    body.encode("cp1251")
    return encoded(code[:start] + body + code[end:])


def solver_source(inherited):
    source = text(inherited)
    source = once(source, 'ByRef factors() As Double, ByRef projection() As Double, ByVal maxControl As Double, _\n',
                  'ByRef factors() As Double, ByRef labels() As String, ByRef projection() As Double, _\n'
                  '        ByVal maxControl As Double, ByVal firstTarget As Double, _\n')
    source = once(source, '    Const MAX_PROBES As Long = 20\n',
                  '    Const MAX_PROBES As Long = 36, SOFT_SECONDS As Double = 205#\n'
                  '    Dim started As Double: started = Timer\n')
    source = once(source, 'Or history.Count <> 6 Then Exit Function', 'Or history.Count <> 19 Then Exit Function')
    source = once(source, '    For index = 1 To history.Count\n        expected = history(index): seed = expected\n'
                          '        If index < history.Count Then label = "P" & CStr(index) Else label = "I6"\n',
                  '    Dim saved As New Collection, historyState() As Double\n'
                  '    For index = 1 To history.Count\n        expected = history(index): seed = expected: label = labels(index)\n')
    source = once(source, 'seed, acceptedControl, lambda, True, index >= 5)',
                  'seed, acceptedControl, lambda, True, index = history.Count)')
    source = once(source, '        If index = 5 Then\n            CopyAccepted prior\n',
                  '        If index = 5 Or index = 6 Or index = history.Count Then\n'
                  '            ReadHardF19HistoryTest historyState: saved.Add historyState\n'
                  '        End If\n'
                  '        If index = history.Count - 1 Then\n            CopyAccepted prior\n')
    source = once(source, '    CopyAccepted current\n    acceptedLambda = lambda\n',
                  '    If Not CheckHardF19HistoryTest(history, saved) Then\n'
                  '        WriteHardRankRowTest "FINISH;HISTORY_REFUSED;19;0;0"\n'
                  '        TraceHardFineResumeTest = True\n        Exit Function\n    End If\n'
                  '    CopyAccepted current\n    acceptedLambda = lambda\n')
    source = once(source, '    nominal = (acceptedControl - priorControl) / 16#: minimum = nominal / 64#: maximum = nominal * 4#\n',
                  '    nominal = firstTarget - acceptedControl: minimum = nominal / 128#: maximum = nominal * 16#\n'
                  '    If nominal <= 0# Then Exit Function\n')
    source = once(source, 'HardRankBitsTest(maximum) & ";" & HardRankBitsTest(maxControl) & ";" & CStr(MAX_PROBES)',
                  'HardRankBitsTest(maximum) & ";" & HardRankBitsTest(maxControl) & ";" & CStr(MAX_PROBES) & ";" & _\n'
                  '        HardRankBitsTest(SOFT_SECONDS)')
    source = once(source, '    For probe = 1 To MAX_PROBES\n        target = GeomMin(maxControl, acceptedControl + increment)\n',
                  '    For probe = 1 To MAX_PROBES\n'
                  '        If HardF19ElapsedTest(started) >= SOFT_SECONDS Then\n'
                  '            reason = "TIME_BOUND": Exit For\n        End If\n'
                  '        target = GeomMin(maxControl, acceptedControl + increment)\n'
                  '        If probe = 1 Then target = firstTarget\n')
    source = once(source, 'TryHardFinePointTest("F" & CStr(probe)', 'TryHardFinePointTest("G" & CStr(probe)')
    source = once(source, '    WriteHardRankRowTest "FINISH;" & reason & ";6;"', '    WriteHardRankRowTest "FINISH;" & reason & ";19;"')
    source = once(source, 'ABS_TOLERANCE, REL_TOLERANCE, ITERATIONS, consistentControl:=True, initialField:=seed)\n',
                  'ABS_TOLERANCE, REL_TOLERANCE, ITERATIONS, consistentControl:=True, _\n'
                  '        recoverSameControl:=Not replay, initialField:=seed)\n'
                  '    WriteHardRankRowTest "RECOVERY;" & CStr(mSameControlRecoveryTried) & ";" & _\n'
                  '        CStr(mWrongControlDirection) & ";" & CStr(mRecoveredControlReady)\n')
    source = once(source, '        verified = trialFactor > 0# And norm <= tolerance And GaugesVerified(tolerance) And _\n'
                          '            Abs(ControlResidual(current)) <= tolerance\n',
                  '        verified = trialFactor > 0# And norm <= tolerance And GaugesVerified(tolerance) And _\n'
                  '            Abs(ControlResidual(current)) <= tolerance And mTargetControl = target And Not mRecoveredControlReady\n'
                  '        For i = 1 To mDegreeCount\n'
                  '            If mControlProjection(i) <> projection(i) Then verified = False\n'
                  '        Next i\n')
    source += '\n' + text((HERE / "History.bas").read_bytes())
    return encoded(source)


def concrete_source(stock):
    extra = (REPO / 'tmp/mvbridge-neg/InspectConcrete.txt').read_text(encoding='utf-8-sig')
    extra = extra.replace('CopyArcConcreteHistoryTest', 'CopyHardF19ConcreteHistoryTest')
    extra = once(extra, 'ReDim values(1 To 2 + POINT_WIDTH * mPointCount)\n    values(1) = mCommitted: values(2) = mTrialEpoch\n    position = 2',
                 'ReDim values(1 To 1 + POINT_WIDTH * mPointCount)\n    values(1) = mCommitted\n    position = 1')
    extra.encode('cp1251')
    return encoded(text(stock).rstrip() + '\n\n' + extra)


def steel_source(inherited):
    extra = (REPO / 'tmp/mvbridge-neg/InspectSteel.txt').read_text(encoding='utf-8-sig')
    start = extra.index('Friend Sub CopyArcSteelHistoryTest')
    extra = extra[extra.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, start):].replace('CopyArcSteelHistoryTest', 'CopyHardF19SteelHistoryTest')
    getter = (REPO / 'tmp/hs-yield-tol/Reinforcement.bas').read_text(encoding='utf-8-sig').replace('HardYieldConcreteTest', 'HardF19ConcreteTest')
    (extra + getter).encode('cp1251')
    return encoded(text(inherited).rstrip() + '\n\n' + extra + '\n' + getter)


def runner(old):
    script = text(old)
    script = once(script, "$modules=@('CCoupledSectionAnalysis'", "$modules=@('CCoupledConcreteResponse','CCoupledSectionAnalysis'")
    script = once(script, "PRIVATE_CODE_READY: modules=4;", "PRIVATE_CODE_READY: modules=5;")
    return script.replace('HardFineResume.csv', 'HardF19.csv').replace('HardFineResume\'', 'HardF19\'').encode('utf-8')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--destination', type=Path, default=HERE / 'ready')
    cli.add_argument('--with-workbook', action='store_true')
    args = cli.parse_args()
    dest = args.destination.resolve()
    assert dest.is_relative_to(HERE) or dest.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(BASE.read_bytes()) == BASE_SHA
    added = {}
    with ZipFile(BASE) as package:
        frozen = json.loads(package.read('Fixture.json'))
        source = (REPO / frozen['workbook']).read_bytes()
        assert sha(source) == frozen['source_workbook_sha256'] == BOOK_SHA
        native = package.read('Native/Order10/Verification.json')
        trace = package.read('Native/Order10/HardFineResume.csv')
        assert sha(native) == REPORT_SHA and json.loads(native)['native_trace_sha256'] == sha(trace)
        fields, prior = data(trace)
        initial = json.loads(package.read('Expected.json'))
        expected = {'fields': fields, 'prior': prior, 'max_control': initial['max_control'], 'max_probes': 36,
                    'soft_seconds': 205., 'deviation_factor': 3.}
        added['Expected.json'] = seal(dest, 'Expected.json', (json.dumps(expected,indent=2) + '\n').encode('utf-8'))
        for name, raw in (('Prior/HardFineResume.csv',trace), ('Prior/Verification.json',native), ('PriorVerify.py',package.read('PriorVerify.py')),
                          ('FineVerify.py',package.read('Verify.py'))):
            added[name] = seal(dest,name,raw)
        for path, digest in frozen['inputs'].items():
            raw = package.read(path)
            assert sha(raw) == digest, path
            if path.startswith('tools/') or path.startswith('src/') or path in (TEST,'Guard-IsolatedOffice.ps1','Run.ps1'):
                if path == SOLVER:
                    raw = solver_source(raw)
                elif path == REBAR:
                    raw = steel_source(raw)
                elif path == TEST:
                    raw = test_source(raw, expected)
                elif path == 'Run.ps1':
                    raw = runner(raw)
                added[path] = seal(dest,path,raw)
        concrete = (REPO / CONCRETE).read_bytes()
        production = dict(frozen['production'])
        production[CONCRETE] = sha(concrete)
        added[CONCRETE] = seal(dest, CONCRETE, concrete_source(concrete))
    for file in ('Stage.py', 'Verify.py', 'History.bas'):
        added[file] = seal(dest,file,(HERE / file).read_bytes())
    if args.with_workbook:
        seal(dest, frozen['workbook'], source)
        seal(dest, 'docs/regression/Diagnostic.xlsm', source)
        for directory in ('Temp','Native/Order10'):
            (dest / directory).mkdir(parents=True, exist_ok=True)
    plan = {**frozen, 'inputs': added, 'production': production, 'prior_archive_sha256': BASE_SHA, 'prior_report_sha256': REPORT_SHA,
            'prior_compiled_workbook_sha256':json.loads(native)['proof']['compiled_workbook_sha256'], 'watchdog_seconds': 250,
            'modules': ['CCoupledConcreteResponse',*frozen['modules']],
            'scope': 'exact field and material history through F19; bounded equilibrium past old F20, no physical capacity'}
    print(dest, seal(dest,'Fixture.json',(json.dumps(plan,indent=2) + '\n').encode('utf-8')))


if __name__ == '__main__':
    main()
