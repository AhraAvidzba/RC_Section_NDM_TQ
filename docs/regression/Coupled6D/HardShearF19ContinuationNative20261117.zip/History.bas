' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает принятые переменные трёх материальных станций сечения.
Private Sub ReadHardF19HistoryTest(ByRef values() As Double)
    Dim parts As New Collection, side As Long, i As Long, count As Long, position As Long
    Dim response As CCoupledReinforcedResponse, concrete As CCoupledConcreteResponse
    Dim states() As Double, part As Variant
    For side = -1 To 1
        Set response = YieldResponse(side)
        Set concrete = response.HardF19ConcreteTest
        concrete.CopyHardF19ConcreteHistoryTest states
        count = count + UBound(states): parts.Add states
        response.CopyHardF19SteelHistoryTest states
        count = count + UBound(states): parts.Add states
    Next side
    ReDim values(1 To count)
    For Each part In parts
        For i = LBound(part) To UBound(part)
            position = position + 1: values(position) = part(i)
        Next i
    Next part
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет историю блоками одинаковой длины для автономной побитовой сверки.
Private Sub WriteHardF19HistoryTest(ByVal label As String, ByVal phase As String, ByRef values() As Double)
    Const WIDTH As Long = 64
    Dim lines() As String, piece() As Double, count As Long, i As Long, j As Long, first As Long, size As Long
    count = (UBound(values) + WIDTH - 1) \ WIDTH
    ReDim lines(0 To count)
    lines(0) = "HISTORY;" & label & ";" & phase & ";" & CStr(UBound(values)) & ";" & CStr(count)
    For i = 1 To count
        first = 1 + (i - 1) * WIDTH: size = WIDTH
        If first + size - 1 > UBound(values) Then size = UBound(values) - first + 1
        ReDim piece(1 To size)
        For j = 1 To size: piece(j) = values(first + j - 1): Next j
        lines(i) = "HISTORY-PART;" & label & ";" & phase & ";" & CStr(i) & ";" & HardRankVectorTest(piece)
    Next i
    WriteHardRankRowTest Join(lines, vbCrLf)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет, что повтор только принятых полей воспроизводит каждое значение истории.
Private Function CheckHardF19HistoryTest(ByVal fields As Collection, ByVal saved As Collection) As Boolean
    Dim mark As Variant, i As Long, index As Long, before() As Double, after() As Double
    For Each mark In Array(5, 6, 19)
        index = index + 1
        before = saved(index)
        WriteHardF19HistoryTest CStr(mark), "SOLVED", before
        If Not ReplayAcceptedFields(fields, CLng(mark)) Then Exit Function
        ReadHardF19HistoryTest after
        WriteHardF19HistoryTest CStr(mark), "REBUILT", after
        If UBound(after) <> UBound(before) Then Exit Function
        For i = 1 To UBound(after)
            If HardRankBitsTest(after(i)) <> HardRankBitsTest(before(i)) Then Exit Function
        Next i
    Next mark
    CheckHardF19HistoryTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Измеряет время между принятыми узлами, включая расчёт на границе суток.
Private Function HardF19ElapsedTest(ByVal started As Double) As Double
    HardF19ElapsedTest = Timer - started
    If HardF19ElapsedTest < 0# Then HardF19ElapsedTest = HardF19ElapsedTest + 86400#
End Function
