"""Архивирует нативную F19-серию и независимо воспроизводит её после распаковки."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
OLD = REPO / 'docs/regression/Coupled6D/HardShearFineResumeNative20261117.zip'
OLD_SHA = '9143FD1E28C70100FB5EC631D5E8C87A4D2D6BA8C3416B5F09BCFA834B2E7DF4'
NAME = 'HardShearF19ContinuationNative20261117'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def collect(source):
    plan = json.loads((source/'Fixture.json').read_bytes())
    paths = ['Fixture.json','Compile.log','CompileClosure.json','docs/regression/CodeUpdate.json','Run.ndjson',*plan['inputs']]
    paths.extend('Native/Order10/'+name for name in ('Verification.json','HardF19.csv','HardShear.txt','HardShear.txt.memory.json',
                 'HardShear.txt.Ownership.json','HardShear.txt.ProcessClosure.json','HardShear.txt.RunnerCleanup.json',
                 'HardShear.txt.stderr.log','HardShear.txt.stdout.log'))
    assert len(paths) == len(set(paths))
    files = {name:(source/name).read_bytes() for name in paths}
    assert all(sha(files[name]) == digest for name,digest in plan['inputs'].items())
    assert sha(OLD.read_bytes()) == OLD_SHA
    with ZipFile(OLD) as prior:
        for path,expected in plan['production'].items():
            name = 'Production/'+path
            raw = prior.read(name) if name in prior.namelist() else (REPO/path).read_bytes()
            assert sha(raw) == expected
            files[name] = raw
    for name in ('Verify-Portable.py','README-Portable.md','Pack.py'):
        files[name] = (HERE/name).read_bytes()
    hashes = {name:sha(raw) for name,raw in files.items()}
    files['SHA256SUMS.json'] = (json.dumps(hashes,sort_keys=True,indent=2)+'\n').encode('utf-8')
    return files


def seal(path,raw):
    if path.exists():
        assert path.read_bytes() == raw
    else:
        path.write_bytes(raw)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path)
    args = parser.parse_args()
    files = collect(args.source)
    folder = HERE/'proof'
    folder.mkdir(exist_ok=True)
    output = folder/(NAME+'.zip')
    with TemporaryDirectory(prefix='replay-',dir=folder) as directory:
        stage = Path(directory)
        compressed = stage/'candidate.zip'
        with ZipFile(compressed,'w',compression=ZIP_DEFLATED,compresslevel=9) as archive:
            for name,raw in sorted(files.items()):
                entry = ZipInfo(name,date_time=(2026,11,17,0,0,0))
                entry.create_system = 3
                entry.external_attr = 0o100644 << 16
                archive.writestr(entry,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
        detached = stage/'unpacked'
        with ZipFile(compressed) as archive:
            archive.extractall(detached)
        replay = run([sys.executable,'-B','-X','utf8','Verify-Portable.py'],cwd=detached,stdout=PIPE,check=True).stdout
        fingerprint = sha(compressed.read_bytes())
        seal(output,compressed.read_bytes())
        seal(folder/(NAME+'.replay.txt'),replay)
        seal(folder/(NAME+'.zip.sha256'),f'{fingerprint} *{NAME}.zip\n'.encode('ascii'))
    print(output,fingerprint)
    print(replay.decode('utf-8').splitlines()[-1])


if __name__ == '__main__':
    main()
