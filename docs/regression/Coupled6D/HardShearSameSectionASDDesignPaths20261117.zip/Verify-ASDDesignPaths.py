"""Обособленная проверка всех уравнений и сопоставление полей на общих нагрузках."""

from argparse import ArgumentParser
import gzip
import json
from math import fsum
from pathlib import Path
from runpy import run_path
import sys


HERE = Path(__file__).resolve().parent


def open_wire(source, filename, expected):
    """Проверяет отпечаток исходного пакета до распаковки."""
    raw = (HERE / filename).read_bytes()
    assert source.sha(raw) == expected
    return json.loads(gzip.decompress(raw))


def check_frame(source, geo, dirs, area, length, operators, frame):
    """Сверяет 56 слабых уравнений, четыре связи и шесть интегральных усилий."""
    factor = frame['lambda']
    field = frame['field']
    steel = frame['steel_stress_MPa']
    residual = source.verify_rows(geo, dirs, area, length, operators, field,
                                  frame['net_stress_MPa'], factor, steel)
    repeated = frame['zero_increment_trial']
    repeated_residual = source.verify_rows(geo, dirs, area, length, operators, field,
                                           repeated['net_stress_MPa'], factor, steel, False)
    assert residual == frame['independent'] and repeated_residual == repeated['independent']
    assert frame['immediate_committed_stress_identical'] and not repeated['committed']
    measures = frame['concrete_measures']
    indicators = measures['raw_indicators']
    assert len(indicators) == 75 and all(len(row) == 6 for row in indicators)
    peaks = measures['table_peak_T_C_ordinates']
    assert peaks == [.0001, .002]
    count = [sum(row[i] > limit for row in indicators) for i, limit in enumerate(peaks)]
    assert count == measures['number_above_tension_compression_table_peak']
    return {'lambda': factor, 'twist_rad_per_m': 1000. * field[3] / length,
            'tension_compression_counts': count, 'iterations': frame['iterations'],
            'max_abs_elastic_steel_MPa': max(abs(value) for axis in steel for value in axis),
            'force_N_Nmm': residual['signed_six'], 'accepted_residual_MPa': residual['combined_norm_MPa'],
            'original_tolerance_MPa': residual['original_tolerance_MPa'],
            'discarded_repeat_residual_MPa': repeated_residual['combined_norm_MPa']}


def ndm_comparison(source, repo, length, operators, frames):
    """Сверяет принятые поля ASD и архивные поля НДМ на общей сетке и ступенях."""
    with source.archived(repo, source.H68) as arc:
        records = source.csv(arc.read('HardShear-H68.csv'))
    fields = {float(row[2]): list(map(float, row[3:])) for row in records[1:5]}
    assert list(fields) == [.25, .5, .75, 1.]
    paired = []
    for frame in frames:
        factor = frame['lambda']
        ndm_field = fields[factor]
        difference = [left - right for left, right in zip(frame['field'], ndm_field, strict=True)]
        max_point = max(abs(fsum((b + side * z) * x for b, z, x in zip(bb, zz, difference, strict=True)))
                        for point_b, point_z in zip(operators['B'], operators['Z'], strict=True)
                        for bb, zz in zip(point_b, point_z, strict=True) for side in (0., .001, -.001))
        ndm_twist = 1000. * ndm_field[3] / length
        asd_twist = 1000. * frame['field'][3] / length
        paired.append({'lambda': factor, 'ndm_archived_twist_rad_per_m': ndm_twist,
                       'asd_twist_rad_per_m': asd_twist, 'asd_relative_difference': asd_twist / ndm_twist - 1.,
                       'engineering_strain_max_abs_difference': max_point})
    assert [row['lambda'] for row in paired] == [.25, .5, .75]
    assert all(abs(row['asd_twist_rad_per_m'] - row['ndm_archived_twist_rad_per_m']) < 2e-10 for row in paired[:2])
    assert -.017 < paired[-1]['asd_relative_difference'] < -.016
    return paired, 1000. * fields[1.][3] / length


def check_twist_paths(source, geo, dirs, area, length, operators, refined, material_hash):
    """Сверяет полный шаг, два полушага и отдельное равновесие при том же закручивании."""
    trace = run_path(str(HERE / 'Trace-ASDFixedTwist.py'))
    anchor = refined['arms']['refined']['accepted'][-1]
    origin = 1000. * anchor['field'][3] / length
    arms = {}
    for key, filename, fingerprint, increment, count in (
            ('full', 'ASDFixedTwistWire.json.gz',
             'B75F4A664932C6F73F9C9EC4A3CE0AC6E1675890D2E87D1D249ECA7FE4330489', 4e-5, 10),
            ('half', 'ASDHalfTwistWire.json.gz',
             '6B0BBEE37764DF8EDB833A0A503F602EBC556286F0634C0D08359D98E0D54CEB', 2e-5, 2),
            ('fixed', 'ASDZeroTwistWire.json.gz',
             '4E5B31BE81BAB9574392D0BDF808F5773F1B1D08DBC8C7F5B26E56186601435A', 0., 1)):
        packet = open_wire(source, filename, fingerprint)
        assert packet['operator_sha256'] == refined['operator_sha256']
        assert packet['solver_sha256'] == refined['solver_sha256']
        assert packet['material_command_sha256'] == material_hash
        assert packet['design_sha256'] == refined['previous_wire_sha256']
        assert packet['refinement_sha256'] == trace['REFINEMENT_SHA']
        assert packet['failure'] is None and not packet['physical_limit_established']
        assert packet['prefix_count'] == 14 and packet['cold_replay_count'] == 14 + count
        frames = packet['accepted']
        assert len(frames) == count
        arm = [check_frame(source, geo, dirs, area, length, operators, frame) for frame in frames]
        for index, (result, frame) in enumerate(zip(arm, frames, strict=True), 1):
            expected = origin + index * increment
            assert abs(frame['twist_rad_per_m'] - expected) < 1e-15
            assert frame['twist_rad_per_m'] == result['twist_rad_per_m']
            assert 0 < frame['lambda'] < anchor['lambda'] < 1.
            assert result['tension_compression_counts'][1] == 0 and result['max_abs_elastic_steel_MPa'] < 12.
        arms[key] = arm
    first, two, same = arms['full'][0], arms['half'][-1], arms['fixed'][0]
    assert first['twist_rad_per_m'] == two['twist_rad_per_m'] and same['twist_rad_per_m'] == origin
    assert -.0025 < two['lambda'] - first['lambda'] < -.0024
    assert -.010 < same['lambda'] - anchor['lambda'] < -.009
    return {'anchor_lambda': anchor['lambda'], 'anchor_twist_rad_per_m': origin, 'arms': arms,
            'half_minus_full_same_twist_delta_lambda': two['lambda'] - first['lambda'],
            'new_equilibrium_delta_lambda_at_anchor_twist': same['lambda'] - anchor['lambda']}


def main(repo):
    """Проверяет заданные терминальные исходы без запуска Excel и OpenSees."""
    runner = run_path(str(HERE / 'Continue-ASDToDesign.py'))
    refinement = run_path(str(HERE / 'Refine-ASDToDesign.py'))
    source, _, prior, histories, old_hash = runner['inputs'](repo)
    design = open_wire(source, 'ASDToDesignWire.json.gz', refinement['PREVIOUS'])
    refined = open_wire(source, 'ASDRefineToDesignWire.json.gz',
                        '5D844C9E76D7456E39C12F7B2ED3645A7F1F50727A6C841ADDB4DDD44D212E61')
    geo, dirs, area, length, _, _ = source.fixture(repo)
    operators = source.operators(geo, area, length)
    op_hash = source.sha(source.packed(operators))
    material_hash = source.sha(source.packed(prior['material_command']))
    assert design['input_wire_sha256'] == old_hash and refined['previous_wire_sha256'] == refinement['PREVIOUS']
    for packet in (design, refined):
        assert packet['operator_sha256'] == op_hash == prior['identity']['exact_built_operator_sha256']
        assert packet['solver_sha256'] == prior['identity']['solver_source_sha256']
        assert packet['material_command_sha256'] == material_hash
        assert packet['runtime'] == '3.8.0' and packet['numpy'] == '2.3.5' and not packet['physical_limit_established']
    records = {}
    for name, arms, schedule, prefix, solved, lost, kind in (
            ('single', design['arms'], runner['SCHEDULES']['single'], len(histories['single']),
             [.9375], 1., 'line_search_no_decrease'),
            ('split', design['arms'], runner['SCHEDULES']['split'], len(histories['split']),
             [.90625, .9375, .96875], 1., 'maximum_iterations'),
            ('refined', refined['arms'], refinement['NEAR_DESIGN'], 13,
             [.9765625], .984375, 'line_search_no_decrease'),
            ('ndm_schedule', refined['arms'], refinement['NDM_STEPS'], 0,
             [.25, .5, .75], 1., 'maximum_iterations')):
        arm = arms[name]
        assert arm['prefix_count'] == prefix and arm['schedule'] == list(schedule)
        accepted = [check_frame(source, geo, dirs, area, length, operators, frame) for frame in arm['accepted']]
        assert [frame['lambda'] for frame in accepted] == solved
        assert arm['exact_cold_steps_with_discarded_trials'] == prefix + len(accepted)
        failure = arm['first_failure']
        assert failure['lambda'] == lost and failure['numerical']['kind'] == kind
        assert failure['numerical']['weak_or_forces_norm_MPa'] > 1e-3
        records[name] = {'accepted': accepted, 'first_failure': failure}
    paired, ndm_design = ndm_comparison(source, repo, length, operators, refined['arms']['ndm_schedule']['accepted'])
    twist = check_twist_paths(source, geo, dirs, area, length, operators, refined, material_hash)
    return {'operator_sha256': op_hash, 'same_schedule_comparison': paired, 'arms': records,
            'ndm_archived_design_twist_rad_per_m': ndm_design, 'twist_control': twist,
            'physical_limit_established': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--report', type=Path)
    opts = parser.parse_args()
    sys.dont_write_bytecode = True
    result = main(opts.repo.resolve())
    raw = (json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    if opts.report:
        with opts.report.open('xb') as out:
            out.write(raw)
    print('HARDSHEAR ASD DESIGN PATHS OFFLINE PASS', result['operator_sha256'])
