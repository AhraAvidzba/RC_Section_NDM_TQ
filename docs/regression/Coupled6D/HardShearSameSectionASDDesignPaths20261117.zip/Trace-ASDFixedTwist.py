"""Прослеживает HardShear с управлением закручиванием после силового отказа ASD."""

from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
from runpy import run_path
import sys
from time import perf_counter


REFINEMENT_SHA = '5D844C9E76D7456E39C12F7B2ED3645A7F1F50727A6C841ADDB4DDD44D212E61'
TWIST_INCREMENT = 4e-5  # Изменение закручивания в рад/м на один принятый шаг.
NUMBER_STEPS = 10
MAX_ITERATIONS = 24


def solve_twist(section, load, predictor, controlled_coordinate):
    """Заменяет заданный множитель нагрузки заданным коэффициентом закручивания."""
    np = section.np
    scale = section.scale
    ext = scale * (load @ section.L)
    coordinates = np.r_[np.arange(3), np.arange(4, 60)]
    field, factor = predictor
    field = field.copy()
    field[3] = controlled_coordinate
    for turn in range(MAX_ITERATIONS + 1):
        state = section.equations(field, factor * load)
        if state[4] <= state[5]:
            section.accepted_stresses.append(state[2].tolist())
            section.commit()
            return (field, factor), {'iterations': turn, 'norm': state[4]}
        if turn == MAX_ITERATIONS:
            break
        tangent = section.equations(field, factor * load, True)[1]
        bordered = np.column_stack((scale[:, None] * tangent[:, coordinates], -ext))
        try:
            delta = np.linalg.solve(bordered, -scale * state[0])
        except np.linalg.LinAlgError:
            return None, {'kind': 'singular_tangent', 'iterations': turn, 'norm': state[4]}
        score = np.linalg.norm(scale * state[0])
        for division in range(14):
            step = delta * 0.5 ** division
            trial = field.copy()
            trial[coordinates] += step[:-1]
            trial_factor = factor + step[-1]
            if trial_factor <= 0. or trial_factor > 1.2:
                continue
            try:
                candidate = section.equations(trial, trial_factor * load)
            except ArithmeticError:
                continue
            if candidate[4] <= candidate[5] or np.linalg.norm(scale * candidate[0]) < score:
                field, factor = trial, trial_factor
                break
        else:
            return None, {'kind': 'line_search_no_decrease', 'iterations': turn, 'norm': state[4]}
    return None, {'kind': 'maximum_iterations', 'iterations': MAX_ITERATIONS, 'norm': state[4]}


def trace(repo, design_path, refinement_path, output, twist_increment=TWIST_INCREMENT, number_steps=NUMBER_STEPS):
    """Повторяет принятую историю и измеряет отклик при контроле одной деформации."""
    import numpy as np
    import openseespy.opensees as ops

    start = perf_counter()
    assert not output.exists() and ops.version() == '3.8.0' and np.__version__ == '2.3.5'
    runner = run_path(str(Path(__file__).with_name('Continue-ASDToDesign.py')))
    refinement = run_path(str(Path(__file__).with_name('Refine-ASDToDesign.py')))
    source, compare, prior, histories, _ = runner['inputs'](repo)
    design_wire = design_path.read_bytes()
    refinement_wire = refinement_path.read_bytes()
    assert source.sha(design_wire) == refinement['PREVIOUS']
    assert source.sha(refinement_wire) == REFINEMENT_SHA
    design = json.loads(gzip.decompress(design_wire))
    refined = json.loads(gzip.decompress(refinement_wire))
    history = histories['split'] + design['arms']['split']['accepted'] + refined['arms']['refined']['accepted']
    assert len(history) == 14 and history[-1]['lambda'] == .9765625
    geo, dirs, area, length, _, _ = source.fixture(repo)
    operators = source.operators(geo, area, length)
    operator_sha = source.sha(source.packed(operators))
    assert operator_sha == prior['identity']['exact_built_operator_sha256']
    solver, solver_sha = source.source_model(repo)
    assert solver_sha == prior['identity']['solver_source_sha256']
    command, _ = source.material_command(repo)
    assert list(command) == prior['material_command']
    solver.P = 43
    load = np.array(source.RAY)
    make_section = compare.kernel(np, ops, solver, geo, dirs, area, length, operators, command,
                                  start + 55., source.ES)
    section = make_section()
    current = compare.replay(np, section, history, load), history[-1]['lambda']
    left = np.array(history[-2]['field']), history[-2]['lambda']
    origin = current[0][3]
    increment = twist_increment * length / 1000.
    accepted = []
    failure = None
    for number in range(1, number_steps + 1):
        desired = origin + number * increment
        advance = (desired - current[0][3]) / (current[0][3] - left[0][3])
        guess = tuple(c + advance * (c - l) for c, l in zip(current, left, strict=True))
        selected, transition = solve_twist(section, load, guess, desired)
        if selected is None:
            failure = {'twist_rad_per_m': 1000. * desired / length, **transition}
            break
        left, current = current, selected
        field, factor = current
        stress = section.accepted_stresses[-1]
        steel = section.steel_stress.tolist()
        check = source.verify_rows(geo, dirs, area, length, operators, field.tolist(), stress, factor, steel)
        assert abs(check['combined_norm_MPa'] - transition['norm']) < 3e-12
        frame = {'lambda': factor, 'field': field.tolist(), 'net_stress_MPa': stress, 'steel_stress_MPa': steel,
                 'independent': check, 'iterations': transition['iterations'],
                 'twist_rad_per_m': 1000. * desired / length}
        frame.update(compare.material_readback(np, ops, vars(source), section, command, field, factor,
                                               load, stress, steel, geo, dirs, area, length, operators))
        accepted.append(frame)
    assert section.committed == len(history) + len(accepted)
    cold = make_section()
    compare.replay(np, cold, history + accepted, load, excursions=True)
    ops.wipe()
    report = {'operator_sha256': operator_sha, 'solver_sha256': solver_sha,
              'design_sha256': source.sha(design_wire), 'refinement_sha256': REFINEMENT_SHA,
              'material_command_sha256': source.sha(source.packed(command)),
              'prefix_count': len(history), 'cold_replay_count': cold.committed,
              'runtime': ops.version(), 'numpy': np.__version__, 'accepted': accepted,
              'failure': failure, 'physical_limit_established': False}
    raw = gzip.compress(source.packed(report), compresslevel=9, mtime=0)
    with output.open('xb') as sink:
        sink.write(raw)
    print('HARDSHEAR ASD FIXED TWIST WIRE', source.sha(raw), f'{perf_counter()-start:.3f}s',
          [step['lambda'] for step in accepted], failure)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--design', required=True, type=Path)
    parser.add_argument('--refinement', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--twist-increment', type=float, default=TWIST_INCREMENT)
    parser.add_argument('--steps', type=int, default=NUMBER_STEPS)
    arguments = parser.parse_args()
    sys.dont_write_bytecode = True
    assert arguments.steps > 0
    assert arguments.twist_increment > 0. or (arguments.twist_increment == 0. and arguments.steps == 1)
    trace(arguments.repo.resolve(), arguments.design.resolve(), arguments.refinement.resolve(), arguments.out.resolve(),
          arguments.twist_increment, arguments.steps)
