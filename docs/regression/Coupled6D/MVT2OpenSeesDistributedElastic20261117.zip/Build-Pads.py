"""Pack the detached distributed MVT2 verification without engine or PDF binaries."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
FILES = ("Build-Pads.py","ElasticDistributedResult.json","MVT2DistributedPads.py","README.md","VerificationPads.json","Verify-Pads.py")
OUT = HERE / "MVT2OpenSeesDistributedElastic20261117.zip"


def add(archive,name,payload):
    info = ZipInfo(name,(2026,11,17,0,0,0))
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    info.compress_type = ZIP_STORED
    archive.writestr(info,payload)


def main():
    records = []
    with ZipFile(OUT,"w") as archive:
        for name in FILES:
            payload = (HERE / name).read_bytes()
            records.append(f"{sha256(payload).hexdigest()}  {name}\n")
            add(archive,name,payload)
        add(archive,"SHA256SUMS","".join(records).encode("ascii"))
    print(sha256(OUT.read_bytes()).hexdigest().upper())


if __name__ == "__main__":
    main()
