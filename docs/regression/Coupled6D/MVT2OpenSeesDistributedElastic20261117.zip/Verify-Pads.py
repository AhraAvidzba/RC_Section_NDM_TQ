"""Independent detached verification of the four-stage distributed elastic MVT2 trial."""
import argparse
from hashlib import sha256
import json
from math import ceil, fsum, isfinite
from pathlib import Path


HERE = Path(__file__).resolve().parent
FILES = {"ElasticDistributedResult.json":"4A8CCD2FAE474DEC5923D7DD92EEBB1A446353E2A7F59D08D1E179D0972A2463",
         "MVT2DistributedPads.py":"3B341EB7F76226C06303C5A4E24AEC76D9A8E4759017872A941F4E05B00E5136"}
RIG_SHA = "C2777D5D748972220113C54F78FD18DEDA86DB6786AE7268633E0FDB1C5CC8A7"
CUTS = (800.,860.,1340.,1400.)
COMPONENTS = ("N","Mx","My","T","Qx","Qy")
SCALES = (1.,240.,240.,240.,1.,1.)
ZERO = (0.,)*6
SUPPORTS = {"1289":(-96.,-120.,500.), "1297":(96.,-120.,500.),
            "1293":(0.,-120.,500.), "4065":(0.,-120.,1700.)}


def require(condition,name):
    if not condition:
        raise ValueError(name)


def add(*vectors):
    return tuple(fsum(items) for items in zip(*vectors,strict=True))


def integrate_hat(axis,index,a,b):
    center = axis[index]
    integral = 0.
    for j in (index-1,index+1):
        if not 0<=j<len(axis):
            continue
        other = axis[j]
        lo,hi = max(min(center,other),a),min(max(center,other),b)
        if lo < hi:
            integral += (hi-lo)*((lo+hi)/2.-other)/(center-other)
    return integral/(b-a)


def pad_weights_proof(raw):
    xs = (-120.,-96.,-84.,-60.,-30.,0.,30.,60.,84.,96.,120.)
    ys = (-120.,-96.,-84.,-60.,0.,60.,84.,96.,120.)
    required = sorted({0,500,1080,1100,1120,1700,2200,*CUTS,
                       *range(20,500,40),*range(530,1700,60),*range(1720,2200,40)})
    zs = [a+(b-a)*i/ceil((b-a)/60.) for a,b in zip(required,required[1:])
          for i in range(ceil((b-a)/60.))]+[2200.]
    require(len(zs)==55,"frozen starting mesh")
    measured = []
    for weights,center,j in zip(raw,(-96.,96.),(0,len(ys)-1),strict=True):
        theoretical = {}
        xyz = {}
        for i,x in enumerate(xs):
            wx = integrate_hat(xs,i,center-24.,center+24.)
            for k,z in enumerate(zs):
                w = wx*integrate_hat(zs,k,460.,540.)
                if w > 0.:
                    tag = str(1+(k*len(ys)+j)*len(xs)+i)
                    theoretical[tag] = w
                    xyz[tag] = (x,ys[j],z)
        require(set(weights)==set(theoretical),"pad node tags from independent tensor-product integration")
        defect = max(abs(weights[tag]-theoretical[tag]) for tag in weights)
        require(defect<=4e-16,"pad interpolation weights")
        barycentre = tuple(fsum(weights[tag]*xyz[tag][i] for tag in weights) for i in range(3))
        require(max(abs(a-b) for a,b in zip(barycentre,(center,ys[j],500.),strict=True))<=1e-11,"patch traction barycentre")
        require(abs(fsum(weights.values())-1.)<=4e-16,"patch partition unity")
        measured.append({"pad_nodes":len(theoretical),"barycentre_mm":barycentre,"max_weight_error":defect})
    return measured


def gauge_wrench(gauge,z,select):
    contributions = []
    for tag,(x,y,zz) in SUPPORTS.items():
        if select(zz):
            fx,fy,fz = gauge[tag]
            dz = zz-z
            contributions.append((fz,y*fz-dz*fy,x*fz-dz*fx,x*fy-y*fx,fx,fy))
    return add(*contributions)


def verify_state(state, torque, load):
    require((state["T_Nmm"],state["P_N"]) == (torque,load),"four sequential loads")
    gauge = state["gauge_reactions_N"]
    require(set(gauge)==set(SUPPORTS) and all(len(v)==3 for v in gauge.values()),"four gauge nodes")
    gauge_max = max(abs(v) for values in gauge.values() for v in values)
    require(gauge_max < .05,"zero gauge residual")
    errors = {}
    summary = [0.]*6

    def error(label,actual,expected):
        require(len(actual)==6 and all(map(isfinite,actual)),label)
        diffs = [abs(a-b) for a,b in zip(actual,expected,strict=True)]
        for j,diff in enumerate(diffs):
            summary[j] = max(summary[j],diff)
        errors[label] = max(d/s for d,s in zip(diffs,SCALES,strict=True))
        require(errors[label] <= .05,label)

    q = load/2.
    lforce,rforce = load/4. + torque/192.,load/4. - torque/192.
    require(lforce>0. and rforce<0.,"both actual pad tractions compress toward specimen")
    error("left pad sum",state["left_pad_wrench_N_Nmm"],(0.,0.,0.,-torque,0.,q))
    error("right support sum",state["right_support_wrench_N_Nmm"],(0.,0.,0.,0.,0.,q))
    error("overall gauge residual",gauge_wrench(gauge,1100.,lambda _:True),ZERO)
    require(tuple(row["z_mm"] for row in state["cuts"])==CUTS,"four original cut planes")
    for row in state["cuts"]:
        z = row["z_mm"]
        left = z<1100.
        v = -q if left else q
        expected = (0.,-(z-500. if left else 1700.-z)*q,0.,torque,0.,v)
        faces = row["low_and_high_face"]
        require(len(faces)==2 and len(row["left_right_free_bodies"])==2,"two faces and two free bodies")
        for n,wrench in enumerate(faces):
            error(f"{z:g} face {n}",wrench,expected)
            nn,mx,my,t,qx,qy = wrench
            nominal = (nn,-mx+(z-1100.)*qy,-my+(z-1100.)*qx,t,-qx,-qy)
            error(f"{z:g} translated face {n}",nominal,(0.,600.*q,0.,torque,0.,-v))
            error(f"{z:g} recorded translate {n}",row["low_and_high_nominal_in_ndm_axes"][n],nominal)
        error(f"{z:g} face to face",faces[0],faces[1])
        a = gauge_wrench(gauge,z,lambda z0:z0<z)
        b = gauge_wrench(gauge,z,lambda z0:z0>z)
        for n,(recorded,correction) in enumerate(zip(row["left_right_free_bodies"],(tuple(-v for v in a),b),strict=True)):
            error(f"{z:g} free body {n}",recorded,expected)
            error(f"{z:g} reconstructed free body {n}",recorded,add(expected,correction))
    measured = state["recovered_kinematics"]
    y1,y2 = measured["pad_mean_raw_uy_mm"]
    angle_x,angle_z = measured["gauge_rotation_about_x_and_z_rad"]
    rebuilt = (y1+1200.*angle_x-96.*angle_z,y2+1200.*angle_x+96.*angle_z)
    require(max(map(abs,rebuilt))<=1e-17,"zero physical weighted deflection")
    require(max(abs(a-b) for a,b in zip(rebuilt,measured["pad_mean_physical_uy_mm"],strict=True))<=1e-17,"archived corrected pad averages")
    carried = measured["unchanged_datum_residuals_mm"]
    require(max(abs(v) for values in carried for v in values)==0.,"four datum conditions unchanged")
    work = lforce*rebuilt[0]+rforce*rebuilt[1]+q*carried[1][1]
    require(abs(work-state["physical_support_work_Nmm"])<=2e-12 and abs(work)<1e-10,"zero work done by physical supports")
    reconstructed_max = max([gauge_max,*errors.values()])
    require(abs(reconstructed_max-state["max_balance_error_N_equivalent"])<2e-10,"archived maximum residual")
    return {"T_kNm":torque/1e6,"P_kN":load/1e3,"peak_balance_N_equivalent":reconstructed_max,
            "max_numerical_gauge_reaction_N":gauge_max,"pad_coefficients_N":[lforce,rforce],
            "physical_average_uy_mm":measured["pad_mean_physical_uy_mm"],"physical_support_work_Nmm":state["physical_support_work_Nmm"],
            "max_component_error_native_units":dict(zip(COMPONENTS,summary,strict=True))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path)
    opts = parser.parse_args()
    for name,sha in FILES.items():
        require(sha256((HERE/name).read_bytes()).hexdigest().upper()==sha,name)
    raw = json.loads((HERE/"ElasticDistributedResult.json").read_bytes())
    require(raw["rig_source_sha256"]==RIG_SHA and raw["OpenSees"]=="3.8.0","dependencies")
    require(raw["physical_average_constraint_rank"]==raw["numerical_gauge_rank"]==6 and raw["peak_allowed_force_moment_normalized_N"]==.05,"acceptance contract")
    require(raw["physical_limit_established"] is False and raw["pad_x_z_extent_mm"]==[48.,80.],"elastic fixture scope")
    pads = pad_weights_proof(raw["support_nodal_weights"])
    steps = ((5_255_000.,0.),(10_510_000.,0.),(10_510_000.,10_000.),(10_510_000.,20_000.))
    states = [verify_state(item,*step) for item,step in zip(raw["states"],steps,strict=True)]
    proof = {"checks":"PASS","states":states,"pad_quadrature":pads,"physical_limit_established":False}
    if opts.out:
        opts.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True,allow_nan=False)+"\n").encode("utf-8"))
    worst = max(row["peak_balance_N_equivalent"] for row in states)
    print(f"MVT2_DISTRIBUTED_DETACHED_PASS {len(states)} states worst={worst:.12g} N equivalent")


if __name__ == "__main__":
    main()
