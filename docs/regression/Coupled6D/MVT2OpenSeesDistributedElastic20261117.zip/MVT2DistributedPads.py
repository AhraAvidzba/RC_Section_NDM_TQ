"""Elastic MVT2 trial with finite opposing left reaction pads on the verified mesh."""
import argparse
from hashlib import sha256
from itertools import product
import json
from math import fsum, isclose
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
BASE = HERE.parent
RIG_SHA = "C2777D5D748972220113C54F78FD18DEDA86DB6786AE7268633E0FDB1C5CC8A7"
sys.dont_write_bytecode = True
sys.path.insert(0,str(BASE))
import MVT2Elastic as rig


PATCH_X_HALF, PATCH_Z_HALF = 24., 40.
HALF_LEVER = 96.
ZERO = (0.,)*3


def combine_maps(*fields):
    return {tag:rig.combine(*(field.get(tag,ZERO) for field in fields))
            for tag in sorted(set().union(*(field.keys() for field in fields)))}


def pad_weights(geometry, center_x, face_y):
    weights = {}
    layer = 0 if face_y < 0. else geometry.ny
    area = 4.*PATCH_X_HALF*PATCH_Z_HALF
    xlo,xhi = center_x-PATCH_X_HALF,center_x+PATCH_X_HALF
    zlo,zhi = rig.Z_LEFT-PATCH_Z_HALF,rig.Z_LEFT+PATCH_Z_HALF
    for i,k in product(range(geometry.nx),range(geometry.nz)):
        xl,xr = geometry.x[i:i+2]
        zl,zr = geometry.z[k:k+2]
        ax,bx,az,bz = max(xlo,xl),min(xhi,xr),max(zlo,zl),min(zhi,zr)
        if ax >= bx or az >= bz:
            continue
        weight = (bx-ax)*(bz-az)/(4.*area)
        # Integrate the original face interpolation over the intersected pad rectangle.
        for rx,rz in product(rig.GAUSS,repeat=2):
            nx = (ax+bx+rx*(bx-ax)-xl-xr)/(xr-xl)
            nz = (az+bz+rz*(bz-az)-zl-zr)/(zr-zl)
            for a,b in rig.CORNERS:
                shape = (1.+(2*a-1)*nx)*(1.+(2*b-1)*nz)/4.
                tag = geometry.node(i+a,layer,k+b)
                weights[tag] = weights.get(tag,0.)+weight*shape
    return weights


def weighted(weights, fn):
    return fsum(value*fn(tag) for tag,value in weights.items())


def vertical_nodes(weights, force):
    return {tag:(0.,force*value,0.) for tag,value in weights.items()}


def load_fields(geometry, pads, torque, vertical):
    arm_force = torque/(2.*HALF_LEVER)
    left_negative_x = vertical / 4. + arm_force
    left_positive_x = vertical / 4. - arm_force
    applied = rig.applied_nodes(geometry,torque,vertical)
    physical_left = combine_maps(vertical_nodes(pads[0],left_negative_x),vertical_nodes(pads[1],left_positive_x))
    physical_right = {geometry.right_vertical:(0.,vertical/2.,0.)}
    return applied, physical_left, physical_right


def rigid_displacement(point, omega_x, omega_z):
    x,y,z = point
    return (-omega_z*(y+120.), -omega_x*(z-rig.Z_RIGHT)+omega_z*x, omega_x*(y+120.))


def recover_pad_kinematics(geometry, pads, displacements):
    u_left,u_right = (weighted(pad,lambda n:displacements[n][1]) for pad in pads)
    omega_x = -(u_left+u_right)/(2.*(rig.Z_RIGHT-rig.Z_LEFT))
    omega_z = (u_left-u_right)/(2.*HALF_LEVER)
    correction = lambda tag: rigid_displacement(geometry.coords[tag],omega_x,omega_z)
    fixed_residuals = [[displacements[tag][j]+correction(tag)[j] for j in dofs]
                       for tag,dofs in ((geometry.left_translation,(0,2)),(geometry.right_vertical,(0,1)))]
    mean_residuals = [weighted(pad,lambda tag:displacements[tag][1]+correction(tag)[1]) for pad in pads]
    return {"pad_mean_raw_uy_mm":[u_left,u_right],"gauge_rotation_about_x_and_z_rad":[omega_x,omega_z],
            "pad_mean_physical_uy_mm":mean_residuals,"unchanged_datum_residuals_mm":fixed_residuals,
            "max_physical_constraint_error_mm":max(map(abs,(*mean_residuals,*fixed_residuals[0],*fixed_residuals[1])))}


def precision_basis(geometry, pads):
    for pad,x,y in zip(pads,(-HALF_LEVER,HALF_LEVER),(-120.,120.),strict=True):
        observed = (fsum(pad.values()),*(weighted(pad,lambda tag:geometry.coords[tag][i]) for i in range(3)))
        if max(abs(a-b) for a,b in zip(observed,(1.,x,y,rig.Z_LEFT),strict=True)) > 1e-11 or min(pad.values()) <= 0.:
            raise ValueError(("invalid pad partition or centroid",observed))
    # Mean vertical rigid rows depend only on the two x-z centroids, matching the point gauge rows.
    if rig.support_rank(geometry) != 6:
        raise ValueError("Rigid body restraint rank")
    model_test = {tag:rigid_displacement(point,.002,-.006) for tag,point in geometry.coords.items()}
    if recover_pad_kinematics(geometry,pads,model_test)["max_physical_constraint_error_mm"] > 1e-12:
        raise ValueError("Rigid rotation recovery does not satisfy the six physical equations")
    for torque,vertical in ((rig.TORQUE,0.),(0.,20_000.),(rig.TORQUE,20_000.)):
        applied,left,right = load_fields(geometry,pads,torque,vertical)
        supports = combine_maps(left,right)
        external = combine_maps(applied,supports)
        rig.require_balance("left patch statics",geometry.sum_wrench(left,rig.Z_LEFT),(0.,0.,0.,-torque,0.,vertical/2.),1e-7)
        rig.require_balance("exact total load",geometry.sum_wrench(external,rig.Z_MID),(0.,)*6,1e-7)
        for z in rig.CUTS:
            for use_left in (True,False):
                rig.require_balance("analytic section using distributed reactions",rig.free_body(geometry,z,applied,supports,use_left),
                                    rig.expected_section(z,torque,vertical),1e-7)


def inspect(model, pads, torque, vertical):
    geometry,ops = model.geometry,model.ops
    ops.reactions()
    gauge = {tag:tuple(ops.nodeReaction(tag)) for tag in geometry.supports}
    errors = [max(abs(v) for f in gauge.values() for v in f)]
    if errors[0] > rig.MAX_BALANCE_ERROR:
        raise ValueError(("Force leaked into a numerical gauge",gauge))
    applied,left,right = load_fields(geometry,pads,torque,vertical)
    physical_support = combine_maps(left,right)
    applied_assembly = combine_maps(applied,physical_support,gauge)
    errors.append(rig.require_balance("overall actual balance",geometry.sum_wrench(applied_assembly,rig.Z_MID),(0.,)*6,rig.MAX_BALANCE_ERROR))
    cuts = []
    for z in rig.CUTS:
        k = geometry.z.index(z)
        lower = model.utility.Prism.cut(model,k-1,True)
        upper = model.utility.Prism.cut(model,k,False)
        field = (lower,upper)
        # Physical reactions were applied as equivalent forces. Gauges are added only as residual reactions.
        from_left = rig.free_body(geometry,z,applied,combine_maps(physical_support,gauge),True)
        from_right = rig.free_body(geometry,z,applied,combine_maps(physical_support,gauge),False)
        target = rig.expected_section(z,torque,vertical)
        for observed in (*field,from_left,from_right):
            errors.append(rig.require_balance(f"Cut {z:g}",observed,target,rig.MAX_BALANCE_ERROR))
        errors.append(rig.require_balance(f"Cut {z:g} face-to-face",lower,upper,rig.MAX_BALANCE_ERROR))
        any_left = z < rig.Z_MID
        nominal = [rig.ndm_axes(rig.transport(values,rig.Z_MID-z)) for values in field]
        q = vertical/2.
        for observed in nominal:
            errors.append(rig.require_balance("Nominal one-sided cut",observed,(0.,600.*q,0.,torque,0.,q if any_left else -q),rig.MAX_BALANCE_ERROR))
        cuts.append({"z_mm":z,"low_and_high_face":field,"left_right_free_bodies":[from_left,from_right],
                     "low_and_high_nominal_in_ndm_axes":nominal})
    displacements = {tag:tuple(ops.nodeDisp(tag)) for tag in geometry.coords}
    kinematics = recover_pad_kinematics(geometry,pads,displacements)
    if kinematics["max_physical_constraint_error_mm"] > 1e-9:
        raise ValueError(("Recovered pad support kinematics",kinematics))
    ox,oz = kinematics["gauge_rotation_about_x_and_z_rad"]
    support_work = fsum(fi*(ui+ui_rig) for tag,force in physical_support.items()
                        for fi,ui,ui_rig in zip(force,displacements[tag],rigid_displacement(geometry.coords[tag],ox,oz),strict=True))
    if abs(support_work) > 1e-6:
        raise ValueError(("Corrected reactions perform virtual work on support displacements",support_work))
    return {"T_Nmm":torque,"P_N":vertical,"left_pad_wrench_N_Nmm":geometry.sum_wrench(left,rig.Z_LEFT),
            "right_support_wrench_N_Nmm":geometry.sum_wrench(right,rig.Z_RIGHT),"gauge_reactions_N":gauge,
            "cuts":cuts,"recovered_kinematics":kinematics,"physical_support_work_Nmm":support_work,
            "max_balance_error_N_equivalent":max(errors)}


def solve(geometry,pads,meta):
    sys.path.insert(0,str(rig.UTILITY.parent))
    import validate_opensees_hardshear as utility

    model = rig.Model(geometry,utility)
    ops = model.ops

    def set_load(tag,torque,vertical):
        applied,left,right = load_fields(geometry,pads,torque,vertical)
        physical = combine_maps(applied,left,right)
        ops.timeSeries("Linear",tag)
        ops.pattern("Plain",tag,tag)
        for node,value in physical.items():
            if any(value):
                ops.load(node,*value)

    def phase(states,torque_start,vertical_end):
        for f in (.5,1.):
            if ops.analyze(1) or not isclose(ops.getTime(),f,rel_tol=0.,abs_tol=1e-14):
                raise RuntimeError(("Elastic checkpoint failed",f))
            torque,vertical = (torque_start,vertical_end*f) if vertical_end else (torque_start*f,0.)
            states.append(inspect(model,pads,torque,vertical))

    set_load(1,rig.TORQUE,0.)
    ops.constraints("Transformation")
    ops.numberer("RCM")
    ops.system("UmfPack")
    ops.algorithm("Linear")
    ops.integrator("LoadControl",.5)
    ops.analysis("Static")
    states = []
    phase(states,rig.TORQUE,0.)
    ops.loadConst("-time",0.)
    set_load(2,0.,20_000.)
    phase(states,rig.TORQUE,20_000.)
    return {**meta,"OpenSees":ops.version(),"states":states}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs",action="store_true")
    mode.add_argument("--run",action="store_true")
    opts = parser.parse_args()
    if sha256((BASE/"MVT2Elastic.py").read_bytes()).hexdigest().upper() != RIG_SHA:
        raise ValueError("Elastic rig identity changed")
    geometry = rig.Geometry(60.,1)
    rig.basis_check(geometry)
    pads = (pad_weights(geometry,-HALF_LEVER,-120.),pad_weights(geometry,HALF_LEVER,120.))
    precision_basis(geometry,pads)
    meta = {"rig_source_sha256":RIG_SHA,"x_z_centroid_mm":[[-96.,500.],[96.,500.]],
            "opposing_faces_y_mm":[-120.,120.],"pad_x_z_extent_mm":[2.*PATCH_X_HALF,2.*PATCH_Z_HALF],
            "support_nodal_weights":pads,"numerical_gauge_rank":6,"physical_average_constraint_rank":6,
            "peak_allowed_force_moment_normalized_N":rig.MAX_BALANCE_ERROR,"physical_limit_established":False}
    if opts.check_inputs:
        print("MVT2_DISTRIBUTED_INPUTS_OK",json.dumps(meta,allow_nan=False))
        return
    output = HERE / "ElasticDistributedResult.json"
    if output.exists():
        raise FileExistsError(output)
    proof = solve(geometry,pads,meta)
    output.write_text(json.dumps(proof,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    print("MVT2_DISTRIBUTED_ELASTIC_PASS",output)


if __name__ == "__main__":
    main()
