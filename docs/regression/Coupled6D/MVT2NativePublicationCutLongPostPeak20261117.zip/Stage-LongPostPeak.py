"""Продолжает MVT2 из архивной истории после первого спада."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile
import json


HERE = Path(__file__).resolve().parent
ARCHIVE = 'MVT2NativePublicationCutPostPeak20261117.zip'
ARCHIVE_SHA = 'BF9D72D7D2DE15889534285A690753F3892F5E761F4591C5862F9D1BD8056525'


def digest(data):
    return sha256(data).hexdigest().upper()


def stage(repo, target):
    archive = repo / 'docs/regression/Coupled6D' / ARCHIVE
    assert digest(archive.read_bytes()) == ARCHIVE_SHA
    with ZipFile(archive) as pinned:
        old = pinned.read('Replay.Fields.csv').decode('ascii').splitlines()
        records = json.loads(pinned.read('PostPeakProof.json'))['fields']
        loads = {row['phase']:row['Qy_N'] for row in records}
        for row in pinned.read('Native/Operators.csv').decode('ascii').splitlines():
            if row.startswith('F;PostPeak'):
                _, label, *values = row.split(';')
                old.append(';'.join((label, f'{loads[label]:.15g}', '10510000', *values)))
        assert len(old) == 56
        assert old[-1].split(';')[:3] == ['PostPeak20','22317.8850066221','10510000']
        assert old[-2].split(';')[:3] == ['PostPeak19','22317.8888079934','10510000']
    prior = run_path(str(HERE/'Stage-PostPeak.py'))
    prior['stage'](repo, target)
    replay = target / 'Replay.Fields.csv'
    replay.write_bytes(('\r\n'.join(old)+'\r\n').encode('ascii'))
    test = target / 'tests/modTestMVT2GaussSpan.bas'
    source = test.read_text(encoding='utf-8-sig')
    change = run_path(str(HERE/'Stage-Follow.py'))['replace_once']
    for a,b in (
        ('Q_ACCEPTED As Double = 22377.4648255896','Q_ACCEPTED As Double = 22317.8850066221'),
        ('If history.Count <> 36 Or','If history.Count <> 56 Or'),
        ('leftField = history.Item(35): rightField = history.Item(36)', 'leftField = history.Item(55): rightField = history.Item(56)'),
        ('MVT2_POST_PEAK_REPLAY;36;22377.4648255896','MVT2_LONG_POST_PEAK_REPLAY;56;22317.8850066221'),
        ('START_Q As Double = 22.3774648255896, LEFT_Q As Double = 22.382470120887',
         'START_Q As Double = 22.3178850066221, LEFT_Q As Double = 22.3178888079934'),
        ('PROBE_LIMIT As Long = 28','PROBE_LIMIT As Long = 32'),
        ('+ 256# * initialWidth','+ 1024# * initialWidth'),
        ('16# * initialWidth','64# * initialWidth'),
        ('"MVT2_POST_PEAK;"','"MVT2_LONG_POST_PEAK;"'),
    ):
        source = change(source,a,b)
    test.write_bytes(source.replace('\n','\r\n').encode('utf-8-sig'))
    meta_file = target / 'Preparation.json'
    data = json.loads(meta_file.read_bytes())
    data['follow_mode'] = 'LongPostPeak'
    data['follow_history_archive'] = ARCHIVE_SHA
    for f in (replay,test):
        data['inputs'][f.relative_to(target).as_posix()] = digest(f.read_bytes())
    meta_file.write_bytes((json.dumps(data,indent=2)+'\n').encode())
    print('LONG POST PEAK PREPARED',data['inputs']['Replay.Fields.csv'])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--stage', type=Path, required=True)
    args = parser.parse_args()
    stage(args.repo.resolve(),args.stage.resolve())
