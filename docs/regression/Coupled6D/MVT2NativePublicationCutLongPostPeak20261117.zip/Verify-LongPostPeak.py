"""Проверяет продолжение MVT2 выше первого локального максимума."""

from argparse import ArgumentParser
from hashlib import sha256
from itertools import product
import json
from math import isclose
from pathlib import Path
from zipfile import ZipFile

ARCHIVE = 'MVT2NativePublicationCutPostPeak20261117.zip'
ARCHIVE_SHA = 'BF9D72D7D2DE15889534285A690753F3892F5E761F4591C5862F9D1BD8056525'
FOLLOW = 'MVT2NativePublicationCutFollow20261117.zip'
FOLLOW_SHA = '9F55DE3FC0B1B652DD1ED9683507423ADE4DF6AB3B008D9590EE1D9327F9864E'
BOOK_SHA = '6C9A63BC5E52928978D4F5F8427916C4CA57A03C237678DFB4583C8F1190D84E'
FIELDS_SHA = 'B3A0BAEED9121DD5F38897ADFA1F4B0B71EEF87E8933A7D79796E7990488B206'
LAST = 'PostPeak20'
PREVIOUS = 'PostPeak19'


def digest(data):
    return sha256(data).hexdigest().upper()


def close(a, b, limit):
    return isclose(a, b, rel_tol=0., abs_tol=limit)


def verify(repo, root):
    evidence = repo / 'docs/regression/Coupled6D'
    follow = {'__name__': '__pinned__'}
    assert digest((evidence / FOLLOW).read_bytes()) == FOLLOW_SHA
    assert digest((evidence / ARCHIVE).read_bytes()) == ARCHIVE_SHA
    with ZipFile(evidence / FOLLOW) as archive:
        exec(compile(archive.read('Verify-NativeFollow.py'), FOLLOW, 'exec'), follow)
    utility, recovery, _, _, _, mesh = follow['read_references'](repo)
    with ZipFile(evidence / ARCHIVE) as archive:
        old = utility['read_operators'](archive.read('Native/Operators.csv'))
        old_frames = utility['read_tensor_frames'](archive.read('Native/MVTGaussMixed.Tensor.csv'), 45)
        old_wire = archive.read('Replay.Fields.csv')
        prior_max = json.loads(archive.read('PostPeakProof.json'))['prior_maximum_N']

    native = root / 'Native'
    log = (native / 'MVTGaussMixed.txt').read_text(encoding='utf-8-sig')
    ending, pid, ticks = follow['owner_check'](root, log, recovery)
    assert ending == 'completed'
    assert follow['read_json'](root / 'CodeUpdate.json')['WorkbookSHA256'] == BOOK_SHA
    prep = follow['read_json'](root / 'Preparation.json')
    assert prep['follow_mode'] == 'LongPostPeak' and prep['follow_history_archive'] == ARCHIVE_SHA
    assert prep['source_book_sha256'] == recovery['BOOK_SHA']
    for name in ('Run-Native.ps1', 'Replay.Fields.csv', 'tests/modTestMVT2GaussSpan.bas'):
        assert digest((root / name).read_bytes()) == prep['inputs'][name]
    history = (root / 'Replay.Fields.csv').read_bytes()
    assert digest(history) == FIELDS_SHA and history.startswith(old_wire)
    tail = [line.split(';') for line in history[len(old_wire):].decode('ascii').splitlines()]
    assert [row[0] for row in tail] == [f'PostPeak{i}' for i in range(1, 21)]
    for name, q, t, *field in tail:
        assert tuple(map(float, field)) == old['F'][name]
        assert (float(t), float(q)) == old_frames[name][:2]

    operators = utility['read_operators']((native / 'Operators.csv').read_bytes())
    frames = utility['read_tensor_frames']((native / 'MVTGaussMixed.Tensor.csv').read_bytes(), 45)
    rows = [line.split(';') for line in (native / 'MVTGaussMixed.csv').read_text(encoding='cp1251').splitlines()]
    assert recovery['geometry'](rows) == mesh and all(operators[k] == old[k] for k in 'GLBSR')
    assert operators['F']['Replay'] == old['F'][LAST]
    assert frames['Replay'][:2] == old_frames[LAST][:2]
    replay_error = max(abs(a - b) for side, point in product((-1, 0, 1), mesh[1])
                       for a, b in zip(operators['H']['Replay', side, point], old['H'][LAST, side, point], strict=True))
    assert replay_error < 5e-12 and 'MVT2_LONG_POST_PEAK_REPLAY;56;22317.8850066221' in log
    scale = 1000. / mesh[0][3]
    previous_axis, theta = old['F'][PREVIOUS][3], old['F'][LAST][3]
    previous_q, q = old_frames[PREVIOUS][1] / 1000., old_frames[LAST][1] / 1000.
    initial = theta - previous_axis
    width, ceiling = initial, theta + 1024. * initial
    fields = [{'phase': 'Replay', 'Qy_N': 1000. * q, 'twist_rad_per_m': scale * theta,
               'equilibrium': recovery['equations']('Replay', frames['Replay'], operators, mesh)}]
    trials = [row for row in rows if row[0] == 'MVT2_LONG_POST_PEAK']
    attempts = []
    assert len(trials) == 30
    for i, row in enumerate(trials, 1):
        _, tag, base, target, old_q, estimate, actual, ok, internal, code, *details = row
        assert tag == f'PostPeak{i}' and ';'.join(row) in log and width >= initial / 32.
        wanted = min(theta + width, ceiling)
        predictor = q + (wanted - theta) / (theta - previous_axis) * (q - previous_q)
        assert close(float(base), theta, 3e-17) and close(float(target), wanted, 3e-17)
        assert close(float(old_q), q, 2e-12) and close(float(estimate), predictor, 1e-10)
        work = follow['trial_work'](details, ok, internal, code)
        attempts.append(work | {'phase': tag, 'twist_rad_per_m': scale * wanted, 'estimated_Qy_N': 1000. * float(estimate)})
        if not work['accepted']:
            assert tag not in frames and tag not in operators['F'] and float(actual) == 0.
            width /= 2.
            continue
        new = operators['F'][tag][3]
        assert new > theta and close(new, wanted, 3e-17)
        assert frames[tag][0] == follow['TORQUE'] and close(frames[tag][1], float(actual) * 1000., 2e-8)
        fields.append({'phase': tag, 'Qy_N': frames[tag][1], 'twist_rad_per_m': scale * new,
                       'equilibrium': recovery['equations'](tag, frames[tag], operators, mesh)})
        previous_axis, theta = theta, new
        previous_q, q = q, float(actual)
        width = min(width * 2., 64. * initial)

    names = [field['phase'] for field in fields]
    assert list(frames) == list(operators['F']) == names
    assert set(operators['H']) == set(product(names, (-1, 0, 1), mesh[1]))
    finish, = [row for row in rows if row[0] == 'CASE_FINISHED']
    assert finish[2] == 'False' and 0. < float(finish[3]) < 165.
    assert theta < ceiling and width < initial / 32. and len(fields) == 14
    crossing = next(field for field in fields if field['Qy_N'] > 22500.)
    assert crossing['phase'] == 'PostPeak8' and fields[-1] == max(fields, key=lambda field: field['Qy_N'])
    assert fields[-1]['Qy_N'] > crossing['Qy_N'] > prior_max
    return {'attempts': attempts, 'fields': fields, 'first_above_22_5_kN': crossing, 'end': fields[-1],
            'prior_maximum_N': prior_max, 'max_net_stress_replay_delta_MPa': replay_error,
            'macro_seconds': float(finish[3]), 'excel_closed_pid': pid, 'excel_closed_ticks': ticks,
            'stop_reason': 'next_step_below_minimum', 'physical_limit_established': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    result = verify(args.repo.resolve(), args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(result, output, indent=2, sort_keys=True, allow_nan=False)
        output.write('\n')
    print('MVT2 LONG POST PEAK OFFLINE PASS 13')
