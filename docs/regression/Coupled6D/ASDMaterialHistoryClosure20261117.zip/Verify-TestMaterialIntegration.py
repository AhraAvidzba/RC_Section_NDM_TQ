"""ДЛЯ ТЕСТОВ: проверяет материальный шаг, две нативные истории и соответствие фактической библиотеке."""

from argparse import ArgumentParser
from base64 import b64decode
from hashlib import sha1, sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


KRYLOV = ('KrylovFallbackNative20261117.zip', 'C31C5EFABADD5CB81A790C4E5432DBCCDBAE587D3A4639D666881ACCA2BDD633')
BINARY = '25BA42E1672526137D765D9C3631D1403E091F54F5AFCDB9242F9243C63C3A96'


def TestRead(file):
    """Читает точные нативные квитанции, включая BOM."""
    return json.loads(file.read_text('utf-8-sig'))


def TestNative(repo, folder, helper, scope):
    """Декодирует реальный VBA и подтверждает предел фактически выполненного направленного набора."""
    prep, compiler = TestRead(folder/'Preparation.json'), TestRead(folder/'CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged']
    assert compiler['ProductionSHA256'] == prep['source_book_sha256']
    assert TestRead(folder/'CompileClosure.json')['State'] == 'Absent'
    log = (folder/'Native/MVTGaussMixed.txt').read_text('utf-8-sig')
    assert f"SOURCE_SHA256: {compiler['WorkbookSHA256']}" in log
    assert not re.search(r'^(FAIL:|RUNTIME ERROR:|TIMEOUT)', log, re.M)
    close = TestRead(folder/'Native/MVTGaussMixed.txt.ProcessClosure.json')
    owner = TestRead(folder/'Native/MVTGaussMixed.txt.Ownership.json')
    assert close['Passed'] and close['RunnerCleanupValid'] and close['ChildExitCode'] == 0
    assert close['Closure']['FinalState']['State'] == 'Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == compiler['WorkbookSHA256']
    assert close['Closure']['Identity']['PID'] == owner['PID'] and close['Closure']['Identity']['Ticks'] == int(owner['StartTicksUTC'])
    assert len(compiler['Modules']) == 9
    guard = folder/'Guard-IsolatedOffice.ps1'
    assert sha256(guard.read_bytes()).hexdigest().upper() == prep['inputs'][guard.name]
    safe_phases = []
    blocked = 0
    for row in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines():
        record = json.loads(row)
        assert record['ramMiB'] >= 6500 and record['freeCommitGiB'] >= 6
        if all(p['ProtectedUser'] for p in record['excel']):
            safe_phases.append(record['phase'])
        else:
            assert not safe_phases  # Отклонённые предварительные проверки до запуска какого-либо собственного Excel.
            blocked += 1
    assert len(safe_phases) == 2 and safe_phases[0].startswith('Compile') and safe_phases[1].startswith('Verify')
    with helper['TestArchive'](repo, helper['BASE']) as archive:
        observer, sources = helper['TestScript'](archive, 'Stage-Release.py')['parse_vba'](repo)
    _, actual = sources(helper['TestContainer']((folder/'CompiledVBA.bin').read_bytes()))
    conversions = {}
    for name in compiler['Modules']:
        files = [p for base in ('src', 'tests') for p in (folder/base).rglob(name+'.*') if p.suffix in ('.bas', '.cls')]
        assert len(files) == 1
        alias = 'modTestMVT2GaussSpan' if name.startswith('modTestMVT2Closure') else name
        expected, edits = helper['TestMVTCompilerBody'](observer['compiler_body'], files[0].read_text('utf-8-sig'), alias)
        assert expected == observer['compiler_body'](actual[name], name)[0], name
        if edits:
            conversions[name] = edits
    assert 'не одно обновление библиотеки' in actual['CTestTabulatedConcreteFlow']
    finished, seconds = re.findall(r'^CASE_FINISHED;MVTGaussMixed;(True|False);([^\n]+)$', log, re.M)[0]
    if scope == 'First':
        assert finished == 'True' and 'TOTAL_MVT2_CLOSURE_FIRST_MIXED: passed=1; failed=0; target_reached=True' in log
    else:
        assert finished == 'False' and 'TOTAL_MVT2_CLOSURE_FORCE_PATH: passed=1; failed=0; target_reached=False' in log
        assert 'MVT2_CUT_TRIAL;S27;10510000;62500;-24750000;False;' in log
    return {'native_macro_seconds': float(seconds), 'scope_completed': finished == 'True',
            'compiled_modules': compiler['Modules'], 'compiled_sha256': compiler['WorkbookSHA256'],
            'blocked_external_preflights': blocked, 'compiler_conversions': conversions}


def TestVerify(repo, root, output):
    """Повторяет существенные численные свидетельства, сохраняя отрицательные результаты и физические ограничения."""
    raw = (repo/'docs/regression/Coupled6D'/KRYLOV[0]).read_bytes()
    assert sha256(raw).hexdigest().upper() == KRYLOV[1]
    with ZipFile(BytesIO(raw)) as archive:
        helper = {'__name__': '__pinned__', '__file__': 'Verify-TestKrylovFallback.py'}
        exec(compile(archive.read('Verify-TestKrylovFallback.py'), helper['__file__'], 'exec'), helper)
    native = {name: TestNative(repo, root/name, helper, name) for name in ('First', 'Full')}
    assert (root/'Native/Operators.csv').read_bytes() == (root/'First/Native/Operators.csv').read_bytes()
    with TemporaryDirectory(dir=root) as directory:
        temp = Path(directory)
        run_path(str(root/'Probe-TestASDMaterialSteps.py'))['TestProbe'](repo, temp/'Steps.json', 8)
        assert (temp/'Steps.json').read_bytes() == (root/'MaterialSteps.json').read_bytes()
        run_path(str(root/'Probe-TestASDClosure.py'))['TestRun'](repo, temp/'Closure.json')
        assert (temp/'Closure.json').read_bytes() == (root/'MaterialClosure.json').read_bytes()
        run_path(str(root/'Check-TestASDSourceBehavior.py'))['TestVerify'](repo, root/'SourcePointOpenSees.json.gz', temp/'Source.json')
        assert (temp/'Source.json').read_bytes() == (root/'SourcePointChecks.json').read_bytes()
        run_path(str(root/'Replay-TestASDIntegration.py'))['TestVerify'](repo, root, root/'IntegrationFullOpenSees.json.gz', temp/'Integration.json')
        assert (temp/'Integration.json').read_bytes() == (root/'IntegrationFullChecks.json').read_bytes()
        run_path(str(root/'Continue-TestClosedASDNative.py'))['TestContinue'](repo, root/'Full/Native', temp/'Continuation.json')
        assert (temp/'Continuation.json').read_bytes() == (root/'ClosedNativeContinuation.json').read_bytes()
    source = TestRead(root/'GitHub-file.json')
    content = b64decode(source['content'])
    assert sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest() == source['sha'] == '000c50a2f927ff05ef82f424c93dab20b62ba504'
    assert sha256(content).hexdigest().upper() == '210EADE9C167DA38FB5A7894570C64BA0CA35D9D9307A9818FDE485435EBEA31'
    assert TestRead(root/'GitHub-tag.json')['object']['sha'] == '6e55293513192aa05c7e1205e66a5a1a1ed088c4'
    identity = TestRead(root/'EngineIdentity.json')
    assert identity['native_sha256'] == BINARY and identity['version'] == '3.8.0' and identity['NDTest'] == '<built-in function NDTest>'
    source_check = TestRead(root/'SourcePointChecks.json')
    assert source_check['states'] == 24 and source_check['separate_prediction_error_MPa'] < 8e-7
    assert source_check['additional_mixing_prediction_error_MPa'] > 1. and not source_check['source_behavior_correspondence_established']
    integration = TestRead(root/'IntegrationFullChecks.json')
    continuation = TestRead(root/'ClosedNativeContinuation.json')
    assert len(continuation['native_replay']) == 35 and all(not t['accepted'] for t in continuation['trials'])
    adaptive = TestRead(root/'ClosedForceNdmAdaptive.json')
    accepted = [r for r in adaptive['preload'] if r['accepted']]
    assert len(accepted) == 17 and len(adaptive['preload']) == 35 and not adaptive['preload'][-1]['accepted']
    assert accepted[-1]['target'][3] == 10233772.916793823 and not adaptive['mixed_trials']
    for row in accepted:
        assert row['norms_MPa'][-1] <= row['tolerance_MPa']
    proof = {'native': native, 'opensees_updates': sum(c['updates'] for c in integration['cases'].values()),
             'native_accepted_states': 35, 'last_native_Qy_N': continuation['native_replay'][-1]['Qy_N'],
             'native_material_error_MPa': continuation['native_material_error_MPa'], 'source_behavior': source_check,
             'NDM_closed_confirmed_T_Nmm': accepted[-1]['target'][3], 'physical_capacity_certified': False,
             'integration_modified': True, 'candidate_installed': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('ASD MATERIAL HISTORY AND NATIVE VBA VERIFIED; PHYSICAL CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestVerify(args.repo.resolve(), args.root.resolve(), args.out.resolve())
