﻿# Запускает одну направленную проверку в проверенной частной книге Excel.
param([ValidateSet('MVTGaussMixed')][string]$Case = 'MVTGaussMixed',[switch]$CompiledOnly)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$tempBefore=$env:TEMP
$tmpBefore=$env:TMP
$flowBefore=$env:NDM_MVT_FLOW_FOLDER
$modeBefore=$env:NDM_MVT_FLOW_MODE
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$report="Native/$Case.txt"
$modules=@('CCoupledSectionQuadrature','CCoupledElasticState','modTestMVT2ClosureForcePath','CCoupledConcreteResponse','CTestConcreteBackbone','CTestTabulatedConcreteFlow','CCoupledNewtonSolver','CCoupledSteelCorrection','CCoupledReinforcedResponse')
Push-Location -LiteralPath $root
try {
    . './Guard-IsolatedOffice.ps1'
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    foreach ($frozenFile in $prep.inputs.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $frozenFile.Name).Hash -cne $frozenFile.Value) {
            throw "Не совпали байты тестового входа $($frozenFile.Name)."
        }
    }
    if (Test-Path -LiteralPath $report) {throw 'Для этой проверки уже есть протокол.'}
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    $env:NDM_MVT_FLOW_FOLDER=$root
    $env:NDM_MVT_FLOW_MODE='default'
    if (!$CompiledOnly) {
        if ((Test-Path -LiteralPath 'Compile.log') -or
            (Get-FileHash -LiteralPath $draft).Hash -cne $prep.source_book_sha256) {throw 'Изменена исходная книга теста.'}
        Assert-IsolatedOfficeReady 'CompileMVT2GaussSpan'
        & './tools/build_workbook/Update-IsolatedOptimizerCode.ps1' -WorkbookPath $draft -ModuleNames $modules |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $compiled.Modules.Count -ne $modules.Count -or
        (Compare-Object ($modules | Sort-Object) ($compiled.Modules | Sort-Object)) -or
        $compiled.ProductionSHA256 -cne $prep.source_book_sha256 -or $closure.State -cne 'Absent' -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash) {throw 'Не подтверждена тестовая компиляция.'}
    Assert-IsolatedOfficeReady "VerifyMVT2GaussSpan$Case"
    $timeout='165'
    $run=@('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-FocusedKaniWatchdog.ps1',
        '-SourceWorkbook',$draft,'-ReportPath',$report,'-Macro','modTestMVT2ClosureForcePath.RunTestMVT2ClosureForcePath',
        '-MacroArgument1',$Case,'-Mode','No','-TimeoutSeconds',$timeout,'-FailFast')
    & $legacy @run
    $exitCode=$LASTEXITCODE
    $fixtures=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixtures.Count -ne 1) {throw 'Нет однозначного пути к копии.'}
    $folder=Split-Path -Parent $fixtures[0].Substring('FIXTURE: '.Length)
    if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь вне временного каталога.'}
    $trace=Join-Path $folder 'MVT2GaussSpan.csv'
    if (Test-Path -LiteralPath $trace) {Copy-Item -LiteralPath $trace -Destination "Native/$Case.csv"}
    if ($exitCode -ne 0) {throw "Нативная проверка завершилась с кодом $exitCode."}
    $tensorWire=$trace+'.Tensor.csv'
    Copy-Item -LiteralPath $tensorWire -Destination "Native/$Case.Tensor.csv"
    Copy-Item -LiteralPath ($trace+'.Operators.csv') -Destination "Native/Operators.csv"

}
finally {
    $env:TEMP=$tempBefore
    $env:TMP=$tmpBefore
    $env:NDM_MVT_FLOW_FOLDER=$flowBefore
    $env:NDM_MVT_FLOW_MODE=$modeBefore
    Pop-Location
}
