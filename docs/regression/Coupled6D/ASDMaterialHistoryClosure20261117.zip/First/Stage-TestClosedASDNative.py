"""ДЛЯ ТЕСТОВ: готовит нативный контроль восьми T-ступеней и первой совместной цели."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestStage(root, mode):
    """Меняет только тестовую интеграцию материала и создаёт явно ограниченный новый тест."""
    here = Path(__file__).resolve().parent
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/VBAFlowIntegratedCore')
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, digest in prep['inputs'].items():
        raw = (template/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == digest
        files[name] = raw
    flow = 'src/Materials/CTestTabulatedConcreteFlow.cls'
    code = files[flow].decode('utf-8-sig').replace('\r\n', '\n')
    needle = 'Friend Sub TestStep('
    assert code.count(needle) == 1
    code = code.replace(needle, 'Private Sub TestSingleStep(')
    code += '\n'+(here/'TestClosedASDStep.bas.txt').read_text('utf-8')
    files[flow] = code.replace('\n', '\r\n').encode('utf-8-sig')
    old = 'tests/modTestMVT2GaussSpan.bas'
    new = 'tests/modTestMVT2ClosureFirstMixed.bas'
    code = files.pop(old).decode('utf-8-sig').replace('\r\n', '\n')
    code = code.replace('modTestMVT2GaussSpan', 'modTestMVT2ClosureFirstMixed')
    code = code.replace('RunTestMVT2GaussSpan', 'RunTestMVT2ClosureFirstMixed')
    code = code.replace('TOTAL_MVT2_GAUSS_SPAN', 'TOTAL_MVT2_CLOSURE_FIRST_MIXED')
    needle = '    goals(37) = 77625#'
    assert code.count(needle) == 1
    code = code.replace(needle, needle+'\n    ReDim Preserve goals(1 To 1) \' ДЛЯ ТЕСТОВ: только первая совместная цель; не полный путь MVT2.')
    files[new] = code.replace('\n', '\r\n').encode('utf-8-sig')
    driver = files['Run-Native.ps1'].decode('utf-8-sig').replace('modTestMVT2GaussSpan', 'modTestMVT2ClosureFirstMixed')
    driver = driver.replace('RunTestMVT2GaussSpan', 'RunTestMVT2ClosureFirstMixed')
    driver = driver.replace("$env:NDM_MVT_FLOW_MODE='default'", f"$env:NDM_MVT_FLOW_MODE='{mode}'")
    files['Run-Native.ps1'] = driver.encode('utf-8-sig')
    files[Path(__file__).name] = Path(__file__).read_bytes()
    files['TestClosedASDStep.bas.txt'] = (here/'TestClosedASDStep.bas.txt').read_bytes()
    files['docs/regression/Diagnostic.xlsm'] = files['workbook/output/RC_Section_NDM.xlsm']
    prep['inputs'] = {name: sha256(raw).hexdigest().upper() for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    prep['test_scope'] = 'eight torque goals and first mixed Qy=2500 N only; not full MVT2 path'
    prep['modified_integration'] = 'repeat ASD at fixed strain until effective stress, nominal stress and E*history changes <= 1e-9 MPa'
    prep['controlled_material'] = mode
    root.mkdir()
    for name in ('Native', 'Temp', 'tests', 'src'):
        (root/name).mkdir(exist_ok=True)
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('CLOSED ASD NATIVE FIRST MIXED INPUTS READY', mode)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--mode', choices=('default', 'ndm_uniaxial'), default='default')
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.mode)
