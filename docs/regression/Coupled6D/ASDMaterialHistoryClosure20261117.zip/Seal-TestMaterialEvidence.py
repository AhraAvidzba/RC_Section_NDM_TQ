"""ДЛЯ ТЕСТОВ: закрепляет проверенные истории ASD одним случаем манифеста."""

from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED


def TestSeal():
    """Сохраняет все прежние случаи и добавляет только исследовательский этап §591."""
    repo = Path.cwd()
    root = Path(__file__).resolve().parent/'MaterialIntegrationBundle'
    output = root/'MaterialIntegrationChecks.json'
    proof = json.loads(output.read_bytes())
    assert proof['native_accepted_states'] == 35 and proof['opensees_updates'] == 86481
    assert not proof['physical_capacity_certified'] and not proof['candidate_installed']
    name = 'ASDMaterialHistoryClosure20261117'
    path = repo/'docs/regression/Coupled6D'/(name+'.zip')
    with path.open('xb') as stream, ZipFile(stream, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for file in sorted(root.rglob('*')):
            if not file.is_file():
                continue
            assert '__pycache__' not in file.parts and file.suffix not in ('.pyc', '.xlsm')
            info = ZipInfo(file.relative_to(root).as_posix(), date_time=(2026, 11, 17, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, file.read_bytes(), compresslevel=9)
    digest = sha256(path.read_bytes()).hexdigest().upper()
    manifest_file = repo/'docs/reports/Coupled6DEvidence.json'
    original = manifest_file.read_text('utf-8')
    manifest = json.loads(original)
    assert name not in manifest['archives']
    old_name, old_digest = list(manifest['archives'].items())[-1]
    manifest['archives'][name] = digest
    case = {'id': 'asd-history-integration-native-vba-and-pinned-reference-behavior', 'journal_section': 591,
            'archive': name, 'script': 'Verify-TestMaterialIntegration.py',
            'arguments': ['--repo', '{repo}', '--root', '.', '--out', 'MaterialIntegrationChecks.json'],
            'stdout_contains': 'ASD MATERIAL HISTORY AND NATIVE VBA VERIFIED; PHYSICAL CAPACITY OPEN',
            'outputs': {'MaterialIntegrationChecks.json': sha256(output.read_bytes()).hexdigest().upper()}}
    manifest['cases'].append(case)
    old = '    '+json.dumps(old_name)+': '+json.dumps(old_digest)
    assert original.count(old) == 1
    updated = original.replace(old, old+',\n    '+json.dumps(name)+': '+json.dumps(digest))
    marker = '\n  ],\n  "frozen_repositories": {'
    assert updated.count(marker) == 1
    block = '\n'.join('    '+row for row in json.dumps(case, ensure_ascii=False, indent=2).splitlines())
    updated = updated.replace(marker, ',\n'+block+marker)
    assert json.loads(updated) == manifest
    manifest_file.write_bytes(updated.replace('\n', '\r\n').encode())
    print('MATERIAL INTEGRATION EVIDENCE SEALED', path.stat().st_size, digest)


if __name__ == '__main__':
    TestSeal()
