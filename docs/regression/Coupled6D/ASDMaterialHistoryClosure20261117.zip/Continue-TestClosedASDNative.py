"""ДЛЯ ТЕСТОВ: проверяет точную отклонённую цель из принятой нативной истории."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestContinue(repo, native, output):
    """Восстанавливает каждый принятый буфер; отклонённые поля в прогноз не передаются."""
    here = Path(__file__).resolve().parent
    inputs = run_path(str(here/'Probe-TestASDMaterialSteps.py'))
    closure = run_path(str(here/'Probe-TestASDClosure.py'))['TestClosure']
    solve = run_path(str(here/'Solve-TestASDClosure.py'))['TestSolve']
    sections, _, _ = inputs['TestInputs'](repo)
    section = sections['default']
    section.TestOriginalNominal = section.nominal
    section.TestClosureIterations = 0
    section.nominal = lambda field, history: closure(section, field, history)
    frames, centers = {}, {}
    for line in (native/'MVTGaussMixed.Tensor.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME':
            phase = row[1]
            frames[phase] = float(row[2]), float(row[3])
            centers[phase] = np.zeros((45, 6))
        elif row[0] == 'POINT':
            centers[phase][int(row[1])-1] = np.asarray(row[8:], dtype=float)
    history, records, points = section.initial(), [], []
    maximum_error = 0.
    for line in (native/'Operators.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] != 'F':
            continue
        phase, field = row[1], np.asarray(row[2:], dtype=float)
        torque, q = frames[phase]
        target = np.array([0., -396.*q, 0., torque, 0., q])
        response = section.evaluate(field, history, target)
        pure_concrete = response[3][0].copy()
        pure_concrete[25:] = response[5][0, :, None]*section.directions-pure_concrete[25:]
        maximum_error = max(maximum_error, float(np.max(np.abs(pure_concrete-centers[phase]))))
        tolerance = 5e-7+5e-7*np.max(np.abs((target@section.l)[:56]))
        assert response[1] <= tolerance, (phase, response[1], tolerance)
        history = response[4]
        records.append({'phase': phase, 'Qy_N': q, 'norm_MPa': float(response[1]), 'tolerance_MPa': float(tolerance)})
        if q > 0.:
            points.append((q, field))
    assert maximum_error < 8e-7 and points[-1][0] == 61718.75, maximum_error
    result = []
    for mode in ('last', 'secant'):
        start = points[-1][1].copy()
        if mode == 'secant':
            qa, fa = points[-2]
            qb, fb = points[-1]
            start += (62500.-qb)/(qb-qa)*(fb-fa)
        field, proposed, record = solve(section, np.array([0., -396.*62500., 0., 10510000., 0., 62500.]), start, history)
        record['seed'] = mode
        result.append(record)
        print(mode, record['accepted'], record['norms_MPa'][-1], flush=True)
    output.write_bytes((json.dumps({'native_replay': records, 'native_material_error_MPa': maximum_error,
                                  'trials': result, 'physical_capacity_certified': False}, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestContinue(args.repo.resolve(), args.native.resolve(), args.out.resolve())
