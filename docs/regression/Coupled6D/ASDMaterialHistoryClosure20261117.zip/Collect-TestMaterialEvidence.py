"""ДЛЯ ТЕСТОВ: собирает источники и фактические свидетельства замыкания ASD."""

from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json


def TestCollect():
    """Сохраняет две частные книги как реальные VBA-контейнеры и полный набор направленных протоколов."""
    here = Path(__file__).resolve().parent
    root = here/'MaterialIntegrationBundle'
    root.mkdir()
    scripts = ('Probe-TestASDMaterialSteps.py', 'Probe-TestASDClosure.py', 'Solve-TestASDClosure.py',
               'Check-TestASDSourceBehavior.py', 'Replay-TestASDIntegration.py', 'Continue-TestClosedASDNative.py',
               'Stage-TestClosedASDNative.py', 'TestClosedASDStep.bas.txt', 'Collect-TestMaterialEvidence.py',
               'Verify-TestMaterialIntegration.py')
    data = ('MaterialSteps.json', 'MaterialClosure.json', 'ClosedForceNdm.json', 'ClosedForceNdmAdaptive.json',
            'ClosedForceDefault.json', 'ClosedNativeContinuation.json', 'SourcePointOpenSees.json.gz',
            'SourcePointChecks.json', 'EngineIdentity.json', 'SourceComparison.json', 'GitHub-tag.json',
            'GitHub-file.json', 'GitHub-history.json', 'ReplayResources.json', 'IntegrationFullOpenSees.json.gz',
            'IntegrationFullChecks.json')
    for name in (*scripts, *data):
        (root/name).write_bytes((here/name).read_bytes())
    for variant, folder in (('First', 'ClosedASDFirstMixed20261117'), ('Full', 'ClosedASDForcePath20261117')):
        source = Path('D:/CodexScratch/RC_Section_NDM_TQ')/folder
        target = root/variant
        target.mkdir()
        for file in source.rglob('*'):
            relative = file.relative_to(source)
            if not file.is_file() or relative.parts[0] in ('Temp', 'workbook', 'tools', 'docs') or file.suffix == '.xlsm':
                continue
            path = target/relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(file.read_bytes())
        compiled = source/'docs/regression/Diagnostic.xlsm'
        metadata = source/'docs/regression/CodeUpdate.json'
        if not metadata.exists():
            metadata = source/'CodeUpdate.json'
        (target/'CodeUpdate.json').write_bytes(metadata.read_bytes())
        compiler = json.loads(metadata.read_text('utf-8-sig'))
        raw = compiled.read_bytes()
        assert sha256(raw).hexdigest().upper() == compiler['WorkbookSHA256']
        with ZipFile(compiled) as archive:
            (target/'CompiledVBA.bin').write_bytes(archive.read('xl/vbaProject.bin'))
    (root/'Native').mkdir()
    for name in ('Operators.csv', 'MVTGaussMixed.Tensor.csv'):
        (root/'Native'/name).write_bytes((root/'First/Native'/name).read_bytes())
    print('MATERIAL INTEGRATION EVIDENCE COLLECTED')


if __name__ == '__main__':
    TestCollect()
