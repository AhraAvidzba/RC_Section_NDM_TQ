"""ДЛЯ ТЕСТОВ. Проверяет рабочее продолжение без автоматического дорогого перехода к полной секущей."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Сохраняет явные численные опции API, стандартные регрессии и чтение полей фактического Both/Excel."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingConditioned.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    assert b'TryChangeSpatialSecantControl' not in (root / 'src/Solver/CCoupledDeformationContinuation.cls').read_bytes()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'DefaultRecoveryWithoutAutomaticSecant',
        'accepted_secant_fallback_after_reverse': False,
        'unresolved_load_change_does_not_block_verified_forward_secant_field': False,
        'automatic_expensive_secant_continuation': False,
        'explicit_conditioned_step_API_retained': True,
        'all_material_and_equilibrium_limits_unchanged': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('DEFAULT RECOVERY WITHOUT AUTOMATIC EXPENSIVE SECANT READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
