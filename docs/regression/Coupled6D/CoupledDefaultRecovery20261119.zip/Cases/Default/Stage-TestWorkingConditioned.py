"""ДЛЯ ТЕСТОВ. Проверяет рабочий масштабированный резерв на точной истории и в штатном запуске."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Рабочие классы импортируются без опытных изменений; тестовые точки только задают воспроизводимый вход."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestSecantProjection.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    changes = {
        '    For index = 1 To 4': '    For index = 1 To 1',
        '        For probeVariant = 0 To 4': '        For probeVariant = 3 To 4',
        '            If probeVariant > 0 Then absTol = GeomMin(absTol, 0.0000000001): relTol = GeomMin(relTol, 0.0000000001)': '',
        'allowHybridRecovery:=(probeVariant > 0))': 'allowHybridRecovery:=True, conditionHybridRecovery:=True)'}
    for old, new in changes.items():
        assert code.count(old) == 1, old
        code = code.replace(old, new, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'Compile','ReversePolish'"
    assert code.count(old) == 1
    code = code.replace(old, "'Compile','HybridCore','ReversePolish'", 1)
    old = "        if ($Phase -eq 'ReversePolish') {"
    assert code.count(old) == 1
    code = code.replace(old, '''        if ($Phase -eq 'HybridCore') {
            $arguments+=@('-Macro','modTestCoupledHybrid.RunTestCoupledHybrid','-TimeoutSeconds','120')
        } elseif ($Phase -eq 'ReversePolish') {''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'WorkingConditionedSecant', 'runtime_automatic_scaling_option': True,
        'runtime_fresh_matrix_option': True, 'accepted_secant_fallback_after_reverse': True,
        'unresolved_load_change_does_not_block_verified_forward_secant_field': True,
        'full_acceptance_completed': False, 'installed_workbook_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('WORKING CONDITIONED SECANT API AND ACTUAL WORKBOOK VALIDATION READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
