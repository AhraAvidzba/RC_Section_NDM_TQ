"""ДЛЯ ТЕСТОВ. Проверяет возврат стандартного продолжения и явно незавершённый физический предел."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestFiles(root):
    """Байты исходных отказов и фактического исполнения закреплены без округления ключей."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    checkpoint = json.loads((root / 'SourceCheckpoint.json').read_bytes())
    assert checkpoint['base'] == 'bdf4b29' and not checkpoint['automatic_expensive_secant_continuation']
    assert checkpoint['controller_sha256'] == 'AED218A5DCDA3E5D6C153242926C1CB810D7966587B6044C339D5AF018CFE3F4'
    assert sha256((root / 'Baseline/WorkingController.cls').read_bytes()).hexdigest().upper() == checkpoint['controller_sha256']
    private = (root / 'Cases/Default/src/Solver/CCoupledDeformationContinuation.cls').read_bytes()
    assert sha256(private).hexdigest().upper() == checkpoint['private_instrumented_controller_sha256']
    assert b'TryChangeSpatialSecantControl' not in private


def TestNative(repo, root, output):
    """Проверяет CFB, целевые регрессии, сохранение Results и завершение собственных Excel."""
    TestFiles(root)
    folder = root / 'Cases/Default'
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        proof = Path(temporary) / 'Code.json'
        run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit'](repo, folder, proof)
        record = json.loads(proof.read_bytes())
    assert (record['components'], record['imported'], record['unchanged']) == (244, 30, 214)
    assert len(record['checked_coupled_sources']) == 33
    phases = {'HybridCore': 36, 'Core': 382, 'PeakRegression': 168, 'ActualReverse': 29}
    assert {file.stem for file in (folder / 'Native').glob('*.txt')} == set(phases)
    reports = {}
    for phase, total in phases.items():
        path = folder / 'Native' / (phase + '.txt')
        log = path.read_text('utf-8-sig')
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log and 'RUNTIME ERROR:' not in log
        totals = re.findall(r'^TOTAL[^:\r\n]*:\s*passed=(\d+);\s*failed=(\d+)', log, re.M)
        assert (sum(int(a) for a, b in totals), sum(int(b) for a, b in totals)) == (total, 0)
        source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
        assert source == record['compiled_workbook_sha256']
        closure = json.loads(path.with_name(path.name + '.ProcessClosure.json').read_bytes())
        assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
        assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
        reports[phase] = {'passed': total, 'failed': 0, 'owned_excel_absent': True}
    record.update(native_reports=reports, installed_workbook_changed=False,
                  full_acceptance_completed=False, physical_capacity_certified=False)
    output.write_text(json.dumps(record, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('DEFAULT RECOVERY ACTUAL VBA AND DIRECTED REGRESSIONS VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Сравнивает время одного запуска, исходные 26 полей и все уравнения; предел не подменяет нижней оценкой."""
    TestFiles(root)
    folder = root / 'Cases/Default'
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        proof = Path(temporary) / 'Mechanics.json'
        run_path(str(root / 'Check-TestActualReverseCapture.py'))['TestCheck'](folder, proof)
        actual = json.loads(proof.read_bytes())
    read = run_path(str(root / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original = read(root / 'Baseline/Original26.bin')
    current = read(folder / 'Native/ActualReverse.Reverse1.bin')
    for name in ('calibration', 'options', 'offset', 'direction', 'fields', 'lambdas', 'fractions'):
        assert np.array_equal(original[name], current[name]), name
    def TestTiming(path):
        """Время включает штатный Both/Excel до записи Results, дальнейший тестовый экспорт полей исключён."""
        log = path.read_text('utf-8-sig')
        seconds, = re.findall(r'^TIMING_SECONDS: ([0-9.]+) \| Both \| Excel$', log, re.M)
        factor, = re.findall(r'^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([0-9.]+); limit=; code=NUMERICAL_FAILURE$', log, re.M)
        return float(seconds), float(factor)
    old_seconds, old_lambda = TestTiming(root / 'Baseline/ExpensiveActual.txt')
    seconds, factor = TestTiming(folder / 'Native/ActualReverse.txt')
    old_proof = json.loads((root / 'Baseline/ExpensiveMechanics.json').read_bytes())
    assert len(old_proof['actual_automatic_history']['states']) == 46
    assert old_proof['actual_workbook_seconds'] == old_seconds
    assert old_seconds == 334.755859375 and old_lambda == 1.10778583044346
    assert factor == 1.10777685521242 and factor < old_lambda
    assert 0 < seconds < old_seconds
    execution = (folder / 'SavedExecutionReport.txt').read_bytes()
    assert execution.startswith(b'\xff\xfe')
    assert 'переходов к полной секущей:' not in execution.decode('utf-16')
    result = {'actual_history': actual, 'original_26_fields_binary_exact': True,
              'direct_status': 'OK', 'capacity_status': 'NumFail',
              'actual_workbook_seconds': seconds, 'confirmed_lower_lambda': factor,
              'expensive_workbook_seconds': old_seconds, 'expensive_lower_lambda': old_lambda,
              'extra_lower_lambda_relative_percent': 100 * (old_lambda / factor - 1),
              'time_ratio_expensive_to_default': old_seconds / seconds,
              'timing_scope': 'one directed run per version, not a statistical performance benchmark',
              'independent_material_reintegration': False, 'physical_capacity_certified': False,
              'full_acceptance_completed': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('DEFAULT RECOVERY ORIGINAL 26 FIELDS AND SAVED EXCEL VERIFIED; EXPENSIVE DEFAULT DISABLED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
