"""ДЛЯ ТЕСТОВ. Различает исходник рабочего контроллера и частную копию с чтением полей."""

from hashlib import sha256
import json
from pathlib import Path


def TestRepair():
    """Исходная ошибка служебной проверки сохраняется; численные данные и ожидания регрессий не меняются."""
    repo = Path.cwd()
    root = Path('D:/CodexScratch/RC_Section_NDM_TQ/DefaultRecoveryEvidence20261119')
    here = Path(__file__).resolve().parent
    failure = root / 'TestPreparationFailures'
    failure.mkdir()
    for name in ('SourceCheckpoint.json', 'Collect-TestDefaultRecovery.py', 'Check-TestDefaultRecovery.py'):
        (failure / name).write_bytes((root / name).read_bytes())
    (failure / 'Reason.json').write_text(json.dumps({'failed_scopes': ['native', 'mechanics'],
        'failed_assertion': 'checkpoint controller_sha256 equals uninstrumented working source',
        'reason': 'collector labelled the instrumented private capture controller as the working controller',
        'native_numerical_runs_changed': False, 'equilibrium_limits_changed': False,
        'correction': 'pin and check both exact working source and instrumented private source separately'}, indent=2)+'\n', encoding='utf-8')
    checkpoint = json.loads((root / 'SourceCheckpoint.json').read_bytes())
    checkpoint['private_instrumented_controller_sha256'] = checkpoint['controller_sha256']
    original = (repo / 'src/Solver/CCoupledDeformationContinuation.cls').read_bytes()
    checkpoint['controller_sha256'] = sha256(original).hexdigest().upper()
    assert checkpoint['controller_sha256'] == 'AED218A5DCDA3E5D6C153242926C1CB810D7966587B6044C339D5AF018CFE3F4'
    (root / 'Baseline/WorkingController.cls').write_bytes(original)
    (root / 'SourceCheckpoint.json').write_text(json.dumps(checkpoint, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    for name in ('Collect-TestDefaultRecovery.py', 'Check-TestDefaultRecovery.py', Path(__file__).name):
        (root / name).write_bytes((here / name).read_bytes())
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('WORKING AND PRIVATE INSTRUMENTED SOURCE SCOPES PINNED SEPARATELY; ORIGINAL CHECK FAILURE RETAINED')


if __name__ == '__main__':
    TestRepair()
