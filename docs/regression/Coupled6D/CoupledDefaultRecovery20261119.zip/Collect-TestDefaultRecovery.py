"""ДЛЯ ТЕСТОВ. Сохраняет направленную проверку отключения дорогого автоматического продолжения."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
from zipfile import ZIP_DEFLATED, ZipFile


def TestCollect(repo, root):
    """Сохраняет исполненный VBA, результаты Excel и исходное сравнение без изменения основной книги."""
    here = Path(__file__).resolve().parent
    scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = {'Default': 'DefaultRecovery20261119'}
    collect(repo, root)
    folder, source = root / 'Cases/Default', scratch / 'DefaultRecovery20261119'
    sources = {}
    for file in sorted((repo / 'src').rglob('*')):
        if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
            continue
        relative = file.relative_to(repo)
        target = folder / relative
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(file.read_bytes())
        sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
    assert len(sources) == 33
    (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    log = (source / 'Native/ActualReverse.txt').read_text('utf-8-sig')
    saved, = re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$', log, re.M)
    assert Path(saved).resolve().is_relative_to((source / 'Temp').resolve())
    with ZipFile(saved) as book, ZipFile(folder / 'SavedWorkbookMarkup.zip', 'x', ZIP_DEFLATED, compresslevel=9) as output:
        for name in sorted(book.namelist()):
            if Path(name).suffix.lower() in ('.xml', '.rels', '.vml'):
                output.writestr(name, book.read(name))
    (folder / 'SavedWorkbookScope.json').write_text(json.dumps({'original_scratch_root': str(source),
        'results_saved_and_reopened': True, 'whole_workbook_preserved': False}, indent=2)+'\n', encoding='utf-8')
    execution, = re.findall(r'Пошаговый отчет сохранен: \| ([^|]+) \|', log)
    execution = Path(execution.strip())
    assert execution.resolve().is_relative_to((source / 'Temp').resolve())
    (folder / 'SavedExecutionReport.txt').write_bytes(execution.read_bytes())
    baseline = root / 'Baseline'
    baseline.mkdir()
    baseline_sources = {
        'Original26.bin': scratch / 'ActualReverseCapture20261119/Native/ActualReverse.Reverse1.bin',
        'ExpensiveActual.txt': scratch / 'ConditionedWorking20261119/Native/ActualReverse.txt',
        'ExpensiveMechanics.json': scratch / 'ConditionedSecantEvidence20261119/MechanicsProof.json'}
    for name, path in baseline_sources.items():
        (baseline / name).write_bytes(path.read_bytes())
    (baseline / 'WorkingController.cls').write_bytes((repo / 'src/Solver/CCoupledDeformationContinuation.cls').read_bytes())
    for name in ('Collect-TestDefaultRecovery.py', 'Check-TestDefaultRecovery.py',
                 'Check-TestActualReverseCapture.py', 'Compare-TestSavedCoupledTrace.py',
                 'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py',
                 'Audit-TestPrivateCoupledBook.py', 'Canonical-TestCoreVBA.py'):
        (root / name).write_bytes((here / name).read_bytes())
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': 'bdf4b29',
        'controller_sha256': sha256((repo / 'src/Solver/CCoupledDeformationContinuation.cls').read_bytes()).hexdigest().upper(),
        'private_instrumented_controller_sha256': sources['src/Solver/CCoupledDeformationContinuation.cls'],
        'automatic_expensive_secant_continuation': False, 'explicit_conditioned_API_retained': True,
        'installed_workbook_changed': False, 'physical_capacity_certified': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('DEFAULT RECOVERY EVIDENCE COLLECTED', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
