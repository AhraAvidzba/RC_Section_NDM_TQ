"""Вторая малая поправка и нативная фиксация точно проверенного поля."""

from hashlib import sha256
import json
from pathlib import Path

here = Path(__file__).resolve().parent
repo = here.parents[1]
previous = here.parent / "mvcr"
book = "workbook/output/RC_Section_NDM.xlsm"
test = "tests/modTestCoupledExperiment.bas"
verify = "Verify-MVT2ShearControlled.py"


def digest(data):
    return sha256(data).hexdigest().upper()


def put(name, raw):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def once(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


raw = (previous / "Preparation.json").read_bytes()
assert digest(raw) == "63B7BCF77521C7B2A3B975FFAD557BA7AD4849784CD665AB199885AF1FEBD1DB"
checks = json.loads(raw)
book_bytes = (repo / book).read_bytes()
assert digest(book_bytes) == checks["book_sha256"]
put(book, book_bytes)
put("docs/regression/Diagnostic.xlsm", book_bytes)
for folder in ("src", "Temp", "NativeHalf"):
    (here / folder).mkdir(exist_ok=True)

inputs = {}
for name, wanted in checks["inputs"].items():
    if name in (test, "CorrectionInput.json", "Stage.py", verify):
        continue
    item = (previous / name).read_bytes()
    assert digest(item) == wanted
    target = "FirstDelta.csv" if name == "CorrectionDelta.csv" else name
    inputs[target] = put(target, item)
for name, original in (("FirstNative.csv", "NativeHalf/MVT2.csv"), ("FirstVerification.json", "VerificationCorrection.json")):
    inputs[name] = put(name, (previous / original).read_bytes())
inputs["MVTHistory.json"] = put("MVTHistory.json", (here.parent / "mvca/MVTHistory.json").read_bytes())

source = (previous / test).read_bytes()
assert digest(source) == checks["inputs"][test]
module = source.decode("utf-8-sig").replace("\r\n", "\n")
module = once(module, '    ReadWangRayVectorTest folder & "CorrectionDelta.csv", ray, qray', '''    ReadWangRayVectorTest folder & "CorrectionDelta.csv", ray, qray
    Dim first() As Double, qFirst As Double
    ReadWangRayVectorTest folder & "FirstDelta.csv", first, qFirst''')
module = once(module, '    For Each ratio In Array(0.5, 1#)', '    For Each ratio In Array(0#, 0.5, 1#)')
module = once(module, '        For i = 1 To 60: field(i) = field(i) + CDbl(ratio) * ray(i): Next i',
              '        For i = 1 To 60: field(i) = field(i) + first(i) + CDbl(ratio) * (ray(i) - first(i)): Next i')
module = once(module, '        factor = q0 + CDbl(ratio) * qray',
              '        factor = q0 + qFirst + CDbl(ratio) * (qray - qFirst)')
module = once(module, '        RequireWangArcHistoryTest stockHistory, checkedHistory\n    Next ratio',
              '        RequireWangArcHistoryTest stockHistory, checkedHistory\n        If CDbl(ratio) = 1# Then CheckWangCorrectionCommitTest output, solver, operators, materials, responses, field, factor\n    Next ratio')
module += "\n" + (here / "Roundtrip.bas").read_text(encoding="utf-8")
inputs[test] = put(test, module.replace("\n", "\r\n").encode("utf-8"))
for name in ("CorrectionDelta.csv", "CorrectionInput.json", "Stage.py", "Roundtrip.bas", verify):
    inputs[name] = digest((here / name).read_bytes())
settings = {"inputs": inputs, "book_sha256": digest(book_bytes), "replay_sha256": checks["replay_sha256"], "watchdog_seconds": 95}
print(put("Preparation.json", (json.dumps(settings, indent=2) + "\n").encode()))
