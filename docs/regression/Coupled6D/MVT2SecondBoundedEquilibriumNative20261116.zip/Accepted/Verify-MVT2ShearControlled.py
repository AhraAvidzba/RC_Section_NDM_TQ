"""Независимо проверяет второй шаг и фиксацию точного поля в Excel."""

import argparse
import json
from math import fsum, sqrt
from pathlib import Path
import VerifyBase as v


here = Path(__file__).resolve().parent
native = here / "NativeHalf"


def vector(name, size=61):
    [line] = (here / name).read_text(encoding="ascii").splitlines()
    values = tuple(map(float, line.split(";")))
    assert len(values) == size
    return values


def prepare():
    prep = v.read(here / "Preparation.json")
    assert all(v.digest(here / name) == value for name, value in prep["inputs"].items())
    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]
    assert v.digest(here / "Replay.csv") == prep["replay_sha256"]
    assert v.digest(here / "FirstVerification.json") == "D0E1E82AF4072FE0A1E402B65B45493FECBB340B937710D912A0E115B210D4A7"
    prior, stations = v.verified_states(v.read_native(here / "FirstNative.csv"))
    normal = vector("MVTNormal.csv", 62)
    assert normal[56:60] == (0.,) * 4
    stop = vector("RayStop.csv")
    first = vector("FirstDelta.csv")
    total = vector("CorrectionDelta.csv")
    meta = v.read(here / "CorrectionInput.json")
    assert v.digest(here / "CorrectionInput.json") == "AD4648DAECEA6FF45670F391F016AE25E20B7219608D0EDDD3F948D60A9E49D8"
    assert meta["candidate_delta_sha256"] == v.digest(here / "CorrectionDelta.csv")
    assert meta["first_total_delta_sha256"] == v.digest(here / "FirstDelta.csv")
    assert meta["native_first_csv_sha256"] == v.digest(here / "FirstNative.csv")
    assert meta["workbook_sha256"] == prep["book_sha256"] and meta["H24_replay_sha256"] == prep["replay_sha256"]
    assert meta["stop_csv_sha256"] == v.digest(here / "RayStop.csv") and meta["normal_csv_sha256"] == v.digest(here / "MVTNormal.csv")
    assert abs(v.dot(normal[:61], total)) * v.MODULUS < 5e-12
    return prep, prior, stations, normal, stop, first, total, meta


def measure(field, geometry):
    return [(area, fsum(e * e / (1 if i < 3 else 2) for i, e in enumerate(v.strain_at(field, v.operators(x, y), side))))
            for (_, side), (x, y, area) in geometry.items()]


def radius(field, geometry):
    return sqrt(max(squared for _, squared in measure(field, geometry)))


def verify(prep, prior, old_stations, normal, stop, first, total, meta):
    compile_info = v.read(here / "docs/regression/CodeUpdate.json")
    compiler = v.read(here / "CompileClosure.json")
    owner = v.read(native / "MVT2.txt.Ownership.json")
    watcher = v.read(native / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(native / "RunReceipt.json")
    final = watcher["Closure"]["FinalState"]
    assert compile_info["Compiled"] and compile_info["Modules"] == ["modTestCoupledExperiment"]
    assert not compile_info["ProductionChanged"] and compile_info["ProductionSHA256"] == prep["book_sha256"]
    assert compiler["State"] == "Absent" and owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"]
    assert owner["SourceSHA256"] == compile_info["WorkbookSHA256"]
    assert watcher["Passed"] and watcher["ChildHasExited"] and watcher["ChildExitCode"] == receipt["native_exit"] == 0
    assert final["State"] == "Absent" and final["PID"] == owner["PID"] and final["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    raw = native / "MVT2.csv"
    tags = v.read_native(raw)
    assert tags["B_FRESH_PHASE"] == [["Half"]]
    states, stations = v.verified_states(tags)
    assert set(states) == {"Base24", "Restored24", "RayZero", "Ray0", "Ray50", "Ray100"}
    steel = v.verify_steel(tags, states, stations, v.vec(tags, "MVT2_CONTROL_FIELD"))
    for new, old in (("Base24", "Base24"), ("Restored24", "Restored24"), ("RayZero", "RayZero"), ("Ray0", "Ray100")):
        assert states[new] == prior[old] and stations[new] == old_stations[old], (new, old)
    starting = states["Ray0"]
    accepted = {name: tuple(vals) for name, *vals in tags["B_ARC_HISTORY"]}
    phase0 = {"RayBefore", "Ray0", "Ray50", "Ray100", "RayFinal"}
    assert all(accepted[label] == accepted["RayBefore"] and len(accepted[label]) == 1080 for label in phase0)
    base = states["Base24"]
    target = v.dot(normal[:60], base["field"]) + normal[60] * base["q"] + normal[61] / 64
    scale = v.read(here / "MVTHistory.json")["strains_normalized_to_last_Qy_increment_per_kN"]
    outcomes = {}
    for fraction, name in ((.5, "Ray50"), (1., "Ray100")):
        state = states[name]
        expected = tuple(q + one + fraction * (two - one) for q, one, two in zip(stop, first, total, strict=True))
        assert v.peak(v.diff(state["field"], expected[:60])) < 5e-15 and abs(state["q"] - expected[60]) < 5e-14
        step_radius = radius(v.diff(state["field"], starting["field"]), base["geometry"])
        full_radius = radius(v.diff(state["field"], states["RayZero"]["field"]), base["geometry"])
        assert step_radius <= fraction * meta["incremental_tensor_radius"] + 4e-14
        assert full_radius <= meta["total_tensor_radius"] + 4e-14
        rows, forces, _ = v.reconstruct(state["field"], state["q"], stations[name])
        gauge = v.peak(rows[-4:]) * v.MODULUS
        plane = (v.dot(normal[:60], state["field"]) + normal[60] * state["q"] - target) * v.MODULUS
        force = max(abs(error) / multiplier for error, multiplier in zip(state["signed_force_N_Nmm"], v.SCALES, strict=True))
        weak = v.peak(rows[:56])
        total_norm = max(gauge, abs(plane), force, weak)
        differential = measure(v.diff(state["field"], base["field"]), base["geometry"])
        distance = sqrt(fsum(area*d2 for area, d2 in differential) / fsum(area for area, _ in differential)
                        + (scale * (state["q"] - base["q"])) ** 2)
        changes = [list(key) for key, old in stations["Ray0"].items() if key[0] <= 25 and
                   (stations[name][key][3:6] != old[3:6] or stations[name][key][6] * old[6] <= 0)]
        outcomes[name] = {"Qy_kN": state["q"], "maximum_steel_stress_MPa": steel[name], "weak_MPa": weak,
                          "row53_MPa": rows[52], "gauge_MPa": gauge, "plane_MPa": plane, "force_errors_MPa": force,
                          "actual_resultants_N_Nmm": forces, "actual_norm_MPa": total_norm, "tolerance_MPa": state["tol_MPa"],
                          "incremental_radius": step_radius, "total_radius": full_radius, "branch_changes": changes,
                          "physical_arc_distance_over_nominal_step": distance / (normal[61] / 64),
                          "equilibrium_at_original_tolerance": total_norm <= state["tol_MPa"]}
    [[solved, identical, committed, internal, code, utilization]] = tags["B_ROUNDTRIP"]
    assert all(x in ("0", "1") for x in (solved, identical, committed))
    if committed == "1":
        assert solved == identical == "1" and float(utilization) <= 1
        assert outcomes["Ray100"]["equilibrium_at_original_tolerance"]
        assert set(accepted) == phase0 | {"PrivateAccepted"} and accepted["PrivateAccepted"] != accepted["RayBefore"]
        assert len(accepted["PrivateAccepted"]) == 1080
        assert v.vec(tags, "B_ROUNDTRIP_FIELD")["PrivateAccepted"] == states["Ray100"]["field"]
        actual = v.vec(tags, "B_ROUNDTRIP_FORCES")["PrivateAccepted"]
        assert max(abs(x-y)/unit for x,y,unit in zip(actual,outcomes["Ray100"]["actual_resultants_N_Nmm"],v.SCALES,strict=True)) < 4e-12
    else:
        assert set(accepted) == phase0
    return {"source_workbook_sha256": prep["book_sha256"], "raw_sha256": v.digest(raw), "exact_H24_restored": True,
            "frozen_input": meta, "outcomes": outcomes, "private_exact_commit": committed == "1",
            "physical_steel_utilization": float(utilization), "solver_status": int(internal), "solver_code": int(code),
            "native_seconds": receipt["wall_seconds"], "native_closure": final}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--inputs-only", action="store_true")
    cli.add_argument("--phase", choices=["Half"])
    args = cli.parse_args()
    inputs = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS", v.digest(here / "Preparation.json"))
    else:
        assert args.phase == "Half"
        result = here / "VerificationSecondCorrection.json"
        result.write_bytes((json.dumps(verify(*inputs), indent=2) + "\n").encode())
        print(result, v.digest(result))
