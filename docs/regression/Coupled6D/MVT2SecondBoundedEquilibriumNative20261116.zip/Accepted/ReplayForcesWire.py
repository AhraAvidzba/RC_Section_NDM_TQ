"""Разбирает шесть сохранённых усилий отдельно от 60 координат поля."""

import argparse
import json
from hashlib import sha256
from pathlib import Path


here = Path(__file__).resolve().parent


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def one(source, before, after):
    assert source.count(before) == 1
    return source.replace(before, after)


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("--offline", action="store_true")
    offline = args.parse_args().offline
    verifier = here / "Verify-MVT2ShearControlled.py"
    source = one(verifier.read_text(encoding="utf-8"),
                 '        actual = v.vec(tags, "B_ROUNDTRIP_FORCES")["PrivateAccepted"]',
                 '''        [[label, *tokens]] = tags["B_ROUNDTRIP_FORCES"]
        assert label == "PrivateAccepted" and len(tokens) == 6
        actual = tuple(map(float, tokens))''')
    if offline:
        source = one(source, '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]',
                     '    assert prep["book_sha256"] == "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"')
    scope = {"__name__": "roundtrip_wire_replay", "__file__": str(verifier)}
    exec(compile(source, str(verifier), "exec"), scope)
    result = scope["verify"](*scope["prepare"]())
    result["six_efforts_wire_verification"] = {"frozen_verifier_sha256": digest(verifier),
        "frozen_native_trace_sha256": digest(here / "NativeHalf/MVT2.csv"),
        "expected_resultant_components": 6, "expected_field_components": 60}
    target = here / "VerificationSecondCorrection.json"
    target.write_bytes((json.dumps(result, indent=2) + "\n").encode())
    print("MVT2 PRIVATE EXACT EQUILIBRIUM", digest(target))


if __name__ == "__main__":
    assert __debug__
    main()
