"""Replay the private native acceptance and the preceding zero-iteration run."""
import argparse
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile


root = Path(__file__).resolve().parent
archives = {
    "jet":"6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33",
    "ray":"E6FCD67D16C2637EF7992AB67CE6DB71AA7E63EE41F15CD33E8CB198A586304D",
    "first":"A2ED199D5EE0699206ADD65F0D89DE1DC3007A027B64F5B466E605A6646DB135",
}
final_sha = "04F899F1943CDB65F2DD022F0AD63A51DB254F321D77AF919D5D97ECF6D917DB"
zero_sha = "FD9BD731827E11ABF99B853000212E89CF1BDA6CCD144020C4F276674B367E4E"
book_sha = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def check_zero(work):
    verifier = work/"Verify-MVT2ShearControlled.py"
    src = verifier.read_text(encoding="utf-8")
    guard = '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]'
    assert src.count(guard) == 1
    src = src.replace(guard,f'    assert prep["book_sha256"] == "{book_sha}"')
    scope = {"__name__":"private_zero","__file__":str(verifier)}
    sys.path.insert(0,str(work))
    try:
        exec(compile(src,str(verifier),"exec"),scope)
        return scope["verify"](*scope["prepare"]())
    finally:
        sys.path.pop(0)


def check_history(trace):
    histories = {}
    for line in trace.read_text(encoding="cp1251").splitlines():
        if line.startswith("B_ARC_HISTORY;"):
            _,label,*values = line.split(";")
            assert label not in histories and len(values) == 1080
            histories[label] = tuple(map(Decimal,values))
    before = histories["RayBefore"]
    private = histories["PrivateAccepted"]
    assert before == histories["Ray0"] == histories["Ray50"] == histories["Ray100"] == histories["RayFinal"]
    increments = []
    for offset in (6,7):
        pairs = list(zip(before[offset::8],private[offset::8],strict=True))
        assert len(pairs) == 135 and all(0 <= a <= b for a,b in pairs)
        increments.append(sum(a < b for a,b in pairs))
    assert increments == [110,71]
    return increments


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in archives:
        parser.add_argument(name,type=Path)
    args = parser.parse_args()
    for name,identity in archives.items():
        assert digest(getattr(args,name).read_bytes()) == identity, name
    manifest = json.loads((root/"PortableManifest.json").read_bytes())
    with (tempfile.TemporaryDirectory() as folder, ZipFile(args.jet) as jet, ZipFile(args.ray) as ray,
          ZipFile(args.first) as first):
        work = Path(folder)
        sources = {"jet":jet,"ray":ray,"first":first}
        for name,entry in manifest.items():
            archive = entry.get("archive")
            raw = ((root/entry.get("member",name)).read_bytes() if archive is None
                   else sources[archive].read(entry["member"]))
            assert digest(raw) == entry["sha256"], name
            dst = work/name
            dst.parent.mkdir(parents=True,exist_ok=True)
            dst.write_bytes(raw)
        zero, accepted = work/"ZeroLimit",work/"Accepted"
        target = "VerificationSecondCorrection.json"
        old_data = (zero/target).read_bytes()
        new_data = (accepted/target).read_bytes()
        assert digest(old_data) == zero_sha and digest(new_data) == final_sha
        original = check_zero(zero)
        assert (json.dumps(original,indent=2)+"\n").encode() == old_data
        original = json.loads(old_data)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayForcesWire.py","--offline"),cwd=accepted,check=True)
        assert (accepted/target).read_bytes() == new_data
        final = json.loads(new_data)
        assert original["outcomes"] == final["outcomes"] and original["frozen_input"] == final["frozen_input"]
        assert (zero/"CorrectionDelta.csv").read_bytes() == (accepted/"CorrectionDelta.csv").read_bytes()
        assert original["exact_H24_restored"] and final["exact_H24_restored"]
        assert not original["private_exact_commit"] and (original["solver_status"],original["solver_code"]) == (8,13)
        assert final["private_exact_commit"] and (final["solver_status"],final["solver_code"]) == (4,0)
        assert 0 < final["physical_steel_utilization"] < 1
        old_roundtrip = (zero/"Roundtrip.bas").read_text(encoding="utf-8")
        new_roundtrip = (accepted/"Roundtrip.bas").read_text(encoding="utf-8")
        assert old_roundtrip.count("ABS_TOL, REL_TOL, 0, initialField:=seed") == 1
        assert old_roundtrip.replace("ABS_TOL, REL_TOL, 0, initialField:=seed","ABS_TOL, REL_TOL, 1, initialField:=seed").replace(
            "' Проверяет заданное поле с нулём итерационных поправок и фиксирует",
            "' Проверяет заданное поле при лимите одной итерации и фиксирует") == new_roundtrip
        outcome = final["outcomes"]["Ray100"]
        assert outcome["equilibrium_at_original_tolerance"] and not outcome["branch_changes"]
        assert not final["outcomes"]["Ray50"]["equilibrium_at_original_tolerance"]
        increment_counts = check_history(accepted/"NativeHalf/MVT2.csv")
        print("ZERO-ITERATION CONFIGURATION REPRODUCED",zero_sha)
        print("PRIVATE EXACT ACCEPTANCE REPRODUCED",final_sha)
        print("Qy",outcome["Qy_kN"],"original residual/tolerance",outcome["actual_norm_MPa"]/outcome["tolerance_MPa"])
        print("135 STATIONS WITH NONDESCENDING COMMITTED ENERGIES",*increment_counts,"points increased for tension and compression")


if __name__ == "__main__":
    main()
