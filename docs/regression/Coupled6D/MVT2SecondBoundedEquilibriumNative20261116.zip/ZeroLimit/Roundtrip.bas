' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет заданное поле с нулём итерационных поправок и фиксирует
' пробу только в отдельной книге. Вызывающий затем восстанавливает H24.
Private Sub CheckWangCorrectionCommitTest(ByVal output As Integer, ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByRef materials() As CCoupledConcreteResponse, _
        ByRef responses() As ICoupledPointResponse, ByRef field() As Double, ByVal factor As Double)
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005
    Dim seed As Variant: seed = field
    Dim solved As Boolean, equal As Boolean, saved As Boolean
    Dim meta As CResultMeta
    Dim candidate() As Double, forces() As Double, committed() As Double, accepted() As Double
    solved = solver.TryStep(0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, _
        ABS_TOL, REL_TOL, 0, initialField:=seed)
    Set meta = solver.ResultMeta
    Dim i As Long, utilization As Double, response As CCoupledReinforcedResponse
    If solved Then
        solver.CopyTrial candidate, forces
        equal = True
        For i = 1 To UBound(field)
            If candidate(i) <> field(i) Then equal = False
        Next i
        For i = -1 To 1
            Set response = responses(i)
            utilization = GeomMax(utilization, response.TrialSteelUtilization)
        Next i
        If equal And utilization <= 1# Then
            solver.AcceptStep
            solver.CopyAccepted accepted
            For i = 1 To UBound(candidate)
                If accepted(i) <> candidate(i) Then Err.Raise 5, , "Фиксация изменила проверенное поле MVT2."
            Next i
            CaptureWangArcHistoryTest output, "PrivateAccepted", operators, materials, committed
            EmitWangTangentVectorTest output, "B_ROUNDTRIP_FIELD;PrivateAccepted", accepted
            EmitWangTangentVectorTest output, "B_ROUNDTRIP_FORCES;PrivateAccepted", forces
            saved = True
        End If
    End If
    Print #output, "B_ROUNDTRIP;" & CStr(Abs(CLng(solved))) & ";" & CStr(Abs(CLng(equal))) & ";" & _
        CStr(Abs(CLng(saved))) & ";" & CStr(meta.InternalStatus) & ";" & CStr(meta.ResultCode) & ";" & ExperimentNumberTest(utilization)
    solver.DiscardStep
End Sub
