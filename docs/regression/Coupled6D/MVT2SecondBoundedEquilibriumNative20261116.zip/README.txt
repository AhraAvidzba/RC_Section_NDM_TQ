Second bounded native correction and exact private MVT2 B acceptance

Extract and run with the three frozen dependencies

    python -B -X utf8 ReplaySecondPortable.py PATH/MVT2HalfJointJetNative20261116.zip PATH/MVT2SameRayDerivativeNative20261116.zip PATH/MVT2FirstBoundedBranchCorrectionNative20261116.zip

The manifest checks both native inputs, shared sources and original process
ownership. Each identical input blob is stored once. Workbook binaries are
omitted. The conditioned design, exact 61-value delta and both evaluated
fractions use the original H24 history and original materials. The same
active pseudo-arc plane and all six force, weak and gauge constraints apply.

The full field at Qy=18.5707887177759 kN has original residual
8.4828008716664e-7 MPa under the original tolerance 1.1217580792766e-6 MPa,
no concrete branch switches, and maximum design steel use 0.017163542629.
It was accepted at the identical fixed-force seed in the private native
fixture. Exact H24 was restored afterwards. This proves a local equilibrium
point at the stated load and does not determine a physical capacity.
Exact decimal readback checks both accepted energy components at all 135
material stations. Tensile energy grows at 110 and compressive energy at
71 stations. Other values stay equal. After restoration all 1080 recorded
stress/energy values agree exactly with H24.

ZeroLimit contains the preceding 0-iteration attempt. Its raw material
outcomes and frozen candidate are equal to Accepted, but VBA rejected the
configuration before the private accept operation. The only native roundtrip
source change is the iteration allowance from 0 to 1 and its comment.
In Accepted, the original offline reader wrongly tried to interpret the
six accepted forces through the 60-component field parser. Its original
failure is recorded. ReplayForcesWire corrects only the width of the six-force
decoder. It retains the frozen original verifier and actual native bytes.
