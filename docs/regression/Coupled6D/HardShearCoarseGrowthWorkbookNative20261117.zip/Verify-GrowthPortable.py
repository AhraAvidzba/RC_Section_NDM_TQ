"""Replay HardShear growth evidence using the staged verifier and accepted Results curves."""
from argparse import ArgumentParser
from decimal import Decimal
from hashlib import sha256
from json import loads
from pathlib import Path, PureWindowsPath
import re
from runpy import run_path
from zipfile import Path as ZipPath, ZipFile

HERE = Path(__file__).resolve().parent
BASE_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
VARIANT_SHA = "27099C1E3F2CB0514C18AD3804039D784B91015D83366A200ADC49BACEE923B8"
STAGE_SHA = "49D50EB03DAEDBA0DEA9AFE064675F99F5A93ECA379E1FC48B4655D129BAC161"
STOCK_SAVED_SHA = "B453911412BACE66A6F57706D03E114CC048A33FB3ED88B621072BB7CD69EADA"
STOCK_REL = "docs/regression/Coupled6D/HardShearInstalledStockTiming20261117.zip"
STOCK_SHA = "C452D2A59077C5DA5F6667DDD5ADF33778A0681F1B955A0E091FB08D8D2EE24F"
MODULE = "CCoupledDeformationContinuation"
CLASS = f"src/Solver/{MODULE}.cls"


def json_file(path):
    return loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read_dense(curve):
    entries = curve["entries"]
    assert len(entries) >= 2 and len(entries) % 2 == 0
    numbers = []
    for index, (one, two) in enumerate(zip(entries[0::2], entries[1::2], strict=True), 1):
        assert one[:2] == [index, "Lambda"] and two[:2] == [index, "Offset"]
        assert one[3] == f"Coupled.Trace.Capacity.{index}.Lambda" and two[3] == f"Coupled.Trace.Capacity.{index}.Offset"
        assert re.findall(r"\d+$", one[2]) == re.findall(r"\d+$", one[4])
        assert re.findall(r"\d+$", two[2]) == re.findall(r"\d+$", two[4])
        factor, offset = Decimal(one[5]), Decimal(two[5])
        assert factor.is_finite() and offset == 1 and factor > 0
        numbers.append(factor)
    return numbers


def check(root, repo, stock_workbook=None, candidate_workbook=None):
    manifest = json_file(root / "SHA256SUMS.json")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    assert actual == set(manifest) | {"SHA256SUMS.json"}
    for name, expected in manifest.items():
        path = (root / name).resolve()
        assert path.is_relative_to(root) and digest(path) == expected, name
    assert manifest[CLASS] == VARIANT_SHA and manifest["ABManifest.json"] == STAGE_SHA
    plan = json_file(root / "ABManifest.json")
    assert plan["modules"] == [MODULE] and plan["book_sha256"] == BASE_SHA
    for name in (CLASS, "Run-FullAB.ps1", "Verify-FullAB.py", "Stage.py"):
        assert plan["inputs"][name] == manifest[name]
    receipt = json_file(root / "docs/regression/CodeUpdate.json")
    closure = json_file(root / "CompileClosure.json")
    assert receipt["Modules"] == [MODULE] and receipt["Compiled"] and not receipt["ProductionChanged"]
    assert receipt["ProductionSHA256"] == BASE_SHA and closure["State"] == "Absent"
    assert PureWindowsPath(receipt["Workbook"]) == PureWindowsPath(
        r"D:\CodexScratch\RC_Section_NDM_TQ\HardGrowthAB1\docs\regression\Diagnostic.xlsm"
    )
    compile_log = (root / "Compile.log").read_text(encoding="utf-8-sig")
    assert compile_log.count(f"OWNED_EXCEL: id={closure['PID']}; utcStartTicks={closure['StartTicksUTC']}") == 1

    verifier = run_path(str(root / "Verify-FullAB.py"))
    archived = repo / STOCK_REL
    assert digest(archived) == STOCK_SHA
    with ZipFile(archived) as stock:
        a = verifier["native"](ZipPath(stock, at="Native/"), BASE_SHA)
        old = loads(stock.read("StockProof.json"))
        assert a["report_sha256"] == old["report_sha256"] and a["trace_sha256"] == old["trace_sha256"]
        assert a["results_reopened_sha256"] == old["reopened_results_sha256"]
    b = verifier["native"](root / "Native/B", receipt["WorkbookSHA256"])
    assert max(abs(x - y) for x, y in zip(a["direct_N_Nmm"], b["direct_N_Nmm"], strict=True)) < 0.001
    trace = (root / "Native/B/Both.Execution.txt").read_text(encoding="utf-16")
    records = set(re.findall(r"GrowthTestAcceptedBeyondDouble=(\d+); GrowthTestFinalLambda=([\d.,Ee+-]+)", trace))
    assert len(records) <= 1
    if records:
        count, last = records.pop()
        continuation = {"accepted_beyond_double": int(count), "last_positive_lambda": verifier["number"](last)}
    else:
        continuation = {"accepted_beyond_double": 0, "last_positive_lambda": None}
    expected = {"stock_source": "archive §490", "A": a, "B": b, "matched_runtime_delta_s": None,
                "continuation": continuation}
    assert json_file(root / "ABVerification.json") == expected

    extract = run_path(str(root / "ReadWorkbookCurve.py"))["read_curve"]
    curve_a = json_file(root / "StockWorkbookCurve.json")
    curve_b = json_file(root / "CandidateWorkbookCurve.json")
    assert curve_a["saved_workbook_sha256"] == STOCK_SAVED_SHA
    if stock_workbook:
        assert extract(stock_workbook) == curve_a
    if candidate_workbook:
        assert extract(candidate_workbook) == curve_b
    samples_a, samples_b = read_dense(curve_a), read_dense(curve_b)
    assert len(samples_a) == 68 and samples_a[8] == Decimal("1.1029088921956576")
    assert samples_a[-1] == Decimal("0.96921408144626919") and curve_a["entries"][-2][4] == "V400"
    assert abs(float(max(samples_a)) - a["lower_lambda"]) < 1e-13
    if b["lower_lambda"] is not None:
        assert abs(float(max(samples_b)) - b["lower_lambda"]) < 1e-13
    if continuation["last_positive_lambda"] is not None:
        assert abs(float(samples_b[-1]) - continuation["last_positive_lambda"]) < 1e-13
    return {
        "accepted_points_A_B": [len(samples_a), len(samples_b)],
        "last_accepted_lambda_A_B": [str(samples_a[-1]), str(samples_b[-1])],
        "local_maximum_lambda_A_B": [str(max(samples_a)), str(max(samples_b))],
        "postpeak_descending_entire_A_B": [
            all(left > right for left, right in zip(xs[xs.index(max(xs)):-1], xs[xs.index(max(xs)) + 1:]))
            for xs in (samples_a, samples_b)
        ],
        "accepted_beyond_double_B": continuation["accepted_beyond_double"],
        "extra_lambda_drop_B": str(samples_a[-1] - samples_b[-1]),
        "last_Qy_kN_A_B": [str(-Decimal("7.1") * xs[-1]) for xs in (samples_a, samples_b)],
        "status_A_B": [a["capacity_status"], b["capacity_status"]],
    }


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--stock-workbook", type=Path)
    parser.add_argument("--candidate-workbook", type=Path)
    options = parser.parse_args()
    out = check(HERE, options.repo, options.stock_workbook, options.candidate_workbook)
    print("HARDSHEAR COARSE GROWTH PORTABLE VERIFIED")
    print(out)
