"""Verify the isolated HardShear workbook owner, signed forces, statuses and saved Results."""
from argparse import ArgumentParser
from hashlib import sha256
from json import dumps, loads
from pathlib import Path
import re
from runpy import run_path

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
CLASS = "src/Solver/CCoupledDeformationContinuation.cls"
BASE_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
CANDIDATE_SHA = "27099C1E3F2CB0514C18AD3804039D784B91015D83366A200ADC49BACEE923B8"
COMPONENTS = ("N", "Mx", "My", "T", "Qx", "Qy")
TARGET = (28000.0, 510000.0, 180000.0, 1500000.0, 17000.0, -7100.0)


def read_json(path):
    return loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def match(pattern, text):
    hits = re.findall(pattern, text, flags=re.MULTILINE)
    assert len(hits) == 1, (pattern, hits)
    return hits[0]


def number(raw):
    return float(raw.replace(",", "."))


def inputs(root):
    plan = read_json(root / "ABManifest.json")
    assert plan["book_sha256"] == plan["inputs"][BOOK] == BASE_SHA
    assert plan["inputs"][CLASS] == CANDIDATE_SHA
    assert plan["modules"] == ["CCoupledDeformationContinuation"] and plan["draft"] == "docs/regression/Diagnostic.xlsm"
    for name, checksum in plan["inputs"].items():
        path = (root / name).resolve()
        assert path.is_relative_to(root) and digest(path) == checksum, name
    return plan


def compiled(root, plan):
    receipt = read_json(root / "docs/regression/CodeUpdate.json")
    owner = read_json(root / "CompileClosure.json")
    line = match(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$",
                 (root / "Compile.log").read_text(encoding="utf-8-sig"))
    assert receipt["Compiled"] and not receipt["ProductionChanged"]
    assert receipt["ProductionSHA256"] == BASE_SHA and receipt["Modules"] == plan["modules"]
    assert Path(receipt["Workbook"]).resolve() == (root / plan["draft"]).resolve()
    assert receipt["WorkbookSHA256"] == digest(root / plan["draft"]) != BASE_SHA
    assert owner["State"] == "Absent" and (str(owner["PID"]), str(owner["StartTicksUTC"])) == line
    return receipt


def forces(report, kind, factor):
    rows = re.findall(rf"^OK: {kind} (N|Mx|My|T|Qx|Qy) actual=([^ ]+) expected=", report, flags=re.MULTILINE)
    assert tuple(row[0] for row in rows) == COMPONENTS, rows
    values = [number(raw) * (9806650.0 if 1 <= i <= 3 else 9806.65) for i, (_, raw) in enumerate(rows)]
    assert max(abs(value - factor * base) for value, base in zip(values, TARGET, strict=True)) < 0.001
    return values


def native(prefix, source_hash):
    data = prefix / "Both.txt"
    report = data.read_text(encoding="utf-8-sig")
    trace_path = prefix / "Both.Execution.txt"
    trace = trace_path.read_text(encoding="utf-16")
    owner = read_json(prefix / "Both.txt.Ownership.json")
    exit_receipt = read_json(prefix / "Both.txt.ProcessClosure.json")
    final = exit_receipt["Closure"]["FinalState"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == source_hash
    assert (final["State"], final["PID"], final["StartTicksUTC"]) == ("Absent", owner["PID"], owner["StartTicksUTC"])
    assert exit_receipt["Passed"] and exit_receipt["ChildHasExited"] and exit_receipt["ChildExitCode"] == 0
    assert match(r"^SOURCE_SHA256: ([A-F0-9]{64})$", report) == source_hash
    assert "SOURCE_UNCHANGED: True" in report and not re.search(r"^(RUNTIME ERROR:|FAIL:|NOT RUN:)", report, re.MULTILINE)
    passed = int(match(r"^TOTAL_COUPLED_WORKBOOK_TIMING: passed=(\d+); failed=0$", report))
    assert passed >= 28
    hashes = match(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=([A-F0-9]{64}); equal=True;", report)
    assert hashes[0] == hashes[1]
    capacity, lower, limit, code = match(r"^TIMING_STATES: direct=OK; capacity=([^;]+); confirmed lower=([^;]*); limit=([^;]*); code=([^\n]*)$", report)
    reason = match(r"^TIMING_LIMIT_REASON: ([^\n]*)$", report)
    directly = forces(report, "direct", 1.0)
    ultimate = None
    if not limit:
        assert capacity == "NumFail" and code and reason and number(lower) > 0
        assert re.findall(r"^OK: no unconfirmed limit component (.+)$", report, flags=re.MULTILINE) == list(COMPONENTS)
    else:
        assert capacity != "NumFail" and number(limit) > 0
        ultimate = forces(report, "capacity", number(limit))
    elapsed = number(match(r"^TIMING_SECONDS: ([\d.,]+) \| Both \| Excel$", report))
    direct_s = number(match(r"^\[([\d.,]+) с\] Связанное равновесие подтверждено по шести усилиям\.", trace))
    capacity_s, trace_lower, probes = match(
        r"^\[([\d.,]+) с\] [^\n]*наибольший допустимый lambda: ([\d.,]+); равновесие при lambda = 1 подтверждено: True; проб: (\d+)\b",
        trace,
    )
    capacity_s = number(capacity_s)
    assert 0 < direct_s < capacity_s < elapsed and 0 < int(probes) <= 96
    if lower:
        assert abs(number(lower) - number(trace_lower)) < 1e-10
    return {"source_sha256": source_hash, "results_reopened_sha256": hashes[0],
            "direct_N_Nmm": directly, "capacity_status": capacity, "result_code": code,
            "lower_lambda": number(lower) if lower else None, "limit_lambda": number(limit) if limit else None,
            "ultimate_N_Nmm": ultimate, "reason": reason, "probes": int(probes), "assertions": passed,
            "timing_s": {"direct": direct_s, "capacity": capacity_s, "results": elapsed},
            "report_sha256": digest(data), "trace_sha256": digest(trace_path), "excel_pid": owner["PID"]}


def stock(root, fresh):
    if fresh:
        run_path(str(root / "Verify-Stock.py"))["verify"](root, root)
        result = native(root / "Native", BASE_SHA)
    else:
        result = native(root / "StockPrior/Native", BASE_SHA)
        old = read_json(root / "StockPrior/StockProof.json")
        assert result["report_sha256"] == old["report_sha256"] and result["trace_sha256"] == old["trace_sha256"]
        assert result["results_reopened_sha256"] == old["reopened_results_sha256"]
    assert result["lower_lambda"] == 1.10290889219566 and result["probes"] == 96 and result["capacity_status"] == "NumFail"
    return result


def main():
    parser = ArgumentParser(description=__doc__)
    phases = parser.add_mutually_exclusive_group(required=True)
    for phase in ("inputs", "compiled", "fresh-stock", "native"):
        phases.add_argument("--" + phase, action="store_true")
    args = parser.parse_args()
    plan = inputs(HERE)
    if args.inputs:
        stock(HERE, False)
        print("HARDSHEAR AB INPUTS VERIFIED")
        return
    if args.fresh_stock:
        stock(HERE, True)
        print("HARDSHEAR FRESH A VERIFIED")
        return
    receipt = compiled(HERE, plan)
    if args.compiled:
        print("HARDSHEAR AB COMPILE VERIFIED", receipt["WorkbookSHA256"])
        return
    fresh = (HERE / "Native/Both.txt").is_file()
    a = stock(HERE, fresh)
    b = native(HERE / "Native/B", receipt["WorkbookSHA256"])
    assert max(abs(x - y) for x, y in zip(a["direct_N_Nmm"], b["direct_N_Nmm"], strict=True)) < 0.001
    comparison = {"stock_source": "fresh" if fresh else "archive §490", "A": a, "B": b,
                  "matched_runtime_delta_s": b["timing_s"]["results"] - a["timing_s"]["results"] if fresh else None}
    trace = (HERE / 'Native/B/Both.Execution.txt').read_text(encoding='utf-16')
    records = set(re.findall(r'GrowthTestAcceptedBeyondDouble=(\d+); GrowthTestFinalLambda=([\d.,Ee+-]+)', trace))
    assert len(records) <= 1, records
    if records:
        count, last = records.pop()
        comparison['continuation'] = {'accepted_beyond_double': int(count), 'last_positive_lambda': number(last)}
    else:
        comparison['continuation'] = {'accepted_beyond_double': 0, 'last_positive_lambda': None}
    out = HERE / "ABVerification.json"
    raw = (dumps(comparison, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if out.exists():
        assert out.read_bytes() == raw, out
    else:
        out.write_bytes(raw)
    print("HARDSHEAR A/B VERIFIED", digest(out))


if __name__ == "__main__":
    main()
