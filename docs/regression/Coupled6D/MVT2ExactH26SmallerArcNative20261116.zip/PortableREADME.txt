Native MVT2 H26 benchmark, two separate smaller pseudo-arclength probes.

Extract this archive and execute the interpretation offline with the manifest's tracked prior archives.

    python -B -X utf8 ReplayResumePortable.py --archives <repository>/docs/regression/Coupled6D

The offline wrapper checks every artifact's digest, reconstructs accepted prefix and normal wires
from the previous native archive, regenerates the exact VBA driver, and compares the complete
independently reconstructed original verification report byte-for-byte. To omit workbook copies,
only the private workbook input digest check uses the pinned manifest and compile receipts.

H25 and H26 were reconstructed at binary solver precision. The sealed decimal witness confirms
all earlier exported field, resultant, and station values. Each probe restores the same full H26,
and both are separately discarded. Final exact H24 restoration and runtime owner closure are
verified by their independent receipts. A returned numerical load interval establishes only
local solver sensitivity; the original force equilibrium and directed motion are checked separately.

InitialTransportFailure preserves the first workbook run, which stopped before any probe
while reading the LF-only large records. Replay verifies closed ownership and that converting to
short CRLF records retained every original numeric token before the successful fixture read.
