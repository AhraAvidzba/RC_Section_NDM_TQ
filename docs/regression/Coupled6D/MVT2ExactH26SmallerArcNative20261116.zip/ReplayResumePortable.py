"""Reproduce the private H26 witness and two-probe verification offline."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
PARENT = "MVT2AdaptiveBoundedContinuationNative20261116.zip"
DEPENDENCIES = {
    PARENT: "A5F4EABFE14F46544D6BA36934B050AED5C5F3655DC91D32D6E8C6408562E699",
    "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
    "MVT2StockBranchArcNative20261116.zip": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def local(root, name):
    return root / (root / name).resolve().relative_to(root.resolve())


def materialize(work, manifest, archive_dir):
    assert manifest["reference_workbook"] == {"path": BOOK, "sha256": WORKBOOK}
    assert manifest["archives"] == DEPENDENCIES
    for name, expected in DEPENDENCIES.items():
        assert digest((archive_dir / name).read_bytes()) == expected
    for name, entry in manifest["inputs"].items():
        source = entry.get("archive")
        member = entry.get("member",name)
        if source:
            with ZipFile(archive_dir / source) as prior:
                raw = prior.read(member)
        else:
            raw = local(HERE,member).read_bytes()
        assert digest(raw) == entry["sha256"], name
        destination = local(work,name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)


def replay(work, archives):
    verifier = work / "Verify-MVT2ShearControlled.py"
    source = verifier.read_text(encoding="utf-8")
    original = '    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items())'
    assert source.count(original) == 1 and not (work / BOOK).exists()
    patched = (f'    assert prep["inputs"]["{BOOK}"] == prep["book_sha256"] == "{WORKBOOK}"\n'
               f'    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items() if path != "{BOOK}")')
    sys.path.insert(0, str(work))
    scope = {"__file__": str(verifier), "__name__": "archived_native"}
    exec(compile(source.replace(original,patched), str(verifier), "exec"), scope)
    report = scope["verify"](*scope["prepare"]())
    proof = (work / "VerificationResume.json").read_bytes()
    assert (json.dumps(report, indent=2) + "\n").encode() == proof
    assert report["exact_H26_replayed"] and report["private_probes_never_committed"] and report["H24_restored_exactly"]
    assert report["H26_base_Qy_kN"] == 18.5785550208131
    stage = work / "Stage.py"
    stage_scope = {"__file__": str(stage), "__name__": "archived_stage"}
    exec(compile(stage.read_text(encoding="utf-8"),str(stage),"exec"),stage_scope)
    with ZipFile(archives / PARENT) as parent:
        accepted = parent.read("NativeContinue/MVT2.csv")
        assert digest(accepted) == stage_scope["PARENT_NATIVE"]
        assert digest(parent.read("Preparation.json")) == stage_scope["PARENT_PREP"]
        assert digest(parent.read("VerificationContinue.json")) == stage_scope["PARENT_REPORT"]
        normal,witness = stage_scope["wire"](accepted)
        assert normal == (work / "H26Normal.csv").read_bytes() and witness == (work / "AcceptedWire.csv").read_bytes()
        macro = stage_scope["MACRO"]
        assert stage_scope["overlay"](parent.read(macro)) == (work / macro).read_bytes()
    failure = work / "InitialTransportFailure"
    assert digest((failure / "Preparation.json").read_bytes()) == "27899CB29EF0372D823AC5B6CDD4F4E8099BED759361B7404D1096819431FAC8"
    for path, shape in (("AcceptedWire.csv",(2,1147)), ("H26Normal.csv",(1,63))):
        raw = (failure / path).read_bytes()
        assert b"\r" not in raw and raw.count(b"\n") == shape[0]
        assert [len(row.split(b";")) for row in raw.splitlines()] == [shape[1]]*shape[0]
        old = tuple(token for row in raw.splitlines() for token in row.split(b";"))
        new = tuple(token for row in (work/path).read_bytes().splitlines() for token in row.split(b";"))
        assert old == new
    first_native = failure / "NativeResume"
    failure_log = (first_native/"MVT2.txt").read_text(encoding="utf-8-sig")
    raw_failure_rows = (first_native/"MVT2.csv").read_bytes()
    assert "RUNTIME ERROR: VBAProject Неполная контрольная запись H26." in failure_log
    assert "WATCHDOG_COMPLETED: exit=1; source unchanged=True" in failure_log
    assert b"B_FRESH_PHASE;Resume" in raw_failure_rows and b"B_EXT_TRY;" not in raw_failure_rows
    initial_owner = json.loads((first_native/"MVT2.txt.Ownership.json").read_text(encoding="utf-8-sig"))
    initial_close = json.loads((first_native/"MVT2.txt.ProcessClosure.json").read_text(encoding="utf-8-sig"))
    end = initial_close["Closure"]["FinalState"]
    assert initial_close["ChildExitCode"] == 1 and end["State"] == "Absent"
    assert (initial_owner["PID"],initial_owner["StartTicksUTC"]) == (end["PID"],end["StartTicksUTC"])
    return report,digest(proof)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives",type=Path,required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE / "PortableManifest.json").read_bytes())
    with TemporaryDirectory() as temp:
        work = Path(temp)
        materialize(work,manifest,args.archives)
        report, proof_hash = replay(work,args.archives)
    print("EXACT H26 REPLAY",proof_hash,"H24 RESTORED",report["H24_restored_exactly"])
    for attempt in report["attempts"][2:]:
        print(attempt["attempt"], attempt["decision"], attempt.get("Qy_kN"), attempt.get("load_progression_sign_resolved"))


if __name__ == "__main__":
    main()
