"""Package the native H26 probes and run a detached verification."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import ReplayResumePortable as replay


HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[1] / "docs/regression/Coupled6D"
RESULT = HERE / "MVT2ExactH26SmallerArcNative20261116.zip"
FAILED = HERE.parent / "mv26"


def main():
    prep = json.loads((HERE / "Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK] == prep["book_sha256"] == replay.WORKBOOK
    archived = {}
    for name, expected in replay.DEPENDENCIES.items():
        path = REGRESSION / name
        assert replay.digest(path.read_bytes()) == expected
        with ZipFile(path) as z:
            for member in z.namelist():
                if not member.casefold().endswith(".xlsm"):
                    archived.setdefault(replay.digest(z.read(member)),(name,member))
    attachments = ("Preparation.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json",
                   "VerificationResume.json", "ReplayResumePortable.py", "PackResume.py", "PortableREADME.txt")
    failure = ("AcceptedWire.csv", "H26Normal.csv", "Preparation.json", "Compile.log", "CompileClosure.json", "Run.ndjson",
               "tests/modTestCoupledExperiment.bas", "docs/regression/CodeUpdate.json")
    failure += tuple(f"NativeResume/{item.name}" for item in (FAILED / "NativeResume").iterdir() if item.is_file())
    native = tuple(f"NativeResume/{item.name}" for item in (HERE / "NativeResume").iterdir() if item.is_file())
    items, manifest = {}, {}
    for path in sorted(set(prep["inputs"]) | set(attachments) | set(native)):
        if path == replay.BOOK:
            continue
        raw = (HERE / path).read_bytes()
        checksum = replay.digest(raw)
        if path in prep["inputs"]:
            assert checksum == prep["inputs"][path]
        match = archived.get(checksum) if path in prep["inputs"] else None
        if match:
            source, member = match
            manifest[path] = {"archive":source,"member":member,"sha256":checksum}
        else:
            manifest[path] = {"sha256":checksum}
            items[path] = raw
    for path in sorted(failure):
        name = "InitialTransportFailure/" + path
        items[name] = (FAILED / path).read_bytes()
        manifest[name] = {"sha256":replay.digest(items[name])}
    definition = {"reference_workbook":{"path":replay.BOOK,"sha256":replay.WORKBOOK},"archives":replay.DEPENDENCIES,"inputs":manifest}
    items["PortableManifest.json"] = (json.dumps(definition,indent=2)+"\n").encode()
    assert all(not name.casefold().endswith(".xlsm") for name in items)
    with ZipFile(RESULT,"w",compresslevel=9) as z:
        for name, raw in sorted(items.items()):
            member = ZipInfo(name)
            member.compress_type = ZIP_DEFLATED
            z.writestr(member,raw)
    with TemporaryDirectory(dir=HERE / "Temp") as temp, ZipFile(RESULT) as z:
        assert z.testzip() is None
        z.extractall(temp)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayResumePortable.py","--archives",str(REGRESSION)),cwd=temp,check=True)
    print(RESULT.name,RESULT.stat().st_size,replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
