"""Seal a two-size MVT2 probe from natively reconstructed H26."""
import csv
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mvext"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MACRO = "tests/modTestCoupledExperiment.bas"
RUNNER = "Run-MVT2ShearControlled.ps1"
PARENT_PREP = "091A74941ECA0ADCF6FF65EC2C4991068C5DD9FF8950476C4AF4DBED22A0802B"
PARENT_NATIVE = "244065BBF02C27B45EBBBE7D0CD7BAAB6CBB2C0F9483607D9F337C07BD6BD5EF"
PARENT_REPORT = "AD22C868815404D79FCA5D888B46D11F77F923FF3FFA6C5C645F635EEACABFF4"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name, raw):
    target = HERE / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, target
    else:
        target.write_bytes(raw)
    return digest(raw)


def swap(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def wire(raw):
    rows = list(csv.reader(raw.decode("cp1251").splitlines(),delimiter=";"))
    def at(marker,label):
        [row] = [row for tag,item,*row in (row for row in rows if len(row) >= 2) if tag == marker and item == label]
        return row
    p = at("B_EXT_PROJECTION", "Attempt6")
    old_step = at("B_EXT_TRY", "Attempt6")
    terminal = at("B_EXT_END","MinimumStep")
    assert len(p) == 60 and old_step[0] == "26" and terminal[1] == "2"
    assert abs(float(terminal[3]) - float(old_step[3]) / 2.) < 1e-20
    normal = [*p,old_step[5],old_step[4],terminal[3]]
    states = []
    for anchor, label in [(25,"Attempt1"),(26,"Attempt5")]:
        count, qy, *field = at("B_TANGENT_FIELD",label)
        forces = at("B_EXT_SOLVER_ACTUAL",label)
        state = at("B_ARC_HISTORY","Committed"+label)
        assert (int(count),len(field),len(forces),len(state)) == (anchor-1,60,6,1080)
        assert at("B_EXT_COMMITTED",label) == field and at("B_ARC_HISTORY","Replayed"+label) == state
        assert at("B_EXT_DECISION",label) == ["Accepted"]
        states.extend([[qy], *(field[i:i+15] for i in range(0,60,15)), forces, *(state[i:i+8] for i in range(0,1080,8))])
    normal_rows = [*(normal[i:i+15] for i in range(0,60,15)), normal[60:]]
    def encode(data):
        return ("\r\n".join(";".join(row) for row in data)+"\r\n").encode("ascii")
    return encode(normal_rows), encode(states)


def overlay(raw):
    source = raw.decode("utf-8-sig").replace("\r\n","\n")
    source = swap(source, 'If phase <> "Continue" Then', 'If phase <> "Resume" Then')
    start = source.index("Private Sub ContinueWangArcTest(")
    marker = "' -------------------- ДЛЯ ТЕСТОВ --------------------\n"
    end = source.index("Private Sub BuildWangArcMetricTest(")
    a,b = source.rfind(marker,0,start),source.rfind(marker,0,end)
    body = source[a:b]
    body = swap(body, "Const MAX_ITERATIONS As Long = 26, GOAL As Long = 6, ATTEMPT_CAP As Long = 10, BUDGET As Double = 175#", "Const MAX_ITERATIONS As Long = 26")
    body = swap(body, '    Dim baseField() As Double,', '''    Dim witnesses As Collection, resumeWire As Variant
    Set witnesses = ReadWangResumeWitnessesTest(folder & "AcceptedWire.csv")
    resumeWire = ReadWangResumeNormalTest(folder & "H26Normal.csv")
    Dim baseField() As Double,''')
    body = swap(body, '    Dim status As CResultMeta: previousFactor = previousLoad: baseFactor = originalLoad', '''    Dim status As CResultMeta: previousFactor = previousLoad: baseFactor = originalLoad
    Dim u As Double, uncertaintyOK As Boolean, nativeWire As Variant, savedTrial() As Double, savedForces() As Double''')
    begin = body.index('    Print #output, "B_EXT_PLAN;"')
    end = body.index('        ReDim directionField',begin)
    body = body[:begin] + '''    Print #output, "B_RESUME_PLAN;" & ExperimentNumberTest(Sqr(loadMetric)) & ";" & _
        ExperimentNumberTest(initialStep) & ";" & ExperimentNumberTest(ATOL) & ";" & ExperimentNumberTest(RTOL) & ";" & CStr(MAX_ITERATIONS)
    watch = Timer
    For attempt = 1 To 4
        label = "Attempt" & CStr(attempt)
        If attempt = 2 Then nominal = initialStep * 1.5 / 8# ' Воспроизводит размер принятой пятой пробы.
        If attempt = 3 Then nominal = Val(resumeWire(62))
        If attempt = 4 Then nominal = nominal / 2#
        RestoreWangShearBaselineTest solver, workingHistory, baseField
        CaptureWangArcHistoryTest output, "BeforeSolve" & label, operators, materials, snapshot
        RequireWangArcHistoryTest committed, snapshot
''' + body[end:]
    body = swap(body, "        prediction = baseField", '''        If attempt >= 3 Then
            RequireWangResumeWireTest resumeWire, projection, 0
            If ExperimentNumberTest(normalLoad) <> resumeWire(60) Or ExperimentNumberTest(secantNorm) <> resumeWire(61) Then _
                Err.Raise 5, , "Нормаль H26 отличается от принятой."
        End If
        prediction = baseField''')
    body = swap(body, '        Print #output, "B_EXT_DECISION;" & label & ";" & reason\n        If verdict Then', '''        If attempt < 3 And Not verdict Then Err.Raise 5, , "Не восстановлена принятая точка " & label & "."
        If verdict And attempt >= 2 Then
            uncertaintyOK = solver.TrialLambdaUncertainty(ATOL, RTOL, u)
            If uncertaintyOK Then
                Print #output, "B_RESUME_UNCERTAINTY;" & label & ";" & ExperimentNumberTest(u) & ";" & _
                    ExperimentNumberTest(trialFactor - u) & ";" & ExperimentNumberTest(trialFactor + u)
            Else
                Print #output, "B_RESUME_UNCERTAINTY;" & label & ";Unavailable"
                If attempt = 2 Then ' При отказе оценки возвращает тот же точно вычисленный кандидат перед записью.
                    trialFactor = predictorFactor
                    If Not solver.TryDeformationStep(baseLoad, direction, projection, target, predictorFactor, trialFactor, _
                            ATOL, RTOL, MAX_ITERATIONS, consistentControl:=False, initialField:=seed, loadProjection:=normalLoad) Then _
                        Err.Raise 5, , "Не повторилось принятое поле H26 после оценки погрешности."
                    solver.CopyTrial savedTrial, savedForces
                    RequireWangArcHistoryTest actualField, savedTrial
                    RequireWangArcHistoryTest trialForces, savedForces
                End If
            End If
        End If
        If verdict And attempt >= 3 Then reason = "VerifiedProbe"
        Print #output, "B_EXT_DECISION;" & label & ";" & reason
        If verdict And attempt < 3 Then
            nativeWire = witnesses(attempt)
            If ExperimentNumberTest(trialFactor) <> nativeWire(0) Then Err.Raise 5, , "Множитель принятой истории изменился."
            RequireWangResumeWireTest nativeWire, actualField, 1
            RequireWangResumeWireTest nativeWire, trialForces, 61''')
    body = swap(body, '            RequireWangArcEnergyTest committed, snapshot\n', '''            RequireWangArcEnergyTest committed, snapshot
            RequireWangResumeWireTest nativeWire, snapshot, 67
''')
    body = swap(body, '            If length <= 1.5 * nominal Then nominal = GeomMin(2# * initialStep, 1.5 * nominal)\n', '')
    body = swap(body, '            nominal = nominal / 2#\n', '')
    begin = body.index('    Loop\n    Print #output, "B_EXT_END;"')
    end = body.index('    RestoreWangShearBaselineTest solver, sourceHistory',begin)
    body = body[:begin] + '''    Next attempt
    Print #output, "B_RESUME_END;" & CStr(workingHistory.Count) & ";" & ExperimentNumberTest(baseFactor) & ";" & _
        ExperimentNumberTest(WangArcElapsedTest(watch))
''' + body[end:]
    body += '''' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает контрольные поля и состояния по коротким строкам Windows.
Private Function ReadWangResumeWitnessesTest(ByVal path As String) As Collection
    Dim source As Integer, values As Variant, anchor As Long, offset As Long
    Dim result As New Collection
    source = FreeFile
    Open path For Input As #source
    For anchor = 1 To 2
        ReDim values(0 To 1146)
        ReadWangResumeWireChunkTest source, values, 0, 1
        For offset = 1 To 60 Step 15
            ReadWangResumeWireChunkTest source, values, offset, 15
        Next offset
        ReadWangResumeWireChunkTest source, values, 61, 6
        For offset = 67 To 1146 Step 8
            ReadWangResumeWireChunkTest source, values, offset, 8
        Next offset
        result.Add values
    Next anchor
    If Not EOF(source) Then Err.Raise 5, , "Лишняя контрольная запись H26."
    Close #source
    Set ReadWangResumeWitnessesTest = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает 60 координат нормали и три скалярных параметра псевдодуги H26.
Private Function ReadWangResumeNormalTest(ByVal path As String) As Variant
    Dim source As Integer, values As Variant, offset As Long
    ReDim values(0 To 62)
    source = FreeFile
    Open path For Input As #source
    For offset = 0 To 59 Step 15
        ReadWangResumeWireChunkTest source, values, offset, 15
    Next offset
    ReadWangResumeWireChunkTest source, values, 60, 3
    If Not EOF(source) Then Err.Raise 5, , "Лишние координаты нормали H26."
    Close #source
    ReadWangResumeNormalTest = values
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет все десятичные поля одной короткой строки ASCII без числового преобразования.
Private Sub ReadWangResumeWireChunkTest(ByVal source As Integer, ByRef target As Variant, ByVal offset As Long, ByVal width As Long)
    Dim raw As String, tokens As Variant, index As Long
    If EOF(source) Then Err.Raise 5, , "Контрольная запись H26 закончилась на позиции " & CStr(offset)
    Line Input #source, raw
    tokens = Split(raw, ";")
    If UBound(tokens) <> width - 1 Then Err.Raise 5, , "Неполная контрольная запись H26 на позиции " & CStr(offset) & _
        ". Получено полей: " & CStr(UBound(tokens) + 1) & "; ожидалось: " & CStr(width)
    For index = 0 To width - 1: target(offset + index) = tokens(index): Next index
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает все повторно вычисленные значения с архивной записью без изменения её точности.
Private Sub RequireWangResumeWireTest(ByRef raw As Variant, ByRef actual() As Double, ByVal offset As Long)
    Dim index As Long
    For index = 1 To UBound(actual)
        If ExperimentNumberTest(actual(index)) <> CStr(raw(offset + index - 1)) Then _
            Err.Raise 5, , "Контрольная запись H26 отличается. Индекс: " & CStr(offset + index - 1)
    Next index
End Sub

'''
    source = source[:a] + body + source[b:]
    assert max(map(len,source.splitlines())) < 1023
    return source.replace("\n","\r\n").encode()


def main():
    parent = (PARENT / "Preparation.json").read_bytes()
    original = (PARENT / "NativeContinue/MVT2.csv").read_bytes()
    verified = (PARENT / "VerificationContinue.json").read_bytes()
    assert (digest(parent),digest(original),digest(verified)) == (PARENT_PREP,PARENT_NATIVE,PARENT_REPORT)
    prep = json.loads(parent)
    normal, accepted = wire(original)
    inputs = {"H26Normal.csv":put("H26Normal.csv", normal), "AcceptedWire.csv":put("AcceptedWire.csv", accepted)}
    for name, expected in prep["inputs"].items():
        raw = (PARENT / name).read_bytes()
        assert digest(raw) == expected
        if name == "Verify-MVT2ShearControlled.py":
            inputs["PriorReplay.py"] = put("PriorReplay.py", raw)
            continue
        if name in ("Stage.py", "ContinueTest.txt", "README.txt"):
            continue
        if name == MACRO:
            raw = overlay(raw)
        elif name == RUNNER:
            raw = swap(raw.decode("utf-8"), "[ValidateSet('Continue')][string]$Phase='Continue'", "[ValidateSet('Resume')][string]$Phase='Resume'").encode()
        inputs[name] = put(name, raw)
    for name in ("Stage.py", "README.txt", "Verify-MVT2ShearControlled.py"):
        inputs[name] = digest((HERE / name).read_bytes())
    assert put("docs/regression/Diagnostic.xlsm", (HERE / BOOK).read_bytes()) == prep["book_sha256"]
    for folder in ("NativeResume","Temp"):
        (HERE / folder).mkdir(exist_ok=True)
    metadata = {"inputs": inputs, "book_sha256":prep["book_sha256"], "replay_sha256":prep["replay_sha256"],
                "watchdog_seconds":105, "parent_native_sha256":PARENT_NATIVE, "parent_report_sha256":PARENT_REPORT}
    print(put("Preparation.json",(json.dumps(metadata,indent=2)+"\n").encode()))


if __name__ == "__main__":
    main()
