Two isolated smaller-arc MVT2 B probes at the accepted station history H26.

    python -B -X utf8 tmp/mv26b/Stage.py
    python -B -X utf8 tmp/mv26b/Verify-MVT2ShearControlled.py --inputs-only

After allocating the isolated Office slot and passing the resource guard, launch once.

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mv26b/Run-MVT2ShearControlled.ps1

Reconstruct H25 and H26 natively by repeating only previously accepted attempts 1 and 5.
All 60 coordinates, 6 resultants and 1080 history values must match the archived native
15-digit output exactly. Numerical reconstruction at full native precision preserves the
state omitted by decimal export. Windows VBA transport uses short ASCII CRLF rows and their
original decimal values. Each probe restores the accepted prefix to H26 and verifies
native double equality. Attempts at 1.31947154672837e-7 and its exact half use only the
sealed attempt-6 normal, the original stress law, original 56+6+4 equations and their
unmodified tolerances. Check actual radius, directed arc projection and all true signed
efforts. The solver's local adjoint interval describes numerical load uncertainty and is
checked separately from the physical direction along the plane. An overlap or an unavailable
interval leaves load direction unresolved, even with a forward physical projection.
Each successful diagnostic field is discarded before the next test. Final H24 is restored.
Native watchdog is 105 s. No new load limit or production result follows from these probes.
