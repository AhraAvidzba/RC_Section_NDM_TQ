"""ДЛЯ ТЕСТОВ: продолжает нативные 44 состояния, проверяя общее отображение и деформационное управление."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestStage(repo, root, direct_control=False):
    """Не использует независимые поля в прогнозе; исходная история содержит только собственные нативные решения."""
    here = Path(__file__).resolve().parent
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/ClosedASDReducedNative20261118')
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, expected in prep['inputs'].items():
        raw = (template/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, name
        files[name] = raw
    old, new = 'modTestMVT2ReducedTest', 'modTestMVT2ReducedControlTest'
    code = files.pop('tests/'+old+'.bas').decode('utf-8-sig').replace('\r\n', '\n')
    code = code.replace(old, new).replace('RunTestMVT2ReducedTest', 'RunTestMVT2ReducedControlTest')
    code = code.replace('TOTAL_MVT2_REDUCED_TEST', 'TOTAL_MVT2_REDUCED_CONTROL_TEST')
    code = code.replace('completed = RunReducedMVT2Test(report, tracePath)',
                        'RunReducedGeometryTest report, tracePath\n            completed = RunReducedMVT2Test(report, tracePath)')
    code = code.replace('If history.Count <> 38 Or Not solver.ReplayAcceptedFields', 'If history.Count <> 44 Or Not solver.ReplayAcceptedFields')
    code = code.replace('previousQ = 64375#: currentQ = 64687.5', 'previousQ = 73750#: currentQ = 75000#')
    code = code.replace('requested = Array(65000#, 67500#, 70000#, 72500#, 73750#, 75000#)',
                        'requested = Array(75312.5, 76000#, 77500#, 80000#)')
    needle = '''        If Not solved Then
            solver.DiscardStep
            Exit Function
        End If
        solver.CopyTrial field, actual'''
    assert code.count(needle) == 1
    code = code.replace(needle, '''        If Not solved Then
            solver.DiscardStep
            RunReducedMVT2Test = RunReducedControlTest(solver, operators, previous, previousQ, currentQ, report, tracePath, stations)
            Exit Function
        End If
        solver.CopyTrial field, actual''')
    code = code.replace('    RunReducedMVT2Test = True',
                        '    RunReducedMVT2Test = RunReducedControlTest(solver, operators, previous, previousQ, currentQ, report, tracePath, stations)')
    control = (here/'TestNativeTransferredControl.bas.txt').read_text('utf-8')
    control = control.replace('RunTransferredControlTest', 'RunReducedControlTest').replace('For index = 1 To 30', 'For index = 1 To 60')
    if direct_control:
        code = code.replace('requested = Array(75312.5, 76000#, 77500#, 80000#)', 'requested = Array()')
        control = control.replace('For index = 1 To 60', 'For index = 1 To 30')
    control = control.replace('phase = "TransferredControl"', 'phase = "ReducedControl"')
    code += '\n'+control+'\n'+(here/'TestReducedGeometry.bas.txt').read_text('utf-8')
    files['tests/'+new+'.bas'] = code.replace('\n', '\r\n').encode('utf-8-sig')
    files['Run-Native.ps1'] = files['Run-Native.ps1'].decode('utf-8-sig').replace(old, new).replace('RunTestMVT2ReducedTest', 'RunTestMVT2ReducedControlTest').encode('utf-8-sig')
    old_prefix = files['FinePrefix.csv'].decode('cp1251').splitlines()
    added = [line for line in (template/'Native/Operators.csv').read_text('cp1251').splitlines() if line.startswith('F;')]
    assert len(old_prefix) == 38 and len(added) == 6
    files['FinePrefix.csv'] = ('\r\n'.join(old_prefix+added)+'\r\n').encode('cp1251')
    files['docs/regression/Diagnostic.xlsm'] = files['workbook/output/RC_Section_NDM.xlsm']
    for name in (Path(__file__).name, 'TestNativeTransferredControl.bas.txt', 'TestReducedGeometry.bas.txt'):
        files[name] = (here/name).read_bytes()
    prep['test_scope'] = 'four geometry projection checks; replay 44 own fine fields; force targets 75.3125,76,77.5,80 kN; 60 first-bar control steps on force failure'
    if direct_control:
        prep['test_scope'] = 'four geometry projection checks; replay 44 own fine fields; directly perform 30 first-bar control steps without difficult extra force probes'
    prep['direct_control_from_75kN'] = direct_control
    prep['history_source'] = '38 native G5S2 states and six native Reduced states, without coarse fields'
    prep['inputs'] = {name: sha256(raw).hexdigest().upper() for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    root.mkdir()
    for directory in ('Native', 'Temp', 'src', 'tests'):
        (root/directory).mkdir(exist_ok=True)
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE REDUCED CONTROL INPUTS READY', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--direct-control', action='store_true')
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.direct_control)
