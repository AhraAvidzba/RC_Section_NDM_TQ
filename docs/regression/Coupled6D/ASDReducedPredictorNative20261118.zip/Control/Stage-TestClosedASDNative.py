"""ДЛЯ ТЕСТОВ: готовит нативный контроль восьми T-ступеней и первой совместной цели."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestStage(root, mode, full, external_pid, external_ticks):
    """Меняет только тестовую интеграцию материала и создаёт явно ограниченный новый тест."""
    here = Path(__file__).resolve().parent
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/VBAFlowIntegratedCore')
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, digest in prep['inputs'].items():
        raw = (template/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == digest
        files[name] = raw
    flow = 'src/Materials/CTestTabulatedConcreteFlow.cls'
    code = files[flow].decode('utf-8-sig').replace('\r\n', '\n')
    needle = 'Friend Sub TestStep('
    assert code.count(needle) == 1
    code = code.replace(needle, 'Private Sub TestSingleStep(')
    code += '\n'+(here/'TestClosedASDStep.bas.txt').read_text('utf-8')
    files[flow] = code.replace('\n', '\r\n').encode('utf-8-sig')
    old = 'tests/modTestMVT2GaussSpan.bas'
    test_name = 'MVT2ClosureForcePath' if full else 'MVT2ClosureFirstMixed'
    new = 'tests/modTest'+test_name+'.bas'
    code = files.pop(old).decode('utf-8-sig').replace('\r\n', '\n')
    code = code.replace('modTestMVT2GaussSpan', 'modTest'+test_name)
    code = code.replace('RunTestMVT2GaussSpan', 'RunTest'+test_name)
    code = code.replace('TOTAL_MVT2_GAUSS_SPAN', 'TOTAL_MVT2_CLOSURE_FORCE_PATH' if full else 'TOTAL_MVT2_CLOSURE_FIRST_MIXED')
    needle = '    goals(37) = 77625#'
    assert code.count(needle) == 1
    if not full:
        code = code.replace(needle, needle+'\n    ReDim Preserve goals(1 To 1) \' ДЛЯ ТЕСТОВ: только первая совместная цель; не полный путь MVT2.')
    files[new] = code.replace('\n', '\r\n').encode('utf-8-sig')
    driver = files['Run-Native.ps1'].decode('utf-8-sig').replace('modTestMVT2GaussSpan', 'modTest'+test_name)
    driver = driver.replace('RunTestMVT2GaussSpan', 'RunTest'+test_name)
    driver = driver.replace("$env:NDM_MVT_FLOW_MODE='default'", f"$env:NDM_MVT_FLOW_MODE='{mode}'")
    files['Run-Native.ps1'] = driver.encode('utf-8-sig')
    if external_pid:
        assert external_ticks > 0
        guard = files['Guard-IsolatedOffice.ps1'].decode('utf-8-sig')
        assert guard.count('$protected=@{') == 1
        guard = guard.replace('$protected=@{', f'$protected=@{{{external_pid}=[long]{external_ticks};')
        files['Guard-IsolatedOffice.ps1'] = guard.encode('utf-8-sig')
        prep['protected_external_excel'] = {'pid': external_pid, 'startTicks': str(external_ticks), 'classification': 'Preexisting external automation; never owned or closed by this test'}
    files[Path(__file__).name] = Path(__file__).read_bytes()
    files['TestClosedASDStep.bas.txt'] = (here/'TestClosedASDStep.bas.txt').read_bytes()
    files['docs/regression/Diagnostic.xlsm'] = files['workbook/output/RC_Section_NDM.xlsm']
    prep['inputs'] = {name: sha256(raw).hexdigest().upper() for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    prep['test_scope'] = 'eight torque goals and 37 mixed force goals; capacity search not included' if full else 'eight torque goals and first mixed Qy=2500 N only; not full MVT2 path'
    prep['modified_integration'] = 'repeat ASD at fixed strain until effective stress, nominal stress and E*history changes <= 1e-9 MPa'
    prep['controlled_material'] = mode
    root.mkdir()
    for name in ('Native', 'Temp', 'tests', 'src'):
        (root/name).mkdir(exist_ok=True)
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('CLOSED ASD NATIVE FIRST MIXED INPUTS READY', mode)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--mode', choices=('default', 'ndm_uniaxial'), default='default')
    parser.add_argument('--full-force-path', action='store_true')
    parser.add_argument('--protected-external-pid', type=int, default=0)
    parser.add_argument('--protected-external-ticks', type=int, default=0)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.mode, args.full_force_path, args.protected_external_pid, args.protected_external_ticks)
