"""ДЛЯ ТЕСТОВ: собирает направленную книгу с собственным нелинейным прогнозом на неизменной квадратуре."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re


def TestStage(repo, root):
    """Копирует проверенные входы, добавляет три числовых проекции и тестовый класс; основной VBA не меняет."""
    here = Path(__file__).resolve().parent
    template = here/'ResolutionEvidenceBundle/G5S2'
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, expected in prep['inputs'].items():
        if name == 'workbook/output/RC_Section_NDM.xlsm':
            continue
        raw = (template/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, name
        files[name] = raw
    source = (repo/'workbook/output/RC_Section_NDM.xlsm').read_bytes()
    assert sha256(source).hexdigest().upper() == 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
    prep['source_book_sha256'] = sha256(source).hexdigest().upper()
    files['workbook/output/RC_Section_NDM.xlsm'] = source
    files['docs/regression/Diagnostic.xlsm'] = source
    sections = re.split(r'^@@(\w+)\n', (here/'TestReducedProjectionMethods.txt').read_text('utf-8'), flags=re.M)
    for name, addition in zip(sections[1::2], sections[2::2], strict=True):
        relative = 'src/Solver/'+name+'.cls'
        original = files.get(relative, (repo/relative).read_bytes()).decode('utf-8-sig').replace('\r\n', '\n')
        files[relative] = (original+addition).replace('\n', '\r\n').encode('utf-8-sig')
    files['tests/CCoupledReducedPredictorTest.cls'] = (here/'CCoupledReducedPredictorTest.cls').read_bytes()
    old, new = 'modTestMVT2ResolutionTest', 'modTestMVT2ReducedTest'
    code = files.pop('tests/'+old+'.bas').decode('utf-8-sig').replace('\r\n', '\n')
    code = code.replace(old, new).replace('RunTestMVT2ResolutionTest', 'RunTestMVT2ReducedTest')
    code = code.replace('TOTAL_MVT2_RESOLUTION_TEST', 'TOTAL_MVT2_REDUCED_TEST')
    needle = 'completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True)'
    assert code.count(needle) == 1
    code = code.replace(needle, 'completed = RunReducedMVT2Test(report, tracePath)')
    code += '\n'+(here/'TestReducedContinuation.bas.txt').read_text('utf-8')
    files['tests/'+new+'.bas'] = code.replace('\n', '\r\n').encode('utf-8-sig')
    driver = files['Run-Native.ps1'].decode('utf-8-sig').replace(old, new)
    driver = driver.replace('RunTestMVT2ResolutionTest', 'RunTestMVT2ReducedTest')
    needle = "'CCoupledReinforcedResponse')"
    assert driver.count(needle) == 1
    driver = driver.replace(needle, "'CCoupledReinforcedResponse','CCubicSplineBasis','CCoupledReducedPredictorTest')")
    files['Run-Native.ps1'] = driver.encode('utf-8-sig')
    prefix = [line for line in (template/'Native/Operators.csv').read_text('cp1251').splitlines() if line.startswith('F;')]
    assert len(prefix) == 38
    files['FinePrefix.csv'] = ('\r\n'.join(prefix)+'\r\n').encode('cp1251')
    for name in (Path(__file__).name, 'TestReducedContinuation.bas.txt', 'TestReducedProjectionMethods.txt'):
        files[name] = (here/name).read_bytes()
    prep.update({'base_stage_commit': '41c63d6', 'test_scope': '38 own fine states; force targets 65,67.5,70,72.5,73.75,75 kN; quadratic nonlinear predictor only on direct failure',
                 'history_source': 'G5S2/Native/Operators.csv from verified section 593',
                 'separate_coarse_material_history': False, 'auxiliary_commit': False, 'physical_capacity_certified': False})
    prep['inputs'] = {name: sha256(raw).hexdigest().upper() for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    root.mkdir()
    for directory in ('Native', 'Temp', 'src', 'tests'):
        (root/directory).mkdir(exist_ok=True)
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE REDUCED PREDICTOR INPUTS READY', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
