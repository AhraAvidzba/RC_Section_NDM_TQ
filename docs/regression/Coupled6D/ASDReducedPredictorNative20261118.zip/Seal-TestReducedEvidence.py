"""ДЛЯ ТЕСТОВ: закрепляет проверенные исходники и нативные состояния уменьшенного прогноза."""

from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED


def TestSeal(repo, root):
    """Добавляет направленные проверки, сохраняя все предыдущие свидетельства и незавершённость полной приёмки."""
    name = 'ASDReducedPredictorNative20261118'
    mechanics = json.loads((root/'ReducedMechanicsChecks.json').read_bytes())
    assert mechanics['native_states']['Reduced']['states'] == 44
    assert mechanics['native_states']['Control']['states'] == 74
    assert mechanics['native_states']['Failed']['states'] == 97
    assert not mechanics['physical_capacity_certified'] and not mechanics['production_changed']
    output = repo/'docs/regression/Coupled6D'/(name+'.zip')
    with output.open('xb') as stream, ZipFile(stream, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for file in sorted(root.rglob('*')):
            if not file.is_file():
                continue
            assert '__pycache__' not in file.parts and file.suffix != '.pyc'
            info = ZipInfo(file.relative_to(root).as_posix(), date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, file.read_bytes(), compresslevel=9)
    assert output.stat().st_size < 100*2**20
    digest = sha256(output.read_bytes()).hexdigest().upper()
    path = Path('docs/reports/Coupled6DEvidence.json')
    original = check_output(['git', 'cat-file', 'blob', 'HEAD:'+path.as_posix()]).decode('utf-8').replace('\r\n', '\n')
    manifest = json.loads(original)
    assert json.loads((repo/path).read_bytes()) == manifest and name not in manifest['archives']
    last_name, last_digest = list(manifest['archives'].items())[-1]
    needle = '    '+json.dumps(last_name)+': '+json.dumps(last_digest)
    assert original.count(needle) == 1
    updated = original.replace(needle, needle+',\n    '+json.dumps(name)+': '+json.dumps(digest))
    cases = []
    for scope, output_name, message in (
        ('native', 'ReducedNativeChecks.json', 'REDUCED PREDICTOR NATIVE VBA AND CLOSED EXCEL VERIFIED; CAPACITY OPEN'),
        ('mechanics', 'ReducedMechanicsChecks.json', 'REDUCED PREDICTOR FULL EQUILIBRIUM AND GEOMETRY VERIFIED; PHYSICAL CAPACITY OPEN')):
        cases.append({'id': 'asd-reduced-predictor-'+scope, 'journal_section': 594, 'archive': name,
                      'script': 'Verify-TestReducedEvidence.py',
                      'arguments': ['--repo', '{repo}', '--root', '.', '--scope', scope, '--out', output_name],
                      'stdout_contains': message,
                      'outputs': {output_name: sha256((root/output_name).read_bytes()).hexdigest().upper()}})
    marker = '\n  ],\n  "frozen_repositories": {'
    assert updated.count(marker) == 1
    block = ',\n'.join('\n'.join('    '+line for line in json.dumps(case, ensure_ascii=False, indent=2).splitlines()) for case in cases)
    updated = updated.replace(marker, ',\n'+block+marker)
    manifest['archives'][name] = digest
    manifest['cases'].extend(cases)
    assert json.loads(updated) == manifest
    (repo/path).write_bytes(updated.replace('\n', '\r\n').encode())
    print('REDUCED PREDICTOR SEALED', output.stat().st_size, digest, len(manifest['archives']), len(manifest['cases']))


if __name__ == '__main__':
    TestSeal(Path.cwd(), Path('D:/CodexScratch/RC_Section_NDM_TQ/ReducedPredictorEvidence20261118'))
