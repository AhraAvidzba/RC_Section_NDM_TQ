"""ДЛЯ ТЕСТОВ: пробует силовое равновесие MVT2 с явно изменённой интеграцией ASD."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestSolve(section, target, field, history):
    """Принимает только полную невязку шести усилий, 56 слабых строк и четырёх связей."""
    tolerance = 5e-7+5e-7*np.max(np.abs((target@section.l)[:len(section.gauge_scale)-4]))
    result = section.evaluate(field, history, target)
    norms = [float(result[1])]
    failure = ''
    for _ in range(28):
        if result[1] <= tolerance:
            break
        try:
            correction, _ = section.correction(field, history, result, 'active', 2e-9)
        except (ArithmeticError, np.linalg.LinAlgError) as error:
            failure = str(error)
            break
        for fraction in 2.**-np.arange(13):
            trial = field+fraction*correction
            try:
                candidate = section.evaluate(trial, history, target)
            except ArithmeticError:
                continue
            if candidate[1] < result[1]:
                field, result = trial, candidate
                norms.append(float(result[1]))
                break
        else:
            failure = 'Полная невязка не уменьшилась при демпфировании.'
            break
    accepted = result[1] <= tolerance
    return field, result[4], {'accepted': bool(accepted), 'target': target.tolist(), 'forces': result[2].tolist(),
                             'norms_MPa': norms, 'tolerance_MPa': float(tolerance), 'field': field.tolist(),
                             'failure': failure, 'twist_rad_per_m': float(1000*field[3]/section.radius)}


def TestRun(repo, output, mode, adaptive):
    """Начинает с нуля и принимает только собственные уравновешенные поля без внешнего прогноза."""
    here = Path(__file__).resolve().parent
    helper = run_path(str(here/'Probe-TestASDMaterialSteps.py'))
    closure = run_path(str(here/'Probe-TestASDClosure.py'))['TestClosure']
    sections, _, _ = helper['TestInputs'](repo)
    section = sections[mode]
    section.TestOriginalNominal = section.nominal
    section.TestClosureIterations = 0
    section.nominal = lambda field, history: closure(section, field, history)
    history, field = section.initial(), np.zeros(60)
    log, good = [], True
    goals = [262750., 525500., 1051000., 2102000., 4204000., 6831500., 8670750., 10510000.]
    current_torque, previous = 0., None
    attempts = 0
    while goals:
        torque = goals[0]
        initial = field
        if adaptive and previous is not None:
            old_torque, old_field = previous
            initial = field+(torque-current_torque)/(current_torque-old_torque)*(field-old_field)
        candidate, proposed, record = TestSolve(section, np.array([0., 0., 0., torque, 0., 0.]), initial, history)
        log.append(record)
        attempts += 1
        print('T', torque, record['accepted'], record['norms_MPa'][-1], flush=True)
        if not record['accepted']:
            if adaptive and torque-current_torque > 20. and attempts < 80:
                goals.insert(0, .5*(current_torque+torque))
                continue
            good = False
            break
        goals.pop(0)
        previous = current_torque, field
        current_torque, field, history = torque, candidate, proposed
    trials = []
    if good:
        base_field, base_history = field, history
        for q in (2500., 1250., 625., 312.5, 0.):
            field, proposed, record = TestSolve(section, np.array([0., -396.*q, 0., 10510000., 0., q]), base_field, base_history)
            trials.append(record)
            print('Q', q, record['accepted'], record['norms_MPa'][-1], flush=True)
            if record['accepted'] and q > 0.:
                break
    proof = {'mode': mode, 'integration_modified': True, 'accepted_history_source': 'own force solutions from zero',
             'adaptive_preload': adaptive, 'closure_tolerance_stress_MPa': 1e-9,
             'preload': log, 'mixed_trials': trials, 'material_updates': section.calls,
             'closure_updates': section.TestClosureIterations, 'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode('utf-8'))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--mode', choices=('ndm_uniaxial', 'default'), default='ndm_uniaxial')
    parser.add_argument('--adaptive-preload', action='store_true')
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.out.resolve(), args.mode, args.adaptive_preload)
