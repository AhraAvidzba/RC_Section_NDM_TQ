"""ДЛЯ ТЕСТОВ: проверяет нелинейный прогноз в подпространстве на той же квадратуре и принятой истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestQuadraticProjection():
    """Повышает степень девяти тензорных квадратичных функций до шестнадцати кубических без изменения поля."""
    elevation = np.array([[1., 0., 0.], [1./3., 2./3., 0.], [0., 2./3., 1./3.], [0., 0., 1.]])
    projection = np.zeros((60, 39))
    projection[:4, :4] = np.eye(4)
    for column in range(27):
        unit = np.eye(27)[column].reshape(3, 3, 3)
        projection[4:52, column+4] = np.einsum('ai,bj,ijc->abc', elevation, elevation, unit).reshape(48)
    projection[52:56, 31:35] = np.eye(4)
    projection[56:60, 35:39] = np.eye(4)
    assert np.linalg.matrix_rank(projection) == 39
    return projection


def TestHistoryDigest(history):
    """Выявляет любое изменение принятого состояния при вспомогательных и отклонённых пробах."""
    return [sha256(np.ascontiguousarray(value).tobytes()).hexdigest() for value in history]


def TestReducedCorrection(section, projection, field, history, result, tangent):
    """Ограничивает производную и активные ветви стали тем же отображением, что и виртуальные перемещения."""
    if getattr(section, 'TestReducedSimple', False):
        matrix = tangent(section, field, history, single_update=False, include_steel=True)[0]
        complete = projection.T@matrix@projection
        scales = np.max(np.abs(complete), axis=0)
        return np.linalg.solve(complete/scales, -projection.T@result[0])/scales, 1
    concrete = tangent(section, field, history, single_update=False, include_steel=False)[0]
    matrix = projection.T@concrete@projection
    scatter, strains = projection.T@section.scatter, section.a@projection
    trial = result[-1].ravel()
    bounds = np.tile(section.bounds, 3)
    clipped = np.clip(trial, -bounds, bounds)
    mask, visited = np.sign(trial-clipped), set()
    for iteration in range(1, 9):
        visited.add(mask.tobytes())
        elastic = mask == 0.
        complete = matrix+(scatter[:, elastic]*200000.)@strains[elastic]
        right = -projection.T@result[0]-scatter@(np.where(elastic, trial, mask*bounds)-clipped)
        scales = np.max(np.abs(complete), axis=0)
        if np.any(scales == 0.):
            raise ArithmeticError('Нулевая колонка вспомогательной касательной.')
        step = np.linalg.solve(complete/scales, right)/scales
        predicted = trial+200000.*(strains@step)
        new_mask = np.sign(predicted-np.clip(predicted, -bounds, bounds))
        if new_mask.tobytes() in visited:
            return step, iteration
        mask = new_mask
    return step, iteration


def TestReducedSolve(section, projection, target, seed, history, tangent, affine):
    """Не фиксирует материалы; малую невязку подпространства не выдаёт за решение полной задачи."""
    coordinates = np.linalg.lstsq(projection, seed, rcond=None)[0]
    offset = seed-projection@coordinates if affine else np.zeros_like(seed)
    scales = np.array([1.]*(projection.shape[1]-4)+[30000.]*4)
    right = (target@section.l)@projection
    tolerance = float(5e-7+5e-7*np.max(np.abs(right[:-4])))

    def TestEvaluate(coordinates):
        """Считает обе невязки по одному материальному ответу; шесть усилий проверяются и в прогнозе."""
        field = offset+projection@coordinates
        result = section.evaluate(field, history, target)
        reduced_norm = max(float(np.max(np.abs((projection.T@result[0])*scales))),
                           float(np.max(np.abs(result[2]-target)/section.force_scale)))
        return field, result, reduced_norm

    field, result, norm = TestEvaluate(coordinates)
    norms, complete_norms, failure = [norm], [float(result[1])], ''
    for _ in range(32):
        if norm <= tolerance:
            break
        try:
            step, _ = TestReducedCorrection(section, projection, field, history, result, tangent)
        except (ArithmeticError, np.linalg.LinAlgError) as error:
            failure = str(error)
            break
        for fraction in 2.**-np.arange(13):
            candidate = coordinates+fraction*step
            try:
                trial_field, trial, trial_norm = TestEvaluate(candidate)
            except ArithmeticError:
                continue
            if trial_norm < norm:
                coordinates, field, result, norm = candidate, trial_field, trial, trial_norm
                norms.append(norm)
                complete_norms.append(float(result[1]))
                break
        else:
            failure = 'Невязка подпространства не уменьшилась при демпфировании.'
            break
    return field, {'auxiliary_converged': bool(norm <= tolerance), 'norms_MPa': norms,
                   'complete_norms_MPa': complete_norms, 'tolerance_MPa': tolerance,
                   'failure': failure, 'coordinates': coordinates.tolist(), 'offset': offset.tolist(),
                   'field': field.tolist(), 'affine': affine, 'degrees': projection.shape[1]}


def TestRun(repo, native, coarse, output, target_q, continue_path=False, simple_tangent=False):
    """Сравнивает исходный и вспомогательный прогнозы из одного принятого состояния без внешних полей."""
    here = Path(__file__).resolve().parent
    helpers = run_path(str(here/'TestResolutionSection.py'))
    section, history, fields = helpers['TestReplay'](repo, native, output.with_suffix('.Prefix.json'))
    section.TestReducedSimple = simple_tangent
    tangent = run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    correct = run_path(str(here/'Solve-TestSingleASDTangent.py'))['TestCorrection']
    solve = run_path(str(here/'Solve-TestASDClosure.py'))['TestSolve']
    section.correction = lambda f, h, r, method, delta: correct(section, f, h, r, tangent, single_update=False)
    prefix = json.loads(output.with_suffix('.Prefix.json').read_bytes())['states']
    q, prior_q = prefix[-1]['target_N_Nmm'][5], prefix[-2]['target_N_Nmm'][5]
    field, previous = fields[-1][1], fields[-2][1]
    target = np.array([0., -396.*target_q, 0., 10510000., 0., target_q])
    seed = field+(target_q-q)/(q-prior_q)*(field-previous)
    quadratic = TestQuadraticProjection()
    projections = [('quadratic', quadratic)]
    identities = {}
    if section.TestDof == 87:
        reference = run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
        other = helpers['TestResolutionSection'](coarse, reference, True)
        cubic, identities = run_path(str(here/'Prolong-TestResolution.py'))['TestTransfer'](other, section)
        projections = [('cubic', cubic), ('quadratic', cubic@quadratic)]
    elif section.TestDof != 60:
        raise AssertionError('Контрольный сценарий требует полную сетку 4×4 либо 5×5 базисных функций.')
    digest = TestHistoryDigest(history)
    _, _, original = solve(section, target, seed, history)
    print('original', original['accepted'], original['norms_MPa'][-1], flush=True)
    trials = []
    for name, projection in projections:
        assert np.linalg.matrix_rank(projection) == projection.shape[1]
        for affine in (False, True):
            predictor, reduced = TestReducedSolve(section, projection, target, seed, history, tangent, affine)
            _, _, full = solve(section, target, predictor, history)
            assert TestHistoryDigest(history) == digest
            row = {'space': name, 'auxiliary': reduced, 'complete': full}
            trials.append(row)
            print(name, 'affine', affine, 'aux', reduced['auxiliary_converged'], reduced['norms_MPa'][-1],
                  'full', full['accepted'], full['norms_MPa'][-1], flush=True)
    continuation = []
    if continue_path:
        projection = projections[-1][1]
        for requested in (target_q, 67500., 70000., 72500., 73750., 75000., 76000., 77500., 80000., 82500.):
            if requested <= q:
                continue
            target = np.array([0., -396.*requested, 0., 10510000., 0., requested])
            seed = field+(requested-q)/(q-prior_q)*(field-previous)
            digest_before = TestHistoryDigest(history)
            candidate, proposed, direct = solve(section, target, seed, history)
            reduced, full = None, direct
            if not direct['accepted']:
                predictor, reduced = TestReducedSolve(section, projection, target, seed, history, tangent, False)
                if reduced['auxiliary_converged']:
                    candidate, proposed, full = solve(section, target, predictor, history)
            assert TestHistoryDigest(history) == digest_before
            continuation.append({'target_q_N': requested, 'direct': direct, 'auxiliary': reduced, 'complete': full})
            print('path', requested, 'direct', direct['accepted'], 'reduced',
                  reduced['auxiliary_converged'] if reduced else None, 'complete', full['accepted'],
                  full['norms_MPa'][-1], flush=True)
            if not full['accepted']:
                break
            previous, prior_q, field, q, history = field, q, candidate, requested, proposed
    proof = {'original': original, 'trials': trials, 'identity': identities, 'history_sha256': digest,
             'same_quadrature_and_committed_history': True, 'auxiliary_state_committed': False,
             'prefix_states': len(fields), 'continuation': continuation, 'simple_tangent': simple_tangent,
             'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--coarse', type=Path)
    parser.add_argument('--target-q', type=float, required=True)
    parser.add_argument('--continue-path', action='store_true')
    parser.add_argument('--simple-tangent', action='store_true')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.native.resolve(), args.coarse.resolve() if args.coarse else None,
            args.out.resolve(), args.target_q, args.continue_path, args.simple_tangent)
