"""ДЛЯ ТЕСТОВ: проверяет точный перенос кубического поля в уточнённый базис и поиск равновесия из него."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestFields(native):
    """Связывает принятые поля с точными усилиями их собственного нативного пути."""
    fields = {row[1]: np.asarray(row[2:], dtype=float) for row in
              (line.split(';') for line in (native/'Operators.csv').read_text('cp1251').splitlines()) if row[0] == 'F'}
    return {float(row[3]): fields[row[1]] for row in
            (line.split(';') for line in (native/'MVTGaussMixed.Tensor.csv').read_text('cp1251').splitlines())
            if row[0] == 'FRAME' and float(row[2]) == 10510000.}


def TestTransfer(coarse, fine):
    """Вставляет один средний узел каждой оси; тождество деформаций проверяется на всех трёх станциях."""
    assert coarse.TestDof == 60 and fine.TestDof == 87
    knot = np.array([[1., 0., 0., 0.], [.5, .5, 0., 0.], [0., .5, .5, 0.], [0., 0., .5, .5], [0., 0., 0., 1.]])
    transfer = np.zeros((87, 60))
    transfer[:4, :4] = np.eye(4)
    for column in range(48):
        base = np.zeros(48)
        base[column] = 1.
        coefficients = np.einsum('ai,bj,ijc->abc', knot, knot, base.reshape(4, 4, 3)).reshape(75)
        transfer[4:79, column+4] = coefficients
    transfer[79:83, 52:56] = np.eye(4)
    transfer[83:87, 56:60] = np.eye(4)
    xy = coarse.xy[:coarse.TestConcreteCount]/120.
    design = np.polynomial.legendre.legvander2d(xy[:, 0], xy[:, 1], [3, 3]).reshape(len(xy), 16)
    samples = coarse.b[:, :coarse.TestConcreteCount].transpose(1, 0, 2, 3).reshape(len(xy), -1)
    polynomial = np.linalg.lstsq(design, samples, rcond=None)[0]
    fit_error = float(np.max(np.abs(design@polynomial-samples)))
    other = fine.xy/120.
    evaluate = np.polynomial.legendre.legvander2d(other[:, 0], other[:, 1], [3, 3]).reshape(len(other), 16)
    expected = (evaluate@polynomial).reshape(fine.TestPointCount, 3, 6, 60).transpose(1, 0, 2, 3)
    error = float(np.max(np.abs(fine.b@transfer-expected)))
    assert fit_error < 1e-11 and error < 1e-11, (fit_error, error)
    return transfer, {'coarse_fit_error': fit_error, 'maximum_operator_transfer_error': error}


def TestRun(repo, coarse_native, fine_native, output):
    """Сохраняет принятую историю уточнённого расчёта; переносит только начальное поле из собственного грубого расчёта."""
    here = Path(__file__).resolve().parent
    reference = run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    helper = run_path(str(here/'TestResolutionSection.py'))
    coarse = helper['TestResolutionSection'](coarse_native, reference, True)
    fine, history, points = helper['TestReplay'](repo, fine_native, output.with_suffix('.Prefix.json'))
    transfer, identity = TestTransfer(coarse, fine)
    candidates = TestFields(coarse_native)
    prefix = json.loads(output.with_suffix('.Prefix.json').read_bytes())['states']
    field = points[-1][1]
    q = prefix[-1]['target_N_Nmm'][5]
    prior_field, prior_q = points[-2][1], prefix[-2]['target_N_Nmm'][5]
    tangent = run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    correct = run_path(str(here/'Solve-TestSingleASDTangent.py'))['TestCorrection']
    solve = run_path(str(here/'Solve-TestASDClosure.py'))['TestSolve']
    fine.correction = lambda f, h, r, method, delta: correct(fine, f, h, r, tangent, single_update=False)
    records = []
    for requested in sorted(value for value in candidates if value > q):
        ratio = (requested-q)/(q-prior_q)
        warm = field+ratio*(field-prior_field)
        mapped = transfer@candidates[requested]
        for name, seed in (('own_secant', warm), ('coarse_prolongation', mapped), ('half_prolongation', .5*(field+mapped))):
            target = np.array([0., -396.*requested, 0., 10510000., 0., requested])
            accepted_field, proposed, row = solve(fine, target, seed, history)
            row['seed'] = name
            records.append(row)
            print(requested, name, row['accepted'], row['norms_MPa'][-1], flush=True)
            if row['accepted']:
                prior_field, prior_q, field, q, history = field, q, accepted_field, requested, proposed
                break
        else:
            break
    proof = {'transfer_identity': identity, 'transfer': transfer.tolist(), 'trials': records,
             'fine_history_source': 'own native accepted history; never imported from coarse model',
             'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--coarse', type=Path, required=True)
    parser.add_argument('--fine', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.coarse.resolve(), args.fine.resolve(), args.out.resolve())
