"""ДЛЯ ТЕСТОВ: отделяет наблюдаемый максимум ветви от материального предельного критерия."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestAnalyze(repo, root, output):
    """Повторяет всю принятую историю и снимает фактические главные деформации, координаты таблиц и напряжения стали."""
    with TemporaryDirectory(dir=output.parent) as directory:
        helper = run_path(str(root/'TestResolutionSection.py'))
        section, _, fields = helper['TestReplay'](repo, root/'Failed/Native', Path(directory)/'Replay.json',
            prefix_native=[root/'Prefix/Native', root/'Reduced/Native'])
        states = json.loads((Path(directory)/'Replay.json').read_bytes())['states']
    history = section.initial()
    tensorize = run_path(str(root/'TestClosedASDTangent.py'))['TestTensorize']
    curve = section.curves[1]
    peak = float(curve.x[int(np.argmax(curve.nominal))])
    records = []
    for (_, field), state in zip(fields, states, strict=True):
        result = section.evaluate(field, history, np.asarray(state['target_N_Nmm']))
        history = result[4]
        strain = (section.b@field)[:, :section.TestConcreteCount].copy()
        strain[..., 3:] *= .5
        principal = np.linalg.eigvalsh(tensorize(strain))
        coordinate = history[2][1, :, :section.TestConcreteCount]
        steel_strain = (section.a@field).reshape(3, section.TestSteelCount)
        utilization = np.abs(result[5])/section.bounds
        records.append({'label': state['label'], 'Qy_N': state['target_N_Nmm'][5],
            'compression_table_coordinate_maximum': float(np.max(coordinate)),
            'compression_table_peak_coordinate': peak,
            'concrete_stations_past_compression_table_peak': int(np.count_nonzero(coordinate > peak)),
            'minimum_principal_concrete_strain': float(np.min(principal)),
            'maximum_principal_concrete_strain': float(np.max(principal)),
            'maximum_longitudinal_steel_stress_yield_ratio': float(np.max(utilization[:, :4])),
            'maximum_transverse_steel_stress_yield_ratio': float(np.max(utilization[:, 4:])),
            'maximum_longitudinal_steel_strain': float(np.max(np.abs(steel_strain[:, :4]))),
            'maximum_transverse_steel_strain': float(np.max(np.abs(steel_strain[:, 4:])))})
    maximum = max(records, key=lambda row: row['Qy_N'])
    position = records.index(maximum)
    proof = {'states': records, 'observed_peak': maximum, 'post_peak_states': len(records)-position-1,
             'difference_from_experimental_80000N_percent': (maximum['Qy_N']/80000.-1.)*100.,
             'peak_is_not_automatic_material_failure': True, 'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE BRANCH MATERIAL STATES ANALYZED', maximum['Qy_N'], len(records)-position-1)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.repo.resolve(), args.root.resolve(), args.out.resolve())
