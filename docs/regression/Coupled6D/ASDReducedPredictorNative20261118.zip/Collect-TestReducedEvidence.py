"""ДЛЯ ТЕСТОВ: сохраняет собственные нативные пробы и точный VBA уменьшенного прогноза."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile


def TestCopy(source, target):
    """Копирует свидетельство один раз, не заменяя неизвестные байты."""
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = source.read_bytes()
    if target.exists():
        assert target.read_bytes() == raw
    else:
        target.write_bytes(raw)


def TestCollect(repo, root, control_name):
    """Включает только завершённые собственные процессы и не захватывает пользовательские книги."""
    here = Path(__file__).resolve().parent
    root.mkdir()
    cases = {'Reduced': 'ClosedASDReducedNative20261118', 'Control': control_name,
             'Failed': 'ClosedASDReducedControl20261118'}
    for key, name in cases.items():
        source, target = Path('D:/CodexScratch/RC_Section_NDM_TQ')/name, root/key
        prep = json.loads((source/'Preparation.json').read_bytes())
        closure = json.loads((source/'Native/MVTGaussMixed.txt.ProcessClosure.json').read_text('utf-8-sig'))
        if key == 'Failed':
            assert closure['Stage'] == 'TIMEOUT' and closure['After']['State'] == 'Absent'
            assert closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout']
        else:
            assert closure['Passed'] and closure['Closure']['FinalState']['State'] == 'Absent'
        for relative, expected in prep['inputs'].items():
            file = source/relative
            assert sha256(file.read_bytes()).hexdigest().upper() == expected, (key, relative)
            if file.suffix != '.xlsm':
                TestCopy(file, target/relative)
        for relative in ('Preparation.json', 'Compile.log', 'CompileClosure.json', 'Run.ndjson', 'docs/regression/CodeUpdate.json'):
            TestCopy(source/relative, target/Path(relative).name)
        for file in (source/'Native').rglob('*'):
            if file.is_file():
                TestCopy(file, target/'Native'/file.relative_to(source/'Native'))
        if key == 'Failed':
            log = (source/'Native/MVTGaussMixed.txt').read_text('utf-8-sig')
            fixture, = re.findall(r'^FIXTURE: ([^\r\n]+)$', log, re.M)
            folder = Path(fixture).parent.resolve()
            assert folder.is_relative_to((source/'Temp').resolve()) and folder.name.startswith('RC_NDM_ModeSuite_')
            receipts = {}
            for suffix, name in (('.Operators.csv', 'Operators.csv'), ('.Tensor.csv', 'MVTGaussMixed.Tensor.csv'), ('', 'MVTGaussMixed.csv')):
                file = folder/('MVT2GaussSpan.csv'+suffix)
                TestCopy(file, target/'Native'/name)
                receipts[name] = {'path': str(file), 'sha256': sha256(file.read_bytes()).hexdigest().upper()}
            (target/'FailedTensorCapture.json').write_bytes((json.dumps(receipts, indent=2, sort_keys=True)+'\n').encode())
        compiler = json.loads((source/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
        book = source/'docs/regression/Diagnostic.xlsm'
        assert sha256(book.read_bytes()).hexdigest().upper() == compiler['WorkbookSHA256']
        with ZipFile(book) as archive:
            raw = archive.read('xl/vbaProject.bin')
        (target/'CompiledVBA.bin').write_bytes(raw)
        (target/'CompiledVBA.json').write_bytes((json.dumps({'bytes': len(raw), 'sha256': sha256(raw).hexdigest().upper()}, indent=2)+'\n').encode())
    for name in ('Operators.csv', 'MVTGaussMixed.csv', 'MVTGaussMixed.Tensor.csv', 'MVTGaussMixed.txt'):
        TestCopy(here/'ResolutionEvidenceBundle/G5S2/Native'/name, root/'Prefix/Native'/name)
    scripts = ('Probe-TestASDMaterialSteps.py', 'Probe-TestASDClosure.py', 'Solve-TestASDClosure.py',
               'Solve-TestSingleASDTangent.py', 'TestClosedASDTangent.py', 'TestResolutionSection.py',
               'Predict-TestReducedSpace.py', 'Prolong-TestResolution.py', 'Stage-TestReducedNative.py',
               'Stage-TestReducedControl.py', 'CCoupledReducedPredictorTest.cls', 'TestReducedProjectionMethods.txt',
               'TestReducedContinuation.bas.txt', 'TestReducedGeometry.bas.txt', 'TestNativeTransferredControl.bas.txt',
               'Collect-TestReducedEvidence.py', 'Verify-TestReducedEvidence.py', 'Restore-TestReducedCase.py',
               'Analyze-TestReducedBranch.py')
    for name in scripts:
        TestCopy(here/name, root/name)
    for name in ('ResolutionReducedG5S2.json', 'ResolutionReducedPathG5S2.json', 'ResolutionReducedSimpleG5S2.json'):
        TestCopy(here/name, root/name)
    TestCopy(here/'Inspect-TestResolutionVBA.py', root/'Inspect-TestResolutionVBA.py')
    TestCopy(here/'Verify-TestASDResolution.py', root/'Verify-TestASDResolution.py')
    TestCopy(here/'ResolutionEvidenceBundle/ProductionUnchanged.json', root/'ProductionUnchanged.json')
    (root/'Cases.json').write_bytes((json.dumps(cases, indent=2, sort_keys=True)+'\n').encode())
    source = {'archive': 'ASDResolutionSourceBooks20261118.zip',
              'sha256': '567B3B8117360BC69CFC8A3BACEB5CD800F06D1D856E54270DB2F98F5CED851E',
              'entry': 'SourceBooks/E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450.xlsm'}
    (root/'SourceBook.json').write_bytes((json.dumps(source, indent=2, sort_keys=True)+'\n').encode())
    print('REDUCED NATIVE EVIDENCE COLLECTED', len(cases))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--control-name', default='ClosedASDReducedControl20261118')
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve(), args.control_name)
