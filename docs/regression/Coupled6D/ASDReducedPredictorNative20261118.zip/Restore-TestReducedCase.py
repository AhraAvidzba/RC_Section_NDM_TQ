"""ДЛЯ ТЕСТОВ: восстанавливает чистые входы нативной книги уменьшенного прогноза."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestRestore(repo, root, key, destination):
    """Проверяет каждый вход и исходную XLSM; не переносит готовые результаты и протокол компиляции."""
    source_book, digest = run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    source = root/key
    prep = json.loads((source/'Preparation.json').read_bytes())
    assert prep['source_book_sha256'] == digest and not destination.exists()
    destination.mkdir()
    for name, expected in prep['inputs'].items():
        path = Path(name)
        assert not path.is_absolute() and '..' not in path.parts
        raw = source_book if name == 'workbook/output/RC_Section_NDM.xlsm' else (source/path).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, name
        output = destination/path
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(raw)
    (destination/'Preparation.json').write_bytes((source/'Preparation.json').read_bytes())
    for directory in ('Native', 'Temp', 'tests', 'src', 'docs/regression'):
        (destination/directory).mkdir(parents=True, exist_ok=True)
    (destination/'docs/regression/Diagnostic.xlsm').write_bytes(source_book)
    assert not (destination/'Compile.log').exists() and not (destination/'Native/MVTGaussMixed.txt').exists()
    print('CLEAN REDUCED NATIVE INPUTS RESTORED', key)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--case', choices=('Reduced', 'Control', 'Failed'), required=True)
    parser.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    TestRestore(args.repo.resolve(), args.root.resolve(), args.case, args.destination.resolve())
