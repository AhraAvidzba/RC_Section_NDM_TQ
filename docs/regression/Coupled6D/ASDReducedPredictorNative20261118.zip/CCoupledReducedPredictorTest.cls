VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CCoupledReducedPredictorTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ========================================================================
' ДЛЯ ТЕСТОВ: нелинейный прогноз на той же квадратуре и принятой истории
' ========================================================================
' Квадратичное подпространство ограничивает только вспомогательные пробы.
' Класс не принимает состояние материала и не объявляет прочность сечения.
' Матрицы хранят столбец первым индексом, как CCoupledLinearSystem.

Private Const REDUCED_COUNT As Long = 39
Private Const GAUGE_COUNT As Long = 4
Private mProjection() As Double, mForceProjection() As Double
Private mNormal As CCoupledLinearSystem
Private mDegreeCount As Long
Private mDetails As String

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Готовит постоянное отображение и факторизацию ортогонального начального прогноза.
Friend Sub InitializeTest(ByVal operators As CCoupledElasticState)
    operators.TestCopyQuadraticProjection mProjection
    operators.CopyResultantResidualProjection mForceProjection
    mDegreeCount = operators.DegreeCount
    If UBound(mProjection, 1) <> REDUCED_COUNT Or UBound(mProjection, 2) <> mDegreeCount Then _
        Err.Raise 5, "CCoupledReducedPredictorTest", "Неверный размер квадратичного отображения."
    Dim normal() As Double, i As Long, j As Long, row As Long
    ReDim normal(1 To REDUCED_COUNT, 1 To REDUCED_COUNT)
    For j = 1 To REDUCED_COUNT
        For i = 1 To REDUCED_COUNT
            For row = 1 To mDegreeCount
                normal(j, i) = normal(j, i) + mProjection(j, row) * mProjection(i, row)
            Next row
        Next i
    Next j
    Set mNormal = New CCoupledLinearSystem
    If Not mNormal.Factor(normal, REDUCED_COUNT) Then _
        Err.Raise 5, "CCoupledReducedPredictorTest", "Квадратичное подпространство линейно зависимо."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает только прогноз; любое его применение требует последующего полного TryStep.
Friend Function TryPredictTest(ByVal solver As CCoupledNewtonSolver, ByRef external() As Double, _
        ByRef seed() As Double, ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double, _
        ByVal referenceModulus As Double, ByRef predicted() As Double) As Boolean
    Erase predicted: mDetails = vbNullString
    Dim coordinates() As Double, current() As Double, residual() As Double, matrix() As Double
    Dim reduced() As Double, right() As Double, tangent() As Double, candidate() As Double
    Dim trialCoordinates() As Double, trialResidual() As Double, unused() As Double
    Dim norm As Double, trialNorm As Double, tolerance As Double, maximum As Double, fraction As Double
    Dim iteration As Long, i As Long, row As Long, accepted As Boolean
    PullVectorTest seed, coordinates
    If Not mNormal.SolveFactored(coordinates) Then Exit Function
    PullVectorTest external, right
    For i = 1 To REDUCED_COUNT - GAUGE_COUNT
        If Abs(right(i)) > maximum Then maximum = Abs(right(i))
    Next i
    tolerance = absoluteTolerance + relativeTolerance * maximum
    For iteration = 0 To 32
        ExpandTest coordinates, current
        If Not solver.TestEquilibriumLinearization(current, True, True, residual, matrix) Then
            mDetails = "Материальный отклик прогноза не получен.": Exit Function
        End If
        For row = 1 To mDegreeCount: residual(row) = residual(row) - external(row): Next row
        norm = ReducedNormTest(residual, referenceModulus)
        mDetails = mDetails & CStr(iteration) & ":" & CStr(norm) & ";"
        If norm <= tolerance Then
            predicted = current: TryPredictTest = True: Exit Function
        End If
        If iteration = 32 Then Exit For
        PullVectorTest residual, right
        PullMatrixTest matrix, tangent
        For i = 1 To REDUCED_COUNT: right(i) = -right(i): Next i
        Dim linear As New CCoupledLinearSystem
        If Not linear.Solve(tangent, right, REDUCED_COUNT) Then
            mDetails = mDetails & "Вырождена касательная прогноза.": Exit Function
        End If
        fraction = 1#: accepted = False
        ReDim trialCoordinates(1 To REDUCED_COUNT)
        Do While fraction >= 0.000244140625
            For i = 1 To REDUCED_COUNT: trialCoordinates(i) = coordinates(i) + fraction * right(i): Next i
            ExpandTest trialCoordinates, candidate
            If solver.TestEquilibriumLinearization(candidate, False, False, trialResidual, unused) Then
                For row = 1 To mDegreeCount: trialResidual(row) = trialResidual(row) - external(row): Next row
                trialNorm = ReducedNormTest(trialResidual, referenceModulus)
                If trialNorm < norm Then
                    coordinates = trialCoordinates: accepted = True: Exit Do
                End If
            End If
            fraction = fraction * 0.5
        Loop
        If Not accepted Then
            mDetails = mDetails & "Не снизилась невязка подпространства.": Exit Function
        End If
    Next iteration
    mDetails = mDetails & "Достигнут лимит итераций прогноза."
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт численные итерации прогноза отдельно от статуса полной системы.
Friend Property Get DetailsTest() As String
    DetailsTest = mDetails
End Property

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Ограничивает виртуальную работу тем же отображением, что и поле перемещений.
Private Sub PullVectorTest(ByRef full() As Double, ByRef reduced() As Double)
    ReDim reduced(1 To REDUCED_COUNT)
    Dim i As Long, row As Long
    For row = 1 To mDegreeCount
        For i = 1 To REDUCED_COUNT
            reduced(i) = reduced(i) + mProjection(i, row) * full(row)
        Next i
    Next row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Собирает P-transpose K P без симметризации неспряжённой материальной касательной.
Private Sub PullMatrixTest(ByRef full() As Double, ByRef reduced() As Double)
    Dim intermediate() As Double, column As Long, row As Long, i As Long, j As Long
    ReDim intermediate(1 To REDUCED_COUNT, 1 To mDegreeCount)
    ReDim reduced(1 To REDUCED_COUNT, 1 To REDUCED_COUNT)
    For column = 1 To mDegreeCount
        For j = 1 To REDUCED_COUNT
            If mProjection(j, column) <> 0# Then
                For row = 1 To mDegreeCount
                    intermediate(j, row) = intermediate(j, row) + full(column, row) * mProjection(j, column)
                Next row
            End If
        Next j
    Next column
    For row = 1 To mDegreeCount
        For i = 1 To REDUCED_COUNT
            If mProjection(i, row) <> 0# Then
                For j = 1 To REDUCED_COUNT
                    reduced(j, i) = reduced(j, i) + mProjection(i, row) * intermediate(j, row)
                Next j
            End If
        Next i
    Next row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Восстанавливает пробное поле без высоких мод; исходная материальная история сохраняется.
Private Sub ExpandTest(ByRef reduced() As Double, ByRef full() As Double)
    ReDim full(1 To mDegreeCount)
    Dim i As Long, row As Long
    For row = 1 To mDegreeCount
        For i = 1 To REDUCED_COUNT: full(row) = full(row) + mProjection(i, row) * reduced(i): Next i
    Next row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет вспомогательные строки, четыре связи и проекции шести силовых невязок.
Private Function ReducedNormTest(ByRef residual() As Double, ByVal modulus As Double) As Double
    Dim reduced() As Double, i As Long, row As Long, component As Long, value As Double
    PullVectorTest residual, reduced
    For i = 1 To REDUCED_COUNT
        value = Abs(reduced(i))
        If i > REDUCED_COUNT - GAUGE_COUNT Then value = value * modulus
        If value > ReducedNormTest Then ReducedNormTest = value
    Next i
    For component = 1 To 6
        value = 0#
        For row = 1 To UBound(mForceProjection, 1)
            value = value + mForceProjection(row, component) * residual(row)
        Next row
        If Abs(value) > ReducedNormTest Then ReducedNormTest = Abs(value)
    Next component
End Function
