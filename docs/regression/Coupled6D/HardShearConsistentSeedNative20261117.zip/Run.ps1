# Компилирует диагностическую копию и запускает один профилируемый расчёт HardShear.
param([ValidateSet('Inputs','Compile','Native')][string]$Phase='Inputs')

$ErrorActionPreference='Stop'
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
Push-Location -LiteralPath $PSScriptRoot
try {
    python -B -X utf8 'Verify.py' --inputs
    if ($LASTEXITCODE) {throw 'Входы профилирования не подтверждены.'}
    if ($Phase -eq 'Inputs') {return}
    $plan=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    $modules=@($plan.modules)
    $draft='docs/regression/Diagnostic.xlsm'
    $native='Native/Report.txt'
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    . './Guard-IsolatedOffice.ps1'
    if ($Phase -eq 'Compile') {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Get-FileHash -LiteralPath $draft).Hash -cne $plan.source_workbook_sha256) {
            throw 'Для компиляции нужна новая копия исходной книги.'
        }
        Assert-IsolatedOfficeReady 'CompileHardPhysicalControl'
        & './tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $draft -ModuleNames $modules |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
        return
    }
    $code=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closed=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$code.Compiled -or $code.ProductionChanged -or $code.ProductionSHA256 -cne $plan.source_workbook_sha256 -or
        $code.Workbook -ine (Resolve-Path -LiteralPath $draft).Path -or $code.WorkbookSHA256 -cne (Get-FileHash $draft).Hash -or
        (($code.Modules | Sort-Object) -join ',') -cne (($modules | Sort-Object) -join ',') -or $closed.State -cne 'Absent') {
        throw 'Компиляция профилируемой копии не подтверждена.'
    }
    if (Test-Path -LiteralPath $native) {throw 'Нативный результат уже существует.'}
    Assert-IsolatedOfficeReady 'RunHardPhysicalControl'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $draft -ReportPath $native -Macro 'modTestCoupledElasticState.RunTestHardConsistentSeeds' `
        -Mode No -TimeoutSeconds 220 -FailFast -VerifyResultsReopen
    if ($LASTEXITCODE) {throw "Нативный профилируемый расчёт завершился с кодом $LASTEXITCODE."}
    $details=Get-Content -LiteralPath $native -Encoding utf8
    $fixture=@($details | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixture.Count -ne 1) {throw 'Не подтверждён путь рабочей копии.'}
    $directory=Split-Path -Parent $fixture[0].Substring('FIXTURE: '.Length)
    if (!$directory.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Копия находится вне Temp.'}
    $execution=Join-Path $directory 'RC_Section_NDM_execution_report.txt'
    Copy-Item -LiteralPath $execution -Destination 'Native/Execution.txt'
    python -B -X utf8 'Verify.py'
    if ($LASTEXITCODE) {throw 'Независимая сверка профиля не пройдена.'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
