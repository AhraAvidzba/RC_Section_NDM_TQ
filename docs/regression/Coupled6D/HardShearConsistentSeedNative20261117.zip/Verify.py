"""Verify native candidate and stock results while preserving any capacity differences."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re


HERE=Path(__file__).resolve().parent


def digest(name):
    return sha256((HERE/name).read_bytes()).hexdigest().upper()


def read(name):
    raw=(HERE/name).read_bytes()
    encoding='utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig'
    return raw.decode(encoding).replace('\r\n','\n')


def tagged(report,prefix):
    matches=[row for row in report.splitlines() if row.startswith(prefix)]
    assert len(matches)==1,prefix
    return matches[0]


def inputs():
    plan=json.loads(read('Fixture.json'))
    for name,expected in plan['inputs'].items():
        assert digest(name)==expected,name
    if (HERE/plan['workbook']).exists():
        assert digest(plan['workbook'])==plan['source_workbook_sha256']
    return plan


def native(plan):
    stock=read('Stock/Both.txt')
    result=read('Native/Report.txt')
    compiled=json.loads(read('docs/regression/CodeUpdate.json'))
    closure=json.loads(read('CompileClosure.json'))
    assert compiled['Compiled'] and not compiled['ProductionChanged'] and closure['State']=='Absent'
    assert sorted(compiled['Modules'])==sorted(plan['modules'])
    assert tagged(stock,'SOURCE_SHA256: ')=='SOURCE_SHA256: '+plan['source_workbook_sha256']
    assert tagged(result,'SOURCE_SHA256: ')=='SOURCE_SHA256: '+compiled['WorkbookSHA256']
    assert 'RUNTIME ERROR:' not in result and not re.search(r'^(FAIL:|NOT RUN:)',result,re.M)
    count={}
    for name in ('WORKBOOK_TIMING','DEFORMATION_CONTROL','SPATIAL_TRANSACTIONS'):
        tag=tagged(result,'TOTAL_COUPLED_'+name+':')
        passed=re.fullmatch(r'.*: passed=(\d+); failed=0',tag)
        assert passed and int(passed[1])>0
        count[name]=int(passed[1])
    assert count['WORKBOOK_TIMING']==28 and count['SPATIAL_TRANSACTIONS']==13
    for prefix in ('N','Mx','My','T','Qx','Qy'):
        assert tagged(stock,f'OK: direct {prefix} actual=')==tagged(result,f'OK: direct {prefix} actual=')
    observations=[]
    for transcript,log in ((stock,'Stock/Both.Execution.txt'),(result,'Native/Execution.txt')):
        before,after=re.search(r'^RESULTS_SAVE_REOPEN: before=([\dA-F]{64}); after=([\dA-F]{64}); equal=True;',transcript,re.M).groups()
        assert before==after
        assert tagged(transcript,'SOURCE_UNCHANGED:')=='SOURCE_UNCHANGED: True'
        timed=tagged(transcript,'TIMING_SECONDS: ')
        elapsed=float(timed.split(' | ')[0].split(': ')[1].replace(',','.'))
        state=tagged(transcript,'TIMING_STATES: ')
        lower=re.search(r'direct=OK; capacity=NumFail; confirmed lower=([0-9.,]+); limit=; code=NUMERICAL_FAILURE',state)
        assert lower and all(f'OK: no unconfirmed limit component {component}' in transcript for component in ('N','Mx','My','T','Qx','Qy'))
        lines=[row for row in read(log).splitlines() if '| Мера деформации:' in row]
        assert len(lines)==1
        controls=lines[0].split('] ',1)[1]
        probes=re.search(r'равновесие при lambda = 1 подтверждено: True; проб: (\d+)',controls)
        assert probes and int(probes[1])<=96
        physical=re.search(r'принято полей по тензорной мере: (\d+)',controls)
        observations.append({'seconds':elapsed,'lower_lambda':float(lower[1].replace(',','.')),
                             'probes':int(probes[1]),'physical_control_selected':physical is not None,
                             'physical_control_accepted':int(physical[1]) if physical else 0,
                             'diagnostic':controls,'results_fingerprint':before})
    assert 'OK: точный прогноз требует одной сборки без касательной' in result
    output={'status':'PASS','stock':observations[0],'candidate':observations[1],'assertions':count,
            'six_signed_direct_forces_identical':True,'physical_limit_certified':False,
            'stock_native_report_sha256':digest('Stock/Both.txt'),'candidate_native_report_sha256':digest('Native/Report.txt')}
    raw=(json.dumps(output,ensure_ascii=False,indent=2)+'\n').encode()
    path=HERE/'Native/Verification.json'
    if path.exists():
        assert path.read_bytes()==raw
    else:
        path.write_bytes(raw)
    print('HARDSHEAR CONSISTENT SEED A/B PASS',json.dumps(output,ensure_ascii=False))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',action='store_true')
    options=parser.parse_args()
    fixture=inputs()
    if options.inputs:
        print('HARDSHEAR CONSISTENT SEED INPUTS: PASS')
    else:
        native(fixture)
