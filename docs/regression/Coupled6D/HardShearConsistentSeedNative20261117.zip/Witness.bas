    ' Точная нулевая проба проверяет сокращённый путь без касательной и три буфера.
    Dim zeroLoad(1 To 6) As Double, loadSlope(1 To 6) As Double, seedControl() As Double
    Dim seedField() As Double, seedWrench() As Double, trialValue As Double, seed As Variant
    Dim i As Long, unchanged As Boolean
    If Not solver.TryStep(9000#, 1000#, -1200#, 900#, 650#, -520#, 1E-8, 1E-8, 25) Then _
        Err.Raise 5, , "Не удалось подготовить контрольный прогноз."
    solver.CopyTrial field, resultants
    solver.AcceptStep
    ReDim seedControl(1 To operators.DegreeCount)
    seedControl(1) = 1#: loadSlope(1) = 100#
    zeroLoad(1) = 9000#: zeroLoad(2) = 1000#: zeroLoad(3) = -1200#
    zeroLoad(4) = 900#: zeroLoad(5) = 650#: zeroLoad(6) = -520#
    seed = field
    If Not solver.TryDeformationStep(zeroLoad, loadSlope, seedControl, field(1), 0#, trialValue, 1E-8, 1E-8, 25, _
            consistentControl:=True, initialField:=seed) Then Err.Raise 5, , "Контрольное предсказание не прошло равновесие."
    TestRecord InStr(1, solver.ResultMeta.DiagnosticDetails, "; пробы: 1;", vbBinaryCompare) > 0, _
        "точный прогноз требует одной сборки без касательной", passed, failed, report
    solver.CopyTrial seedField, seedWrench
    unchanged = (trialValue = 0#)
    For i = 1 To UBound(field): unchanged = unchanged And seedField(i) = field(i): Next i
    For i = 1 To UBound(resultants): unchanged = unchanged And seedWrench(i) = resultants(i): Next i
    TestRecord unchanged, "точный прогноз сохраняет поле и шесть усилий", passed, failed, report
    solver.DiscardStep
    TestRecord center.TestAcceptedSteps = 1 And plusSide.TestAcceptedSteps = 1 And minusSide.TestAcceptedSteps = 1, _
        "быстрый контроль не принимает историю до команды", passed, failed, report
