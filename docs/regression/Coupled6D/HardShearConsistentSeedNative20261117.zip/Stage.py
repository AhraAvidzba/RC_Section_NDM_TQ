"""Stage an equilibrium-first validation candidate for consistent material control."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
STORAGE=Path('D:/CodexScratch/RC_Section_NDM_TQ')
PREVIOUS=REPO/'docs/regression/Coupled6D/HardShearPhysicalControlCandidateBNative20261117.zip'
PREVIOUS_SHA='EDE8F989348A06C21492DF840F7315C1DB5C4EF8C91719735B85D49A7A9E0F59'
BOOK='workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA='245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'
TEST='tests/modTestCoupledElasticState.bas'


def sha(data):
    return sha256(data).hexdigest().upper()


def source(data):
    return data.decode('utf-8-sig').replace('\r\n','\n')


def one(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)


def solver(text):
    location='        built = Evaluate(current, True, useGradientTangent, Not mConsistentControl, mConsistentControl)\n'
    check='''        ' Точный прогноз проверяется по всем уравнениям до построения касательной.
        If mConsistentControl And mIterations = 0 Then
            If Abs(ControlResidual(current)) <= tolerance Then
                If Evaluate(current, False) Then
                    If EquilibriumNorm(load, current) <= tolerance And GaugesVerified(tolerance) Then
                        mCandidate = current
                        PublishCandidate currentLambda
                        SolveStep = True
                        Exit Function
                    End If
                End If
            End If
        End If
'''
    return one(text,location,check+location)


def tests(text):
    start=text.index('Public Function RunTestCoupledSpatialTransactions()')
    end=text.index('\nEnd Function',start)
    witness=source((HERE/'Witness.bas').read_bytes())
    report='    RunTestCoupledSpatialTransactions = report & "TOTAL_COUPLED_SPATIAL_TRANSACTIONS: passed="'
    body=one(text[start:end],report,witness+'\n'+report)
    wrapper='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запускает штатный HardShear и отдельно проверяет историю трёх станций.
Public Function RunTestHardConsistentSeeds() As String
    RunTestHardConsistentSeeds = RunTestCoupledWorkbookTiming("Both", "Excel") & vbCrLf & _
        RunTestCoupledSpatialTransactions() & vbCrLf & RunTestCoupledDeformationControl()
End Function
'''
    return text[:start]+body+text[end:]+ '\n'+wrapper


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,required=True)
    args=cli.parse_args()
    root=args.destination.resolve()
    assert root.is_relative_to(STORAGE.resolve()) and root!=STORAGE.resolve()
    stock=(REPO/BOOK).read_bytes()
    assert sha(stock)==BOOK_SHA and sha(PREVIOUS.read_bytes())==PREVIOUS_SHA
    with ZipFile(PREVIOUS) as archive:
        plan=json.loads(archive.read('Fixture.json'))
        files={name:archive.read(name) for name in plan['inputs'] if name.startswith(('tools/','Guard-','Stock/'))}
        assert all(sha(data)==plan['inputs'][name] for name,data in files.items())
        files['Run.ps1']=archive.read('Run.ps1').decode().replace('RunTestHardPhysicalControlCandidate','RunTestHardConsistentSeeds').encode()
    originals={}
    for name,edit in ((SOLVER,solver),(TEST,tests)):
        raw=(REPO/name).read_bytes()
        originals[name]=sha(raw)
        assert originals[name]==plan['original_sources'][name]
        files[name]=edit(source(raw)).replace('\n','\r\n').encode()
    assert all(max(map(len,source(data).splitlines()))<1024 for name,data in files.items() if name.endswith(('.bas','.cls')))
    for name in ('Stage.py','Verify.py','Witness.bas'):
        files[name]=(HERE/name).read_bytes()
    manifest={'source_workbook_sha256':BOOK_SHA,'workbook':BOOK,'modules':[Path(name).stem for name in originals],
              'prior_comparison_sha256':PREVIOUS_SHA,'original_sources':originals,
              'inputs':{name:sha(data) for name,data in sorted(files.items())}}
    files.update({BOOK:stock,'docs/regression/Diagnostic.xlsm':stock,'Fixture.json':(json.dumps(manifest,indent=2)+'\n').encode()})
    root.mkdir()
    for name in ('Temp','Native'):
        (root/name).mkdir()
    for name,data in files.items():
        path=root/name
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as streamed:
            streamed.write(data)
    print('CONSISTENT SEED INPUTS',sha(files['Fixture.json']))


if __name__=='__main__':
    main()
