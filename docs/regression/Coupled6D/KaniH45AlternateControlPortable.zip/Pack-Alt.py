"""Package immutable inputs and actual native outputs. Never runs Excel."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import json
import runpy

H=Path(__file__).resolve().parent
BOOK='workbook/output/RC_Section_NDM.xlsm'
CLOSURE=('KaniV4.txt','KaniV4.txt.Ownership.json','KaniV4.txt.ProcessClosure.json',
         'KaniV4.txt.RunnerCleanup.json','KaniV4.txt.memory.json','KaniV4.txt.stdout.log','KaniV4.txt.stderr.log',
         'Compile.log','CompileClosure.json','Preflight.ndjson')
MEASURED=('KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv')


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def pack(repo):
    preflight=[json.loads(row) for row in (H/'Native/Preflight.ndjson').read_text(encoding='utf-8-sig').splitlines()]
    assert [x['phase'] for x in preflight]==['PreCompile','PreCompile','PreNative']
    assert preflight[0]['UTC']=='2026-11-16T14:56:44.4118352+00:00'
    attempts={
        'firstAttempt':{'preflight':preflight[0],'failedBeforeCOM':True,
                        'cause':'missing source directory','recovery':'Created empty tmp/kaniAlt/src before the second launch.',
                        'provenance':'Project launcher reported the pre-COM abort; compiler checks source files before creating an Excel.Application.'},
        'nativeAttempt':{'preflight':preflight[1:]},
    }
    (H/'RunAttempts.json').write_text(json.dumps(attempts,indent=2)+'\n',encoding='utf8')
    stage=runpy.run_path(H/'Replay-Alt.py')['adjusted_namespace']('AlternateVerification.json',portable=False)
    result=stage['verify'](repo)
    prep=read(H/'Preparation.json')
    files={n for n in prep['frozen'] if n!=BOOK}
    files.update('Native/'+n for n in (*CLOSURE,*MEASURED))
    files.update(('Preparation.json','AlternateVerification.json','docs/regression/CodeUpdate.json','Replay-Alt.py',
                  'Pack-Alt.py','Portable-README.md','RunAttempts.json'))
    assert all((H/n).is_file() for n in files)
    assert not any(n.lower().endswith(('.xlsm','.xlsx')) for n in files)
    native_book=read(H/'docs/regression/CodeUpdate.json')
    assert result['unchangedReplay'] and result['workbookSHA256']==prep['bookSHA256']
    manifest={'schema':'KaniH45AlternateControl/v1','historicalGit':prep['sourceGit'],
              'sourceWorkbookSHA256':prep['bookSHA256'],'compiledPrivateWorkbookSHA256':native_book['WorkbookSHA256'],
              'replayRequiresGitAndInputArchivesOnly':True,'files':{n:sha(H/n) for n in sorted(files)}}
    folder=H/'Portable'
    folder.mkdir(exist_ok=True)
    archive=folder/'KaniH45AlternateControlPortable.zip'
    data=json.dumps(manifest,indent=2)+'\n'
    with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=9) as out:
        fixed=(2026,11,16,0,0,0)
        for n in sorted(files):
            out.writestr(ZipInfo(n,fixed),(H/n).read_bytes(),compress_type=ZIP_DEFLATED,compresslevel=9)
        out.writestr(ZipInfo('Manifest.json',fixed),data.encode('utf-8'),compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist())==files|{'Manifest.json'}
    print(archive,sha(archive),archive.stat().st_size)
    return archive


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    pack(a.repo_root.resolve())
