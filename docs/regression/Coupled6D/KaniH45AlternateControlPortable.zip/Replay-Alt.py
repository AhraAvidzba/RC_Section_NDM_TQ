"""Replay Kani H45 alternate control from portable receipts, without Excel."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import contextlib
import io
import json
import math
import runpy
import subprocess

H = Path(__file__).resolve().parent
BOOK = 'workbook/output/RC_Section_NDM.xlsm'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(data):
    if isinstance(data, Path):
        data = data.read_bytes()
    return sha256(data).hexdigest().upper()


def blob(repo, revision, name):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',revision+':'+name])


def preparation(repo):
    manifest = read(H/'Manifest.json')
    files = manifest['files']
    assert manifest['schema']=='KaniH45AlternateControl/v1'
    assert all(digest(H/n)==v for n,v in files.items())
    receipt = read(H/'Preparation.json')
    assert manifest['historicalGit']==receipt['sourceGit']
    assert manifest['sourceWorkbookSHA256']==receipt['bookSHA256']==receipt['frozen'][BOOK]
    assert digest(blob(repo,receipt['sourceGit'],BOOK))==receipt['bookSHA256']
    assert all(files[n]==v for n,v in receipt['frozen'].items() if n!=BOOK)
    for file, expected in receipt['productionDiagnosticSourcesSHA256'].items():
        data=blob(repo,receipt['sourceGit'],file)
        assert expected in {digest(data),digest(data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))}
    for file, expected in receipt['inputZIP_SHA256'].items():
        assert digest(repo/'docs/regression/Coupled6D'/file)==expected
    # Recompute the source hash from Git. The compiled private workbook is omitted.
    # Its native launch and compile receipts must report the same SHA independently.
    private=receipt['bookSHA256']
    assert manifest['compiledPrivateWorkbookSHA256']==read(H/'docs/regression/CodeUpdate.json')['WorkbookSHA256']
    if (H/BOOK).exists():
        assert digest(H/BOOK)==private
    return receipt


def compare(expected, measured, path='result'):
    if isinstance(expected,dict):
        assert set(expected)==set(measured),path
        for key,val in expected.items():
            compare(val,measured[key],path+'.'+key)
    elif isinstance(expected,list):
        assert len(expected)==len(measured),path
        for index,(left,right) in enumerate(zip(expected,measured)):
            compare(left,right,f'{path}[{index}]')
    elif isinstance(expected,float):
        # Permit platform-level floating assembly differences after recomputing
        # the native acceptance predicates and the original tolerance directly.
        assert math.isclose(expected,measured,rel_tol=2e-11,abs_tol=5e-13),(path,expected,measured)
    else:
        assert expected==measured,(path,expected,measured)


def adjusted_namespace(name, portable):
    original=H/'Verify-Alt.py'
    code=original.read_text(encoding='utf-8-sig')
    strict_phases="    assert [p['phase'] for p in pre] == ['PreCompile', 'PreNative']"
    retained_phases="""    attempts = read_json(H/'RunAttempts.json')
    assert [p['phase'] for p in pre] == ['PreCompile', 'PreCompile', 'PreNative']
    assert attempts['firstAttempt']['preflight'] == pre[0]
    assert attempts['firstAttempt']['failedBeforeCOM'] and attempts['firstAttempt']['cause']=='missing source directory'
    assert attempts['nativeAttempt']['preflight'] == pre[1:]
    tool = (H/'tools/build_workbook/Update-IsolatedOptimizerCode.ps1').read_text(encoding='utf-8-sig')
    assert tool.index('Get-ChildItem') < tool.index('New-Object -ComObject Excel.Application')"""
    assert code.count(strict_phases)==1 and code.count("'AlternateVerification.json'")==1
    code=code.replace(strict_phases,retained_phases).replace("'AlternateVerification.json'",repr(name))
    if portable:
        native_check="    assert book['WorkbookSHA256'] == P['sha'](H / P['draft']) == own['SourceSHA256']"
        archived_check="""    assert book['WorkbookSHA256'] == own['SourceSHA256']
    if (H / P['draft']).exists():
        assert book['WorkbookSHA256'] == P['sha'](H / P['draft'])"""
        assert code.count(native_check)==1
        code=code.replace(native_check,archived_check)
    ns={'__file__':str(original),'__name__':'portable_kani_alternate'}
    exec(compile(code,str(original),'exec'),ns)
    return ns


def replay(repo):
    receipt=preparation(repo)
    saved=read(H/'AlternateVerification.json')
    ns=adjusted_namespace('Replay-AlternateVerification.json', portable=True)
    ns['P']['check']=lambda root: receipt
    with contextlib.redirect_stdout(io.StringIO()):
        computed=ns['verify'](repo)
    compare(saved,computed)
    right=computed['rightShoulder']
    print(json.dumps({'PASS':True,'sourceWorkbookSHA256':receipt['bookSHA256'],
                      'compiledPrivateWorkbookSHA256_inReceipts':read(H/'Manifest.json')['compiledPrivateWorkbookSHA256'],
                      'originalTau_MPa':computed['originalH45Tau_MPa'],'baselineAdjoint_N':computed['baselineAdjoint_N'],
                      'rightShoulder':right,'historyExact':computed['unchangedReplay'],'ownedExcelClosure':computed['ownedExcelClosure']},
                     ensure_ascii=False,indent=2))
    return computed


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    args=p.parse_args()
    replay(args.repo_root.resolve())
