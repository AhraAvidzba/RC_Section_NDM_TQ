# Архив нативной пробы альтернативного управления Kani H45

Отчёты получены в одной частной копии книги. Архив хранит исходную историю,
точную проекцию, код проверочного макроса, численные ряды станций и
независимый повтор. В паспорте `Manifest.json` указаны входы и их SHA-256.
Книги Excel в архив не вложены.

Для повтора нужны Python с NumPy/SciPy, история исходного Git и три закреплённых
контрольных архива в `docs/regression/Coupled6D`. Из корня репозитория:

```powershell
$env:PYTHONPATH='D:/CodexScratch/RC_Section_NDM_TQ/FocusedVerifierDeps'
$replay=(New-Item -ItemType Directory -Path 'tmp/kaniAlt/PortableReplay').FullName
Expand-Archive -LiteralPath 'tmp/kaniAlt/Portable/KaniH45AlternateControlPortable.zip' -DestinationPath $replay
python -B -X utf8 (Join-Path $replay 'Replay-Alt.py') --repo-root (Get-Location).Path
```

Скрипт читает исходную книгу как исторический Git blob `dde8810`. SHA
скомпилированной частной книги сверяется между журналами исходного прогона компиляции и открытия приватного Excel. Повтор отдельно
сверяет исходники, 89 силовых невязок, пять кинематических связей, исходное
поле H45 и его восстановление. Сохранённый отчёт сравнивается с заново
вычисленным `Replay-AlternateVerification.json`. Открывать Excel для
этого не нужно.

В `AlternateVerification.json` поле `rightShoulder` показывает, найдено ли
равновесие в единственной конечной пробе. Вычисленная Qy и её численная
разрешимость доступны при успехе пробы. Сам отчёт о тесте и восстановлении
истории остаётся воспроизводимым при численном отказе продолжения.

Первый запуск остановился до Excel при отсутствии пустой папки `src` в
частном каталоге. Первый предварительный замер и повторный вход сохранены
в `Native/Preflight.ndjson` и объяснены в `RunAttempts.json`. Измерение
в Office выполнено один раз. Для подготовки нового частного прогона
создайте `tmp/kaniAlt/src` до вызова `Run-Alt.ps1`.
