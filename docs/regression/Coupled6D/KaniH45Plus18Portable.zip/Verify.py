"""Recalculate the H45 +18 N evidence from the five sealed project archives."""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import json,os,runpy

here=Path(__file__).resolve().parent
parser=ArgumentParser(); parser.add_argument('--repo-root',type=Path,required=True); args=parser.parse_args()
os.environ['KANI_REPLAY_REPOSITORY']=str(args.repo_root.resolve())
manifest=json.loads((here/'Manifest.json').read_text(encoding='utf8'))
digest=lambda p:sha256(p.read_bytes()).hexdigest().upper()
assert all(digest(here/name)==want for name,want in manifest['files'].items())
# The nonlinear section replay also emits the one preregistered directional measurement.
runpy.run_path(here/'Design-DirectionH45.py')
full=json.loads((here/'H45Plus18Diagnostic.json').read_text(encoding='utf8'))
p=json.loads((here/'H45Plus18DirectionalPlan.json').read_text(encoding='utf8'))
s=json.loads((here/'CompactResult.json').read_text(encoding='utf8'))
assert p['fixedQyN']==s['probe']['prescribedQy_N'] and p['fixedPositiveGamma']==s['probe']['gamma']
assert abs(p['stencilPhysicalCosineToPriorMeasuredLoadShape'])<1e-12
assert p['fixtureSHA256']==s['probe']['fixtureSHA256']==digest(here/'H45Plus18DirectionalFields.csv')
assert full['nativeInputSHA256']==s['inputZIP_SHA256'] and full['stencilReconstructedStations']==104 and full['screenedStations']==128
assert full['comparisons']['freshCommonMinimumMPa']<full['toleranceMPa']
assert min(full['comparisons']['freshCandidate']['apexFiniteNorms'].values())>1000*full['toleranceMPa']
assert min(full['comparisons']['last']['apexFiniteNorms'].values())>700*full['toleranceMPa']
assert set(full['comparisons']['last']['apexFiniteMaxRow'].values())=={81}
assert full['nativeTrialRecommended'] is False
numbers={'freshLinear':full['comparisons']['freshCommonMinimumMPa'],
         'sameFieldFiniteApex':max(full['comparisons']['freshCandidate']['apexFiniteNorms'].values()),
         'afterThreeCorrectors':max(full['comparisons']['last']['apexFiniteNorms'].values())}
for label,value in numbers.items(): assert abs(value-s['conditionalNorms_MPa'][label])<max(4e-12,4e-8*abs(value)),(label,value)
print(json.dumps(s,indent=2,ensure_ascii=False))
