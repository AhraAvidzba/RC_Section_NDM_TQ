from pathlib import Path
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
import csv,json,os,runpy
import numpy as np

H=Path(__file__).resolve().parent; ROOT=Path(os.environ.get('KANI_REPLAY_REPOSITORY',str(H.parent.parent))).resolve(); ART=ROOT/'docs'/'regression'/'Coupled6D'
FILES={'H45':('KaniCommitNear48Portable.zip','EA0A80006AF81D99799B53FDCB75B18CDDE7B7DF730AB16039902F12C6431488'),
       'H44':('KaniPracticalProbe45Portable.zip','4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113'),
       'section':('KaniApexSectionActions20261116.zip','360D22C5847F1DF3D40ECAA11689AF2B8B68CF8C94A22E7ACC2B3D19A08486A6'),
       'hydro':('KaniHydrostaticApex46Portable.zip','B920F591EA6436DB65914CEF8582EA8EB42301679A15311A924253942FEAAEA5'),
       'constitutive':('KaniApexConstitutiveReplay20261116.zip','7AC4030A1635FAFED411B69A6AB5AB23CEEC6A29EFA98D52C3D2DBEF5D496484')}
digest=lambda p:sha256(p.read_bytes()).hexdigest().upper()
for key,(file,expect) in FILES.items():
    assert expect is None or digest(ART/file)==expect,file

def from_zip(key,name):
    with ZipFile(ART/FILES[key][0]) as z: return z.read(name)

def unpack_local(key,name):
    dest=H/name; dest.parent.mkdir(parents=True,exist_ok=True); data=from_zip(key,name); dest.write_bytes(data); return dest

def samples(key): return dict(np.load(BytesIO(from_zip(key,'MeasuredSamples.npz')),allow_pickle=False))

def record(data,tag):
    i=list(data['names']).index(tag)
    return data['fields'][i],data['states'][i],data['stations'][data['station_index'][i]]

def numeric(v): return json.loads(v)

operators=runpy.run_path(unpack_local('hydro','BuildOperators.py'))['operators']
local=runpy.run_path(unpack_local('constitutive','Verify-KaniApexReturn.py'))
pk=lambda x:float(np.max(abs(x))); R=samples('H45'); S=samples('H44'); assert np.array_equal(R['geometry'],S['geometry'])
Q,A,T=record(R,'Committed45'); E=numeric(from_zip('H45','Commit48Verification.json')); e0=np.array(E['energiesByStation_minus0plus']['Committed45']); f0=np.array(E['acceptedPredictorF_MPa']['Committed45']); assert f0.shape==(3,184)
q0=np.r_[Q[2:],Q[0]]; s0=T[:,:,:6].copy(); section_stress=T[:,:,6:].copy(); tau=A[3]
points=np.loadtxt(BytesIO(from_zip('hydro','GeometryAndDirections.csv')),delimiter=';'); assert np.array_equal(R['geometry'],points[:,:3])
L=float(R['length']); h,N,g,wt,area,forceScale=operators(points[:,:3],L)
D=np.zeros((3,184,6,88)); D[:,:,:,:79]=h[None,:,:,:]
D[0,:,:,79:83]=-.001*h[:,:,:4]; D[2,:,:,79:83]=.001*h[:,:,:4]; shape=D.reshape(-1,88)
assert pk(D@q0-s0)<2e-12
P=np.zeros((89,3,184,6)); P[:79,1]=h.transpose(2,0,1)*area[None,:,None]
W=np.zeros((79,184,6))
for i in range(25):
    for j,c in enumerate((4,5,2)): W[4+3*i+j,:,c]=N[:,i]*area
P[:79,0]=W/.002; P[:79,2]=-W/.002
Wl=h[:,:,:4].transpose(2,0,1)*area[None,:,None]/.002
P[79:83,0]=-Wl; P[79:83,2]=Wl
P[83:,1]=wt.transpose(1,0,2)*points[None,:,2,None]/forceScale[:,None,None]
Pe=P.reshape(89,-1); gauge=np.r_[g.T,np.zeros((10,4))]
load=np.zeros(89); load[[80,88]]=-1e5/forceScale[-1]  # weak long row 81 and actual Qy
r=Pe@section_stress.ravel()+gauge@q0[83:87]+load*q0[-1]
assert pk(r[:83]-A[12:95])<3e-10 and abs(pk(r)-A[2])<3e-10
assert pk(Pe[83:]-S['resultant_projection']@Pe[:83])<1e-12
assert pk(Pe[83:]@section_stress.ravel()-A[6:12]/forceScale)<2e-12

# Steel remained elastic through H44 with max axial stress <181 MPa, §315. Recheck the
# current field, Kani reinforcing geometry, and native critical hoop before subtraction.
steel_direction=np.zeros((40,6)); steel_direction[:,:4]=points[144:,3:]
steel_strain=np.einsum('sij,ij->si',s0[:,144:],steel_direction)
steel=2e5*steel_strain; assert pk(steel)<181.
check={row[1]:row for row in csv.reader(from_zip('H45','KaniV4Trace.csv').decode('cp1251').splitlines(),delimiter=';') if row[0]=='CHECK'}
hoop=int(np.argmax(abs(steel[1,8:])))+8
assert abs(steel[1,hoop]-float(check['Committed45'][-2]))<1e-8
concrete=section_stress.copy(); concrete[:,144:]=steel[:,:,None]*steel_direction[None,:,:]-section_stress[:,144:]

mats={}
for row in csv.reader(from_zip('H45','KaniV4Tangents.csv').decode('cp1251').splitlines(),delimiter=';'):
    if row[0]!='MATRIX' or row[1]=='H44TrialStock': continue
    _,k,i,*v=row; mats.setdefault(k,np.full((88,88),np.nan))[int(i)-1]=list(map(float,v))
assert sorted(mats)==['H45Refined','H45Stock'] and all(np.isfinite(x).all() for x in mats.values())
J={k:np.r_[m[:83], S['resultant_projection']@m[:83]] for k,m in mats.items()}; K=mats['H45Stock'][83:]
assert pk(mats['H45Refined'][83:]-K)<1e-14 and all(pk(m[:,-1]-load)<2e-12 for m in J.values())

# Rebuild the same coordinate tangent used by the working material for fully tensile,
# saturated stations. Positive F within the code tolerance has a special regular return;
# a cell requiring its stencil is left to the original operator.
mat=local['matrix']; vec=local['vector']; kernel=local['return_apex']

def tangent(b, kt,kc,eps, refined):
    C=np.empty((6,6)); _,cc,*_=local['parameters'](b,kt,kc)
    for j in range(6):
        delta=2e-9*(1+abs(eps[j]))/(64 if refined else 1)
        for i in range(3):
            u=np.zeros(6); u[j]=eps[j]+delta-eps[j]
            v=np.zeros(6); v[j]=eps[j]-delta-eps[j]
            pp,plus=kernel(b,kt,kc,u); mm,minus=kernel(b,kt,kc,v)
            if (0<plus['Ftrial']<=1e-8*cc) or (0<minus['Ftrial']<=1e-8*cc): raise ValueError('SmallPositivePredictor')
            ps=plus['kind']=='Elastic'; ms=minus['kind']=='Elastic'
            if ps or ms or i==2:
                C[:,j]=(np.array(vec(pp-mm))/(2*delta) if ps and ms else
                        np.array(vec(b-mm))/delta if ms and not ps else np.array(vec(pp-b))/delta)
                break
            delta*=.25
    return C

screen=[]; rejected={}; fitted=[]
for side in range(3):
    for point in range(184):
        nominal=mat(concrete[side,point]); eps=s0[side,point]; kt,kc=e0[side,point]
        if not (21*kt>=1 and np.linalg.eigvalsh(nominal)[0]>0): continue
        screen.append((side,point))
        try: m0=tangent(nominal,kt,kc,eps,False); m1=tangent(nominal,kt,kc,eps,True)
        except ValueError as x:
            rejected[str(x)]=rejected.get(str(x),0)+1; continue
        fitted.append((side,point,nominal,kt,kc,-1 if point>=144 else 1,m0,m1))
Jrest={k:m.copy() for k,m in J.items()}
for si,ip,b,kt,kc,sign,Cs,Cr in fitted:
    local_rows=P[:,si,ip,:]*sign
    Jrest['H45Stock']-=local_rows@Cs@D[si,ip]
    Jrest['H45Refined']-=local_rows@Cr@D[si,ip]

def local_response(d, derivative=False):
    action=np.zeros(89); slope=np.zeros((89,88)); excluded=[]; regimes={}
    for sj,ij,b,kt,kc,sign,Cs,Cr in fitted:
        dstrain=D[sj,ij]@d; rows=P[:,sj,ij,:]*sign
        try:
            stress,res=kernel(b,kt,kc,dstrain)
            Ct=np.column_stack([vec(local['apex_jvp'](b,kt,kc,dstrain,direction)[0]) for direction in np.eye(6)]) if derivative else None
        except ValueError as exc:
            excluded.append([sj-1,ij+1,str(exc)]); continue
        action+=rows@np.array(vec(stress-b)); regimes[res['kind']]=regimes.get(res['kind'],0)+1
        if derivative: slope+=rows@Ct@D[sj,ij]
    return action,slope,excluded,regimes

print('anchor',pk(r),tau,'screen',len(screen),'covered stencils',len(fitted),'excluded',rejected,flush=True)
