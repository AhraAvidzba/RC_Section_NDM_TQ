"""Fixed +18 N test of fresh H45 and finite-apex-corrected section charts."""
from pathlib import Path
from hashlib import sha256
import json,runpy
import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
m=runpy.run_path(HERE/'Build-H45Section.py'); pk=m['pk']; E=m['E']; K=m['K']; B=m['shape']; D=m['D']; J=m['J']; Jrest=m['Jrest']
P=m['P']; r=m['r']; q0=m['q0']; sr=m['R']; rr=m['S']; tau=m['tau']; Q=m['Q']; kappa=K[4]/25600
increment=18.; dl=increment/1e5; cap=6e-8; modes=sorted(J)
scale=np.r_[np.full(83,1e-7),np.full(4,1e-3),1e-4]
compat=np.r_[25600*m['g']@q0[:79],0.]
base_eq=np.vstack((K[:4],np.eye(88)[-1]))*scale
rhs=np.r_[-compat[:4],dl]; norm=np.max(abs(base_eq),axis=1); base_eq/=norm[:,None]; rhs/=norm
S=B*scale/cap
Aeq=np.c_[base_eq,np.zeros(5)]
cvx=[np.c_[S,np.zeros(len(S))],np.c_[-S,np.zeros(len(S))],np.r_[-kappa*scale/cap,0.][None,:]]
crhs=[np.ones(len(S)),np.ones(len(S)),np.zeros(1)]


def linear_solve(operators,offsets,around=None):
    rows=cvx.copy(); vals=crhs.copy()
    for k,a in operators.items():
        s=a*scale/tau; b=offsets[k]/tau
        rows += [np.c_[s,-np.ones(89)],np.c_[-s,-np.ones(89)]]; vals += [-b,b]
    if around is not None:
        trust=2.5e-8; Jshape=B*scale/trust; anchor=B@around/trust
        rows += [np.c_[Jshape,np.zeros(len(S))],np.c_[-Jshape,np.zeros(len(S))]]; vals += [1+anchor,1-anchor]
    s=linprog(np.r_[np.zeros(88),1.],np.vstack(rows),np.concatenate(vals),Aeq,rhs,method='highs',
              bounds=[(-4,4)]*83+[(-30,30)]*4+[(0,3),(0,None)])
    if not s.success: return None,s.message
    return s.x[:88]*scale,s.fun*tau


def evaluate(d,derivative=False):
    action,slope,skip,reg=m['local_response'](d,derivative)
    R={name:matrix.copy() for name,matrix in Jrest.items()}; by={(p+1,n-1):(reason) for p,n,reason in skip}
    if skip:
        for si,ip,b,kt,kc,sign,Cs,Cr in m['fitted']:
            if (si,ip) not in by: continue
            PR=P[:,si,ip,:]*sign
            R['H45Stock']+=PR@Cs@D[si,ip]
            R['H45Refined']+=PR@Cr@D[si,ip]
    actual={name:r+action+matrix@d for name,matrix in R.items()}
    tangents={name:v+slope for name,v in R.items()}
    return actual,tangents,{'skipped':skip,'supportedRegimes':reg,'signedApexActionMaxMPa':pk(action),
                           'signedApexActionRow81MPa':float(action[80])}


def detail(d):
    expected,_,st=evaluate(d); linear={name:r+op@d for name,op in J.items()}
    return {'field':(q0+d).tolist(),'delta':d.tolist(),'Qy_N':float((q0[-1]+d[-1])*1e5),
            'DGamma':float(kappa@d),'gamma':float(Q[1]+kappa@d),'strainStep':pk(B@d),'fiveCompatibilityMPa':np.r_[(K@d+compat)[:4],K[4]@d-25600*(kappa@d)].tolist(),
            'rawLinearNorms':{k:pk(y) for k,y in linear.items()},'apexFiniteNorms':{k:pk(y) for k,y in expected.items()},
            'apexFiniteKeyRows':{k:y[[69,79,80,82,88]].tolist() for k,y in expected.items()},'apexFiniteMaxRow':{k:int(np.argmax(abs(y))+1) for k,y in expected.items()},
            **st}

raw,raw_min=linear_solve(J,{k:r for k in J}); assert raw is not None
record={'freshCommonMinimumMPa':raw_min,'freshCandidate':detail(raw),'iterations':[]}
d=raw.copy()
print('raw',raw_min,record['freshCandidate']['apexFiniteNorms'],record['freshCandidate']['DGamma'],len(record['freshCandidate']['skipped']),flush=True)
for i in range(3):
    f,G,extra=evaluate(d,True); best=max(map(pk,f.values())); residual={k:f[k]-G[k]@d for k in G}
    proposal,tangent_norm=linear_solve(G,residual,around=d)
    if proposal is None: break
    best_new=best; chosen=None; log=[]
    for fraction in (1.,.5,.25):
        a=d+fraction*(proposal-d); y,_,props=evaluate(a); v=max(map(pk,y.values())); log.append([fraction,v,len(props['skipped'])]);
        if v<best_new:
            chosen=a; best_new=v
    print('nlin',i,tangent_norm,log,flush=True)
    if chosen is None: break
    d=chosen; record['iterations'].append({'conditionalLinearMinMPa':tangent_norm,'candidateComparison':log,'fieldResult':detail(d)})
record['last']=detail(d)

# No fit to withheld H44 probe values. This comparison measures model transport mismatch
# and includes real changes of material history. It is not an error bar for the H45 field.
Q44,_,T44=m['record'](rr,'BaseAccepted'); f44=np.r_[Q44[2:],Q44[0]]; st44=T44[:,:,6:]
withheld={}
for tag in ('LoadShape18Plus','LoadShape18Minus','PriorSecant50Plus','TangentContrast50Plus'):
    ff,_,samp=m['record'](rr,tag); z=np.r_[ff[2:],ff[0]]-f44
    actual=m['Pe']@(samp[:,:,6:]-st44).ravel()+m['gauge']@z[83:87]+m['load']*z[-1]
    corrected,_,props=evaluate(z); qd={key:corrected[key]-r for key in corrected}
    sim=float((B@z)@(B@d)/np.linalg.norm(B@z)/np.linalg.norm(B@d))
    withheld[tag]={'cosineToNewFieldStationIncrement':sim,'correctedH45TransferMismatchMPa':{k:pk(v-actual) for k,v in qd.items()},
           'rawH45TransferMismatchMPa':{k:pk(J[k]@z-actual) for k in J},'actualH44ActionPeakMPa':pk(actual),
           'unsupportedExactReplacement':len(props['skipped'])}
report={'basis':'Exact committed H45 station strains and stresses; 89 equations plus 4 gauges; forward γ from candidate',
        'nativeInputSHA256':{name:m['digest'](m['ART']/path) for name,(path,_) in m['FILES'].items()},
        'freshAnchorMPa':pk(r),'toleranceMPa':float(tau),'QyIncrementN':increment,'stationRadius':cap,
        'freshAdjointN':E['adjointUncertainty_N']['FromHistory45'],'screenedStations':len(m['screen']),'stencilReconstructedStations':len(m['fitted']),
        'withheldH44SameDirectionTransport':withheld, 'comparisons':record,
        'nativeTrialRecommended':False, 'scope':'Shape proposals are conditional. Frozen exact apex replacement does not verify the remaining station material tangents.'}
out=HERE/'H45Plus18Diagnostic.json'; out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(out,sha256(out.read_bytes()).hexdigest().upper(),report['comparisons']['last']['apexFiniteNorms'])
