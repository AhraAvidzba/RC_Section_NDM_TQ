"""Select a single non-collinear, fixed-load measurement at the real +18 N scale."""
from pathlib import Path
from hashlib import sha256
import json,runpy
import numpy as np
from scipy.optimize import linprog

H=Path(__file__).resolve().parent
s=runpy.run_path(H/'Solve-H45Plus18.py'); m=s['m']; pk=m['pk']; B=m['shape']; K=m['K']; q0=m['q0']; r=m['r']; J=m['J']; Q=m['Q']
old=m['S']; _,_,one=m['record'](old,'BaseAccepted'); q44,_,_=m['record'](old,'BaseAccepted'); q18,_,_=m['record'](old,'LoadShape18Plus')
z=np.r_[q18[2:]-q44[2:],18/1e5]; under=B@z
assert 4.6e-8<pk(under)<4.9e-8
remaining,Qm,branch=s['evaluate'](z,True)
assert not branch['skipped'] and all(int(np.argmax(abs(p))+1)==81 for p in remaining.values())
stationCap=2e-9; columns=np.r_[np.full(83,stationCap),np.zeros(5)]
# q/gamma, four constraints and the four pure gauge coordinates are unchanged. Physical direction
# is orthogonal to the previously measured incremental station tensor under a Euclidean metric.
geometry=np.vstack((K[:,:83],(under@B[:,:83])[None]))*stationCap
nn=np.max(abs(geometry),axis=1); geometry/=nn[:,None]
S=B[:,:83]*stationCap/stationCap
upper=[np.c_[S,np.zeros(len(S))],np.c_[-S,np.zeros(len(S))]]; rhs=[np.ones(len(S)),np.ones(len(S))]
tau=A=t=float(m['tau']); eq=np.c_[geometry,np.zeros(len(geometry))]
for name,M in Qm.items():
    op=M[:,:83]*stationCap/tau; v=remaining[name]/tau
    upper.extend((np.c_[op,-np.ones(89)],np.c_[-op,-np.ones(89)])); rhs.extend((-v,v))
opt=linprog(np.r_[np.zeros(83),1.],np.vstack(upper),np.concatenate(rhs),eq,np.zeros(len(geometry)),method='highs',bounds=[(-8,8)]*83+[(0,None)])
assert opt.success
v=np.r_[opt.x[:83]*stationCap,np.zeros(5)]; assert pk(K@v)<2e-15 and pk(B@v)<=stationCap*1.00000001
cos=float((B@v)@under/np.linalg.norm(B@v)/np.linalg.norm(under)); assert abs(cos)<1e-12

save={}; tol=float(m['tau']); peakRow=80
q0csv=m['from_zip']('H45','History45Verified.csv').decode('ascii').strip().split(';'); base_exact=np.r_[list(map(float,q0csv[4:-1])),float(q0csv[-1])]
assert np.max(abs(base_exact[:-1]-q0[:-1]))<3e-16 and abs(base_exact[-1]-q0[-1])<1e-14
lam=base_exact[-1]+18./1e5; gamma=float(q0csv[3])+float(K[4]@z/25600)
rows=[]; center,_,centerdetail=s['evaluate'](z)
for name,d in [('Plus18Center',z),('Plus18TargetMinus',z-v),('Plus18TargetPlus',z+v)]:
    u=base_exact+d; corrected,_,det=s['evaluate'](d)
    assert len(det['skipped'])==0 and abs(u[-1]-lam)<1e-14
    assert pk(K[:4]@d)<3e-12 and abs(K[4]@d/25600+float(q0csv[3])-gamma)<2e-16
    txt=';'.join(['KANI_B_FIELD',name,'1',format(gamma,'.17g'),*[format(q,'.17g') for q in u[:87]],format(lam,'.17g')]); assert len(txt.split(';'))==92
    rows.append(txt)
    save[name]={'apexHybrid':{k:{'normMPa':pk(y),'largestRow':int(np.argmax(abs(y))+1),'row81MPa':float(y[peakRow]),
                         'row81RelativeToCenter_MPa':float(y[peakRow]-center[k][peakRow]),'actionsAll89FromCenter_MPa':(y-center[k]).tolist()} for k,y in corrected.items()},
                'freshRaw':{k:{'norm_MPa':pk(r+j@d),'row81_MPa':float((r+j@d)[peakRow])} for k,j in J.items()},
                'field':u.tolist(),'strainMaximumFromAccepted':pk(B@d),'stationBranchCounts':det['supportedRegimes']}
assert max(x['normMPa'] for x in save['Plus18TargetPlus']['apexHybrid'].values())<max(x['normMPa'] for x in save['Plus18Center']['apexHybrid'].values())
expected_min=min(abs(save[name]['apexHybrid']['H45Stock']['row81RelativeToCenter_MPa']) for name in ('Plus18TargetPlus','Plus18TargetMinus'))
assert expected_min>2e-5
path=H/'H45Plus18DirectionalFields.csv'; path.write_bytes(('\r\n'.join(rows)+'\r\n').encode('ascii'))
reason={'sampledFields':3,'fixedQyN':float(lam*1e5),'fixedPositiveGamma':gamma,'acceptedBaselineQyN':float(base_exact[-1]*1e5),
 'acceptedBaselineGamma':float(q0csv[3]),'stencilNorm':pk(B@v),'stencilPhysicalCosineToPriorMeasuredLoadShape':cos,
 'expectedMinDirectionalRow81Signal_MPa':expected_min,'allUnchangedGaugeCoordinates':True,
 'precisionAtDistinctLoadN':float(m['E']['adjointUncertainty_N']['FromHistory45']),
 'recommendedUse':'Raw native measurement only, all trials from exact H45; do not commit without original tolerance and station guards.',
 'freshNativeDataNeeded':['Baseline H45 before/after, original energies and exact field',
    'Center and signed fields: 552 strain/stress tensors, branch/plastic/sign/substep and predictor per station',
    'Both stock and refined tangent at center field; record ordinary fallback if branch tangent unavailable',
    'Independent 89/5 equilibrium criteria, exact control, fixed signed Qy and zero history promotion'],
 'conditionalModel':save, 'fixtureSHA256':sha256(path.read_bytes()).hexdigest().upper()}
out=H/'H45Plus18DirectionalPlan.json'; out.write_text(json.dumps(reason,indent=2)+'\n',encoding='utf8')
print(path,reason['fixtureSHA256'],out,sha256(out.read_bytes()).hexdigest().upper(),
      reason['fixedQyN'],reason['fixedPositiveGamma'],expected_min)
for name,y in save.items():
    v=y['apexHybrid']['H45Stock']; print(name, v['normMPa'],v['largestRow'],v['row81MPa'],y['strainMaximumFromAccepted'],y['stationBranchCounts'])
