"""Isolate the maximal archived HardShear zero-increment drift in one material."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
FROZEN={
    'HardShearSameSectionASDCoarsePilot20261117.zip':('67DE39B8362615DC3045BF8F0DF18D9859B75478EA8386F8751C4E2B78CAB904',
                                                   'CoarsePilot.json.gz','6AF40BA9D209A244C376449470DB5055328005105D1B0E9075F43F4A1FD9607D'),
    'HardShearSameSectionASDCoarseFollow20261117.zip':('F89FFBD0F47E05CBAC62CDF07F3318BC4AFB4DEDB86366FFEA9E70B93FCFFA50',
                                                    'CoarseFollowDetailed.json.gz','5220D142B5A0EA8F87DDA0E358AC46320B76E20EC0C02B360B6A01F8133F39AF'),
}


def sha(b):
    return sha256(b).hexdigest().upper()


def fixture(repo):
    prefix=[]
    compiled=None
    for name,(seal,leaf,digest) in FROZEN.items():
        path=repo/'docs/regression/Coupled6D'/name
        assert sha(path.read_bytes())==seal
        with ZipFile(path) as z:
            raw=z.read(leaf); compiled=z.read('HardShearSameSection.py')
        assert sha(raw)==digest
        info=json.loads(gzip.decompress(raw)); prefix.extend(info['accepted_targets'])
    source={'__name__':'_frozen','__file__':str(HERE/'HardShearSameSection.py')}
    exec(compile(compiled,source['__file__'],'exec'),source)
    assert [r['lambda'] for r in prefix]==[.03125,.0625,.125,.25,.375,.5,.625,.75,.875]
    op_identity=info['identity']['exact_built_operator_sha256']
    return prefix,info['material_command'],op_identity,source


def original_point(last):
    a=last['net_stress_MPa']; b=last['post_commit_new_zero_increment']['net_stress_MPa']
    tag=max(((i,j,k) for i in range(3) for j in range(43) for k in range(6)),key=lambda p:abs(b[p[0]][p[1]][p[2]]-a[p[0]][p[1]][p[2]]))
    assert tag==(1,2,2)
    return tag


def native(ops,field):
    a,b,c,d,e,f=field
    wire=(a,b,c,d,f,e)
    ops.NDTest('SetStrain',1,*wire)
    assert tuple(ops.NDTest('GetStrain',1))==wire
    return stress(ops)


def stress(ops):
    a,b,c,d,f,e=ops.NDTest('GetStress',1)
    return [a,b,c,d,e,f]


def measure(ops):
    return {key:list(ops.NDTest('GetResponse',1,key)) for key in ('equivalentTotalStrain','equivalentPlasticStrain','damage')}


def run(repo,out):
    began=perf_counter()
    sys.path.insert(0,'D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython')
    import numpy as np
    import openseespy.opensees as ops
    assert np.__version__=='2.3.5' and ops.version()=='3.8.0'
    chain,command,op_id,source=fixture(repo)
    geometry,_,area,length,_,_=source['fixture'](repo)
    op=source['operators'](geometry,area,length)
    assert source['sha'](source['packed'](op))==op_id
    b=np.array(op['B']); z=np.array(op['Z']); h=source['HALF']
    assembly=np.stack((b,b+h*z,b-h*z))
    side,point,component=original_point(chain[-1])
    ops.wipe(); ops.model('basic','-ndm',3,'-ndf',3)
    ops.nDMaterial(command[0],1,*command[1:]); entries=[]
    for step in chain:
        strain=(assembly@np.array(step['field']))[side,point]
        value=native(ops,strain)
        assert value==step['net_stress_MPa'][side][point]
        ops.NDTest('CommitState',1)
        assert stress(ops)==value
        entries.append({'lambda_label_only':step['lambda'],'prescribed_engineering_strain':strain.tolist(),
                        'computed_point_stress_MPa':value,'immediate_committed_getter_equal':True})
    before=measure(ops); last=entries[-1]
    assert stress(ops)==last['computed_point_stress_MPa']
    trial=native(ops,np.asarray(last['prescribed_engineering_strain']))
    after=measure(ops)
    assert trial==chain[-1]['post_commit_new_zero_increment']['net_stress_MPa'][side][point]
    ops.wipe()
    diff=[b-a for a,b in zip(last['computed_point_stress_MPa'],trial,strict=True)]
    result={'material_point_count':1,'section_solver_calls':0,'tag':1,'shape_operator_sha256':op_id,
            'source_inputs':FROZEN,'component_order':['xx','yy','zz','xy','xz','yz'],'point_in_archived_geometry':point+1,
            'axial_station':(0,1,-1)[side],'geometry_x_y_weight':geometry[point],
            'component_of_maximum_drift':component+1,'replayed_accepted_tensor_history':entries,
            'discarded_zero_increment':{'new_trial_stress_MPa':trial,'stress_delta_MPa':diff,
                                         'committed':False,'same_prescribed_tensor':True},
            'material_reported_indicators_immediate_after_commit':before,'material_reported_indicators_new_trial':after,
            'exact_archived_zero_drift_reproduced':True,'engine_version':ops.version()}
    raw=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    with out.open('xb') as f: f.write(raw)
    print('HARDSHEAR_ONE_ASD_MATERIAL_EXACT_PASS',sha(raw),diff[component],perf_counter()-began)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--out',type=Path,default=HERE/'ASDOnePoint.json')
    options=parser.parse_args(); run(options.repo.resolve(),options.out)
