"""Recheck the isolated ASD material against the pinned section response."""
from argparse import ArgumentParser
from hashlib import sha256
from math import fsum
from pathlib import Path
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WIRE='D4E9F63CF3E0919D63DB50AA317BF338D83FE86E7B850A03D9302403B5C14017'


def sha(b):
    return sha256(b).hexdigest().upper()


def main(repo):
    trial=runpy.run_path(str(HERE/'Replay-ASDOnePoint.py'))
    raw=(HERE/'ASDOnePoint.json').read_bytes(); assert sha(raw)==WIRE
    report=json.loads(raw)
    chain,_,op_hash,s=trial['fixture'](repo)
    geo,_,area,length,_,_=s['fixture'](repo); op=s['operators'](geo,area,length)
    assert sha(s['packed'](op))==op_hash==report['shape_operator_sha256']
    i,j,k=trial['original_point'](chain[-1]); side=(0,1,-1)[i]
    assert (report['axial_station'],report['point_in_archived_geometry'],report['component_of_maximum_drift'])==(side,j+1,k+1)
    assert report['geometry_x_y_weight']==list(geo[j])
    assert report['material_point_count']==1 and report['tag']==1 and report['section_solver_calls']==0
    assert report['exact_archived_zero_drift_reproduced'] and report['engine_version']=='3.8.0'
    records=report['replayed_accepted_tensor_history']
    assert len(records)==len(chain)==9
    errors=[]
    for e,step in zip(records,chain,strict=True):
        assert e['lambda_label_only']==step['lambda'] and e['immediate_committed_getter_equal']
        strain=[fsum((a+side*s['HALF']*b)*v for a,b,v in zip(B,Z,step['field'],strict=True))
                for B,Z in zip(op['B'][j],op['Z'][j],strict=True)]
        errors.extend(abs(a-b) for a,b in zip(strain,e['prescribed_engineering_strain'],strict=True))
        assert e['computed_point_stress_MPa']==step['net_stress_MPa'][i][j]
    assert max(errors)<2e-18
    old=records[-1]['computed_point_stress_MPa']; check=report['discarded_zero_increment']
    new=check['new_trial_stress_MPa']; assert check['same_prescribed_tensor'] and not check['committed']
    assert new==chain[-1]['post_commit_new_zero_increment']['net_stress_MPa'][i][j]
    assert check['stress_delta_MPa']==[b-a for a,b in zip(old,new,strict=True)]
    assert check['stress_delta_MPa'][k]==-0.029324125622928854
    before=report['material_reported_indicators_immediate_after_commit']; after=report['material_reported_indicators_new_trial']
    assert all(right[0]>left[0] and right[1]==left[1] for left,right in zip(before.values(),after.values(),strict=True))
    return {'status':'PASS','starting_archive_exact_sha256':WIRE,'isolated_point':[j+1,side,k+1],
            'material_runtime':'OpenSees 3.8.0','max_reconstructed_shape_delta':max(errors),
            'old_and_new_sigma_zz_MPa':[old[k],new[k]], 'uncommitted_delta_sigma_zz_MPa':new[k]-old[k],
            'material_measures_immediately_committed':before,'material_measures_at_discarded_trial':after,
            'solver_calls':0,'tensors_replayed':9}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd()); p.add_argument('--report',type=Path)
    args=p.parse_args(); report=main(args.repo)
    out=(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if args.report:
        with args.report.open('xb') as f: f.write(out)
    print('HARDSHEAR_ONE_ASD_MATERIAL_OFFLINE_PASS',sha(out),report['uncommitted_delta_sigma_zz_MPa'])
