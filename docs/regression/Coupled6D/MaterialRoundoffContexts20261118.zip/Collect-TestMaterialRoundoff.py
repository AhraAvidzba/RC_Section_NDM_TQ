"""ДЛЯ ТЕСТОВ: закрепляет причины материальных отказов, неуспешные варианты и окончательный VBA."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


TestCases={
    'CompileFailure':'ControlFailureProbe20261118',
    'OriginalProbes':'ControlFailureProbe0220261118',
    'AlternativeControls':'ResolvedControlContinuation20261118',
    'RoundoffProbes':'RoundoffControlContinuation20261118',
    'Final':'MaterialRoundoffFinal20261118',
    'ExactBaseline':'MaterialRoundoffBaseline20261118',
}


def TestCopy(source,target):
    """Копирует доказательства без перезаписи и изменения кодировки."""
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream: stream.write(source.read_bytes())


def TestCollect(repo,root):
    """Сохраняет источники и VBA всех попыток; большие неизменённые XLSM восстанавливаются из закреплённого источника."""
    root.mkdir()
    scratch=Path('D:/CodexScratch/RC_Section_NDM_TQ')
    for name,directory in TestCases.items():
        source=scratch/directory; target=root/'Cases'/name
        prep=json.loads((source/'Preparation.json').read_bytes())
        for relative,expected in prep['inputs'].items():
            assert sha256((source/relative).read_bytes()).hexdigest().upper()==expected,(name,relative)
        for file in source.rglob('*'):
            if not file.is_file(): continue
            relative=file.relative_to(source)
            if relative.parts[0] in ('Temp','workbook') or file.suffix.lower()=='.xlsm': continue
            TestCopy(file,target/relative)
        if name!='CompileFailure':
            with ZipFile(source/'docs/regression/Diagnostic.xlsm') as book: binary=book.read('xl/vbaProject.bin')
            (target/'CompiledVBA.bin').write_bytes(binary)
            (target/'CompiledVBA.json').write_bytes((json.dumps({'bytes':len(binary),'sha256':sha256(binary).hexdigest().upper()},indent=2)+'\n').encode())
        if name=='Final':
            # Сохранённый Results доказывается отдельно от исходного и конечного VBA.
            import re
            log=(source/'Native/Stock.txt').read_text('utf-8-sig')
            saved,=re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$',log,re.M)
            assert Path(saved).resolve().is_relative_to((source/'Temp').resolve())
            with ZipFile(saved) as book,ZipFile(target/'SavedWorkbookXML.zip','x',8,compresslevel=9) as out:
                for relative in sorted(book.namelist()):
                    if relative!='xl/vbaProject.bin': out.writestr(relative,book.read(relative))
    here=Path(__file__).resolve().parent
    for name in ('Collect-TestMaterialRoundoff.py','Check-TestMaterialRoundoff.py','Analyze-TestFailureContexts.py',
                 'Finalize-TestMaterialRoundoff.py','Stage-TestMaterialRoundoffBaseline.py','Inspect-TestResolutionVBA.py',
                 'Verify-TestReducedEvidence.py','Verify-TestASDResolution.py','TestResolutionSection.py',
                 'Probe-TestASDMaterialSteps.py','TestClosedASDTangent.py','Probe-TestASDClosure.py'):
        TestCopy(here/name,root/name)
    TestCopy(scratch/'WorkingForceSubspaceEvidence20261118/SourceBook.json',root/'SourceBook.json')
    (root/'Cases.json').write_bytes((json.dumps(list(TestCases),indent=2)+'\n').encode())
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper() for file in root.rglob('*') if file.is_file()}
    (root/'Files.json').write_bytes((json.dumps(files,indent=2,sort_keys=True)+'\n').encode())
    print('MATERIAL ROUNDOFF EVIDENCE COLLECTED',len(files))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestCollect(args.repo.resolve(),args.root.resolve())
