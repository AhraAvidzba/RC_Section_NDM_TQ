"""ДЛЯ ТЕСТОВ: оставляет диагностику принятой истории, исключая не подтвердивший пользу подбор меры."""
from pathlib import Path
from subprocess import check_output


def TestFinalize(repo):
    """Восстанавливает неизменённый алгоритм из HEAD; собственные попытки сохранены в частных книгах."""
    relative='src/Solver/CCoupledNewtonSolver.cls'
    raw=check_output(['git','show','HEAD:'+relative],cwd=repo)
    (repo/relative).write_bytes(raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))
    relative='src/Solver/CCoupledDeformationContinuation.cls'
    original=check_output(['git','show','HEAD:'+relative],cwd=repo).decode('utf-8-sig')
    current=(repo/relative).read_text('utf-8-sig')
    start=current.index("' Возвращает независимую числовую копию принятого пути;")
    end=current.index("' Один раз выбирает другую меру,",start)
    getter=current[start:end]
    old='Private mTrace As CCoupledLoadTrace, mLimitTrace As CCoupledLoadTrace'
    assert original.count(old)==1
    original=original.replace(old,old+'\nPrivate mCurrentFields As Collection \' Принятый путь для воспроизводимой диагностики незавершённого поиска.')
    old='    Set mTrace = Nothing: Set mLimitTrace = Nothing'
    assert original.count(old)==1
    original=original.replace(old,old+'\n    Set mCurrentFields = Nothing')
    old='    mDesignHistoryIndex = InitialDesignHistoryIndex(history.Count, previousLambda, currentLambda)'
    assert original.count(old)==1
    original=original.replace(old,'    Set mCurrentFields = history\n'+old)
    old='    Set history = mLimitFields'
    assert original.count(old)==1
    original=original.replace(old,old+'\n    Set mCurrentFields = history')
    marker="' Один раз выбирает другую меру,"
    assert original.count(marker)==1
    original=original.replace(marker,getter+marker)
    (repo/relative).write_bytes(original.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))


if __name__=='__main__':
    TestFinalize(Path.cwd())
