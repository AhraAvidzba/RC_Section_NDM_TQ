"""ДЛЯ ТЕСТОВ: готовит отрицательный контроль пяти контекстов с точным исходным сравнением Double."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStageBaseline(repo,root):
    """Меняет только материальный компонент чистой ещё не компилированной частной копии."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingASD.py'))['TestStage'](repo,root)
    original=Path('D:/CodexScratch/RC_Section_NDM_TQ/ControlFailureProbe0220261118')
    relative='src/Materials/CCoupledConcreteResponse.cls'
    pin=json.loads((original/'Preparation.json').read_bytes())['inputs'][relative]
    raw=(original/relative).read_bytes()
    assert sha256(raw).hexdigest().upper()==pin
    assert b'PLASTIC_ROUNDOFF' not in raw
    assert b'updated.Plastic(i) <> committed.Plastic(i)' in raw
    (root/relative).write_bytes(raw)
    prep=json.loads((root/'Preparation.json').read_bytes())
    prep['inputs'][relative]=pin
    prep['negative_control']='Original exact comparison, five captured contexts, identical 74-field input history'
    prep['inputs'][Path(__file__).name]=sha256(Path(__file__).read_bytes()).hexdigest().upper()
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('EXACT COMPARISON BASELINE READY',pin)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestStageBaseline(args.repo.resolve(),args.root.resolve())
