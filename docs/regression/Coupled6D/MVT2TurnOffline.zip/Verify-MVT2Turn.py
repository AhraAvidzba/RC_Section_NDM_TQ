"""Apply independent field, force, lineage and sign checks to the controlled MVT2 window."""

import argparse
from collections import defaultdict
import csv
from hashlib import sha256
import json
import math
from pathlib import Path


ROOT=Path(__file__).resolve().parent
NATIVE=ROOT/'Native'
SOURCE=NATIVE/'MVT2.csv'
AREA=240.0**2
LENGTH=math.hypot(110.0,110.0)
TORQUE=10510000.0
MODULUS=30000.0


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def table(path, timed_out=False):
    raw=path.read_bytes()
    lines=raw.decode('cp1251').splitlines()
    if not raw.endswith((b'\r',b'\n')):
        assert timed_out
        lines.pop()
    tags=defaultdict(list)
    for cells in csv.reader(lines,delimiter=';'):
        if cells:
            tags[cells[0]].append(cells[1:])
    return tags


def distance(a,b):
    return max(abs(x-y) for x,y in zip(a,b,strict=True))


def near(a,b,tolerance=1e-11):
    assert abs(a-b)<=tolerance,(a,b,tolerance)


def fields(tags):
    output={}
    for name,*values in tags['MVT2_CONTROL_FIELD']:
        assert name not in output
        state=tuple(map(float,values))
        assert len(state)==60 and all(map(math.isfinite,state))
        output[name]=state
    return output


def owner_check(prep, offline=False):
    native=NATIVE/'MVT2.txt'
    record=read_json(NATIVE/'RunReceipt.json')
    closure=read_json(NATIVE/'MVT2.txt.ProcessClosure.json')
    owner=read_json(NATIVE/'MVT2.txt.Ownership.json')
    compiled=read_json(ROOT/'docs/regression/CodeUpdate.json')
    compiled_book=compiled['WorkbookSHA256'] if offline else sha(ROOT/'docs/regression/Diagnostic.xlsm')
    assert compiled['Compiled'] and compiled['Modules']==[prep['only_updated_module']] and not compiled['ProductionChanged']
    assert compiled['ProductionSHA256']==prep['book_sha256'] and compiled['WorkbookSHA256']==compiled_book
    assert read_json(ROOT/'CompileClosure.json')['State']=='Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==compiled_book
    timed_out=closure['Stage']=='TIMEOUT'
    if timed_out:
        assert record['native_exit']!=0 and not closure['ChildStopError'] and not closure['ExcelStopError']
        stopped=closure['After']
    else:
        assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['ChildHasExited']
        assert closure['ChildExitCode']==record['native_exit']==0
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in native.read_text(encoding='utf-8-sig')
        stopped=closure['Closure']['FinalState']
    assert stopped['State']=='Absent' and [stopped['PID'],stopped['StartTicksUTC']]==[owner['PID'],owner['StartTicksUTC']]
    return timed_out,stopped,record


def same_prefix(actual, baseline, full=True):
    old=baseline['WANG_PAIR_STATUS']
    new=actual['WANG_PAIR_STATUS']
    assert len(new)<=len(old)==5
    for a,b in zip(new,old):
        assert a[:10]==b[:10]
    if full:
        assert len(new)==5
    return len(new)


def tolerance(initial):
    return 5e-7*(1+max(TORQUE/(AREA*LENGTH),6e5*abs(initial)/(AREA*LENGTH),abs(initial)*1000/AREA))


def wrench_error(lam, forces):
    demand=(0,6e5*lam,0,TORQUE,0,1000*lam)
    return max(abs(a-b)/(AREA*(LENGTH if 0<i<4 else 1)) for i,(a,b) in enumerate(zip(forces,demand,strict=True)))


def adjacent(left,right):
    change=right['q_kN']-left['q_kN']
    bound=right['adjoint_uncertainty_kN']+left['adjoint_uncertainty_kN']
    sign='rising' if change>bound else 'falling' if change < -bound else 'unresolved'
    return {'left_attempt':left['attempt'],'right_attempt':right['attempt'],'change_kN':change,'combined_linear_uncertainty_kN':bound,'sign':sign}


def refine(tags, baseline, coarse, packed, partial):
    old_packed=fields(baseline)
    force_count,=[int(line[0]) for line in tags['MVT2_TURN_HISTORY']]
    assert force_count==50
    force=[packed[f'Force{i}'] for i in range(1,force_count+1)]
    assert force[-2:]==[packed['Prior'],packed['Base']]
    assert all(distance(a,b)<1e-12 for a,b in zip((packed['Prior'],packed['Base'],packed['Projection']),
                                                  (old_packed[name] for name in ('Prior','Base','Projection')),strict=True))
    for x,y in zip(coarse,baseline['MVT2_CONTROL_ACCEPT']):
        assert x[0]==y[0]
        near(float(x[1]),float(y[1]),1e-9)
        near(float(x[2]),float(y[2]),1e-14)
        assert distance(packed[x[0]],old_packed[y[0]])<1e-10
    assert len(coarse)<=5
    if not partial:
        assert len(coarse)==5
    projection=packed['Projection'][:-4]
    previous,current=(row[:-4] for row in force[-2:])
    left,right,coord,current_increment=map(float,tags['MVT2_CONTROL_START'][0][:4])
    near(math.fsum(x*y for x,y in zip(projection,current,strict=True)),coord,1e-14)
    minimum=current_increment/64
    goals=[float(row[1]) for row in tags['MVT2_TURN_GOAL']]
    if goals:
        assert len(coarse)==5 and len(goals)==10
        p,q,r,s,t=(float(row[2]) for row in coarse)
        expected=[p,(p+q)/2,q,(q+r)/2,r,s,(s+t)/2,t,t+(t-s)/2,t+(t-s)]
        assert distance(goals,expected)<1e-14
    turn={int(name):row for name,*row in tags['MVT2_TURN_ACCEPT']}
    accepted=[]
    index=0
    next_target=goals[0] if goals else None
    for n,probe in enumerate(tags['MVT2_TURN_PROBE'],1):
        expect,goal=map(int,probe[:2]); target,increment,initial,lam=map(float,probe[2:6]); status=probe[6]
        assert expect==n and index==goal-1 and n<=24
        near(target,next_target,1e-14);near(increment,target-coord,1e-14)
        ratio=increment/current_increment
        near(initial,right+ratio*(right-left),1e-9)
        if status!='Accepted':
            assert n not in turn and status in ('SolverRejected','ForwardRejected','AdjointUnavailable')
            next_target=coord+increment/2
            continue
        if n not in turn or f'Turn{n}' not in packed:
            assert partial and n==len(tags['MVT2_TURN_PROBE'])
            break
        goal_record,exact=map(int,turn[n][:2]);data=list(map(float,turn[n][2:]))
        coord_new,q_kN,bound,limit,weak,gauge,wrench,control,steel,*forces=data
        assert goal_record==goal and lam>0 and 0<=steel<=1 and math.isfinite(bound) and bound>2e-12*(1+lam)
        near(coord_new,target,1e-14);near(q_kN,lam,1e-9)
        near(limit,tolerance(initial),1e-13);near(wrench,wrench_error(lam,forces),1e-12)
        assert max(weak,gauge,wrench,control)<=limit+1e-12
        candidate=packed[f'Turn{n}'][:-4]
        near(control,MODULUS*abs(math.fsum(x*y for x,y in zip(projection,candidate,strict=True))-target),1e-10)
        a=[y-x for x,y in zip(previous,current,strict=True)];b=[y-x for x,y in zip(current,candidate,strict=True)]
        cosine=math.fsum(x*y for x,y in zip(a,b,strict=True))/math.hypot(*a)/math.hypot(*b)
        assert cosine>0 and math.hypot(*b)<=3*ratio*math.hypot(*a)*(1+1e-8)
        assert abs(lam-right) <= 3*ratio*max(abs(right-left),.01)*(1+1e-8)
        assert bool(exact)==(abs(target-goals[index])<1e-14)
        accepted.append({'attempt':n,'target':goal,'exact':bool(exact),'coordinate':target,'q_kN':lam,
                         'adjoint_uncertainty_kN':bound,'q_interval_linear_kN':[lam-bound,lam+bound],
                         'wrench_N_Nmm':forces,'steel_strain_utilization':steel,'forward_cosine':cosine,
                         'weak_gauge_wrench_control_MPa':[weak,gauge,wrench,control],'tolerance_MPa':limit})
        previous,current=current,candidate
        left,right=right,lam
        coord,current_increment=target,increment
        index+=exact
        if index<len(goals):
            next_target=goals[index]
    if not partial:
        outcome,count,probes,final,last_q=tags['MVT2_TURN_STOP'][0]
        assert outcome in ('WindowComplete','MinimumIncrement','AttemptLimit')
        assert int(count)==len(accepted) and int(probes)==len(tags['MVT2_TURN_PROBE'])
        near(float(final),coord,1e-14);near(float(last_q),right,1e-9)
        assert (outcome=='WindowComplete')==(index==len(goals)==10)
    return accepted


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--offline',action='store_true',help='check the recorded workbook hashes rather than opening the omitted XLSM')
    options=parser.parse_args()
    prep=read_json(ROOT/'Preparation.json')
    partial,owner,native_run=owner_check(prep,options.offline)
    old_source=ROOT/'Offline/Native/MVT2.csv'
    assert sha(old_source)==prep['archive_inputs']['Native/MVT2.csv']
    tags=table(SOURCE,partial)
    baseline=table(old_source)
    count=same_prefix(tags,baseline,not partial)
    coarse=tags['MVT2_CONTROL_ACCEPT']
    result={'status':'VerifiedPartialTimeout' if partial else 'VerifiedDirected',
            'native_run':native_run,'owner_closed':owner,'trace_sha256':sha(SOURCE),'baseline_trace_sha256':sha(old_source),
            'matched_force_route_stages':count,'original_control_matches':len(coarse),'complete_turn_targets':0,'physical_capacity_claimed':False}
    if tags['MVT2_TURN_HISTORY']:
        packed=fields(tags)
        if all(name in packed for name in ('Prior','Base','Projection')):
            accepted=refine(tags,baseline,coarse,packed,partial)
        else:
            assert partial and not tags['MVT2_TURN_PROBE']
            accepted=[]
        differences=[adjacent(a,b) for a,b in zip(accepted,accepted[1:])]
        peak=max(accepted,key=lambda row:row['q_kN']) if accepted else None
        edges={row['target']:row for row in accepted if row['exact']}
        shoulder_window=[]
        if peak and 1 in edges and 5 in edges and edges[1]['coordinate']<peak['coordinate']<edges[5]['coordinate']:
            shoulder_window=[adjacent(edges[1],peak),adjacent(peak,edges[5])]
        resolvable_bracket=[]
        if peak:
            location=accepted.index(peak)
            left=next((comparison for row in reversed(accepted[:location])
                       if (comparison:=adjacent(row,peak))['sign']=='rising'),None)
            right=next((comparison for row in accepted[location+1:]
                        if (comparison:=adjacent(peak,row))['sign']=='falling'),None)
            if left and right:
                resolvable_bracket=[left,right]
        result.update(accepted=accepted,accepted_force_fields=50,differences=differences,
                      complete_turn_targets=sum(bool(row['exact']) for row in accepted),
                      discrete_peak=peak,refined_left_and_right_shoulders=shoulder_window,nearest_resolved_bracket=resolvable_bracket,
                      locally_resolved_turns=[accepted[i+1]['attempt'] for i,(left,right) in enumerate(zip(differences,differences[1:]))
                                              if left['sign']=='rising' and right['sign']=='falling'],
                      resolved_later_growth=[item for item in differences if peak and item['left_attempt']>=peak['attempt'] and item['sign']=='rising'],
                      left_anchor_match_kN=(accepted[0]['q_kN']-float(coarse[0][1]) if accepted and accepted[0]['exact'] else None),
                      left_anchor_field_difference=(distance(packed[f"Turn{accepted[0]['attempt']}"],packed[coarse[0][0]])
                                                    if accepted and accepted[0]['exact'] else None))
    path=ROOT/'TurnVerification.json'
    path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(result['status'],result['complete_turn_targets'],sha(path))


if __name__=='__main__':
    main()
