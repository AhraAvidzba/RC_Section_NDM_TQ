"""Independently reconstruct 56 weak equations, four constraints and six signed efforts."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import csv
import json
import math
import sys

HERE = Path(__file__).resolve().parent
NATIVE = HERE / "Native"
DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result


def verify():
    prep = read(HERE/"Preparation.json")
    build = read(HERE/"docs/regression/CodeUpdate.json")
    closure = read(HERE/"CompileClosure.json")
    owner = read(NATIVE/"MVT2.txt.Ownership.json")
    watcher = read(NATIVE/"MVT2.txt.ProcessClosure.json")
    receipt = read(NATIVE/"RunReceipt.json")
    final = watcher["Closure"]["FinalState"]
    assert build["Compiled"] and not build["ProductionChanged"]
    assert build["Modules"]==["modTestCoupledExperiment"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and closure["State"]=="Absent"
    assert all(digest(HERE/name)==identity for name,identity in prep["prior_input_sha256"].items())
    assert digest(HERE/"tests/modTestCoupledExperiment.bas")==prep["module_sha256"]
    if "--offline" not in sys.argv:
        assert digest(HERE/"docs/regression/Diagnostic.xlsm")==build["WorkbookSHA256"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert watcher["Passed"] and watcher["ChildExitCode"]==receipt["native_exit"]==0
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (NATIVE/"MVT2.txt").read_text(encoding="utf-8-sig")
    assert digest(HERE/"Replay.csv")==prep["replay_sha256"]
    archived = list(csv.reader((HERE/"Replay.csv").read_text(encoding="ascii").splitlines(),delimiter=";"))[1:]
    assert len(archived)==24
    tags=defaultdict(list)
    trace = NATIVE/"MVT2.csv"
    for tag,*row in csv.reader(trace.read_text(encoding="cp1251").splitlines(),delimiter=";"):
        tags[tag].append(row)
    fields = vec(tags,"MVT2_CONTROL_FIELD")
    assert len(fields)==len(archived)
    for i,row in enumerate(archived,1):
        expected = [float(x) for x in row[9:]]
        assert int(row[0])==i and peak(diff(expected,fields[f"Replay{i}"]))<1e-15
    [[fb,ft]]=tags["B_TANGENT_LOAD"]
    base_factor, target_factor = float(fb),float(ft)
    near(base_factor,float(archived[-1][2]),1e-13)
    near(target_factor,base_factor+(base_factor-float(archived[-2][2]))/64.,1e-13)
    [[last,factor]]=tags["B_TANGENT_END"]
    assert int(last)==24 and float(factor)==base_factor
    state_fields, flags = {}, {}
    for label,h,f,*values in tags["B_TANGENT_FIELD"]:
        assert label not in state_fields and len(values)==DIM
        state_fields[label]=tuple(map(float,values))
        flags[label]=(int(h),float(f))
    residuals=vec(tags,"B_TANGENT_RESIDUAL")
    stations=defaultdict(dict)
    for label,point,side,*values in tags["B_TANGENT_STATION"]:
        identity=(int(point),int(side))
        assert label in residuals and identity not in stations[label] and len(values)==19
        stations[label][identity]=tuple(map(float,values))
    unavailable=defaultdict(list)
    for label,reason,*info in tags["B_TANGENT_UNAVAILABLE"]:
        unavailable[label].append((reason,*info))
    for name in state_fields.keys()-residuals.keys():
        assert name in unavailable and unavailable[name]==[("Residual",)]
    assert all(name in stations and name in state_fields for name in residuals)
    for label in ("Base24","Unpublished24","Restored24"):
        assert state_fields[label]==fields["Replay24"] and stations[label]==stations["Base24"]
        assert flags[label]==(24,base_factor) and residuals[label]==residuals["Base24"]
    geometric_scale=(AREA,AREA*LENGTH,AREA*LENGTH,AREA*LENGTH,AREA,AREA)
    responses, diagnostics = {}, {}
    for name in residuals:
        h,f = flags[name]
        assert set(stations[name])=={(point,side) for point in range(1,46) for side in (-1,0,1)}
        computed, actual, error = reconstruct(state_fields[name],f,stations[name])
        discrepancy=peak(diff(computed,residuals[name]))
        assert error<4e-15 and discrepancy<3e-10,(name,error,discrepancy)
        integral=peak(delta/s for delta,s in zip(diff(actual,force(f)),geometric_scale,strict=True))
        weak=peak(computed[:56]); gauge=MODULUS*peak(computed[56:]); tol=5e-7*(1.+peak(loading(f)))
        diagnostics[name]={"history":h,"Qy_kN":f,"max_weak_MPa":weak,"gauge_MPa":gauge,"force_MPa":integral,
            "max_full_MPa":max(weak,gauge,integral),"worst_weak_row":max(range(56),key=lambda idx:abs(computed[idx]))+1,
            "equilibrium_tolerance_MPa":tol,"six_N_Nmm":actual,
            "independent_weak_difference_MPa":discrepancy,"station_strain_discrepancy":error}
        responses[name]=computed
    base=state_fields["Base24"]
    assert state_fields["BaseTrial"]==base and flags["BaseTrial"]==(24,target_factor)
    assert stations["BaseTrial"]==stations["Base24"]
    prior=defaultdict(list)
    for tag,*row in csv.reader((HERE/"PreviousNative.csv").read_text().splitlines(),delimiter=";"):
        prior[tag].append(row)
    prior_fields={label:tuple(map(float,values)) for label,h,f,*values in prior["B_TANGENT_FIELD"]}
    prior_stations=defaultdict(dict)
    for label,point,side,*values in prior["B_TANGENT_STATION"]:
        prior_stations[label][int(point),int(side)]=tuple(map(float,values))
    previous_errors={}
    for current,older in (("Base24","Base24"),("StockQuarter","Stock24/Newton/.25")):
        field_discrepancy=peak(diff(state_fields[current],prior_fields[older]))
        assert field_discrepancy<4e-16
        assert set(stations[current])==set(prior_stations[older])
        errors=[peak(diff(stations[current][key],prior_stations[older][key])) for key in stations[current]]
        assert max(errors)<2e-9,(current,max(errors))
        near(peak(diff(residuals[current],vec(prior,"B_TANGENT_RESIDUAL")[older])),0.,5e-10)
        previous_errors[current]={"field":field_discrepancy,"station_rows":max(errors)}
    native_norm={name:float(norm) for name,norm in tags["B_BOUND_NORM"]}
    native_actual={name:tuple(map(float,values)) for name,*values in tags["B_BOUND_ACTUAL"]}
    assert set(native_norm)==set(native_actual)==set(diagnostics)
    queried_steel=defaultdict(dict)
    for name,point,side,axis,e,concrete,stress in tags["B_BOUND_STEEL"]:
        key=(int(point),int(side))
        assert key not in queried_steel[name]
        queried_steel[name][key]=(int(axis),float(e),float(concrete),float(stress))
    assert set(queried_steel)==set(diagnostics)
    for label,metrics in diagnostics.items():
        near(native_norm[label],metrics["max_full_MPa"],4e-10)
        assert len(native_actual[label])==6
        assert peak(delta/s for delta,s in zip(diff(native_actual[label],metrics["six_N_Nmm"]),geometric_scale,strict=True))<2e-12
        steel=queried_steel[label]; assert len(steel)==60
        ratios=[]; maxima=[]; history_peak=0.
        for (point,side),row in stations[label].items():
            if point<=25: continue
            x,y,_=row[:3]
            axis=2 if point<=29 else 1 if abs(x)>abs(y) else 0
            if point<=29:
                near(abs(x),84.,1e-8); near(abs(y),84.,1e-8)
            else: near(max(abs(x),abs(y)),96.,1e-8)
            named,e,concrete,stress=steel[point,side]
            assert named==axis+1
            near(e,row[7+axis],4e-16)
            near(stress,row[13+axis]+concrete,4e-10)
            near(stress,e*200000.,4e-8)
            limit=498. if point<=29 else 450.
            hist_max=max(abs(strain_at(q,operators(x,y),side)[axis])*200000. for q in fields.values())
            assert abs(stress)<limit and hist_max<limit
            history_peak=max(history_peak,hist_max)
            ratios.append(abs(e)/.05); maxima.append(abs(stress))
        metrics["max_steel_strain_utilization"]=max(ratios)
        metrics["max_steel_stress_MPa"]=max(maxima)
        metrics["max_archived_steel_stress_MPa"]=history_peak
    def tensor_components(q):
        components=[]
        for (point,side),row in stations["Base24"].items():
            eps=strain_at(q,operators(*row[:2]),side)
            components.extend(value/(1. if i<3 else math.sqrt(2.)) for i,value in enumerate(eps))
        return components
    secant=diff(base,fields["Replay23"])
    secant_components=tensor_components(secant)
    for k,label in ((1.,"Secant/1"),(-1.,"Secant/-1")):
        dq=diff(state_fields[label],base)
        assert peak(diff(dq,tuple(k*q*1e-7/peak(secant_components) for q in secant)))<2e-15
        near(peak(tensor_components(dq)),1e-7,2e-15)
    selection={"Stock100":("Stock24",1e-7),"Positive100":("BiasedPositive",1e-7),"Positive500":("BiasedPositive",5e-7),
        "Envelope10":("CurrentEnvelope",1e-8),"Envelope100":("CurrentEnvelope",1e-7),"Envelope500":("CurrentEnvelope",5e-7)}
    input_rows={name:tuple(map(float,values)) for name,*values in csv.reader((HERE/"BoundedFields.csv").read_text().splitlines(),delimiter=";")}
    assert input_rows.pop("StockQuarter")[2:]==prior_fields["Stock24/Newton/.25"]
    assert set(input_rows)==set(selection)
    bounds=read(HERE/"Bounds.json")
    assert bounds["native_trace_sha256"]=="66D014FF04BC13625676E41B45397B6233D511CBB12662DDD1F9190534664F47"
    near(bounds["load_target_Qy_kN"],target_factor,3e-14)
    near(bounds["baseline_weak_MPa"],diagnostics["BaseTrial"]["max_weak_MPa"],4e-10)
    input_native={name:tuple(map(float,values)) for name,*values in tags["B_BOUND_INPUT"]}
    assert set(input_native)==set(selection)
    stock=diagnostics["StockQuarter"]["max_full_MPa"]
    measured={}
    for name,(group,radius) in selection.items():
        old_row=next(row for row in bounds["tests"][group] if row["radius"]==radius)
        bound,prediction,*delta=input_rows[name]
        assert bound==radius and prediction==old_row["target_residual_MPa"] and delta==old_row["dq"]
        expected=tuple(a+b for a,b in zip(base,delta,strict=True))
        assert peak(diff(state_fields[name],expected))<2e-15
        native_radius,native_pred,tensor_peak=input_native[name]
        near(native_radius,radius,1e-18); near(native_pred,prediction,1e-15)
        components=tensor_components(delta)
        calc=peak(components)
        near(calc,tensor_peak,4e-16); near(calc,old_row["max_tensor_strain_component"],4e-16)
        assert calc<=radius+4e-16
        cos=dot(components,secant_components)/math.hypot(*components)/math.hypot(*secant_components)
        near(cos,old_row["cosine_strain_secant"],2e-13)
        metrics=diagnostics.get(name)
        measured[name]={"radius":radius,"prediction_MPa":prediction,"predicted_by_all_matrices_MPa":old_row["modeled_residuals_MPa"],
            "max_tensor_component":calc,"station_strain_cosine_to_secant":cos,"actual":metrics,
            "reduction_from_stock":None if metrics is None else 1.-metrics["max_full_MPa"]/stock}
    [[selection_label,best_native,stock_native]]=tags["B_BOUND_PICK"]
    best_val,best=min([(stock,"")]+[(diagnostics[name]["max_full_MPa"],name) for name in selection if name in diagnostics])
    near(float(stock_native),stock,4e-10)
    assert selection_label==best
    near(float(best_native),best_val,4e-10)
    eligible=(best_val<.7*stock and bool(best))
    follow=None
    if eligible and tags["B_BOUND_FOLLOW"]:
        [[label,fraction,length,radius]]=tags["B_BOUND_FOLLOW"]
        assert label==best and not tags["B_BOUND_FOLLOW_UNAVAILABLE"]
        fraction,length,radius=map(float,(fraction,length,radius))
        near(radius,selection[best][1],2e-18)
        correction=vec(tags,"B_BOUND_CORRECTION")["Follow"]
        extent=peak(tensor_components(correction)); near(length,extent,3e-15)
        near(fraction,min(.25,radius/extent) if extent else .25,3e-13)
        assert extent*fraction<=radius+4e-16
        expected=tuple(b+fraction*d for b,d in zip(state_fields[best],correction,strict=True))
        assert peak(diff(state_fields["Follow"],expected))<2e-15 and flags["Follow"]==(24,target_factor)
        follow={"start_label":best,"fraction":fraction,"radius":radius,"actual":diagnostics.get("Follow")}
    elif eligible:
        [[label,reason,*_]]=tags["B_BOUND_FOLLOW_UNAVAILABLE"]
        assert label==best and reason in ("Matrix","LinearSystem")
        follow={"start_label":best,"unavailable":reason}
    else:
        assert not any(tags[tag] for tag in ("B_BOUND_FOLLOW","B_BOUND_FOLLOW_UNAVAILABLE","B_BOUND_CORRECTION"))
    summary={"workbook_sha256":prep["book_sha256"],"prefix_sha256":prep["replay_sha256"],"trace_sha256":digest(trace),
        "solver_owned_closure":final,"compile_closure":closure,"wall_s":receipt["wall_seconds"],
        "origin_factor_kN":base_factor,"trial_factor_kN":target_factor,"scope_fields":len(state_fields),
        "exact_rollback":True,"prior_stock_and_base_compatibility":previous_errors,"base":diagnostics["Base24"],
        "base_with_trial_load":diagnostics["BaseTrial"],"stock_quarter":diagnostics["StockQuarter"],
        "secants":{label:diagnostics.get(label) for label in ("Secant/1","Secant/-1")},"candidates":measured,
        "best_bounded":best or None,"follow_threshold_MPa":.7*stock,"follow":follow,"unavailable":dict(unavailable),
        "physical_limit_confirmed":False}
    result=HERE/"Verification.json"
    result.write_text(json.dumps(summary,indent=2)+"\n",encoding="utf8")
    print(result,digest(result))


if __name__=="__main__":
    verify()
