' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет сохранённые ограниченные поправки на фактическом материальном отклике MVT2 B.
Public Function RunTestWangShearControlled(ByVal replayPath As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Const EC As Double = 30000#, NU As Double = 0.2, FT As Double = 2.10667357864589
    Const PEAK_STRAIN As Double = 0.0022, LOCALIZATION_LENGTH As Double = 125#
    concrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    plusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    response.Initialize operators, concrete, steel
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, response, EC, plusSide, minusSide
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim materials(-1 To 1) As CCoupledConcreteResponse, responses(-1 To 1) As ICoupledPointResponse
    Set materials(0) = concrete: Set materials(1) = plusConcrete: Set materials(-1) = minusConcrete
    Set responses(0) = response: Set responses(1) = plusSide: Set responses(-1) = minusSide
    Dim previous() As Double, base() As Double, secant() As Double, working() As Double, inputField() As Double
    Dim bestField() As Double, bestLabel As String, bestNorm As Double, bestRadius As Double, stockNorm As Double
    Dim qBase As Double, qTrial As Double, k As Long, factor As Double, norm As Double, sign As Variant
    Dim labels() As String, radii() As Double, predictions() As Double, candidates() As Double
    ReadWangBoundsTest Left$(replayPath, InStrRev(replayPath, "\")) & "BoundedFields.csv", labels, radii, predictions, candidates
    previous = history(23): base = history(24)
    qBase = factors(24): qTrial = qBase + (qBase - factors(23)) / 64#
    Dim output As Integer: output = FreeFile
    Open tracePath For Append As #output
    Print #output, "B_TANGENT_LOAD;" & ExperimentNumberTest(qBase) & ";" & ExperimentNumberTest(qTrial)
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Base24", 24, qBase, solver, operators, materials, responses, base)
    norm = RecordWangTangentStateTest(output, "BaseTrial", 24, qTrial, solver, operators, materials, responses, base)
    ReDim inputField(1 To 60)
    For k = 1 To 60: inputField(k) = candidates(k, 1): Next k
    stockNorm = RecordWangTangentStateTest(output, "StockQuarter", 24, qTrial, solver, operators, materials, responses, inputField)
    If stockNorm <= 0# Then Err.Raise 5, , "Нет контрольной штатной невязки MVT2 B."
    ReDim secant(1 To 60)
    For k = 1 To 60: secant(k) = base(k) - previous(k): Next k
    factor = 0.0000001 / WangBoundedTensorPeakTest(operators, secant)
    For Each sign In Array(1#, -1#)
        AddWangTangentDirectionTest base, secant, CDbl(sign) * factor, working
        norm = RecordWangTangentStateTest(output, "Secant/" & ExperimentNumberTest(CDbl(sign)), 24, qTrial, _
            solver, operators, materials, responses, working)
    Next sign
    Dim i As Long
    bestNorm = stockNorm
    For i = 2 To UBound(labels)
        RestoreWangShearBaselineTest solver, history, base
        For k = 1 To 60: inputField(k) = candidates(k, i): Next k
        AddWangTangentDirectionTest base, inputField, 1#, working
        Print #output, "B_BOUND_INPUT;" & labels(i) & ";" & ExperimentNumberTest(radii(i)) & ";" & _
            ExperimentNumberTest(predictions(i)) & ";" & ExperimentNumberTest(WangBoundedTensorPeakTest(operators, inputField))
        norm = RecordWangTangentStateTest(output, labels(i), 24, qTrial, solver, operators, materials, responses, working)
        If norm >= 0# And norm < bestNorm Then
            bestField = working: bestNorm = norm: bestLabel = labels(i): bestRadius = radii(i)
        End If
        RequireWangAcceptedFieldTest solver, base
    Next i
    Print #output, "B_BOUND_PICK;" & bestLabel & ";" & ExperimentNumberTest(bestNorm) & ";" & ExperimentNumberTest(stockNorm)
    If Len(bestLabel) > 0 And bestNorm < 0.7 * stockNorm Then
        TryOneWangBoundedCorrectionTest output, bestLabel, bestField, bestRadius, qTrial, solver, operators, materials, responses
    End If
    RequireWangAcceptedFieldTest solver, base
    norm = RecordWangTangentStateTest(output, "Unpublished24", 24, qBase, solver, operators, materials, responses, base)
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Restored24", 24, qBase, solver, operators, materials, responses, base)
    Print #output, "B_TANGENT_END;24;" & ExperimentNumberTest(qBase)
    Close #output
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    Dim problem As String: problem = Err.Source & " " & Err.Description
    On Error Resume Next
    If output > 0 Then Close #output
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Масштабирует одно и то же направление без изменения принятого поля решателя.
Private Sub AddWangTangentDirectionTest(ByRef base() As Double, ByRef direction() As Double, _
        ByVal amount As Double, ByRef target() As Double)
    Dim j As Long
    ReDim target(1 To UBound(base))
    For j = 1 To UBound(base): target(j) = base(j) + amount * direction(j): Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает вектор в инвариантной форме для независимой проверки.
Private Sub EmitWangTangentVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef values() As Double)
    Dim row As String, j As Long
    row = prefix
    For j = 1 To UBound(values): row = row & ";" & ExperimentNumberTest(values(j)): Next j
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет независимые центральные и боковые напряжения, признаки ветви и слабые строки.
Private Function RecordWangTangentStateTest(ByVal output As Integer, ByVal label As String, ByVal historyCount As Long, _
        ByVal factor As Double, ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef field() As Double) As Double
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, grad(1 To 6) As Double
    Dim residual() As Double, matrix() As Double, external() As Double, row As String, flag As Long
    Dim yielding As Boolean, principal As Long, substeps As Long, yieldValue As Double
    Dim concretePoint As ICoupledPointResponse, concreteStress(1 To 6) As Double, component As Long
    EmitWangTangentVectorTest output, "B_TANGENT_FIELD;" & label & ";" & CStr(historyCount) & ";" & _
        ExperimentNumberTest(factor), field
    RecordWangTangentStateTest = -1#
    If Not solver.TestEquilibriumLinearization(field, False, False, residual, matrix) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";Residual"
        Exit Function
    End If
    operators.LoadEquations 0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, external
    For i = 1 To UBound(residual): residual(i) = residual(i) - external(i): Next i
    EmitWangTangentVectorTest output, "B_TANGENT_RESIDUAL;" & label, residual
    Dim norm As Double, value As Double, actual(1 To 6) As Double, demand(1 To 6) As Double
    For i = 1 To UBound(residual)
        value = Abs(residual(i))
        If i > solver.PhysicalDegreeCount Then value = value * 30000#
        norm = GeomMax(norm, value)
    Next i
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For point = 1 To operators.PointCount
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, slope
        For side = -1 To 1
            For i = 1 To 6: station(i) = strain(i) + side * 0.001 * slope(i): Next i
            If responses(side).EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Не подтвержден станционный отклик MVT2 B. " & label
            If side = 0 Then
                actual(1) = actual(1) + area * stress(3)
                actual(2) = actual(2) + area * stress(3) * y
                actual(3) = actual(3) + area * stress(3) * x
                actual(4) = actual(4) + area * (x * stress(6) - y * stress(5))
                actual(5) = actual(5) + area * stress(5)
                actual(6) = actual(6) + area * stress(6)
            End If
            If point > operators.ConcretePointCount Then
                Set concretePoint = materials(side)
                If concretePoint.EvaluatePoint(point, station, concreteStress, tangent, ctmStressOnly, False) <> sfcNone Then _
                    Err.Raise 5, , "Не подтверждён бетон в поправке замещения арматуры MVT2 B. " & label
                component = 3 ' Продольные стержни имеют ось z.
                If point > operators.ConcretePointCount + 4 Then
                    If Abs(x) > Abs(y) Then component = 2 Else component = 1 ' Ось ветви параллельна стенке квадрата.
                End If
                Print #output, "B_BOUND_STEEL;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & CStr(component) & ";" & _
                    ExperimentNumberTest(station(component)) & ";" & ExperimentNumberTest(concreteStress(component)) & ";" & _
                    ExperimentNumberTest(stress(component) + concreteStress(component))
            End If
            flag = -1: principal = 0: substeps = -1: yieldValue = 0#
            If point <= operators.ConcretePointCount Then
                If Not materials(side).TryReadConcreteBranch(point, station, yielding, principal, substeps) Then _
                    Err.Raise 5, , "Недоступна ветвь бетона MVT2 B. " & label
                If Not materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=False) Then _
                    Err.Raise 5, , "Недоступна пробная поверхность бетона MVT2 B. " & label
                flag = Abs(CLng(yielding))
            End If
            row = "B_TANGENT_STATION;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area) & ";" & _
                CStr(flag) & ";" & CStr(principal) & ";" & CStr(substeps) & ";" & ExperimentNumberTest(yieldValue)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(station(i)): Next i
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(i)): Next i
            Print #output, row
        Next side
    Next point
    EmitWangTangentVectorTest output, "B_BOUND_ACTUAL;" & label, actual
    RecordWangTangentStateTest = GeomMax(norm, operators.ResultantResidualNorm(actual, demand))
    Print #output, "B_BOUND_NORM;" & label & ";" & ExperimentNumberTest(RecordWangTangentStateTest)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные координаты и линейные прогнозы из отдельно проверяемой таблицы.
Private Sub ReadWangBoundsTest(ByVal path As String, ByRef labels() As String, ByRef radii() As Double, _
        ByRef predictions() As Double, ByRef fields() As Double)
    ReDim labels(1 To 7), radii(1 To 7), predictions(1 To 7), fields(1 To 60, 1 To 7)
    Dim file As Integer, i As Long, k As Long, row As String, parts As Variant
    file = FreeFile: Open path For Input As #file
    For i = 1 To 7
        If EOF(file) Then Err.Raise 5, , "Неполный перечень ограниченных поправок MVT2 B."
        Line Input #file, row
        parts = Split(row, ";")
        If UBound(parts) <> 62 Then Err.Raise 5, , "Неверный размер ограниченной поправки MVT2 B."
        labels(i) = parts(0): radii(i) = Val(parts(1)): predictions(i) = Val(parts(2))
        For k = 1 To 60: fields(k, i) = Val(parts(k + 2)): Next k
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние ограниченные поправки MVT2 B."
    Close #file
    If labels(1) <> "StockQuarter" Then Err.Raise 5, , "Не найдена штатная контрольная поправка MVT2 B."
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает наибольшую взвешенную компоненту тензора на всех 135 станциях.
Private Function WangBoundedTensorPeakTest(ByVal operators As CCoupledElasticState, ByRef direction() As Double) As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double
    Dim point As Long, side As Long, j As Long, s As Double, peak As Double
    For point = 1 To operators.PointCount
        operators.PointStrain point, direction, strain
        operators.AxialGradientAtPoint point, direction, slope
        For side = -1 To 1
            For j = 1 To 6
                s = Abs(strain(j) + side * 0.001 * slope(j))
                If j > 3 Then s = s / Sqr(2#)
                peak = GeomMax(peak, s)
            Next j
        Next side
    Next point
    WangBoundedTensorPeakTest = peak
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает одну ограниченную поправку при прежнем целевом усилии. История остаётся H24.
Private Sub TryOneWangBoundedCorrectionTest(ByVal output As Integer, ByVal label As String, ByRef start() As Double, _
        ByVal radius As Double, ByVal factor As Double, ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByRef materials() As CCoupledConcreteResponse, _
        ByRef responses() As ICoupledPointResponse)
    Dim residual() As Double, matrix() As Double, external() As Double, target() As Double, k As Long
    Dim system As New CCoupledLinearSystem
    If Not solver.TestEquilibriumLinearization(start, True, False, residual, matrix) Then
        Print #output, "B_BOUND_FOLLOW_UNAVAILABLE;" & label & ";Matrix"
        Exit Sub
    End If
    operators.LoadEquations 0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, external
    For k = 1 To UBound(start): residual(k) = external(k) - residual(k): Next k
    If Not system.Solve(matrix, residual, UBound(start)) Then
        Print #output, "B_BOUND_FOLLOW_UNAVAILABLE;" & label & ";LinearSystem;" & CStr(system.FailureCode)
        Exit Sub
    End If
    Dim length As Double, fraction As Double, norm As Double
    length = WangBoundedTensorPeakTest(operators, residual)
    fraction = 0.25
    If length > 0# Then fraction = GeomMin(fraction, radius / length)
    Print #output, "B_BOUND_FOLLOW;" & label & ";" & ExperimentNumberTest(fraction) & ";" & _
        ExperimentNumberTest(length) & ";" & ExperimentNumberTest(radius)
    EmitWangTangentVectorTest output, "B_BOUND_CORRECTION;Follow", residual
    AddWangTangentDirectionTest start, residual, fraction, target
    norm = RecordWangTangentStateTest(output, "Follow", 24, factor, solver, operators, materials, responses, target)
End Sub
