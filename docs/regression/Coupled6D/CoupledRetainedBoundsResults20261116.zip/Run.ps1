# Проверяет подготовленную книгу частным экземпляром Excel и сохраняет протоколы.
param([Parameter(Mandatory=$true)][ValidateSet('Base','Candidate')][string]$Role)
$ErrorActionPreference='Stop'
$root=Join-Path $PSScriptRoot $Role
$savedTemp=$env:TEMP; $savedTmp=$env:TMP
$savedVerifier=$env:NDM_LOAD_PATH_VERIFIER_ROOT
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$production=(Resolve-Path -LiteralPath 'workbook/output/RC_Section_NDM.xlsm').Path
if((Get-FileHash -LiteralPath $production).Hash -ne 'E9F63337672E9FEC00E228A100EF554E9CA740D9395AC80D92E23417D0DA8833'){throw 'Установленная книга изменилась.'}
Push-Location -LiteralPath $root
try {
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $protected[9552]=[long]639304334673501852
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    $proof=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json -AsHashtable
    foreach($file in $proof.Keys){if((Get-FileHash -LiteralPath $file).Hash -cne $proof[$file]){throw ('Изменился вход. '+$file)}}
    if(Test-Path -LiteralPath 'Compile.log'){throw 'Проверьте прежний протокол.'}
    if((Get-FileHash -LiteralPath $draft).Hash -cne $proof['workbook\output\RC_Section_NDM.xlsm']){throw 'Неверная исходная книга.'}
    Assert-IsolatedOfficeReady ('Compile'+$Role)
    $modules=@('modTestCoupledElasticState','CTestCoupledPointResponse')
    if($Role -eq 'Candidate'){$modules+= @('CStrengthSummaryWriter','CNDMResultsWriter','CCoupledDeformationContinuation')}
    & (Join-Path $root 'tools/build_workbook/Update-IsolatedOptimizerCode.ps1') -WorkbookPath $draft -ModuleNames $modules |
        Tee-Object -FilePath 'Compile.log'
    Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    $receipt=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    if(!$receipt.Compiled -or $receipt.ProductionChanged -or (Get-FileHash -LiteralPath $draft).Hash -cne $receipt.WorkbookSHA256){throw 'Частная книга не подтверждена.'}
    $runBook=$draft
    if($Role -eq 'Candidate'){
        python -B -X utf8 (Join-Path $root 'Package.py')
        if($LASTEXITCODE -ne 0){throw 'Ошибка пакета книги.'}
        $runBook='docs/regression/Audit03/DesignWitness/RC_Section_NDM.xlsm'
    }
    $suites=@('RunTestCoupledDiscardedShoulder','RunTestCoupledWorkbookInput')
    if($Role -eq 'Candidate'){$suites+= @('RunTestCoupledRetainedShoulders','RunTestCoupledDesignWitness','RunTestCoupledHoopCapacity','RunTestCoupledTraditionalChecks')}
    foreach($suite in $suites){
        Assert-IsolatedOfficeReady $suite
        $log="Native/$suite.txt"
        & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-FocusedKaniWatchdog.ps1' -SourceWorkbook $runBook -ReportPath $log -Macro ('modTestCoupledElasticState.'+$suite) -Mode No -TimeoutSeconds 160 -FailFast
        $nativeExit=$LASTEXITCODE
        $actual=Get-Content -LiteralPath $log -Raw -Encoding UTF8
        $total=[regex]::Match($actual,'(?m)^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)')
        $closed=(Get-Content -LiteralPath ($log+'.ProcessClosure.json') -Raw | ConvertFrom-Json).Closure.FinalState
        if(!$total.Success -or $closed.State -ne 'Absent'){throw ('Нет результата или процесс не закрыт. '+$suite)}
        $expectedFailures=0
        if($Role -eq 'Base'){
            if($suite -eq 'RunTestCoupledDiscardedShoulder'){$expectedFailures=2}else{$expectedFailures=6}
        }
        [ordered]@{role=$Role;suite=$suite;pass=[int]$total.Groups[1].Value;fail=[int]$total.Groups[2].Value;exit=$nativeExit;closed=$closed} |
            ConvertTo-Json -Depth 4 | Set-Content -LiteralPath ($log+'.Receipt.json') -Encoding UTF8
        if(($Role -eq 'Base' -and $nativeExit -eq 0) -or ($Role -eq 'Candidate' -and $nativeExit -ne 0) -or [int]$total.Groups[2].Value -ne $expectedFailures){throw ('Неожиданный исход. '+$suite)}
        Write-Output $total.Value
    }
    if($Role -eq 'Candidate'){
        Assert-IsolatedOfficeReady 'ExportCandidate'
        $export='docs/regression/Audit03/DesignWitness/VBA_All_Code.txt'
        & (Join-Path $root 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1') -WorkbookPath $runBook -OutputPath $export |
            Tee-Object -FilePath 'Export.log'
        Save-OfficeClosure 'Export.log' 'ExportClosure.json'
        python -B -X utf8 tools/build_workbook/Verify-ExportDifference.py workbook/output/VBA_All_Code.txt $export @modules |
            Tee-Object -FilePath 'ExportDifference.json'
        if($LASTEXITCODE -ne 0){throw 'Расходится фактическая выгрузка VBA.'}
        $env:NDM_LOAD_PATH_VERIFIER_ROOT=(Get-Location).Path
        & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Verify-SolverSource.ps1' -ExportPath $export -ReportPath 'docs/regression/SourceEquality.json'
        if($LASTEXITCODE -ne 0){throw 'Исходники не совпадают с кодом открытой книги.'}
    }
}
finally {
    $env:TEMP=$savedTemp; $env:TMP=$savedTmp
    $env:NDM_LOAD_PATH_VERIFIER_ROOT=$savedVerifier
    Pop-Location
}
