"""ДЛЯ ТЕСТОВ: проверяет свежесть реально собранного VBA, неизменность физических исходов и устранение рассогласования истории."""
from argparse import ArgumentParser
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from subprocess import check_output


def TestRead(file):
    """Сохраняет численные ожидания и различие между дефектом тестовой сборки и дефектом решателя."""
    return json.loads(file.read_text('utf-8-sig'))


def TestNative(repo,root,output):
    """Декодирует все компоненты и проверяет, что новые проверки присутствуют именно в сохранённых частных книгах."""
    shared=run_path(str(root/'Check-TestMaterialRoundoff.py'));shared['TestFiles'](root)
    source,_=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _,original=reader(BytesIO(source));cases={}
    canonical=run_path(str(root/'Canonical-TestCoreVBA.py'));body=canonical['TestWrap'](body)
    normal=lambda text:canonical['TestCanonical'](text)[0]
    controls={
        'equivalent_decimal_literal':normal('x=1e-8')==normal('x=0.00000001'),
        'changed_tolerance_rejected':normal('x=1e-8')!=normal('x=1e-7'),
        'changed_literal_type_rejected':normal('x=200000#')!=normal('x=200000'),
        'runtime_unicode_string_exact':normal('msg="ε"')!=normal('msg="?"'),
        'runtime_numeric_string_exact':normal('msg="1e-8"')!=normal('msg="0.00000001"'),
        'russian_comment_change_rejected':normal("x=1 'бетон")!=normal("x=1 'арматура"),
        'unsupported_comment_glyph_only':normal("x=1 'ν=0")==normal("x=1 '?=0"),
        'adjacent_large_integer_value_rejected':normal('x=10000000000#')!=normal('x=10000000001#')}
    assert all(controls.values())
    for key in TestRead(root/'Cases.json'):
        folder=root/'Cases'/key
        record=shared['TestSourceComparison'](repo,root,folder,source,original,helper,body,reader)
        expected=(239,24,215) if key=='StaleTests' else (239,25,214)
        assert (record['components'],record['imported'],record['unchanged'])==expected
        compiler=TestRead(folder/'docs/regression/CodeUpdate.json')
        assert ('modTestCoupledElasticState' in compiler['Modules'])==(key!='StaleTests')
        reports={}
        for file in sorted((folder/'Native').glob('*.txt')):
            log=file.read_text('utf-8-sig');phase=file.stem
            owner=TestRead(file.with_name(file.name+'.Ownership.json'));closure=TestRead(file.with_name(file.name+'.ProcessClosure.json'))
            identity=closure['Closure']['Identity'];negative=(key=='Before')
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
            assert owner['PID']==identity['PID'] and int(owner['StartTicksUTC'])==identity['Ticks']
            assert owner['SourceSHA256']==compiler['WorkbookSHA256'] and closure['Closure']['FinalState']['State']=='Absent'
            assert closure['ChildExitCode']==(1 if negative else 0)
            assert 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
            totals=[tuple(map(int,row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',log,re.M)]
            if key=='StaleTests':assert phase=='SteelCrossing' and totals==[(32,0)]
            elif key=='Before':assert phase=='SteelCrossing' and totals==[(35,6)]
            elif phase=='SteelCrossing':assert totals==[(41,0)]
            else:assert phase=='Core' and sum(passed for passed,failed in totals)==374 and all(failed==0 for passed,failed in totals)
            reports[phase]={'totals':totals,'expected_negative':negative}
        safety=[json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB']>=6500 and row['freeCommitGiB']>=6 for row in safety)
        assert all(all(process['ProtectedUser'] for process in row['excel']) for row in safety)
        record['reports']=reports;record['new_assertions_present']=(key!='StaleTests');cases[key]=record
    base=TestRead(root/'SourceCheckpoint.json')['base'];name='src/Solver/CCoupledDeformationContinuation.cls'
    original_code=check_output(['git','cat-file','blob',base+':'+name],cwd=repo).replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
    assert (root/'Cases/Before'/name).read_bytes()==(root/'Cases/StaleTests'/name).read_bytes()==original_code
    assert (root/'Cases/Before/tests/modTestCoupledElasticState.bas').read_bytes()==(root/'Cases/Fixed/tests/modTestCoupledElasticState.bas').read_bytes()
    factory=(root/'AuditedSource/src/Excel/modCoupledWorkbookInput.bas').read_text('utf-8-sig')
    assert 'settings.GetRequiredLong("Solver.MaxIterations"), supplementary' in factory
    assert 'asdFlow:=' not in factory
    flow=(root/'Cases/Fixed/src/Materials/CCoupledASDFlow.cls').read_text('utf-8-sig')
    assert 'LawIdentifier = "ASD-Closed-Cdf0"' in flow and 'SingleStep strain, strain, priorEffective' in flow
    output.write_text(json.dumps({'cases':cases,'default_workbook_material':'CDP',
        'tabular_research_material':'ASD-Closed-Cdf0','physical_capacity_certified':False,
        'core_source_comparison_controls':controls,
        'core_comparison_comment_encoding':'cp1251 replacement only in comments',
        'installed_workbook_changed':False},indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('STEEL HISTORY NATIVE SOURCE FRESHNESS NEGATIVE CONTROLS AND FIX VERIFIED',flush=True)


def TestMechanics(repo,root,output):
    """Сравнивает 32 прежних исхода побайтно и независимо проверяет силы предельных точек аналитического сечения."""
    run_path(str(root/'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    labels=('accepted fields align with the complete load trace','last saved field exactly matches the committed solver state',
            'last retained field independently equilibrates its saved load')
    rows={}
    for key in ('Before','Fixed'):
        text=(root/'Cases'/key/'Native/SteelCrossing.txt').read_text('utf-8-sig')
        all_rows=[line for line in text.splitlines() if line.startswith(('OK:','FAIL:'))]
        added=[line for line in all_rows if any(label in line for label in labels)]
        old=[line for line in all_rows if line not in added]
        assert len(all_rows)==41 and len(old)==32 and len(added)==9
        forces=re.findall(r'last retained field independently equilibrates its saved load actual=([\d.E+-]+) expected=([\d.E+-]+)',text)
        assert len(forces)==3
        rows[key]={'old':old,'added':added,'forces':[(Decimal(a),Decimal(b)) for a,b in forces]}
    assert rows['Before']['old']==rows['Fixed']['old']
    assert sum(line.startswith('FAIL:') for line in rows['Before']['added'])==6
    assert all(line.startswith('OK:') for line in rows['Fixed']['added'])
    area=Decimal(21500);steel_area=Decimal(100);e=Decimal(30000);es=Decimal(200000);fy=Decimal(100);cubic=Decimal('1e10')
    def force(strain):return area*(e*strain-cubic*strain**3)+steel_area*min(es*strain,fy)
    limits=(Decimal('.00125'),Decimal('.0008'),Decimal('.0008'))
    designs=(Decimal(410000),Decimal(450000),Decimal(415920));records=[]
    for index,(limit,design) in enumerate(zip(limits,designs)):
        boundary=force(limit);before,trace_before=rows['Before']['forces'][index];after,trace_after=rows['Fixed']['forces'][index]
        assert trace_before==trace_after and abs(after-trace_after)<=Decimal('.01')
        assert abs(trace_after-boundary)<=Decimal('.0001')*design+Decimal('.01')
        if index in (0,2):assert abs(before-trace_before)>Decimal(8000)
        records.append({'strain_limit':str(limit),'design_force_N':str(design),'analytical_boundary_force_N':str(boundary),
                        'before_field_force_N':str(before),'trace_force_N':str(trace_after),'fixed_field_force_N':str(after)})
    peak=force(Decimal('.001'));assert peak==Decimal(440000)
    output.write_text(json.dumps({'cases':records,'unchanged_physical_and_numerical_checks':32,
        'added_history_checks':9,'expected_initial_failures':6,'analytical_curve_maximum_force_N':str(peak),
        'global_capacity_return_for_late_event_still_unresolved':True,'physical_capacity_certified':False},indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('STEEL HISTORY ANALYTICAL FORCES AND ALL 32 UNCHANGED PHYSICAL OUTCOMES VERIFIED',flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--scope',choices=('native','mechanics'),required=True)
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    {'native':TestNative,'mechanics':TestMechanics}[args.scope](args.repo.resolve(),args.root.resolve(),args.out.resolve())
