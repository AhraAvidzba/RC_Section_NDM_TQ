"""ДЛЯ ТЕСТОВ: фиксирует переносимый контроль истории и свежести фактически собранных тестов."""
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile,ZIP_DEFLATED


def TestSeal():
    """Добавляет два случая, не меняя 326 исторических результатов и установленную книгу."""
    repo=Path.cwd();scratch=Path('D:/CodexScratch/RC_Section_NDM_TQ');root=scratch/'SteelHistoryEvidence20261118'
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    outputs={'NativeProof.json','MechanicsProof.json'}
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper()
           for file in root.rglob('*') if file.is_file() and file.relative_to(root).as_posix() not in outputs|{'Files.json'}}
    (root/'Files.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    name='CoupledSteelHistoryIntegrity20261118';archive=scratch/(name+'.zip')
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as output:
        for file in sorted(root.rglob('*')):
            if file.is_file():output.write(file,file.relative_to(root).as_posix())
    assert archive.stat().st_size<100000000,(name,archive.stat().st_size)
    digest=sha256(archive.read_bytes()).hexdigest().upper();destination=repo/'docs/regression/Coupled6D'/(name+'.zip')
    assert not destination.exists();copyfile(archive,destination)
    additions=[];pins={}
    for scope,title,marker in (
        ('native','NativeProof.json','STEEL HISTORY NATIVE SOURCE FRESHNESS NEGATIVE CONTROLS AND FIX VERIFIED'),
        ('mechanics','MechanicsProof.json','STEEL HISTORY ANALYTICAL FORCES AND ALL 32 UNCHANGED PHYSICAL OUTCOMES VERIFIED')):
        pins[title]=sha256((root/title).read_bytes()).hexdigest().upper()
        additions.append({'id':'coupled-steel-history-'+scope,'journal_section':609,'archive':name,
            'script':'Check-TestSteelHistory.py','arguments':['--repo','{repo}','--root','.','--scope',scope,'--out',title],
            'stdout_contains':marker,'outputs':{title:pins[title]},'timeout_seconds':300})
    path=repo/'docs/reports/Coupled6DEvidence.json';text=path.read_text('utf-8').replace('\r\n','\n');old=json.loads(text)
    assert len(old['archives'])==299 and len(old['cases'])==326
    pos=text.index('\n  },\n  "cases": [');text=text[:pos]+',\n    '+json.dumps(name)+': '+json.dumps(digest)+text[pos:]
    pos=text.index('\n  ],\n  "frozen_repositories": {')
    text=text[:pos]+',\n'+',\n'.join('\n'.join('    '+line for line in json.dumps(case,ensure_ascii=False,indent=2).splitlines()) for case in additions)+text[pos:]
    current=json.loads(text);assert current['cases'][:326]==old['cases'] and len(current['cases'])==328
    assert all(current['archives'][key]==value for key,value in old['archives'].items())
    path.write_bytes(text.replace('\n','\r\n').encode())
    receipt={'archive':name,'bytes':archive.stat().st_size,'sha256':digest,'proofs':pins}
    (repo/'tmp/SteelHistorySeal.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,indent=2),flush=True)


if __name__=='__main__':TestSeal()
