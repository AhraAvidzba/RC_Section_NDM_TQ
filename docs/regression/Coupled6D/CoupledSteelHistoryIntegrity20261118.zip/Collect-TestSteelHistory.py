"""ДЛЯ ТЕСТОВ: сохраняет контроль устаревшего теста, воспроизведённый дефект истории и исправленную нативную книгу."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from subprocess import check_output


def TestCollect(repo,root):
    """Закрепляет реальные байты всех трёх сборок и снимок проверенного контракта материала."""
    here=Path(__file__).resolve().parent
    collect=run_path(str(here/'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases']={'StaleTests':'SteelHistoryBefore20261118',
                                    'Before':'SteelHistoryBefore0220261118','Fixed':'SteelHistoryFixed20261118'}
    collect(repo,root)
    for name in ('Collect-TestSteelHistory.py','Check-TestSteelHistory.py','Stage-TestSteelHistory.py','Canonical-TestCoreVBA.py'):
        (root/name).write_bytes((here/name).read_bytes())
    for name in ('src/Excel/modCoupledWorkbookInput.bas','docs/Coupled6DMaterialContract.md',
                 'literature/Coupled6D/OpenSees-3.8.0-ReferenceIdentity.json'):
        path=root/'AuditedSource'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((repo/name).read_bytes())
    (root/'SourceCheckpoint.json').write_text(json.dumps({'base':check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),
        'installed_workbook_changed':False,'physical_capacity_certified':False,'full_acceptance_completed':False},indent=2)+'\n',encoding='utf-8')
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper()
           for file in root.rglob('*') if file.is_file() and file.name!='Files.json'}
    (root/'Files.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('STEEL HISTORY FAILURE FRESHNESS CONTROL AND FIX COLLECTED',len(files),flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True);args=parser.parse_args();TestCollect(args.repo.resolve(),args.root.resolve())
