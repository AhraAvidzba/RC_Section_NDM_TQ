"""ДЛЯ ТЕСТОВ: проверяет общий рабочий API спектрального перехода без добавления методов в решатель."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Вызывает автоматический выбор точки по фактическому численному отказу; номера контрольного примера не задаются решателю."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestOriented148Probes.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    code = (here/'TestNativeCornerTrace.bas.txt').read_text('utf-8')
    begin = code.index('    Dim incomingSpacing As Double:')
    end = code.index('    movement = current\n', begin)
    replacement = '''    Dim incomingSpacing As Double: incomingSpacing = spacing
    Dim testProjection() As Double, testCoordinate As Double, testSpacing As Double, controlName As String
    If Not solver.SelectTransverseDeformationControl(previous, current, direction, testProjection, testCoordinate, testSpacing, controlName) Then Err.Raise 5, , "Нет исходной автоматической меры."
    Dim solved As Boolean, target As Double, phase As String, forward As Boolean, advance As Double, referenceIncrement As Double
    solved = solver.TryDeformationStep(base, direction, testProjection, testCoordinate + testSpacing / 64#, lambda, nextLambda, ATOL, RTOL, 32)
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;initial_raw_failure;" & CStr(Not solved)
    If solved Then Err.Raise 5, , "Не воспроизведён исходный численный отказ."
    Dim transition As CCoupledPrincipalTransition
    solved = solver.TryPreparePrincipalTransition(base, direction, previous, lambda, ATOL, RTOL, 32, transition, nextLambda, projection)
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;automatic_preparation;" & CStr(solved) & ";" & solver.ResultMeta.DiagnosticDetails
    If Not solved Then Err.Raise 5, , "Не подготовлен общий материальный переход."
    AddExperimentTraceTest report, tracePath, "CORNER_STATION;" & transition.Point & ";" & transition.Side & ";" & transition.PrincipalIndex
    Dim rejected As Boolean, unusedLambda As Double, unusedProjection() As Double
    rejected = Not solver.TryCompletePrincipalTransition(transition, base, direction, lambda, 32, unusedLambda, unusedProjection)
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;outgoing_before_acceptance_rejected;" & CStr(rejected)
    If Not rejected Then Err.Raise 5, , "Исходящая сторона разрешена до принятия входящей."
    Dim facePath As String, unusedReport As String
    transition.CopyFace field, nextLambda
    phase = "FaceReadOnly": facePath = tracePath & ".Face"
    AddExperimentTraceTest report, tracePath, "CORNER_STEP;" & phase & ";True;0;" & ExperimentNumberTest(nextLambda)
    AddExperimentTraceTest report, tracePath, "CORNER_COORDINATE;" & phase & ";" & ExperimentNumberTest(ReadPrincipalCoordinateTest(operators, transition, field, stations))
    RecordGaussPointsTest section, operators, unusedReport, facePath: WriteMVT2OperatorsTest operators, facePath
    handle = FreeFile: Open facePath & ".Tensor.csv" For Output As #handle: Close #handle
    WriteMVT2ReadOnlyFrameTest operators, field, phase, TORQUE, FORCE_SCALE * nextLambda, facePath, stations
    transition.CopyIncoming field, nextLambda
    solver.CopyTrial field, actual
    For Each phaseValue In Array("Incoming", "Outgoing")
        phase = CStr(phaseValue)
        target = transition.IncomingSign * transition.PrincipalGap
        If phase = "Outgoing" Then
            target = -target
            solved = solver.TryCompletePrincipalTransition(transition, base, direction, lambda, 32, nextLambda, projection)
            If Not solved Then Err.Raise 5, , "Не решена общая исходящая сторона."
            solver.CopyTrial field, actual
        End If
        AddExperimentTraceTest report, tracePath, "CORNER_STEP;" & phase & ";True;" & ExperimentNumberTest(target) & ";" & ExperimentNumberTest(nextLambda)
        AddExperimentTraceTest report, tracePath, "CORNER_COORDINATE;" & phase & ";" & ExperimentNumberTest(ReadPrincipalCoordinateTest(operators, transition, field, stations))
        forward = solver.SpatialIncrementAdvances(previous, current, field, advance, referenceIncrement)
        AddExperimentTraceTest report, tracePath, "CORNER_ORIENTATION;" & phase & ";" & CStr(forward) & ";" & ExperimentNumberTest(advance)
        solver.AcceptStep
        WriteMVT2FullFrameTest operators, field, phase, TORQUE, FORCE_SCALE * nextLambda, tracePath, stations
        previous = current: current = field: lambda = nextLambda
    Next phaseValue
    rejected = Not solver.TryCompletePrincipalTransition(transition, base, direction, lambda, 32, unusedLambda, unusedProjection)
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;consumed_context_rejected;" & CStr(rejected)
    If Not rejected Then Err.Raise 5, , "Повторно использован завершённый материальный переход."
'''
    replacement = replacement.replace('    Dim solved As Boolean,', '    Dim phaseValue As Variant\n    Dim solved As Boolean,')
    code = code[:begin]+replacement+code[end:]
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает выбранную рабочим алгоритмом спектральную координату от текущей принятой истории без изменения пробных буферов.
Private Function ReadPrincipalCoordinateTest(ByVal operators As CCoupledElasticState, ByVal transition As CCoupledPrincipalTransition, _
        ByRef field() As Double, ByVal stations As Collection) As Double
    Dim response As CCoupledReinforcedResponse: Set response = stations.Item(2 * transition.Side + 4)
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, unused(1 To 6) As Double, value As Double, i As Long
    operators.PointStrain transition.Point, field, strain: operators.AxialGradientAtPoint transition.Point, field, slope
    For i = 1 To 6: strain(i) = strain(i) + transition.Side * 0.001 * slope(i): Next i
    If Not response.TryReadPrincipalBoundary(transition.Point, strain, transition.PrincipalIndex, value, unused, False) Then Err.Raise 5, , "Не читается выбранная спектральная координата."
    ReadPrincipalCoordinateTest = value
End Function
'''
    name = 'tests/modTestMVT2ProductionASDTest.bas'; module = (root/name).read_text('utf-8-sig')
    begin = module.index('Private Function RunControlProbesTest('); end = module.index('\nEnd Function', begin)+len('\nEnd Function')
    (root/name).write_bytes((module[:begin]+code+module[end:]).replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'; text = (root/runner).read_text('utf-8-sig')
    old = "foreach ($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv'))"; assert text.count(old) == 1
    text = text.replace(old, "foreach ($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv','.Face','.Face.Tensor.csv','.Face.Operators.csv'))")
    (root/runner).write_bytes(text.encode('utf-8-sig'))
    for filename in (Path(__file__).name, 'TestNativeCornerTrace.bas.txt'):
        (root/filename).write_bytes((here/filename).read_bytes())
        prep['inputs'][filename] = sha256((root/filename).read_bytes()).hexdigest().upper()
    for filename in (name, runner): prep['inputs'][filename] = sha256((root/filename).read_bytes()).hexdigest().upper()
    prep['probe_scope'] = {'working_transition_api': True, 'automatic_point_selection': True,
        'prefix_states': 148, 'external_equilibrium_seed_used': False, 'physical_capacity_certified': False}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('GENERAL WORKING PRINCIPAL TRANSITION READY; AUTOMATIC STATION; NO SOLVER INSTRUMENTATION')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve())
