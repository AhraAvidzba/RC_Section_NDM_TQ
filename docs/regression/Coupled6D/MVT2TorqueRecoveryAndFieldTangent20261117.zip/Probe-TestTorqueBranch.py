"""ДЛЯ ТЕСТОВ: продолжает кручение при заданном закручивании и неизвестном T."""

from copy import copy
import json
from pathlib import Path
from runpy import run_path
from time import perf_counter

import numpy as np


def TestControlledStep(section,field,history,torque,control):
    """Исключает заданное закручивание; момент становится одной из неизвестных равновесия."""
    scale=10510000.
    indices=np.array([i for i in range(60) if i!=3])
    x=np.append(field[indices],torque/scale)
    def TestValue(value):
        f=np.empty(60);f[indices]=value[:-1];f[3]=control
        target=np.array([0.,0.,0.,scale*value[-1],0.,0.])
        return f,target,section.evaluate(f,history,target)
    field,target,result=TestValue(x)
    for iteration in range(28):
        tolerance=5e-7+5e-7*np.max(np.abs((target@section.l)[:56]))
        if result[1]<=tolerance:return field,float(target[3]),result,True,iteration
        tangent=np.empty((60,60))
        h=1e-9
        for col,unit in enumerate(np.eye(60)[indices]):
            plus=section.evaluate(field+h*unit,history,target)[0]
            minus=section.evaluate(field-h*unit,history,target)[0]
            tangent[:,col]=(plus-minus)/(2*h)*section.gauge_scale
        tangent[:,-1]=-scale*section.l[3]*section.gauge_scale
        try:step=np.linalg.solve(tangent,-result[0]*section.gauge_scale)
        except np.linalg.LinAlgError:break
        for factor in 2.**-np.arange(13):
            candidate=x+factor*step
            f,t,value=TestValue(candidate)
            if value[1]<result[1]:
                x,field,target,result=candidate,f,t,value
                break
        else:break
    return field,float(target[3]),result,False,iteration


def TestRun(repo,out):
    """Проверяет, скрывается ли за силовой остановкой продолжаемая деформационная ветвь."""
    helpers=run_path(str(repo/'tmp/mvt-split-follow/Continue-MVT2Tabulated.py'))
    loader=run_path(str(repo/'tmp/mvt-split-follow/Probe-TestNdmCurveEquilibrium.py'))['TestLoadSection']
    seed,ndm_history,ndm_field=loader(repo)
    case=json.loads((repo/'tmp/mvt-split-follow/ASDEnergySection.json').read_bytes())['cases']['ASDNDMEnergies125']
    output={}
    for name in ('NDMCurves','ASDExplicitEnergy'):
        section=copy(seed)
        if name=='NDMCurves':history,field=ndm_history,ndm_field.copy()
        else:
            section.curves=[helpers['Curve'](table,floor) for table,floor in zip(case['curves'].values(),case['floors'],strict=True)]
            history=section.initial()
            for row in case['trials'][:8]:
                field=np.asarray(row['field'])
                history=section.evaluate(field,history,np.array([0.,0.,0.,row['T_Nmm'],0.,0.]))[4]
        started=perf_counter()
        torque=10510000.
        spacing=0.02*abs(field[3])
        before=None
        trials=[]
        for attempt in range(90):
            target=field[3]+spacing
            predicted=field
            predicted_torque=torque
            if before is not None:
                previous_torque,previous_field=before
                ratio=(target-field[3])/(field[3]-previous_field[3])
                predicted=field+ratio*(field-previous_field)
                predicted_torque=torque+ratio*(torque-previous_torque)
            trial,new_torque,value,accepted,count=TestControlledStep(section,predicted,history,predicted_torque,target)
            trials.append({'T_Nmm':new_torque,'Qy_N':0.,'control':target,'field':trial.tolist(),
                           'accepted':accepted,'norm_MPa':float(value[1]),'forces':value[2].tolist(),'iterations':count})
            if accepted:
                before=torque,field
                torque,field,history=new_torque,trial,value[4]
                spacing=min(0.0001,1.5*spacing)
                if field[3]>=0.01 or torque<0.:break
            else:
                spacing*=0.5
                if spacing<1e-8:break
        output[name]={'trials':trials,'elapsed_s':perf_counter()-started}
        out.write_bytes((json.dumps(output,indent=2)+'\n').encode())
        a=[x for x in trials if x['accepted']]
        print(name,len(a),len(trials),'T range',min(x['T_Nmm'] for x in a),max(x['T_Nmm'] for x in a),flush=True)


if __name__=='__main__':
    root=Path.cwd()
    TestRun(root,root/'tmp/mvt-split-follow/TorqueBranch.json')
