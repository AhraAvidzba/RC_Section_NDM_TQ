"""ДЛЯ ТЕСТОВ: проверяет совместное нагружение после найденного восстановления чистого T."""

from copy import copy
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from time import perf_counter

import numpy as np


def TestRun(repo,out,only):
    """Возвращается к точному T после спада и затем меняет Qy и Mx по исходной траектории."""
    helpers=run_path(str(repo/'tmp/mvt-split-follow/Continue-MVT2Tabulated.py'))
    common=run_path(str(repo/'tmp/mvt-split-follow/Probe-TestASDEnergySection.py'))
    loader=run_path(str(repo/'tmp/mvt-split-follow/Probe-TestNdmCurveEquilibrium.py'))['TestLoadSection']
    seed,ndm_history,ndm_field=loader(repo)
    energy=json.loads((repo/'tmp/mvt-split-follow/ASDEnergySection.json').read_bytes())['cases']['ASDNDMEnergies125']
    branches=json.loads((repo/'tmp/mvt-split-follow/TorqueBranch.json').read_bytes())
    output=json.loads(out.read_bytes()) if only and out.exists() else {}
    for name,branch in branches.items():
        if only and name!=only:continue
        started=perf_counter()
        section=copy(seed)
        if name=='NDMCurves':history,field=ndm_history,ndm_field.copy()
        else:
            section.curves=[helpers['Curve'](table,floor) for table,floor in zip(energy['curves'].values(),energy['floors'],strict=True)]
            history=section.initial()
            for row in energy['trials'][:8]:
                field=np.asarray(row['field'])
                history=section.evaluate(field,history,np.array([0.,0.,0.,row['T_Nmm'],0.,0.]))[4]
        prefix=[]
        recovery=None
        minimum_index=min(range(len(branch['trials'])),key=lambda i:branch['trials'][i]['T_Nmm'])
        for row in branch['trials']:
            assert row['accepted']
            if len(prefix)>minimum_index and prefix[-1]['T_Nmm']<10510000.<=row['T_Nmm']:
                factor=(10510000.-prefix[-1]['T_Nmm'])/(row['T_Nmm']-prefix[-1]['T_Nmm'])
                predicted=field+factor*(np.asarray(row['field'])-field)
                target=np.array([0.,0.,0.,10510000.,0.,0.])
                trial,result,count,solved=common['TestForceStep'](section,predicted,history,target)
                recovery={'T_Nmm':10510000.,'Qy_N':0.,'accepted':solved,'field':trial.tolist(),
                          'norm_MPa':float(result[1]),'iterations':count,'forces':result[2].tolist()}
                if solved:field,history=trial,result[4]
                break
            field=np.asarray(row['field'])
            value=section.evaluate(field,history,np.array([0.,0.,0.,row['T_Nmm'],0.,0.]))
            assert abs(value[1]-row['norm_MPa'])<1e-10
            history=value[4]
            prefix.append(row)
        assert recovery is not None
        trials=[]
        if recovery['accepted']:
            step,q,before=2500.,0.,None
            for attempt in range(100):
                goal=min(q+step,80000.)
                target=np.array([0.,-396.*goal,0.,10510000.,0.,goal])
                predicted=field
                if before is not None:
                    oldq,oldfield=before
                    predicted=field+(goal-q)/(q-oldq)*(field-oldfield)
                trial,result,count,solved=common['TestForceStep'](section,predicted,history,target)
                row={'T_Nmm':10510000.,'Qy_N':goal,'accepted':solved,'field':trial.tolist(),
                     'norm_MPa':float(result[1]),'forces':result[2].tolist(),'iterations':count}
                trials.append(row)
                if solved:
                    before=q,field
                    q,field,history=goal,trial,result[4]
                    step=min(2500.,2.*step)
                    if q>=80000.:break
                else:
                    step*=0.5
                    if step<1.:break
        output[name]={'prefix':prefix,'recovery':recovery,'trials':trials,'elapsed_s':perf_counter()-started}
        out.write_bytes((json.dumps(output,indent=2)+'\n').encode())
        accepted=[r for r in trials if r['accepted']]
        print(name,'recovery',recovery['accepted'],'last_Qy_N',accepted[-1]['Qy_N'] if accepted else 0.,
              'accepted',len(accepted),'probes',len(trials),flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--case',choices=('NDMCurves','ASDExplicitEnergy'))
    args=parser.parse_args()
    repo=Path.cwd()
    TestRun(repo,repo/'tmp/mvt-split-follow/TorqueRecoverySection.json',args.case)
