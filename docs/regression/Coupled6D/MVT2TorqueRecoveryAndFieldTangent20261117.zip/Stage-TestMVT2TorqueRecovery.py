"""ДЛЯ ТЕСТОВ: готовит нативное продолжение кручения с необязательной касательной по полю."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,field_tangent):
    """Меняет только тестовый макрос и при явном выборе две проверки доступности резервной касательной."""
    here=Path(__file__).resolve().parent
    stage=run_path(str(here/'Stage-MVT2BarControl.py'))
    stage['stage'](repo,root,False,True,2e-5,'ndm_uniaxial')
    file=root/'tests/modTestMVT2GaussSpan.bas'
    code=file.read_text('utf-8-sig')
    code=stage['once'](code,'    expected(4) = TORQUE\n    For i = LBound(goals) To UBound(goals)',
        '    expected(4) = TORQUE\n    If Not TestRecoverMVT2Torque(operators, solver, atol, rtol, report, tracePath, stations) Then Exit Function\n    For i = LBound(goals) To UBound(goals)')
    code+=(here/'MVT2TorqueRecovery.bas.txt').read_text('utf-8')
    file.write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    p=root/'Preparation.json';prep=json.loads(p.read_bytes())
    prep['inputs']['tests/modTestMVT2GaussSpan.bas']=sha256(file.read_bytes()).hexdigest().upper()
    prep['torque_recovery_control']='own-field twist; 0.02 initial; maximum 0.0001; no external seeds'
    prep['field_tangent_before_steel_switch']=field_tangent
    if field_tangent:
        name='src/Solver/CCoupledNewtonSolver.cls'
        file=root/name
        code=file.read_text('utf-8-sig')
        code=stage['once'](code,'If mSteelBranchBuilds > 0 Then minimumFraction = STEEL_MIN_FRACTION',
                               'If mSteelBranchBuilds > 0 Or mSteelFieldTangents > 0 Then minimumFraction = STEEL_MIN_FRACTION')
        code=stage['once'](code,'If useSteelCorrection And mSteelBranchBuilds > 0 And Not useConcreteFieldTangent And _',
                               'If useSteelCorrection And Not useConcreteFieldTangent And _')
        file.write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
        prep['inputs'][name]=prep['source_core'][name]=sha256(file.read_bytes()).hexdigest().upper()
    p.write_bytes((json.dumps(prep,indent=2)+'\n').encode())
    print('NATIVE TORQUE RECOVERY PREPARED',field_tangent)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True);p.add_argument('--field-tangent',action='store_true')
    a=p.parse_args()
    TestStage(Path.cwd(),a.root,a.field_tangent)
