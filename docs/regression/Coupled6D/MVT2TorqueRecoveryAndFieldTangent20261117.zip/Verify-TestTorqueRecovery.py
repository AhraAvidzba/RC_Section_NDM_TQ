"""ДЛЯ ТЕСТОВ: проверяет продолжение кручения, возврат к точному T и резервную касательную VBA."""

from argparse import ArgumentParser
from copy import deepcopy
from gzip import compress,decompress
from hashlib import sha256
import json
from math import fsum,ulp
from io import BytesIO
from pathlib import Path
from runpy import run_path
from subprocess import PIPE,run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


ORIGIN=('MVT2NdmCurveConsistency20261117.zip','CE2DD6CE11F0C30BCAF46F3F14ABF35E25295B38762A4DBEDD90B0075DF85034')
FLOW=('MVT2EffectivePlasticFlow20261117.zip','42D0340DACD7FE6E3A9BE3592DD6464219A6F58832F43061EC59999553E12220')
BALANCE=('MVT2TabulatedActiveSteelVBA20261117.zip','87CECC42511E773F37611E4749AFD4947C299F5853893715F284FA9F498789FB')


def TestArchive(repo,entry):
    """Открывает закреплённые уравнения или материалы."""
    path=repo/'docs/regression/Coupled6D'/entry[0]
    assert sha256(path.read_bytes()).hexdigest().upper()==entry[1]
    return ZipFile(path)


def TestReferences(repo,root,temp):
    """Восстанавливает скалярный материал и независимое интегрирование всех уравнений."""
    common=run_path(str(root/'Verify-NativeMVT2BarControl.py'))
    refs=common['references'](repo,temp)
    with TestArchive(repo,FLOW) as z:
        curves=json.loads(z.read('MVT2ASDBackboneTables.json'))['ndm_uniaxial']
        initial=json.loads(z.read('MVT2EffectiveInitial.json'))['ndm_uniaxial']
    with TestArchive(repo,BALANCE) as z:
        env={'__name__':'__pinned__','__file__':'Verify-ActiveSteelWitness.py'}
        exec(compile(z.read(env['__file__']),env['__file__'],'exec'),env)
    tools,material,mesh,support,*_=refs
    utility,backbone,rotation,_=support
    floors=[-30000.*x for x in initial[3]]
    support=utility,backbone,rotation,[backbone['Backbone'](x,f) for x,f in zip(curves.values(),floors,strict=True)]
    return common,refs,curves,floors,support,env['measure']


def TestVariant(root,variant,common,refs,support,measure):
    """Проверяет точные два изменения касательной и каждое собственное принятое состояние VBA."""
    tools,material,mesh,_,_,original,_,_=refs
    expected=deepcopy(original)
    code=root/variant/'src/Solver/CCoupledNewtonSolver.cls'
    source=(root/'Base/src/Solver/CCoupledNewtonSolver.cls').read_bytes()
    assert sha256(source).hexdigest().upper()==original['source_core']['src/Solver/CCoupledNewtonSolver.cls']
    if variant=='Field':
        text=source.decode('utf-8-sig').replace('\r\n','\n')
        for before,after in (
            ('If mSteelBranchBuilds > 0 Then minimumFraction = STEEL_MIN_FRACTION',
             'If mSteelBranchBuilds > 0 Or mSteelFieldTangents > 0 Then minimumFraction = STEEL_MIN_FRACTION'),
            ('If useSteelCorrection And mSteelBranchBuilds > 0 And Not useConcreteFieldTangent And _',
             'If useSteelCorrection And Not useConcreteFieldTangent And _')):
            assert text.count(before)==1
            text=text.replace(before,after)
        source=text.replace('\n','\r\n').encode('utf-8-sig')
        expected['source_core']['src/Solver/CCoupledNewtonSolver.cls']=sha256(source).hexdigest().upper()
    assert code.read_bytes()==source
    prep=common['process'](root/variant,expected)
    assert prep['torque_recovery_control']=='own-field twist; 0.02 initial; maximum 0.0001; no external seeds'
    tables=tools['read_operators']((root/variant/'Native/Operators.csv').read_bytes())
    frames=tools['read_tensor_frames']((root/variant/'Native/MVTGaussMixed.Tensor.csv').read_bytes(),45)
    for key in 'GLBSR':assert tables[key]==refs[6][key]
    control={}
    for row in (root/variant/'Native/MVTGaussMixed.csv').read_bytes().splitlines():
        if row.startswith(b'MVT2_TORQUE_CONTROL_TRIAL;'):
            _,phase,target,solved,factor,*_=row.decode('cp1251').split(';')
            control[phase]=float(target),solved=='True',float(factor)
    zero=(0.,)*6
    history={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
    strains,stresses=[],[]
    error=max_norm=0.
    lowest=10510000.
    for phase,(torque,q,center) in frames.items():
        field=tables['F'][phase]
        if phase.startswith('Torque') and phase!='TorqueRecovered':
            target,accepted,factor=control[phase]
            assert accepted and abs(field[3]-target)<1e-15
            torque=factor*10510000.;q=0.
            lowest=min(lowest,torque)
        if phase=='TorqueRecovered':torque,q=10510000.,0.
        history,net,c=material(field,tables,mesh[1],support,history)
        error=max(error,max(abs(a-b) for p in c for a,b in zip(c[p],center[p],strict=True)))
        measure.__globals__['TORQUE']=torque
        norm,tol=measure(field,q,net,tables,mesh)
        assert norm<=tol,(variant,phase,norm,tol)
        max_norm=max(max_norm,norm)
        strains.append([history[s,p][0] for s in (0,1,-1) for p in mesh[1]])
        point=[]
        for s in (0,1,-1):
            for p in mesh[1]:
                sigma=net[s,p]
                if p>25:
                    eps,_,_,plastic=history[s,p]
                    axial=200000.*(fsum(a*d for a,d in zip(eps,mesh[1][p][3:],strict=True))-plastic)
                    sigma=tuple(axial*d-v for d,v in zip(mesh[1][p][3:],sigma,strict=True))
                point.append(sigma)
        stresses.append(point)
    assert error<8e-7
    assert all(key in frames for key in ('R8','TorqueRecovered','S2'))
    last=max(value[1] for value in frames.values())
    assert last==({'Base':58437.5,'Field':67812.5}[variant])
    radius=mesh[0][3]
    stats={'fields':len(frames),'last_Qy_N':last,'max_native_scalar_stress_error_MPa':error,
           'maximum_norm_MPa':max_norm,'minimum_followed_T_Nmm':lowest,
           'initial_twist_mrad_per_m':tables['F']['R8'][3]*1e6/radius,
           'recovered_twist_mrad_per_m':tables['F']['TorqueRecovered'][3]*1e6/radius}
    return tables,frames,strains,stresses,stats


def TestIndependent(repo,root,refs,support,measure,curves,floors):
    """Проверяет контролируемые ветви и совместные силовые пробы независимого решателя."""
    tools,material,mesh,*_=refs
    import numpy as np
    assert np.__version__=='2.3.5'
    numerical=run_path(str(root/'Continue-MVT2Tabulated.py'))
    archive=BytesIO()
    with ZipFile(archive,'w') as z:
        for file in ('Operators.csv','MVTGaussMixed.csv'):
            z.writestr('Matched/Native/'+file,(root/'Base/Native'/file).read_bytes())
    material_input=[{'ndm_uniaxial':curves},{'ndm_uniaxial':[None,None,None,[-f/30000. for f in floors]]}]
    with ZipFile(archive) as z:section=numerical['Section'](z,material_input,'ndm_uniaxial')
    with TestArchive(repo,ORIGIN) as z:
        tables=tools['read_operators'](z.read('Native/Operators.csv'))
        origin=tools['read_tensor_frames'](z.read('Native/MVTGaussMixed.Tensor.csv'),45)
    energy=json.loads((root/'ASDEnergySection.json').read_bytes())['cases']['ASDNDMEnergies125']
    branches=json.loads((root/'TorqueBranch.json').read_bytes())
    recovered=json.loads((root/'TorqueRecoverySection.json').read_bytes())
    result={}
    for name,case in branches.items():
        chosen,floor=(curves,floors) if name=='NDMCurves' else (energy['curves'],energy['floors'])
        utility,backbone,rotation,_=support
        laws=utility,backbone,rotation,[backbone['Backbone'](x,f) for x,f in zip(chosen.values(),floor,strict=True)]
        zero=(0.,)*6
        h={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
        section.curves=[numerical['Curve'](x,f) for x,f in zip(chosen.values(),floor,strict=True)]
        numerical_history=section.initial()
        for i,(phase,(torque,q,_)) in enumerate(origin.items()):
            if name=='NDMCurves':field=tables['F'][phase]
            else:field=energy['trials'][i]['field']
            h,net,_=material(field,tables,mesh[1],laws,h)
            numerical_history=section.evaluate(np.asarray(field),numerical_history,np.array([0.,0.,0.,torque,0.,q]))[4]
            measure.__globals__['TORQUE']=torque
            norm,tol=measure(field,q,net,tables,mesh)
            assert norm<=tol
        prior=h
        numerical_prior=numerical_history
        rows=case['trials']
        assert len(rows)==90 and all(r['accepted'] and abs(r['field'][3]-r['control'])<1e-15 for r in rows)
        _,a,b,error=TestBoundedHistory(rows,tables,material,mesh,laws,measure,prior,section,numerical_prior)
        assert a==90 and b==0
        follow=recovered[name]
        assert follow['prefix']==rows[:len(follow['prefix'])] and len(follow['prefix'])==48
        chain=follow['prefix']+[follow['recovery']]+follow['trials']
        _,a,b,err=TestBoundedHistory(chain,tables,material,mesh,laws,measure,prior,section,numerical_prior)
        assert follow['recovery']['accepted'] and follow['recovery']['T_Nmm']==10510000.
        accepted=[r for r in follow['trials'] if r['accepted']]
        result[name]={'controlled_accepted':90,'recovery_chain_accepted':a,'recovery_chain_rejected':b,
                      'last_Qy_N':accepted[-1]['Qy_N'],'maximum_norm_difference_MPa':max(error,err)}
    return result


def TestBoundedHistory(rows,tables,material,mesh,support,measure,history,section,numerical_history):
    """Проверяет материал и объясняет разницу норм действием исходных линейных операторов на разницу тензоров."""
    import numpy as np
    coefficient=1.
    for j in range(60):
        value=fsum(abs(tables['S'][p,k][j])+2.*abs(tables['R'][p,k][j])/.002 for p in mesh[1] for k in range(1,7))
        if j>=56:value*=30000.
        coefficient=max(coefficient,value)
    accepted=rejected=0
    maximum=0.
    for row in rows:
        proposed,net,_=material(row['field'],tables,mesh[1],support,history)
        target=np.array([0.,-396.*row['Qy_N'],0.,row['T_Nmm'],0.,row['Qy_N']])
        current=section.evaluate(np.asarray(row['field']),numerical_history,target)
        raw={(s,p):tuple(current[3][i,p-1]) for i,s in enumerate((0,1,-1)) for p in mesh[1]}
        stress_error=max(abs(a-b) for key in net for a,b in zip(net[key],raw[key],strict=True))
        assert stress_error<8e-7,(row['Qy_N'],stress_error)
        measure.__globals__['TORQUE']=row['T_Nmm']
        norm,tol=measure(row['field'],row['Qy_N'],net,tables,mesh)
        numerical_norm,_=measure(row['field'],row['Qy_N'],raw,tables,mesh)
        assert abs(numerical_norm-row['norm_MPa'])<1e-9
        difference={key:tuple(a-b for a,b in zip(net[key],raw[key],strict=True)) for key in net}
        measure.__globals__['TORQUE']=0.
        bound,_=measure([0.]*60,0.,difference,tables,mesh)
        magnitude=max(1.,max(abs(v) for key in net for v in (*net[key],*raw[key])))
        rounding=512.*ulp(magnitude)*coefficient
        assert abs(norm-numerical_norm)<=bound+rounding
        assert bool(norm<=tol)==bool(numerical_norm<=tol)==row['accepted']
        maximum=max(maximum,abs(norm-row['norm_MPa']))
        if row['accepted']:
            history,numerical_history=proposed,current[4]
            accepted+=1
        else:rejected+=1
    return history,accepted,rejected,maximum


def TestCapture(repo,root,interpreter,target):
    """Подаёт в OpenSees полные истории точек по небольшим последовательным партиям."""
    worker=root/'Verify-TestASDCalibration.py'
    with TemporaryDirectory(dir=root) as name:
        temp=Path(name)
        common,refs,curves,floors,support,measure=TestReferences(repo,root,temp)
        command=support[0]['read_inputs'](repo,temp)[3][0]['ndm_uniaxial']
        results={}
        for variant in ('Base','Field'):
            _,_,frames,_,_=TestVariant(root,variant,common,refs,support,measure)
            values=[[] for _ in frames]
            for start in range(0,135,5):
                file=temp/'Part.json'
                run([str(interpreter),'-B','-X','utf8',str(worker),'--worker',str(file)],
                    input=json.dumps([command,[f[start:start+5] for f in frames]]).encode(),
                    stdout=PIPE,stderr=PIPE,timeout=45,check=True,creationflags=0x08000000 if sys.platform=='win32' else 0)
                data=json.loads(file.read_bytes())
                for row,new in zip(values,data['stress'],strict=True):row.extend(new)
            results[variant]={'stress':values,'strain_sha256':sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest().upper()}
        target.write_bytes(compress(json.dumps({'engine':'OpenSees 3.8.0','commands':command,'variants':results},separators=(',',':')).encode(),mtime=0))


def TestVerify(repo,root,wire,temp):
    """Сопоставляет внешний материал, собственную VBA-ветвь и независимое продолжение."""
    common,refs,curves,floors,support,measure=TestReferences(repo,root,temp)
    data=json.loads(decompress(wire.read_bytes()))
    assert data['engine']=='OpenSees 3.8.0'
    assert data['commands']==support[0]['read_inputs'](repo,temp)[3][0]['ndm_uniaxial']
    result={}
    for variant in ('Base','Field'):
        _,_,frames,expected,stats=TestVariant(root,variant,common,refs,support,measure)
        recorded=data['variants'][variant]
        assert recorded['strain_sha256']==sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest().upper()
        error=max(abs(a-b) for x,y in zip(expected,recorded['stress'],strict=True)
                  for p,q in zip(x,y,strict=True) for a,b in zip(p,q,strict=True))
        assert error<8e-7
        stats['max_OpenSees_stress_error_MPa']=error
        stats['OpenSees_states']=len(frames)*135
        result[variant]=stats
    independent=TestIndependent(repo,root,refs,support,measure,curves,floors)
    assert independent['NDMCurves']['last_Qy_N']==74895.01953125
    return {'native':result,'independent':independent,'physical_limit_established':False,
            'recovered_history_equivalent_to_experimental_force_control':False,'production_material_changed':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--capture',type=Path);p.add_argument('--python',type=Path);p.add_argument('--wire',type=Path);p.add_argument('--out',type=Path)
    a=p.parse_args()
    if a.capture:TestCapture(a.repo.resolve(),a.root.resolve(),a.python.resolve(),a.capture)
    else:
        with TemporaryDirectory(dir=a.root) as name:proof=TestVerify(a.repo.resolve(),a.root.resolve(),a.wire,Path(name))
        a.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
        print('TORQUE RECOVERY AND NATIVE FIELD TANGENT VERIFIED')
