﻿# Собирает изолированный VBA-кандидат и проверяет его после повторного открытия.
param([ValidateSet('Compile','Package','Native','Export','Verify','All')][string]$Stage='All')
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$tools=Join-Path $root 'tools/build_workbook'
$region='docs/regression'
$draft="$region/Compiled.xlsm"
$candidate="$region/RC_Section_NDM.xlsm"
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$protected=@{25900=[long]639301894503450644;32172=[long]639304180394977771;36308=[long]639304159664638157;37736=[long]639304161194652457}
$previousTemp=$env:TEMP;$previousTmp=$env:TMP
$previousExportRoot=$env:NDM_SECANT_EXPORT_ROOT;$previousSourceRoot=$env:NDM_LOAD_PATH_VERIFIER_ROOT

# Проверяет свободные ресурсы и защищает все подтверждённые пользовательские экземпляры.
function Assert-IsolatedOfficeReady([string]$Phase) {
    $others=@(Get-Process Excel -ErrorAction SilentlyContinue)
    foreach($item in $others) {
        $ticks=$item.StartTime.ToUniversalTime().Ticks
        if ($protected.ContainsKey($item.Id) -and $protected[$item.Id] -eq $ticks) {continue}
        $instance=Get-CimInstance Win32_Process -Filter ('ProcessId='+$item.Id)
        if (!$instance -or !$item.MainWindowHandle -or [math]::Abs(($instance.CreationDate-$item.StartTime).TotalMilliseconds) -ge 100) {continue}
        $parent=Get-Process -Id $instance.ParentProcessId -ErrorAction SilentlyContinue
        if ($parent -and $parent.ProcessName -ieq 'explorer' -and $parent.SessionId -eq $item.SessionId -and
            $parent.StartTime -lt $item.StartTime -and $instance.CommandLine -notmatch '[/\-]embedding(?:\s|$)') {$protected[$item.Id]=$ticks}
    }
    $unknown=@($others | Where-Object {!$protected.ContainsKey($_.Id) -or $protected[$_.Id] -ne $_.StartTime.ToUniversalTime().Ticks})
    $memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
    $state=[ordered]@{phase=$Phase;utc=[DateTimeOffset]::UtcNow.ToString('o');ramMiB=$memory.AvailableMBytes;
        freeCommitGiB=($memory.CommitLimit-$memory.CommittedBytes)/1GB;freeC_MiB=(Get-PSDrive C).Free/1MB;freeD_GiB=(Get-PSDrive D).Free/1GB;
        excel=@($others|Select-Object Id,StartTime,@{Name='ProtectedUser';Expression={$protected[$_.Id] -eq $_.StartTime.ToUniversalTime().Ticks}})}
    $state|ConvertTo-Json -Depth 5 -Compress|Add-Content -LiteralPath "$region/Run.ndjson" -Encoding utf8
    if ($unknown.Count -or $state.ramMiB -lt 6500 -or $state.freeCommitGiB -lt 8 -or $state.freeC_MiB -lt 80 -or $state.freeD_GiB -lt 4) {
        throw "Нет свободного окна для этапа $Phase. Подробности в Run.ndjson."
    }
}

# Подтверждает закрытие по зафиксированной личности VBA COM-процесса.
function Save-OfficeClosure([string]$Log,[string]$Output) {
    $pattern='^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$'
    $owner=@(Get-Content -LiteralPath $Log -Encoding utf8 | Where-Object {$_ -match $pattern})
    if ($owner.Count -ne 1 -or $owner[0] -notmatch $pattern) {throw "Личность Excel отсутствует в $Log."}
    $workerId=[int]$Matches[1];$workerTicks=[long]$Matches[2]
    if ($workerId -le 0 -or $workerTicks -le 0 -or $protected.ContainsKey($workerId)) {throw 'Недопустимая личность Excel.'}
    $deadline=[DateTime]::UtcNow.AddSeconds(20)
    do {
        $worker=Get-Process -Id $workerId -ErrorAction SilentlyContinue
        if (!$worker) {break}
        if ($worker.ProcessName -ine 'excel' -or $worker.StartTime.ToUniversalTime().Ticks -ne $workerTicks) {throw 'Личность дочернего Excel изменилась.'}
        Start-Sleep -Milliseconds 200
    } while ([DateTime]::UtcNow -lt $deadline)
    if ($worker) {throw 'Дочерний Excel ещё работает.'}
    [ordered]@{State='Absent';PID=$workerId;StartTicksUTC=[string]$workerTicks} |
        ConvertTo-Json | Set-Content -LiteralPath $Output -Encoding utf8
}

# Передаёт подкоманды упаковщику без повторного открытия COM.
function Invoke-Package([string]$Action) {
    & python -B -X utf8 (Join-Path $root 'Verify-CoupledGaugeRelease.py') $Action
    if ($LASTEXITCODE -ne 0) {throw "Не прошла сверка $Action."}
}

Push-Location -LiteralPath $root
try {
    & python -B -X utf8 (Join-Path $root 'Prepare-CoupledGaugeRelease.py')
    if ($LASTEXITCODE -ne 0) {throw 'Не совпадают сохранённые входы сборки.'}
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    if ($Stage -in 'All','Compile','Native','Export') {
        $temp=Join-Path $root 'Temp'
        [void][IO.Directory]::CreateDirectory($temp)
        $env:TEMP=$temp;$env:TMP=$temp
        if ((Join-Path $temp 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
            throw 'Путь к временной книге превышает допустимую длину.'
        }
    }
    if ($Stage -in 'All','Compile') {
        if (Test-Path -LiteralPath "$region/Compile.log") {throw 'Доказательства компиляции уже существуют.'}
        if ((Get-FileHash -LiteralPath $draft).Hash -cne $prep.base_sha256.'RC_Section_NDM.xlsm') {throw 'Подготовленная копия изменилась до компиляции.'}
        Assert-IsolatedOfficeReady 'Compile'
        & (Join-Path $tools 'Update-IsolatedOptimizerCode.ps1') -WorkbookPath $draft -ModuleNames @($prep.modules) |
            Tee-Object -FilePath "$region/Compile.log"
        Save-OfficeClosure "$region/Compile.log" "$region/CompileClosure.json"
    }
    if ($Stage -in 'All','Package','Native','Export') {Invoke-Package 'package'}
    if ($Stage -in 'All','Native') {
        if (Test-Path -LiteralPath "$region/DirectedNative.txt") {throw 'Нативный отчёт уже существует.'}
        Assert-IsolatedOfficeReady 'Native'
        $macros=@($prep.native_plan | ForEach-Object {$_.macro})
        & $legacy -NoProfile -ExecutionPolicy Bypass -File (Join-Path $tools 'Run-Audit03Watchdog.ps1') -SourceWorkbook $candidate `
            -ReportPath "$region/DirectedNative.txt" -Macro ($macros -join ',') -TimeoutSeconds 260 -FailFast
        if ($LASTEXITCODE -ne 0) {throw 'Нативные проверки завершились ошибкой.'}
        $closure=Get-Content -LiteralPath "$region/DirectedNative.txt.ProcessClosure.json" -Raw|ConvertFrom-Json
        if (!$closure.Passed -or !$closure.RunnerCleanupValid -or $closure.Closure.FinalState.State -cne 'Absent') {throw 'Не подтверждено закрытие нативного Excel.'}
    }
    if ($Stage -in 'All','Export') {
        if (Test-Path -LiteralPath "$region/Export.log") {throw 'Доказательства выгрузки уже существуют.'}
        $exportArea="$region/Audit03/ExportProof"
        [void][IO.Directory]::CreateDirectory((Join-Path $root $exportArea))
        $exportBook="$exportArea/RC_Section_NDM.xlsm"
        $exportFile="$exportArea/VBA_All_Code.txt"
        if (!(Test-Path -LiteralPath $exportBook)) {Copy-Item -LiteralPath $candidate -Destination $exportBook}
        if ((Get-FileHash -LiteralPath $exportBook).Hash -cne (Get-FileHash -LiteralPath $candidate).Hash) {
            throw 'Копия для read-only выгрузки отличается от кандидата.'
        }
        Assert-IsolatedOfficeReady 'Export'
        $env:NDM_SECANT_EXPORT_ROOT=$root
        $env:NDM_LOAD_PATH_VERIFIER_ROOT=$root
        & $legacy -NoProfile -ExecutionPolicy Bypass -File (Join-Path $tools 'Export-VerifiedVBA.ps1') `
            -WorkbookPath $exportBook -OutputPath $exportFile | Tee-Object -FilePath "$region/Export.log"
        if ($LASTEXITCODE -ne 0) {throw 'Выгрузка VBA завершилась ошибкой.'}
        Save-OfficeClosure "$region/Export.log" "$region/ExportClosure.json"
        Copy-Item -LiteralPath $exportFile -Destination "$region/VBA_All_Code.txt"
        & $legacy -NoProfile -ExecutionPolicy Bypass -File (Join-Path $tools 'Verify-SolverSource.ps1') `
            -ExportPath "$region/VBA_All_Code.txt" -ReportPath "$region/SolverSourceEquality.json"
        if ($LASTEXITCODE -ne 0) {throw 'Модули не совпали с сохранёнными исходниками.'}
    }
    if ($Stage -in 'All','Verify') {Invoke-Package 'verify'}
}
finally {
    $env:TEMP=$previousTemp;$env:TMP=$previousTmp
    $env:NDM_SECANT_EXPORT_ROOT=$previousExportRoot;$env:NDM_LOAD_PATH_VERIFIER_ROOT=$previousSourceRoot
    Pop-Location
}
