"""Replace the workbook and its export only after directed release verification."""
import argparse
from datetime import datetime
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
from tempfile import NamedTemporaryFile

HERE = Path(__file__).resolve().parent
OUT = HERE / "docs/regression"
TARGETS = {"RC_Section_NDM.xlsm": ("package", "candidate_sha256"),
           "VBA_All_Code.txt": ("reopened_export", "export_sha256")}

def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()

def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def prepare_file(source, destination):
    with NamedTemporaryFile(prefix=".ndm-gauge-", suffix=".pending",
                            dir=destination.parent, delete=False) as output:
        pending = Path(output.name)
        try:
            with source.open("rb") as origin:
                shutil.copyfileobj(origin, output)
            output.flush()
            os.fsync(output.fileno())
        except BaseException:
            output.close()
            pending.unlink(missing_ok=True)
            raise
    return pending

def publish(repo):
    proof_path = OUT / "ReleaseVerification.json"
    proof = read_json(proof_path)
    prep = read_json(HERE / "Preparation.json")
    assert all(digest(HERE / name) == expected for name, expected in prep['controls'].items())
    assert proof["status"] == "PASS" and proof["package"]["preparation_sha256"] == digest(HERE / "Preparation.json")
    claimed_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
    assert claimed_head == prep["source_git_head"], "Worktree HEAD has changed since the build"
    for file in prep["sources"]:
        assert digest(repo / file) == prep["frozen"][file], file

    folder = repo / "workbook/output"
    assert folder.resolve(strict=True) == folder and folder.is_dir()
    backup = OUT / "BeforePublication"
    pending, replaced, records = {}, [], []
    assert not backup.exists() and not (OUT / "Publication.json").exists()
    for name,(section, key) in TARGETS.items():
        assert digest(folder / name) == prep["base_sha256"][name], f"Local baseline changed: {name}"
        assert digest(OUT / name) == proof[section][key], f"Candidate changed: {name}"
    backup.mkdir()
    try:
        for name,(section,key) in TARGETS.items():
            shutil.copyfile(folder / name, backup / name)
            assert digest(backup / name) == prep["base_sha256"][name]
            path = folder / name
            pending[name] = prepare_file(OUT / name, path)
            assert digest(pending[name]) == proof[section][key]
            records.append({"path": str(path),"replaced_sha256":prep["base_sha256"][name],
                            "actual_sha256": proof[section][key]})
        for name, path in pending.items():
            assert digest(folder / name) == prep["base_sha256"][name], f"File changed before publication: {name}"
            os.replace(path, folder / name)
            replaced.append(name)
        assert all(digest(Path(row["path"])) == row["actual_sha256"] for row in records)
        receipt = {"status":"PASS", "date":datetime.now().astimezone().isoformat(),
                   "source_git_rev":claimed_head, "release_verification_sha256":digest(proof_path),
                   "directed_report_sha256":digest(OUT/"DirectedNative.txt"), "files":records}
        (OUT / "Publication.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    except BaseException:
        for name in reversed(replaced):
            os.replace(prepare_file(backup / name,folder / name),folder / name)
        raise
    finally:
        for path in pending.values():
            path.unlink(missing_ok=True)
    print("PUBLISHED", digest(OUT/"Publication.json"))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    publish(parser.parse_args().repo.resolve(strict=True))