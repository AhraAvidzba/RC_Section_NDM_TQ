# Сборка книги с поправкой кинематического множителя

Вход — рабочая книга 462546E8EE57451AC32F95128972E36E245517A3CADDB5D51B888DCBF0392FA2 и её выгрузка VBA 65D3C407ECE8AB82AF652A28C90068E0D0847FF3DD310633D8DA8C570D8D5FB7. Исходная ревизия 006c1ef69fa4ede80867414c683c8d5ae8acb5f7. Подготовка фиксирует точные байты выбранных исходников, контрольных сценариев и частей XLSM.

Из корня репозитория:

    $release = 'D:/CodexScratch/RC_Section_NDM_TQ/CoupledGaugeRelease'
    $repo = (Get-Location).Path
    python -B -X utf8 "$release/Prepare-CoupledGaugeRelease.py" --check-current $repo
    & "$release/Run-CoupledGaugeRelease.ps1" -Stage All
    python -B -X utf8 "$release/Prepare-CoupledGaugeRelease.py" --check-current $repo

В новой папке заморозка выполняется один раз:

    python -B -X utf8 "$release/Prepare-CoupledGaugeRelease.py" --stage-from $repo --check-current $repo

NativeSuites.json перечисляет 12 направленных макросов с ожидаемыми 1644 утверждениями. Повтор подтверждённого пакета в Test-ReleaseProofOffline.py проверяет разбор сохранённых квитанций Excel, сверку VBA и отказ при изменении контрольного хеша XML или числа утверждений.

Компиляция импортирует четыре компонента в копию книги. Упаковка переносит единственную изменённую VBA-часть поверх исходного пакета и проверяет CRC, состав, порядок и байты остальных 121 части. Проверочный экземпляр открывает упакованную книгу отдельной копией. Ещё один экземпляр открывает её для чтения и выгружает 225 компонентов. Для трёх запусков сохраняются отдельные сведения о владельцах процессов и завершении Excel. Проверки не охватывают полный ON/OFF, нативный AutoCAD или визуальную приёмку.

Локальная установка проверенной пары:

    python -B -X utf8 "$release/Publish-VerifiedWorkbook.py" $repo

Установка сверяет исходники, прежние файлы и кандидатов, сохраняет резервные копии, записывает оба выходных файла с проверкой SHA-256 и возвращает заменённые файлы при исключении. Итог записан в docs/regression/Publication.json каталога сборки. Привязку к сборке, проверкам и выгрузке хранит docs/regression/ReleaseVerification.json.

## Независимая проверка архива

Распакуйте CoupledGaugeReleasePortable.zip в новый каталог. Передайте два каталога, каждый с парой RC_Section_NDM.xlsm и VBA_All_Code.txt, и снимок исходников ревизии 006c1ef69fa4ede80867414c683c8d5ae8acb5f7. Исходная пара соответствует fb6897d. После локальной установки каталог кандидата находится в workbook/output. Файлы обеих пар предоставляются отдельно.

Из корня репозитория можно извлечь входные пары и исходники по зафиксированным ревизиям:

    git archive --format=zip -o GaugeBaseline.zip fb6897d -- workbook/output/RC_Section_NDM.xlsm workbook/output/VBA_All_Code.txt
    git archive --format=zip -o GaugeSource.zip 006c1ef69fa4ede80867414c683c8d5ae8acb5f7 -- src/Solver/CCoupledElasticState.cls src/Solver/CCoupledNewtonSolver.cls src/Solver/CCoupledDeformationContinuation.cls tests/modTestCoupledElasticState.bas
    Expand-Archive -LiteralPath GaugeBaseline.zip -DestinationPath GaugeBaseline
    Expand-Archive -LiteralPath GaugeSource.zip -DestinationPath GaugeSource
    python -B -X utf8 GaugeEvidence/Verify-PortableEvidence.py --baseline GaugeBaseline/workbook/output --candidate workbook/output --source GaugeSource

Офлайн-сценарий заново сверяет четыре исходных файла по SHA-256, целые две пары входов, CRC, состав и байты всех 122 частей обеих книг. Он заново сравнивает тело и тип каждого из 225 компонентов двух экспортов VBA, включая перечень изменений только регистра. Он также перепроверяет привязку всех отчётов к хешу кандидата, 12 макросов и 1644 сохранённых утверждения, а также PID и время запуска трёх экземпляров по квитанциям. Компиляция, запуск макросов и запись живого экспорта для этого анализа подтверждаются архивными протоколами. Чтобы повторить эти действия, используется отдельный сценарий сборки и настольный Excel.
