"""ДЛЯ ТЕСТОВ: измеряет зависимость ASD-ответа от дробления заданной истории деформаций."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np


FLOW = ('MVT2EffectivePlasticFlow20261117.zip', '42D0340DACD7FE6E3A9BE3592DD6464219A6F58832F43061EC59999553E12220')
SECTION = ('MVT2TabulatedActiveSteel20261117.zip', '12AC8259874E45568C5B04BB110F4C17D18FDEBD617532A30DE34C262B999792')
NATIVE = ('MVT2TabulatedFlowNative20261117.zip', '0DDB248B0B2F61AF814F1E70EAE55CABE46CC07C261E8E8043A8D8A960850F49')
NDM = ('MVT2NdmCurveConsistency20261117.zip', 'CE2DD6CE11F0C30BCAF46F3F14ABF35E25295B38762A4DBEDD90B0075DF85034')


def TestArchive(repo, entry):
    """Читает только закреплённый научный контроль."""
    raw = (repo/'docs/regression/Coupled6D'/entry[0]).read_bytes()
    assert sha256(raw).hexdigest().upper() == entry[1]
    return ZipFile(BytesIO(raw))


def TestInputs(repo):
    """Загружает обе калибровки и одни и те же восемь нативных полей НДМ."""
    with TestArchive(repo, FLOW) as archive:
        material = [json.loads(archive.read(name)) for name in ('MVT2ASDBackboneTables.json', 'MVT2EffectiveInitial.json')]
    with TestArchive(repo, SECTION) as archive:
        scope = {'__name__': '__pinned__', '__file__': 'Continue-MVT2Tabulated.py'}
        exec(compile(archive.read('Continue-MVT2Tabulated.py'), scope['__file__'], 'exec'), scope)
    with TestArchive(repo, NDM) as archive:
        fields = [(row[1], np.array(row[2:], dtype=float)) for row in scope['records'](archive, 'Native/Operators.csv', 'F')]
        expected = {}
        for row in scope['records'](archive, 'Native/MVTGaussMixed.Tensor.csv'):
            if row[0] == 'FRAME':
                phase = row[1]
                expected[phase] = np.zeros((45, 6))
            elif row[0] == 'POINT':
                expected[phase][int(row[1])-1] = np.array(row[8:], dtype=float)
    assert [name for name, _ in fields] == [f'R{i}' for i in range(1, 9)]
    with TestArchive(repo, NATIVE) as archive:
        sections = {mode: scope['Section'](archive, material, mode) for mode in ('ndm_uniaxial', 'default')}
    return sections, fields, expected


def TestNet(section, response):
    """Объединяет бетон и направленное замещение арматуры без смены знаков."""
    concrete, steel = response[:2]
    net = concrete.copy()
    net[:, 25:] += steel[..., None]*section.directions
    return net


def TestRun(section, fields, subdivisions):
    """Дробит только материальную историю фиксированных полей, не решая равновесие заново."""
    history = section.initial()
    previous = np.zeros(60)
    endpoints, concrete_endpoints = {}, {}
    for name, field in fields:
        for i in range(1, subdivisions+1):
            current = field if i == subdivisions else previous+(i/subdivisions)*(field-previous)
            response = section.nominal(current, history)
            history = response[3]
        previous = field
        endpoints[name] = TestNet(section, response)
        concrete_endpoints[name] = response[0][0].copy()
        concrete_endpoints[name][25:] *= -1.
    original = endpoints['R8']
    first = section.nominal(fields[-1][1], history)
    after = TestNet(section, first)
    error = after-original
    where = np.unravel_index(np.argmax(np.abs(error)), error.shape)
    repeats = [float(np.max(np.abs(error)))]
    history = first[3]
    for _ in range(9):
        next_response = section.nominal(fields[-1][1], history)
        other = TestNet(section, next_response)
        repeats.append(float(np.max(np.abs(other-after))))
        after, history = other, next_response[3]
    return {'subdivisions': subdivisions, 'zero_increment_change_MPa': repeats,
            'largest_zero_change_at': {'side': (0, 1, -1)[where[0]], 'point': int(where[1])+1, 'component': int(where[2])+1},
            'endpoint_resultants_N_Nmm': section.loads(original[0]).tolist()}, endpoints, concrete_endpoints


def TestProbe(repo, output, maximum):
    """Сопоставляет обе калибровки при неизменных геометрии и полях деформаций."""
    sections, fields, expected = TestInputs(repo)
    results, end = {}, {}
    for mode, section in sections.items():
        series, prior = [], None
        for power in range(maximum+1):
            result, endpoints, concrete = TestRun(section, fields, 2**power)
            if prior is not None:
                result['endpoint_difference_from_previous_refinement_MPa'] = float(np.max(np.abs(endpoints['R8']-prior)))
            prior = endpoints['R8']
            if mode == 'ndm_uniaxial' and power == 0:
                error = max(float(np.max(np.abs(value-expected[name]))) for name, value in concrete.items())
                assert error < 8e-7, error
                result['native_endpoint_stress_error_MPa'] = error
                assert abs(result['zero_increment_change_MPa'][0]-.06712) < .00001
            series.append(result)
            print(mode, 2**power, 'zero change', result['zero_increment_change_MPa'][0], flush=True)
        results[mode] = series
        end[mode] = prior.tolist()
    proof = {'histories': results, 'finest_endpoints': end, 'fixed_strain_history': True,
             'global_equilibrium_resolved': False, 'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode('utf-8'))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--maximum-power', type=int, default=8)
    args = parser.parse_args()
    TestProbe(args.repo.resolve(), args.out.resolve(), args.maximum_power)
