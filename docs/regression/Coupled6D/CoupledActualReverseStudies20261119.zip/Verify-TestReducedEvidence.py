"""ДЛЯ ТЕСТОВ: проверяет нативный нелинейный прогноз, его VBA и полное равновесие всех принятых полей."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import numpy as np


def TestRead(path):
    """Читает протоколы Windows PowerShell и Python с сохранением численных значений."""
    return json.loads(path.read_text('utf-8-sig'))


def TestSource(repo, root):
    """Читает точную исходную книгу из уже закреплённого архива, не подменяя её текущим файлом."""
    source = TestRead(root/'SourceBook.json')
    raw = (repo/'docs/regression/Coupled6D'/source['archive']).read_bytes()
    assert sha256(raw).hexdigest().upper() == source['sha256']
    with ZipFile(BytesIO(raw)) as archive:
        book = archive.read(source['entry'])
    digest = Path(source['entry']).stem
    assert sha256(book).hexdigest().upper() == digest
    return book, digest


def TestNative(repo, root, source_book, digest, key, helper, body, reader, gauss):
    """Сверяет фактический VBA с подготовленными файлами и подтверждает закрытие собственных Excel."""
    folder = root/key
    prep, compiler = TestRead(folder/'Preparation.json'), TestRead(folder/'CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and len(compiler['Modules']) == 11
    assert compiler['ProductionSHA256'] == prep['source_book_sha256'] == digest
    for name, expected in prep['inputs'].items():
        raw = source_book if name == 'workbook/output/RC_Section_NDM.xlsm' else (folder/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, (key, name)
    assert TestRead(folder/'CompileClosure.json')['State'] == 'Absent'
    closure = TestRead(folder/'Native/MVTGaussMixed.txt.ProcessClosure.json')
    owner = TestRead(folder/'Native/MVTGaussMixed.txt.Ownership.json')
    if key == 'Failed':
        assert closure['Stage'] == 'TIMEOUT' and closure['After']['State'] == 'Absent'
        assert not closure['Passed'] and closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout']
        identity = closure['Identity']
    else:
        assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['Closure']['FinalState']['State'] == 'Absent'
        assert closure['ChildExitCode'] == 0
        identity = closure['Closure']['Identity']
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == compiler['WorkbookSHA256']
    assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
    safety = [json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert len(safety) == 2
    for row in safety:
        assert row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 and all(p['ProtectedUser'] for p in row['excel'])
    container = (folder/'CompiledVBA.bin').read_bytes()
    pinned = TestRead(folder/'CompiledVBA.json')
    assert len(container) == pinned['bytes'] and sha256(container).hexdigest().upper() == pinned['sha256']
    _, actual = reader(helper['TestContainer'](container))
    _, base = reader(BytesIO(source_book))
    assert set(actual) == set(base)|set(compiler['Modules'])
    untouched, conversions = 0, {}
    for name, value in base.items():
        if name not in compiler['Modules']:
            try:
                expected_body, actual_body = body(value, name)[0], body(actual[name], name)[0]
            except IndexError:
                assert value == actual[name], (key, name)
            else:
                assert expected_body == actual_body, (key, name)
            untouched += 1
    for name in compiler['Modules']:
        files = [p for directory in ('src', 'tests') for p in (folder/directory).rglob(name+'.*') if p.suffix in ('.bas', '.cls')]
        assert len(files) == 1
        alias = 'modTestMVT2GaussSpan' if name.startswith('modTestMVT2') else name
        expected, changes = helper['TestMVTCompilerBody'](body, files[0].read_text('utf-8-sig'), alias)
        observed = body(actual[name], name)[0]
        expected, additions = gauss(expected, observed, name)
        assert expected == observed, (key, name)
        if changes or additions:
            conversions[name] = changes+additions
    assert untouched == 219 and len(actual) == 230
    log = (folder/'Native/MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'SOURCE_SHA256: '+compiler['WorkbookSHA256'] in log and 'RUNTIME ERROR:' not in log
    if key == 'Failed':
        assert 'WATCHDOG_FAILURE: timeout=240 sec;' in log and 'CASE_FINISHED;' not in log
        complete, seconds = 'False', None
    else:
        assert 'TIMEOUT' not in log
        complete, seconds = re.findall(r'^CASE_FINISHED;MVTGaussMixed;(True|False);([^\r\n]+)$', log, re.M)[0]
    return {'components': len(actual), 'unchanged_components': untouched, 'macro_seconds': float(seconds) if seconds else None,
            'watchdog_time_limit_reached': key == 'Failed',
            'declared_scope_completed': complete == 'True', 'compiler_conversions': conversions}


def TestRows(section, history, rows):
    """Повторяет принятые и отклонённые полные пробы с исходными допусками; отклонённые историю не меняют."""
    accepted, rejected = 0, 0
    for row in rows:
        target, field = np.asarray(row['target']), np.asarray(row['field'])
        result = section.evaluate(field, history, target)
        tolerance = float(5e-7+5e-7*np.max(np.abs((target@section.l)[:section.TestDof-4])))
        assert tolerance == row['tolerance_MPa'] and abs(result[1]-row['norms_MPa'][-1]) < 5e-9
        assert bool(result[1] <= tolerance) == row['accepted']
        if row['accepted']:
            history = result[4]
            accepted += 1
        else:
            rejected += 1
    return history, {'accepted': accepted, 'rejected': rejected}


def TestProjection(spans):
    """Независимо раскрывает глобальные квадратичные полиномы по узлам открытого кубического сплайна."""
    knots = np.r_[np.zeros(4), np.arange(1, spans)/spans, np.ones(4)]
    coefficients = []
    for i in range(1, spans+4):
        a, b, c = knots[i:i+3]
        first, second = (a+b+c)/3., (a*b+a*c+b*c)/3.
        coefficients.append([1.-2.*first+second, 2.*(first-second), second])
    width = spans+3
    projection = np.zeros((12+3*width**2, 39))
    projection[:4, :4] = np.eye(4)
    for y in range(width):
        for x in range(width):
            for b in range(3):
                for a in range(3):
                    for component in range(3):
                        projection[4+3*(width*y+x)+component, 4+3*(3*b+a)+component] = coefficients[x][a]*coefficients[y][b]
    projection[-8:-4, -8:-4] = np.eye(4)
    projection[-4:, -4:] = np.eye(4)
    assert np.linalg.matrix_rank(projection) == 39
    return projection


def TestAuxiliary(section, history, folder, fields):
    """Проверяет реальные вспомогательные поля VBA до фиксации последующих полных решений."""
    seeds = {}
    for line in (folder/'MVTGaussMixed.txt').read_text('utf-8-sig').splitlines():
        row = line.split(';')
        if row[0] == 'REDUCED_SEED':
            seeds[row[1]] = np.asarray(row[2:], dtype=float)
    projection, checks = TestProjection(2), []
    scale = np.r_[np.ones(35), np.full(4, 30000.)]
    labels = list(fields)
    for label in dict.fromkeys([*labels, *seeds]):
        q = float(label.removeprefix('Reduced'))
        target = np.array([0., -396.*q, 0., 10510000., 0., q])
        if label in seeds:
            seed = seeds[label]
            coefficients = np.linalg.lstsq(projection, seed, rcond=None)[0]
            mapping_error = float(np.max(np.abs(projection@coefficients-seed)))
            assert mapping_error < 1e-12
            result = section.evaluate(seed, history, target)
            norm = max(float(np.max(np.abs((projection.T@result[0])*scale))),
                       float(np.max(np.abs(result[2]-target)/section.force_scale)))
            tolerance = float(5e-7+5e-7*np.max(np.abs(((target@section.l)@projection)[:-4])))
            assert norm <= tolerance
            checks.append({'label': label, 'restricted_norm_MPa': norm, 'restricted_tolerance_MPa': tolerance,
                           'full_norm_MPa': float(result[1]), 'mapping_error': mapping_error})
        if label in fields:
            history = section.evaluate(fields[label], history, target)[4]
    return checks


def TestVerify(repo, root, output, scope):
    """Проверяет ограниченный исследовательский этап; не подтверждает физический предел и рабочий выпуск."""
    native = {}
    if scope == 'native':
        source_book, digest = TestSource(repo, root)
        helper, body, reader = run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
        gauss = run_path(str(root/'Verify-TestASDResolution.py'))['TestGaussBody']
        for key in TestRead(root/'Cases.json'):
            native[key] = TestNative(repo, root, source_book, digest, key, helper, body, reader, gauss)
        proof = {'native': native, 'production_changed': False, 'physical_capacity_certified': False}
        output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
        print('REDUCED PREDICTOR NATIVE VBA AND CLOSED EXCEL VERIFIED; CAPACITY OPEN')
        return
    replay = run_path(str(root/'TestResolutionSection.py'))['TestReplay']
    helper = run_path(str(root/'Predict-TestReducedSpace.py'))
    summaries = {}
    auxiliary = {}
    with TemporaryDirectory(dir=output.parent) as directory:
        temp = Path(directory)
        for key, prefixes in (('Reduced', [root/'Prefix/Native']),
                              ('Control', [root/'Prefix/Native', root/'Reduced/Native']),
                              ('Failed', [root/'Prefix/Native', root/'Reduced/Native'])):
            section, history, fields = replay(repo, root/key/'Native', temp/(key+'.json'), prefix_native=prefixes)
            data = TestRead(temp/(key+'.json'))
            maximum = max(data['states'], key=lambda row: row['target_N_Nmm'][5])
            summaries[key] = {'states': len(fields), 'last_Qy_N': data['states'][-1]['target_N_Nmm'][5],
                              'maximum_Qy_N': maximum['target_N_Nmm'][5], 'maximum_label': maximum['label'],
                              'post_maximum_accepted_states': len(data['states'])-data['states'].index(maximum)-1,
                              'maximum_native_stress_error_MPa': data['native_stress_error_MPa'],
                              'maximum_norm_MPa': max(row['norm_MPa'] for row in data['states'])}
        section, history, fields = replay(repo, root/'Prefix/Native', temp/'Prefix.json')
        raw = (root/'Reduced/Native/Operators.csv').read_text('cp1251')
        fields = {row[1]: np.asarray(row[2:], dtype=float) for row in (line.split(';') for line in raw.splitlines()) if row[0] == 'F'}
        auxiliary['Reduced'] = TestAuxiliary(section, history, root/'Reduced/Native', fields)
        assert len(auxiliary['Reduced']) == 1 and auxiliary['Reduced'][0]['full_norm_MPa'] > auxiliary['Reduced'][0]['restricted_tolerance_MPa']
        for filename in ('ResolutionReducedG5S2.json', 'ResolutionReducedSimpleG5S2.json'):
            data = TestRead(root/filename)
            original = section.evaluate(np.asarray(data['original']['field']), history, np.asarray(data['original']['target']))
            assert not data['original']['accepted'] and original[1] > data['original']['tolerance_MPa']
            for row in data['trials']:
                TestRows(section, history, [row['complete']])
        data = TestRead(root/'ResolutionReducedPathG5S2.json')
        _, path = TestRows(section, history, [row['complete'] for row in data['continuation']])
        assert path == {'accepted': 5, 'rejected': 1}
        restore = run_path(str(root/'Restore-TestReducedCase.py'))['TestRestore']
        for key in ('Reduced', 'Control'):
            restore(repo, root, key, temp/('Restored'+key))
        analyze = run_path(str(root/'Analyze-TestReducedBranch.py'))['TestAnalyze']
        analyze(repo, root, temp/'Branch.json')
        assert (temp/'Branch.json').read_bytes() == (root/'ReducedBranchChecks.json').read_bytes()
        branch = TestRead(temp/'Branch.json')
    assert summaries['Reduced']['states'] == 44 and summaries['Reduced']['last_Qy_N'] == 75000.
    assert summaries['Control']['states'] == 74 and summaries['Failed']['states'] == 97
    assert summaries['Failed']['post_maximum_accepted_states'] > 0
    geometry = []
    log = (root/'Control/Native/MVTGaussMixed.txt').read_text('utf-8-sig')
    for line in log.splitlines():
        row = line.split(';')
        if row[0] == 'REDUCED_GEOMETRY':
            geometry.append({'id': int(row[1]), 'hole': row[2] == 'True', 'spans': int(row[3]),
                             'degrees': int(row[4]), 'points': int(row[5]), 'maximum_strain_error': float(row[6])})
    assert len(geometry) == 4 and geometry[-1]['hole'] and max(row['maximum_strain_error'] for row in geometry) < 1e-12
    proof = {'native_states': summaries, 'geometry': geometry, 'independent_force_path': path, 'native_auxiliary': auxiliary,
             'observed_peak_material_state': branch['observed_peak'],
             'difference_from_experimental_80000N_percent': branch['difference_from_experimental_80000N_percent'],
             'same_quadrature_and_committed_history': True, 'auxiliary_state_committed': False,
             'production_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('REDUCED PREDICTOR FULL EQUILIBRIUM AND GEOMETRY VERIFIED; PHYSICAL CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestVerify(args.repo.resolve(), args.root.resolve(), args.out.resolve(), args.scope)
