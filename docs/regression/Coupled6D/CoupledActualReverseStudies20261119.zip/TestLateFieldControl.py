"""ДЛЯ ТЕСТОВ: проверяет продолжение по физической секущей и критической моде поля, сохраняя шесть нагрузок."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestRun(repo,root,merit,output):
    """Использует тензорную метрику деформаций трёх станций; отдельная смена меры не назначает физический предел."""
    here=Path(__file__).resolve().parent
    tools=run_path(str(here/'Solve-TestRejectedDirection.py'))
    section,history,_,_,_,_=tools['TestRestore'](repo,root)
    rows=[line.split(';') for line in (root/'AcceptedHistory.csv').read_text().splitlines()]
    previous,current=(np.asarray(row[3:],float) for row in rows[-2:])
    old_lambda,lam=(float(row[2])/75000. for row in rows[-2:])
    change=current-previous; n=len(current)
    weight=section.weight/(3.*np.sum(section.weight))
    voigt=np.array([1.,1.,1.,.5,.5,.5])
    metric=np.einsum('spki,p,k,spkj->ij',section.b,weight,voigt,section.b)
    assert np.max(np.abs(metric[-4:]))==0.
    directions={'FieldSecant':change}
    tangent=run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    near=json.loads(merit.read_bytes())['trf']; anchor=np.asarray(near['field'])
    direction=np.array([0.,-396.*75000.,0.,0.,0.,75000.])
    # Критическая мода расширенной системы с исходным сдвиговым управлением; она служит только новой мерой.
    shear=np.einsum('p,pd->d',section.weight[:section.TestConcreteCount],section.b[0,:section.TestConcreteCount,5,:])/57600.
    matrix=np.zeros((n+1,n+1)); matrix[:n,:n]=tangent(section,anchor,history)[0]
    matrix[:n,n]=-direction@section.l; matrix[n,:n]=30000.*shear
    matrix[:n]*=section.gauge_scale[:,None]
    units=1./np.maximum(1e-20,np.max(np.abs(matrix),axis=0))
    _,singular,vh=np.linalg.svd(matrix*units)
    mode=(vh[-1]*units)[:n]; mode[-4:]=0.
    if mode@metric@change<0.: mode=-mode
    directions['CriticalFieldMode']=mode
    captured=[line.split(';') for line in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    correction,=[row for row in captured if row[0]=='REJECTED_CORRECTION']
    rejected=np.asarray(correction[2:-1],float); assert len(rejected)==n
    rejected[-4:]=0.
    if rejected@metric@change<0.: rejected=-rejected
    directions['RejectedNewtonMode']=rejected
    native_matrix=np.asarray([row[2:] for row in captured if row[0]=='REJECTED_MATRIX'],float).T
    augmented=matrix.copy(); augmented[:n,:n]=native_matrix*section.gauge_scale[:,None]
    native_units=1./np.maximum(1e-20,np.max(np.abs(augmented),axis=0))
    _,native_singular,native_vh=np.linalg.svd(augmented*native_units)
    native_mode=(native_vh[-1]*native_units)[:n]; native_mode[-4:]=0.
    if native_mode@metric@change<0.: native_mode=-native_mode
    directions['NativeMatrixMode']=native_mode
    result={'scaled_singular_values':singular.tolist(),'native_scaled_singular_values':native_singular.tolist(),
            'cases':{},'physical_capacity_certified':False}
    for name,move in directions.items():
        size=float(np.sqrt(move@metric@move)); assert size>0.
        projection=metric@move/size
        prior=float(projection@previous); control=float(projection@current); spacing=control-prior
        assert spacing>0.,(name,spacing)
        for multiple in (.5,2.):
            seed=current+multiple*change; factor=lam+multiple*(lam-old_lambda)
            record=tools['TestSolve'](section,history,seed,factor,projection,control+multiple*spacing,'local')
            record.update({'projection':projection.tolist(),'base_control':control,'control_spacing':spacing,'multiple':multiple})
            result['cases'][name+str(multiple)]=record
            output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
            print(name,multiple,record['solved'],record['Qy_N'],record['norm_MPa'],len(record['steps']),flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True); parser.add_argument('--merit',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True); args=parser.parse_args()
    TestRun(args.repo.resolve(),args.root.resolve(),args.merit.resolve(),args.out.resolve())
