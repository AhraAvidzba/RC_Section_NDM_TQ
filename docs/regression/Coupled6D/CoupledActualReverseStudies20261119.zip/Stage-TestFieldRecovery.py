"""ДЛЯ ТЕСТОВ: готовит общий поиск с полевой сменой меры и заранее заданным временем наблюдения."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root):
    """Наблюдает оба направленных продолжения 480 с; точность, материал и общий бюджет 96 проб неизменны."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestGeneralContinuation.py'))['TestStage'](repo,root)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='Run-TestWorkingASD.ps1'; code=(root/name).read_text('utf-8-sig')
    old="if ($Phase -eq 'Trace74') {'480'} else {'240'}"; assert code.count(old)==1
    code=code.replace(old,"if ($Phase -in @('Trace44','Trace74')) {'480'} else {'240'}")
    (root/name).write_bytes(code.encode('utf-8-sig')); prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    script=Path(__file__); (root/script.name).write_bytes(script.read_bytes()); prep['inputs'][script.name]=sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope']={'traces':['Trace44','Trace74'],'maximum_probe_count':96,'observation_seconds':480,'full_acceptance':False}
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('FIELD RECOVERY READY; SAME 96 PROBES; TRACE OBSERVATION 480 SECONDS')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True); args=parser.parse_args(); TestStage(args.repo.resolve(),args.root.resolve())
