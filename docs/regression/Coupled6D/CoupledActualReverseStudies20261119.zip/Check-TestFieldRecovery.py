"""ДЛЯ ТЕСТОВ: проверяет фактическую полевую смену меры и все независимые уравнения без объявления предела."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestRead(file):
    """Читает исходные статусы без нормализации отказов в положительный результат."""
    return json.loads(file.read_text('utf-8-sig'))


def TestFiles(root):
    """Проверяет байты до исполнения архивных проверяющих сценариев."""
    for name,expected in TestRead(root/'Files.json').items(): assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name


def TestNative(repo,root,output):
    """Сверяет все компоненты книг, нативные статусы, исходную точность, память и завершение собственных Excel."""
    TestFiles(root)
    source,_=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _,original=reader(BytesIO(source)); shared=run_path(str(root/'Check-TestMaterialRoundoff.py')); cases={}
    for key in TestRead(root/'Cases.json'):
        folder=root/'Cases'/key
        record=shared['TestSourceComparison'](repo,root,folder,source,original,helper,body,reader)
        compiler=TestRead(folder/'docs/regression/CodeUpdate.json'); reports={}
        assert record['components']==236 and record['imported']==20 and record['unchanged']==216
        for log in sorted((folder/'Native').glob('*.txt')):
            text=log.read_text('utf-8-sig'); phase=log.stem
            closure=TestRead(log.with_name(log.name+'.ProcessClosure.json')); owner=TestRead(log.with_name(log.name+'.Ownership.json'))
            assert closure['Passed'] and closure['ChildExitCode']==0 and closure['RunnerCleanupValid']
            assert closure['Closure']['FinalState']['State']=='Absent'
            identity=closure['Closure']['Identity']; assert identity['PID']==owner['PID'] and identity['Ticks']==int(owner['StartTicksUTC'])
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==compiler['WorkbookSHA256']
            assert 'SOURCE_UNCHANGED: True' in text and 'RUNTIME ERROR:' not in text
            totals=[tuple(map(int,row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',text,re.M)]
            assert totals and all(failed==0 for passed,failed in totals)
            if phase=='Material': assert totals==[(362,0)]
            if phase=='Core': assert sum(passed for passed,failed in totals)==365
            if phase=='Stock':
                assert totals==[(28,0)]
                assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10460833943358; limit=;' in text
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;',text,re.M)
                reports['stock_seconds']=float(re.search(r'^TIMING_SECONDS: ([\d.]+)',text,re.M)[1])
            if phase=='ControlProbe':
                trials=re.findall(r'^CONTROL_PROBE;([^;]+);(True|False);',text,re.M)
                expected={'Probes':(8,0),'Direction':(1,0),'NativeField':(1,1)}[key]
                assert len(trials)==expected[0] and sum(ok=='True' for name,ok in trials)==expected[1]
                reports['accepted_probes']=expected[1]
            if phase in ('Trace44','Trace74'):
                count,=re.findall(r'^PRODUCTION_PATH_COUNT;(\d+)$',text,re.M)
                assert int(count)==(85 if phase=='Trace44' else 108)
                assert 'до подтверждения физического предела' in text
                if phase=='Trace44': assert 'смен пространственной меры после отказа: 1' in text
                reports[phase+'_states']=int(count)
            reports[phase]={'scope_execution_completed':True,'assertions':sum(passed for passed,failed in totals)}
        safety=[json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB']>=6500 and row['freeCommitGiB']>=6 for row in safety)
        assert all(all(item['ProtectedUser'] for item in row['excel']) for row in safety)
        record['reports']=reports; cases[key]=record
    final=root/'Cases/Final'; prep=TestRead(final/'Preparation.json')
    assert set(cases['Final']['reports'])>=set(('Core','Material','Stock','Trace44','Trace74'))
    assert prep['directed_scope']=={'traces':['Trace44','Trace74'],'maximum_probe_count':96,'observation_seconds':480,'full_acceptance':False}
    for name in ('Trace44.Operators.csv','Trace44.Tensor.csv'):
        assert (root/'Cases/First/Native'/name).read_bytes()==(final/'Native'/name).read_bytes(),name
    # Удаление только диагностических вставок должно вернуть неизменённый решатель первых проб.
    direction=root/'Cases/Direction'; private=(direction/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    inserts=["Private mTestCaptured As Boolean, mTestLambda As Double\nPrivate mTestField() As Double, mTestCorrection() As Double, mTestMatrix() As Double\n",
             '    mTestCaptured = False\n',
             '            mTestField = current: mTestCorrection = correction: mTestMatrix = mMatrix\n            mTestLambda = currentLambda: mTestCaptured = True\n']
    for insert in inserts: assert private.count(insert)==1; private=private.replace(insert,'')
    marker="\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Копирует последнюю отвергнутую итерацию без признания её равновесием."
    assert private.count(marker)==1; private=private[:private.index(marker)]
    assert private==(root/'Cases/Probes/src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    with TemporaryDirectory() as scratch:
        restored=Path(scratch)
        for name,expected in prep['inputs'].items():
            raw=source if name=='workbook/output/RC_Section_NDM.xlsm' else (final/name).read_bytes()
            target=restored/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(raw)
            assert sha256(raw).hexdigest().upper()==expected,name
        for name in ('Native','Temp','docs/regression'): (restored/name).mkdir(parents=True,exist_ok=True)
        (restored/'Preparation.json').write_bytes((final/'Preparation.json').read_bytes())
        (restored/'docs/regression/Diagnostic.xlsm').write_bytes(source)
        restoration={'inputs':len(prep['inputs']),'compiled_state_reused':False,'excel_started':False}
    result={'cases':cases,'clean_input_restoration':restoration,'physical_capacity_certified':False,
            'installed_workbook_changed':False,'full_acceptance_completed':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('FIELD RECOVERY EXACT VBA, NEGATIVE PROBES AND DIRECTED NATIVE REGRESSIONS VERIFIED; CAPACITY OPEN')


def TestMechanics(repo,root,output):
    """Повторяет каждую собственную историю, фактическое заблокированное направление и сохранённые исследовательские пробы."""
    TestFiles(root); results={}
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        for key in ('Probes','Direction','NativeField'):
            target=scratch/(key+'.json')
            run_path(str(root/'Validate-TestLateProbe.py'))['TestValidate'](repo,root/'Cases'/key,target)
            results[key]=TestRead(target)
        for key,phase in (('First','Trace44'),('Final','Trace44'),('Final','Trace74')):
            target=scratch/(key+phase+'.json')
            replay=run_path(str(root/'Validate-TestGeneralContinuation.py'))['TestValidate'](repo,root/'Cases'/key,phase,target,44 if phase=='Trace44' else 74)
            if key=='First': adaptive_section,adaptive_history,adaptive_fields=replay
            results[key+phase]=TestRead(target)
        target=scratch/'Direction.json'
        run_path(str(root/'Analyze-TestRejectedDirection.py'))['TestAnalyze'](repo,root/'Cases/Direction',target)
        results['RejectedDirection']=TestRead(target)
        assert results['RejectedDirection']['accepted_prefix_states']==73
        assert all(row['steel_branch_changes']==0 for row in results['RejectedDirection']['samples'])
        section,history,_,_,original_projection,original_target=run_path(str(root/'Solve-TestRejectedDirection.py'))['TestRestore'](repo,root/'Cases/Direction')
        stored=TestRead(root/'Cases/Direction/NativeModeProof.json'); checked={}
        for name,row in stored['cases'].items():
            field=np.asarray(row['field']); value=row['lambda']; projection=np.asarray(row['projection'])
            target=row['base_control']+row['multiple']*row['control_spacing']
            load=np.array([0.,-396.*75000.*value,0.,10510000.,0.,75000.*value])
            state=section.TestEvaluate(field,history,load)
            norm=max(float(state[1]),abs(float(30000.*(projection@field-target))))
            tolerance=float(5e-7+5e-7*np.max(np.abs((load@section.l)[:-4])))
            assert bool(norm<=tolerance)==row['solved'],(name,norm,tolerance)
            checked[name]={'equilibrium_verified':bool(norm<=tolerance),'norm_MPa':norm,'tolerance_MPa':tolerance}
        results['StoredFieldModes']=checked
        # Оптимизаторы остановились выше исходного допуска; их собственный success не назначает равновесие.
        merit=TestRead(root/'Cases/Direction/MeritProof.json'); failures={}
        for name,row in merit.items():
            assert not row['equilibrium_verified'] and row['norm_MPa']>row['tolerance_MPa']
            field=np.asarray(row['field']); value=row['lambda']
            load=np.array([0.,-396.*75000.*value,0.,10510000.,0.,75000.*value])
            state=section.TestEvaluate(field,history,load)
            norm=max(float(state[1]),abs(float(30000.*(original_projection@field-original_target))))
            assert norm>row['tolerance_MPa'] and abs(norm-row['norm_MPa'])<1e-7
            failures[name]={'equilibrium_verified':False,'calls':row['evaluations'],'jacobians':row['jacobians'],'norm_MPa':norm}
        results['MeritFailures']=failures
        adaptive=TestRead(root/'Cases/First/AdaptiveFieldProof.json')
        assert adaptive['requested_states']==12 and adaptive['accepted_states']==2 and adaptive['attempts']==9
        checked=[]; previous_field=adaptive_fields[-1][1]
        for row in adaptive['trials']:
            field=np.asarray(row['field']); projection=np.asarray(row['projection']); value=row['lambda']
            load=np.array([0.,-396.*75000.*value,0.,10510000.,0.,75000.*value])
            state=adaptive_section.TestEvaluate(field,adaptive_history,load)
            norm=max(float(state[1]),abs(float(30000.*(projection@field-row['target_control']))))
            assert bool(norm<=row['tolerance_MPa'])==row['solved']
            item={'attempt':row['attempt'],'equilibrium_verified':row['solved'],'norm_MPa':norm}
            if row['solved']:
                advance=float(abs(projection@(field-previous_field)))
                item.update({'control_advance':advance,'above_ten_tolerance_resolutions':bool(30000.*advance>10.*row['tolerance_MPa'])})
                adaptive_history=state[4]; previous_field=field
            checked.append(item)
        results['AdaptiveField']={'requested_states':12,'accepted_states':2,'scope_passed':False,'native_verified':False,'trials':checked}
    result={'cases':results,'physical_capacity_certified':False,'full_acceptance_completed':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('FIELD RECOVERY SIX EQUATIONS, REJECTED DIRECTION AND SEPARATE MATERIAL HISTORIES VERIFIED; PHYSICAL LIMIT OPEN')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--scope',choices=('native','mechanics'),required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); (TestNative if args.scope=='native' else TestMechanics)(args.repo.resolve(),args.root.resolve(),args.out.resolve())
