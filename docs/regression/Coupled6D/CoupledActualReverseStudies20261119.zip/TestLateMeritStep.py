"""ДЛЯ ТЕСТОВ: проверяет глобализацию последней заблокированной задачи при неизменном критерии равновесия."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import time
import numpy as np
from scipy.optimize import least_squares


def TestRun(repo,root,output):
    """Сравнивает TRF и LM на одних полях, материальной истории и шести нагрузках; результаты исследовательские."""
    here=Path(__file__).resolve().parent
    section,history,field,lam,projection,target=run_path(str(here/'Solve-TestRejectedDirection.py'))['TestRestore'](repo,root)
    tangent=run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    close=run_path(str(here/'Probe-TestASDClosure.py'))['TestClosure']
    section.nominal=lambda value,old:close(section,value,old,maximum_iterations=1024)
    constant=np.array([0.,0.,0.,10510000.,0.,0.]); direction=np.array([0.,-396.*75000.,0.,0.,0.,75000.])
    n=len(field); initial=np.r_[field,lam]; weights=np.r_[section.gauge_scale,1.]
    def TestEvaluate(value):
        """Возвращает исходный максимум всех физических уравнений и неизменную строку управления."""
        load=constant+value[-1]*direction
        data=section.TestEvaluate(value[:-1],history,load)
        control=30000.*(projection@value[:-1]-target)
        residual=np.r_[data[0],control]*weights
        norm=max(float(data[1]),abs(float(control)))
        tolerance=float(5e-7+5e-7*np.max(np.abs((load@section.l)[:-4])))
        return residual,norm,tolerance
    def TestJacobian(value):
        """Собирает исследовательскую спектральную производную вместе с точной нагрузочной колонкой и управлением."""
        matrix=np.zeros((n+1,n+1)); matrix[:n,:n]=tangent(section,value[:-1],history)[0]
        matrix[:n,n]=-direction@section.l; matrix[n,:n]=30000.*projection
        return matrix*weights[:,None]
    matrix=TestJacobian(initial); units=1./np.maximum(1e-20,np.max(np.abs(matrix),axis=0))
    results={}
    for method in ('trf','lm'):
        trace=[]; calls=0; jacobians=0; start=time.perf_counter()
        def TestResidual(step):
            """Учитывает каждое обращение, не изменяя принятый материальный буфер."""
            nonlocal calls
            calls+=1; residual,norm,tolerance=TestEvaluate(initial+units*step)
            trace.append({'call':calls,'norm_MPa':norm,'tolerance_MPa':tolerance,'squared_merit_MPa2':float(residual@residual)})
            return residual
        def TestDerivative(step):
            """Масштабирует только неизвестные; физические уравнения остаются исходными."""
            nonlocal jacobians
            jacobians+=1
            return TestJacobian(initial+units*step)*units
        try:
            result=least_squares(TestResidual,np.zeros(n+1),jac=TestDerivative,method=method,
                                 ftol=1e-13,xtol=1e-13,gtol=1e-13,max_nfev=64)
            value=initial+units*result.x; residual,norm,tolerance=TestEvaluate(value)
            row={'equilibrium_verified':bool(norm<=tolerance),'optimizer_success':bool(result.success),'message':str(result.message),
                 'norm_MPa':norm,'tolerance_MPa':tolerance,'lambda':float(value[-1]),'Qy_N':float(75000.*value[-1]),
                 'field':value[:-1].tolist(),'squared_merit_MPa2':float(residual@residual)}
        except (ArithmeticError,np.linalg.LinAlgError,ValueError) as error:
            row={'equilibrium_verified':False,'error':str(error)}
        row.update({'evaluations':calls,'jacobians':jacobians,'seconds':time.perf_counter()-start,
                    'trace':trace,'physical_capacity_certified':False,'production_iteration_budget_verified':False})
        results[method]=row
        output.write_bytes((json.dumps(results,indent=2,sort_keys=True)+'\n').encode())
        print(method,row['equilibrium_verified'],row.get('Qy_N'),row.get('norm_MPa'),calls,jacobians,flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); TestRun(args.repo.resolve(),args.root.resolve(),args.out.resolve())
