"""ДЛЯ ТЕСТОВ. Сравнивает плохо направленную управляющую меру с полной принятой секущей без ослабления направления."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Новые пробы используют существующий SelectSpatialDirectionControl и половину/полную длину принятого приращения."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestReversePolish.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '    Dim factor As Double, seedFactor As Double, solved As Boolean, started As Double, seconds As Double, stats As Variant'
    assert code.count(old) == 1
    code = code.replace(old, old + '\n    Dim targetValue As Double, movement() As Double, controlCoordinate As Double, controlSpacing As Double', 1)
    old = '        For probeVariant = 0 To 2'
    assert code.count(old) == 1
    code = code.replace(old, '        For probeVariant = 0 To 4', 1)
    old = '            seed = original: seedFactor = context(1)'
    assert code.count(old) == 1
    code = code.replace(old, old + ': targetValue = context(2): factor = 0#', 1)
    old = '            seedVariant = seed: started = Timer'
    assert code.count(old) == 1
    code = code.replace(old, '''            If probeVariant >= 3 Then
                ReDim movement(1 To operators.DegreeCount)
                For degree = 1 To solver.PhysicalDegreeCount: movement(degree) = accepted(degree) - previous(degree): Next degree
                If Not solver.SelectSpatialDirectionControl(previous, accepted, movement, projection, controlCoordinate, controlSpacing) Then _
                    Err.Raise 5, , "Не построена мера вдоль полной принятой секущей."
                ratio = 0.5
                If probeVariant = 4 Then ratio = 1#
                targetValue = controlCoordinate + ratio * controlSpacing
                seed = accepted
                For degree = 1 To solver.PhysicalDegreeCount: seed(degree) = accepted(degree) + ratio * movement(degree): Next degree
                trace.ReadPoint fields.Count, fraction, currentFactor
                trace.ReadPoint fields.Count - 1, fraction, previousFactor
                seedFactor = currentFactor + ratio * (currentFactor - previousFactor)
            End If
''' + old, 1)
    old = 'projection, context(2), seedFactor, factor, _'
    assert code.count(old) == 1
    code = code.replace(old, 'projection, targetValue, seedFactor, factor, _', 1)
    old = 'controlError = Abs(controlError - context(2)) * calibration(0)'
    assert code.count(old) == 1
    code = code.replace(old, 'controlError = Abs(controlError - targetValue) * calibration(0)', 1)
    old = '            Print #handle, "TOLERANCE;"'
    assert code.count(old) == 1
    code = code.replace(old, '''            Print #handle, "CONTROL;" & CStr(index) & ";" & CStr(probeVariant) & ";" & TestOnsetNumber(targetValue) & TestHardPreparedVector(projection)
''' + old, 1)
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'SecantProjectionExactReplay',
        'variants': ['OriginalTrial', 'StrictTrial', 'StrictForwardSecant', 'StrictSecantMeasureHalf', 'StrictSecantMeasureFull'],
        'existing_spatial_metric_and_direction_gate_unchanged': True, 'new_control_steps': [.5, 1.]})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('FULL ACCEPTED SECANT MEASURE HALF AND FULL STEP STUDY READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
