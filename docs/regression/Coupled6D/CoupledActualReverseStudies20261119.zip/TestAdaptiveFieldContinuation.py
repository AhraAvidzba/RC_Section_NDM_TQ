"""ДЛЯ ТЕСТОВ: исследует обновляемую пространственную секущую после нативной смены меры."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestRun(repo,root,output):
    """Сохраняет историю 85 полей и пробует 12 новых шагов; критерий всех шести усилий остаётся исходным."""
    here=Path(__file__).resolve().parent
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        for a,b in (('Operators.csv','Trace44.Operators.csv'),('MVTGaussMixed.csv','Trace44.csv'),('MVTGaussMixed.Tensor.csv','Trace44.Tensor.csv')):
            (scratch/a).write_bytes((root/'Native'/b).read_bytes())
        section,history,fields=run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo,scratch,output.with_suffix('.Prefix.json'))
    prefix=json.loads(output.with_suffix('.Prefix.json').read_bytes())['states']
    assert len(fields)==85
    previous,current=fields[-2][1],fields[-1][1]
    old_lambda,lam=(row['target_N_Nmm'][5]/75000. for row in prefix[-2:])
    weight=section.weight/(3.*np.sum(section.weight)); voigt=np.array([1.,1.,1.,.5,.5,.5])
    metric=np.einsum('spki,p,k,spkj->ij',section.b,weight,voigt,section.b)
    def TestMeasure():
        """Нормирует секущую в средней тензорной метрике; кинематические связи не входят в направление."""
        move=current-previous; size=float(np.sqrt(move@metric@move))
        assert size>0.
        projection=metric@move/size
        return projection,float(projection@current),size
    projection,control,spacing=TestMeasure(); step=.5*spacing; minimum=step/64.; ceiling=4.*step
    solve=run_path(str(here/'Solve-TestRejectedDirection.py'))['TestSolve']
    records=[]; accepted=0; count=0
    while accepted<12 and count<48 and step>=minimum:
        count+=1; ratio=step/spacing; seed=current+ratio*(current-previous); factor=lam+ratio*(lam-old_lambda)
        result=solve(section,history,seed,factor,projection,control+step,'local')
        result.update({'attempt':count,'accepted_before_trial':accepted,'projection':projection.tolist(),'target_control':control+step,'step_size':step})
        records.append(result)
        if result['solved']:
            field=np.asarray(result['field']); value=result['lambda']
            load=np.array([0.,-396.*75000.*value,0.,10510000.,0.,75000.*value])
            checked=section.TestEvaluate(field,history,load)
            assert checked[1]<=result['tolerance_MPa']
            history=checked[4]; previous,current=current,field; old_lambda,lam=lam,value
            accepted+=1; projection,control,spacing=TestMeasure(); step=min(ceiling,1.25*step)
        else: step*=.5
        proof={'prefix_states':85,'requested_states':12,'accepted_states':accepted,'attempts':count,'trials':records,
               'physical_capacity_certified':False,'native_implementation_verified':False}
        output.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
        print(count,result['solved'],result['Qy_N'],result['norm_MPa'],'accepted',accepted,flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); TestRun(args.repo.resolve(),args.root.resolve(),args.out.resolve())
