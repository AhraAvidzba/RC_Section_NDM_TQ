"""ДЛЯ ТЕСТОВ: проверяет точный VBA, отрицательный контроль и независимо повторяет принятые поля."""
from argparse import ArgumentParser
from decimal import Decimal
from difflib import unified_diff
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def TestRead(file):
    """Читает JSON без изменения числовых или строковых ожиданий."""
    return json.loads(file.read_text('utf-8-sig'))


def TestFiles(root):
    """Проверяет закрепление каждого исходного байта комплекта."""
    for name,expected in TestRead(root/'Files.json').items():
        assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name


def TestSourceComparison(repo,root,folder,source,original,helper,body,reader):
    """Декодирует все компоненты; преобразования VBE принимаются только известные и равнозначные."""
    prep=TestRead(folder/'Preparation.json'); compiler=TestRead(folder/'docs/regression/CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged']
    assert compiler['ProductionSHA256']==sha256(source).hexdigest().upper()==prep['source_book_sha256']
    assert sorted(compiler['Modules'])==sorted(prep['modules'])
    assert TestRead(folder/'CompileClosure.json')['State']=='Absent'
    for name,expected in prep['inputs'].items():
        raw=source if name=='workbook/output/RC_Section_NDM.xlsm' else (folder/name).read_bytes()
        assert sha256(raw).hexdigest().upper()==expected,(folder.name,name)
    binary=(folder/'CompiledVBA.bin').read_bytes(); pin=TestRead(folder/'CompiledVBA.json')
    assert len(binary)==pin['bytes'] and sha256(binary).hexdigest().upper()==pin['sha256']
    _,actual=reader(helper['TestContainer'](binary))
    assert set(actual)==set(original)|set(compiler['Modules'])
    conversions={}; untouched=0
    gauss=run_path(str(root/'Verify-TestASDResolution.py'))['TestGaussBody']
    for name in actual:
        if name not in compiler['Modules']:
            try: assert body(actual[name],name)[0]==body(original[name],name)[0],name
            except IndexError: assert actual[name]==original[name],name
            untouched+=1; continue
        files=[p for directory in ('src','tests') for p in (folder/directory).rglob(name+'.*') if p.suffix in ('.bas','.cls')]
        assert len(files)==1
        code=files[0].read_text('utf-8-sig')
        alias='modTestMVT2GaussSpan' if name=='modTestMVT2ProductionASDTest' else name
        expected,edits=helper['TestMVTCompilerBody'](body,code,alias)
        if name=='CCoupledSectionAnalysis':
            old="' рабочий знак my соответствует +x·σz."
            assert expected.count(old)==1; expected=expected.replace(old,old.replace('σ','?'))
            edits.append({'kind':'legacy_inline_comment_encoding_loss','from':old,'to':old.replace('σ','?')})
        if name=='modCoupledConcreteTensor':
            old,new='0.0000000000000001','1e-16'
            assert expected.count(old)==1 and Decimal(old)==Decimal(new)
            expected=expected.replace(old,new); edits.append({'kind':'equivalent_literal','from':old,'to':new})
        if name=='modTestCoupledASDMaterial':
            for label in ('spatial measure independent three-station tensor norm','spatial measure positive increment',
                          'spatial measure independent of direction scale and sign','spatial reversed traversal retains positive increment'):
                old='< 1e-12, "'+label+'"'; new='< 0.000000000001, "'+label+'"'
                if old in expected:
                    assert expected.count(old)==1 and Decimal('1e-12')==Decimal('0.000000000001')
                    expected=expected.replace(old,new); edits.append({'kind':'equivalent_literal','from':old,'to':new})
        observed=body(actual[name],name)[0]; expected,extra=gauss(expected,observed,name)
        if expected!=observed:
            print(folder.name,name,'\n'.join(list(unified_diff(expected.splitlines(),observed.splitlines(),lineterm=''))[:70]))
            raise AssertionError(name)
        if edits or extra: conversions[name]=edits+extra
    return {'components':len(actual),'imported':len(compiler['Modules']),'unchanged':untouched,'conversions':conversions}


def TestNative(repo,root,output):
    """Различает успешное выполнение диагностики, действительные равновесия и неподтверждённую несущую способность."""
    TestFiles(root)
    source,digest=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _,original=reader(BytesIO(source)); cases={}
    for name in TestRead(root/'Cases.json'):
        folder=root/'Cases'/name
        if name=='CompileFailure':
            failure=TestRead(folder/'CompileFailureClosure.json')
            assert failure['State']=='Absent' and not failure['Compiled']
            assert 'COMPILE_LOCATION:' in (folder/'Compile.log').read_text('utf-8-sig')
            cases[name]={'compiled':False,'failure_preserved':True}; continue
        record=TestSourceComparison(repo,root,folder,source,original,helper,body,reader)
        compiler=TestRead(folder/'docs/regression/CodeUpdate.json'); reports={}
        for file in sorted((folder/'Native').glob('*.txt')):
            log=file.read_text('utf-8-sig'); phase=file.stem
            closure=TestRead(file.with_name(file.name+'.ProcessClosure.json'))
            owner=TestRead(file.with_name(file.name+'.Ownership.json'))
            assert closure['Closure']['FinalState']['State']=='Absent' and closure['RunnerCleanupValid']
            identity=closure['Closure']['Identity']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
            assert owner['SourceSHA256']==compiler['WorkbookSHA256']
            assert owner['PID']==identity['PID'] and int(owner['StartTicksUTC'])==identity['Ticks']
            assert 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
            totals=[tuple(map(int,row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',log,re.M)]
            assert totals,(name,phase)
            if name=='ExactBaseline':
                assert phase=='MaterialContexts' and totals==[(0,1)]
                # При текстовом переносе контекстов округление меняет точные Boolean-признаки: воспроизводится один из пяти отказов.
                assert 'MATERIAL_CONTEXT_SUMMARY;5;1' in log and closure['ChildExitCode']==1
            else:
                assert closure['Passed'] and closure['ChildExitCode']==0 and all(b==0 for a,b in totals)
            if phase=='Core': assert sum(a for a,b in totals)==365
            if phase=='Material': assert totals==[(324,0)]
            if phase=='ControlProbe':
                assert len(re.findall(r'^CONTROL_PROBE;',log,re.M))==6
                assert len(re.findall(r'^CONTROL_PROBE;[^;]+;True;',log,re.M))==1
                assert re.search(r'^CONTROL_PROBE;ShearY32;True;',log,re.M)
                contexts=len(re.findall(r'^MATERIAL_CONTEXT;',log,re.M))
                assert contexts==(5 if name=='OriginalProbes' else 0)
                reports[phase+'_material_failures']=contexts
            if phase=='MaterialContexts' and name!='ExactBaseline':
                assert 'MATERIAL_CONTEXT_SUMMARY;5;0' in log
                rows=[line.split(';') for line in log.splitlines() if line.startswith('MATERIAL_CONTEXT_RESULT;')]
                assert len(rows)==5 and all(row[5]=='0' and row[6]=='False' and row[8]=='0' for row in rows)
            if phase=='Trace74':
                assert 'PRODUCTION_PATH_COUNT;74' in log and 'проверено альтернативных мер: 4' in log
                assert 'до подтверждения физического предела' in log
            if phase=='Stock':
                assert totals==[(28,0)]
                assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10290889219566; limit=;' in log
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;',log,re.M)
                reports['stock_seconds']=float(re.search(r'^TIMING_SECONDS: ([\d.]+)',log,re.M)[1])
            reports[phase]={'passed':sum(a for a,b in totals),'failed':sum(b for a,b in totals)}
        safety=[json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB']>=6500 and row['freeCommitGiB']>=6 for row in safety)
        assert all(all(p['ProtectedUser'] for p in row['excel']) for row in safety)
        record['reports']=reports; cases[name]=record
    final=root/'Cases/Final'; baseline=root/'Cases/ExactBaseline'
    assert (final/'Data/FailureContexts.csv').read_bytes()==(baseline/'Data/FailureContexts.csv').read_bytes()
    assert (final/'AcceptedHistory.csv').read_bytes()==(baseline/'AcceptedHistory.csv').read_bytes()
    assert (final/'tests/modTestMVT2ProductionASDTest.bas').read_bytes()==(baseline/'tests/modTestMVT2ProductionASDTest.bas').read_bytes()
    # Математика обновления ASD и обычный Ньютон не менялись в исправлении классификатора.
    for relative in ('src/Materials/CCoupledASDFlow.cls','src/Solver/CCoupledNewtonSolver.cls'):
        assert (final/relative).read_bytes()==(baseline/relative).read_bytes()
    restorations={}; point_contexts=[]
    with TemporaryDirectory() as scratch:
        for name in ('Final','ExactBaseline'):
            folder=root/'Cases'/name; target=Path(scratch)/name; target.mkdir()
            prep=TestRead(folder/'Preparation.json')
            for relative,expected in prep['inputs'].items():
                raw=source if relative=='workbook/output/RC_Section_NDM.xlsm' else (folder/relative).read_bytes()
                file=target/relative; file.parent.mkdir(parents=True,exist_ok=True); file.write_bytes(raw)
                assert sha256(file.read_bytes()).hexdigest().upper()==expected
            restorations[name]=len(prep['inputs'])
        point_proof=Path(scratch)/'PointFailureContexts.json'
        run_path(str(root/'Analyze-TestFailureContexts.py'))['TestRun'](repo,root/'Cases/OriginalProbes',point_proof)
        point_contexts=TestRead(point_proof)
        assert len(point_contexts)==5 and all(len(row['neighbours'])==6 for row in point_contexts)
        assert all(item['closed'] for row in point_contexts for item in row['neighbours'])
        assert max(row['base_plastic_increment'] for row in point_contexts)<1e-17
        assert max(item['plastic_increment'] for row in point_contexts for item in row['neighbours'])<1e-17
    result={'cases':cases,'clean_inputs_restored':restorations,'independent_failure_contexts':point_contexts,'installed_workbook_changed':False,
            'full_acceptance_completed':False,'physical_capacity_certified':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('MATERIAL ROUNDOFF NATIVE SOURCE, CAPTURED CONTEXTS, NEGATIVE CONTROL AND DIRECTED REGRESSIONS VERIFIED; CAPACITY OPEN')


def TestMechanics(repo,root,output):
    """Повторяет 74 исходных равновесия и отдельную принятую сдвиговую пробу, не смешивая независимые истории."""
    TestFiles(root)
    raw=(repo/'docs/regression/Coupled6D/ProductionGaussAndASD20261118.zip').read_bytes()
    assert sha256(raw).hexdigest().upper()=='322CBF36E5FD026CD3C7A2D852CF3BC0FF1E91A529B5FBBF8CD6186254B96395'
    replay=run_path(str(root/'TestResolutionSection.py'))['TestReplay']
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch); prefixes=[]
        with ZipFile(BytesIO(raw)) as archive:
            for index,prefix in enumerate(('Prefix/Native/','NativeCase/Mechanics/')):
                folder=scratch/str(index); folder.mkdir(); prefixes.append(folder)
                for name in ('Operators.csv','MVTGaussMixed.csv','MVTGaussMixed.Tensor.csv'):
                    (folder/name).write_bytes(archive.read(prefix+name))
        probe=scratch/'Probe'; probe.mkdir()
        source=root/'Cases/RoundoffProbes/Native'
        for name,relative in (('Operators.csv','ControlProbe.Operators.csv'),('MVTGaussMixed.csv','ControlProbe.csv'),
                              ('MVTGaussMixed.Tensor.csv','ControlProbe.Tensor.csv')):
            (probe/name).write_bytes((source/relative).read_bytes())
        replay(repo,probe,scratch/'Probe.json',prefix_native=prefixes)
        result=TestRead(scratch/'Probe.json')
        assert len(result['states'])==75 and result['states'][-1]['label']=='ShearY32'
        assert result['states'][-1]['target_N_Nmm'][5]==79927.6155615199
        trace=scratch/'Trace'; trace.mkdir(); source=root/'Cases/AlternativeControls/Native'
        for name,relative in (('Operators.csv','Trace74.Operators.csv'),('MVTGaussMixed.csv','Trace74.csv'),
                              ('MVTGaussMixed.Tensor.csv','Trace74.Tensor.csv')):
            (trace/name).write_bytes((source/relative).read_bytes())
        replay(repo,trace,scratch/'Trace.json')
        result['alternative_control_trace']=TestRead(scratch/'Trace.json')
        assert len(result['alternative_control_trace']['states'])==74
    result['physical_capacity_certified']=False
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('MATERIAL ROUNDOFF ALL SIX RESULTANTS, TENSORS AND INDEPENDENT HISTORIES VERIFIED; PHYSICAL LIMIT OPEN')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--scope',choices=('native','mechanics'),required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); (TestNative if args.scope=='native' else TestMechanics)(args.repo.resolve(),args.root.resolve(),args.out.resolve())
