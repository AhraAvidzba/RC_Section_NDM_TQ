"""ДЛЯ ТЕСТОВ: сравнивает меры продолжения из последнего равновесия MVT2 без изменения рабочего решателя."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root):
    """Сохраняет полную принятую историю и восемь независимых проб с одинаковыми точностью и бюджетом."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingASD.py'))['TestStage'](repo,root)
    source=Path('D:/CodexScratch/RC_Section_NDM_TQ/GeneralShearContinuation0820261118/Native')
    pins={'Trace44Extended.Operators.csv':'','Trace44Extended.Tensor.csv':''}
    loads={}
    for line in (source/'Trace44Extended.Tensor.csv').read_text('cp1251').splitlines():
        row=line.split(';')
        if row[0]=='FRAME': loads[row[1]]=row[2:4]
    fields=[]
    for line in (source/'Trace44Extended.Operators.csv').read_text('cp1251').splitlines():
        row=line.split(';')
        if row[0]=='F': fields.append(';'.join([row[1],*loads[row[1]],*row[2:]]))
    assert len(fields)==73
    (root/'AcceptedHistory.csv').write_bytes(('\r\n'.join(fields)+'\r\n').encode())
    name='tests/modTestMVT2ProductionASDTest.bas'; full=(root/name).read_text('utf-8-sig')
    begin=full.index('Private Function RunControlProbesTest(')
    end=full.index('\nEnd Function',begin)+len('\nEnd Function')
    code=full[begin:end]
    replacements={
        'If history.Count <> 74 Then':'If history.Count <> 73 Then',
        'Для сравнительных проб нужны 74 принятых состояния.':'Для сравнительных проб нужны 73 принятых состояния.',
        'For index = 1 To 6':'For index = 1 To 8',
        'Case 1, 2\n                mode = "FirstBar"':'Case 3, 4\n                mode = "FirstBar"',
        'Case 3, 4\n                mode = "Automatic"':'Case 1, 2\n                mode = "Automatic"',
        'Case 5\n                mode = "Twist"':'Case 5, 6\n                mode = "Twist"',
        'Case 6\n                Dim unused()':'Case 7, 8\n                Dim unused()',
        'factor = 32#: If index = 1 Or index = 3 Then factor = 4#':'factor = 0.5: If index Mod 2 = 0 Then factor = 2#',
    }
    for old,new in replacements.items():
        assert code.count(old)==1,old
        code=code.replace(old,new)
    (root/name).write_bytes((full[:begin]+code+full[end:]).replace('\n','\r\n').encode('utf-8-sig'))
    prep=json.loads((root/'Preparation.json').read_bytes())
    for relative in ('AcceptedHistory.csv',name): prep['inputs'][relative]=sha256((root/relative).read_bytes()).hexdigest().upper()
    for relative in pins:
        raw=(source/relative).read_bytes(); target='Reference/'+relative
        (root/'Reference').mkdir(exist_ok=True); (root/target).write_bytes(raw)
        prep['inputs'][target]=sha256(raw).hexdigest().upper(); pins[relative]=sha256(raw).hexdigest().upper()
    script=Path(__file__); (root/script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name]=sha256(script.read_bytes()).hexdigest().upper()
    prep['probe_scope']={'prefix_states':73,'independent_trials':8,'multiples_of_last_increment':[0.5,2.],
                         'newton_iterations_per_trial':32,'source_history':pins,'physical_capacity_certified':False}
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('POST-MAXIMUM NATIVE PROBES READY; 73 PREFIX STATES; 8 INDEPENDENT TRIALS')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--repo',type=Path,default=Path.cwd()); args=parser.parse_args()
    TestStage(args.repo.resolve(),args.root.resolve())
