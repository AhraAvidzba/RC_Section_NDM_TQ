"""ДЛЯ ТЕСТОВ. Проверяет автоматическую историю, точные снимки и неудачные способы продолжения."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestFiles(root):
    """Все сохранённые входы и прежние исходы неизменны."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == '0ffa656f549f1661fce9c916c66200cd434f025a'


def TestNative(repo, root, output):
    """Проверяет действительные компоненты и закрытие каждого отдельного экземпляра Excel."""
    TestFiles(root)
    audit = run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit']
    cases = {}
    for case, phase, count in (('Actual', 'ActualReverse', 29), ('Polish', 'ReversePolish', 1), ('Secant', 'ReversePolish', 1)):
        folder = root / 'Cases' / case
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Code.json'
            audit(repo, folder, proof)
            record = json.loads(proof.read_bytes())
        assert (record['components'], record['imported'], record['unchanged']) == (244, 30, 214)
        assert len(record['checked_coupled_sources']) == 33
        path = folder / 'Native' / (phase + '.txt')
        log = path.read_text('utf-8-sig')
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log and 'RUNTIME ERROR:' not in log
        totals = re.findall(r'^TOTAL[^:\r\n]*:\s*passed=(\d+);\s*failed=(\d+)', log, re.M)
        assert (sum(int(a) for a, b in totals), sum(int(b) for a, b in totals)) == (count, 0)
        source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
        assert source == record['compiled_workbook_sha256']
        closure = json.loads(path.with_name(path.name + '.ProcessClosure.json').read_bytes())
        assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
        assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
        record.update(owned_excel_absent=True, passed=count, numerical_study_outcomes_are_not_asserted_as_success=(case != 'Actual'))
        cases[case] = record
    result = {'cases': cases, 'runtime_source_changed': False, 'installed_workbook_changed': False,
              'full_acceptance_completed': False, 'physical_capacity_certified': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('ACTUAL REVERSE THREE NATIVE BOOKS AND CLOSURE VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Два последних опыта отрицательные; перестройка контроля не называется решением задачи."""
    TestFiles(root)
    here = root
    actual_check = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestCheck']
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        path = Path(temporary) / 'Actual.json'
        actual_check(root / 'Cases/Actual', path)
        actual = json.loads(path.read_bytes())
    helper = run_path(str(here / 'Validate-TestHardPrepared.py'))
    binaries = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    results = {}
    for case, total in (('Polish', 12), ('Secant', 20)):
        folder = root / 'Cases' / case
        rows = helper['TestRows'](folder / 'Native/ReversePolish.csv')
        variants = {}
        for row in rows:
            if row[0] != 'PROBE':
                continue
            index, variant = int(row[1]), int(row[2])
            snapshot = binaries(folder / 'Input' / ('Reverse' + str(index) + '.bin'))
            original = binaries(root / 'Cases/Actual/Native' / ('ActualReverse.Reverse' + str(index) + '.bin'))
            assert snapshot['sha256'] == original['sha256']
            solved = row[3] == 'True'
            record = {'solved': solved, 'lambda': float(row[4]), 'seconds': float(row[5]),
                      'native_residual_MPa': float(row[13])}
            if solved:
                proof, fields = helper['TestValidate'](folder, 'ReversePolish.Reverse' + str(10 * index + variant))
                assert len(fields) == 27 and proof['reversed_fields'] == [27]
                np.testing.assert_allclose(fields[:26], snapshot['fields'], rtol=1e-14, atol=1e-300)
                if variant > 0:
                    assert float(row[4]) < snapshot['lambdas'][-1] and float(row[13]) < 1e-10
                record['equilibrium'] = proof
            else:
                assert case == 'Secant' and variant in (3, 4)
                assert float(row[4]) == 0 and float(row[6]) == 30
            variants[str(index) + ':' + str(variant)] = record
        assert len(variants) == total and sum(item['solved'] for item in variants.values()) == 12
        results[case] = variants
    result = {'actual_automatic_history': actual, 'negative_studies': results,
              'same_control_strict_solutions_are_reversed': True, 'secant_half_and_full_not_converged_within_budget': True,
              'strict_native_tolerance_not_claimed_as_independent_CSV_precision': True,
              'CSV_rounding_allowance_MPa': 1e-9, 'independent_material_reintegration': False,
              'physical_capacity_certified': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('ACTUAL AUTOMATIC 26 FIELDS EXACT LOADS AND NEGATIVE POLISH SECANT STUDIES VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
