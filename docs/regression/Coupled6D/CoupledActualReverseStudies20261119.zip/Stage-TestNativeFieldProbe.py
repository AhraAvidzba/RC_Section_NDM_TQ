"""ДЛЯ ТЕСТОВ: проверяет в VBA одну меру из фактической отвергнутой поправки, без внешнего начального поля."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root):
    """Все начальные поля строятся штатной секущей из 73 нативных состояний; извне передаётся только закреплённая мера."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestPostMaximumProbes.py'))['TestStage'](repo,root)
    proof=Path('D:/CodexScratch/RC_Section_NDM_TQ/LateRejectedDirection20261118/NativeModeProof.json')
    raw=proof.read_bytes(); record=json.loads(raw)['cases']['RejectedNewtonMode0.5']
    assert record['solved']
    (root/'Data/FieldProjection.csv').write_bytes((';'.join(format(x,'.17g') for x in record['projection'])+'\r\n').encode())
    name='tests/modTestMVT2ProductionASDTest.bas'; full=(root/name).read_text('utf-8-sig')
    begin=full.index('Private Function RunControlProbesTest('); end=full.index('\nEnd Function',begin)+len('\nEnd Function')
    code=full[begin:end]
    old='For index = 1 To 8'; assert code.count(old)==1; code=code.replace(old,'For index = 1 To 1')
    old='''                mode = "Automatic"
                If Not solver.SelectDeformationControl(previous, current, projection, control, spacing, name) Then _
                    Err.Raise 5, , "Не выбрана меняющаяся мера."'''
    assert code.count(old)==1
    code=code.replace(old,'''                mode = "RejectedNewtonField"
                ReadFieldProjectionTest Environ$("NDM_MVT_FLOW_FOLDER") & "\\Data\\FieldProjection.csv", projection''')
    full=full[:begin]+code+full[end:]
    full+='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает закреплённую числовую меру; принятые поля и исходная материальная история от неё не меняются.
Private Sub ReadFieldProjectionTest(ByVal path As String, ByRef projection() As Double)
    Dim handle As Integer, line As String, row As Variant, i As Long
    handle = FreeFile: Open path For Input As #handle
    Line Input #handle, line: Close #handle: row = Split(line, ";")
    ReDim projection(1 To UBound(row) + 1)
    For i = 1 To UBound(projection): projection(i) = Val(row(i - 1)): Next i
End Sub
'''
    (root/name).write_bytes(full.replace('\n','\r\n').encode('utf-8-sig'))
    prep=json.loads((root/'Preparation.json').read_bytes())
    for relative in (name,'Data/FieldProjection.csv'):
        prep['inputs'][relative]=sha256((root/relative).read_bytes()).hexdigest().upper()
    (root/'ModeSelectionProof.json').write_bytes(raw)
    prep['inputs']['ModeSelectionProof.json']=sha256(raw).hexdigest().upper()
    script=Path(__file__); (root/script.name).write_bytes(script.read_bytes()); prep['inputs'][script.name]=sha256(script.read_bytes()).hexdigest().upper()
    prep['probe_scope'].update({'independent_trials':1,'measure':'RejectedNewtonField','external_field_seed':False})
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('NATIVE FIELD CONTROL READY; OWN TWO-STATE SEED; NO EXTERNAL EQUILIBRIUM FIELD')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--repo',type=Path,default=Path.cwd()); args=parser.parse_args()
    TestStage(args.repo.resolve(),args.root.resolve())
