"""ДЛЯ ТЕСТОВ: проверяет дискретизацию, фактический VBA, перенос и независимые равновесия."""

from argparse import ArgumentParser
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestRead(path):
    """Читает точные нативные записи, включая BOM."""
    return json.loads(path.read_text('utf-8-sig'))


def TestGaussBody(expected, actual, name):
    """Ограничивает округление VBE только коэффициентами тестового правила; сообщения и расчётный код не нормализует."""
    changes = []
    if name == 'CCoupledConcreteResponse':
        old, new = '0.000000000020000', '0.00000000002'
        if old in expected:
            assert Decimal(old) == Decimal(new) and expected.count(old) == 1
            expected = expected.replace(old, new)
            changes.append({'kind': 'equal_decimal_literal', 'from': old, 'to': new})
    if name != 'CCoupledSectionQuadrature':
        return expected, changes
    rows = expected.splitlines()
    for i, row in enumerate(rows):
        if row.lstrip().startswith("'") and ('test_gauss_order²' in row or '2n−1' in row):
            converted = row.replace('²', '?').replace('−', '?')
            changes.append({'kind': 'test_comment_encoding_loss', 'from': row, 'to': converted})
            rows[i] = converted
    expected = '\n'.join(rows)
    if 'private sub gaussunitruletest(' not in expected or 'innernode' in expected:
        return expected, changes
    start = expected.index('private sub gaussunitruletest(')
    end = expected.index('end sub', start)
    first = actual.index('private sub gaussunitruletest(')
    last = actual.index('end sub', first)
    assert expected[start:end].splitlines()[0] == actual[first:last].splitlines()[0]
    pattern = r'node\((\d+)\)\s*=\s*([^:]+):\s*weight\(\1\)\s*=\s*(.+)'
    source = [re.fullmatch(pattern, row.strip()) for row in expected[start:end].splitlines()[1:]]
    target = [re.fullmatch(pattern, row.strip()) for row in actual[first:last].splitlines()[1:]]
    assert len(source) == len(target) and all(source) and all(target)
    nodes, weights, maximum = [], [], 0.
    for a, b in zip(source, target, strict=True):
        assert a[1] == b[1]
        for j in (2, 3):
            x, y = float(a[j].rstrip('#')), float(b[j].rstrip('#'))
            maximum = max(maximum, abs(x-y))
            assert abs(x-y) <= 1e-15, (a[j], b[j])
        nodes.append(float(b[2].rstrip('#')))
        weights.append(float(b[3].rstrip('#')))
    assert min(weights) > 0.
    moments = [abs(float(np.asarray(weights)@(np.asarray(nodes)**k))-1./(k+1.)) for k in range(2*len(nodes))]
    assert max(moments) < 3e-14
    expected = expected[:start]+actual[first:last]+expected[end:]
    changes.append({'kind': 'VBE_test_gauss_literal_precision', 'order': len(nodes),
                    'maximum_absolute_coefficient_difference': maximum,
                    'maximum_actual_source_moment_error': max(moments)})
    return expected, changes


def TestNative(repo, root, key, helper, body, reader, unpack):
    """Сверяет действительную программу, охват макроса, ресурсы и закрытие двух собственных Excel."""
    folder = root/key
    prep, compiler = TestRead(folder/'Preparation.json'), TestRead(folder/'CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and len(compiler['Modules']) == 9
    assert compiler['ProductionSHA256'] == prep['source_book_sha256']
    source_book = root/'SourceBooks'/(prep['source_book_sha256']+'.xlsm')
    assert sha256(source_book.read_bytes()).hexdigest().upper() == prep['source_book_sha256']
    for name, expected in prep['inputs'].items():
        file = source_book if name == 'workbook/output/RC_Section_NDM.xlsm' else folder/name
        assert sha256(file.read_bytes()).hexdigest().upper() == expected, (key, name)
    assert TestRead(folder/'CompileClosure.json')['State'] == 'Absent'
    closure, owner = TestRead(folder/'Native/MVTGaussMixed.txt.ProcessClosure.json'), TestRead(folder/'Native/MVTGaussMixed.txt.Ownership.json')
    assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['Closure']['FinalState']['State'] == 'Absent'
    assert closure['ChildExitCode'] == (1 if key == 'ControlFailed' else 0)
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == compiler['WorkbookSHA256']
    assert owner['PID'] == closure['Closure']['Identity']['PID'] and int(owner['StartTicksUTC']) == closure['Closure']['Identity']['Ticks']
    safety = [json.loads(row) for row in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert len(safety) == 2
    for row in safety:
        assert row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 and all(p['ProtectedUser'] for p in row['excel'])
    _, actual = reader(helper['TestContainer'](unpack(root, folder)))
    _, base = reader(BytesIO(source_book.read_bytes()))
    assert set(actual) == set(base)|set(compiler['Modules'])
    untouched = 0
    for name, value in base.items():
        if name not in compiler['Modules']:
            try:
                expected_body, actual_body = body(value, name)[0], body(actual[name], name)[0]
            except IndexError:
                assert value == actual[name], (key, name)  # Пустые модули листов сверяются целиком, без удаления атрибутов.
            else:
                assert expected_body == actual_body, (key, name)
            untouched += 1
    conversions = {}
    for name in compiler['Modules']:
        files = [p for directory in ('src', 'tests') for p in (folder/directory).rglob(name+'.*') if p.suffix in ('.bas', '.cls')]
        assert len(files) == 1
        alias = 'modTestMVT2GaussSpan' if name.startswith('modTestMVT2') else name
        expected, changes = helper['TestMVTCompilerBody'](body, files[0].read_text('utf-8-sig'), alias)
        observed = body(actual[name], name)[0]
        expected, additions = TestGaussBody(expected, observed, name)
        assert expected == observed, (key, name)
        if changes or additions:
            conversions[name] = changes+additions
    log = (folder/'Native/MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'SOURCE_SHA256: '+compiler['WorkbookSHA256'] in log and 'TIMEOUT' not in log
    if key == 'ControlFailed':
        assert 'RUNTIME ERROR: VBAProject Subscript out of range' in log
        assert 'TOTAL_MVT2_TRANSFER_CONTROL_TEST: passed=0; failed=1' in log
        seconds = None
    else:
        assert 'RUNTIME ERROR:' not in log
        complete, seconds = re.findall(r'^CASE_FINISHED;MVTGaussMixed;(True|False);([^\r\n]+)$', log, re.M)[0]
        assert (complete == 'True') == (key == 'Control')
    if key == 'Control':
        assert prep['native_source_from_current_installed_workbook']
        assert prep['source_book_sha256'] == 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
        assert len(re.findall(r'^TRANSFER_CONTROL_ACCEPTED;', log, re.M)) == 30
    return {'components': len(actual), 'unchanged_source_components': untouched,
            'compiled_sha256': compiler['WorkbookSHA256'], 'source_book_sha256': prep['source_book_sha256'],
            'native_macro_seconds': float(seconds) if seconds is not None else None,
            'expected_fixed_test_failure': key == 'ControlFailed', 'compiler_conversions': conversions}


def TestRows(section, history, rows, projection=None):
    """Принимает только заново проверенное равновесие и сохраняет буфер при каждом отказе."""
    accepted, rejected = 0, 0
    for row in rows:
        load = np.asarray(row['target']) if 'target' in row else np.array([0., -396.*row['Qy_N'], 0., 10510000., 0., row['Qy_N']])
        field = np.asarray(row['field'])
        result = section.evaluate(field, history, load)
        norm = float(result[1])
        if projection is not None:
            norm = max(norm, abs(float(30000.*(projection@field-row['control_target']))))
        tolerance = float(5e-7+5e-7*np.max(np.abs((load@section.l)[:section.TestDof-4])))
        assert abs(tolerance-row['tolerance_MPa']) < 1e-15
        assert bool(norm <= tolerance) == row['accepted'] and abs(norm-row['norms_MPa'][-1]) < 5e-9
        if row['accepted']:
            history = result[4]
            accepted += 1
        else:
            rejected += 1
    return history, {'accepted': accepted, 'rejected': rejected}


def TestVerify(repo, root, output, scope='all'):
    """Подтверждает исследовательский этап; рабочий выпуск и физический максимум остаются открытыми."""
    if (root/'ResolutionPayloads.json').exists():
        run_path(str(root/'Ensure-TestResolutionPayloads.py'))['TestEnsure'](root, repo)
    native = {}
    if scope != 'mechanics':
        inspector = run_path(str(root/'Inspect-TestResolutionVBA.py'))
        helper, body, reader = inspector['TestHelpers'](repo)
        native = {key: TestNative(repo, root, key, helper, body, reader, inspector['TestContainer']) for key in TestRead(root/'Cases.json')}
    if scope == 'native':
        output.write_bytes((json.dumps({'scope': scope, 'native': native, 'physical_capacity_certified': False}, indent=2, sort_keys=True)+'\n').encode())
        print('RESOLUTION NATIVE VBA AND CLOSED EXCEL PROCESSES VERIFIED; CAPACITY OPEN')
        return
    projection = run_path(str(root/'TestResolutionSection.py'))
    summaries = {}
    with TemporaryDirectory(dir=output.parent) as directory:
        temp = Path(directory)
        restore = run_path(str(root/'Restore-TestResolutionCase.py'))['TestRestore']
        for key in ('G7S1', 'Control'):
            destination = temp/('Restored'+key)
            restore(root, key, destination)
            for name, expected in TestRead(destination/'Preparation.json')['inputs'].items():
                assert sha256((destination/name).read_bytes()).hexdigest().upper() == expected
        for key in ('G5S1', 'G7S1', 'G9S1', 'G5S2', 'G7Fine', 'Transfer', 'ControlFailed', 'Control'):
            prefix = root/'G5S2/Native' if key in ('Transfer', 'ControlFailed', 'Control') else None
            section, history, _ = projection['TestReplay'](repo, root/key/'Native', temp/(key+'.json'), prefix_native=prefix)
            check = TestRead(temp/(key+'.json'))
            summaries[key] = {'states': len(check['states']), 'last_Qy_N': check['states'][-1]['target_N_Nmm'][5],
                              'concrete_points': section.TestConcreteCount, 'degrees': section.TestDof,
                              'native_stress_error_MPa': check['native_stress_error_MPa']}
        for key in ('G7S1', 'G9S1', 'G5S2'):
            section, history, _ = projection['TestReplay'](repo, root/key/'Native', temp/(key+'Base.json'))
            data = TestRead(root/('Resolution'+key+'Continuation.json'))
            history, force = TestRows(section, history, data['trials'])
            file = 'Resolution'+key+('ControlResolved.json' if key != 'G5S2' else 'Control.json')
            controlled = TestRead(root/file)
            _, control = TestRows(section, history, controlled['trials'], np.asarray(controlled['projection']))
            summaries[key]['independent_force'], summaries[key]['independent_control'] = force, control
        coarse, _, _ = projection['TestReplay'](repo, root/'G7S1/Native', temp/'Coarse.json')
        fine, history, _ = projection['TestReplay'](repo, root/'G5S2/Native', temp/'Fine.json')
        transfer = run_path(str(root/'Prolong-TestResolution.py'))['TestTransfer'](coarse, fine)
        saved = TestRead(root/'ResolutionProlongation.json')
        assert np.array_equal(transfer[0], saved['transfer'])
        assert transfer[1]['maximum_operator_transfer_error'] < 1e-11
        history, prolonged = TestRows(fine, history, saved['trials'])
        control = TestRead(root/'ResolutionG5S2TransferredControl.json')
        _, prolonged_control = TestRows(fine, history, control['trials'], np.asarray(control['projection']))
        external = run_path(str(root/'Replay-TestResolutionOpenSees.py'))
        external['TestVerify'](repo, root, root/'G7S1/Native', root/'ResolutionG7S1Continuation.json',
                               root/'ResolutionG7S1ControlResolved.json', root/'ResolutionG7OpenSees.json.gz', temp/'External.json')
        assert (temp/'External.json').read_bytes() == (root/'ResolutionG7OpenSeesChecks.json').read_bytes()
        same = run_path(str(root/'Solve-TestSameNativeControls.py'))
        same['TestRun'](repo, root, root/'G5S2/Native', root/'Transfer/Native', root/'Control/Native', temp/'SameControls.json')
        assert (temp/'SameControls.json').read_bytes() == (root/'ResolutionSameNativeControls.json').read_bytes()
    assert summaries['G7S1']['states'] == summaries['G9S1']['states'] == 39 and summaries['G5S2']['states'] == 38
    assert summaries['Control']['states'] == 72 and summaries['Control']['last_Qy_N'] > 76524.
    assert prolonged['accepted'] == 4 and prolonged_control['accepted'] == 30
    independent = [row for row in TestRead(root/'ResolutionG5S2TransferredControl.json')['trials'] if row['accepted']]
    paired = [row.split(';') for row in (root/'Control/Native/MVTGaussMixed.txt').read_text('utf-8-sig').splitlines()
              if row.startswith('TRANSFER_CONTROL_ACCEPTED;')]
    assert len(independent) == len(paired) == 30
    agreement = {'maximum_Qy_difference_N': max(abs(float(native_row[3])-row['Qy_N']) for native_row, row in zip(paired, independent, strict=True)),
                 'maximum_control_target_difference': max(abs(float(native_row[2])-row['control_target']) for native_row, row in zip(paired, independent, strict=True))}
    # Длительный сырой прогон с приращениями ниже разрешения не считается продвижением к пределу.
    raw = TestRead(root/'ResolutionG7S1ControlExtended.json')
    resolved = TestRead(root/'ResolutionG7S1ControlResolved.json')
    assert len(raw['trials']) > len(resolved['trials']) and resolved['stop_reason'] == 'ControlIncrementBelowTenResidualResolutions'
    proof = {'native': native, 'states': summaries, 'independent_prolonged_force': prolonged,
             'independent_prolonged_control': prolonged_control, 'transfer_identity': transfer[1],
             'native_independent_control_comparison': agreement,
             'identical_native_control_targets': {'shared_prefix_states': 42, 'completed': True,
                 'maximum_Qy_difference_N': TestRead(root/'ResolutionSameNativeControls.json')['maximum_Qy_difference_N'],
                 'native_control_fields_used_as_seeds': False},
             'opensees': TestRead(root/'ResolutionG7OpenSeesChecks.json'), 'raw_subresolution_steps_claimed_as_progress': False,
             'clean_native_input_restore_verified': ['G7S1', 'Control'],
             'production_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('RESOLUTION STUDY AND NATIVE FIELD TRANSFER VERIFIED; PHYSICAL CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--scope', choices=('all', 'native', 'mechanics'), default='all')
    args = parser.parse_args()
    TestVerify(args.repo.resolve(), args.root.resolve(), args.out.resolve(), args.scope)
