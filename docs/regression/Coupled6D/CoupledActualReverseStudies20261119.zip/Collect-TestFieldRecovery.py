"""ДЛЯ ТЕСТОВ: сохраняет полевую смену меры, отрицательные пробы и фактический VBA."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile, ZIP_DEFLATED


TestCases={'Probes':'PostMaximumControlProbes02202611118','Direction':'LateRejectedDirection20261118',
           'NativeField':'NativeRejectedFieldControl20261118','First':'FieldRecovery20261118','Final':'FieldRecoveryFinal20261118'}


def TestCopy(source,target):
    """Сохраняет точные байты без подмены уже сохранённой попытки."""
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream: stream.write(source.read_bytes())


def TestCollect(repo,root):
    """Отделяет исходники, CFB и проверяемые XML; двоичные рисунки неизменного исходного файла не дублирует."""
    scratch=Path('D:/CodexScratch/RC_Section_NDM_TQ'); root.mkdir()
    for key,directory in TestCases.items():
        source=scratch/directory; target=root/'Cases'/key; prep=json.loads((source/'Preparation.json').read_bytes())
        for name,expected in prep['inputs'].items(): assert sha256((source/name).read_bytes()).hexdigest().upper()==expected,(key,name)
        for file in source.rglob('*'):
            if not file.is_file(): continue
            relative=file.relative_to(source)
            if relative.parts[0] in ('Temp','workbook') or file.suffix.lower()=='.xlsm': continue
            TestCopy(file,target/relative)
        for log in (target/'Native').glob('*.txt'): assert log.with_name(log.name+'.ProcessClosure.json').is_file(),log
        with ZipFile(source/'docs/regression/Diagnostic.xlsm') as book: binary=book.read('xl/vbaProject.bin')
        (target/'CompiledVBA.bin').write_bytes(binary)
        (target/'CompiledVBA.json').write_bytes((json.dumps({'bytes':len(binary),'sha256':sha256(binary).hexdigest().upper()},indent=2)+'\n').encode())
        if key=='Final':
            saved,=re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$',(source/'Native/Stock.txt').read_text('utf-8-sig'),re.M)
            assert Path(saved).resolve().is_relative_to((source/'Temp').resolve())
            with ZipFile(saved) as book,ZipFile(target/'SavedWorkbookMarkup.zip','x',ZIP_DEFLATED,compresslevel=9) as output:
                for name in sorted(book.namelist()):
                    if Path(name).suffix.lower() in ('.xml','.rels','.vml'): output.writestr(name,book.read(name))
            (target/'SavedWorkbookScope.json').write_bytes((json.dumps({'xml_relationships_vml_saved':True,'binary_media_saved':False,
                'whole_workbook_preserved':False,'results_save_reopen_verified_by_native_report':True},indent=2)+'\n').encode())
    here=Path(__file__).resolve().parent
    names=('Collect-TestFieldRecovery.py','Check-TestFieldRecovery.py','Stage-TestPostMaximumProbes.py','Stage-TestLateRejected.py',
           'Stage-TestRejectedDirection.py','TestNativeRejectedDirection.bas.txt','Stage-TestNativeFieldProbe.py','Stage-TestFieldRecovery.py',
           'Analyze-TestRejectedDirection.py','Solve-TestRejectedDirection.py','TestClosedASDTangent.py','TestLateMeritStep.py',
           'TestLateFieldControl.py','TestAdaptiveFieldContinuation.py','Validate-TestLateProbe.py','Validate-TestGeneralContinuation.py',
           'TestResolutionSection.py','Probe-TestASDMaterialSteps.py','Probe-TestASDClosure.py','Check-TestMaterialRoundoff.py',
           'Inspect-TestResolutionVBA.py','Verify-TestReducedEvidence.py','Verify-TestASDResolution.py')
    for name in names: TestCopy(here/name,root/name)
    TestCopy(scratch/'WorkingForceSubspaceEvidence20261118/SourceBook.json',root/'SourceBook.json')
    (root/'Cases.json').write_bytes((json.dumps(TestCases,indent=2,sort_keys=True)+'\n').encode())
    (root/'SourceCheckpoint.json').write_bytes((json.dumps({'base':'fcae8f7','installed_workbook_changed':False,
        'physical_capacity_certified':False,'full_acceptance_completed':False},indent=2)+'\n').encode())
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper() for file in root.rglob('*') if file.is_file()}
    (root/'Files.json').write_bytes((json.dumps(files,indent=2,sort_keys=True)+'\n').encode())
    print('FIELD RECOVERY EVIDENCE COLLECTED',len(files))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestCollect(args.repo.resolve(),args.root.resolve())
