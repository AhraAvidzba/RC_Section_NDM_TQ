"""ДЛЯ ТЕСТОВ: независимо повторяет все принятые поля поздней пробы с её собственной полной историей."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestValidate(repo,root,output):
    """Проверяет шесть усилий, слабые уравнения, три станции и фактическую новую меру без внешнего поля решения."""
    here=Path(__file__).resolve().parent
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch); prefix=scratch/'Prefix'; prefix.mkdir(); native=scratch/'Native'; native.mkdir()
        for a,b in (('Operators.csv','ControlProbe.Operators.csv'),('MVTGaussMixed.csv','ControlProbe.csv'),
                    ('MVTGaussMixed.Tensor.csv','ControlProbe.Tensor.csv')):
            (native/a).write_bytes((root/'Native'/b).read_bytes())
        for a,b in (('Operators.csv','Trace44Extended.Operators.csv'),('MVTGaussMixed.Tensor.csv','Trace44Extended.Tensor.csv')):
            (prefix/a).write_bytes((root/'Reference'/b).read_bytes())
        (prefix/'MVTGaussMixed.csv').write_bytes((native/'MVTGaussMixed.csv').read_bytes())
        section,_,fields=run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo,native,scratch/'Proof.json',prefix_native=prefix)
        proof=json.loads((scratch/'Proof.json').read_bytes())
    assert len(fields)>=73
    rows=[line.split(';') for line in (root/'Native/ControlProbe.txt').read_text('utf-8-sig').splitlines()]
    trials=[row for row in rows if row[0]=='CONTROL_PROBE']
    accepted=[row for row in trials if row[2]=='True']
    assert len(fields)==73+len(accepted)
    control_rows=[line.split(';') for line in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    projections={row[1]:np.asarray(row[2:],float) for row in control_rows if row[0]=='CONTROL_PROJECTION'}
    errors=[]
    for row in accepted:
        label=row[1]; target=float(row[3]); value=float(row[4])
        field,=[field for name,field in fields[73:] if name==label]
        state,=[state for state in proof['states'] if state['label']==label]
        error=float(abs(30000.*(projections[label]@field-target)))
        assert error<=state['tolerance_MPa'],(label,error)
        assert abs(75000.*value-state['target_N_Nmm'][5])<1e-6
        errors.append(error)
    proof.update({'native_probes':len(trials),'accepted_probes':len(accepted),'prefix_states':73,
                  'maximum_control_error_MPa':max(errors,default=0.),'external_equilibrium_seed':False,
                  'physical_capacity_certified':False})
    output.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('LATE NATIVE PROBES ALL SIX EQUATIONS AND FULL MATERIAL HISTORY VERIFIED',len(trials),len(accepted),flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); TestValidate(args.repo.resolve(),args.root.resolve(),args.out.resolve())
