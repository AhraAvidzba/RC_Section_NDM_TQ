"""ДЛЯ ТЕСТОВ: исследует численное замыкание ASD-обновления на неизменной деформации."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestClosure(section, field, history, tolerance=1e-9, maximum_iterations=64):
    """Сравнивает фиксации одной деформации; не объявляет это авторским законом ASD."""
    first = section.TestOriginalNominal(field, history)
    old = first
    for iteration in range(1, maximum_iterations+1):
        new = section.TestOriginalNominal(field, old[3])
        errors = (np.max(np.abs(new[0]-old[0])), np.max(np.abs(new[3][1]-old[3][1])),
                  30000.*np.max(np.abs(new[3][2]-old[3][2])))
        section.TestClosureIterations += 1
        if max(errors) <= tolerance:
            return new
        old = new
    raise ArithmeticError('Не замкнулась история ASD при фиксированной деформации: '+str(errors))


def TestRun(repo, output):
    """Сопоставляет фиксированные поля и пробует первую совместную силовую цель."""
    helper = run_path(str(Path(__file__).with_name('Probe-TestASDMaterialSteps.py')))
    sections, fields, _ = helper['TestInputs'](repo)
    proof = {}
    for mode, section in sections.items():
        section.TestOriginalNominal = section.nominal
        section.TestClosureIterations = 0
        section.nominal = lambda field, history, s=section: TestClosure(s, field, history)
        series, previous = [], None
        for power in range(6):
            result, endpoints, _ = helper['TestRun'](section, fields, 2**power)
            if previous is not None:
                result['endpoint_difference_from_previous_refinement_MPa'] = float(np.max(np.abs(endpoints['R8']-previous)))
            previous = endpoints['R8']
            series.append(result)
            print(mode, 2**power, 'closed torque', result['endpoint_resultants_N_Nmm'][3]/1e6,
                  'repeat', result['zero_increment_change_MPa'][0], flush=True)
        proof[mode] = {'fixed_strain_series': series, 'closure_updates': section.TestClosureIterations}
    output.write_bytes((json.dumps({'variants': proof, 'integration_modified': True, 'physical_capacity_certified': False},
                                  indent=2, sort_keys=True)+'\n').encode('utf-8'))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.out.resolve())
