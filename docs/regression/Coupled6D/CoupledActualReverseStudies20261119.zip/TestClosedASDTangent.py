"""ДЛЯ ТЕСТОВ: дифференцирует спектральное ASD-замыкание без изменения его диаграмм."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


TestTensor = ((0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2))
TestE = 30000.


def TestCurve(curve, x, ordinate):
    """Возвращает ординату и производную фактически выбранного линейного отрезка."""
    index = np.clip(np.searchsorted(curve.edges, x), 1, len(curve.x)-1)
    slope = (ordinate[index]-ordinate[index-1])/(curve.x[index]-curve.x[index-1])
    slope = np.where(x > curve.edges[-1], np.maximum(0., slope), slope)
    value = ordinate[index-1]+slope*(x-curve.x[index-1])
    return np.maximum(curve.floor, value), np.where(value >= curve.floor, slope, 0.)


def TestCurveUpdate(curve, old, d_old, equiv, d_equiv):
    """Проводит производные по трём начальным главным напряжениям через max и таблицу."""
    prior, prior_slope = TestCurve(curve, old, curve.effective)
    plastic = old-prior/TestE
    d_plastic = (1.-prior_slope/TestE)[..., None]*d_old
    trial = equiv+plastic
    active = trial > old
    current = np.maximum(old, trial)
    d_current = np.where(active[..., None], d_equiv+d_plastic, d_old)
    reference = TestE*(current-plastic)
    d_reference = TestE*(d_current-d_plastic)
    scales, gradients = [], []
    for ordinate in (curve.nominal, curve.effective):
        value, slope = TestCurve(curve, current, ordinate)
        scale = value/reference
        gradient = (slope[..., None]*d_current-scale[..., None]*d_reference)/reference[..., None]
        scales.append(scale)
        gradients.append(gradient)
    return current, d_current, scales, gradients


def TestEquivalent(values, jacobian, ratio, compression, floor):
    """Дифференцирует эквивалентную координату на выбранной стороне спектрального разбиения."""
    alpha, gamma = 4./33., 3.
    beta = (1.-alpha)*ratio-(1.+alpha)
    v = np.minimum(values, 0.) if compression else values
    dv = jacobian*np.where(values < 0., 1., 0.)[..., None] if compression else jacobian
    mean = v.mean(axis=-1, keepdims=True)
    deviation = v-mean
    q = np.sqrt(1.5*np.sum(deviation**2, axis=-1))
    dq = np.divide(1.5*deviation, q[..., None], out=np.zeros_like(v), where=q[..., None] > 1e-20)
    high = v[..., -1]
    equivalent = alpha*v.sum(axis=-1)+q+beta*np.maximum(high, 0.)-gamma*np.maximum(-high, 0.)
    derivative = alpha+dq
    derivative[..., -1] += np.where(high > 0., beta, np.where(high < 0., gamma, 0.))
    factor = (1.-alpha)*TestE*(1. if compression else ratio)
    equivalent /= factor
    gradient = np.einsum('...i,...ij->...j', derivative, dv)/factor
    if not compression:
        valid = high >= floor
        equivalent = np.where(valid, equivalent, 0.)
        gradient = np.where(valid[..., None], gradient, 0.)
    return equivalent, gradient


def TestPack(matrix):
    """Упаковывает физический тензор напряжений в xx, yy, zz, xy, xz, yz."""
    return np.stack([matrix[..., i, j] for i, j in TestTensor], axis=-1)


def TestTensorize(vector):
    """Восстанавливает симметричный тензор без удвоения касательных напряжений."""
    matrix = np.empty((*vector.shape[:-1], 3, 3))
    for k, (i, j) in enumerate(TestTensor):
        matrix[..., i, j] = matrix[..., j, i] = vector[..., k]
    return matrix


def TestConcrete(section, strain, history, tolerance=1e-9, maximum_iterations=64, trace=None, single_update=False):
    """Возвращает неизменённое замыкание и его алгоритмическую касательную по инженерной деформации."""
    prior_strain, prior_effective, old = history[:3]
    increment = strain-prior_strain
    trial = prior_effective+increment*np.array([25000.]*3+[12500.]*3)
    trial[..., :3] += (25000./3.)*increment[..., :3].sum(axis=-1, keepdims=True)
    initial, axes = np.linalg.eigh(TestTensorize(trial))
    values = initial.copy()
    jacobian = np.broadcast_to(np.eye(3), (*values.shape, 3)).copy()
    d_old = np.zeros((*old.shape, 3))
    nominal_previous = effective_previous = old_previous = None
    initial_scale = np.ones_like(values)
    iterations = 0
    for iteration in range(maximum_iterations+1):
        proposed, d_proposed, nominal_scales, effective_scales, d_nominal, d_effective = [], [], [], [], [], []
        for k, curve in enumerate(section.curves):
            equivalent, d_equivalent = TestEquivalent(values, jacobian, section.ratio, k == 1, curve.floor)
            current, d_current, scales, gradients = TestCurveUpdate(curve, old[k], d_old[k], equivalent, d_equivalent)
            if trace is not None:
                side, point = getattr(section, 'TestTraceLocation', (2, 11))
                plastic = old[k]-curve.value(old[k], curve.effective)/TestE
                trace.append({'iteration': iteration, 'branch': k, 'principal': values[side, point].tolist(),
                              'old_coordinate': float(old[k, side, point]), 'new_coordinate': float(current[side, point]),
                              'activation_gap': float((equivalent+plastic-old[k])[side, point]),
                              'nominal_scale': float(scales[0][side, point]), 'effective_scale': float(scales[1][side, point])})
            proposed.append(current)
            d_proposed.append(d_current)
            nominal_scales.append(scales[0])
            effective_scales.append(scales[1])
            d_nominal.append(gradients[0])
            d_effective.append(gradients[1])
        negative = values < 0.
        ns = np.where(negative, nominal_scales[1][..., None], nominal_scales[0][..., None])
        es = np.where(negative, effective_scales[1][..., None], effective_scales[0][..., None])
        dns = np.where(negative[..., None], d_nominal[1][..., None, :], d_nominal[0][..., None, :])
        des = np.where(negative[..., None], d_effective[1][..., None, :], d_effective[0][..., None, :])
        nominal_values = values*ns
        nominal_jacobian = jacobian*ns[..., None]+values[..., None]*dns
        effective_values = values*es
        effective_jacobian = jacobian*es[..., None]+values[..., None]*des
        proposed = np.asarray(proposed)
        nominal = TestPack(np.einsum('...ik,...k,...jk->...ij', axes, nominal_values, axes))
        effective = TestPack(np.einsum('...ik,...k,...jk->...ij', axes, effective_values, axes))
        if single_update:
            break
        if iteration:
            errors = (np.max(np.abs(nominal-nominal_previous)), np.max(np.abs(effective-effective_previous)),
                      TestE*np.max(np.abs(proposed-old_previous)))
            if max(errors) <= tolerance:
                iterations = iteration
                break
        nominal_previous, effective_previous, old_previous = nominal, effective, proposed
        values, jacobian, old, d_old = effective_values, effective_jacobian, proposed, np.asarray(d_proposed)
        if iteration == maximum_iterations:
            raise ArithmeticError('Не замкнулась дифференцируемая история ASD: '+str(errors))
        initial_scale *= es
    # Изменение собственных векторов учитывается разделённой разностью спектральной функции.
    spectral_ratio = np.empty((*initial.shape[:-1], 3, 3))
    limiting_scale = initial_scale*ns
    for i in range(3):
        for j in range(3):
            gap = initial[..., i]-initial[..., j]
            spectral_ratio[..., i, j] = np.divide(nominal_values[..., i]-nominal_values[..., j], gap,
                out=limiting_scale[..., i].copy(), where=np.abs(gap) > 1e-10*(1.+np.max(np.abs(initial), axis=-1)))
    elastic = np.diag([25000.]*3+[12500.]*3)
    elastic[:3, :3] += 25000./3.
    elastic_tensors = TestTensorize(elastic.T)
    rotated = np.einsum('...ai,kab,...bj->...kij', axes, elastic_tensors, axes)
    tangent = np.empty((*strain.shape, 6))
    for k in range(6):
        derivative = spectral_ratio*rotated[..., k, :, :]
        diagonals = np.einsum('...ij,...j->...i', nominal_jacobian, np.diagonal(rotated[..., k, :, :], axis1=-2, axis2=-1))
        for i in range(3):
            derivative[..., i, i] = diagonals[..., i]
        tangent[..., k] = TestPack(np.einsum('...ai,...ij,...bj->...ab', axes, derivative, axes))
    return nominal, (strain.copy(), effective, proposed), tangent, iterations


def TestGlobalMatrix(section, field, history, single_update=False, include_steel=True):
    """Собирает производную слабых уравнений, замещения бетона и упругопластической стали."""
    concrete, _, constitutive, iterations = TestConcrete(section, section.b@field, history, single_update=single_update)
    concrete_count = getattr(section, 'TestConcreteCount', 25)
    constitutive[:, concrete_count:] *= -1.
    operators = constitutive@section.b
    matrix = section.g+np.einsum('pij,pik->jk', section.s, operators[0])
    matrix += np.einsum('pij,pik->jk', section.r, (operators[1]-operators[2])/section.double_dx)
    steel_trial = 200000.*((section.a@field).reshape(3, len(section.bounds))-history[3])
    active = np.abs(steel_trial).ravel() < np.tile(section.bounds, 3)
    if include_steel:
        matrix += (section.scatter[:, active]*200000.)@section.a[active]
    return matrix, iterations


def TestCheck(repo, native, pilot, output):
    """Проверяет тензоры и касательные на принятых историях и точной отклонённой пробе."""
    helper = run_path(str(Path(__file__).with_name('Trace-TestClosedASDControl.py')))
    section, history, _, _ = helper['TestRestore'](repo, native)
    rows = json.loads(pilot.read_bytes())['variants']['bar26']['trials']
    for row in rows:
        if row['accepted']:
            target = np.array([0., -396.*row['Qy_N'], 0., 10510000., 0., row['Qy_N']])
            history = section.evaluate(np.asarray(row['field']), history, target)[4]
    field = np.asarray(rows[-1]['field'])
    samples = []
    for scale in (1., 1.00001, .99999):
        strain = section.b@(scale*field)
        nominal, proposed, tangent, iterations = TestConcrete(section, strain, history)
        original = section.nominal(scale*field, history)
        original_concrete = original[0].copy()
        original_concrete[:, 25:] *= -1.
        error = float(np.max(np.abs(nominal-original_concrete)))
        state_error = float(np.max(np.abs(proposed[1]-original[3][1])))
        assert error < 8e-8 and state_error < 8e-8, (error, state_error)
        comparisons = []
        for step in (2e-9, 2e-10, 2e-11):
            differences = []
            for j in range(6):
                unit = np.eye(6)[j]
                plus = TestConcrete(section, strain+step*unit, history)[0]
                minus = TestConcrete(section, strain-step*unit, history)[0]
                differences.append((plus-minus)/(2*step))
            finite = np.stack(differences, axis=-1)
            comparisons.append({'step': step, 'maximum_error_MPa': float(np.max(np.abs(finite-tangent))),
                                'scaled_error': float(np.max(np.abs(finite-tangent)/(30000.+np.abs(tangent))))})
        matrix, _ = TestGlobalMatrix(section, scale*field, history)
        h = 2e-11
        finite = np.column_stack([(section.evaluate(scale*field+h*unit, history, np.zeros(6))[0]-
                                  section.evaluate(scale*field-h*unit, history, np.zeros(6))[0])/(2*h) for unit in np.eye(60)])
        entry = {'field_scale': scale, 'nominal_error_MPa': error, 'effective_error_MPa': state_error,
                 'iterations': iterations, 'point_tangents': comparisons,
                 'global_tangent_relative_error': float(np.max(np.abs(matrix-finite)/(30000.+np.abs(matrix))))}
        samples.append(entry)
        print(json.dumps(entry), flush=True)
    output.write_bytes((json.dumps({'samples': samples, 'integration_modified': True, 'physical_capacity_certified': False},
                                   indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--pilot', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestCheck(args.repo.resolve(), args.native.resolve(), args.pilot.resolve(), args.out.resolve())
