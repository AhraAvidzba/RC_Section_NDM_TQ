"""ДЛЯ ТЕСТОВ: сохраняет фактическое заблокированное направление из поздней ветви MVT2."""
from argparse import ArgumentParser
from pathlib import Path
from runpy import run_path


def TestStage(repo,root):
    """Инструментирует только частную пробу ShearY0.5; рабочий код и полная история материала неизменны."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestPostMaximumProbes.py'))['TestStage'](repo,root)
    run_path(str(here/'Stage-TestRejectedDirection.py'))['TestInstrument'](root,loop_count=8,first_index=7)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--repo',type=Path,default=Path.cwd()); args=parser.parse_args()
    TestStage(args.repo.resolve(),args.root.resolve())
