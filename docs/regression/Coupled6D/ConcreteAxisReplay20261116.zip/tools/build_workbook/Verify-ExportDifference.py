"""Сопоставляет текст компонентов VBE до и после направленного изменения."""

import json
import re
import sys
from pathlib import Path


VBA_TOKEN = re.compile(r'''"(?:""|[^"])*"|'[^\n]*|[^\W\d]\w*''')


def code_case(line):
    return VBA_TOKEN.sub(lambda token: token[0] if token[0][0] in "\"'" else token[0].lower(), line)


def modules(path):
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    components = {}
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.startswith("COMPONENT: "):
            i += 1
            continue
        name = line.removeprefix("COMPONENT: ")
        assert name not in components
        component_type = int(lines[i + 1].removeprefix("TYPE: "))
        count = int(lines[i + 2].removeprefix("LINES: "))
        assert re.fullmatch(r"=+", lines[i + 3])
        components[name] = component_type, lines[i + 4:i + 4 + count]
        i += 4 + count
    return components


if __name__ == "__main__":
    baseline, candidate = (modules(Path(arg)) for arg in sys.argv[1:3])
    assert baseline.keys() == candidate.keys()
    assert all(baseline[name][0] == candidate[name][0] for name in baseline)
    raw_changes = sorted(name for name in baseline if baseline[name] != candidate[name])
    changes = [name for name in raw_changes
               if list(map(code_case, baseline[name][1])) != list(map(code_case, candidate[name][1]))]
    expected = sorted(sys.argv[3:])
    print(json.dumps(dict(components=len(baseline), changes=changes, expected=expected,
                          case_only_changes=sorted(set(raw_changes) - set(changes))), ensure_ascii=False))
    assert changes == expected
