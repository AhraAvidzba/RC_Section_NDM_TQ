﻿# Читает фактический VBA из отдельной проверяемой книги без импорта исходников,
# запуска макросов или сохранения книги. Экспорт служит доказательством
# source/book equality; операция не исправляет проверяемый артефакт.
param(
    [Parameter(Mandatory=$true)][string]$WorkbookPath,
    [Parameter(Mandatory=$true)][string]$OutputPath
)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $env:NDM_SECANT_EXPORT_ROOT).Path
$allowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/Audit03')) + [IO.Path]::DirectorySeparatorChar
$postAuditAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/PostAudit03')) + [IO.Path]::DirectorySeparatorChar
$performanceAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/Performance')) + [IO.Path]::DirectorySeparatorChar
$plateauAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/PlateauSlope_2026-10-11')) + [IO.Path]::DirectorySeparatorChar
$openIssuesAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/OpenIssues_2026-10-11')) + [IO.Path]::DirectorySeparatorChar
$geometryAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/GeometryDeclarative_2026-10-12')) + [IO.Path]::DirectorySeparatorChar
$reviewAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/GeometryReview_2026-10-12')) + [IO.Path]::DirectorySeparatorChar
$endpointAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/RoundedEndpoint_2026-10-12')) + [IO.Path]::DirectorySeparatorChar
$fullAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/GeometryFull_2026-10-13')) + [IO.Path]::DirectorySeparatorChar
$guardGuideAllowed = [IO.Path]::GetFullPath((Join-Path $root 'docs/regression/ExcelGuardGuide_2026-10-13')) + [IO.Path]::DirectorySeparatorChar
$source = (Resolve-Path -LiteralPath (Join-Path $root $WorkbookPath)).Path
$output = [IO.Path]::GetFullPath((Join-Path $root $OutputPath))
$publishedWorkbook = Join-Path $root 'workbook/output/RC_Section_NDM.xlsm'
$dependentRowsAllowed=[IO.Path]::GetFullPath((Join-Path $root "docs/regression/DependentRowOffsets_2026-10-17"))+[IO.Path]::DirectorySeparatorChar
$structuredTablesAllowed=[IO.Path]::GetFullPath((Join-Path $root "docs/regression/StructuredGeometryTables_2026-10-17"))+[IO.Path]::DirectorySeparatorChar
$sharedRebarAllowed=[IO.Path]::GetFullPath((Join-Path $root "docs/regression/SharedRebarInput_2026-10-18"))+[IO.Path]::DirectorySeparatorChar
$workflowAllowed=[IO.Path]::GetFullPath((Join-Path $root 'docs/regression/SectionWorkflowLayers_2026-10-21'))+[IO.Path]::DirectorySeparatorChar
foreach ($path in @($source, $output)) {
    # Итоговая приёмка может читать именно опубликованную книгу. Это исключение
    # только для source; dump создаётся в evidence, без сохранения книги и запуска макросов.
    if ($path -eq $source -and $source -eq $publishedWorkbook) {continue}
    if (-not $path.StartsWith($workflowAllowed,[StringComparison]::OrdinalIgnoreCase) -and -not $path.StartsWith($sharedRebarAllowed,[StringComparison]::OrdinalIgnoreCase) -and -not $path.StartsWith($structuredTablesAllowed,[StringComparison]::OrdinalIgnoreCase) -and -not $path.StartsWith($dependentRowsAllowed,[StringComparison]::OrdinalIgnoreCase) -and -not $path.StartsWith($allowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($postAuditAllowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($performanceAllowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($plateauAllowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($openIssuesAllowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($geometryAllowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($reviewAllowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($endpointAllowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($fullAllowed, [StringComparison]::OrdinalIgnoreCase) -and
        -not $path.StartsWith($guardGuideAllowed, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Read-only export paths must stay in their regression evidence directory.'
    }
}
if (Test-Path -LiteralPath $output) { throw 'Export already exists; use a new evidence path.' }
$beforeHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$excel = $null
$book = $null
$text = New-Object Text.StringBuilder
$componentCount = 0
$ownedPid=0;$ownedTicks=0
$preexisting=@(Get-Process Excel -ErrorAction SilentlyContinue)
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class VbaSnapshotWindow{[DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hWnd,out uint id);}'
try {
    $excel = New-Object -ComObject Excel.Application
    [uint32]$id=0;[void][VbaSnapshotWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd,[ref]$id)
    $owner=Get-Process -Id $id -ErrorAction Stop
    if ($id -le 0 -or $id -in $preexisting.Id -or $owner.ProcessName -ine 'EXCEL') { throw 'Export requires a verified new Excel instance.' }
    $ownedPid=[int]$id;$ownedTicks=$owner.StartTime.ToUniversalTime().Ticks
    Write-Output ('OWNED_EXCEL: id='+$ownedPid+'; utcStartTicks='+$ownedTicks)
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AutomationSecurity = 3
    $excel.EnableEvents=$false
    Write-Output 'EXPORT_OPEN_START'
    $workbooks = $excel.Workbooks
    $book = $workbooks.Open($source, 0, $true)
    [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($workbooks)
    Write-Output 'EXPORT_OPEN_DONE'
    if (-not $book.ReadOnly) { throw 'Verification workbook must be read-only.' }
    [void]$text.AppendLine('VBA PROJECT EXPORT')
    [void]$text.AppendLine('Workbook: ' + $book.Name)
    [void]$text.AppendLine('Date: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    if(-not $book.HasVBProject){throw 'Verification workbook did not expose a VBA project.'}
    $project=$book.VBProject
    Write-Output 'EXPORT_VBE_START'
    $vbe = $excel.VBE
    $vbe.ActiveVBProject = $project
    [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($vbe)
    Write-Output 'EXPORT_VBE_DONE'
    $components = $project.VBComponents
    $expectedComponentCount = [int]$components.Count
    if($expectedComponentCount -lt 1){throw 'VBA project component collection is empty; export is not accepted.'}
    for($componentIndex=1;$componentIndex -le $expectedComponentCount;$componentIndex++) {
        if($componentIndex -eq 1 -or $componentIndex % 25 -eq 0){Write-Output ('EXPORT_COMPONENT_INDEX: '+$componentIndex)}
        $component=$components.Item($componentIndex)
        $componentCount++
        [void]$text.AppendLine('=' * 100)
        [void]$text.AppendLine('COMPONENT: ' + $component.Name)
        [void]$text.AppendLine('TYPE: ' + $component.Type)
        $module = $component.CodeModule
        $lineCount = $module.CountOfLines
        [void]$text.AppendLine('LINES: ' + $lineCount)
        [void]$text.AppendLine('=' * 100)
        if ($lineCount -gt 0) { [void]$text.AppendLine($module.Lines(1, $lineCount)) }
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($module)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($component)
        [void]$text.AppendLine()
    }
    if($componentCount -ne $expectedComponentCount){throw 'VBA export component count changed during read.'}
    [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($components)
    [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($project)
    Write-Output 'EXPORT_CLOSE_START'
    $book.Close($false)
    [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($book)
    $book = $null
    Write-Output 'EXPORT_CLOSE_DONE'
    $postCloseHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    if($postCloseHash -ne $beforeHash){throw 'Read-only workbook changed on close.'}
    [IO.File]::WriteAllText($output+'.closed.tmp', $text.ToString(), (New-Object Text.UTF8Encoding($true)))
} finally {
    if ($book) { $book.Close($false) }
    if ($excel) {
        if ($ownedPid) {$excel.Quit()}
        [Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel) | Out-Null
    }
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
    if ($ownedPid) {
        $owned=Get-Process -Id $ownedPid -ErrorAction SilentlyContinue
        if ($owned -and $owned.ProcessName -eq 'EXCEL' -and $owned.StartTime.ToUniversalTime().Ticks -eq $ownedTicks) {try{Stop-Process -InputObject $owned -Force -ErrorAction Stop}catch{if(Get-Process -Id $ownedPid -ErrorAction SilentlyContinue){throw}}}
    }
}
$afterHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
if ($beforeHash -ne $afterHash) { throw 'Verification source changed; export is not accepted.' }
[IO.File]::Move($output+'.closed.tmp', $output)
Write-Output "VBA_READ_ONLY_EXPORT: components=$componentCount; sourceSHA256=$afterHash; sourceUnchanged=True; output=$output"
