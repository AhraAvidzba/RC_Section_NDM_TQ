"""Prepare exact tensors for native replay from the packaged inverse material proof."""
from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json, runpy, sys

here=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve(strict=True)
check="--check" in sys.argv[2:]
m=runpy.run_path(str(here/"Verify-ConcreteAxisPatch.py"))
paths={
    "Free":(-1.,0.,0.),
    "CompressEqual":(-1.,-1.,0.),
    "CompressQuarter":(-1.,-.25,0.),
    "TransverseTension":(-1.,.05,0.),
    "Combined3D":(-1.,.05,-.15),
    "CommonInPlane":(-1.,.2,0.),
}
release=Path("D:/CodexScratch/RC_Section_NDM_TQ/SolverOptimizerReleaseV4_20261116/tools/build_workbook")
src="workbook/output/RC_Section_NDM.xlsm"
diagnostic="docs/regression/Diagnostic.xlsm"
book_sha="A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A"
files={src:repo/src}
needed=("GeometryExampleSupport.ps1","SettingsCatalog.ps1","Run-Audit02ModeTests.ps1",
        "Run-Audit03Watchdog.ps1","Update-IsolatedOptimizerCode.ps1")
for name in sorted(p.name for p in release.iterdir() if p.is_file()):
    p=release/name
    files["tools/build_workbook/"+p.name]=p
def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()
assert sha(repo/src)==book_sha
if "--refresh" in sys.argv[2:]:
    assert sha(here/diagnostic)==book_sha
    for relative, source in files.items():
        if not (here/relative).exists():
            copyfile(source,here/relative)
elif not check:
    assert not (here/diagnostic).exists()
    here.joinpath("src").mkdir()
    for relative,file in files.items():
        target=here/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        copyfile(file,target)
    (here/diagnostic).parent.mkdir(parents=True,exist_ok=True)
    copyfile(here/src,here/diagnostic)
assert all(sha(here/name)==sha(source) for name,source in files.items())
all_cases={}

def matrix_values(vector, rotation, is_strain):
    t=m["rotate"](m["diag"](vector),m["rot"](rotation))
    shear=2. if is_strain else 1.
    return t[0][0],t[1][1],t[2][2],shear*t[0][1],shear*t[0][2],shear*t[1][2]

fixture=[]
for name,direction in paths.items():
    for n in (200,400,800):
        history=m["path"](direction,n)
        for angle in ((0.,37.) if n==400 else (0.,)):
            case=f"{name}_{n}_{int(angle)}"
            initial=dict(total_strain=(0.,0.,0.),nominal_stress=(0.,0.,0.), plastic_strain=(0.,0.,0.),
                         tension_energy=0.,compression_energy=0.)
            records=[initial]+[dict(state) for state in history]
            all_cases[case]=dict(direction=direction,rotation_angle=angle,intervals=n,steps=records)
            fixture.append(f"CASE;{case};{len(records)}")
            for i,s in enumerate(records):
                strain=matrix_values(s["total_strain"],angle,True)
                s["tensor_strain"]=strain
                s["tensor_stress"]=matrix_values(s["nominal_stress"],angle,False)
                s["tensor_plastic"]=matrix_values(s["plastic_strain"],angle,True)
                fixture.append(";".join(("STRAIN",str(i),*(format(v,".17g") for v in strain))))
def verify_or_write(path, payload):
    if check:
        assert path.read_bytes()==payload
    else:
        path.write_bytes(payload)
verify_or_write(here/"InverseStrains.csv",("\r\n".join(fixture)+"\r\n").encode("ascii"))
verify_or_write(here/"ExpectedReplay.json",(json.dumps(all_cases,separators=(",",":"),allow_nan=False)+"\n").encode("ascii"))
proof=dict(workbook_sha256=book_sha,only_updated_modules=["modTestConcreteAxisReplay"],
           cases=len(all_cases),samples=sum(len(c["steps"]) for c in all_cases.values()),
           inputs_sha256={**{name:sha(here/name) for name in files},
                          **{name:sha(here/name) for name in ("InverseStrains.csv","ExpectedReplay.json",
                              "Verify-ConcreteAxisPatch.py","tests/modTestConcreteAxisReplay.bas")}})
verify_or_write(here/"Preparation.json",(json.dumps(proof,indent=2)+"\n").encode("ascii"))
print(sha(here/"Preparation.json"),proof["cases"],proof["samples"])



