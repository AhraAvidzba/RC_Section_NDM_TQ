"""Verify inverse point histories against the private workbook's actual VBA trace."""
from collections import Counter,defaultdict
from hashlib import sha256
import json,math,re,runpy,sys
from pathlib import Path

here=Path(__file__).resolve().parent
m=runpy.run_path(str(here/"Verify-ConcreteAxisPatch.py"))
def read(path):
    return json.loads(path.read_text("utf-8-sig"))
def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()
def maxabs(a,b):
    return max(abs(x-y) for x,y in zip(a,b,strict=True))
def finite(text):
    vals=list(map(float,text))
    assert all(map(math.isfinite,vals)),text
    return vals

def parse():
    prep=read(here/"Preparation.json")
    for relative,sha in prep["inputs_sha256"].items():
        path=here/relative
        if relative=="workbook/output/RC_Section_NDM.xlsm" and not path.exists():
            assert sha==prep["workbook_sha256"]
        else:
            assert digest(path)==sha,relative
    expected=read(here/"ExpectedReplay.json")
    assert len(expected)==prep["cases"]
    assert sum(len(c["steps"]) for c in expected.values())==prep["samples"]
    def tensor_of(vector, angle, shear):
        t=m["rotate"](m["diag"](vector),m["rot"](angle))
        return t[0][0],t[1][1],t[2][2],shear*t[0][1],shear*t[0][2],shear*t[1][2]
    # Rebuild from immutable diagonal values. The early generator shared history records
    # between rotations when writing its secondary JSON. The actual VBA CSV was written
    # before those diagnostic keys were overwritten.
    fixture=iter((here/"InverseStrains.csv").read_text("ascii").splitlines())
    for key,case in expected.items():
        assert next(fixture)==f"CASE;{key};{len(case['steps'])}"
        for i,state in enumerate(case["steps"]):
            angle=case["rotation_angle"]
            raw=next(fixture).split(";")
            assert raw[:2]==["STRAIN",str(i)]
            state["tensor_strain"]=tensor_of(state["total_strain"],angle,2.)
            assert tuple(finite(raw[2:]))==state["tensor_strain"]
            state["tensor_stress"]=tensor_of(state["nominal_stress"],angle,1.)
            state["tensor_plastic"]=tensor_of(state["plastic_strain"],angle,2.)
    assert next(fixture,None) is None
    report=here/"Native/ConcreteAxisReplay.txt"
    native=report.with_suffix(".csv")
    receipt=read(here/"docs/regression/CodeUpdate.json")
    assert receipt["Compiled"] and not receipt["ProductionChanged"]
    assert receipt["Modules"]==prep["only_updated_modules"]
    assert receipt["ProductionSHA256"]==prep["workbook_sha256"]
    shadow=here/"docs/regression/Diagnostic.xlsm"
    if shadow.exists():
        assert digest(shadow)==receipt["WorkbookSHA256"]
    owner=read(report.with_suffix(".txt.Ownership.json"))
    closure=read(report.with_suffix(".txt.ProcessClosure.json"))
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"]
    assert receipt["WorkbookSHA256"]==owner["SourceSHA256"]
    assert closure["ChildHasExited"] and closure["Passed"] and closure["RunnerCleanupValid"]
    final=closure["Closure"]["FinalState"]
    assert final["State"]=="Absent"
    assert [owner[k] for k in ("PID","StartTicksUTC")]==[final[k] for k in ("PID","StartTicksUTC")]
    assert read(here/"CompileClosure.json")["State"]=="Absent"
    elapsed=read(here/"Native/RunReceipt.json")
    case_data={}
    probes={}
    total=0
    for line in native.read_text("cp1251").splitlines():
        parts=line.split(";")
        if parts[0]=="CASE":
            _,key,n=parts
            assert key not in case_data and int(n)==len(expected[key]["steps"])
            current=dict(steps=[],failure=None)
            case_data[key]=current
        elif parts[0]=="STEP":
            _,key,i,plastic,sign,substeps,*raw=parts
            assert int(i)==len(case_data[key]["steps"]) and len(raw)==8
            values=finite(raw)
            record=dict(index=int(i),plastic=bool(int(plastic)),principal_sign=int(sign),substeps=int(substeps),
                       stress=values[:6],energy=values[6:])
            assert record["principal_sign"] in (-1,0,1)
            assert record["substeps"] in (0,1,2,4,8,16)
            assert 0.<=min(record["energy"])<=max(record["energy"])<=1.
            case_data[key]["steps"].append(record)
            total+=1
        elif parts[0]=="STOP":
            _,key,i,code,branch=parts
            assert int(i)==len(case_data[key]["steps"])
            case_data[key]["failure"]=dict(index=int(i),return_code=int(code),branch_ok=bool(int(branch)))
        elif parts[0]=="DIRECTION":
            assert parts[1]=="CommonInPlane_400_0"
            probes["case"]=parts[1]
            probes["direction"]=finite(parts[2:])
            probes["results"]={}
        elif parts[0]=="PROBE":
            _,h,side,code,branch,plastic,principal,n,*stress=parts
            assert len(stress)==6
            key=(float(h),int(side))
            assert key not in probes["results"]
            probes["results"][key]=dict(return_code=int(code),branch_ok=bool(int(branch)),
                 plastic=bool(int(plastic)),principal_sign=int(principal),substeps=int(n),stress=finite(stress))
        else:
            assert parts==["PROBE_HISTORY_UNCHANGED","CommonInPlane_400_0"],parts
            probes["history_unchanged"]=True
    assert set(case_data)==set(expected)
    failures=sum(seq["failure"] is not None for seq in case_data.values())
    assert re.search(rf"^TOTAL_CONCRETE_AXIS_REPLAY: passed={total}; failed={failures}$",
                     report.read_text("utf-8-sig"),re.M)
    proof=dict(workbook_sha256=prep["workbook_sha256"],private_workbook_sha256=receipt["WorkbookSHA256"],
               native_raw_sha256=digest(native),passed_points=total,failed_paths=failures,timeout=False,
               total_paths=len(case_data),native_exit=elapsed["exit"],native_wall_s=elapsed["wall_seconds"],
               production_class_replaced=False,fixtures_sha256=prep["inputs_sha256"]["InverseStrains.csv"])
    return expected,case_data,probes,proof

def stress_matrix(vector):
    x,y,z,xy,xz,yz=vector
    return ((x,xy,xz),(xy,y,yz),(xz,yz,z))

def plastic_from_output(state, strain):
    fc,e,nu,fc0,kmax,loc,gc=(m[key] for key in ("FC","E","NU","FC0","KC_PEAK","LENGTH","GC"))
    kt,kc=state["energy"]
    density=gc/loc
    eq=.5*(fc+fc0)*kmax/density
    if kc<=eq:
        hardening=(fc-fc0)/kmax
        x=2.*kc*density/(fc0+math.sqrt(fc0**2+2.*hardening*kc*density))
    else:
        rate=fc/(density-eq*density)
        x=kmax-math.log((1.-kc)/(1.-eq))/rate
    dc=1.-math.exp(math.log(1.-m["DC_PEAK"])*x/kmax)
    r=m["spectrum_a2"](stress_matrix(state["stress"]))
    tensile_fraction=sum(max(z,0.) for z in r)/sum(abs(z) for z in r) if any(r) else 0.
    scale=(1.-tensile_fraction*kt)*(1.-dc)
    st=[s/scale for s in state["stress"]]
    tr=sum(st[:3])
    elastic=tuple(((1.+nu)*s-(nu*tr if i<3 else 0.))/e*(1. if i<3 else 2.) for i,s in enumerate(st))
    return [x-y for x,y in zip(strain,elastic,strict=True)]

def compare(expected,case_data,probes,proof):
    cases={}
    for key,case in case_data.items():
        wanted=expected[key]
        n=wanted["intervals"]
        ref=wanted["steps"]
        observed=case["steps"]
        assert (case["failure"] is None)==(len(observed)==len(ref))
        checks=[]
        for native,entry in zip(observed,ref):
            i=native["index"]
            tensor=entry["tensor_stress"]
            plane=abs(native["stress"][2]) if wanted["direction"][2]==0. else None
            est=plastic_from_output(native,entry["tensor_strain"])
            target_branch = i>=2
            branch_stress=m["spectrum_a2"](stress_matrix(tensor))[-1]
            row=dict(index=i,plastic_expected=target_branch,plastic=native["plastic"],
                     max_abs_stress_gap_MPa=maxabs(tensor,native["stress"]),
                     max_abs_energy_gap=maxabs((entry["tension_energy"],entry["compression_energy"]),native["energy"]),
                     max_abs_plastic_gap=maxabs(est,entry["tensor_plastic"]),
                     plane_stress_normal_residual_MPa=plane,
                     observed_sx_MPa=native["stress"][0],reference_sx_MPa=tensor[0],
                     expected_max_principal_MPa=branch_stress,observed_principal_sign=native["principal_sign"])
            checks.append(row)
        keys=("max_abs_stress_gap_MPa","max_abs_energy_gap","max_abs_plastic_gap","plane_stress_normal_residual_MPa")
        cases[key]=dict(
            n=len(observed),complete=(case["failure"] is None),first_unaccepted=case["failure"],
            late_plastic_steps=sum(native["plastic"] for native in observed[2:]),
            branch_mismatch=[r["index"] for r in checks if r["plastic"]!=r["plastic_expected"]],
            near_zero_principal_signs=dict(Counter(str(r["observed_principal_sign"]) for r in checks if abs(r["expected_max_principal_MPa"])<=1e-10)),
            strictly_nonzero_principal_mismatches=[r["index"] for r in checks if r["expected_max_principal_MPa"]>1e-10 and r["observed_principal_sign"]!=1],
            local_substeps=dict(Counter(native["substeps"] for native in observed)),
            checkpoints={str(i):checks[i] for i in (0,1,n//2+1,n+1) if i<len(checks)},
            maximum_over_accepted={k:max((r[k] for r in checks if r[k] is not None),default=None) for k in keys},
            maximum_at_step={k:max((r for r in checks if r[k] is not None),key=lambda r:r[k],default={}).get("index") for k in keys}
        )
    resolutions={}
    for key in expected:
        if not key.endswith("_200_0"):continue
        name=key.removesuffix("_200_0")
        r=case_data
        def gaps(base,other):
            a=r[f"{name}_{base}_0"]["steps"]; b=r[f"{name}_{other}_0"]["steps"]
            pairs=[(state,b[(i-1)*(other//base)+1 if i else 0]) for i,state in enumerate(a)
                   if ((i-1)*(other//base)+1 if i else 0)<len(b)]
            return max((maxabs(x["stress"],y["stress"]) for x,y in pairs),default=None)
        a=r[f"{name}_400_0"]["steps"]; b=r[f"{name}_400_37"]["steps"]
        diffs=[]
        for unrot,rot in zip(a,b):
            pred=m["rotate"](stress_matrix(unrot["stress"]),m["rot"](37.))
            v=(pred[0][0],pred[1][1],pred[2][2],pred[0][1],pred[0][2],pred[1][2])
            diffs.append(maxabs(v,rot["stress"]))
        resolutions[name]=dict(native_max_stress_gap_200_to_400_MPa=gaps(200,400),
                    native_max_stress_gap_400_to_800_MPa=gaps(400,800),
                    rotation_common_points=len(diffs),max_stress_covariance_gap_MPa=max(diffs,default=None))
    if probes:
        assert probes["history_unchanged"]
        case=probes["case"]
        reference=expected[case]["steps"]
        strain_now,strain_past=(reference[k]["tensor_strain"] for k in (-1,-2))
        difference=[a-b for a,b in zip(strain_now,strain_past,strict=True)]
        scale=max(map(abs,difference))
        assert maxabs(probes["direction"],[d/scale for d in difference])<1e-14
        base=case_data[case]["steps"][-1]["stress"]
        result=[]
        for h in (1e-9,1e-8,1e-7):
            minus,plus=(probes["results"][h,k] for k in (-1,1))
            item=dict(h=h,minus=minus,plus=plus)
            if not minus["return_code"] and not plus["return_code"]:
                item["central_stress_slope_MPa"]=[(a-b)/(2.*h) for a,b in zip(plus["stress"],minus["stress"],strict=True)]
                item["right_stress_slope_MPa"]=[(a-b)/h for a,b in zip(plus["stress"],base,strict=True)]
                item["left_stress_slope_MPa"]=[(a-b)/h for a,b in zip(base,minus["stress"],strict=True)]
            result.append(item)
        probes=dict(case=case,normalized_strain_secant=probes["direction"],committed_base_stress=base,
                    history_unchanged=True,results=result)
    proof.update(paths=cases,resolutions=resolutions,read_only_endpoint_probes=probes)
    return proof

if __name__=="__main__":
    proof=compare(*parse())
    out=Path(sys.argv[1]) if len(sys.argv)>1 else here/"NativeReplayChecks.json"
    out.write_text(json.dumps(proof,indent=2,allow_nan=False)+"\n","utf-8")
    print(digest(out),proof["passed_points"],proof["failed_paths"])
    for name,v in proof["paths"].items():
        print(name,v["n"],v["maximum_over_accepted"],v["local_substeps"])

