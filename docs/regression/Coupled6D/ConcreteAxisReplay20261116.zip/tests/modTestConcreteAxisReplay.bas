Attribute VB_Name = "modTestConcreteAxisReplay"
Option Explicit

' ============================================================================
' ДЛЯ ТЕСТОВ
' Повтор предписанных тензоров деформации в неизменённом законе бетона.
' Каждая история начинает расчёт без повреждений в частной книге.
' ============================================================================

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет фактические напряжения, энергии, ветвь и число внутренних подшагов.
Public Function RunTestConcreteAxisReplay(ByVal inputPath As String, ByVal casesText As String) As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для материальной проверки требуется изолированная книга."
    Dim destination As String: destination = ThisWorkbook.Path & "\ConcreteAxisReplay.csv"
    If Len(Dir$(destination)) > 0 Then Err.Raise 5, , "Протокол материальной проверки уже существует."
    Dim fin As Integer: fin = FreeFile
    Open inputPath For Input Access Read As #fin
    Dim fout As Integer: fout = FreeFile
    Open destination For Output Access Write As #fout
    Dim concrete As CCoupledConcreteResponse, material As ICoupledPointResponse
    Dim fields() As String, inputRow As String, label As String, record As String
    Dim remaining As Long, sample As Long, col As Long, cases As Long, accepted As Long, failures As Long
    Dim strain(1 To 6) As Double, previous(1 To 6) As Double, stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim tension As Double, compression As Double, plastic As Boolean, substeps As Long, principalSign As Long
    Dim blocked As Boolean, branchOK As Boolean, code As ESolverFailureCode
    Do Until EOF(fin)
        Line Input #fin, inputRow
        fields = Split(inputRow, ";")
        If fields(0) = "CASE" Then
            If UBound(fields) <> 2 Or remaining <> 0 Then Err.Raise 5, , "Нарушена структура блока материальной истории."
            label = fields(1): remaining = CLng(Val(fields(2))): sample = 0: blocked = False
            If remaining < 2 Then Err.Raise 5, , "Материальная история без загрузки."
            Set concrete = New CCoupledConcreteResponse
            concrete.Initialize 1, 30000#, 0.2, 17.4, 29#, 3#, 0.002, 0.12, 80#, 125#
            Set material = concrete
            cases = cases + 1
            Print #fout, inputRow
        Else
            If fields(0) <> "STRAIN" Or UBound(fields) <> 7 Or remaining <= 0 Then _
                Err.Raise 5, , "Неверная строка тензора деформаций."
            If CLng(Val(fields(1))) <> sample Then Err.Raise 5, , "Нарушен порядок шагов материальной истории."
            remaining = remaining - 1
            If Not blocked Then
                For col = 1 To 6: strain(col) = Val(fields(col + 1)): Next col
                branchOK = concrete.TryReadConcreteBranch(1, strain, plastic, principalSign, substeps)
                code = material.EvaluatePoint(1, strain, stress, tangent, ctmStressOnly)
                If branchOK And code = sfcNone Then
                    material.AcceptTrial
                    concrete.AcceptedPointDamage 1, tension, compression
                    record = "STEP;" & label & ";" & CStr(sample) & ";" & CStr(Abs(CLng(plastic))) & ";" & _
                        CStr(principalSign) & ";" & CStr(substeps)
                    For col = 1 To 6: record = record & ";" & Trim$(Str$(stress(col))): Next col
                    Print #fout, record & ";" & Trim$(Str$(tension)) & ";" & Trim$(Str$(compression))
                    If remaining = 0 And label = "CommonInPlane_400_0" Then _
                        RecordTestAxisPartial concrete, material, strain, previous, stress, tension, compression, fout
                    For col = 1 To 6: previous(col) = strain(col): Next col
                    accepted = accepted + 1
                Else
                    Print #fout, "STOP;" & label & ";" & CStr(sample) & ";" & CStr(code) & ";" & CStr(Abs(CLng(branchOK)))
                    failures = failures + 1: blocked = True
                End If
            End If
            sample = sample + 1
        End If
    Loop
    If cases <> CLng(Val(casesText)) Or remaining <> 0 Then Err.Raise 5, , "Прочитан неполный набор материальных историй."
    Close #fin, #fout
    RunTestConcreteAxisReplay = "TOTAL_CONCRETE_AXIS_REPLAY: passed=" & CStr(accepted) & "; failed=" & CStr(failures)
    Exit Function
Failed:
    Dim detail As String: detail = Err.Source & " " & Err.Description
    On Error Resume Next
    If fin > 0 Then Close #fin
    If fout > 0 Then Close #fout
    RunTestConcreteAxisReplay = "RUNTIME ERROR: " & detail
End Function



' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает напряжения по обе стороны конечной точки без изменения принятой истории.
Private Sub RecordTestAxisPartial(ByVal concrete As CCoupledConcreteResponse, ByVal material As ICoupledPointResponse, _
        ByRef endpoint() As Double, ByRef previous() As Double, ByRef acceptedStress() As Double, _
        ByVal acceptedTension As Double, ByVal acceptedCompression As Double, ByVal fout As Integer)
    Dim i As Long, signValue As Long, maxDirection As Double, record As String
    Dim offset As Variant, difference(1 To 6) As Double, probe(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim tension As Double, compression As Double, plastic As Boolean, branchOK As Boolean
    Dim principalSign As Long, substeps As Long, code As ESolverFailureCode
    For i = 1 To 6
        difference(i) = endpoint(i) - previous(i)
        maxDirection = GeomMax(maxDirection, Abs(difference(i)))
    Next i
    If maxDirection <= 0# Then Err.Raise 5, , "Нулевая секущая в конечной точке."
    record = "DIRECTION;CommonInPlane_400_0"
    For i = 1 To 6
        difference(i) = difference(i) / maxDirection
        record = record & ";" & Trim$(Str$(difference(i)))
    Next i
    Print #fout, record
    For Each offset In Array(0.000000001, 0.00000001, 0.0000001)
        For signValue = -1 To 1 Step 2
            For i = 1 To 6: probe(i) = endpoint(i) + signValue * CDbl(offset) * difference(i): Next i
            branchOK = concrete.TryReadConcreteBranch(1, probe, plastic, principalSign, substeps)
            code = material.EvaluatePoint(1, probe, stress, tangent, ctmStressOnly, False)
            record = "PROBE;" & Trim$(Str$(CDbl(offset))) & ";" & CStr(signValue) & ";" & CStr(code) & ";" & _
                CStr(Abs(CLng(branchOK))) & ";" & CStr(Abs(CLng(plastic))) & ";" & CStr(principalSign) & ";" & CStr(substeps)
            For i = 1 To 6: record = record & ";" & Trim$(Str$(stress(i))): Next i
            Print #fout, record
        Next signValue
    Next offset
    concrete.AcceptedPointDamage 1, tension, compression
    If tension <> acceptedTension Or compression <> acceptedCompression Then _
        Err.Raise 5, , "Возмущение изменило принятую историю."
    If material.EvaluatePoint(1, endpoint, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
        Err.Raise 5, , "Не возвращается принятое состояние после непринятых проб."
    For i = 1 To 6
        If stress(i) <> acceptedStress(i) Then Err.Raise 5, , "Непринятая проба изменила фактическое напряжение."
    Next i
    Print #fout, "PROBE_HISTORY_UNCHANGED;CommonInPlane_400_0"
End Sub
