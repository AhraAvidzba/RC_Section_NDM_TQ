"""Повторяет проверку нативных квитанций и предельной строки Results."""

from argparse import ArgumentParser
import json
from math import isclose
from pathlib import Path
import re
from runpy import run_path


HERE = Path(__file__).resolve().parent
STOCK = run_path(str(HERE / 'Verify-NativeSelectedStock.py'))
CAPTURE = run_path(str(HERE / 'Capture-Eccentric.py'))
CANDIDATE_SHA = '331009F550020B2818B8C7DEBCA57539C735F4E050CAAA724CE02E15DF78CE39'
RESULT_XML_SHA = '05A48943CABDA9480F5C3B4D8926361ADD7A88DEAB135277DB1830CFA82011FC'


def verify_eccentric():
    """Отделяет доказательство тестовой копии от регрессий рабочего пакета."""
    captured = json.loads((HERE / 'EccentricOOXML.json').read_text(encoding='utf-8'))
    assert captured['base_sha256'] == STOCK['BOOK_SHA']
    assert captured['candidate_sha256'] == CANDIDATE_SHA
    assert captured['component_count'] == 225
    assert captured['changed_vba_modules'] == ['modTestCoupledElasticState']
    assert captured['original_test_module_prefix_unchanged']
    assert captured['appended_test_code_matches_source']
    assert 'PRIVATE_CODE_READY: modules=1; production unchanged=True' in (
        HERE / 'CompileCorrected.log').read_text(encoding='utf-8-sig')
    raw = CAPTURE['extract_row'](HERE / 'EccentricResultsParts.zip')
    assert raw['anchor'] == captured['anchor']
    assert raw['results_xml_sha256'] == captured['results_xml_sha256'] == RESULT_XML_SHA
    assert {str(key): value for key, value in raw['cells'].items()} == captured['cells']

    row = {offset: value for offset, (_, value) in raw['cells'].items()}
    assert row[35] == chr(955) + '*T'
    assert row[58] == row[64] == 'FAIL'
    multiplier = row[37]
    assert 0 < multiplier < 1 and row[59] == multiplier
    assert isclose(multiplier, 0.982444763183594, rel_tol=0, abs_tol=1e-14)
    tf = 9806.65
    scales = [tf, tf * 1000, tf * 1000, tf * 1000, tf, tf]
    actual = [row[offset] * scale for offset, scale in zip(range(38, 44), scales)]
    expected = [-250, -3200, 6450, 10510080 * multiplier, 3, -4]
    assert all(isclose(a, b, rel_tol=1e-13) for a, b in zip(actual, expected))

    native = STOCK['native']('EccentricVerified.txt', CANDIDATE_SHA,
                             {'COUPLED_ECCENTRIC_TORQUE': 33}, True)
    transcript = (HERE / 'EccentricVerified.txt').read_text(encoding='utf-8-sig')
    audit, = re.findall(r'^ECCENTRIC_TORQUE_STATUS;FAIL;([^;]+);FAIL;PHYSICAL_LIMIT_EXCEEDED$',
                        transcript, re.M)
    assert isclose(float(audit), multiplier, rel_tol=0, abs_tol=1e-14)
    # Перенос T к центру использует обе поперечные силы и обе координаты
    # точки приложения. Эти слагаемые не масштабируются на траектории T.
    native_target, = re.findall(r'^OK: Explicit T CapacityState saves the correct centered target T actual=([^ ]+) ',
                                transcript, re.M)
    centered_torque = expected[3] + 35 * expected[5] - (-20) * expected[4]
    assert isclose(float(native_target) * tf * 1000, centered_torque, rel_tol=1e-13)
    return {'native': native, 'candidate_sha256': CANDIDATE_SHA, 'saved_sha256': captured['saved_sha256'],
            'result_xml_sha256': RESULT_XML_SHA, 'lambda': multiplier,
            'actions_at_load_point_N_Nmm': actual, 'centered_torque_Nmm': centered_torque,
            'hoop_direct_status': row[58], 'hoop_capacity_status': row[64]}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    report = {'installed': STOCK['main'](args.repo.resolve()), 'eccentric_test_copy': verify_eccentric()}
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(report, output, indent=2, sort_keys=True)
        output.write('\n')
    print('EXPLICIT TORQUE WORKBOOK EVIDENCE OFFLINE PASS')
