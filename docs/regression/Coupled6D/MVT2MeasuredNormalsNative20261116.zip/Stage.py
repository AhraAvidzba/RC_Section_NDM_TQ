"""Seal the reoriented continuation at ForceHalf inside the measured strain radius."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"force15"
EVIDENCE=BASE/"MVT2Force15Native20261116.zip"
SHA="AAF97ABED8510F390488F2A5C515E57431BED7ED56694181D2CD763F35A8900F"


def digest(x):
    return sha256(x).hexdigest().upper()


def save(name,raw):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==raw,path
    else:
        path.write_bytes(raw)
    return digest(raw)


def roles(text):
    return text.replace("ForceHalf","ReturnToTrial").replace("LockedFull","ForceHalf").replace("ReturnToTrial","NormalsHalf")


def main():
    assert digest(EVIDENCE.read_bytes())==SHA
    from sys import path
    path.insert(0,str(BASE))
    import VerifyBase as v
    with ZipFile(EVIDENCE) as archive:
        previous_prep=json.loads(archive.read("Preparation.json"))
        inputs={name:save(name,archive.read(name)) for name in
                ("Replay.csv","VerifyBase.py","Guard-IsolatedOffice.ps1","Run-MVT2ShearControlled.ps1")}
        for name in tuple(inputs):
            assert inputs[name]==previous_prep["inputs"][name]
        for asset,sha in previous_prep["inputs"].items():
            if asset.startswith("tools/"):
                inputs[asset]=save(asset,archive.read(asset))
                assert inputs[asset]==sha
        native=archive.read("NativeHalf/MVT2.csv")
        inputs["PreviousNative.csv"]=save("PreviousNative.csv",native)
        prior=json.loads(archive.read("ForceProbe.json"))
        decision=json.loads(archive.read("ForceNext.json"))
        assert digest(native)==decision["native_trace_sha256"]
        choice=decision["conditional_candidate"]
        assert choice["regime"]=="surface_normals_all_three" and choice["radius"]==5e-9
        assert choice["cumulative_gain_over_tau"]>=8 and choice["additional_gain_over_tau"]>=5
        inputs["ForceNext.json"]=save("ForceNext.json",archive.read("ForceNext.json"))
        module=archive.read("tests/modTestCoupledExperiment.bas").decode("utf8").replace("\r\n","\n")
        vba=roles(archive.read("Control.bas").decode("utf8"))
        code=roles(archive.read("Verify-MVT2ShearControlled.py").decode("utf8"))
    states,station=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    before=states["ForceHalf"]
    p={"baseline_field":before["field"],"half_dq":choice["dq"],"half_radius":choice["radius"],
       "q_trial_kN":prior["q_trial_kN"],"q_accepted_kN":prior["q_accepted_kN"],
       "nominal_half_target_MPa":decision["prior_LockedFull_norm_MPa"]-8*prior["tau_MPa"],
       "prior_LockedFull_norm_MPa":decision["prior_LockedFull_norm_MPa"],"tau_MPa":prior["tau_MPa"],
       "original_caps_MPa":prior["original_caps_MPa"],"planning_My_bound_Nmm":decision["planning_My_bound_Nmm"],
       "signed_surface_evaluations_prediction":choice["surface_trial"],"predicted_half_all66_MPa":choice["predictions_all66_MPa"]}
    assert before["q"]==p["q_trial_kN"]
    inputs["ForceProbe.json"]=save("ForceProbe.json",(json.dumps(p,indent=2)+"\n").encode("utf8"))
    row=lambda x:(";".join(map(str,x))+"\r\n").encode("ascii")
    inputs["AnchorField.csv"]=save("AnchorField.csv",row(before["field"]))
    inputs["Half/Candidate.csv"]=save("Half/Candidate.csv",row(("NormalsHalf",p["half_radius"],p["nominal_half_target_MPa"],*p["half_dq"])))
    signature="Public Function RunTestWangShearControlled("
    cut=module.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,module.index(signature))
    inputs["Control.bas"]=save("Control.bas",vba.encode("utf8"))
    inputs["tests/modTestCoupledExperiment.bas"]=save("tests/modTestCoupledExperiment.bas",(module[:cut]+vba).replace("\n","\r\n").encode("utf8"))
    cut=code.index('    for key,xyz in f0["geometry"].items():')
    end=code.index('    return prep,rule',cut)
    code=code[:cut]+code[end:]
    cut=code.index('            if p==3:')
    end=code.index('            probe.append',cut)
    code=code[:cut]+code[end:]
    needle='    no_cross=all(x["flags_before"]==x["flags_after"] for x in probe if x["point"]==15)'
    assert code.count(needle)==1
    code=code.replace(needle,'    no_cross=all(x["flags_before"]==x["flags_after"] and x["F_before_MPa"]*x["F_after_MPa"]>0 for x in probe)')
    code=code.replace('"passes_no_branch_crossing_point15"','"passes_no_branch_crossing_all_three"')
    code=code.replace('"passes_four_tau_norm"','"passes_cumulative_eight_tau_norm"')
    code=code.replace('"gain_over_tau":(v.peak(base)-v.peak(value))/rule["tau_MPa"],',
        '"gain_over_tau":(v.peak(base)-v.peak(value))/rule["tau_MPa"],\n        "cumulative_gain_over_tau":(rule["prior_LockedFull_norm_MPa"]-v.peak(value))/rule["tau_MPa"],')
    inputs["Verify-MVT2ShearControlled.py"]=save("Verify-MVT2ShearControlled.py",code.encode("utf8"))
    book="workbook/output/RC_Section_NDM.xlsm"
    raw=(BASE/book).read_bytes()
    assert digest(raw)==previous_prep["book_sha256"]
    save(book,raw)
    save("docs/regression/Diagnostic.xlsm",raw)
    for directory in ("src","NativeHalf","Temp"):
        (HERE/directory).mkdir(exist_ok=True)
    doc={"inputs":inputs,"book_sha256":previous_prep["book_sha256"],"previous_native_sha256":digest(native),
         "replay_sha256":previous_prep["replay_sha256"],"source_bundle_sha256":SHA,"watchdog_seconds":200}
    print(save("Preparation.json",(json.dumps(doc,indent=2)+"\n").encode("utf8")))


if __name__=="__main__":
    main()
