"""Reconstruct the branch-constrained native correction without an XLSM."""
import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

import VerifyBase as v

HERE=Path(__file__).resolve().parent
PRIOR="AAF97ABED8510F390488F2A5C515E57431BED7ED56694181D2CD763F35A8900F"
CURRENT="11BC995BCE708919D632A441162AED37A6896A79F6083836191F0E44806EF4C7"


def signed_detail(state,X):
    raw,_,_=v.reconstruct(state["field"],state["q"],X)
    parts=[]
    q=state["field"]
    for point in range(1,46):
        x,y,area=X[point,0][:3]
        cols,shape,xn,yn=v.operators(x,y)
        t=X[point,0][13:19]
        grad=(X[point,1][18]-X[point,-1][18])/.002
        w=area/v.AREA
        in_plane=tuple(w*t[i]*a for i,a in cols[5])
        gauge=w*shape[0]*(q[57]+xn*q[59]) if point<=25 else 0.
        parts.append((point,x,y,(*in_plane,-w*shape[0]*grad,gauge)))
    names=("in_plane_normal","in_plane_shear","longitudinal_yz_gradient","gauge_reaction")
    contribution={key:sum(part[-1][j] for part in parts) for j,key in enumerate(names)}
    assert abs(sum(contribution.values())-raw[5])<4e-10
    pressure=max(abs(s) for s in state["r"][56:62])
    ceiling=state["norm_MPa"]-pressure
    closes=sorted(({"point":point,"side":side,"signed_F_MPa":item[6],"plastic_and_principal_flags":item[3:6],
                    "x_mm":item[0],"y_mm":item[1]} for (point,side),item in X.items() if point<=25),
                  key=lambda row:abs(row["signed_F_MPa"]))[:12]
    return {"weak_row6_terms_MPa":contribution,"largest_signed_stations":[[p,x,y,sum(z)] for p,x,y,z in
              sorted(parts,key=lambda p:abs(sum(p[-1])),reverse=True)[:8]],
            "force_floor_MPa":pressure,"q53_through_q60_only_improvement_upper_MPa":ceiling,
            "q53_through_q60_only_improvement_upper_tau":ceiling/state["tol_MPa"],"stations_closest_to_trial_yield":closes}


def surface_intercepts(record,base,trial,station):
    step=v.diff(trial["field"],base["field"])
    result=[]
    for item in record["station_branch_gradients"]:
        point,side=item["point"],item["side"]
        x,y=station[point,side][:2]
        grad=item["gradient_after"]
        F=item["F_after_MPa"]
        if grad is None:
            continue
        dF=v.dot(grad,v.strain_at(step,v.operators(x,y),side))
        intercept=-F/dF if F*dF<0. else None
        result.append({"point":point,"side":side,"F_now_MPa":F,"measured_gradient_direction_dF_MPa":dF,
                       "predicted_F_after_reusing_step_MPa":F+dF,"positive_tangent_intercept":intercept})
    ranked=sorted((row for row in result if row["positive_tangent_intercept"] is not None),
                  key=lambda x:x["positive_tangent_intercept"])
    assert [(x["point"],x["side"]) for x in ranked[:2]]==[(15,-1),(3,1)]
    return {"measured_normal_events":result,"first_two":ranked[:2],
            "event_coordinate_is_tangent_prediction":True,
            "next_diagnostic":"Compare signed all-six and point strains/stresses on both sides of each isolated switching event."}


def replay(args):
    spec=spec_from_file_location("normal_native",HERE/"Verify-MVT2ShearControlled.py")
    checker=module_from_spec(spec)
    spec.loader.exec_module(checker)
    prep=v.read(HERE/"Preparation.json")
    rules=v.read(HERE/"ForceProbe.json")
    assert all(v.digest(HERE/name)==identity for name,identity in prep["inputs"].items())
    if args.workbook is not None:
        assert v.digest(args.workbook)==prep["book_sha256"]
    prior=HERE/"Decision/MVT2Force15Native20261116.zip"
    assert v.digest(prior)==prep["source_bundle_sha256"]==PRIOR
    with ZipFile(prior) as artifact:
        assert (HERE/"PreviousNative.csv").read_bytes()==artifact.read("NativeHalf/MVT2.csv")
        assert (HERE/"ForceNext.json").read_bytes()==artifact.read("ForceNext.json")
        if args.decision:
            # Strict whole-archive SHA is checked before extracting the known package.
            folder=HERE/"DecisionReplay"
            folder.mkdir(exist_ok=True)
            artifact.extractall(folder)
            subprocess.run([sys.executable,"-B","-X","utf8",str(folder/"ReplayProof.py"),"--decision"],check=True)
            assert v.digest(folder/"ForceNext.json")==v.digest(HERE/"ForceNext.json")
    old,old_X=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    base=old["ForceHalf"]
    assert tuple(rules["baseline_field"])==tuple(map(float,checker.one_line("AnchorField.csv")))==base["field"]
    label,radius,gate,*values=checker.one_line("Half/Candidate.csv")
    delta=tuple(map(float,values))
    assert label=="NormalsHalf" and delta==tuple(rules["half_dq"])
    assert v.tensor_radius(delta,base["geometry"])<=float(radius)+4e-16
    assert float(gate)==rules["nominal_half_target_MPa"]
    native=checker.attest(prep,rules,base,old_X["ForceHalf"],delta)
    assert native["trace_sha256"]==CURRENT and native["qualified"]
    archive=HERE/"VerificationHalf.json"
    expected=(json.dumps(native,indent=2)+"\n").replace("\n","\r\n").encode("utf8")
    assert expected==archive.read_bytes()
    tags=v.read_native(HERE/"NativeHalf/MVT2.csv")
    states,X=v.verified_states(tags)
    current=states["NormalsHalf"]
    rows=sorted(({ "row":i+1,"signed_MPa":x} for i,x in enumerate(native["native_force_half_all66_MPa"])),
                key=lambda x:abs(x["signed_MPa"]),reverse=True)
    assert rows[0]["row"]==6
    result={"decision_sha256":v.digest(HERE/"ForceNext.json"),"native_trace_sha256":native["trace_sha256"],
            "verification_sha256":v.digest(archive),"test_overlay_sha256":prep["inputs"]["tests/modTestCoupledExperiment.bas"],
            "book_sha256":prep["book_sha256"],"H24_sha256":prep["replay_sha256"],"exact_H24_restore":native["H24_exact_rollback"],
            "Qy_kN":native["Qy_trial_kN"],"Qy_last_accepted_kN":native["Qy_accepted_kN"],
            "signed_efforts_and_branch_pass":native["qualified"],"history_published":False,"equilibrium":native["equilibrium"],
            "actual_norm_MPa":native["actual_norm_MPa"],"additional_tau":native["gain_over_tau"],
            "cumulative_tau":native["cumulative_gain_over_tau"],"active_rows":rows[:18],"weak_and_branch_detail":signed_detail(current,X["NormalsHalf"]),
            "predicted_branch_surface_intercepts":surface_intercepts(native,states["ForceHalf"],current,X["NormalsHalf"]),
            "compiler":native["compiler"],"owner":native["owner"],"native_wall_s":native["native_wall_s"]}
    out=HERE/"PortableReport.json"
    out.write_bytes((json.dumps(result,indent=2)+"\n").encode("utf8"))
    print(out,v.digest(out))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--decision",action="store_true")
    p.add_argument("--workbook",type=Path)
    replay(p.parse_args())
