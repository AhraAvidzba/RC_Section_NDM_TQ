"""Check exact H24, all efforts and signed trial-yield slopes in the point-15 witness."""
import argparse
import csv
import json
from pathlib import Path

import VerifyBase as v

HERE=Path(__file__).resolve().parent
RUN=HERE/"NativeHalf"


def full(state,stations):
    weak,_,_=v.reconstruct(state["field"],state["q"],stations)
    return (*state["r"],*(a*v.MODULUS for a in weak[-4:]))


def one_line(path):
    data=(HERE/path).read_bytes()
    assert data.count(b"\r\n")==data.count(b"\n")==1
    return data.decode("ascii").strip().split(";")


def preflight():
    prep=v.read(HERE/"Preparation.json")
    assert all(v.digest(HERE/name)==expected for name,expected in prep["inputs"].items())
    assert v.digest(HERE/"workbook/output/RC_Section_NDM.xlsm")==prep["book_sha256"]
    assert v.digest(HERE/"PreviousNative.csv")==prep["previous_native_sha256"]
    assert v.digest(HERE/"Replay.csv")==prep["replay_sha256"]
    rule=v.read(HERE/"ForceProbe.json")
    old,station=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    f0=old["LockedFull"]
    assert f0["q"]==rule["q_trial_kN"] and f0["field"]==tuple(rule["baseline_field"])
    assert f0["field"]==tuple(map(float,one_line("AnchorField.csv")))
    label,radius,gate,*values=one_line("Half/Candidate.csv")
    assert label=="ForceHalf" and float(gate)==rule["nominal_half_target_MPa"] and float(radius)==rule["half_radius"]
    delta=tuple(map(float,values))
    assert len(delta)==60 and delta==tuple(rule["half_dq"])
    assert v.tensor_radius(delta,f0["geometry"])<=float(radius)+4e-16<=1e-8+4e-16
    for key,xyz in f0["geometry"].items():
        if key[0]==3:
            assert v.peak(v.strain_at(delta,v.operators(*xyz[:2]),key[1]))<=2e-17
    return prep,rule,f0,station["LockedFull"],delta


def attest(prep,rule,reference,previous_station,delta):
    build=v.read(HERE/"docs/regression/CodeUpdate.json")
    compiler=v.read(HERE/"CompileClosure.json")
    owner=v.read(RUN/"MVT2.txt.Ownership.json")
    watchdog=v.read(RUN/"MVT2.txt.ProcessClosure.json")
    runtime=v.read(RUN/"RunReceipt.json")
    closed=watchdog["Closure"]["FinalState"]
    assert build["Compiled"] and not build["ProductionChanged"] and build["Modules"]==["modTestCoupledExperiment"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and compiler["State"]=="Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert watchdog["Passed"] and watchdog["ChildHasExited"] and watchdog["ChildExitCode"]==runtime["native_exit"]==0
    assert closed["State"]=="Absent" and closed["PID"]==owner["PID"] and closed["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (RUN/"MVT2.txt").read_text(encoding="utf-8-sig")
    native=RUN/"MVT2.csv"
    tags=v.read_native(native)
    states,stations=v.verified_states(tags)
    [[qbase,q]]=tags["B_TANGENT_LOAD"]
    assert (float(qbase),float(q))==(rule["q_accepted_kN"],rule["q_trial_kN"])
    assert tags["B_FRESH_PHASE"]==[["Half"]] and tags["B_FRESH_PROBES"]==[["1"]]
    history=v.vec(tags,"MVT2_CONTROL_FIELD")
    replay=list(csv.reader((HERE/"Replay.csv").read_text().splitlines(),delimiter=";"))[1:]
    assert len(replay)==len(history)==24
    for i,row in enumerate(replay,1):
        assert int(row[0])==i and v.peak(v.diff(tuple(map(float,row[9:])),history[f"Replay{i}"]))<1e-15
    assert states["Restored24"]==states["Base24"] and stations["Restored24"]==stations["Base24"]
    assert states["Base24"]["field"]==history["Replay24"] and states["Base24"]["q"]==float(qbase)
    before=states["LockedFull"]
    base=full(before,stations["LockedFull"])
    source_error=v.peak(v.diff(base,full(reference,previous_station)))
    assert source_error<=8e-10 and v.peak(v.diff(before["field"],reference["field"]))<3e-15
    steel=v.verify_steel(tags,states,stations,history)
    result={"trace_sha256":v.digest(native),"reference_error_MPa":source_error,"Qy_trial_kN":float(q),
            "Qy_accepted_kN":float(qbase),"H24_exact_rollback":True,"history_published":False,
            "compiler":compiler,"owner":closed,"native_wall_s":runtime["wall_seconds"]}
    if "ForceHalf" not in states:
        assert ["ForceHalf","Residual"] in tags["B_TANGENT_UNAVAILABLE"]
        return {**result,"available":False}
    after=states["ForceHalf"]
    assert after["q"]==before["q"] and after["geometry"]==before["geometry"]
    assert v.peak(v.diff(after["field"],tuple(a+b for a,b in zip(before["field"],delta,strict=True))))<3e-15
    value=full(after,stations["ForceHalf"])
    surface={}
    for label,point,side,ok,F,*grad in tags["B_FORCE_SURFACE"]:
        assert label in ("LockedFull","ForceHalf")
        key=int(point),int(side)
        assert (label,key) not in surface
        assert (len(grad)==6)==bool(int(ok))
        assert abs(float(F)-stations[label][key][6])<4e-10
        surface[label,key]=None if not int(ok) else tuple(map(float,grad))
    assert len(surface)==18
    probe=[]
    for p in (3,15,19):
        for side in (-1,0,1):
            key=p,side
            a,b=(stations[label][key] for label in ("LockedFull","ForceHalf"))
            step=v.diff(b[7:13],a[7:13])
            grad=surface["LockedFull",key]
            g1=surface["ForceHalf",key]
            if p==3:
                assert a[3:6]==b[3:6] and v.peak(step)<=4e-15 and v.peak(v.diff(a[13:19],b[13:19]))<=4e-10
            probe.append({"point":p,"side":side,"F_before_MPa":a[6],"F_after_MPa":b[6],"flags_before":a[3:6],"flags_after":b[3:6],
                "gradient_before":grad,"gradient_after":g1,"tangent_estimate_delta_F_MPa":None if grad is None else v.dot(grad,step),
                "actual_delta_F_MPa":b[6]-a[6]})
    no_cross=all(x["flags_before"]==x["flags_after"] for x in probe if x["point"]==15)
    original=tuple(rule["original_caps_MPa"])
    passed=all(abs(x)<=cap for x,cap in zip(value[56:62],original,strict=True))
    progress=v.peak(value)<=rule["nominal_half_target_MPa"]
    return {**result,"available":True,"base_norm_MPa":v.peak(base),"actual_norm_MPa":v.peak(value),
        "gain_over_tau":(v.peak(base)-v.peak(value))/rule["tau_MPa"],"native_force_half_all66_MPa":value,
        "signed_residuals_N_Nmm":after["signed_force_N_Nmm"],"four_gauges_MPa":value[-4:],
        "peak_steel_MPa":steel["ForceHalf"],"passes_original_six":passed,"passes_four_tau_norm":progress,
        "passes_no_branch_crossing_point15":no_cross,"qualified":passed and progress and no_cross,
        "governing_weak_rows_55_56_MPa":[[base[i-1],value[i-1]] for i in (55,56)],
        "station_branch_gradients":probe,"equilibrium":v.peak(value)<=rule["tau_MPa"]}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--inputs-only",action="store_true")
    p.add_argument("--phase",choices=("Half",))
    args=p.parse_args()
    verified=preflight()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert args.phase=="Half"
        report=attest(*verified)
        output=HERE/"VerificationHalf.json"
        output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
        print(output,v.digest(output))
