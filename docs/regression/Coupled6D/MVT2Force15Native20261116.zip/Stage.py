"""Seal one native read-only point-15 release witness at exact LockedFull."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
NATIVE=BASE/"lock/MVT2BranchLockedNative20261116.zip"
PROBE=BASE/"force-lock/Run/ForceProbe.json"
PIN="42648C93E2A03D55A09F8E9688357D062D3E4210F98FA4B7507CF3FB5820FFF5"
PROBE_SHA="DA522D4C68F0BB700C24D626B91ED73411AEE8DDB6F42F20AC7295DADA4DB261"
BOOK="A90C7A5E610C19D2C3CF0D7DB12831651DB12EEFD052E5DBED1378EE3C2C04FA"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(path,raw):
    dest=HERE/path
    dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():
        assert dest.read_bytes()==raw,dest
    else:
        dest.write_bytes(raw)
    return digest(raw)


def replace(text,src,dest):
    assert text.count(src)==1,src
    return text.replace(src,dest)


def main():
    assert digest(NATIVE.read_bytes())==PIN and digest(PROBE.read_bytes())==PROBE_SHA
    inputs={"ForceProbe.json":put("ForceProbe.json",PROBE.read_bytes())}
    q=json.loads(PROBE.read_text())
    with ZipFile(NATIVE) as z:
        prep=json.loads(z.read("Preparation.json"))
        for name in ("Replay.csv","VerifyBase.py","Guard-IsolatedOffice.ps1"):
            inputs[name]=put(name,z.read(name))
            assert inputs[name]==prep["inputs"][name]
        old=z.read("NativeFull/MVT2.csv")
        assert digest(old)==q["locked_baseline_trace_sha256"]
        inputs["PreviousNative.csv"]=put("PreviousNative.csv",old)
        for name,want in prep["inputs"].items():
            if name.startswith("tools/"):
                inputs[name]=put(name,z.read(name))
                assert inputs[name]==want
        overlay=z.read("tests/modTestCoupledExperiment.bas").decode("utf8").replace("\r\n","\n")
        vba=z.read("Control.bas").decode("utf8")
    vba=replace(vba,'    norm = RecordWangTangentStateTest(output, "Fresh1First",','    norm = RecordWangTangentStateTest(output, "LockedFull",')
    vba=replace(vba,'Не воспроизведено измеренное исходное поле Fresh1First.','Не воспроизведено измеренное исходное поле LockedFull.')
    vba=replace(vba,'    If phase <> "Half" And phase <> "Full" Then','    If phase <> "Half" Then')
    vba=replace(vba,'    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double',
        '''    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double
    Dim responseRow As String, prop As Long''')
    vba=replace(vba,'                flag = Abs(CLng(yielding))','''                flag = Abs(CLng(yielding))
                If (label = "LockedFull" Or label = "ForceHalf") And (point = 3 Or point = 15 Or point = 19) Then
                    responseRow = "B_FORCE_SURFACE;" & label & ";" & CStr(point) & ";" & CStr(side)
                    If materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=True) Then
                        responseRow = responseRow & ";1;" & ExperimentNumberTest(yieldValue)
                        For prop = 1 To 6: responseRow = responseRow & ";" & ExperimentNumberTest(grad(prop)): Next prop
                    Else
                        responseRow = responseRow & ";0;" & ExperimentNumberTest(yieldValue)
                    End If
                    Print #output, responseRow
                End If''')
    inputs["Control.bas"]=put("Control.bas",vba.encode("utf8"))
    name="Public Function RunTestWangShearControlled("
    start=overlay.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,overlay.index(name))
    module=(overlay[:start]+vba).replace("\n","\r\n").encode("utf8")
    inputs["tests/modTestCoupledExperiment.bas"]=put("tests/modTestCoupledExperiment.bas",module)
    assert module.count(name.encode())==1

    def csv(row):
        return (";".join(map(str,row))+"\r\n").encode("ascii")
    inputs["AnchorField.csv"]=put("AnchorField.csv",csv(q["baseline_field"]))
    inputs["Half/Candidate.csv"]=put("Half/Candidate.csv",csv(("ForceHalf",q["half_radius"],q["nominal_half_target_MPa"],*q["half_dq"])))
    runner=(BASE/"lock/Run-MVT2ShearControlled.ps1").read_text(encoding="utf8")
    runner=replace(runner,"[ValidateSet('Half','Full')][string]$Phase='Half'","[ValidateSet('Half')][string]$Phase='Half'")
    inputs["Run-MVT2ShearControlled.ps1"]=put("Run-MVT2ShearControlled.ps1",runner.encode("utf8"))
    book="workbook/output/RC_Section_NDM.xlsm"
    raw=(BASE/"lock"/book).read_bytes()
    assert digest(raw)==BOOK
    put(book,raw)
    if not (HERE/"docs/regression/Diagnostic.xlsm").exists():
        put("docs/regression/Diagnostic.xlsm",raw)
    for name in ("src","NativeHalf","Temp"):
        (HERE/name).mkdir(exist_ok=True)
    inputs["Verify-MVT2ShearControlled.py"]=digest((HERE/"Verify-MVT2ShearControlled.py").read_bytes())
    doc={"inputs":inputs,"book_sha256":BOOK,"previous_native_sha256":q["locked_baseline_trace_sha256"],
         "replay_sha256":q["H24_sha256"],"source_bundle_sha256":PIN,"watchdog_seconds":200}
    print(put("Preparation.json",(json.dumps(doc,indent=2)+"\n").encode("utf8")))


if __name__=="__main__":
    main()
