"""Optimize only branch-preserving directions using the newly measured station gradients."""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent


def main(native_root,decision_source,output):
    sys.path.insert(0,str(native_root))
    sys.path.insert(1,str(decision_source))
    import VerifyBase as v
    sys.path.insert(0,str(decision_source/"Run"))
    import PlanFresh as model
    report=v.read(native_root/"VerificationHalf.json")
    probe=v.read(native_root/"ForceProbe.json")
    trace=native_root/"NativeHalf/MVT2.csv"
    assert v.digest(trace)==report["trace_sha256"]=="8E759775518EF15D8ACC186E6D0A4AA9FA17BB1966E30FB09270A48FDEE4A2B9"
    tags=v.read_native(trace)
    states,stations=v.verified_states(tags)
    current=states["ForceHalf"]
    old=states["LockedFull"]
    assert current["q"]==old["q"]==probe["q_trial_kN"]
    assert states["Restored24"]==states["Base24"] and stations["Restored24"]==stations["Base24"]
    q0=np.array(old["field"])
    q=np.array(current["field"])
    base_internal,_,_=v.reconstruct(q0,old["q"],stations["LockedFull"])
    r0=np.r_[old["r"],np.array(base_internal[-4:])*v.MODULUS]
    r=np.asarray(report["native_force_half_all66_MPa"])
    tau=probe["tau_MPa"]
    old_tags=v.read_native(decision_source/"Run/NativeA/MVT2.csv")
    old_a,old_a_station=v.verified_states(old_tags)
    anchor=old_a["Reacted"]
    ar,_,_=v.reconstruct(anchor["field"],anchor["q"],old_a_station["Reacted"])
    A,G,_=model.assembled(old_tags,np.r_[anchor["r"],np.array(ar[-4:])*v.MODULUS],
                          anchor,anchor["geometry"],anchor["q"])
    J={name:A[name] for name in ("Consistent","Refined")}
    S=model.strain_matrix(current["geometry"])
    index={key:idx for idx,key in enumerate(current["geometry"])}
    geological=[]
    next_F=[]
    for entry in report["station_branch_gradients"]:
        i=index[entry["point"],entry["side"]]
        local=S[6*i:6*(i+1)].copy()
        local[3:]*=np.sqrt(2.)
        F=entry["F_after_MPa"]
        normal=np.asarray(entry["gradient_after"])@local
        observed=entry["actual_delta_F_MPa"]
        finite_limit=abs(observed-entry["tangent_estimate_delta_F_MPa"])
        geological.append({"point":entry["point"],"side":entry["side"],"F":F,"normal":normal,
                           "empirical_error":finite_limit,"physical_rows":local})
        next_F.append({"point":entry["point"],"side":entry["side"],
                       "one_more_same_nominal_F_MPa":float(F+normal@(q-q0)),
                       "one_more_same_secant_F_MPa":float(F+observed)})
    assert all(e["one_more_same_nominal_F_MPa"]>0. for e in next_F if e["point"]==15)
    model_defect=np.max([abs(r-r0-J[d]@(q-q0)) for d in J],axis=0)
    frozen=probe["half_radius"]
    original=np.asarray(probe["original_caps_MPa"])
    rounding=8e-10
    # The more restrictive present My limit is used as a planning reserve.
    caps=original.copy()
    caps[2]=min(caps[2],abs(r[58]))
    factors=np.r_[np.repeat(1e-9,56),np.repeat(1e-3,4)]
    stress=1e-4
    stacked=np.vstack(list(J.values()))*factors/stress
    forces=np.vstack([M[56:62] for M in J.values()])*factors/stress
    physical=S*factors/1e-9
    E=np.r_[stacked,-stacked,forces,-forces,physical,-physical]
    k=len(J)
    c=np.r_[np.zeros(60),1.]
    objective_rows=np.r_[-np.ones(2*len(stacked)),np.zeros(len(E)-2*len(stacked))]
    tested=[]
    for regime in ("exact_point3","surface_normals_all_three"):
        keep=[station["physical_rows"] for station in geological if station["point"]==3 and regime=="exact_point3"]
        H=np.vstack([G,*keep])
        eq=np.c_[H*factors/1e-9,np.zeros(len(H))]
        rhs=np.r_[-r[-4:]/v.MODULUS/1e-9,np.zeros(len(H)-4)]
        for radius in (2.5e-9,5e-9,1e-8):
            error=model_defect*radius/frozen+rounding
            stress_rhs=np.r_[-np.tile(r+error,k)/stress,np.tile(r-error,k)/stress,
                            np.tile(caps-r[56:62]-error[56:62],k)/stress,
                            np.tile(caps+r[56:62]-error[56:62],k)/stress,np.full(2*len(S),radius/1e-9)]
            sign_rows=[]
            sign_caps=[]
            for item in geological:
                F=item["F"]
                sign_rows.append(-np.sign(F)*item["normal"]*factors/.001)
                pad=max(1e-10,item["empirical_error"]*radius/frozen)
                sign_caps.append((.5*abs(F)-pad)/.001)
            system=np.c_[np.vstack([E,sign_rows]),np.r_[objective_rows,np.zeros(len(sign_caps))]]
            answer=linprog(c,A_ub=system,b_ub=np.r_[stress_rhs,sign_caps],A_eq=eq,b_eq=rhs,
                           bounds=[(None,None)]*60+[(0.,None)],method="highs",
                           options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
            if not answer.success:
                tested.append({"radius":radius,"regime":regime,"status":answer.message})
                continue
            dq=answer.x[:60]*factors
            vals={n:r+matrix@dq for n,matrix in J.items()}
            obj=max(max(abs(z)+error) for z in vals.values())
            assert abs(obj-answer.fun*stress)<2e-12
            assert max(abs(H@dq-np.r_[ -r[-4:]/v.MODULUS,np.zeros(len(H)-4)]))<2e-17
            calc_surfaces=[]
            for item in geological:
                t=item["F"]+item["normal"]@dq
                assert t*item["F"]>0. and abs(t)>=.5*abs(item["F"])-1e-10
                calc_surfaces.append({"point":item["point"],"side":item["side"],"trial_F_MPa":float(t)})
            cap_margins={n:list((original-abs(z[56:62])-error[56:62])*v.SCALES) for n,z in vals.items()}
            assert all(min(a)>=-1e-6 for a in cap_margins.values())
            tested.append({"radius":radius,"regime":regime,"upper_all66_MPa":float(obj),
                           "additional_gain_over_tau":float((max(abs(r))-obj)/tau),
                           "cumulative_gain_over_tau":float((max(abs(r0))-obj)/tau),"surface_trial":calc_surfaces,
                           "original_caps_slack_N_Nmm":cap_margins,
                           "predictions_all66_MPa":{k:list(z) for k,z in vals.items()},"dq":list(dq)})
    known=[j for j in tested if "additional_gain_over_tau" in j]
    strong=[j for j in known if j["additional_gain_over_tau"]>=8. and j["radius"]<=frozen*(1.+1e-10)]
    half_extension=[j for j in known if j["cumulative_gain_over_tau"]>=8. and j["radius"]<=frozen*(1.+1e-10)]
    chosen=min(strong or half_extension,key=lambda j:(j["radius"],-j["additional_gain_over_tau"]),default=None)
    result={"native_trace_sha256":v.digest(trace),"prior_LockedFull_norm_MPa":float(max(abs(r0))),
            "exact_ForceHalf_norm_MPa":float(max(abs(r))),"same_direction_extension_violates_point15":next_F,
            "all66_small_step_model_error_MPa":list(model_defect),"force_model_signed_bound_N_Nmm":list(model_defect[56:62]*v.SCALES),
            "original_force_caps_MPa":list(original),"planning_My_bound_Nmm":float(caps[2]*v.SCALES[2]),
            "tested":tested,"strong_additional_8tau_candidate":bool(strong),"more_conservative_cumulative_8tau_candidate":bool(half_extension),
            "conditional_candidate":chosen}
    output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(output,v.digest(output))
    for j in tested:
        print(j["regime"],j["radius"],j.get("additional_gain_over_tau"),j.get("cumulative_gain_over_tau"),j.get("status"))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("native_root",type=Path)
    parser.add_argument("decision_source",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    main(args.native_root.resolve(),args.decision_source.resolve(),args.output.resolve())
