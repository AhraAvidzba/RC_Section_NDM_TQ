"""Reconstruct the exact native ForceHalf test and optionally replay both LP decisions."""
import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

import VerifyBase as v

HERE=Path(__file__).resolve().parent


def replay(workbook,decision):
    spec=spec_from_file_location("locked_force",HERE/"Verify-MVT2ShearControlled.py")
    test=module_from_spec(spec)
    spec.loader.exec_module(test)
    prep=v.read(HERE/"Preparation.json")
    rules=v.read(HERE/"ForceProbe.json")
    assert all(v.digest(HERE/name)==identity for name,identity in prep["inputs"].items())
    if workbook is not None:
        assert v.digest(workbook)==prep["book_sha256"]
    historical=HERE/"Decision/MVT2BranchLockedNative20261116.zip"
    sealed=HERE/"Decision/MVT2ForcePartitionDecision20261116.zip"
    assert v.digest(historical)==prep["source_bundle_sha256"]
    assert v.digest(sealed)=="3331E8A071414259A1B368FD9498D56541FBADBC2F69CFEFDF2AF93F7777ABC2"
    old,stations=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    ref=old["LockedFull"]
    assert tuple(rules["baseline_field"])==tuple(map(float,test.one_line("AnchorField.csv")))==ref["field"]
    assert v.digest(HERE/"PreviousNative.csv")==prep["previous_native_sha256"] and v.digest(HERE/"Replay.csv")==prep["replay_sha256"]
    label,radius,gate,*values=test.one_line("Half/Candidate.csv")
    dq=tuple(map(float,values))
    assert tuple(rules["half_dq"])==dq and label=="ForceHalf"
    out=test.attest(prep,rules,ref,stations["LockedFull"],dq)
    frozen=HERE/"VerificationHalf.json"
    raw=(json.dumps(out,indent=2)+"\n").replace("\n","\r\n").encode("utf8")
    assert raw==frozen.read_bytes() and out["qualified"] and not out["equilibrium"]
    signed={f:x for f,x in zip(v.EFFORT_NAMES,out["signed_residuals_N_Nmm"],strict=True)}
    interval={}
    for point in (3,15,19):
        relevant=[entry for entry in out["station_branch_gradients"] if entry["point"]==point]
        assert len(relevant)==3
        interval[str(point)]={"all_three_branch_flags_identical":all(e["flags_before"]==e["flags_after"] for e in relevant),
            "signed_F_before_MPa":[e["F_before_MPa"] for e in relevant],"signed_F_after_MPa":[e["F_after_MPa"] for e in relevant],
            "signed_F_tangent_error_max_MPa":max(abs(e["actual_delta_F_MPa"]-e["tangent_estimate_delta_F_MPa"]) for e in relevant)}
    if decision:
        root=HERE/"DecisionReplay"
        root.mkdir(exist_ok=True)
        with ZipFile(sealed) as package:
            script=root/"ForceLock.py"
            script.write_bytes(package.read("ForceLock.py"))
            subprocess.run([sys.executable,"-B","-X","utf8",str(script),str(historical),str(root/"Run")],check=True)
            for name in ("ForceDecision.json","ForceProbe.json"):
                proof=(root/"Run"/name).read_bytes()
                assert proof.replace(b"\r\n",b"\n")==package.read("Run/"+name).replace(b"\r\n",b"\n")
        follow=root/"ForceNext.json"
        subprocess.run([sys.executable,"-B","-X","utf8",str(HERE/"ForceNext.py"),str(HERE),str(root),str(follow)],check=True)
        assert follow.read_bytes().replace(b"\r\n",b"\n")==(HERE/"ForceNext.json").read_bytes().replace(b"\r\n",b"\n")
    result={"native_report_sha256":v.digest(frozen),"decision_archive_sha256":v.digest(sealed),"next_decision_sha256":v.digest(HERE/"ForceNext.json"),
        "trace_sha256":out["trace_sha256"],"book_sha256":prep["book_sha256"],"source_overlay_sha256":prep["inputs"]["tests/modTestCoupledExperiment.bas"],
        "Qy_trial_kN":out["Qy_trial_kN"],"Qy_last_accepted_kN":out["Qy_accepted_kN"],
        "H24_sha256":prep["replay_sha256"],"exact_H24_restore":out["H24_exact_rollback"],"history_published":False,
        "actual_norm_MPa":out["actual_norm_MPa"],"gain_over_tau":out["gain_over_tau"],"signed_six_N_Nmm":signed,
        "station_surface_checks":interval,"actual_four_gauges_MPa":out["four_gauges_MPa"],"equilibrium":False,
        "native_wall_s":out["native_wall_s"],"compiler":out["compiler"],"owner":out["owner"]}
    proof=HERE/"PortableReport.json"
    proof.write_bytes((json.dumps(result,indent=2)+"\n").encode("utf8"))
    print(proof,v.digest(proof))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--decision",action="store_true")
    p.add_argument("--workbook",type=Path)
    a=p.parse_args()
    replay(a.workbook,a.decision)
