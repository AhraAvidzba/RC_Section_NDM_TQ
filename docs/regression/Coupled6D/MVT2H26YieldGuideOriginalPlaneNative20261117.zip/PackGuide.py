"""Package the fixed H26 yield-guide native proof without workbook copies."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import ReplayGuidePortable as replay

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent/"mv26y"
REGRESSION = HERE.parents[1]/"docs/regression/Coupled6D"
RESULT = HERE/"MVT2H26YieldGuideOriginalPlaneNative20261117.zip"


def main():
    prep = json.loads((SOURCE/"Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK] == prep["book_sha256"] == replay.WORKBOOK
    lookup = {}
    for name,expected in replay.DEPENDENCIES.items():
        path = REGRESSION/name
        assert replay.digest(path.read_bytes()) == expected
        with ZipFile(path) as archive:
            for member in archive.namelist():
                if not member.casefold().endswith(".xlsm"):
                    lookup.setdefault(replay.digest(archive.read(member)),(name,member))
    native = tuple(f"NativeResume/{file.name}" for file in (SOURCE/"NativeResume").iterdir() if file.is_file())
    original = ("Preparation.json","PreparationFirst.json","CompileFirst.log","Compile.log","CompileClosure.json",
                "Run.ndjson","docs/regression/CodeUpdate.json","VerifyGuideDetached.py","VerificationYieldSeed.json")
    local = ("PackGuide.py","ReplayGuidePortable.py","PortableREADME.txt","CompileFirstProcessCheck.json")
    content, manifest = {}, {}
    for name in sorted(set(prep["inputs"]) | set(native) | set(original) | set(local)):
        if name == replay.BOOK:
            continue
        raw = ((HERE if name in local else SOURCE)/name).read_bytes()
        digest = replay.digest(raw)
        if name in prep["inputs"]:
            assert digest == prep["inputs"][name], name
        match = lookup.get(digest) if name in prep["inputs"] else None
        if match:
            archive,member = match
            manifest[name] = {"archive":archive,"member":member,"sha256":digest}
        else:
            manifest[name] = {"sha256":digest}
            content[name] = raw
    full = {"workbook":{"path":replay.BOOK,"sha256":replay.WORKBOOK},"archives":replay.DEPENDENCIES,"inputs":manifest}
    content["PortableManifest.json"] = (json.dumps(full,indent=2)+"\n").encode()
    assert all(not name.casefold().endswith(".xlsm") for name in content)
    with ZipFile(RESULT,"w",compresslevel=9) as z:
        for name,raw in sorted(content.items()):
            info = ZipInfo(name)
            info.compress_type = ZIP_DEFLATED
            z.writestr(info,raw)
    with TemporaryDirectory(dir=HERE) as temp, ZipFile(RESULT) as z:
        assert z.testzip() is None
        z.extractall(temp)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayGuidePortable.py","--archives",str(REGRESSION)),cwd=temp,check=True)
    print(RESULT.name,RESULT.stat().st_size,replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
