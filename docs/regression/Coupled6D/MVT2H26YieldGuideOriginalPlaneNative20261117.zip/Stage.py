"""Freeze a material-event predictor probe on the original H26 plane."""
import json
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mv26r"
FROZEN_PARENT = "A6D4267E9EBB7B25936883D12B8EA43FC63E2B7BF611B8001CF85032F56B554D"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
SOLVER = "src/Solver/CCoupledNewtonSolver.cls"
MACRO = "tests/modTestCoupledExperiment.bas"
VERIFY = "Verify-MVT2ShearControlled.py"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(path, raw):
    target = HERE / path
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, target
    else:
        target.write_bytes(raw)
    return digest(raw)


def overlay(source, name, anchor=None, insertion=None):
    text = source.decode("utf-8-sig").replace("\r\n", "\n")
    if anchor:
        assert text.count(anchor) == 1
        text = text.replace(anchor, anchor + insertion)
    extra = (HERE / name).read_text(encoding="utf-8-sig")
    text = text.rstrip() + "\n\n" + extra.strip() + "\n"
    assert max(map(len, text.splitlines())) < 1023
    return text.replace("\n", "\r\n").encode()


def main():
    raw = (PARENT / "Preparation.json").read_bytes()
    assert digest(raw) == FROZEN_PARENT
    data = json.loads(raw)
    inputs = {}
    for name, expected in data["inputs"].items():
        exact = (PARENT / name).read_bytes()
        assert digest(exact) == expected
        if name in ("Stage.py", "README.txt"):
            continue
        if name == VERIFY:
            name = "RadiusBase.py"
        if name == SOLVER:
            exact = overlay(exact, "GuideSolver.txt")
        if name == MACRO:
            exact = overlay(exact, "GuideTest.txt", "                    projection, normalLoad, metric, loadMetric, nominal, committed\n",
                "                RunWangYieldSeedTest output, solver, operators, materials, responses, baseField, baseFactor, _\n"
                "                    projection, normalLoad, metric, loadMetric, nominal, target, committed\n"
                "                RunWangYieldAnchorTest output, solver, operators, materials, responses, baseField, baseFactor, _\n"
                "                    projection, normalLoad, metric, loadMetric, target, committed\n")
        inputs[name] = put(name, exact)
    for name in ("Stage.py", "GuideSolver.txt", "GuideTest.txt", VERIFY):
        inputs[name] = digest((HERE / name).read_bytes())
    assert put("docs/regression/Diagnostic.xlsm", (HERE / BOOK).read_bytes()) == data["book_sha256"]
    for folder in ("NativeResume", "Temp"):
        (HERE / folder).mkdir(exist_ok=True)
    data = {**data, "inputs": inputs, "base_radius_prep_sha256": FROZEN_PARENT}
    print(put("Preparation.json", (json.dumps(data, indent=2) + "\n").encode()))


if __name__ == "__main__":
    main()
