"""Reproduce native H26 event-guided equilibrium and both harness corrections."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from traceback import extract_tb
from types import ModuleType
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
PARTIAL = "D6C80D102915959DED5B4C217DF747C5DB8119FAD5585DE7332491D5F9130170"
REPORT = "0B9E9033401684AEF852C7A49292FB36B81C5265D8BF27376709375BD1F06949"
PARENT = "MVT2H26RadiusRejectionNative20261117.zip"
DEPENDENCIES = {
    PARENT: "72D5A584147EB019F811EAA92E439F81504E88218FF499899A1BE17152FD1788",
    "MVT2ExactH26SmallerArcNative20261116.zip": "B775E3D70EED7CC8239F905AC4E3779AA65CE8994BA1F045BED899B6235B4F07",
    "MVT2AdaptiveBoundedContinuationNative20261116.zip": "A5F4EABFE14F46544D6BA36934B050AED5C5F3655DC91D32D6E8C6408562E699",
    "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
    "MVT2StockBranchArcNative20261116.zip": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def local(root,name):
    return root/(root/name).resolve().relative_to(root.resolve())


def materialize(work,manifest,archives):
    assert manifest["archives"] == DEPENDENCIES and manifest["workbook"] == {"path":BOOK,"sha256":WORKBOOK}
    for name,expected in DEPENDENCIES.items():
        assert digest((archives/name).read_bytes()) == expected
    for name,rec in manifest["inputs"].items():
        source = rec.get("archive")
        member = rec.get("member",name)
        if source:
            with ZipFile(archives/source) as z:
                raw = z.read(member)
        else:
            raw = local(HERE,member).read_bytes()
        assert digest(raw) == rec["sha256"]
        target = local(work,name)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)


def scope_of(path,name):
    scope = {"__name__":name,"__file__":str(path)}
    exec(compile(path.read_text(encoding="utf-8"),str(path),"exec"),scope)
    return scope


def verify_generation(work,archive_dir):
    stage = scope_of(work/"Stage.py","archived_stage")
    raw_first = (work/"PreparationFirst.json").read_bytes()
    assert digest(raw_first) == PARTIAL
    first = json.loads(raw_first)
    second = json.loads((work/"Preparation.json").read_bytes())
    assert set(name for name,sha in first["inputs"].items() if sha != second["inputs"][name]) == {stage["SOLVER"],"GuideSolver.txt"}
    compiled_solver = (work/stage["SOLVER"]).read_bytes()
    removed_arg = b", ignoredProjection)"
    assert compiled_solver.count(removed_arg) == 1
    prior_solver = compiled_solver.replace(removed_arg,b")")
    assert digest(prior_solver) == first["inputs"][stage["SOLVER"]]
    compile_log = (work/"CompileFirst.log").read_text(encoding="utf-8-sig")
    assert "COMPILE_LOCATION: module=CCoupledNewtonSolver; line=1790; column=31" in compile_log
    [incomplete_call] = [line.strip() for line in prior_solver.decode().splitlines()
                         if line.strip().endswith(", True, field, loadFactor)")]
    assert incomplete_call in compile_log
    process = json.loads((work/"CompileFirstProcessCheck.json").read_text(encoding="utf-8-sig"))
    assert process["State"] == "Absent"
    assert f"id={process['PID']}; utcStartTicks={process['ExpectedStartTicksUTC']}" in compile_log
    with ZipFile(archive_dir/PARENT) as prior:
        assert digest(prior.read("Preparation.json")) == stage["FROZEN_PARENT"]
        solver = stage["overlay"](prior.read(stage["SOLVER"]),"GuideSolver.txt")
        macro = stage["overlay"](prior.read(stage["MACRO"]),"GuideTest.txt",
             "                    projection, normalLoad, metric, loadMetric, nominal, committed\n",
             "                RunWangYieldSeedTest output, solver, operators, materials, responses, baseField, baseFactor, _\n"
             "                    projection, normalLoad, metric, loadMetric, nominal, target, committed\n"
             "                RunWangYieldAnchorTest output, solver, operators, materials, responses, baseField, baseFactor, _\n"
             "                    projection, normalLoad, metric, loadMetric, target, committed\n")
    assert solver == compiled_solver and macro == (work/stage["MACRO"]).read_bytes()


def verify_native(work):
    sys.path.insert(0,str(work))
    path = work/"ResumeBase.py"
    text = path.read_text(encoding="utf-8")
    old = '    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items())'
    assert text.count(old) == 1 and not (work/BOOK).exists()
    pinned = (f'    assert prep["inputs"]["{BOOK}"] == prep["book_sha256"] == "{WORKBOOK}"\n'
              f'    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items() if path != "{BOOK}")')
    base = ModuleType("ResumeBase")
    base.__file__ = str(path)
    sys.modules["ResumeBase"] = base
    exec(compile(text.replace(old,pinned),str(path),"exec"),base.__dict__)
    broken = scope_of(work/"Verify-MVT2ShearControlled.py","original_verifier")
    fixed = scope_of(work/"VerifyGuideDetached.py","corrected_verifier")
    inputs = fixed["radius"].prepare()
    try:
        broken["verify"](inputs)
    except AssertionError as exc:
        assert [frame.name for frame in extract_tb(exc.__traceback__)][-2:] == ["verify","vec"]
        assert "B_BOUND_ACTUAL" in extract_tb(exc.__traceback__)[-2].line
    else:
        raise AssertionError("Original six-effort parser mismatch did not reproduce")
    raw = fixed["v"].read_native(work/"NativeResume/MVT2.csv")
    assert all(len(record) == 7 for tag in ("B_BOUND_ACTUAL","B_Y_SEED_EXACT_ACTUAL") for record in raw[tag])
    assert raw["B_Y_SEED_EVENT"][0][:2] == ["22","-1"]
    report = fixed["verify"](inputs)
    saved = (work/"VerificationYieldSeed.json").read_bytes()
    assert digest(saved) == REPORT and (json.dumps(report,indent=2)+"\n").encode() == saved
    assert report["first_crossing"][:2] == [22,-1]
    assert report["trials"][-1]["evaluation_only"] and "converged_internal" not in report["trials"][-1]
    assert [r["mode"] for r in report["trials"] if r.get("final_exact_equilibrium")] == ["Exact"]
    assert report["H26_unmodified"] and report["H24_restored"]
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives",type=Path,required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE/"PortableManifest.json").read_bytes())
    with TemporaryDirectory() as tmp:
        work = Path(tmp)
        materialize(work,manifest,args.archives)
        verify_generation(work,args.archives)
        report = verify_native(work)
    print("NATIVE YIELD GUIDE",REPORT,"EVENT",report["first_crossing"][:2])
    print("ORIGINAL PLANE",next(r["Qy_kN"] for r in report["trials"] if r.get("final_exact_equilibrium")))


if __name__ == "__main__":
    main()
