H26 native constitutive-event guide and original-plane return.

    python -B -X utf8 ReplayGuidePortable.py --archives <repository>/docs/regression/Coupled6D

The first private compiler stopped before any test because the call to TraceYieldCrossing
omitted its returned projection argument. The archive preserves the first compiler output,
original source digest, and verified retired PID. The exact failed solver module is
reconstructed by removing just that argument from the compiled source. The final isolated
native run completed and closed its owned process. No workbook bytes are archived.

The original offline checker passed six-effort records to its 60-coefficient parser. The
detached replay reproduces that assertion and independently confirms the two affected
wire tables have exactly six effort values. The corrected report retains the detected
event station, distinguishes the evaluation-only anchor, and verifies all original force,
weak, gauge, and plane residuals without changing native traces or tolerances.
The auxiliary material-surface guide is followed by an exact solve on the original plane.
No diagnostic state was accepted into a new history, and the original H24 is restored.
