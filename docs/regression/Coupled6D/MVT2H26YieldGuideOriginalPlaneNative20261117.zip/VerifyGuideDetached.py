"""Independently verify the optional yield guide and the unchanged target plane."""
import argparse
from collections import defaultdict
import json
from math import hypot
from pathlib import Path

import RadiusBase as radius
from RadiusBase import prior, v

HERE = Path(__file__).resolve().parent


def verify(frozen):
    report = radius.verify(*frozen)
    values = v.read_native(HERE / "NativeResume/MVT2.csv")
    history = prior.by_name(values, "B_ARC_HISTORY")
    assert history["YieldSeedRestored"] == history["YieldAnchorRestored"] == history["DiscardedAttempt3"] == history["CommittedAttempt2"]
    previous = prior.by_name(values, "B_EXT_TRY")["Attempt3"]
    _, _, base_factor, ds, _, load_normal, _, _ = prior.numbers(previous)
    projection = v.vec(values, "B_EXT_PROJECTION")["Attempt3"]
    base_field = v.vec(values, "B_EXT_COMMITTED")["Attempt2"]
    load_scale = frozen[7]
    runs = prior.by_name(values, "B_Y_SEED_SOLVER")
    assert tuple(runs) in (("Guide", "Retangent"), ("Guide", "Exact", "Retangent"))
    runs["Anchor"] = ["1", "0"]
    [(event_point, event_side, from_value, to_value)] = values["B_Y_SEED_EVENT"]
    assert int(event_point) == 22 and int(event_side) == -1 and float(from_value) < 0 < float(to_value)
    gates = prior.by_name(values, "B_Y_SEED_GATES")
    station_data = defaultdict(dict)
    for label, point, side, *record in values["B_TANGENT_STATION"]:
        station_data[label][(int(point),int(side))] = prior.numbers(record)
    original_geometry = {k: a[:3] for k,a in station_data["Attempt2"].items()}
    wire_fields = prior.by_name(values, "B_TANGENT_FIELD")
    wire_rows = v.vec(values, "B_TANGENT_RESIDUAL")
    wire_forces = {label: prior.numbers(fields) for label, fields in prior.by_name(values, "B_BOUND_ACTUAL").items()}
    result = {"native_trace_sha256": report["native_trace_sha256"], "target_step": ds,
              "H26_unmodified": True, "H24_restored": report["H24_exact_restored"],
              "original_radius_rejected": report["same_original_failure"],
              "first_crossing": [int(event_point),int(event_side),float(from_value),float(to_value)],
              "physical_limit_established": False, "trials": []}
    guide_eligible = False
    for mode, (ok, seconds) in runs.items():
        solved = ok == "1"
        assert ok in ("0","1") and (mode in gates) == solved
        trial = {"mode": mode}
        if mode == "Anchor":
            trial["evaluation_only"] = True
        else:
            trial.update({"converged_internal": solved, "seconds": float(seconds)})
        if solved:
            factor, norm, tau, projection_distance, length = prior.numbers(gates[mode])
            label = "Yield"+mode
            before, on_wire, *coefficients = wire_fields[label]
            assert before == "26" and float(on_wire) == factor
            field = prior.numbers(coefficients)
            geometry = {k: row[:3] for k,row in station_data[label].items()}
            assert original_geometry == geometry and len(geometry) == 135
            delta = v.diff(field, base_field)
            independent_projection = v.dot(projection,delta)+load_normal*(factor-base_factor)
            independent_length = hypot(*prior.station_metric(delta,geometry),load_scale*(factor-base_factor))
            v.near(projection_distance, independent_projection, 4e-15)
            v.near(length, independent_length, 4e-15)
            v.near(tau,5e-7*(1+v.peak(v.loading(factor))),2e-18)
            rows, forces, strain_error = v.reconstruct(field, factor, station_data[label])
            assert strain_error < 4e-15 and v.peak(v.diff(rows,wire_rows[label])) < 3e-10
            normalized = lambda a,b: v.peak(x/s for x,s in zip(v.diff(a,b),v.SCALES,strict=True))
            assert normalized(forces,wire_forces[label]) < 4e-12
            measured = max(v.peak(rows[:56]), v.peak(x*v.MODULUS for x in rows[56:]), normalized(forces,v.force(factor)))
            v.near(norm,measured,4e-10)
            local = norm >= 0 and norm<=tau and projection_distance>0 and length<=3*ds
            on_plane = local and abs(projection_distance-ds)*v.MODULUS<=tau
            if mode == "Guide":
                guide_eligible = local
            elif mode == "Anchor":
                assert projection_distance>0 and length<=3*ds and abs(projection_distance-ds)*v.MODULUS<=tau
                assert {key for key,x in station_data["YieldAnchor"].items()
                        if x[3] != station_data["Stall"][key][3]} == {(22,-1)}
                assert station_data["YieldAnchor"][(22,-1)][6] > 0
            else:
                assert on_plane
                assert prior.by_name(values,"B_Y_SEED_META")[mode][:2] == ["4","0"]
                assert normalized(forces,prior.numbers(prior.by_name(values,"B_Y_SEED_EXACT_ACTUAL")[mode])) <= 4e-12
            trial.update({"Qy_kN":factor,"full_residual_over_original_tau":measured/tau,
                          "physical_arc_length_over_nominal":independent_length/ds,
                          "residual_to_original_plane_MPa":(independent_projection-ds)*v.MODULUS,
                          "final_exact_equilibrium": mode in ("Exact", "Retangent") and on_plane})
        result["trials"].append(trial)
    assert ("Exact" in runs) == guide_eligible
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Resume"])
    args = parser.parse_args()
    frozen = radius.prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE / "Preparation.json"))
    else:
        assert args.phase == "Resume"
        report = HERE / "VerificationYieldSeed.json"
        report.write_bytes((json.dumps(verify(frozen), indent=2)+"\n").encode())
        print("MVT2 YIELD SEED",v.digest(report))
