"""ДЛЯ ТЕСТОВ. Закрепляет рабочую смену меры, отдельную гипотезу и отрицательную компиляционную пробу."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestCollect(repo, root):
    """Сохраняет фактический VBA и неизменяемые входы всех законченных направленных проверок."""
    here = Path(__file__).resolve().parent
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = {'Before': 'HardPreparedField0220261118',
        'RecoveryTrial': 'HardPreparedRecovery20261118', 'Final': 'HardFieldWorking20261118'}
    collect(repo, root)
    for folder in (root / 'Cases').iterdir():
        scope = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            scope[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(scope) == 30
        (folder / 'AllCoupledSources.json').write_text(json.dumps(scope, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    for name in ('Collect-TestHardField.py', 'Check-TestHardField.py', 'Validate-TestHardPrepared.py',
                 'Stage-TestHardPrepared.py', 'Stage-TestHardRecovery.py', 'TestNativeHardPrepared.bas.txt',
                 'Stage-TestClosedBranchPeak.py', 'Stage-TestSteelHistory.py', 'Canonical-TestCoreVBA.py'):
        (root / name).write_bytes((here / name).read_bytes())
    failed = Path('D:/CodexScratch/RC_Section_NDM_TQ/HardPreparedField20261118')
    target = root / 'FailedCompile'
    target.mkdir()
    for file in failed.rglob('*'):
        if not file.is_file():
            continue
        relative = file.relative_to(failed)
        if relative.parts[0] in ('Temp', 'workbook') or file.suffix.lower() == '.xlsm':
            continue
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(file.read_bytes())
    baseline = repo / 'docs/regression/Coupled6D/CoupledClosedBranchCapacity20261118.zip'
    digest = sha256(baseline.read_bytes()).hexdigest().upper()
    assert digest == 'F2177698D7B60B9CDD5852EC0B443491B1BB3FC7648901525902A7B8F53E43EE'
    (root / 'Baseline').mkdir()
    entries = {}
    with ZipFile(baseline) as archive:
        for name in ('Trace74.Operators.csv', 'Trace74.Tensor.csv', 'Trace74.txt'):
            raw = archive.read('Cases/Working/Native/' + name)
            (root / 'Baseline' / name).write_bytes(raw)
            entries[name] = sha256(raw).hexdigest().upper()
    (root / 'Baseline/Origin.json').write_text(json.dumps({'archive': baseline.name,
        'sha256': digest, 'entries': entries}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '1463a87',
        'installed_workbook_changed': False, 'physical_capacity_certified': False,
        'full_acceptance_completed': False, 'recovery_per_revision_in_working_code': False}, indent=2) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('HARD FIELD NATIVE AND PRIVATE NEGATIVE EVIDENCE COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
