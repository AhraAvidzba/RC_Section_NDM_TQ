"""ДЛЯ ТЕСТОВ. Проверяет отдельную гипотезу о повторном восстановлении CDP на новой принятой истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Не меняет рабочий бюджет 96 и допуски; четвёртая попытка относится к той же неизменной принятой ревизии."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardPrepared.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    def TestOnce(code, old, new):
        """Закрепляет единственное место каждого частного переключателя."""
        assert code.count(old) == 1, old
        return code.replace(old, new)
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, 'Public HardPreparedRequestedTest As Boolean, EarlyFieldRequestedTest As Boolean',
        'Public HardPreparedRequestedTest As Boolean, EarlyFieldRequestedTest As Boolean, RecoveryPerRevisionRequestedTest As Boolean')
    code = TestOnce(code, 'If mode <> "Baseline" And mode <> "EarlyField" Then', 'If mode <> "Baseline" And mode <> "EarlyField" And mode <> "Recovery" Then')
    code = TestOnce(code, '    EarlyFieldRequestedTest = (mode = "EarlyField")',
        '    EarlyFieldRequestedTest = (mode <> "Baseline"): RecoveryPerRevisionRequestedTest = (mode = "Recovery")')
    assert code.count('EarlyFieldRequestedTest = False') == 2
    code = code.replace('EarlyFieldRequestedTest = False', 'EarlyFieldRequestedTest = False: RecoveryPerRevisionRequestedTest = False')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, '''Private Function MayRecoverMaterialBoundary() As Boolean
    If Not mSolver.HasPrincipalBoundaries Then''', '''Private Function MayRecoverMaterialBoundary() As Boolean
    If modTestCoupledElasticState.RecoveryPerRevisionRequestedTest And Not mSolver.HasPrincipalBoundaries And mFollowingLocalPeak Then Exit Function
    If Not mSolver.HasPrincipalBoundaries And Not modTestCoupledElasticState.RecoveryPerRevisionRequestedTest Then''')
    code = TestOnce(code, '''        If mSolver.HasPrincipalBoundaries Then
            If mMaterialRecoveryRevision <> mSolver.AcceptedRevision Then''', '''        If mSolver.HasPrincipalBoundaries Or modTestCoupledElasticState.RecoveryPerRevisionRequestedTest Then
            If mMaterialRecoveryRevision <> mSolver.AcceptedRevision Then''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, "'Compile','HardBaseline','HardEarlyField'", "'Compile','HardBaseline','HardEarlyField','HardRecovery'")
    code = TestOnce(code, '''        if ($Phase -in @('HardBaseline','HardEarlyField')) {
            $caseMode=if ($Phase -eq 'HardBaseline') {'Baseline'} else {'EarlyField'}
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardPrepared','-MacroArgument1',$PSScriptRoot,
                '-MacroArgument2',$caseMode,'-TimeoutSeconds','240')''', '''        if ($Phase -in @('HardBaseline','HardEarlyField','HardRecovery')) {
            $caseMode=$Phase.Substring(4)
            $caseTimeout=if ($Phase -eq 'HardRecovery') {'360'} else {'240'}
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardPrepared','-MacroArgument1',$PSScriptRoot,
                '-MacroArgument2',$caseMode,'-TimeoutSeconds',$caseTimeout)''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledDeformationContinuation.cls', 'tests/modTestCoupledElasticState.bas', 'Run-TestWorkingASD.ps1'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'cases': ['EarlyField', 'Recovery'], 'recovery_scope': 'four per accepted revision',
        'recovery_in_working_code': False, 'global_probe_limit': 96, 'numerical_tolerances_changed': False,
        'full_acceptance_completed': False}
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('HARDSHEAR WORKING ORIENTATION AND PRIVATE CDP REVISION RECOVERY READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
