"""ДЛЯ ТЕСТОВ. Сверяет фактические рабочие компоненты контрольной книги с текущими исходниками."""

from difflib import unified_diff
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path


def TestAudit():
    """Не принимает неизменность относительно исходной книги за доказательство актуальности рабочего класса."""
    repo = Path.cwd()
    helper, body, reader = run_path(str(Path(__file__).with_name('Inspect-TestResolutionVBA.py')))['TestHelpers'](repo)
    book = Path('D:/CodexScratch/RC_Section_NDM_TQ/ClosedBranchConverged20261118/docs/regression/Diagnostic.xlsm')
    _, components = reader(BytesIO(book.read_bytes()))
    records = {}
    for file in sorted((repo / 'src').rglob('*')):
        if file.suffix not in ('.bas', '.cls') or file.stem not in components: continue
        name = file.stem
        try:
            expected, _ = helper['TestMVTCompilerBody'](body, file.read_text('utf-8-sig'), name)
            actual = body(components[name], name)[0]
        except IndexError:
            records[name] = {'same': False, 'file': file.relative_to(repo).as_posix(), 'not_comparable': True}
            print('NOT COMPARABLE', name)
            continue
        if name == 'CCoupledSectionAnalysis': expected = expected.replace("' рабочий знак my соответствует +x·σz.", "' рабочий знак my соответствует +x·?z.")
        if name == 'modCoupledConcreteTensor': expected = expected.replace('0.0000000000000001', '1e-16')
        same = (actual == expected)
        records[name] = {'same': same, 'file': file.relative_to(repo).as_posix()}
        if not same:
            lines = list(unified_diff(expected.splitlines(), actual.splitlines(), lineterm=''))
            records[name]['difference'] = lines[:24]
            print('DIFFERENCE', name, '\n'.join(lines[:12]))
    (repo / 'tmp/HardRuntimeSourceAudit.json').write_text(json.dumps(records, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print('CURRENT WORKING SOURCES', len(records), 'SAME', sum(row['same'] for row in records.values()), flush=True)


if __name__ == '__main__':
    TestAudit()
