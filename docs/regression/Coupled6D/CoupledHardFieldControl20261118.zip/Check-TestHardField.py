"""ДЛЯ ТЕСТОВ. Различает продление равновесной ветви, нативную регрессию и ещё не найденную несущую способность."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from subprocess import check_output
import numpy as np


def TestRead(file):
    """Читает сохранённые признаки без преобразования ожидаемых чисел."""
    return json.loads(file.read_text('utf-8-sig'))


def TestNative(repo, root, output):
    """Проверяет состав реальных книг, точность исходников и закрытие только собственных Excel."""
    shared = run_path(str(root / 'Check-TestMaterialRoundoff.py'))
    shared['TestFiles'](root)
    source, _ = run_path(str(root / 'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root / 'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    canonical = run_path(str(root / 'Canonical-TestCoreVBA.py'))
    normal = lambda value: canonical['TestCanonical'](value)[0]
    controls = {'equivalent_literal': normal('x=1e-8') == normal('x=0.00000001'),
        'tolerance_change': normal('x=1e-8') != normal('x=1e-7'),
        'literal_type': normal('x=200000#') != normal('x=200000'),
        'unicode_string': normal('s="ε"') != normal('s="?"'),
        'numeric_string': normal('s="1e-8"') != normal('s="0.00000001"'),
        'russian_comment': normal("x=1 'бетон") != normal("x=1 'сталь"),
        'unrepresentable_comment_only': normal("x=1 'ν") == normal("x=1 '?"),
        'large_integer': normal('x=10000000000#') != normal('x=10000000001#')}
    assert all(controls.values())
    core_body = canonical['TestWrap'](body)
    cases = {}
    for key in TestRead(root / 'Cases.json'):
        folder = root / 'Cases' / key
        record = shared['TestSourceComparison'](repo, root, folder, source, original, helper, core_body, reader)
        assert (record['components'], record['imported'], record['unchanged']) == (239, 25, 214)
        compiler = TestRead(folder / 'docs/regression/CodeUpdate.json')
        _, actual = reader(helper['TestContainer']((folder / 'CompiledVBA.bin').read_bytes()))
        coupled = []
        for file in sorted((folder / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            name = file.stem
            expected, _ = helper['TestMVTCompilerBody'](body, file.read_text('utf-8-sig'), name)
            observed = body(actual[name], name)[0]
            if name == 'CCoupledConcreteReturn':
                def TestConstantSpacing(text):
                    """Учитывает только выравнивание одного числового объявления VBE перед неизменным комментарием."""
                    lines = text.splitlines(keepends=True)
                    for i, line in enumerate(lines):
                        if line.startswith('private const rounding_limit as double = '):
                            code, comment = line.split("'", 1)
                            lines[i] = code.rstrip() + " '" + comment
                    return ''.join(lines)
                expected, observed = TestConstantSpacing(expected), TestConstantSpacing(observed)
            assert normal(expected) == normal(observed), (key, name, 'current coupled source differs')
            coupled.append(name)
        assert len(coupled) == len(TestRead(folder / 'AllCoupledSources.json')) == 30
        record['all_coupled_sources_match'] = coupled
        reports = {}
        for file in sorted((folder / 'Native').glob('*.txt')):
            log = file.read_text('utf-8-sig')
            phase = file.stem
            owner = TestRead(file.with_name(file.name + '.Ownership.json'))
            closure = TestRead(file.with_name(file.name + '.ProcessClosure.json'))
            identity = closure['Closure']['Identity']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
            assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
            assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
            assert closure['Closure']['FinalState']['State'] == 'Absent'
            assert closure['Passed'] and closure['ChildExitCode'] == 0
            assert 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
            totals = [(name, int(passed), int(failed)) for name, passed, failed in
                re.findall(r'^(TOTAL_[A-Z0-9_]+): passed=(\d+); failed=(\d+)', log, re.M)]
            assert totals and all(failed == 0 for _, _, failed in totals)
            if phase in ('HardBaseline', 'HardEarlyField', 'HardRecovery'):
                assert [(a, b) for _, a, b in totals] == [(1, 0)]
                assert re.search(r'^HARD_PREPARED_RESULT;\d+;[\d.E+-]+;6;', log, re.M)
                assert 'до подтверждения физического предела' in log
            elif phase == 'Core':
                assert sum(a for _, a, _ in totals) == 382
            elif phase == 'PeakRegression':
                assert sum(a for _, a, _ in totals) == 168
            elif phase == 'Stock':
                assert [(a, b) for _, a, b in totals] == [(28, 0)]
                assert 'TIMING_STATES: direct=OK; capacity=NumFail;' in log
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;', log, re.M)
                record['stock_seconds'] = float(re.search(r'^TIMING_SECONDS: ([\d.]+)', log, re.M)[1])
                record['stock_state'] = re.search(r'^TIMING_STATES: (.*)$', log, re.M)[1]
            elif phase == 'Trace74':
                assert 'PRODUCTION_PATH_COUNT;151' in log
                assert 'Предельное состояние железобетонного сечения не установлено.' in log
            else:
                raise AssertionError((key, phase))
            reports[phase] = {'totals': totals}
        expected = {'HardBaseline', 'HardEarlyField'} if key == 'Before' else {
            'HardEarlyField', 'HardRecovery'} if key == 'RecoveryTrial' else {'Core', 'PeakRegression', 'Stock', 'Trace74'}
        assert set(reports) == expected
        safety = [json.loads(line) for line in (folder / 'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in safety)
        assert all(all(p['ProtectedUser'] for p in row['excel']) for row in safety)
        record['reports'] = reports
        cases[key] = record
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    before = check_output(['git', 'cat-file', 'blob', '1463a87:' + name], cwd=repo)
    before = before.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
    assert (root / 'Cases/Before/BaselineSource' / name).read_bytes() == before
    assert (root / 'Cases/RecoveryTrial/BaselineSource' / name).read_bytes() == (root / 'Cases/Final' / name).read_bytes()
    for key in ('Before', 'RecoveryTrial'):
        for relative in ('src/Solver/CCoupledSectionAnalysis.cls', 'tests/modTestCoupledElasticState.bas'):
            assert (root / 'Cases' / key / 'BaselineSource' / relative).read_bytes() == (root / 'Cases/Final' / relative).read_bytes()
    for key in ('Before', 'RecoveryTrial', 'Final'):
        for relative in ('src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledLoadContinuation.cls',
                         'src/Materials/CCoupledConcreteReturn.cls'):
            assert (root / 'Cases' / key / relative).read_bytes() == (root / 'Cases/Final' / relative).read_bytes()
    final = (root / 'Cases/Final' / name).read_text('utf-8-sig')
    assert 'modTestCoupledElasticState' not in final and 'RecoveryPerRevisionRequestedTest' not in final
    failed = root / 'FailedCompile'
    assert TestRead(failed / 'CompileClosure.json')['State'] == 'Absent'
    failure_log = (failed / 'Compile.log').read_text('utf-8-sig')
    assert 'COMPILE_LOCATION:' in failure_log and 'PRIVATE_CODE_READY:' not in failure_log
    output.write_text(json.dumps({'cases': cases, 'canonical_controls': controls,
        'failed_compile_preserved': True, 'working_recovery_budget_unchanged': True,
        'installed_workbook_changed': False, 'physical_capacity_certified': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('HARD FIELD ACTUAL VBA NATIVE REGRESSIONS AND NEGATIVE COMPILE VERIFIED', flush=True)


def TestMechanics(repo, root, output):
    """Интегрирует все шесть усилий и полные уравнения каждой принятой пробы с тремя станциями."""
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    validate = run_path(str(root / 'Validate-TestHardPrepared.py'))['TestValidate']
    result, fields = {}, {}
    for key, phases in (('Before', ('HardBaseline', 'HardEarlyField')),
                        ('RecoveryTrial', ('HardEarlyField', 'HardRecovery'))):
        for phase in phases:
            label = key + '/' + phase
            proof, fields[label] = validate(root / 'Cases' / key, phase)
            assert not proof['reversed_fields']
            assert proof['meta'][0] == '6' and proof['meta'][1] == '10'
            assert proof['physical_capacity_certified'] is False
            result[label] = proof
    a, b, c, d = result.values()
    assert len(a['states']) == 10 and len(b['states']) == len(c['states']) == 23 and len(d['states']) == 31
    assert a['maximum_lambda'] == 1.10460833943358
    assert b['maximum_lambda'] == c['maximum_lambda'] == 1.10760941419977
    assert d['maximum_lambda'] == 1.10791221123986
    assert all(a['material'] == p['material'] and a['options'] == p['options'] for p in (b, c, d))
    assert np.array_equal(fields['Before/HardBaseline'], fields['Before/HardEarlyField'][:10])
    assert np.array_equal(fields['Before/HardEarlyField'], fields['RecoveryTrial/HardEarlyField'])
    assert np.array_equal(fields['RecoveryTrial/HardEarlyField'][:14], fields['RecoveryTrial/HardRecovery'][:14])
    output.write_text(json.dumps({'cases': result, 'baseline_prefix_exact': 10,
        'orientation_guard_fields_exact': 23, 'private_recovery_prefix_exact': 14,
        'physical_capacity_certified': False, 'independent_material_reintegration': False},
        indent=2, sort_keys=True, ensure_ascii=False) + '\n', encoding='utf-8')
    print('HARD FIELD ALL SIX FORCES FULL SPATIAL EQUATIONS AND ORIENTATION VERIFIED; CAPACITY OPEN', flush=True)


def TestSpatial(repo, root, output):
    """Повторяет согласованный материал и равновесие всех полей MVT2, сравнивает с закреплённой историей."""
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    run_path(str(root / 'Validate-TestGeneralContinuation.py'))['TestValidate'](repo, root / 'Cases/Final', 'Trace74', output)
    proof = TestRead(output)
    baseline = TestRead(root / 'Baseline/Origin.json')
    archive = repo / 'docs/regression/Coupled6D' / baseline['archive']
    assert sha256(archive.read_bytes()).hexdigest().upper() == baseline['sha256']
    for name, digest in baseline['entries'].items():
        assert sha256((root / 'Baseline' / name).read_bytes()).hexdigest().upper() == digest
    def TestFields(file):
        """Не округляет и не исключает множители связей из сравнения нативных полей."""
        return [line for line in file.read_text('cp1251').splitlines() if line.startswith('F;')]
    original = TestFields(root / 'Baseline/Trace74.Operators.csv')
    final = TestFields(root / 'Cases/Final/Native/Trace74.Operators.csv')
    assert len(original) == len(final) == 151 and original == final
    proof['all_original_fields_byte_exact'] = 151
    output.write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('HARD FIELD MVT2 MATERIAL REPLAY ALL EQUILIBRIA AND 151 ORIGINAL FIELDS VERIFIED', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics', 'spatial'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics, 'spatial': TestSpatial}[args.scope](
        args.repo.resolve(), args.root.resolve(), args.out.resolve())
