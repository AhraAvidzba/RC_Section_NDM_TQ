"""Rebuild all native force/compatibility rows, detached from the Excel solver."""
from argparse import ArgumentParser
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from hashlib import sha256
import csv,json,runpy
import numpy as np

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare-SecondNative.py')
Z=H/'Native'
LABELS=('Base45','Plus18Center','Plus18TargetMinus','Plus18TargetPlus','Plus18Repeat','End45','Restore45')
PROBES=LABELS[1:5]


def read_json(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def peak(v): return float(np.max(abs(v)))
def sha(p): return sha256(p.read_bytes()).hexdigest().upper()

def archived(repo,name):
    return P['frozen_archive'](repo,name)

def sample_rows(path):
    with path.open(encoding='cp1251',newline='') as stream:
        yield from csv.reader(stream,delimiter=';')

def trace(folder):
    q={}; out={}; flags={}; projections={}
    for tag,name,*row in sample_rows(folder/'KaniV4Trace.csv'):
        if tag=='K59C_VECTOR': dest=q; expected=89
        elif tag=='K59C_STATE': dest=out; expected=99
        elif tag=='PROJECTION': dest=projections; expected=87
        elif tag=='TANGENT_FLAGS': dest=flags; expected=3
        else:
            assert tag=='CHECK'; continue
        assert name not in dest and len(row)==expected
        dest[name]=np.array(row,float)
    assert set(out)==set(q)==set(LABELS) and set(flags)=={'Center'} and set(projections)=={'Mean'}
    return q,out,flags['Center'],projections['Mean']

def station_fields(folder,names):
    tensors={label:np.full((3,184,12),np.nan) for label in names}
    for kind,name,pt,side,*row in sample_rows(folder/'KaniV4Stations.csv'):
        i,j=int(side)+1,int(pt)-1
        assert 0<=i<3 and 0<=j<184 and kind=='K59C_STATION' and len(row)==12 and np.isnan(tensors[name][i,j]).all()
        tensors[name][i,j]=list(map(float,row))
    assert all(np.isfinite(x).all() for x in tensors.values())
    return tensors

def material_observations(folder,names,flags):
    branches={label:np.full((3,184,3),-999) for label in names}; F={label:np.full((3,184),np.nan) for label in names}
    energy={label:np.full((3,184,2),np.nan) for label in ('Base45','End45','Restore45')}; jac={}
    for kind,name,pt,*row in sample_rows(folder/'KaniV4Tangents.csv'):
        j=int(pt)-1
        if kind=='MATRIX':
            assert 0<=j<88 and len(row)==88
            m=jac.setdefault(name,np.full((88,88),np.nan)); assert np.isnan(m[j]).all(); m[j]=list(map(float,row)); continue
        i=int(row[0])+1; tail=row[1:]; assert 0<=i<3 and 0<=j<184
        if kind=='BRANCH':
            assert branches[name][i,j,0]==-999 and len(tail)==3
            branches[name][i,j]=list(map(int,tail))
        elif kind=='ENERGY':
            assert np.isnan(energy[name][i,j]).all() and len(tail)==2
            energy[name][i,j]=list(map(float,tail))
        else:
            assert kind=='YIELD' and len(tail)==1 and np.isnan(F[name][i,j])
            F[name][i,j]=float(tail[0])
    assert all(np.isfinite(x).all() for x in [*energy.values(),*F.values(),*jac.values()])
    assert all((x!=-999).all() for x in branches.values())
    assert set(jac)=={k for yes,k in zip(flags,('CenterStock','CenterRefined','CenterOrdinary')) if yes}
    return branches,F,energy,jac


def verify(repo,donor_zip):
    manifest=read_json(H/'Manifest.json')
    assert all(sha(H/k)==x for k,x in manifest['files'].items())
    prep=read_json(H/'Preparation.json'); assert sha(repo/P['BOOK'])==prep['bookSHA256']
    plan=read_json(H/'Plus18Plan.json'); r=read_json(Z/'KaniV4.txt.ProcessClosure.json')
    book=read_json(H/'docs/regression/CodeUpdate.json'); own=read_json(Z/'KaniV4.txt.Ownership.json'); closed=read_json(Z/'CompileClosure.json')
    end=r['Closure']['FinalState']; report=(Z/'KaniV4.txt').read_text(encoding='utf-8-sig')
    assert r['Passed'] and r['ChildExitCode']==0 and end['State']==closed['State']=='Absent'
    assert end['PID']==own['PID'] and end['StartTicksUTC']==own['StartTicksUTC'] and own['VerifiedNewOwner']
    assert book['Compiled'] and not book['ProductionChanged'] and book['ProductionSHA256']==prep['bookSHA256']
    assert ('SOURCE_SHA256: '+book['WorkbookSHA256']) in report and sorted(book['Modules'])==['CCoupledElasticState','CCoupledNewtonSolver','modTestKaniStage38']
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    with archived(repo,'KaniCommitNear48Portable.zip') as history, archived(repo,'KaniPracticalProbe45Portable.zip') as original:
        stage=json.loads(history.read('Commit48Verification.json')); h=dict(np.load(BytesIO(history.read('MeasuredSamples.npz')),allow_pickle=False))
        old=dict(np.load(BytesIO(original.read('MeasuredSamples.npz')),allow_pickle=False)); src=history.read('Verify.py').decode('utf-8')
        # Read only the independently checked spatial basis helper from the identified source.
        stop=src.index('ROOT='); base=src[:stop].replace('\r\n','\n'); ops=H/'BuildOperators.py'; ops.write_text(base,encoding='utf8')
    q,summary,flags,proj=trace(Z); T=station_fields(Z,q); b,F,e,M=material_observations(Z,q,flags)
    ids={key:i for i,key in enumerate(h['names'])}; v=ids['Committed45']; base=q['Base45']
    assert np.array_equal(proj,h['projection']) and np.array_equal(base,h['fields'][v]) and np.array_equal(T['Base45'],h['stations'][h['station_index'][v]])
    assert np.array_equal(e['Base45'],np.array(stage['energiesByStation_minus0plus']['Committed45']))
    for fields in (q,T,b,F,e):
        assert all(np.array_equal(fields['Base45'],fields[n]) for n in ('End45','Restore45'))
    for fields in (q,T,b,F): assert np.array_equal(fields['Plus18Center'],fields['Plus18Repeat'])
    assert np.array_equal(summary['Plus18Center'],summary['Plus18Repeat'])
    assert np.array_equal(old['geometry'],h['geometry'])
    build=runpy.run_path(ops)['operators']; length=float(h['length']); geo=h['geometry']; H0,sh,g,phys,area,scale=build(geo,length)

    def material_force(stress):
        core=stress[1]; gradient=(stress[2]-stress[0])/.002
        weak=np.einsum('nij,ni,n->j',H0,core,area)
        weak[4:]-=np.einsum('nk,na,n->ka',sh,gradient[:,[4,5,2]],area).ravel()
        long=np.einsum('nij,ni,n->j',H0[:,:,:4],gradient,area)
        wrench=np.einsum('nij,nj,n->i',phys,core,geo[:,2]); return np.r_[weak,long],wrench
    def section(tag):
        lam,gamma=q[tag][:2]; d=q[tag][2:]; state=summary[tag]; tensor=T[tag]
        target=np.r_[np.zeros(5),1e5*lam]
        strain=H0@d[:79]; gradient=H0[:,:,:4]@d[79:83]
        expected=np.array([strain+i*.001*gradient for i in (-1,0,1)])
        assert peak(expected-tensor[:,:,:6])<2e-12
        w,c=material_force(tensor[:,:,6:]); w[:79]+=g.T@d[83:]; w[80]-=lam*1e5/scale[0];
        eq=np.r_[25600*g@d[:79],25600*(proj@d-gamma)]
        rows=np.r_[w,(c-target)/scale]; assert len(rows)==89 and len(eq)==5
        errs=[peak(w-state[12:95]),peak((c-state[6:12])/scale),peak(eq[:4]/25600-state[95:99]),abs(eq[-1]-state[4])]
        n=max(peak(rows),abs(eq[-1])); assert max(errs)<2e-10 and abs(n-state[2])<2e-10 and peak(eq)<=state[3]
        return rows,c,n,eq,max(errs)
    points={tag:section(tag) for tag in LABELS}; center=points['Plus18Center'][0]
    assert abs(q['Plus18Center'][0]*1e5-plan['fixedQyN'])<1e-8 and abs(q['Plus18Center'][1]-plan['fixedPositiveGamma'])<2e-16
    for tag in PROBES:
        assert np.array_equal(q[tag][:2],q['Plus18Center'][:2]) and np.array_equal(q[tag][-4:],q['Plus18Center'][-4:])
        expect=np.array(plan['conditionalModel'][tag if tag!='Plus18Repeat' else 'Plus18Center']['field'])
        assert peak(q[tag][2:]-expect[:87])<3e-16 and abs(q[tag][0]-expect[-1])<1e-14
    assert sha(donor_zip)==P['ANCHOR']
    with ZipFile(donor_zip) as proof:
        prior_result=json.loads(proof.read('Plus18Verification.json'))
        D={tag:np.full((3,184,12),np.nan) for tag in ('Plus18TargetPlus','Plus18TargetMinus')}
        for kind,tag,pt,side,*points0 in csv.reader(proof.read('Native/KaniV4Stations.csv').decode('cp1251').splitlines(),delimiter=';'):
            if tag in D: D[tag][int(side)+1,int(pt)-1]=list(map(float,points0))
        assert np.array_equal(D['Plus18TargetPlus'],T['Plus18Center'])
    old_action=(D['Plus18TargetPlus'][:,:,:6]-D['Plus18TargetMinus'][:,:,:6]).ravel()
    new_action=(T['Plus18TargetPlus'][:,:,:6]-T['Plus18TargetMinus'][:,:,:6]).ravel()
    cos=float((old_action@new_action)/np.linalg.norm(old_action)/np.linalg.norm(new_action))
    assert abs(cos)<1e-8 and abs(peak(new_action)/2e-9-2)<1e-5
    p_old=prior_result['statuses']['Plus18TargetPlus']; p_now=points['Plus18Center']
    assert peak(np.array(p_old['all89Rows_MPa'])-p_now[0])<2e-10
    refined=old['resultant_projection']; matrix89={k:np.r_[a[:83],refined@a[:83]] for k,a in M.items()}
    weights=np.array([-1,0,1])[:,None]*((geo[:,2]*geo[:,1])/(305.*610.*length*.002))[None]
    cert={}
    for tag in PROBES:
        rows,wrench,n,five,roundoff=points[tag]; c=T['Plus18Center']; change=T[tag]-c
        w81=weights*change[:,:,8]; delta=rows-center; d=np.r_[q[tag][2:]-q['Plus18Center'][2:],0.]
        assert abs(float(w81.sum())-delta[80])<2e-12
        i,k=np.unravel_index(int(np.argmax(abs(w81))),w81.shape)
        a=plan['conditionalModel'][tag if tag!='Plus18Repeat' else 'Plus18Center']['apexHybrid']['H45Stock']
        cert[tag]={'maxForceRows_MPa':peak(rows),'maxWithControls_MPa':n,'tau_MPa':float(summary[tag][3]),'withinTolerance':bool(n<=summary[tag][3]),
                   'independentNoiseUpper_MPa':roundoff,'dominantRow':int(np.argmax(abs(rows))+1),'all89Rows_MPa':rows.tolist(),
                   'sixWrenches_N_Nmm':wrench.tolist(),'targetQyMiss_N':float(wrench[-1]-q[tag][0]*1e5),'fiveControlsMPa':five.tolist(),
                   'weak81_MPa':float(rows[80]),'weak81Change_MPa':float(delta[80]),'predictedWeak81_MPa':a['row81MPa'],
                   'branchChangesVersusCenter':int(np.count_nonzero(np.any(b[tag]!=b['Plus18Center'],axis=2))),
                   'plasticIncrementSwitchesVersusCenter':int(np.count_nonzero(b[tag][:,:,0]!=b['Plus18Center'][:,:,0])),
                   'FSignChangesVersusCenter':int(np.count_nonzero(np.sign(F[tag])!=np.sign(F['Plus18Center']))),
                   'maxStrainChangeVersusCenter':peak(change[:,:,:6]),
                   'row81Stations':{'directConcrete_MPa':float(w81[:,:144].sum()),'netRebar_MPa':float(w81[:,144:].sum()),
                                      'point8AllSides_MPa':float(w81[:,7].sum()),'largestSidePoint':[int(i)-1,int(k)+1],
                                      'largestContributionMPa':float(w81[i,k])},
                   'measuredDeltaAll89_MPa':delta.tolist(), 'freshTangentErrorAll89_MPa':{k:peak(m@d-delta) for k,m in matrix89.items()},
                   'freshTangentRow81Change_MPa':{k:float((m@d)[80]) for k,m in matrix89.items()}}
    plus=points['Plus18TargetPlus'][0]; minus=points['Plus18TargetMinus'][0]; even=plus+minus-2*center
    result={'workbook':prep['bookSHA256'],'commonQy_N':float(q['Plus18Center'][0]*1e5),'commonGamma':float(q['Plus18Center'][1]),
            'physicalRows':89,'kinematicRows':5,'stationsPerState':552,'recordedStates':len(LABELS),
            'stationProofH45Exact':True,'afterProbesAndReplaySame':True,'statuses':cert,
            'repeatDeterminism':{'repeatRowDifference_MPa':peak(points['Plus18Repeat'][0]-center),
                'repeatTensorDifference':peak(T['Plus18Repeat']-T['Plus18Center']),
                'maxIndependentAssemblyMismatchMPa':max(row[-1] for row in points.values()),
                'evenPartOfSignedProbes_MPa':peak(even),'evenRow81_MPa':float(even[80]),'staticTangentMinimaxErrorLowerMPa':peak(even)/2.},
            'tangentFlags':dict(zip(('stock','refined','ordinaryFallback'),map(bool,flags))),
            'closure':{'compile':closed,'native':end},'nativeSHA256':{file:sha(Z/file) for file in ('KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv')}}
    gidx=[80,83,86,88]; r0=points['Plus18Center'][0]; rtarget=points['Plus18TargetPlus'][0]
    result.update(slotAliases=plan['slotAliases'],originalBaselineExactlyReproduced=True,
        signedDirectionCosineToOriginal=cos, nativeChangesFourSignedRows_MPa=(rtarget-r0)[gidx].tolist(),
        nativeTargetAbsRatios=(abs(rtarget[gidx])/abs(r0[gidx])).tolist(),
        fourSimultaneouslyImproved=bool(np.all(abs(rtarget[gidx])<abs(r0[gidx]))),
        previouslyCheckedSourceReceipt_hash=P['ANCHOR'])
    out=H/'ReplayedSecondNativeVerification.json'; out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(out,sha(out),[(k,x['weak81_MPa'],x['maxForceRows_MPa']) for k,x in cert.items()],result['tangentFlags'])
    assert result==read_json(H/'SecondNativeVerification.json')
    return result

if __name__=='__main__':
    parser=ArgumentParser(); parser.add_argument('--repo-root',type=Path,required=True); parser.add_argument('--donor-zip',type=Path,default=H.parent/'kani18b/KaniH45Plus18NativePortable.zip'); a=parser.parse_args()
    verify(a.repo_root.resolve(),a.donor_zip.resolve())
