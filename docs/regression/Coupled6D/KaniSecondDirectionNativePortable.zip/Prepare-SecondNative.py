from argparse import ArgumentParser
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from shutil import copyfile
import csv,json

H=Path(__file__).resolve().parent; P=H.parent/'kani18b'; X=H.parent/'kani-correct'
BOOK=Path('workbook/output/RC_Section_NDM.xlsm'); PRIVATE=Path('docs/regression/Diagnostic.xlsm')
LIVE={BOOK:'A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A',
      Path('src/Solver/CCoupledNewtonSolver.cls'):'9E33A100858D4181123244A0A54F98DF23258B9ABD87CF0E6293C122E371176F',
      Path('src/Solver/CCoupledElasticState.cls'):'A6BF256F42610AE7A353AD4AE1CCC9275DC247B398C3FA429CACD83840C97F94',
      Path('src/Materials/CCoupledConcreteResponse.cls'):'92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C'}
ANCHOR='10FFDC956D9F6D74F6A50A79DF2E50B3C5F7EFE810AEB18A4415D8584E1C5F48'
FIXTURE='9C53E6223929FB210237A5610FD2417496C88E204304005BF93A99AB6AA6E0B3'
PLAN='5D95AD1707A18F72A8645E4314A4F448E22BF0A9A2341965C7E9C50EB2B66CA4'
NATIVE_ROLES={'Plus18Center':'SecondCenter','Plus18TargetMinus':'SecondOpposite','Plus18TargetPlus':'SecondImprove','Plus18Repeat':'SecondRepeat'}
ARCHIVES={'KaniCommitNear48Portable.zip':'EA0A80006AF81D99799B53FDCB75B18CDDE7B7DF730AB16039902F12C6431488',
          'KaniPracticalProbe45Portable.zip':'4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113'}
sha=lambda p:sha256(p.read_bytes() if isinstance(p,Path) else p).hexdigest().upper()

def frozen_archive(repo,file):
    z=repo/'docs/regression/Coupled6D'/file
    assert sha(z)==ARCHIVES[file]
    return ZipFile(z)

def live(repo):
    assert H.is_relative_to((repo/'tmp').resolve()) and all(sha(repo/k)==v for k,v in LIVE.items())

def prepare(repo):
    live(repo)
    if (H/'Preparation.json').exists(): return check(repo)
    arch=P/'KaniH45Plus18NativePortable.zip'; assert sha(arch)==ANCHOR
    assert sha(X/'SecondCoordinateDiagnostic.csv')==FIXTURE and sha(X/'SecondCoordinatePlan.json')==PLAN
    with ZipFile(arch) as z:
        old=json.loads(z.read('Preparation.json')); g=z.read('KaniGaugeInput.csv').decode('ascii').splitlines();
        receipt=z.read('docs/regression/CodeUpdate.json'); clo=z.read('Native/CompileClosure.json'); own=z.read('Native/KaniV4.txt.ProcessClosure.json')
        last=json.loads(z.read('Plus18Verification.json')); oldfields=z.read('Plus18Fields.csv').decode('ascii').splitlines()
        assert sha(z.read('Plus18Verification.json'))=='982D826223C8EC5B6EF6E8F72F4C1A4ABFE1E6AE24B6FDFC118D75E8AF2D82FD'
    permit=json.loads(receipt); first=json.loads(clo); prev=json.loads(own)['Closure']['FinalState']
    assert first['State']==prev['State']=='Absent' and permit['Compiled'] and not permit['ProductionChanged']
    assert permit['ProductionSHA256']==LIVE[BOOK] and permit['WorkbookSHA256']==sha(P/PRIVATE)
    assert last['afterProbesAndReplaySame'] and not last['statuses']['Plus18TargetPlus']['withinTolerance']
    new=(X/'SecondCoordinateDiagnostic.csv').read_text(encoding='ascii').splitlines()
    baseline=next(x.replace(';Plus18TargetPlus;',';SecondCenter;') for x in oldfields if x.startswith('KANI_B_FIELD;Plus18TargetPlus;'))
    assert new[0]==baseline and [x.split(';')[1] for x in new]==list(NATIVE_ROLES.values())[:3]
    assert all(new[0].split(';')[i]==x.split(';')[i] for i in [3,91,*range(87,91)] for x in new)
    h=[x for x in g if x.startswith('KANI_B_FIELD;History')]; assert len(h)==8
    live_input=[]
    for raw,role in zip(new,list(NATIVE_ROLES)[:3],strict=True):
        x=raw.split(';'); assert len(x)==92; x[1]=role; live_input.append(';'.join(x))
    target=(H/'KaniGaugeInput.csv'); target.write_bytes(('\r\n'.join(h+live_input)+'\r\n').encode('ascii'))
    artifact={'conditionalModel':{},'fixedQyN':last['commonQy_N'],'fixedPositiveGamma':last['commonGamma'],
              'slotAliases':NATIVE_ROLES,'fixtureSHA256':FIXTURE}
    p=json.loads((X/'SecondCoordinatePlan.json').read_text(encoding='utf8')); delta=p['candidateAnalysis']['balancedSecondDirection']['delta']
    from math import isfinite
    for raw,role,s in zip(new,list(NATIVE_ROLES)[:3],(0,-1,1),strict=True):
        x=raw.split(';'); d=list(map(float,x[4:-1]))+[float(x[-1])]; assert len(d)==88 and all(map(isfinite,d))
        alias='Plus18Repeat' if role=='Plus18Center' else None
        candidate=p['candidateAnalysis']['balancedSecondDirection']['allCharts']['CenterStock']
        expected=last['statuses']['Plus18TargetPlus']['weak81_MPa']+s*candidate['deltaTargetFromNativeMPa'][0]
        artifact['conditionalModel'][role]={'field':d,'apexHybrid':{'H45Stock':{'row81MPa':expected}}}
    (H/'Plus18Plan.json').write_text(json.dumps(artifact,indent=2)+'\n',encoding='utf8')
    kit={str(PRIVATE):(P/PRIVATE).read_bytes(),'docs/regression/CodeUpdate.json':receipt,'Native/CompileClosure.json':clo,
         'Native/DonorNativeClosure.json':own,'SecondCoordinateDiagnostic.csv':(X/'SecondCoordinateDiagnostic.csv').read_bytes(),
         'SecondCoordinatePlan.json':(X/'SecondCoordinatePlan.json').read_bytes()}
    for k,v in old['frozen'].items():
        if k.startswith('tools/') or k in ('KaniV4Input.csv','KaniChartInput.csv'):
            source=P/k; assert sha(source)==v; kit[k]=source.read_bytes()
    for k,v in kit.items():
        path=H/k; path.parent.mkdir(exist_ok=True,parents=True); path.write_bytes(v)
    for sub in ('Temp','Native'): (H/sub).mkdir(exist_ok=True)
    names=sorted(set(kit)|{'KaniGaugeInput.csv','Plus18Plan.json','Prepare-SecondNative.py','Verify-SecondNative.py','Run-SecondNative.ps1'})
    out={'bookSHA256':LIVE[BOOK],'donorBookSHA256':permit['WorkbookSHA256'],'donorEvidenceSHA256':ANCHOR,
         'experimentFixtureSHA256':FIXTURE,'frozen':{k:sha(H/k) for k in names}}
    (H/'Preparation.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
    return check(repo)

def check(repo):
    live(repo)
    p=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert p['bookSHA256']==LIVE[BOOK] and p['donorBookSHA256']==sha(H/PRIVATE)
    assert all(sha(H/k)==v for k,v in p['frozen'].items())
    return p

if __name__=='__main__':
    ap=ArgumentParser(); ap.add_argument('--repo-root',type=Path,required=True); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    assert (check if a.check else prepare)(a.repo_root.resolve())['bookSHA256']==LIVE[BOOK]
    print(sha(H/'Preparation.json'))
