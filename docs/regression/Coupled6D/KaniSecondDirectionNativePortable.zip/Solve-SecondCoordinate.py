"""Find what a second physical direction could resolve near the best native +18 N sample."""
from pathlib import Path
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
import csv,json,runpy
import numpy as np
from scipy.optimize import linprog

H=Path(__file__).resolve().parent; N=H.parent/'kani18b'; X=H.parent/'kani-next'; ROOT=H.parent.parent
AR=N/'KaniH45Plus18NativePortable.zip'; sha=lambda p:sha256(p.read_bytes()).hexdigest().upper()
assert sha(AR)=='10FFDC956D9F6D74F6A50A79DF2E50B3C5F7EFE810AEB18A4415D8584E1C5F48'
with ZipFile(AR) as z:
    report=json.loads(z.read('Plus18Verification.json')); plan=json.loads(z.read('Plus18Plan.json'))
    records={r[1]:np.array(r[2:],float) for r in csv.reader(z.read('Native/KaniV4Trace.csv').decode('cp1251').splitlines(),delimiter=';') if r[0]=='K59C_VECTOR'}
    mats={}
    for row in csv.reader(z.read('Native/KaniV4Tangents.csv').decode('cp1251').splitlines(),delimiter=';'):
        if row[0]=='MATRIX': mats.setdefault(row[1],np.full((88,88),np.nan))[int(row[2])-1]=list(map(float,row[3:]))
    native_hashes={name:sha256(z.read('Native/'+name)).hexdigest().upper() for name in ('KaniV4Stations.csv','KaniV4Tangents.csv','KaniV4Trace.csv')}
assert native_hashes==report['nativeSHA256'] and set(mats)=={'CenterStock','CenterRefined'}
m=runpy.run_path(X/'Build-H45Section.py'); sec=m['S']; K=m['K']; B=m['shape']; proj=m['R']['projection']; force_scale=m['forceScale']; pk=m['pk']
assert all(pk(j[83:]-K)<2e-11 for j in mats.values())
J={name:np.r_[j[:83],sec['resultant_projection']@j[:83]] for name,j in mats.items()}
T={name:np.array(x['all89Rows_MPa']) for name,x in report['statuses'].items()}; assert all(x.shape==(89,) for x in T.values())
base='Plus18TargetPlus'; center='Plus18Center'; minus='Plus18TargetMinus'; R=T[base]; tau=report['statuses'][base]['tau_MPa']
native_q=lambda n:np.r_[records[n][2:],records[n][0]]
q=native_q(base); center_q=native_q(center)
v=.5*(native_q(base)-native_q(minus)); l=center_q-native_q('Base45'); assert pk(B@v)>0
assert pk(native_q(base)+native_q(minus)-2*center_q)<5e-15 and pk(K@v)<2e-10
# This second measured direction spans a larger change from the accepted H45 to the native center.
# Its load term is known exactly, and the finite material secant is held as a stress-test scenario.
z=np.column_stack((v,l)); k=B@z; W=np.linalg.solve(k.T@k,k.T@B); assert pk(W@z-np.eye(2))<3e-12
j45=m['J']; s_native=(T[center]-m['r']); v_measured_plus=T[base]-T[center]; v_measured_minus=T[center]-T[minus]
QF=force_scale[0]; QT=force_scale[3]
TARGET=np.array([80,83,86,88]); targeted=list(TARGET)

def section_model():
    ops={}
    for name,j in J.items():
        ops[name]=j
        ops[name+'/transportSecant']=j+np.outer(s_native-j@l,W[1])
    return ops
models=section_model()


def solve(group,op_names,cap,allow_gauge,targets_hard=False):
    # Correction is restricted to a second physical direction. The measured order-2 chord is not
    # reused as a linear prediction: preserve the exact same loading and remove its projection.
    eq=np.vstack((K,W[0]))
    scale=np.r_[np.full(83,cap),np.full(4,2e-5),1.]
    coeff=eq[:,:87]*scale[:87]; es=np.max(abs(coeff),axis=1)
    # Keep all controls fixed. The reconstructed stored H45 gauge residual can be ignored only after checking it is roundoff.
    assert pk(np.r_[25600*m['g']@q[:79],25600*(proj@q[:87]-records[base][1])])<2e-11
    Aeq=np.c_[coeff/es[:,None],np.zeros(len(es))]; beq=np.zeros(len(es)); S=B[:,:87]*scale[:87]/cap
    U=[np.c_[S,np.zeros(len(S))],np.c_[-S,np.zeros(len(S))]]; h=[np.ones(len(S)),np.ones(len(S))]
    rowset=targeted if group=='targetedMinimax' else list(range(89))
    for name in op_names:
        J0=models[name][:,:87]*scale[:87]/tau; r0=R/tau
        M=J0[rowset]; rr=r0[rowset]
        U += [np.c_[M,-np.ones(len(M))],np.c_[-M,-np.ones(len(M))]]; h += [-rr,rr]
        if targets_hard:
            T0=J0[targeted]; v0=r0[targeted]
            U += [np.c_[T0,np.zeros(len(T0))],np.c_[-T0,np.zeros(len(T0))]]; h += [1-v0,1+v0]
    prior=([-10.,10.] if allow_gauge else [0.,0.]); bounds=[(-8.,8.)]*83+[tuple(prior)]*4+[(0,None)]
    ans=linprog(np.r_[np.zeros(87),1.],np.vstack(U),np.concatenate(h),Aeq,beq,bounds=bounds,method='highs')
    if not ans.success: return {'succeeded':False,'status':int(ans.status),'message':ans.message}
    d=np.r_[ans.x[:87]*scale[:87],0.]
    assert pk(K@d)<2e-12
    assert pk(B@d)<cap*(1+1e-8)
    assert abs(float(W[0]@d))<3e-11
    yy={lab:R+j@d for lab,j in models.items()}
    act={lab:{'fullNormMPa':pk(values),'peakRow':int(np.argmax(abs(values))+1),
              'fourTargetsMPa':values[TARGET].tolist(),'physicalErrorsN_Nmm':[float(values[83]*QF),float(values[86]*QT),float(values[88]*QF)]}
              for lab,values in yy.items()}
    lower=float(ans.fun*tau)
    dual_obj=sum(g@h for g,h in [(ans.ineqlin.marginals,np.concatenate(h)),(ans.eqlin.marginals,beq)])
    dual_obj+=sum(mul*lim for mul,(lim,_) in zip(ans.lower.marginals,bounds) if lim is not None)
    dual_obj+=sum(mul*lim for mul,(_,lim) in zip(ans.upper.marginals,bounds) if lim is not None)
    assert abs(dual_obj-ans.fun)<1e-5
    return {'succeeded':True,'activeChartNames':list(op_names),'minimaxMPa':lower,'dualLowerMPa':float(dual_obj*tau),
            'boundsOnEachGauge_MPa':(np.array(prior)*scale[83]).tolist(),'maxStrain':pk(B@d),
            'newPhysicalStrainCosine':float((B@d)@(B@v)/np.linalg.norm(B@d)/np.linalg.norm(B@v)),
            'oldSecantProjection':float(W[1]@d),'delta':d.tolist(),'predictedByAllCharts':act}

names=tuple(J); stress=tuple(models); radius=2e-9
boxes={}
for case,group,family,gauge,req in [('freshUnchangedGauge','full',names,False,False),
                                    ('freshFreeGauge','full',names,True,False),
                                    ('freshFourTargets','targetedMinimax',names,False,False),
                                    ('freshEnforceTargets','full',names,True,True),
                                    ('scopePlusTransport','full',stress,False,False),
                                    ('scopeEnforceTargets','full',stress,True,True)]:
    boxes[case]=solve(group,family,radius,gauge,req)
    v0=boxes[case]; print(case,v0.get('minimaxMPa'),v0.get('message'),flush=True)

# Compare signed force/stress action from the native same-history probes, independently of optimizers.
inventory={}
for n,d,actual in [('Plus',v,v_measured_plus),('Minus',-v,-v_measured_minus)]:
    err={k:j@d-actual for k,j in J.items()}
    inventory[n]={'deltaQy_N':float(actual[88]*QF),'deltaN_N':float(actual[83]*QF),'deltaT_Nmm':float(actual[86]*QT),
                 'deltaWeak81_MPa':float(actual[80]),'rawPredictedChangeAtFourRowsMPa':{k:(j@d)[TARGET].tolist() for k,j in J.items()},
                 'reconstructedActualFourRowsMPa':actual[TARGET].tolist(),
                 'errorAtFourRowsMPa':{k:v[TARGET].tolist() for k,v in err.items()},
                 'fullNormLinearizationError_MP':{k:pk(v) for k,v in err.items()}}

ans={'inputArchiveSHA':sha(AR),'originalEquilibriumToleranceMPa':tau,'storedNoiseMPa':report['repeatDeterminism']['maxIndependentAssemblyMismatchMPa'],
     'staticTangentWorstErrorLowerMPaAlongFirstMeasuredAxis':report['repeatDeterminism']['staticTangentMinimaxErrorLowerMPa'],
     'targetIndicesOneBased':[int(k)+1 for k in TARGET], 'physicalBaselineNormMPa':pk(R),
     'physicalBaselineTargetsMPa':R[TARGET].tolist(),'fixtureLambda':float(q[-1]),'fixtureGamma':float(records[base][1]),
     'baselineName':base,'secondDirectionStrainRadius':radius,'fromBase45ToCenterPhysicalNorm':pk(B@l),
     'measuredSignedVsFreshLinear':inventory,'conditionalLP':boxes,
     'explicitLimits':'All LPs are chart-conditional. Center to plus changed 61 branch signatures. Whole-section response of the second direction after this change is unmeasured. Transport alternative deliberately retains observed full-section history change.'}
f=H/'SecondCoordinateResults.json'; f.write_text(json.dumps(ans,indent=2)+'\n',encoding='utf8')
print(f,sha(f))
