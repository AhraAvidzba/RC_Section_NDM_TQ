"""Allow the already sampled coordinate as well as a bounded independent one."""
from pathlib import Path
from hashlib import sha256
import json,runpy
import numpy as np
from scipy.optimize import linprog

H=Path(__file__).resolve().parent; m=runpy.run_path(H/'Solve-SecondCoordinate.py')
B=m['B']; K=m['K']; T=m['T']; W=m['W']; t=m['tau']; models=m['models']; radius=2e-9; v=m['v']; q=m['q']
center,plus,minus=m['center'],m['base'],m['minus']; tgt=m['TARGET']; pk=m['pk']
R0=T[center]; A=0.5*(T[plus]+T[minus])-R0; C=.5*(T[plus]-T[minus]);
assert pk(A+C+R0-T[plus])<2e-18 and pk(A-C+R0-T[minus])<2e-18
scale=np.r_[np.full(83,radius),np.full(4,2e-5)]
E=np.vstack((K[:,:87],W[:1,:87]))*scale; E/=np.max(abs(E),axis=1)[:,None]
Aeq=np.c_[E,np.zeros((len(E),2))]; no_eq=np.zeros(len(E)); stm=B[:,:87]*scale/radius
capA=[np.c_[stm,np.zeros((len(stm),2))],np.c_[-stm,np.zeros((len(stm),2))]]; capb=[np.ones(len(stm)),np.ones(len(stm))]


def solve(sector,obj,op_names):
    ro=R0/t; row_sets=list(tgt) if obj=='fourTargets' else list(range(89))
    bb=capA.copy(); cc=capb.copy()
    chord=(T[plus]-R0 if sector>0 else T[minus]-R0)/t
    for lab in op_names:
        rs=np.c_[models[lab][:,:87]*scale/t,chord][row_sets]; r=ro[row_sets]
        bb += [np.c_[rs,-np.ones(len(rs))],np.c_[-rs,-np.ones(len(rs))]]; cc += [-r,r]
    u=np.vstack(bb); b=np.concatenate(cc); cb=[(-8,8)]*83+[(-10,10)]*4+[(0,1),(0,None)]
    ans=linprog(np.r_[np.zeros(88),1.],u,b,Aeq,no_eq,bounds=cb,method='highs')
    assert ans.success
    d=np.r_[ans.x[:87]*scale,0.]; s=float(ans.x[87]*sector)
    primal=float(ans.fun*t)
    dual=float((ans.ineqlin.marginals@b+sum(l*a for l,(a,_) in zip(ans.lower.marginals,cb) if a is not None)
        +sum(h*z for h,(_,z) in zip(ans.upper.marginals,cb) if z is not None))*t)
    assert abs(primal-dual)<2e-12
    resid_chord=R0+abs(s)*chord*t; resid_quad=R0+s*C+s*s*A
    predicted={k:(resid_chord+M@d,resid_quad+M@d) for k,M in models.items()}
    return {'sign':sector,'minimaxMPa':primal,'dualLowerMPa':dual,'measuredCoordinateFraction':s,
            'secondDirectionStrain':pk(B@d),'totalStrainDistanceFromBestSample':pk(B@(d+(s-1)*v)),
            'linearVersusQuadraticTrackedAxisMPa':pk(resid_chord-resid_quad),
            'fullNormAtEitherInterpolation':{key:[pk(a),pk(b)] for key,(a,b) in predicted.items()},
            'rowFactorsAtEitherInterpolation':{key:[a[tgt].tolist(),b[tgt].tolist()] for key,(a,b) in predicted.items()}}

families={'fresh':tuple(m['J']),'plusMeasuredFiniteSecant':tuple(models)}; common={}
for label,version in families.items():
    common[label]={}
    for kind in ('all89','fourTargets'):
        common[label][kind]=[solve(s,kind,version) for s in (-1,1)]; print(label,kind,[(x['minimaxMPa'],x['measuredCoordinateFraction'],x['linearVersusQuadraticTrackedAxisMPa']) for x in common[label][kind]],flush=True)
res={'approximation':'Native residuals enter exactly at the three sampled anchors. Within each measured segment, use linear chord and check against quadratic, neither validated in-between.',
     'radiusOfIndependentCorrection':radius,'originalToleranceMPa':t,'conditionalJointSubspace':common}
out=H/'MixedCoordinateResults.json'; out.write_text(json.dumps(res,indent=2)+'\n',encoding='utf8')
print(out,sha256(out.read_bytes()).hexdigest().upper())
