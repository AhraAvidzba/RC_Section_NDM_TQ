"""Choose a diagnostic second move that improves every named target in the retained charts."""
from pathlib import Path
from hashlib import sha256
import numpy as np
from scipy.optimize import linprog
import csv,json,runpy

H=Path(__file__).resolve().parent
m=runpy.run_path(H/'Solve-SecondCoordinate.py')
B=m['B']; K=m['K']; R=m['R']; T=m['TARGET']; tau=m['tau']; W=m['W']; q=m['q']; J=m['models']; N=m['N']
old=m['report']; radius=2e-9; S=B[:,:83]*radius; coeff=np.vstack((K[:,:83],W[:1,:83]))*radius
coef=coeff/np.max(abs(coeff),axis=1)[:,None]
E=np.c_[coef,np.zeros(len(coef))]; er=np.zeros(len(coef))
columns=J
scale=np.abs(R[T]); assert np.all(scale>tau)


def plan(case, names, *, strain_objective=False, constrain_full=False):
    s=S/radius
    if strain_objective:
        rows=[np.c_[s,-np.ones(len(s))],np.c_[-s,-np.ones(len(s))]]; rhs=[np.zeros(len(s)),np.zeros(len(s))]
    else:
        rows=[np.c_[s,np.zeros(len(s))],np.c_[-s,np.zeros(len(s))]]; rhs=[np.ones(len(s)),np.ones(len(s))]
    for label in names:
        v=J[label][:,:83]*radius
        if strain_objective:
            T0=v[T]/tau; Rt=R[T]/tau
            rows += [np.c_[T0,np.zeros(len(T0))],np.c_[-T0,np.zeros(len(T0))]]; rhs += [1-Rt,1+Rt]
        else:
            T0=v[T]/scale[:,None]; Rt=R[T]/scale
            rows += [np.c_[T0,-np.ones(len(T0))],np.c_[-T0,-np.ones(len(T0))]]; rhs += [-Rt,Rt]
        if constrain_full:
            v=v/np.max(abs(R)); r=R/np.max(abs(R))
            rows += [np.c_[v,np.zeros(len(v))],np.c_[-v,np.zeros(len(v))]]; rhs += [1-r,1+r]
    U=np.vstack(rows); d=np.concatenate(rhs); eps=linprog(np.r_[np.zeros(83),1.],U,d,E,er,method='highs',
         bounds=([(-250,250)] if strain_objective else [(-8,8)])*83+[(0,None)])
    if not eps.success: return {'feasible':False,'code':eps.status,'why':eps.message}
    dq=np.r_[eps.x[:83]*radius,np.zeros(5)]; Rnew={k:R+op@dq for k,op in J.items()}
    assert max(abs(K@dq))<1e-12
    o={'mode':case,'feasible':True,'objective':float(eps.fun*(radius if strain_objective else 1)),
            'objectiveIsStrain':strain_objective,'scaledStationStep':float(np.max(abs(B@dq))),
            'scalarOnFittedFiniteLoadDirection':float(W[1]@dq),'orthogonalToPreviousPlusMinus':float((B@dq)@(B@m['v'])/np.linalg.norm(B@dq)/np.linalg.norm(B@m['v'])),
            'allCharts':{name:{'allRowsMPa':float(np.max(abs(vec))),'targetsMPa':vec[T].tolist(),'absFractionOfOriginalTargets':(np.abs(vec[T])/scale).tolist(),
                               'deltaTargetFromNativeMPa':(vec[T]-R[T]).tolist(),'rQy_N':float(vec[88]*m['QF']),
                               'rN_N':float(vec[83]*m['QF']),'rT_Nmm':float(vec[86]*m['QT'])} for name,vec in Rnew.items()},
            'delta':dq.tolist()}
    print(case,o['objective'],'maxstrain',o['scaledStationStep'],{name:val['absFractionOfOriginalTargets'] for name,val in o['allCharts'].items()},flush=True)
    return o

fresh=tuple(m['J']); guard=tuple(J)
response={case:plan(case,names,strain_objective=s,constrain_full=fc) for case,names,s,fc in
          [('balancedSecondDirection',guard,False,True),('minRadiusFourTargetsFresh',fresh,True,False),
           ('minRadiusFourTargetsGuarded',guard,True,True)]}
a=response['balancedSecondDirection']; min_signal_MPa=min(min(abs(op) for op in rec['deltaTargetFromNativeMPa']) for rec in a['allCharts'].values())
assert a['feasible'] and a['objective']<1. and min_signal_MPa>10*m['report']['repeatDeterminism']['maxIndependentAssemblyMismatchMPa']
raw=(N/'Plus18Fields.csv').read_text(encoding='ascii').splitlines(); seed=next(x.split(';') for x in raw if x.startswith('KANI_B_FIELD;Plus18TargetPlus;'))
w=np.array(a['delta']); records=[]; roles=('SecondCenter','SecondOpposite','SecondImprove')
for s,name in zip((0.,-1.,1.),roles):
    zz=np.array(seed[4:-1],float)+s*w[:87]
    assert np.max(abs(zz-q[:87]))<2e-7
    cells=seed[:1]+[name]+seed[2:4]+[format(v,'.17g') for v in zz]+seed[-1:]
    assert len(cells)==92; records.append(';'.join(cells))
p=H/'SecondCoordinateDiagnostic.csv'; p.write_bytes(('\r\n'.join(records)+'\r\n').encode('ascii'))
fs=sha256(p.read_bytes()).hexdigest().upper()
report={'inputArchiveSHA':m['ans']['inputArchiveSHA'],'fixtureSHA256':fs,'fixedQy_N':float(seed[-1])*1e5,'fixedGamma':float(seed[3]),
        'bestNativeFourErrMPa':R[T].tolist(),'sameOriginalTolMPa':tau,'allGaugeValuesExactlyFixed':True,
        'fitUsesUnsignedOscillationFromNative':False,'minimumProjectedSignalMPa':min_signal_MPa,
        'twoSignsExperimentalPurpose':'Identify whether second directional actions reduce all four errors and whether this holds beyond the two fresh tangents. Not a verified equilibrium candidate.',
        'candidateAnalysis':response}
out=H/'SecondCoordinatePlan.json'; out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(out,sha256(out.read_bytes()).hexdigest().upper(),p,fs,min_signal_MPa)
