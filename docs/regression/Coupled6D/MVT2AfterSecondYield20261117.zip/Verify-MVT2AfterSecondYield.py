"""Проверяет продолжение MVT2 после двух текучих продольных стержней."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


SOURCE = ('MVT2SecondBarControl20261117.zip','D6F9BF818204BC07A5CCF4EB6CF89A164CE2BC9FFBAB2E095407503CC1FFF14B')


def verify(repo, root, folder):
    """Собирает принятые и отклонённые поля с исходными допусками и прежней историей."""
    archive=repo/'docs/regression/Coupled6D'/SOURCE[0]
    assert sha256(archive.read_bytes()).hexdigest().upper()==SOURCE[1]
    helper={'__name__':'__pinned__','__file__':'Verify-MVT2SecondBar.py'}
    with ZipFile(archive) as z:
        exec(compile(z.read('Verify-MVT2SecondBar.py'),'Verify-MVT2SecondBar.py','exec'),helper)
        earlier=json.loads(z.read('MVT2SecondBarControl.json'))
    history,tables,mesh,support,material,measure=helper['recover'](repo,folder)
    prefix=earlier['adaptive']['26;0;1e-07;2e-09']
    for row in prefix:
        if row['accepted']:
            history=material(row['field'],tables,mesh[1],support,history)[0]
    actual=json.loads((root/'MVT2AfterSecondYield.json').read_bytes())
    assert actual['initial_Qy_N']==79334.17221299952 and actual['source']==SOURCE[1]
    assert not actual['physical_limit_established']
    scalar=history[0,26][0]
    direction=mesh[1][26][3:]
    control=fsum(a*b for a,b in zip(scalar,direction,strict=True))
    step=1e-7
    accepted=[]
    rejected=0
    for row in actual['rows']:
        assert row['step']==step
        assert abs(row['target_steel_strain']-control-step)<2e-17
        next_history,net,_=material(row['field'],tables,mesh[1],support,history)
        norm,tol=measure(row['field'],row['Qy_N'],net,tables,mesh)
        assert abs(norm-row['norm_MPa'])<3e-9 and abs(tol-row['tol_MPa'])<1e-16
        if row['accepted']:
            assert norm<=tol
            history=next_history
            control=row['target_steel_strain']
            step=min(2e-5,step*2.)
            # Раздельное обнуление вытесненного бетона и проекция возвращают напряжение стали.
            for side,stresses in zip((0,1,-1),row['steel_stress'],strict=True):
                for p,expected in enumerate(stresses,26):
                    eps,_,_,plastic=history[side,p]
                    axial=fsum(a*b for a,b in zip(eps,mesh[1][p][3:],strict=True))
                    assert abs(200000.*(axial-plastic)-expected)<1e-10
            accepted.append({'Qy_N':row['Qy_N'],'strain':control,'norm_MPa':norm,
                             'twist_rad_per_m':row['twist_rad_per_m']})
        else:
            assert norm>tol
            rejected+=1
            step*=.5
    assert len(accepted)==16 and rejected==21 and step<3.125e-9
    max_index=max(range(len(accepted)),key=lambda i:accepted[i]['Qy_N'])
    assert max_index==14 and 79921.30<accepted[max_index]['Qy_N']<79921.31
    assert max_index==len(accepted)-2
    assert accepted[-1]['Qy_N']<accepted[max_index]['Qy_N'] and all(x['norm_MPa']<2e-6 for x in accepted[-2:])
    return {'accepted':accepted,'rejected':rejected,'maximum_Qy_N':accepted[max_index]['Qy_N'],
            'last_Qy_N':accepted[-1]['Qy_N'],'last_equivalent_compressive_strain':max(value[2][1] for value in history.values()),
            'local_falling_pair':True,'physical_limit_established':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    with TemporaryDirectory(dir=a.out.resolve().parent) as folder:
        proof=verify(a.repo,a.root,Path(folder))
    a.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('MVT2 AFTER SECOND YIELD VERIFIED',len(proof['accepted']),proof['rejected'])
