"""Продолжает подтверждённую центральную ветвь MVT2 после текучести двух стержней."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

REFERENCE = ('MVT2SecondBarControl20261117.zip','D6F9BF818204BC07A5CCF4EB6CF89A164CE2BC9FFBAB2E095407503CC1FFF14B')


def run(repo,out):
    """Восстанавливает принятую историю и наращивает шаг после повторного подтверждения равновесия."""
    from zipfile import ZipFile

    path=repo/'docs/regression/Coupled6D'/REFERENCE[0]
    assert sha256(path.read_bytes()).hexdigest().upper()==REFERENCE[1]
    env={'__name__':'__pinned__','__file__':'Trace-MVT2TwistControl.py'}
    controller={'__name__':'__pinned__','__file__':'Trace-MVT2SecondBar.py'}
    with ZipFile(path) as z:
        exec(compile(z.read('Trace-MVT2TwistControl.py'),'Trace-MVT2TwistControl.py','exec'),env)
        exec(compile(z.read('Trace-MVT2SecondBar.py'),'Trace-MVT2SecondBar.py','exec'),controller)
        ref=json.loads(z.read('MVT2SecondBarControl.json'))
    solve=controller['solve']
    section,states,_=env['load'](repo)
    field,history=states[77625.]
    previous=states[77500.][0],77500.
    force=77625.
    prefix=ref['adaptive']['26;0;1e-07;2e-09']
    for row in prefix:
        if not row['accepted']:continue
        q,f=row['Qy_N'],np.asarray(row['field'])
        result=section.evaluate(f,history,env['demand'](q))
        assert result[1]<=row['tol_MPa'] and abs(result[1]-row['norm_MPa'])<1e-9
        previous=field,force
        field,history,force=f,result[4],q
    assert force==79334.17221299952
    projection=section.a[0]
    control=float(projection@field)
    increment=1e-7
    rows=[]
    for i in range(100):
        f,h,row=solve(section,field,history,force,projection,control+increment,previous,2e-9)
        row['step']=increment
        rows.append(row)
        if row['accepted']:
            previous=field,force
            field,history,force=f,h,row['Qy_N']
            control=row['target_steel_strain']
            increment=min(2e-5,increment*2.)
            print(i,'accepted',force,control,flush=True)
            if control>=.004:break
        else:
            increment*=.5
            if increment<3.125e-9:break
    out.write_bytes((json.dumps({'source':REFERENCE[1],'initial_Qy_N':79334.17221299952,'rows':rows,
                                'physical_limit_established':False},indent=2)+'\n').encode())


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    run(a.repo,a.out)
