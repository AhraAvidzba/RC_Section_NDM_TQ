"""ДЛЯ ТЕСТОВ. Переиспользует точную проверку CFB и исходников для явно заданного состава импортов исследования."""
from pathlib import Path
from runpy import run_path


def TestSources(repo,root,expected):
    """Отделяет общую проверку фактического VBA от частных численных результатов, сохраняя все проверки байтов и контрактов."""
    source=Path(__file__).resolve().parent/'Check-TestEnvelopeFailureEvidence.py'
    code=source.read_text('utf-8-sig')
    begin=code.index('def TestProof(repo,root):')
    end=code.index('    numerical={',begin)
    body=code[begin:end]+'    return sources\n'
    body=body.replace('def TestProof(repo,root):','def TestSourceProof(repo,root,expected):',1)
    begin=body.index('    expected={');end=body.index('    for key in cases:',begin)
    body=body[:begin]+'    assert set(expected)==set(cases)\n'+body[end:]
    anchor="expected.get(key,['modTestCoupledElasticState'])";assert body.count(anchor)==1
    body=body.replace(anchor,'expected[key]',1)
    namespace=run_path(str(source));exec(compile(body,str(source),'exec'),namespace)
    return namespace['TestSourceProof'](repo,root,expected)
