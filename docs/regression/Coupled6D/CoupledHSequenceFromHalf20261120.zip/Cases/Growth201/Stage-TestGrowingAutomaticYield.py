"""ДЛЯ ТЕСТОВ. Продолжает H до фактической остановки, переиспользуя скомпилированное ядро автоматического выбора события."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root, parent):
    """Импортирует только новый тестовый сценарий; CNewton и радиус остаются точными байтами родительской компиляции."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestAutomaticYieldPreparation.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body, code)
    assert count == 1 and code.count('Public Sub TestRecordActualEventHalf(') == 1
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name, 'TestAutomaticYieldPreparation.bas.txt'):
        (root / name).write_bytes((here / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='GrowingHThenAutomaticYieldPreparation', actual_import_this_pass=['modTestCoupledElasticState'],
        source_classes_unchanged=True, immutable_compiled_automatic_H_trial_retention=True, CDP_incoming_radius=1.,
        prescribed_material_point_or_level=False, event_context_restored=False, actual_H_progress_committed=True,
        maximum_new_H_states=8, maximum_H_failures_at_revision=4, original_force_and_material_criteria=True,
        controller_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, sort_keys=True, indent=2) + '\n').encode())
    print('GROWING H THEN AUTOMATIC EVENT READY; IMMUTABLE CORE; ONE TEST MODULE IMPORT; NO PRESCRIBED POINT')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve())
