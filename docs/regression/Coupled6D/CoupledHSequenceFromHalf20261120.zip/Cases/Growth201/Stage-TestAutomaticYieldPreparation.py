"""ДЛЯ ТЕСТОВ. Сравнивает автоматическую подготовку CDP-события в двух ограниченных радиусах после реальной H-пробы."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root, parent, expanded):
    """Меняет только сохранение непринятой H-пробы и численный радиус CDP; физические условия и допуски сохраняет."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    body = (here / 'TestAutomaticYieldPreparation.bas.txt').read_text('utf-8-sig')
    record = (here / 'TestActualPoint6Completion.bas.txt').read_text('utf-8-sig')
    record = record[record.index("' -------------------- ДЛЯ ТЕСТОВ --------------------", record.index('\nEnd Sub') + 1):]
    code, count = re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', lambda _: body + '\n' + record, code)
    assert count == 1
    names = re.findall(r'(?im)^(?:Public|Private|Friend) (?:Function|Sub) (\w+)', code)
    assert len(names) == len(set(name.lower() for name in names))
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    begin = code.index('Private Function SolveEnvelopeTarget(')
    end = code.index('\nEnd Function', begin)
    body = code[begin:end]
    anchor = '    If Not solved Or Not solver.HasBestPoint Then GoTo Finished'
    assert body.count(anchor) == 1
    body = body.replace(anchor, '''    If Not solved And solver.HasBestPoint Then
        Dim rejected() As Double, rejectedLambda As Double
        ReadEquationField solution, rejected, rejectedLambda
        mTransitionFrom = mAccepted: mTransitionTo = rejected
        mTransitionRevision = mAcceptedRevision: mHasTransitionSegment = True ' Непринятое поле разрешает только поиск события; равновесием и разрушением не считается.
    End If
''' + anchor, 1)
    code = code[:begin] + body + code[end:]
    if expanded:
        for method in ('SelectYieldEventStation', 'YieldEventPrediction'):
            begin = code.index('Private Function ' + method + '(')
            end = code.index('\nEnd Function', begin)
            body = code[begin:end]
            assert body.count('PRINCIPAL_EVENT_RADIUS') == 1
            body = body.replace('PRINCIPAL_EVENT_RADIUS', 'YIELD_EVENT_RADIUS', 1)
            code = code[:begin] + body + code[end:]
        begin = code.index('Friend Function TryPreparePrincipalTransition(')
        end = code.index('\nEnd Function', begin)
        body = code[begin:end]
        anchor = '    radius = PRINCIPAL_EVENT_RADIUS * reference'
        assert body.count(anchor) == 1
        body = body.replace(anchor, anchor + '\n    If station.PrincipalIndex = 0 Then radius = YIELD_EVENT_RADIUS * reference', 1)
        code = code[:begin] + body + code[end:]
    anchor = '        If SpatialFieldDistance(doubled, outgoing) > YIELD_EVENT_HALF_ERROR * stepLength Then GoTo Unsuccessful'
    assert code.count(anchor) == 1
    code = code.replace(anchor, '        modTestCoupledElasticState.TestRecordActualEventHalf face, outgoing, halfField, faceLambda, trialLambda, halfLambda, stepLength, SpatialFieldDistance(doubled, outgoing)\n' + anchor, 1)
    code += '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает результат автоматического выбора и размер его прогноза; точку, историю, разрешение и поля не подменяет.
Friend Function TestReadYieldPreparation(ByRef previous() As Double, ByVal lambda As Double, _
        ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double) As Variant
    Dim station As TYieldStation, selected As Boolean, prediction() As Double, predicted As Boolean, distance As Double
    selected = SelectYieldEventStation(previous, station)
    If selected Then
        predicted = YieldEventPrediction(previous, station, prediction)
        If predicted Then distance = SpatialFieldDistance(mAccepted, prediction)
    End If
    TestReadYieldPreparation = Array(HasPrincipalTransitionSegment, selected, station.Point, station.Side, station.PrincipalIndex, _
        station.FromValue, station.ToValue, SpatialFieldDistance(previous, mAccepted), predicted, distance, _
        CanPreparePrincipalTransition(previous, lambda, absoluteTolerance, relativeTolerance))
End Function
'''
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    compiler = (root / 'Compile-TestExternalPoint.ps1').read_text('utf-8-sig')
    compiler = compiler.replace("-ModuleNames 'modTestCoupledElasticState'", "-ModuleNames @('CCoupledNewtonSolver','modTestCoupledElasticState')", 1)
    name = 'Compile-TestAutomaticYieldPreparation.ps1'
    (root / name).write_bytes(compiler.encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    runner = root.parent / 'ActualStrictPoint6Completion20261120/Run-TestIntegratedYield.py'
    assert runner.is_file()
    for name, data in {Path(__file__).name: Path(__file__).read_bytes(),
                       'TestAutomaticYieldPreparation.bas.txt': (here / 'TestAutomaticYieldPreparation.bas.txt').read_bytes(),
                       'Run-TestIntegratedYield.py': runner.read_bytes()}.items():
        (root / name).write_bytes(data)
        prep['inputs'][name] = sha256(data).hexdigest().upper()
    prep['directed_scope'].update(case='AutomaticYieldPreparationAfterActualHFailure',
        actual_import_this_pass=['CCoupledNewtonSolver', 'modTestCoupledElasticState'], fresh_compilation_claimed=True,
        source_classes_unchanged=False, retained_failed_H_trial=True, CDP_incoming_radius=(1. if expanded else .25),
        prescribed_material_point_or_level=False, event_context_restored=False, original_force_and_material_criteria=True,
        original_event_force_and_scalar_tolerances=True, controller_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, sort_keys=True, indent=2) + '\n').encode())
    print('AUTOMATIC EVENT PREPARATION READY; RADIUS', 1. if expanded else .25, '; NO PRESCRIBED POINT; ORIGINAL CRITERIA')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    parser.add_argument('--expanded', action='store_true')
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve(), args.expanded)
