"""ДЛЯ ТЕСТОВ. Проверяет равновесие, рост материальной координаты и разрешённые половинной пробой повороты ветви."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestCheck(root, output=None):
    """Напряжения берёт из нативного экспорта; независимо собирает усилия и геометрическую метрику, материал повторно не интегрирует."""
    here = Path(__file__).resolve().parent
    reader = run_path(str(here / 'Validate-TestHardPrepared.py'))
    proof, fields = reader['TestValidate'](root, 'IntegratedEvent.Sequence')
    records = reader['TestRows'](root / 'Native/IntegratedEvent.Sequence.csv')
    events = reader['TestRows'](root / 'Native/IntegratedEvent.csv')
    headers = {r[0]: r[1:] for r in records if r[0] in ('DIM', 'LAW')}
    dofs, _, points, concrete = map(int, headers['DIM'][:4])
    law = np.asarray(headers['LAW'], float)
    _, _, _, _, coords, _, b, g = run_path(str(here / 'Check-TestHardHalfSteps.py'))['TestOperators'](
        root / 'Native/IntegratedEvent.Sequence.Operators.csv', dofs, points)
    raw = np.zeros((len(fields), 3, points, 9))
    seen = np.zeros((len(fields), 3, points), int)
    for r in records:
        if r[0] == 'S':
            i, s, p = int(r[1]) - 1, int(r[2]) + 1, int(r[3]) - 1
            raw[i, s, p] = np.asarray(r[4:], float)
            seen[i, s, p] += 1
    assert np.all(seen == 1)
    density = (law[6] * raw[:, :, :concrete, 6] + law[7] * raw[:, :, :concrete, 7]) / law[8]
    energy = np.einsum('nsp,p->n', density, coords[:concrete, 2]) / (3 * sum(coords[:concrete, 2]))
    binary = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](root / 'Input/Reverse1.bin')
    count = len(binary['fields'])
    np.testing.assert_allclose(fields[:count], binary['fields'], rtol=1e-14, atol=1e-300)
    accepted = {int(r[2]): r for r in events if r[0] == 'ACCEPTED'}
    assert len(fields) == count + len(accepted)
    native = {int(r[1]): r for r in events if r[0] == 'NATIVE'}
    half = {int(r[1]): r for r in events if r[0] == 'HALF'}
    half_fields = {int(r[1]): np.asarray(r[3:], float) for r in events if r[0] == 'HALF_FIELD'}
    resolved = {int(r[1]): r for r in events if r[0] == 'ORIENTATION_RESOLVED'}
    metric = np.asarray([1., 1., 1., .5, .5, .5])

    def TestNorm(field):
        """Считает тензорную норму в трёх станциях без реакций связей."""
        tensor = np.asarray([b @ field + s * .001 * (g @ field) for s in (-1, 0, 1)])
        return float(np.sqrt(np.einsum('spc,spc,p,c->', tensor, tensor, coords[:, 2], metric) / (3 * sum(coords[:, 2]))))

    half_proofs = {}
    for index, event in accepted.items():
        attempt = int(event[1])
        row = native[attempt]
        assert row[2:4] == ['-1', '-1']
        assert abs(float(event[3]) - proof['states'][index - 1]['lambda']) < 1e-13
        assert abs(float(event[4]) - energy[index - 1]) < 1e-16
        assert energy[index - 1] > energy[index - 2]
        if row[4] != '-1':
            assert resolved[attempt][2:5] == ['-1', '-1', '-1']
            checked = half[attempt]
            assert checked[2:7] == ['-1'] * 5
            field = half_fields[attempt]
            assert field.shape == (dofs,)
            previous, full = fields[index - 2:index]
            relative_error = TestNorm(2 * field - previous - full) / TestNorm(full - previous)
            factor = float(checked[10])
            lambda_error = abs(2 * factor - proof['states'][index - 2]['lambda'] - proof['states'][index - 1]['lambda'])
            assert abs(relative_error - float(checked[12])) < 2e-8
            assert relative_error <= .005 and lambda_error <= float(checked[14]) + 1e-13
            half_proofs[index] = dict(attempt=attempt, tensor_relative_error=relative_error,
                lambda_error=lambda_error, full_and_half_native_force_verified=True)
    expected_reversals = [i for i in proof['reversed_fields'] if i > count]
    assert all(i in half_proofs for i in expected_reversals)
    owned = json.loads((root / 'Native/ExternalOwnership.json').read_bytes())
    result = json.loads((root / 'Native/ExternalResult.json').read_bytes())
    assert result['source_unchanged'] and result['owned_excel_final_state']['filetime'] == owned['filetime']
    closure_retried = False
    if result['owned_excel_final_state']['state'] != 'Exited':
        retry = json.loads((root / 'Native/ClosureRetry.json').read_bytes())
        assert retry['closed'] and retry['after']['state'] == 'Exited'
        assert retry['after']['filetime'] == owned['filetime'] and retry['books'] == [result['fixture']]
        closure_retried = True
    factors = np.asarray([s['lambda'] for s in proof['states']])
    new = factors[count - 1:]
    summary = dict(initial_states=count, states=len(fields), new_states=len(accepted),
        minimum_new_lambda=float(new.min()), last_lambda=float(new[-1]), largest_recovery=float(np.max(new - np.minimum.accumulate(new))),
        envelope_coordinate_initial=float(energy[count - 1]), envelope_coordinate_final=float(energy[-1]),
        independent_force_and_spatial_equilibrium=True, independent_material_reintegration=False,
        numerical_material_coordinate_is_not_total_dissipation=True, accepted_halfstep_reversals=half_proofs,
        inherited_reversed_fields=[i for i in proof['reversed_fields'] if i <= count],
        cleanup_retry_required=closure_retried, own_excel_final_state='Exited', physical_capacity_certified=False,
        native_equilibrium=proof)
    if output is not None:
        output.write_bytes((json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode())
    return summary


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    proof = TestCheck(a.root.resolve(), a.out.resolve())
    print(json.dumps({k: v for k, v in proof.items() if k != 'native_equilibrium'}, indent=2))
