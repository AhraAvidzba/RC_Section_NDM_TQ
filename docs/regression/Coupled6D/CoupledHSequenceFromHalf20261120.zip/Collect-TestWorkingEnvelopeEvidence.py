"""ДЛЯ ТЕСТОВ. Сохраняет проверяемые входы рабочего продолжения, штатного расчёта и точные скомпилированные проекты."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from zipfile import ZipFile, ZIP_DEFLATED

TestCases = {'Kernel': 'WorkingEnvelopeKernel02202611120',
    'Controller147': 'WorkingEnvelopeController14720261120',
    'Stock': 'WorkingEnvelopeStock20261120', 'From219': 'WorkingEnvelopeFrom21920261120'}


def TestCollect(repo, root):
    """Копирует все закреплённые входы и конечные экспорты; изменяемые временные книги в комплект не включает."""
    here = Path(__file__).resolve().parent
    root.mkdir()
    projects, pending = {}, {}
    for key, case in TestCases.items():
        source, target = root.parent / case, root / 'Cases' / key
        prep = json.loads((source / 'Preparation.json').read_bytes())
        selected = set(prep['inputs']) - {'workbook/output/RC_Section_NDM.xlsm'}
        selected.update(('Preparation.json', 'docs/regression/CodeUpdate.json', 'CompileClosure.json',
            'ParentCodeUpdate.json', 'ParentCompileClosure.json', 'CompiledSourceReuse.json', 'PointTraceSourceComposition.json'))
        for name in ('CompilePoint.log', 'CompilePointClosure.json', 'AllCoupledSources.json', 'Run.ndjson'):
            if (source / name).is_file(): selected.add(name)
        for file in (source / 'Native').iterdir():
            if file.is_file() and not file.name.startswith('EnvelopeEnergy.'):
                selected.add(file.relative_to(source).as_posix())
        for name in selected:
            raw = (source / name).read_bytes()
            if name in prep['inputs']:
                assert sha256(raw).hexdigest().upper() == prep['inputs'][name], (key, name)
            path = target / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        comp = json.loads((source / 'docs/regression/CodeUpdate.json').read_bytes())
        book = (source / 'docs/regression/Diagnostic.xlsm').read_bytes()
        assert sha256(book).hexdigest().upper() == comp['WorkbookSHA256']
        with ZipFile(BytesIO(book)) as archive: binary = archive.read('xl/vbaProject.bin')
        digest = sha256(binary).hexdigest().upper()
        projects.setdefault(digest, key)
        (target / 'CompiledVBA.bin').write_bytes(binary)
        (target / 'CompiledVBA.json').write_bytes((json.dumps(dict(bytes=len(binary), sha256=digest), indent=2) + '\n').encode())
        if key == 'Stock':
            report = (source / 'Native/Stock.txt').read_text('utf-8-sig')
            saved = Path(re.findall(r'^RESULTS_SAVE_REOPEN: .*equal=True; file=([^\r\n]+)$', report, re.M)[0])
            assert saved.resolve().is_relative_to((source / 'Temp').resolve())
            (target / 'SavedWorkbookScope.json').write_bytes((json.dumps(dict(original_scratch_root=str(source),
                exact_saved_workbook_sha256=sha256(saved.read_bytes()).hexdigest().upper(),
                markup_only=True, source_preserved=True), indent=2, sort_keys=True) + '\n').encode())
            with ZipFile(saved) as workbook, ZipFile(target / 'SavedWorkbookMarkup.zip', 'x', ZIP_DEFLATED) as markup:
                for name in workbook.namelist():
                    if name.startswith('xl/') and name.endswith('.xml') or name == 'xl/_rels/workbook.xml.rels':
                        markup.writestr(name, workbook.read(name))
        imports = prep['directed_scope']['actual_import_this_pass'] if key != 'Stock' else []
        if key == 'Stock':
            assert prep['directed_scope']['fresh_compilation_claimed'] is False
        (target / 'CaseExecution.json').write_bytes((json.dumps(dict(actual_imports=imports,
            historical_compilation_imports=comp['Modules'],
            no_new_compilation=not bool(imports)), indent=2, sort_keys=True) + '\n').encode())
        if imports:
            parent = (source / 'ParentCompiledVBA.bin').read_bytes()
        else:
            parent_root = Path(json.loads((source / 'CompiledSourceReuse.json').read_bytes())['parent'])
            with ZipFile(parent_root / 'docs/regression/Diagnostic.xlsm') as archive: parent = archive.read('xl/vbaProject.bin')
            assert parent == binary
        pending[key] = sha256(parent).hexdigest().upper(), parent
    parents, names = {}, list(TestCases)
    for key, (digest, binary) in pending.items():
        if digest not in projects:
            name = 'Ancestor' + str(len(projects))
            folder = root / 'Cases' / name
            folder.mkdir()
            (folder / 'CompiledVBA.bin').write_bytes(binary)
            (folder / 'CompiledVBA.json').write_bytes((json.dumps(dict(bytes=len(binary), sha256=digest), indent=2) + '\n').encode())
            projects[digest] = name
            names.append(name)
        parents[key] = dict(case=projects[digest], sha256=digest)
    for name, value in (('Cases.json', TestCases), ('ParentProjects.json', parents)):
        (root / name).write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())
    reference = root.parent / 'MaterialBranchHalf18420261120'
    selected = ('Input/Reverse1.bin', 'Native/IntegratedEvent.csv', 'Native/IntegratedEvent.Sequence.csv',
        'Native/IntegratedEvent.Sequence.Operators.csv', 'Native/ExternalOwnership.json', 'Native/ExternalResult.json')
    for name in selected:
        path = root / 'Reference' / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((reference / name).read_bytes())
    (root / 'BaseWorkbook.xlsm').write_bytes((repo / 'workbook/output/RC_Section_NDM.xlsm').read_bytes())
    working = run_path(str(here / 'Stage-TestWorkingEnvelope.py'))['TestWorking']
    for name in working:
        target = root / 'WorkingSources' / Path(name).name
        target.parent.mkdir(exist_ok=True)
        target.write_bytes((repo / name).read_bytes())
    (root / 'StudyReport.md').write_bytes((repo / 'docs/reports/Coupled6DWorkingEnvelope_2026-11-20.md').read_bytes())
    scripts = {Path(__file__).name, 'Check-TestWorkingEnvelopeEvidence.py', 'Check-TestWorkingEnvelope.py',
        'Check-TestMaterialBranch.py', 'Audit-TestPrivateCoupledBook.py', 'Inspect-TestResolutionVBA.py',
        'Pack-TestCompiledProjects.py', 'Compare-TestSavedCoupledTrace.py'}
    todo = list(scripts)
    while todo:
        code = (here / todo.pop()).read_text('utf-8-sig')
        for name in re.findall(r"['\"]([^/'\"\s]+\.py)['\"]", code):
            if name not in scripts and (here / name).is_file(): scripts.add(name); todo.append(name)
    for name in scripts: (root / name).write_bytes((here / name).read_bytes())
    run_path(str(here / 'Pack-TestCompiledProjects.py'))['TestPack'](root, names)
    pins = {p.relative_to(root).as_posix(): sha256(p.read_bytes()).hexdigest().upper() for p in root.rglob('*')
        if p.is_file() and p.name not in ('CompiledVBA.bin', 'Files.json')}
    (root / 'Files.json').write_bytes((json.dumps(pins, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING ENVELOPE EVIDENCE COLLECTED', len(pins), 'FILES')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=Path.cwd())
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    TestCollect(a.repo.resolve(), a.root.resolve())
