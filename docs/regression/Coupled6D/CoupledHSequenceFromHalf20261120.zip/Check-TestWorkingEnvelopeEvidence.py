"""ДЛЯ ТЕСТОВ. Воспроизводит проверку рабочего H-продолжения, штатного расчёта и неизменности остальных компонентов VBA."""
from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
import tarfile
from tempfile import TemporaryDirectory
import numpy as np


def TestProof(repo, root):
    """Проверяет фактический код из CFB и численные экспорты; наличие NumFail не превращает в подтверждение физического предела."""
    here = Path(__file__).resolve().parent
    for name, digest in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == digest, name
    class TestRepo:
        """Для исходной книги использует точную сохранённую копию, остальные инструменты читает из репозитория."""
        def __truediv__(self, name):
            return root / 'BaseWorkbook.xlsm' if str(name) == 'workbook/output/RC_Section_NDM.xlsm' else repo / name
    base = TestRepo()
    bundle = json.loads((root / 'CompiledProjects.json').read_bytes())
    binaries = {}
    with tarfile.open(root / 'CompiledProjects.tar.xz', mode='r|xz') as archive:
        for member in archive:
            assert member.isfile() and '/' not in member.name and member.size <= 64 * 1024 * 1024
            key = member.name[:-4]
            raw = archive.extractfile(member).read()
            assert sha256(raw).hexdigest().upper() == bundle['projects'][key]['sha256']
            binaries[key] = raw
    helper, _, reader = run_path(str(here / 'Inspect-TestResolutionVBA.py'))['TestHelpers'](base)
    decoded = {}
    def TestComponents(key):
        """Кэширует только точные неизменные байты скомпилированного проекта."""
        digest = sha256(binaries[key]).hexdigest().upper()
        if digest not in decoded: _, decoded[digest] = reader(helper['TestContainer'](binaries[key]))
        return decoded[digest]
    def TestIdentifierCase(code):
        """Учитывает только регистр имён VBE, сохраняя строки, комментарии, числа и операторы."""
        return re.sub(r'"(?:[^"\n]|"")*"|\'[^\n]*|[A-Za-z_][\w]*',
            lambda m: m.group() if m.group().startswith(('"', "'")) else m.group().lower(), code)
    source = (here / 'Audit-TestPrivateCoupledBook.py').read_text('utf-8-sig')
    anchor = "    assert compilation['Compiled'] and not compilation['ProductionChanged']"
    assert source.count(anchor) == 1
    source = source.replace(anchor, anchor + "\n    compilation['Modules']=json.loads((root/'Preparation.json').read_bytes())['modules']", 1)
    scope = {'__name__': 'working_envelope_audit', '__file__': str(here / 'Audit-TestPrivateCoupledBook.py')}
    exec(compile(source, scope['__file__'], 'exec'), scope)
    cases = json.loads((root / 'Cases.json').read_bytes())
    parents = json.loads((root / 'ParentProjects.json').read_bytes())
    source_proofs, audit_cache = {}, {}
    for key in cases:
        folder = root / 'Cases' / key
        prep = json.loads((folder / 'Preparation.json').read_bytes())
        for name, digest in prep['inputs'].items():
            path = base / name if name == 'workbook/output/RC_Section_NDM.xlsm' else folder / name
            assert sha256(path.read_bytes()).hexdigest().upper() == digest, (key, name)
        execution = json.loads((folder / 'CaseExecution.json').read_bytes())
        comp = json.loads((folder / 'docs/regression/CodeUpdate.json').read_bytes())
        imports = execution['actual_imports']
        assert len(imports) == {'Kernel': 6, 'Controller147': 1, 'Stock': 0, 'From219': 0}[key]
        assert execution['historical_compilation_imports'] == comp['Modules']
        signature = (sha256(binaries[key]).hexdigest().upper(), tuple(sorted((n, h) for n, h in prep['inputs'].items() if n.startswith(('src/', 'tests/')))))
        if signature not in audit_cache:
            with TemporaryDirectory() as temp, redirect_stdout(StringIO()):
                out = Path(temp) / 'Source.json'
                scope['TestAudit'](base, folder, out)
                audit_cache[signature] = json.loads(out.read_bytes())
        audit = audit_cache[signature]
        assert (audit['components'], audit['imported'], audit['unchanged']) == (254, 41, 213)
        parent = TestComponents(parents[key]['case'])
        actual = TestComponents(key)
        assert len(actual) == 254 and set(actual) == set(parent) | set(imports)
        assert sha256(binaries[parents[key]['case']]).hexdigest().upper() == parents[key]['sha256']
        assert all(TestIdentifierCase(actual[n]) == TestIdentifierCase(parent[n]) for n in actual if n not in imports)
        if not imports: assert binaries[key] == binaries[parents[key]['case']]
        source_proofs[key] = dict(actual_imports=imports, source=audit, other_components_exact_except_identifier_case=254-len(imports))
    for key in cases:
        folder = root / 'Cases' / key
        for file in (root / 'WorkingSources').iterdir():
            category = 'Materials' if file.name in ('CCoupledConcreteResponse.cls', 'CCoupledReinforcedResponse.cls') else 'Solver'
            working, prepared = file.read_text('utf-8-sig'), (folder / 'src' / category / file.name).read_text('utf-8-sig')
            if file.name in ('CCoupledConcreteResponse.cls', 'CCoupledNewtonSolver.cls'):
                assert prepared.startswith(working) and 'ДЛЯ ТЕСТОВ' in prepared[len(working):]
            else: assert working == prepared
    reference = run_path(str(here / 'Check-TestMaterialBranch.py'))['TestCheck'](root / 'Reference')
    check = run_path(str(here / 'Check-TestWorkingEnvelope.py'))['TestCheck']
    with TemporaryDirectory() as temporary:
        kernel = check(root / 'Cases/Kernel', root / 'Reference', Path(temporary) / 'Kernel.json')
        after = check(root / 'Cases/From219', None, Path(temporary) / 'After.json')
    validate = run_path(str(here / 'Validate-TestHardPrepared.py'))
    controller_root = root / 'Cases/Controller147'
    controller, fields = validate['TestValidate'](controller_root, 'IntegratedEvent.Sequence')
    original = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](controller_root / 'Input/Reverse1.bin')
    assert len(original['fields']) == 147 and len(fields) == 219
    np.testing.assert_allclose(fields[:147], original['fields'], rtol=1e-14, atol=1e-300)
    events = validate['TestRows'](controller_root / 'Native/IntegratedEvent.csv')
    rows = {r[0]: r[1:] for r in events}
    assert rows['CONTROLLER'][2:4] == ['6', '10'] and rows['PEAK'][0] == rows['STEEL'][0] == '0'
    details = ';'.join(rows['DETAILS'])
    assert 'проб материальной координаты: 3; восстановлений по ней: 2' in details
    native = json.loads((controller_root / 'Native/ExternalResult.json').read_bytes())
    owner = json.loads((controller_root / 'Native/ExternalOwnership.json').read_bytes())
    assert native['source_unchanged'] and native['owned_excel_final_state']['state'] == 'Exited'
    assert native['owned_excel_final_state']['filetime'] == owner['filetime']
    stock_root = root / 'Cases/Stock'
    stock = (stock_root / 'Native/Stock.txt').read_text('utf-8-sig')
    regressions = (stock_root / 'Native/PeakRegression.txt').read_text('utf-8-sig')
    totals = re.findall(r'^TOTAL_[^:]+: passed=(\d+); failed=(\d+)$', regressions, re.M)
    assert len(totals) == 7 and sum(int(p) for p, _ in totals) == 168 and all(int(f) == 0 for _, f in totals)
    assert 'TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0' in stock
    state, = re.findall(r'^TIMING_STATES: direct=(\w+); capacity=(\w+); confirmed lower=([^;]+); limit=([^;]*); code=(\w+)$', stock, re.M)
    assert state[0:2] == ('OK', 'NumFail') and state[3:] == ('', 'NUMERICAL_FAILURE')
    assert 'Исчерпан общий лимит проб' in stock
    for phase in ('PeakRegression', 'Stock'):
        closure = json.loads((stock_root / ('Native/' + phase + '.txt.ProcessClosure.json')).read_bytes())
        assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
    saved = run_path(str(here / 'Compare-TestSavedCoupledTrace.py'))['TestSavedTrace'](stock_root)
    factors = [float(v['value']) for k, v in saved.items() if '.Capacity.' in k and k.endswith('.Lambda')]
    assert len(factors) == 36 and abs(max(factors) - float(state[2])) < 1e-13
    elapsed = float(re.findall(r'^TIMING_SECONDS: ([^ |]+)', stock, re.M)[0])
    return dict(source=source_proofs, working_source_binding=True, reference_half=reference,
        working_kernel=kernel, working_controller=dict(native_equilibrium=controller, initial_states=147,
            new_states=72, envelope_recoveries=2, probes=96, certified_peak=False, certified_steel_limit=False,
            controller_seconds=float(rows['CONTROLLER'][0]), own_excel_closed=True), after_controller=after,
        stock=dict(direct=state[0], capacity=state[1], lower_lambda=float(state[2]), capacity_trace_states=len(factors),
            seconds=elapsed, results_saved_reopened_equal=True, regressions_passed=168, stock_assertions_passed=28,
            code=state[4], probe_budget_exhausted=True),
        installed_workbook_changed=False, physical_capacity_certified=False, full_acceptance_completed=False,
        independent_material_reintegration=False, target_10_seconds_met=False,
        numerical_material_coordinate_is_not_total_dissipation_or_failure_criterion=True)


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=Path.cwd())
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    result = TestProof(a.repo.resolve(), a.root.resolve())
    a.out.write_bytes((json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING ENVELOPE EVIDENCE PASS; STOCK NUMFAIL RETAINED; PHYSICAL CAPACITY OPEN')
