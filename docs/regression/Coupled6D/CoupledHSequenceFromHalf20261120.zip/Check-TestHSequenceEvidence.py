"""ДЛЯ ТЕСТОВ. Проверяет цепочку H-продолжения и отсутствие приписанного эффекта неиспользованной стратегии события."""
from argparse import ArgumentParser
import json
from pathlib import Path
import re
from runpy import run_path
import numpy as np


def TestProof(repo, root):
    """Проверяет исходный рабочий H-метод, принятые состояния и границы подтверждения; предел не объявляет."""
    here = Path(__file__).resolve().parent
    expected = {'SingleH': ['CCoupledNewtonSolver', 'modTestCoupledElasticState'],
                'Growth201': ['modTestCoupledElasticState'], 'Working209': ['modTestCoupledElasticState']}
    sources = run_path(str(here / 'Check-TestStudySourceSet.py'))['TestSources'](repo, root, expected)
    working = (root / 'WorkingSources/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    code = (root / 'Cases/SingleH/src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    assert code == (root / 'Cases/Growth201/src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    marker = "' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Читает результат автоматического выбора"
    assert code.count(marker) == 1
    code = code[:code.index(marker)]
    capture = '''    If Not solved And solver.HasBestPoint Then
        Dim rejected() As Double, rejectedLambda As Double
        ReadEquationField solution, rejected, rejectedLambda
        mTransitionFrom = mAccepted: mTransitionTo = rejected
        mTransitionRevision = mAcceptedRevision: mHasTransitionSegment = True ' Непринятое поле разрешает только поиск события; равновесием и разрушением не считается.
    End If
'''
    assert code.count(capture) == 1
    code = code.replace(capture, '', 1)
    line = '        modTestCoupledElasticState.TestRecordActualEventHalf face, outgoing, halfField, faceLambda, trialLambda, halfLambda, stepLength, SpatialFieldDistance(doubled, outgoing)\n'
    assert code.count(line) == 1
    code = code.replace(line, '', 1)
    line = '    If station.PrincipalIndex = 0 Then radius = YIELD_EVENT_RADIUS * reference\n'
    assert code.count(line) == 1
    code = code.replace(line, '', 1)
    for method in ('SelectYieldEventStation', 'YieldEventPrediction'):
        begin = code.index('Private Function ' + method + '(')
        end = code.index('\nEnd Function', begin)
        body = code[begin:end]
        assert body.count('YIELD_EVENT_RADIUS') == 1
        code = code[:begin] + body.replace('YIELD_EVENT_RADIUS', 'PRINCIPAL_EVENT_RADIUS', 1) + code[end:]
    assert code.startswith(working) and 'ДЛЯ ТЕСТОВ' in code[len(working):]
    body = (root / 'Cases/Working209/TestAutomaticYieldPreparation.bas.txt').read_text('utf-8-sig')
    begin, end = body.index('    Print #report, "SELECTION"'), body.index('\nFinished:')
    body = body[:begin] + '    GoTo Finished\n' + body[end:]
    body = body.replace('hAccepted >= 8', 'hAccepted >= 16', 1).replace('EightAcceptedStates', 'AcceptedStateLimit16', 1)
    body = body.replace('hAttempt = 1 To 32', 'hAttempt = 1 To 64', 1)
    body = body.replace('AutomaticYieldPreparationAfterActualHFailure', 'WorkingHContinuationFromExactSnapshot', 1)
    body = body.replace('Вызывает выбор и обе стороны материального события после действительной неудачной H-пробы; номер точки не задаёт.',
                        'Продолжает исходную рабочую H-координату с силовым повтором и точными снимками; выбора события не вызывает.', 1)
    module = (root / 'Cases/Working209/tests/modTestCoupledElasticState.bas').read_text('utf-8-sig')
    actual_body = re.search(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub', module).group()
    assert actual_body.strip() == body[body.index('Private Sub TestIntegratedYieldEvent()'):].strip()
    check = run_path(str(here / 'Check-TestGrowingAutomaticYield.py'))['TestCheck']
    growth = check(root / 'Cases/Growth201')
    continuation = check(root / 'Cases/Working209')
    assert len(growth['H_accepted']) == 8 and not growth['automatic_event_selection_attempted']
    assert continuation['H_accepted'] and not continuation['automatic_event_selection_attempted']
    raw = (root / 'Cases/Growth201/Native/IntegratedEvent.Accepted209.bin').read_bytes()
    assert raw == (root / 'Cases/Working209/Input/Reverse1.bin').read_bytes()
    single = root / 'Cases/SingleH'
    read = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original = read(single / 'Input/Reverse1.bin')
    mechanics, fields = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate'](single, 'IntegratedEvent.Sequence')
    assert len(fields) == len(original['fields']) == 201
    np.testing.assert_allclose(fields, original['fields'], rtol=1e-14, atol=1e-300)
    result = json.loads((single / 'Native/ExternalResult.json').read_bytes())
    owner = json.loads((single / 'Native/ExternalOwnership.json').read_bytes())
    assert result['source_unchanged'] and result['owned_excel_final_state']['state'] == 'Exited'
    assert result['owned_excel_final_state']['filetime'] == owner['filetime']
    rows = run_path(str(here / 'Check-TestHardHalfSteps.py'))['TestRows'](single / 'Native/IntegratedEvent.csv')
    probe = next(list(map(float, row[1:])) for row in rows if row[0] == 'H_PROBE')
    assert probe[0] == -1. and abs(probe[1] - growth['H_accepted'][0][2]) <= 1e-13
    assert not any(row[0] == 'SELECTION' for row in rows)
    assert (single / 'Input/Reverse1.bin').read_bytes() == (root / 'Cases/Growth201/Input/Reverse1.bin').read_bytes()
    return dict(source=sources, initial_successful_H_probe=dict(lambda_value=probe[1], candidate_committed=False,
                input_history_equilibrium=mechanics, own_excel_closed=True),
                H_growth_from201=growth, original_working_H_from209=continuation,
                native_Double_history_chain_exact=True, experimental_event_strategy_exercised=False,
                experimental_event_strategy_promoted=False, original_working_core_continuation_verified=True,
                working_sources_unchanged_from_checkpoint637=True, installed_workbook_changed=False,
                physical_capacity_certified=False, full_acceptance_completed=False,
                independent_material_reintegration=False)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    proof = TestProof(args.repo.resolve(), args.root.resolve())
    args.out.write_bytes((json.dumps(proof, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode())
    print('H SEQUENCE VERIFIED; EXACT209 HANDOFF; ORIGINAL WORKING CORE; PHYSICAL CAPACITY OPEN')
