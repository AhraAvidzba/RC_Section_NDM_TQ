"""ДЛЯ ТЕСТОВ. Сравнивает два шага на одинаковой монотонной координате огибающих, не назначая критерий прочности."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestRead(root):
    """Восстанавливает координату из нативных долей энергий; не использует итоговый ответ решателя для её определения."""
    here = Path(__file__).resolve().parent
    rows = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestRows'](root / 'Native/IntegratedEvent.Sequence.csv')
    headers = {r[0]: r[1:] for r in rows if r[0] in ('DIM', 'LAW')}
    dofs, _, points, concrete = map(int, headers['DIM'][:4])
    law = np.asarray(headers['LAW'], float)
    frames = [r for r in rows if r[0] == 'F']
    fields = np.asarray([r[4:] for r in frames], float)
    factors = np.asarray([r[3] for r in frames], float)
    energies = np.zeros((len(fields), 3, concrete, 2))
    for r in rows:
        if r[0] == 'S' and int(r[3]) <= concrete:
            energies[int(r[1]) - 1, int(r[2]) + 1, int(r[3]) - 1] = np.asarray(r[10:12], float)
    _, _, _, _, coords, _, b, g = run_path(str(here / 'Check-TestHardHalfSteps.py'))['TestOperators'](
        root / 'Native/IntegratedEvent.Sequence.Operators.csv', dofs, points)
    density = (law[6] * energies[..., 0] + law[7] * energies[..., 1]) / law[8]
    coordinate = np.einsum('nsp,p->n', density, coords[:concrete, 2]) / (3 * sum(coords[:concrete, 2]))
    start = len(run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](root / 'Input/Reverse1.bin')['fields']) - 1
    return coordinate[start:], fields[start:], factors[start:], coords, b, g


def TestCompare(first, second, output=None):
    """Интерполирует только для оценки шага; интерполированное поле не считается дополнительным решением равновесия."""
    a, b = TestRead(first), TestRead(second)
    assert np.array_equal(a[1][0], b[1][0]) and np.array_equal(a[3], b[3])
    assert abs(a[0][0] - b[0][0]) < 1e-18
    assert np.all(np.diff(a[0]) > 0) and np.all(np.diff(b[0]) > 0)
    end = min(a[0][-1], b[0][-1])

    def TestAt(data, target):
        """Сохраняет положение целевой координаты между двумя реальными принятыми состояниями."""
        values, fields, factors, _, _, _ = data
        right = min(len(values) - 1, max(1, int(np.searchsorted(values, target))))
        fraction = (target - values[right - 1]) / (values[right] - values[right - 1])
        return (1 - fraction) * fields[right - 1] + fraction * fields[right], float((1 - fraction) * factors[right - 1] + fraction * factors[right])

    def TestNorm(field):
        """Использует ту же физическую тензорную метрику, независимо вычисленную по сохранённой геометрии."""
        _, _, _, coords, operator, gradient = a
        tensor = np.asarray([operator @ field + s * .001 * (gradient @ field) for s in (-1, 0, 1)])
        return float(np.sqrt(np.einsum('spc,spc,p,c->', tensor, tensor, coords[:, 2], [1, 1, 1, .5, .5, .5]) / (3 * sum(coords[:, 2]))))

    levels = []
    for fraction in (.25, .5, .75, 1.):
        target = a[0][0] + fraction * (end - a[0][0])
        field_a, factor_a = TestAt(a, target)
        field_b, factor_b = TestAt(b, target)
        levels.append(dict(envelope_coordinate=float(target), first_lambda=factor_a, second_lambda=factor_b,
            tensor_relative_difference=TestNorm(field_a - field_b) / TestNorm(field_a),
            lambda_relative_difference=abs(factor_a - factor_b) / abs(factor_a)))
    proof = dict(first=first.name, second=second.name, exact_same_initial_field=True, levels=levels,
        interpolation_is_not_additional_equilibrium=True, complete_branch_and_peak_sensitivity_not_proven=True,
        physical_capacity_certified=False)
    if output is not None:
        output.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode())
    return proof


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--first', type=Path, required=True)
    p.add_argument('--second', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    print(json.dumps(TestCompare(a.first.resolve(), a.second.resolve(), a.out.resolve()), indent=2))
