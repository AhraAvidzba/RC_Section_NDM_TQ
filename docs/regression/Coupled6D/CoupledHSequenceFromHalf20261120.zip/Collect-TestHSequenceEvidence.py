"""ДЛЯ ТЕСТОВ. Сохраняет продолжение принятой H-ветви и точную передачу 209 состояний исходному рабочему ядру."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path

TestCases = {'SingleH': 'AutomaticYieldFull20120261120',
             'Growth201': 'AutomaticYieldGrowthFull20120261120',
             'Working209': 'WorkingHExact20920261120'}


def TestCollect(repo, root):
    """Закрепляет начальные данные, все принятые Double, конечные напряжения и фактические CFB; исходники не меняет."""
    here = Path(__file__).resolve().parent
    collect = run_path(str(here / 'Collect-TestWorkingEnvelopeEvidence.py'))['TestCollect']
    collect.__globals__['TestCases'] = TestCases
    collect.__globals__['__file__'] = str(Path(__file__).resolve())
    collect(repo, root)
    for key, name in TestCases.items():
        source, target = root.parent / name, root / 'Cases' / key
        for name in ('Native/EnvelopeEnergy.Accepted.csv', 'Native/EnvelopeEnergy.Accepted.Operators.csv',
                     'Native/EnvelopeEnergy.Operators.csv', 'CompileClosureRecovery.json', 'GrowingHProof.json'):
            if (source / name).is_file():
                path = target / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes((source / name).read_bytes())
        if key != 'Working209':
            path = root / 'ExperimentalSources' / key / 'CCoupledNewtonSolver.cls'
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes((source / 'src/Solver/CCoupledNewtonSolver.cls').read_bytes())
    for relative in ('src/Solver/CCoupledHybridSolver.cls', 'src/Materials/CCoupledConcreteReturn.cls'):
        (root / 'WorkingSources' / Path(relative).name).write_bytes((repo / relative).read_bytes())
    (root / 'Cases/Working209/TestAutomaticYieldPreparation.bas.txt').write_bytes((here / 'TestAutomaticYieldPreparation.bas.txt').read_bytes())
    (root / 'StudyReport.md').write_bytes((repo / 'docs/reports/Coupled6DHSequenceFromHalf_2026-11-20.md').read_bytes())
    scripts = {Path(__file__).name, 'Check-TestHSequenceEvidence.py', 'Check-TestGrowingAutomaticYield.py',
               'Check-TestStudySourceSet.py', 'Collect-TestWorkingEnvelopeEvidence.py', 'Record-TestHSequenceEvidence.py'}
    todo = list(scripts)
    while todo:
        code = (here / todo.pop()).read_text('utf-8-sig')
        for name in re.findall(r"['\"]([^/'\"\s]+\.py)['\"]", code):
            if name not in scripts and (here / name).is_file():
                scripts.add(name)
                todo.append(name)
    for name in scripts:
        (root / name).write_bytes((here / name).read_bytes())
    pins = {path.relative_to(root).as_posix(): sha256(path.read_bytes()).hexdigest().upper()
            for path in root.rglob('*') if path.is_file() and path.name not in ('CompiledVBA.bin', 'Files.json')
            and 'Reference' not in path.relative_to(root).parts}
    (root / 'Files.json').write_bytes((json.dumps(pins, sort_keys=True, indent=2) + '\n').encode())
    print('H SEQUENCE EVIDENCE COLLECTED', len(pins), 'FILES; EXACT HISTORY CHAIN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
