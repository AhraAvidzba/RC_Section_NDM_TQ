"""ДЛЯ ТЕСТОВ. Фиксирует этап 639 только после точного повторения доказательств из чисто распакованного архива."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile,ZIP_LZMA


def TestRecord(repo,root):
    """Сохраняет отрицательные численные результаты и три проверенных промежуточных равновесия, не объявляя найденным предел."""
    proof=(root/'EnvelopeFailureEvidenceProof.json').read_bytes();parsed=json.loads(proof)
    assert parsed['working_sources_unchanged_from_checkpoint637'] and not parsed['physical_capacity_certified']
    assert not any(v['native_force_verified'] for v in parsed['external'].values())
    for file in (root/'WorkingSources').iterdir():
        category='Materials' if file.name in ('CCoupledConcreteResponse.cls','CCoupledConcreteReturn.cls','CCoupledReinforcedResponse.cls') else 'Solver'
        assert file.read_bytes()==(repo/'src'/category/file.name).read_bytes()
    assert sha256((repo/'workbook/output/RC_Section_NDM.xlsm').read_bytes()).hexdigest().upper()=='E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
    assert sha256((repo/'workbook/output/VBA_All_Code.txt').read_bytes()).hexdigest().upper()=='DB8023F9384B0059E1D1C51D59FE0E62F9B8CD94AC4D9B329DD0EE810AF676CC'
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes())
    pins=json.loads((root/'Files.json').read_bytes());pins[name]=sha256((root/name).read_bytes()).hexdigest().upper()
    (root/'Files.json').write_bytes((json.dumps(pins,sort_keys=True,indent=2)+'\n').encode())
    archive=root.parent/'CoupledEnvelopeFailureDiagnosis20261120.zip'
    with ZipFile(archive,'x',ZIP_LZMA) as output:
        for name in sorted(set(pins)|{'Files.json','EnvelopeFailureEvidenceProof.json'}):output.write(root/name,name)
    assert archive.stat().st_size<100*1024*1024
    clean=root.parent/'EnvelopeFailureCleanReplay20261120';clean.mkdir()
    with ZipFile(archive) as source:
        for member in source.infolist():
            assert (clean/member.filename).resolve().is_relative_to(clean.resolve())
            source.extract(member,clean)
    repeated=run_path(str(clean/'Check-TestEnvelopeFailureEvidence.py'))['TestProof'](repo,clean)
    raw=(json.dumps(repeated,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode()
    (clean/'EnvelopeFailureEvidenceProof.Repeated.json').write_bytes(raw);assert raw==proof
    destination=repo/'docs/regression/Coupled6D'/archive.name
    with destination.open('xb') as out:out.write(archive.read_bytes())
    digest=sha256(destination.read_bytes()).hexdigest().upper();proof_digest=sha256(proof).hexdigest().upper()
    path=repo/'docs/reports/Coupled6DEvidence.json';text=path.read_text('utf-8-sig');old=json.loads(text)
    assert len(old['archives'])==332 and len(old['cases'])==392
    previous='CoupledEnvelopeStepSensitivity20261120'
    anchor='    "'+previous+'": "'+old['archives'][previous]+'"';assert text.count(anchor)==1
    text=text.replace(anchor,anchor+',\n    "'+archive.stem+'": "'+digest+'"',1)
    case=dict(id='coupled-envelope-failure-diagnosis',journal_section=639,archive=archive.stem,
        script='Check-TestEnvelopeFailureEvidence.py',arguments=['--repo','{repo}','--root','.','--out','EnvelopeFailureEvidenceProof.json'],
        stdout_contains='ENVELOPE FAILURE EVIDENCE VERIFIED; THREE INTERMEDIATE EQUILIBRIA; PHYSICAL CAPACITY OPEN',
        outputs={'EnvelopeFailureEvidenceProof.json':proof_digest},timeout_seconds=600)
    begin=text.index('  "cases": [\n');end=text.index('\n  ],',begin)
    text=text[:end]+',\n'+'\n'.join('    '+line for line in json.dumps(case,ensure_ascii=False,indent=2).splitlines())+text[end:]
    updated=json.loads(text);assert updated['cases'][:-1]==old['cases']
    assert {k:v for k,v in updated['archives'].items() if k!=archive.stem}==old['archives']
    assert all(updated[k]==v for k,v in old.items() if k not in ('archives','cases'))
    path.write_bytes(text.replace('\n','\r\n').encode())
    note=f'''
### 639. Реальная остановка H: промежуточные равновесия и отрицательный контроль TRF

На общей истории 219 изменение центрального шага, Dogleg и ужесточение
локальных численных допусков в сто раз не устранили остановку искусственно
строгой H-пробы. Исходные 219 полей и напряжений сохранены точно.
Продолжение контроллера по H после позднего переключения прервано watchdog
600 с; последний законченный снимок содержит 206 состояний. Эта политика
отклонена, рабочий контроллер сохранён на уровне этапа 637.

Из реальной неудачной пробы выделены 200 принятых полей и H-цель. При
исходном допуске изменение разностного шага и Dogleg не дали равновесия.
Промежуточные цели от одной неизменной материальной истории дали три
равновесия до lambda 1,112329429970, подтверждённые штатной силовой пробой,
H и независимой сборкой шести усилий и пространственных уравнений.
Цели 3/4 и полного приращения не решены. Прямая и обратная разности также
не дали пригодного поля.

TRF из SciPy решал те же рабочие уравнения с материальным откликом VBA:
25 оценок — невязка 0,000664661 МПа; повтор из точного двоичного поля,
100 оценок — 0,000622172 МПа. Исходная силовая приёмка не пройдена.
Внешняя физическая модель этим контролем не заменялась. Численная остановка
не подтверждает разрушение; основания переносить эти варианты в рабочий
код или увеличивать штатные бюджеты не получено.

Комплект [CoupledEnvelopeFailureDiagnosis20261120](../regression/Coupled6D/CoupledEnvelopeFailureDiagnosis20261120.zip),
{destination.stat().st_size} байт, SHA-256 `{digest}`.
EnvelopeFailureEvidenceProof.json: `{proof_digest}`. Чистое воспроизведение
точное. Всего 333 архива и 393 случая; прежние записи сохранены.
Фактические частные компиляции: 254 компонента, 41 подготовленный исходник
и 213 компонентов базы; реальные импорты каждого запуска проверены отдельно.
Первоначальная ошибка компиляции тестового помощника сохранена, дубликат
исправлен и повторная частная компиляция выполнена. Собственные Excel закрыты.

Рабочие исходники, основная книга, VBA_All_Code.txt и main не менялись.
Независимое повторное интегрирование материала не выполнялось. Предел,
цель 10 с и полная приёмка остаются открытыми; полные наборы не запускались.
[Методика проверок и ограничения](Coupled6DEnvelopeFailureDiagnosis_2026-11-20.md).
'''
    for name in ('Coupled6DProgress.md','Coupled6DAcceptance.md'):
        path=repo/'docs/reports'/name;original=path.read_bytes();assert b'### 639.' not in original
        path.write_bytes(original+note.replace('\n','\r\n').encode())
    path=repo/'docs/reports/Coupled6DEnvelopeFailureDiagnosis_2026-11-20.md'
    path.write_bytes(path.read_bytes()+('\n## Контрольная точка\n\n'+note.strip()+'\n').encode())
    record=dict(bytes=destination.stat().st_size,sha256=digest,proof_sha256=proof_digest,
        archives=333,cases=393,clean_replay_exact=True,working_sources_unchanged_from637=True,
        physical_capacity_certified=False,target_10_seconds_met=False)
    (root.parent/'EnvelopeFailureRecord.json').write_bytes((json.dumps(record,sort_keys=True,indent=2)+'\n').encode())
    print('ENVELOPE FAILURE CHECKPOINT 639 RECORDED; CLEAN REPLAY EXACT; PHYSICAL CAPACITY OPEN')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,required=True)
    a=p.parse_args();TestRecord(a.repo.resolve(),a.root.resolve())
