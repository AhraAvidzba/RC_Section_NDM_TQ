"""ДЛЯ ТЕСТОВ. Записывает этап 642 после точного чистого воспроизведения принятой H-последовательности."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestRecord(repo, root):
    """Добавляет проверенный архив и запись журнала; прежние записи реестра не меняет."""
    source = Path(__file__).resolve().parent / 'Record-TestEnvelopeFailureEvidence.py'
    code = source.read_text('utf-8-sig')
    edits = [('EnvelopeFailureEvidenceProof.Repeated.json', 'HSequenceEvidenceProof.Repeated.json'),
             ('EnvelopeFailureEvidenceProof.json', 'HSequenceEvidenceProof.json'),
             ('CoupledEnvelopeFailureDiagnosis20261120.zip', 'CoupledHSequenceFromHalf20261120.zip'),
             ('EnvelopeFailureCleanReplay20261120', 'HSequenceCleanReplay20261120'),
             ('Check-TestEnvelopeFailureEvidence.py', 'Check-TestHSequenceEvidence.py'),
             ("==332 and len(old['cases'])==392", "==335 and len(old['cases'])==395"),
             ("previous='CoupledEnvelopeStepSensitivity20261120'", "previous='CoupledStrictEventCompletion20261120'"),
             ("id='coupled-envelope-failure-diagnosis',journal_section=639", "id='coupled-h-sequence-from-half',journal_section=642"),
             ('ENVELOPE FAILURE EVIDENCE VERIFIED; THREE INTERMEDIATE EQUILIBRIA; PHYSICAL CAPACITY OPEN',
              'H SEQUENCE VERIFIED; EXACT209 HANDOFF; ORIGINAL WORKING CORE; PHYSICAL CAPACITY OPEN'),
             ("b'### 639.'", "b'### 642.'"),
             ('Coupled6DEnvelopeFailureDiagnosis_2026-11-20.md', 'Coupled6DHSequenceFromHalf_2026-11-20.md'),
             ('archives=333,cases=393', 'archives=336,cases=396'),
             ('EnvelopeFailureRecord.json', 'HSequenceRecord.json'),
             ('ENVELOPE FAILURE CHECKPOINT 639 RECORDED; CLEAN REPLAY EXACT; PHYSICAL CAPACITY OPEN',
              'H SEQUENCE CHECKPOINT 642 RECORDED; CLEAN REPLAY EXACT; PHYSICAL CAPACITY OPEN')]
    for before, after in edits:
        assert before in code, before
        code = code.replace(before, after)
    before = "    assert not any(v['native_force_verified'] for v in parsed['external'].values())"
    assert before in code
    code = code.replace(before, "    assert parsed['original_working_core_continuation_verified'] and parsed['native_Double_history_chain_exact']", 1)
    note = '''    note=f\x27\x27\x27
### 642. Принятое H-продолжение: 24 новых равновесия и точная передача исходному ядру

После промежуточного принятого состояния 201 следующий H-шаг сошёлся.
Восьми последовательным принятым состояниям соответствуют lambda до
1,11643050753238. Точный двоичный снимок 209 состояний передан исходным
рабочим классам этапа 637, которые нашли ещё шестнадцать равновесий,
до lambda = 1,11969335861893. Увеличение от исходных 1,11232942997007 —
около 0,662%. Это доступная ветвь, а не физический предел.

Крупные неудачные H-шаги делились; все новые поля прошли отдельный обычный
силовой вызов без изменения координат и положительную пространственную
ориентацию. Шесть усилий и пространственные строки 225 состояний
независимо пересобраны. Все 24 новых состояния сохранены точными Double.
Вход второго продолжения побайтно равен принятому снимку первого.

Автоматический выбор события не вызван: H продолжался после дробления.
Эффект экспериментального радиуса не подтверждён, изменения не перенесены
в рабочие исходники. Второй участок использует исходное рабочее ядро.
Оба опыта остановлены по заданному количеству состояний, без разрушения.
Продолжение заняло 319,043 и 229,410 с без холодного повтора и полного
экспорта; вся частная сессия — 393,681 и 310,492 с. Цель 10 с не выполнена.

Комплект [CoupledHSequenceFromHalf20261120](../regression/Coupled6D/CoupledHSequenceFromHalf20261120.zip),
{destination.stat().st_size} байт, SHA-256 `{digest}`.
HSequenceEvidenceProof.json: `{proof_digest}`. Чистое воспроизведение
точное. Всего 336 архивов и 396 случаев; прежние записи сохранены.
Рабочие исходники остаются на этапе 637; основная книга, VBA_All_Code.txt
и main не менялись. Предел, штатный путь от нуля, все LoadPath и полная
приёмка открыты. Полные наборы и независимое интегрирование материала
не выполнялись.
[Постановка, проверки и ограничения](Coupled6DHSequenceFromHalf_2026-11-20.md).
\x27\x27\x27'''
    begin = code.index("    note=f'''")
    end = code.index("'''", begin + len("    note=f'''")) + 3
    code = code[:begin] + note + code[end:]
    name = source.name
    (root / name).write_bytes(source.read_bytes())
    pins = json.loads((root / 'Files.json').read_bytes())
    pins[name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / 'Files.json').write_bytes((json.dumps(pins, sort_keys=True, indent=2) + '\n').encode())
    namespace = {'__file__': str(Path(__file__).resolve()), '__name__': 'H_sequence_record_test'}
    exec(compile(code, str(source), 'exec'), namespace)
    namespace['TestRecord'](repo, root)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestRecord(args.repo.resolve(), args.root.resolve())
