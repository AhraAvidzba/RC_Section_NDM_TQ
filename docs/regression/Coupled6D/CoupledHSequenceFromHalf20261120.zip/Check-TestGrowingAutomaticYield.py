"""ДЛЯ ТЕСТОВ. Независимо проверяет принятую H-ветвь и фактически вызванное автоматическое событие."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestCheck(root, output=None):
    """Не приравнивает исчерпание локального бюджета, численную остановку или отдельное событие к пределу сечения."""
    here = Path(__file__).resolve().parent
    helpers = run_path(str(here / 'Check-TestHardHalfSteps.py'))
    rows = helpers['TestRows'](root / 'Native/IntegratedEvent.csv')
    data = {row[0]: row[1:] for row in rows if row[0] in
            ('MODE', 'START', 'H_STOP', 'H_BLOCKED', 'SELECTION', 'PREPARE', 'EVENT', 'COMPLETE',
             'COMPLETE_EFFORT', 'DEPARTURE', 'SPATIAL_HANDOFF', 'END')}
    assert 'NoPrescribedPoint' in data['MODE']
    external = json.loads((root / 'Native/ExternalResult.json').read_bytes())
    owner = json.loads((root / 'Native/ExternalOwnership.json').read_bytes())
    assert external['outcome'] == 'WorkingMaterialEventDiagnostic;NotCapacity'
    assert external['source_unchanged'] and external['owned_excel_final_state']['state'] == 'Exited'
    assert external['owned_excel_final_state']['filetime'] == owner['filetime']
    read = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original = read(root / 'Input/Reverse1.bin')
    original_count = len(original['fields'])
    assert original_count == int(data['START'][0])
    mechanics, fields = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate'](root, 'IntegratedEvent.Sequence')
    assert len(fields) == int(data['END'][0])
    np.testing.assert_allclose(fields[:original_count], original['fields'], rtol=1e-14, atol=1e-300)
    np.testing.assert_allclose([state['lambda'] for state in mechanics['states'][:original_count]], original['lambdas'], rtol=1e-14)
    probes = [list(map(float, row[1:])) for row in rows if row[0] == 'H_PROBE']
    accepted = [list(map(float, row[1:])) for row in rows if row[0] == 'H_ACCEPT']
    native = {int(row[1]): list(map(float, row[2:])) for row in rows if row[0] == 'H_NATIVE'}
    assert [int(row[0]) for row in probes] == list(range(1, len(probes) + 1))
    scope = json.loads((root / 'Preparation.json').read_bytes())['directed_scope']
    maximum = scope['maximum_new_H_states']
    assert maximum in (8, 16, 24)
    assert len(probes) <= 4 * maximum and len(accepted) <= maximum
    binaries = []
    for index, row in enumerate(accepted, original_count + 1):
        attempt, count, factor, energy = row
        assert count == index and probes[int(attempt) - 1][1] == -1.
        checked = native[int(attempt)]
        assert checked[0] == checked[1] == -1. and (checked[2] == -1. or checked[3] == -1.)
        assert checked[-1] <= 1.
        assert abs(mechanics['states'][index - 1]['lambda'] - factor) <= 1e-13
        file = root / 'Native' / ('IntegratedEvent.Accepted' + str(index) + '.bin')
        snapshot = read(file)
        assert len(snapshot['fields']) == index
        assert np.array_equal(snapshot['fields'][:original_count], original['fields'])
        assert np.array_equal(snapshot['lambdas'][:original_count], original['lambdas'])
        np.testing.assert_allclose(snapshot['fields'], fields[:index], rtol=1e-14, atol=1e-300)
        binaries.append(dict(states=index, sha256=sha256(file.read_bytes()).hexdigest().upper(), lambda_exact=float(snapshot['lambdas'][-1])))
    proof = dict(equilibrium=mechanics, original_history_states=original_count, H_probes=probes, H_accepted=accepted,
                 exact_accepted_H_snapshots=binaries, source_unchanged=True, own_excel_closed=True,
                 original_force_revalidation_unchanged=True, H_blocked='H_BLOCKED' in data,
                 automatic_event_selection_attempted='SELECTION' in data, preparation_success=False,
                 completion_success=False, ordinary_spatial_handoff_success=False,
                 physical_capacity_certified=False, full_controller_search_verified=False,
                 independent_material_reintegration=False, solver_and_export_seconds=float(data['END'][2]))
    if 'SELECTION' in data:
        assert 'H_BLOCKED' in data and probes and probes[-1][1] == 0.
        selected = list(map(float, data['SELECTION']))
        prepared = list(map(float, data['PREPARE']))
        assert prepared[-1] == probes[-1][5]
        proof.update(selection=selected, preparation_success=prepared[0] == -1.)
        if proof['preparation_success']:
            event = list(map(float, data['EVENT']))
            assert selected[0] == selected[1] == selected[-1] == -1.
            assert event[:3] == selected[2:5]
            proof['event'] = event
            complete = list(map(float, data['COMPLETE']))
            assert complete[3] == complete[4]
            proof['completion_success'] = complete[0] == -1.
            if proof['completion_success']:
                assert data['DEPARTURE'][0] == '-1'
                proof['ordinary_spatial_handoff_success'] = data['SPATIAL_HANDOFF'][0] == '-1'
                half_rows = helpers['TestRows'](root / 'Native/ActualEventHalf.csv')
                half_data = {row[0]: np.asarray(row[1:], float) for row in half_rows}
                face, full, half = (half_data[name] for name in ('FACE', 'FULL', 'HALF'))
                _, _, _, _, coordinates, _, b, slope = helpers['TestOperators'](
                    root / 'Native/IntegratedEvent.Sequence.Operators.csv', 60, 43)
                weights = coordinates[:, 2]
                tensor = np.asarray((1., 1., 1., .5, .5, .5))

                def TestLength(field):
                    """Пересобирает тензорную метрику трёх станций из геометрии; множители связей в неё не входят."""
                    strain = np.asarray([np.einsum('pcd,d->pc', b + side * .001 * slope, field) for side in (-1, 0, 1)])
                    return float(np.sqrt(np.einsum('spc,spc,p,c->', strain, strain, weights, tensor) / (3 * sum(weights))))

                length = TestLength(full - face)
                error = TestLength(2. * half - face - full)
                levels = half_data['LEVELS']
                load_error = abs(2. * (levels[2] - levels[0]) - (levels[1] - levels[0]))
                assert length > 0 and error <= .005 * length
                assert load_error <= .005 * abs(levels[1] - levels[0])
                assert abs(length - levels[3]) <= 5e-18 and abs(error - levels[4]) <= 5e-18
                proof.update(half_field_relative_error=error / length,
                             half_lambda_relative_error=load_error / abs(levels[1] - levels[0]),
                             half_force_check_by_working_method_only=True)
    if output is not None:
        output.write_bytes((json.dumps(proof, sort_keys=True, indent=2) + '\n').encode())
    return proof


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    proof = TestCheck(args.root.resolve(), args.out.resolve())
    print('GROWING H VERIFIED;', len(proof['H_accepted']), 'NEW H STATES; AUTOMATIC EVENT',
          proof['preparation_success'], proof['completion_success'], '; PHYSICAL LIMIT OPEN')
