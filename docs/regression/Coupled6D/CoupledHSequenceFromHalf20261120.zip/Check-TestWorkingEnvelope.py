"""ДЛЯ ТЕСТОВ. Проверяет рабочую материальную координату, исходное равновесие и соответствие ранее проверенному прототипу."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestCheck(root, reference, output):
    """Независимо восстанавливает шесть усилий, пространственные строки и H; материал и внутреннюю половинную пробу повторно не интегрирует."""
    here = Path(__file__).resolve().parent
    reader = run_path(str(here / 'Validate-TestHardPrepared.py'))
    equilibrium, fields = reader['TestValidate'](root, 'IntegratedEvent.Sequence')
    events = reader['TestRows'](root / 'Native/IntegratedEvent.csv')
    binary = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](root / 'Input/Reverse1.bin')
    count = len(binary['fields'])
    np.testing.assert_allclose(fields[:count], binary['fields'], rtol=1e-14, atol=1e-300)
    accepted = [r for r in events if r[0] == 'ACCEPTED']
    assert count in (184, 219) and len(accepted) == 8 and len(fields) == count + 8
    coordinate = run_path(str(here / 'Compare-TestMaterialCoordinate.py'))['TestRead']
    h, new_fields, factors, *_ = coordinate(root)
    assert np.all(np.diff(h) > 0)
    native = {int(r[1]): r for r in events if r[0] == 'NATIVE'}
    half = {int(r[1]): r for r in events if r[0] == 'KERNEL_HALF'}
    details = {int(r[1]): ';'.join(r[2:]) for r in events if r[0] == 'WORKING_DETAILS'}
    reversed_new = [index for index in equilibrium['reversed_fields'] if index > count]
    for event, value, factor in zip(accepted, h[1:], factors[1:]):
        attempt, index = int(event[1]), int(event[2])
        assert native[attempt][2:4] == ['-1', '-1']
        assert float(native[attempt][7]) <= 1
        assert abs(float(event[3]) - factor) < 1e-13 and abs(float(event[4]) - value) < 1e-16
        assert 'Материальное продолжение' in details[attempt]
        assert '\ufffd' not in details[attempt]
        if index in reversed_new:
            assert native[attempt][4] == '0' and half[attempt][2] == '-1'
            assert 'поворот подтверждён половинным H' in details[attempt]
    assert reversed_new == ([186] if count == 184 else [])
    assert reader['TestRows'](root / 'Native/EnvelopeGuards.csv') == [['GUARDS', '8', 'Passed', 'AcceptedRevisionUnchanged']]
    result = json.loads((root / 'Native/ExternalResult.json').read_bytes())
    owner = json.loads((root / 'Native/ExternalOwnership.json').read_bytes())
    assert result['source_unchanged'] and result['owned_excel_final_state']['state'] == 'Exited'
    assert result['owned_excel_final_state']['filetime'] == owner['filetime']
    comparison = None
    if reference is not None:
        # Сопоставляются реальные равновесия, а не интерполированные поля.
        ref_h, ref_fields, ref_factors, *_ = coordinate(reference)
        assert len(ref_h) >= len(h)
        comparison = dict(maximum_H_difference_MPa=float(np.max(np.abs(h - ref_h[:len(h)]))),
            maximum_field_absolute_difference=float(np.max(np.abs(new_fields - ref_fields[:len(h)]))),
            maximum_lambda_absolute_difference=float(np.max(np.abs(factors - ref_factors[:len(h)]))))
    proof = dict(initial_states=count, new_states=len(accepted), states=len(fields), last_lambda=float(factors[-1]),
        original_equilibrium_checked_independently=True, H_checked_independently=True,
        eight_guards_passed=True, accepted_reverse_fields=reversed_new,
        internal_half_fields_exported_this_pass=False, independent_material_reintegration=False,
        reference=reference.name if reference is not None else None, comparison=comparison,
        reference_half_probe_previously_independently_checked=reference is not None,
        own_excel_closed=True, physical_capacity_certified=False, native_equilibrium=equilibrium)
    output.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode())
    return proof


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    for name in ('root', 'out'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--reference', type=Path)
    a = p.parse_args()
    proof = TestCheck(a.root.resolve(), a.reference.resolve() if a.reference else None, a.out.resolve())
    print(json.dumps({key: value for key, value in proof.items() if key != 'native_equilibrium'}, indent=2))
