"""ДЛЯ ТЕСТОВ. Независимо проверяет собранный VBA, физически закрытый максимум и все поля полиномиальной регрессии."""

from argparse import ArgumentParser
from decimal import Decimal, localcontext
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from subprocess import check_output


def TestRead(file):
    """Читает закреплённый протокол без изменения численных значений."""
    return json.loads(file.read_text('utf-8-sig'))


def TestNative(repo, root, output):
    """Сверяет все компоненты и источник каждого законченного нативного набора, включая ожидаемые отказы."""
    shared = run_path(str(root / 'Check-TestMaterialRoundoff.py'))
    shared['TestFiles'](root)
    source, _ = run_path(str(root / 'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root / 'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    canonical = run_path(str(root / 'Canonical-TestCoreVBA.py'))
    core_body = canonical['TestWrap'](body)
    normal = lambda value: canonical['TestCanonical'](value)[0]
    controls = {
        'equivalent_literal': normal('x=1e-8') == normal('x=0.00000001'),
        'changed_tolerance_rejected': normal('x=1e-8') != normal('x=1e-7'),
        'literal_type_rejected': normal('x=200000#') != normal('x=200000'),
        'unicode_runtime_string_exact': normal('msg="ε"') != normal('msg="?"'),
        'numeric_runtime_string_exact': normal('msg="1e-8"') != normal('msg="0.00000001"'),
        'russian_comment_exact': normal("x=1 'бетон") != normal("x=1 'арматура"),
        'unrepresentable_comment_only': normal("x=1 'ν=0") == normal("x=1 '?=0"),
        'large_integer_exact': normal('x=10000000000#') != normal('x=10000000001#')}
    assert all(controls.values())
    cases = {}
    for key in TestRead(root / 'Cases.json'):
        folder = root / 'Cases' / key
        def TestBody(text, name):
            """Учитывает только известный неподдерживаемый символ одного комментария промежуточной сборки."""
            record = core_body(text, name)
            if key == 'Initial' and name == 'CCoupledDeformationContinuation':
                old = "' находит восходящий интервал λ=1"
                record = (record[0].replace(old, old.replace('λ', '?')), *record[1:])
            return record
        record = shared['TestSourceComparison'](repo, root, folder, source, original, helper, TestBody, reader)
        assert (record['components'], record['imported'], record['unchanged']) == (239, 25, 214)
        compiler = TestRead(folder / 'docs/regression/CodeUpdate.json')
        assert 'modTestCoupledElasticState' in compiler['Modules']
        reports = {}
        for file in sorted((folder / 'Native').glob('*.txt')):
            log = file.read_text('utf-8-sig')
            phase = file.stem
            owner = TestRead(file.with_name(file.name + '.Ownership.json'))
            closure = TestRead(file.with_name(file.name + '.ProcessClosure.json'))
            identity = closure['Closure']['Identity']
            negative = (key == 'Before' and phase == 'ClosedPeak' or key == 'Initial' and phase == 'PeakRegression')
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
            assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
            assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
            assert closure['Closure']['FinalState']['State'] == 'Absent'
            assert closure['ChildExitCode'] == (1 if negative else 0)
            assert 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
            totals = [(name, int(passed), int(failed)) for name, passed, failed in
                      re.findall(r'^(TOTAL_[A-Z0-9_]+): passed=(\d+); failed=(\d+)', log, re.M)]
            assert totals
            if key == 'Before' and phase == 'ClosedPeak':
                assert phase == 'ClosedPeak' and [(a, b) for _, a, b in totals] == [(15, 3)]
            elif key == 'Initial' and phase == 'PeakRegression':
                assert [(a, b) for _, a, b in totals] == [(35, 0), (14, 7)]
            else:
                assert all(failed == 0 for _, _, failed in totals)
                if phase == 'ClosedPeak': assert [(a, b) for _, a, b in totals] == [(72, 0)]
                elif phase == 'SteelCrossing': assert [(a, b) for _, a, b in totals] == [(49, 0)]
                elif phase == 'Core': assert sum(passed for _, passed, _ in totals) == 382
                elif phase == 'PeakRegression':
                    assert {name for name, _, _ in totals} == {
                        'TOTAL_COUPLED_DEFORMATION_CONTROL', 'TOTAL_COUPLED_RETAINED_SHOULDERS',
                        'TOTAL_COUPLED_DESIGN_WITNESS', 'TOTAL_COUPLED_DISCARDED_SHOULDER',
                        'TOTAL_COUPLED_STEEL_AT_DESIGN', 'TOTAL_COUPLED_MINIMUM_LOAD_STEP', 'TOTAL_COUPLED_CONTROL_PROGRESS'}
                elif phase == 'Stock':
                    assert [(a, b) for _, a, b in totals] == [(28, 0)]
                    assert 'TIMING_STATES: direct=OK; capacity=NumFail;' in log
                    assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;', log, re.M)
                elif phase == 'Trace74':
                    assert re.search(r'^PRODUCTION_PATH_COUNT;\d+$', log, re.M)
                    assert 'Предельное состояние железобетонного сечения не установлено.' in log
                else: raise AssertionError((key, phase))
            reports[phase] = {'totals': totals, 'expected_negative': negative}
        expected = {'ClosedPeak', 'Stock'} if key == 'Before' else {'ClosedPeak', 'SteelCrossing', 'Core', 'PeakRegression'} if key == 'Initial' else {
            'ClosedPeak', 'SteelCrossing', 'Core', 'PeakRegression', 'Stock', 'Trace74'} if key == 'PrecisionTrial' else {
            'ClosedPeak', 'Core', 'PeakRegression', 'Stock', 'Trace74'}
        assert set(reports) == expected, (key, set(reports))
        safety = [json.loads(line) for line in (folder / 'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in safety)
        assert all(all(process['ProtectedUser'] for process in row['excel']) for row in safety)
        record['reports'] = reports
        cases[key] = record
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    original_code = check_output(['git', 'cat-file', 'blob', '20ecfaa:' + name], cwd=repo)
    original_code = original_code.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
    assert (root / 'Cases/Before' / name).read_bytes() == original_code
    source_tests = [(root / 'Cases' / key / 'tests/modTestCoupledElasticState.bas').read_text('utf-8-sig') for key in ('Before', 'Working')]
    for signature, end in (('Public Function RunTestCoupledClosedBranchPeak()', 'End Function'),
                           ('Private Sub TestCoupledDeformationSteelCrossing(', 'End Sub')):
        def TestMethod(text):
            """Сравнивает полный исходный текст исполнявшегося аналитического случая."""
            start = text.index(signature)
            return text[start:text.index('\n' + end, start)]
        assert TestMethod(source_tests[0]) == TestMethod(source_tests[1])
    stock = [(root / 'Cases' / key / 'Native/Stock.txt').read_text('utf-8-sig') for key in ('Before', 'Working')]
    states = [re.search(r'^TIMING_STATES: (.*)$', log, re.M)[1] for log in stock]
    assert states[0] == states[1]
    output.write_text(json.dumps({'cases': cases, 'analytical_closed_capacity_certified': True,
        'general_physical_capacity_certified': False, 'full_acceptance_completed': False,
        'installed_workbook_changed': False, 'initial_comment_encoding_only': 'lambda glyph in one source comment',
        'core_source_comparison_controls': controls,
        'analytical_cases_identical_before_and_after': True}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('CLOSED BRANCH NATIVE SOURCE NEGATIVE CONTROLS AND REGRESSIONS VERIFIED', flush=True)


def TestMechanics(repo, root, output):
    """Повторяет силы кубической модели и весь полиномиальный след с высокой точностью Decimal."""
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    log = (root / 'Cases/Working/Native/ClosedPeak.txt').read_text('utf-8-sig')
    positive = [line for line in log.splitlines() if line.startswith('OK: physical closure certifies')]
    assert len(positive) == 3
    forces = re.findall(r'^OK: last retained field independently equilibrates its saved load actual=([\d.E+-]+) expected=([\d.E+-]+)$', log, re.M)
    assert len(forces) == 3
    records = []
    number = r'[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?'
    with localcontext() as context:
        context.prec = 50
        def TestForce(strain):
            """Независимая явная сила однородного сечения после замещения бетона центральным стержнем."""
            return Decimal(21500) * (30000 * strain - Decimal('1e10') * strain ** 3) + 100 * min(200000 * strain, Decimal(100))
        exact_peak = TestForce(Decimal('.001'))
        assert exact_peak == 440000
        for design, line, (actual, saved) in zip(map(Decimal, ('410000', '450000', '440000')), positive, forces):
            peak, accuracy = map(Decimal, re.search(rf'Определяющий максимум lambda: ({number}); оценка погрешности: ({number})', line).groups())
            low, high = map(Decimal, re.search(rf'Координата деформации: \[({number}), ({number})\]', line).groups())
            terminal_low, terminal_high = map(Decimal, re.search(rf'Арматурное событие: lambda до = ({number}), lambda после = ({number})', line).groups())
            assert 0 < accuracy <= Decimal('.0001') and abs(peak - exact_peak / design) <= accuracy
            assert low <= Decimal('.00125') < high and low >= Decimal('.00124')
            assert abs(TestForce(low) / design - terminal_low) <= Decimal('1e-12')
            assert abs(TestForce(high) / design - terminal_high) <= Decimal('1e-12')
            assert max(terminal_low, terminal_high) < peak - accuracy
            assert abs(Decimal(actual) - Decimal(saved)) <= Decimal('.01')
            assert abs(Decimal(actual) - peak * design) <= Decimal('.01')
            assert Decimal(actual) <= exact_peak and exact_peak - Decimal(actual) <= accuracy * design
            records.append({'design_N': str(design), 'peak_lambda': str(peak), 'accuracy': str(accuracy),
                'peak_force_N': actual, 'exact_peak_N': str(exact_peak), 'closing_strain_interval': [str(low), str(high)],
                'expected_peak_torque_Nmm': str(30000 + 200000 * peak)})
        assert all('OK: capacity classifies the known maximum as ' + status in log for status in ('OK', 'FAIL', 'NumFail'))
        assert log.count('OK: the same peak state balances the fixed and scaled torque') == 3
        assert 'OK: an open reinforced branch supplies no governing capacity' in log
        regression = (root / 'Cases/Working/Native/PeakRegression.txt').read_text('utf-8-sig')
        def TestPolynomial(t):
            """Множитель аналитической регрессии с двумя максимумами."""
            return (((-218 * t + 1309) * t - 2428) * t + 1379) * t / 600 + Decimal('.75')
        roots = []
        for lower, upper in ((0, 1), (1, 2), (2, 3)):
            a, b = Decimal(lower), Decimal(upper)
            def TestDerivative(t):
                """Точная производная полинома по его безразмерной координате."""
                return ((-872 * t + 3927) * t - 4856) * t + 1379
            sign = TestDerivative(a)
            for _ in range(150):
                middle = (a + b) / 2
                if TestDerivative(middle) * sign > 0: a = middle
                else: b = middle
            roots.append((a + b) / 2)
        exact_twin_max = TestPolynomial(roots[2])
        earlier_unresolved_max = max(TestPolynomial(t) for t in roots)
        assert earlier_unresolved_max > exact_twin_max
        assert 'OK: локальный пик железобетона не опубликован как предел' in regression
        assert 'OK: сохраняется численный исход без физического предела' in regression
        groups = {}
        for method in ('RunTestCoupledRetainedShoulders', 'RunTestCoupledDiscardedShoulder'):
            text = regression.split('SUITE_STARTED: modTestCoupledElasticState.' + method + ';', 1)[1]
            text = text.split('SUITE_FINISHED:', 1)[0]
            rows = re.findall(r'^TEST_TWIN_PEAK_FIELD;(\d+);([\d.E+-]+);([\d.E+-]+)$', text, re.M)
            assert len(rows) > 5
            previous = Decimal(0)
            maximum = Decimal(0)
            for index, (number, strain, factor) in enumerate(rows, 1):
                strain, factor = Decimal(strain), Decimal(factor)
                assert int(number) == index and strain > previous
                assert abs(factor - TestPolynomial((strain - Decimal('.0004')) / Decimal('.0001'))) <= Decimal('1e-9')
                previous = strain
                maximum = max(maximum, factor)
            assert abs(maximum - exact_twin_max) <= Decimal('.0001') and maximum < Decimal('1.2')
            groups[method] = {'states': len(rows), 'maximum_lambda': str(maximum)}
    output.write_text(json.dumps({'closed_cases': records, 'right_local_peak_after_second_seed_lambda': str(exact_twin_max),
        'earlier_unresolved_polynomial_peak_lambda': str(earlier_unresolved_max),
        'polynomial_cases_certify_capacity': False, 'polynomial_peak_scope_start_strain': '.0006',
        'all_retained_polynomial_fields': groups, 'general_physical_capacity_certified': False}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('CLOSED BRANCH ANALYTICAL MAXIMUM PHYSICAL CLOSURE AND EVERY POLYNOMIAL FIELD VERIFIED', flush=True)


def TestSpatial(repo, root, output):
    """Повторяет все пространственные равновесия MVT по полному фактически сохранённому пути."""
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    validate = run_path(str(root / 'Validate-TestGeneralContinuation.py'))['TestValidate']
    validate(repo, root / 'Cases/Working', 'Trace74', output)
    proof = TestRead(output)
    baseline = TestRead(root / 'Baseline/Origin.json')
    archive = repo / 'docs/regression/Coupled6D' / baseline['archive']
    assert sha256(archive.read_bytes()).hexdigest().upper() == baseline['sha256']
    for name, digest in baseline['entries'].items():
        assert sha256((root / 'Baseline' / name).read_bytes()).hexdigest().upper() == digest
    def TestFields(file):
        """Сравнивает точную запись всех координат полей, включая множители связей."""
        return [line for line in file.read_text('cp1251').splitlines() if line.startswith('F;')]
    original = TestFields(root / 'Baseline/Trace74.Operators.csv')
    working = TestFields(root / 'Cases/Working/Native/Trace74.Operators.csv')
    trial = TestFields(root / 'Cases/PrecisionTrial/Native/Trace74.Operators.csv')
    assert len(original) == len(working) == 151 and original == working
    assert len(trial) == 148 and trial == original[:148]
    proof['restored_original_fields_byte_exact'] = 151
    proof['redundant_refinement_trial_prefix_byte_exact'] = 148
    output.write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('CLOSED BRANCH SPATIAL EQUILIBRIA AND ORIGINAL 151 FIELDS RESTORED VERIFIED', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics', 'spatial'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics, 'spatial': TestSpatial}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
