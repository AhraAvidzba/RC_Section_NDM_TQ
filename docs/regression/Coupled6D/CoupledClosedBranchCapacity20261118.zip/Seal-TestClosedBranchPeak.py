"""ДЛЯ ТЕСТОВ. Фиксирует воспроизводимые проверки закрытого максимума без изменения исторических случаев."""

from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile, ZIP_DEFLATED


def TestSeal():
    """Добавляет три случая и архив после успешного независимого повтора всех трёх проверок."""
    repo = Path.cwd()
    scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    root = scratch / 'ClosedBranchEvidence20261118'
    assert json.loads((root / 'SpatialProof.json').read_bytes())['restored_original_fields_byte_exact'] == 151
    assert len(json.loads((root / 'MechanicsProof.json').read_bytes())['closed_cases']) == 3
    assert json.loads((root / 'NativeProof.json').read_bytes())['analytical_cases_identical_before_and_after']
    (root / 'Operational').mkdir()
    for source, target in (('tmp/CompletedArtifactRelocation20261118.json', 'Relocation.json'),
                           ('tmp/material-consistency/Move-TestCompletedArtifacts.ps1', 'Move-TestCompletedArtifacts.ps1'),
                           ('docs/Coupled6DMaterialContract.md', 'Coupled6DMaterialContract.md'),
                           ('docs/CoupledSectionModel.md', 'CoupledSectionModel.md')):
        (root / 'Operational' / target).write_bytes((repo / source).read_bytes())
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    outputs = {'NativeProof.json', 'MechanicsProof.json', 'SpatialProof.json'}
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.relative_to(root).as_posix() not in outputs | {'Files.json'}}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    name = 'CoupledClosedBranchCapacity20261118'
    archive = scratch / (name + '.zip')
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as output:
        for file in sorted(root.rglob('*')):
            if file.is_file(): output.write(file, file.relative_to(root).as_posix())
    assert archive.stat().st_size < 100000000, archive.stat().st_size
    digest = sha256(archive.read_bytes()).hexdigest().upper()
    destination = repo / 'docs/regression/Coupled6D' / (name + '.zip')
    assert not destination.exists()
    copyfile(archive, destination)
    cases, pins = [], {}
    for scope, title, marker in (
        ('native', 'NativeProof.json', 'CLOSED BRANCH NATIVE SOURCE NEGATIVE CONTROLS AND REGRESSIONS VERIFIED'),
        ('mechanics', 'MechanicsProof.json', 'CLOSED BRANCH ANALYTICAL MAXIMUM PHYSICAL CLOSURE AND EVERY POLYNOMIAL FIELD VERIFIED'),
        ('spatial', 'SpatialProof.json', 'CLOSED BRANCH SPATIAL EQUILIBRIA AND ORIGINAL 151 FIELDS RESTORED VERIFIED')):
        pins[title] = sha256((root / title).read_bytes()).hexdigest().upper()
        cases.append({'id': 'coupled-closed-branch-' + scope, 'journal_section': 610, 'archive': name,
            'script': 'Check-TestClosedBranchPeak.py', 'arguments': ['--repo', '{repo}', '--root', '.', '--scope', scope, '--out', title],
            'stdout_contains': marker, 'outputs': {title: pins[title]}, 'timeout_seconds': 600 if scope == 'spatial' else 300})
    path = repo / 'docs/reports/Coupled6DEvidence.json'
    text = path.read_text('utf-8').replace('\r\n', '\n')
    old = json.loads(text)
    assert len(old['archives']) == 300 and len(old['cases']) == 328
    index = text.index('\n  },\n  "cases": [')
    text = text[:index] + ',\n    ' + json.dumps(name) + ': ' + json.dumps(digest) + text[index:]
    index = text.index('\n  ],\n  "frozen_repositories": {')
    text = text[:index] + ',\n' + ',\n'.join('\n'.join('    ' + line for line in json.dumps(case, ensure_ascii=False, indent=2).splitlines()) for case in cases) + text[index:]
    current = json.loads(text)
    assert current['cases'][:328] == old['cases'] and len(current['cases']) == 331
    assert all(current['archives'][key] == value for key, value in old['archives'].items())
    path.write_bytes(text.replace('\n', '\r\n').encode())
    receipt = {'archive': name, 'bytes': archive.stat().st_size, 'sha256': digest, 'proofs': pins}
    (repo / 'tmp/ClosedBranchSeal.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    TestSeal()
