"""ДЛЯ ТЕСТОВ. Сохраняет прежнее ядро, промежуточную неудачную регрессию и итоговую сборку."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestCollect(repo, root):
    """Закрепляет исходники и фактический CFB всех проверяемых сборок без изменения основной книги."""
    here = Path(__file__).resolve().parent
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = {'Before': 'ClosedBranchBefore20261118',
        'Initial': 'ClosedBranchFixed20261118', 'PrecisionTrial': 'ClosedBranchFinal20261118',
        'Working': 'ClosedBranchConverged20261118'}
    collect(repo, root)
    for name in ('Collect-TestClosedBranchPeak.py', 'Check-TestClosedBranchPeak.py',
                 'Stage-TestClosedBranchPeak.py', 'Stage-TestSteelHistory.py', 'Canonical-TestCoreVBA.py'):
        (root / name).write_bytes((here / name).read_bytes())
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '20ecfaa',
        'installed_workbook_changed': False, 'analytical_closed_capacity_certified': True,
        'general_physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2) + '\n', encoding='utf-8')
    baseline = repo / 'docs/regression/Coupled6D/ASDPrincipalPredictor20261118.zip'
    digest = sha256(baseline.read_bytes()).hexdigest().upper()
    assert digest == 'A710318F0D27A169832B28508E015217DEA0FE3F3D7C6F4601232589BC12E508'
    (root / 'Baseline').mkdir()
    entries = {}
    with ZipFile(baseline) as archive:
        for name in ('Trace74.Operators.csv', 'Trace74.Tensor.csv', 'Trace74.txt'):
            raw = archive.read('Cases/Predictor/Native/' + name)
            (root / 'Baseline' / name).write_bytes(raw)
            entries[name] = sha256(raw).hexdigest().upper()
    (root / 'Baseline/Origin.json').write_text(json.dumps({'archive': baseline.name, 'sha256': digest,
        'entries': entries}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('CLOSED BRANCH NEGATIVE CONTROLS AND WORKING VBA COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
