# ДЛЯ ТЕСТОВ. Переносит только завершённый игнорируемый Temp доказательств, сохраняя путь и проверяя каждый байт.
$ErrorActionPreference='Stop'
$taskWorkspace=(Get-Location).Path
$taskRelative='tmp/dplot/Temp'
$taskSource=(Resolve-Path -LiteralPath $taskRelative).Path
$taskBackup=Join-Path ([IO.Path]::GetDirectoryName($taskSource)) 'Temp_RelocationBackup20261118'
$taskTarget='D:\CodexScratch\RC_Section_NDM_TQ\RelocatedCompletedProofs20261118\dplot\Temp'
$taskAllowedPrefix=[IO.Path]::GetFullPath((Join-Path $taskWorkspace 'tmp/dplot'))+[IO.Path]::DirectorySeparatorChar
foreach ($taskChecked in @($taskSource,$taskBackup)) {
    if (![IO.Path]::GetFullPath($taskChecked).StartsWith($taskAllowedPrefix,[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь выходит за разрешённую завершённую проверку.'}
}
if ((Get-Item -LiteralPath $taskSource).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Исходный Temp уже является ссылкой.'}
if ((Test-Path -LiteralPath $taskBackup) -or (Test-Path -LiteralPath $taskTarget)) {throw 'Цель переноса или резерв уже существуют.'}
if (@(& git ls-files -- $taskRelative).Count -ne 0) {throw 'В служебном Temp найдены отслеживаемые файлы.'}
$taskClosed=Get-Content -LiteralPath 'tmp/dplot/CompileClosure.json' -Raw | ConvertFrom-Json
if ($taskClosed.State -cne 'Absent') {throw 'Нет подтверждения завершённой сборки.'}
$taskLive=Get-Process -Id ([int]$taskClosed.PID) -ErrorAction SilentlyContinue
if ($taskLive -and $taskLive.StartTime.ToUniversalTime().Ticks -eq [long]$taskClosed.StartTicksUTC) {throw 'Сборочный процесс ещё существует.'}
$taskItems=@(Get-ChildItem -LiteralPath $taskSource -Recurse -Force)
if ($taskItems | Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}) {throw 'В Temp имеются вложенные ссылки.'}
$taskManifest=@()
foreach ($taskFile in @($taskItems | Where-Object {!$_.PSIsContainer})) {
    $taskManifest+=,[pscustomobject]@{Path=$taskFile.FullName.Substring($taskSource.Length+1);Length=$taskFile.Length;SHA256=(Get-FileHash -LiteralPath $taskFile.FullName).Hash}
}
New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($taskTarget)) -Force | Out-Null
Copy-Item -LiteralPath $taskSource -Destination $taskTarget -Recurse
foreach ($taskEntry in $taskManifest) {
    $taskCopy=Join-Path $taskTarget $taskEntry.Path
    if ((Get-Item -LiteralPath $taskCopy).Length -ne $taskEntry.Length -or (Get-FileHash -LiteralPath $taskCopy).Hash -cne $taskEntry.SHA256) {throw 'Копия не совпадает с исходным файлом.'}
}
if (@(Get-ChildItem -LiteralPath $taskTarget -Recurse -File -Force).Count -ne $taskManifest.Count) {throw 'Количество скопированных файлов не совпало.'}
$taskReceipt=[pscustomobject]@{Source=$taskSource;Destination=$taskTarget;Files=$taskManifest;SourceClosure=$taskClosed;JunctionPreservesOriginalPath=$true}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path ([IO.Path]::GetDirectoryName($taskTarget)) 'Relocation.json') -Encoding UTF8
Move-Item -LiteralPath $taskSource -Destination $taskBackup
try {New-Item -ItemType Junction -Path $taskSource -Target $taskTarget | Out-Null} catch {
    Move-Item -LiteralPath $taskBackup -Destination $taskSource
    throw
}
if (!(Get-Item -LiteralPath $taskSource).Attributes.HasFlag([IO.FileAttributes]::ReparsePoint)) {throw 'Исходный путь не восстановлен ссылкой.'}
$taskResolvedBackup=(Resolve-Path -LiteralPath $taskBackup).Path
if ($taskResolvedBackup -cne $taskBackup -or !$taskResolvedBackup.StartsWith($taskAllowedPrefix,[StringComparison]::OrdinalIgnoreCase)) {throw 'Резерв не принадлежит разрешённой папке.'}
if ((Get-Item -LiteralPath $taskBackup).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Резерв не должен быть ссылкой.'}
foreach ($taskEntry in $taskManifest) {
    $taskOriginal=Join-Path $taskBackup $taskEntry.Path
    $taskReadable=Join-Path $taskSource $taskEntry.Path
    if ((Get-FileHash -LiteralPath $taskOriginal).Hash -cne $taskEntry.SHA256 -or (Get-FileHash -LiteralPath $taskReadable).Hash -cne $taskEntry.SHA256) {throw 'Файл изменился во время переноса; резерв сохранён.'}
}
if (@(Get-ChildItem -LiteralPath $taskBackup -Recurse -File -Force).Count -ne $taskManifest.Count) {throw 'Резерв изменился; удаление запрещено.'}
Remove-Item -LiteralPath $taskResolvedBackup -Recurse -Force
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath 'tmp/CompletedArtifactRelocation20261118.json' -Encoding UTF8
Write-Output ('VERIFIED_TEMP_RELOCATION; files='+$taskManifest.Count+'; bytes='+($taskManifest|Measure-Object Length -Sum).Sum+'; free_C_MiB='+[math]::Round((Get-PSDrive C).Free/1MB))
