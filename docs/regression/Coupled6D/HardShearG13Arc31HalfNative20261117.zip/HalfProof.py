"""Сравнивает продвижение и поперечное отклонение в восстановленной метрике деформаций."""
from math import fsum, isclose, sqrt
from pathlib import Path

import ArcVerify as arc
import PriorVerify as prior


HERE=Path(__file__).resolve().parent
REPORT='8F255FA77B6EE1753173C5C37633B5EB0248DCC673DDFBC82C5E3908A73C5A9B'
ARCHIVE='CBC7CB1E5D33FF2DC18FAC4A37BB109FFC7B18804D3BD4000A89173BEA8F77BC'


def inputs(fixture,extract):
    baseline=HERE/'FullTravel/HardG14Direction.csv'
    receipt=HERE/'FullTravel/Verification.json'
    assert fixture['full_travel_archive_sha256']==ARCHIVE
    assert fixture['full_travel_report_sha256']==prior.file_hash(receipt)==REPORT
    full=prior.read(receipt)
    assert full['native_trace_sha256']==prior.file_hash(baseline)
    assert full['automatic_branch_retry']['attempt14']=='ACCEPTED'
    assert full['automatic_branch_retry']['attempt15']=='LOCALITY_OR_BALANCE'
    _,_,_,steps,_,final=extract(baseline)
    assert len(steps)==15 and final==['SINGLE_STOCK_PROBE','10','9744']


def movement_metrics(step,base,direction,weights,operator):
    requested=prior.number(step['args'][2])
    result={'requested_distance':requested,'decision':step['TRACE-DECISION'][0],
            'solver_returned':prior.received(step['args'][7])}
    if 'TRACE-FIELD' not in step:
        assert not result['solver_returned']
        return result
    field=prior.numbers(step['TRACE-FIELD'])
    displacement=[b-a for a,b in zip(base,field,strict=True)]
    projection=prior.numbers(step['TRACE-PROJECTION'])
    axial=fsum(x*y for x,y in zip(projection,displacement,strict=True))
    length=sqrt(arc.metric_value(weights,operator,direction))
    orthogonal=[a-axial*b/length for a,b in zip(displacement,direction,strict=True)]
    orthogonal_norm=sqrt(arc.metric_value(weights,operator,orthogonal))
    physical_norm=sqrt(arc.metric_value(weights,operator,displacement))
    factor,norm,tau,advance,distance,steel,error,xz=prior.numbers(step['TRACE-BALANCE'][:-1])
    assert isclose(axial,advance,rel_tol=1e-9,abs_tol=1e-20)
    assert isclose(physical_norm,distance,rel_tol=1e-9,abs_tol=1e-20)
    assert isclose(orthogonal_norm**2+axial**2,physical_norm**2,rel_tol=1e-8,abs_tol=1e-29)
    result.update(lambda_factor=factor,norm_MPa=norm,tolerance_MPa=tau,steel_utilization=steel,
                  projected_advance=advance,physical_distance=distance,xz=xz,
                  orthogonal_distance=orthogonal_norm,orthogonal_to_request=orthogonal_norm/requested,
                  distance_to_request=distance/requested,within_same_threefold_gate=distance<=3.*requested)
    return result


def verify(path,extract,steps,final,rows,weights,operator):
    raw=path.read_text(encoding='cp1251').splitlines()
    original=HERE/'FullTravel/HardG14Direction.csv'
    prior_lines=original.read_text(encoding='cp1251').splitlines()
    assert [r for r in raw if r.startswith('AUTO-')]==[r for r in prior_lines if r.startswith('AUTO-')]
    _,base_weights,base_op,before,_,_=extract(original)
    assert len(steps)==15 and steps[:14]==before[:14] and weights==base_weights and operator==base_op
    assert final[0]=='SINGLE_STOCK_PROBE' and final[2]=='9744'
    unit=steps[14]
    full=before[14]
    assert unit['TRACE-PROJECTION']==full['TRACE-PROJECTION']
    assert unit['args'][:2]==full['args'][:2] and unit['args'][5]==full['args'][5]
    assert prior.number(unit['args'][2])==.5*prior.number(full['args'][2])
    base=prior.numbers(steps[13]['TRACE-COMMIT'])
    previous=prior.numbers(steps[10]['TRACE-COMMIT'])
    direction=[b-a if i<56 else 0. for i,(a,b) in enumerate(zip(previous,base,strict=True))]
    long=movement_metrics(full,base,direction,weights,operator)
    short=movement_metrics(unit,base,direction,weights,operator)
    result={'exact_first_14_attempts_and_fields':True,'same_normalized_control':True,
            'restored_original_history_words':9744,'full_original_attempt15':long,'half_new_attempt15':short,
            'physical_limit_certified':False}
    if 'orthogonal_distance' in short:
        result['half_to_full_orthogonal_distance']=short['orthogonal_distance']/long['orthogonal_distance']
    if short['decision']=='ACCEPTED':
        before,after=rows[13:15]
        delta=after['lambda']-before['lambda']
        tol=after['lambda_uncertainty']+before['lambda_uncertainty']
        result['accepted_half_delta_lambda_interval']=[delta-tol,delta+tol]
    return result
