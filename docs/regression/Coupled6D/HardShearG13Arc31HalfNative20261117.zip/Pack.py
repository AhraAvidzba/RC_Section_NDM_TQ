"""Сохраняет результаты ARC31Half вместе с автономной проверкой."""
from argparse import ArgumentParser
import json
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import PortableSupport as support

HERE=Path(__file__).resolve().parent
DEFAULT56=HERE.parent/'hs-arc56/proof/HardShearG13SerialArcAttempt14DirectionNative20261117.zip'
DEFAULT_RESUME=HERE.parent/'hs-p31-resume/proof/HardShearG13Arc31ResumeNative20261117.zip'
DEFAULT_AUTO=HERE.parent/'hs-p31-auto/proof/HardShearG13Arc31AutoNative20261117.zip'
NAME='HardShearG13Arc31HalfNative20261117'


def collect(source,baselines,native_sha):
    plan=support.fixture((source/'Fixture.json').read_bytes())
    common=dict(support.inherited(plan,baselines))
    for name,digest in plan['inputs'].items():
        data=(source/name).read_bytes()
        assert support.sha(data)==digest
        if name in common:
            assert data==common[name]
    extra=('Fixture.json','Compile.log','CompileClosure.json',support.CODE,'Run.ndjson')
    native=[item.relative_to(source).as_posix()
            for item in sorted((source/'Native/Order10').iterdir()) if item.is_file()]
    names=[*extra,*(name for name in plan['inputs'] if name not in common),*native]
    assert len(names)==len(set(names)) and support.REPORT in names and support.TRACE in names
    files={name:(source/name).read_bytes() for name in names}
    assert support.sha(files[support.REPORT])==native_sha.upper()
    assert json.loads(files[support.REPORT])['native_trace_sha256']==support.sha(files[support.TRACE])
    files[support.DELTA]=support.json_bytes(support.trace_delta(baselines[support.TRACE],files.pop(support.TRACE)))
    for name in ('Pack.py','Verify-Portable.py','PortableSupport.py','AutoPortableSupport.py','README-Portable.md'):
        files[name]=(HERE/name).read_bytes()
    files[support.SUMS]=support.json_bytes(dict(sorted((name,support.sha(data)) for name,data in files.items())))
    return files


def seal(path,raw):
    if path.exists():
        assert path.read_bytes()==raw
    else:
        path.write_bytes(raw)


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('source',type=Path)
    cli.add_argument('report_sha256')
    cli.add_argument('--arc56',type=Path,default=DEFAULT56)
    cli.add_argument('--resume',type=Path,default=DEFAULT_RESUME)
    cli.add_argument('--auto',type=Path,default=DEFAULT_AUTO)
    args=cli.parse_args()
    base56,base31,full_auto=args.arc56.resolve(),args.resume.resolve(),args.auto.resolve()
    files=collect(args.source,support.read_baselines(base56,base31,full_auto),args.report_sha256)
    out=HERE/'proof'
    out.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix='replay-',dir=out) as directory:
        root=Path(directory)
        pack=root/'candidate.zip'
        with ZipFile(pack,'w',compression=ZIP_DEFLATED,compresslevel=9) as archive:
            for filename,data in sorted(files.items()):
                entry=ZipInfo(filename,date_time=(2026,11,17,0,0,0))
                entry.create_system=3
                entry.external_attr=0o100644 << 16
                archive.writestr(entry,data,compress_type=ZIP_DEFLATED,compresslevel=9)
        unpacked=root/'extracted'
        with ZipFile(pack) as archive:
            archive.extractall(unpacked)
        check=run([sys.executable,'-B','-X','utf8','Verify-Portable.py',str(base56),str(base31),str(full_auto)],
                  cwd=unpacked,stdout=PIPE,check=True).stdout
        data=pack.read_bytes()
        sha=support.sha(data)
        seal(out/(NAME+'.zip'),data)
        seal(out/(NAME+'.zip.sha256'),f'{sha} *{NAME}.zip\n'.encode('ascii'))
        seal(out/(NAME+'.replay.txt'),check)
    print(out/(NAME+'.zip'),sha,len(data))
    print(check.decode('utf-8').splitlines()[-1])


if __name__=='__main__':
    main()
