"""Восстанавливает исходную запись ARC31Auto из двух закреплённых архивов."""

from base64 import b64decode, b64encode
from hashlib import sha256
import json
from zipfile import ZipFile

BASE56='6CA5C64823399B7385635AA50F31C132A221164C47DE8D8E96B42DBC23037318'
BASE31='819291EB230833351A6A9742D57B8FCC4473146176D5442BEDD7BB5557ED0978'
FIXTURE='5F6779FEBE11DA6F615CBF99D509105CA95998B6836E1B44371DB77A16E94363'
TRACE='Native/Order10/HardG14Direction.csv'
REPORT='Native/Order10/Verification.json'
CODE='docs/regression/CodeUpdate.json'
DELTA='Native/Order10/TraceDeltaAuto.json'
SUMS='SHA256SUMS.json'
REFERENCES={
    'Manual/Arc56.csv':(56,TRACE),
    'Manual/ResumeVerification.json':(31,REPORT),
    'Manual/ExpectedCandidate.json':(31,'Candidate.json'),
}
GENERIC_SHA='5F201EDF38B5B1268D08D8A0309F0ED74A2AAFDBB612160C1A20842A2B0284A7'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'


def strip_prior_capture(raw):
    return b''.join(line for line in raw.splitlines(keepends=True) if not line.startswith(b'ARC56-'))


def sha(raw):
    return sha256(raw).hexdigest().upper()


def json_bytes(value):
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')


def fixture(raw):
    assert sha(raw)==FIXTURE
    spec=json.loads(raw)
    assert spec['manual_follow_on_archive_sha256']==BASE31 and spec['branch_source_sha256']==GENERIC_SHA
    return spec


def read_zip(path,expected):
    assert sha(path.read_bytes())==expected
    with ZipFile(path) as archive:
        return {name:archive.read(name) for name in archive.namelist()}


def read_baselines(arc56,arc31):
    return {56:read_zip(arc56,BASE56),31:read_zip(arc31,BASE31)}


def trace_delta(old,new):
    a,b=(part.splitlines(keepends=True) for part in (old,new))
    prefix=0
    while prefix<min(len(a),len(b)) and a[prefix]==b[prefix]:
        prefix+=1
    suffix=0
    while suffix<min(len(a),len(b))-prefix and a[-suffix-1]==b[-suffix-1]:
        suffix+=1
    middle=b[prefix:len(b)-suffix]
    assert prefix>2000 and 0<len(middle)<40 and sum(map(len,middle))<70000
    return dict(old_sha256=sha(old),new_sha256=sha(new),old_lines=len(a),new_lines=len(b),
                prefix_lines=prefix,suffix_lines=suffix,
                middle=b64encode(b''.join(middle)).decode('ascii'))


def restore_trace(old,delta):
    lines=old.splitlines(keepends=True)
    prefix,suffix=delta['prefix_lines'],delta['suffix_lines']
    assert sha(old)==delta['old_sha256'] and len(lines)==delta['old_lines']
    assert 0<=suffix<=len(lines)-prefix and 2000<prefix<=len(lines)
    middle=b64decode(delta['middle'],validate=True)
    result=b''.join(lines[:prefix])+middle+b''.join(lines[len(lines)-suffix:])
    assert sha(result)==delta['new_sha256'] and len(result.splitlines())==delta['new_lines']
    assert trace_delta(old,result)==delta
    return result


def inherited(spec,baselines):
    for name,expected in spec['inputs'].items():
        origin,path=REFERENCES.get(name,(56,name))
        raw=baselines[origin].get(path)
        if raw is not None and sha(raw)==expected:
            yield name,raw
    for name,digest in spec['production'].items():
        path='Production/'+name
        raw=baselines[56][path]
        assert sha(raw)==digest
        yield path,raw


def restore_files(delta_pack,baselines):
    existing=dict(inherited(fixture(delta_pack['Fixture.json']),baselines))
    assert existing.keys().isdisjoint(delta_pack) and TRACE not in delta_pack
    files={**existing,**delta_pack}
    for name,digest in fixture(files['Fixture.json'])['inputs'].items():
        assert sha(files[name])==digest,name
    files[TRACE]=restore_trace(strip_prior_capture(baselines[56][TRACE]),json.loads(delta_pack[DELTA]))
    generic=files['Support/GenericNewton.cls']
    assert sha(generic)==GENERIC_SHA
    stitched=files[SOLVER].decode('utf-8-sig')
    assert stitched.count('    mHardAutoEnabledTest = (attempt = 14)')==1
    assert stitched.count('    mHardAutoEnabledTest = False')==1
    assert 'RestoreHardArc31Test' not in stitched
    return files
