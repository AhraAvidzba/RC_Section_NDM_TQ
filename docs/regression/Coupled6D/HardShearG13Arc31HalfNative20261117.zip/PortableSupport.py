"""Восстанавливает исходную запись ARC31Half из двух закреплённых архивов."""

from base64 import b64decode, b64encode
from hashlib import sha256
import json
import AutoPortableSupport as auto

AUTO='CBC7CB1E5D33FF2DC18FAC4A37BB109FFC7B18804D3BD4000A89173BEA8F77BC'
FIXTURE='481AC49C38A7E5E88389E15B12FC151AA2C26A2F586F9D8CA3A60AA99F2E1C21'
TRACE='Native/Order10/HardG14Direction.csv'
REPORT='Native/Order10/Verification.json'
CODE='docs/regression/CodeUpdate.json'
DELTA='Native/Order10/TraceDeltaHalf.json'
SUMS='SHA256SUMS.json'
REFERENCES={
    'FullTravel/HardG14Direction.csv':TRACE,
    'FullTravel/Verification.json':REPORT,
}
SOLVER='src/Solver/CCoupledNewtonSolver.cls'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def json_bytes(value):
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')


def fixture(raw):
    assert sha(raw)==FIXTURE
    spec=json.loads(raw)
    assert spec['full_travel_archive_sha256']==AUTO and spec['branch_source_sha256']==auto.GENERIC_SHA
    return spec


def read_baselines(arc56,resume,full_auto):
    actual=auto.read_zip(full_auto,AUTO)
    from pathlib import Path
    assert Path(auto.__file__).read_bytes()==actual['PortableSupport.py']
    return auto.restore_files(actual,auto.read_baselines(arc56,resume))


def trace_delta(old,new):
    a,b=(part.splitlines(keepends=True) for part in (old,new))
    prefix=0
    while prefix<min(len(a),len(b)) and a[prefix]==b[prefix]:
        prefix+=1
    suffix=0
    while suffix<min(len(a),len(b))-prefix and a[-suffix-1]==b[-suffix-1]:
        suffix+=1
    middle=b[prefix:len(b)-suffix]
    assert prefix>2000 and 0<len(middle)<40 and sum(map(len,middle))<70000
    return dict(old_sha256=sha(old),new_sha256=sha(new),old_lines=len(a),new_lines=len(b),
                prefix_lines=prefix,suffix_lines=suffix,
                middle=b64encode(b''.join(middle)).decode('ascii'))


def restore_trace(old,delta):
    lines=old.splitlines(keepends=True)
    prefix,suffix=delta['prefix_lines'],delta['suffix_lines']
    assert sha(old)==delta['old_sha256'] and len(lines)==delta['old_lines']
    assert 0<=suffix<=len(lines)-prefix and 2000<prefix<=len(lines)
    middle=b64decode(delta['middle'],validate=True)
    result=b''.join(lines[:prefix])+middle+b''.join(lines[len(lines)-suffix:])
    assert sha(result)==delta['new_sha256'] and len(result.splitlines())==delta['new_lines']
    assert trace_delta(old,result)==delta
    return result


def inherited(spec,baseline):
    for name,expected in spec['inputs'].items():
        raw=baseline.get(REFERENCES.get(name,name))
        if raw is not None and sha(raw)==expected:
            yield name,raw
    for name,digest in spec['production'].items():
        path='Production/'+name
        raw=baseline[path]
        assert sha(raw)==digest
        yield path,raw


def restore_files(delta_pack,baseline):
    plan=fixture(delta_pack['Fixture.json'])
    existing=dict(inherited(plan,baseline))
    assert existing.keys().isdisjoint(delta_pack) and TRACE not in delta_pack
    files={**existing,**delta_pack}
    for name,digest in plan['inputs'].items():
        assert sha(files[name])==digest,name
    files[TRACE]=restore_trace(baseline[TRACE],json.loads(delta_pack[DELTA]))
    before=baseline[SOLVER]
    marker=b'            requested = trialLength\r\n'
    assert before.count(marker)==1
    assert files[SOLVER]==before.replace(marker,marker+b'            If attempt = 14 Then requested = 0.5 * trialLength\r\n')
    return files
