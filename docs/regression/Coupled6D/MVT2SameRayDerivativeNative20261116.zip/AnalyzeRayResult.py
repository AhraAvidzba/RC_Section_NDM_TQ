"""Quantify the same-branch/crossed-branch discrepancy from the native ray data."""
from math import fsum
import json
from pathlib import Path

import VerifyBase as v


here = Path(__file__).resolve().parent


def main():
    native = here / "NativeHalf/MVT2.csv"
    canonical = here / "VerificationRay.json"
    assert v.digest(native) == "7B36BD0EE4173093C26224831461BDD7FD89D09CBB85B5C52C1941695976C8EB"
    assert v.digest(canonical) == "1242A059FBBF5E2128ABD94774A48D68C7A54CE33CC937055F808602B746C8D6"
    evidence = v.read(canonical)
    states, stations = v.verified_states(v.read_native(native))
    stable = evidence["original_material_directional_measurements"]["0.25"]
    crossed = evidence["original_material_directional_measurements"]["0.5"]
    assert not stable["branch_switches_relative_to_zero"] and crossed["branch_switches_relative_to_zero"] == [[2,1]]
    native_stock = fsum(evidence["original_stock_center_slope_MPa"])
    fresh_stock = fsum(evidence["fresh_stock_center_slope_MPa"])
    assert evidence["fresh_stock_closes_original_matrix"] and abs(native_stock-fresh_stock) < 1e-12
    central = stable["central_row53_action_MPa"]
    assert native_stock > 0. and central < 0.
    anchor = states["RayZero"]
    base_f = stations["RayZero"][2,1][6]
    results = {}
    for label, ratio in (("Ray-50",-.5),("Ray-25",-.25),("Ray25",.25),("Ray50",.5)):
        state, station = states[label], stations[label][2,1]
        observed = (state["r"][52]-anchor["r"][52]) / ratio
        assert (observed > 0.) == (label == "Ray-50")
        assert (station[3] == 0. and station[6] < 0.) == (label == "Ray-50")
        results[label] = {"ray_fraction":ratio, "trial_Qy_kN":state["q"],"row53_MPa":state["r"][52],
                          "row53_secant_MPa":observed, "full_residual_norm_MPa":state["norm_MPa"],
                          "point2_plus_yielding":bool(station[3]), "point2_plus_F_MPa":station[6]}
    points = {}
    for number in (2,22,5,23,27):
        measured = stable["all_station_values"][str(number)]
        predicted = fsum(side["stock_MPa"] for side in measured.values())
        observed = fsum(side["centered_MPa"] for side in measured.values())
        points[str(number)] = {"stock_action_MPa":predicted, "centered_action_MPa":observed,
                               "signed_difference_MPa":observed-predicted,
                               "signed_difference_by_side_MPa":{key:a["centered_MPa"]-a["stock_MPa"] for key,a in measured.items()}}
    global_diff = central-fresh_stock
    remaining = global_diff - fsum(points[str(p)]["signed_difference_MPa"] for p in (2,22))
    assert abs(remaining) < 5e-11
    assert all(abs(points[str(p)]["signed_difference_MPa"]) < 5e-12 for p in (5,23,27))
    result = {"raw_trace_sha256":v.digest(native), "native_report_sha256":v.digest(canonical),
              "stock_global_row53_action_MPa":native_stock,"new_stock_global_row53_action_MPa":fresh_stock,
              "stable_centered_row53_action_MPa":central,"stable_actual_minus_stock_MPa":global_diff,
              "stable_actual_minus_stock_outside_points2_22_MPa":remaining,
              "crossed_centered_row53_action_MPa":crossed["central_row53_action_MPa"],
              "stop_Qy_kN":anchor["q"],"stop_point2_plus_F_MPa":base_f,"directional_samples":results,
              "point_actions_at_stable_centered_scale":points,"accepted_history":"H24 unchanged","new_accepted_field":False}
    output = here / "RayScientificComparison.json"
    output.write_bytes((json.dumps(result,indent=2)+"\n").encode())
    print(output,v.digest(output))


if __name__ == "__main__":
    main()
