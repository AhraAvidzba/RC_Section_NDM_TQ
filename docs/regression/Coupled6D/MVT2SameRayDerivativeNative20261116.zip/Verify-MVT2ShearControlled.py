"""Independently replay the fixed-history derivative of the exact shifted ray."""
import argparse
import json
from math import fsum
from pathlib import Path

import VerifyBase as v

here = Path(__file__).resolve().parent
native = here / "NativeHalf"
ratios = {"Ray-50": -.5, "Ray-25": -.25, "Ray25": .25, "Ray50": .5}


def row(name):
    return tuple(map(float, (here / name).read_text(encoding="ascii").strip().split(";")))


def prepare():
    prep = v.read(here / "Preparation.json")
    assert all(v.digest(here / name) == sha for name, sha in prep["inputs"].items())
    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]
    raw = v.read_native(here / "ShiftNative.csv")
    states, stations = v.verified_states(raw)
    stop, trial = states["ShiftStop"], states["ShiftTrial"]
    ray = row("RayDirection.csv")
    assert row("RayStop.csv") == (*stop["field"], stop["q"])
    assert ray == tuple(map(float, raw["B_SHIFT_RAY"][0][1:]))
    assert v.peak(v.diff(trial["field"], tuple(a+b for a,b in zip(stop["field"],ray[:60],strict=True)))) < 6e-15
    assert abs(trial["q"]-stop["q"]-ray[-1]) < 2e-13
    old_row = tuple(map(float, raw["B_SHIFT_MATRIX"][52][1:]))
    return prep, states, stations, ray, old_row


def area_delta(old, new, point, side):
    a, b = old[point, side], new[point, side]
    return side * a[2] * (b[15]-a[15]) / (v.AREA * .002)


def verify(prep, previous, archived, ray, old_row):
    build = v.read(here / "docs/regression/CodeUpdate.json")
    compiler = v.read(here / "CompileClosure.json")
    owner = v.read(native / "MVT2.txt.Ownership.json")
    watch = v.read(native / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(native / "RunReceipt.json")
    final = watch["Closure"]["FinalState"]
    assert build["Compiled"] and build["Modules"] == ["modTestCoupledExperiment"] and not build["ProductionChanged"]
    assert build["ProductionSHA256"] == prep["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == build["WorkbookSHA256"]
    assert watch["Passed"] and watch["ChildExitCode"] == receipt["native_exit"] == 0 and watch["ChildHasExited"]
    assert final["State"] == "Absent" and final["PID"] == owner["PID"] and final["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    trace = native / "MVT2.csv"
    tags = v.read_native(trace)
    assert tags["B_FRESH_PHASE"] == [["Half"]]
    history = v.vec(tags, "MVT2_CONTROL_FIELD")
    replay = (here / "Replay.csv").read_text(encoding="ascii").splitlines()[1:]
    for i, line in enumerate(replay, 1):
        assert v.peak(v.diff(tuple(map(float,line.split(";")[9:])), history[f"Replay{i}"])) < 1e-15
    assert len(history) == len(replay) == 24
    states, stations = v.verified_states(tags)
    fields = v.vec(tags, "B_TANGENT_RESIDUAL")
    assert states["Base24"] == states["Restored24"] == previous["Base24"]
    assert stations["Base24"] == stations["Restored24"] == archived["Base24"]
    stored = {name: tuple(history) for name, *history in tags["B_ARC_HISTORY"]}
    assert set(stored) == {"RayBefore", "RayFinal", *ratios}
    assert all(values == stored["RayBefore"] and len(values) == 1080 for values in stored.values())
    base = states["RayZero"]
    orig = stations["RayZero"]
    assert base["q"] == previous["ShiftStop"]["q"] and base["field"] == previous["ShiftStop"]["field"]
    assert v.peak(v.diff(base["r"], previous["ShiftStop"]["r"])) < 4e-10
    assert max(abs(a-b) for key in orig for a,b in zip(orig[key][13:19],archived["ShiftStop"][key][13:19],strict=True)) < 4e-9
    p = row("MVTNormal.csv")
    available = {}
    for label, fraction, lam in tags["B_RAY_STEP"]:
        h = float(fraction)
        assert h == ratios[label] and abs(float(lam) - (base["q"] + h * ray[60])) < 6e-14
        if label not in states:
            assert [label, "Residual"] in tags["B_TANGENT_UNAVAILABLE"]
            continue
        field = states[label]
        assert field["q"] == float(lam)
        assert v.peak(v.diff(field["field"], tuple(a+h*b for a,b in zip(base["field"],ray[:60],strict=True)))) < 3e-15
        assert abs(v.dot(p[:60], v.diff(field["field"],base["field"])) + p[60]*(field["q"]-base["q"])) * v.MODULUS < 4e-9
        available[label] = h
    assert len(tags["B_RAY_STEP"]) == 4
    stock = {}
    for point, side, code, center, slope in tags["B_RAY_STOCK"]:
        key = int(point), int(side)
        assert key not in stock
        if int(code) == 0:
            weight = key[1] * orig[key][2] / (v.AREA * .002)
            stock[key] = (float(center)*weight, float(slope)*weight)
        else:
            stock[key] = None
    assert set(stock) == {(point,side) for point in range(1,46) for side in (-1,1)}
    parts = None
    if all(item is not None for item in stock.values()):
        parts = [fsum(item[index] for item in stock.values()) for index in (0,1)]
    original_parts = [v.dot(old_row[:52],ray[:52]),v.dot(old_row[52:56],ray[52:56])]
    faithful = parts is not None and v.peak(v.diff(parts,original_parts)) < 5e-9
    diagnostics = {}
    for lookup in (("Ray-25","Ray25"),("Ray-50","Ray50")):
        if not all(label in available for label in lookup):
            continue
        before, after = lookup
        h = available[after]
        minus, plus = stations[before], stations[after]
        direct = (fields[after][52]-fields[before][52])/(2*h)
        calculated = {}
        for point in range(1,46):
            local = {}
            for side in (-1,1):
                key = point,side
                centered = (area_delta(orig,plus,point,side)-area_delta(orig,minus,point,side))/(2*h)
                local[side] = {"centered_MPa":centered,
                               "plus_one_sided_MPa":area_delta(orig,plus,point,side)/h,
                               "minus_one_sided_MPa":-area_delta(orig,minus,point,side)/h,
                               "stock_MPa":sum(stock[key]) if stock[key] is not None else None}
            calculated[point] = local
        assert abs(direct-fsum(s["centered_MPa"] for point in calculated.values() for s in point.values())) < 2e-9
        branches = [(p,s) for p in range(1,26) for s in (-1,0,1) if
                    any(other[p,s][3:6] != orig[p,s][3:6] or other[p,s][6]*orig[p,s][6] < 0 for other in (minus,plus))]
        ranked = sorted(calculated, key=lambda pt:
                        abs(fsum(s["centered_MPa"]-(s["stock_MPa"] or 0) for s in calculated[pt].values())), reverse=True)
        diagnostics[str(h)] = {"central_row53_action_MPa":direct,"branch_switches_relative_to_zero":branches,
                               "ranked_local_departures":ranked,"all_station_values":calculated}
    return {"raw_sha256":v.digest(trace),"history_sha256":prep["replay_sha256"],"history_restored":True,
            "published":False,"native_compiler":compiler,"native_owner_closed":final,"native_wall_s":receipt["wall_seconds"],
            "original_stock_center_slope_MPa":original_parts,"fresh_stock_center_slope_MPa":parts,
            "fresh_stock_closes_original_matrix":faithful,"original_material_directional_measurements":diagnostics}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase",choices=["Half"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(here / "Preparation.json"))
    else:
        assert args.phase == "Half"
        report = here / "VerificationRay.json"
        report.write_bytes((json.dumps(verify(*frozen), indent=2)+"\n").encode())
        print(report,v.digest(report))
