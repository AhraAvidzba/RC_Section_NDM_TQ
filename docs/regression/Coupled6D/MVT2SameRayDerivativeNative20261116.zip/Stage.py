"""Stage the fixed H24 original-law derivative stencil without invoking Office."""
import json
from hashlib import sha256
from pathlib import Path
import sys


here = Path(__file__).resolve().parent
shift = here.parent / "mvts"
original = here.parent / "mvt-next/arc-ab"
runner_base = here.parent / "mvt-next/jetb"
book = "workbook/output/RC_Section_NDM.xlsm"
sys.path.insert(0, str(shift))
import VerifyBase as v


def save(name, raw):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return v.digest(path)


def csv_line(items):
    return (";".join(map(str, items)) + "\r\n").encode("ascii")


def main():
    assert v.digest(shift / "Preparation.json") == "7FAB47341CDC931EE31F029F542E0E4BEC30BAF43EC47F05E5844C586A42A6B5"
    manifest = v.read(shift / "Preparation.json")
    inputs = {}
    for name in ("Replay.csv", "VerifyBase.py", "Guard-IsolatedOffice.ps1", "MVTNormal.csv",
                 *(name for name in manifest["inputs"] if name.startswith("tools/"))):
        raw = (shift / name).read_bytes()
        assert sha256(raw).hexdigest().upper() == manifest["inputs"][name], name
        inputs[name] = save(name, raw)
    assert v.digest(shift / book) == manifest["book_sha256"]
    save(book, (shift / book).read_bytes())
    save("docs/regression/Diagnostic.xlsm", (shift / book).read_bytes())
    for directory in ("src", "NativeHalf", "Temp"):
        (here / directory).mkdir(exist_ok=True)
    archived = shift / "NativeCompare/MVT2.csv"
    assert v.digest(archived) == "7F36511004C965E75D2076076ADE36DC4F9E3079671AE226423B23F12810794D"
    inputs["ShiftNative.csv"] = save("ShiftNative.csv", archived.read_bytes())
    tags = v.read_native(archived)
    fields = {name: (float(q), tuple(map(float, entries))) for name, _, q, *entries in tags["B_TANGENT_FIELD"]}
    lam, q = fields["ShiftStop"]
    [_, *ray] = tags["B_SHIFT_RAY"][0]
    fraction = float(tags["B_SHIFT_TRACE"][0][8])
    assert len(ray) == 61 and fraction == 1.
    inputs["RayStop.csv"] = save("RayStop.csv", csv_line((*q, lam)))
    inputs["RayDirection.csv"] = save("RayDirection.csv", csv_line(ray))

    raw = (original / "Control.bas").read_bytes()
    assert sha256(raw).hexdigest().upper() == "CD49BC3CA3CF38549794EF7901C1E87C4808B9FF57B036E0E9124CB24FF5313E"
    control = raw.decode("utf-8")
    old = '''    If phase <> "Compare" Then Err.Raise 5, , "Неизвестная фаза сравнения MVT2."
    ProbeWangArcComparisonTest output, folder, history, solver, operators, materials, responses, base, qBase, qTrial'''
    assert control.count(old) == 1
    control = control.replace(old, '''    If phase <> "Half" Then Err.Raise 5, , "Неизвестная фаза луча MVT2."
    ProbeWangSameRayTest output, folder, history, solver, operators, materials, responses, base''')
    control = control.replace("' Сравнивает усилие и плоскость псевдодуги при одной истории MVT2 B.",
                              "' Измеряет двустороннее действие исходного материала MVT2 B.")
    boundary = "' -------------------- ДЛЯ ТЕСТОВ --------------------"
    start = control.rindex(boundary, 0, control.index("Private Sub ProbeWangArcComparisonTest"))
    end = control.rindex(boundary, 0, control.index("Private Sub CaptureWangArcHistoryTest"))
    control = control[:start] + (here / "RayProbe.bas").read_text(encoding="utf-8") + "\n" + control[end:]
    inputs["Control.bas"] = save("Control.bas", control.encode("utf-8"))
    test = "tests/modTestCoupledExperiment.bas"
    raw = (shift / test).read_bytes()
    assert sha256(raw).hexdigest().upper() == manifest["inputs"][test]
    text = raw.decode("utf-8").replace("\r\n", "\n")
    start = text.rindex(boundary, 0, text.index("Public Function RunTestWangShearControlled("))
    inputs[test] = save(test, (text[:start] + control).replace("\n", "\r\n").encode("utf-8"))
    name = "Run-MVT2ShearControlled.ps1"
    raw = (runner_base / name).read_bytes()
    assert sha256(raw).hexdigest().upper() == v.read(runner_base / "Preparation.json")["inputs"][name]
    inputs[name] = save(name, raw)
    for name in ("Stage.py", "RayProbe.bas", "Verify-MVT2ShearControlled.py", "AnalyzeShiftStations.py", "ShiftStationAnalysis.json"):
        inputs[name] = v.digest(here / name)
    prep = {"book_sha256": manifest["book_sha256"], "replay_sha256": manifest["replay_sha256"],
            "watchdog_seconds": 100, "inputs": inputs}
    print(save("Preparation.json", (json.dumps(prep, indent=2) + "\n").encode()))


if __name__ == "__main__":
    main()
