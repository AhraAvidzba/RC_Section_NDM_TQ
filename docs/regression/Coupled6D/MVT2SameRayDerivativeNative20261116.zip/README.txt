Directional native check of the stocked tangent action at the MVT2 B stall

From an extracted directory run with the Python standard library

    python -B -X utf8 VerifyRayPortable.py PATH/MVT2HalfJointJetNative20261116.zip PATH/MVT2SafeguardedTangentShift20261116.zip

The two pinned archives are already tracked under docs/regression/Coupled6D.
The manifest resolves identical shared source and raw files without duplicate
copies. The compiled workbook is not included. Its input and native ownership
identity are checked from the original private launch and closure receipts.

The original constitutive laws, H24 history and saved 61-component shifted
ray are reproduced. Station readings at 0, minus/plus 1/4 and 1/2 are used
to calculate signed axial-action sensitivities. Six forces, the 56 weak
equations, four gauges and arc plane are reconstructed independently.
No trial was accepted and the exact H24 observables remained unchanged.

The same-branch quarter-radius centered derivative of weak equation 53
is -9.387760750941216e-6 MPa per full shifted-ray fraction. The remeasured
stock derivative agrees with the archived linear action +7.257838915622285e-5
MPa. Concrete points 2 and 22 explain the entire stable discrepancy.
Point 2 on its positive axial station changes yielding only at minus 1/2,
so the resulting central half-radius derivative includes a branch transition.
This evidence diagnoses the local tangent, without finding a load limit.
