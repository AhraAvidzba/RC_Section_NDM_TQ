"""Reconstruct the exact shifted-row action by original material station."""
from decimal import Decimal as D
from math import fsum
import json
from pathlib import Path
import sys


here = Path(__file__).resolve().parent
shift = here.parent / "mvts"
sys.path.insert(0, str(shift))
import VerifyBase as v


def contribution(before, after, point):
    area = before[point, 0][2]
    # Row 53 projects d(sigma_z)/dz with unit axial coefficient.
    minus = -(after[point, -1][15] - before[point, -1][15]) * area / (v.AREA * .002)
    plus = (after[point, 1][15] - before[point, 1][15]) * area / (v.AREA * .002)
    return plus, minus


def main():
    trace = shift / "NativeCompare/MVT2.csv"
    assert v.digest(trace) == "7F36511004C965E75D2076076ADE36DC4F9E3079671AE226423B23F12810794D"
    tags = v.read_native(trace)
    states, stations = v.verified_states(tags)
    before, after = stations["ShiftStop"], stations["ShiftTrial"]
    expected = states["ShiftTrial"]["r"][52] - states["ShiftStop"]["r"][52]
    groups = {"concrete": [], "longitudinal_replacement": [], "hoop_replacement": []}
    output, branches = [], []
    for point in range(1, 46):
        group = "concrete" if point <= 25 else "longitudinal_replacement" if point <= 29 else "hoop_replacement"
        plus, minus = contribution(before, after, point)
        groups[group].append(plus + minus)
        data = {"point": point, "x_y": before[point, 0][:2], "group": group,
                "contribution_MPa": plus + minus, "plus_MPa": plus, "minus_MPa": minus}
        if point <= 25:
            data["side_values"] = [
                {"side": side, "from_F": before[point, side][6], "to_F": after[point, side][6],
                 "plastic_principal_substeps": before[point, side][3:6]} for side in (-1, 0, 1)]
            for side in (-1, 0, 1):
                a, b = before[point, side], after[point, side]
                if a[3:6] != b[3:6] or a[6] * b[6] <= 0.:
                    branches.append((point, side))
        output.append(data)
    assert not branches
    measured = fsum(data["contribution_MPa"] for data in output)
    assert abs(measured - expected) < 6e-14
    # Raw stress at each signed endpoint contributes one half-unit at its
    # scale. Their absolute sum bounds cancellation of the extracted row.
    bound_terms = []
    for lab, p, side, *values in tags["B_TANGENT_STATION"]:
        if lab in ("ShiftStop", "ShiftTrial") and side != "0":
            stress, area = D(values[15]), D(values[2])
            if stress:
                bound_terms.append(D(1).scaleb(stress.copy_abs().adjusted()-14) * area / D("230.4"))
    wire_bound = sum(bound_terms)
    matrix = [tuple(map(float, row[1:])) for row in tags["B_SHIFT_MATRIX"]]
    ray = tuple(map(float, tags["B_SHIFT_RAY"][0][1:]))
    fraction = float(tags["B_SHIFT_TRACE"][0][8])
    row53 = matrix[52]
    center = fraction * v.dot(row53[:52], ray[:52])
    slope = fraction * v.dot(row53[52:56], ray[52:56])
    tail = fraction * v.dot(row53[56:], ray[56:])
    diagnostic = {"raw_sha256": v.digest(trace), "original_law_actual_row53_MPa": measured,
                  "reconstructed_global_row53_MPa": expected, "wire_bound_MPa": str(wire_bound),
                  "signed_group_totals_MPa": {name: fsum(items) for name, items in groups.items()},
                  "stock_linear_partition_MPa": {"center": center, "slope": slope, "reactions_and_load": tail},
                  "changed_concrete_stations": branches,
                  "points": sorted(output, key=lambda row: abs(row["contribution_MPa"]), reverse=True)}
    report = here / "ShiftStationAnalysis.json"
    report.write_bytes((json.dumps(diagnostic, indent=2) + "\n").encode())
    print(report, v.digest(report))


if __name__ == "__main__":
    main()
