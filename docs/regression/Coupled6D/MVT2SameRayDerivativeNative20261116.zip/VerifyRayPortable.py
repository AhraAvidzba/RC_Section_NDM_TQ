"""Replay the native stencil and both scientific reports with archived dependencies."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile


root = Path(__file__).resolve().parent
phase_sha = "1242A059FBBF5E2128ABD94774A48D68C7A54CE33CC937055F808602B746C8D6"
summary_sha = "17967B4908E809B9DC338853B02C97F19817F0E2CDA03C15BDED5DC8C1D6581F"
station_sha = "F7162629385506B6050BE40E88CD6E12D3E0EA7F04AB4644E7065221C3F1CCFF"
jet_sha = "6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33"
shift_sha = "688E1CB09A1FC7E4A4976FEA214BB4E0A9DADA0FE042BBBB6AFA55D1EA9B0979"
book_sha = "8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def verify_native(work):
    entry = work / "Verify-MVT2ShearControlled.py"
    src = entry.read_text(encoding="utf-8")
    guard = '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]'
    assert src.count(guard) == 1
    src = src.replace(guard, f'    assert prep["book_sha256"] == "{book_sha}"')
    scope = {"__file__":str(entry), "__name__":"portable"}
    sys.path.insert(0,str(work))
    try:
        exec(compile(src,str(entry),"exec"), scope)
        report = scope["verify"](*scope["prepare"]())
    finally:
        sys.path.pop(0)
    return (json.dumps(report,indent=2)+"\n").encode("utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jet_archive",type=Path)
    parser.add_argument("shift_archive",type=Path)
    args = parser.parse_args()
    for path, expected in ((args.jet_archive,jet_sha),(args.shift_archive,shift_sha)):
        assert digest(path.read_bytes()) == expected
    manifest = json.loads((root / "PortableManifest.json").read_bytes())
    with (tempfile.TemporaryDirectory() as folder, ZipFile(args.jet_archive) as jet,
          ZipFile(args.shift_archive) as shift):
        work = Path(folder) / "mvtr"
        archives = {"jet":jet,"shift":shift}
        for name, record in manifest.items():
            archive = record.get("archive")
            raw = ((root/name).read_bytes() if archive is None else archives[archive].read(record["member"]))
            assert digest(raw) == record["sha256"], name
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        prior = work.parent / "mvts"
        (prior/"NativeCompare").mkdir(parents=True)
        (prior/"NativeCompare/MVT2.csv").write_bytes((work/"ShiftNative.csv").read_bytes())
        (prior/"VerifyBase.py").write_bytes((work/"VerifyBase.py").read_bytes())
        actual = verify_native(work)
        assert digest(actual) == phase_sha and actual == (work/"VerificationRay.json").read_bytes()
        subprocess.run((sys.executable,"-B","-X","utf8","AnalyzeRayResult.py"),cwd=work,check=True)
        subprocess.run((sys.executable,"-B","-X","utf8","AnalyzeShiftStations.py"),cwd=work,check=True)
        assert digest((work/"RayScientificComparison.json").read_bytes()) == summary_sha
        assert digest((work/"ShiftStationAnalysis.json").read_bytes()) == station_sha
        print("CANONICAL NATIVE STENCIL",phase_sha)


if __name__ == "__main__":
    main()
