
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет один записанный луч по обе стороны остановки при неизменной H24.
' Ни одна точка стенда не публикуется в историю материала.
Private Sub ProbeWangSameRayTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef base() As Double)
    Dim origin() As Double, ray() As Double, field() As Double, q0 As Double, qray As Double
    ReadWangRayVectorTest folder & "RayStop.csv", origin, q0
    ReadWangRayVectorTest folder & "RayDirection.csv", ray, qray
    Dim stockHistory() As Double, checkedHistory() As Double, norm As Double, actual() As Double, weak() As Double
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "RayBefore", operators, materials, stockHistory
    norm = RecordWangTangentStateTest(output, "RayZero", 24, q0, solver, operators, materials, responses, origin, actual, weak)
    If norm < 0# Then Err.Raise 5, , "Не воспроизведено поле остановки MVT2."
    ReadWangRayStockActionsTest output, operators, responses, origin, ray
    Dim ratio As Variant, label As String, i As Long, factor As Double
    For Each ratio In Array(-0.5, -0.25, 0.25, 0.5)
        label = "Ray" & CStr(CLng(100# * CDbl(ratio)))
        RestoreWangShearBaselineTest solver, history, base
        field = origin
        For i = 1 To 60: field(i) = field(i) + CDbl(ratio) * ray(i): Next i
        factor = q0 + CDbl(ratio) * qray
        Print #output, "B_RAY_STEP;" & label & ";" & ExperimentNumberTest(CDbl(ratio)) & ";" & ExperimentNumberTest(factor)
        norm = RecordWangTangentStateTest(output, label, 24, factor, solver, operators, materials, responses, field, actual, weak)
        RequireWangAcceptedFieldTest solver, base
        CaptureWangArcHistoryTest output, label, operators, materials, checkedHistory
        RequireWangArcHistoryTest stockHistory, checkedHistory
    Next ratio
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "RayFinal", operators, materials, checkedHistory
    RequireWangArcHistoryTest stockHistory, checkedHistory
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает ровно 60 координат и составляющую параметра для замороженного луча.
Private Sub ReadWangRayVectorTest(ByVal path As String, ByRef field() As Double, ByRef factor As Double)
    Dim stream As Integer, raw As String, terms As Variant, i As Long
    stream = FreeFile: Open path For Input As #stream
    Line Input #stream, raw
    If Not EOF(stream) Then Err.Raise 5, , "Лишние строки луча MVT2."
    Close #stream
    terms = Split(raw, ";")
    If UBound(terms) <> 60 Then Err.Raise 5, , "Неверная длина луча MVT2."
    ReDim field(1 To 60)
    For i = 1 To 60: field(i) = Val(terms(i - 1)): Next i
    factor = Val(terms(60))
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает местное действие штатной касательной на точное приращение луча.
' Слагаемые центра и продольного уклона записываются отдельно.
Private Sub ReadWangRayStockActionsTest(ByVal output As Integer, ByVal operators As CCoupledElasticState, _
        ByRef responses() As ICoupledPointResponse, ByRef origin() As Double, ByRef ray() As Double)
    Dim p As Long, side As Long, i As Long
    Dim center(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim rayCenter(1 To 6) As Double, raySlope(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim fromCenter As Double, fromSlope As Double, code As ESolverFailureCode
    For p = 1 To operators.PointCount
        operators.PointStrain p, origin, center
        operators.AxialGradientAtPoint p, origin, slope
        operators.PointStrain p, ray, rayCenter
        operators.AxialGradientAtPoint p, ray, raySlope
        For side = -1 To 1 Step 2
            For i = 1 To 6: station(i) = center(i) + side * 0.001 * slope(i): Next i
            code = responses(side).EvaluatePoint(p, station, stress, tangent, ctmFull, False)
            fromCenter = 0#: fromSlope = 0#
            If code = sfcNone Then
                For i = 1 To 6
                    fromCenter = fromCenter + tangent(3, i) * rayCenter(i)
                    fromSlope = fromSlope + tangent(3, i) * raySlope(i) * side * 0.001
                Next i
            End If
            Print #output, "B_RAY_STOCK;" & CStr(p) & ";" & CStr(side) & ";" & CStr(code) & ";" & _
                ExperimentNumberTest(fromCenter) & ";" & ExperimentNumberTest(fromSlope)
        Next side
    Next p
End Sub
