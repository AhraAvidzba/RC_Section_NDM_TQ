"""Recreate the exact completed mixed native report and its four-curve comparison."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path, PurePosixPath
import runpy
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
BOOK_COMMIT = "709e7dfa16c192748fc2c6d999925bdbf9948a4c"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
NATIVE_REPORT = "VerificationMVTGaussMixed.json"
NATIVE_SHA = "96D0D88C548528D04BCFBA5F9117CFA9F0C797CD7C9FE6EFA464ACA28F79CF0F"
CURVES = "VerifiedCurveComparison.json"
CURVES_SHA = "6FD874839553F80CA74CEE040D983FDDF17D7E57CFC37C24BA82FA96F4B2C962"


def digest(data):
    return sha256(data).hexdigest().upper()


def check_manifest():
    contents = {}
    for line in (HERE/"SHA256SUMS").read_text(encoding="ascii").splitlines():
        expected,name = line.split("  ",1)
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts
        assert name not in contents and not name.lower().endswith(".xlsm")
        data = (HERE/name).read_bytes()
        assert digest(data)==expected
        contents[name]=data
    assert set(contents)=={p.relative_to(HERE).as_posix() for p in HERE.rglob("*")
                           if p.is_file() and p.name!="SHA256SUMS"}
    return contents


def exact_book(path, repo):
    if path is not None:
        data = path.read_bytes()
    else:
        current = repo / BOOK
        data = current.read_bytes() if current.is_file() else b""
        if digest(data) != BOOK_SHA:
            data = subprocess.check_output(["git","-C",str(repo),"show",f"{BOOK_COMMIT}:{BOOK}"])
    assert digest(data)==BOOK_SHA
    return data


def replay(book, repo):
    contents=check_manifest()
    assert digest(contents[NATIVE_REPORT])==NATIVE_SHA
    assert digest(contents[CURVES])==CURVES_SHA
    with tempfile.TemporaryDirectory(prefix="MVGLMixedReplay_") as name:
        work = Path(name)
        for leaf,data in {**contents,BOOK:exact_book(book,repo)}.items():
            target=work/leaf
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
        runpy.run_path(str(work/"Verify-Mixed.py"))["main"]()
        assert (work/NATIVE_REPORT).read_bytes()==contents[NATIVE_REPORT]
        compare=runpy.run_path(str(work/"Compare-Curves.py"))["content"]
        assert compare(repo,work/NATIVE_REPORT)==contents[CURVES]
        print("PASS exact matched signed right-window curve comparison",CURVES_SHA)


if __name__=="__main__":
    args=ArgumentParser()
    args.add_argument("--book",type=Path)
    args.add_argument("--repo",type=Path,default=Path.cwd())
    opts=args.parse_args()
    replay(opts.book,opts.repo)
