"""Independently reconstruct the four right-window comparisons from sealed data."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json

HERE = Path(__file__).resolve().parent
ARCHIVES = {
    "pure_Gauss": ("MVT2GaussSpanNative20261117", "71DC4A17F7E648043DF52F423C8419E74A93B96944F9501D48102E04CFDC14C2"),
    "refined_midpoint": ("MVT2MixedAdaptiveNative20261117", "300ACEADD3033A627969BA1DBA7CB7EDC7FCD51632C4907CDA162758C8FDA990"),
    "original_midpoint": ("MVT2NDMSignedWindow20261117", "F33926B1BC77BCD2E736DC39520CF66DCCA98CF630A51110D7C293FFE1861C25"),
    "OpenSees": ("MVT2OpenSeesHeldTQ1520261117", "0CF1E1AD6A6FC0F2DB821A0F49A871DBAD03FED4D5EA11EA2A262EA01AC2E745"),
}
MIXED = "96D0D88C548528D04BCFBA5F9117CFA9F0C797CD7C9FE6EFA464ACA28F79CF0F"


def digest(data):
    return sha256(data).hexdigest().upper()


def read_archive(repo, key):
    name, expected = ARCHIVES[key]
    data = (repo / "docs/regression/Coupled6D" / f"{name}.zip").read_bytes()
    assert digest(data) == expected, name
    return ZipFile(BytesIO(data))


def ndm_rows(data):
    result = {}
    for line in data.decode("cp1251").splitlines():
        kind, *r = line.split(";")
        if kind == "MVT2_STATE":
            assert r[0] not in result
            result[r[0]] = tuple(map(float,r[1:]))
    return result


def external_twist(row):
    return row["displacement"]["clear_twist_rad_per_m"]["right"]


def q_match(row, q):
    """Check local faces in N, Nmm before any transport to physical midspan."""
    cuts = {c["z_mm"]: c for c in row["rig_balance"]["cuts"]}
    max_error = 0.
    for z, arm in ((1340., 360.),(1400.,300.)):
        expected = (0., -arm*q*1e3, 0., 10.51e6, 0., q*1e3)
        for actual in cuts[z]["low_and_high_face"]:
            for i,(a,b) in enumerate(zip(actual,expected,strict=True)):
                scale = 240. if 1 <= i <= 3 else 1.
                max_error = max(max_error,abs(a-b)/scale)
    assert max_error < .05
    return max_error


def compare(repo, native_proof):
    gl_mixed = native_proof.read_bytes()
    assert digest(gl_mixed) == MIXED
    gl = json.loads(gl_mixed)
    assert gl["reached_Qy15"] and gl["cold_gauss_preload_identical"]
    with read_archive(repo,"pure_Gauss") as z:
        gauss_data = json.loads(z.read("VerificationMVTGauss.json"))
        frozen = z.read("Native/MVTGauss.csv")
        assert digest(b"".join(frozen.splitlines(keepends=True)[:-1])) == gl["pure_preload_sha256"]
    with read_archive(repo,"refined_midpoint") as z:
        data100 = json.loads(z.read("Casemixed/Verification.json"))
        native100 = z.read("Casemixed/Native/RightAdaptiveMixed10.csv")
        cold100 = z.read("Case10/Native/RightAdaptive10.csv")
        assert digest(native100) == data100["trace_sha256"] and native100.startswith(cold100)
        assert data100["exact_Q15"] and data100["pure_torsion_prefix_checked_bytewise"]
    with read_archive(repo,"original_midpoint") as z:
        midpoint = ndm_rows(z.read("Fine15/Native/Right330.csv"))
        comparison = json.loads(z.read("VerifiedFine15.json"))["comparison"]
    with read_archive(repo,"OpenSees") as z:
        raw_os = z.read("HeldTQ15Native.json")
        os = json.loads(raw_os)
        os_check = json.loads(z.read("VerificationHeldTQ15.json"))
        assert digest(raw_os) == os_check["native_sha256"]
        assert os_check["last_verified_Qy_kN"] == 15. and os_check["process_closed"]
        assert os["last_certified_Qy_kN"] == 15. and os["held_torsion_kNm"] == 10.51
    ndm100 = ndm_rows(native100)
    ext = [os["base_Q5_state"], *os["shear_confirmed_states"]]
    ref = {"NDM_midpoint25":midpoint["R7"][11], "NDM_midpoint100":ndm100["R7"][11],
           "NDM_Gauss25":gauss_data["stages"][-1]["twist_rad_per_m"],
           "OpenSees":external_twist(os["replay_states"][-1])}
    assert ref["OpenSees"] == comparison[6]["OpenSees_right_window_rad_per_m"]
    out = []
    for i,(s,m,d,e) in enumerate(zip(gl["accepted_goals"],data100["states"],comparison[7:],ext,strict=True),1):
        q = s["Qy_kN"]
        assert q == m["Qy_kN"] == d["Qy_kN"] == e["Qy_kN"]
        assert abs(s["Mx_kNm"] + q*.330) < 1e-14 and s["T_kNm"] == m["T_kNm"] == d["T_kNm"] == 10.51
        normalized_external_residual = q_match(e, q)
        osc = external_twist(e)
        c25 = midpoint[f"R{i+7}"][11]
        c100 = ndm100[f"S{i}"][11]
        assert osc == m["OpenSees_right_window_twist_rad_per_m"] == d["OpenSees_right_window_rad_per_m"]
        assert c25 == m["NDM_original_center_twist_rad_per_m"] == d["NDM_twist_by_arm_rad_per_m"]["330"]
        assert c100 == m["NDM_refined_center_twist_rad_per_m"]
        sample = {"NDM_midpoint25":c25, "NDM_midpoint100":c100,
                  "NDM_Gauss25":s["twist_rad_per_m"], "OpenSees":osc}
        delta = {k:value-ref[k] for k,value in sample.items()}
        out.append({"Qy_kN":q, "local_Mx_kNm":s["Mx_kNm"], "T_kNm":s["T_kNm"],
                    "external_60mm_Mx_end_values_kNm":[-.360*q,-.300*q],
                    "twist_rad_per_m":sample,"change_since_pure_T_rad_per_m":delta,
                    "total_twist_relative_to_OpenSees":{k:v/osc for k,v in sample.items()},
                    "twist_change_relative_to_OpenSees":{k:v/delta["OpenSees"] for k,v in delta.items()},
                    "max_OpenSees_cut_force_error_N_equivalent":normalized_external_residual})
    assert len(out) == 18 and out[-1]["Qy_kN"] == 15.
    return {"status":"PASS","native_mixed_proof_sha256":MIXED,"dependent_archive_names_and_sha256":ARCHIVES,
            "pure_T_kNm":10.51,"pure_T_twist_rad_per_m":ref,
            "states":out,"constitutive_laws_equated":False,"physical_limit_established":False}


def content(repo, native_proof):
    return (json.dumps(compare(repo,native_proof),indent=2,sort_keys=True)+"\n").encode()


if __name__ == "__main__":
    parser=ArgumentParser()
    parser.add_argument("--repo",type=Path,default=Path.cwd())
    parser.add_argument("--proof",type=Path,default=HERE/"VerificationMVTGaussMixed.json")
    parser.add_argument("--out",type=Path)
    args=parser.parse_args()
    data=content(args.repo,args.proof)
    if args.out:
        with args.out.open("xb") as s: s.write(data)
    print("PASS exact compared curves SHA256",digest(data))
