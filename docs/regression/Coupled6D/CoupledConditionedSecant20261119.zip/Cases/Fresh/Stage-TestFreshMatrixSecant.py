"""ДЛЯ ТЕСТОВ. Проверяет обновление полной касательной после каждой принятой dogleg-поправки."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Параметризация, материалы и исходные критерии неизменны; сравнивается только стратегия матрицы."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestSecantProjection.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledHybridSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '            algebra.Update movement, nextResidual, model, movementNorm, accepted'
    assert code.count(old) == 1
    code = code.replace(old, '''            If accepted Then Exit Do ' ДЛЯ ТЕСТОВ: следующая поправка использует новую полную производную, без секущего обновления.
''' + old, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    changes = {
        '    For index = 1 To 4': '    For index = 1 To 1',
        '        For probeVariant = 0 To 4': '        For probeVariant = 3 To 6',
        '            If probeVariant > 0 Then absTol = GeomMin(absTol, 0.0000000001): relTol = GeomMin(relTol, 0.0000000001)': '',
        '                If probeVariant = 4 Then ratio = 1#': '                If probeVariant Mod 2 = 0 Then ratio = 1#',
        '    Dim targetValue As Double, movement() As Double, controlCoordinate As Double, controlSpacing As Double':
            '    Dim targetValue As Double, movement() As Double, controlCoordinate As Double, controlSpacing As Double, iterationBudget As Long',
        '            seedVariant = seed: started = Timer': '''            iterationBudget = 30
            If probeVariant >= 5 Then iterationBudget = 60
            seedVariant = seed: started = Timer''',
        'absTol, relTol, CLng(options(2)), initialField:=seedVariant, allowHybridRecovery:=(probeVariant > 0))':
            'absTol, relTol, iterationBudget, initialField:=seedVariant, allowHybridRecovery:=True)',
        'stats(0) > options(2)': 'stats(0) > iterationBudget',
        '            Print #handle, "TOLERANCE;"': '''            Print #handle, "BUDGET;" & CStr(probeVariant) & ";" & CStr(iterationBudget)
            Print #handle, "TOLERANCE;"'''}
    for old, new in changes.items():
        assert code.count(old) == 1, old
        code = code.replace(old, new, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'FreshCompleteMatrixSecant', 'budgets': [30, 60],
        'accepted_step_rebuilds_full_jacobian': True, 'native_acceptance_uses_original_tolerance': True,
        'runtime_source_changed': False, 'matrix_policy_only_in_private_book': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('FRESH COMPLETE MATRIX SECANT CONTROL READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
