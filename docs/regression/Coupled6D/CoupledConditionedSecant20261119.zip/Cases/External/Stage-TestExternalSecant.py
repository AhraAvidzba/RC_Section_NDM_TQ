"""ДЛЯ ТЕСТОВ. Удерживает точную историю после 26-го поля для независимого решения полной секущей меры."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Материальные отклики остаются в VBA; внешний TRF получает только ту же полную невязку."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestReversePolish.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    declarations = '''
#If VBA7 Then
Private Declare PtrSafe Sub TestHybridSleep Lib "kernel32" Alias "Sleep" (ByVal milliseconds As Long)
#Else
Private Declare Sub TestHybridSleep Lib "kernel32" Alias "Sleep" (ByVal milliseconds As Long)
#End If
Private mStoredSolverTest As CCoupledNewtonSolver, mStoredOperatorsTest As CCoupledElasticState
Private mStoredConcreteTest As CCoupledConcreteResponse, mStoredReinforcedTest As CCoupledReinforcedResponse
Private mStoredSidesTest As Collection, mStoredFieldsTest As Collection, mStoredTraceTest As CCoupledLoadTrace
Private mStoredFieldTest() As Double, mStoredBaseTest() As Double, mStoredDirectionTest() As Double, mStoredProjectionTest() As Double
Private mStoredExternalTest() As Double, mStoredDirectionExternalTest() As Double
Private mStoredFactorTest As Double, mStoredTargetTest As Double, mStoredArcTest As Double, mStoredModulusTest As Double
Private mStoredCalibrationTest As Variant, mStoredOptionsTest As Variant
'''
    assert code.count('Option Explicit\n') == 1
    code = code.replace('Option Explicit\n', 'Option Explicit\n' + declarations, 1)
    body = '''Public Sub TestRunReversePolishModel(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal reinforced As CCoupledReinforcedResponse, ByVal sides As Collection, _
        ByVal path As CLoadPathVector, ByVal calibration As Variant, ByVal options As Variant)
    Set mReverseSolverTest = solver: Set mReverseOperatorsTest = operators
    mReverseCalibrationTest = calibration: mReverseOptionsTest = options
    path.Components mReverseBaseTest, mReverseDirectionTest
    Dim fields As Collection, trace As CCoupledLoadTrace, previous() As Double, accepted() As Double
    Dim original() As Double, projection() As Double, context() As Double
    TestReadPolishSnapshot mPolishRootTest & "\\Input\\Reverse1.bin", fields, trace, previous, accepted, original, projection, context
    If Not solver.ReplayAcceptedFields(fields, fields.Count) Then Err.Raise 5, , "Не восстановлена удерживаемая история."
    Set mStoredSolverTest = solver: Set mStoredOperatorsTest = operators
    Set mStoredConcreteTest = concrete: Set mStoredReinforcedTest = reinforced: Set mStoredSidesTest = sides
    Set mStoredFieldsTest = fields: Set mStoredTraceTest = trace
    mStoredCalibrationTest = calibration: mStoredOptionsTest = options: mStoredModulusTest = calibration(0)
    mStoredBaseTest = mReverseBaseTest: mStoredDirectionTest = mReverseDirectionTest
    Dim movement() As Double, degree As Long, coordinate As Double, spacing As Double
    movement = accepted
    For degree = 1 To UBound(movement): movement(degree) = accepted(degree) - previous(degree): Next degree
    If Not solver.SelectSpatialDirectionControl(previous, accepted, movement, mStoredProjectionTest, coordinate, spacing) Then _
        Err.Raise 5, , "Не построена полная секущая мера."
    mStoredTargetTest = coordinate + 0.5 * spacing: mStoredArcTest = 0#
    mStoredFieldTest = accepted
    For degree = 1 To solver.PhysicalDegreeCount: mStoredFieldTest(degree) = accepted(degree) + 0.5 * movement(degree): Next degree
    Dim fraction As Double, currentFactor As Double, previousFactor As Double
    trace.ReadPoint fields.Count, fraction, currentFactor
    trace.ReadPoint fields.Count - 1, fraction, previousFactor
    mStoredFactorTest = currentFactor + 0.5 * (currentFactor - previousFactor)
    operators.LoadEquations mStoredBaseTest(1), mStoredBaseTest(2), mStoredBaseTest(3), mStoredBaseTest(4), _
        mStoredBaseTest(5), mStoredBaseTest(6), mStoredExternalTest
    operators.LoadEquations mStoredDirectionTest(1), mStoredDirectionTest(2), mStoredDirectionTest(3), mStoredDirectionTest(4), _
        mStoredDirectionTest(5), mStoredDirectionTest(6), mStoredDirectionExternalTest
    mHardPreparedPathTest = mPolishRootTest & "\\Native\\ExternalSecant"
    Dim handle As Integer: handle = FreeFile
    Open mHardPreparedPathTest & ".Context.csv" For Output As #handle
    Print #handle, "TARGET;" & TestOnsetNumber(mStoredTargetTest)
    Print #handle, "PROJECTION" & TestHardPreparedVector(mStoredProjectionTest)
    Print #handle, "SEED" & TestHardPreparedVector(mStoredFieldTest)
    Print #handle, "INITIAL_LAMBDA;" & TestOnsetNumber(mStoredFactorTest)
    Close #handle
    TestRunSecantBridge
    mPolishExecutedTest = True
End Sub'''
    code, count = re.subn(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', lambda _: body, code)
    assert count == 1
    stored = (here / 'TestNativeStoredStall.bas.txt').read_text('utf-8-sig')
    for method in ('TestStoredVector', 'TestStoredEvaluate', 'TestStoredValidate', 'TestStoredExportCandidate', 'TestStoredServeRequest'):
        block, = re.findall(r'(?ms)^Private (?:Function|Sub) ' + method + r'\(.*?^End (?:Function|Sub)', stored)
        block = block.replace('    FineOrdinaryCDPTangentTest = True\n', '')
        block = block.replace('TestHardStallLinearization(field, withMatrix, 0, weak, matrix)',
                              'TestEquilibriumLinearization(field, withMatrix, False, weak, matrix)')
        code += "\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Обслуживает неизменный контрольный контекст; не изменяет рабочую книгу.\n" + block + '\n'
    bridge, = re.findall(r'(?ms)^    Dim folder As String: folder = outputRoot.*?^    Close #handle', stored)
    bridge = bridge.replace('outputRoot', 'mPolishRootTest')
    code += "\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Запускает ограниченный внешний контроль в скрытом собственном процессе; история и материалы остаются в VBA.\nPrivate Sub TestRunSecantBridge()\n" + bridge + '\nEnd Sub\n'
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'TestHybridOptimizer.py'
    code = (here / name).read_text('utf-8-sig')
    old = '''            x = seed + scale * y
            matrix = TestRequest('J', x)
            assert matrix.shape == (61 * 61,) and np.all(np.isfinite(matrix))
            return matrix.reshape(61, 61) * scale[None, :]'''
    assert code.count(old) == 1
    code = code.replace(old, '''            matrix = np.empty((61, 61))
            for column in range(61):
                step = 1e-6 * max(1., abs(float(y[column])))
                plus, minus = y.copy(), y.copy()
                plus[column] += step
                minus[column] -= step
                matrix[:, column] = (TestResidual(plus) - TestResidual(minus)) / (2. * step)
            return matrix''', 1)
    code = code.replace("for method in ('hybr', 'trf'):", "for method in ('trf', 'hybr'):", 1)
    code = code.replace('Читает обычную касательную VBA в порядке строк и учитывает только масштабы неизвестных.',
                        'Независимо дифференцирует полную невязку при неизменной истории VBA.')
    (root / name).write_text(code, encoding='utf-8')
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'ExternalFullSecantAt26', 'material_history_in_VBA': True,
        'independent_numerical_algorithm': 'SciPy TRF then HYBRJ, complete central Jacobian',
        'target_step_previous_secant_fraction': .5, 'time_limit_seconds': 180,
        'independent_material_reintegration': False, 'runtime_source_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('EXACT PREFIX 26 EXTERNAL FULL SECANT CONTROL READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
