"""ДЛЯ ТЕСТОВ. Готовит чтение полной касательной без нового длительного поиска предела."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Проверяются исходные поля, истории и три шага производной; производственный код не изменяется."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestReversePolish.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig') + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает действующие геометрические масштабы координат, не затрагивая принятую материальную историю.
Friend Function ReadCurrentTangentScalesTest() As Variant
    If Not PrepareHybridScales() Then Err.Raise 5, , "Не подготовлены масштабы касательной."
    ReadCurrentTangentScalesTest = mHybridScales
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    # Подстановка отдельной строкой сохраняет обратные слеши путей VBA без обработки re.sub.
    original = (root / name).read_text('utf-8-sig')
    replacement = (here / 'TestNativeCurrentTangent.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', lambda _: replacement, original)
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeCurrentTangent.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'CurrentCompleteTangent', 'new_capacity_search_executed': False,
        'accepted_prefixes': [25, 26], 'secant_positions': [0., .125, .5, 1.],
        'coordinate_difference_steps': [2.5e-7, 1e-6, 4e-6], 'full_equilibrium_residual_binary_export': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('CURRENT EXACT PREFIX COMPLETE TANGENT STUDY READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
