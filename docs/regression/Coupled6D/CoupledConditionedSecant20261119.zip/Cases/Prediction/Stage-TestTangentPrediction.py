"""ДЛЯ ТЕСТОВ. Сравнивает прогноз по полной касательной и два бюджета решения на точной истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
import struct


def TestStage(repo, root, source, tangent):
    """Измеренное линейное направление становится только прогнозом; приёмка требует исходного равновесия."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestReversePolish.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    proof = json.loads(tangent.read_bytes())
    direction = proof['records']['CurrentTangent.P26S0D1']
    values = direction['oriented_tangent_field'] + [direction['oriented_tangent_lambda']]
    assert len(values) == 61 and values[-1] > 0
    name = 'Input/Tangent.bin'
    (root / name).write_bytes(struct.pack('<i', len(values)) + struct.pack('<61d', *values))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Input/TangentProof.json'
    (root / name).write_bytes(tangent.read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    def TestReplace(old, new):
        """Патч применяется только к однозначной тестовой подготовке."""
        nonlocal code
        assert code.count(old) == 1, old
        code = code.replace(old, new, 1)
    TestReplace('    For index = 1 To 4', '''    Dim targetValue As Double, movement() As Double, coordinate As Double, spacing As Double
    Dim tangentValues As Variant, reader As Integer, iterationBudget As Long, choices As Variant
    reader = FreeFile
    Open mPolishRootTest & "\\Input\\Tangent.bin" For Binary Access Read As #reader
    tangentValues = TestReadPolishVector(reader)
    If Seek(reader) <> LOF(reader) + 1 Or UBound(tangentValues) <> 61 Then Err.Raise 5, , "Неверный прогноз полной касательной."
    Close #reader
    choices = Array(0.125, 0.5, 1#)
    For index = 1 To 1''')
    TestReplace('        For probeVariant = 0 To 2', '        For probeVariant = 0 To 5')
    code, count = re.subn(r'(?ms)^            If probeVariant = 2 Then\n.*?^            End If\n', '', code)
    assert count == 1
    TestReplace('            seedVariant = seed: started = Timer', '''            ReDim movement(1 To operators.DegreeCount)
            For degree = 1 To UBound(movement): movement(degree) = tangentValues(degree): Next degree
            If Not solver.SelectSpatialDirectionControl(previous, accepted, movement, projection, coordinate, spacing) Then _
                Err.Raise 5, , "Не построена мера вдоль полной касательной."
            ratio = choices(probeVariant \\ 2): spacing = 0#
            For degree = 1 To solver.PhysicalDegreeCount: spacing = spacing + projection(degree) * movement(degree): Next degree
            If spacing <= 0# Then Err.Raise 5, , "Прогноз касательной не направлен вперёд."
            targetValue = coordinate + ratio * spacing
            seed = accepted
            For degree = 1 To UBound(seed): seed(degree) = accepted(degree) + ratio * movement(degree): Next degree
            trace.ReadPoint fields.Count, fraction, currentFactor
            seedFactor = currentFactor + ratio * tangentValues(61)
            absTol = 0.0000000001: relTol = 0.0000000001
            iterationBudget = 30
            If probeVariant Mod 2 = 1 Then iterationBudget = 60
            seedVariant = seed: started = Timer''')
    TestReplace('projection, context(2), seedFactor, factor, _', 'projection, targetValue, seedFactor, factor, _')
    TestReplace('absTol, relTol, CLng(options(2)), initialField:=seedVariant, allowHybridRecovery:=(probeVariant > 0))',
                'absTol, relTol, iterationBudget, initialField:=seedVariant, allowHybridRecovery:=True)')
    TestReplace('stats(0) > options(2)', 'stats(0) > iterationBudget')
    TestReplace('''                If probeVariant = 0 Then
                    If factor <> context(1) Then Err.Raise 5, , "Исходный множитель изменился при штатном повторе."
                    For degree = 1 To UBound(original)
                        If trial(degree) <> original(degree) Then Err.Raise 5, , "Исходное равновесие изменилось при штатном повторе."
                    Next degree
                End If
''', '')
    TestReplace('''            ElseIf probeVariant = 0 Then
                Err.Raise 5, , "Исходная отклонённая проба не воспроизвела равновесие."
''', '')
    TestReplace('controlError = Abs(controlError - context(2)) * calibration(0)',
                'controlError = Abs(controlError - targetValue) * calibration(0)')
    TestReplace('            seed = original: seedFactor = context(1)', '            seed = original: seedFactor = context(1): factor = 0#')
    TestReplace('            Print #handle, "TOLERANCE;"', '''            Print #handle, "PREDICTION;" & CStr(probeVariant) & ";" & TestOnsetNumber(ratio) & ";" & CStr(iterationBudget) & ";" & TestOnsetNumber(targetValue)
            Print #handle, "CONTROL;" & CStr(index) & ";" & CStr(probeVariant) & ";" & TestOnsetNumber(targetValue) & TestHardPreparedVector(projection)
            Print #handle, "TOLERANCE;"''')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'ExactCurrentCompleteTangentPrediction', 'ratios': [.125, .5, 1.],
        'iteration_budgets': [30, 60], 'input_direction_is_not_equilibrium': True,
        'full_tangent_source': 'CurrentTangent.P26S0D1', 'runtime_source_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('FULL CURRENT TANGENT PREDICTION STUDY READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--tangent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve(), args.tangent.resolve())
