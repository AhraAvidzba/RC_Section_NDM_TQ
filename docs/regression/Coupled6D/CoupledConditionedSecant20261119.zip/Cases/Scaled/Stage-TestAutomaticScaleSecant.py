"""ДЛЯ ТЕСТОВ. Проверяет автоматическое масштабирование столбцов полной касательной по HYBRJ mode=1."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Масштабирование меняет метрику численной поправки, а не исходные уравнения и допуск приёмки."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestFreshMatrixSecant.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledHybridSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    changes = {
        '    Dim fresh As Boolean, first As Boolean, accepted As Boolean, i As Long':
            '    Dim fresh As Boolean, first As Boolean, accepted As Boolean, i As Long, column As Long, row As Long\n    Dim diagonal() As Double, workMetric() As Double, columnNorm As Double, diagonalReady As Boolean\n    ReDim diagonal(1 To count): ReDim workMetric(1 To count)',
        '        algebra.Factor matrix, residual, count': '''        For column = 1 To count
            For row = 1 To count: workMetric(row) = matrix(column, row): Next row
            columnNorm = algebra.VectorNorm(workMetric, 1, count)
            If columnNorm = 0# Then columnNorm = 1#
            If diagonalReady Then diagonal(column) = GeomMax(diagonal(column), columnNorm) Else diagonal(column) = columnNorm
            For row = 1 To count: matrix(column, row) = matrix(column, row) / diagonal(column): Next row
        Next column
        diagonalReady = True
        algebra.Factor matrix, residual, count''',
        '            xnorm = algebra.VectorNorm(x, 1, count): radius = initialRadius * xnorm':
            '            For i = 1 To count: workMetric(i) = diagonal(i) * x(i): Next i\n            xnorm = algebra.VectorNorm(workMetric, 1, count): radius = initialRadius * xnorm',
        '            For i = 1 To count: movement(i) = -movement(i): trial(i) = x(i) + movement(i): Next i':
            '            For i = 1 To count: movement(i) = -movement(i): trial(i) = x(i) + movement(i) / diagonal(i): Next i',
        '                xnorm = algebra.VectorNorm(x, 1, count): mAccepted = mAccepted + 1: first = False':
            '                For i = 1 To count: workMetric(i) = diagonal(i) * x(i): Next i\n                xnorm = algebra.VectorNorm(workMetric, 1, count): mAccepted = mAccepted + 1: first = False',
        '            If accepted Then Exit Do \' ДЛЯ ТЕСТОВ: следующая поправка использует новую полную производную, без секущего обновления.':
            '            If accepted And modTestCoupledElasticState.FreshMatrixRequestedTest Then Exit Do \' ДЛЯ ТЕСТОВ: отдельное сравнение полной матрицы и ранга один.'}
    for old, new in changes.items():
        assert code.count(old) == 1, old
        code = code.replace(old, new, 1)
    code = code.replace("' (mode=2, diag=1). Полная касательная чередуется с секущим обновлением", "' ДЛЯ ТЕСТОВ: автоматическая норма столбцов полной касательной (mode=1). Матрица чередуется с обновлением", 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    assert code.count('Option Explicit\n') == 1
    code = code.replace('Option Explicit\n', 'Option Explicit\nPublic FreshMatrixRequestedTest As Boolean\n', 1)
    old = '            If probeVariant >= 5 Then iterationBudget = 60'
    assert code.count(old) == 1
    code = code.replace(old, '            FreshMatrixRequestedTest = (probeVariant >= 5)', 1)
    old = '            Print #handle, "BUDGET;"'
    assert code.count(old) == 1
    code = code.replace(old, '''            Print #handle, "MATRIX_POLICY;" & CStr(probeVariant) & ";AutoColumnNorm;Fresh=" & CStr(FreshMatrixRequestedTest)
''' + old, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'AutomaticColumnNormSecant', 'budgets': [30],
        'automatic_column_norm_scaling': True, 'matrix_policies': ['RankOne', 'Fresh'],
        'algorithm_source': 'Minpack src/hybrj.c mode=1, diagonal monotone column norm',
        'equivalent_QR_coordinate_change': True, 'runtime_source_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('AUTOMATIC COLUMN NORM SECANT CONTROL READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
