"""ДЛЯ ТЕСТОВ. Проверяет измеренную касательную, отрицательные опыты, новый корень и штатную интеграцию."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestFiles(root):
    """Не допускает изменения входов, исходных отказов и результатов сохранённых попыток."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == 'f47b420'


def TestNative(repo, root, output):
    """Проверяет реальный CFB каждого исполнения и завершение только собственных процессов."""
    TestFiles(root)
    audit = run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit']
    result = {}
    for case in ('Tangent', 'Prediction', 'External', 'Fresh', 'Scaled', 'Working'):
        folder = root / 'Cases' / case
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Code.json'
            audit(repo, folder, proof)
            record = json.loads(proof.read_bytes())
        assert (record['components'], record['imported'], record['unchanged']) == (244, 30, 214)
        assert len(record['checked_coupled_sources']) == 33
        phases = {'ReversePolish': 1}
        if case == 'Working':
            phases.update(HybridCore=36, Core=382, PeakRegression=168, ActualReverse=29)
        assert {file.stem for file in (folder / 'Native').glob('*.txt')} == set(phases)
        reports = {}
        for phase, total in phases.items():
            path = folder / 'Native' / (phase + '.txt')
            log = path.read_text('utf-8-sig')
            assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log and 'RUNTIME ERROR:' not in log
            totals = re.findall(r'^TOTAL[^:\r\n]*:\s*passed=(\d+);\s*failed=(\d+)', log, re.M)
            assert (sum(int(a) for a, b in totals), sum(int(b) for a, b in totals)) == (total, 0)
            source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
            assert source == record['compiled_workbook_sha256']
            closure = json.loads(path.with_name(path.name + '.ProcessClosure.json').read_bytes())
            assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
            assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
            reports[phase] = {'passed': total, 'failed': 0, 'owned_excel_absent': True}
        record['native_reports'] = reports
        result[case] = record
    external = root / 'Cases/External/Native/HybridBridge'
    owner = json.loads((external / 'PythonOwner.json').read_bytes())
    closure = json.loads((external / 'PythonClosure.json').read_bytes())
    assert closure['State'] == 'Absent' and closure['PID'] == owner['pid']
    assert closure['ExpectedStartTicks'] == owner['start_ticks'] and not closure['ClosedByAgent'] and not owner['created_excel']
    result = {'cases': result, 'external_python_absent': True, 'installed_workbook_changed': False,
              'full_acceptance_completed': False, 'physical_capacity_certified': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('CONDITIONED SECANT SIX NATIVE BOOKS AND WORKING REGRESSIONS VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Найденная допустимая точка и прирост пути не выдаются за предельную несущую способность."""
    TestFiles(root)
    helper = run_path(str(root / 'Validate-TestHardPrepared.py'))
    validate, rows = helper['TestValidate'], helper['TestRows']
    read_binary = run_path(str(root / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    snapshot = read_binary(root / 'Cases/Working/Input/Reverse1.bin')
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        path = Path(temporary) / 'Tangent.json'
        run_path(str(root / 'Analyze-TestCurrentTangent.py'))['TestAnalyze'](root / 'Cases/Tangent', path)
        tangent = json.loads(path.read_bytes())
    assert len(tangent['records']) == 24
    negative = {}
    for case, count in (('Prediction', 6), ('Fresh', 4)):
        probes = [row for row in rows(root / 'Cases' / case / 'Native/ReversePolish.csv') if row[0] == 'PROBE']
        assert len(probes) == count and all(row[3] == 'False' and float(row[4]) == 0 for row in probes)
        negative[case] = probes
    proofs, fields = {}, {}
    for case, phase in (('External', 'ExternalSecant.HybridCandidate'), ('Scaled', 'ReversePolish.Reverse15'),
                        ('Working', 'ReversePolish.Reverse13')):
        proof, data = validate(root / 'Cases' / case, phase)
        assert len(data) == 27 and not proof['reversed_fields']
        np.testing.assert_allclose(data[:26], snapshot['fields'], rtol=1e-14, atol=1e-300)
        assert proof['states'][-1]['lambda'] > snapshot['lambdas'][-1]
        proofs[case], fields[case] = proof, data
    assert np.array_equal(fields['Scaled'], fields['Working'])
    external = root / 'Cases/External/Native/HybridBridge'
    outcome = json.loads((external / 'Result.json').read_bytes())
    assert outcome['native_equilibrium_found'] and outcome['native_validation'][:2] == [1., 1.]
    assert outcome['methods'][0]['method'] == 'trf' and outcome['methods'][0]['success']
    assert 'PermissionError' in outcome['methods'][1]['error']
    best = np.fromfile(external / 'BestCandidate.bin', dtype='<f8')
    np.testing.assert_allclose(best[:60], fields['External'][-1], rtol=1e-14, atol=1e-300)
    assert best[-1] == outcome['best_lambda']
    scaled_probes = [row for row in rows(root / 'Cases/Scaled/Native/ReversePolish.csv') if row[0] == 'PROBE']
    assert len(scaled_probes) == 4 and [row[3] for row in scaled_probes] == ['False', 'False', 'True', 'False']
    actual, actual_fields = validate(root / 'Cases/Working', 'ActualReverse.Accepted')
    assert len(actual_fields) == 46 and not actual['reversed_fields']
    np.testing.assert_allclose(actual_fields[:26], snapshot['fields'], rtol=1e-14, atol=1e-300)
    assert actual['maximum_lambda'] > snapshot['lambdas'][-1]
    log = (root / 'Cases/Working/Native/ActualReverse.txt').read_text('utf-8-sig')
    seconds, = re.findall(r'^TIMING_SECONDS: ([0-9.]+) \| Both \| Excel$', log, re.M)
    assert 'direct=OK; capacity=NumFail;' in log and 'limit=; code=NUMERICAL_FAILURE' in log
    execution = (root / 'Cases/Working/SavedExecutionReport.txt').read_bytes()
    assert execution.startswith(b'\xff\xfe')
    execution = execution.decode('utf-16')
    assert 'переходов к полной секущей: 1' in execution
    assert 'продвижений поля при неразличимом изменении нагрузки: 20' in execution and 'проб: 96;' in execution
    saved = run_path(str(root / 'Compare-TestSavedCoupledTrace.py'))['TestSavedTrace'](root / 'Cases/Working', 'ActualReverse')
    factors = np.asarray([float(saved[f'Coupled.Trace.Capacity.{i}.Lambda']['value']) for i in range(1, len(actual_fields)+1)])
    np.testing.assert_allclose(factors, [item['lambda'] for item in actual['states']], rtol=1e-14, atol=1e-300)
    exact_prefixes = []
    for file in sorted((root / 'Cases/Working/Native').glob('ActualReverse.Reverse*.bin')):
        binary = read_binary(file)
        count = len(binary['fields'])
        np.testing.assert_allclose(actual_fields[:count], binary['fields'], rtol=1e-14, atol=1e-300)
        if count == 26:
            assert np.array_equal(binary['fields'], snapshot['fields'])
        assert np.array_equal(factors[:count], binary['lambdas'])
        exact_prefixes.append(count)
    assert exact_prefixes and max(exact_prefixes) >= 26
    result = {'complete_tangent_study': tangent, 'negative_studies': negative, 'control_equilibria': proofs,
              'working_API_and_private_candidate_fields_exact': True, 'external_control': outcome,
              'external_method_IO_failure_preserved': True, 'actual_automatic_history': actual,
              'saved_Excel_binary_exact_prefix_lengths': exact_prefixes,
              'original_26_fields_binary_exact': True, 'actual_workbook_seconds': float(seconds),
              'accepted_forward_fields_with_unresolved_load_change': 20, 'global_probe_budget_exhausted': 96,
              'full_accepted_history_binary_exact_loads_proved': max(exact_prefixes) == len(actual_fields),
              'full_accepted_history_CSV_rounding_allowance_MPa': 1e-9,
              'physical_capacity_certified': False, 'independent_material_reintegration': False,
              'full_acceptance_completed': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('CONDITIONED SECANT FULL FIELDS AND ACTUAL AUTOMATIC ADVANCE VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
