"""ДЛЯ ТЕСТОВ. Восстанавливает полную касательную из двоичных проб и направление её одномерного ядра."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestRead(path):
    """Первый индекс сохранённой механической матрицы уже преобразован в порядок строк."""
    raw = path.read_bytes()
    assert raw[:16] == b'NDMTANGETEST0001'
    size, physical, prefix, ratio, step, modulus = struct.unpack_from('<iiiddd', raw, 16)
    assert (size, physical) == (60, 56) and prefix in (25, 26)
    position = 52
    def TestVector():
        """Не допускает усечения или нечислового значения."""
        nonlocal position
        count, = struct.unpack_from('<i', raw, position)
        position += 4
        assert 0 < count <= 61
        result = np.frombuffer(raw, dtype='<f8', count=count, offset=position).copy()
        position += count * 8
        assert np.all(np.isfinite(result))
        return result
    scales, field, weak = (TestVector() for _ in range(3))
    legacy = np.frombuffer(raw, dtype='<f8', count=size*size, offset=position).copy().reshape(size, size)
    position += 8 * size * size
    pairs = [(TestVector(), TestVector()) for _ in range(size)]
    assert position == len(raw) and scales.shape == (61,) and field.shape == weak.shape == (60,)
    derivative = np.column_stack([(plus - minus)/(2 * step) for plus, minus in pairs])
    return {'prefix': prefix, 'ratio': ratio, 'step': step, 'modulus': modulus,
            'scales': scales, 'field': field, 'weak': weak, 'legacy': legacy, 'complete': derivative,
            'sha256': sha256(raw).hexdigest().upper()}


def TestAnalyze(root, output):
    """Линейное направление не объявляется равновесием, продолжением или физическим пределом."""
    here = Path(__file__).resolve().parent
    snapshot = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](root / 'Input/Reverse1.bin')
    helpers = run_path(str(here / 'Check-TestHardHalfSteps.py'))
    _, load, _, _, coordinate, _, b, slope = helpers['TestOperators'](root / 'Native/CurrentTangent.Operators.csv', 60, 43)
    matrices = np.asarray([b + side*.001*slope for side in (-1, 0, 1)])
    tensor = np.asarray((1., 1., 1., .5, .5, .5))
    metric = np.einsum('spci,spcj,p,c->ij', matrices, matrices, coordinate[:, 2], tensor) / (3*sum(coordinate[:, 2]))
    records = {}
    for path in sorted((root / 'Native').glob('CurrentTangent.*.bin')):
        item = TestRead(path)
        prefix = item['prefix']
        previous, accepted = snapshot['fields'][prefix-2:prefix]
        movement = accepted-previous
        expected = accepted.copy()
        expected[:56] += item['ratio'] * movement[:56]
        assert np.array_equal(item['field'], expected)
        scales = item['scales']
        row_scales = np.r_[np.ones(56), np.full(4, item['modulus'])]
        complete = item['complete'] * row_scales[:, None]
        legacy = item['legacy'] * scales[None, :60] * row_scales[:, None]
        load_column = -(load @ snapshot['direction']) * row_scales * scales[-1]
        augmented = np.column_stack((complete, load_column))
        _, singular, vh = np.linalg.svd(augmented, full_matrices=True)
        tangent = vh[-1] * scales
        advance = float(movement @ metric @ tangent[:60])
        if advance < 0:
            tangent *= -1
            advance *= -1
        old_length = np.sqrt(movement @ metric @ movement)
        secant_projection = metric @ movement / old_length
        controlled = np.vstack((augmented, np.r_[item['modulus'] * secant_projection * scales[:60], 0.]))
        column_norms = np.linalg.norm(controlled, axis=0)
        assert np.all(column_norms > 0)
        tangent_length = np.sqrt(tangent[:60] @ metric @ tangent[:60])
        tangent *= old_length / tangent_length
        target = snapshot['offset'] + snapshot['lambdas'][prefix-1] * snapshot['direction']
        residual = row_scales * (item['weak'] - load @ target)
        error = complete-legacy
        row, column = np.unravel_index(np.argmax(np.abs(error)), error.shape)
        records[path.stem] = {'prefix': prefix, 'ratio': item['ratio'], 'difference_step': item['step'], 'binary_sha256': item['sha256'],
            'residual_at_prefix_lambda_MPa': float(np.max(np.abs(residual))),
            'complete_vs_assembled_maximum': float(np.max(np.abs(error))), 'worst_one_based': [int(row)+1, int(column)+1],
            'complete_gauge_error': float(np.max(np.abs(error[56:]))),
            'secant_control_column_norm_ratio': float(max(column_norms)/min(column_norms)),
            'secant_control_condition': float(np.linalg.cond(controlled)),
            'secant_control_column_normalized_condition': float(np.linalg.cond(controlled/column_norms)),
            'singular_values': singular.tolist(), 'rectangular_condition_number': float(singular[0]/singular[-1]),
            'null_residual': float(np.max(np.abs(augmented @ (tangent / scales)))),
            'oriented_tangent_field': tangent[:60].tolist(), 'oriented_tangent_lambda': float(tangent[-1]),
            'previous_lambda_step': float(snapshot['lambdas'][prefix-1]-snapshot['lambdas'][prefix-2]),
            'oriented_tangent_cosine': float(advance/(old_length*tangent_length)),
            'old_control_delta_on_oriented_tangent': float(snapshot['projection'] @ tangent[:60]),
            'accepted_secant_length': float(old_length)}
    assert len(records) == 24
    result = {'records': records, 'physical_capacity_certified': False, 'tangents_are_not_equilibrium_points': True,
              'independent_material_reintegration': False, 'spatial_half_step_dimensionless': .001}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    for name, record in records.items():
        if record['difference_step'] == 1e-6:
            print(name, 'lambda_tangent', record['oriented_tangent_lambda'], 'cosine', record['oriented_tangent_cosine'],
                  'old_control', record['old_control_delta_on_oriented_tangent'], 'condition', record['rectangular_condition_number'])
    print('CURRENT COMPLETE TANGENTS RECONSTRUCTED; DIRECTIONS ARE NOT EQUILIBRIUM OR CAPACITY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
