"""Check the early nonlinear MVT2 path on the already qualified elastic rig."""
import argparse
from hashlib import sha256
from itertools import product
import json
from math import atan2, dist, exp, expm1, fsum, isfinite, log1p
from pathlib import Path
import sys
from time import monotonic
from types import SimpleNamespace

sys.dont_write_bytecode = True
import MVT2Elastic as rig


FC = 588_000. / (.3 * 240.**2)
FT_NOMINAL = .302 * FC**(2./3.)
FT = 2.10667357864589
GT = .073 * FC**.18
GC = (FC/FT_NOMINAL)**2 * GT
H = 125.
PEAK = .0022
FY = {2:498., 3:450.}
LABEL = {2:"long", 3:"hoop"}
TORQUE_KNOTS = (.4, .65, .82, 1.)
SHEAR_KNOTS_KN = (5., 10., 15.)
EXPECTED_SHA = "C2777D5D748972220113C54F78FD18DEDA86DB6786AE7268633E0FDB1C5CC8A7"
UTILITY_SHA = "17CAD60D1E55F84F62CFCFE49EDDE9FD6F3D7CF29761E3252A37975047812106"
ELASTIC_SHA = "B2F08BF4339C3827982AE0E21244FACAAD5269B4A9FF0C37A0BADB2AC42DB449"
ASD_DEFAULT_LENGTH = min(.01*GT/(.5*FT**2/rig.E),
                         .02*GT*(FC/FT)**2/(.5*FC*(.6*FC/rig.E)))


def envelope(yield_stress, peak_stress, peak_plastic, damage_rate, energy):
    """Sample the NDM nominal uniaxial envelope for the ASD three-column law."""
    decay = peak_stress/(energy-(peak_stress+yield_stress)*peak_plastic/2.)
    if decay <= 0.:
        raise ValueError("Nonpositive post-peak energy")
    knots = [peak_plastic*i/40 for i in range(40)] if peak_plastic else []
    knots.extend(peak_plastic+i/(20.*decay) for i in range(277))
    rows = [(0.,0.,0.)]
    for plastic in knots:
        stress = (yield_stress+(peak_stress-yield_stress)*plastic/peak_plastic
                  if plastic < peak_plastic else peak_stress * exp(-decay*(plastic-peak_plastic)))
        damage = -expm1(-damage_rate*plastic)
        if damage >= 1.-1e-12:
            break
        strain = plastic + stress/((1.-damage)*rig.E)
        if strain > .1:
            break
        a, _, d = rows[-1]
        if not a < strain or not d <= damage < 1. or not stress > 0.:
            raise ValueError(("Invalid stress-law point", strain, stress, damage, rows[-1]))
        rows.append((strain,stress,damage))
    return rows


def tables():
    damage = .423*(1.-FC/(PEAK*rig.E))
    plastic = PEAK-FC/((1.-damage)*rig.E)
    tensile = envelope(FT, FT, 0., FT*H/GT, GT/H)
    compressive = envelope(.6*FC, FC, plastic, -log1p(-damage)/plastic, GC/H)
    return tensile, compressive


class MaterialCommands:
    """Override only the rig's three material declarations, preserving topology and forces."""
    def __init__(self, ops, variant):
        self.ops, self.variant = ops, variant

    def __getattr__(self, name):
        return getattr(self.ops, name)

    def nDMaterial(self, kind, tag, e, nu):
        if (kind,tag,e,nu) != ("ElasticIsotropic",1,rig.E,rig.NU):
            raise ValueError("Elastic material interface changed")
        if self.variant == "default":
            self.ops.nDMaterial("ASDConcrete3D",tag,e,nu,"-fc",FC,"-ft",FT,"-tangent")
            return
        args = ["ASDConcrete3D",tag,e,nu]
        for prefix,rows in zip(("T","C"), tables(), strict=True):
            for j,field in enumerate("esd"):
                args.extend(["-"+prefix+field,*(row[j] for row in rows)])
        self.ops.nDMaterial(*args,"-tangent")

    def uniaxialMaterial(self, kind, tag, e):
        if kind != "Elastic" or tag not in FY or e != rig.ES:
            raise ValueError("Elastic steel interface changed")
        self.ops.uniaxialMaterial("Steel01",tag,FY[tag],e,0.)


def zone(z):
    if z <= 500. or z >= 1700.:
        return "reinforced_end"
    if min(z-500.,1700.-z) < 240.:
        return "support_band"
    if abs(z-1100.)-rig.PATCH_Z < 220.:
        return "load_band"
    return "central_clear"


def control_displacements(model):
    geom, ops = model.geometry, model.ops
    positions = (500., *rig.CUTS, 1100., 1700.)
    profile = {}
    for z in sorted(positions):
        corners = [(x,y,ops.nodeDisp(geom.at(x,y,z))) for x,y in product((-120.,120.), repeat=2)]
        dot = fsum(x*(x+u[0])+y*(y+u[1]) for x,y,u in corners)
        cross = fsum(x*u[1]-y*u[0] for x,y,u in corners)
        average_uy = fsum(u[1] for _,_,u in corners)/4.
        profile[str(int(z))] = {"rotation_rad":atan2(cross,dot),"mean_y_displacement_mm":average_uy,
                                "corner_axial_mm":[u[2] for _,_,u in corners]}
    profile["clear_twist_rad_per_m"] = {"left": (profile["860"]["rotation_rad"]-profile["800"]["rotation_rad"])/.06,
                                        "right": (profile["1400"]["rotation_rad"]-profile["1340"]["rotation_rad"])/.06}
    profile["midspan_top_y_mm"] = ops.nodeDisp(geom.at(0.,120.,1100.))[1]
    return profile


def field_summary(model):
    ops = model.ops
    steel = {}
    for tag,(a,b,material) in model.bars.items():
        start,end = model.coords[a],model.coords[b]
        z = (start[2]+end[2])/2.
        length = dist(start,end)
        strain, = ops.eleResponse(tag,"deformations")
        strain /= length
        if not isfinite(strain):
            raise ValueError(("invalid truss response",tag))
        extrema = steel.setdefault(zone(z), {}).setdefault(LABEL[material],{})
        for label, sign in (("min",-1.),("max",1.)):
            if label not in extrema or sign*strain > sign*extrema[label]["axial_strain"]:
                extrema[label] = {"tag":tag,"axial_strain":strain,"z_mm":z,"yield_strain_magnitude":FY[material]/rig.ES}
    damage = {}
    for k,layer in enumerate(model.bricks):
        lower,upper = model.z[k:k+2]
        for tag,nodes in layer:
            xyz = [model.coords[n] for n in nodes]
            bounds = [(min(p[i] for p in xyz),max(p[i] for p in xyz)) for i in range(3)]
            for gp in range(1,9):
                values = ops.eleResponse(tag,"material",gp,"damage")
                if len(values) != 2 or not all(isfinite(v) and -.000001 <= v <= 1.000001 for v in values):
                    raise ValueError(("invalid concrete damage",tag,gp,values))
                # Brick::formResidAndTangent assigns Gauss indices with z innermost.
                local = tuple(rig.GAUSS[((gp-1)//stride)%2] for stride in (4,2,1))
                point = tuple((lo+hi+(hi-lo)*xi)/2. for (lo,hi),xi in zip(bounds,local,strict=True))
                z = point[2]
                high = damage.setdefault(zone(z),{})
                for label, value in zip(("tension","compression"), values, strict=True):
                    if label not in high or value > high[label]["damage"]:
                        high[label] = {"damage":value,"element":tag,"point":gp,"xyz_mm":point,
                                       "element_z_interval_mm":[lower,upper]}
    return {"concrete_damage_by_station_band":damage,"steel_signed_extrema_by_band":steel}


def rollback_sample(model):
    geometry, ops = model.geometry, model.ops
    nodal = tuple(value for tag in geometry.coords for value in ops.nodeDisp(tag))
    controls = (max(0,geometry.z.index(z)-1) for z in (500.,800.,860.,1100.,1340.,1400.,1700.))
    tags = [model.bricks[k][i][0] for k in controls for i in (0,len(model.bricks[k])//2,-1)]
    damage = tuple(tuple(ops.eleResponse(tag,"material",gp,"damage")) for tag in tags for gp in (1,8))
    if any(len(values) != 2 or not all(map(isfinite,values)) for values in damage):
        raise ValueError("Rollback sample did not produce two concrete damage values per Gauss point")
    return ops.getTime(), nodal, damage


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def inputs(opts):
    if (digest(rig.HERE/"MVT2Elastic.py"), digest(rig.UTILITY), digest(rig.HERE/"ElasticResult.json")) != (EXPECTED_SHA, UTILITY_SHA, ELASTIC_SHA):
        raise ValueError("Elastic rig evidence changed")
    geometry = rig.Geometry(60.,1)
    rig.basis_check(geometry)
    tensile, compressive = tables()
    if len(tensile) <= 40 or len(compressive) <= 40 or abs(max(row[1] for row in compressive)-FC) > 1e-10:
        raise ValueError("Two explicit uniaxial curves do not resolve the prescribed peak")
    meta = {"variant":opts.variant,"scope":"early nonlinear diagnostic", "E_MPa":rig.E,"nu":rig.NU,"fc_MPa":FC,
            "ft_MPa":FT,"steel_E_MPa":rig.ES,"steel_yield_MPa":FY,"steel_post_yield_slope_MPa":0.,
            "explicit_Gt_N_per_mm":GT,"explicit_Gc_N_per_mm":GC,"explicit_Lch_mm":H,
            "explicit_compression_peak_strain":PEAK,"default_ASD_generated_Lch_mm":ASD_DEFAULT_LENGTH,
            "ASD_autoRegularization":False,"torque_knots_kNm":[t*rig.TORQUE/1e6 for t in TORQUE_KNOTS],
            "shear_knots_kN":SHEAR_KNOTS_KN, "tensile_knots":len(tensile), "compressive_knots":len(compressive),
            "elastic_rig_sha256":EXPECTED_SHA,"elastic_result_sha256":ELASTIC_SHA,"integrator_sha256":UTILITY_SHA,
            "physical_limit_established":False}
    return geometry,meta


def run(opts, geometry, output, report):
    sys.path.insert(0,str(rig.UTILITY.parent))
    import validate_opensees_hardshear as utility

    deadline = monotonic()+opts.seconds
    real_ops = utility.ops
    adapter = MaterialCommands(real_ops,opts.variant)
    model = rig.Model(geometry,SimpleNamespace(ops=adapter,Prism=utility.Prism))
    ops = real_ops
    report.update(termination="running", candidates=[], states=[], opensees_version=ops.version())

    def save():
        temp = output.with_suffix(output.suffix+".part")
        temp.write_text(json.dumps(report,indent=2,allow_nan=False)+"\n",encoding="utf-8")
        temp.replace(output)

    def set_load(pattern, nodal_unit_load, maximum):
        ops.timeSeries("Linear",pattern)
        ops.pattern("Plain",pattern,pattern)
        for tag,f in nodal_unit_load.items():
            ops.load(tag,*rig.scale(maximum,f))

    def follow(phase, milestones):
        for goal in milestones:
            increment = goal - ops.getTime()
            while goal - ops.getTime() > 2e-12:
                if monotonic() >= deadline or len(report["candidates"]) >= opts.max_attempts:
                    return "bounded_run_budget"
                previous = rollback_sample(model)
                step = min(increment,goal-previous[0])
                if step < .002:
                    return "step_floor_after_failed_equilibrium"
                ops.integrator("LoadControl",step)
                code = ops.analyze(1)
                received = ops.getTime()
                receipt = {"phase":phase,"from_scale":previous[0],"attempted_scale":previous[0]+step,
                           "observed_scale":received,"solver_code":code,"iterations":ops.testIter()}
                report["candidates"].append(receipt)
                if code:
                    rolled = rollback_sample(model)
                    receipt["all_nodal_rollback_max_mm"] = max(abs(a-b) for a,b in zip(previous[1],rolled[1],strict=True))
                    receipt["sampled_damage_rollback_exact"] = rolled[2] == previous[2]
                    receipt["returned_load_time"] = rolled[0] == previous[0]
                    save()
                    if (not receipt["returned_load_time"] or not receipt["sampled_damage_rollback_exact"] or
                        receipt["all_nodal_rollback_max_mm"] > 1e-10):
                        return "unverified_solver_rollback"
                    increment = step / 2.
                    continue
                if abs(received-previous[0]-step) > 1e-12:
                    return "committed_load_time_mismatch"
                t,p = ((rig.TORQUE*received,0.) if phase == "torsion" else (rig.TORQUE,2e3*SHEAR_KNOTS_KN[-1]*received))
                values = model.inspect(t,p)
                item = {"phase":phase,"nominal_milestone":abs(received-goal)<=2e-12,
                        "rig_balance":values,"displacement":control_displacements(model)}
                report["states"].append(item)
                save()
                if item["nominal_milestone"]:
                    item.update(field_summary(model))
                    save()
        return None

    set_load(1,geometry.torque_unit,rig.TORQUE)
    for command,args in ((ops.constraints,("Transformation",)), (ops.numberer,("RCM",)),(ops.system,("UmfPack",)),
                         (ops.test,("NormUnbalance",1e-5,12)), (ops.algorithm,("Newton",)),
                         (ops.integrator,("LoadControl",.1)),(ops.analysis,("Static",))):
        command(*args)
    save()
    try:
        termination = follow("torsion",TORQUE_KNOTS)
        if termination is None:
            ops.loadConst("-time",0.)
            set_load(2,geometry.vertical_unit,2e3*SHEAR_KNOTS_KN[-1])
            termination = follow("fixed_torsion_increasing_shear",[q/SHEAR_KNOTS_KN[-1] for q in SHEAR_KNOTS_KN])
        report["termination"] = termination or "pilot_targets_reached"
    except Exception as problem:
        report.update(termination="verification_or_engine_exception",detail=str(problem))
        raise
    finally:
        save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs",action="store_true")
    mode.add_argument("--run",action="store_true")
    parser.add_argument("--variant",choices=("default","explicit"),default="default")
    parser.add_argument("--seconds",type=float,default=110.)
    parser.add_argument("--max-attempts",type=int,default=22)
    parser.add_argument("--out",type=Path)
    opts = parser.parse_args()
    if not 0. < opts.seconds <= 300. or not 1 <= opts.max_attempts <= 60:
        parser.error("Use 1–60 attempts and no more than 300 seconds.")
    geometry, meta = inputs(opts)
    if opts.check_inputs:
        print("MVT2_NONLINEAR_INPUTS_OK",json.dumps(meta,allow_nan=False))
        return
    out = (opts.out or rig.HERE/f"Nonlinear-{opts.variant}.json").resolve()
    out.relative_to(rig.HERE)
    if out.exists() or out.with_suffix(out.suffix+".part").exists():
        raise FileExistsError(out)
    run(opts,geometry,out,meta)
    print("MVT2_NONLINEAR_PILOT",meta["termination"],len(meta["states"]),out)


if __name__ == "__main__":
    main()
