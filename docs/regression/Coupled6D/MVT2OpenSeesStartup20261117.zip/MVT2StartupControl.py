"""Probe the ASD secant start with smaller torque steps on the frozen MVT2 setup."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent
BASE = HERE.parent
BASE_SHA = "D5E37F6DE0964AAF942DF541E77482AF4988C3CBC9E2F714A20CEAF0AB0B5E68"
sys.dont_write_bytecode = True
sys.path.insert(0, str(BASE))
import MVT2NonlinearPilot as original


class MaterialDirection(original.MaterialCommands):
    """Select either documented ASD linearization while retaining the same stress law."""
    numerical_tangent = False

    def nDMaterial(self, kind, tag, e, nu):
        if (kind,tag,e,nu,self.variant) != ("ElasticIsotropic",1,original.rig.E,original.rig.NU,"default"):
            raise ValueError("Unexpected qualified model material interface")
        flags = ("-tangent",) if self.numerical_tangent else ()
        self.ops.nDMaterial("ASDConcrete3D",tag,e,nu,"-fc",original.FC,"-ft",original.FT,*flags)


def inputs(opts):
    if sha256((BASE / "MVT2NonlinearPilot.py").read_bytes()).hexdigest().upper() != BASE_SHA:
        raise ValueError("Original pilot no longer has the isolated expected identity")
    opts.variant = "default"
    old_knots = original.TORQUE_KNOTS
    original.TORQUE_KNOTS = (.025,.05,.1,*old_knots)
    MaterialDirection.numerical_tangent = opts.direction == "tangent"
    original.MaterialCommands = MaterialDirection
    geometry, meta = original.inputs(opts)
    meta.update(base_nonlinear_source_sha256=BASE_SHA, asd_linearization=opts.direction,
                scaled_start_levels=[.025,.05,.1], max_attempts=opts.max_attempts,
                global_algorithm="Newton with selected ASD matrix", norm_unbalance_force=1e-5,
                Newton_iteration_cap=12,cut_balance_N_equivalent=original.rig.MAX_BALANCE_ERROR)
    return geometry,meta


def output_paths(opts):
    part = ("Startup-" if opts.max_attempts <= 3 else "Extended-")+opts.direction
    return tuple(HERE / f"{part}{suffix}" for suffix in (".json", ".stdout.log", ".stderr.log"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs",action="store_true")
    mode.add_argument("--start",action="store_true")
    mode.add_argument("--child",action="store_true",help=argparse.SUPPRESS)
    parser.add_argument("--direction",choices=("secant","tangent"),default="secant")
    parser.add_argument("--max-attempts",type=int,default=3)
    parser.add_argument("--wall-seconds",type=int,default=85)
    opts = parser.parse_args()
    if not 1 <= opts.max_attempts <= 24 or not 30 <= opts.wall_seconds <= 140:
        parser.error("Use 1–24 attempts and 30–140 watchdog seconds.")
    opts.seconds = opts.wall_seconds - 15.
    if opts.check_inputs:
        _,meta = inputs(opts)
        print("MVT2_STARTUP_CONTROL_INPUTS_OK",json.dumps(meta,allow_nan=False))
        return 0
    result,stdout_log,stderr_log = output_paths(opts)
    if result.exists() or result.with_suffix(".json.part").exists():
        raise FileExistsError(result)
    if opts.child:
        geometry,meta = inputs(opts)
        original.run(opts,geometry,result,meta)
        print("MVT2_STARTUP_CONTROL",meta["termination"],len(meta["states"]),result.name)
        return 0
    inputs(opts)
    argv = [sys.executable,"-B","-X","utf8",str(Path(__file__).resolve()),"--child",
            "--direction",opts.direction,"--max-attempts",str(opts.max_attempts),"--wall-seconds",str(opts.wall_seconds)]
    with stdout_log.open("xb") as stdout, stderr_log.open("xb") as stderr:
        try:
            code = subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=opts.wall_seconds).returncode
        except subprocess.TimeoutExpired:
            print(f"MVT2_STARTUP_CONTROL_WATCHDOG {opts.wall_seconds}s; see {result.name} if created")
            return 124
    print(f"MVT2_STARTUP_CONTROL_CLOSED code={code} result={result.name}")
    return code


if __name__ == "__main__":
    sys.exit(main())
