"""Elastic 3D equilibrium benchmark for Wang and Huang's MVT2 beam.

Loads and reactions use N, mm and MPa. Run --check-inputs without OpenSees.
Run --run explicitly to solve the elastic control. No capacity is computed.
"""
import argparse
from hashlib import sha256
from itertools import product
import json
from math import ceil, fsum, isclose, isfinite, pi, sqrt
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PAPER = ROOT / "literature/Coupled6D/Wang-Huang-2017-MVT-NMVT.pdf"
PAPER_SHA = "6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E"
UTILITY = ROOT / "tools/validate_opensees_hardshear.py"
Z_END, Z_LEFT, Z_MID, Z_RIGHT = 2200., 500., 1100., 1700.
WIDTH, TORQUE = 240., 10_510_000.
PATCH_X, PATCH_Z = 30., 20.
CUTS = (800., 860., 1340., 1400.)
E, NU, ES = 30_000., .2, 200_000.
MAX_BALANCE_ERROR = .05
LONG_CORNERS = tuple(product((-84., 84.), repeat=2))
END_LONG_ADDITIONAL = ((0., -84.), (0., 84.), (-84., 0.), (84., 0.))
CORNERS = ((0, 0), (1, 0), (1, 1), (0, 1))
GAUSS = (-1./sqrt(3), 1./sqrt(3))
COMPONENTS = ("N", "Mx", "My", "T", "Qx", "Qy")
HOOP_PHASES = (tuple(range(20, 500, 40)), tuple(range(530, 1700, 60)), tuple(range(1720, 2200, 40)))
X_BREAKS = (-120., -96., -84., -60., -30., 0., 30., 60., 84., 96., 120.)
Y_BREAKS = (-120., -96., -84., -60., 0., 60., 84., 96., 120.)


def combine(*vectors):
    return tuple(fsum(items) for items in zip(*vectors, strict=True))


def scale(factor, vector):
    return tuple(factor * value for value in vector)


def wrench(point, force, ref):
    x, y, z = point
    fx, fy, fz = force
    return fz, y*fz-(z-ref)*fy, x*fz-(z-ref)*fx, x*fy-y*fx, fx, fy


def transport(values, delta_z):
    n, mx, my, torque, qx, qy = values
    return n, mx + delta_z*qy, my + delta_z*qx, torque, qx, qy


def ndm_axes(values):
    # The original checked rig axes have y upwards. A common 180-degree
    # rotation of x/y yields positive sagging and Qy in the left half-span.
    return tuple(value * sign for value, sign in zip(values, (1, -1, -1, 1, -1, -1), strict=True))


def error(found, expected):
    if len(found) != 6 or not all(map(isfinite, found)):
        raise ValueError(f"Invalid section wrench {found}")
    return max(abs(x-y) / (WIDTH if i in (1, 2, 3) else 1.)
               for i, (x, y) in enumerate(zip(found, expected, strict=True)))


def require_balance(label, found, expected, threshold):
    residual = error(found, expected)
    if residual > threshold:
        raise ValueError(f"{label}: wrench defect {residual:.12g} N equivalent, found={found}, expected={expected}")
    return residual


def near_segments(levels, maximum):
    return [a + (b-a)*j/ceil((b-a)/maximum) for a, b in zip(levels, levels[1:])
            for j in range(ceil((b-a)/maximum))] + [levels[-1]]


class Geometry:
    """Structured mesh with bond-shared steel and explicit rig control planes."""

    def __init__(self, step, refine):
        if not (0. < step <= 100. and 1 <= refine <= 3):
            raise ValueError("Require 0 < dz_max <= 100 mm and integer XY refinement 1..3")
        self.x = [a+(b-a)*i/refine for a,b in zip(X_BREAKS,X_BREAKS[1:]) for i in range(refine)] + [X_BREAKS[-1]]
        self.y = [a+(b-a)*i/refine for a,b in zip(Y_BREAKS,Y_BREAKS[1:]) for i in range(refine)] + [Y_BREAKS[-1]]
        self.hoops = tuple(level for zone in HOOP_PHASES for level in zone)
        forced = sorted({0., Z_END, Z_LEFT, Z_RIGHT, Z_MID, Z_MID - PATCH_Z, Z_MID + PATCH_Z, *self.hoops, *CUTS})
        self.z = near_segments(forced, step)
        self.nx, self.ny, self.nz = len(self.x)-1, len(self.y)-1, len(self.z)-1
        self.coords = {self.node(i, j, k): (x, y, z) for k, z in enumerate(self.z)
                       for j, y in enumerate(self.y) for i, x in enumerate(self.x)}
        self.left_vertical = (self.at(-96., -120., Z_LEFT), self.at(96., -120., Z_LEFT))
        self.left_translation = self.at(0., -120., Z_LEFT)
        self.right_vertical = self.at(0., -120., Z_RIGHT)
        self.supports = {self.left_vertical[0]: (0, 1, 0), self.left_vertical[1]: (0, 1, 0),
                         self.left_translation: (1, 0, 1), self.right_vertical: (1, 1, 0)}
        self.torque_unit = self.end_torque()
        self.vertical_unit = self.vertical_patch()

    def node(self, i, j, k):
        return 1 + (k*(self.ny+1)+j)*(self.nx+1)+i

    def at(self, x, y, z):
        return self.node(self.x.index(x), self.y.index(y), self.z.index(z))

    def end_torque(self):
        forces = {}
        polar_area_moment = WIDTH**4 / 6.
        for i, j in product(range(self.nx), range(self.ny)):
            x0, x1 = self.x[i:i+2]
            y0, y1 = self.y[j:j+2]
            jacobian = (x1-x0)*(y1-y0)/4.
            for r, s in product(GAUSS, repeat=2):
                x = (x0+x1+r*(x1-x0))/2.
                y = (y0+y1+s*(y1-y0))/2.
                traction = (-y / polar_area_moment, x / polar_area_moment, 0.)
                for a,b in CORNERS:
                    shape = (1+(2*a-1)*r)*(1+(2*b-1)*s)/4.
                    tag = self.node(i+a, j+b, self.nz)
                    forces[tag] = combine(forces.get(tag, (0.,)*3), scale(shape*jacobian, traction))
        return forces

    def vertical_patch(self):
        forces = {}
        patch_area = 4. * PATCH_X * PATCH_Z
        for i, k in product(range(self.nx), range(self.nz)):
            xx, zz = self.x[i:i+2], self.z[k:k+2]
            if xx[0] < -PATCH_X or xx[1] > PATCH_X or zz[0] < Z_MID-PATCH_Z or zz[1] > Z_MID+PATCH_Z:
                continue
            nodal = -(xx[1]-xx[0])*(zz[1]-zz[0])/(4.*patch_area)
            for a,b in CORNERS:
                tag = self.node(i+a, self.ny, k+b)
                forces[tag] = combine(forces.get(tag, (0.,)*3), (0., nodal, 0.))
        return forces

    def sum_wrench(self, values, z, predicate=lambda point: True):
        terms = [wrench(self.coords[tag], value, z) for tag, value in values.items() if predicate(self.coords[tag])]
        return combine(*terms) if terms else (0.,)*6

    def hoop_loop(self, z):
        left, right, lo, hi, k = self.x.index(-96.), self.x.index(96.), self.y.index(-96.), self.y.index(96.), self.z.index(z)
        perimeter = ([(i,lo) for i in range(left,right)] + [(right,j) for j in range(lo,hi)] +
                     [(i,hi) for i in range(right,left,-1)] + [(left,j) for j in range(hi,lo,-1)])
        return [self.node(i, j, k) for i, j in perimeter]


def expected_section(z, t, p):
    q = p/2.
    return (0., -q*min(z-Z_LEFT, Z_RIGHT-z), 0., t, 0., -q if z<Z_MID else q)


def applied_nodes(geometry, t, p):
    return {tag: combine(scale(t, geometry.torque_unit.get(tag, (0.,)*3)),
                         scale(p, geometry.vertical_unit.get(tag, (0.,)*3)))
            for tag in geometry.torque_unit.keys() | geometry.vertical_unit.keys()}


def reference_reactions(geometry, t, p):
    left, right = geometry.left_vertical
    return {left: (0., (p/2.+t/96.)/2., 0.), right: (0., (p/2.-t/96.)/2., 0.),
            geometry.left_translation: (0.,)*3, geometry.right_vertical: (0., p/2., 0.)}


def free_body(geometry, z, applied, reactions, left):
    predicate = (lambda point: point[2] < z) if left else (lambda point: point[2] > z)
    summed = combine(geometry.sum_wrench(applied, z, predicate), geometry.sum_wrench(reactions, z, predicate))
    return scale(-1. if left else 1., summed)


def support_rank(geometry):
    rows = []
    for tag, fixed in geometry.supports.items():
        x, y, z = (value / Z_END for value in geometry.coords[tag])
        # Translation plus omega cross r at the restrained coordinate.
        rigid = ((1.,0.,0.,0.,z,-y),(0.,1.,0.,-z,0.,x),(0.,0.,1.,y,-x,0.))
        rows.extend(list(row) for row, constrained in zip(rigid, fixed, strict=True) if constrained)
    rank = 0
    for column in range(6):
        if rank == len(rows):
            break
        pivot = max(range(rank, len(rows)), key=lambda row: abs(rows[row][column]))
        if abs(rows[pivot][column]) < 1e-12:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for lower in range(rank + 1, len(rows)):
            factor = rows[lower][column] / rows[rank][column]
            rows[lower] = list(combine(rows[lower], scale(-factor, rows[rank])))
        rank += 1
    return rank


def basis_check(geometry):
    assert len(geometry.left_vertical) == 2 and sum(sum(flags) for flags in geometry.supports.values()) == 6
    assert support_rank(geometry) == 6
    assert all(z in geometry.z and z not in geometry.hoops for z in CUTS)
    assert min(abs(z-Z_MID) - PATCH_Z for z in CUTS) == 220.
    assert len(geometry.hoops) == len(set(geometry.hoops))
    assert all(len(geometry.hoop_loop(z)) >= 4 for z in geometry.hoops)
    # Verify two independent generalized load bases and their combination.
    for t,p in ((TORQUE,0.), (0.,20_000.), (TORQUE,20_000.)):
        applied = applied_nodes(geometry, t, p)
        react = reference_reactions(geometry, t, p)
        require_balance("analytic applied resultants", geometry.sum_wrench(applied,Z_MID), (0.,0.,0.,t,0.,-p), 1e-7)
        require_balance("analytic global reactions", combine(geometry.sum_wrench(applied,Z_MID),
                                                               geometry.sum_wrench(react,Z_MID)), (0.,)*6, 1e-7)
        for z in CUTS:
            expected = expected_section(z,t,p)
            for left in (True,False):
                require_balance("analytic cut free body", free_body(geometry,z,applied,react,left), expected, 1e-7)
            nominal = ndm_axes(transport(expected, Z_MID-z))
            sign = 1. if z<Z_MID else -1.
            require_balance("nominal one-sided midspan", nominal, (0.,600.*p/2.,0.,t,0.,sign*p/2.), 1e-7)


class Model:
    """Uses the same element resisting-force cut operation as HardShear."""

    def __init__(self, geometry, utility):
        self.geometry = geometry
        self.z, self.coords = geometry.z, geometry.coords
        self.ops, self.utility = utility.ops, utility
        ops = self.ops
        ops.wipe()
        ops.model("basic", "-ndm", 3, "-ndf", 3)
        ops.nDMaterial("ElasticIsotropic", 1, E, NU)
        ops.uniaxialMaterial("Elastic", 2, ES)
        ops.uniaxialMaterial("Elastic", 3, ES)
        for tag, point in self.coords.items():
            ops.node(tag, *point)
        for tag, fixed in geometry.supports.items():
            ops.fix(tag, *fixed)
        self.bricks = [[] for _ in range(geometry.nz)]
        self.long = [[] for _ in range(geometry.nz)]
        self.bars = {}
        self.next = 1
        for k, j, i in product(range(geometry.nz), range(geometry.ny), range(geometry.nx)):
            nodes = [geometry.node(i+a,j+b,k+c) for c in (0,1) for a,b in CORNERS]
            ops.element("stdBrick", self.next, *nodes, 1)
            self.bricks[k].append((self.next, nodes))
            self.next += 1
        for k, (lo, hi) in enumerate(zip(self.z, self.z[1:])):
            layout = LONG_CORNERS if lo >= Z_LEFT and hi <= Z_RIGHT else (*LONG_CORNERS,*END_LONG_ADDITIONAL)
            for x,y in layout:
                self.long[k].append(utility.Prism.bar(self,geometry.at(x,y,lo),geometry.at(x,y,hi),2,16.))
        for z in geometry.hoops:
            nodes = geometry.hoop_loop(z)
            for a,b in zip(nodes, nodes[1:]+nodes[:1], strict=True):
                utility.Prism.bar(self,a,b,3,8.)

    def inspect(self, t, p):
        self.ops.reactions()
        geometry = self.geometry
        applied = applied_nodes(geometry,t,p)
        reactions = {tag: tuple(self.ops.nodeReaction(tag)) for tag in geometry.supports}
        left_supports = {*geometry.left_vertical, geometry.left_translation}
        support_reactions = {
            "left": geometry.sum_wrench({n:f for n,f in reactions.items() if n in left_supports},Z_LEFT),
            "right": geometry.sum_wrench({geometry.right_vertical:reactions[geometry.right_vertical]},Z_RIGHT),
        }
        checks = [require_balance("left support",support_reactions["left"],(0.,0.,0.,-t,0.,p/2.), MAX_BALANCE_ERROR),
                  require_balance("right support",support_reactions["right"],(0.,0.,0.,0.,0.,p/2.), MAX_BALANCE_ERROR),
                  require_balance("global wrench",combine(geometry.sum_wrench(applied,Z_MID),
                            geometry.sum_wrench(reactions,Z_MID)),(0.,)*6,MAX_BALANCE_ERROR)]
        cuts = []
        for z in CUTS:
            k = self.z.index(z)
            expected = expected_section(z,t,p)
            one = self.utility.Prism.cut(self,k-1,True)
            other = self.utility.Prism.cut(self,k,False)
            left = free_body(geometry,z,applied,reactions,True)
            right = free_body(geometry,z,applied,reactions,False)
            for label,value in (("low layer cut",one),("high layer cut",other),("left free body",left),("right free body",right)):
                checks.append(require_balance(f"{label} at z={z}",value,expected,MAX_BALANCE_ERROR))
            checks.append(require_balance(f"two cut faces at z={z}",one,other,MAX_BALANCE_ERROR))
            cuts.append({"z_mm":z, "expected_raw":expected, "low_layer_raw":one,"high_layer_raw":other,
                         "left_free_body_raw":left,"right_free_body_raw":right,
                         "low_layer_nominal_midspan_ndm_axes":ndm_axes(transport(one,Z_MID-z)),
                         "high_layer_nominal_midspan_ndm_axes":ndm_axes(transport(other,Z_MID-z))})
        for side in ("left", "right"):
            signs = 1. if side == "left" else -1.
            nominal = (0.,600.*p/2.,0.,t,0.,signs*p/2.)
            for row in cuts:
                if (row["z_mm"] < Z_MID) == (side == "left"):
                    for column in ("low_layer_nominal_midspan_ndm_axes","high_layer_nominal_midspan_ndm_axes"):
                        checks.append(require_balance(f"{side} nominal carried wrench",row[column],nominal,MAX_BALANCE_ERROR))
        return {"T_Nmm":t,"P_N":p,"support_reactions_raw_at_own_z":support_reactions,
                "support_nodal_reactions":reactions,"cuts":cuts,"peak_balance_error_N_equivalent":max(checks)}


def run(geometry, qy, meta):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(UTILITY.parent))
    import validate_opensees_hardshear as utility

    model = Model(geometry,utility)
    ops = model.ops
    ops.timeSeries("Linear",1)
    ops.pattern("Plain",1,1)
    for node,force in geometry.torque_unit.items():
        ops.load(node,*scale(TORQUE,force))
    ops.constraints("Transformation")
    ops.numberer("RCM")
    ops.system("UmfPack")
    ops.algorithm("Linear")
    ops.integrator("LoadControl",.5)
    ops.analysis("Static")
    states = []
    for fraction in (.5,1.):
        if ops.analyze(1) or not isclose(ops.getTime(),fraction,rel_tol=0.,abs_tol=1e-14):
            raise RuntimeError("Elastic torque preload did not converge at the prescribed increment")
        states.append({"phase":"torque",**model.inspect(fraction*TORQUE,0.)})
    ops.loadConst("-time",0.)
    ops.timeSeries("Linear",2)
    ops.pattern("Plain",2,2)
    for node,force in geometry.vertical_unit.items():
        ops.load(node,*scale(2.*qy,force))
    for fraction in (.5,1.):
        if ops.analyze(1) or not isclose(ops.getTime(),fraction,rel_tol=0.,abs_tol=1e-14):
            raise RuntimeError("Elastic force step did not converge at the prescribed increment")
        states.append({"phase":"vertical_at_constant_T",**model.inspect(TORQUE,fraction*2.*qy)})
    return {**meta,"opensees_version":ops.version(),"states":states,"physical_limit_established":False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs",action="store_true")
    mode.add_argument("--run",action="store_true")
    parser.add_argument("--qy-kn",type=float,default=10.)
    parser.add_argument("--dz-max",type=float,default=60.)
    parser.add_argument("--xy-refine",type=int,default=1)
    parser.add_argument("--out",type=Path,default=HERE/"ElasticResult.json")
    opts = parser.parse_args()
    if not isfinite(opts.qy_kn) or not 0. < opts.qy_kn <= 30.:
        parser.error("Elastic control requires 0 < Qy <= 30 kN")
    assert sha256(PAPER.read_bytes()).hexdigest().upper() == PAPER_SHA
    geometry = Geometry(opts.dz_max,opts.xy_refine)
    basis_check(geometry)
    metadata = {"benchmark":"MVT2 elastic qualification", "units":["mm","N","Nmm","MPa"],"wrench_order":COMPONENTS,
                "primary_figure_pdf_sha256":PAPER_SHA,"reused_HardShear_script_sha256":sha256(UTILITY.read_bytes()).hexdigest().upper(),
                "mesh_intervals_xyz":[geometry.nx,geometry.ny,geometry.nz],"mesh_node_count":len(geometry.coords),
                "support_rigid_body_rank":support_rank(geometry),
                "support_z_mm":[Z_LEFT,Z_RIGHT],"load_center_z_mm":Z_MID,"torque_end_z_mm":Z_END,"safe_cut_z_mm":CUTS,
                "patch_half_extents_x_z_mm":[PATCH_X,PATCH_Z],"hoop_levels_mm":geometry.hoops,
                "max_equilibrium_error_N_equivalent":MAX_BALANCE_ERROR,"material_elastic_E_MPa_nu_Es_MPa":[E,NU,ES],
                "requested_Qy_kN_for_sign_test":opts.qy_kn}
    if opts.check_inputs:
        print("MVT2_ELASTIC_INPUTS_OK",json.dumps(metadata,separators=(",",":"),allow_nan=False))
    else:
        output = opts.out.resolve()
        output.relative_to(HERE)
        if output.exists():
            raise FileExistsError(output)
        result = run(geometry,opts.qy_kn*1000.,metadata)
        output.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n",encoding="utf-8")
        print("MVT2_ELASTIC_BALANCE_PASS",output)


if __name__ == "__main__":
    main()
