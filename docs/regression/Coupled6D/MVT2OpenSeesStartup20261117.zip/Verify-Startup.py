"""Verify the three retained OpenSees MVT2 startup lanes offline."""
import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
RAW = {
    "Nonlinear-default.json": "21FE257A9B07D80FBB845C8F6BEA7446725804EEBD06041B85957D5C79CB9B13",
    "Nonlinear-default.stdout.log": "E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855",
    "Nonlinear-default.stderr.log": "86B50389F3DDB28789443FA5013344320287AFBA2EA0176EA71647FE30209CD4",
    "Startup-secant.json": "C632111B776A1AB8B4D8E62F9A0806E395E4E52C23488D876218B344EB695B6F",
    "Startup-secant.stdout.log": "0E74D304B093FD9E0CEF2D036043DF10F7B0227871C1A365066C5E298CABF718",
    "Startup-secant.stderr.log": "8F40A71E56737EDF425B62FCE2B9645DEE014E9D641897988C9E90457361A1FC",
    "Startup-tangent.json": "7C2F051CBD16644F7628F074F58C5CB38FC8AF16BCD2E75F2E40EEDFA0714F91",
    "Startup-tangent.stdout.log": "EF4B80039B448482DCB375453C34A5CF0934BAA2FD7FD7865CFA22F995A433E1",
    "Startup-tangent.stderr.log": "06AE28BF755DA0A3C91E209D344A50F7F7A48D7C01F5BDC2D059A97B5C049619",
}
BASE_VALIDATOR_SHA = "3392E927E7AFCCAD51A818CBAAEAA252A9C66C67EA6A96DF0E9EF3E307542044"
TERMINATIONS = {"Nonlinear-default":"running", "Startup-secant":"bounded_run_budget", "Startup-tangent":"bounded_run_budget"}
EXPECTED = {"Nonlinear-default":((.4,-3),(.2,-3),(.1,-3)),
            "Startup-secant":((.025,-3),(.0125,0),(.025,-3)),
            "Startup-tangent":((.025,0),(.05,-3),(.0375,0))}


def require(condition, label):
    if not condition:
        raise ValueError(label)


def data(name, root):
    direct = root / name
    location = direct if direct.exists() else root / "secant" / name
    return location.read_bytes()


def verify(root):
    payload = {name:data(name,root) for name in RAW}
    for name, body in payload.items():
        require(sha256(body).hexdigest().upper() == RAW[name], name)
    module = root / "Verify-Elastic.py"
    require(sha256(module.read_bytes()).hexdigest().upper() == BASE_VALIDATOR_SHA, "independent equilibrium evaluator identity")
    spec = spec_from_file_location("equilibrium", module)
    equilibrium = module_from_spec(spec)
    spec.loader.exec_module(equilibrium)
    terminal_observation = json.loads(data("StartupProcessReceipt.json", root))
    require(terminal_observation["watchdog_seconds"] == 140 and terminal_observation["wrapper_exit_code"] == 124, "outer terminal/watchdog receipt")
    require(terminal_observation["outer_tool_exit_code"] == 1 and
            terminal_observation["outer_tool_stdout"] == "MVT2_NONLINEAR_WATCHDOG 140s; last accepted steps in Nonlinear-default.json if present", "outer watchdog output")
    require(terminal_observation["process_ids_absent_observed"] == [3332,11704], "process closure observation")
    result = {}
    for lane, expected in EXPECTED.items():
        output = json.loads(payload[lane+".json"])
        require(output["termination"] == TERMINATIONS[lane] and output["physical_limit_established"] is False, f"{lane} status")
        if lane.startswith("Startup"):
            require(output["asd_linearization"] == lane.split("-")[-1] and output["scaled_start_levels"] == [.025,.05,.1], "comparison inputs")
            require(output["max_attempts"] == 3 and output["norm_unbalance_force"] == 1e-5 and output["cut_balance_N_equivalent"] == .05, "fixed acceptance")
            require(f"bounded_run_budget {len(output['states'])}".encode() in payload[lane+".stdout.log"], f"{lane} completion marker")
            terminal = terminal_observation["short_lane_terminal"][lane.split("-")[-1]]
            require(terminal == {"outer_tool_exit_code":0,"outer_tool_stdout":f"MVT2_STARTUP_CONTROL_CLOSED code=0 result={lane}.json"}, "short outer closure")
        else:
            require(payload[lane+".stdout.log"] == b"" and not output["states"], "partial watchdog state")
        states = iter(output["states"])
        prior = 0.
        accepted = []
        failures = []
        for row, (attempted,code) in zip(output["candidates"], expected, strict=True):
            require(row["phase"] == "torsion" and row["from_scale"] == prior, f"{lane} accepted history")
            require(abs(row["attempted_scale"]-attempted) < 1e-15 and row["solver_code"] == code, f"{lane} attempts")
            if code:
                require(row["observed_scale"] == prior and row["returned_load_time"] is True and
                        row["all_nodal_rollback_max_mm"] == 0. and row["sampled_damage_rollback_exact"] is True, f"{lane} rollback")
                failures.append({"attempted_T_kNm":attempted*10.51,"solver_code":code,"test_counter":row["iterations"]})
                continue
            state = next(states)
            prior = row["observed_scale"]
            require(abs(prior-attempted) < 1e-15 and state["rig_balance"]["P_N"] == 0., f"{lane} committed time")
            torque = float(state["rig_balance"]["T_Nmm"])
            require(abs(torque-attempted*10510000.) <= 1e-8, f"{lane} actual torque")
            proof = equilibrium.verify_step({"phase":"torsion",**state["rig_balance"]}, "torsion", torque, 0.)
            survey = state.get("concrete_damage_by_station_band")
            require((survey is not None) == state["nominal_milestone"], "survey availability")
            band_damage = None if survey is None else {band:{mode:point["damage"] for mode,point in extra.items()} for band,extra in survey.items()}
            if band_damage:
                require(set(band_damage) == {"reinforced_end","support_band","load_band","central_clear"}, "survey bands")
                require(all(item == {"compression":0.,"tension":0.} for item in band_damage.values()), "verified damage maxima")
            proof.update(iterations=row["iterations"], clear_twist_rad_per_m=state["displacement"]["clear_twist_rad_per_m"],
                         nominal_milestone=state["nominal_milestone"], measured_band_damage=band_damage)
            accepted.append(proof)
        require(next(states,None) is None, "unmatched accepted state")
        result[lane] = {"raw_json_termination":output["termination"],"accepted":accepted,"failed":failures}
    return {"checks":"PASS", "lanes":result, "original_watchdog":terminal_observation, "physical_limit_established":False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--native-root", type=Path, default=HERE)
    parser.add_argument("--out", type=Path)
    opts = parser.parse_args()
    proof = verify(opts.native_root)
    if opts.out:
        opts.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True,allow_nan=False)+"\n").encode("utf-8"))
    print("MVT2_STARTUP_DETACHED_PASS", " ".join(f"{name}={len(row['accepted'])}" for name,row in proof["lanes"].items()))


if __name__ == "__main__":
    main()
