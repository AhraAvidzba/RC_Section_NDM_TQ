"""Run one MVT2 pilot process with a hard watchdog and private logs."""
import argparse
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=("default", "explicit"), default="default")
    parser.add_argument("--wall-seconds", type=int, default=140)
    opts = parser.parse_args()
    if not 30 <= opts.wall_seconds <= 300:
        parser.error("Use 30–300 seconds.")
    basename = f"Nonlinear-{opts.variant}"
    result = HERE / f"{basename}.json"
    if result.exists() or result.with_suffix(".json.part").exists():
        raise FileExistsError(result)
    args = [sys.executable, "-B", "-X", "utf8", str(HERE / "MVT2NonlinearPilot.py"),
            "--run", "--variant", opts.variant, "--seconds", str(opts.wall_seconds - 24),
            "--out", str(result)]
    with (HERE / f"{basename}.stdout.log").open("xb") as stdout, (HERE / f"{basename}.stderr.log").open("xb") as stderr:
        try:
            code = subprocess.run(args, stdout=stdout, stderr=stderr, timeout=opts.wall_seconds).returncode
        except subprocess.TimeoutExpired:
            print(f"MVT2_NONLINEAR_WATCHDOG {opts.wall_seconds}s; last accepted steps in {result.name} if present")
            return 124
    print(f"MVT2_NONLINEAR_WATCHDOG_CLOSED code={code} result={result.name}")
    return code


if __name__ == "__main__":
    sys.exit(main())
