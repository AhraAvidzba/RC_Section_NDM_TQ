"""Independently audit the stored four-step MVT2 OpenSees equilibrium result."""
from hashlib import sha256
from math import fsum, isfinite
from pathlib import Path
import argparse
import json


HERE = Path(__file__).resolve().parent
RECEIPT = {
    "ElasticResult.json": "B2F08BF4339C3827982AE0E21244FACAAD5269B4A9FF0C37A0BADB2AC42DB449",
    "MVT2Elastic.py": "C2777D5D748972220113C54F78FD18DEDA86DB6786AE7268633E0FDB1C5CC8A7",
    "literature/Coupled6D/Wang-Huang-2017-MVT-NMVT.pdf": "6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E",
    "tools/validate_opensees_hardshear.py": "17CAD60D1E55F84F62CFCFE49EDDE9FD6F3D7CF29761E3252A37975047812106",
}
COMPONENTS = ("N", "Mx", "My", "T", "Qx", "Qy")
SCALES = (1., 240., 240., 240., 1., 1.)
ZERO = (0.,) * 6
CUTS = (800., 860., 1340., 1400.)
STEPS = (("torque", 5_255_000., 0.), ("torque", 10_510_000., 0.),
         ("vertical_at_constant_T", 10_510_000., 10_000.), ("vertical_at_constant_T", 10_510_000., 20_000.))
SUPPORTS = {"1289": (-96., -120., 500.), "1297": (96., -120., 500.),
            "1293": (0., -120., 500.), "4065": (0., -120., 1700.)}
THRESHOLD = .05


def require(condition, name):
    if not condition:
        raise ValueError(name)


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def net(*vectors):
    return tuple(fsum(values) for values in zip(*vectors, strict=True))


def support_wrench(reactions, tags, z_reference):
    contributions = []
    for tag in tags:
        x, y, z = SUPPORTS[tag]
        fx, fy, fz = reactions[tag]
        z -= z_reference
        # The physical My is ry cross F along y; the project reports its negative.
        mx, physical_my, mz = y*fz-z*fy, z*fx-x*fz, x*fy-y*fx
        contributions.append((fz, mx, -physical_my, mz, fx, fy))
    return net(*contributions)


def translate_to_ndm(raw, z):
    n, mx, my, torque, qx, qy = raw
    return n, -mx+(z-1100.)*qy, -my+(z-1100.)*qx, torque, -qx, -qy


def verify_step(state, phase, torque, vertical):
    require((state["phase"], state["T_Nmm"], state["P_N"]) == (phase, torque, vertical), "load sequence")
    qy = vertical / 2.
    left_ids = ("1289", "1297", "1293")
    right_ids = ("4065",)
    reactions = state["support_nodal_reactions"]
    require(set(reactions) == set(SUPPORTS), "reaction node IDs")
    errors = {}
    archived_check_errors = []
    component_maximum = [0.] * 6

    def check(name, actual, expected, in_run=True):
        require(len(actual) == 6 and all(map(isfinite, actual)), f"finite six values for {name}")
        delta = [abs(a-b) for a, b in zip(actual, expected, strict=True)]
        item = max(d/s for d, s in zip(delta, SCALES, strict=True))
        require(item <= THRESHOLD, f"equilibrium tolerance at {name}: {item}")
        for i, value in enumerate(delta):
            component_maximum[i] = max(component_maximum[i], value)
        errors[name] = item
        if in_run:
            archived_check_errors.append(item)

    left_reaction = support_wrench(reactions, left_ids, 500.)
    right_reaction = support_wrench(reactions, right_ids, 1700.)
    archived_reactions = state["support_reactions_raw_at_own_z"]
    check("rebuild left support", archived_reactions["left"], left_reaction, False)
    check("rebuild right support", archived_reactions["right"], right_reaction, False)
    check("left reaction", left_reaction, (0., 0., 0., -torque, 0., qy))
    check("right reaction", right_reaction, (0., 0., 0., 0., 0., qy))
    total_reaction = support_wrench(reactions, (*left_ids, *right_ids), 1100.)
    check("overall equilibrium", total_reaction, (0., 0., 0., -torque, 0., vertical))

    require(tuple(row["z_mm"] for row in state["cuts"]) == CUTS, "cut locations")
    nominal_endpoints = {}
    for row in state["cuts"]:
        z = row["z_mm"]
        side = 1 if z < 1100. else -1
        arm = z-500. if side == 1 else 1700.-z
        target = (0., -arm*qy, 0., torque, 0., -side*qy)
        check(f"{z:g} stored analytic", row["expected_raw"], target, False)
        left_applied = ZERO if side == 1 else (0., (1100.-z)*vertical, 0., 0., 0., -vertical)
        right_applied = (0., (1100.-z)*vertical, 0., torque, 0., -vertical) if side == 1 else (0., 0., 0., torque, 0., 0.)
        left_free = tuple(-value for value in net(support_wrench(reactions, left_ids, z), left_applied))
        right_free = net(support_wrench(reactions, right_ids, z), right_applied)
        check(f"{z:g} left free body reconstruction", row["left_free_body_raw"], left_free, False)
        check(f"{z:g} right free body reconstruction", row["right_free_body_raw"], right_free, False)
        check(f"{z:g} left free body", left_free, target)
        check(f"{z:g} right free body", right_free, target)
        nominal = (0., 600.*qy, 0., torque, 0., side*qy)
        nominal_endpoints[str(int(z))] = []
        for layer in ("low", "high"):
            traction = row[f"{layer}_layer_raw"]
            check(f"{z:g} {layer} force integration", traction, target)
            translated = translate_to_ndm(traction, z)
            check(f"{z:g} {layer} nominal in NDM axes", translated, nominal)
            check(f"{z:g} {layer} stored transport", row[f"{layer}_layer_nominal_midspan_ndm_axes"], translated, False)
            nominal_endpoints[str(int(z))].append(translated)
        check(f"{z:g} face to face", row["low_layer_raw"], row["high_layer_raw"])

    independent_peak = max(archived_check_errors)
    require(abs(independent_peak - state["peak_balance_error_N_equivalent"]) <= 2e-10, "archived balance maximum")
    governing = max(errors, key=errors.get)
    return {"phase": phase, "T_kNm": torque / 1e6, "P_kN": vertical / 1e3,
            "governing_check": governing, "peak_error_N_equivalent": errors[governing],
            "max_component_absolute_error_native_units": dict(zip(COMPONENTS, component_maximum, strict=True)),
            "left_reaction_N_Nmm": left_reaction, "right_reaction_N_Nmm": right_reaction,
            "nominal_sides_N_Nmm": nominal_endpoints}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, help="Also check the local copies of the two pinned repository dependencies.")
    parser.add_argument("--out", type=Path, help="Save independent metrics as JSON.")
    opts = parser.parse_args()
    for name in ("ElasticResult.json", "MVT2Elastic.py"):
        require(digest(HERE / name) == RECEIPT[name], f"archived SHA for {name}")
    if opts.repo:
        for name in RECEIPT:
            if "/" in name:
                require(digest(opts.repo / name) == RECEIPT[name], f"repository dependency SHA for {name}")
    result = json.loads((HERE / "ElasticResult.json").read_text(encoding="utf-8"))
    require(result["opensees_version"] == "3.8.0", "OpenSees runtime version")
    require(result["primary_figure_pdf_sha256"] == RECEIPT["literature/Coupled6D/Wang-Huang-2017-MVT-NMVT.pdf"], "PDF identity")
    require(result["reused_HardShear_script_sha256"] == RECEIPT["tools/validate_opensees_hardshear.py"], "utility identity")
    require(result["units"] == ["mm", "N", "Nmm", "MPa"] and tuple(result["wrench_order"]) == COMPONENTS, "unit contract")
    require(result["mesh_intervals_xyz"] == [10, 8, 54] and result["mesh_node_count"] == 5445, "mesh receipt")
    require(result["support_rigid_body_rank"] == 6 and result["support_z_mm"] == [500., 1700.], "support receipt")
    require(result["load_center_z_mm"] == 1100. and result["torque_end_z_mm"] == 2200., "load positions")
    require(tuple(result["safe_cut_z_mm"]) == CUTS and result["patch_half_extents_x_z_mm"] == [30., 20.], "cut and patch separation")
    require(result["max_equilibrium_error_N_equivalent"] == THRESHOLD and result["requested_Qy_kN_for_sign_test"] == 10., "fixed comparison gates")
    require(result["physical_limit_established"] is False, "elastic qualification scope")
    states = [verify_step(state, *step) for state, step in zip(result["states"], STEPS, strict=True)]
    proof = {"checks": "PASS", "states": states, "provenance_sha256": RECEIPT,
             "worst_error_N_equivalent": max(state["peak_error_N_equivalent"] for state in states),
             "physical_limit_established": False}
    if opts.out:
        opts.out.write_bytes((json.dumps(proof, indent=2, sort_keys=True, allow_nan=False)+"\n").encode("utf-8"))
    print(f"MVT2_ELASTIC_DETACHED_PASS {len(states)} steps; worst equilibrium defect {proof['worst_error_N_equivalent']:.12g} N equivalent")


if __name__ == "__main__":
    main()
