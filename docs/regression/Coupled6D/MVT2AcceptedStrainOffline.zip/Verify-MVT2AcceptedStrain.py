"""Rebuild accepted MVT2 concrete strains and elastic rebar stresses from 60 DOF."""
import argparse
import csv
from hashlib import sha256
from io import StringIO
import json
import math
from pathlib import Path
from zipfile import ZipFile

import numpy as np

LENGTH = math.hypot(110., 110.)
PEAK_STRAIN = .0022
STATIONS = (-.001, 0., .001)
ARCHIVES = {
    "A": ("MVT2TurnOffline.zip", "Native/MVT2.csv",
          "2E362A0EDC31616253D79A15F9B81AC93197A02C6673246028B2F20CE07D3AA5"),
    "B": ("MVT2MinimumBisectionReplay.zip", "MVT2MinimumFields/Native/ShearB.csv",
          "8B7CC447A1C365056EF1449E0842057425ADE9C4718AF97EBC9C30B6EB9B92AA")
}

def digest(data):
    return sha256(data).hexdigest().upper()

def read_archive(repo, spec):
    file, path, expected = spec
    with ZipFile(repo / "docs/regression/Coupled6D" / file) as archive:
        names = [name for name in archive.namelist() if name == path]
        assert len(names) == 1, names
        data = archive.read(names[0])
    assert digest(data) == expected
    return list(csv.reader(StringIO(data.decode("cp1251")), delimiter=";")), expected

def bernstein(coordinate):
    t = (coordinate + 120.) / 240.
    s = 1. - t
    shape = np.array([s**3, 3*s*s*t, 3*s*t*t, t**3])
    gradient = (3. / 240.) * np.array([-s*s, s*s-2*s*t, 2*s*t-t*t, t*t])
    return shape, gradient

def strain(q, x, y, station):
    bx, dx = bernstein(x)
    by, dy = bernstein(y)
    dx = np.outer(by, dx).ravel() * LENGTH
    dy = np.outer(dy, bx).ravel() * LENGTH
    u, v, w = q[4:52].reshape(16,3).T
    xx, yy = x / LENGTH, y / LENGTH
    return np.array([
        dx @ u,
        dy @ v,
        q[0]+q[1]*yy+q[2]*xx+station*(q[52]+q[53]*yy+q[54]*xx),
        dy @ u + dx @ v,
        dx @ w - (q[3]+station*q[55])*yy,
        dy @ w + (q[3]+station*q[55])*xx,
    ])

def principal(values):
    a, b, c, gxy, gxz, gyz = values
    return np.linalg.eigvalsh([[a,gxy/2,gxz/2],[gxy/2,b,gyz/2],[gxz/2,gyz/2,c]])

def maximum_steel(q):
    steel = 200000.
    long = max(abs(strain(q,x,y,0.)[2])*steel for x in (-84.,84.) for y in (-84.,84.))
    nodes = np.polynomial.legendre.leggauss(4)[0] * 96.
    hoop = max(abs(strain(q,along,side,0.)[0])*steel for side in (-96.,96.) for along in nodes)
    hoop = max(hoop,max(abs(strain(q,side,along,0.)[1])*steel for side in (-96.,96.) for along in nodes))
    return long,hoop

def summarize(q, force):
    points = [(x,y) for y in (-96.,-48.,0.,48.,96.) for x in (-96.,-48.,0.,48.,96.)]
    samples = [(x,y,z,strain(q,x,y,z)) for x,y in points for z in STATIONS]
    min_epszz = min(samples, key=lambda value:value[3][2])
    max_epszz = max(samples, key=lambda value:value[3][2])
    min_principal = min(samples, key=lambda value:principal(value[3])[0])
    coordinate = lambda value:dict(x_mm=value[0],y_mm=value[1],z_over_L=value[2])
    long,hoop = maximum_steel(q)
    return {
        "Qy_kN":force,"curvature_x_per_m":q[1]*1000./LENGTH,"twist_rad_per_m":q[3]*1000./LENGTH,
        "average_gamma_yz":float(np.mean([strain(q,x,y,0.)[5] for x,y in points])),
        "long_max_MPa_elastic":long,"hoop_max_MPa_elastic":hoop,
        "min_axial":dict(value=float(min_epszz[3][2]),**coordinate(min_epszz)),
        "max_axial":dict(value=float(max_epszz[3][2]),**coordinate(max_epszz)),
        "min_principal":dict(values=principal(min_principal[3]).tolist(),**coordinate(min_principal)),
        "abs_min_principal_over_uniaxial_peak_strain":float(abs(principal(min_principal[3])[0])/PEAK_STRAIN),
    }

def main(repo):
    result = {"length_mm":LENGTH,"comparison_uniaxial_peak_strain":PEAK_STRAIN,"routes":{}}
    for route, spec in ARCHIVES.items():
        rows, identity = read_archive(repo,spec)
        prefix = "Force" if route=="A" else "ShearB/Force"
        fields = {r[1]:np.array(r[2:],float) for r in rows
                  if r[0]=="MVT2_CONTROL_FIELD" and r[1].startswith(prefix)}
        assert len(fields)==(50 if route=="A" else 24) and all(len(q)==60 for q in fields.values())
        summaries = [r for r in rows if r[0]=="MVT2_STATE" and r[1]==("Combined" if route=="A" else "B/Shear")]
        checks,field_loads=[],{}
        for index,r in enumerate(summaries):
            force=float(r[3])
            if force<0: continue
            native = np.array([float(r[10]),float(r[11])*LENGTH/1000.,float(r[12])*LENGTH/1000.,float(r[13])*LENGTH/1000.])
            matches = [(name,q) for name,q in fields.items() if np.max(np.abs(q[:4]-native))<1e-12]
            assert len(matches)==1,(route,force,[name for name,_ in matches])
            name,q=matches[0]
            diag=summarize(q,force)
            gamma_error=abs(diag["average_gamma_yz"]-float(r[14]))
            rebar_error=max(abs(diag["long_max_MPa_elastic"]-float(r[15])),abs(diag["hoop_max_MPa_elastic"]-float(r[16])))
            assert gamma_error<3e-12 and rebar_error<3e-7 and float(r[17])==float(r[18])==0., (route,name,force,gamma_error,rebar_error)
            diag.update(field=name,mean_gamma_error=gamma_error,max_steel_error_MPa=rebar_error,
                        compression_energy_native=float(r[20]),minimum_principal_stress_native_MPa=float(r[21]))
            field_loads[name]=force
            checks.append(diag)
        assert len(checks)>1,(route,summaries)
        all_fields=[summarize(q,field_loads.get(name)) for name,q in fields.items()]
        compressive_max=max(enumerate(all_fields,1),key=lambda row:row[1]["abs_min_principal_over_uniaxial_peak_strain"])
        result["routes"][route]={"trace_sha":identity,"matched_native_summaries":checks,
            "field_count":len(all_fields),"max_compressive_principal_over_path":{"field_index":compressive_max[0],**compressive_max[1]}}
    return result

if __name__=="__main__":
    args=argparse.ArgumentParser()
    args.add_argument("repo",type=Path)
    args.add_argument("--output",type=Path,required=True)
    parsed=args.parse_args()
    report=main(parsed.repo)
    parsed.output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(digest(parsed.output.read_bytes()))