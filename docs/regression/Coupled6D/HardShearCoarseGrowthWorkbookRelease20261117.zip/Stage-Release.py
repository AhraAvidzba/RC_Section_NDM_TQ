"""Stage the clean HardShear release, then verify one native VBE export."""
from argparse import ArgumentParser
from copy import copy
from hashlib import sha256
from io import BytesIO
from json import dumps, loads
from pathlib import Path, PureWindowsPath
import re
from subprocess import check_output
from sys import modules
from types import ModuleType
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
STORAGE = Path("D:/CodexScratch/RC_Section_NDM_TQ")
CLEAN = STORAGE / "HardGrowthClean1"
RELEASE = STORAGE / "HardGrowthRelease1"
COMPILED = CLEAN / "docs/regression/Diagnostic.xlsm"
RELEASE_BOOK = "docs/regression/Audit03/RC_Section_NDM.xlsm"
RELEASE_EXPORT = "docs/regression/Audit03/VBA_All_Code.txt"
BASE_REVISION = "709e7dfa16c192748fc2c6d999925bdbf9948a4c"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
DUMP = "workbook/output/VBA_All_Code.txt"
MODULE = "CCoupledDeformationContinuation"
CLASS = f"src/Solver/{MODULE}.cls"
PART = "xl/vbaProject.bin"
OLD_BOOK = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
OLD_DUMP = "815680F95BDB321D7DF5374EAC9F9B1BAD4F4D0A9E628F09EC0BA11EE70AD90D"
CLEAN_BOOK = "BD7DB986507FC1B43B22A8ADB5E78F7145874DF06727D06BCCA0AC03FE783D76"
CLEAN_SOURCE = "C99CA320BA1D82F75AE227E84C6FF98AD19EDF7A112853C2DCD1B15A2771FB29"
OBSERVE_ARCHIVE = "MVT2ArcRecoveryWorkbookRelease20261117.zip"
OBSERVE_SHA = "6A76629D2C14789BDFDE0939CA9E8B384CE31E101E74BAC80597AF7F914FF9E8"
CLEAN_ARCHIVE = "HardShearCoarseGrowthCleanWorkbookNative20261117.zip"
CLEAN_ARCHIVE_SHA = "1B9A0181BE2E7BAD53058549EE33DB9B1703DF1C01C0ADA20293D32A3D266396"
EXPORT_SCRIPT = "tools/build_workbook/Export-Audit03VbaSnapshot.ps1"
EXPORT_SCRIPT_SHA = "61C3A8C261FED85A188E392F120E721075B9A08A95BDA9F3AA5BA0553C21A142"
GUARD_SHA = "7E7C36AE9044330D21DE82EF84A8B19EB4C1054EB5AFDFA9FD6A191924C7749C"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def pinned(path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, path
    return raw


def load_baseline(repo, name, expected):
    raw = (repo / name).read_bytes()
    if digest(raw) != expected:
        raw = check_output(["git", "cat-file", "blob", f"{BASE_REVISION}:{name}"], cwd=repo)
    assert digest(raw) == expected, name
    return raw


def parse_vba(repo):
    path = repo / "docs/regression/Coupled6D" / OBSERVE_ARCHIVE
    with ZipFile(BytesIO(pinned(path, OBSERVE_SHA))) as archive:
        library = ModuleType("ReadVbaSource")
        exec(compile(archive.read("ReadVbaSource.py"), "ReadVbaSource.py", "exec"), library.__dict__)
        modules[library.__name__] = library
        observe = {}
        exec(compile(archive.read("Observe-Workbook.py"), "Observe-Workbook.py", "exec"), observe)
    return observe, library.workbook_sources


def clean_inputs(repo):
    source = pinned(CLEAN / CLASS, CLEAN_SOURCE)
    archive_path = repo / "docs/regression/Coupled6D" / CLEAN_ARCHIVE
    verify = ("CompileClosure.json", "Compile.log", "docs/regression/CodeUpdate.json", "ABVerification.json", CLASS)
    with ZipFile(BytesIO(pinned(archive_path, CLEAN_ARCHIVE_SHA))) as archive:
        for name in verify:
            assert archive.read(name) == (CLEAN / name).read_bytes(), name
        native = loads(archive.read("ABVerification.json"))
        assert native["B"]["source_sha256"] == CLEAN_BOOK
        assert native["same_previously_verified_curve"] and len(native["curve"]["entries"]) == 136
    receipt = loads((CLEAN / "docs/regression/CodeUpdate.json").read_text(encoding="utf-8-sig"))
    assert receipt["Compiled"] and not receipt["ProductionChanged"]
    assert receipt["ProductionSHA256"] == OLD_BOOK and receipt["WorkbookSHA256"] == CLEAN_BOOK
    assert receipt["Modules"] == [MODULE] and not receipt["EntryPointNames"] and not receipt["RetiredModules"]
    assert not receipt["TraceGeometry"] and Path(receipt["Workbook"]).resolve() == COMPILED.resolve()
    return source, pinned(COMPILED, CLEAN_BOOK)


def observed_sources(repo, base, candidate, class_source):
    observer, read = parse_vba(repo)
    old_vba, before = read(BytesIO(base))
    new_vba, after = read(BytesIO(candidate))
    assert before.keys() == after.keys() and len(before) == 225 and old_vba != new_vba
    fold = observer["literal_safe_fold"]
    raw = [name for name in before if before[name] != after[name]]
    changed = [name for name in raw if fold(before[name]) != fold(after[name])]
    assert changed == [MODULE], changed
    body = observer["compiler_body"]
    assert body(class_source.decode("utf-8"), MODULE) == body(after[MODULE], MODULE)
    return {"component_count": len(after), "changed_components": changed,
            "case_only_components": sorted(set(raw) - set(changed)),
            "original_vba_sha256": old_vba, "vba_sha256": new_vba,
            "source_sha256": CLEAN_SOURCE}


def package_bytes(base, compiled):
    output = BytesIO()
    with ZipFile(BytesIO(base)) as old, ZipFile(BytesIO(compiled)) as clean, ZipFile(output, "w") as out:
        project = clean.read(PART)
        out.comment = old.comment
        for item in old.infolist():
            out.writestr(copy(item), project if item.filename == PART else old.read(item))
    return output.getvalue()


def verify_parts(base, compiled, package, observation):
    with ZipFile(BytesIO(base)) as old, ZipFile(BytesIO(compiled)) as clean, ZipFile(BytesIO(package)) as out:
        names = old.namelist()
        assert len(names) == len(set(names)) == 122
        assert names == out.namelist() and old.comment == out.comment
        assert [name for name in names if old.read(name) != out.read(name)] == [PART]
        assert out.read(PART) == clean.read(PART)
        parts = {name: digest(out.read(name)) for name in names}
    return {"base_sha256": OLD_BOOK, "compiled_sha256": CLEAN_BOOK, "candidate_sha256": digest(package),
            "unchanged_ooxml_parts": 121, "changed_part": PART, "part_sha256": parts, "vba": observation}


TOKEN = re.compile(r'''"(?:""|[^"])*"|'[^\n]*|[^\W\d]\w*''')


def fold_line(line):
    return TOKEN.sub(lambda match: match[0] if match[0][0] in "\"'" else match[0].lower(), line.rstrip())


def fold_body(lines):
    return [fold_line(line) for line in "\n".join(lines).rstrip().splitlines()]


def components(raw):
    lines = raw.decode("utf-8-sig").splitlines()
    out = {}
    index = 0
    while index < len(lines):
        if not lines[index].startswith("COMPONENT: "):
            index += 1
            continue
        name = lines[index].removeprefix("COMPONENT: ")
        assert name not in out and lines[index + 1].startswith("TYPE: ") and lines[index + 2].startswith("LINES: ")
        assert re.fullmatch(r"=+", lines[index + 3])
        count = int(lines[index + 2].removeprefix("LINES: "))
        out[name] = (lines[index + 1], fold_body(lines[index + 4:index + 4 + count]))
        index += 4 + count
    return out


def verify_export(repo, checks, source):
    previous = components(load_baseline(repo, DUMP, OLD_DUMP))
    export = (RELEASE / RELEASE_EXPORT).read_bytes()
    current = components(export)
    assert current.keys() == previous.keys() and len(current) == 225
    assert all(current[name][0] == previous[name][0] for name in current)
    assert [name for name in current if current[name] != previous[name]] == [MODULE]
    text = source.decode("utf-8").splitlines()
    assert fold_body(text[text.index("Option Explicit"):]) == current[MODULE][1]
    owner = loads((RELEASE / "ExportClosure.json").read_text(encoding="utf-8-sig"))
    log = (RELEASE / "Export.log").read_text(encoding="utf-8-sig")
    assert owner["State"] == "Absent"
    assert log.count(f"OWNED_EXCEL: id={owner['PID']}; utcStartTicks={owner['StartTicksUTC']}") == 1
    assert f"VBA_READ_ONLY_EXPORT: components=225; sourceSHA256={checks['candidate_sha256']}; sourceUnchanged=True;" in log
    return {"candidate_sha256": checks["candidate_sha256"], "vba_all_code_sha256": digest(export),
            "components": len(current), "changed": [MODULE], "unchanged_components": 224}


def write_new(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(content)


def json_bytes(data):
    return (dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--repo", type=Path, required=True)
    phase = cli.add_mutually_exclusive_group(required=True)
    for flag in ("check", "stage", "verify-package", "verify-export"):
        phase.add_argument(f"--{flag}", action="store_true")
    cli.add_argument("--near-event-proof", type=Path)
    cli.add_argument("--near-event-sha")
    args = cli.parse_args()
    assert bool(args.near_event_proof) == bool(args.near_event_sha)
    assert not args.near_event_proof or args.verify_export
    repo = args.repo.resolve()
    source, compiled = clean_inputs(repo)
    original = load_baseline(repo, BOOK, OLD_BOOK)
    load_baseline(repo, DUMP, OLD_DUMP)
    if args.verify_package or args.verify_export:
        old = (RELEASE / "PackageChecks.json").read_bytes()
        package = (RELEASE / RELEASE_BOOK).read_bytes()
        assert (RELEASE / CLASS).read_bytes() == source
        record = verify_parts(original, compiled, package, observed_sources(repo, original, package, source))
        assert old == json_bytes(record)
        if args.verify_export:
            export = verify_export(repo, record, source)
            if args.near_event_proof:
                assert re.fullmatch(r"[A-Fa-f0-9]{64}", args.near_event_sha)
                proof = pinned(args.near_event_proof, args.near_event_sha.upper())
                export["reviewed_near_event_evidence_sha256"] = digest(proof)
            print("HARDSHEAR RELEASE NATIVE EXPORT VERIFIED", dumps(export))
            return
    else:
        observation = observed_sources(repo, original, compiled, source)
        package = package_bytes(original, compiled)
        record = verify_parts(original, compiled, package, observation)
        if args.stage:
            assert RELEASE.resolve() == RELEASE.absolute() and RELEASE.parent.is_dir()
            guard = pinned(CLEAN / "Guard-IsolatedOffice.ps1", GUARD_SHA)
            exporter = pinned(repo / EXPORT_SCRIPT, EXPORT_SCRIPT_SHA)
            RELEASE.mkdir()
            for name, data in {
                RELEASE_BOOK: package, CLASS: source, "PackageChecks.json": json_bytes(record),
                "Stage-Release.py": Path(__file__).read_bytes(),
                "Export-Release.ps1": (HERE / "Export-Release.ps1").read_bytes(),
                "Guard-IsolatedOffice.ps1": guard, EXPORT_SCRIPT: exporter,
            }.items():
                write_new(RELEASE / name, data)
            (RELEASE / "Temp").mkdir()
    print("HARDSHEAR RELEASE OOXML VERIFIED", record["candidate_sha256"], record["vba"]["vba_sha256"], RELEASE)


if __name__ == "__main__":
    main()
