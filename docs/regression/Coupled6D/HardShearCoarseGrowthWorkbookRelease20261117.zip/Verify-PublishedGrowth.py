"""Verify the packaged HardShear release and optionally reread the installed artifacts."""
from argparse import ArgumentParser
from io import BytesIO
from pathlib import Path, PureWindowsPath
from json import loads
import re
from runpy import run_path
from subprocess import check_output
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
RELEASE_BOOK = "97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5"
RELEASE_VBA = "EEFABBAF894B501ABFC04B3097E6A0313E36430000E78413171532E549F85870"
RELEASE_EXPORT = "8F48A525BD7983304E7CB83874F4FBCE0F475C63ED4D210E2550353DE0F956EF"
PACKAGED_RECEIPT = "BD805238DC41B7ED129BFEE902A8DEC11ADB225B3337C82193829EBBC4528C7E"
GROWTH_ARCHIVE = "HardShearCoarseGrowthWorkbookNative20261117.zip"
GROWTH_SHA = "40B29680E2E73033519883545091BD201DC109430D405151D8EC5EBF97B99302"
LATE_ARCHIVE = "HardShearLateSteelDiagnosticNative20261117.zip"
LATE_SHA = "4AB502FC1CA801C30AD5A0C31A618768C7A43D9CED9C95304F334AB4F9D62CF9"
OWNER_PATH = PureWindowsPath(r"D:\CodexScratch\RC_Section_NDM_TQ\HardGrowthRelease1\docs\regression\Audit03\VBA_All_Code.txt")
MODULE = "CCoupledDeformationContinuation"


def json_file(path):
    return loads(path.read_text(encoding="utf-8-sig"))


def workbook_parts(raw, digest):
    with ZipFile(BytesIO(raw)) as book:
        names = book.namelist()
        assert len(names) == len(set(names)) == 122
        return {name: digest(book.read(name)) for name in names}


def component_records(stage, raw):
    return {name: {"type": kind.removeprefix("TYPE: "),
                   "normalized_lines_sha256": stage["digest"]("\n".join(lines).encode("utf-8"))}
            for name, (kind, lines) in stage["components"](raw).items()}


def git_blob(repo, stage, path):
    return check_output(["git", "cat-file", "blob", f"{stage['BASE_REVISION']}:{path}"], cwd=repo)


def verify_package_bytes(stage, repo, parts, previous_book, book, export, source, records):
    digest = stage["digest"]
    assert digest(book) == RELEASE_BOOK and digest(export) == RELEASE_EXPORT
    assert workbook_parts(book, digest) == parts
    assert stage["observed_sources"](repo, previous_book, book, source)["changed_components"] == [MODULE]
    assert component_records(stage, export) == records


def check(root, repo, *, installed=False, package=None, export=None, saved_workbook=None):
    stage = run_path(str(root / "Stage-Release.py"))
    digest, pinned = stage["digest"], stage["pinned"]
    inventory = json_file(root / "SHA256SUMS.json")
    actual = {item.relative_to(root).as_posix() for item in root.rglob("*") if item.is_file()}
    assert actual == set(inventory) | {"SHA256SUMS.json"}
    for name, expected in inventory.items():
        path = (root / name).resolve()
        assert path.is_relative_to(root) and digest(path.read_bytes()) == expected, name

    class_name = stage["CLASS"]
    source = pinned(root / class_name, stage["CLEAN_SOURCE"])
    original_book = git_blob(repo, stage, stage["BOOK"])
    original_export = git_blob(repo, stage, stage["DUMP"])
    original_source = git_blob(repo, stage, class_name)
    assert digest(original_book) == stage["OLD_BOOK"] and digest(original_export) == stage["OLD_DUMP"]
    original_source = original_source.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
    assert digest(original_source) == "5154E5B80EF6D3CB16E592F533185FDC3816AA228AA64C14BBC11CA1EB2408FB"
    stock_lines = [line for line in source.splitlines(keepends=True) if b"POST_PEAK_EXTENDED_RATIO" not in line]
    assert b"".join(stock_lines) == original_source

    stage_report = json_file(root / "PackageChecks.json")
    stored_parts = stage_report["part_sha256"]
    original_parts = workbook_parts(original_book, digest)
    assert list(original_parts) == list(stored_parts)
    assert [name for name in original_parts if original_parts[name] != stored_parts[name]] == [stage["PART"]]
    assert stage_report["base_sha256"] == stage["OLD_BOOK"] and stage_report["compiled_sha256"] == stage["CLEAN_BOOK"]
    assert stage_report["candidate_sha256"] == RELEASE_BOOK and stage_report["unchanged_ooxml_parts"] == 121
    assert stored_parts[stage["PART"]] == stage_report["vba"]["vba_sha256"] == RELEASE_VBA
    assert stage_report["vba"]["component_count"] == 225 and stage_report["vba"]["changed_components"] == [MODULE]
    assert stage_report["vba"]["source_sha256"] == stage["CLEAN_SOURCE"]

    original_records = component_records(stage, original_export)
    exported = json_file(root / "NativeVbeModules.json")
    assert exported["export_sha256"] == RELEASE_EXPORT
    records = exported["components"]
    assert len(original_records) == len(records) == 225 and original_records.keys() == records.keys()
    assert all(original_records[name]["type"] == records[name]["type"] for name in records)
    assert [name for name in records if records[name] != original_records[name]] == [MODULE]
    source_lines = source.decode("utf-8").splitlines()
    body = stage["fold_body"](source_lines[source_lines.index("Option Explicit"):])
    assert records[MODULE]["normalized_lines_sha256"] == digest("\n".join(body).encode("utf-8"))
    export_receipt = (root / "Export.log").read_text(encoding="utf-8-sig")
    export_owner = json_file(root / "ExportClosure.json")
    assert export_owner["State"] == "Absent"
    assert export_receipt.count(f"OWNED_EXCEL: id={export_owner['PID']}; utcStartTicks={export_owner['StartTicksUTC']}") == 1
    paths = re.findall(
        rf"^VBA_READ_ONLY_EXPORT: components=225; sourceSHA256={RELEASE_BOOK}; sourceUnchanged=True; output=(.+)$",
        export_receipt, re.MULTILINE,
    )
    assert len(paths) == 1 and PureWindowsPath(paths[0]) == OWNER_PATH

    archives = repo / "docs/regression/Coupled6D"
    with ZipFile(BytesIO(pinned(archives / stage["CLEAN_ARCHIVE"], stage["CLEAN_ARCHIVE_SHA"]))) as clean:
        clean_receipt = clean.read("ABVerification.json")
        clean_proof = loads(clean_receipt)
        assert clean.read(class_name) == source and clean_proof["B"]["source_sha256"] == stage["CLEAN_BOOK"]
        clean_plan = loads(clean.read("ABManifest.json"))
        for script in ("Verify-FullAB.py", "ReadWorkbookCurve.py"):
            assert clean_plan["inputs"][script] == inventory[script]
    with ZipFile(BytesIO(pinned(archives / GROWTH_ARCHIVE, GROWTH_SHA))) as growth:
        reference = loads(growth.read("CandidateWorkbookCurve.json"))["entries"]
    with ZipFile(BytesIO(pinned(archives / LATE_ARCHIVE, LATE_SHA))) as late:
        event = loads(late.read("ABVerification.json"))["late_steel_test"]
        assert event["point"] == 30 and event["same_anchor_and_restored_B"] and not event["physical_limit_certified"]
        assert all(event["routes"][arm]["findings"][0] == "LATE_NUMFAIL_NO_CAPACITY" for arm in ("1", "2"))

    verify = run_path(str(root / "Verify-FullAB.py"))
    actual = verify["native"](root / "Native/Packaged", RELEASE_BOOK)
    for name in ("direct_N_Nmm", "capacity_status", "result_code", "lower_lambda", "limit_lambda",
                 "ultimate_N_Nmm", "probes", "assertions"):
        assert clean_proof["B"][name] == actual[name], name
    run_receipt = loads(pinned(root / "PackagedNativeVerification.json", PACKAGED_RECEIPT))
    assert run_receipt["native"] == actual and run_receipt["workbook_sha256"] == RELEASE_BOOK
    assert run_receipt["clean_proof_sha256"] == digest(clean_receipt)
    curve = run_receipt["curve"]
    assert curve["entries"] == reference == clean_proof["curve"]["entries"] and len(reference) == 136
    if saved_workbook:
        parser = run_path(str(root / "ReadWorkbookCurve.py"))
        assert parser["read_curve"](saved_workbook) == curve
    if installed:
        package, export = repo / stage["BOOK"], repo / stage["DUMP"]
        raw = (repo / class_name).read_bytes().replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        assert raw == source
    if package or export:
        assert package and export
        verify_package_bytes(stage, repo, stored_parts, original_book, package.read_bytes(), export.read_bytes(), source, records)
    return {"workbook_sha256": RELEASE_BOOK, "native_vba_export_sha256": RELEASE_EXPORT, "unchanged_ooxml_parts": 121,
            "modules": 225, "changed_modules": [MODULE], "accepted_curve_points": len(reference) // 2,
            "last_lambda": reference[-2][5], "capacity_status": actual["capacity_status"], "probes": actual["probes"],
            "assertions": actual["assertions"], "macro_seconds": actual["timing_s"]["results"],
            "installed_artifacts_read_back": installed}


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--repo", type=Path, required=True)
    cli.add_argument("--verify-installed", action="store_true")
    options = cli.parse_args()
    proof = check(HERE, options.repo.resolve(), installed=options.verify_installed)
    print("HARDSHEAR PACKAGED RELEASE PORTABLE VERIFIED")
    print(proof)
