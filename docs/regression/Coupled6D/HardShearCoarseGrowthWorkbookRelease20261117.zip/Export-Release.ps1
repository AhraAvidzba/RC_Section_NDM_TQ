# Read the final packaged candidate in VBE without running macros or saving.
param([Parameter(Mandatory=$true)][string]$Repository)

$ErrorActionPreference='Stop'
$release='D:\CodexScratch\RC_Section_NDM_TQ\HardGrowthRelease1'
if ((Resolve-Path -LiteralPath $PSScriptRoot).Path -ine $release) {throw 'Unexpected release directory.'}
$growthPreviousTemp=$env:TEMP
$growthPreviousTmp=$env:TMP
Push-Location -LiteralPath $release
try {
    python -B -X utf8 './Stage-Release.py' --repo $Repository --verify-package
    if ($LASTEXITCODE) {throw 'The staged package did not pass offline verification.'}
    if ((Test-Path -LiteralPath 'Export.log') -or (Test-Path -LiteralPath 'docs/regression/Audit03/VBA_All_Code.txt')) {
        throw 'The release already has a native export.'
    }
    . './Guard-IsolatedOffice.ps1'
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    Assert-IsolatedOfficeReady 'ExportHardGrowthRelease'
    & './tools/build_workbook/Export-Audit03VbaSnapshot.ps1' `
        -WorkbookPath 'docs/regression/Audit03/RC_Section_NDM.xlsm' `
        -OutputPath 'docs/regression/Audit03/VBA_All_Code.txt' |
        Tee-Object -FilePath 'Export.log'
    Save-OfficeClosure 'Export.log' 'ExportClosure.json'
    python -B -X utf8 './Stage-Release.py' --repo $Repository --verify-export
    if ($LASTEXITCODE) {throw 'VBE export does not match the release inputs.'}
} finally {
    $env:TEMP=$growthPreviousTemp
    $env:TMP=$growthPreviousTmp
    Pop-Location
}
