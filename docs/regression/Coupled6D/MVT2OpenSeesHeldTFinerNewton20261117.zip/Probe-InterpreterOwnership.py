"""Observe the configured Python venv's redirector without loading OpenSees."""

import argparse
import ctypes as ct
from ctypes import wintypes
from datetime import UTC, datetime
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent
SOURCE = "import json,os,sys;print(json.dumps({'pid':os.getpid(),'parent_pid':os.getppid(),'executable':sys.executable,'base_executable':sys._base_executable}))"


def absent(pid):
    kernel = ct.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    handle = kernel.OpenProcess(0x101000, False, pid)
    if handle:
        try:
            kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
            kernel.WaitForSingleObject.restype = wintypes.DWORD
            kernel.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ct.POINTER(wintypes.DWORD))
            kernel.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ct.POINTER(wintypes.FILETIME),) * 4
            code = wintypes.DWORD()
            terminated = kernel.WaitForSingleObject(handle, 0) == 0
            queried = kernel.GetExitCodeProcess(handle, ct.byref(code))
            result = {"pid": pid, "observed_absent": False, "terminated": terminated, "OpenProcess_error": 0,
                      "process_exit": code.value if queried else None}
            times = [wintypes.FILETIME() for _ in range(4)]
            if kernel.GetProcessTimes(handle, *(ct.byref(field) for field in times)):
                ticks = lambda field: (field.dwHighDateTime << 32) | field.dwLowDateTime
                result.update(created_utc_filetime=str(ticks(times[0])), exited_utc_filetime=str(ticks(times[1])))

            class ProcessBasic(ct.Structure):
                _fields_ = [("exit_status", wintypes.LONG), ("address", ct.c_void_p), ("affinity", ct.c_size_t),
                            ("priority", wintypes.LONG), ("pid", ct.c_size_t), ("parent_pid", ct.c_size_t)]

            info = ProcessBasic()
            query = ct.WinDLL("ntdll").NtQueryInformationProcess
            query.argtypes = (wintypes.HANDLE, wintypes.ULONG, ct.c_void_p, wintypes.ULONG, ct.c_void_p)
            query.restype = wintypes.LONG
            query_status = query(handle, 0, ct.byref(info), ct.sizeof(info), None)
            result.update(basic_information_query_status=query_status)
            if query_status == 0:
                assert info.pid == pid
                result.update(kernel_parent_pid=info.parent_pid)
            return result
        finally:
            kernel.CloseHandle(handle)
    error = ct.get_last_error()
    return {"pid": pid, "observed_absent": error == 87, "OpenProcess_error": error}


def digest(content):
    return sha256(content).hexdigest().upper()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--native", type=Path, default=HERE / "FinerHeldTNative.json")
    parser.add_argument("--receipt", type=Path, default=HERE / "FinerHeldTNative.receipt.json")
    parser.add_argument("--out", type=Path, default=HERE / "InterpreterOwnership.json")
    options = parser.parse_args()
    native, receipt = options.native.read_bytes(), options.receipt.read_bytes()
    raw, host = json.loads(native), json.loads(receipt)
    command = [sys.executable, "-B", "-X", "utf8", "-c", SOURCE]
    with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as process:
        output, errors = process.communicate(timeout=12)
        assert process.returncode == 0 and not errors
        observed = json.loads(output)
        parent_alias, launched = process.pid, observed["pid"]
        assert observed["parent_pid"] == parent_alias != launched, observed
        assert Path(observed["executable"]) == Path(sys.executable)
        assert Path(observed["base_executable"]) == Path(sys._base_executable)
    launcher, engine = host["child_pid"], raw["owned_engine_pid"]
    observations = (absent(launcher), absent(engine))
    report = {"observed_utc": datetime.now(UTC).isoformat(), "probe_did_not_import_opensees": True,
              "popen_pid": parent_alias, "interpreter": observed, "probe_exit": process.returncode,
              "venv_executable_sha256": digest(Path(sys.executable).read_bytes()),
              "venv_configuration_sha256": digest((Path(sys.executable).parents[1] / "pyvenv.cfg").read_bytes()),
              "original_launcher_observation": observations[0], "original_engine_observation": observations[1],
              "original_parent_link_retroactively_available": observations[1].get("kernel_parent_pid") == launcher,
              "native_sha256": digest(native), "launcher_receipt_sha256": digest(receipt)}
    assert all(obs["observed_absent"] or (obs.get("terminated") and obs.get("process_exit") == 0) for obs in observations), observations
    with options.out.open("xb") as output_stream:
        output_stream.write((json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode())
    print("VENV LAUNCHER CONFIRMED", parent_alias, "=>", launched, "original PIDs reaped", launcher, engine,
          "original lineage identified", report["original_parent_link_retroactively_available"])


if __name__ == "__main__":
    main()
