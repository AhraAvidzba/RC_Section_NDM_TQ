"""Verify the accepted OpenSees prefix, six actual forces, and termination without OpenSees."""

import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isfinite
from pathlib import Path
import re
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
ARCHIVES = HERE.parents[1] / "docs/regression/Coupled6D"
UPSTREAM = HERE.parent / "mvt-external/distributed"
NAME = "MVT2OpenSeesHeldTSmallSteps20261117.zip"
UPSTREAM_SHA = "49972528D7D4F8E8006BECB54489FA6FD7F4C5A7952811C1D9E36E41C55484EC"
START_STATE_SHA = "86A9B65C61F1196158D321AF1EBADC9A1FA0C9AD7E5093B7CD68586482DB12EB"
UPSTREAM_RESULT = "NonlinearDistributedHeldTSmallSteps.json"
PREFIX = [6.25, 7.5, 8.75, 10., 11.25]
TARGETS = [11.5625, 11.875, 12.1875, 12.5, 12.8125, 13.125, 13.4375, 13.75, 14.0625, 14.375, 14.6875, 15.]
TORQUE_NMM = 10510000.


def require(condition, label):
    if not condition:
        raise ValueError(label)


def digest(data):
    return sha256(data).hexdigest().upper()


def load_module(name, file):
    spec = spec_from_file_location(name, file)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepared_prefix(record):
    groups = {"Q5_attempt": record["base_replay_attempt"], "Q5_differences": record["base_Q5_replayed"],
              "Q5_state": record["base_Q5_state"], "attempts": record["attempts"][:12],
              "replay_states": record["replay_states"], "shear_states": record["shear_confirmed_states"][:5]}
    return json.dumps(groups, allow_nan=False, sort_keys=True, separators=(",", ":")).encode()


def reference(archives, upstream):
    original = archives / NAME
    require(digest(original.read_bytes()) == UPSTREAM_SHA, "Archived held-T packet hash")
    with ZipFile(original) as packet:
        original_raw = packet.read(UPSTREAM_RESULT)
        saved_proof = packet.read("VerificationHeldTSmallSteps.json")
        for name in (UPSTREAM_RESULT, "Verify-HeldTSmallSteps.py", "Verify-Shear.py", "Verify-Pads.py", "Verify-Torsion.py"):
            require((upstream / name).read_bytes() == packet.read(name), name)
        source_hash = digest(packet.read("MVT2HeldTSmallSteps.py"))
    previous_check = load_module("previous_check", upstream / "Verify-HeldTSmallSteps.py")
    prior_verified = previous_check.verify(upstream / UPSTREAM_RESULT, archives)
    require(prior_verified == json.loads(saved_proof), "Prior independent proof reproduction")
    require(prior_verified["last_confirmed_Qy_kN"] == PREFIX[-1], "Prior terminal Qy")
    reject = prior_verified["rejected_step"]
    require(reject["target_Qy_kN"] == 12.5 and reject["solver_code"] == -3, "Prior solver rejection")
    require(reject["rollback_time_exact"] and reject["rollback_all_nodes_exact"] and
            reject["rollback_sampled_damage_exact"] is False, "Prior material rollback failure")
    old = json.loads(original_raw)
    require(digest(prepared_prefix(old)) == START_STATE_SHA, "Exact archived prefix")
    return old, digest(original_raw), source_hash


def closed_engine(host, record, raw, receipt, ownership):
    launcher, engine = host["child_pid"], record["owned_engine_pid"]
    require(launcher > 0 and engine > 0, "Engine identity")
    if launcher == engine:
        return "direct child and recorded engine PID match"
    witness = json.loads(ownership.read_bytes())
    require(witness["native_sha256"] == digest(raw.read_bytes()) and
            witness["launcher_receipt_sha256"] == digest(receipt.read_bytes()), "Ownership evidence bound to original run")
    shim = witness["interpreter"]
    require(witness["probe_exit"] == 0 and witness["probe_did_not_import_opensees"] and
            shim["parent_pid"] == witness["popen_pid"] != shim["pid"], "Independent launcher relationship")
    outer, actual = witness["original_launcher_observation"], witness["original_engine_observation"]
    require(actual["pid"] == engine and outer["pid"] == launcher and witness["original_parent_link_retroactively_available"],
            "Exact original engine and launcher")
    require(actual["kernel_parent_pid"] == launcher and all(
        event["basic_information_query_status"] == 0 and event["terminated"] and event["process_exit"] == 0
        for event in (outer, actual)), "Original kernel lineage and termination")
    original_start = int(outer["created_utc_filetime"])
    original_end = int(outer["exited_utc_filetime"])
    require(original_start <= int(actual["created_utc_filetime"]) <= int(actual["exited_utc_filetime"]) <= original_end,
            "Original process lifetimes")
    require(abs((original_end - original_start) / 1e7 - host["wall_elapsed_seconds"]) < 1., "Recorded original launcher duration")
    completion = raw.with_suffix(".stdout.log").read_text(encoding="utf-8").strip()
    require(completion == f"MVT2_HELD_T_FINER {record['termination']} states {len(record['shear_confirmed_states'])}",
            "Recorded terminal engine stdout")
    return "original engine kernel parent matches venv launcher, both terminated"


def verify(raw, receipt, archives, upstream, ownership):
    old, old_sha, old_source = reference(archives, upstream)
    record = json.loads(raw.read_bytes())
    host = json.loads(receipt.read_bytes())
    require(host["child_exit"] == 0 and host["wait_returned"] and not host["watchdog_timeout"], "Engine not cleanly reaped")
    process_identity = closed_engine(host, record, raw, receipt, ownership)
    require(host["hard_cap_seconds"] == record["process_deadline_seconds"] and
            0. <= record["engine_elapsed_seconds"] <= host["wall_elapsed_seconds"] <= host["hard_cap_seconds"] + 1., "Engine wall budget")
    require(record["reference_archive_sha256"] == UPSTREAM_SHA and record["reference_raw_sha256"] == old_sha and
            record["reference_source_sha256"] == old_source, "Archive provenance")
    require(record["planned_prefix_Qy_kN"] == PREFIX and record["planned_new_Qy_kN"] == TARGETS and
            record["planned_Qy_kN"] == PREFIX + TARGETS, "Exact shear schedule")
    require(record["held_torsion_kNm"] == 10.51 and record["original_Newton_step_kN"] == 1.25 and
            record["trial_Newton_step_kN"] == 0.3125 and record["solver_algorithm"] == "Newton", "Chosen test variant")
    require(record["prefix_exact"] and record["accepted_torsion_replayed"] == 7 and record["replay_passed"] and
            record["prefix_expected_sha256"] == record["prefix_observed_sha256"] == START_STATE_SHA, "Recorded accepted prefix")
    require(prepared_prefix(record) == prepared_prefix(old), "Exact replay of all recorded physical groups, loads and solver counts")
    require(not (record["physical_limit_established"] or record["prior_Q12_5_damaged_engine_reused"] or
                 record["recoverable_continuation_after_rejection"] or record["restart_from_archived_material_state"]), "Scope of the observation")
    for key in ("opensees_version", "E_MPa", "nu", "fc_MPa", "ft_MPa", "steel_E_MPa", "steel_yield_MPa",
                "steel_post_yield_slope_MPa", "explicit_Gt_N_per_mm", "explicit_Gc_N_per_mm", "explicit_Lch_mm",
                "explicit_compression_peak_strain", "ASD_autoRegularization", "compressive_knots", "support_mode",
                "asd_linearization", "kinematics", "pad_xz_size_mm", "validated_input_sha256",
                "Newton_iteration_cap", "norm_unbalance_force"):
        require(record[key] == old[key], f"Changed criterion/material or rig: {key}")

    pad = load_module("heldT_fine_pad_verify", upstream / "Verify-Pads.py")
    tensor = load_module("heldT_fine_tensor_verify", upstream / "Verify-Torsion.py")
    shear = load_module("heldT_fine_shear_verify", upstream / "Verify-Shear.py")
    rows = record["shear_confirmed_states"][5:]
    events = record["attempts"][12:]
    require(len(events) <= len(TARGETS), "Exceeded maximum finer trial count")
    retained = iter(rows)
    last = PREFIX[-1]
    rejected = None
    accepted, comparison = [], []
    for index, step in enumerate(events):
        target = TARGETS[index]
        require(step["phase"] == "fixed_T_finer_shear_step" and step["target_Qy_kN"] == target and
                abs(step["from_Qy_kN"] - last) < 2e-12 and 0. <= step["solver_elapsed_seconds"], "Discontinuous accepted history")
        if step["solver_code"] != 0:
            require(index == len(events) - 1 and step["solver_code"] == -3 and
                    step["rollback_time_exact"] and step["rollback_all_nodes_exact"] and
                    type(step["rollback_sampled_damage_exact"]) is bool, "Terminal solver rejection and rollback scope")
            require(abs(step["observed_Qy_kN"] - last) < 2e-12, "Rejected load advanced time")
            rejected = step
            break
        row = next(retained)
        q = row["Qy_kN"]
        require(isfinite(q) and q == step["observed_Qy_kN"] and abs(q - target) < 2e-12, "Exact actual accepted force")
        require(0 < step["iterations"] <= record["Newton_iteration_cap"], "Accepted solver iteration count")
        require(abs(row["nominal_midspan_Mx_kNm"] - 0.60 * q) < 2e-12, "Nominal midspan Mx")
        forces = pad.verify_state(row["rig_balance"], TORQUE_NMM, 2000. * q)
        stresses = tensor.tensors(row)
        twist = row["displacement"]["clear_twist_rad_per_m"]
        require(len(twist) == 2 and all(map(isfinite, twist.values() if isinstance(twist, dict) else twist)), "Twist evidence")
        accepted.append({"Qy_kN": q, "iterations": step["iterations"], "force_check": forces, "twist_rad_per_m": twist,
                         "concrete_peak_stresses_MPa": stresses})
        if abs(q - 15.) < 2e-12:
            ndm = archives / "MVT2ShearABOffline.zip"
            require(digest(ndm.read_bytes()) == "DEA4CCBB06ECCCECE9B076BF4D1B2ACA2DD7FCC4E84786FCE740FDFD6581FAB3",
                    "Retained NDM Q15 reference")
            comparison.append({"Qy_kN": q, "NDM": shear.validated_ndm(ndm, record)[15.],
                               "OpenSees_twist_rad_per_m": twist, "OpenSees_local_Mx_kNm_range": [0.3*q, 0.36*q],
                               "nominal_midspan_Mx_kNm": 0.6*q})
        last = q
    require(next(retained, None) is None, "Reported state with no accepted attempt")
    termination = record["termination"]
    if rejected:
        require(termination == "first_finer_step_rejected_engine_discarded", "Engine must stop after first rejected step")
        stderr = raw.with_suffix(".stderr.log").read_text(encoding="utf-8")
        (count, achieved, limit) = re.findall(
            r"after:\s*(\d+)\s+iterations\s+current Norm:\s*(\S+)\s+\(max:\s*(\S+),", stderr)[-1]
        require(int(count) == record["Newton_iteration_cap"] and float(achieved) > float(limit) == record["norm_unbalance_force"],
                "Global iterative residual and frozen stopping threshold")
        rejected = {**rejected, "native_global_L2_unbalance_N": float(achieved), "native_iteration_tolerance_N": float(limit),
                    "native_global_L2_over_tolerance": float(achieved) / float(limit)}
    elif len(rows) == len(TARGETS):
        require(termination == "all_finer_steps_verified", "Successful terminal schedule")
    else:
        require(termination == "bounded_time_before_next_finer_step", "Incomplete simulation without bounded stop")
    return {"status": "PASS", "native_sha256": digest(raw.read_bytes()), "source_prefix_sha256": START_STATE_SHA,
            "accepted_prefix_state_count": 13, "verified_Qy_kN": last, "new_accepted_states": accepted,
            "comparison_at_15_kN": comparison, "rejection": rejected, "termination": termination,
            "engine_pid": record["owned_engine_pid"], "launcher_pid": host["child_pid"], "process_identity": process_identity,
            "process_closed": True, "wall_seconds": host["wall_elapsed_seconds"],
            "physical_limit_established": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-only", action="store_true")
    parser.add_argument("--raw", type=Path, default=HERE / "FinerHeldTNative.json")
    parser.add_argument("--receipt", type=Path, default=HERE / "FinerHeldTNative.receipt.json")
    parser.add_argument("--ownership", type=Path, default=HERE / "InterpreterOwnership.json")
    parser.add_argument("--archives", type=Path, default=ARCHIVES)
    parser.add_argument("--upstream", type=Path, default=UPSTREAM)
    parser.add_argument("--out", type=Path, default=HERE / "VerificationFinerHeldT.json")
    options = parser.parse_args()
    if options.reference_only:
        _, previous, _ = reference(options.archives, options.upstream)
        print("ARCHIVED HELD-T VERIFIED", previous, START_STATE_SHA)
        return
    result = verify(options.raw, options.receipt, options.archives, options.upstream, options.ownership)
    content = (json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    with options.out.open("xb") as report:
        report.write(content)
    print("MVT2 HELD-T FINER PROOF PASS", result["verified_Qy_kN"], result["termination"], digest(content))


if __name__ == "__main__":
    main()
