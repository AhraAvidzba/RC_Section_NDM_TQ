"""Check every retained MVT2 increment against physical load and frozen replay records."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
TORSION_ARCHIVE = "E330C5999357A5E56847488315AE25384B507AEF2ED650071672938A1A5D32FB"
SHEAR_ARCHIVE = "BADC056B0CD7287D62441D19D9E242719485F6CBE92969B25C10C7AEF8329F8C"
DAMAGE_ARCHIVE = "DD6FA6FA923F2FB1A2DBBFAD772A146201566B31614F14DFBF03F5234D3D54BE"
NDM_ARCHIVE = "DEA4CCBB06ECCCECE9B076BF4D1B2ACA2DD7FCC4E84786FCE740FDFD6581FAB3"
TORQUE = 10510000.0
TARGETS = [6.25, 7.5, 8.75, 10.0, 11.25, 12.5, 13.75, 15.0]


def archive_bytes(archive, checksum, member):
    """Read the exact original record from a pinned upstream archive."""
    check(sha256(archive.read_bytes()).hexdigest().upper() == checksum, archive.name)
    with ZipFile(archive) as evidence:
        return evidence.read(member)


def check(condition, reason):
    """Reject incomplete or altered physical evidence."""
    if not condition:
        raise ValueError(reason)


def verify(raw, archives):
    """Check replay identity, force balance, accepted steps and the exact stop condition."""
    from importlib.util import module_from_spec, spec_from_file_location

    spec = spec_from_file_location("small_step_equilibrium", HERE / "Verify-Shear.py")
    controls = module_from_spec(spec)
    spec.loader.exec_module(controls)
    pad = controls.module("small_step_pad_force", HERE / "Verify-Pads.py")
    tensors = controls.module("small_step_tensors", HERE / "Verify-Torsion.py")

    torsion = archive_bytes(archives / "MVT2OpenSeesDistributedTorsion20261117.zip", TORSION_ARCHIVE,
                           "NonlinearDistributedContinue.json")
    shear = archive_bytes(archives / "MVT2OpenSeesDistributedShear20261117.zip", SHEAR_ARCHIVE,
                          "NonlinearDistributedShear15.json")
    damage = archive_bytes(archives / "MVT2OpenSeesDamageReplay20261117.zip", DAMAGE_ARCHIVE,
                           "NonlinearDistributedDamageReplay.json")
    record = json.loads(raw.read_bytes())
    preload = json.loads(torsion)
    q5 = json.loads(shear)["shear_confirmed_states"][0]

    check(record["source_rollback_diagnosis_sha256"] == sha256(damage).hexdigest().upper(), "original damaged rollback")
    check(record["torsion_execution_reference_sha256"] == sha256(torsion).hexdigest().upper(), "original accepted torsion")
    check(record["frozen_shear_native_sha256"] == sha256(shear).hexdigest().upper(), "original accepted Q5")
    check(record["accepted_torsion_replayed"] == 7 and record["replay_passed"], "full preload")
    check(record["planned_Qy_kN"] == TARGETS and record["held_torsion_kNm"] == 10.51, "physical schedule")
    check(record["opensees_version"] == preload["opensees_version"] == "3.8.0", "runtime")
    check(not record["physical_limit_established"], "scope of sampled loading")
    for name in ("ft_MPa", "fc_MPa", "E_MPa", "nu", "steel_yield_MPa", "explicit_Gt_N_per_mm", "explicit_Lch_mm",
                 "Newton_iteration_cap", "norm_unbalance_force", "validated_input_sha256"):
        check(record[name] == preload[name], name)

    for row, reference in zip(record["replay_states"], preload["states"], strict=True):
        check(all(value == 0.0 for value in row["maximum_replay_differences"].values()), "torsion replay drift")
        check(all(row[key] == reference[key] for key in row if key != "maximum_replay_differences"), "reference torsion data")
        pad.verify_state(row["rig_balance"], row["rig_balance"]["T_Nmm"], 0.0)
    check(record["base_replay_attempt"] == {"solver_code": 0, "iterations": 6, "time": 1.0 / 3.0}, "Q5 solver replay")
    base = record["base_Q5_state"]
    physical_fields = {"rig_balance", "displacement", "concrete_damage_by_station_band",
                       "steel_signed_extrema_by_band", "concrete_peak_stress_by_longitudinal_and_surface_band"}
    differences = record["base_Q5_replayed"]
    check(differences.keys() == physical_fields and all(value == 0.0 for value in differences.values()),
          "Q5 replay drift")
    check(all(base[key] == q5[key] for key in physical_fields), "exact Q5 field")
    check(base["Qy_kN"] == q5["Qy_kN"] == 5.0 and q5["nominal_milestone"], "Q5 reference load")
    for row in (base, q5):
        check(abs(row["nominal_midspan_Mx_kNm"] - 0.60 * row["Qy_kN"]) < 2e-12, "Q5 nominal moment")
    pad.verify_state(base["rig_balance"], TORQUE, 10000.0)

    actual = []
    stored = iter(record["shear_confirmed_states"])
    previous_qy = 5.0
    rejection = None
    steps = record["attempts"][7:]
    for index, step in enumerate(steps):
        target = TARGETS[index]
        check(step["phase"] == "fixed_T_small_shear_step" and step["target_Qy_kN"] == target, "fixed step size")
        check(abs(step["from_Qy_kN"] - previous_qy) < 2e-12, "uninterrupted accepted history")
        if step["solver_code"] != 0:
            check(index == len(steps) - 1, "engine reused after rejected material trial")
            check(step["solver_code"] == -3 and step["rollback_time_exact"] and step["rollback_all_nodes_exact"]
                  and not step["rollback_sampled_damage_exact"], "rejected trial and rollback signature")
            rejection = step
            break
        row = next(stored)
        check(abs(step["observed_Qy_kN"] - target) < 2e-12 and row["Qy_kN"] == step["observed_Qy_kN"], "actual accepted shear")
        check(abs(row["nominal_midspan_Mx_kNm"] - 0.60 * target) < 2e-12, "midspan bending moment")
        physical = pad.verify_state(row["rig_balance"], TORQUE, 2000.0 * row["Qy_kN"])
        stresses = tensors.tensors(row)
        actual.append({"Qy_kN": row["Qy_kN"], "iterations": step["iterations"], "force_check": physical,
                       "twist_rad_per_m": row["displacement"]["clear_twist_rad_per_m"],
                       "concrete_peak_stresses_MPa": stresses})
        previous_qy = row["Qy_kN"]
    check(next(stored, None) is None, "data not backed by an accepted attempt")
    termination = record["termination"]
    if rejection is not None:
        check(termination == "first_small_step_rejected_engine_discarded", "numerical stop")
    elif len(actual) == len(TARGETS):
        check(termination == "all_small_steps_verified", "complete schedule")
    else:
        check(termination == "bounded_time_before_next_shear_step", "bounded schedule")

    ndm = archives / "MVT2ShearABOffline.zip"
    check(controls.digest(ndm) == NDM_ARCHIVE, "retained NDM comparison")
    comparison = []
    for state in actual:
        q = state["Qy_kN"]
        if abs(q - 15.0) < 2e-12:
            comparison.append({"Qy_kN": q, "NDM": controls.validated_ndm(ndm, record)[15.0],
                               "OpenSees_twist_rad_per_m": state["twist_rad_per_m"],
                               "OpenSees_local_Mx_kNm_range": [0.30 * q, 0.36 * q],
                               "nominal_midspan_Mx_kNm": 0.60 * q})
    return {"status": "PASS", "last_confirmed_Qy_kN": previous_qy, "confirmed_states": actual,
            "comparison_at_15_kN": comparison, "rejected_step": rejection, "termination": termination,
            "physical_limit_established": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", type=Path, default=HERE / "NonlinearDistributedHeldTSmallSteps.json")
    parser.add_argument("--archives", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    options = parser.parse_args()
    proof = verify(options.raw, options.archives)
    with options.out.open("x", encoding="utf-8", newline="\n") as report:
        report.write(json.dumps(proof, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print("MVT2_SMALL_SHEAR_PROOF_PASS", proof["last_confirmed_Qy_kN"], proof["termination"])


if __name__ == "__main__":
    main()
