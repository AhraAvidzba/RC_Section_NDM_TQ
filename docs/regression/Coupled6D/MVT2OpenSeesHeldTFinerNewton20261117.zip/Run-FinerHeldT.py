"""Replay the archived OpenSees held-T path in a fresh domain and try 0.3125-kN steps."""

import argparse
from hashlib import sha256
import json
from os import getpid
from pathlib import Path
import subprocess
import sys
from time import monotonic
from types import SimpleNamespace
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent / "mvt-external/distributed"
ARCHIVES = HERE.parents[1] / "docs/regression/Coupled6D"
ARCHIVE = "MVT2OpenSeesHeldTSmallSteps20261117.zip"
ARCHIVE_SHA = "49972528D7D4F8E8006BECB54489FA6FD7F4C5A7952811C1D9E36E41C55484EC"
SOURCE_SHA = "AD54E674380AE0CEF9867E8ED17C9248A52936656B6929BC4022390D0383EDA6"
RAW_NAME = "NonlinearDistributedHeldTSmallSteps.json"
RAW_SHA = "09E0AF526ED355D58E71304181201840F52623A154EBBA477E8AA7CD2347821C"
PREFIX = (6.25, 7.5, 8.75, 10.0, 11.25)
NEXT = tuple(11.25 + i * 0.3125 for i in range(1, 13))
DEFAULT_WALL = 240

sys.dont_write_bytecode = True


def digest_bytes(data):
    return sha256(data).hexdigest().upper()


def wire(record):
    normalized = json.loads(json.dumps(record, allow_nan=False))
    return json.dumps(normalized, sort_keys=True, allow_nan=False, separators=(",", ":")).encode()


def archived(archive_root):
    original = archive_root / ARCHIVE
    if digest_bytes(original.read_bytes()) != ARCHIVE_SHA:
        raise ValueError("Held-T evidence archive changed")
    with ZipFile(original) as packet:
        raw = packet.read(RAW_NAME)
        if digest_bytes(raw) != RAW_SHA or digest_bytes(packet.read("MVT2HeldTSmallSteps.py")) != SOURCE_SHA:
            raise ValueError("Incorrect held-T evidence members")
    reference = json.loads(raw)
    if tuple(row["Qy_kN"] for row in reference["shear_confirmed_states"]) != PREFIX:
        raise ValueError("Archived five accepted shear increments changed")
    failure = reference["attempts"][-1]
    if failure["target_Qy_kN"] != 12.5 or failure["solver_code"] != -3 or failure["rollback_sampled_damage_exact"]:
        raise ValueError("Prior Q12.5 failure was absent or materially restored")
    return reference


def prefix_record(record):
    states = record["shear_confirmed_states"]
    return {"attempts": record["attempts"][: 7 + len(PREFIX)], "replay_states": record["replay_states"],
            "Q5_attempt": record["base_replay_attempt"], "Q5_differences": record["base_Q5_replayed"],
            "Q5_state": record["base_Q5_state"], "shear_states": states[:len(PREFIX)]}


def preflight(wall):
    for name, want in (("MVT2HeldTSmallSteps.py", SOURCE_SHA), (RAW_NAME, RAW_SHA)):
        if digest_bytes((ORIGINAL / name).read_bytes()) != want:
            raise ValueError(f"Working dependency changed: {name}")
    reference = archived(ARCHIVES)
    sys.path.insert(0, str(ORIGINAL))
    import MVT2HeldTSmallSteps as stock

    # This prepares geometry and hashes only. The native binding is loaded in child().
    geometry, metadata, torsion, q5 = stock.inputs(wall)
    for key in ("ft_MPa", "fc_MPa", "E_MPa", "nu", "steel_yield_MPa", "explicit_Gt_N_per_mm",
                "explicit_Lch_mm", "Newton_iteration_cap", "norm_unbalance_force", "held_torsion_kNm", "validated_input_sha256"):
        if wire(metadata[key]) != wire(reference[key]):
            raise ValueError(f"Physical parameter changed: {key}")
    metadata.update(scope="cold exact held-T Q11.25 replay followed by fixed 0.3125 kN steps",
                    reference_archive_sha256=ARCHIVE_SHA, reference_raw_sha256=RAW_SHA, reference_source_sha256=SOURCE_SHA,
                    planned_prefix_Qy_kN=list(PREFIX), planned_new_Qy_kN=list(NEXT),
                    planned_Qy_kN=list(PREFIX + NEXT), maximum_shear_attempts=len(PREFIX + NEXT),
                    original_Newton_step_kN=1.25, trial_Newton_step_kN=0.3125, solver_algorithm="Newton",
                    prefix_expected_sha256=digest_bytes(wire(prefix_record(reference))), prefix_exact=False,
                    restart_from_archived_material_state=False,
                    prior_Q12_5_damaged_engine_reused=False, physical_limit_established=False)
    return stock, geometry, metadata, torsion, q5, reference


def run_schedule(stock, model, geometry, report, torsion, q5, reference, output, deadline):
    # Call precisely the frozen routine (same analysis, observations and calls)
    # through its five accepted steps. The previously failed step is never run.
    stock.OUTPUT, stock.TARGETS_QY_KN = output, PREFIX
    stop = stock.trace(model, geometry.vertical_unit, report, torsion, q5, deadline)
    if stop != "all_small_steps_verified":
        return "prefix_replay_incomplete:" + str(stop)
    head = prefix_record(report)
    archive_head = prefix_record(reference)
    if wire(head) != wire(archive_head):
        report["prefix_nonmatching_groups"] = [key for key in head if wire(head[key]) != wire(archive_head[key])]
        return "prefix_replay_mismatch"
    report.update(prefix_exact=True, prefix_observed_sha256=digest_bytes(wire(head)))
    stock.SHEAR.persist(output, report)

    ops = model.ops
    for target in NEXT:
        if monotonic() >= deadline:
            return "bounded_time_before_next_finer_step"
        goal = target / 15.0
        before = stock.damage.ORIGINAL.rollback_sample(model)
        ops.integrator("LoadControl", goal - before[0])
        started = monotonic()
        code = ops.analyze(1)
        arrived = ops.getTime()
        attempt = {"phase": "fixed_T_finer_shear_step", "from_Qy_kN": before[0] * 15.0, "target_Qy_kN": target,
                   "observed_Qy_kN": arrived * 15.0, "solver_code": code, "iterations": ops.testIter(),
                   "solver_elapsed_seconds": monotonic() - started}
        report["attempts"].append(attempt)
        if code:
            after = stock.damage.ORIGINAL.rollback_sample(model)
            attempt.update(rollback_time_exact=after[0] == before[0], rollback_all_nodes_exact=after[1] == before[1],
                           rollback_sampled_damage_exact=after[2] == before[2])
            return "first_finer_step_rejected_engine_discarded"
        if abs(arrived - goal) > 2e-12:
            return "committed_load_time_mismatch"
        report["shear_confirmed_states"].append(stock.snapshot(model, arrived * 15.0))
        stock.SHEAR.persist(output, report)
    return "all_finer_steps_verified"


def child(prepared, output, wall):
    stock, geometry, report, torsion, q5, reference = prepared
    sys.path.insert(0, str(stock.damage.RIG.UTILITY.parent))
    import validate_opensees_hardshear as utility

    ops = utility.ops
    started = monotonic()
    deadline = started + wall - 15.
    model = stock.SHEAR.STARTUP.PadModel(geometry, SimpleNamespace(
        ops=stock.damage.ORIGINAL.MaterialCommands(ops, "default"), Prism=utility.Prism))
    stock.SHEAR.set_load(ops, 1, geometry.torque_unit, stock.damage.RIG.TORQUE)
    stock.SHEAR.configure_analysis(ops)
    report.update(termination="running", opensees_version=ops.version(), owned_engine_pid=getpid(),
                  process_deadline_seconds=wall, recoverable_continuation_after_rejection=False)
    stock.SHEAR.persist(output, report)
    try:
        report["termination"] = run_schedule(stock, model, geometry, report, torsion, q5, reference, output, deadline)
    except Exception as error:
        report.update(termination="engine_or_physical_verification_exception", detail=str(error))
        raise
    finally:
        report["engine_elapsed_seconds"] = monotonic() - started
        stock.SHEAR.persist(output, report)
    print("MVT2_HELD_T_FINER", report["termination"], "states", len(report["shear_confirmed_states"]))
    return 0 if report["prefix_exact"] and report["termination"] in (
        "all_finer_steps_verified", "first_finer_step_rejected_engine_discarded", "bounded_time_before_next_finer_step") else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs", action="store_true")
    mode.add_argument("--start", action="store_true")
    mode.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--wall-seconds", type=int, default=DEFAULT_WALL, choices=range(150, 301))
    opts = parser.parse_args()
    prepared = preflight(opts.wall_seconds)
    if opts.check_inputs:
        print("HELD_T_FINER_INPUTS_PASS", prepared[2]["prefix_expected_sha256"], "prefix", PREFIX, "next", NEXT)
        return 0
    output = HERE / "FinerHeldTNative.json"
    staged = [output, output.with_suffix(".json.part"), output.with_suffix(".receipt.json")]
    if opts.start:
        staged += [output.with_suffix(".stdout.log"), output.with_suffix(".stderr.log")]
    if any(path.exists() for path in staged):
        raise FileExistsError("Retain prior evidence. A fresh root is required for a new engine.")
    if opts.child:
        return child(prepared, output, opts.wall_seconds)
    command = [sys.executable, "-B", "-X", "utf8", str(Path(__file__).resolve()),
               "--child", "--wall-seconds", str(opts.wall_seconds)]
    with output.with_suffix(".stdout.log").open("xb") as stdout, output.with_suffix(".stderr.log").open("xb") as stderr:
        started = monotonic()
        with subprocess.Popen(command, stdout=stdout, stderr=stderr) as engine:
            timed_out = False
            try:
                code = engine.wait(timeout=opts.wall_seconds)
            except subprocess.TimeoutExpired:
                timed_out = True
                engine.kill()
                code = engine.wait()
            receipt = {"child_pid": engine.pid, "child_exit": code, "wait_returned": engine.poll() is not None,
                       "watchdog_timeout": timed_out, "wall_elapsed_seconds": monotonic() - started,
                       "hard_cap_seconds": opts.wall_seconds}
    with output.with_suffix(".receipt.json").open("x", encoding="utf-8", newline="\n") as log:
        log.write(json.dumps(receipt, indent=2) + "\n")
    print("MVT2_HELD_T_FINER_CLOSED", receipt)
    return 124 if timed_out else code


if __name__ == "__main__":
    sys.exit(main())
