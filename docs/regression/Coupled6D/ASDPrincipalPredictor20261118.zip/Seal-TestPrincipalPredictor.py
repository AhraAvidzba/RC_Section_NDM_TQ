"""ДЛЯ ТЕСТОВ: закрепляет независимые проверки длинной ветви и рабочего прогноза, сохраняя историю манифеста."""
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile, ZIP_DEFLATED


def TestSeal():
    """Выходы не входят в перечень входных файлов; их SHA-256 проверяется после нового вычисления."""
    repo=Path.cwd();scratch=Path('D:/CodexScratch/RC_Section_NDM_TQ');root=scratch/'PrincipalPredictorEvidence20261118'
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    outputs={'NativeProof.json','LongProof.json','PredictorProof.json'}
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper()
           for file in root.rglob('*') if file.is_file() and file.relative_to(root).as_posix() not in outputs|{'Files.json'}}
    (root/'Files.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    name='ASDPrincipalPredictor20261118';archive=scratch/(name+'.zip')
    with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as output:
        for file in sorted(root.rglob('*')):
            if file.is_file():output.write(file,file.relative_to(root).as_posix())
    assert archive.stat().st_size<100000000,(name,archive.stat().st_size)
    digest=sha256(archive.read_bytes()).hexdigest().upper();destination=repo/'docs/regression/Coupled6D'/(name+'.zip')
    assert not destination.exists();copyfile(archive,destination)
    additions=[];pins={}
    for scope,title,marker in (
        ('native','NativeProof.json','PRINCIPAL PREDICTOR NATIVE SOURCES BUDGETS AND PROCESS CLOSURES VERIFIED'),
        ('long','LongProof.json','PRIVATE 233 STATE PATH ALL FOUR EVENT FACES AND NEGATIVE SCOPE CONTROL VERIFIED'),
        ('predictor','PredictorProof.json','READONLY EQUILIBRIUM NORMAL STEP PREDICTOR REUSE INDEPENDENTLY VERIFIED')):
        pins[title]=sha256((root/title).read_bytes()).hexdigest().upper()
        additions.append({'id':'asd-principal-predictor-'+scope,'journal_section':608,'archive':name,
                          'script':'Check-TestPrincipalPredictor.py','arguments':['--repo','{repo}','--root','.','--scope',scope,'--out',title],
                          'stdout_contains':marker,'outputs':{title:pins[title]},'timeout_seconds':300})
    path=repo/'docs/reports/Coupled6DEvidence.json';text=path.read_text('utf-8').replace('\r\n','\n');old=json.loads(text)
    assert len(old['archives'])==298 and len(old['cases'])==323
    pos=text.index('\n  },\n  "cases": [');text=text[:pos]+',\n    '+json.dumps(name)+': '+json.dumps(digest)+text[pos:]
    pos=text.index('\n  ],\n  "frozen_repositories": {')
    text=text[:pos]+',\n'+',\n'.join('\n'.join('    '+line for line in json.dumps(case,ensure_ascii=False,indent=2).splitlines()) for case in additions)+text[pos:]
    new=json.loads(text);assert new['cases'][:323]==old['cases'] and len(new['cases'])==326
    assert all(new['archives'][key]==value for key,value in old['archives'].items())
    path.write_bytes(text.replace('\n','\r\n').encode())
    receipt={'archive':name,'bytes':archive.stat().st_size,'sha256':digest,'proofs':pins}
    (repo/'tmp/PrincipalPredictorSeal.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,indent=2),flush=True)


if __name__=='__main__':TestSeal()
