"""ДЛЯ ТЕСТОВ: независимо восстанавливает общие точки и исходящие направления всех спектральных событий пути."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestBoundary(section, history, field, station):
    """Читает простое главное напряжение эффективного прогноза и его градиент по полю, без изменения истории."""
    side, point, principal = station
    elastic = np.zeros((6, 6)); elastic[:3, :3] = 25000./3.
    elastic[np.arange(3), np.arange(3)] += 25000.; elastic[3:, 3:] = np.eye(3)*12500.
    trial = history[1][side, point]+elastic@(section.b[side, point]@field-history[0][side, point])
    tensor = np.diag(trial[:3])
    for value, (i, j) in zip(trial[3:], ((0, 1), (0, 2), (1, 2))): tensor[i, j] = tensor[j, i] = value
    values, axes = np.linalg.eigh(tensor); vector = axes[:, principal]
    gradient = np.r_[vector**2, 2*vector[0]*vector[1], 2*vector[0]*vector[2], 2*vector[1]*vector[2]]
    return float(values[principal]), gradient@elastic@section.b[side, point]


def TestSolve(section, history, initial, factor, station, target, tolerance, anchor, radius, helpers):
    """Решает G=0 и h=target без регуляризации и без принятия проб; использует 32 итерации и 17 долей."""
    tangent, solve, augment, metric = helpers
    field = initial.copy(); base = np.array([0., 0., 0., 10510000., 0., 0.])
    direction = np.array([0., -396.*75000., 0., 0., 0., 75000.])
    for iteration in range(32):
        data = section.TestEvaluate(field, history, base+factor*direction)
        value, gradient = TestBoundary(section, history, field, station)
        norm = max(float(data[1]), abs(value-target))
        if norm <= tolerance:
            return field, factor, norm, iteration
        matrix = augment(section, tangent(section, field, history)[0], gradient)
        step = solve(matrix, -np.r_[data[0], value-target]); accepted = False
        for fraction in 2.**-np.arange(17):
            proposed = field+fraction*step[:-1]; lam = factor+fraction*step[-1]
            if lam <= 0. or np.sqrt(metric(section, proposed-anchor, proposed-anchor)) > radius: continue
            residual = section.TestEvaluate(proposed, history, base+lam*direction)
            value = TestBoundary(section, history, proposed, station)[0]
            proposed_norm = max(float(residual[1]), abs(value-target))
            if proposed_norm <= tolerance or proposed_norm < norm*(1.-1e-4*fraction):
                field, factor = proposed, lam; accepted = True; break
        assert accepted, ('no descent', station, target, norm)
    raise AssertionError(('iteration budget', station, target))


def TestVerify(repo, root, output, mode="long", point_limit=None):
    """Отделяет проверку равновесия событий от проверки их связности и направления первого обычного шага."""
    here = Path(__file__).resolve().parent
    with TemporaryDirectory() as temporary:
        script = 'Validate-TestPrincipalBudget.py' if mode == 'long' else 'Validate-TestPrincipalPredictor.py'
        section, _, fields, events = run_path(str(here/script))['TestValidate'](
            repo, root, Path(temporary)/'States.json')
    read = run_path(str(here/'Validate-TestNativeCorner.py'))['TestRead']
    _, _, loads, _ = read(root/'Native', '', 'Trace74')
    corner = run_path(str(here/'TestOriented148Corner.py'))
    tangent = run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    metric = run_path(str(here/'TestRefineBeforeSign.py'))['TestMetric']
    helpers = tangent, corner['TestSolveMatrix'], corner['TestAugmented'], metric
    history = section.TestInitial(); origins = {event['incoming_state']-1: event for event in events}; records = []
    for index, (label, field) in enumerate(fields, 1):
        history = section.TestEvaluate(field, history, loads[label])[4]
        if index not in origins: continue
        event = origins[index]; incoming = fields[index][1]; outgoing = fields[index+1][1]
        incoming_load = loads[fields[index][0]]; outgoing_load = loads[fields[index+1][0]]
        after_incoming = section.TestEvaluate(incoming, history, incoming_load)[4]
        after_outgoing = section.TestEvaluate(outgoing, after_incoming, outgoing_load)[4]
        standard = float(5e-7+5e-7*np.max(np.abs((loads[label]@section.l)[:section.TestDof-4])))
        candidates = []; ranks = []
        for side in range(3):
            for point in range(section.TestPointCount if point_limit is None else point_limit):
                for principal in range(3):
                    station = side, point, principal
                    value = TestBoundary(section, history, field, station)[0]
                    if abs(value) <= 3.2e-11: continue
                    sign = np.sign(value); gap = min(.25*abs(value), .125*standard)
                    first = TestBoundary(section, history, incoming, station)[0]
                    second = TestBoundary(section, after_incoming, outgoing, station)[0]
                    ranks.append((max(abs(first-sign*gap), abs(second+sign*gap)), station, value, first, second, gap))
                    if sign*first > 0. and sign*second < 0.:
                        error = max(abs(first-sign*gap), abs(second+sign*gap))
                        if error <= 1e-9: candidates.append((error, station, value, sign, gap))
        assert len(candidates) == 1, (event, candidates, sorted(ranks)[:5])
        _, station, original_h, sign, gap = candidates[0]
        tolerance = min(1e-9, .125*gap); movement = field-fields[index-2][1]
        reference = np.sqrt(metric(section, movement, movement)); radius = .25*reference
        face, face_lam, face_norm, _ = TestSolve(section, history, incoming, incoming_load[5]/75000., station, 0.,
                                               tolerance, field, radius, helpers)
        other, other_lam, other_norm, _ = TestSolve(section, after_incoming, outgoing, outgoing_load[5]/75000., station, 0.,
                                                   tolerance, incoming, radius, helpers)
        advance = metric(section, movement, face-field)/reference
        assert advance > 0. and np.sqrt(metric(section, other-face, other-face)) <= radius
        value = TestBoundary(section, after_outgoing, outgoing, station)[0]
        target = value-sign*max(gap, 30000.*2.**-26)
        probe, probe_lam, probe_norm, _ = TestSolve(section, after_outgoing, outgoing, outgoing_load[5]/75000., station,
                                                   target, tolerance, outgoing, radius, helpers)
        gradient = TestBoundary(section, after_outgoing, probe, station)[1]
        matrix = corner['TestAugmented'](section, tangent(section, probe, after_outgoing)[0], gradient)
        rhs = np.zeros(len(matrix)); rhs[-1] = -sign
        direction = corner['TestSolveMatrix'](matrix, rhs)[:-1]
        direction /= np.sqrt(metric(section, direction, direction))
        delta = fields[index+2][1]-outgoing
        departure_advance = metric(section, direction, delta)
        assert departure_advance > 0., (event, departure_advance)
        probe_spacing = metric(section, direction, probe-outgoing)
        records.append(dict(event, point=station[1]+1, side=(0, 1, -1)[station[0]], principal_index=3-station[2],
                            origin_h_MPa=original_h, principal_gap_MPa=gap, face_Qy_N=face_lam*75000.,
                            concrete_replacement_at_steel_point=(station[1] >= section.TestConcreteCount),
                            face_norm_MPa=face_norm, outgoing_history_face_norm_MPa=other_norm,
                            readonly_probe_Qy_N=probe_lam*75000., readonly_probe_norm_MPa=probe_norm,
                            signed_face_advance=advance, signed_first_ordinary_advance=departure_advance,
                            readonly_probe_spacing=probe_spacing, reference_increment_div64=reference/64.,
                            first_step_to_reference_div64_ratio=departure_advance/(reference/64.)))
        print('INDEPENDENT EVENT CONNECTIVITY VERIFIED', records[-1], flush=True)
    assert len(records) == (4 if mode == "long" else 1)
    output.write_text(json.dumps({'events': records, 'physical_capacity_certified': False,
                                 'native_new_departure_matrix_action_explicitly_recorded': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('EVENT FACES AND FIRST ORDINARY DIRECTIONS INDEPENDENTLY VERIFIED', len(records), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--mode', choices=('long', 'predictor'), default='long')
    args = parser.parse_args(); TestVerify(args.repo.resolve(), args.root.resolve(), args.out.resolve(), args.mode)
