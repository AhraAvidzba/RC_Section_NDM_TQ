"""ДЛЯ ТЕСТОВ: проверяет расширенную частную проходку без объявления найденного локального максимума физическим пределом."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import numpy as np


def TestValidate(repo, root, output):
    """Повторяет все принятые поля, проверяет неизменный префикс и выделяет события для отдельной проверки связности."""
    here = Path(__file__).resolve().parent
    helper = run_path(str(here/'Validate-TestGeneralContinuation.py'))['TestValidate']
    read = run_path(str(here/'Validate-TestNativeCorner.py'))['TestRead']
    with TemporaryDirectory() as temporary:
        temporary = Path(temporary)
        section, history, fields = helper(repo, root, 'Trace74', temporary/'AllStates.json')
        proof = json.loads((temporary/'AllStates.json').read_bytes())
        digest = '98519929F54D1911353C1877190D93BA2A65794BD8451A57E68CF3404CCB54A9'
        raw = (repo/'docs/regression/Coupled6D/ASDPrincipalTransitionIntegration20261118.zip').read_bytes()
        assert sha256(raw).hexdigest().upper() == digest
        with ZipFile(BytesIO(raw)) as archive:
            for name in ('Trace74.Operators.csv', 'Trace74.Tensor.csv'):
                (temporary/name).write_bytes(archive.read('Cases/Bounded/Native/'+name))
        baseline, _, _, _ = read(temporary, '', 'Trace74')
    assert len(baseline) == 151 and len(fields) >= 151
    assert all(np.array_equal(first, second) for (_, first), (_, second) in zip(fields[:151], baseline))
    events = []; previous = 0; frame = None
    for line in (root/'Native/Trace74.Checkpoint.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'CHECKPOINT': frame = tuple(map(int, row[1:]))
        elif row[0] == 'DETAILS':
            count = re.search(r'подтверждённых переходов: (\d+)', line)
            if count and int(count[1]) > previous:
                assert int(count[1]) == previous+1
                events.append({'incoming_state': frame[1]-1, 'outgoing_state': frame[1],
                               'first_ordinary_state': frame[1]+1, 'checkpoint_probe': frame[0]})
                previous = int(count[1])
    log = (root/'Native/Trace74.txt').read_text('utf-8-sig')
    assert len(events) == previous == 4 and 'проб: 192;' in log
    assert events[0]['incoming_state'] == 149 and events[0]['outgoing_state'] == 150
    orientations = run_path(str(here/'Check-TestSignMetric.py'))['TestRead'](
        root/'Native/Trace74.Operators.csv', root/'Native/Trace74.csv')
    special = {event[key] for event in events for key in ('outgoing_state', 'first_ordinary_state')}
    assert all(row['signed_advance'] > 0. for row in orientations if row['ending_state'] not in special)
    proof.update({'same_151_state_prefix': True, 'baseline_archive_sha256': digest,
                  'completed_transitions_reported': events, 'ordinary_orientations_outside_events_verified': True,
                  'new_event_faces_and_departure_directions_verified': False,
                  'diagnostic_probe_limit': 192, 'working_probe_limit': 96,
                  'physical_capacity_certified': False, 'full_acceptance_completed': False})
    output.write_text(json.dumps(proof, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('PRIVATE LONG PATH EQUILIBRIA AND SAME 151 STATE PREFIX VERIFIED', len(fields), events, flush=True)
    return section, history, fields, events


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(); TestValidate(args.repo.resolve(), args.root.resolve(), args.out.resolve())
