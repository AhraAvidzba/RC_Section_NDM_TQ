"""ДЛЯ ТЕСТОВ: проверяет фактический VBA, все материальные точки и обычный шаг из проверочного равновесия."""
from argparse import ArgumentParser
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from subprocess import check_output
from tempfile import TemporaryDirectory


def TestRead(file):
    """Читает доказательство без изменения единиц или численных ожиданий."""
    return json.loads(file.read_text('utf-8-sig'))


def TestNative(repo,root,output):
    """Сверяет все компоненты двух книг и доказывает единственное изменение бюджета в частной контрольной копии."""
    shared=run_path(str(root/'Check-TestMaterialRoundoff.py'));shared['TestFiles'](root)
    source,_=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _,original=reader(BytesIO(source));records={}
    for key in TestRead(root/'Cases.json'):
        folder=root/'Cases'/key
        record=shared['TestSourceComparison'](repo,root,folder,source,original,helper,body,reader)
        assert (record['components'],record['imported'],record['unchanged'])==(239,24,215)
        compiler=TestRead(folder/'docs/regression/CodeUpdate.json');reports={}
        for file in sorted((folder/'Native').glob('*.txt')):
            phase=file.stem;log=file.read_text('utf-8-sig')
            owner=TestRead(file.with_name(file.name+'.Ownership.json'));closure=TestRead(file.with_name(file.name+'.ProcessClosure.json'))
            identity=closure['Closure']['Identity']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['Passed'] and closure['RunnerCleanupValid']
            assert owner['SourceSHA256']==compiler['WorkbookSHA256'] and owner['PID']==identity['PID']
            assert int(owner['StartTicksUTC'])==identity['Ticks'] and closure['Closure']['FinalState']['State']=='Absent'
            assert closure['ChildExitCode']==0 and 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
            totals=[tuple(map(int,row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',log,re.M)]
            assert totals and all(failed==0 for passed,failed in totals)
            if phase=='Core':assert sum(passed for passed,failed in totals)==365
            if phase=='ControlProbe':assert 'CORNER_POST_COUNT;11;requested;32' in log
            reports[phase]={'passed':sum(passed for passed,failed in totals),'failed':0}
        safety=[json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB']>=6500 and row['freeCommitGiB']>=6 for row in safety)
        assert all(all(process['ProtectedUser'] for process in row['excel']) for row in safety)
        record['reports']=reports;records[key]=record
    name='src/Solver/CCoupledDeformationContinuation.cls';base=TestRead(root/'SourceCheckpoint.json')['base']
    original_code=check_output(['git','cat-file','blob',base+':'+name],cwd=repo).replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
    old=b'Private Const PROBE_LIMIT As Long = 96 ';new=b'Private Const PROBE_LIMIT As Long = 192 '
    assert original_code.count(old)==1
    assert (root/'Cases/LongBudget'/name).read_bytes()==original_code.replace(old,new)
    current=(root/'Cases/Predictor'/name).read_bytes()
    assert current.count(old)==1 and new not in current and b'mHasCornerProbe' in current
    for file in (root/'Cases/LongBudget/src').rglob('*'):
        if file.is_file() and file.relative_to(root/'Cases/LongBudget').as_posix()!=name:
            assert file.read_bytes()==(root/'Cases/Predictor'/file.relative_to(root/'Cases/LongBudget')).read_bytes()
    output.write_text(json.dumps({'cases':records,'only_private_budget_changed':True,'working_probe_limit':96,
                                 'installed_workbook_changed':False,'physical_capacity_certified':False},indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('PRINCIPAL PREDICTOR NATIVE SOURCES BUDGETS AND PROCESS CLOSURES VERIFIED',flush=True)


def TestLong(repo,root,output):
    """Проверяет 233 состояния и все четыре перехода; ограничение проверки первыми 100 точками должно давать отказ."""
    run_path(str(root/'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    helper=run_path(str(root/'Verify-TestPrincipalEvents.py'))['TestVerify'];results={}
    with TemporaryDirectory() as temporary:
        temporary=Path(temporary)
        helper(repo,root/'Cases/LongBudget',temporary/'Events.json','long')
        results['events']=TestRead(temporary/'Events.json')
        try:helper(repo,root/'Cases/LongBudget',temporary/'IncompleteScope.json','long',100)
        except AssertionError as error:
            event,candidates,ranks=error.args[0]
            assert event['incoming_state']==170 and candidates==[] and ranks[0][0]>1e-9
            results['incomplete_material_scope']={'expected_rejection':True,'omitted_material_points':36,
                                                 'first_unverified_incoming_state':170}
        else:raise AssertionError('Неполный материальный охват не был отвергнут.')
    output.write_text(json.dumps(results,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('PRIVATE 233 STATE PATH ALL FOUR EVENT FACES AND NEGATIVE SCOPE CONTROL VERIFIED',flush=True)


def TestPredictor(repo,root,output):
    """Подтверждает строгую повторную проверку найденного поля, исходящую касательную и первый обычный шаг."""
    run_path(str(root/'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    results={};folder=root/'Cases/Predictor'
    with TemporaryDirectory() as temporary:
        temporary=Path(temporary)
        for name,script,function,extra in (
            ('corner','Validate-TestNativeCorner.py','TestValidate',()),
            ('states','Validate-TestPrincipalPredictor.py','TestValidate',()),
            ('event','Verify-TestPrincipalEvents.py','TestVerify',('predictor',))):
            target=temporary/(name+'.json');run_path(str(root/script))[function](repo,folder,target,*extra);results[name]=TestRead(target)
    output.write_text(json.dumps(results,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('READONLY EQUILIBRIUM NORMAL STEP PREDICTOR REUSE INDEPENDENTLY VERIFIED',flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--scope',choices=('native','long','predictor'),required=True)
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    {'native':TestNative,'long':TestLong,'predictor':TestPredictor}[args.scope](args.repo.resolve(),args.root.resolve(),args.out.resolve())
