"""ДЛЯ ТЕСТОВ: сохраняет расширенный диагностический путь и рабочий прогноз из проверочного равновесия."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from subprocess import check_output


def TestCollect(repo, root):
    """Хранит две разные ревизии с явным разделением частного бюджета и рабочего изменения прогноза."""
    here = Path(__file__).resolve().parent
    collect = run_path(str(here/'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = {'LongBudget':'PrincipalLongBudget20261118', 'Predictor':'PrincipalPredictor20261118'}
    collect(repo, root)
    for name in ('Collect-TestPrincipalPredictor.py', 'Check-TestPrincipalPredictor.py',
                 'Validate-TestNativeCorner.py', 'Validate-TestPrincipalBudget.py', 'Validate-TestPrincipalPredictor.py',
                 'Verify-TestPrincipalEvents.py', 'TestOriented148Corner.py', 'TestRefineBeforeSign.py',
                 'Check-TestSignMetric.py', 'Stage-TestGeneralPrincipalTransition.py', 'Stage-TestPrincipalBudget.py',
                 'Diagnose-TestPrincipalStates.py'):
        (root/name).write_bytes((here/name).read_bytes())
    checkpoint = {'base': check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),
                  'installed_workbook_changed':False,'physical_capacity_certified':False,'full_acceptance_completed':False}
    (root/'SourceCheckpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
    files = {file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root/'Files.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('LONG PATH AND PRINCIPAL PREDICTOR EVIDENCE COLLECTED',len(files),flush=True)


if __name__ == '__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True);args=parser.parse_args();TestCollect(args.repo.resolve(),args.root.resolve())
