"""ДЛЯ ТЕСТОВ: проверяет соответствие индексов снимков события фактическим полям и малым главным напряжениям."""
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
import json
import numpy as np

repo = Path.cwd(); here = Path(__file__).resolve().parent
root = Path('D:/CodexScratch/RC_Section_NDM_TQ/PrincipalLongBudget20261118')
read = run_path(str(here/'Validate-TestNativeCorner.py'))['TestRead']
fields, _, loads, _ = read(root/'Native', '', 'Trace74')
reference = run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
with TemporaryDirectory() as temporary:
    temporary = Path(temporary)
    for target, source in (('Operators.csv', 'Trace74.Operators.csv'), ('MVTGaussMixed.csv', 'Trace74.csv')):
        (temporary/target).write_bytes((root/'Native'/source).read_bytes())
    section = run_path(str(here/'TestResolutionSection.py'))['TestResolutionSection'](temporary, reference, True)
history = section.TestInitial()
for index, (label, field) in enumerate(fields, 1):
    if index > 175: break
    proposed = section.TestEvaluate(field, history, loads[label])[4]
    if index >= 165:
        strain = section.b@field
        stress = history[1]+(strain-history[0])*np.array([25000.]*3+[12500.]*3)
        stress[..., :3] += (25000./3.)*(strain-history[0])[..., :3].sum(axis=-1, keepdims=True)
        tensor = np.empty((3, section.TestConcreteCount, 3, 3))
        for k, (i, j) in enumerate(((0,0),(1,1),(2,2),(0,1),(0,2),(1,2))):
            tensor[..., i, j] = tensor[..., j, i] = stress[:, :section.TestConcreteCount, k]
        values = np.linalg.eigvalsh(tensor); position = np.unravel_index(np.argmin(np.abs(values)), values.shape)
        print(json.dumps({'state': index, 'label': label, 'Qy_N':loads[label][5],
                          'closest_trial_h_MPa': float(values[position]), 'station': tuple(map(int, position))}), flush=True)
    history = proposed
