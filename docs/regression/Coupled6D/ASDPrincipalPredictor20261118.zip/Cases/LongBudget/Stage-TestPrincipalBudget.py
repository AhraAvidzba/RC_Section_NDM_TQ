"""ДЛЯ ТЕСТОВ: отделяет предел общего бюджета от следующего препятствия на том же пространственном пути."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Меняет единственный численный бюджет только в частной копии; рабочий VBA и допуски сохраняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestGeneralPrincipalTransition.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    raw = (root/name).read_bytes(); original = (repo/name).read_bytes(); assert raw == original
    old = b'Private Const PROBE_LIMIT As Long = 96 '
    new = b'Private Const PROBE_LIMIT As Long = 192 '
    assert raw.count(old) == 1
    (root/name).write_bytes(raw.replace(old, new))
    script = Path(__file__); (root/script.name).write_bytes(script.read_bytes())
    for relative in (name, script.name):
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {
        'phase': 'Trace74', 'working_probe_limit': 96, 'diagnostic_probe_limit': 192,
        'working_source_sha256': sha256(original).hexdigest().upper(),
        'only_private_constant_changed': True, 'newton_iterations': 32, 'observation_seconds': 480,
        'full_acceptance_completed': False, 'physical_capacity_certified': False}
    (root/'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('PRIVATE 192 PROBE DIAGNOSTIC READY; WORKING BUDGET 96 UNCHANGED', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve())
