"""ДЛЯ ТЕСТОВ: проверяет повторное использование непринятого равновесия только как прогноза обычной пробы."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import numpy as np


def TestValidate(repo, root, output):
    """Подтверждает те же первые 150 состояний и новое принятое поле на месте ранее читающей точки при том же бюджете."""
    here = Path(__file__).resolve().parent
    read = run_path(str(here/'Validate-TestNativeCorner.py'))['TestRead']
    with TemporaryDirectory() as temporary:
        temporary = Path(temporary)
        section, history, fields = run_path(str(here/'Validate-TestGeneralContinuation.py'))['TestValidate'](
            repo, root, 'Trace74', temporary/'AllStates.json')
        proof = json.loads((temporary/'AllStates.json').read_bytes())
        digest = '98519929F54D1911353C1877190D93BA2A65794BD8451A57E68CF3404CCB54A9'
        raw = (repo/'docs/regression/Coupled6D/ASDPrincipalTransitionIntegration20261118.zip').read_bytes()
        assert sha256(raw).hexdigest().upper() == digest
        with ZipFile(BytesIO(raw)) as archive:
            for name in ('Trace74.Operators.csv', 'Trace74.Tensor.csv'):
                (temporary/name).write_bytes(archive.read('Cases/Bounded/Native/'+name))
        baseline, _, _, _ = read(temporary, '', 'Trace74')
    assert len(fields) == len(baseline) == 151
    assert all(np.array_equal(a, b) for (_, a), (_, b) in zip(fields[:150], baseline[:150]))
    proposed, _, loads, _ = read(root/'Native', '.Departure', 'ControlProbe')
    assert len(proposed) == 1
    difference = float(np.max(np.abs(fields[-1][1]-proposed[0][1])))
    assert difference < 1e-10
    load_difference = np.asarray(proof['states'][-1]['target_N_Nmm'])-loads[proposed[0][0]]
    scaled_load_difference = float(np.max(np.abs(load_difference)/section.force_scale))
    assert scaled_load_difference <= 1e-9  # Штатный строгий допуск в МПа; силы и моменты не сравниваются одним порогом в разных единицах.
    metric = run_path(str(here/'TestRefineBeforeSign.py'))['TestMetric']
    delta = fields[-1][1]-proposed[0][1]
    field_difference = float(np.sqrt(metric(section, delta, delta)))
    assert field_difference < 1e-12
    assert proof['states'][-1]['norm_MPa'] <= 1e-9
    log = (root/'Native/Trace74.txt').read_text('utf-8-sig')
    assert 'проб: 96;' in log and 'прогнозов из проверочного равновесия: 1;' in log
    orientation = run_path(str(here/'Check-TestSignMetric.py'))['TestRead'](
        root/'Native/Trace74.Operators.csv', root/'Native/Trace74.csv')
    assert all(row['signed_advance'] > 0. for row in orientation if row['ending_state'] not in (150, 151))
    proof.update({'same_150_state_prefix': True, 'baseline_archive_sha256': digest,
                  'rechecked_ordinary_state_matches_readonly_equilibrium': True,
                  'maximum_predictor_field_difference': difference, 'predictor_tensor_RMS_difference': field_difference,
                  'predictor_load_difference_N_Nmm': load_difference.tolist(),
                  'predictor_load_difference_MPa': scaled_load_difference, 'working_probe_limit': 96,
                  'completed_transitions_reported': [{'incoming_state':149, 'outgoing_state':150,
                                                      'first_ordinary_state':151, 'checkpoint_probe':96}],
                  'readonly_predictor_reuses': 1, 'physical_capacity_certified': False,
                  'full_acceptance_completed': False})
    output.write_text(json.dumps(proof, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('ORDINARY STEP READONLY PREDICTOR REUSE AND SAME 150 STATE PREFIX VERIFIED', difference, flush=True)
    return section, history, fields, proof['completed_transitions_reported']


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(); TestValidate(args.repo.resolve(), args.root.resolve(), args.out.resolve())
