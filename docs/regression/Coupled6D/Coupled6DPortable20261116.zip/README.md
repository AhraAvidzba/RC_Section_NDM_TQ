# Повтор численных проверок связанного расчёта

Комплект проверен на снимке Git fb6897d для установленной книги и на исходниках a20da9f, использованных при её сборке. Сценарий сверяет SHA-256 книги, выгрузки VBA, двух изменённых исходников, нативных квитанций и архивов. Для четырёх офлайн-проверок создаются отдельные чистые каталоги распаковки. Оценки Kani сверяются по численным допускам в манифесте, результаты MVT2 сверяются побайтно.

## Офлайн-повтор

Распакуйте комплект в произвольный отдельный каталог. Для запуска нужны Python 3.11+, NumPy и SciPy. Проверено с Python 3.12.10, NumPy 2.3.5 и SciPy 1.18.1. Зависимости нужны только для воспроизведения контроля Kani и не входят в Excel.

Из корня чистой копии репозитория на версии fb6897d выполните команду, заменив C:/ndm-replay на каталог распаковки. По умолчанию сценарий читает PDF из literature/Coupled6D; для файла в другом месте передайте его через --paper. Ожидается SHA-256 6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E.

    python -B -X utf8 C:/ndm-replay/Verify-Coupled6DPortable.py . --output C:/ndm-replay/Replay.json

PDF Wang и Huang исключён из Git. Его можно восстановить по записи литературы или по URL издателя из манифеста с проверкой SHA-256.

Для повторения без Git checkout создайте снимки только необходимых файлов. При наличии отдельного снимка предыдущей книги параметр --baseline-book дополнительно сверяет фактические прежние XML-части.

    git archive --format=zip -o C:/ndm-replay/Fixture.zip fb6897d -- workbook/output/RC_Section_NDM.xlsm workbook/output/VBA_All_Code.txt src/Solver/CCoupledSectionAnalysis.cls tests/modTestCoupledElasticState.bas docs/regression/Coupled6D/KaniV4-Reserve-Feasibility.zip docs/regression/Coupled6D/MVT2ControlledOffline.zip docs/regression/Coupled6D/MVT2TurnOffline.zip docs/regression/Coupled6D/MVT2PublicationCompare.zip
    git archive --format=zip -o C:/ndm-replay/Baseline.zip 9383d90 -- workbook/output/RC_Section_NDM.xlsm
    Expand-Archive -LiteralPath C:/ndm-replay/Fixture.zip -DestinationPath C:/ndm-replay/Fixture
    Expand-Archive -LiteralPath C:/ndm-replay/Baseline.zip -DestinationPath C:/ndm-replay/Baseline
    python -B -X utf8 C:/ndm-replay/Verify-Coupled6DPortable.py C:/ndm-replay/Fixture --paper C:/ndm-replay/Wang-Huang-2017-MVT-NMVT.pdf --baseline-book C:/ndm-replay/Baseline/workbook/output/RC_Section_NDM.xlsm --output C:/ndm-replay/GitReplay.json

Успешный результат содержит четыре выполненные офлайн-проверки. Архив подтверждает записанные 1512 утверждений установленной книги, отдельное открытие для выгрузки 225 компонентов и закрытие собственных процессов Excel. Проверка пакета XLSM сравнивает 122 части с предыдущей книгой. Единственная изменённая часть содержит проект VBA. Офлайн-сценарий Excel не запускает.

## Повтор направленного прогона Excel

Из корня чистой копии fb6897d при доступном настольном Excel запустите штатный watchdog Windows PowerShell 5.1. Для временных копий выберите новый короткий путь. Watchdog проверяет ресурсы и идентичность своего процесса.

    $macros = 'modTestCoupledElasticState.RunTestCoupledCenteredLoadPaths,modTestCoupledElasticState.RunTestCoupledHoopCapacity,modTestCoupledElasticState.RunTestCoupledTraditionalChecks,modTestConfiguration.RunAudit03UniversalLoadPathTests'
    $nativeTemp = 'C:/ndm-replay/NativeTemp'
    if (Test-Path -LiteralPath $nativeTemp) { throw 'Use a fresh directory for Excel fixtures.' }
    New-Item -ItemType Directory -Path $nativeTemp | Out-Null
    $priorTemp = $env:TEMP
    $priorTmp = $env:TMP
    try {
        $env:TEMP = $nativeTemp
        $env:TMP = $nativeTemp
        & "$env:WINDIR/System32/WindowsPowerShell/v1.0/powershell.exe" -NoProfile -ExecutionPolicy Bypass -File tools/build_workbook/Run-Audit03Watchdog.ps1 -SourceWorkbook workbook/output/RC_Section_NDM.xlsm -ReportPath docs/regression/Coupled6DReplay/DirectedNative.txt -Macro $macros -TimeoutSeconds 260 -FailFast
        if ($LASTEXITCODE) { throw 'The directed Excel run failed.' }
    } finally {
        $env:TEMP = $priorTemp
        $env:TMP = $priorTmp
    }

Ожидаются 323, 228, 16 и 945 пройденных утверждений по наборам. Успешный протокол заканчивается WATCHDOG_COMPLETED с exit=0. Квитанции Ownership и ProcessClosure должны относиться к той же книге и идентичности процесса. Повтор сохранённой нативной проверки не выполнялся при сборке этого офлайн-комплекта.

## Границы результата

Kani и MVT2 воспроизводятся на своих зафиксированных диагностических входах. Kani проверяет достижимость линейной поправки на одном поле. В MVT2 проверены траектория, знаки и интегральные усилия, управляющая координата и локальная неопределённость, а также сопоставление со статьёй по сохранённым координатам растра. Поля напряжений для общей независимой пересборки слабых уравнений MVT2 отсутствуют. Физические пределы этих образцов, полный ON/OFF, визуальная приёмка, нативный AutoCAD и серия штатных замеров времени остаются открытыми.