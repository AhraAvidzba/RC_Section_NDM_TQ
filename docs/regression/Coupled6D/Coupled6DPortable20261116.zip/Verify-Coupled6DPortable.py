"""Verify archived Coupled6D numerical controls and the associated XLSM release."""

import argparse
from hashlib import file_digest, sha256
from importlib.metadata import version
import json
import math
from pathlib import Path, PurePosixPath
import platform
import re
from shutil import copyfileobj
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

MANIFEST = Path(__file__).with_name("Coupled6DPortableManifest.json")


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def json_file(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest().upper()


def checked(path, expected):
    require(path.is_file(), f"Required input missing: {path}")
    require(sha(path) == expected, f"SHA-256 mismatch: {path}")
    return path


def unpack(source, target):
    with ZipFile(source) as archive:
        parts = archive.infolist()
        names = [part.filename for part in parts]
        require(len({name.casefold() for name in names}) == len(names), f"Duplicate entry: {source.name}")
        require(sum(part.file_size for part in parts) <= 4_000_000, f"Unexpected expanded size: {source.name}")
        for part in parts:
            name = PurePosixPath(part.filename)
            require(not name.is_absolute() and ".." not in name.parts and
                    ":" not in part.filename and "\\" not in part.filename,
                    f"Invalid ZIP entry: {part.filename}")
            destination = target.joinpath(*name.parts)
            if part.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(part) as original, destination.open("xb") as copy:
                    copyfileobj(original, copy)


def verify_release(root, evidence, manifest, baseline):
    preparation = json_file(evidence / "Preparation.json")
    release = json_file(checked(evidence / "ReleaseVerification.json",
                                manifest["native_evidence"]["release_verification_sha256"]))
    equality = json_file(evidence / "SolverSourceEquality.json")
    closure = json_file(evidence / "DirectedNative.txt.ProcessClosure.json")
    owner = json_file(evidence / "DirectedNative.txt.Ownership.json")
    package = release["package"]
    export = release["reopened_export"]
    report = release["scoped_native"]
    workbook, export_path = (root / manifest["paths"][key] for key in ("workbook", "export"))
    require(preparation["source_git_head"] == manifest["source_git_revision"], "Different source revision")
    require(release["status"] == package["status"] == "PASS", "Failed release record")
    require(sha(workbook) == package["candidate_sha256"], "Native release workbook differs")
    require(sha(export_path) == export["export_sha256"] == equality["ExportSHA256"],
            "Export differs from the native release")
    require(sha(evidence / "Preparation.json") == package["preparation_sha256"], "Preparation differs")

    if baseline is not None:
        checked(baseline, package["baseline_sha256"])
        with ZipFile(baseline) as book:
            names = book.namelist()
            require(book.testzip() is None and len(names) == len(set(names)), "Invalid baseline ZIP")
            parts = {name: sha256(book.read(name)).hexdigest().upper() for name in names}
            require(parts == preparation["baseline_package_parts"], "Baseline payload differs from the build record")
    with ZipFile(workbook) as book:
        names = book.namelist()
        require(book.testzip() is None and len(names) == len(set(names)), "Invalid workbook ZIP")
        require(set(names) == set(preparation["baseline_package_parts"]), "Workbook entries differ")
        parts = {name: sha256(book.read(name)).hexdigest().upper() for name in names}
    changed = [name for name in names if parts[name] != preparation["baseline_package_parts"][name]]
    require(changed == package["changed_parts"] == ["xl/vbaProject.bin"] and
            len(names) == package["identical_parts"] + 1 and parts[changed[0]] == package["vba_sha256"],
            "Workbook payload differs from the archived baseline (excluding VBA)")

    modules = {Path(path).stem: path for path in preparation["sources"]}
    require(set(modules.values()) == set(manifest["sources"]) and
            set(modules) == set(package["modules"]) == set(export["semantic_changed"]),
            "Scope of changed VBA differs")
    require(equality["Passed"] and not equality["Missing"] and not equality["Differences"] and
            len(equality["Components"]) == equality["SourceComponents"] == len(modules) and
            all(equality["VerifierSelfChecks"].values()), "Failed source comparison")
    for component in equality["Components"]:
        filename = modules[component["Name"]]
        require(component["Equal"] and component["ExpectedType"] == component["ComponentType"] and
                sha(root / filename) == component["SourceSHA256"] == preparation["frozen"][filename],
                f"Changed VBA differs: {filename}")

    code_text = export_path.read_text(encoding="utf-8-sig")
    components = re.findall(r"^COMPONENT: (.+)$", code_text, re.MULTILINE)
    require(len(components) == len(set(components)) == export["components"] == equality["ExportComponents"],
            "VBA export component inventory differs")
    report_path = evidence / "DirectedNative.txt"
    require(sha(report_path) == report["report_sha256"], "Native report differs")
    test_log = report_path.read_text(encoding="utf-8-sig")
    matches = re.findall(r"^(TOTAL_\w+): passed=(\d+); failed=(\d+)$", test_log, re.MULTILINE)
    totals = {suite: int(passed) for suite, passed, failed in matches if int(failed) == 0}
    macros = re.findall(r"^===== (modTest[A-Za-z0-9_.]+) =====$", test_log, re.MULTILINE)
    require(len(matches) == len(totals) and totals == report["totals"] == manifest["native_totals"] and
            macros == manifest["native_macros"], "Directed native checks differ")
    require(test_log.splitlines().count(f"SOURCE_SHA256: {sha(workbook)}") == 1 and
            "SOURCE_UNCHANGED: True" in test_log and
            test_log.splitlines()[-1] == "WATCHDOG_COMPLETED: exit=0; source unchanged=True",
            "Native source or terminal record differs")
    pid, ticks = report["owned_pid"], report["owned_ticks"]
    require(test_log.splitlines().count(f"TEST_EXCEL_PROCESS: id={pid}; startTicks={ticks}") == 1 and
            owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and
            owner["SourceSHA256"] == sha(workbook) and owner["PID"] == pid and
            owner["StartTicksUTC"] == ticks, "Native ownership record differs")
    final = closure["Closure"]["FinalState"]
    require(closure["Passed"] and closure["RunnerCleanupValid"] and closure["ChildHasExited"] and
            closure["ChildExitCode"] == 0 and not closure["OrdinaryPathKilledAnything"] and
            final["State"] == "Absent" and final["PID"] == pid and final["StartTicksUTC"] == ticks,
            "Native Excel final exit lacks proof")
    identities = {(pid, ticks)}
    for filename in ("CompileClosure.json", "ExportClosure.json"):
        record = json_file(evidence / filename)
        require(record["State"] == "Absent", f"Recorded process was not closed: {filename}")
        identities.add((record["PID"], record["StartTicksUTC"]))
    require(len(identities) == 3 and (export["owned_pid"], export["owned_ticks"]) in identities,
            "Compilation, native run and export lack distinct ownership")
    return {"workbook_sha256": sha(workbook), "export_sha256": sha(export_path),
            "unchanged_package_parts": package["identical_parts"],
            "baseline_package_rechecked": baseline is not None, "components": len(components),
            "native_archive_assertions": sum(totals.values()), "native_executed_by_this_script": False}


def rerun(root, paper, archive, output):
    source = checked(root / archive["path"], archive["sha256"])
    target = output / source.stem
    target.mkdir()
    unpack(source, target)
    arguments = [str(paper) if arg == "<paper>" else arg for arg in archive["arguments"]]
    run = subprocess.run([sys.executable, "-B", "-X", "utf8", archive["script"], *arguments],
                         cwd=target, text=True, encoding="utf-8", capture_output=True, timeout=90)
    require(run.returncode == 0, f"{source.name} failed:\n{run.stdout}\n{run.stderr}")
    output_name = archive.get("output")
    if output_name:
        result = target / output_name
        checked(result, archive["result_sha256"])
        require((target / "ExpectedVerification.json").read_bytes() == result.read_bytes(),
                f"Expected output differs: {source.name}")
        return {"archive": source.name, "result_sha256": sha(result), "status": "PASS"}
    result = json.loads(run.stdout)
    require(result["status"] == "PASS" and result["force_rows"] == 89 and result["equalities"] == 5,
            "Kani reserve replay scope differs")
    for key in ["radius", "acceptance_tolerance_MPa", "native_linear_cap_MPa"]:
        require(math.isclose(result[key], archive["numerics"][key], rel_tol=2e-11),
                f"Kani reserve {key} differs")
    for name, value in archive["numerics"]["linear_min_MPa"].items():
        actual = result["results"][name]
        require(math.isclose(actual["linear_min_MPa"], value, rel_tol=2e-8) and
                actual["dual_lower_MPa"] > result["acceptance_tolerance_MPa"],
                f"Kani {name} result differs")
    return {"archive": source.name, "status": "PASS", "result": result}


def main():
    command = argparse.ArgumentParser(description=__doc__)
    command.add_argument("checkout", type=Path)
    command.add_argument("--paper", type=Path)
    command.add_argument("--baseline-book", type=Path)
    command.add_argument("--output", type=Path, required=True)
    args = command.parse_args()
    manifest = json_file(MANIFEST)
    root = args.checkout.resolve(strict=True)
    evidence_archive = manifest["native_evidence"]
    checked_input = checked(MANIFEST.parent / evidence_archive["file"], evidence_archive["sha256"])
    for relative, digest in manifest["checkout_sha256"].items():
        checked(root / relative, digest)
    paper = args.paper if args.paper is not None else root / manifest["paper"]["checkout_path"]
    checked(paper, manifest["paper"]["sha256"])
    paper = paper.resolve(strict=True)
    versions = {"python": platform.python_version(), "numpy": version("numpy"), "scipy": version("scipy")}
    with TemporaryDirectory(prefix="coupled6d-replay-") as directory:
        scratch = Path(directory)
        evidence = scratch / "release"
        evidence.mkdir()
        unpack(checked_input, evidence)
        release = verify_release(root, evidence, manifest, args.baseline_book)
        results = [rerun(root, paper, archive, scratch) for archive in manifest["offline_archives"]]
    summary = {"status": "PASS", "workbook_git_revision": manifest["workbook_git_revision"],
               "source_git_revision": manifest["source_git_revision"], "versions": versions,
               "release": release, "offline_controls": results, "limits": manifest["limits"]}
    with args.output.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(f"PASS: {len(results)} offline controls, native archive {release['native_archive_assertions']} assertions")
    print(f"SHA-256 {sha(args.output)}  {args.output}")


if __name__ == "__main__":
    main()