"""Разделяет влияние главных значений и направлений номинального тензора."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
from itertools import permutations
from math import acos, degrees, fsum
from pathlib import Path
from zipfile import ZipFile
import json


DIRECTORY = Path('docs/regression/Coupled6D')
SIGN_ARCHIVE = 'MVT2Cut396PrincipalSigns20261117.zip'
SIGN_SHA = '1588EF69B15D6398613C4F96C526792BE31AAF1D46C857ECD116109C9AE51269'
PAIRS = ((0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2))


def ordered_system(row, rotate):
    """Возвращает упорядоченные главные значения и ортонормированные оси."""
    xx, yy, zz, xy, xz, yz = row
    matrix = [[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]]
    axes = [[float(i == j) for j in range(3)] for i in range(3)]
    raw = rotate([line.copy() for line in matrix], axes)
    order = sorted(range(3), key=raw.__getitem__)
    values = tuple(raw[i] for i in order)
    basis = tuple(tuple(axes[j][k] for j in range(3)) for k in order)
    reconstructed = build(values, basis)
    assert max(abs(x-y) for x, y in zip(reconstructed, row, strict=True)) < 2e-13
    return values, basis


def build(values, basis):
    """Суммирует взвешенные спектральные проекторы, независимо от знака осей."""
    return tuple(fsum(value * axis[i] * axis[j] for value, axis in zip(values, basis, strict=True))
                 for i, j in PAIRS)


def action(point, row, point_id):
    """Учитывает вес бетона и отдельно знак замещения бетона арматурой."""
    x, y, w, *_ = point
    if point_id > 25:
        w = -w
    _, _, zz, _, xz, yz = row
    return w*zz, w*y*zz, w*x*zz, w*(x*yz-y*xz), w*xz, w*yz


def exchange(native, target):
    """Усредняет предельные вклады по двум порядкам подстановки."""
    av, au = native
    bv, bu = target
    a = tuple(min(0., x) for x in av)
    b = tuple(min(0., x) for x in bv)
    aa, ba = build(a, au), build(b, au)
    ab, bb = build(a, bu), build(b, bu)
    magnitude = tuple(.5 * ((v-w)+(x-y)) for v,w,x,y in zip(ba,aa,bb,ab,strict=True))
    direction = tuple(.5 * ((v-w)+(x-y)) for v,w,x,y in zip(ab,aa,bb,ba,strict=True))
    difference = tuple(x-y for x,y in zip(bb,aa,strict=True))
    assert max(abs(a+b-c) for a,b,c in zip(magnitude,direction,difference,strict=True)) < 2e-14
    return difference, magnitude, direction


def align(native, target):
    """Альтернативно сопоставляет оси по суммарному квадрату скалярного произведения."""
    _, au = native
    bv, bu = target
    overlaps = tuple(tuple(abs(fsum(x*y for x,y in zip(a,b,strict=True))) for b in bu) for a in au)
    order = max(permutations(range(3)), key=lambda match: fsum(overlaps[i][j]**2 for i,j in enumerate(match)))
    return (tuple(bv[i] for i in order), tuple(bu[i] for i in order)), order, overlaps[0][0]


def station(points, native, target, rotate):
    """Интегрирует эффект перестановки спектров и ранжирует вклады каждой точки."""
    local = []
    for j, point in points.items():
        a, b = ordered_system(native[j-1],rotate), ordered_system(target[j-1],rotate)
        alternate, order, overlap = align(a,b)
        difference, magnitudes, directions = exchange(a,b)
        same, alternate_magnitudes, alternate_directions = exchange(a,alternate)
        assert max(abs(x-y) for x,y in zip(difference,same,strict=True)) < 2e-14
        local.append(dict(point=j, x_mm=point[0], y_mm=point[1],
                          action=action(point,difference,j), magnitude=action(point,magnitudes,j),
                          direction=action(point,directions,j),
                          alternate_magnitude=action(point,alternate_magnitudes,j),
                          alternate_direction=action(point,alternate_directions,j),
                          ranked_principal_axis_angle_deg=degrees(acos(min(1.,overlap))),
                          alternate_order=order, native_MPa=a[0], target_MPa=b[0]))
    def sums(key, sample):
        return tuple(map(fsum,zip(*(item[key] for item in sample),strict=True)))
    results = {key:sums(key,local) for key in ('action','magnitude','direction','alternate_magnitude','alternate_direction')}
    for magnitude,direction in (('magnitude','direction'),('alternate_magnitude','alternate_direction')):
        assert max(abs(a+b-c) for a,b,c in zip(results[magnitude],results[direction],results['action'],strict=True)) < 1e-7
    for name in ('magnitude', 'direction'):
        assert max(abs(a-b) for a,b in zip(results[name],results['alternate_'+name],strict=True)) < 1e-7
    results['largest_concrete_torque_points'] = sorted(local[:25],key=lambda item:-abs(item['action'][3]))[:5]
    results['largest_concrete_Qy_points'] = sorted(local[:25],key=lambda item:-abs(item['action'][5]))[:5]
    results['gross_action'] = sums('action',local[:25])
    results['replacement_action'] = sums('action',local[25:])
    results['alternate_changed_points'] = [item['point'] for item in local if item['alternate_order'] != (0,1,2)]
    results['minimum_two_lowest_eigenvalues_gap_MPa'] = min(
        abs(spec[1]-spec[0]) for item in local for spec in (item['native_MPa'],item['target_MPa']))
    return results


def verify(repo):
    """Сверяет центр и две численные боковые станции для двух полей."""
    raw = (repo / DIRECTORY / SIGN_ARCHIVE).read_bytes()
    assert sha256(raw).hexdigest().upper() == SIGN_SHA
    functions = {'__name__':'__pinned__', '__file__':'Split-Cut396Principal.py'}
    with ZipFile(BytesIO(raw)) as source:
        exec(compile(source.read('Split-Cut396Principal.py'),functions['__file__'],'exec'),functions)
        reference = json.loads(source.read('Cut396PrincipalJacobiProof.json'))['cases']
    replay, wire = functions['read_replay'](repo)
    tables, path, points, *_ = replay['read_data'](repo)
    rotate = functions['rotate']
    results = {}
    for index,(phase,_,q,state) in enumerate(path):
        if q not in (20000.,21875.):
            continue
        stations = {}
        for s,side in enumerate(replay['STATIONS']):
            def concrete(j):
                nominal = tables['H'][phase,side,j]
                if j <= 25:
                    return nominal
                strain = replay['prescribed'](tables,phase,side,j,state[j])
                axial = replay['STEEL_E'] * fsum(x*y for x,y in zip(strain,points[j][3:],strict=True))
                return tuple(axial*d-n for d,n in zip(points[j][3:],nominal,strict=True))
            native = [concrete(j) for j in points]
            if side == 0:
                assert max(abs(a-b) for j in points for a,b in zip(native[j-1],state[j][6:],strict=True)) < 2e-11
            comparisons = {mode:station(points,native,history[index][s],rotate)
                           for mode,history in wire['stress'].items()}
            if side == 0:
                ref = reference[phase]['models']
                for mode,rule in comparisons.items():
                    expected = tuple(x-y for x,y in zip(ref[mode]['negative_net'],ref['ndm']['negative_net'],strict=True))
                    assert max(abs(a-b) for a,b in zip(rule['action'],expected,strict=True)) < 2e-7
            stations[str(side)] = comparisons
        results[phase] = dict(q_N=q,stations=stations)
    assert list(results) == ['S9','S10A21875']
    return dict(input_sign_archive_sha256=SIGN_SHA,fields=results)


if __name__ == '__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args()
    proof=verify(args.repo.resolve())
    with args.report.open('x',encoding='utf-8',newline='\n') as file:
        json.dump(proof,file,indent=2,sort_keys=True,allow_nan=False)
        file.write('\n')
    print('MVT2 CUT396 SPECTRAL SUBSTITUTION OFFLINE PASS 2')
