"""Проверяет нулевое приращение после кручения с одноосными таблицами НДМ."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha256
import json
from math import fsum
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


FLOW = ('MVT2EffectivePlasticFlow20261117.zip','42D0340DACD7FE6E3A9BE3592DD6464219A6F58832F43061EC59999553E12220')
REPLAY = ('MVT2NativeBarOpenSeesReplay20261117.zip','3FC1E30F23F2410CCF8C3C716D5B8554E385BB59F21DC14DE69CE53DD9301DFE')


def sealed(repo, entry):
    """Открывает проверенный архив независимой реализации или нормированных таблиц."""
    path=repo/'docs/regression/Coupled6D'/entry[0]
    assert sha256(path.read_bytes()).hexdigest().upper()==entry[1]
    return ZipFile(path)


def script(z,name):
    """Подключает архивный скалярный повтор как отдельный модуль."""
    module={'__name__':'__pinned__','__file__':name}
    exec(compile(z.read(name),name,'exec'),module)
    return module


def inputs(repo,root,temp):
    """Читает восемь принятых полей и формирует все три продольные станции."""
    common=__import__('runpy').run_path(str(root/'Verify-NativeMVT2BarControl.py'))
    refs=common['references'](repo,temp)
    tools,material,mesh,support,_,prep,_,_=refs
    note=common['process'](root,prep)
    assert note['controlled_material']=='tabulated:ndm_uniaxial'
    directory=root/'Native'
    tables=tools['read_operators']((directory/'Operators.csv').read_bytes())
    frames=tools['read_tensor_frames']((directory/'MVTGaussMixed.Tensor.csv').read_bytes(),45)
    assert list(frames)==[f'R{i}' for i in range(1,9)] and not tables['H']
    utility,backbone,rotation,_=support
    with sealed(repo,FLOW) as z:
        raw=json.loads(z.read('MVT2ASDBackboneTables.json'))['ndm_uniaxial']
        initial=json.loads(z.read('MVT2EffectiveInitial.json'))['ndm_uniaxial']
    laws=[backbone['Backbone'](raw[k],-30000.*p) for k,p in zip(('T','C'),initial[3],strict=True)]
    support=utility,backbone,rotation,laws
    directions=mesh[1]
    zero=(0.,)*6
    history={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in directions}
    coordinates=[(s,p) for s in (0,1,-1) for p in directions]
    strains,states,nets=[],[],[]
    for phase,(torque,q,center) in frames.items():
        assert q==0.
        history,net,c=material(tables['F'][phase],tables,directions,support,history)
        assert max(abs(a-b) for p in c for a,b in zip(c[p],center[p],strict=True))<8e-7
        strains.append([history[s,p][0] for s,p in coordinates])
        states.append(history)
        nets.append(net)
    history1,net1,_=material(tables['F']['R8'],tables,directions,support,history)
    history2,net2,_=material(tables['F']['R8'],tables,directions,support,history1)
    states.extend((history1,history2))
    nets.extend((net1,net2))
    strains.extend((strains[-1],strains[-1]))
    concrete=[]
    for state,net in zip(states,nets,strict=True):
        point=[]
        for s,p in coordinates:
            stress=net[s,p]
            if p>25:
                eps,_,_,plastic=state[s,p]
                axial=200000.*(fsum(a*d for a,d in zip(eps,directions[p][3:],strict=True))-plastic)
                stress=tuple(axial*d-v for d,v in zip(directions[p][3:],stress,strict=True))
            point.append(stress)
        concrete.append(point)
    commands=utility['read_inputs'](repo,temp)[3][0]['ndm_uniaxial']
    return commands,strains,concrete,(tables,mesh,nets)


def capture(repo,root,interpreter,output):
    """Выполняет три последовательных пакета OpenSees, включая два нулевых принятых приращения."""
    with TemporaryDirectory(dir=root,prefix='ndm-null-') as name:
        temp=Path(name)
        command,frames,_,_=inputs(repo,root,temp)
        with sealed(repo,REPLAY) as z:(temp/'Replay-NativeBarOpenSees.py').write_bytes(z.read('Replay-NativeBarOpenSees.py'))
        data=[[] for _ in frames]
        for start in range(0,135,45):
            wire=json.dumps([command,[frame[start:start+45] for frame in frames]]).encode()
            target=temp/f'Part{start}.json'
            run([str(interpreter),'-B','-X','utf8',str(temp/'Replay-NativeBarOpenSees.py'),'--worker',str(target)],
                input=wire,stdout=PIPE,stderr=PIPE,check=True,timeout=45,creationflags=0x08000000 if sys.platform=='win32' else 0)
            for row,new in zip(data,json.loads(target.read_bytes()),strict=True):row.extend(new)
        record={'material':'ndm_uniaxial','engine':'OpenSees 3.8.0','stress':data,'frames':10,'points':135,
                'commands':command,'strain_sha256':sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest().upper()}
        output.write_bytes(compress(json.dumps(record,separators=(',',':')).encode(),mtime=0))


def verify(repo,root,wire,temp):
    """Сравнивает материал библиотеки и VBA, измеряя остаток при неизменном поле."""
    command,frames,expected,(tables,mesh,nets)=inputs(repo,root,temp)
    data=json.loads(decompress(wire.read_bytes()))
    assert (data['material'],data['engine'],data['frames'],data['points'])==('ndm_uniaxial','OpenSees 3.8.0',10,135)
    assert data['commands']==command
    assert data['strain_sha256']==sha256(json.dumps(frames,separators=(',',':')).encode()).hexdigest().upper()
    error=max(abs(a-b) for row,raw in zip(expected,data['stress'],strict=True) for point,observed in
              zip(row,raw,strict=True) for a,b in zip(point,observed,strict=True))
    assert error<8e-7
    change=max(abs(a-b) for new,old in zip(data['stress'][8],data['stress'][7],strict=True) for a,b in zip(new,old,strict=True))
    assert change>1e-4
    with sealed(repo,('MVT2TabulatedActiveSteelVBA20261117.zip','87CECC42511E773F37611E4749AFD4947C299F5853893715F284FA9F498789FB')) as z:
        measure=script(z,'Verify-ActiveSteelWitness.py')['measure']
    original,original_tol=measure(tables['F']['R8'],0.,nets[7],tables,mesh)
    after,_=measure(tables['F']['R8'],0.,nets[8],tables,mesh)
    after2,_=measure(tables['F']['R8'],0.,nets[9],tables,mesh)
    assert original<=original_tol and after>original_tol and after2>original_tol
    setup=(root/'Native/MVTGaussMixed.csv').read_bytes().splitlines()[0].decode('ascii').split(';')
    assert setup[0]=='MVT2_ADAPT_SETUP'
    fc,ft,gt,gc=map(float,setup[2:])
    modulus=30000.
    default_gt=0.073*fc**0.18
    default_gc=2.*default_gt*(fc/ft)**2
    peak=2.*fc/modulus
    compression_plastic_peak=(peak-fc/modulus)*0.4+fc/modulus
    default_length=min(0.01*default_gt/(0.5*ft*ft/modulus),
                       0.01*default_gc/(0.5*fc*(peak-compression_plastic_peak)))
    assert abs(gt-default_gt)<1e-12 and abs(default_length-18.621285527678477)<1e-10
    source=repo/'literature/Coupled6D/OpenSees-3.8.0-ASDConcrete3DMaterial.cpp'
    assert sha256(source.read_bytes()).hexdigest().upper()=='210EADE9C167DA38FB5A7894570C64BA0CA35D9D9307A9818FDE485435EBEA31'
    calibration={'modulus_MPa':modulus,'fc_MPa':fc,'ft_MPa':ft,
                 'default_Gt_N_per_mm':default_gt,'default_Gc_N_per_mm':default_gc,
                 'default_build_length_mm':default_length,
                 'NDM_Gt_N_per_mm':gt,'NDM_Gc_N_per_mm':gc,'NDM_length_mm':125.,
                 'default_scaled_Gt_MPa':default_gt/default_length,'default_scaled_Gc_MPa':default_gc/default_length,
                 'NDM_scaled_Gt_MPa':gt/125.,'NDM_scaled_Gc_MPa':gc/125.}
    return {'states_compared':1350,'max_OpenSees_independent_stress_error_MPa':error,'zero_increment_stress_change_MPa':change,
            'accepted_T_Nmm':10510000.,'accepted_norm_MPa':original,'tol_MPa':original_tol,
            'first_zero_increment_norm_MPa':after,'second_zero_increment_norm_MPa':after2,
            'calibration':calibration,'physical_limit_established':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--capture',type=Path)
    p.add_argument('--python',type=Path)
    p.add_argument('--wire',type=Path)
    p.add_argument('--out',type=Path)
    a=p.parse_args()
    if a.capture:
        assert a.python
        capture(a.repo.resolve(),a.root.resolve(),a.python.resolve(),a.capture.resolve())
    else:
        assert a.wire and a.out
        with TemporaryDirectory(dir=a.out.resolve().parent) as name:proof=verify(a.repo,a.root,a.wire,Path(name))
        a.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
        print('NDM CURVE NULL INCREMENT VERIFIED 1350')
