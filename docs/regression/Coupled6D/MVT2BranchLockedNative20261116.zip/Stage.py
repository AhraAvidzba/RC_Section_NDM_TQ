"""Freeze the half and full stage from verified branch-locked MVT2 evidence."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
FROM=BASE/"f367"
FOCUS=BASE/"f367decision/MVT2BranchLockedDecision20261116.zip"
NATIVE=FROM/"MVT2ReactedFreshNative20261116.zip"
FOCUS_SHA="72F70ACA02022BC8E2F3754606541135507929BF4F59BCE51B8B2BA1A4015452"
NATIVE_SHA="5DCAB88E25FD13C1DB6C43A8898243D2AF03E906ADA2F87C31A17638E84ABA3E"
BOOK_SHA="A90C7A5E610C19D2C3CF0D7DB12831651DB12EEFD052E5DBED1378EE3C2C04FA"
H24_SHA="504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8"
B_SHA="D958777BF0A87FF073C32717206788C27212ADB3F8A603668BB935454A38E055"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def freeze(name,raw):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==raw,path
    else:
        path.write_bytes(raw)
    return digest(raw)


def replace(text,needle,replacement):
    assert text.count(needle)==1,needle
    return text.replace(needle,replacement)


def main():
    assert digest(FOCUS.read_bytes())==FOCUS_SHA
    assert digest(NATIVE.read_bytes())==NATIVE_SHA
    inputs={}
    with ZipFile(FOCUS) as archive:
        for name in ("DirectedProbe.json","DirectedProbe.csv"):
            inputs[name]=freeze(name,archive.read("Run/"+name))
    assert inputs["DirectedProbe.json"]=="D54415D3939A849D242DE97752B50DA3B5AAA3AF48ED190231BBA7D0703AC292"
    assert inputs["DirectedProbe.csv"]=="77B566C42C7B49274B1B00F26B98A480A2C26D170DE6D234AA41BC07F800C5F1"
    with ZipFile(NATIVE) as archive:
        for member,dest in (("Replay.csv","Replay.csv"),("NativeB/MVT2.csv","PreviousNative.csv"),("VerifyBase.py","VerifyBase.py")):
            inputs[dest]=freeze(dest,archive.read(member))
        prep=json.loads(archive.read("Preparation.json"))
        for name,identity in prep["inputs"].items():
            if name.startswith("tools/") or name=="Guard-IsolatedOffice.ps1":
                inputs[name]=freeze(name,archive.read(name))
                assert inputs[name]==identity
        source_overlay=archive.read("tests/modTestCoupledExperiment.bas").decode("utf8").replace("\r\n","\n")
        old=archive.read("Control.bas").decode("utf8").replace("\r\n","\n")
        runner=archive.read("Run-MVT2ShearControlled.ps1").decode("utf8")
    assert inputs["Replay.csv"]==H24_SHA and inputs["PreviousNative.csv"]==B_SHA
    p=json.loads((HERE/"DirectedProbe.json").read_text())
    fmt=lambda row: ";".join(map(str,row)) .encode("ascii")+b"\r\n"
    inputs["AnchorField.csv"]=freeze("AnchorField.csv",fmt(p["raw_base_field"]))
    for phase,delta,radius,target in (
        ("Half","half_delta","half_radius","half_target_norm_MPa"),("Full","full_delta","radius","full_target_norm_MPa"),
    ):
        file=phase+"/Candidate.csv"
        inputs[file]=freeze(file,fmt(["Locked"+phase,p[radius],p[target],*p[delta]]))
    signature='Public Function RunTestWangShearControlled('
    marker="' -------------------- ДЛЯ ТЕСТОВ --------------------"
    boundary=source_overlay.rindex(marker,0,source_overlay.index(signature))
    start=old.index("Private Sub ProcessWangFreshReactedTest")
    first=old.rindex(marker,0,start)
    end=old.index("Private Sub RecordWangFreshTrialsTest",start)
    last=old.rindex(marker,0,end)
    main_vba=old[:first]+old[last:]
    main_vba=replace(main_vba,'    ProcessWangFreshReactedTest output, folder, phase, history, solver, operators, materials, responses, base, anchor, qTrial','''    If phase <> "Half" And phase <> "Full" Then Err.Raise 5, , "Неизвестная фаза проверки зафиксированных станций."
    RecordWangFreshTrialsTest output, folder & phase & "\\Candidate.csv", history, solver, operators, materials, responses, base, anchor, qTrial''')
    main_vba=replace(main_vba,'"Reacted", 24, qTrial','"Fresh1First", 24, qTrial')
    main_vba=replace(main_vba,'Не воспроизведено измеренное исходное поле Reacted.','Не воспроизведено измеренное исходное поле Fresh1First.')
    inputs["Control.bas"]=freeze("Control.bas",main_vba.encode("utf8"))
    code=(source_overlay[:boundary]+main_vba).replace("\n","\r\n").encode("utf8")
    assert code.count(signature.encode())==1 and b"CopyTestWangTangent" not in code
    inputs["tests/modTestCoupledExperiment.bas"]=freeze("tests/modTestCoupledExperiment.bas",code)
    runner=replace(runner,"[ValidateSet('A','B')][string]$Phase='A'","[ValidateSet('Half','Full')][string]$Phase='Half'")
    assert runner.count("$Phase -eq 'B'")==2
    runner=runner.replace("$Phase -eq 'B'","$Phase -eq 'Full'")
    runner=replace(runner,"-ModuleNames @('CCoupledNewtonSolver','modTestCoupledExperiment')","-ModuleNames @('modTestCoupledExperiment')")
    runner=replace(runner,"-cne 'CCoupledNewtonSolver,modTestCoupledExperiment'","-cne 'modTestCoupledExperiment'")
    runner=replace(runner,"throw 'Для фазы B требуется скомпилированная книга фазы A.'",
                          "throw 'Для полного шага нужна скомпилированная книга половинного шага.'")
    inputs["Run-MVT2ShearControlled.ps1"]=freeze("Run-MVT2ShearControlled.ps1",runner.encode("utf8"))
    for directory in ("src","Temp","NativeHalf","NativeFull"):
        (HERE/directory).mkdir(exist_ok=True)
    path="workbook/output/RC_Section_NDM.xlsm"
    workbook=(FROM/path).read_bytes()
    assert digest(workbook)==BOOK_SHA
    freeze(path,workbook)
    draft="docs/regression/Diagnostic.xlsm"
    if not (HERE/draft).exists():
        freeze(draft,workbook)
    inputs["Verify-MVT2ShearControlled.py"]=digest((HERE/"Verify-MVT2ShearControlled.py").read_bytes())
    report={"inputs":inputs,"book_sha256":BOOK_SHA,"previous_native_sha256":B_SHA,"replay_sha256":H24_SHA,
            "phase_decision_archive_sha256":FOCUS_SHA,"source_native_archive_sha256":NATIVE_SHA,"watchdog_seconds":200}
    identity=freeze("Preparation.json",(json.dumps(report,indent=2)+"\n").encode("utf8"))
    print("Preparation.json",identity)


if __name__=="__main__":
    main()
