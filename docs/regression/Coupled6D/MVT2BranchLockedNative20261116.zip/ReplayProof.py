"""Reproduce both locked correction probes and the optional numerical decision."""
import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

import VerifyBase as v

HERE=Path(__file__).resolve().parent


def open_verifier():
    spec=spec_from_file_location("locked_verifier",HERE/"Verify-MVT2ShearControlled.py")
    verifier=module_from_spec(spec)
    spec.loader.exec_module(verifier)
    return verifier


def pinned_inputs(verifier,workbook):
    prep=v.read(HERE/"Preparation.json")
    assert all(v.digest(HERE/name)==expected for name,expected in prep["inputs"].items())
    if workbook is not None:
        assert v.digest(workbook)==prep["book_sha256"]
    nested=HERE/"Decision"
    decision=nested/"MVT2BranchLockedDecision20261116.zip"
    prior=nested/"MVT2ReactedFreshNative20261116.zip"
    assert v.digest(decision)==prep["phase_decision_archive_sha256"]
    assert v.digest(prior)==prep["source_native_archive_sha256"]
    with ZipFile(decision) as archive:
        for file in ("DirectedProbe.json","DirectedProbe.csv"):
            assert archive.read("Run/"+file)==(HERE/file).read_bytes()
    rules=v.read(HERE/"DirectedProbe.json")
    assert rules["H24_sha256"]==prep["replay_sha256"]==v.digest(HERE/"Replay.csv")
    archived,station=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    assert v.digest(HERE/"PreviousNative.csv")==prep["previous_native_sha256"]
    f0=archived["Fresh1First"]
    assert f0["q"]==rules["q_target_kN"] and f0["tol_MPa"]==rules["tau_MPa"]
    assert tuple(rules["raw_base_field"])==f0["field"]
    [anchor]=verifier.read_grid("AnchorField.csv")
    assert tuple(map(float,anchor))==f0["field"]
    geometry=f0["geometry"]
    grid=verifier.read_grid("DirectedProbe.csv")
    fields={}
    for i,phase in enumerate(("Half","Full"),2):
        [row]=verifier.read_grid(phase+"/Candidate.csv")
        assert row[0]==grid[i][0]=="Locked"+phase
        rad,limit,*dq=map(float,row[1:])
        delta=tuple(dq)
        assert delta==tuple(rules[phase.lower()+"_delta"])
        extent=v.tensor_radius(delta,geometry)
        assert extent<=rad+4e-16
        field=tuple(q+d for q,d in zip(f0["field"],delta,strict=True))
        assert field==tuple(map(float,grid[i][3:]))
        for point in rules["locked_points"]:
            for side in (-1,0,1):
                assert v.peak(v.strain_at(delta,v.operators(*geometry[point,side][:2]),side))<=2e-17
        fields[phase]=field,rad,limit,extent
    return (prep,rules,archived,station,fields),decision,prior


def same_report(filename,report):
    frozen=HERE/filename
    raw=(json.dumps(report,indent=2)+"\n").replace("\n","\r\n").encode("utf8")
    assert raw==frozen.read_bytes(),filename
    return v.digest(frozen)


def replay_decision(decision,prior):
    folder=HERE/"DecisionReplay"
    folder.mkdir(exist_ok=True)
    with ZipFile(decision) as archive:
        script=folder/"Decision.py"
        script.write_bytes(archive.read("Decision.py"))
        subprocess.run([sys.executable,"-B","-X","utf8",str(script),str(prior),str(folder/"Run")],check=True)
        for filename in ("Decision.json","DirectedProbe.json","DirectedProbe.csv"):
            raw=(folder/"Run"/filename).read_bytes()
            if filename.endswith(".json"):
                raw=raw.replace(b"\r\n",b"\n")
            expected=archive.read("Run/"+filename)
            if filename.endswith(".json"):
                expected=expected.replace(b"\r\n",b"\n")
            assert raw==expected,filename


def summary(result,rules):
    values=result["trial_all66_MPa"]
    caps=rules["original_caps_MPa"]
    return {k:result[k] for k in ("actual_norm_MPa","actual_progress_in_tau","six_signed_effort_residuals_N_Nmm",
        "actual_four_gauges_MPa","passes_norm_gate","passes_six_caps","equilibrium","station_locks","selected_rows_MPa",
        "native_wall_s","native_owner","archive_base_vector_error_MPa")}|{
        "governing_weak_row":max(range(56),key=lambda i:abs(values[i]))+1,
        "original_effort_margins_N_Nmm":{key:(c-abs(val))*scale for key,c,val,scale in
             zip(v.EFFORT_NAMES,caps,values[56:62],v.SCALES,strict=True)}}


def main(args):
    verifier=open_verifier()
    inputs,decision,prior=pinned_inputs(verifier,args.workbook)
    prep,rules,*_=inputs
    if args.decision:
        replay_decision(decision,prior)
    half=verifier.verify("Half",inputs)
    cert=verifier.certificate(half,rules,prep)
    assert cert["passes_full_permission"]
    full=verifier.verify("Full",inputs)
    assert full["passes_norm_gate"] and full["passes_six_caps"] and not full["equilibrium"]
    hashes={name:same_report(name,doc) for name,doc in (
        ("VerificationHalf.json",half),("FullCertificate.json",cert),("VerificationFull.json",full))}
    result={"history_published":False,"exact_H24_rollback":half["exact_H24_rollback"] and full["exact_H24_rollback"],
        "H24_sha256":prep["replay_sha256"],"Qy_trial_kN":full["target_Qy_kN"],"Qy_accepted_kN":full["last_accepted_Qy_kN"],
        "equilibrium_tolerance_MPa":full["tau_MPa"],"original_workbook_sha256":prep["book_sha256"],
        "test_overlay_sha256":prep["inputs"]["tests/modTestCoupledExperiment.bas"],"compiler":half["compiler"],
        "prior_bound_decision_sha256":prep["phase_decision_archive_sha256"],"bytewise_independent_reports":hashes,
        "half_trace_sha256":half["trace_sha256"],"full_trace_sha256":full["trace_sha256"],
        "half":summary(half,rules),"full":summary(full,rules)}
    args.output.write_bytes((json.dumps(result,indent=2)+"\n").encode("utf8"))
    print(args.output,v.digest(args.output))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook",type=Path)
    parser.add_argument("--decision",action="store_true")
    parser.add_argument("--output",type=Path,default=HERE/"PortableReport.json")
    main(parser.parse_args())
