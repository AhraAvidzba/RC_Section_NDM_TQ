"""Verify locked MVT2 half field and gate the full probe using measured signed efforts."""
import argparse
import csv
import json
from pathlib import Path

import VerifyBase as v

HERE=Path(__file__).resolve().parent
GUARD_MPA=8e-10
FOCUS_ROWS=(6,29,53)


def full(state,stations):
    weak,resultant,strain_error=v.reconstruct(state["field"],state["q"],stations)
    return (*state["r"],*(x*v.MODULUS for x in weak[56:]))


def read_grid(name):
    data=(HERE/name).read_bytes()
    assert data.count(b"\r\n")==data.count(b"\n")
    return list(csv.reader(data.decode("ascii").splitlines(),delimiter=";"))


def preflight():
    prep=v.read(HERE/"Preparation.json")
    assert all(v.digest(HERE/name)==identity for name,identity in prep["inputs"].items())
    assert v.digest(HERE/"workbook/output/RC_Section_NDM.xlsm")==prep["book_sha256"]
    assert v.digest(HERE/"PreviousNative.csv")==prep["previous_native_sha256"]
    assert v.digest(HERE/"Replay.csv")==prep["replay_sha256"]
    rules=v.read(HERE/"DirectedProbe.json")
    assert rules["H24_sha256"]==prep["replay_sha256"]
    archive,stations=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    base=archive["Fresh1First"]
    q=base["q"]
    assert rules["q_target_kN"]==q==18.5720088671875
    assert rules["accepted_qy_kN"]==archive["Base24"]["q"]==18.55811
    assert rules["tau_MPa"]==base["tol_MPa"]
    caps=tuple(rules["original_caps_MPa"])
    r0=full(base,stations["Fresh1First"])
    assert all(abs(value)<=limit for value,limit in zip(r0[56:62],caps,strict=True))
    [row]=read_grid("AnchorField.csv")
    assert len(row)==60 and tuple(map(float,row))==base["field"]==tuple(rules["raw_base_field"])
    [header,*official]=read_grid("DirectedProbe.csv")
    assert [row[0] for row in official]==["Fresh1First","LockedHalf","LockedFull"]
    assert all(len(row)==63 and float(row[1])==q for row in official)
    fields={}
    for label,reference,stem,radius in (
        ("Half",official[1],"half","half_radius"),("Full",official[2],"full","radius"),
    ):
        [candidate]=read_grid(label+"/Candidate.csv")
        assert candidate[0]==reference[0]=="Locked"+label
        data=tuple(map(float,candidate[1:]))
        delta=data[2:]
        assert len(delta)==60 and delta==tuple(rules[stem+"_delta"])
        assert data[0]==rules[radius] and data[1]==rules[stem+"_target_norm_MPa"]==float(reference[2])
        field=tuple(a+b for a,b in zip(base["field"],delta,strict=True))
        assert field==tuple(map(float,reference[3:]))
        actual=v.tensor_radius(delta,base["geometry"])
        assert actual<=data[0]+4e-16<=1e-8+4e-16
        for (point,side),xyz in base["geometry"].items():
            if point in rules["locked_points"]:
                assert v.peak(v.strain_at(delta,v.operators(*xyz[:2]),side))<=2e-17
        fields[label]=(field,data[0],data[1],actual)
    return prep,rules,archive,stations,fields


def receipts(phase,prep):
    native=HERE/f"Native{phase}"
    compiler=v.read(HERE/"CompileClosure.json")
    build=v.read(HERE/"docs/regression/CodeUpdate.json")
    proof=v.read(native/"MVT2.txt.ProcessClosure.json")
    owner=v.read(native/"MVT2.txt.Ownership.json")
    runtime=v.read(native/"RunReceipt.json")
    assert build["Compiled"] and not build["ProductionChanged"] and build["Modules"]==["modTestCoupledExperiment"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and compiler["State"]=="Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert proof["Passed"] and proof["ChildHasExited"] and proof["ChildExitCode"]==runtime["native_exit"]==0
    final=proof["Closure"]["FinalState"]
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (native/"MVT2.txt").read_text(encoding="utf-8-sig")
    return native,compiler,final,runtime["wall_seconds"]


def verify(phase,inputs):
    prep,rules,archive,old_station,fields=inputs
    native,compiler,owner,wall=receipts(phase,prep)
    path=native/"MVT2.csv"
    tags=v.read_native(path)
    states,stations=v.verified_states(tags)
    assert tags["B_FRESH_PHASE"]==[[phase]]
    [[qbase,q]]=tags["B_TANGENT_LOAD"]
    qbase,q=map(float,(qbase,q))
    assert qbase==rules["accepted_qy_kN"] and q==rules["q_target_kN"]
    history=v.vec(tags,"MVT2_CONTROL_FIELD")
    rows=list(csv.reader((HERE/"Replay.csv").read_text().splitlines(),delimiter=";"))[1:]
    assert len(rows)==len(history)==24
    for i,row in enumerate(rows,1):
        assert int(row[0])==i and v.peak(v.diff(tuple(map(float,row[9:])),history[f"Replay{i}"]))<1e-15
    assert states["Restored24"]==states["Base24"]
    assert states["Base24"]["field"]==history["Replay24"] and states["Base24"]["q"]==qbase
    assert stations["Restored24"]==stations["Base24"]
    base=states["Fresh1First"]
    exact=archive["Fresh1First"]
    base_station=stations["Fresh1First"]
    assert base["q"]==q and base["geometry"]==exact["geometry"]
    assert v.peak(v.diff(base["field"],exact["field"]))<3e-15
    actual0=full(base,base_station)
    archive_error=v.peak(v.diff(actual0,full(exact,old_station["Fresh1First"])))
    assert archive_error<=GUARD_MPA
    steel=v.verify_steel(tags,states,stations,history)
    label="Locked"+phase
    [[trial,*values]]=tags["B_FRESH_INPUT"]
    assert tags["B_FRESH_PROBES"]==[["1"]] and trial==label
    coords,radius,norm_gate,extent=fields[phase]
    near=tuple(map(float,values))
    assert v.peak(v.diff(near,(radius,norm_gate,extent)))<4e-15
    common={"phase":phase,"source_book_sha256":prep["book_sha256"],"H24_sha256":prep["replay_sha256"],
            "trace_sha256":v.digest(path),"target_Qy_kN":q,"last_accepted_Qy_kN":qbase,
            "tau_MPa":rules["tau_MPa"],"archive_base_vector_error_MPa":archive_error,"exact_H24_rollback":True,
            "history_published":False,"compiler":compiler,"native_owner":owner,"native_wall_s":wall}
    if label not in states:
        assert [label,"Residual"] in tags["B_TANGENT_UNAVAILABLE"]
        return {**common,"available":False}
    state=states[label]
    station=stations[label]
    assert state["q"]==q and state["geometry"]==base["geometry"]
    assert v.peak(v.diff(state["field"],coords))<3e-15
    assert v.tensor_radius(v.diff(state["field"],base["field"]),state["geometry"])<=radius+4e-16
    locks=[]
    for point in rules["locked_points"]:
        for side in (-1,0,1):
            old=base_station[point,side]
            new=station[point,side]
            max_strain=v.peak(v.diff(new[7:13],old[7:13]))
            max_stress=v.peak(v.diff(new[13:19],old[13:19]))
            assert max_strain<=4e-15 and max_stress<=4e-10 and new[3:6]==old[3:6]
            locks.append({"point":point,"side":side,"max_strain_delta":max_strain,"max_stress_delta_MPa":max_stress,
                          "trial_yield_delta":new[6]-old[6]})
    vector=full(state,station)
    caps=tuple(rules["original_caps_MPa"])
    effort_ok=all(abs(val)<=cap for val,cap in zip(vector[56:62],caps,strict=True))
    actual_norm=v.peak(vector)
    return {**common,"available":True,"base_norm_MPa":v.peak(actual0),"actual_norm_MPa":actual_norm,
        "actual_progress_in_tau":(v.peak(actual0)-actual_norm)/rules["tau_MPa"],
        "norm_gate_MPa":norm_gate,"passes_norm_gate":actual_norm<=norm_gate,"passes_six_caps":effort_ok,
        "station_locks":locks,"station_19_before_after":[[side,base_station[19,side],station[19,side]] for side in (-1,0,1)],
        "base_all66_MPa":actual0,"trial_all66_MPa":vector,"actual_four_gauges_MPa":vector[-4:],
        "six_signed_effort_residuals_N_Nmm":state["signed_force_N_Nmm"],
        "six_actual_N_Nmm":[a+b for a,b in zip(v.force(q),state["signed_force_N_Nmm"],strict=True)],
        "selected_rows_MPa":{str(i):[actual0[i-1],vector[i-1]] for i in FOCUS_ROWS},
        "peak_steel_MPa":steel[label],"equilibrium":actual_norm<=rules["tau_MPa"]}


def certificate(half,rules,prep):
    base={"half_trace_sha256":half["trace_sha256"],"original_caps_MPa":rules["original_caps_MPa"],
          "full_input_sha256":prep["inputs"]["Full/Candidate.csv"],"passes_full_permission":False}
    if not half["available"]:
        return {**base,"reason":"half response unavailable"}
    before=half["base_all66_MPa"]
    after=half["trial_all66_MPa"]
    required=rules["original_caps_MPa"]
    uncertainty=rules["half_empirical_signed_effort_uncertainty_MPa"]
    trial={}
    for i,label in enumerate(v.EFFORT_NAMES):
        row=56+i
        err={key:2*(after[row]-r[row]) for key,r in rules["half_predictor_modes_all66_MPa"].items()}
        adjusted={key:rules["full_predictor_modes_all66_MPa"][key][row]+val for key,val in err.items()}
        secant=2*after[row]-before[row]
        lower=min(secant,*adjusted.values())-uncertainty[i]
        upper=max(secant,*adjusted.values())+uncertainty[i]
        bound=max(abs(lower),abs(upper))
        trial[label]={"half_actual_signed_MPa":after[row],"twice_measured_half_signed_error_MPa":err,
            "full_extrapolated_signed_MPa":adjusted,"full_secant_signed_MPa":secant,
            "full_signed_interval_MPa":[lower,upper],"spare_original_cap_MPa":required[i]-bound}
    acceptable=half["passes_norm_gate"] and half["passes_six_caps"] and all(x["spare_original_cap_MPa"]>=0. for x in trial.values())
    return {**base,"signed_guard":trial,"passes_full_permission":acceptable,
            "reason":"norm, six actual half caps and six scaled signed full intervals" if acceptable else "guard exhausted"}


def write(name,result):
    path=HERE/name
    path.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(name,v.digest(path))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--prevalidate",action="store_true")
    parser.add_argument("--phase",choices=("Half","Full"))
    args=parser.parse_args()
    inputs=preflight()
    prep,rules,*_=inputs
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"),rules["q_target_kN"],rules["original_caps_MPa"])
    elif args.prevalidate or args.phase=="Full":
        measured=verify("Half",inputs)
        approval=certificate(measured,rules,prep)
        write("FullCertificate.json",approval)
        assert approval["passes_full_permission"],"Full is blocked by exact half measurement and signed effort intervals."
        if args.phase=="Full":
            write("VerificationFull.json",verify("Full",inputs))
    else:
        assert args.phase=="Half"
        half=verify("Half",inputs)
        write("VerificationHalf.json",half)
        write("FullCertificate.json",certificate(half,rules,prep))
