"""Verify native local branch actions with previously archived shared evidence."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile


here = Path(__file__).resolve().parent
book_sha = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
verification_sha = "7CDA42FD0EE58CDF0494B53198A63169A26DA9B298DEA36A13C83CFD5106ECDC"
dependencies = {
    "jet": "6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33",
    "shift": "688E1CB09A1FC7E4A4976FEA214BB4E0A9DADA0FE042BBBB6AFA55D1EA9B0979",
    "ray": "E6FCD67D16C2637EF7992AB67CE6DB71AA7E63EE41F15CD33E8CB198A586304D",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for tag in dependencies:
        parser.add_argument(tag, type=Path)
    args = parser.parse_args()
    for tag, sha in dependencies.items():
        assert digest(getattr(args,tag).read_bytes()) == sha, tag
    manifest = json.loads((here / "PortableManifest.json").read_bytes())
    with (tempfile.TemporaryDirectory() as folder, ZipFile(args.jet) as jet,
          ZipFile(args.shift) as shift, ZipFile(args.ray) as ray):
        work = Path(folder)
        archives = {"jet":jet,"shift":shift,"ray":ray}
        for name, row in manifest.items():
            tag = row.get("archive")
            raw = (here/name).read_bytes() if tag is None else archives[tag].read(row["member"])
            assert digest(raw) == row["sha256"], name
            target = work/name
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(raw)
        saved = (work/"VerificationBranch.json").read_bytes()
        assert digest(saved) == verification_sha
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayFullCenterReference.py","--offline"),cwd=work,check=True)
        assert (work/"VerificationBranch.json").read_bytes() == saved
        print("CANONICAL COMPLETE MATCHED ACTION",verification_sha)


if __name__ == "__main__":
    main()
