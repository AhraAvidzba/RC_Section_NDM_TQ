"""Extend the already checked local probe to all six stress response rows."""
from hashlib import sha256
from pathlib import Path


here = Path(__file__).resolve().parent
old = here.parent / "mvbc"


def materialize(name, expected):
    raw = (old / name).read_bytes()
    assert sha256(raw).hexdigest().upper() == expected
    return raw


def single(text, source, replacement):
    assert text.count(source) == 1, source
    return text.replace(source, replacement)


for name, digest in {
    "Stage.py":"9229CB769E4838987B51693C48CBAE8BF1386C5697CBFD01EEA5FB4B596BBE6A",
    "RecoveryPlan.txt":"B3E97A3C696E97E965749D47BB5E12745B2E1D6B7D32864B8C94489AF1F58F00",
}.items():
    raw = materialize(name,digest)
    if name == "Stage.py":
        old_inputs = '"Verify-MVT2ShearControlled.py", "RecoveryPlan.txt")'
        raw = single(raw.decode("utf-8"), old_inputs,
                     '"Verify-MVT2ShearControlled.py", "RecoveryPlan.txt", "FullTensor.py", "CreateFull.py")').encode("utf-8")
    (here / name).write_bytes(raw)


vba = materialize("BranchProbe.bas","DECAEC3C8F554C9794A35F89EBF817D5476E46E2F6DCC7D53DE66786857A1ABB").decode("utf-8")
extensions = [
    ("Array(Array(2, -1), Array(2, 1), Array(22, 1), Array(23, -1), Array(23, 1))",
     "Array(Array(2, -1), Array(2, 1), Array(22, 1), Array(23, -1), Array(23, 1), Array(2, 0), Array(22, 0))"),
    ("    Dim baseStress As Double, baseF As Double, basePlastic As Boolean, basePrincipal As Long, baseSteps As Long",
     "    Dim baseStress As Double, baseF As Double, basePlastic As Boolean, basePrincipal As Long, baseSteps As Long\n"
     "    Dim baseFull(1 To 6) As Double, axisFull(1 To 6) As Double, leftFull(1 To 6) As Double, rightFull(1 To 6) As Double, j As Long"),
    ("station, baseStress, baseF, basePlastic, basePrincipal, baseSteps) Then",
     "station, baseStress, baseF, basePlastic, basePrincipal, baseSteps, baseFull) Then"),
    ('    Print #output, row\n    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, matched(1 To 6) As Double',
     '    Print #output, row\n    WriteWangBranchStressVectorTest output, "B_BC_BASE_FULL;" & prefix, baseFull\n'
     '    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, matched(1 To 6, 1 To 6) As Double'),
    ("        If code = sfcNone Then\n            value = 0#",
     '        If code = sfcNone Then\n            WriteWangBranchTensorTest output, prefix, method, tangent\n            value = 0#'),
    ("station, trialStress, trialF, plastic, principal, substeps)",
     "station, trialStress, trialF, plastic, principal, substeps, axisFull)"),
    ("""                If bump < 0 Then
                    leftStress = trialStress: leftMatched = agrees
                Else
                    rightStress = trialStress: rightMatched = agrees
                End If""",
     """                If bump < 0 Then
                    leftStress = trialStress: leftMatched = agrees
                    For j = 1 To 6: leftFull(j) = axisFull(j): Next j
                Else
                    rightStress = trialStress: rightMatched = agrees
                    For j = 1 To 6: rightFull(j) = axisFull(j): Next j
                End If
                WriteWangBranchStressVectorTest output, "B_BC_AXIS_FULL;" & prefix & ";" & CStr(i) & ";" & CStr(divisor) & ";" & CStr(bump), axisFull"""),
    ("""                If leftMatched And rightMatched Then
                    matched(i) = (rightStress - leftStress) / (2# * h)
                ElseIf rightMatched Then
                    matched(i) = (rightStress - baseStress) / h
                ElseIf leftMatched Then
                    matched(i) = (baseStress - leftStress) / h
                Else
                    complete = False
                End If""",
     """                If Not leftMatched And Not rightMatched Then complete = False
                For j = 1 To 6
                    If leftMatched And rightMatched Then
                        matched(j, i) = (rightFull(j) - leftFull(j)) / (2# * h)
                    ElseIf rightMatched Then
                        matched(j, i) = (rightFull(j) - baseFull(j)) / h
                    ElseIf leftMatched Then
                        matched(j, i) = (baseFull(j) - leftFull(j)) / h
                    End If
                Next j"""),
    ("    If complete Then\n        value = 0#",
     '    If complete Then\n        WriteWangBranchTensorTest output, prefix, "MatchedQuarter", matched\n        value = 0#'),
    ("ExperimentNumberTest(matched(i))\n            value = value + matched(i) * direction(i)",
     "ExperimentNumberTest(matched(3, i))\n            value = value + matched(3, i) * direction(i)"),
    ("""        ByRef plastic As Boolean, ByRef principal As Long, ByRef substeps As Long) As Boolean
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, unused(1 To 6) As Double
    If response.EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then Exit Function""",
     """        ByRef plastic As Boolean, ByRef principal As Long, ByRef substeps As Long, ByRef allStress() As Double) As Boolean
    Dim tangent(1 To 6, 1 To 6) As Double, unused(1 To 6) As Double
    If response.EvaluatePoint(point, station, allStress, tangent, ctmStressOnly, False) <> sfcNone Then Exit Function"""),
    ("    axialStress = stress(3)", "    axialStress = allStress(3)"),
]
for a,b in extensions:
    vba = single(vba,a,b)
vba += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет полный порядок напряжений как принятый в интерфейсе материала.
Private Sub WriteWangBranchStressVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef stress() As Double)
    Dim i As Long
    For i = 1 To 6: prefix = prefix & ";" & ExperimentNumberTest(stress(i)): Next i
    Print #output, prefix
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет полный тензор касательной. Строка задаёт компоненту напряжений.
Private Sub WriteWangBranchTensorTest(ByVal output As Integer, ByVal prefix As String, ByVal method As String, ByRef tangent() As Double)
    Dim i As Long, j As Long, row As String
    For i = 1 To 6
        row = "B_BC_TENSOR;" & prefix & ";" & method & ";" & CStr(i)
        For j = 1 To 6: row = row & ";" & ExperimentNumberTest(tangent(i, j)): Next j
        Print #output, row
    Next i
End Sub
'''
(here / "BranchProbe.bas").write_text(vba,encoding="utf8",newline="\n")

source = materialize("Verify-MVT2ShearControlled.py","0844A114F9A9D15AB6497BE33C2B0BD58392123063D2B434962868BF37FAF2A7").decode("utf-8")
source = single(source,"selected = ((2,-1),(2,1),(22,1),(23,-1),(23,1))",
                "selected = ((2,-1),(2,1),(22,1),(23,-1),(23,1),(2,0),(22,0))")
ext = (here / "FullTensor.py").read_text(encoding="utf8")
entry = '\nif __name__ == "__main__":'
source = single(source,entry,"\n\n"+ext+"\n"+entry)
source = single(source,'            "history_or_equilibrium_claimed":False,',
                '            "complete_tensor_comparison": verify_full_tensors(tags, z, minus, plus, ray, resolved, states),\n'
                '            "history_or_equilibrium_claimed":False,')
(here / "Verify-MVT2ShearControlled.py").write_text(source,encoding="utf8",newline="\n")
