"""Replay the frozen verification with old raw centre-station references."""
import argparse
from hashlib import sha256
import json
from pathlib import Path


here = Path(__file__).resolve().parent
verifier_sha = "A345F3B9FF6E3223BFCB7DFB107193E03F86BA9073D59C9A829AB9662816D0B8"
trace_sha = "FFAFCBE9E3E7D1A36445B4A0B42482214D942A4D34408900CA5C858799F3ECD8"
book_sha = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def single(text, source, replacement):
    assert text.count(source) == 1, source
    return text.replace(source,replacement)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline",action="store_true",help="verify workbook via the owned native receipts")
    args = parser.parse_args()
    entry = here/"Verify-MVT2ShearControlled.py"
    assert digest(entry) == verifier_sha
    assert digest(here/"NativeHalf/MVT2.csv") == trace_sha
    source = entry.read_text(encoding="utf-8")
    source = single(source,"        weight = side*a[2]/(v.AREA*.002)",
                    "        weight = a[2]/v.AREA if side == 0 else side*a[2]/(v.AREA*.002)")
    source = single(source,'''        old_exact = old["original_material_directional_measurements"]["0.25"]["all_station_values"][str(point)][str(side)]
        assert abs(actual-old_exact["centered_MPa"]) < 2e-9''',
                    '''        if side == 0:
            old_minus, old_plus = old_stations["Ray-25"][key], old_stations["Ray25"][key]
            assert old_minus[:3] == old_plus[:3] == a[:3]
            old_centered = 2*weight*(old_plus[15]-old_minus[15])
            assert abs(actual-old_centered) < 2e-9
        else:
            old_exact = old["original_material_directional_measurements"]["0.25"]["all_station_values"][str(point)][str(side)]
            assert abs(actual-old_exact["centered_MPa"]) < 2e-9''')
    source = single(source,'            if name == "Stock":\n                assert abs(action-old_exact["stock_MPa"]) < 2e-9',
                    '            if name == "Stock" and side != 0:\n                assert abs(action-old_exact["stock_MPa"]) < 2e-9')
    if args.offline:
        source = single(source,'    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]',
                        f'    assert prep["book_sha256"] == "{book_sha}"')
    scope = {"__name__":"full_tensor_centre_reference","__file__":str(entry)}
    exec(compile(source,str(entry),"exec"),scope)
    result = scope["verify"](*scope["prepare"]())
    result["detached_amendment"] = {
        "archived_independent_verifier_sha256":verifier_sha,
        "original_native_trace_sha256":trace_sha,
        "reason":"The old scalar report stores two axial-side tangent actions per point. The two new centre-station controls use the old raw quarter-ray stresses, the same fields, and their centre axial quadrature weights.",
        "source_centre_stress_archive_sha256":digest(here/"SameRayNative.csv"),
        "old_local_stock_centre_action_available":False,
        "new_centre_tangent_still_checked_against_original_material":True,
        "unchanged_original_acceptance_checks":True}
    target = here/"VerificationBranch.json"
    target.write_bytes((json.dumps(result,indent=2)+"\n").encode())
    print(target,digest(target))


if __name__ == "__main__":
    main()
