' -------------------- ДЛЯ ТЕСТОВ --------------------
' Измеряет двустороннее действие исходного материала MVT2 B.
Public Function RunTestWangShearControlled(ByVal replayPath As String, ByVal phase As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Const EC As Double = 30000#, NU As Double = 0.2, FT As Double = 2.10667357864589
    Const PEAK_STRAIN As Double = 0.0022, LOCALIZATION_LENGTH As Double = 125#
    concrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    plusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    response.Initialize operators, concrete, steel
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, response, EC, plusSide, minusSide
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim materials(-1 To 1) As CCoupledConcreteResponse, responses(-1 To 1) As ICoupledPointResponse
    Set materials(0) = concrete: Set materials(1) = plusConcrete: Set materials(-1) = minusConcrete
    Set responses(0) = response: Set responses(1) = plusSide: Set responses(-1) = minusSide
    Dim base() As Double, qBase As Double, qTrial As Double, norm As Double, folder As String
    Dim actual() As Double, residual() As Double
    folder = Left$(replayPath, InStrRev(replayPath, "\"))
    base = history(24): qBase = factors(24): qTrial = qBase + (qBase - factors(23)) / 64#
    Dim output As Integer: output = FreeFile
    Open tracePath For Append As #output
    Print #output, "B_TANGENT_LOAD;" & ExperimentNumberTest(qBase) & ";" & ExperimentNumberTest(qTrial)
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Base24", 24, qBase, solver, operators, materials, responses, base, actual, residual)
    Print #output, "B_FRESH_PHASE;" & phase
    If phase <> "Half" Then Err.Raise 5, , "Неизвестная фаза луча MVT2."
    ProbeWangSameRayTest output, folder, history, solver, operators, materials, responses, base
    RequireWangAcceptedFieldTest solver, base
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Restored24", 24, qBase, solver, operators, materials, responses, base, actual, residual)
    Print #output, "B_TANGENT_END;24;" & ExperimentNumberTest(qBase)
    Close #output
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    Dim problem As String: problem = Err.Source & " " & Err.Description
    On Error Resume Next
    If output > 0 Then Close #output
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Масштабирует одно и то же направление без изменения принятого поля решателя.
Private Sub AddWangTangentDirectionTest(ByRef base() As Double, ByRef direction() As Double, _
        ByVal amount As Double, ByRef target() As Double)
    Dim j As Long
    ReDim target(1 To UBound(base))
    For j = 1 To UBound(base): target(j) = base(j) + amount * direction(j): Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает вектор в инвариантной форме для независимой проверки.
Private Sub EmitWangTangentVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef values() As Double)
    Dim row As String, j As Long
    row = prefix
    For j = 1 To UBound(values): row = row & ";" & ExperimentNumberTest(values(j)): Next j
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет независимые центральные и боковые напряжения, признаки ветви и слабые строки.
Private Function RecordWangTangentStateTest(ByVal output As Integer, ByVal label As String, ByVal historyCount As Long, _
        ByVal factor As Double, ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef field() As Double, _
        ByRef actual() As Double, ByRef residual() As Double) As Double
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, grad(1 To 6) As Double
    Dim matrix() As Double, external() As Double, row As String, flag As Long
    Dim yielding As Boolean, principal As Long, substeps As Long, yieldValue As Double
    Dim concretePoint As ICoupledPointResponse, concreteStress(1 To 6) As Double, component As Long
    EmitWangTangentVectorTest output, "B_TANGENT_FIELD;" & label & ";" & CStr(historyCount) & ";" & _
        ExperimentNumberTest(factor), field
    RecordWangTangentStateTest = -1#
    If Not solver.TestEquilibriumLinearization(field, False, False, residual, matrix) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";Residual"
        Exit Function
    End If
    operators.LoadEquations 0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, external
    For i = 1 To UBound(residual): residual(i) = residual(i) - external(i): Next i
    EmitWangTangentVectorTest output, "B_TANGENT_RESIDUAL;" & label, residual
    Dim norm As Double, value As Double, demand(1 To 6) As Double
    ReDim actual(1 To 6)
    For i = 1 To UBound(residual)
        value = Abs(residual(i))
        If i > solver.PhysicalDegreeCount Then value = value * 30000#
        norm = GeomMax(norm, value)
    Next i
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For point = 1 To operators.PointCount
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, slope
        For side = -1 To 1
            For i = 1 To 6: station(i) = strain(i) + side * 0.001 * slope(i): Next i
            If responses(side).EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Не подтвержден станционный отклик MVT2 B. " & label
            If side = 0 Then
                actual(1) = actual(1) + area * stress(3)
                actual(2) = actual(2) + area * stress(3) * y
                actual(3) = actual(3) + area * stress(3) * x
                actual(4) = actual(4) + area * (x * stress(6) - y * stress(5))
                actual(5) = actual(5) + area * stress(5)
                actual(6) = actual(6) + area * stress(6)
            End If
            If point > operators.ConcretePointCount Then
                Set concretePoint = materials(side)
                If concretePoint.EvaluatePoint(point, station, concreteStress, tangent, ctmStressOnly, False) <> sfcNone Then _
                    Err.Raise 5, , "Не подтверждён бетон в поправке замещения арматуры MVT2 B. " & label
                component = 3 ' Продольные стержни имеют ось z.
                If point > operators.ConcretePointCount + 4 Then
                    If Abs(x) > Abs(y) Then component = 2 Else component = 1 ' Ось ветви параллельна стенке квадрата.
                End If
                Print #output, "B_BOUND_STEEL;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & CStr(component) & ";" & _
                    ExperimentNumberTest(station(component)) & ";" & ExperimentNumberTest(concreteStress(component)) & ";" & _
                    ExperimentNumberTest(stress(component) + concreteStress(component))
            End If
            flag = -1: principal = 0: substeps = -1: yieldValue = 0#
            If point <= operators.ConcretePointCount Then
                If Not materials(side).TryReadConcreteBranch(point, station, yielding, principal, substeps) Then _
                    Err.Raise 5, , "Недоступна ветвь бетона MVT2 B. " & label
                If Not materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=False) Then _
                    Err.Raise 5, , "Недоступна пробная поверхность бетона MVT2 B. " & label
                flag = Abs(CLng(yielding))
            End If
            row = "B_TANGENT_STATION;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area) & ";" & _
                CStr(flag) & ";" & CStr(principal) & ";" & CStr(substeps) & ";" & ExperimentNumberTest(yieldValue)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(station(i)): Next i
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(i)): Next i
            Print #output, row
        Next side
    Next point
    EmitWangTangentVectorTest output, "B_BOUND_ACTUAL;" & label, actual
    RecordWangTangentStateTest = GeomMax(norm, operators.ResultantResidualNorm(actual, demand))
    Print #output, "B_BOUND_NORM;" & label & ";" & ExperimentNumberTest(RecordWangTangentStateTest)
End Function



' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет один записанный луч по обе стороны остановки при неизменной H24.
' Ни одна точка стенда не публикуется в историю материала.
Private Sub ProbeWangSameRayTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef base() As Double)
    Dim origin() As Double, ray() As Double, field() As Double, q0 As Double, qray As Double
    ReadWangRayVectorTest folder & "RayStop.csv", origin, q0
    ReadWangRayVectorTest folder & "RayDirection.csv", ray, qray
    Dim stockHistory() As Double, checkedHistory() As Double, norm As Double, actual() As Double, weak() As Double
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "RayBefore", operators, materials, stockHistory
    norm = RecordWangTangentStateTest(output, "RayZero", 24, q0, solver, operators, materials, responses, origin, actual, weak)
    If norm < 0# Then Err.Raise 5, , "Не воспроизведено поле остановки MVT2."
    ReadWangBranchActionTest output, operators, materials, responses, origin, ray
    Dim ratio As Variant, label As String, i As Long, factor As Double
    For Each ratio In Array(-0.25, 0.25)
        label = "Ray" & CStr(CLng(100# * CDbl(ratio)))
        RestoreWangShearBaselineTest solver, history, base
        field = origin
        For i = 1 To 60: field(i) = field(i) + CDbl(ratio) * ray(i): Next i
        factor = q0 + CDbl(ratio) * qray
        Print #output, "B_RAY_STEP;" & label & ";" & ExperimentNumberTest(CDbl(ratio)) & ";" & ExperimentNumberTest(factor)
        norm = RecordWangTangentStateTest(output, label, 24, factor, solver, operators, materials, responses, field, actual, weak)
        RequireWangAcceptedFieldTest solver, base
        CaptureWangArcHistoryTest output, label, operators, materials, checkedHistory
        RequireWangArcHistoryTest stockHistory, checkedHistory
    Next ratio
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "RayFinal", operators, materials, checkedHistory
    RequireWangArcHistoryTest stockHistory, checkedHistory
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает ровно 60 координат и составляющую параметра для замороженного луча.
Private Sub ReadWangRayVectorTest(ByVal path As String, ByRef field() As Double, ByRef factor As Double)
    Dim stream As Integer, raw As String, terms As Variant, i As Long
    stream = FreeFile: Open path For Input As #stream
    Line Input #stream, raw
    If Not EOF(stream) Then Err.Raise 5, , "Лишние строки луча MVT2."
    Close #stream
    terms = Split(raw, ";")
    If UBound(terms) <> 60 Then Err.Raise 5, , "Неверная длина луча MVT2."
    ReDim field(1 To 60)
    For i = 1 To 60: field(i) = Val(terms(i - 1)): Next i
    factor = Val(terms(60))
End Sub


' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет касательные только на трёх проблемных станциях и двух
' контрольных станциях точки 23. Состояние H24 используется только для чтения.
Private Sub ReadWangBranchActionTest(ByVal output As Integer, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef origin() As Double, ByRef ray() As Double)
    Dim item As Variant, point As Long, side As Long
    For Each item In Array(Array(2, -1), Array(2, 1), Array(22, 1), Array(23, -1), Array(23, 1), Array(2, 0), Array(22, 0))
        point = CLng(item(0)): side = CLng(item(1))
        ReadWangBranchStationTest output, operators, materials(side), responses(side), origin, ray, point, side
    Next item
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает исходные столбцы и ветви всех возмущений для независимого
' пересчёта направленного действия dσz на архивном луче.
Private Sub ReadWangBranchStationTest(ByVal output As Integer, ByVal operators As CCoupledElasticState, _
        ByVal material As CCoupledConcreteResponse, ByVal response As ICoupledPointResponse, _
        ByRef origin() As Double, ByRef ray() As Double, ByVal point As Long, ByVal side As Long)
    Dim center(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim rayCenter(1 To 6) As Double, raySlope(1 To 6) As Double, direction(1 To 6) As Double
    operators.PointStrain point, origin, center: operators.AxialGradientAtPoint point, origin, slope
    operators.PointStrain point, ray, rayCenter: operators.AxialGradientAtPoint point, ray, raySlope
    Dim i As Long, prefix As String, row As String
    prefix = CStr(point) & ";" & CStr(side)
    For i = 1 To 6
        station(i) = center(i) + side * 0.001 * slope(i)
        direction(i) = rayCenter(i) + side * 0.001 * raySlope(i)
    Next i
    Dim baseStress As Double, baseF As Double, basePlastic As Boolean, basePrincipal As Long, baseSteps As Long
    Dim baseFull(1 To 6) As Double, axisFull(1 To 6) As Double, leftFull(1 To 6) As Double, rightFull(1 To 6) As Double, j As Long
    If Not ReadWangBranchStressTest(material, response, point, station, baseStress, baseF, basePlastic, basePrincipal, baseSteps, baseFull) Then _
        Err.Raise 5, , "Не восстановлена ветвь опытной станции MVT2."
    row = "B_BC_BASE;" & prefix & ";" & ExperimentNumberTest(baseStress) & ";" & ExperimentNumberTest(baseF) & ";" & _
        CStr(Abs(CLng(basePlastic))) & ";" & CStr(basePrincipal) & ";" & CStr(baseSteps)
    For i = 1 To 6: row = row & ";" & ExperimentNumberTest(direction(i)): Next i
    Print #output, row
    WriteWangBranchStressVectorTest output, "B_BC_BASE_FULL;" & prefix, baseFull
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, matched(1 To 6, 1 To 6) As Double
    Dim code As ESolverFailureCode, mode As Variant, method As String, value As Double
    For Each mode In Array(ctmFull, ctmFullBranchConsistent)
        method = "Stock": If CLng(mode) = ctmFullBranchConsistent Then method = "Consistent"
        code = response.EvaluatePoint(point, station, stress, tangent, CLng(mode), False)
        row = "B_BC_MODE;" & prefix & ";" & method & ";" & CStr(Abs(CLng(code = sfcNone)))
        If code = sfcNone Then
            WriteWangBranchTensorTest output, prefix, method, tangent
            value = 0#
            For i = 1 To 6
                row = row & ";" & ExperimentNumberTest(tangent(3, i))
                value = value + tangent(3, i) * direction(i)
            Next i
            row = row & ";" & ExperimentNumberTest(value)
        End If
        Print #output, row
    Next mode
    Dim h As Double, bump As Long, divisor As Variant, leftStress As Double, rightStress As Double, trialStress As Double
    Dim trialF As Double, plastic As Boolean, principal As Long, substeps As Long, ok As Boolean, agrees As Boolean
    Dim leftMatched As Boolean, rightMatched As Boolean, complete As Boolean
    complete = True
    For Each divisor In Array(1&, 4&)
        For i = 1 To 6
            h = 0.000000002 * (1# + Abs(station(i))) / CLng(divisor)
            leftMatched = False: rightMatched = False
            For bump = -1 To 1 Step 2
                trialStress = 0#: trialF = 0#: plastic = False: principal = 0: substeps = 0
                station(i) = center(i) + side * 0.001 * slope(i) + bump * h
                ok = ReadWangBranchStressTest(material, response, point, station, trialStress, trialF, plastic, principal, substeps, axisFull)
                agrees = (ok And plastic = basePlastic And principal = basePrincipal And substeps = baseSteps And Sgn(trialF) = Sgn(baseF))
                If bump < 0 Then
                    leftStress = trialStress: leftMatched = agrees
                    For j = 1 To 6: leftFull(j) = axisFull(j): Next j
                Else
                    rightStress = trialStress: rightMatched = agrees
                    For j = 1 To 6: rightFull(j) = axisFull(j): Next j
                End If
                WriteWangBranchStressVectorTest output, "B_BC_AXIS_FULL;" & prefix & ";" & CStr(i) & ";" & CStr(divisor) & ";" & CStr(bump), axisFull
                Print #output, "B_BC_AXIS;" & prefix & ";" & CStr(i) & ";" & CStr(divisor) & ";" & CStr(bump) & ";" & _
                    ExperimentNumberTest(h) & ";" & CStr(Abs(CLng(ok))) & ";" & CStr(Abs(CLng(agrees))) & ";" & _
                    ExperimentNumberTest(trialStress) & ";" & ExperimentNumberTest(trialF) & ";" & _
                    CStr(Abs(CLng(plastic))) & ";" & CStr(principal) & ";" & CStr(substeps)
            Next bump
            station(i) = center(i) + side * 0.001 * slope(i)
            If CLng(divisor) = 4 Then
                If Not leftMatched And Not rightMatched Then complete = False
                For j = 1 To 6
                    If leftMatched And rightMatched Then
                        matched(j, i) = (rightFull(j) - leftFull(j)) / (2# * h)
                    ElseIf rightMatched Then
                        matched(j, i) = (rightFull(j) - baseFull(j)) / h
                    ElseIf leftMatched Then
                        matched(j, i) = (baseFull(j) - leftFull(j)) / h
                    End If
                Next j
            End If
        Next i
    Next divisor
    row = "B_BC_MODE;" & prefix & ";MatchedQuarter;" & CStr(Abs(CLng(complete)))
    If complete Then
        WriteWangBranchTensorTest output, prefix, "MatchedQuarter", matched
        value = 0#
        For i = 1 To 6
            row = row & ";" & ExperimentNumberTest(matched(3, i))
            value = value + matched(3, i) * direction(i)
        Next i
        row = row & ";" & ExperimentNumberTest(value)
    End If
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает напряжение и признаки ветви от той же принятой истории, не
' записывая материальную пробу. Локальная ошибка оставляет колонку пустой.
Private Function ReadWangBranchStressTest(ByVal material As CCoupledConcreteResponse, ByVal response As ICoupledPointResponse, _
        ByVal point As Long, ByRef station() As Double, ByRef axialStress As Double, ByRef valueF As Double, _
        ByRef plastic As Boolean, ByRef principal As Long, ByRef substeps As Long, ByRef allStress() As Double) As Boolean
    Dim tangent(1 To 6, 1 To 6) As Double, unused(1 To 6) As Double
    If response.EvaluatePoint(point, station, allStress, tangent, ctmStressOnly, False) <> sfcNone Then Exit Function
    If Not material.TryReadTrialYield(point, station, valueF, unused, needGradient:=False) Then Exit Function
    If Not material.TryReadConcreteBranch(point, station, plastic, principal, substeps) Then Exit Function
    axialStress = allStress(3)
    ReadWangBranchStressTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет полный порядок напряжений как принятый в интерфейсе материала.
Private Sub WriteWangBranchStressVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef stress() As Double)
    Dim i As Long
    For i = 1 To 6: prefix = prefix & ";" & ExperimentNumberTest(stress(i)): Next i
    Print #output, prefix
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет полный тензор касательной. Строка задаёт компоненту напряжений.
Private Sub WriteWangBranchTensorTest(ByVal output As Integer, ByVal prefix As String, ByVal method As String, ByRef tangent() As Double)
    Dim i As Long, j As Long, row As String
    For i = 1 To 6
        row = "B_BC_TENSOR;" & prefix & ";" & method & ";" & CStr(i)
        For j = 1 To 6: row = row & ";" & ExperimentNumberTest(tangent(i, j)): Next j
        Print #output, row
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает напряжения и энергии всех принятых точек бетона с трёх станций.
' Вывод снимается до явного повтора истории, чтобы обнаружить лишнюю фиксацию.
Private Sub CaptureWangArcHistoryTest(ByVal output As Integer, ByVal label As String, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef snapshot() As Double)
    Dim point As Long, side As Long, i As Long, position As Long
    Dim stress(1 To 6) As Double, tension As Double, compression As Double
    ReDim snapshot(1 To 3 * operators.PointCount * 8)
    For side = -1 To 1
        For point = 1 To operators.PointCount
            materials(side).CopyAcceptedStress point, stress
            materials(side).AcceptedPointDamage point, tension, compression
            For i = 1 To 6
                snapshot(position + i) = stress(i)
            Next i
            snapshot(position + 7) = tension: snapshot(position + 8) = compression
            position = position + 8
        Next point
    Next side
    EmitWangTangentVectorTest output, "B_ARC_HISTORY;" & label, snapshot
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет точное совпадение принятого отклика, без округления и послабления.
Private Sub RequireWangArcHistoryTest(ByRef committed() As Double, ByRef afterProbe() As Double)
    Dim i As Long
    For i = 1 To UBound(committed)
        If committed(i) <> afterProbe(i) Then Err.Raise 5, , "Принятая история изменилась во время пробы MVT2."
    Next i
End Sub
