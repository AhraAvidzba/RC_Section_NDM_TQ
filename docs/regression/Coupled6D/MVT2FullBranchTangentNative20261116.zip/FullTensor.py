# Added to the common local-station verifier during sealing.


def point_projection(geometry, side, traction):
    x, y, area = geometry
    operator, shape, _, _ = v.operators(x,y)
    weak = [0.]*61
    direct_six = [0.]*6
    if side == 0:
        for i, terms in enumerate(operator):
            weak[i] = area/v.AREA * fsum(traction[j]*coefficient for j,coefficient in terms)
        sx, sy, axial = (area*traction[i] for i in (4,5,2))
        direct_six = [axial, axial*y, axial*x, x*sy-y*sx, sx, sy]
    else:
        grad = tuple(side*area/(.002*v.AREA) * x for x in traction)
        for i, terms in enumerate(operator):
            if i < 4:
                weak[i+52] = fsum(grad[j]*coeff for j,coeff in terms)
            else:
                weak[i] = -shape[(i-4)//3]*grad[(4,5,2)[(i-4)%3]]
    return weak,direct_six


def full_point_action(tensors, key, method, field, station):
    p,side = key
    geometry = station[key][:3]
    strains = v.strain_at(field, v.operators(*geometry[:2]),side)
    modified = tensors[key,method]
    stock = tensors[key,"Stock"]
    return point_projection(geometry,side,tuple(v.dot(v.diff(m,s),strains) for m,s in zip(modified,stock,strict=True)))


def verify_full_tensors(tags, z, minus, plus, ray, resolved, states):
    native_matrix = {}
    for p,s,name,i,*vals in tags["B_BC_TENSOR"]:
        key = (int(p),int(s)),name
        assert len(vals) == 6 and int(i) not in native_matrix.setdefault(key,{})
        native_matrix[key][int(i)] = tuple(map(float,vals))
    mats = {}
    for point, side in selected:
        for method in methods:
            previous = resolved[f"{point}/{side}"]["tangent_actions"][method]
            key = (point,side),method
            if previous is None:
                assert key not in native_matrix
            else:
                rows = native_matrix[key]
                assert tuple(rows) == (1,2,3,4,5,6)
                mats[key] = tuple(rows.values())
                assert rows[3] == tuple(previous["stress_row_z"])
    assert set(mats) == set(native_matrix)
    base = {(int(p),int(s)):tokens for p,s,*tokens in tags["B_BC_BASE_FULL"]}
    assert tuple(base) == selected
    for key,tokens in base.items():
        assert len(tokens) == 6 and tuple(map(float,tokens)) == z[key][13:19]
    raw_stress = {(int(p),int(s),int(i),int(div),int(sign)):tokens
                  for p,s,i,div,sign,*tokens in tags["B_BC_AXIS_FULL"]}
    axis_info = {(int(p),int(s),int(i),int(div),int(sign)):(float(h),bool(int(ok)),bool(int(matched)),sigma)
                 for p,s,i,div,sign,h,ok,matched,sigma,*_ in tags["B_BC_AXIS"]}
    assert set(raw_stress) == set(axis_info) and len(raw_stress) == len(selected)*24
    for key,tokens in raw_stress.items():
        assert len(tokens) == 6
        if axis_info[key][1]:
            assert float(tokens[2]) == float(axis_info[key][3])
    for key in selected:
        if (key,"MatchedQuarter") not in mats:
            continue
        expected = mats[key,"MatchedQuarter"]
        for i in range(6):
            left, right = (*key,i+1,4,-1),(*key,i+1,4,1)
            h,mleft = axis_info[left][0],axis_info[left][2]
            mright = axis_info[right][2]
            assert mleft or mright
            p, m, dx = ((raw_stress[right],raw_stress[left],2*h) if mleft and mright else
                        (raw_stress[right],base[key],h) if mright else (base[key],raw_stress[left],h))
            for j,(a,b) in enumerate(zip(p,m,strict=True)):
                lo,hi = (float(a)-float(b))/dx,(half_wire_unit(a)+half_wire_unit(b))/dx
                assert abs(expected[j][i]-lo) <= hi+3e-6
    prior_trace = v.read_native(here/"ShiftNative.csv")
    J = [tuple(map(float,row[1:])) for row in prior_trace["B_SHIFT_MATRIX"]]
    assert len(J) == 61 and all(len(row) == 61 for row in J)
    stock_action = [v.dot(row,ray) for row in J]
    actual_action = [2.*(b-a) for a,b in zip(states["Ray-25"]["r"][:56],states["Ray25"]["r"][:56],strict=True)]
    side_only = ((2,-1),(2,1),(22,1))
    with_centres = (*side_only,(2,0),(22,0))
    tests = {}
    for method in ("Consistent","MatchedQuarter"):
        for name,scope in (("ThreeSides",side_only),("FiveSites",with_centres)):
            marker = method+"_"+name
            if not all((key,method) in mats and (key,"Stock") in mats for key in scope):
                tests[marker] = {"complete":False}
                continue
            parts = {str(key):full_point_action(mats,key,method,ray[:60],z) for key in scope}
            dw = [fsum(point[0][i] for point in parts.values()) for i in range(61)]
            df = [fsum(point[1][i] for point in parts.values()) for i in range(6)]
            adjusted = [a+b for a,b in zip(stock_action,dw,strict=True)]
            delta = v.diff(adjusted[:56],actual_action)
            delta_columns,force_columns = [],[]
            for j in range(60):
                unit = tuple(float(i==j) for i in range(60))
                rows = [full_point_action(mats,key,method,unit,z) for key in scope]
                delta_columns.append(tuple(fsum(block[0][i] for block in rows) for i in range(61)))
                force_columns.append(tuple(fsum(block[1][i] for block in rows) for i in range(6)))
            matrix = [[a+b for a,b in zip(J[i][:60],(column[i] for column in delta_columns),strict=True)]+[J[i][-1]] for i in range(61)]
            assert v.peak(v.diff(tuple(v.dot(row,ray) for row in matrix),adjusted)) < 4e-12
            tests[marker] = {"complete":True,"held_ray_56_peak_mismatch_MPa":v.peak(delta),
                             "delta_assembled_action61":dw,"direct_six_action_delta_N_Nmm":df,
                             "archive_J_with_local_correction":matrix,
                             "direct_six_matrix_delta_by_row_internal":list(zip(*force_columns,strict=True)),
                             "per_station_weak_and_force_action_delta":parts}
    stresses = {}
    for key in selected:
        d = v.strain_at(ray[:60],v.operators(*z[key][:2]),key[1])
        actual = tuple(2*(y-x) for x,y in zip(minus[key][13:19],plus[key][13:19],strict=True))
        stresses[str(key)] = {"central_reference_action_MPa":actual,
                             "per_mode":{mode:{"tensor":mats[key,mode],"stress_ray_action_MPa":tuple(v.dot(r,d) for r in mats[key,mode])}
                                         for mode in methods if (key,mode) in mats}}
    return {"all_raw_axes_kept":True,"per_station_matrices_and_original_material_action":stresses,
            "stock_56_peak_mismatch_MPa":v.peak(v.diff(stock_action[:56],actual_action)),
            "same_ray_56_original_material_action_MPa":actual_action,"tested_assembly":tests}
