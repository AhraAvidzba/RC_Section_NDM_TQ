Native 6×6 constitutive tensors near MVT2 B branch interfaces

Run after extracting this archive, with the three pinned tracked dependencies.

    python -B -X utf8 ReplayTensorPortable.py PATH/MVT2HalfJointJetNative20261116.zip PATH/MVT2SafeguardedTangentShift20261116.zip PATH/MVT2SameRayDerivativeNative20261116.zip

The current 2ACF workbook (c9e7268) exactly reproduced the old 8EAD accepted
H24 point, stop, and both quarter-ray trial fields, all 62 weak/force
residuals, and all station stress components. H24 was restored. No solver
trial was accepted.

Seven selected stations export all 6×6 Stock, branch-consistent, and matched
h/4 tangent components and actual axis-probe stresses/branch flags. The
independent verified report contains archived J61 plus a current measured
local correction and its separate six-force derivative increment. Three
side-only and five-site patches are compared against the original-law
whole-56 weak action on the unchanged archived ray. No matrix patch was
installed, and the ray check does not establish physical capacity.

The exact archived native verifier omitted raw reference handling at the two
new centre stations and therefore stopped with KeyError '0'. The detached
amendment uses the old raw +/- quarter-ray centre stresses at identical fields
and applies the axial centre projection A_i/A. It preserves the original
law and residual checks. The original verifier, failure and native trace remain.
