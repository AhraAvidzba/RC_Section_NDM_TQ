"""Stage local branch-sensitive derivative checks on the current working workbook."""
from hashlib import sha256
import json
from pathlib import Path


here = Path(__file__).resolve().parent
ray = here.parent / "mvtr"
repo = here.parents[1]
book = "workbook/output/RC_Section_NDM.xlsm"
source_book = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, raw):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def once(text, old, value):
    assert text.count(old) == 1, old
    return text.replace(old, value)


def main():
    original = (ray / "Preparation.json").read_bytes()
    assert digest(original) == "984C3CBE82192CAFA8F9FABD7C1F14996FB0C7E89FB786201E0E0FEE99661AF7"
    archived = json.loads(original)
    inputs = {}
    for name in ("Replay.csv", "VerifyBase.py", "Guard-IsolatedOffice.ps1", "RayStop.csv", "RayDirection.csv",
                 "MVTNormal.csv", "ShiftNative.csv", "Run-MVT2ShearControlled.ps1",
                 *(path for path in archived["inputs"] if path.startswith("tools/"))):
        raw = (ray / name).read_bytes()
        assert digest(raw) == archived["inputs"][name]
        inputs[name] = save(name, raw)
    for name, original, sha in (
        ("SameRayNative.csv", "NativeHalf/MVT2.csv", "7B36BD0EE4173093C26224831461BDD7FD89D09CBB85B5C52C1941695976C8EB"),
        ("SameRayVerification.json", "VerificationRay.json", "1242A059FBBF5E2128ABD94774A48D68C7A54CE33CC937055F808602B746C8D6"),
    ):
        raw = (ray / original).read_bytes()
        assert digest(raw) == sha
        inputs[name] = save(name, raw)
    raw = (repo / book).read_bytes()
    assert digest(raw) == source_book
    save(book, raw)
    save("docs/regression/Diagnostic.xlsm", raw)
    for name in ("src", "NativeHalf", "Temp"):
        (here / name).mkdir(exist_ok=True)
    raw = (ray / "Control.bas").read_bytes()
    assert digest(raw) == archived["inputs"]["Control.bas"]
    control = raw.decode("utf-8")
    control = once(control, "    ReadWangRayStockActionsTest output, operators, responses, origin, ray",
                   "    ReadWangBranchActionTest output, operators, materials, responses, origin, ray")
    control = once(control, "    For Each ratio In Array(-0.5, -0.25, 0.25, 0.5)", "    For Each ratio In Array(-0.25, 0.25)")
    boundary = "' -------------------- ДЛЯ ТЕСТОВ --------------------"
    start = control.rindex(boundary, 0, control.index("Private Sub ReadWangRayStockActionsTest"))
    end = control.rindex(boundary, 0, control.index("Private Sub CaptureWangArcHistoryTest"))
    control = control[:start] + (here / "BranchProbe.bas").read_text(encoding="utf-8") + "\n" + control[end:]
    inputs["Control.bas"] = save("Control.bas", control.encode("utf-8"))
    test = "tests/modTestCoupledExperiment.bas"
    raw = (ray / test).read_bytes()
    assert digest(raw) == archived["inputs"][test]
    module = raw.decode("utf-8").replace("\r\n", "\n")
    start = module.rindex(boundary, 0, module.index("Public Function RunTestWangShearControlled("))
    inputs[test] = save(test, (module[:start] + control).replace("\n", "\r\n").encode("utf-8"))
    for name in ("Stage.py", "BranchProbe.bas", "Verify-MVT2ShearControlled.py", "RecoveryPlan.txt", "FullTensor.py", "CreateFull.py"):
        inputs[name] = digest((here / name).read_bytes())
    prep = {"workbook_revision": "c9e7268", "book_sha256": source_book,
            "control_book_sha256": archived["book_sha256"], "replay_sha256": archived["replay_sha256"],
            "watchdog_seconds": 95, "inputs": inputs}
    print(save("Preparation.json", (json.dumps(prep, indent=2) + "\n").encode()))


if __name__ == "__main__":
    main()
