"""Replay the bracket, native Results assertions and compiled provenance."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
REVISION = '5790d83aac05744605f39d23ea08ed2caef6272c'
SOURCES = ('src/Solver/CCoupledNewtonSolver.cls', 'tests/modTestCoupledElasticState.bas')
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
EXPORT = 'workbook/output/VBA_All_Code.txt'
CASES = {
    'Base': ('RunTestCoupledFinalLoadTolerance',),
    'Candidate': ('RunTestCoupledFinalLoadTolerance', 'RunTestCoupledDeformationControl',
                  'RunTestCoupledDeformationSteelCrossing', 'RunTestCoupledRetainedShoulders',
                  'RunTestCoupledDesignWitness', 'RunTestCoupledDiscardedShoulder',
                  'RunTestCoupledKinematicGauge', 'RunTestCoupledTangentProof', 'RunTestCoupledWorkbookInput'),
}


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, values):
    path.write_text(json.dumps(values, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def selected_log(role, name):
    return ROOT / role / 'Native' / f'{name}.txt'


def native(role, name, expected_hash):
    log = selected_log(role, name)
    report = log.read_text(encoding='utf-8-sig')
    receipt = read(log.with_suffix('.txt.Receipt.json'))
    owner = read(log.with_suffix('.txt.Ownership.json'))
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256'] == expected_hash
    assert (owner['PID'], owner['StartTicksUTC']) == (receipt['closed']['PID'], receipt['closed']['StartTicksUTC'])
    assert receipt['closed']['State'] == 'Absent'
    assert f'SOURCE_SHA256: {expected_hash}' in report
    match = re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)$', report, re.M)
    assert len(match) == 1 and tuple(map(int, match[0])) == (receipt['pass'], receipt['fail'])
    assert 'RUNTIME ERROR:' not in report and 'SOURCE_UNCHANGED: True' in report
    failures = re.findall(r'^FAIL: (.*)$', report, re.M)
    assert len(failures) == receipt['fail']
    assert receipt['exit'] == int(bool(failures))
    return receipt, failures


def check_behavior(base_hash, new_hash):
    totals = {role: {} for role in CASES}
    strain, modulus, cubic, area = Fraction('1.8e-6'), 30_000, 10**10, 21_600
    absolute, relative = Fraction('1e-8'), Fraction('5e-7')
    elastic_stress = strain * modulus
    initial_tolerance = absolute + 3 * relative * elastic_stress
    corrected_tolerance = absolute + relative * elastic_stress
    cubic_stress = cubic * strain**3
    correct_lambda = (elastic_stress + cubic_stress) / elastic_stress
    assert corrected_tolerance < cubic_stress < initial_tolerance
    assert correct_lambda == Fraction('1.00000108')
    for role, names in CASES.items():
        for name in names:
            receipt, failures = native(role, name, base_hash if role == 'Base' else new_hash)
            if role == 'Candidate':
                assert not failures
            else:
                assert (receipt['pass'], receipt['fail']) == (2, 2)
                result = re.fullmatch(r'остаток в допуске найденной нагрузки (\S+) <= (\S+)', failures[0])
                assert abs(float(result[1].replace(',', '.')) - float(cubic_stress)) <= 1e-15
                assert abs(float(result[2].replace(',', '.')) - float(corrected_tolerance)) <= 1e-15
                assert failures[1].replace(',', '.') == 'множитель по независимому кубическому закону actual=1 expected=1.00000108'
            totals[role][name] = receipt
    return totals, dict(elastic_force_N=float(area * elastic_stress), cubic_stress_MPa=float(cubic_stress),
                        initial_tolerance_MPa=float(initial_tolerance), corrected_tolerance_MPa=float(corrected_tolerance),
                        exact_lambda=float(correct_lambda))


def verify_export(proof, equality, comparison):
    assert equality['Passed'] and all(equality['VerifierSelfChecks'].values())
    assert equality['SourceComponents'] == len(SOURCES)
    assert equality['ExportComponents'] == comparison['components'] == 225
    assert equality['ExportSHA256'] == proof['installed_export_sha256']
    assert {record['Name']: record['SourceSHA256'] for record in equality['Components']} == {
        Path(name).stem: value for name, value in proof['sources'].items()
    }
    assert sorted(Path(name).stem for name in SOURCES) == comparison['changes']


def attest():
    base = ROOT / 'Base'
    candidate = ROOT / 'Candidate'
    result = candidate / 'docs/regression/Audit03/DesignWitness'
    package = read(candidate / 'PackageChecks.json')
    assert package['base_sha256'] == sha(candidate / BOOK)
    assert package['candidate_sha256'] == sha(result / Path(BOOK).name)
    with ZipFile(candidate / BOOK) as original, ZipFile(result / Path(BOOK).name) as built:
        assert built.testzip() is None and original.namelist() == built.namelist()
        assert [entry for entry in original.namelist() if original.read(entry) != built.read(entry)] == ['xl/vbaProject.bin']
        assert package['unchanged_package_parts'] == len(original.infolist()) - 1 == 121
        assert package['vba_sha256'] == sha256(built.read('xl/vbaProject.bin')).hexdigest().upper()

    base_compile = read(base / 'docs/regression/CodeUpdate.json')
    assert base_compile['Compiled'] and not base_compile['ProductionChanged']
    assert base_compile['ProductionSHA256'] == package['base_sha256']
    assert base_compile['WorkbookSHA256'] == sha(base / 'docs/regression/Diagnostic.xlsm')
    totals, analytical = check_behavior(base_compile['WorkbookSHA256'], package['candidate_sha256'])
    closure = read(candidate / 'ExportClosure.json')
    assert closure['State'] == 'Absent'
    assert f"sourceSHA256={package['candidate_sha256']}; sourceUnchanged=True" in (candidate / 'Export.log').read_text(encoding='utf-8-sig')
    proof = {
        'status': 'PASS', 'source_git_revision': REVISION, 'package': package,
        'installed_export_sha256': sha(result / Path(EXPORT).name), 'previous_export_sha256': sha(candidate / EXPORT),
        'sources': {name: sha(candidate / name) for name in SOURCES}, 'native': totals, 'analytical': analytical,
        'baseline_diagnostic_sha256': base_compile['WorkbookSHA256'], 'export_closure': closure,
    }
    verify_export(proof, read(candidate / 'docs/regression/SourceEquality.json'), read(candidate / 'ExportDifference.json'))
    write(ROOT / 'Verification.json', proof)
    print('PASS', sha(ROOT / 'Verification.json'), [sum(r['pass'] for r in layer.values()) for layer in totals.values()])


def replay():
    proof = read(ROOT / 'Verification.json')
    publication = read(ROOT / 'Publication.json')
    assert publication['verification_sha256'] == sha(ROOT / 'Verification.json')
    assert publication['status'] == proof['status'] == 'PASS' and proof['source_git_revision'] == REVISION
    workbook = proof['package']['candidate_sha256']
    assert publication['installed'] == {BOOK: workbook, EXPORT: proof['installed_export_sha256'], **proof['sources']}
    assert proof['package']['unchanged_package_parts'] == 121 and proof['export_closure']['State'] == 'Absent'
    for path in SOURCES:
        assert sha(ROOT / 'compiled' / path) == proof['sources'][path]
    verify_export(proof, read(ROOT / 'SourceEquality.json'), read(ROOT / 'ExportDifference.json'))
    totals, analytical = check_behavior(proof['baseline_diagnostic_sha256'], workbook)
    assert proof['native'] == totals and proof['analytical'] == analytical
    results = {
        'native_assertions': sum(row['pass'] for row in totals['Candidate'].values()),
        'baseline_expected_failures': sum(row['fail'] for row in totals['Base'].values()),
        'analytical': analytical, 'build_verification_sha256': sha(ROOT / 'Verification.json'),
        'workbook_sha256': workbook, 'export_sha256': proof['installed_export_sha256'],
    }
    write(ROOT / 'Replay.json', results)
    print('PASS', sha(ROOT / 'Replay.json'), results['native_assertions'])


if __name__ == '__main__':
    if sys.argv[1:] == ['--build']:
        attest()
    else:
        assert not sys.argv[1:]
        replay()
