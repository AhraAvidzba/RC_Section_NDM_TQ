"""Готовит отдельную книгу для повтора тензоров MVT2 с разной дилатансией."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent


def stage(repo, root):
    base = run_path(str(HERE / 'Stage-MaterialHistory.py'))
    base['stage'](repo, root)
    test = root / 'tests/modTestMVT2GaussSpan.bas'
    module = test.read_text(encoding='utf-8-sig')
    original = 'TestPublicationRecovery = TestPublicationMaterialHistory(solver, operators, concrete, history, report, tracePath)'
    replacement = 'TestPublicationRecovery = TestPublicationDilationSweep(operators, history, report, tracePath)'
    assert module.count(original) == 1
    module = module.replace(original, replacement)
    module += (HERE / 'DilationSweep.bas.txt').read_text(encoding='utf-8')
    module.encode('cp1251')
    test.write_bytes(module.replace('\n', '\r\n').encode('utf-8-sig'))
    driver = root / 'Run-Native.ps1'
    content = driver.read_text(encoding='utf-8')
    anchor = '    Copy-Item -LiteralPath ($trace+\'.Operators.csv\') -Destination "Native/Operators.csv"'
    assert content.count(anchor) == 1
    driver.write_bytes(content.replace(anchor, anchor + '\n' +
        '    Copy-Item -LiteralPath ($trace+\'.Dilation.csv\') -Destination "Native/Dilation.csv"').encode('utf-8'))
    meta = root / 'Preparation.json'
    preparation = json.loads(meta.read_bytes())
    preparation['dilation_max_degrees'] = [20, 26, 32, 40]
    for path in (test, driver):
        preparation['inputs'][path.relative_to(root).as_posix()] = base['digest'](path.read_bytes())
    meta.write_bytes((json.dumps(preparation, indent=2) + '\n').encode('utf-8'))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--stage', required=True, type=Path)
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve())
