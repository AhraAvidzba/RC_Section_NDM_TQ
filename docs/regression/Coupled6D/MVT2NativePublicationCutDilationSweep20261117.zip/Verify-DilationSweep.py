"""Сверяет влияние максимального угла дилатансии на одинаковых полях MVT2."""

from argparse import ArgumentParser
import json
from math import fsum
from pathlib import Path
from statistics import fmean


ANGLES = (20, 26, 32, 40)
MODEL = 'MVT2NativePublicationCutMaterialHistory20261117.zip'
MODEL_SHA = '6920EB24A5D01585E510FDBC1064513C0C83AA62583AEB0C2553D6F0D495EE55'
REFERENCE = 'MVT2NativePublicationCutTimed20261117.zip'
REFERENCE_SHA = 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A'
ASD = 'MVT2Cut396MaterialPredictor20261117.zip'
ASD_SHA = '9371CDC9B169CEDDE05776280399C2676F776033DC12F01F0F7C572C1031EF55'
SOURCE_PATH = 'src/Materials/CCoupledConcreteResponse.cls'
PAPER_PATH = 'literature/Coupled6D/Poliotti-Bairan-2019-Evolutive-dilatancy.pdf'
PAPER_SHA = '55B25E1C0EF995543E8F7414F04BE670B112C294A9C69D02C1ECE20EC9E0A08D'
POINTS = tuple(range(1, 26))


def integrate(geometry, stresses):
    """Интегрирует шесть знаковых компонент только по 25 точкам бетона."""
    (ox, oy, _, _), points = geometry
    parts = []
    for point, tensor in zip(POINTS, stresses, strict=True):
        x, y, area, *_ = points[point]
        _, _, zz, _, xz, yz = tensor
        parts.append((area * zz, area * (y - oy) * zz, area * (x - ox) * zz,
                      area * ((x - ox) * yz - (y - oy) * xz), area * xz, area * yz))
    return tuple(map(fsum, zip(*parts, strict=True)))


def check_process(root, reference, utility):
    """Сверяет процесс компиляции, источник макроса и закрытие своего Excel."""
    native = root / 'Native'
    compiler = utility['read'](root / 'CodeUpdate.json')
    owner = utility['read'](native / 'MVTGaussMixed.txt.Ownership.json')
    closure = utility['read'](native / 'MVTGaussMixed.txt.ProcessClosure.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256'] == reference
    assert compiler['WorkbookSHA256'] == owner['SourceSHA256']
    assert set(compiler['Modules']) == {'CCoupledConcreteResponse', 'CCoupledElasticState',
                                       'CCoupledSectionQuadrature', 'modTestMVT2GaussSpan'}
    assert utility['read'](root / 'CompileClosure.json')['State'] == 'Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    identity = closure['Closure']['Identity']
    assert identity['Valid'] and identity['PID'] == owner['PID'] and identity['Ticks'] == int(owner['StartTicksUTC'])
    assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['ChildExitCode'] == 0
    assert closure['Closure']['FinalState']['State'] == 'Absent'
    log = (native / 'MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log and 'RUNTIME ERROR:' not in log
    assert f"TEST_EXCEL_PROCESS: id={owner['PID']}; startTicks={owner['StartTicksUTC']}" in log
    return owner['PID'], log


def read_history(repo, root, utility, prep):
    """Сравнивает историю нагружения, геометрию и данные ASD с архивами."""
    evidence = repo / 'docs/regression/Coupled6D'
    parser, asd = {'__name__': '__pinned__'}, {'__name__': '__pinned__'}
    with utility['pinned'](evidence, REFERENCE, REFERENCE_SHA) as archive:
        exec(compile(archive.read('Verify-NativePublicationCut.py'), REFERENCE, 'exec'), parser)
        frames = parser['read_tensor_frames'](archive.read('Native/MVTGaussMixed.Tensor.csv'), 45)
        operators = parser['read_operators'](archive.read('Native/Operators.csv'))
        geometry = [row for row in archive.read('Native/MVTGaussMixed.csv').decode('cp1251').splitlines()
                    if row.startswith(('MVT_GEOM;', 'MVT_POINT;'))]
    with utility['pinned'](evidence, ASD, ASD_SHA) as archive:
        exec(compile(archive.read('Check-Cut396Material.py'), ASD, 'exec'), asd)
    _, external, _, _, _, _ = asd['load'](repo)
    native_operators = parser['read_operators']((root / 'Native/Operators.csv').read_bytes())
    assert all(native_operators[key] == operators[key] for key in 'GLBSR')
    wire = [row.split(';') for row in (root / 'Replay.Fields.csv').read_text('ascii').splitlines()]
    assert len(wire) == 22 and [row[0] for row in wire] == list(operators['F'])
    for phase, q, t, *field in wire:
        assert tuple(map(float, field)) == operators['F'][phase]
        assert (float(t), float(q)) == frames[phase][:2]
    rows = (root / 'Native/MVTGaussMixed.csv').read_text('cp1251').splitlines()
    assert [row for row in rows if row.startswith(('MVT_GEOM;', 'MVT_POINT;'))] == geometry
    frame, *points = [row.split(';') for row in geometry]
    assert frame[1:4] == ['25', '45', '60']
    assert [int(row[1]) for row in points] == list(range(1, 46))
    assert all(f'MVT2_DILATION;{angle};22;0' in rows for angle in prep['dilation_max_degrees'])
    finish, = [row.split(';') for row in rows if row.startswith('CASE_FINISHED;')]
    assert finish[1:3] == ['MVTGaussMixed', 'True'] and 0. < float(finish[3]) < 165.
    mesh = tuple(map(float, frame[4:])), {int(row[1]): tuple(map(float, row[2:])) for row in points}
    return frames, mesh, [row[0] for row in wire], external['stress'], asd['elastic'], float(finish[3])


def verify(repo, root):
    utility = {'__name__': '__pinned__'}
    with utility_archive(repo) as archive:
        exec(compile(archive.read('Verify-NativeMaterialHistory.py'), MODEL, 'exec'), utility)
        source_with_test_method = archive.read(SOURCE_PATH)
    assert utility['digest']((repo / PAPER_PATH).read_bytes()) == PAPER_SHA
    assert (root / SOURCE_PATH).read_bytes() == source_with_test_method
    prep = utility['read'](root / 'Preparation.json')
    assert prep['material_base_sha256'] == utility['SOURCE_SHA']
    assert prep['dilation_max_degrees'] == list(ANGLES)
    for path in (SOURCE_PATH, 'Replay.Fields.csv', 'Run-Native.ps1', 'tests/modTestMVT2GaussSpan.bas'):
        assert utility['digest']((root / path).read_bytes()) == prep['inputs'][path]
    pid, log = check_process(root, prep['source_book_sha256'], utility)
    assert prep['source_book_sha256'] == utility['BOOK']
    assert all(f'MVT2_DILATION;{angle};22;0' in log for angle in ANGLES)
    frames, mesh, history, asd, elastic, seconds = read_history(repo, root, utility, prep)
    entries = {}
    for row in (root / 'Native/Dilation.csv').read_text('ascii').splitlines():
        kind, angle, stage, point, *data = row.split(';')
        key = int(angle), int(stage), int(point)
        assert kind == 'D' and len(data) == 26 and key not in entries
        entries[key] = tuple(map(float, data))
    assert list(entries) == [(a, i, p) for a in ANGLES for i in range(1,23) for p in POINTS]

    alternative = {}
    max_base_error, max_strain_error, max_recovery_error = 0., 0., 0.
    for angle in ANGLES:
        by_stage = {}
        for i, phase in enumerate(history, 1):
            point_metrics, tensors = {}, []
            for point in POINTS:
                data = entries[angle, i, point]
                ref = frames[phase][2][point]
                prior = entries.get((angle, i-1, point))
                strain_error = max(abs(a-b) for a,b in zip(data[:6], ref[:6], strict=True))
                max_strain_error = max(max_strain_error, strain_error)
                if angle == 32:
                    max_base_error = max(max_base_error, *(abs(a-b) for a,b in zip(data[6:12], ref[6:], strict=True)))
                metrics = utility['accepted_wire']({point: (*ref[:6], *data[6:12])}, point, data, elastic, prior)
                max_recovery_error = max(max_recovery_error, metrics['nominal_recovery_error_MPa'])
                if point in (11,14,15):
                    point_metrics[point] = metrics
                tensors.append(data[6:12])
            actions = integrate(mesh, tensors)
            variants = {}
            for name, values in asd.items():
                external = values[i-1][0][:25]
                compare = integrate(mesh, external)
                rms = fmean((u-v)**2 for a,b in zip(tensors, external, strict=True) for u,v in zip(a,b,strict=True))**.5
                variants[name] = {'solid_concrete_actions_N_Nmm': compare, 'component_rms_MPa': rms}
            by_stage[phase] = {'Qy_N': frames[phase][1], 'solid_concrete_actions_N_Nmm': actions,
                               'points': point_metrics, 'OpenSees': variants}
        alternative[angle] = by_stage
    assert max_base_error < 5e-12 and max_strain_error < 3e-16
    return {'angle_models': alternative, 'entries': len(entries), 'macro_seconds': seconds,
            'excel_closed_pid': pid, 'max_base_stress_error_MPa': max_base_error,
            'max_prescribed_strain_error': max_strain_error, 'max_nominal_reconstruction_error_MPa': max_recovery_error,
            'equilibrium_solved_for_alternative_angles': False}


def utility_archive(repo):
    """Читает неизменённую проверку принятой истории §558."""
    from hashlib import sha256
    from zipfile import ZipFile

    path = repo / 'docs/regression/Coupled6D' / MODEL
    assert sha256(path.read_bytes()).hexdigest().upper() == MODEL_SHA
    return ZipFile(path)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    result = verify(args.repo.resolve(), args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(f"MVT2 DILATION SWEEP OFFLINE PASS {result['entries']}")
