"""Seal paired point-level native evidence after both native runs exist."""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import json
import runpy

H=Path(__file__).resolve().parent
ARMS=('A','D')
OUTS=('Compile.log','CompileClosure.json','Preflight.ndjson','KaniV4.txt','KaniV4.txt.Ownership.json',
      'KaniV4.txt.ProcessClosure.json','KaniV4.txt.RunnerCleanup.json','KaniV4.txt.memory.json','KaniV4.txt.stdout.log',
      'KaniV4.txt.stderr.log','KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv','KaniElasticTangent.csv')


def sha(x):
    return sha256(x.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def pack(repo):
    # The standalone D verdict is written only after the native owner has exited.
    assert (H/'Verification-PointsD.json').is_file()
    prep=read(H/'Preparation.json')
    files={path for path in prep['frozen'] if '/tools/' not in path and not path.endswith('.xlsm')}
    for arm in ARMS:
        files.add(f'{arm}/docs/regression/CodeUpdate.json')
        files.update(f'{arm}/Native/{path}' for path in OUTS)
    files.update(('Preparation.json','Verification-PointsA.json','Verification-PointsD.json',
                  'Verification-Points.json','Replay-Points.py','Pack-Points.py','Portable-README.md'))
    assert all((H/path).is_file() for path in files if path!='Verification-Points.json')
    replay=runpy.run_path(H/'Verify.py')['verify'](repo,'Both','Points')
    authority=read(H/'FailedD/Verification-PointsA.Original.json')['variants']['A']
    assert authority==replay['variants']['A']==read(H/'Verification-PointsA.json')['variants']['A']
    assert replay['variants']['D']==read(H/'Verification-PointsD.json')['variants']['D']
    assert len(replay['stockToCandidate'])==6
    manifest={'schema':'KaniH45ElasticDamageNative/v1','sourceGit':prep['sourceGit'],'bookSHA256':prep['bookSHA256'],
              'candidateMaterialSHA256':prep['candidateMaterialSHA256'],
              'compiledPrivateBookSHA256':{arm:read(H/arm/'docs/regression/CodeUpdate.json')['WorkbookSHA256'] for arm in ARMS},
              'files':{name:sha(H/name) for name in sorted(files)}}
    root=H/'Portable'
    root.mkdir(exist_ok=True)
    archive=root/'KaniH45ElasticDamageNativePortable.zip'
    fixed=(2026,11,16,0,0,0)
    with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
        for name in sorted(files):
            z.writestr(ZipInfo(name,fixed),(H/name).read_bytes(),compress_type=ZIP_DEFLATED,compresslevel=9)
        m=(json.dumps(manifest,indent=2)+'\n').encode('utf8')
        z.writestr(ZipInfo('Manifest.json',fixed),m,compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==files|{'Manifest.json'}
    print(archive,sha(archive),archive.stat().st_size)
    return archive


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    pack(a.repo_root.resolve())
