"""Replay the paired H45 points without an installed or private Excel workbook."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import math
import runpy

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')
BOOK=P['BOOK']
ARMS=('A','D')


def read(f):
    return json.loads(f.read_text(encoding='utf-8-sig'))


def digest(b):
    return sha256(b.read_bytes() if isinstance(b,Path) else b).hexdigest().upper()


def validate_preparation(repo):
    files=read(H/'Manifest.json')
    assert files['schema']=='KaniH45ElasticDamageNative/v1'
    assert all(digest(H/path)==sha for path,sha in files['files'].items())
    receipt=read(H/'Preparation.json')
    assert receipt['sourceGit']==P['git'](repo,'rev-parse',P['TIP']).decode().strip()==files['sourceGit']
    assert receipt['bookSHA256']==P['BOOK_SHA']==digest(P['blob'](repo,BOOK))==files['bookSHA256']
    assert receipt['candidateMaterialSHA256']==P['DAMAGE_SHA']==files['candidateMaterialSHA256']
    assert receipt['stockMaterialGitBlobSHA256']==P['STOCK_SHA']
    for item,sha in receipt['production'].items():
        assert digest(P['blob'](repo,item))==sha
    repo_archives={P['ROW']:P['ROW_SHA'],P['ALT']:P['ALT_SHA'],**receipt['supportArchives']}
    for n,sha in repo_archives.items():
        assert digest(repo/P['ART']/n)==sha
    for arm in ARMS:
        assert receipt['frozen'][f'{arm}/{BOOK}']==receipt['bookSHA256']
        code=read(H/arm/'docs/regression/CodeUpdate.json')
        owner=read(H/arm/'Native/KaniV4.txt.Ownership.json')
        assert code['WorkbookSHA256']==owner['SourceSHA256']==files['compiledPrivateBookSHA256'][arm]
    for k,sha in receipt['frozen'].items():
        if k in files['files']:
            assert files['files'][k]==sha
        elif k.endswith('/'+BOOK):
            assert sha==receipt['bookSHA256']
        else:
            arm, tool=k.split('/',1)
            assert arm in ARMS and tool.startswith('tools/')
            exact=P['blob'](repo,tool)
            lf=exact.replace(b'\r\n',b'\n')
            assert sha in {digest(exact),digest(lf),digest(lf.replace(b'\n',b'\r\n'))},k
    file=P['CONCRETE']
    assert not (H/'A'/file).exists()
    assert digest(H/'D'/file)==receipt['candidateMaterialSHA256']
    assert P['retry_candidate_bytes']((H/'FailedD'/file).read_bytes())==(H/'D'/file).read_bytes()
    for f in (P['MACRO'],*P['HISTORIES'],'KaniElasticTangentInputs.csv'):
        assert (H/'A'/f).read_bytes()==(H/'D'/f).read_bytes()
    failure=read(H/'FailedD/RetryReceipt.json')
    assert failure==receipt['retry'] and failure['observedOfficeState']=='Absent' and not failure['nativeMacroStarted']
    bad=(H/'FailedD/Native/Compile.log').read_text(encoding='utf-8-sig')
    assert f"id={failure['failedOwnedPID']}; utcStartTicks={failure['failedOwnerStartTicksUTC']}" in bad
    assert 'CCoupledConcreteResponse' in bad and 'Dim scale As Double' in bad
    return receipt


def once(txt,old,new):
    assert txt.count(old)==1,old
    return txt.replace(old,new)


def adapt_private_receipt(v):
    old="    assert book['WorkbookSHA256'] == P['sha'](H / P['draft']) == own['SourceSHA256']"
    new="""    assert book['WorkbookSHA256'] == own['SourceSHA256']
    if (H / P['draft']).exists():
        assert book['WorkbookSHA256'] == P['sha'](H / P['draft'])"""
    return once(v,old,new)


def compare(a,b,where='paired'):
    if isinstance(a,dict):
        assert a.keys()==b.keys(),where
        for k,v in a.items():
            compare(v,b[k],where+'.'+k)
    elif isinstance(a,list):
        assert len(a)==len(b),where
        for i,(left,right) in enumerate(zip(a,b)):
            compare(left,right,f'{where}[{i}]')
    elif isinstance(a,float):
        assert math.isclose(a,b,abs_tol=2e-12,rel_tol=2e-10),(where,a,b)
    else:
        assert a==b,(where,a,b)


def replay(repo):
    prep=validate_preparation(repo)
    original=H/'Verify.py'
    text=original.read_text(encoding='utf-8-sig')
    marker="    n={'__name__':'private_elastic_stage_verifier','__file__':str(src)}"
    text=once(text,marker,"    original=adapt_private_receipt(original)\n"+marker)
    text=once(text,"f'Verification-{scope}{suffix}.json'","f'Replay-Verification-{scope}{suffix}.json'")
    v={'__name__':'portable_paired_elastic','__file__':str(original),'adapt_private_receipt':adapt_private_receipt}
    exec(compile(text,str(original),'exec'),v)
    v['P']['check']=lambda _:prep
    replayed=v['verify'](repo,'Both','Points')
    compare(read(H/'Verification-Points.json'),replayed)
    stock=read(H/'FailedD/Verification-PointsA.Original.json')['variants']['A']
    compare(stock,replayed['variants']['A'],'firstStock')
    print('DETACHED_POINTS_PASS',digest(H/'Replay-Verification-Points.json'),len(replayed['stockToCandidate']))
    return replayed


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    args=p.parse_args()
    replay(args.repo_root.resolve())
