"""Check private source custody, exact H45 and the point-level elastic tangent comparison."""
from argparse import ArgumentParser
from io import BytesIO
from pathlib import Path
import json
import runpy

import numpy as np

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')
STATES=('Base45','End45')
ORACLE={'Points':'TOTAL_KANI_ELASTIC_POINTS: passed=6; failed=0',
        'Section':'TOTAL_KANI_V4_STAGE38: passed=1; failed=0'}


def cached_verifier(arm,scope):
    src=H/'Verify-Alt.py'
    original=src.read_text(encoding='utf-8-sig')
    substitutions={
        "assert book['Modules'] == ['modTestKaniStage38']": f"assert sorted(book['Modules']) == {sorted(P['MODULES'][arm])!r}",
        'TOTAL_KANI_V4_STAGE38: passed=1; failed=0':ORACLE[scope],
    }
    for a,b in substitutions.items():
        assert original.count(a)==1,a
        original=original.replace(a,b)
    n={'__name__':'private_elastic_stage_verifier','__file__':str(src)}
    exec(compile(original,str(src),'exec'),n)
    n['H']=H/arm
    n['Z']=n['H']/'Native'
    n['P']['check']=P['check']
    return n


def force_and_controls(q,sigma,history,build,measure):
    geo=history['geometry']
    h,sh,g,phys,area,scale=build(geo,float(history['length']))
    field=q[2:]
    lam,alpha=q[:2]
    stress=sigma[:,:,6:]
    strain=h@field[:79]+np.array([-.001,0.,.001])[:,None,None]*(h[:,:,:4]@field[79:83])[None]
    delta=(stress[2]-stress[0])/.002
    weak=np.einsum('nij,ni,n->j',h,stress[1],area)+g.T@field[83:]
    weak[4:]-=np.einsum('nk,na,n->ka',sh,delta[:,[4,5,2]],area).ravel()
    long=np.einsum('nij,ni,n->j',h[:,:,:4],delta,area)
    long[1]-=1e5*lam/scale[0]
    physical=np.einsum('nij,nj,n->i',phys,stress[1],geo[:,2])
    force=np.r_[weak,long,(physical-np.r_[np.zeros(5),1e5*lam])/scale]
    controls=25600*np.r_[g@field[:79],measure@field-alpha]
    assert force.size==89 and controls.size==5
    assert np.max(abs(strain-sigma[:,:,:6]))<2e-12
    return force,controls,physical


def points(repo,arm,prep):
    n=cached_verifier(arm,'Points')
    n['FINAL']=STATES
    closure=n['verify_closure'](prep)
    root=H/arm
    q={}
    summary={}
    checks={}
    ds={'K59C_STATE':(summary,99),'K59C_VECTOR':(q,89),'CHECK':(checks,4)}
    for k,label,*row in n['csv_rows'](root/'Native/KaniV4Trace.csv'):
        dst,size=ds[k]
        assert len(row)==size and label in STATES and label not in dst
        dst[label]=np.array(row,float)
    assert set(q)==set(summary)==set(checks)==set(STATES)
    data,branch,yielded,energy=n['read_material'](q)
    for channel in (q,summary,data,branch,yielded,energy,checks):
        assert np.array_equal(channel['Base45'],channel['End45'])
    history,valid,build,_=n['archived_inputs'](repo)
    i=list(history['names']).index('Committed45')
    x=q['Base45']
    assert x[0]==history['fields'][i,0] and np.array_equal(x[2:],history['fields'][i,2:])
    assert np.array_equal(data['Base45'],history['stations'][history['station_index'][i]])
    assert np.array_equal(energy['Base45'],np.array(valid['energiesByStation_minus0plus']['Committed45']))
    with P['ZipFile'](repo/P['ART']/P['ROW']) as old:
        native_prior=json.loads(old.read('AlternateVerification.json'))
    native_base=native_prior['comparison89PlusFive']['Base45']['targetAlpha']
    assert abs(x[1]-native_base)<2e-16
    measure=np.array((root/'H45DiscriminatingControl.csv').read_text(encoding='ascii').strip().split(';')[5:],float)
    force,control,physical=force_and_controls(x,data['Base45'],history,build,measure)
    native=summary['Base45']
    maximum=float(max(max(abs(force)),max(abs(control))))
    assert maximum<=prep['originalTauMPa']==native[3] and abs(maximum-native[2])<2e-10 and native[5]==1
    assert np.max(abs(force[:83]-native[12:95]))<2e-10
    assert np.max(abs(control[:4]/25600-native[95:]))<2e-10
    assert abs(control[-1]-native[4])<2e-10
    oracle=runpy.run_path(H/'Verify-ElasticNative.py')
    raw=oracle['read'](root/'Native/KaniElasticTangent.csv')
    for label,records in raw.items():
        if label.startswith('Probe'):
            assert records[0]==0 and records[2]==1 and records[3]<0
        else:
            assert records[2]==0
    report={'exactH45':True,'unchangedHistoryAfterStations':True,'norm89Plus5MPa':maximum,
            'originalToleranceMPa':native[3],'forceRowsMPa':force.tolist(),'controlRowsMPa':control.tolist(),
            'actualForces_N_Nmm':physical.tolist(),'closure':closure,
            'stationCSV_SHA256':P['sha'](root/'Native/KaniElasticTangent.csv')}
    return report,raw


def verify(repo,variant,scope):
    prep=P['check'](repo)
    arms=('A','D') if variant=='Both' else (variant,)
    results={}
    readings={}
    for arm in arms:
        if scope=='Points':
            results[arm],readings[arm]=points(repo,arm,prep)
        else:
            results[arm]=cached_verifier(arm,'Section')['verify'](repo)
    record={'bookSHA256':prep['bookSHA256'],'candidateMaterialSHA256':prep['candidateMaterialSHA256'],
            'scope':scope,'variants':results}
    if scope=='Points' and len(arms)==2:
        oracle=runpy.run_path(H/'Verify-ElasticNative.py')
        record['stockToCandidate']=oracle['verify'](readings['A'],readings['D'])
        for field in ('forceRowsMPa','controlRowsMPa','actualForces_N_Nmm'):
            assert results['A'][field]==results['D'][field]
    suffix='' if variant=='Both' else variant
    out=H/f'Verification-{scope}{suffix}.json'
    out.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print('PASS',out,P['sha'](out))
    return record


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    p.add_argument('--variant',choices=('A','D','Both'),default='Both')
    p.add_argument('--scope',choices=('Points','Section'),default='Points')
    a=p.parse_args()
    verify(a.repo_root.resolve(),a.variant,a.scope)
