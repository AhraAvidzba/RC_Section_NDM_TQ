"""Freeze executable stock and elastic-damage test arms without Office."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import re
import subprocess

H=Path(__file__).resolve().parent
TIP='77043b5'
BOOK='workbook/output/RC_Section_NDM.xlsm'
DRAFT='docs/regression/Diagnostic.xlsm'
MACRO='tests/modTestKaniStage38.bas'
CONCRETE='src/Materials/CCoupledConcreteResponse.cls'
BOOK_SHA='D0CB47951B64A65DD5FE84A1F823DBE395C8BF027C2833813EDAF0FF6A06BBE6'
STOCK_SHA='A66098447E4A7203D5E5088C609976228C728F78E671E0AB7AC06DB3D0ED8A03'
ORIGINAL_DAMAGE_SHA='0D7F2D2379638841A4A6A75675635BE329968B3D60AF8FE8FDE6BD2F65F39918'
DAMAGE_SHA='A8C4F9664F300A344C6047553D55FD9E589F3BB0ECEA3371BE1EAA4EDC22837B'
CANDIDATE_SHA='B97C5CE8F7488402C98A7A8E7F609FBC07C0E39A874CC2F288C9776B9A4F73B8'
ART='docs/regression/Coupled6D'
ROW='KaniH45Row81DirectionPortable.zip'
ROW_SHA='4B65725C0977E6855720BFBD0F9CA7D5D3FCF0AD3F4C1C0A8FA68F73DECDA701'
ALT='KaniH45AlternateControlPortable.zip'
ALT_SHA='4A9CADBD73726D133E99B5EA1D58F1DB8DB574C45BC189470F8EEC856C911BD4'
MODULES={'A':['modTestKaniStage38'],'D':['CCoupledConcreteResponse','modTestKaniStage38']}
COMPONENTS=(CONCRETE,'src/Solver/CCoupledNewtonSolver.cls','src/Solver/CCoupledElasticState.cls',
            'src/Materials/CCoupledReinforcedResponse.cls')
HISTORIES=('KaniV4Input.csv','KaniGaugeInput.csv','H45DiscriminatingControl.csv','DiscriminatingH45Measurement.json')
COMMON=('IndependentElasticTangent.json','Verify-ElasticNative.py','Verify-Alt.py','Prepare-Alt.py','README.md','Prepare.py','Run.ps1','Verify.py')


def sha(x):
    return sha256(x.read_bytes() if isinstance(x,Path) else x).hexdigest().upper()


def git(repo,*args):
    return subprocess.check_output(['git','-C',str(repo),*args])


def blob(repo,p):
    return git(repo,'cat-file','blob',f'{TIP}:{p}')


def normalize(data):
    return data.replace(b'\r\n',b'\n')


def write(p,b):
    p.parent.mkdir(exist_ok=True,parents=True)
    p.write_bytes(b)
    return sha(b)


def check(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    receipt=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert receipt['sourceGit']==git(repo,'rev-parse',TIP).decode().strip()
    assert receipt['bookSHA256']==BOOK_SHA==sha(blob(repo,BOOK))==sha(repo/BOOK)
    assert receipt['historicalWitnessSHA256']==ROW_SHA==sha(repo/ART/ROW)
    assert receipt['sectionDonorSHA256']==ALT_SHA==sha(repo/ART/ALT)
    assert receipt['variants']==MODULES and receipt['candidateMaterialSHA256']==DAMAGE_SHA
    for k,value in receipt['production'].items():
        assert sha(blob(repo,k))==value and normalize(blob(repo,k))==normalize((repo/k).read_bytes())
    assert sha(blob(repo,CONCRETE))==STOCK_SHA
    assert all(sha(repo/ART/n)==d for n,d in receipt['supportArchives'].items())
    assert all(sha(H/k)==d for k,d in receipt['frozen'].items())
    for arm,modules in MODULES.items():
        p=H/arm
        assert all((p/d).is_dir() and not (p/d).is_symlink() for d in ('src','tests','Native','Temp'))
        files={f.stem for d in ('src','tests') for f in (p/d).rglob('*') if f.is_file()}
        assert files==set(modules)
        assert sha(p/BOOK)==BOOK_SHA
    assert not (H/'A'/CONCRETE).exists() and sha(H/'D'/CONCRETE)==DAMAGE_SHA
    for f in (MACRO,*HISTORIES,'KaniElasticTangentInputs.csv'):
        assert sha(H/'A'/f)==sha(H/'D'/f)
    return receipt


def retry_candidate_bytes(original):
    start=original.index(b'Private Function TryElasticDamageTangent(')
    end=original.index(b'End Function',start)
    before=original[start:end]
    after,n=re.subn(rb'\bscale\b',b'stressScale',before)
    assert n==13 and re.sub(rb'\bstressScale\b',b'scale',after)==before
    return original[:start]+after+original[end:]


def stage(repo):
    assert git(repo,'rev-parse','HEAD')==git(repo,'rev-parse',TIP)
    assert not (H/'Preparation.json').exists()
    assert not any((H/k).exists() for k in MODULES)
    assert H.is_relative_to((repo/'tmp').resolve())
    stock=(repo/BOOK).read_bytes()
    assert sha(stock)==BOOK_SHA and stock==blob(repo,BOOK)
    assert sha(repo/ART/ROW)==ROW_SHA and sha(repo/ART/ALT)==ALT_SHA
    proof=repo/'tmp/kaned/KaniElasticDamageCandidatePortable.zip'
    assert sha(proof)==CANDIDATE_SHA
    frozen={}
    with ZipFile(repo/ART/ROW) as za,ZipFile(repo/ART/ALT) as zb,ZipFile(proof) as p:
        hmanifest=json.loads(za.read('Manifest.json'))['files']
        wmanifest=json.loads(zb.read('Manifest.json'))['files']
        pmanifest=json.loads(p.read('Manifest.json'))['files']
        # Use the exact material history of the archived rejected Newton point.
        history={n:za.read(n) for n in HISTORIES}
        assert all(sha(v)==hmanifest[n] and v==zb.read(n) for n,v in history.items())
        donor=zb.read(MACRO)
        assert sha(donor)==wmanifest[MACRO]
        for name in ('Verify-Alt.py','Prepare-Alt.py'):
            b=zb.read(name)
            assert sha(b)==wmanifest[name]
            frozen[name]=write(H/name,b)
        for name in ('IndependentElasticTangent.json','Verify-ElasticNative.py'):
            b=p.read(name)
            assert sha(b)==pmanifest[name]
            frozen[name]=write(H/name,b)
        fixture=p.read('KaniElasticTangentInputs.csv')
        helper=p.read('KaniElasticTangentProbe.bas.txt')
        candidate=p.read(CONCRETE)
        for name,b in (('KaniElasticTangentInputs.csv',fixture),('KaniElasticTangentProbe.bas.txt',helper),(CONCRETE,candidate)):
            assert sha(b)==pmanifest[name]
        assert sha(candidate)==ORIGINAL_DAMAGE_SHA
        candidate=retry_candidate_bytes(candidate)
        assert sha(candidate)==DAMAGE_SHA
        txt=donor.decode('utf-8-sig').replace('\r\n','\n')
        start=txt.index('    Dim history As New Collection,')
        end=txt.index('    Dim projectionX() As Double,',start)
        setup=txt[start:end]
        points=(H/'PointsEntry.bas.txt').read_text(encoding='utf-8-sig')
        assert points.count('@@EXACT_H45_SHARED_MODULE_SETUP@@')==1
        points=points.replace('@@EXACT_H45_SHARED_MODULE_SETUP@@\n',setup)
        complete=(txt.rstrip()+'\n\n'+points.rstrip()+'\n\n'+helper.decode('utf-8-sig').rstrip()+'\n').replace('\n','\r\n').encode('utf8')
        assert len([l for l in complete.splitlines() if len(l)>900])==0
        tool_names=[n for n in wmanifest if n.startswith('tools/') and not n.endswith('Update-IsolatedOptimizerCode.ps1')]
        tools={n:(repo/n).read_bytes() for n in tool_names}
        assert 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' in tools
        assert 'tools/build_workbook/Run-Audit03Watchdog.ps1' in tools
        for n,b in tools.items():
            assert normalize(blob(repo,n))==normalize(b),n
        support=json.loads(zb.read('Preparation.json'))['inputZIP_SHA256']
    for arm in MODULES:
        loc=H/arm
        for folder in ('src','tests','Native','Temp','docs/regression'):
            (loc/folder).mkdir(parents=True,exist_ok=True)
        files={**history,**tools,BOOK:stock,MACRO:complete,'KaniElasticTangentInputs.csv':fixture}
        if arm=='D':
            files[CONCRETE]=candidate
        for name,b in files.items():
            frozen[f'{arm}/{name}']=write(loc/name,b)
        write(loc/DRAFT,stock)
    for name in COMMON+('PointsEntry.bas.txt',):
        frozen[name]=sha(H/name)
    receipt={'sourceGit':git(repo,'rev-parse',TIP).decode().strip(),'bookSHA256':BOOK_SHA,'stockMaterialGitBlobSHA256':STOCK_SHA,
             'candidateMaterialSHA256':DAMAGE_SHA,'candidateArchiveSHA256':CANDIDATE_SHA,
             'historicalWitnessSHA256':ROW_SHA,'sectionDonorSHA256':ALT_SHA,'variants':MODULES,
             'pointTimeoutSeconds':100,'sectionTimeoutSeconds':180,'originalTauMPa':5.59190995944018e-7,
             'supportArchives':support,'production':{n:sha(blob(repo,n)) for n in COMPONENTS},
             'frozen':dict(sorted(frozen.items()))}
    write(H/'Preparation.json',(json.dumps(receipt,indent=2)+'\n').encode())
    return check(repo)


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    p.add_argument('--check',action='store_true')
    a=p.parse_args()
    (check if a.check else stage)(a.repo_root.resolve())
    print('SEAL_PASS',sha(H/'Preparation.json'))
