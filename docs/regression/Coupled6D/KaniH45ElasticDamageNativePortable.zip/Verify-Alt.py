"""Independently rebuild the alternate-control experiment from its native output."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import csv
import json
import re
import runpy

import numpy as np

H = Path(__file__).resolve().parent
Z = H / 'Native'
P = runpy.run_path(H / 'Prepare-Alt.py')
FINAL = ('Base45', 'End45', 'Restore45')
FORCE = 1e5
MODULUS = 25600.0


def peak(values):
    return float(np.max(np.abs(values)))


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def csv_rows(path):
    with path.open(encoding='cp1251', newline='') as stream:
        yield from csv.reader(stream, delimiter=';')


def verify_closure(prep):
    closure = read_json(Z / 'KaniV4.txt.ProcessClosure.json')
    own = read_json(Z / 'KaniV4.txt.Ownership.json')
    comp = read_json(Z / 'CompileClosure.json')
    report = (Z / 'KaniV4.txt').read_text(encoding='utf-8-sig')
    book = read_json(H / 'docs/regression/CodeUpdate.json')
    end = closure['Closure']['FinalState']
    assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
    assert closure['Closure']['Passed'] and end['State'] == comp['State'] == 'Absent'
    assert not closure['Closure']['OrdinaryPathKilledAnything'] and own['VerifiedNewOwner'] and own['BeforeWorkbookOpen']
    assert end['PID'] == own['PID'] and end['StartTicksUTC'] == own['StartTicksUTC']
    assert book['Compiled'] and not book['ProductionChanged'] and book['ProductionSHA256'] == prep['bookSHA256']
    assert book['WorkbookSHA256'] == P['sha'](H / P['draft']) == own['SourceSHA256']
    assert book['Modules'] == ['modTestKaniStage38']
    compile_text = (Z / 'Compile.log').read_text(encoding='utf-8-sig')
    assert re.findall(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$', compile_text, re.M) == [(str(comp['PID']), comp['StartTicksUTC'])]
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    pre = [json.loads(x) for x in (Z / 'Preflight.ndjson').read_text(encoding='utf-8-sig').splitlines()]
    assert [p['phase'] for p in pre] == ['PreCompile', 'PreNative']
    assert all(p['RAMMiB'] >= 6500 and p['FreeCommitGiB'] >= 8 and p['FreeCMiB'] >= 80 for p in pre)
    assert all(e['ProtectedUser'] for p in pre for e in p['Excel'])
    assert all(p['PID'] not in {e['PID'] for x in pre for e in x['Excel']} for p in (comp, end))
    return {'compile': comp, 'native': end}


def read_trace():
    groups = {}
    for tag, label, *row in csv_rows(Z / 'KaniV4Trace.csv'):
        expected = {'K59C_VECTOR': 89, 'K59C_STATE': 99, 'PROJECTION': 87, 'CHECK': 4,
                    'MEASUREMENT': 4, 'STATUS': 3, 'DIAGNOSTIC': 1, 'RIGHT': 4, 'ADJOINT': 2}[tag]
        dest = groups.setdefault(tag, {})
        assert label not in dest and len(row) == expected
        dest[label] = row[0] if tag == 'DIAGNOSTIC' else np.array(row, float)
    q, state, check = (groups[k] for k in ('K59C_VECTOR', 'K59C_STATE', 'CHECK'))
    stat = groups['STATUS']['Right']
    assert list(groups['STATUS']) == ['Right'] and set(groups['DIAGNOSTIC']) == {'Zero45','Right'}
    assert groups['DIAGNOSTIC']['Zero45'].split('|',1)[0]=='Итерации: 0'
    assert stat[0] in (0,1) and np.all(stat == stat.astype(int))
    labels = {*FINAL, 'Zero45'}
    if stat[0]:
        labels.add('Right')
        assert list(groups['RIGHT']) == ['Values']
    else:
        assert 'RIGHT' not in groups
    assert set(q) == set(state) == set(check) == labels
    assert set(groups['PROJECTION']) == {'Mean', 'Alternative'} and list(groups['MEASUREMENT']) == ['Control']
    assert set(groups['ADJOINT']) == set(labels) - set(FINAL)
    assert groups['ADJOINT']['Zero45'][0] == 1 and groups['ADJOINT']['Zero45'][1] > 0
    return groups


def read_material(labels):
    t = {n: np.full((3,184,12), np.nan) for n in labels}
    b = {n: np.full((3,184,3), -999) for n in labels}
    f = {n: np.full((3,184), np.nan) for n in labels if n != 'Zero45'}
    e = {n: np.full((3,184,2), np.nan) for n in FINAL}
    for tag, label, pt, side, *row in csv_rows(Z / 'KaniV4Stations.csv'):
        i, j = int(side) + 1, int(pt) - 1
        assert tag == 'K59C_STATION' and 0 <= i < 3 and 0 <= j < 184 and len(row) == 12
        assert np.isnan(t[label][i,j]).all()
        t[label][i,j] = np.array(row, float)
    for tag, label, pt, side, *row in csv_rows(Z / 'KaniV4Tangents.csv'):
        i, j = int(side) + 1, int(pt) - 1
        assert 0 <= i < 3 and 0 <= j < 184
        if tag == 'BRANCH':
            assert len(row) == 3 and (b[label][i,j] == -999).all()
            b[label][i,j] = np.array(row, int)
        elif tag == 'YIELD':
            assert len(row) == 1 and np.isnan(f[label][i,j])
            f[label][i,j] = float(row[0])
        else:
            assert tag == 'ENERGY' and len(row) == 2 and np.isnan(e[label][i,j]).all()
            e[label][i,j] = np.array(row, float)
    assert all(np.isfinite(x).all() for x in [*t.values(), *f.values(), *e.values()])
    assert all((x != -999).all() for x in b.values())
    return t, b, f, e


def archived_inputs(repo):
    with P['open_art'](repo, 'KaniCommitNear48Portable.zip') as z:
        h = dict(np.load(BytesIO(z.read('MeasuredSamples.npz')), allow_pickle=False))
        receipt = json.loads(z.read('Commit48Verification.json'))
        src = z.read('Verify.py').decode('utf-8')
        ns = {}
        exec(compile(src[:src.index('ROOT=')], 'archived BuildOperators.py', 'exec'), ns)
        m = {k: np.full((88,88), np.nan) for k in ('H45Stock','H45Refined')}
        for tag, label, index, *row in csv.reader(z.read('KaniV4Tangents.csv').decode('ascii').splitlines(),delimiter=';'):
            if tag != 'MATRIX' or label not in m:
                continue
            i = int(index)-1
            assert 0 <= i < 88 and np.isnan(m[label][i]).all() and len(row) == 88
            m[label][i] = np.array(row,float)
        assert all(np.isfinite(x).all() for x in m.values())
    return h, receipt, ns['operators'], m


def matrix_uncertainties(mats, proj, lam, residual_floor):
    compares = {}
    unit = np.eye(88)[-1]
    for k, baseline in mats.items():
        m = baseline.copy()
        # Archive matrices already scale the four gauge reaction columns.
        m[-1,:87] = MODULUS*proj
        m[-1,-1] = 0.
        w = np.linalg.solve(m.T, unit)
        compares[k] = float(FORCE*(np.sum(np.abs(w))*residual_floor+2e-12*(1+abs(lam))))
    return compares


def indicators(tensor):
    v = tensor[:,:144,6:]
    mapping = [[0,3,4],[3,1,5],[4,5,2]]
    strain = tensor[:,:144,:6].copy()
    strain[:,:,3:] *= .5
    sigma = np.linalg.eigvalsh(v[:,:,mapping])
    epsilon = np.linalg.eigvalsh(strain[:,:,mapping])
    return {'directConcreteMinPrincipalStrain': float(epsilon[:,:,0].min()),
            'directConcreteMaxPrincipalStrain': float(epsilon[:,:,2].max()),
            'directConcreteMinPrincipalStress_MPa': float(sigma[:,:,0].min()),
            'directConcreteMaxPrincipalStress_MPa': float(sigma[:,:,2].max())}


def verify(repo):
    prep = P['check'](repo)
    closure = verify_closure(prep)
    groups = read_trace()
    q, summaries = groups['K59C_VECTOR'], groups['K59C_STATE']
    t, b, f, e = read_material(q)
    h, previous, build, mats = archived_inputs(repo)
    ids = {name: i for i, name in enumerate(h['names'])}
    hx = ids['Committed45']
    alt, old_proj = (groups['PROJECTION'][label] for label in ('Alternative','Mean'))
    plan = read_json(H/'DiscriminatingH45Measurement.json')
    a0, target, da, lam0 = groups['MEASUREMENT']['Control']
    native_base = q['Base45']
    control_cells = (H/'H45DiscriminatingControl.csv').read_text(encoding='ascii').strip().split(';')
    # VBA Str(Double) serializes fifteen significant digits. The source vector is sealed at full precision.
    assert np.allclose(alt, np.array(control_cells[5:],float),atol=0,rtol=5e-15) and not alt[-4:].any()
    assert np.array_equal(old_proj, h['projection'])
    assert np.array_equal(native_base[2:], h['fields'][hx, 2:]) and native_base[0] == h['fields'][hx,0] == lam0
    assert abs(old_proj@native_base[2:]-h['fields'][hx,1])<2e-16
    assert abs(a0-float(control_cells[2]))<2e-16 and abs(target-plan['targetAlpha'])<2e-16
    assert da == plan['incrementAlpha'] and abs(target-a0-da)<2e-16 and native_base[1] == a0
    assert np.array_equal(t['Base45'], h['stations'][h['station_index'][hx]])
    assert np.array_equal(e['Base45'], np.array(previous['energiesByStation_minus0plus']['Committed45']))
    for items in (q, t, b, e, f, summaries):
        assert all(np.array_equal(items[n], items['Base45']) for n in FINAL)
    for items in (q,t,b,summaries):
        assert np.array_equal(items['Zero45'], items['Base45'])

    geo = h['geometry']
    H0, sh, g, phys, area, scale = build(geo, float(h['length']))

    def section(label):
        lam, alpha = q[label][:2]
        field = q[label][2:]
        state = summaries[label]
        expected_eps = H0@field[:79] + np.array([-.001,0.,.001])[:,None,None]*(H0[:,:,:4]@field[79:83])[None]
        assert peak(expected_eps-t[label][:,:,:6])<2e-12
        stress = t[label][:,:,6:]
        gradient = (stress[2]-stress[0])/.002
        weak = np.einsum('nij,ni,n->j', H0, stress[1], area)
        weak[4:] -= np.einsum('nk,na,n->ka', sh, gradient[:,[4,5,2]], area).ravel()
        weak += g.T@field[83:]
        longitudinal = np.einsum('nij,ni,n->j', H0[:,:,:4], gradient, area)
        longitudinal[1] -= FORCE*lam/scale[0]
        weak = np.r_[weak, longitudinal]
        true_forces = np.einsum('nij,nj,n->i',phys,stress[1],geo[:,2])
        external = np.r_[np.zeros(5), FORCE*lam]
        rows = np.r_[weak,(true_forces-external)/scale]
        eq = MODULUS*np.r_[g@field[:79],alt@field-alpha]
        mismatch = max(peak(weak-state[12:95]),peak((true_forces-state[6:12])/scale),
                       peak(eq[:4]/MODULUS-state[95:99]),abs(eq[-1]-state[4]))
        tau = 5e-7 + 2e-8*abs(lam)*FORCE/scale[0]
        norm = max(peak(rows),abs(eq[-1]))
        assert len(rows) == 89 and len(eq) == 5 and state[5] == 1
        assert mismatch<2e-10 and abs(state[2]-norm)<2e-10
        assert np.array_equal(q[label][:2],state[1::-1]) and abs(state[3]-tau)<2e-20
        within = max(norm,peak(eq))<=tau
        assert within, (label,norm,peak(eq),tau)
        return {'lambda':float(lam),'targetAlpha':float(alpha),'actualAlpha':float(alt@field),
                'meanEngineeringShearYZ':float(old_proj@field),
                'sixWrenches_N_Nmm':true_forces.tolist(),'all89ForceRows_MPa':rows.tolist(),
                'allFiveControls_MPa':eq.tolist(),'maximum89PlusFive_MPa':max(norm,peak(eq)),
                'originalToleranceRule_MPa':float(tau),
                'satisfiesFrozenH45Tau':bool(max(norm,peak(eq))<=prep['originalTauMPa']),
                'withinOriginalToleranceRule':bool(within),'row81_MPa':float(rows[80]),
                'assemblyMismatch_MPa':mismatch,'Qy_N':float(lam*FORCE),
                'transverseConstitutiveIndicators':indicators(t[label])}

    states = {label:section(label) for label in q}
    base = states['Base45']
    u0 = float(groups['ADJOINT']['Zero45'][1]*FORCE)
    estimates = matrix_uncertainties(mats,alt,lam0,max(base['maximum89PlusFive_MPa'],base['originalToleranceRule_MPa']))
    # An archived stock/refined tangent bracket is an independent forecast. Native
    # consistent signatures may differ so any departure is retained in the receipt.
    estimate_relative_error = min(abs(x-u0)/u0 for x in estimates.values())
    s = groups['STATUS']['Right']
    right = {'converged':bool(s[0]),'internalStatus':int(s[1]),'resultCode':int(s[2]),
             'diagnostic':groups['DIAGNOSTIC']['Right']}
    if s[0]:
        r = states['Right']; raw = groups['RIGHT']['Values']
        assert raw[0] == r['lambda'] and abs(raw[1]-r['actualAlpha'])<2e-16 and abs(raw[2]-r['meanEngineeringShearYZ'])<2e-16
        assert abs(r['actualAlpha']-target)<=r['originalToleranceRule_MPa']/MODULUS
        r['trialSteelUltimateUtilization']=float(raw[3])
        left = h['stations'][h['station_index'][ids['Base44']]]
        previous_strain = (t['Base45'][:,:,:6]-left[:,:,:6]).ravel()
        right_strain = (t['Right'][:,:,:6]-t['Base45'][:,:,:6]).ravel()
        prev_norm = float(np.linalg.norm(previous_strain))
        right_norm = float(np.linalg.norm(right_strain))
        along = float(np.dot(previous_strain,right_strain)/prev_norm)
        assert prev_norm>0 and right_norm>0
        u1valid, u1 = groups['ADJOINT']['Right']
        assert u1valid in (0,1) and (u1>0 if u1valid else u1==0)
        delta = r['Qy_N']-base['Qy_N']
        u1 = float(u1*FORCE) if u1valid else None
        resolution = (u0+u1) if u1 is not None else None
        right.update({'prescribedAlphaIncrement':float(da),'actualAlphaIncrement':r['actualAlpha']-base['actualAlpha'],
                      'computedQy_N':r['Qy_N'],'deltaQy_N':delta,
                      'secant_NPerUnitAlpha':float(delta/(r['actualAlpha']-base['actualAlpha'])),
                      'summedAdjointResolution_N':resolution,'rightAdjoint_N':u1,
                      'resolvedSign':int(np.sign(delta)) if resolution is not None and abs(delta)>resolution else 0,
                      'strainDirectionCosineAgainstLastAccepted':along/right_norm,
                      'strainStepL2ToLastAcceptedRatio':right_norm/prev_norm,'maxStrainIncrement':peak(right_strain),
                      'strainOrthogonalL2':float(np.linalg.norm(right_strain-along/prev_norm*previous_strain)),
                      'branchSwitchesFromH45':int(np.count_nonzero(np.any(b['Right']!=b['Base45'],axis=2))),
                      'yieldPredictorSignChangesFromH45':int(np.count_nonzero(np.sign(f['Right'])!=np.sign(f['Base45']))),
                      'concreteYieldPredictorMinMax':[float(f['Right'].min()),float(f['Right'].max())]})
    result = {'workbookSHA256':prep['bookSHA256'],'originalH45Tau_MPa':prep['originalTauMPa'],
              'baselineAdjoint_N':u0,'archivedIndependentAdjoints_N':estimates,
              'baselineAdjointClosestArchivedRelativeDifference':estimate_relative_error,
              'unchangedReplay':True,'finiteProbesExecuted':1,'comparison89PlusFive':states,
              'rightShoulder':right,'ownedExcelClosure':closure,
              'interpretationScope':'A failed bounded solve does not establish physical capacity. One separated right load alone does not establish a peak or certify continuous branch identity.',
              'nativeSHA256':{n:sha256((Z/n).read_bytes()).hexdigest().upper()
                              for n in ('KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv')}}
    out = H/'AlternateVerification.json'
    out.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n',encoding='utf8')
    print(out, P['sha'](out), right)
    return result


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--repo-root',type=Path,required=True)
    args = parser.parse_args()
    verify(args.repo_root.resolve())
