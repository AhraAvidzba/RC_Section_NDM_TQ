"""Validate the native six-station fixture against stock repeats and the independent material matrix."""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import csv
import json
import numpy as np

H=Path(__file__).resolve().parent
RECEIPT='8EB4E9CA893595380E17D383D8DE42F9DD2FFFC0C978B8D448FA552395953D30'
LABELS={'Probe1':(135,1),'Probe2':(10,-1),'Probe3':(11,1),'Probe4':(135,-1),
        'Repeat1':(135,1),'Repeat2':(10,-1)}


def read(p):
    states={}
    with p.open(encoding='cp1251',newline='') as f:
        for kind,label,point,side,*r in csv.reader(f,delimiter=';'):
            assert kind=='DAMAGE_TANGENT' and len(r)==46 and label not in states
            assert (int(point),int(side))==LABELS[label]
            states[label]=np.array(r,float)
    assert states.keys()==LABELS.keys()
    return states


def verify(stock,candidate):
    p=H/'IndependentElasticTangent.json'
    assert sha256(p.read_bytes()).hexdigest().upper()==RECEIPT
    expected=json.loads(p.read_text(encoding='utf8'))
    expected={(r['point'],r['side']):r for r in expected['archivedIndependentPoints']}
    result=[]
    for label in LABELS:
        a,b=stock[label],candidate[label]
        assert np.array_equal(a[:10],b[:10]), label
        if label.startswith('Repeat'):
            assert b[2]==0 and np.array_equal(a,b),label
            result.append({'label':label,'exactNativeRepeat':True})
        else:
            r=expected[LABELS[label]]
            assert b[0]==0 and b[2]==1 and b[3]<0
            assert max(abs(b[4:10]-r['expectedStressMPa']))<2e-10
            expect=np.array(r['tangentMPa']).ravel()
            v=float(max(abs(b[10:]-expect)))
            assert v<2e-6, (label,v)
            result.append({'label':label,'candidateErrorMPa':v,'stockErrorMPa':float(max(abs(a[10:]-expect)))})
    return result


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--stock',type=Path,required=True)
    p.add_argument('--candidate',type=Path,required=True)
    a=p.parse_args()
    print(json.dumps(verify(read(a.stock),read(a.candidate)),indent=2))
