"""Build the isolated alternate-control witness inputs; never starts Office."""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
from io import BytesIO
import json,subprocess
import re
import numpy as np

H=Path(__file__).resolve().parent; D=H.parent/'kani18b'; draft=Path('docs/regression/Diagnostic.xlsm'); book=Path('workbook/output/RC_Section_NDM.xlsm')
mod=Path('tests/modTestKaniStage38.bas'); repoArt=Path('docs/regression/Coupled6D')
installed='E9F63337672E9FEC00E228A100EF554E9CA740D9395AC80D92E23417D0DA8833'
git_commit='dde8810'
sources_hashes={'src/Solver/CCoupledNewtonSolver.cls':'9E33A100858D4181123244A0A54F98DF23258B9ABD87CF0E6293C122E371176F',
 'src/Solver/CCoupledElasticState.cls':'A6BF256F42610AE7A353AD4AE1CCC9275DC247B398C3FA429CACD83840C97F94',
 'src/Materials/CCoupledConcreteResponse.cls':'92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C'}
archives={'KaniCommitNear48Portable.zip':'EA0A80006AF81D99799B53FDCB75B18CDDE7B7DF730AB16039902F12C6431488',
          'KaniH45Plus18NativePortable.zip':'10FFDC956D9F6D74F6A50A79DF2E50B3C5F7EFE810AEB18A4415D8584E1C5F48',
          'KaniPracticalProbe45Portable.zip':'4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113'}
control_archive='F22D91FE8632950056C045D519879962947297ACA12D5530BCDFEA236406F4F2'
sha=lambda x:sha256(x.read_bytes() if isinstance(x,Path) else x).hexdigest().upper()

def blob(repo,path):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',git_commit+':'+str(path).replace('\\','/')])

def open_art(repo,name):
    p=repo/repoArt/name; assert sha(p)==archives[name]; return ZipFile(p)

def make(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    if (H/'Preparation.json').exists(): return check(repo)
    rawbook=blob(repo,book); assert sha(rawbook)==installed
    for k,v in sources_hashes.items():
        git_source=blob(repo,k)
        variants={sha(git_source),sha(git_source.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))}
        assert v in variants
    with open_art(repo,'KaniCommitNear48Portable.zip') as h,open_art(repo,'KaniH45Plus18NativePortable.zip') as demo:
        q0=h.read('History45Verified.csv').decode('ascii').strip(); original=[x for x in demo.read('KaniGaugeInput.csv').decode('ascii').splitlines() if x.startswith('KANI_B_FIELD;History')]
        assert len(original)==8 and original[-1]==q0 and sha(h.read('History45Verified.csv'))=='97FF3089BA40A3B7349B1A0588B21FAFB3689E33DB7BA95892163C80B83CA9EE'
        old=json.loads(demo.read('Preparation.json'))
        st0=dict(np.load(BytesIO(h.read('MeasuredSamples.npz')),allow_pickle=False))
        c0=st0['fields'][list(st0['names']).index('Committed45')]
    p=H.parent/'kani-physical/KaniH45PhysicalBranchPortable.zip'; assert sha(p)==control_archive
    with ZipFile(p) as s:
        ctrl=s.read('H45DiscriminatingControl.csv'); plan=s.read('DiscriminatingH45Measurement.json'); audit=s.read('H45PhysicalBranchAudit.json')
    cells=ctrl.decode('ascii').strip().split(';'); assert len(cells)==92 and sha(ctrl)=='D856525577F01DB473E57F5202FFAADCDBB2C806FCD07F8A2AD713FAEB1922D9'
    projection=np.array(cells[5:],float); a0,target,step=map(float,cells[2:5]);
    assert projection.shape==(87,) and np.count_nonzero(projection[-4:])==0 and abs(projection@c0[2:]-a0)<2e-17
    assert abs((target-a0)-step)<2e-17 and step==1.5e-8
    src=(D/mod).read_text(encoding='utf8'); start=src.index('    Dim rootPath As String'); finish=src.index('    Close #tangents:',start)
    src=src[:start]+(H/'AlternateMain.bas.txt').read_text(encoding='utf8').rstrip()+'\n'+src[finish:]
    # Drop obsolete tests and their diagnostic solver API; import only this standard module.
    unused={
        'TryKaniChartTest','ReadKaniBoundedSeedsTest','ForwardKaniBoundedSeedTest',
        'ReadKaniChartInputTest',
    }
    for name in sorted(unused):
        pat=rf"(?ms)^' -------------------- ДЛЯ ТЕСТОВ --------------------\n' [^\n]+\nPrivate (Sub|Function) {name}\(.*?^End \1\n"
        src,n=re.subn(pat,'',src)
        assert n==1, name
    src=src.replace('Продолжает Kani 37 на штатном решателе V4 из проверенной материальной истории.',
                    'Проверяет одну меру управления от точной принятой истории Kani H45.')
    src=src.replace('Прямой и двухшаговый маршруты используют одно восстановленное состояние 37.',
                    'Воспроизводит H45, проверяет нулевой шаг, выполняет одну конечную пробу и восстанавливает H45.')
    assert 'solver.TryTestKaniDeformationStepWithInitial' not in src and 'solver.ReadTestKaniProbe45Tangent' not in src
    assert src.count('If entries.Count <> 3 Or history.Count <> 45')==1
    src=src.replace('If entries.Count <> 3 Or history.Count <> 45','If entries.Count <> 0 Or history.Count <> 45')
    src+='\n'+(H/'AlternateInput.bas.txt').read_text(encoding='utf8').rstrip()+'\n'
    bundle={book:rawbook,draft:rawbook,mod:src.encode('utf8'),Path('H45DiscriminatingControl.csv'):ctrl,
            Path('DiscriminatingH45Measurement.json'):plan,Path('H45PhysicalBranchAudit.json'):audit,
            Path('KaniGaugeInput.csv'):('\r\n'.join(original)+'\r\n').encode('ascii')}
    for n,v in old['frozen'].items():
        if n.startswith('tools/') or n=='KaniV4Input.csv':
            src0=D/n; assert sha(src0)==v; bundle[Path(n)]=src0.read_bytes()
    for name,raw in bundle.items():
        local=H/name; local.parent.mkdir(exist_ok=True,parents=True); local.write_bytes(raw)
    (H/'Native').mkdir(exist_ok=True); (H/'Temp').mkdir(exist_ok=True)
    readme={Path(n) for n in ('AlternateMain.bas.txt','AlternateInput.bas.txt','Prepare-Alt.py','Run-Alt.ps1','Verify-Alt.py','README.md')}
    m={'bookSHA256':installed,'sourceGit':git_commit,'productionDiagnosticSourcesSHA256':sources_hashes,'inputZIP_SHA256':archives,
       'controlArchiveSHA256':control_archive,'originalTauMPa':5.59190995944018e-7,
       'boundedIterations':12,'nativeTimeoutSeconds':125,'frozen':{n.as_posix():sha(H/n) for n in sorted((set(bundle)-{draft})|readme)}}
    (H/'Preparation.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf8')
    return check(repo)

def check(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    r=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert r['bookSHA256']==installed==sha(H/book)==sha(blob(repo,book))
    assert r['sourceGit']==git_commit and r['inputZIP_SHA256']==archives
    assert all(sha(repo/repoArt/n)==v for n,v in archives.items())
    assert all(sha(H/n)==v for n,v in r['frozen'].items())
    return r

if __name__=='__main__':
    p=ArgumentParser(); p.add_argument('--repo-root',type=Path,required=True); p.add_argument('--check',action='store_true'); a=p.parse_args()
    data=(check if a.check else make)(a.repo_root.resolve()); print(data['bookSHA256'],sha(H/'Preparation.json'))
