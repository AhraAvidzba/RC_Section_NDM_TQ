"""ДЛЯ ТЕСТОВ: исследует материальную неудачу новой оболочки без изменения допусков."""
from pathlib import Path
from runpy import run_path
import json
import numpy as np

repo=Path.cwd()
folder=Path(__file__).resolve().parent
references=run_path(str(folder/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]
step=run_path(str(folder/'TestClosedASDTangent.py'))['TestConcrete']
root=Path('D:/CodexScratch/RC_Section_NDM_TQ/WorkingASDIntegration0220261118')
records=[]
for name,section in references.items():
    oldpath=None
    for line in (root/'Data/History.csv').read_text().splitlines():
        row=line.split(';'); path=row[0]; index=int(row[1]); strain=np.array(list(map(float,row[2:]))).reshape(1,1,6)
        if oldpath!=path:
            history=(np.zeros((1,1,6)),np.zeros((1,1,6)),np.zeros((2,1,1)))
            oldpath=path
        try: nominal,history,_,iterations=step(section,strain,history,maximum_iterations=4096)
        except ArithmeticError as error:
            records.append({'law':name,'path':path,'index':index,'base_failure':str(error)})
            break
        if index%3==0:
            probe=strain+np.arange(1,7).reshape(1,1,6)*.00003
            for axis in (-1,*range(6)):
                perturbed=probe.copy()
                if axis>=0: perturbed[...,axis]+=2e-9*(1.+abs(float(probe[...,axis].item())))
                try:
                    result=step(section,perturbed,history,maximum_iterations=4096)
                    if result[3]>64: records.append({'law':name,'path':path,'index':index,'axis':axis,'iterations':result[3]})
                except ArithmeticError as error:
                    records.append({'law':name,'path':path,'index':index,'axis':axis,'failure':str(error)})
print(json.dumps(records,indent=2))
