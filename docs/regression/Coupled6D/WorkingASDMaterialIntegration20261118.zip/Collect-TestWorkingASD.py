"""ДЛЯ ТЕСТОВ: сохраняет точные входы, нативный VBA, внешние ответы и отрицательные результаты."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED

TestCases={'LFInput':'WorkingASDIntegration20261118','Budget64':'WorkingASDIntegration0220261118',
           'UnstableRoots':'WorkingASDIntegration0320261118','CompileFailed':'WorkingASDIntegration0420261118',
           'Final':'WorkingASDIntegration0520261118'}

def TestCopy(source,target):
    """Копирует неизменные байты без перезаписи посторонних файлов."""
    raw=source.read_bytes(); target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists(): assert target.read_bytes()==raw,target
    else: target.write_bytes(raw)

def TestCollect(repo,root):
    """Не включает временные Excel и повторные полные копии исходной книги."""
    root.mkdir()
    for key,name in TestCases.items():
        source=Path('D:/CodexScratch/RC_Section_NDM_TQ')/name; target=root/key
        prep=json.loads((source/'Preparation.json').read_bytes())
        for relative,expected in prep['inputs'].items():
            file=source/relative
            assert sha256(file.read_bytes()).hexdigest().upper()==expected,(key,relative)
        for file in source.rglob('*'):
            if not file.is_file(): continue
            relative=file.relative_to(source)
            if relative.parts[0] in ('Temp','workbook') or file.suffix.lower()=='.xlsm': continue
            TestCopy(file,target/relative)
        compiler=source/'docs/regression/CodeUpdate.json'
        if compiler.exists():
            with ZipFile(source/'docs/regression/Diagnostic.xlsm') as book: binary=book.read('xl/vbaProject.bin')
            (target/'CompiledVBA.bin').write_bytes(binary)
            (target/'CompiledVBA.json').write_bytes((json.dumps({'bytes':len(binary),'sha256':sha256(binary).hexdigest().upper()},indent=2)+'\n').encode())
    source=Path('D:/CodexScratch/RC_Section_NDM_TQ')/TestCases['Final']
    log=(source/'Native/Stock.txt').read_text('utf-8-sig')
    saved,=re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$',log,re.M)
    assert Path(saved).resolve().is_relative_to((source/'Temp').resolve())
    if not Path(saved).exists(): raise FileNotFoundError(saved)
    with ZipFile(saved) as original,ZipFile(root/'Final/SavedWorkbookXML.zip','x',ZIP_DEFLATED,compresslevel=9) as out:
        for name in sorted(original.namelist()):
            if name=='xl/vbaProject.bin': continue
            entry=ZipInfo(name,date_time=(2026,11,18,0,0,0)); entry.compress_type=ZIP_DEFLATED
            out.writestr(entry,original.read(name),compresslevel=9)
    here=Path(__file__).resolve().parent
    for name in ('Stage-TestWorkingASD.py','Run-TestWorkingASD.ps1','Verify-TestWorkingASD.py',
                 'Collect-TestWorkingASD.py','Check-TestWorkingASDEvidence.py','Inspect-TestResolutionVBA.py',
                 'Verify-TestASDResolution.py','Verify-TestReducedEvidence.py','Probe-TestWorkingClosure.py',
                 'Probe-TestNativeASDClosure.py'):
        TestCopy(here/name,root/name)
    TestCopy(Path('D:/CodexScratch/RC_Section_NDM_TQ/WorkingForceSubspaceEvidence20261118/SourceBook.json'),root/'SourceBook.json')
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper() for file in root.rglob('*') if file.is_file()}
    (root/'Files.json').write_bytes((json.dumps(files,indent=2,sort_keys=True)+'\n').encode())
    (root/'Cases.json').write_bytes((json.dumps(TestCases,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING ASD EVIDENCE COLLECTED',len(files))

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestCollect(args.repo.resolve(),args.root.resolve())
