"""ДЛЯ ТЕСТОВ: независимый ответ нативного OpenSees на историях рабочего VBA-материала."""

from argparse import ArgumentParser
import ctypes
from gzip import decompress
from hashlib import sha256
import json
from pathlib import Path
from subprocess import run, PIPE
import sys
from zipfile import ZipFile

TestBinary = '25BA42E1672526137D765D9C3631D1403E091F54F5AFCDB9242F9243C63C3A96'
TestReference = 'CE2DD6CE11F0C30BCAF46F3F14ABF35E25295B38762A4DBEDD90B0075DF85034'


def TestMemory():
    """Проверяет общий запас памяти непосредственно перед собственным процессом."""
    class TestPerformance(ctypes.Structure):
        _fields_ = [('cb',ctypes.c_ulong)]+[(key,ctypes.c_size_t) for key in
            ('CommitTotal','CommitLimit','CommitPeak','PhysicalTotal','PhysicalAvailable','SystemCache',
             'KernelTotal','KernelPaged','KernelNonpaged','PageSize')]+[(key,ctypes.c_ulong) for key in
            ('HandleCount','ProcessCount','ThreadCount')]
    state=TestPerformance(); state.cb=ctypes.sizeof(state)
    assert ctypes.windll.psapi.GetPerformanceInfo(ctypes.byref(state),state.cb)
    result={'ramMiB':state.PhysicalAvailable*state.PageSize/2**20,
            'freeCommitGiB':(state.CommitLimit-state.CommitTotal)*state.PageSize/2**30}
    assert result['ramMiB']>=6500 and result['freeCommitGiB']>=6,result
    return result


def TestWorker(output):
    """Повторяет неизменную деформацию 1025 раз; история каждого пути независима."""
    import openseespy.opensees as ops
    import openseespywin.opensees as native
    assert ops.NDTest is native.NDTest and ops.version()=='3.8.0'
    assert sha256(Path(native.__file__).read_bytes()).hexdigest().upper()==TestBinary
    command,paths=json.load(sys.stdin)
    ops.wipe(); ops.model('basic','-ndm',3,'-ndf',3)
    results={}
    for tag,(name,rows) in enumerate(paths.items(),1):
        ops.nDMaterial(command[0],tag,*command[1:])
        values=[]
        for index,row in enumerate(rows):
            xx,yy,zz,xy,xz,yz=row
            for _ in range(1025):
                ops.NDTest('SetStrain',tag,xx,yy,zz,xy,yz,xz)
                assert tuple(ops.NDTest('GetStrain',tag))==(xx,yy,zz,xy,yz,xz)
                ops.NDTest('CommitState',tag)
            a,b,c,d,e,f=ops.NDTest('GetStress',tag)
            values.append([a,b,c,d,f,e])
        results[name]=values
    ops.wipe()
    output.write_bytes((json.dumps({'binary_sha256':TestBinary,'command':command,'stress':results},separators=(',',':'))+'\n').encode())


def TestRun(repo,root,interpreter,output):
    """Не получает истории или напряжения VBA; сравнивает все шесть тензорных компонент."""
    paths={}
    for line in (root/'Data/History.csv').read_text().splitlines():
        row=line.split(';'); paths.setdefault(row[0],[]).append(list(map(float,row[2:])))
    archive=repo/'docs/regression/Coupled6D/MVT2NdmCurveConsistency20261117.zip'
    assert sha256(archive.read_bytes()).hexdigest().upper()==TestReference
    with ZipFile(archive) as source:
        command=json.loads(decompress(source.read('NdmCurveNullOpenSees.json.gz')))['commands']
    commands={'default':['ASDConcrete3D',30000.,.2,'-fc',34.0277777777778,'-ft',2.10667357864589,'-tangent'],
              'ndm_uniaxial':command}
    results={}
    for name,command in commands.items():
        selected=dict(paths)
        probes={}
        for line in (root/'Data'/(name+'.Probes.csv')).read_text().splitlines():
            row=line.split(';'); index=int(row[1]); key=row[0]+'#Probe'+row[1]
            selected[key]=paths[row[0]][:index+1]+[list(map(float,row[2:8]))]
            probes[key]=list(map(float,row[8:]))
        memory=TestMemory()
        raw=root/(name+'.OpenSees1025.json')
        assert not raw.exists(),raw
        process=run([str(interpreter),'-B','-X','utf8',str(Path(__file__).resolve()),'--worker',str(raw)],
                    input=json.dumps([command,selected],separators=(',',':')).encode(),stdout=PIPE,stderr=PIPE,
                    timeout=45,check=True,creationflags=0x08000000)
        assert process.returncode==0
        data=json.loads(raw.read_bytes())
        native={}
        for line in (root/'Data'/(name+'.Native.csv')).read_text().splitlines():
            row=line.split(';')
            assert len(row)==14,row
            native.setdefault(row[0],[]).append(list(map(float,row[8:])))
            assert list(map(float,row[2:8]))==paths[row[0]][int(row[1])]
        error,location,scalars=0.,None,0
        for path,rows in data['stress'].items():
            comparison=([rows[-1]],[probes[path]]) if path in probes else (rows,native[path])
            for step,(left,right) in enumerate(zip(*comparison,strict=True)):
                for component,(a,b) in enumerate(zip(left,right,strict=True)):
                    difference=abs(a-b); scalars+=1
                    if difference>error: error,location=difference,[path,step,component+1]
        assert error<8e-7,(name,error,location)
        permutation=0.
        for original,permuted in zip(native['Mixed'],native['PermutedMixed'],strict=True):
            permutation=max(permutation,*(abs(a-b) for a,b in zip(permuted,
                [original[i] for i in (2,0,1,4,5,3)],strict=True)))
        assert permutation<1e-8,permutation
        results[name]={'maximum_stress_error_MPa':error,'location':location,'scalar_comparisons':scalars,
                       'axis_permutation_error_MPa':permutation,'resources':memory,
                       'native_output_sha256':sha256(raw.read_bytes()).hexdigest().upper()}
        print('WORKING ASD PRIMARY MATERIAL VERIFIED',name,error,scalars,flush=True)
    proof={'variants':results,'binary_sha256':TestBinary,'fixed_strain_external_updates_per_step':1025,
           'fixed_strain_external_updates_per_probe':1025,
           'material_path_count':len(paths),'steps_per_variant':sum(map(len,paths.values())),
           'global_external_capacity_search':False,'physical_capacity_certified':False}
    output.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path)
    parser.add_argument('--python',type=Path)
    parser.add_argument('--out',type=Path)
    parser.add_argument('--worker',type=Path)
    args=parser.parse_args()
    if args.worker: TestWorker(args.worker)
    else: TestRun(args.repo.resolve(),args.root.resolve(),args.python.resolve(),args.out.resolve())
