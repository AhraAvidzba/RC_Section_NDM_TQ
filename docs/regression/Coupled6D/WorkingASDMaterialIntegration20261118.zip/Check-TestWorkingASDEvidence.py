"""ДЛЯ ТЕСТОВ: повторяет проверки сохранённых VBA, протоколов и первичных внешних ответов."""
from argparse import ArgumentParser
from hashlib import sha256
from decimal import Decimal
from io import BytesIO
import json
import math
from pathlib import Path
import re
from runpy import run_path

def TestRead(path):
    """Читает точные JSON, в том числе протоколы Windows PowerShell с BOM."""
    return json.loads(path.read_text('utf-8-sig'))

def TestClosure(folder,name,success):
    """Отделяет успешное закрытие собственного процесса от успешности самого теста."""
    proof=TestRead(folder/'Native'/(name+'.txt.ProcessClosure.json'))
    assert proof['Passed'] and proof['RunnerCleanupValid'] and proof['Closure']['FinalState']['State']=='Absent'
    assert proof['ChildExitCode']==(0 if success else 1)
    identity=proof['Closure']['Identity']; owner=TestRead(folder/'Native'/(name+'.txt.Ownership.json'))
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    assert owner['PID']==identity['PID'] and int(owner['StartTicksUTC'])==identity['Ticks']

def TestRotateStress(values):
    """Поворачивает физические напряжения независимо от инженерных деформаций входного генератора."""
    x,y,z,xy,xz,yz=values; tensor=((x,xy,xz),(xy,y,yz),(xz,yz,z))
    c,s,d,t=math.cos(.53),math.sin(.53),math.cos(.37),math.sin(.37)
    rotation=((c*d,-s,c*t),(s*d,c,s*t),(-t,0.,d))
    result=[[sum(rotation[i][k]*tensor[k][m]*rotation[j][m] for k in range(3) for m in range(3)) for j in range(3)] for i in range(3)]
    return result[0][0],result[1][1],result[2][2],result[0][1],result[0][2],result[1][2]

def TestPrimary(root):
    """Заново сравнивает все тензоры и проверяет пространственную инвариантность."""
    folder=root/'Final'; result={}
    for name in ('default','ndm_uniaxial'):
        complete=(folder/(name+'.OpenSeesClosed.json')).exists()
        if complete:
            observed=TestRead(folder/(name+'.OpenSeesClosed.json'))
        else:
            observed={'stress':{},'closure_iterations':{}}
            for file in sorted((folder/'PrimaryParts').glob(name+'.*.json')):
                part=TestRead(file)
                assert part['binary_sha256']=='25BA42E1672526137D765D9C3631D1403E091F54F5AFCDB9242F9243C63C3A96'
                assert part['tolerance_MPa']==1e-9
                observed['stress'].update(part['stress']); observed['closure_iterations'].update(part['closure_iterations'])
        native={}
        for line in (folder/'Data'/(name+'.Native.csv')).read_text().splitlines():
            row=line.split(';'); assert len(row)==14
            native.setdefault(row[0],[]).append(list(map(float,row[8:])))
        probes={row[0]+'#Probe'+row[1]:list(map(float,row[8:])) for row in
                (line.split(';') for line in (folder/'Data'/(name+'.Probes.csv')).read_text().splitlines())}
        maximum=0.; scalars=0
        for path,rows in observed['stress'].items():
            pair=([rows[-1]],[probes[path]]) if path in probes else (rows,native[path])
            for left,right in zip(*pair,strict=True):
                maximum=max(maximum,*(abs(a-b) for a,b in zip(left,right,strict=True))); scalars+=6
        assert maximum<8e-7
        assert scalars==(900 if complete else 744)
        rotation=0.
        for path in ('Compression','Mixed'):
            for original,rotated in zip(native[path],native['Rotated'+path],strict=True):
                rotation=max(rotation,*(abs(a-b) for a,b in zip(TestRotateStress(original),rotated,strict=True)))
        assert rotation<1e-8,rotation
        counts=[count for rows in observed['closure_iterations'].values() for count in rows]
        assert all(1<=value<=1024 for value in counts)
        result[name]={'maximum_error_MPa':maximum,'rotation_error_MPa':rotation,'scalar_comparisons':scalars,
                      'maximum_native_closure_repeats':max(counts),'declared_external_scope_completed':complete}
    diagnostic=TestRead(folder/'NdmShearProbe12Diagnostic/Result.json')
    assert diagnostic['timed_out'] and diagnostic['timeout_seconds']==45
    trace=[json.loads(line) for line in (folder/'NdmShearProbe12Diagnostic/Trace.ndjson').read_text().splitlines()]
    assert trace[-1]['stage']=='NumpySpectrumRead'
    assert [r for r in trace if r['stage']=='BeforeSetStrain'][-1]['iteration']==188
    assert diagnostic['resources']['ramMiB']>=6500 and diagnostic['resources']['freeCommitGiB']>=6
    return result

def TestVerify(repo,root,output):
    """Не выдаёт направленную интеграцию за физическую или полную приёмку книги."""
    for name,expected in TestRead(root/'Files.json').items():
        assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name
    source,digest=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    gauss=run_path(str(root/'Verify-TestASDResolution.py'))['TestGaussBody']
    _,original=reader(BytesIO(source)); native={}
    for key in ('LFInput','Budget64','UnstableRoots','Final'):
        folder=root/key; prep=TestRead(folder/'Preparation.json'); compiler=TestRead(folder/'docs/regression/CodeUpdate.json')
        assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256']==digest
        assert TestRead(folder/'CompileClosure.json')['State']=='Absent'
        for name,expected in prep['inputs'].items():
            raw=source if name.endswith('RC_Section_NDM.xlsm') else (folder/name).read_bytes()
            assert sha256(raw).hexdigest().upper()==expected,(key,name)
        binary=(folder/'CompiledVBA.bin').read_bytes(); pinned=TestRead(folder/'CompiledVBA.json')
        assert len(binary)==pinned['bytes'] and sha256(binary).hexdigest().upper()==pinned['sha256']
        _,actual=reader(helper['TestContainer'](binary)); changes={}
        assert set(actual)==set(original)|set(compiler['Modules'])
        for name in actual:
            if name not in compiler['Modules']:
                try: assert body(actual[name],name)[0]==body(original[name],name)[0],(key,name)
                except IndexError: assert actual[name]==original[name],(key,name)
                continue
            files=[p for directory in ('src','tests') for p in (folder/directory).rglob(name+'.*') if p.suffix in ('.bas','.cls')]
            assert len(files)==1
            code=files[0].read_text('utf-8-sig')
            if name=='CCoupledSectionQuadrature':
                expected=body(code,name)[0]
                assert expected.count('1e-7')==1 and '1e-8' not in expected
                expected=expected.replace('1e-7','0.0000001')
                edits=[{'kind':'equivalent_literal','from':'1e-7','to':'0.0000001','count':1}]
            else:
                expected,edits=helper['TestMVTCompilerBody'](body,code,name)
            if name=='CCoupledSectionAnalysis':
                old="' рабочий знак my соответствует +x·σz."
                assert expected.count(old)==1
                expected=expected.replace(old,old.replace('σ','?'))
                edits.append({'kind':'legacy_inline_comment_encoding_loss','from':old,'to':old.replace('σ','?')})
            if name=='modCoupledConcreteTensor':
                old='0.0000000000000001'; new='1e-16'
                assert expected.count(old)==1 and Decimal(old)==Decimal(new)
                expected=expected.replace(old,new)
                edits.append({'kind':'equivalent_literal','from':old,'to':new,'count':1})
            observed=body(actual[name],name)[0]
            expected,extra=gauss(expected,observed,name)
            assert expected==observed,(key,name)
            if edits or extra: changes[name]=edits+extra
        for state in map(json.loads,(folder/'Run.ndjson').read_text('utf-8-sig').splitlines()):
            assert state['ramMiB']>=6500 and state['freeCommitGiB']>=6 and all(p['ProtectedUser'] for p in state['excel'])
        TestClosure(folder,'Material',key in ('UnstableRoots','Final'))
        native[key]={'components':len(actual),'imported':len(compiler['Modules']),'compiler_conversions':changes}
    failure=root/'CompileFailed'
    assert not TestRead(failure/'CompileFailureClosure.json')['Compiled'] and TestRead(failure/'CompileFailureClosure.json')['State']=='Absent'
    assert 'COMPILE_LOCATION: module=modCoupledConcreteTensor;' in (failure/'Compile.log').read_text('utf-8-sig')
    final=root/'Final'; totals={}
    for name,count in (('Material',324),('Core',365),('Stock',28)):
        TestClosure(final,name,True)
        log=(final/'Native'/(name+'.txt')).read_text('utf-8-sig')
        pairs=[(int(a),int(b)) for a,b in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',log,re.M)]
        assert pairs and sum(a for a,b in pairs)==count and sum(b for a,b in pairs)==0
        assert 'RUNTIME ERROR:' not in log and 'SOURCE_UNCHANGED: True' in log
        totals[name]=count
    assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;',log,re.M)
    result={'native':native,'passed_assertions':totals,'primary':TestPrimary(root),'installed_workbook_changed':False,
            'external_material_acceptance_completed':False,
            'global_external_capacity_search':False,'physical_capacity_certified':False,'full_acceptance_completed':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING ASD SOURCES AND DIRECTED REGRESSIONS VERIFIED; EXTERNAL MATERIAL SCOPE INCOMPLETE; CAPACITY OPEN')

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); TestVerify(args.repo.resolve(),args.root.resolve(),args.out.resolve())
