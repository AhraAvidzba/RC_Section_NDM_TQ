"""ДЛЯ ТЕСТОВ: готовит частную книгу для проверки рабочего спектрального материала."""

from argparse import ArgumentParser
from hashlib import sha256
import json
import math
from pathlib import Path
from subprocess import check_output


def TestStage(repo, root):
    """Закрепляет инструменты, рабочие исходники и две независимые калибровки."""
    here = Path(__file__).resolve().parent
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/ForceSubspaceStock20261118')
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, expected in prep['inputs'].items():
        if name.startswith('tools/') or name == 'Guard-IsolatedOffice.ps1':
            raw = (template/name).read_bytes()
            assert sha256(raw).hexdigest().upper() == expected
            files[name] = raw
    source = (repo/'workbook/output/RC_Section_NDM.xlsm').read_bytes()
    expected = 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
    assert sha256(source).hexdigest().upper() == expected
    files['workbook/output/RC_Section_NDM.xlsm'] = source
    files['docs/regression/Diagnostic.xlsm'] = source
    names = ['CCubicSplineBasis', 'CCoupledSectionQuadrature', 'CCoupledElasticState',
             'CCoupledFieldSubspace', 'CCoupledNewtonSolver', 'CCoupledConcreteBackbone',
             'CCoupledASDFlow', 'CCoupledConcreteResponse', 'CCoupledMaterialSnapshot',
             'CCoupledSectionAnalysis', 'CNDMResultsWriter', 'modCoupledConcreteTensor', 'modTestCoupledASDMaterial']
    for name in names:
        paths = list(repo.glob('src/**/'+name+'.cls'))+list(repo.glob('src/**/'+name+'.bas'))+list(repo.glob('tests/'+name+'.bas'))
        assert len(paths) == 1, name
        file = paths[0]
        raw = file.read_bytes()
        assert max(map(len, raw.decode('utf-8-sig').splitlines())) < 1024
        files[file.relative_to(repo).as_posix()] = raw
    for name in ('default', 'ndm_uniaxial'):
        files['Data/'+name+'.csv'] = (Path('D:/CodexScratch/RC_Section_NDM_TQ/ClosedASDG5S220261118')/(name+'.csv')).read_bytes()
    paths = {
        'Tension': [(-.2*x, -.2*x, x, 0., 0., 0.) for x in (0.,1e-5,5e-5,1e-4,3e-4,.001,.003,.006,.003,0.,-.0003,.002,.01)],
        'Compression': [(-.2*x, -.2*x, x, 0., 0., 0.) for x in (0.,-1e-5,-1e-4,-5e-4,-.001,-.002,-.003,-.005,-.002,0.,.0001,-.001)],
        'Shear': [(0.,0.,0.,x,0.,0.) for x in (0.,1e-5,5e-5,.0001,.0003,.001,.003,.006,.002,0.,-.001,-.003,.001)],
        'Hydrostatic': [(x,x,x,0.,0.,0.) for x in (0.,-1e-5,-.0001,-.0005,-.001,-.0002,0.,1e-5,.0001,0.)],
        'Mixed': [tuple(x*y for y in (-.3,.2,-1.,.17,-.7,.5)) for x in (0.,1e-5,1e-4,.0005,.001,.002,.004,.001,0.,-.0005,-.001,.001)],
    }
    paths['PermutedMixed'] = [(z,x,y,b,c,a) for x,y,z,a,b,c in paths['Mixed']]
    paths['Repeated'] = paths['Mixed'][:8]+[paths['Mixed'][7]]*3+paths['Mixed'][8:]
    def TestRotate(row):
        """Поворачивает инженерные деформации двумя независимыми пространственными углами."""
        x,y,z,xy,xz,yz=row
        tensor=((x,xy/2.,xz/2.),(xy/2.,y,yz/2.),(xz/2.,yz/2.,z))
        c,s,d,t=math.cos(.53),math.sin(.53),math.cos(.37),math.sin(.37)
        rotation=((c*d,-s,c*t),(s*d,c,s*t),(-t,0.,d))
        value=[[sum(rotation[i][k]*tensor[k][m]*rotation[j][m] for k in range(3) for m in range(3)) for j in range(3)] for i in range(3)]
        return value[0][0],value[1][1],value[2][2],2.*value[0][1],2.*value[0][2],2.*value[1][2]
    paths['RotatedCompression']=list(map(TestRotate,paths['Compression']))
    paths['RotatedMixed']=list(map(TestRotate,paths['Mixed']))
    files['Data/History.csv'] = ('\r\n'.join(';'.join([name,str(i),*(format(v,'.17g') for v in row)])
                                         for name, path in paths.items() for i, row in enumerate(path))+'\r\n').encode()
    for name in (Path(__file__).name, 'Run-TestWorkingASD.ps1'):
        files[name] = (here/name).read_bytes()
    root.mkdir()
    for directory in ('Native','Temp','tests'):
        (root/directory).mkdir()
    for name, raw in files.items():
        file = root/name
        file.parent.mkdir(parents=True, exist_ok=True)
        with file.open('xb') as stream: stream.write(raw)
    record = {'base_stage_commit': check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),
              'source_book_sha256':expected,'modules':names,'prepared_tables_not_raw_inputs':True,
              'inputs':{name:sha256(raw).hexdigest().upper() for name,raw in files.items() if name!='docs/regression/Diagnostic.xlsm'}}
    (root/'Preparation.json').write_bytes((json.dumps(record,indent=2,sort_keys=True)+'\n').encode())
    print('WORKING ASD INPUTS READY',len(files),'histories',len(paths),'steps',sum(map(len,paths.values())))


if __name__ == '__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args()
    TestStage(args.repo.resolve(),args.root.resolve())
