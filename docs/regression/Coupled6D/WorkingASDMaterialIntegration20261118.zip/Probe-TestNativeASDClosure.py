"""ДЛЯ ТЕСТОВ: локализует внешний тайм-аут одной замкнутой пробы сдвига."""
from argparse import ArgumentParser
from hashlib import sha256
import json
import os
from pathlib import Path
from runpy import run_path
from subprocess import run,PIPE,TimeoutExpired

def TestRun(folder,root,interpreter):
    """Сохраняет вход, последний нативный вызов и неизменный 45-секундный предел."""
    helper=run_path(str(folder/'Verify-TestWorkingASD.py'))
    memory=helper['TestMemory']()
    command=json.loads((root/'ndm_uniaxial.OpenSees1025.json').read_bytes())['command']
    history=[list(map(float,row[2:])) for row in (line.split(';') for line in (root/'Data/History.csv').read_text().splitlines()) if row[0]=='Shear']
    row,=[row for row in (line.split(';') for line in (root/'Data/ndm_uniaxial.Probes.csv').read_text().splitlines()) if row[:2]==['Shear','12']]
    wire=json.dumps([command,{'Shear#Probe12':history[:13]+[list(map(float,row[2:8]))]}],separators=(',',':')).encode()
    target=root/'NdmShearProbe12Diagnostic'; target.mkdir()
    (target/'Input.json').write_bytes(wire)
    environment=os.environ.copy(); environment['NDM_TEST_ASD_TRACE']=str(target/'Trace.ndjson')
    arguments=[str(interpreter),'-B','-X','utf8',str(folder/'Verify-TestWorkingASD.py'),'--worker',str(target/'Output.json')]
    try:
        child=run(arguments,input=wire,stdout=PIPE,stderr=PIPE,timeout=45,env=environment,creationflags=0x08000000)
        result={'exit_code':child.returncode,'timed_out':False}
        (target/'Stdout.txt').write_bytes(child.stdout); (target/'Stderr.txt').write_bytes(child.stderr)
    except TimeoutExpired as error:
        result={'timed_out':True,'timeout_seconds':45}
        (target/'Stdout.txt').write_bytes(error.stdout or b''); (target/'Stderr.txt').write_bytes(error.stderr or b'')
    result['resources']=memory; result['input_sha256']=sha256(wire).hexdigest().upper()
    (target/'Result.json').write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps(result),flush=True)
    if (target/'Trace.ndjson').exists(): print('\n'.join((target/'Trace.ndjson').read_text().splitlines()[-6:]),flush=True)

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--root',type=Path,required=True); parser.add_argument('--python',type=Path,required=True)
    args=parser.parse_args(); TestRun(Path(__file__).resolve().parent,args.root.resolve(),args.python.resolve())
