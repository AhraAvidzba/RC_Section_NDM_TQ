"""Сверяет исходную меру, независимую невязку и историю пробы восстановления H26."""

import argparse
import json
from pathlib import Path
from importlib.util import module_from_spec, spec_from_file_location
import re

import ResumeBase as history
from ResumeBase import prior, v


HERE = Path(__file__).resolve().parent

_spec = spec_from_file_location("verify_setup", HERE / "Verify-Setup.py")
_setup_module = module_from_spec(_spec)
_spec.loader.exec_module(_setup_module)
setup_trial = _setup_module.verify_setup


def verify(frozen):
    prep, prefix, earlier, _, witnesses, *_ = frozen
    prior.MODULES = prep["arc_modules"]
    compiler, owner, wall = history.verified_receipts(prep)
    path = HERE / "NativeResume/MVT2.csv"
    raw = v.read_native(path)
    setup = setup_trial(raw)
    snapshots = prior.by_name(raw, "B_ARC_HISTORY")
    assert snapshots["Base24"] == snapshots["Restored24"]
    assert snapshots["CommittedAttempt2"] == witnesses[1][67:]
    for stage in ("ApiBefore", "ApiProvisional", "ApiDiscarded"):
        assert snapshots[stage] == snapshots["CommittedAttempt2"], stage
    committed = prior.by_name(raw, "B_EXT_COMMITTED")
    assert committed["Attempt1"] == witnesses[0][1:61]
    assert committed["Attempt2"] == witnesses[1][1:61]
    replay = v.vec(raw, "MVT2_CONTROL_FIELD")
    for i, (field, _) in enumerate(prefix, 1):
        assert v.peak(v.diff(replay[f"Replay{i}"], field)) < 1e-15

    assert raw["A_GUARD"] == [[condition, "0"] for condition in ("Count", "Offset", "Order", "Factor", "Budget")]
    [[used, *original]] = raw["A_STOCK"]
    [[calls, iterations, status, result_code, *diagnostic]] = raw["A_RECOVERED"]
    assert (int(calls), int(status), int(result_code)) == (2, 4, 0)
    assert int(used) == 15 and int(used) <= int(iterations) <= 26
    diagnostic = ";".join(diagnostic)
    assert " | Исходный отказ: " in diagnostic and ";".join(original) in diagnostic
    parts = re.search(r"итерации исходной пробы / дуги / повтора: (\d+) / (\d+) / (\d+); общий лимит: (\d+)", diagnostic)
    initial, arc, fixed, maximum = map(int, parts.groups())
    assert initial == int(used) and arc > 0 and fixed > 0 and initial + arc + fixed == int(iterations) and maximum == 26

    [[_, target]] = raw["A_CONTROL"]
    projection = v.vec(raw, "A_PROJECTION")["Original"]
    assert projection == (0., 1.) + (0.,) * 58
    prior_target = v.read(HERE / "FixedTargetWitness.json")["target_coordinate"]
    v.near(float(target), prior_target, 3e-15)
    target = float(target)
    [[_, factor, reported, control]] = raw["B_OWN_GATE"]
    factor, reported, control = float(factor), float(reported), float(control)
    key = "OwnApi"
    count, stored, *q = prior.by_name(raw, "B_TANGENT_FIELD")[key]
    assert count == "26" and float(stored) == factor
    q = prior.numbers(q)
    stations = {(int(point), int(side)): prior.numbers(values) for label, point, side, *values in raw["B_TANGENT_STATION"]
                if label == key}
    residual, actual, strain_error = v.reconstruct(q, factor, stations)
    assert earlier["geometry"] == {loc: data[:3] for loc, data in stations.items()}
    signed = v.diff(actual, v.force(factor))
    gauges_mpa = [value * v.MODULUS for value in residual[56:]]
    norm = max(v.peak(residual[:56]), v.peak(gauges_mpa), v.peak(x / s for x, s in zip(signed, v.SCALES, strict=True)))
    actual_control = (v.dot(projection, q) - target) * v.MODULUS
    tolerance = 5e-7 * (1. + v.peak(v.loading(factor)))
    assert strain_error < 4e-15 and v.peak(v.diff(residual, v.vec(raw, "B_TANGENT_RESIDUAL")[key])) < 3e-10
    reported_resultants = prior.numbers(prior.by_name(raw, "B_OWN_ACTUAL")["Api"])
    assert v.peak(x / s for x, s in zip(v.diff(actual, reported_resultants), v.SCALES, strict=True)) < 4e-12
    v.near(norm, reported, 4e-10)
    v.near(actual_control, control, 3e-10)
    assert norm <= tolerance and abs(actual_control) <= tolerance
    assert abs(factor - 18.5807648298282) <= 5e-6
    reference = v.read(HERE / "BranchWitness.json")["fixed"]["fingerprint"]
    actual_branches = [[point, side, *map(int, state[3:6]), state[6] >= 0.]
                       for (point, side), state in stations.items() if point <= 25]
    assert actual_branches == reference
    return {"historical_setup": setup, "native_trace_sha256": v.digest(path), "solver_source": prep["arc_sources"], "probes": int(calls),
            "stock_iterations": initial, "arc_iterations": arc, "fixed_iterations": fixed,
            "total_iterations": int(iterations), "maximum_iterations": maximum,
            "Qy_kN": factor, "target": target, "signed_resultant_errors_N_Nmm": signed,
            "normalized_equilibrium_MPa": norm, "fixed_control_error_MPa": actual_control, "equilibrium_tolerance_MPa": tolerance,
            "replayed_branch_matches": True, "accepted_history_untouched": True, "H24_exact_restore": True,
            "compiler_closed": compiler["State"] == "Absent", "owner_pid": owner["PID"], "wall_seconds": wall}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Resume"])
    command = parser.parse_args()
    setup = history.prepare()
    if command.inputs_only:
        print("FROZEN API INPUTS", v.digest(HERE / "Preparation.json"))
    else:
        assert command.phase == "Resume"
        out = HERE / "VerificationArcApi.json"
        out.write_text(json.dumps(verify(setup), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("API VERIFIED", v.digest(out))
