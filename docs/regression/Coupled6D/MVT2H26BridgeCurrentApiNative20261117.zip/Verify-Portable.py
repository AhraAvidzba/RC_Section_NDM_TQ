"""Повторяет независимую проверку нативной пробы H26 и подготовительной остановки."""

import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
import ResumeBase as history
from ResumeBase import prior, v


HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
CURRENT = "C603E41639484DB313C5390930BC52F1AC3CC42ED4CE01BC1946BC01ED84FA95"
MANIFEST = "CC9F56663E89134D6355E002016C9D44F32084193C6F618D55D266792673506B"
TERMINAL = "3D1DDCABACCE72EC2940CE3E6B531D9F10F7653D1BDA53D9D6FBE326F6870656"
OLD_PREP = "A3C86DC8091B3189ED1A153CF421EE1CE280D4BA23AC457E37631C8677DD5CC0"


def prepare(args):
    """Воспроизводит подготовку исходной сверки с явно передаваемым бинарником."""
    inventory = v.read(HERE / "SHA256SUMS.json")
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file()
              and p.name != "SHA256SUMS.json" and "__pycache__" not in p.parts}
    assert actual == set(inventory)
    for name, sha in inventory.items():
        assert Path(name).suffix.lower() not in {".xlsm", ".xlsx", ".xls", ".ndm"}
        assert Path(name).name.lower() != "vba_all_code.txt"
        assert v.digest(HERE / name) == sha, name

    assert v.digest(HERE / "Preparation.json") == MANIFEST
    prep = v.read(HERE / "Preparation.json")
    assert prep["book_sha256"] == prep["inputs"][BOOK] == CURRENT
    assert prep["historical_bounded_setup_only"] is True and prep["negative_case"] is False
    for file, sha in prep["inputs"].items():
        if file != BOOK:
            assert v.digest(HERE / file) == sha, file
    if args.workbook:
        assert v.digest(args.workbook) == CURRENT
    if args.diagnostic_workbook:
        assert v.digest(args.diagnostic_workbook) == v.read(HERE / "docs/regression/CodeUpdate.json")["WorkbookSHA256"]

    assert prep["inputs"]["Replay.csv"] == prep["replay_sha256"] and prep["watchdog_seconds"] == 105
    archive, stations = v.verified_states(v.read_native(HERE / "JetNative.csv"))
    base24 = archive["Base24"]
    assert base24 == archive["Restored24"] and stations["Base24"] == stations["Restored24"]
    replay = (HERE / "Replay.csv").read_text().splitlines()[1:]
    assert len(replay) == 24
    prefix = [(tuple(map(float, row[9:])), float(row[2])) for row in (line.split(";") for line in replay)]
    assert prefix[-1] == (base24["field"], base24["q"])
    accepted = history.wire_chunks("AcceptedWire.csv", (1, 15, 15, 15, 15, 6, *(8,) * 135) * 2)
    witnesses = [accepted[:1147], accepted[1147:]]
    assert len(witnesses) == 2 and all(len(row) == 1147 for row in witnesses)
    assert [float(row[0]) for row in witnesses] == [18.5708039839326, 18.5785550208131]
    endpoints = [(tuple(map(float, row[1:61])), float(row[0])) for row in witnesses]
    original_normal = prior.numbers((HERE / "MVTNormal.csv").read_text().strip().split(";"))
    pinned = prior.numbers(history.wire_chunks("H26Normal.csv", (15, 15, 15, 15, 3)))
    load_scale = v.read(HERE / "MVTHistory.json")["strains_normalized_to_last_Qy_increment_per_kN"]
    direct, normal_load, length = prior.determine_normal(endpoints[1], endpoints[0], base24["geometry"], load_scale)
    assert len(pinned) == 63 and pinned[56:60] == (0.,) * 4 and pinned[62] == 1.31947154672837e-7
    assert v.peak(v.diff(direct, pinned[:60])) < 2e-12
    v.near(pinned[60], normal_load, 2e-15)
    v.near(pinned[61], length, 2e-17)
    return prep, prefix, base24, stations["Base24"], witnesses, original_normal, pinned, load_scale


def verify_sources(prep):
    for item in prep["arc_sources"]["modules"]:
        original = HERE / "ProductionSource" / item["path"]
        assert v.digest(original) == item["candidate_sha256"]
        diagnostic = HERE / item["path"]
        if original.name == "CCoupledDeformationContinuation.cls":
            assert diagnostic.read_bytes() == original.read_bytes()
            continue
        block = rb"^Friend Function TryRecoverDeformationByArc\(.*?^End Function"
        body = re.search(block, original.read_bytes(), re.M | re.S)[0]
        assert body == re.search(block, diagnostic.read_bytes(), re.M | re.S)[0]
        test = diagnostic.read_text(encoding="utf-8")
        assert "If mBoundedTraceTest > 0 And mUseSpatialHistory And mControlActive And Len(mismatch) > 0" in test
        assert test.count("matchedFallbackTest:=True") == 1


def verify_guard():
    prior_guard = (HERE / "PreparationFailure/Guard-IsolatedOffice.ps1").read_text(encoding="utf-8")
    current = (HERE / "Guard-IsolatedOffice.ps1").read_text(encoding="utf-8")
    before = "-or $protected.ContainsKey($workerId))"
    after = "-or ($protected.ContainsKey($workerId) -and $protected[$workerId] -eq $workerTicks))"
    assert prior_guard.count(before) == 1 and prior_guard.replace(before, after) == current
    closure = v.read(HERE / "CompileClosure.json")
    compile_identity = (closure["PID"], int(closure["StartTicksUTC"]))
    log = (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    found = re.search(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", log, re.M)
    assert tuple(map(int, found.groups())) == compile_identity and closure["State"] == "Absent"
    assert compile_identity == (36308, 639304687274436521)
    assert "36308=[long]639304159664638157" in prior_guard and "production unchanged=True" in log


def verify_unsuccessful_preparation(terminal):
    """Сопоставляет исходные состояния и сохраняет точный отказ до достижения H26."""
    root = HERE / "PreparationFailure"
    assert v.digest(root / "Preparation.json") == OLD_PREP
    old_prep = v.read(root / "Preparation.json")
    assert old_prep["book_sha256"] == CURRENT
    assert v.digest(root / "Guard-IsolatedOffice.ps1") == old_prep["inputs"]["Guard-IsolatedOffice.ps1"]
    code = v.read(root / "CodeUpdate.json")
    own = v.read(root / "NativeResume/MVT2.txt.Ownership.json")
    check = v.read(root / "NativeResume/MVT2.txt.ProcessClosure.json")
    outcome = v.read(root / "NativeResume/RunReceipt.json")
    closure = check["Closure"]["FinalState"]
    assert code["Compiled"] and code["ProductionSHA256"] == CURRENT and not code["ProductionChanged"]
    assert sorted(code["Modules"]) == old_prep["arc_modules"]
    assert own["VerifiedNewOwner"] and own["SourceSHA256"] == code["WorkbookSHA256"]
    assert check["Passed"] and check["ChildHasExited"] and check["ChildExitCode"] == outcome["native_exit"] == 1
    assert closure["State"] == "Absent" and (closure["PID"], closure["StartTicksUTC"]) == (own["PID"], own["StartTicksUTC"])
    assert v.read(root / "CompileClosure.json")["State"] == "Absent"
    log = (root / "NativeResume/MVT2.txt").read_text(encoding="utf-8-sig")
    assert "RUNTIME ERROR: VBAProject Не восстановлена принятая точка Attempt1." in log
    assert "WATCHDOG_COMPLETED: exit=1; source unchanged=True" in log

    old = v.read_native(root / "NativeResume/MVT2.csv")
    live = v.read_native(HERE / "NativeResume/MVT2.csv")
    assert live["MVT2_CONTROL_FIELD"] == old["MVT2_CONTROL_FIELD"] and len(old["MVT2_CONTROL_FIELD"]) == 24
    assert v.vec(live, "B_EXT_SEED")["Attempt1"] == v.vec(old, "B_EXT_SEED")["Attempt1"]
    assert prior.by_name(old, "B_EXT_TRY")["Attempt1"] == prior.by_name(live, "B_EXT_TRY")["Attempt1"]
    assert prior.by_name(old, "B_BOUND_ACTUAL")["Base24"] == prior.by_name(live, "B_BOUND_ACTUAL")["Base24"]
    state, status, result, *_ = prior.by_name(old, "B_EXT_SOLVER")["Attempt1"]
    assert (state, status, result) == ("0", "6", "10")
    assert not old["B_FB_START"] and not old["A_STOCK"]
    assert terminal["historical_setup"]["two_bounded_corrections"]
    return {"replayed_prefix_equal": 24, "same_first_prediction": True, "stock_attempt1_status": "NumFail", "owner_closed": True}


def main():
    if not __debug__:
        raise SystemExit("Use Python without -O")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook", type=Path)
    parser.add_argument("--diagnostic-workbook", type=Path)
    args = parser.parse_args()
    prepared = prepare(args)
    verify_sources(prepared[0])
    verify_guard()
    spec = spec_from_file_location("native_verify", HERE / "Verify-MVT2ShearControlled.py")
    native = module_from_spec(spec)
    spec.loader.exec_module(native)
    confirmed = native.verify(prepared)
    assert v.digest(HERE / "VerificationArcApi.json") == TERMINAL
    assert json.loads(json.dumps(confirmed)) == v.read(HERE / "VerificationArcApi.json")
    setup = verify_unsuccessful_preparation(confirmed)
    print(f"SETUP {setup['replayed_prefix_equal']} PREVIOUS FIELDS, IDENTICAL ATTEMPT1 PREDICTION, EARLIER NumFail")
    print(f"H26 Qy={confirmed['Qy_kN']:.12f} kN residual={confirmed['normalized_equilibrium_MPa']:.9g} MPa "
          f"iterations={confirmed['stock_iterations']}+{confirmed['arc_iterations']}+{confirmed['fixed_iterations']}"
          f"/{confirmed['maximum_iterations']}")
    print("MVT2 H26 BRIDGE API PORTABLE VERIFIED", TERMINAL)


if __name__ == "__main__":
    main()
