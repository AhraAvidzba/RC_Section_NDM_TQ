"""Собирает и повторно сверяет архив двух нативных прогонов MVT2."""

from hashlib import file_digest
import json
from pathlib import Path
from shutil import copyfile
from subprocess import run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
SCRATCH = Path("D:/CodexScratch/RC_Section_NDM_TQ")
CURRENT = SCRATCH / "MVTArcAccept"
FIRST = SCRATCH / "MVTBridgeApi"
OUT = HERE / "MVT2H26BridgeCurrentApiNative20261117.zip"
STATE = ("Preparation.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json")
RAW = ("MVT2.csv", "MVT2.txt", "MVT2.txt.memory.json", "MVT2.txt.Ownership.json", "MVT2.txt.ProcessClosure.json",
       "MVT2.txt.RunnerCleanup.json", "MVT2.txt.stderr.log", "MVT2.txt.stdout.log", "RunReceipt.json")
BOOK = "workbook/output/RC_Section_NDM.xlsm"


def digest(path):
    with path.open("rb") as file:
        return file_digest(file, "sha256").hexdigest().upper()


def locate_files():
    manifest = json.loads((CURRENT / "Preparation.json").read_bytes())
    all_current = {name for name in manifest["inputs"] if name != BOOK}
    all_current.update(("VerificationArcApi.json", *STATE, *("NativeResume/" + p for p in RAW)))
    for name in sorted(all_current):
        yield CURRENT / name, name
    for name in (*STATE, "Guard-IsolatedOffice.ps1", *("NativeResume/" + p for p in RAW)):
        stored = "CodeUpdate.json" if name.endswith("/CodeUpdate.json") else name
        source = FIRST / name
        assert source.is_file(), source
        yield source, "PreparationFailure/" + stored
    for item in manifest["arc_sources"]["modules"]:
        name = item["path"]
        yield HERE.parent / "mvbridge" / name, "ProductionSource/" + name
    for name in ("Pack.py", "Verify-Portable.py", "README-Portable.md"):
        yield HERE / name, name


def verify(root, extra=()):
    command = [sys.executable, "-B", "-X", "utf8", str(root / "Verify-Portable.py"), *map(str, extra)]
    attempt = run(command, cwd=root, capture_output=True, encoding="utf-8")
    if attempt.returncode:
        raise RuntimeError(attempt.stderr)
    return attempt.stdout


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    with TemporaryDirectory(prefix="stage-", dir=HERE) as tmp, TemporaryDirectory(prefix="extract-", dir=HERE) as extracted:
        staged, detached = Path(tmp), Path(extracted)
        for source, name in locate_files():
            target = staged / name
            assert not target.exists(), name
            target.parent.mkdir(parents=True, exist_ok=True)
            copyfile(source, target)
        files = sorted(path.relative_to(staged).as_posix() for path in staged.rglob("*") if path.is_file())
        inventory = {name: digest(staged / name) for name in files}
        (staged / "SHA256SUMS.json").write_text(json.dumps(inventory, indent=2) + "\n", encoding="utf-8", newline="\n")
        current = verify(staged, ("--workbook", CURRENT / BOOK, "--diagnostic-workbook", CURRENT / "docs/regression/Diagnostic.xlsm"))
        archive_path = staged / OUT.name
        with ZipFile(archive_path, "x", compression=ZIP_DEFLATED, compresslevel=9) as zip_:
            for name in sorted([*files, "SHA256SUMS.json"]):
                info = ZipInfo(name, (2026, 11, 17, 0, 0, 0))
                info.external_attr = 0o100644 << 16
                zip_.writestr(info, (staged / name).read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(archive_path) as zip_:
            assert zip_.testzip() is None and len(set(zip_.namelist())) == len(zip_.namelist())
            zip_.extractall(detached)
        replay = verify(detached)
        assert replay == current
        archive_path.replace(OUT)
    checksum = digest(OUT)
    OUT.with_suffix(".zip.sha256").write_text(f"{checksum}  {OUT.name}\n", encoding="ascii")
    OUT.with_suffix(".replay.txt").write_text(replay, encoding="utf-8", newline="\n")
    print(replay, end="")
    print(f"{OUT.name} {OUT.stat().st_size} bytes SHA-256 {checksum}")


if __name__ == "__main__":
    main()
