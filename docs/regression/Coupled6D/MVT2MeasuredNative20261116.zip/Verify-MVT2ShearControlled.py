"""Independent native verification of the measured MVT2 secant predictions and rollback."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import sys
import csv
import json
import math

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def read_native(path,encoding="cp1251"):
    tables=defaultdict(list)
    for marker,*row in csv.reader(path.read_text(encoding=encoding).splitlines(),delimiter=";"):
        tables[marker].append(row)
    return tables


def verified_states(tags):
    fields, stations = {}, defaultdict(dict)
    for name, history, q, *x in tags["B_TANGENT_FIELD"]:
        assert name not in fields and len(x) == 60
        fields[name] = (int(history), float(q), tuple(map(float, x)))
    for name, point, side, *row in tags["B_TANGENT_STATION"]:
        key = int(point), int(side)
        assert key not in stations[name] and len(row) == 19
        stations[name][key] = tuple(map(float, row))
    raw_r = vec(tags, "B_TANGENT_RESIDUAL")
    raw_force = {name: tuple(map(float, row)) for name, *row in tags["B_BOUND_ACTUAL"]}
    raw_norm = {name: float(value) for name, value in tags["B_BOUND_NORM"]}
    output = {}
    assert set(fields) == set(stations) == set(raw_r) == set(raw_force) == set(raw_norm)
    for name, (history, q, x) in fields.items():
        assert history == 24 and len(stations[name]) == 135
        rows, actual, strain_error = reconstruct(x, q, stations[name])
        error = peak(diff(rows, raw_r[name]))
        assert strain_error < 4e-15 and error < 3e-10
        assert max(abs(a-b)/s for a,b,s in zip(actual, raw_force[name], SCALES, strict=True)) < 4e-12
        signed = diff(actual, force(q))
        efforts = tuple(r/s for r, s in zip(signed, SCALES, strict=True))
        residual = (*rows[:56], *efforts)
        gauge_norm = MODULUS*peak(rows[56:])
        tol = 5e-7*(1.+peak(loading(q)))
        near(max(peak(residual), gauge_norm),raw_norm[name], 4e-10)
        assert gauge_norm <= tol
        output[name] = {"q": q, "field": x, "r": residual, "gauge_MPa": gauge_norm, "tol_MPa": tol,
            "signed_force_N_Nmm": signed, "norm_MPa": peak(residual), "reconstruction_error_MPa": error,
            "geometry": {key: row[:3] for key, row in stations[name].items()}}
    return output, stations


def tensor_radius(field, geometry):
    maximum = 0.
    for (_, side), (x, y, _) in geometry.items():
        strain = strain_at(field, operators(x, y), side)
        maximum = max(maximum, peak(s/(1. if i < 3 else math.sqrt(2.)) for i, s in enumerate(strain)))
    return maximum


HERE=Path(__file__).resolve().parent
NATIVE=HERE/'Native'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def verify_run(prep):
    build=read(HERE/'docs/regression/CodeUpdate.json')
    compiler=read(HERE/'CompileClosure.json')
    owner=read(NATIVE/'MVT2.txt.Ownership.json')
    watch=read(NATIVE/'MVT2.txt.ProcessClosure.json')
    receipt=read(NATIVE/'RunReceipt.json')
    final=watch['Closure']['FinalState']
    assert build['Compiled'] and build['Modules']==['modTestCoupledExperiment'] and not build['ProductionChanged']
    assert build['ProductionSHA256']==prep['book_sha256'] and compiler['State']=='Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==build['WorkbookSHA256']
    assert watch['Passed'] and watch['ChildExitCode']==receipt['native_exit']==0 and watch['ChildHasExited']
    assert final['State']=='Absent' and final['PID']==owner['PID'] and final['StartTicksUTC']==owner['StartTicksUTC']
    assert 'TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0' in (NATIVE/'MVT2.txt').read_text(encoding='utf-8-sig')
    if '--offline' not in sys.argv:
        assert digest(HERE/'docs/regression/Diagnostic.xlsm')==build['WorkbookSHA256']
    return compiler,final,receipt['wall_seconds']


def verify_steel(tags, native, stations, accepted):
    steel=defaultdict(dict)
    for name,point,side,ax,e,concrete,sigma in tags['B_BOUND_STEEL']:
        key=int(point),int(side)
        assert key not in steel[name]
        steel[name][key]=int(ax)-1,float(e),float(concrete),float(sigma)
    assert set(steel)==set(native)
    peaks={}
    for name,stress in steel.items():
        assert len(stress)==60
        for (point,side),(ax,e,concrete,sigma) in stress.items():
            row=stations[name][point,side]
            x,y,area=row[:3]
            assert ax==(2 if point<=29 else 1 if abs(x)>abs(y) else 0)
            near(e,row[7+ax],4e-16)
            near(sigma,row[13+ax]+concrete,4e-10)
            near(sigma,200000.*e,4e-8)
            limit=498. if point<=29 else 450.
            assert abs(sigma)<limit
            block=operators(x,y)
            assert max(abs(strain_at(q,block,side)[ax])*200000. for q in accepted.values())<limit
        peaks[name]=max(abs(row[3]) for row in stress.values())
    return peaks


def main():
    prep=read(HERE/'Preparation.json')
    compiler,owner,wall=verify_run(prep)
    assert digest(HERE/'Replay.csv')==prep['replay_sha256']
    assert digest(HERE/'tests/modTestCoupledExperiment.bas')==prep['module_sha256']
    assert all(digest(HERE/name)==value for name,value in prep['prior_input_sha256'].items())
    tags=read_native(NATIVE/'MVT2.csv')
    native,stations=verified_states(tags)
    earlier_a,stations_a=verified_states(read_native(HERE/'BasisA.csv','ascii'))
    earlier_b,stations_b=verified_states(read_native(HERE/'BasisB.csv','ascii'))
    old_anchor=earlier_a['Anchor']
    archived=list(csv.reader((HERE/'Replay.csv').read_text().splitlines(),delimiter=';'))[1:]
    accepted=vec(tags,'MVT2_CONTROL_FIELD')
    assert len(accepted)==len(archived)==24
    for i,r in enumerate(archived,1):
        assert int(r[0])==i and peak(diff(tuple(map(float,r[9:])),accepted[f'Replay{i}']))<1e-15
    [[qbase,qtrial]]=tags['B_TANGENT_LOAD']
    qbase,qtrial=map(float,(qbase,qtrial))
    near(qbase,float(archived[-1][2]),2e-13)
    near(qtrial,qbase+(qbase-float(archived[-2][2]))/64.,2e-13)
    anchors=['Base24','Restored24','MeasuredLine/Rollback','MeasuredCombination/Rollback']
    for name in anchors:
        assert native[name]==native['Base24'] and native[name]['q']==qbase
        assert native[name]['field']==accepted['Replay24'] and stations[name]==stations['Base24']
    assert tags['B_TANGENT_END']==[['24',f'{qbase:g}']] or (len(tags['B_TANGENT_END'])==1 and tags['B_TANGENT_END'][0][0]=='24' and float(tags['B_TANGENT_END'][0][1])==qbase)
    anchor=native['Anchor']
    for ref in (old_anchor,earlier_b['Anchor']):
        assert anchor['field']==ref['field'] and anchor['q']==ref['q']==qtrial
        assert anchor['geometry']==ref['geometry']
        assert peak(diff(anchor['r'],ref['r']))<4e-10
    assert max(peak(diff(x,stations_a['Anchor'][key])) for key,x in stations['Anchor'].items())<3e-9
    tol=anchor['tol_MPa']; caps=tuple(max(tol,abs(v)) for v in anchor['r'][56:])
    [[r0_log,tol_log]]=tags['B_MEASURE_ORIGIN']
    near(float(r0_log),anchor['norm_MPa'],4e-10); near(float(tol_log),tol,5e-15)
    [[name,*native_caps]]=tags['B_MEASURE_CAPS']
    assert name=='Anchor' and peak(diff(tuple(map(float,native_caps)),caps))<4e-10
    met=read(HERE/'MeasuredAction.json')
    assert peak(diff(met['native_proposal']['individual_effort_caps_MPa'],caps))<4e-10
    best=met['best_unverified_candidate']; interval=met['measured_chord_search']['BoundedLarge']
    directions={
        'BoundedLarge':(diff(earlier_b['BothBest']['field'],earlier_b['Anchor']['field']),
                        diff(earlier_b['BothBest']['r'],earlier_b['Anchor']['r'])),
        'AxialGradientNegative':(diff(earlier_a['GradientNegative']['field'],old_anchor['field']),
                                diff(earlier_a['GradientNegative']['r'],old_anchor['r'])),
    }
    weights={
        'MeasuredLine':{'BoundedLarge':interval['model_optimal_fraction']},
        'MeasuredCombination':{k:v for k,v in best['measured_direction_weights'].items() if v!=0.},
    }
    expected_rows=list(csv.reader((HERE/'CandidateFields.csv').read_text().splitlines(),delimiter=';'))[1:]
    planned={name:(float(q),float(p),tuple(map(float,x))) for name,q,p,*x in expected_rows}
    assert set(planned)==set(weights) and set(native)==set(anchors+['Anchor',*planned])
    inputs={name:tuple(map(float,v)) for name,*v in tags['B_MEASURE_INPUT']}
    assert set(inputs)==set(planned)
    outputs={}
    native_status={name:tuple(map(int,v)) for name,*v in tags['B_MEASURE_STATUS']}
    native_effort={name:tuple(map(float,v)) for name,*v in tags['B_MEASURE_RELATIVE_EFFORTS']}
    assert set(native_effort)==set(native_status)==set(planned)
    steel=verify_steel(tags,native,stations,accepted)
    for name,(q,prior_model,field) in planned.items():
        assert q==qtrial and native[name]['q']==qtrial
        assert peak(diff(native[name]['field'],field))<3e-15
        model_q=[a+math.fsum(weight*directions[k][0][i] for k,weight in weights[name].items()) for i,a in enumerate(old_anchor['field'])]
        assert peak(diff(model_q,field))<3e-15
        model_r=tuple(a+math.fsum(weight*directions[k][1][i] for k,weight in weights[name].items()) for i,a in enumerate(old_anchor['r']))
        near(peak(model_r),prior_model,4e-10)
        near(prior_model,inputs[name][0],2e-14)
        radius=tensor_radius(diff(field,anchor['field']),anchor['geometry'])
        assert radius<=1e-8+4e-16
        near(radius,inputs[name][1],4e-15)
        state=native[name]
        old=state['r'][56:]
        assert peak(diff(old,native_effort[name]))<4e-10
        violations=[key for key,v,limit in zip(EFFORT_NAMES,old,caps,strict=True) if abs(v)>limit+4e-10]
        if not any(abs(abs(v)-c)<4e-10 for v,c in zip(old,caps,strict=True)):
            assert native_status[name][1]==int(not violations)
        error=peak(diff(state['r'],model_r))
        actual_norm=max(state['gauge_MPa'],state['norm_MPa'])
        passes=actual_norm<=tol
        assert native_status[name][0]==int(passes)
        decrease=actual_norm<anchor['norm_MPa']
        assert native_status[name][2]==int(decrease)
        outputs[name]={'overall_MPa':actual_norm,'predicted_MPa':prior_model,'max_prediction_error_MPa':error,
            'predicted_r_vector_MPa':model_r,'measured_r_vector_MPa':state['r'],'gauge_MPa':state['gauge_MPa'],
            'effort_error_N_Nmm':state['signed_force_N_Nmm'],'individual_efforts_within_caps':not violations,
            'violated_efforts':violations,'worst_weak_row':max(range(56),key=lambda i:abs(state['r'][i]))+1,
            'maximum_steel_stress_MPa':steel[name],'tensor_radius':radius,'measured_norm_reduction':1.-actual_norm/anchor['norm_MPa'],
            'full_equilibrium':passes,'progress_gate_passed':decrease and not violations}
    report={'source_workbook_sha256':prep['book_sha256'],'replay_sha256':prep['replay_sha256'],
        'native_trace_sha256':digest(NATIVE/'MVT2.csv'),'compiler':compiler,'owner':owner,'native_wall_s':wall,
        'target_Qy_kN':qtrial,'qLastAccepted_kN':qbase,'anchor_norm_MPa':anchor['norm_MPa'],'equilibrium_tolerance_MPa':tol,
        'effort_cap_MPa':caps,'anchor_signed_force_error_N_Nmm':anchor['signed_force_N_Nmm'],
        'two_exact_rollbacks':True,'native_results':outputs,'physical_limit_confirmed':False}
    path=HERE/'Verification.json'
    path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(path,digest(path))


if __name__=='__main__':
    main()
