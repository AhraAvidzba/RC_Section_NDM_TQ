"""Recompute both native equilibria and verify the paired comparison."""

from argparse import ArgumentParser
from pathlib import Path
from zipfile import ZipFile
import json
import re
import runpy

from Prepare import ART, PRIVATE, ROOT, check, digest


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def verify_closure(variant, manifest):
    location = ROOT / variant
    native = location / "Native"
    closure = read(native / "KaniV4.txt.ProcessClosure.json")
    own = read(native / "KaniV4.txt.Ownership.json")
    compiler = read(native / "CompileClosure.json")
    compiled = read(location / "docs/regression/CodeUpdate.json")
    report = (native / "KaniV4.txt").read_text(encoding="utf-8-sig")
    terminal = closure["Closure"]["FinalState"]
    assert closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"] == 0
    assert closure["Closure"]["Passed"] and terminal["State"] == compiler["State"] == "Absent"
    assert not closure["Closure"]["OrdinaryPathKilledAnything"]
    assert own["VerifiedNewOwner"] and own["BeforeWorkbookOpen"]
    assert (terminal["PID"], terminal["StartTicksUTC"]) == (own["PID"], own["StartTicksUTC"])
    assert compiled["Compiled"] and not compiled["ProductionChanged"]
    assert sorted(compiled["Modules"]) == sorted(manifest["variants"][variant]["modules"])
    assert compiled["ProductionSHA256"] == manifest["bookSHA256"]
    assert compiled["WorkbookSHA256"] == digest(location / PRIVATE) == own["SourceSHA256"]
    compile_text = (native / "Compile.log").read_text(encoding="utf-8-sig")
    assert re.findall(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", compile_text, re.M) == [
        (str(compiler["PID"]), compiler["StartTicksUTC"])
    ]
    assert "TOTAL_KANI_V4_STAGE38: passed=1; failed=0" in report
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in report
    phases = [json.loads(line) for line in (native / "Preflight.ndjson").read_text(encoding="utf-8-sig").splitlines()]
    assert [phase["phase"] for phase in phases] == ["PreCompile", "PreNative"]
    for phase in phases:
        assert phase["RAMMiB"] >= 6500 and phase["FreeCommitGiB"] >= 8 and phase["FreeCMiB"] >= 80
        assert all(process["ProtectedUser"] for process in phase["Excel"])
    protected = {process["PID"] for phase in phases for process in phase["Excel"]}
    assert compiler["PID"] not in protected and terminal["PID"] not in protected
    return {"compile": compiler, "native": terminal, "modules": sorted(compiled["Modules"]),
            "privateSHA256": compiled["WorkbookSHA256"],
            "solverSHA256": manifest["variants"][variant]["solverSHA256"],
            "concreteSHA256": manifest["variants"][variant]["concreteSHA256"]}


def case(repo, variant, manifest):
    # Reuse the exact section, station and rollback oracle of §351.
    namespace = runpy.run_path(str(ROOT / "Verify-Alt.py"))
    verify = namespace["verify"]

    def open_archived(repo, name):
        path = repo / ART / name
        assert digest(path) == manifest["supportArchives"][name]
        return ZipFile(path)

    verify.__globals__.update(
        H=ROOT / variant,
        Z=ROOT / variant / "Native",
        P={"check": lambda given: check(given), "sha": digest, "open_art": open_archived},
        verify_closure=lambda prep: verify_closure(variant, prep),
    )
    return verify(repo)


def compare(results, manifest):
    a = results["A"]
    compared_name = next(name for name in results if name != "A")
    b = results[compared_name]
    assert a["workbookSHA256"] == b["workbookSHA256"] == manifest["bookSHA256"]
    assert a["originalH45Tau_MPa"] == b["originalH45Tau_MPa"] == manifest["originalTauMPa"]
    assert a["ownedExcelClosure"]["privateSHA256"] != b["ownedExcelClosure"]["privateSHA256"]
    for field in ("Base45", "Zero45", "End45", "Restore45"):
        assert a["comparison89PlusFive"][field] == b["comparison89PlusFive"][field], field
    assert a["baselineAdjoint_N"] == b["baselineAdjoint_N"]
    for result in (a, b):
        assert result["unchangedReplay"] and result["finiteProbesExecuted"] == 1
        if result["rightShoulder"]["converged"]:
            assert result["comparison89PlusFive"]["Right"]["satisfiesFrozenH45Tau"]
    stock = a["rightShoulder"]
    refit = b["rightShoulder"]
    assert "Уточнённая касательная (шаг /64)" not in stock["diagnostic"]
    return {
        "verifiedPairedReplay": True,
        "sourceGit": manifest["sourceGit"],
        "workbookSHA256": manifest["bookSHA256"],
        "identicalCheckpointAndRollback": True,
        "baselineAdjoint_N": a["baselineAdjoint_N"],
        "refitWasReportedBySolver": "Уточнённая касательная (шаг /64)" in refit["diagnostic"],
        "right": {"A": stock, compared_name: refit},
        "rightEquilibria": {name: result["comparison89PlusFive"].get("Right") for name, result in results.items()},
        "variantReportsSHA256": {name: digest(ROOT / name / "AlternateVerification.json") for name in results},
        "scope": "A paired numerical replay of one requested deformation. Physical capacity remains a separate question.",
    }


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=ROOT.parent.parent)
    parser.add_argument("--variant", choices=("A", "B", "C", "Both", "CompareLocal"), default="Both")
    args = parser.parse_args()
    repo = args.repo_root.resolve()
    manifest = check(repo)
    variants = {"Both": "AB", "CompareLocal": "AC"}.get(args.variant, args.variant)
    results = {name: case(repo, name, manifest) for name in variants}
    if len(results) == 2:
        compared = compare(results, manifest)
        path = ROOT / ("ComparisonLocal.json" if args.variant == "CompareLocal" else "Comparison.json")
        path.write_text(json.dumps(compared, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf8")
        print(path, digest(path))
