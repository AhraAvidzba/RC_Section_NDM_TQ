"""Recompute A/B/C outputs from portable native receipts, without Excel."""

from argparse import ArgumentParser
from io import BytesIO, StringIO
from pathlib import Path
from zipfile import ZipFile
from contextlib import redirect_stdout
import json
import math
import subprocess

from Prepare import ART, BOOK, PRIVATE, ROOT, digest


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def blob(repo, revision, name):
    return subprocess.check_output(["git", "-C", str(repo), "cat-file", "blob", f"{revision}:{name}"])


def preparation(repo):
    manifest = read(ROOT / "Manifest.json")
    prep = read(ROOT / "Preparation.json")
    assert manifest["schema"] == "KaniH45RefitMatrix/v1"
    assert manifest["historicalGit"] == prep["sourceGit"]
    assert manifest["sourceWorkbookSHA256"] == prep["bookSHA256"]
    assert sorted(manifest["variants"]) == sorted(prep["variants"]) == list("ABC")
    assert all(digest(ROOT / name) == value for name, value in manifest["files"].items())
    for name, value in prep["frozen"].items():
        if name.endswith(".xlsm"):
            assert value == prep["bookSHA256"]
            assert not (ROOT / name).exists()
        else:
            assert manifest["files"][name] == value
    assert digest(blob(repo, prep["sourceGit"], BOOK.as_posix())) == prep["bookSHA256"]
    for name, value in prep["production"].items():
        data = blob(repo, prep["sourceGit"], name)
        normalized = data.replace(b"\r\n", b"\n")
        assert value in {digest(data), digest(normalized), digest(normalized.replace(b"\n", b"\r\n"))}, name
    for name, value in prep["supportArchives"].items():
        assert digest(blob(repo, prep["sourceGit"], (ART / name).as_posix())) == value
    return manifest, prep


def compare(expected, measured, path="result"):
    if isinstance(expected, dict):
        assert set(expected) == set(measured), path
        for key, value in expected.items():
            compare(value, measured[key], f"{path}.{key}")
    elif isinstance(expected, list):
        assert len(expected) == len(measured), path
        for index, pair in enumerate(zip(expected, measured)):
            compare(*pair, f"{path}[{index}]")
    elif isinstance(expected, float):
        assert math.isclose(expected, measured, rel_tol=2e-11, abs_tol=5e-13), (path, expected, measured)
    else:
        assert expected == measured, (path, expected, measured)


def oracle(code, path, output_name=None):
    source = path.read_text(encoding="utf-8-sig")
    if output_name:
        assert source.count("'AlternateVerification.json'") == 1
        source = source.replace("'AlternateVerification.json'", repr(output_name))
    if code == "pair":
        stock = 'assert compiled["WorkbookSHA256"] == digest(location / PRIVATE) == own["SourceSHA256"]'
        portable = 'assert compiled["WorkbookSHA256"] == own["SourceSHA256"] and not (location / PRIVATE).exists()'
        assert source.count(stock) == 1
        source = source.replace(stock, portable)
    ns = {"__file__": str(path), "__name__": "archived_kani_oracle"}
    exec(compile(source, str(path), "exec"), ns)
    return ns


def replay(repo):
    manifest, prep = preparation(repo)
    paired = oracle("pair", ROOT / "Verify.py")

    def open_archived(root, name):
        raw = blob(root, prep["sourceGit"], (ART / name).as_posix())
        assert digest(raw) == prep["supportArchives"][name]
        return ZipFile(BytesIO(raw))

    results = {}
    for variant in "ABC":
        location = ROOT / variant
        assert not (location / PRIVATE).exists()
        retained = read(location / "AlternateVerification.json")
        namespace = oracle("section", ROOT / "Verify-Alt.py", output_name="ReplayedVerification.json")
        verify = namespace["verify"]
        verify.__globals__.update(
            H=location,
            Z=location / "Native",
            P={"check": lambda _: prep, "sha": digest, "open_art": open_archived},
            verify_closure=lambda value: paired["verify_closure"](variant, value),
        )
        with redirect_stdout(StringIO()):
            replayed = verify(repo)
        compare(retained, replayed, variant)
        assert replayed["ownedExcelClosure"]["privateSHA256"] == manifest["variants"][variant]["compiledWorkbookSHA256"]
        results[variant] = replayed
    for variant, report in (("B", "Comparison.json"), ("C", "ComparisonLocal.json")):
        expected = read(ROOT / report)
        compared = paired["compare"]({"A": results["A"], variant: results[variant]}, prep)
        compare(expected, compared, report)
    return {
        "PASS": True,
        "sourceWorkbookSHA256": prep["bookSHA256"],
        "variants": {name: result["rightShoulder"] for name, result in results.items()},
        "historyExact": all(result["unchangedReplay"] for result in results.values()),
        "comparisonSHA256": {n: digest(ROOT / n) for n in ("Comparison.json", "ComparisonLocal.json")},
    }


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--repo-root", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.repo_root.resolve()), ensure_ascii=False, indent=2, allow_nan=False))
