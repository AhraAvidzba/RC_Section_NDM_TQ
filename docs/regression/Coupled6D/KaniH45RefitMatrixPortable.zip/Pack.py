"""Seal the completed native replay without including any workbooks."""

from argparse import ArgumentParser
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
import json

from Prepare import PRIVATE, ROOT, check, digest

NATIVE = (
    "Compile.log", "CompileClosure.json", "Preflight.ndjson", "KaniV4.txt",
    "KaniV4.txt.Ownership.json", "KaniV4.txt.ProcessClosure.json", "KaniV4.txt.RunnerCleanup.json",
    "KaniV4.txt.memory.json", "KaniV4.txt.stderr.log", "KaniV4.txt.stdout.log",
    "KaniV4Trace.csv", "KaniV4Stations.csv", "KaniV4Tangents.csv",
)
AB_SHA = "5B8DE1E22E1EEE5A98FAED2696B8AA5E8E3732252C4D056F36E9313CADED8A2D"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def pack(repo):
    prep = check(repo)
    assert sorted(prep["variants"]) == list("ABC")
    assert digest(ROOT / "Comparison.json") == AB_SHA
    ab, ac = (read(ROOT / name) for name in ("Comparison.json", "ComparisonLocal.json"))
    assert ab["verifiedPairedReplay"] and ac["verifiedPairedReplay"]
    assert ab["identicalCheckpointAndRollback"] and ac["identicalCheckpointAndRollback"]
    assert ab["sourceGit"] == ac["sourceGit"] == prep["sourceGit"]
    assert ab["workbookSHA256"] == ac["workbookSHA256"] == prep["bookSHA256"]
    assert ab["right"]["A"] == ac["right"]["A"]
    assert ab["refitWasReportedBySolver"]
    files = {name for name in prep["frozen"] if not name.endswith(".xlsm")}
    files.update(("Preparation.json", "Comparison.json", "ComparisonLocal.json", "Replay.py", "Pack.py", "Portable-README.md"))
    cases = {}
    for variant in "ABC":
        local = ROOT / variant
        report = local / "AlternateVerification.json"
        expected = ac if variant == "C" else ab
        result = read(report)
        compiled = read(local / "docs/regression/CodeUpdate.json")
        assert result["unchangedReplay"] and result["finiteProbesExecuted"] == 1
        assert result["rightShoulder"] == expected["right"][variant]
        assert expected["variantReportsSHA256"][variant] == digest(report)
        assert compiled["ProductionSHA256"] == prep["bookSHA256"] and not compiled["ProductionChanged"]
        assert compiled["Compiled"] and sorted(compiled["Modules"]) == sorted(prep["variants"][variant]["modules"])
        assert compiled["WorkbookSHA256"] == digest(local / PRIVATE)
        assert compiled["WorkbookSHA256"] == result["ownedExcelClosure"]["privateSHA256"]
        cases[variant] = {
            "compiledWorkbookSHA256": compiled["WorkbookSHA256"],
            "solverSHA256": prep["variants"][variant]["solverSHA256"],
            "concreteSHA256": prep["variants"][variant]["concreteSHA256"],
            "rightConverged": result["rightShoulder"]["converged"],
            "rightInternalStatus": result["rightShoulder"]["internalStatus"],
        }
        files.update((f"{variant}/AlternateVerification.json", f"{variant}/docs/regression/CodeUpdate.json"))
        files.update(f"{variant}/Native/{name}" for name in NATIVE)
    assert not any(name.lower().endswith((".xlsm", ".xlsx")) for name in files)
    assert all((ROOT / name).is_file() for name in files)
    manifest = {
        "schema": "KaniH45RefitMatrix/v1",
        "historicalGit": prep["sourceGit"],
        "sourceWorkbookSHA256": prep["bookSHA256"],
        "variants": cases,
        "files": {name: digest(ROOT / name) for name in sorted(files)},
    }
    folder = ROOT / "Portable"
    folder.mkdir(exist_ok=True)
    target = folder / "KaniH45RefitMatrixPortable.zip"
    stamp = (2026, 11, 16, 0, 0, 0)
    raw = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode("utf8")
    with ZipFile(target, "w", compression=ZIP_DEFLATED, compresslevel=9) as out:
        for name in sorted(files):
            out.writestr(ZipInfo(name, stamp), (ROOT / name).read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
        out.writestr(ZipInfo("Manifest.json", stamp), raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(target) as opened:
        assert opened.testzip() is None and len(opened.namelist()) == len(files) + 1
        assert set(opened.namelist()) == files | {"Manifest.json"}
        assert all(digest(opened.read(name)) == value for name, value in manifest["files"].items())
    print(target, digest(target), target.stat().st_size)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=ROOT.parent.parent)
    pack(parser.parse_args().repo_root.resolve())
