"""Seal the two Kani replay roots without starting Office."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import subprocess

ROOT = Path(__file__).resolve().parent
TIP = "1e1d0f4"
BOOK = Path("workbook/output/RC_Section_NDM.xlsm")
PRIVATE = Path("docs/regression/Diagnostic.xlsm")
SOLVER = Path("src/Solver/CCoupledNewtonSolver.cls")
MACRO = Path("tests/modTestKaniStage38.bas")
CONCRETE = Path("src/Materials/CCoupledConcreteResponse.cls")
BOOK_SHA = "A90C7A5E610C19D2C3CF0D7DB12831651DB12EEFD052E5DBED1378EE3C2C04FA"
STOCK_SHA = "9EC02E71D00DD083D2249126DA7F675D4531F143E4330182F04266C25789691E"
REFIT_SHA = "4A3FC414649C6E13E2B1CB8F15442AF8EA88F0CE7670FF2F0D97980660DDFC6F"
LOCAL_SHA = "3B9368A94209FA50E5E4EB4600A998E30C4E81CA00BBCC5A1F2CD7A9CCB6560A"
ART = Path("docs/regression/Coupled6D")
OLD = ART / "KaniH45AlternateControlPortable.zip"
OLD_SHA = "4A9CADBD73726D133E99B5EA1D58F1DB8DB574C45BC189470F8EEC856C911BD4"
INPUTS = ("KaniV4Input.csv", "KaniGaugeInput.csv", "H45DiscriminatingControl.csv",
          "DiscriminatingH45Measurement.json")
SCRIPTS = ("Prepare.py", "Run.ps1", "Verify.py")
COMMON = ("Prepare-Alt.py", "Verify-Alt.py")
PRODUCTION = (BOOK, SOLVER, Path("src/Solver/CCoupledElasticState.cls"),
              CONCRETE,
              Path("src/Materials/CCoupledReinforcedResponse.cls"))


def digest(value):
    return sha256(value.read_bytes() if isinstance(value, Path) else value).hexdigest().upper()


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args]).strip().decode("ascii")


def check(repo):
    manifest = json.loads((ROOT / "Preparation.json").read_text(encoding="utf8"))
    assert manifest["sourceGit"] == git(repo, "rev-parse", TIP)
    assert manifest["bookSHA256"] == BOOK_SHA == digest(repo / BOOK)
    assert manifest["baselineSolverSHA256"] == STOCK_SHA == digest(repo / SOLVER)
    assert manifest["candidateSolverSHA256"] == REFIT_SHA == digest(ROOT / "B" / SOLVER)
    assert manifest["comparisonArchiveSHA256"] == OLD_SHA == digest(repo / OLD)
    assert all(digest(repo / file) == expected for file, expected in manifest["production"].items())
    assert all(digest(repo / ART / name) == expected for name, expected in manifest["supportArchives"].items())
    assert all(digest(ROOT / name) == expected for name, expected in manifest["frozen"].items())
    assert not (ROOT / "A" / SOLVER).exists() and not (ROOT / "A/src").is_symlink()
    for variant in manifest["variants"]:
        right = ROOT / variant
        present = {p.stem for d in (right / "src", right / "tests") for p in d.rglob("*") if p.is_file()}
        assert present == set(manifest["variants"][variant]["modules"])
        for name in (*INPUTS, MACRO):
            assert digest(ROOT / "A" / name) == digest(ROOT / variant / name)
    if "C" in manifest["variants"]:
        assert manifest["variants"]["C"]["concreteSHA256"] == LOCAL_SHA == digest(ROOT / "C" / CONCRETE)
    return manifest


def stage(repo, include_c=False):
    assert ROOT.is_relative_to((repo / "tmp").resolve())
    assert git(repo, "rev-parse", "HEAD") == git(repo, "rev-parse", TIP)
    assert digest(repo / BOOK) == BOOK_SHA and digest(repo / SOLVER) == STOCK_SHA
    assert digest(repo / OLD) == OLD_SHA
    refit = repo / "tmp/kani-refit/CCoupledNewtonSolver.cls"
    assert digest(refit) == REFIT_SHA
    assert not (ROOT / "Preparation.json").exists()
    assert all(not (ROOT / variant).exists() for variant in "ABC")
    with ZipFile(repo / OLD) as archive:
        archived = json.loads(archive.read("Preparation.json").decode("utf-8-sig"))
        files = {Path(name): archive.read(name) for name in (*INPUTS, *COMMON, MACRO.as_posix())}
    for name in (*INPUTS, MACRO.as_posix(), *COMMON):
        assert digest(files[Path(name)]) == archived["frozen"][name]
    tool_paths = [Path(name) for name in archived["frozen"] if name.startswith("tools/") and
                  not name.endswith("Update-IsolatedOptimizerCode.ps1")]
    for path in tool_paths:
        content = (repo / path).read_bytes()
        stored = subprocess.check_output(["git", "-C", str(repo), "cat-file", "blob", f"{TIP}:{path.as_posix()}"])
        assert content.replace(b"\r\n", b"\n") == stored.replace(b"\r\n", b"\n"), path
        files[path] = content
    for name in COMMON:
        (ROOT / name).write_bytes(files.pop(Path(name)))
    frozen = {name: digest(ROOT / name) for name in (*SCRIPTS, *COMMON)}
    variants = {}
    baseline = (repo / BOOK).read_bytes()
    matrix = "ABC" if include_c else "AB"
    if include_c:
        local = repo / "tmp/kanlocal" / CONCRETE
        assert digest(local) == LOCAL_SHA
    for variant in matrix:
        location = ROOT / variant
        for folder in ("src", "tests", "Native", "Temp", "docs/regression"):
            (location / folder).mkdir(parents=True, exist_ok=True)
        variant_files = {**files, BOOK: baseline}
        if variant == "B":
            variant_files[SOLVER] = refit.read_bytes()
        if variant == "C":
            variant_files[CONCRETE] = local.read_bytes()
        for name, content in variant_files.items():
            destination = location / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(content)
            frozen[destination.relative_to(ROOT).as_posix()] = digest(content)
        (location / PRIVATE).write_bytes(baseline)
        modules = ["modTestKaniStage38"]
        if variant == "B":
            modules.insert(0, "CCoupledNewtonSolver")
        if variant == "C":
            modules.insert(0, "CCoupledConcreteResponse")
        variants[variant] = {"modules": modules, "solverSHA256": REFIT_SHA if variant == "B" else STOCK_SHA,
                             "concreteSHA256": LOCAL_SHA if variant == "C" else digest(repo / CONCRETE)}
    manifest = {
        "sourceGit": git(repo, "rev-parse", TIP),
        "bookSHA256": BOOK_SHA,
        "baselineSolverSHA256": STOCK_SHA,
        "candidateSolverSHA256": REFIT_SHA,
        "comparisonArchiveSHA256": OLD_SHA,
        "supportArchives": archived["inputZIP_SHA256"],
        "originalTauMPa": archived["originalTauMPa"],
        "finiteProbes": 1,
        "maxIterations": 12,
        "timeoutSeconds": 180,
        "variants": variants,
        "production": {name.as_posix(): digest(repo / name) for name in PRODUCTION},
        "frozen": dict(sorted(frozen.items())),
    }
    (ROOT / "Preparation.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf8")
    return check(repo)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=ROOT.parent.parent)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--include-c", action="store_true")
    args = parser.parse_args()
    root = args.repo_root.resolve()
    if args.check:
        check(root)
    else:
        stage(root, args.include_c)
    print(digest(ROOT / "Preparation.json"))
