# Запускает одинаковый сценарий Kani на двух изолированных книгах.
param(
    [string]$RepoRoot=(Join-Path $PSScriptRoot '../..'),
    [ValidateSet('A','B','C','Both')][string]$Variant='Both',
    [string]$DependencyPath='D:/CodexScratch/RC_Section_NDM_TQ/FocusedVerifierDeps'
)
$ErrorActionPreference='Stop'
$repo=(Resolve-Path -LiteralPath $RepoRoot).Path
& python -B -X utf8 (Join-Path $PSScriptRoot 'Prepare.py') --repo-root $repo --check
if ($LASTEXITCODE) {throw 'Не подтверждены входы парного прогона.'}
$prep=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Preparation.json') -Raw | ConvertFrom-Json
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$protected=@{9552=[long]639304334673501852;25900=[long]639301894503450644}

# Сверяет идентичность пользовательского Excel и общий запас перед каждым запуском.
function Assert-PrivateOfficeReserve([string]$phase) {
    $apps=@(Get-Process Excel -ErrorAction SilentlyContinue)
    $states=@(foreach ($app in $apps) {
        if (!$app.StartTime) {throw "Не установлено время запуска Excel PID $($app.Id)."}
        $ticks=$app.StartTime.ToUniversalTime().Ticks
        $confirmed=$protected.ContainsKey($app.Id) -and $protected[$app.Id] -eq $ticks
        if (!$confirmed) {
            $owner=Get-CimInstance Win32_Process -Filter ('ProcessId='+$app.Id)
            if ($owner -and $app.MainWindowHandle -and [Math]::Abs(($owner.CreationDate-$app.StartTime).TotalMilliseconds) -lt 100) {
                $launcher=Get-Process -Id $owner.ParentProcessId -ErrorAction SilentlyContinue
                if ($launcher -and $launcher.ProcessName -ieq 'explorer' -and $owner.SessionId -eq $app.SessionId -and
                    $launcher.SessionId -eq $app.SessionId -and $launcher.StartTime -lt $app.StartTime -and
                    $owner.CommandLine -notmatch '[/\-]embedding(?:\s|$)') {
                    $protected[$app.Id]=$ticks
                    $confirmed=$true
                }
            }
        }
        [ordered]@{PID=$app.Id;StartTicksUTC=[string]$ticks;ProtectedUser=[bool]$confirmed}
    })
    $memory=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
    $log=[ordered]@{phase=$phase;UTC=[DateTimeOffset]::UtcNow.ToString('o');RAMMiB=$memory.AvailableMBytes;
        FreeCommitGiB=($memory.CommitLimit-$memory.CommittedBytes)/1GB;FreeCMiB=(Get-PSDrive -Name C).Free/1MB;Excel=$states}
    $log|ConvertTo-Json -Depth 5 -Compress|Add-Content -LiteralPath 'Native/Preflight.ndjson' -Encoding utf8
    if (@($states | Where-Object {!$_.ProtectedUser}).Count -or $log.RAMMiB -lt 6500 -or
        $log.FreeCommitGiB -lt 8 -or $log.FreeCMiB -lt 80) {throw "Нет безопасного окна для $phase."}
}

# Компилирует ровно модули выбранного варианта, выполняет штатный макрос и сохраняет сырые данные.
function Invoke-KaniVariant([string]$name) {
    if (!$prep.variants.$name) {throw "Вариант $name отсутствует в зафиксированной паре."}
    $location=Join-Path $PSScriptRoot $name
    $savedTemp=$env:TEMP
    $savedTmp=$env:TMP
    Push-Location -LiteralPath $location
    try {
        $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
        $env:TMP=$env:TEMP
        if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
            throw "Слишком длинный путь Excel в варианте $name."
        }
        $draft='docs/regression/Diagnostic.xlsm'
        $report='Native/KaniV4.txt'
        $compile='Native/Compile.log'
        if ((Get-FileHash -LiteralPath $draft).Hash -cne $prep.bookSHA256 -or (Test-Path -LiteralPath $report) -or
            (Test-Path -LiteralPath $compile)) {throw "Требуется исходная частная копия $name."}
        $components=@($prep.variants.$name.modules)
        Assert-PrivateOfficeReserve 'PreCompile'
        & './tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $draft -ModuleNames $components |
            Tee-Object -FilePath $compile
        $lines=@(Get-Content -LiteralPath $compile | Where-Object {$_ -match '^OWNED_EXCEL: id=\d+; utcStartTicks=\d+$'})
        if ($lines.Count -ne 1 -or $lines[0] -notmatch '^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$') {
            throw "Не подтверждён владелец компиляции $name."
        }
        $compilerId=[int]$Matches[1]
        $compilerTicks=[long]$Matches[2]
        if ($protected.ContainsKey($compilerId)) {throw 'Компилятор использовал защищённый Excel.'}
        $endedAt=[DateTime]::UtcNow.AddSeconds(20)
        do {
            $worker=Get-Process -Id $compilerId -ErrorAction SilentlyContinue
            if (!$worker) {break}
            if (!$worker.StartTime -or $worker.StartTime.ToUniversalTime().Ticks -ne $compilerTicks) {
                throw 'Изменилась идентичность Excel компиляции.'
            }
            Start-Sleep -Milliseconds 200
        } while ([DateTime]::UtcNow -lt $endedAt)
        if ($worker) {throw 'Excel компиляции ещё открыт.'}
        [ordered]@{State='Absent';PID=$compilerId;StartTicksUTC=[string]$compilerTicks}|ConvertTo-Json|
            Set-Content -LiteralPath 'Native/CompileClosure.json' -Encoding utf8
        $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
        if (!$compiled.Compiled -or $compiled.ProductionChanged -or $compiled.ProductionSHA256 -cne $prep.bookSHA256 -or
            $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or
            (($compiled.Modules | Sort-Object) -join ',') -cne (($components | Sort-Object) -join ',')) {
            throw "Не подтверждена частная сборка $name."
        }
        Assert-PrivateOfficeReserve 'PreNative'
        $commands=@('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-Audit03Watchdog.ps1',
            '-SourceWorkbook',$draft,'-ReportPath',$report,'-Macro','modTestKaniStage38.RunTestKaniStage38',
            '-MacroArgument1',(Join-Path $location 'KaniV4Input.csv'),'-TimeoutSeconds',[string]$prep.timeoutSeconds,'-FailFast')
        & $legacy @commands
        $nativeExit=$LASTEXITCODE
        $fixture=@(Get-Content -LiteralPath $report | Where-Object {$_ -like 'FIXTURE: *'})
        if ($fixture.Count -ne 1) {throw "В отчёте $name нет пути к изолированной книге."}
        $folder=[IO.Path]::GetFullPath((Split-Path -Parent $fixture[0].Substring(9)))
        if (!$folder.StartsWith($env:TEMP+'\RC_NDM_ModeSuite_',[StringComparison]::OrdinalIgnoreCase)) {
            throw 'Путь нативного протокола вышел за границы частной копии.'
        }
        foreach ($file in ('KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv')) {
            $source=Join-Path $folder $file
            if (Test-Path -LiteralPath $source) {Copy-Item -LiteralPath $source -Destination (Join-Path 'Native' $file)}
        }
        if ($nativeExit) {throw "Нативный сценарий $name завершился с кодом $nativeExit."}
    }
    finally {
        $env:TEMP=$savedTemp
        $env:TMP=$savedTmp
        Pop-Location
    }
}

if ($Variant -eq 'Both') {
    Invoke-KaniVariant 'A'
    Invoke-KaniVariant 'B'
} else {
    Invoke-KaniVariant $Variant
}
$originalPythonPath=$env:PYTHONPATH
try {
    if ($DependencyPath) {
        $dependencies=(Resolve-Path -LiteralPath $DependencyPath).Path
        $env:PYTHONPATH=(@($dependencies,$originalPythonPath) | Where-Object {$_}) -join [IO.Path]::PathSeparator
    }
    & python -B -X utf8 (Join-Path $PSScriptRoot 'Verify.py') --repo-root $repo --variant $Variant
    if ($LASTEXITCODE) {throw 'Независимая проверка завершилась ошибкой.'}
}
finally {$env:PYTHONPATH=$originalPythonPath}
