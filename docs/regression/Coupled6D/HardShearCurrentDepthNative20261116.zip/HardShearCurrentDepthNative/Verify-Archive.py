"""Replay the current HardShear extended-budget trace from detached evidence."""

import argparse
from collections import Counter
import csv
from decimal import Decimal as D, getcontext
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from xml.etree import ElementTree
from zipfile import ZipFile
from zlib import crc32

from ReadChart import CHART_NS, cached_coordinates


HERE = Path(__file__).resolve().parent
FIXTURE = "DD61C6DFD7B6A5E691713F7EFF1B79502E23517364B775E76F30565DBD4D0663"
VERIFICATION = "C941CE97A583A09C08F7193E006C7A58A9A55D6232C5F017BBB6C10782B4FB25"
SOURCE_BOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
COMPILED_BOOK = "2A5E9B6E93665BED9B813CA22AFC658383099C10C460AA6E4214DEE6F4D4E4EB"
SAVED_BOOK = "0615CACD8ADE4CC388599ACE3E68B95250AFA97A01C7A68AE535C325619FF69B"
CHART_SHA = "2030AA8FF4258581DE65EB98E6B1091E297FC0723E37617AC8104BE815868933"
SOURCE = {
    "src/Solver/CCoupledDeformationContinuation.cls": "2B62885FEE84C436C543BAA7BAFB0CA172196A3873DD83D05378BAA6D10AABE2",
    "tests/modTestCoupledElasticState.bas": "2451F24F8661DA1C1C66E96192A349EB677C96BC01AC7944F20D1D5BFCD35E47",
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def obj(path):
    return json.loads((HERE / path).read_bytes())


def once(text, start, replacement):
    assert text.count(start) == 1
    return text.replace(start, replacement)


def build(original, fragment):
    return (original + "\n" + fragment).rstrip().replace("\n", "\r\n").encode("utf-8") + b"\r\n"


def reconstruct(fixture):
    assert fixture["source_revision"] == "c9e7268" and fixture["budget"] == 640
    assert fixture["source_workbook_sha256"] == SOURCE_BOOK
    for name, expected in fixture["inputs"].items():
        assert digest(HERE / name) == expected, name
    for name, expected in SOURCE.items():
        assert digest(HERE / "Baseline" / name) == expected
    solver, test = SOURCE
    original = (HERE / "Baseline" / solver).read_text(encoding="utf-8-sig")
    solver_code = once(original, "Private Const PROBE_LIMIT As Long = 96", "Private Const PROBE_LIMIT As Long = 640")
    solver_code = once(
        solver_code,
        "            If trial.Lambda <= 0# Then\n                mSolver.DiscardStep",
        '            If trial.Lambda <= 0# Then\n'
        '                Dim boundaryField() As Double, boundaryLoads() As Double\n'
        '                mSolver.CopyTrial boundaryField, boundaryLoads\n'
        '                RecordDepthFieldTest history.Count + 1, trial, boundaryField, boundaryLoads, "Boundary"\n'
        '                mSolver.DiscardStep',
    )
    solver_code = once(
        solver_code, "    If Not solved Then\n        mProbeDetails",
        ('    If solved Then TraceDepthRowTest "Probe;" & CStr(mProbeCount) & ";1" '
         'Else TraceDepthRowTest "Probe;" & CStr(mProbeCount) & ";0"\n'
         '    If Not solved Then\n        mProbeDetails'),
    )
    solver_code = once(
        solver_code, "    mSolver.CopyTrial field, mCurrentResultants\n    mSolver.AcceptStep",
        '    mSolver.CopyTrial field, mCurrentResultants\n'
        '    RecordDepthFieldTest history.Count + 1, point, field, mCurrentResultants, "Accept"\n'
        '    mSolver.AcceptStep',
    )
    assert build(solver_code, (HERE / "SolverProbe.bas").read_text(encoding="utf-8")) == (HERE / solver).read_bytes()
    original_test = (HERE / "Baseline" / test).read_text(encoding="utf-8-sig")
    assert build(original_test, (HERE / "NativeProbe.bas").read_text(encoding="utf-8")) == (HERE / test).read_bytes()


def native():
    compiled = obj("docs/regression/CodeUpdate.json")
    assert compiled["Compiled"] and not compiled["ProductionChanged"] and not compiled["RetiredModules"]
    assert compiled["ProductionSHA256"] == SOURCE_BOOK and compiled["WorkbookSHA256"] == COMPILED_BOOK
    assert sorted(compiled["Modules"]) == ["CCoupledDeformationContinuation", "modTestCoupledElasticState"]
    compiler = obj("CompileClosure.json")
    compile_log = (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    pid = re.findall(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", compile_log, re.M)
    assert pid == [(str(compiler["PID"]), compiler["StartTicksUTC"])] and compiler["State"] == "Absent"
    assert "PRIVATE_CODE_READY: modules=2; production unchanged=True" in compile_log
    log = HERE / "Native/HardShear.txt"
    raw = log.read_text(encoding="utf-8-sig")
    assert re.search(r"^SOURCE_SHA256: " + COMPILED_BOOK + "$", raw, re.M)
    assert "===== modTestCoupledElasticState.RunTestHardShearCurrentDepth =====" in raw
    assert "SOURCE_UNCHANGED: True" in raw and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in raw
    assert "TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0" in raw
    assert "TOTAL_HARD_SHEAR_CURRENT_DEPTH: passed=1; failed=0" in raw
    assert not re.search(r"^(?:FAIL|RUNTIME ERROR):", raw, re.M)
    owner = obj("Native/HardShear.txt.Ownership.json")
    receipt = obj("Native/HardShear.txt.ProcessClosure.json")
    identity = str(owner["PID"]), owner["StartTicksUTC"]
    assert pid != [identity] and owner["BeforeWorkbookOpen"] and owner["VerifiedNewOwner"]
    assert owner["SourceSHA256"] == COMPILED_BOOK
    assert re.findall(r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$", raw, re.M) == [identity]
    assert receipt["Passed"] and receipt["ChildHasExited"] and receipt["ChildExitCode"] == 0
    assert receipt["RunnerCleanupValid"] and not receipt["OrdinaryPathKilledAnything"]
    final = receipt["Closure"]["FinalState"]
    assert final["State"] == "Absent" and (str(final["PID"]), final["StartTicksUTC"]) == identity
    states = re.search(r"^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([^;]+); limit=; code=NUMERICAL_FAILURE$", raw, re.M)
    time = re.search(r"^TIMING_SECONDS: ([\d.]+) \| Both \| Excel$", raw, re.M)
    reopen = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", raw, re.M)
    assert states and time and reopen
    assert "вышел из области положительной нагрузки" in raw
    assert "OK: native marker does not claim a limit for NumFail" in raw
    assert re.findall(r"^OK: no unconfirmed limit component (\S+)$", raw, re.M) == ["N", "Mx", "My", "T", "Qx", "Qy"]
    return float(states[1]), float(time[1]), reopen[1], reopen[2], digest(log)


def chart(path_on_report, optional_workbook):
    rec = obj("WorkbookChartPart.json")
    assert rec["original_logged_path"] == path_on_report and rec["saved_workbook_sha256"] == SAVED_BOOK
    assert rec["part"] == "xl/charts/chart4.xml" and rec["part_sha256"] == CHART_SHA
    path = HERE / "Native/chart4.xml"
    binary = path.read_bytes()
    assert digest(path) == CHART_SHA and crc32(binary) == rec["zip_crc32"] and len(binary) == rec["size"]
    if optional_workbook is not None:
        assert digest(optional_workbook) == SAVED_BOOK
        with ZipFile(optional_workbook) as saved:
            part = saved.getinfo(rec["part"])
            assert saved.read(part) == binary and part.CRC == rec["zip_crc32"]
            assert part.compress_size == rec["compressed_size"]
    root = ElementTree.fromstring(binary)
    series = {}
    for entry in root.findall(".//c:ser", CHART_NS):
        name = entry.findtext("./c:tx//c:v", namespaces=CHART_NS)
        assert name not in series
        series[name] = tuple(cached_coordinates(entry, axis) for axis in ("xVal", "yVal"))
    assert set(series) == {"Заданные усилия", "Заданная точка", "Поиск предела", "Последняя точка поиска"}
    steps, values = series["Поиск предела"]
    assert steps == list(range(1, 497)) and min(values) > 0
    assert series["Заданные усилия"][1] == [.25, .5, .75, 1.]
    assert series["Заданная точка"] == ([4.], [1.])
    assert series["Последняя точка поиска"] == ([steps[-1]], [values[-1]])
    return rec["part"], values


def trace(values):
    path = HERE / "Native/CurrentDepth.csv"
    with path.open(encoding="ascii", newline="") as stream:
        rows = list(csv.reader(stream, delimiter=";"))
    counts = Counter(row[0] for row in rows)
    assert counts == {"Probe": 533, "Accept": 489, "Boundary": 1}
    probes = {int(row[1]): row[2] for row in rows if row[0] == "Probe"}
    assert list(probes) == list(range(1, 534)) and set(probes.values()) <= {"0", "1"}
    direction = tuple(map(D, (28000, 510000, 180000, 1500000, 17000, -7100)))
    area, moment = D(21600), D("2219577.365175632")
    scales = (area, moment, moment, moment, area, area)
    relative = max(abs(component / scale) for component, scale in zip(direction, scales, strict=True))
    points, replaced = [], []
    for row in rows:
        if row[0] == "Probe":
            continue
        kind, number, index, coordinate, factor, steel, _ = row[:7]
        number, index = int(number), int(index)
        assert len(row) == 79 and probes[number] == "1"
        coordinate, factor, steel = D(coordinate), D(factor), D(steel)
        assert all(D(value).is_finite() for value in row[19:])
        residual, intervals = D(0), []
        budget = D("5e-7") * (1 + abs(factor) * relative)
        for desired, stored, component, scale in zip(map(D, row[7:13]), map(D, row[13:19]), direction, scales, strict=True):
            assert abs(desired - component * factor) <= (1 + abs(desired)) * D("5e-13")
            residual = max(residual, abs(stored - desired) / scale)
            endpoints = ((stored - budget * scale) / component, (stored + budget * scale) / component)
            intervals.append((min(endpoints), max(endpoints)))
        low, high = max(pair[0] for pair in intervals), min(pair[1] for pair in intervals)
        assert low <= factor <= high and residual <= budget
        if kind == "Accept":
            assert 1 <= index <= len(values)
            charted = D(str(values[index-1]))
            if abs(factor - charted) >= D("5e-14"):
                replaced.append((number, index, factor, charted))
        points.append({"kind": kind, "probe": number, "field": index, "coordinate": coordinate,
                       "lambda": factor, "lambda_interval": (low, high), "six_force_residual_MPa": residual,
                       "steel_utilization": steel})
    assert len(points) == 490 and points[-1]["kind"] == "Boundary" and points[-2]["kind"] == "Accept"
    # The raw trace precedes shoulder replay. The saved graph publishes the refined prefix.
    assert replaced == [(21, 8, D("1.10290854146333"), D("1.1023815758071516"))]
    assert sorted(set(range(1, 497)) - {p["field"] for p in points[:-1]}) == [1, 2, 3, 4, 9, 10, 11]
    assert [p["field"] for p in points[-2:]] == [496, 497] and [p["probe"] for p in points[-2:]] == [532, 533]
    assert points[-1]["coordinate"] > points[-2]["coordinate"]
    assert points[-1]["lambda_interval"][1] < 0 < points[-2]["lambda_interval"][0]
    return counts, points, digest(path)


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--saved-workbook", type=Path, help="also inspect the original saved workbook used to extract chart4.xml")
    args = parser.parse_args()
    getcontext().prec = 42
    for name, expected in obj("SHA256SUMS.json").items():
        assert digest(HERE / name) == expected, name
    assert digest(HERE / "Fixture.json") == FIXTURE
    reconstruct(obj("Fixture.json"))
    factor, seconds, reopened, original_path, log = native()
    part, values = chart(original_path, args.saved_workbook)
    counts, points, trace_sha = trace(values)
    peak = max(values)
    assert abs(peak - factor) < 5e-13 and values.index(peak) == 8
    descent = values[8:]
    assert all(b < a for a, b in zip(descent, descent[1:]))
    result = {"source_workbook_sha256": SOURCE_BOOK, "diagnostic_workbook_sha256": COMPILED_BOOK,
              "verified_results_reopen": reopened, "saved_workbook_sha256": SAVED_BOOK, "saved_chart_part": part,
              "trace_sha256": trace_sha, "native_log_sha256": log, "extended_budget": 640, "counts": counts,
              "diagnostic_seconds": seconds, "confirmed_lower_lambda": peak, "positive_graph_points": len(values),
              "monotonic_after_peak": True, "maximum_steel_use": max(point["steel_utilization"] for point in points),
              "final_points": points[-2:], "verified_exit_from_positive_ray": True, "physical_capacity_certified": False}
    report = HERE / "Native/Verification.json"
    assert digest(report) == VERIFICATION and json.loads(json.dumps(result, default=str)) == obj("Native/Verification.json")
    print("PASS CURRENT HARD SHEAR DEPTH", VERIFICATION,
          "533 probes, 496 accepted chart fields, coarse H8 replaced, positive ray exited")


if __name__ == "__main__":
    main()
