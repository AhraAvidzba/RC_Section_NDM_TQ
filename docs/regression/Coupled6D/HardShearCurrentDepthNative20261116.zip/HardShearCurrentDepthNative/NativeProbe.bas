' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выполняет один штатный расчёт в изолированной книге с расширенным бюджетом.
Public Function RunTestHardShearCurrentDepth() As String
    Dim report As String
    report = RunTestCoupledWorkbookTiming("Both", "Excel")
    If InStr(1, report, "RUNTIME ERROR:", vbBinaryCompare) > 0 Then
        RunTestHardShearCurrentDepth = report
        Exit Function
    End If
    RunTestHardShearCurrentDepth = report & vbCrLf & "TOTAL_HARD_SHEAR_CURRENT_DEPTH: passed=1; failed=0"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает численные данные только рядом с нативной тестовой копией.
Public Sub TraceDepthRowTest(ByVal row As String)
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, "TraceDepthRowTest", "Запись ветви предназначена для изолированной книги."
    Dim channel As Integer: channel = FreeFile
    Open ThisWorkbook.Path & "\CurrentDepth.csv" For Append As #channel
    Print #channel, row
    Close #channel
End Sub
