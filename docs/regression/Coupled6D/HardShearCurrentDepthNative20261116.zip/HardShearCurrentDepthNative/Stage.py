"""Подготавливает пробу увеличенного бюджета на установленной сборке."""

from hashlib import sha256
import json
from pathlib import Path

here = Path(__file__).resolve().parent
repo = here.parents[1]
baseline = here.parent / "dsl"
book = "workbook/output/RC_Section_NDM.xlsm"
solver = "src/Solver/CCoupledDeformationContinuation.cls"
test = "tests/modTestCoupledElasticState.bas"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, content):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == content, path
    else:
        path.write_bytes(content)
    return digest(content)


def once(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


def code(source):
    return source.rstrip().replace("\n", "\r\n").encode("utf-8") + b"\r\n"


installed = (repo / book).read_bytes()
workbook = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
assert digest(installed) == workbook
save(book, installed)
save("docs/regression/Diagnostic.xlsm", installed)
for folder in ("Temp", "Native"):
    (here / folder).mkdir(exist_ok=True)
inputs = {}
for name in ("Guard-IsolatedOffice.ps1",):
    inputs[name] = save(name, (baseline / name).read_bytes())
chart_reader = repo / "docs/regression/Audit03/LocalGradientDerivative20261115/ProductionYieldRecovery/VerifySavedHardShearChart.py"
chart_source = chart_reader.read_bytes()
assert digest(chart_source) == "DADF3AC47CEC5BA09A8A60AC8B8985439CACDDC1094ACF48AAA4714989EDFEFA"
inputs["ReadChart.py"] = save("ReadChart.py", chart_source)
fixture = json.loads((here.parent / "dsi/Fixture.json").read_bytes())
for name, sha in fixture["frozen"].items():
    if not name.startswith("tools/build_workbook/"):
        continue
    raw = (repo / name).read_bytes()
    assert digest(raw) == sha, name
    inputs[name] = save(name, raw)

src = (repo / solver).read_text(encoding="utf-8-sig")
src = once(src, "Private Const PROBE_LIMIT As Long = 96", "Private Const PROBE_LIMIT As Long = 640")
src = once(src, '            If trial.Lambda <= 0# Then\n                mSolver.DiscardStep', '''            If trial.Lambda <= 0# Then
                Dim boundaryField() As Double, boundaryLoads() As Double
                mSolver.CopyTrial boundaryField, boundaryLoads
                RecordDepthFieldTest history.Count + 1, trial, boundaryField, boundaryLoads, "Boundary"
                mSolver.DiscardStep''')
src = once(src, "    If Not solved Then\n        mProbeDetails", '''    If solved Then TraceDepthRowTest "Probe;" & CStr(mProbeCount) & ";1" Else TraceDepthRowTest "Probe;" & CStr(mProbeCount) & ";0"
    If Not solved Then
        mProbeDetails''')
src = once(src, "    mSolver.CopyTrial field, mCurrentResultants\n    mSolver.AcceptStep", '''    mSolver.CopyTrial field, mCurrentResultants
    RecordDepthFieldTest history.Count + 1, point, field, mCurrentResultants, "Accept"
    mSolver.AcceptStep''')
src += "\n" + (here / "SolverProbe.bas").read_text(encoding="utf-8")
inputs[solver] = save(solver, code(src))
src = (repo / test).read_text(encoding="utf-8-sig")
src += "\n" + (here / "NativeProbe.bas").read_text(encoding="utf-8")
inputs[test] = save(test, code(src))
for name in ("Run.ps1", "Verify.py", "Stage.py", "SolverProbe.bas", "NativeProbe.bas"):
    inputs[name] = digest((here / name).read_bytes())
manifest = {"source_workbook_sha256": workbook, "source_revision": "c9e7268", "budget": 640, "inputs": inputs}
print(save("Fixture.json", (json.dumps(manifest, indent=2) + "\n").encode()))
