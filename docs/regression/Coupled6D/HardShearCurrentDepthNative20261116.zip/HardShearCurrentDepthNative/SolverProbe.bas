' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт нагрузки и поле уже уравновешенной пробы диагностическому сценарию.
Private Sub RecordDepthFieldTest(ByVal index As Long, ByRef point As TBranchPoint, _
        ByRef field() As Double, ByRef actual() As Double, ByVal kind As String)
    Dim i As Long, row As String, utilization As Double
    If Not mReinforcement Is Nothing Then utilization = mReinforcement.TrialSteelUtilization
    row = kind & ";" & CStr(mProbeCount) & ";" & CStr(index) & ";" & Trim$(Str$(point.Coordinate)) & ";" & _
        Trim$(Str$(point.Lambda)) & ";" & Trim$(Str$(utilization)) & ";" & CStr(mFollowingLocalPeak)
    For i = 1 To COMPONENT_COUNT: row = row & ";" & Trim$(Str$(mOffset(i) + point.Lambda * mDirection(i))): Next i
    For i = 1 To COMPONENT_COUNT: row = row & ";" & Trim$(Str$(actual(i))): Next i
    For i = LBound(field) To UBound(field): row = row & ";" & Trim$(Str$(field(i))): Next i
    TraceDepthRowTest row
End Sub
