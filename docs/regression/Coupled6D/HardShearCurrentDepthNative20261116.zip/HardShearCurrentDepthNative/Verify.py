"""Сверяет все шесть усилий длинной ветви и сохранённый график Excel."""

import argparse
from collections import Counter
from decimal import Decimal as D, getcontext
from hashlib import sha256
import json
from pathlib import Path
import re

from ReadChart import read_series


here = Path(__file__).resolve().parent
native = here / "Native"


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def obj(name):
    return json.loads((here / name).read_text(encoding="utf-8-sig"))


def verify(fixture):
    log = native / "HardShear.txt"
    trace = native / "CurrentDepth.csv"
    compile_info = obj("docs/regression/CodeUpdate.json")
    compiler = obj("CompileClosure.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    receipt = obj("Native/HardShear.txt.ProcessClosure.json")
    assert compile_info["Compiled"] and not compile_info["ProductionChanged"]
    assert compile_info["ProductionSHA256"] == fixture["source_workbook_sha256"]
    assert sorted(compile_info["Modules"]) == ["CCoupledDeformationContinuation", "modTestCoupledElasticState"]
    assert compiler["State"] == "Absent" and owner["SourceSHA256"] == compile_info["WorkbookSHA256"]
    ending = receipt["Closure"]["FinalState"]
    assert receipt["Passed"] and ending["State"] == "Absent" and receipt["ChildExitCode"] == 0
    assert owner["PID"] == ending["PID"] and owner["StartTicksUTC"] == ending["StartTicksUTC"]
    data = log.read_text(encoding="utf-8-sig")
    assert "TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0" in data
    assert "TOTAL_HARD_SHEAR_CURRENT_DEPTH: passed=1; failed=0" in data
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in data
    execution = re.search(r"^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([^;]+); limit=; code=NUMERICAL_FAILURE", data, re.M)
    saved = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", data, re.M)
    timing = re.search(r"^TIMING_SECONDS: ([\d.,]+) \| Both \| Excel$", data, re.M)
    assert execution and saved and timing
    native_book = Path(saved[2]).resolve()
    assert native_book.is_relative_to(here / "Temp")
    chart, series = read_series(native_book)
    indices, multipliers = series["Поиск предела"]
    assert indices == list(range(1, len(multipliers) + 1)) and series["Заданная точка"][1] == [1.]
    assert series["Последняя точка поиска"] == ([indices[-1]], [multipliers[-1]])
    peak = max(multipliers)
    assert abs(peak - float(execution[1].replace(",", "."))) < 5e-13
    assert all(x > 0 for x in multipliers)
    raw = [line.split(";") for line in trace.read_text(encoding="ascii").splitlines()]
    counts = Counter(line[0] for line in raw)
    assert set(counts) <= {"Probe", "Accept", "Boundary"} and counts["Probe"] > 96 and counts["Accept"] > 68
    indices = [int(row[1]) for row in raw if row[0] == "Probe"]
    assert indices == sorted(set(indices)) and indices[-1] <= fixture["budget"]
    direction = tuple(map(D, (28000, 510000, 180000, 1500000, 17000, -7100)))
    area, moment_scale = D(21600), D("2219577.365175632")
    scales = (area, moment_scale, moment_scale, moment_scale, area, area)
    scaled = max(abs(component / scale) for component, scale in zip(direction, scales, strict=True))
    points = []
    for row in raw:
        if row[0] == "Probe":
            continue
        assert len(row) == 79
        factor, coordinate, utilization = D(row[4]), D(row[3]), D(row[5])
        wanted, actual = tuple(map(D, row[7:13])), tuple(map(D, row[13:19]))
        check_budget = D("5e-7") * (1 + abs(factor) * scaled)
        normalized = max(abs(a - b) / s for a, b, s in zip(actual, wanted, scales, strict=True))
        assert normalized <= check_budget
        intervals = []
        for target, observed, s, f in zip(wanted, actual, scales, direction, strict=True):
            assert abs(target - factor * f) <= (1 + abs(target)) * D("5e-13")
            pair = ((observed - check_budget * s) / f, (observed + check_budget * s) / f)
            intervals.append((min(pair), max(pair)))
        left, right = max(pair[0] for pair in intervals), min(pair[1] for pair in intervals)
        assert left <= factor <= right and all(D(value).is_finite() for value in row[19:])
        points.append({"kind": row[0], "probe": int(row[1]), "field": int(row[2]), "coordinate": coordinate,
                       "lambda": factor, "lambda_interval": (left, right), "six_force_residual_MPa": normalized,
                       "steel_utilization": utilization})
    accepted = [point for point in points if point["kind"] == "Accept"]
    assert all(point["lambda"] > 0 for point in accepted)
    assert abs(float(accepted[-1]["lambda"]) - multipliers[-1]) < 5e-14
    assert counts["Boundary"] <= 1
    if counts["Boundary"]:
        assert "вышел из области положительной нагрузки" in data
        assert points[-1]["kind"] == "Boundary" and points[-2]["kind"] == "Accept"
        assert points[-1]["field"] == points[-2]["field"] + 1 and points[-1]["coordinate"] > points[-2]["coordinate"]
    descending = multipliers[multipliers.index(peak):]
    result = {"source_workbook_sha256": fixture["source_workbook_sha256"], "diagnostic_workbook_sha256": owner["SourceSHA256"],
              "verified_results_reopen": saved[1], "saved_workbook_sha256": digest(native_book), "saved_chart_part": chart,
              "trace_sha256": digest(trace), "native_log_sha256": digest(log), "extended_budget": fixture["budget"],
              "counts": counts, "diagnostic_seconds": float(timing[1].replace(",", ".")), "confirmed_lower_lambda": peak,
              "positive_graph_points": len(multipliers), "monotonic_after_peak": all(b<a for a,b in zip(descending, descending[1:])),
              "maximum_steel_use": max(point["steel_utilization"] for point in points), "final_points": points[-2:],
              "verified_exit_from_positive_ray": bool(counts["Boundary"] and points[-1]["lambda_interval"][1] < 0 < points[-2]["lambda_interval"][0]),
              "physical_capacity_certified": False}
    return result


if __name__ == "__main__":
    getcontext().prec = 42
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", action="store_true")
    config = obj("Fixture.json")
    assert all(digest(here / name) == value for name, value in config["inputs"].items())
    assert digest(here / "workbook/output/RC_Section_NDM.xlsm") == config["source_workbook_sha256"]
    if parser.parse_args().inputs:
        print("INPUTS", digest(here / "Fixture.json"))
    else:
        report = native / "Verification.json"
        report.write_bytes((json.dumps(verify(config), default=str, indent=2) + "\n").encode())
        print("CURRENT HARD SHEAR DEPTH", digest(report))
