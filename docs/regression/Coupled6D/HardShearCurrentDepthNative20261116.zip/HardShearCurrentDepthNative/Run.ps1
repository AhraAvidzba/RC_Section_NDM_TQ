# Запускает расширенный диагностический поиск только в выделенной книге.
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../..')).Path
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$report='Native/HardShear.txt'
Push-Location -LiteralPath $root
try {
    python -B -X utf8 'Verify.py' --inputs
    if ($LASTEXITCODE) {throw 'Входы HardShear не подтверждены.'}
    $data=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    if ((Get-FileHash -LiteralPath (Join-Path $repo 'workbook/output/RC_Section_NDM.xlsm')).Hash -cne $data.source_workbook_sha256) {throw 'Изменилась рабочая книга.'}
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Превышена длина пути фикстуры Excel.'
    }
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    if ((Test-Path -LiteralPath 'Compile.log') -or (Test-Path -LiteralPath $report)) {throw 'Проверка уже выполнялась.'}
    if ((Get-FileHash -LiteralPath $draft).Hash -cne $data.source_workbook_sha256) {throw 'Неверная начальная книга.'}
    Assert-IsolatedOfficeReady 'CompileHardShearCurrentDepth'
    & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft `
        -ModuleNames @('CCoupledDeformationContinuation','modTestCoupledElasticState') | Tee-Object -FilePath 'Compile.log'
    Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    Assert-IsolatedOfficeReady 'RunHardShearCurrentDepth'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $draft -ReportPath $report -Macro 'modTestCoupledElasticState.RunTestHardShearCurrentDepth' `
        -Mode No -TimeoutSeconds 190 -FailFast -VerifyResultsReopen
    if ($LASTEXITCODE) {throw 'Нативная проверка HardShear завершилась ошибкой.'}
    $origin=@(Get-Content -LiteralPath $report -Encoding utf8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($origin.Count -ne 1) {throw 'Нет однозначного пути к фикстуре.'}
    $folder=Split-Path -Parent $origin[0].Substring('FIXTURE: '.Length)
    if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Фикстура указана за рабочим каталогом.'}
    Copy-Item -LiteralPath (Join-Path $folder 'CurrentDepth.csv') -Destination 'Native/CurrentDepth.csv'
    python -B -X utf8 'Verify.py'
    if ($LASTEXITCODE) {throw 'Независимая сверка HardShear завершилась ошибкой.'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
