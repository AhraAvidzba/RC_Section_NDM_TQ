"""ДЛЯ ТЕСТОВ. Проверяет фактические рабочие классы, направленные регрессии и численные результаты общего адаптера."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


def TestFiles(root):
    """Все входы и исходные рабочие классы закреплены точными контрольными суммами."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == '411a80f'


def TestNative(repo, root, output):
    """Проверяет три действительных проекта, 430 направленных утверждений и закрытие только собственных процессов."""
    TestFiles(root)
    records, counts = {}, {}
    for key in ('Unit', 'Pair', 'Sequence'):
        folder = root / 'Cases' / key
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Code.json'
            run_path(str(root / 'Audit-TestGenericConstraintBook.py'))['TestAudit'](repo, folder, proof)
            record = json.loads(proof.read_bytes())
        assert (record['components'], record['imported'], record['unchanged']) == (250, 37, 213)
        assert len(record['checked_coupled_sources']) == 36 and record['compiled_project_storage'] == 'solid-exact-CFB'
        reports = ('ConstraintUnit',) if key == 'Unit' else ('ReversePolish', 'Core') if key == 'Sequence' else ('ReversePolish',)
        for report in reports:
            path = folder / 'Native' / (report + '.txt')
            log = path.read_text('utf-8-sig')
            assert 'RUNTIME ERROR:' not in log and '\nFAIL:' not in log
            assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
            source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
            assert source == record['compiled_workbook_sha256']
            closure = json.loads(path.with_name(path.name + '.ProcessClosure.json').read_bytes())
            assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
            assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
            totals = re.findall(r'^(TOTAL_[^:]+): passed=(\d+); failed=(\d+)', log, re.M)
            assert totals and all(int(failed) == 0 for _, _, failed in totals)
            counts[key + '/' + report] = {name: int(passed) for name, passed, _ in totals}
        records[key] = record
    assert counts['Unit/ConstraintUnit'] == {'TOTAL_COUPLED_CONSTRAINT_TEST': 12, 'TOTAL_COUPLED_HYBRID_TEST': 36}
    assert len(counts['Sequence/Core']) == 8 and sum(counts['Sequence/Core'].values()) == 382
    output.write_text(json.dumps({'projects': records, 'native_totals': counts, 'targeted_assertions': 430,
        'ordinary_solver_recovery_enabled': False, 'installed_workbook_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('THREE GENERIC CONSTRAINT VBA PROJECTS AND 430 TARGETED ASSERTIONS VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Проверяет успешные состояния и сохраняет фактическую неудачу крупного скачка без ослабления допусков."""
    TestFiles(root)
    results = {}
    jobs = (('Pair', 'Analyze-TestGenericConstraint.py'), ('Sequence', 'Analyze-TestGenericBridge.py'))
    for key, script in jobs:
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Analysis.json'
            run_path(str(root / script))['TestAnalyze'](root / 'Cases' / key, proof)
            results[key] = json.loads(proof.read_bytes())
    pair, sequence = results['Pair'], results['Sequence']
    assert pair['cases']['0']['strict_root_found'] and pair['existing_hybrid']['0']['strict_root_found']
    assert not pair['cases']['1']['strict_root_found'] and not pair['existing_hybrid']['1']['strict_root_found']
    assert sequence['accepted_steps'] == 4 and sequence['full_requested_sequence_completed']
    assert sequence['ordinary_bridge']['accepted_steps'] == 2 and sequence['ordinary_bridge']['full_requested_bridge_completed']
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        proof = Path(temporary) / 'Comparison.json'
        run_path(str(root / 'Compare-TestGenericProjection.py'))['TestCompare'](root / 'Reference', root / 'Cases/Pair', proof)
        comparison = json.loads(proof.read_bytes())
    assert all(value['accepted_history_binary_equal'] for value in comparison.values())
    assert all(value['all_stencil_fields_max_difference'] <= 2e-20 for value in comparison.values())
    results.update(first_stencil_comparison=comparison, failed_large_step_not_physical_failure=True,
        independent_material_reintegration=False, ordinary_solver_recovery_enabled=False,
        installed_workbook_changed=False, physical_capacity_certified=False, full_acceptance_completed=False)
    output.write_text(json.dumps(results, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('GENERIC CONSTRAINT EQUATIONS SEQUENTIAL HISTORY AND ORDINARY BRIDGE INDEPENDENTLY VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
