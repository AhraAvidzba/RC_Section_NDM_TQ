"""ДЛЯ ТЕСТОВ. Сопоставляет первые сохранённые пробы общего и исходного отображения без новых расчётов материалов."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestCompare(left, right, output):
    """Разделяет изменение физического поля, невязки и численной производной при точных общих входах."""
    read = run_path(str(Path(__file__).resolve().parent / 'Analyze-TestNewtonLine.py'))['TestRead']
    result = {}
    for case in (0, 1):
        records = []
        for root in (left, right):
            data = read(root / f'Native/NewtonLine.C{case}I0.bin')
            raw = (root / f'Native/NewtonLine.Projection{case}.bin').read_bytes()
            pivot = int.from_bytes(raw[16:20], 'little', signed=True) - 1
            values = np.frombuffer(raw, '<f8', offset=20).reshape(-1, 63)
            maps = {row[:61].tobytes(): row[61] for row in values}
            fields = []
            points = [data['x']]
            for column in range(61):
                for sign in (1, -1):
                    x = data['x'].copy()
                    x[column] += sign * data['sizes'][column]
                    points.append(x)
            for x in points:
                field = data['seed'] + data['scales'][:60] * x[:60]
                field[pivot] = maps[x.tobytes()]
                fields.append(field)
            records.append((data, np.asarray(fields)))
        (a, fa), (b, fb) = records
        assert np.array_equal(a['seed'], b['seed']) and np.array_equal(a['scales'], b['scales'])
        assert a['seed_factor'] == b['seed_factor'] and a['target'] == b['target']
        assert np.array_equal(a['x'], b['x']) and np.array_equal(a['sizes'], b['sizes'])
        difference = b['jacobian'] - a['jacobian']
        rows = np.argsort(np.max(np.abs(difference), axis=1))[::-1][:5]
        item = {'accepted_history_binary_equal': (left / 'Input/Reverse1.bin').read_bytes() == (right / 'Input/Reverse1.bin').read_bytes(),
            'base_field_max_difference': float(np.max(np.abs(fb[0] - fa[0]))),
            'all_stencil_fields_max_difference': float(np.max(np.abs(fb - fa))),
            'base_residual_max_difference_MPa': float(np.max(np.abs(b['residual'] - a['residual']))),
            'stencil_residual_max_difference_MPa': float(max(np.max(np.abs(b[k] - a[k])) for k in ('plus', 'minus'))),
            'Jacobian_max_difference': float(np.max(np.abs(difference))),
            'Jacobian_relative_Frobenius_difference': float(np.linalg.norm(difference) / np.linalg.norm(a['jacobian'])),
            'first_direction_relative_difference': float(np.linalg.norm(a['correction'] - b['correction']) / np.linalg.norm(a['correction'])),
            'most_affected_rows_1_based': (rows + 1).tolist(),
            'left_first_binary_sha256': a['sha256'], 'right_first_binary_sha256': b['sha256']}
        result[str(case)] = item
        print('CASE', case, json.dumps(item), flush=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--left', type=Path, required=True)
    parser.add_argument('--right', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestCompare(args.left.resolve(), args.right.resolve(), args.out.resolve())
