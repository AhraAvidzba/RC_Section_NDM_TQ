"""ДЛЯ ТЕСТОВ. Проверяет общий адаптер и оба численных метода, сохраняя неудачу крупной цели явно."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestAnalyze(root, output):
    """Проверяет проекции, исходные уравнения, бюджеты и окончательные поля; численная неудача не считается разрушением."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Analyze-TestYieldProjection.py'))['TestAnalyze'](root, output)
    result = json.loads(output.read_bytes())
    rows = list(csv.reader((root / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    read = run_path(str(here / 'Analyze-TestNewtonLine.py'))
    results = {}
    for case in (0, 1):
        data = read['TestRead'](root / f'Native/NewtonLine.C{case}I0.bin')
        event = read['TestYieldEventFunction'](root, rows, case)
        summary, = [row for row in rows if row[:2] == ['HYBRID_RESULT', str(case)]]
        final, = [row for row in rows if row[:2] == ['HYBRID_FINAL', str(case)]]
        residual, = [row for row in rows if row[:2] == ['HYBRID_RESIDUAL', str(case)]]
        native, = [row for row in rows if row[:2] == ['HYBRID_NATIVE', str(case)]]
        gates, = [row for row in rows if row[:2] == ['CONTEXT_GATES', str(case)]]
        assert gates[2:] == ['InactiveRejected', 'SameRevisionNewContextRejected', 'FreshReadAccepted']
        values = np.asarray([float(item) for item in residual[2:]])
        assert values.shape == (61,) and np.max(np.abs(values)) == float(summary[4])
        assert int(summary[5]) <= 30 and int(summary[6]) <= 4500 and summary[6] == summary[9]
        if summary[2] == 'True':
            assert np.max(np.abs(values)) <= 1e-10 and int(summary[8]) == 1
        raw = (root / f'Native/NewtonLine.HybridProjection{case}.bin').read_bytes()
        assert raw[:16] == b'NDMQPROJECT00001' and (len(raw) - 20) % 504 == 0
        pivot, = struct.unpack_from('<i', raw, 16)
        assert 1 <= pivot <= 60
        maps = np.frombuffer(raw, '<f8', offset=20).reshape(-1, 63)
        assert 0 < len(maps) <= int(summary[6]) + 1
        maximum = 0.
        for record in maps:
            field = data['seed'] + data['scales'][:60] * record[:60]
            field[pivot - 1] = record[61]
            assert abs(record[62] - data['target']) <= 2e-12
            error = abs(event(field) - record[62])
            assert error <= 1e-9
            maximum = max(maximum, error)
        item = {'strict_root_found': summary[2] == 'True', 'seconds': float(summary[3]),
            'actual_residual_max_MPa': float(summary[4]), 'steps': int(summary[5]),
            'full_function_calls': int(summary[6]), 'jacobians': int(summary[7]), 'stop_code': int(summary[8]),
            'actual_spy_calls_equal_budget': True, 'projection_reads': int(summary[10]),
            'successful_function_projection_records': len(maps), 'independent_event_CSV_error_max_MPa': maximum,
            'final_lambda': float(final[2]), 'native_original_tolerance_verified': native[2] == 'True',
            'native_field_Double_unchanged': native[3] == 'True', 'native_forward_direction': native[4] == 'True',
            'inactive_and_same_revision_replaced_contexts_rejected': True}
        if native[2:4] == ['True', 'True']:
            validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
            proof, fields = validate(root, f'NewtonLine.Reverse{40 + case}')
            assert len(fields) == 27
            np.testing.assert_allclose(fields[-1], np.asarray([float(value) for value in final[3:]]), rtol=1e-14, atol=1e-300)
            item['independent_all_equations'] = proof
        results[str(case)] = item
    result.update(existing_hybrid=results, failed_large_step_retained=True, physical_capacity_certified=False,
                  ordinary_solver_recovery_enabled=False, installed_workbook_changed=False)
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('GENERIC MATERIAL CONSTRAINT BOTH NUMERICAL ENGINES AND LARGE STEP FAILURE VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
