"""ДЛЯ ТЕСТОВ. Сохраняет общие рабочие классы, аналитические проверки, неудачу крупной цели и последовательный возврат."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestCollect(repo, root):
    """Фиксирует точные CFB трёх книг; прежняя успешная крупная цель сохраняется отдельным минимальным сравнением."""
    here = Path(__file__).resolve().parent
    cases = {'Unit': 'GenericConstraint20261119', 'Pair': 'GenericConstraint0220261119', 'Sequence': 'GenericSequence20261119'}
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for key in cases:
        folder = root / 'Cases' / key
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(sources) == 36
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    reference = repo / 'docs/regression/Coupled6D/CoupledYieldProjectionStudies20261119.zip'
    expected = json.loads((repo / 'docs/reports/Coupled6DEvidence.json').read_bytes())['archives']['CoupledYieldProjectionStudies20261119']
    assert sha256(reference.read_bytes()).hexdigest().upper() == expected
    names = ['Input/Reverse1.bin'] + [f'Native/NewtonLine.{part}{case}{tail}' for case in (0, 1)
        for part, tail in (('C', 'I0.bin'), ('Projection', '.bin'))]
    reference_files = {}
    with ZipFile(reference) as bundle:
        pins = json.loads(bundle.read('Files.json'))
        for name in names:
            key = 'Cases/Departure/' + name
            raw = bundle.read(key)
            assert sha256(raw).hexdigest().upper() == pins[key]
            destination = root / 'Reference' / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw)
            reference_files[name] = pins[key]
    (root / 'ReferenceScope.json').write_text(json.dumps({'archive': reference.name, 'sha256': expected,
        'scope': 'only exact accepted prefix, first complete stencils and projection traces', 'files': reference_files},
        indent=2, sort_keys=True)+'\n', encoding='utf-8')
    helpers = ('Collect-TestGenericConstraint.py', 'Check-TestGenericConstraint.py', 'Audit-TestGenericConstraintBook.py',
        'Audit-TestPrivateCoupledBook.py', 'Canonical-TestCoreVBA.py', 'Analyze-TestNewtonLine.py',
        'Analyze-TestYieldProjection.py', 'Analyze-TestYieldSequence.py', 'Analyze-TestGenericConstraint.py',
        'Analyze-TestGenericBridge.py', 'Compare-TestGenericProjection.py', 'Stage-TestGenericConstraint.py',
        'Stage-TestGenericSequence.py', 'Stage-TestYieldProjectedSequence.py', 'CProjectedEquationsTest.cls',
        'TestNativeGenericHybrid.bas.txt', 'TestNativeOrdinaryBridge.bas.txt', 'TestNativeYieldProjection.bas.txt',
        'TestNativeNewtonLine.bas.txt', 'TestNativeNewtonYieldEvent.bas.txt', 'Stage-TestNewtonYieldPrecision.py',
        'Stage-TestNewtonYieldEvent.py', 'Stage-TestNewtonLine.py', 'Guard-TestExistingOffice.py',
        'Check-TestActualReverseCapture.py', 'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py',
        'Pack-TestCompiledProjects.py')
    for name in helpers:
        (root / name).write_bytes((here / name).read_bytes())
    run_path(str(here / 'Pack-TestCompiledProjects.py'))['TestPack'](root, cases)
    working = ('src/Interfaces/ICoupledScalarConstraint.cls', 'src/Solver/CCoupledConstraintEquations.cls',
        'src/Solver/CCoupledMaterialConstraint.cls', 'src/Solver/CCoupledNewtonSolver.cls',
        'tests/CConstraintEquationsTest.cls', 'tests/modTestCoupledConstraint.bas')
    hashes = {}
    for name in working:
        destination = root / 'WorkingSources' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((repo / name).read_bytes())
        hashes[name] = sha256(destination.read_bytes()).hexdigest().upper()
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '411a80f', 'working_sources': hashes,
        'working_sources_changed': True, 'ordinary_solver_recovery_enabled': False,
        'installed_workbook_changed': False, 'physical_capacity_certified': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name not in ('Files.json', 'CompiledVBA.bin')}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('GENERIC CONSTRAINT AND ORDINARY BRIDGE EVIDENCE COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
