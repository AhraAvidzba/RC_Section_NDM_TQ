"""Проверяет нативное восстановление MVT2 и две силовые пробы Excel."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum, isfinite
from pathlib import Path
import re
from zipfile import ZipFile


PRIOR = 'MVT2NativePublicationCutTimed20261117.zip'
PRIOR_SHA = 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A'
BOOK_SHA = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'
DIAGNOSTIC_SHA = {
    False: '59DCEC73F5F4DC1194240D7FC34008D0FCA93799B3CA52A04A386DCDF6A110FC',
    True: '61D6C5B40ED2A0F61D5186E341D8C26C77B4131CEF035B56D2D73E076401E92F',
}
LAST_PHASE = 'S10A21875'
TORQUE = 10510000.
Q_ACCEPTED = 21875.
Q_TARGET = 22500.
ARM = 396.
MODES = ('AcceptedField', 'ForceSecant')


def digest(content):
    return sha256(content).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def checks_of_owner(root, log, branch):
    """Подтверждает отметку теста, завершение дочернего процесса и закрытие Excel."""
    owner = read_json(root / 'Native/MVTGaussMixed.txt.Ownership.json')
    closure = read_json(root / 'Native/MVTGaussMixed.txt.ProcessClosure.json')
    cleanup = read_json(root / 'Native/MVTGaussMixed.txt.RunnerCleanup.json')
    compiler = read_json(root / 'CodeUpdate.json')
    compiler_exit = read_json(root / 'CompileClosure.json')
    assert closure['Stage'] == 'AFTER_CHILD_EXIT' and closure['Passed']
    assert closure['ChildHasExited'] and closure['ChildExitCode'] == 0
    assert not closure['OrdinaryPathKilledAnything'] and closure['RunnerCleanupValid']
    assert closure['RunnerCleanup'] == cleanup
    assert cleanup['OwnerVerified'] and cleanup['QuitRequested'] and cleanup['QuitSucceeded']
    assert not cleanup['Failed'] and not cleanup['Errors']
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['ProcessName'] == 'EXCEL'
    assert compiler['Compiled'] and not compiler['ProductionChanged']
    assert compiler['ProductionSHA256'] == BOOK_SHA
    assert owner['SourceSHA256'] == compiler['WorkbookSHA256'] == DIAGNOSTIC_SHA[branch]
    assert set(compiler['Modules']) == {'CCoupledElasticState', 'CCoupledSectionQuadrature', 'modTestMVT2GaussSpan'} | (
        {'CCoupledNewtonSolver'} if branch else set())
    assert compiler_exit['State'] == 'Absent'
    identity = closure['Closure']['Identity']
    final = closure['Closure']['FinalState']
    assert identity['Valid'] and closure['Closure']['Passed'] and final['State'] == 'Absent'
    assert owner['PID'] == identity['PID'] == final['PID'] == cleanup['PID']
    assert int(owner['StartTicksUTC']) == identity['Ticks'] == int(final['StartTicksUTC']) == int(cleanup['StartTicksUTC'])
    assert [tag for tag in log.splitlines() if tag.startswith('TEST_EXCEL_PROCESS:')] == [
        f"TEST_EXCEL_PROCESS: id={owner['PID']}; startTicks={owner['StartTicksUTC']}"
    ]
    assert 'readOnly=True; sameProxy=True' in log
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
    assert 'WATCHDOG_FAILURE' not in log and 'RUNTIME ERROR:' not in log
    return owner['PID'], owner['StartTicksUTC']


def geometry(rows):
    """Восстанавливает центр, площадь, масштаб и знаки направлений стали."""
    frame, = [row for row in rows if row[0] == 'MVT_GEOM']
    assert frame[1:4] == ['25', '45', '60']
    points = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == 'MVT_POINT'}
    assert set(points) == set(range(1, 46))
    assert all(len(point) == 9 and point[2] > 0. for point in points.values())
    return tuple(map(float, frame[4:])), points


def equations(phase, frame, tables, mesh):
    """Собирает 56 слабых уравнений, четыре связи и шесть знаковых усилий."""
    ox, oy, area, length = mesh[0]
    points = mesh[1]
    torque, shear, central = frame
    field = tables['F'][phase]
    assert len(field) == 60 and all(map(isfinite, field))
    load = (0., -ARM * shear, 0., torque, 0., shear)
    external = [fsum(tables['L'][i][row] * force for i, force in enumerate(load, 1)) for row in range(60)]
    residual_terms = [[fsum(x*g for x, g in zip(field, tables['G'][row+1], strict=True)), -external[row]]
                      for row in range(60)]
    sums, strain_error, stress_error = [], 0., 0.
    for p, (x, y, weight, *direction) in points.items():
        center = tables['H'][phase, 0, p]
        minus, plus = tables['H'][phase, -1, p], tables['H'][phase, 1, p]
        assert all(isfinite(s) for values in (center, minus, plus) for s in values)
        strain = [fsum(coefficient * tables['B'][p, j][k] for j, coefficient in enumerate(field, 1)) for k in range(6)]
        strain_error = max(strain_error, *(abs(a-b) for a,b in zip(strain, central[p][:6], strict=True)))
        if p <= 25:
            assert center == central[p][6:]
        else:
            combined = tuple(a+b for a,b in zip(center, central[p][6:], strict=True))
            axial = fsum(a*d for a,d in zip(combined, direction, strict=True)) / fsum(d*d for d in direction)
            stress_error = max(stress_error, *(abs(a-axial*d) for a,d in zip(combined, direction, strict=True)))
        zz, xz, yz = center[2], center[4], center[5]
        sums.append((weight*zz, weight*(y-oy)*zz, weight*(x-ox)*zz,
                     weight*((x-ox)*yz-(y-oy)*xz), weight*xz, weight*yz))
        for k, (sp, sm, sc) in enumerate(zip(plus, minus, center, strict=True), 1):
            slope = (sp-sm) / .002
            for row, (s, r) in enumerate(zip(tables['S'][p,k], tables['R'][p,k], strict=True)):
                residual_terms[row].extend((sc*s, slope*r))
    residual = tuple(map(fsum, residual_terms))
    actual = tuple(map(fsum, zip(*sums, strict=True)))
    force_error = max(abs(a-b) / (area*length if 1 <= i <= 3 else area)
                      for i,(a,b) in enumerate(zip(actual, load, strict=True)))
    weak, gauge = max(map(abs, residual[:56])), 30000. * max(map(abs, residual[56:]))
    tolerance = 5e-7 + 5e-7 * max(map(abs, external[:56]))
    assert max(weak, gauge, force_error) <= tolerance and strain_error < 3e-16 and stress_error < 2e-12
    return {'actions_N_Nmm': actual, 'weak_MPa': weak, 'gauge_MPa': gauge,
            'resultant_MPa': force_error, 'tolerance_MPa': tolerance}


def trials(rows, log):
    """Сверяет обе отдельные пробы и сохраняет численный исход без оценки предела."""
    cooked = [row for row in rows if row[0] == 'MVT2_RECOVERY_TRIAL']
    assert tuple(row[1] for row in cooked) == MODES
    assert [row for row in rows if row[0] == 'MVT2_RECOVERY_REPLAY'] == [['MVT2_RECOVERY_REPLAY','22','21875']]
    for row in cooked:
        assert ';'.join(row) in log
    outcome = {}
    for _, mode, q, ok, state, reason, *details in cooked:
        assert float(q) == Q_TARGET and ok in ('True', 'False')
        detail = ';'.join(details)
        assert (state,reason) == (('4','0') if ok == 'True' else ('6','10'))
        work = re.match(r'Итерации: ([0-9]+); пробы: ([0-9]+); невязка, МПа: ([0-9.Ee+-]+)', detail)
        assert work and 0 < int(work[1]) <= 26 and int(work[2]) > int(work[1])
        trial = {'accepted': ok == 'True', 'status_id': int(state), 'reason_id': int(reason),
                 'iterations': int(work[1]), 'evaluations': int(work[2]), 'last_reported_MPa': float(work[3])}
        if ok == 'False':
            damping = re.search(r'невязка перед демпфированием, МПа: ([0-9.Ee+-]+); лучшая невязка проб, МПа: ([0-9.Ee+-]+)', detail)
            assert damping and float(damping[1]) < float(damping[2])
            trial.update({'norm_before_damping_MPa': float(damping[1]), 'best_damped_norm_MPa': float(damping[2])})
        outcome[mode] = trial
    reached = str(any(trial['accepted'] for trial in outcome.values()))
    assert f'TOTAL_MVT2_GAUSS_SPAN: passed=1; failed=0; target_reached={reached}' in log
    stage, = [row for row in rows if row[0] == 'CASE_FINISHED']
    assert stage[1:3] == ['MVTGaussMixed', reached] and 0 < float(stage[3]) < 165
    return outcome, float(stage[3])


def verify(root, repo, branch):
    """Связывает подготовленные поля с архивом §547 и проверяет новые выгрузки."""
    path = repo / 'docs/regression/Coupled6D' / PRIOR
    assert digest(path.read_bytes()) == PRIOR_SHA
    with ZipFile(path) as old:
        utilities = {'__name__': '__pinned__'}
        exec(compile(old.read('Verify-NativePublicationCut.py'), 'Verify-NativePublicationCut.py', 'exec'), utilities)
        old_tables = utilities['read_operators'](old.read('Native/Operators.csv'))
        old_frames = utilities['read_tensor_frames'](old.read('Native/MVTGaussMixed.Tensor.csv'), 45)
        old_rows = [line.split(';') for line in old.read('Native/MVTGaussMixed.csv').decode('cp1251').splitlines()]
        old_indexes = old.read('Native/ColdPreload.csv')
        original_preparation = json.loads(old.read('Preparation.json'))

    preparation = read_json(root / 'Preparation.json')
    assert preparation['replayed_native_archive'] == PRIOR_SHA and preparation['source_book_sha256'] == BOOK_SHA
    assert preparation['native_archive_sha256'] == original_preparation['native_archive_sha256']
    assert bool(preparation.get('branch_consistent_fixed_force_test')) == branch
    new_inputs = preparation['inputs']
    assert all(new_inputs[key] == sha for key,sha in original_preparation['inputs'].items()
               if key not in ('Run-Native.ps1','tests/modTestMVT2GaussSpan.bas'))
    extra = {'src/Solver/CCoupledNewtonSolver.cls'} if branch else set()
    assert set(new_inputs) == set(original_preparation['inputs']) | {'Replay.Fields.csv'} | extra
    for name in {'Run-Native.ps1','Replay.Fields.csv','tests/modTestMVT2GaussSpan.bas'} | extra:
        assert digest((root/name).read_bytes()) == new_inputs[name]
    test = (root/'tests/modTestMVT2GaussSpan.bas').read_text(encoding='utf-8-sig')
    assert test.count('branchConsistentForTest:=True') == (2 if branch else 0)
    if branch:
        assert 'mConsistentControl = branchConsistentForTest And mUseSpatialHistory' in (root / next(iter(extra))).read_text('utf-8')
    assert (root/'Native/ColdPreload.csv').read_bytes() == old_indexes
    history = [line.split(';') for line in (root/'Replay.Fields.csv').read_text(encoding='ascii').splitlines()]
    assert list(old_tables['F']) == [row[0] for row in history] and len(history) == 22
    for phase, q, t, *values in history:
        assert (float(t),float(q)) == old_frames[phase][:2]
        assert tuple(map(float, values)) == old_tables['F'][phase]
    assert history[-1][:3] == [LAST_PHASE,'21875','10510000']

    native = root / 'Native'
    tables = utilities['read_operators']((native/'Operators.csv').read_bytes())
    assert all(tables[key] == old_tables[key] for key in 'GLBSR')
    frames = utilities['read_tensor_frames']((native/'MVTGaussMixed.Tensor.csv').read_bytes(), 45)
    assert frames['Replay'][:2] == old_frames[LAST_PHASE][:2] == (TORQUE,Q_ACCEPTED)
    assert tables['F']['Replay'] == old_tables['F'][LAST_PHASE]
    rows = [line.split(';') for line in (native/'MVTGaussMixed.csv').read_bytes().decode('cp1251').splitlines()]
    mesh = geometry(rows)
    assert mesh == geometry(old_rows)
    log = (native/'MVTGaussMixed.txt').read_text(encoding='utf-8-sig')
    pid, ticks = checks_of_owner(root, log, branch)
    outcome, seconds = trials(rows, log)
    expected = ['Replay', *(mode for mode in MODES if outcome[mode]['accepted'])]
    assert list(frames) == expected and list(tables['F']) == expected
    assert set(tables['H']) == {(phase,side,p) for phase in expected for side in (-1,0,1) for p in mesh[1]}
    nets = [(a,b) for side in (-1,0,1) for p in mesh[1]
            for a,b in zip(tables['H']['Replay',side,p],old_tables['H'][LAST_PHASE,side,p],strict=True)]
    concrete = [(p,a,b) for p in mesh[1]
                for a,b in zip(frames['Replay'][2][p],old_frames[LAST_PHASE][2][p],strict=True)]
    strain_delta = max(abs(a-b) for p in mesh[1]
                       for a,b in zip(frames['Replay'][2][p][:6],old_frames[LAST_PHASE][2][p][:6],strict=True))
    concrete_delta = max(abs(a-b) for p in mesh[1]
                         for a,b in zip(frames['Replay'][2][p][6:],old_frames[LAST_PHASE][2][p][6:],strict=True))
    net_delta = max(abs(a-b) for a,b in nets)
    assert strain_delta < 3e-17 and max(net_delta,concrete_delta) < 5e-12
    verified = {phase: equations(phase, frames[phase], tables, mesh) for phase in expected}
    for mode in expected[1:]:
        assert frames[mode][:2] == (TORQUE,Q_TARGET)
    return {'history_fields':len(history), 'history_archive_sha256':PRIOR_SHA, 'workbook_sha256':DIAGNOSTIC_SHA[branch],
            'field_coefficients_equal':True, 'station_components_compared':len(nets),
            'central_tensor_components_compared':len(concrete),
            'differing_station_components':sum(a!=b for a,b in nets), 'net_stress_delta_MPa':net_delta,
            'actual_concrete_delta_MPa':concrete_delta,'strain_delta':strain_delta,
            'macro_elapsed_s':seconds, 'closed_pid':pid, 'closed_start_ticks':ticks,
            'verified_equilibrium':verified, 'trials':outcome}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    baseline = verify(args.root/'StockTangent', args.repo, False)
    branch = verify(args.root/'BranchTangent', args.repo, True)
    assert baseline['verified_equilibrium']['Replay'] == branch['verified_equilibrium']['Replay']
    proof = {'stock_tangent':baseline, 'branch_consistent_tangent':branch}
    with args.report.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(proof, handle, sort_keys=True, ensure_ascii=False, indent=2)
        handle.write('\n')
    print('MVT2 NATIVE RECOVERY OFFLINE PASS', baseline['history_fields'],
          sum(len(run['verified_equilibrium']) - 1 for run in proof.values()), flush=True)
