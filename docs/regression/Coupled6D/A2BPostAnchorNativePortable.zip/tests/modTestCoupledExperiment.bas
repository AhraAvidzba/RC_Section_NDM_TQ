﻿Attribute VB_Name = "modTestCoupledExperiment"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сопоставление связанного НДС с опытами Onsongo TBU3, Kani и Lopes A2.
' Геометрия и стали восстановлены по первичным публикациям в literature/Coupled6D.
' Параметры, отсутствующие в источниках, фиксируются как допущения расчёта.

Private Const TBU3_HALF_WIDTH As Double = 254#
Private Const TBU3_HALF_HEIGHT As Double = 205# ' Полувысота номинального прямоугольника, мм.
Private Const TBU3_MEASUREMENT_HALF_HEIGHT As Double = 76# ' Две соседние базы измерения по 76 мм.
Private Const TBU3_REFERENCE_HOOP_SPACING As Double = 150# ' Контрольный вариант исторического ряда.
Private Const TBU3_MEASURED_HOOP_SPACING As Double = 76# ' Схема TBU по Rahal и Collins.
Private Const TBU3_REFERENCE_BOTTOM_Y As Double = -154# ' Оценка положения нижнего ряда, мм.
Private Const TBU3_PUBLISHED_HOOP_COVER As Double = 6.35 ' Слой до поверхности по Kuan и соавторам, рис. 9, мм.
Private Const TBU3_PUBLISHED_BOTTOM_Y As Double = -173# ' Приведённая глубина оси 378 мм от верхней грани.
Private Const TBU3_REFERENCE_PEAK_COMPRESSION As Double = 0.0045 ' Калибровка Yamamoto с учётом остановок нагружения.
Private Const TBU3_PUBLISHED_PEAK_COMPRESSION As Double = 0.0031 ' Значение Kagermanov и Ceresa, табл. 2.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прослеживает чистый Qy с заданием среднего инженерного сдвига yz.
' Опытная кривая сравнивается с принятыми точками без экстраполяции.
Public Function RunTestCoupledKaniShear(ByVal spansText As String, ByVal shearText As String) As String
    RunTestCoupledKaniShear = TraceKaniShearTest(spansText, shearText, False)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет траекторию с оценками энергий из формул (16.3–16.4)
' Poliotti и Bairán (2019). Характеристическую длину сохраняет.
Public Function RunTestCoupledKaniPublishedEnergy(ByVal spansText As String, ByVal shearText As String) As String
    RunTestCoupledKaniPublishedEnergy = TraceKaniShearTest(spansText, shearText, True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет траекторию Kani с тремя историями и теми же оценками энергий.
Public Function RunTestCoupledKaniSpatial(ByVal spansText As String, ByVal shearText As String) As String
    RunTestCoupledKaniSpatial = TraceKaniShearTest(spansText, shearText, True, spatialHistory:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет точки равновесия и причины уменьшения шага при заданном сдвиге.
Private Function TraceKaniShearTest(ByVal spansText As String, ByVal shearText As String, ByVal publishedEnergies As Boolean, _
        Optional ByVal spatialHistory As Boolean = False) As String
    On Error GoTo Failed
    Const EC As Double = 25600#
    Const FC As Double = 28.2
    Const FT As Double = 1.75
    Const NOMINAL_INCREMENT As Double = 0.0002
    Const MAX_ATTEMPTS As Long = 120
    Const FORCE_SCALE As Double = 100000# ' Множитель равновесия отсчитывается в долях 100 кН.
    Const AREA As Double = 305# * 610#
    Dim report As String, tracePath As String, passed As Long, failed As Long
    Dim spans As Long: spans = CLng(spansText)
    Dim maximumShear As Double: maximumShear = Val(shearText)
    If spans < 1 Or spans > 3 Or maximumShear <= 0# Or maximumShear > 0.008 Then _
        Err.Raise 5, , "Тестовые границы: базис 1–3, инженерный сдвиг от 0 до 0,008."
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) > 0 Then tracePath = ThisWorkbook.Path & "\Kani_Trace.csv"
    AddExperimentTraceTest report, tracePath, "attempt;gamma_yz;Qy_kN;hoop_stress_MPa;hoop_utilization;stress_residual_MPa;seconds"
    Dim gt As Double, gc As Double
    gt = 0.12: gc = 80#
    If publishedEnergies Then
        gt = 0.073 * FC ^ 0.18
        gc = (FC / FT) ^ 2 * gt
    End If
    AddExperimentTraceTest report, tracePath, "KANI_ENERGIES_N_PER_MM: " & ExperimentNumberTest(gt) & " | " & ExperimentNumberTest(gc)
    Dim section As CSectionModel, layout As CTransverseRebarLayout, steel As Object
    Set section = BuildKaniSectionTest(layout, steel)
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse, response As New CCoupledReinforcedResponse
    operators.PrepareModel section, EC, 0.2, spans, spans, 5, layout, steelModels:=steel
    Dim solver As New CCoupledNewtonSolver, shearX() As Double, shearY() As Double
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, 0.2, FC, FT, 0.0022, gt, gc, spatialHistory
    operators.MeanShearProjections shearX, shearY
    Dim baseLoad(1 To 6) As Double, direction(1 To 6) As Double
    direction(6) = FORCE_SCALE
    AddExperimentTraceTest report, tracePath, "KANI_POINTS: " & CStr(operators.PointCount) & " | DOF: " & CStr(operators.DegreeCount)

    Dim coordinate As Double, increment As Double, candidate As Double, trialLambda As Double, reached As Double
    Dim field() As Double, actual() As Double, attempt As Long, i As Long, errorNorm As Double, difference As Double
    Dim gamma As Double, expected As Double, hoopPoint As Long, started As Double, stopReason As String
    increment = NOMINAL_INCREMENT: stopReason = "AttemptLimit"
    For attempt = 1 To MAX_ATTEMPTS
        candidate = coordinate + increment
        If candidate > maximumShear Then candidate = maximumShear
        started = Timer
        If solver.TryDeformationStep(baseLoad, direction, shearY, candidate, reached, trialLambda, 0.0000005, 0.00000002, 24) Then
            solver.CopyTrial field, actual: solver.AcceptStep
            reached = trialLambda: coordinate = candidate: errorNorm = 0#: gamma = 0#
            For i = 1 To operators.DegreeCount: gamma = gamma + shearY(i) * field(i): Next i
            For i = 1 To 6
                expected = reached * direction(i)
                difference = Abs(actual(i) - expected) / AREA
                If i >= 2 And i <= 4 Then difference = difference / 610#
                If difference > errorNorm Then errorNorm = difference
            Next i
            hoopPoint = response.AcceptedTransverseCriticalPoint
            AddExperimentTraceTest report, tracePath, "Kani" & CStr(attempt) & ";" & ExperimentNumberTest(gamma) & ";" & _
                ExperimentNumberTest(actual(6) / 1000#) & ";" & ExperimentNumberTest(response.AcceptedSteelStress(hoopPoint)) & ";" & _
                ExperimentNumberTest(response.AcceptedTransverseSteelUtilization) & ";" & ExperimentNumberTest(errorNorm) & ";" & ExperimentNumberTest(Timer - started)
            If errorNorm < 0.000005 And Abs(gamma - candidate) < 0.000000001 Then passed = passed + 1 Else failed = failed + 1
            If coordinate = maximumShear Then
                stopReason = "TargetReached"
                Exit For
            End If
            increment = increment * 1.25
            If increment > NOMINAL_INCREMENT Then increment = NOMINAL_INCREMENT
        Else
            AddExperimentTraceTest report, tracePath, "KANI_REJECTED: " & CStr(attempt) & " | gamma: " & ExperimentNumberTest(candidate) & _
                " | " & solver.ResultMeta.ResultComment & " | " & solver.ResultMeta.DiagnosticDetails
            increment = increment * 0.5
            If increment < NOMINAL_INCREMENT / 32# Then
                stopReason = "MinimumShearIncrement"
                Exit For
            End If
        End If
    Next attempt
    AddExperimentTraceTest report, tracePath, "KANI_STOP: " & stopReason
    If passed = 0 Then failed = failed + 1
    TraceKaniShearTest = report & "TOTAL_KANI_SHEAR_EQUILIBRIUM: passed=" & passed & "; failed=" & failed
    Exit Function
Failed:
    TraceKaniShearTest = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит номинальное сечение Kani. Положение осей масштабировано по рис. 4a
' Poliotti и Bairán. Фактические радиусы загибов и диаграммы после текучести неизвестны.
Private Function BuildKaniSectionTest(ByRef layout As CTransverseRebarLayout, ByRef steel As Object) As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("Kani_Outer", Array(Array(-152.5, -305#, 305#, 610#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours

    Dim i As Long, x As Double
    For i = 0 To 3
        x = -105# + 70# * i
        section.AddRebarElement x, -254#, 25#, GEOM_PI * 156.25, "KANI_LONG"
        section.AddRebarElement x, 254#, 25#, GEOM_PI * 156.25, "KANI_LONG"
    Next i
    Set layout = New CTransverseRebarLayout
    layout.AddContourGroup section, "KANI_HOOP", vbNullString, 10#, 100#, 25#, "KANI_HOOP"
    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "KANI_LONG", ExperimentBilinearSteelTest(200000#, 442#, 0#)
    steel.Add "KANI_HOOP", ExperimentBilinearSteelTest(200000#, 400#, 0#)
    Set BuildKaniSectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Нагружает полую балку A2 заданным закручиванием. Независимо записывает
' первое повреждение бетона, текучесть хомута и продольной стали.
Public Function RunTestCoupledLopesA2(ByVal spansText As String, ByVal twistText As String) As String
    RunTestCoupledLopesA2 = TraceLopesA2Test(spansText, twistText, False)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет чистое кручение с уточнённой стенкой и отдельными параметрами
' бетона и двух видов стали по таблицам 4.1–4.2 Martins.
Public Function RunTestCoupledLopesA2RefinedInputs(ByVal spansText As String, ByVal twistText As String) As String
    RunTestCoupledLopesA2RefinedInputs = TraceLopesA2Test(spansText, twistText, True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прослеживает ту же траекторию чистого кручения A2 с тремя историями.
Public Function RunTestCoupledLopesA2Spatial(ByVal spansText As String, ByVal twistText As String) As String
    RunTestCoupledLopesA2Spatial = TraceLopesA2Test(spansText, twistText, True, spatialHistory:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит сжатие 1279,1 кН из таблицы 3 Bernardo и Taborda
' до увеличения кручения. Продольная сила затем остаётся постоянной.
Public Function RunTestCoupledLopesA2Compression(ByVal spansText As String, ByVal twistText As String) As String
    RunTestCoupledLopesA2Compression = TraceLopesA2Test(spansText, twistText, True, -1279100#)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет диагностический пик и итог прочности A2 с восстановленной ветвью.
Public Function RunTestCoupledLopesA2LocalPeak(ByVal spansText As String, ByVal maximumLambdaText As String) As String
    RunTestCoupledLopesA2LocalPeak = TraceLopesA2Test(spansText, ".029", True, strengthMaximum:=Val(maximumLambdaText))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает упругое сечение и последующую нелинейную ветвь с армированием.
Private Function TraceLopesA2Test(ByVal spansText As String, ByVal twistText As String, ByVal refinedInputs As Boolean, _
        Optional ByVal normalForce As Double = 0#, Optional ByVal strengthMaximum As Double = 0#, _
        Optional ByVal spatialHistory As Boolean = False, Optional ByVal sampling As Long = 5, _
        Optional ByVal coldAudit As Boolean = False, Optional ByVal tensileEnergyScale As Double = 1#, _
        Optional ByVal measuredTorqueStop As Boolean = False) As String
    On Error GoTo Failed
    Const NU As Double = 0.2
    Const FC As Double = 47.3
    Const START_INCREMENT As Double = 0.00025 ' рад/м
    Const MAX_INCREMENT As Double = 0.001 ' рад/м
    Dim spans As Long: spans = CLng(spansText)
    Dim limitTwist As Double: limitTwist = Val(twistText)
    If spans < 1 Or spans > 3 Or limitTwist <= 0# Or limitTwist > 0.035 Then _
        Err.Raise 5, , "Тестовые границы A2: базис 1–3, закручивание до 0,035 рад/м."
    Dim report As String, tracePath As String, passed As Long, failed As Long
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) > 0 Then tracePath = ThisWorkbook.Path & "\A2_Trace.csv"

    Dim ec As Double, ft As Double, gt As Double, gc As Double, peakStrain As Double, wall As Double
    Dim hoopYield As Double, longitudinalYield As Double
    ec = 35000#: ft = 0.302 * FC ^ (2# / 3#): peakStrain = 0.0024: wall = 100#
    hoopYield = 686#: longitudinalYield = 686#
    If refinedInputs Then
        ec = 36100#: ft = 3.5: peakStrain = 0.002: wall = 107#
        hoopYield = 696#: longitudinalYield = 672#
    End If
    gt = 0.073 * FC ^ 0.18: gc = (FC / ft) ^ 2 * gt
    gt = gt * tensileEnergyScale ' Меняется только энергия растяжения, огибающая сжатия сохраняется.
    Dim section As CSectionModel: Set section = BuildLopesA2SectionTest(wall)
    Dim operators As New CCoupledElasticState
    operators.PrepareModel section, ec, NU, spans, spans, sampling
    Dim field() As Double, actual() As Double, deformation() As Double, stress() As Double
    If Not operators.Solve(0#, 0#, 0#, 10000000#, 0#, 0#, deformation, actual, stress) Then _
        Err.Raise 5, , operators.ResultMeta.ResultComment
    Dim rigidity As Double: rigidity = actual(4) / deformation(4)
    AddExperimentTraceTest report, tracePath, "A2_ELASTIC_J_MM4: " & ExperimentNumberTest(rigidity * 2# * (1# + NU) / ec)
    AddExperimentTraceTest report, tracePath, "A2_ELASTIC_RIGIDITY_KNM2: " & ExperimentNumberTest(rigidity / 1E+9)

    Dim layout As New CTransverseRebarLayout, steel As Object
    AddLopesA2ReinforcementTest section, layout
    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "A2_LONG", ExperimentBilinearSteelTest(200000#, longitudinalYield, 0#)
    steel.Add "A2_HOOP", ExperimentBilinearSteelTest(200000#, hoopYield, 0#)
    operators.PrepareModel section, ec, NU, spans, spans, sampling, layout, steelModels:=steel
    AddExperimentTraceTest report, tracePath, "A2_PARAMETERS: Ec " & ExperimentNumberTest(ec) & " | Ft " & _
        ExperimentNumberTest(ft) & " | Gt " & ExperimentNumberTest(gt) & " | Gc " & ExperimentNumberTest(gc) & _
        " | wall " & ExperimentNumberTest(wall) & " | fy hoop " & ExperimentNumberTest(hoopYield) & _
        " | fy longitudinal " & ExperimentNumberTest(longitudinalYield)
    AddExperimentTraceTest report, tracePath, "A2_POINTS: " & CStr(operators.PointCount) & " | DOF: " & CStr(operators.DegreeCount)
    Dim concrete As New CCoupledConcreteResponse, response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, ec, NU, FC, ft, peakStrain, gt, gc, spatialHistory
    If strengthMaximum > 0# Then
        TraceLopesA2Test = SearchLopesA2StrengthTest(operators, solver, response, strengthMaximum, report, tracePath)
        Exit Function
    End If
    If normalForce <> 0# Then
        Dim path As New CLoadPathVector, preload As New CCoupledLoadContinuation
        path.Initialize normalForce, 0#, 0#, 0#, 0#, 0#
        preload.Initialize solver, path, 4, 12, 24, 0.0000005, 0.00000002
        If Not preload.Advance(0#) Then Err.Raise 5, , preload.ResultMeta.ResultComment & " " & preload.ResultMeta.DiagnosticDetails
        preload.CopyAccepted field, actual
        AddExperimentTraceTest report, tracePath, "A2_PRELOAD_N_KN: " & ExperimentNumberTest(actual(1) / 1000#)
    End If
    Dim projection() As Double, baseLoad(1 To 6) As Double, direction(1 To 6) As Double, target(1 To 6) As Double
    ReDim projection(1 To operators.DegreeCount): projection(4) = 1#
    baseLoad(1) = normalForce: target(1) = normalForce
    direction(4) = 100000000# ' Множитель в долях 100 кН·м.
    Dim eps0 As Double, kx As Double, ky As Double, twist As Double, coordinatePerRadPerM As Double
    operators.GeneralizedDeformation projection, eps0, kx, ky, twist
    coordinatePerRadPerM = 1# / (1000# * twist)
    AddExperimentTraceTest report, tracePath, "attempt;twist_rad_per_m;T_kNm;hoop_stress_MPa;longitudinal_stress_MPa;tension_energy_ratio;residual_MPa;seconds"

    Dim coordinate As Double, increment As Double, requested As Double, lambda As Double, trialLambda As Double
    Dim attempt As Long, i As Long, tension As Double, compression As Double, damage As Double, longStress As Double
    Dim moment As Double, previousMoment As Double, hoopStress As Double, errorNorm As Double, started As Double
    Dim sawDamage As Boolean, sawHoop As Boolean, sawLongitudinal As Boolean, stopReason As String
    Dim retained As Long, laneLimit As Long, minimumStep As Double
    laneLimit = 100: minimumStep = START_INCREMENT / 32#
    If coldAudit Then laneLimit = 180: minimumStep = START_INCREMENT / 128#
    If coldAudit Then AddExperimentTraceTest report, tracePath, "COLD;" & CStr(sampling) & ";" & CStr(operators.ConcretePointCount)
    increment = START_INCREMENT: stopReason = "AttemptLimit"
    For attempt = 1 To laneLimit
        requested = coordinate + increment
        If requested > limitTwist Then requested = limitTwist
        started = Timer
        If solver.TryDeformationStep(baseLoad, direction, projection, requested * coordinatePerRadPerM, lambda, _
                trialLambda, 0.0000005, 0.00000002, 24, consistentControl:=coldAudit) Then
            solver.CopyTrial field, actual: solver.AcceptStep
            lambda = trialLambda: target(4) = lambda * direction(4)
            moment = actual(4) / 1E+6
            operators.GeneralizedDeformation field, eps0, kx, ky, twist
            errorNorm = operators.ResultantResidualNorm(actual, target)
            damage = 0#: longStress = 0#
            For i = 1 To operators.ConcretePointCount
                concrete.AcceptedPointDamage i, tension, compression
                If tension > damage Then damage = tension
            Next i
            For i = operators.ConcretePointCount + 1 To operators.ConcretePointCount + section.RebarCount
                If Abs(response.AcceptedSteelStress(i)) > longStress Then longStress = Abs(response.AcceptedSteelStress(i))
            Next i
            hoopStress = Abs(response.AcceptedSteelStress(response.AcceptedTransverseCriticalPoint))
            AddExperimentTraceTest report, tracePath, "A2Step" & CStr(attempt) & ";" & ExperimentNumberTest(twist * 1000#) & _
                ";" & ExperimentNumberTest(moment) & ";" & ExperimentNumberTest(hoopStress) & ";" & ExperimentNumberTest(longStress) & _
                ";" & ExperimentNumberTest(damage) & ";" & ExperimentNumberTest(errorNorm) & ";" & ExperimentNumberTest(Timer - started)
            If errorNorm < 0.000005 And Abs(twist * 1000# - requested) < 0.00000001 Then passed = passed + 1 Else failed = failed + 1
            RecordLopesA2EventTest "TENSION_DAMAGE", (damage > 0.000001), sawDamage, coordinate, previousMoment, requested, moment, report, tracePath
            RecordLopesA2EventTest "HOOP_YIELD", (hoopStress >= hoopYield - 0.000001), sawHoop, coordinate, previousMoment, requested, moment, report, tracePath
            RecordLopesA2EventTest "LONGITUDINAL_YIELD", (longStress >= longitudinalYield - 0.000001), sawLongitudinal, coordinate, previousMoment, requested, moment, report, tracePath
            retained = retained + 1
            If coldAudit Then RecordA2ColdFieldTest report, tracePath, retained, attempt, field, actual, twist, errorNorm
            coordinate = requested: previousMoment = moment
            If measuredTorqueStop And moment > 254.8 Then
                stopReason = "MeasuredTorqueBracketed"
                Exit For
            End If
            If coordinate = limitTwist Then
                stopReason = "TargetReached"
                Exit For
            End If
            increment = increment * 1.25
            If increment > MAX_INCREMENT Then increment = MAX_INCREMENT
        Else
            Dim meta As CResultMeta: Set meta = solver.ResultMeta
            AddExperimentTraceTest report, tracePath, "A2_REJECTED: " & CStr(attempt) & " | " & ExperimentNumberTest(requested) & _
                " | " & meta.ResultComment & " | " & meta.DiagnosticDetails
            increment = increment * 0.5
            If increment < minimumStep Then
                stopReason = "MinimumTwistIncrement"
                Exit For
            End If
        End If
    Next attempt
    AddExperimentTraceTest report, tracePath, "A2_STOP: " & stopReason
    If passed = 0 Then failed = failed + 1
    TraceLopesA2Test = report & "TOTAL_A2_TORSION_EQUILIBRIUM: passed=" & passed & "; failed=" & failed
    Exit Function
Failed:
    TraceLopesA2Test = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запускает тот же силовой и деформационный поиск, что использует проверка прочности.
Private Function SearchLopesA2StrengthTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByVal response As CCoupledReinforcedResponse, ByVal maximum As Double, ByRef report As String, ByVal tracePath As String) As String
    Const UNIT_MOMENT As Double = 100000000#
    Dim path As New CLoadPathVector, branch As New CCoupledLoadContinuation
    path.Initialize 0#, 0#, 0#, 0#, 0#, 0#, 0#, UNIT_MOMENT
    branch.Initialize solver, path, 4, 64, 24, 0.0000005, 0.0000005, True
    branch.TraceSteelLimit response, 0.25, maximum, 0.005, True
    Dim forceMeta As CResultMeta: Set forceMeta = branch.ResultMeta
    AddExperimentTraceTest report, tracePath, "A2_STRENGTH_FORCE: " & ExperimentNumberTest(branch.AcceptedLambda) & " | " & _
        forceMeta.ResultComment & " | " & forceMeta.DiagnosticDetails
    Dim controlled As CCoupledDeformationContinuation, best As Double, peak As Double, accuracy As Double, verified As Boolean
    Dim limitFields As Collection, actual() As Double, force() As Double, field() As Double
    Dim low As Double, high As Double, onOffset As Boolean, point As Long, failure As Long, passed As Long
    Dim eps0 As Double, kx As Double, ky As Double, twist As Double
    If branch.CopySteelLimit(low, high, onOffset, point) Then
        branch.CopyLimitState limitFields, actual
    Else
        Set controlled = branch.ContinueByDeformation(maximum)
        If Not controlled Is Nothing Then
            Dim meta As CResultMeta: Set meta = controlled.ResultMeta
            best = controlled.BestAdmissibleLambda
            AddExperimentTraceTest report, tracePath, "A2_STRENGTH_CONTROL: " & meta.ResultComment & " | " & meta.DiagnosticDetails
            If controlled.CopyPeak(peak, accuracy, verified) Or controlled.CopySteelLimit(low, high, point) Then _
                controlled.CopyLimitState limitFields, actual
        End If
    End If
    AddExperimentTraceTest report, tracePath, "A2_STRENGTH_LIMIT;" & ExperimentNumberTest(best) & ";" & _
        ExperimentNumberTest(peak) & ";" & ExperimentNumberTest(accuracy) & ";" & CStr(verified) & ";" & _
        ExperimentNumberTest(low) & ";" & ExperimentNumberTest(high) & ";" & CStr(point)
    CheckLopesA2LocalPeakTest controlled, best, peak, point, limitFields, report, tracePath, passed, failure
    If limitFields Is Nothing Then
        If peak = 0# And point = 0 Then passed = passed + 1 Else failure = failure + 1
    Else
        If peak > 0# Then path.TargetSix peak, force Else path.TargetSix low, force
        field = limitFields.Item(limitFields.Count)
        operators.GeneralizedDeformation field, eps0, kx, ky, twist
        Dim errorNorm As Double: errorNorm = operators.ResultantResidualNorm(actual, force)
        AddExperimentTraceTest report, tracePath, "A2_STRENGTH_RESULTANT;" & ExperimentNumberTest(actual(4) / 1E+6) & ";" & _
            ExperimentNumberTest(twist * 1000#) & ";" & ExperimentNumberTest(errorNorm)
        If errorNorm < 0.000005 Then passed = passed + 1 Else failure = failure + 1
    End If
    SearchLopesA2StrengthTest = report & "TOTAL_A2_STRENGTH_SEARCH: passed=" & passed & "; failed=" & failure
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подтверждает, что ранний пик не записан как предельный максимум.
Private Sub CheckLopesA2LocalPeakTest(ByVal controlled As CCoupledDeformationContinuation, ByVal best As Double, _
        ByVal peak As Double, ByVal steelPoint As Long, ByVal fields As Collection, ByRef report As String, _
        ByVal tracePath As String, ByRef passed As Long, ByRef failures As Long)
    Dim passedLocal As Boolean, details As String, capacity As New CCapacityResult
    If Not controlled Is Nothing Then
        Const RECOVERY_MARKER As String = "максимумов превзойдено после спада: "
        Dim meta As CResultMeta: Set meta = controlled.ResultMeta
        details = meta.DiagnosticDetails
        Dim recoveryAt As Long: recoveryAt = InStr(details, RECOVERY_MARKER)
        If recoveryAt > 0 Then
            passedLocal = (Val(Mid$(details, recoveryAt + Len(RECOVERY_MARKER))) > 0 And _
                InStr(details, "локальный максимум lambda:") > 0 And peak = 0# And best > 1.54)
        End If
        If steelPoint = 0 Then
            capacity.InitializeCoupledUnresolved meta, "Auto", best
            passedLocal = passedLocal And (fields Is Nothing) And capacity.Status = "NumFail" And _
                capacity.HasConfirmedLowerBound And Not capacity.HasUltimatePoint
        End If
    End If
    AddExperimentTraceTest report, tracePath, "A2_LOCAL_PEAK_NOT_ULTIMATE: " & CStr(passedLocal)
    If passedLocal Then passed = passed + 1 Else failures = failures + 1
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует первое обнаружение события интервалом двух принятых точек.
Private Sub RecordLopesA2EventTest(ByVal eventName As String, ByVal detected As Boolean, ByRef reported As Boolean, _
        ByVal leftTwist As Double, ByVal leftMoment As Double, ByVal rightTwist As Double, ByVal rightMoment As Double, _
        ByRef report As String, ByVal tracePath As String)
    If Not detected Or reported Then Exit Sub
    reported = True
    AddExperimentTraceTest report, tracePath, "A2_EVENT;" & eventName & ";" & ExperimentNumberTest(leftTwist) & ";" & _
        ExperimentNumberTest(leftMoment) & ";" & ExperimentNumberTest(rightTwist) & ";" & ExperimentNumberTest(rightMoment)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит тот же наружный квадрат и восьмиугольный проём, что и КЭ-эталон.
Private Function BuildLopesA2SectionTest(ByVal wall As Double) As CSectionModel
    Dim query As New CSectionGeometryQuery, outer As CConcreteRegion, inner As CConcreteRegion, geometry As New CGeometryRegion
    Set outer = query.RectangleRegion(0#, 0#, 600#, 600#)
    Dim coordinates(1 To 8, 1 To 2) As Double, vertex As Variant, index As Long
    Dim halfOpening As Double, chamferStart As Double
    halfOpening = 300# - wall: chamferStart = halfOpening - 50#
    For Each vertex In Array(Array(-chamferStart, -halfOpening), Array(chamferStart, -halfOpening), _
            Array(halfOpening, -chamferStart), Array(halfOpening, chamferStart), Array(chamferStart, halfOpening), _
            Array(-chamferStart, halfOpening), Array(-halfOpening, chamferStart), Array(-halfOpening, -chamferStart))
        index = index + 1
        coordinates(index, 1) = vertex(0): coordinates(index, 2) = vertex(1)
    Next vertex
    Set inner = query.PolygonRegion(coordinates)
    geometry.Initialize query.SubtractContainedRegion(outer, inner)
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh geometry, 24#, 24#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    geometry.BuildContours section.Contours
    Set BuildLopesA2SectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Задаёт опубликованные размеры осей хомута и размещает стержни внутри него.
Private Sub AddLopesA2ReinforcementTest(ByVal section As CSectionModel, ByVal layout As CTransverseRebarLayout)
    Dim query As New CSectionGeometryQuery, path As CGeometryPath
    Set path = query.AdjacentRectangles("A2_HOOP", Array(Array(-269#, -265.5, 538#, 531#)))
    layout.AddGroup path, 8#, 80#, "A2_HOOP"
    Dim sx As Long, sy As Long, i As Long
    For sx = -1 To 1 Step 2
        For sy = -1 To 1 Step 2
            section.AddRebarElement sx * 259#, sy * 255.5, 12#, GEOM_PI * 36#, "A2_LONG"
        Next sy
        For i = -1 To 1
            section.AddRebarElement sx * 260#, i * 127.75, 10#, GEOM_PI * 25#, "A2_LONG"
            section.AddRebarElement i * 129.5, sx * 256.5, 10#, GEOM_PI * 25#, "A2_LONG"
        Next i
    Next sx
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит предварительный момент и натурные приращения Mx/T.
' Протокол хранит даже последнюю допустимую точку перед численным отказом.
Public Function RunTestCoupledTBU3(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3 = TraceTBU3Test(spansText, maximumStageText, False)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' До пятой стадии задаёт усилия, затем управляет закручиванием до
' запрошенной стадии либо до явно зафиксированной остановки.
Public Function RunTestCoupledTBU3Twist(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3Twist = TraceTBU3Test(spansText, maximumStageText, True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт начальную траекторию TBU3 рабочему алгоритму подтверждения
' первого максимума с повторным прохождением обоих плеч.
Public Function RunTestCoupledTBU3Peak(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3Peak = TraceTBU3Test(spansText, maximumStageText, True, True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет силовое и деформационное продолжение TBU3 с тремя историями.
Public Function RunTestCoupledTBU3SpatialPeak(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3SpatialPeak = TraceTBU3Test(spansText, maximumStageText, True, True, spatialHistory:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает деформацию обеих вертикальных ветвей в середине стенки
' на принятых полях с тремя пространственными историями.
' Первый аргумент принимает число интервалов или «интервалы x деления».
Public Function RunTestCoupledTBU3HoopGauge(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3HoopGauge = TraceTBU3HoopGaugeTest(spansText, maximumStageText, TBU3_REFERENCE_HOOP_SPACING)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет измерение обеих ветвей с шагом хомутов из схемы образца TBU.
' Дополнительно сохраняет точечное значение для сопоставления полей.
Public Function RunTestCoupledTBU3MeasuredHoop(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3MeasuredHoop = TraceTBU3HoopGaugeTest(spansText, maximumStageText, TBU3_MEASURED_HOOP_SPACING)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет базис при общей бетонной и арматурной квадратуре TBU3.
' Использует шаг хомутов 76 мм и исходные оси номинального сечения.
Public Function RunTestCoupledTBU3CommonHoopGauge(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3CommonHoopGauge = TraceTBU3HoopGaugeTest(spansText, maximumStageText, _
        TBU3_MEASURED_HOOP_SPACING, commonHoopQuadrature:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Оценивает чувствительность TBU3 к положению осей по рис. 9 Kuan и соавторов.
' В обоих случаях сохраняет бетонную сетку, материалы и общую квадратуру хомута.
Public Function RunTestCoupledTBU3PublishedAxes(ByVal caseText As String, ByVal maximumStageText As String) As String
    On Error GoTo Failed
    Dim bottomY As Double
    Select Case LCase$(Trim$(caseText))
        Case "cover": bottomY = TBU3_REFERENCE_BOTTOM_Y
        Case "coverandbottom": bottomY = TBU3_PUBLISHED_BOTTOM_Y
        Case Else: Err.Raise 5, , "Задайте вариант Cover или CoverAndBottom."
    End Select
    RunTestCoupledTBU3PublishedAxes = TraceTBU3PublishedAxesTest(maximumStageText, bottomY, TBU3_REFERENCE_PEAK_COMPRESSION)
    Exit Function
Failed:
    RunTestCoupledTBU3PublishedAxes = "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает две деформации пика на одной модели бетона и одной геометрии TBU3.
' Значение из табл. 2 меняет калибровку НДМ, остальные законы опыта сохраняются.
Public Function RunTestCoupledTBU3CompressionPeak(ByVal caseText As String, ByVal maximumStageText As String) As String
    On Error GoTo Failed
    Dim peakCompression As Double
    Select Case LCase$(Trim$(caseText))
        Case "reference": peakCompression = TBU3_REFERENCE_PEAK_COMPRESSION
        Case "published": peakCompression = TBU3_PUBLISHED_PEAK_COMPRESSION
        Case Else: Err.Raise 5, , "Задайте вариант Reference или Published."
    End Select
    RunTestCoupledTBU3CompressionPeak = TraceTBU3PublishedAxesTest(maximumStageText, TBU3_PUBLISHED_BOTTOM_Y, peakCompression)
    Exit Function
Failed:
    RunTestCoupledTBU3CompressionPeak = "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проводит сравнение TBU3 при слое хомута 6,35 мм и заданной оси нижнего ряда.
' Бетонная сетка, базис 2x6, шаг хомута 76 мм и порядок нагружения одинаковы.
Private Function TraceTBU3PublishedAxesTest(ByVal maximumStageText As String, ByVal bottomY As Double, _
        ByVal peakCompression As Double) As String
    TraceTBU3PublishedAxesTest = TraceTBU3Test("2", maximumStageText, True, spatialHistory:=True, _
        measureHoop:=True, cellsPerSpan:=6, hoopSpacing:=TBU3_MEASURED_HOOP_SPACING, _
        commonHoopQuadrature:=True, bottomY:=bottomY, publishedCover:=True, peakCompression:=peakCompression)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает разрешение базиса и запускает опыт с заданным шагом хомутов.
Private Function TraceTBU3HoopGaugeTest(ByVal spansText As String, ByVal maximumStageText As String, _
        ByVal hoopSpacing As Double, Optional ByVal commonHoopQuadrature As Boolean = False) As String
    On Error GoTo Failed
    Dim resolution() As String: resolution = Split(spansText, "x")
    Dim cellsPerSpan As Long: cellsPerSpan = 5
    If UBound(resolution) > 1 Then Err.Raise 5, , "Задайте число интервалов или «интервалы x деления»."
    If UBound(resolution) = 1 Then cellsPerSpan = CLng(Trim$(resolution(1)))
    TraceTBU3HoopGaugeTest = TraceTBU3Test(Trim$(resolution(0)), maximumStageText, True, _
        spatialHistory:=True, measureHoop:=True, cellsPerSpan:=cellsPerSpan, hoopSpacing:=hoopSpacing, _
        commonHoopQuadrature:=commonHoopQuadrature)
    Exit Function
Failed:
    TraceTBU3HoopGaugeTest = "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает принятые точки силового и деформационного контроля отдельно.
Private Function TraceTBU3Test(ByVal spansText As String, ByVal maximumStageText As String, ByVal followTwist As Boolean, _
        Optional ByVal confirmPeak As Boolean = False, Optional ByVal spatialHistory As Boolean = False, _
        Optional ByVal measureHoop As Boolean = False, Optional ByVal cellsPerSpan As Long = 5, _
        Optional ByVal hoopSpacing As Double = TBU3_REFERENCE_HOOP_SPACING, _
        Optional ByVal commonHoopQuadrature As Boolean = False, _
        Optional ByVal bottomY As Double = TBU3_REFERENCE_BOTTOM_Y, Optional ByVal publishedCover As Boolean = False, _
        Optional ByVal peakCompression As Double = TBU3_REFERENCE_PEAK_COMPRESSION) As String
    On Error GoTo Failed
    Const EC As Double = 30000#
    Const NU As Double = 0.2
    Const FC As Double = 34.8
    Const FT As Double = 1.95
    Const MX_OFFSET As Double = -29600000#
    Const DELTA_MX As Double = -14870000#
    Const DELTA_T As Double = 10350000#
    Dim report As String, passed As Long, failures As Long, tracePath As String
    Dim spans As Long: spans = CLng(spansText)
    Dim maximumStage As Long: maximumStage = CLng(maximumStageText)
    If spans < 1 Or spans > 3 Or maximumStage < 1 Or maximumStage > 21 Then Err.Raise 5, , "Тестовые границы: базис 1–3, стадия 1–21."
    If cellsPerSpan < 4 Or cellsPerSpan > 16 Then Err.Raise 5, , "Задайте от 4 до 16 делений на интервал базиса."
    Dim forceStage As Long: forceStage = maximumStage
    If followTwist And forceStage > 5 Then forceStage = 5
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) > 0 Then tracePath = ThisWorkbook.Path & "\TBU3_Trace.csv"
    AddExperimentTraceTest report, tracePath, "stage;actual_stage;Mx_kNm;T_kNm;kappa_per_m;twist_rad_per_m;hoop_utilization;steel_utilization;stress_residual_MPa;elapsed_s;status"

    Dim layout As CTransverseRebarLayout, steel As Object, section As CSectionModel
    Set section = BuildTBU3SectionTest(layout, steel, hoopSpacing, bottomY, publishedCover)
    If commonHoopQuadrature Then Set layout = CommonTBU3HoopLayoutTest(section, layout)
    Dim gaugeLeftX As Double, gaugeRightX As Double
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse, response As New CCoupledReinforcedResponse
    operators.PrepareModel section, EC, NU, spans, spans, cellsPerSpan, layout, steelModels:=steel
    If measureHoop Then
       Dim hoopPath As CGeometryPath: Set hoopPath = layout.Path(1)
        hoopPath.ProjectionBounds 1#, 0#, gaugeLeftX, gaugeRightX
        AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_X_MM;" & ExperimentNumberTest(gaugeLeftX) & ";" & _
            ExperimentNumberTest(gaugeRightX)
        AddExperimentTraceTest report, tracePath, "TBU3_HOOP_SPACING_MM;" & ExperimentNumberTest(hoopSpacing)
        If publishedCover Then
            AddExperimentTraceTest report, tracePath, "TBU3_LONG_BOTTOM_Y_MM;" & ExperimentNumberTest(bottomY)
            AddExperimentTraceTest report, tracePath, "TBU3_HOOP_CLEAR_COVER_MM;" & _
                ExperimentNumberTest(TBU3_HALF_WIDTH - gaugeRightX - layout.Diameter(1) / 2#)
            AddExperimentTraceTest report, tracePath, "TBU3_COMPRESSION_PEAK_STRAIN;" & ExperimentNumberTest(peakCompression)
        End If
        AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_BASE_MM;" & ExperimentNumberTest(-TBU3_MEASUREMENT_HALF_HEIGHT) & _
            ";" & ExperimentNumberTest(TBU3_MEASUREMENT_HALF_HEIGHT)
        AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_RESOLUTION;" & CStr(spans) & ";" & CStr(cellsPerSpan) & ";" & _
            CStr(operators.ConcretePointCount) & ";" & CStr(operators.PointCount) & ";" & CStr(operators.DegreeCount)
        AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_COLUMNS;stage;Mx_kNm;T_kNm;strain_left;strain_right"
    End If
    If commonHoopQuadrature Then RecordTBU3QuadratureTest operators, report, tracePath
    Dim solver As New CCoupledNewtonSolver, path As New CLoadPathVector, branch As New CCoupledLoadContinuation
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, FC, FT, peakCompression, 0.12, 80#, spatialHistory
    path.Initialize 0#, 0#, MX_OFFSET, DELTA_MX, 0#, 0#, 0#, DELTA_T
    branch.Initialize solver, path, 1, 12, 24, 0.0000005, 0.00000002, saveAcceptedFields:=confirmPeak

    Dim stage As Long, solved As Boolean, started As Double, reached As Double, meta As CResultMeta
    Dim field() As Double, achieved() As Double, target() As Double, errorNorm As Double
    Dim eps0 As Double, kx As Double, ky As Double, twist As Double, row As String
    For stage = 0 To forceStage
        started = Timer
        solved = branch.Advance(CDbl(stage))
        Set meta = branch.ResultMeta
        reached = branch.AcceptedLambda
        row = CStr(stage) & ";" & ExperimentNumberTest(reached)
        If branch.HasAcceptedVariableState Or branch.AcceptedOffsetFraction = 1# And solved Then
            branch.CopyAccepted field, achieved
            path.TargetSix reached, target
            operators.GeneralizedDeformation field, eps0, kx, ky, twist
            errorNorm = TBU3ForceErrorTest(achieved, target)
            If measureHoop And solved And errorNorm < 0.000005 Then _
                RecordTBU3HoopGaugeTest operators, field, reached, achieved, gaugeLeftX, gaugeRightX, spans, report, tracePath
            row = row & ";" & ExperimentNumberTest(-achieved(2) / 1E+6) & ";" & ExperimentNumberTest(achieved(4) / 1E+6) & _
                ";" & ExperimentNumberTest(-kx * 1000#) & ";" & ExperimentNumberTest(twist * 1000#) & _
                ";" & ExperimentNumberTest(response.AcceptedTransverseSteelUtilization) & ";" & ExperimentNumberTest(response.AcceptedSteelUtilization) & _
                ";" & ExperimentNumberTest(errorNorm)
            If errorNorm < 0.000005 Then passed = passed + 1 Else failures = failures + 1
        Else
            row = row & ";;;;;;;"
        End If
        row = row & ";" & ExperimentNumberTest(Timer - started)
        If solved Then
            AddExperimentTraceTest report, tracePath, row & ";Accepted"
        Else
            AddExperimentTraceTest report, tracePath, row & ";Unresolved"
            AddExperimentTraceTest report, tracePath, "DIAGNOSTICS: " & meta.ResultComment & " | " & meta.DiagnosticDetails
            Exit For
        End If
    Next stage
    AddExperimentTraceTest report, tracePath, "LAST_REQUESTED_STAGE_ACCEPTED: " & CStr(solved)
    If followTwist And branch.HasAcceptedVariableState And reached < maximumStage Then
        If confirmPeak Then
            ConfirmTBU3PeakTest operators, solver, path, branch, response, maximumStage, report, tracePath, passed, failures
        Else
            ContinueTBU3ByTwistTest operators, solver, path, branch, response, maximumStage, report, tracePath, passed, failures, _
                measureHoop, gaugeLeftX, gaugeRightX, spans
        End If
    End If
    If passed = 0 Then failures = failures + 1
    TraceTBU3Test = report & "TOTAL_TBU3_FORCE_EQUILIBRIUM: passed=" & passed & "; failed=" & failures
    Exit Function
Failed:
    TraceTBU3Test = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Делит одну замкнутую ось TBU3 по объединению узлов базисов 2 и 3.
' Штатная квадратура использует эти границы и для базиса 1.
Private Function CommonTBU3HoopLayoutTest(ByVal section As CSectionModel, _
        ByVal layout As CTransverseRebarLayout) As CTransverseRebarLayout
    Dim original As CGeometryPath: Set original = layout.Path(1)
    Dim axis As New CGeometryPath: axis.Initialize original.ID
    Dim basisTwo As New CCoupledSectionQuadrature, basisThree As New CCoupledSectionQuadrature
    basisTwo.Initialize section, 2, 2
    basisThree.Initialize section, 3, 3
    Dim edge As TRegionEdge, part As TRegionEdge, cuts() As Double, extraCuts() As Double
    Dim i As Long, j As Long, count As Long, extraCount As Long
    For i = 1 To original.SegmentCount
        original.CopySegment i, edge
        basisTwo.PathCuts edge, cuts, count
        basisThree.PathCuts edge, extraCuts, extraCount
        For j = 1 To extraCount: modGeometryPrimitives.AddScalar cuts, count, extraCuts(j): Next j
        modGeometryPrimitives.SortScalars cuts, count
        For j = 2 To count
            modGeometryPrimitives.SubEdge edge, cuts(j - 1), cuts(j), part
            axis.Append original.SegmentID(i) & "_" & CStr(j - 1), part
        Next j
    Next i
    axis.Seal True
    Dim result As New CTransverseRebarLayout
    result.AddGroup axis, layout.Diameter(1), layout.Spacing(1), layout.SteelClass(1), layout.SourceReference(1)
    Set CommonTBU3HoopLayoutTest = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает фактические координаты, веса и направления материальных
' точек в том порядке, в котором их получает решатель.
Private Sub RecordTBU3QuadratureTest(ByVal operators As CCoupledElasticState, ByRef report As String, ByVal tracePath As String)
    Dim index As Long, x As Double, y As Double, weight As Double, row As String, group As Long
    Dim direction(1 To 6) As Double, material As String
    For index = 1 To operators.PointCount
        operators.Point index, x, y, weight
        group = 0: material = "Concrete"
        If index > operators.ConcretePointCount Then
            group = operators.TransverseGroupAt(index)
            material = operators.SteelClassAt(index)
            operators.SteelProjection index, direction
        End If
        row = "TBU3_QUADRATURE;" & CStr(index) & ";" & material & ";" & CStr(group) & ";" & _
            ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(weight) & ";" & _
            ExperimentNumberTest(direction(1)) & ";" & ExperimentNumberTest(direction(2)) & ";" & _
            ExperimentNumberTest(direction(3)) & ";" & ExperimentNumberTest(direction(4))
        AddExperimentTraceTest report, tracePath, row
    Next index
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает продольные деформации обеих вертикальных ветвей в центре
' и на базе измерения. Читает кинематику из принятого поля.
Private Sub RecordTBU3HoopGaugeTest(ByVal operators As CCoupledElasticState, ByRef field() As Double, _
        ByVal stage As Double, ByRef achieved() As Double, ByVal gaugeLeftX As Double, ByVal gaugeRightX As Double, _
        ByVal verticalSpans As Long, ByRef report As String, ByVal tracePath As String)
    Dim strain(1 To 6) As Double, unusedWarping As Double, leftGauge As Double
    operators.KinematicsAt gaugeLeftX, 0#, field, strain, unusedWarping
    leftGauge = strain(2) ' Вертикальная прямая ветвь, направление ±y даёт одну и ту же проекцию.
    operators.KinematicsAt gaugeRightX, 0#, field, strain, unusedWarping
    AddExperimentTraceTest report, tracePath, "TBU3_GAUGE;" & ExperimentNumberTest(stage) & ";" & _
        ExperimentNumberTest(-achieved(2) / 1E+6) & ";" & ExperimentNumberTest(achieved(4) / 1E+6) & ";" & _
        ExperimentNumberTest(leftGauge) & ";" & ExperimentNumberTest(strain(2))
    AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_AVERAGE;" & ExperimentNumberTest(stage) & ";" & _
        ExperimentNumberTest(-achieved(2) / 1E+6) & ";" & ExperimentNumberTest(achieved(4) / 1E+6) & ";" & _
        ExperimentNumberTest(MeanTBU3GaugeStrainTest(operators, field, gaugeLeftX, verticalSpans)) & ";" & _
        ExperimentNumberTest(MeanTBU3GaugeStrainTest(operators, field, gaugeRightX, verticalSpans))
    Dim row As String, component As Long
    row = "TBU3_INTEGRALS;" & ExperimentNumberTest(stage)
    For component = 1 To 6: row = row & ";" & ExperimentNumberTest(achieved(component)): Next component
    AddExperimentTraceTest report, tracePath, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Осредняет εyy по двум соседним базам 76 мм в середине стенки.
' На каждом интервале кубического сплайна производная квадратична.
Private Function MeanTBU3GaugeStrainTest(ByVal operators As CCoupledElasticState, ByRef field() As Double, _
        ByVal x As Double, ByVal verticalSpans As Long) As Double
    Const GAUSS_ABSCISSA As Double = 0.577350269189626 ' Узел двухточечной квадратуры [-1, 1], вес 1.
    Dim lower As Double: lower = -TBU3_MEASUREMENT_HALF_HEIGHT
    Dim upper As Double, center As Double, halfWidth As Double, integral As Double
    Dim strain(1 To 6) As Double, unusedWarping As Double, span As Long
    For span = 1 To verticalSpans
        upper = GeomMin(TBU3_MEASUREMENT_HALF_HEIGHT, TBU3_HALF_HEIGHT * (2# * span / verticalSpans - 1#))
        If upper > lower Then
            center = 0.5 * (lower + upper): halfWidth = 0.5 * (upper - lower)
            operators.KinematicsAt x, center - GAUSS_ABSCISSA * halfWidth, field, strain, unusedWarping
            integral = integral + halfWidth * strain(2)
            operators.KinematicsAt x, center + GAUSS_ABSCISSA * halfWidth, field, strain, unusedWarping
            integral = integral + halfWidth * strain(2)
            lower = upper
        End If
        If lower >= TBU3_MEASUREMENT_HALF_HEIGHT Then Exit For
    Next span
    MeanTBU3GaugeStrainTest = integral / (2# * TBU3_MEASUREMENT_HALF_HEIGHT)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подключает одну или три истории к одним операторам и параметрам опыта.
' Центральная история используется для наблюдений в протоколах.
Private Sub InitializeExperimentSolverTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal center As CCoupledReinforcedResponse, ByVal steel As Object, _
        ByVal ec As Double, ByVal nu As Double, ByVal fc As Double, ByVal ft As Double, ByVal peakStrain As Double, _
        ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean, _
        Optional ByVal spatialMaterials As Collection = Nothing)
    Const LOCALIZATION_LENGTH As Double = 125# ' мм, принятое значение во всех трёх сопоставлениях.
    Dim pointCount As Long: pointCount = operators.PointCount
    Dim fc0 As Double: fc0 = 0.6 * fc ' Начальная прочность сжатия в материальной модели.
    concrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    center.Initialize operators, concrete, steel
    If Not spatialHistory Then
        solver.Initialize operators, center, ec
        Exit Sub
    End If
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    plusConcrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, center, ec, plusSide, minusSide
    If Not spatialMaterials Is Nothing Then
        spatialMaterials.Add minusConcrete: spatialMaterials.Add minusSide
        spatialMaterials.Add plusConcrete: spatialMaterials.Add plusSide
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет рабочий критерий максимума отдельно от наблюдаемого падения
' в диагностических точках. Сохраняет статус, точность и интегралы пика.
Private Sub ConfirmTBU3PeakTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByVal path As CLoadPathVector, ByVal branch As CCoupledLoadContinuation, ByVal response As CCoupledReinforcedResponse, _
        ByVal requestedStage As Long, ByRef report As String, ByVal tracePath As String, ByRef passed As Long, ByRef failures As Long)
    Const STAGE_TOLERANCE As Double = 0.005 ' 0,052 кН·м на траектории кручения TBU3.
    Dim baseLoad() As Double, direction() As Double, accepted() As Double, resultants() As Double
    path.Components baseLoad, direction
    branch.CopyAccepted accepted, resultants
    Dim controlled As New CCoupledDeformationContinuation
    AddExperimentTraceTest report, tracePath, "PEAK_SEARCH_STARTED: " & ExperimentNumberTest(branch.AcceptedLambda)
    controlled.Trace solver, response, baseLoad, direction, branch.AcceptedFields, branch.PreviousAcceptedLambda, _
        branch.AcceptedLambda, resultants, CDbl(requestedStage), STAGE_TOLERANCE, 24, 0.0000005, 0.00000002

    Dim meta As CResultMeta: Set meta = controlled.ResultMeta
    AddExperimentTraceTest report, tracePath, "PEAK_DIAGNOSTICS: " & meta.ResultComment & " | " & meta.DiagnosticDetails
    AddExperimentTraceTest report, tracePath, "PEAK_BEST_ADMISSIBLE_STAGE: " & ExperimentNumberTest(controlled.BestAdmissibleLambda)
    Dim peak As Double, accuracy As Double, designVerified As Boolean
    If Not controlled.CopyPeak(peak, accuracy, designVerified) Then
        AddExperimentTraceTest report, tracePath, "PEAK_CONFIRMED: False"
        Exit Sub
    End If
    AddExperimentTraceTest report, tracePath, "PEAK_CONFIRMED: True"
    Dim fields As Collection
    If Not controlled.CopyLimitState(fields, resultants) Then
        failures = failures + 1
        Exit Sub
    End If
    Dim target() As Double, eps0 As Double, kx As Double, ky As Double, twist As Double, errorNorm As Double
    path.TargetSix peak, target
    accepted = fields(fields.Count)
    operators.GeneralizedDeformation accepted, eps0, kx, ky, twist
    errorNorm = TBU3ForceErrorTest(resultants, target)
    AddExperimentTraceTest report, tracePath, "PEAK_STAGE_M_T_TWIST_ERROR_ACCURACY;" & ExperimentNumberTest(peak) & ";" & _
        ExperimentNumberTest(-resultants(2) / 1E+6) & ";" & ExperimentNumberTest(resultants(4) / 1E+6) & ";" & _
        ExperimentNumberTest(twist * 1000#) & ";" & ExperimentNumberTest(errorNorm) & ";" & ExperimentNumberTest(accuracy)
    If errorNorm < 0.000005 And accuracy <= STAGE_TOLERANCE Then passed = passed + 1 Else failures = failures + 1
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет переход через отказ силового шага по управляемому углу,
' сохраняя постоянный момент, отношение приращений и принятую историю.
Private Sub ContinueTBU3ByTwistTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByVal path As CLoadPathVector, ByVal branch As CCoupledLoadContinuation, ByVal response As CCoupledReinforcedResponse, _
        ByVal requestedStage As Long, ByRef report As String, ByVal tracePath As String, ByRef passed As Long, ByRef failures As Long, _
        ByVal measureHoop As Boolean, ByVal gaugeLeftX As Double, ByVal gaugeRightX As Double, ByVal verticalSpans As Long)
    Const MAX_ATTEMPTS As Long = 200 ' Лимит опытного прогона, включая уменьшения шага.
    Dim baseLoad() As Double, direction() As Double, projection() As Double
    path.Components baseLoad, direction
    ReDim projection(1 To operators.DegreeCount): projection(4) = 1#
    Dim field() As Double, achieved() As Double, target() As Double, eps0 As Double, kx As Double, ky As Double, twist As Double
    branch.CopyAccepted field, achieved
    operators.GeneralizedDeformation field, eps0, kx, ky, twist
    If twist <= 0# Then
        AddExperimentTraceTest report, tracePath, "TWIST_STOP: NonpositiveInitialTwist"
        Exit Sub
    End If
    Dim increment As Double, initialIncrement As Double, length As Double, reached As Double, coordinate As Double
    length = field(4) / twist ' Обобщённая координата равна относительному углу, умноженному на длину масштаба.
    initialIncrement = 0.0002 * length / 1000#
    increment = initialIncrement: reached = branch.AcceptedLambda: coordinate = field(4)
    Dim attempt As Long, trialLambda As Double, errorNorm As Double, row As String, started As Double, stopReason As String
    stopReason = "AttemptLimit"
    AddExperimentTraceTest report, tracePath, "TWIST_REQUESTED_STAGE: " & CStr(requestedStage)
    For attempt = 1 To MAX_ATTEMPTS
        started = Timer
        If solver.TryDeformationStep(baseLoad, direction, projection, coordinate + increment, reached, trialLambda, _
                0.0000005, 0.00000002, 24) Then
            solver.CopyTrial field, achieved: solver.AcceptStep
            coordinate = field(4): reached = trialLambda
            path.TargetSix reached, target
            operators.GeneralizedDeformation field, eps0, kx, ky, twist
            errorNorm = TBU3ForceErrorTest(achieved, target)
            If measureHoop And errorNorm < 0.000005 Then _
                RecordTBU3HoopGaugeTest operators, field, reached, achieved, gaugeLeftX, gaugeRightX, verticalSpans, report, tracePath
            row = "Twist" & CStr(attempt) & ";" & ExperimentNumberTest(reached) & ";" & ExperimentNumberTest(-achieved(2) / 1E+6) & _
                ";" & ExperimentNumberTest(achieved(4) / 1E+6) & ";" & ExperimentNumberTest(-kx * 1000#) & ";" & ExperimentNumberTest(twist * 1000#) & _
                ";" & ExperimentNumberTest(response.AcceptedTransverseSteelUtilization) & ";" & ExperimentNumberTest(response.AcceptedSteelUtilization) & _
                ";" & ExperimentNumberTest(errorNorm) & ";" & ExperimentNumberTest(Timer - started) & ";Accepted"
            AddExperimentTraceTest report, tracePath, row
            If errorNorm < 0.000005 Then passed = passed + 1 Else failures = failures + 1
            If reached >= requestedStage Then
                stopReason = "TargetReached"
                Exit For
            End If
            If increment < initialIncrement Then increment = increment * 1.25
            If increment > initialIncrement Then increment = initialIncrement
        Else
            AddExperimentTraceTest report, tracePath, "TWIST_REJECTED: " & CStr(attempt) & " | " & ExperimentNumberTest(Timer - started) & _
                " | " & solver.ResultMeta.ResultComment & " | " & solver.ResultMeta.DiagnosticDetails
            increment = increment * 0.5
            If increment < initialIncrement / 32# Then
                stopReason = "MinimumTwistIncrement"
                Exit For
            End If
        End If
    Next attempt
    AddExperimentTraceTest report, tracePath, "TWIST_CONTROL_REACHED_STAGE: " & ExperimentNumberTest(reached)
    AddExperimentTraceTest report, tracePath, "TWIST_STOP: " & stopReason
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выдаёт напряжения однородной коробки при шести ненулевых усилиях для
' сравнения с независимым треугольным КЭ-расчётом sectionproperties.
Public Function RunTestCoupledTBU3Elastic() As String
    On Error GoTo Failed
    Const E As Double = 30000#
    Const G As Double = E / 2# ' В обеих программах контроль проводится при нулевом коэффициенте Пуассона.
    Const FORCE As Double = 100000#
    Const MX As Double = 15000000#
    Const MY As Double = -11000000#
    Const TORQUE As Double = 10000000#
    Const QX As Double = 28000#
    Const QY As Double = -19000#
    Dim section As CSectionModel: Set section = BuildTBU3BoxTest()
    Dim points As Variant: points = Array(Array(0#, 167#), Array(0#, -167#), Array(216#, 0#), Array(-216#, 0#), _
        Array(210#, 170#), Array(-210#, -170#))
    Dim spans As Long, point As Variant, passed As Long, failed As Long, report As String
    Dim solver As CCoupledElasticState, deformation() As Double, resultants() As Double, stress() As Double
    Dim field() As Double, raw As Variant, strain(1 To 6) As Double, warping As Double
    Dim path As New CLoadPathVector, target() As Double
    path.Initialize 0#, FORCE, 0#, MX, 0#, MY, 0#, TORQUE, 0#, QX, 0#, QY
    path.TargetSix 1#, target
    For spans = 1 To 3
        Set solver = New CCoupledElasticState
        solver.PrepareModel section, E, 0#, spans, spans, 7
        If solver.Solve(FORCE, MX, MY, TORQUE, QX, QY, deformation, resultants, stress, raw) Then
            field = raw
            report = report & "ELASTIC_RIGIDITY;" & CStr(spans) & ";" & ExperimentNumberTest(TORQUE / (G * deformation(4))) & vbCrLf
            If TBU3ForceErrorTest(resultants, target) < 0.0000001 Then passed = passed + 1 Else failed = failed + 1
            For Each point In points
                solver.KinematicsAt CDbl(point(0)), CDbl(point(1)), field, strain, warping
                report = report & "ELASTIC_STRESS;" & CStr(spans) & ";" & ExperimentNumberTest(CDbl(point(0))) & ";" & ExperimentNumberTest(CDbl(point(1))) & _
                    ";" & ExperimentNumberTest(E * strain(3)) & ";" & ExperimentNumberTest(G * strain(5)) & ";" & ExperimentNumberTest(G * strain(6)) & vbCrLf
            Next point
        Else
            failed = failed + 1
            report = report & "FAIL: spans=" & CStr(spans) & " " & solver.ResultMeta.ResultComment & vbCrLf
        End If
    Next spans
    RunTestCoupledTBU3Elastic = report & "TOTAL_TBU3_ELASTIC_EQUILIBRIUM: passed=" & passed & "; failed=" & failed
    Exit Function
Failed:
    RunTestCoupledTBU3Elastic = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит номинальную коробку и измеренные площади стали. Для контроля
' чувствительности принимает положение нижнего ряда и слой хомута по публикации.
' Малая длина стыка хомута отдельно не моделируется.
Private Function BuildTBU3SectionTest(ByRef layout As CTransverseRebarLayout, ByRef steel As Object, _
        ByVal hoopSpacing As Double, ByVal bottomY As Double, ByVal publishedCover As Boolean) As CSectionModel
    Dim section As CSectionModel: Set section = BuildTBU3BoxTest()

    Dim i As Long, dx As Double
    For i = -3 To 3
        dx = 206# * CDbl(i) / 3#
        section.AddRebarElement dx, bottomY, Sqr(4# * 510# / GEOM_PI), 510#, "TBU3_8"
    Next i
    For i = -1 To 1
        section.AddRebarElement 216# * i, 167#, Sqr(4# * 129# / GEOM_PI), 129#, "TBU3_4"
        section.AddRebarElement -218#, 78# * i, Sqr(4# * 71# / GEOM_PI), 71#, "TBU3_3"
        section.AddRebarElement 218#, 78# * i, Sqr(4# * 71# / GEOM_PI), 71#, "TBU3_3"
    Next i
    Set layout = New CTransverseRebarLayout
    Dim diameter As Double: diameter = Sqr(4# * 129# / GEOM_PI)
    Dim cover As Double: cover = 32# - diameter / 2# ' Исходная ось отстоит от контура бетона на 32 мм.
    If publishedCover Then cover = TBU3_PUBLISHED_HOOP_COVER
    layout.AddContourGroup section, "TBU3_HOOP", vbNullString, diameter, hoopSpacing, cover, "TBU3_HOOP"

    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "TBU3_8", ExperimentBilinearSteelTest(194200#, 436#, 9000#)
    steel.Add "TBU3_4", ExperimentBilinearSteelTest(201900#, 393#, 4900#)
    steel.Add "TBU3_3", ExperimentBilinearSteelTest(205100#, 552#, 9000#)
    steel.Add "TBU3_HOOP", ExperimentBilinearSteelTest(198500#, 379#, 5200#)
    Set BuildTBU3SectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Использует одинаковые контуры для упругой и нелинейной постановок.
Private Function BuildTBU3BoxTest() As CSectionModel
    Dim query As New CSectionGeometryQuery, outer As CConcreteRegion, inner As CConcreteRegion, geometry As New CGeometryRegion
    Set outer = query.RegionFromPath(query.AdjacentRectangles("TBU3_Outer", Array(Array(-TBU3_HALF_WIDTH, -TBU3_HALF_HEIGHT, 2# * TBU3_HALF_WIDTH, 2# * TBU3_HALF_HEIGHT))))
    Set inner = query.RegionFromPath(query.AdjacentRectangles("TBU3_Opening", Array(Array(-178#, -129#, 356#, 258#))))
    geometry.Initialize query.SubtractContainedRegion(outer, inner)
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh geometry, 20#, 18#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    geometry.BuildContours section.Contours
    Set BuildTBU3BoxTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Двухлинейная аппроксимация измеренной стали. После текучести модуль
' упрочнения включается сразу. Предел 0,05 принят только для диагностики.
Private Function ExperimentBilinearSteelTest(ByVal modulus As Double, ByVal strength As Double, ByVal hardening As Double) As CCoupledSteelModel
    Dim steel As New CCoupledSteelModel
    steel.Initialize modulus, strength, strength, hardening, hardening, 0.05, 0.05
    Set ExperimentBilinearSteelTest = steel
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Приводит остатки шести усилий к МПа по номинальной площади коробки.
Private Function TBU3ForceErrorTest(ByRef achieved() As Double, ByRef target() As Double) As Double
    Const AREA As Double = 508# * 410# - 356# * 258#
    Dim i As Long, difference As Double
    For i = 1 To 6
        difference = Abs(achieved(i) - target(i)) / AREA
        If i >= 2 And i <= 4 Then difference = difference / 508#
        If difference > TBU3ForceErrorTest Then TBU3ForceErrorTest = difference
    Next i
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Русская локаль Excel не меняет десятичную точку в машинном протоколе.
Private Function ExperimentNumberTest(ByVal value As Double) As String
    ExperimentNumberTest = Trim$(Str$(value))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Отмечает завершённую стадию также на диске, чтобы длительный контроль
' можно было наблюдать без обращения к пользовательскому экземпляру Excel.
Private Sub AddExperimentTraceTest(ByRef report As String, ByVal path As String, ByVal row As String)
    report = report & row & vbCrLf
    If Len(path) = 0 Then Exit Sub
    Dim file As Integer: file = FreeFile
    Open path For Append As #file
    Print #file, row
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает собственные истории материала на разных квадратурах, начиная с нулевой нагрузки.
Public Function RunTestA2ColdQuadrature(ByVal quadrature As String) As String
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга."
    If quadrature <> "5" And quadrature <> "7" And quadrature <> "9" Then Err.Raise 5, , "Неизвестная квадратура."
    RunTestA2ColdQuadrature = TraceLopesA2Test("1", ".029", True, spatialHistory:=True, sampling:=CLng(quadrature), coldAudit:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет шесть усилий и коэффициенты каждого принятого поля для повторов от точной истории.
Private Sub RecordA2ColdFieldTest(ByRef report As String, ByVal path As String, ByVal retained As Long, _
        ByVal attempt As Long, ByRef field() As Double, ByRef loads() As Double, ByVal twist As Double, ByVal residual As Double)
    Dim row As String, i As Long
    row = "FIELD;" & CStr(retained) & ";" & CStr(attempt) & ";" & ExperimentNumberTest(twist * 1000#) & ";" & ExperimentNumberTest(residual)
    For i = LBound(loads) To UBound(loads): row = row & ";" & ExperimentNumberTest(loads(i)): Next i
    For i = LBound(field) To UBound(field): row = row & ";" & ExperimentNumberTest(field(i)): Next i
    AddExperimentTraceTest report, path, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет точные опытные моменты на собственной принятой истории уточнённой квадратуры.
Public Function RunTestA2RefinedExactTorque(ByVal inputPath As String, ByVal lane As String) As String
    Dim report As String, handle As Integer
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга."
    handle = FreeFile
    Open inputPath For Input As #handle
    Dim line As String, values() As String, q As Long, n As Long, count As Long
    Line Input #handle, line: values = Split(line, ";")
    q = CLng(values(0)): n = CLng(values(1)): count = CLng(values(2))
    If (q <> 7 And q <> 9) Or n < 3 Or count < 1 Or count > 3 Then Err.Raise 5, , "Неверная история A2."
    Dim i As Long, j As Long, fields As New Collection, field() As Double, moments() As Double
    ReDim moments(1 To n)
    For i = 1 To n
        Line Input #handle, line: values = Split(line, ";")
        If UBound(values) <> 61 Or CLng(values(0)) <> i Then Err.Raise 5, , "Неверный префикс поля A2."
        moments(i) = Val(values(1))
        ReDim field(1 To 60)
        For j = 1 To 60: field(j) = Val(values(j + 1)): Next j
        fields.Add field
    Next i
    Dim target() As Double, left() As Long
    ReDim target(1 To count): ReDim left(1 To count)
    For i = 1 To count
        Line Input #handle, line: values = Split(line, ";")
        target(i) = Val(values(0)): left(i) = CLng(values(1))
        If left(i) < 2 Or left(i) >= n Then Err.Raise 5, , "Неверный интервал момента."
        If target(i) <= moments(left(i)) Or target(i) > moments(left(i) + 1) Then Err.Raise 5, , "Момент вне принятого подъёма."
    Next i
    If Not EOF(handle) Then Err.Raise 5, , "Лишние записи в истории A2."
    Close #handle: handle = 0

    Const FC As Double = 47.3, FT As Double = 3.5, EC As Double = 36100#, NU As Double = 0.2
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.00000002
    Dim section As CSectionModel: Set section = BuildLopesA2SectionTest(107#)
    Dim layout As New CTransverseRebarLayout, steel As Object: Set steel = CreateObject("Scripting.Dictionary")
    AddLopesA2ReinforcementTest section, layout
    steel.Add "A2_LONG", ExperimentBilinearSteelTest(200000#, 672#, 0#)
    steel.Add "A2_HOOP", ExperimentBilinearSteelTest(200000#, 696#, 0#)
    Dim operators As New CCoupledElasticState, response As New CCoupledReinforcedResponse
    Dim concrete As New CCoupledConcreteResponse, solver As New CCoupledNewtonSolver, gt As Double
    operators.PrepareModel section, EC, NU, 1, 1, q, layout, steelModels:=steel
    If operators.DegreeCount <> 60 Or operators.PointCount - operators.ConcretePointCount <> 32 Then _
        Err.Raise 5, , "Не совпадает базис или состав арматуры."
    gt = 0.073 * FC ^ 0.18
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, FC, FT, 0.002, gt * LopesA2TensileEnergyScaleTest(lane), (FC / FT) ^ 2 * gt, True
    Dim trace As String: trace = ThisWorkbook.Path & "\A2RefinedExact.csv"
    AddExperimentTraceTest report, trace, "GRID;" & CStr(q) & ";" & CStr(operators.ConcretePointCount) & ";" & CStr(n)
    Dim area As Double, scaleLength As Double
    operators.CopyResultantResidualScales area, scaleLength
    AddExperimentTraceTest report, trace, "SCALES;" & ExperimentNumberTest(area) & ";" & ExperimentNumberTest(scaleLength)
    Dim right() As Double, leftControl As Double, rightControl As Double, trialControl As Double, ratio As Double, solved As Boolean
    Dim initial As Variant, actual() As Double, expected(1 To 6) As Double, meta As CResultMeta
    Dim offset(1 To 6) As Double, direction(1 To 6) As Double, projection(1 To 60) As Double
    Dim lambda As Double, errorNorm As Double, route As String, passed As Long, failures As Long
    direction(4) = 100000000#: projection(4) = 1#
    For i = 1 To count
        If Not solver.ReplayAcceptedFields(fields, left(i)) Then Err.Raise 5, , "Не воспроизведена собственная история материала."
        solver.CopyAccepted field: right = fields(left(i) + 1)
        leftControl = field(4): rightControl = right(4)
        ratio = (target(i) - moments(left(i))) / (moments(left(i) + 1) - moments(left(i)))
        For j = 1 To 60: field(j) = field(j) + ratio * (right(j) - field(j)): Next j
        trialControl = field(4)
        initial = field: expected(4) = target(i) * 1000000#: route = "Force"
        solved = solver.TryStep(0#, 0#, 0#, expected(4), 0#, 0#, ABS_TOL, REL_TOL, 35, initial)
        If Not solved Then
            If solver.TryDeformationStep(offset, direction, projection, trialControl, target(i) / 100#, _
                    lambda, ABS_TOL, REL_TOL, 30, consistentControl:=True) Then
                solver.CopyTrial field, actual
                solver.DiscardStep
                initial = field: route = "ControlSeed"
                solved = solver.TryStep(0#, 0#, 0#, expected(4), 0#, 0#, ABS_TOL, REL_TOL, 35, initial)
            End If
        End If
        If solved Then
            solver.CopyTrial field, actual
            errorNorm = operators.ResultantResidualNorm(actual, expected)
            If errorNorm > 0.000005 Or field(4) < leftControl Or field(4) > rightControl Or response.TrialSteelUtilization > 1# Then _
                Err.Raise 5, , "Точная проба вышла из интервала или превысила допуск."
            solver.AcceptStep
            line = "ANCHOR;" & CStr(i) & ";" & ExperimentNumberTest(target(i)) & ";" & CStr(left(i)) & ";" & _
                ExperimentNumberTest(field(4) * 1000# / scaleLength) & ";" & ExperimentNumberTest(errorNorm) & ";" & route
            For j = 1 To 6: line = line & ";" & ExperimentNumberTest(actual(j)): Next j
            AddExperimentTraceTest report, trace, line
            RecordA2YieldAnchorTest operators, concrete, response, field, i, trace
            passed = passed + 1
        Else
            Set meta = solver.ResultMeta
            AddExperimentTraceTest report, trace, "FAILED;" & ExperimentNumberTest(target(i)) & ";" & meta.DiagnosticDetails
            failures = failures + 1
        End If
    Next i
    RunTestA2RefinedExactTorque = report & "TOTAL_A2_REFINED_EXACT: passed=" & CStr(passed) & "; failed=" & CStr(failures)
    Exit Function
Failed:
    Dim failure As String: failure = Err.Description
    If handle > 0 Then Close #handle
    RunTestA2RefinedExactTorque = report & "RUNTIME ERROR: " & failure
End Function
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает напряжения бетона и знаковые деформации стержней на точной силовой цели.
Private Sub RecordA2YieldAnchorTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByVal anchor As Long, ByVal path As String)
    Dim id As Integer, i As Long, j As Long, x As Double, y As Double, area As Double
    Dim strain(1 To 6) As Double, stress(1 To 6) As Double, direction(1 To 6) As Double
    Dim rodStress As Double, rodStrain As Double, tension As Double, compression As Double, family As String, row As String
    id = FreeFile
    Open path For Append As #id
    For i = 1 To operators.PointCount
        operators.Point i, x, y, area
        operators.PointStrain i, field, strain
        concrete.CopyAcceptedStress i, stress
        concrete.AcceptedPointDamage i, tension, compression
        rodStress = 0#: rodStrain = 0#: family = "Concrete"
        For j = 1 To 6: direction(j) = 0#: Next j
        If i > operators.ConcretePointCount Then
            operators.SteelProjection i, direction
            For j = 1 To 6: rodStrain = rodStrain + strain(j) * direction(j): Next j
            rodStress = response.AcceptedSteelStress(i)
            If operators.TransverseGroupAt(i) > 0 Then
                family = "Hoop"
            ElseIf Abs(x) > 250# And Abs(y) > 250# Then
                family = "LongitudinalCorner"
            Else
                family = "LongitudinalSide"
            End If
        End If
        row = "POINT;" & CStr(anchor) & ";" & CStr(i) & ";" & family & ";" & ExperimentNumberTest(x) & ";" & _
            ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area) & ";" & ExperimentNumberTest(rodStress) & ";" & _
            ExperimentNumberTest(rodStrain) & ";" & ExperimentNumberTest(tension) & ";" & ExperimentNumberTest(compression)
        For j = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(j)): Next j
        For j = 1 To 6: row = row & ";" & ExperimentNumberTest(direction(j)): Next j
        Print #id, row
    Next i
    Close #id
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прослеживает две отдельные истории A2 от нуля. Меняется только энергия растяжения.
Public Function RunTestA2TensileEnergyCold(ByVal lane As String) As String
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга."
    RunTestA2TensileEnergyCold = TraceLopesA2Test("1", ".035", True, spatialHistory:=True, sampling:=9, _
        coldAudit:=True, tensileEnergyScale:=LopesA2TensileEnergyScaleTest(lane), measuredTorqueStop:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает множитель выбранной ветви опыта. Длина и энергия сжатия едины.
Private Function LopesA2TensileEnergyScaleTest(ByVal lane As String) As Double
    Select Case lane
        Case "A": LopesA2TensileEnergyScaleTest = 1#
        Case "B": LopesA2TensileEnergyScaleTest = 125# / 153#
        Case Else: Err.Raise 5, , "Неизвестная постановка опыта A2."
    End Select
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продолжает послетрещинную ветвь A2 с материалами собственной квадратуры.
Public Function RunTestA2ResumeRefined(ByVal inputPath As String, ByVal lane As String) As String
    Dim report As String, handle As Integer
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга."
    Const sampling As String = "9"
    Dim tensileScale As Double: tensileScale = LopesA2TensileEnergyScaleTest(lane)
    Dim fields As New Collection, values() As String, field() As Double, saved() As Double
    Dim n As Long, i As Long, j As Long, line As String
    handle = FreeFile
    Open inputPath For Input As #handle
    Line Input #handle, line: values = Split(line, ";")
    If UBound(values) <> 2 Then Err.Raise 5, , "Отсутствует идентификатор истории A2."
    If values(2) <> lane Then Err.Raise 5, , "Постановка истории A2 не совпадает."
    n = CLng(values(0))
    Dim nextStep As Double: nextStep = Val(values(1))
    If nextStep <= 0# Or nextStep > 0.001 Then Err.Raise 5, , "Неверный шаг продолжения A2."
    If n < 3 Then Err.Raise 5, , "Недостаточно полей для продолжения."
    Dim prescribed() As Double, torque() As Double
    ReDim prescribed(1 To n): ReDim torque(1 To n): ReDim saved(1 To 6)
    For i = 1 To n
        Line Input #handle, line: values = Split(line, ";")
        If UBound(values) <> 67 Or CLng(values(0)) <> i Then Err.Raise 5, , "Неверная история поля A2."
        prescribed(i) = Val(values(1)): torque(i) = Val(values(5))
        For j = 1 To 6: saved(j) = Val(values(j + 1)): Next j
        ReDim field(1 To 60)
        For j = 1 To 60: field(j) = Val(values(j + 7)): Next j
        fields.Add field
    Next i
    If Not EOF(handle) Then Err.Raise 5, , "Неверный конец истории."
    Close #handle: handle = 0

    Const FC As Double = 47.3, FT As Double = 3.5, EC As Double = 36100#, NU As Double = 0.2
    Dim section As CSectionModel: Set section = BuildLopesA2SectionTest(107#)
    Dim layout As New CTransverseRebarLayout, steel As Object: Set steel = CreateObject("Scripting.Dictionary")
    AddLopesA2ReinforcementTest section, layout
    steel.Add "A2_LONG", ExperimentBilinearSteelTest(200000#, 672#, 0#)
    steel.Add "A2_HOOP", ExperimentBilinearSteelTest(200000#, 696#, 0#)
    Dim operators As New CCoupledElasticState, response As New CCoupledReinforcedResponse
    Dim concrete As New CCoupledConcreteResponse, solver As New CCoupledNewtonSolver, gt As Double
    operators.PrepareModel section, EC, NU, 1, 1, CLng(sampling), layout, steelModels:=steel
    If operators.DegreeCount <> 60 Or operators.PointCount - operators.ConcretePointCount <> 32 Then _
        Err.Raise 5, , "Префикс не соответствует модели A2."
    gt = 0.073 * FC ^ 0.18
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, FC, FT, 0.002, gt * tensileScale, (FC / FT) ^ 2 * gt, True
    If Not solver.ReplayAcceptedFields(fields, n) Then Err.Raise 5, , "Не восстановлена собственная материальная история A2."
    solver.CopyAccepted field
    Dim trace As String: trace = ThisWorkbook.Path & "\A2RefinedResume.csv"
    AddExperimentTraceTest report, trace, "RESUME;" & sampling & ";" & CStr(n) & ";" & CStr(operators.ConcretePointCount)
    AddExperimentTraceTest report, trace, "RESUME_LAW;" & lane & ";" & _
        ExperimentNumberTest(gt * tensileScale) & ";" & ExperimentNumberTest((FC / FT) ^ 2 * gt)
    VerifyA2ResumePrefixTest solver, operators, concrete, response, field, saved, report, trace

    Dim previousField() As Double: previousField = fields(n - 1)
    RunTestA2ResumeRefined = ContinueA2ResumeTest(solver, operators, concrete, response, previousField, field, _
        prescribed(n - 1), prescribed(n), torque(n - 1) / 100000000#, torque(n) / 100000000#, n, nextStep, report, trace)
    Exit Function
Failed:
    Dim problem As String: problem = Err.Description
    If handle > 0 Then Close #handle
    RunTestA2ResumeRefined = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет слабые уравнения и заново интегрирует шесть усилий по восстановленным напряжениям.
Private Sub VerifyA2ResumePrefixTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal response As CCoupledReinforcedResponse, _
        ByRef field() As Double, ByRef saved() As Double, ByRef report As String, ByVal trace As String)
    Dim internal() As Double, dummy() As Double, external() As Double, i As Long, j As Long
    If Not solver.TestEquilibriumLinearization(field, False, True, internal, dummy) Then _
        Err.Raise 5, , "Не получена невязка восстановленного поля."
    operators.LoadEquations saved(1), saved(2), saved(3), saved(4), saved(5), saved(6), external
    Dim weakError As Double
    For i = 1 To 56: weakError = GeomMax(weakError, Abs(internal(i) - external(i))): Next i

    Dim stress(1 To 6) As Double, axis(1 To 6) As Double, sum(1 To 6) As Double
    Dim x As Double, y As Double, area As Double, rod As Double
    For i = 1 To operators.PointCount
        operators.Point i, x, y, area
        concrete.CopyAcceptedStress i, stress
        If i > operators.ConcretePointCount Then
            operators.SteelProjection i, axis
            rod = response.AcceptedSteelStress(i)
            For j = 1 To 6: stress(j) = rod * axis(j) - stress(j): Next j
        End If
        sum(1) = sum(1) + stress(3) * area
        sum(2) = sum(2) + y * stress(3) * area
        sum(3) = sum(3) + x * stress(3) * area
        sum(4) = sum(4) + (x * stress(6) - y * stress(5)) * area
        sum(5) = sum(5) + stress(5) * area
        sum(6) = sum(6) + stress(6) * area
    Next i
    Dim forceError As Double: forceError = operators.ResultantResidualNorm(sum, saved)
    If weakError > 0.000005 Or forceError > 0.000005 Then _
        Err.Raise 5, , "Восстановленный префикс потерял равновесие. " & ExperimentNumberTest(weakError) & "; " & ExperimentNumberTest(forceError)
    Dim row As String: row = "REPLAY;" & ExperimentNumberTest(weakError) & ";" & ExperimentNumberTest(forceError)
    For i = 1 To 6: row = row & ";" & ExperimentNumberTest(sum(i)): Next i
    AddExperimentTraceTest report, trace, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продолжает точное управление закручиванием с проверкой каждого принятого состояния.
Private Function ContinueA2ResumeTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal response As CCoupledReinforcedResponse, _
        ByRef previous() As Double, ByRef current() As Double, ByVal previousTwist As Double, ByVal twist As Double, _
        ByVal previousLambda As Double, ByVal lambda As Double, ByVal prefix As Long, ByVal initialStep As Double, _
        ByRef report As String, ByVal trace As String) As String
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.00000002
    Const MAX_TWIST As Double = 0.035, MAX_STEP As Double = 0.001, MIN_STEP As Double = 0.000001953125
    Const TARGET_TORQUE As Double = 2.548
    Dim offset(1 To 6) As Double, direction(1 To 6) As Double, projection(1 To 60) As Double, expected(1 To 6) As Double
    projection(4) = 1#: direction(4) = 100000000#
    Dim sectionArea As Double, sectionLength As Double
    operators.CopyResultantResidualScales sectionArea, sectionLength
    Dim increment As Double: increment = initialStep
    Dim attempt As Long, acceptedCount As Long, route As String, stopReason As String
    Dim trialTwist As Double, target As Double, trialLambda As Double, lambdaGuess As Double, ratio As Double, started As Double
    Dim actual() As Double, found() As Double
    Dim accepted As Boolean, j As Long, meta As CResultMeta
    stopReason = "AttemptLimit"
    For attempt = 1 To 125
        trialTwist = GeomMin(MAX_TWIST, twist + increment)
        target = trialTwist * sectionLength / 1000#
        ratio = (trialTwist - twist) / (twist - previousTwist)
        accepted = False: route = "AcceptedField": started = Timer
        If ratio > 0# And ratio <= 1.25000001 Then
            lambdaGuess = lambda + ratio * (lambda - previousLambda)
            If lambdaGuess > 0# And lambdaGuess <> lambda Then
                accepted = solver.TryDeformationStep(offset, direction, projection, target, lambdaGuess, trialLambda, _
                    ABS_TOL, REL_TOL, 24, consistentControl:=True)
                If accepted Then
                    solver.CopyTrial found, actual
                    If ForwardA2ResumeTest(previous, current, found, ratio) Then
                        route = "LoadSecant"
                    Else
                        solver.DiscardStep
                        accepted = False
                    End If
                End If
            End If
        End If
        If Not accepted Then
            accepted = solver.TryDeformationStep(offset, direction, projection, target, lambda, trialLambda, _
                ABS_TOL, REL_TOL, 24, consistentControl:=True)
        End If
        If accepted Then
            solver.CopyTrial found, actual
            expected(4) = trialLambda * direction(4)
            Dim norm As Double: norm = operators.ResultantResidualNorm(actual, expected)
            If norm > 0.000005 Or Abs(found(4) - target) > 0.00000000001 Or trialLambda <= 0# Then _
                Err.Raise 5, , "Проверка шести усилий или закручивания не пройдена."
            If response.TrialSteelUtilization > 1# Then
                solver.DiscardStep: stopReason = "SteelStrainBracket"
                Exit For
            End If
            solver.AcceptStep: acceptedCount = acceptedCount + 1
            trialTwist = found(4) * 1000# / sectionLength
            If trialTwist <= twist Then Err.Raise 5, , "Контролируемое закручивание не продвинулось."
            RecordA2ResumeFieldTest operators, concrete, response, found, actual, trialTwist, norm, route, _
                prefix + acceptedCount, attempt, Timer - started, report, trace
            previous = current: current = found
            previousTwist = twist: twist = trialTwist
            previousLambda = lambda: lambda = trialLambda
            If lambda >= TARGET_TORQUE Then
                stopReason = "MeasuredTorqueBracketed"
                Exit For
            End If
            If twist >= MAX_TWIST Then
                stopReason = "TwistLimit"
                Exit For
            End If
            increment = GeomMin(MAX_STEP, increment * 1.25)
        Else
            Set meta = solver.ResultMeta
            AddExperimentTraceTest report, trace, "REJECT;" & CStr(attempt) & ";" & ExperimentNumberTest(trialTwist) & ";" & meta.DiagnosticDetails
            increment = increment * 0.5
            If increment < MIN_STEP Then
                stopReason = "MinimumTwistIncrement"
                Exit For
            End If
        End If
    Next attempt
    AddExperimentTraceTest report, trace, "STOP;" & stopReason & ";" & CStr(acceptedCount)
    ContinueA2ResumeTest = report & "TOTAL_A2_REFINED_RESUME: passed=" & CStr(acceptedCount + 1) & "; failed=0"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Ограничивает переход по прогнозу направлением и размером последней деформации без множителей связей.
Private Function ForwardA2ResumeTest(ByRef previous() As Double, ByRef current() As Double, _
        ByRef found() As Double, ByVal ratio As Double) As Boolean
    Dim i As Long, priorDelta As Double, trialDelta As Double, priorNorm As Double, trialNorm As Double, projection As Double
    For i = 1 To 56
        priorDelta = current(i) - previous(i): trialDelta = found(i) - current(i)
        priorNorm = priorNorm + priorDelta * priorDelta
        trialNorm = trialNorm + trialDelta * trialDelta
        projection = projection + priorDelta * trialDelta
    Next i
    ForwardA2ResumeTest = projection > 0# And trialNorm <= 9# * ratio * ratio * priorNorm
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает знаковые нагрузки и поле для независимого решения опытных моментов.
Private Sub RecordA2ResumeFieldTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByRef actual() As Double, _
        ByVal twist As Double, ByVal norm As Double, ByVal route As String, ByVal index As Long, ByVal attempt As Long, _
        ByVal seconds As Double, ByRef report As String, ByVal trace As String)
    Dim j As Long, hoop As Double, longitudinal As Double, tension As Double, compression As Double, peakDamage As Double
    For j = 1 To operators.ConcretePointCount
        concrete.AcceptedPointDamage j, tension, compression
        peakDamage = GeomMax(peakDamage, tension)
    Next j
    For j = operators.ConcretePointCount + 1 To operators.PointCount
        If operators.TransverseGroupAt(j) > 0 Then
            hoop = GeomMax(hoop, Abs(response.AcceptedSteelStress(j)))
        Else
            longitudinal = GeomMax(longitudinal, Abs(response.AcceptedSteelStress(j)))
        End If
    Next j
    If seconds < 0# Then seconds = seconds + 86400#
    Dim row As String
    row = "FIELD;" & CStr(index) & ";" & CStr(attempt) & ";" & route & ";" & ExperimentNumberTest(twist) & ";" & _
        ExperimentNumberTest(norm) & ";" & ExperimentNumberTest(hoop) & ";" & ExperimentNumberTest(longitudinal) & ";" & _
        ExperimentNumberTest(peakDamage) & ";" & ExperimentNumberTest(seconds)
    For j = 1 To 6: row = row & ";" & ExperimentNumberTest(actual(j)): Next j
    For j = 1 To 60: row = row & ";" & ExperimentNumberTest(field(j)): Next j
    AddExperimentTraceTest report, trace, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продолжает послетрещинную ветвь A2 с материалами собственной квадратуры.
Public Function RunTestA2PostAnchor(ByVal inputPath As String, ByVal lane As String) As String
    Dim report As String, handle As Integer
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга."
    Const sampling As String = "9"
    Dim tensileScale As Double: tensileScale = LopesA2TensileEnergyScaleTest(lane)
    Dim fields As New Collection, values() As String, field() As Double, saved() As Double
    Dim n As Long, i As Long, j As Long, line As String
    handle = FreeFile
    Open inputPath For Input As #handle
    Line Input #handle, line: values = Split(line, ";")
    If UBound(values) <> 2 Then Err.Raise 5, , "Отсутствует идентификатор истории A2."
    If values(2) <> "B" Or lane <> "B" Then Err.Raise 5, , "Постановка истории A2 не совпадает."
    n = CLng(values(0))
    Dim nextStep As Double: nextStep = Val(values(1))
    If nextStep <= 0# Or nextStep > 0.001 Then Err.Raise 5, , "Неверный шаг продолжения A2."
    If n <> 43 Then Err.Raise 5, , "Требуется собственная принятая история B до поля 43."
    Dim prescribed() As Double, torque() As Double
    ReDim prescribed(1 To n): ReDim torque(1 To n): ReDim saved(1 To 6)
    For i = 1 To n
        Line Input #handle, line: values = Split(line, ";")
        If UBound(values) <> 67 Or CLng(values(0)) <> i Then Err.Raise 5, , "Неверная история поля A2."
        prescribed(i) = Val(values(1)): torque(i) = Val(values(5))
        For j = 1 To 6: saved(j) = Val(values(j + 1)): Next j
        ReDim field(1 To 60)
        For j = 1 To 60: field(j) = Val(values(j + 7)): Next j
        fields.Add field
    Next i
    If Not EOF(handle) Then Err.Raise 5, , "Неверный конец истории."
    Close #handle: handle = 0

    Const FC As Double = 47.3, FT As Double = 3.5, EC As Double = 36100#, NU As Double = 0.2
    Dim section As CSectionModel: Set section = BuildLopesA2SectionTest(107#)
    Dim layout As New CTransverseRebarLayout, steel As Object: Set steel = CreateObject("Scripting.Dictionary")
    AddLopesA2ReinforcementTest section, layout
    steel.Add "A2_LONG", ExperimentBilinearSteelTest(200000#, 672#, 0#)
    steel.Add "A2_HOOP", ExperimentBilinearSteelTest(200000#, 696#, 0#)
    Dim operators As New CCoupledElasticState, response As New CCoupledReinforcedResponse
    Dim concrete As New CCoupledConcreteResponse, solver As New CCoupledNewtonSolver, gt As Double
    operators.PrepareModel section, EC, NU, 1, 1, CLng(sampling), layout, steelModels:=steel
    If operators.DegreeCount <> 60 Or operators.PointCount - operators.ConcretePointCount <> 32 Then _
        Err.Raise 5, , "Префикс не соответствует модели A2."
    Dim sides As New Collection
    gt = 0.073 * FC ^ 0.18
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, FC, FT, 0.002, gt * tensileScale, (FC / FT) ^ 2 * gt, True, sides
    If Not solver.ReplayAcceptedFields(fields, n) Then Err.Raise 5, , "Не восстановлена собственная материальная история A2."
    solver.CopyAccepted field
    Dim trace As String: trace = ThisWorkbook.Path & "\A2PostAnchor.csv"
    AddExperimentTraceTest report, trace, "RESUME;" & sampling & ";" & CStr(n) & ";" & CStr(operators.ConcretePointCount)
    AddExperimentTraceTest report, trace, "RESUME_LAW;" & lane & ";" & _
        ExperimentNumberTest(gt * tensileScale) & ";" & ExperimentNumberTest((FC / FT) ^ 2 * gt)
    VerifyA2ResumePrefixTest solver, operators, concrete, response, field, saved, report, trace

    Dim previousField() As Double: previousField = fields(n - 1)
    RunTestA2PostAnchor = ContinueA2PostAnchorTest(solver, operators, concrete, response, sides, previousField, field, _
        prescribed(n - 1), prescribed(n), torque(n - 1) / 100000000#, torque(n) / 100000000#, n, nextStep, report, trace)
    Exit Function
Failed:
    Dim problem As String: problem = Err.Description
    If handle > 0 Then Close #handle
    RunTestA2PostAnchor = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продолжает собственную историю B при заданном закручивании, включая нисходящие участки.
Private Function ContinueA2PostAnchorTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal response As CCoupledReinforcedResponse, ByVal sides As Collection, _
        ByRef previous() As Double, ByRef current() As Double, ByVal previousTwist As Double, ByVal twist As Double, _
        ByVal previousLambda As Double, ByVal lambda As Double, ByVal prefix As Long, ByVal initialStep As Double, _
        ByRef report As String, ByVal trace As String) As String
    Const MAX_TWIST As Double = 0.06, MAX_STEP As Double = 0.001, MIN_STEP As Double = 0.000001953125
    Dim area As Double, sectionLength As Double, increment As Double
    operators.CopyResultantResidualScales area, sectionLength
    increment = initialStep
    Dim attempt As Long, retained As Long, stopReason As String, mode As String
    Dim requested As Double, measure As Double, trialLambda As Double, initialLambda As Double, ratio As Double
    Dim found() As Double, actual() As Double, oldSnapshot() As Double, accepted As Boolean, timeStart As Double
    Dim proposedTwist As Double, usage As Double, nativeNorm As Double
    Dim row As String
    row = "POST;" & CStr(prefix) & ";" & ExperimentNumberTest(twist) & ";" & ExperimentNumberTest(lambda) & ";" & _
        ExperimentNumberTest(initialStep) & ";" & ExperimentNumberTest(MAX_TWIST) & ";" & ExperimentNumberTest(response.AcceptedSteelUtilization)
    AddExperimentTraceTest report, trace, row
    stopReason = "AttemptLimit"
    For attempt = 1 To 125
        requested = GeomMin(MAX_TWIST, twist + increment)
        measure = requested * sectionLength / 1000#
        ratio = (requested - twist) / (twist - previousTwist)
        oldSnapshot = A2PostSnapshotTest(operators, concrete, response, sides)
        timeStart = Timer
        accepted = False: mode = "AcceptedField": initialLambda = lambda
        If ratio > 0# And ratio <= 1.25000001 Then
            initialLambda = lambda + ratio * (lambda - previousLambda)
            If initialLambda > 0# And initialLambda <> lambda Then
                accepted = TryA2PostStepTest(solver, measure, initialLambda, trialLambda)
                If accepted Then
                    solver.CopyTrial found, actual
                    If ForwardA2ResumeTest(previous, current, found, ratio) Then
                        mode = "LoadSecant"
                    Else
                        accepted = False
                    End If
                End If
                If Not accepted Then AssertA2PostRollbackTest solver, operators, concrete, response, sides, current, oldSnapshot
            End If
        End If
        If Not accepted Then
            initialLambda = lambda
            accepted = TryA2PostStepTest(solver, measure, initialLambda, trialLambda)
        End If
        If accepted Then
            solver.CopyTrial found, actual
            proposedTwist = found(4) * 1000# / sectionLength
            If proposedTwist <= twist Then Err.Raise 5, , "Уравновешенное закручивание не продвинулось."
            usage = response.TrialSteelUtilization
            nativeNorm = RecordA2PostBalanceTest(solver, operators, response, found, actual, measure, trialLambda, _
                prefix + retained + 1, attempt, "Primary", trace)
            If usage > 1# Then
                AddExperimentTraceTest report, trace, "UPPER_TRIAL;" & CStr(attempt) & ";" & ExperimentNumberTest(proposedTwist) & ";" & _
                    ExperimentNumberTest(usage)
                If ForwardA2ResumeTest(previous, current, found, ratio) Then
                    If ConfirmA2PostSteelTest(solver, operators, concrete, response, sides, current, oldSnapshot, found, _
                            measure, initialLambda, trialLambda, usage, prefix + retained, attempt, twist, lambda, report, trace) Then
                        stopReason = "ConfirmedSteelStrainBracket"
                        Exit For
                    End If
                Else
                    AddExperimentTraceTest report, trace, "UNCONFIRMED_UPPER;" & CStr(attempt) & ";" & CStr(prefix + retained)
                End If
                accepted = False
            End If
        End If

        If accepted Then
            solver.AcceptStep: retained = retained + 1
            If response.AcceptedSteelUtilization <> usage Then Err.Raise 5, , "При принятии изменился определяющий предел стали."
            RecordA2ResumeFieldTest operators, concrete, response, found, actual, proposedTwist, nativeNorm, mode, _
                prefix + retained, attempt, Timer - timeStart, report, trace
            previous = current: current = found
            previousTwist = twist: twist = proposedTwist
            previousLambda = lambda: lambda = trialLambda
            If requested = MAX_TWIST Then
                stopReason = "TwistLimit"
                Exit For
            End If
            increment = GeomMin(MAX_STEP, increment * 1.25)
        Else
            Dim meta As CResultMeta: Set meta = solver.ResultMeta
            AssertA2PostRollbackTest solver, operators, concrete, response, sides, current, oldSnapshot
            AddExperimentTraceTest report, trace, "REJECT;" & CStr(attempt) & ";" & ExperimentNumberTest(requested) & ";" & meta.DiagnosticDetails
            AddExperimentTraceTest report, trace, "ROLLBACK;" & CStr(attempt) & ";" & CStr(prefix + retained)
            increment = increment * 0.5
            If increment < MIN_STEP Then
                stopReason = "MinimumTwistIncrement"
                Exit For
            End If
        End If
    Next attempt
    AddExperimentTraceTest report, trace, "STOP;" & stopReason & ";" & CStr(retained)
    ContinueA2PostAnchorTest = report & "TOTAL_A2_POST_ANCHOR: passed=" & CStr(retained + 1) & "; failed=0"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выполняет ту же пространственную пробу чистого кручения, что и принятая история B.
Private Function TryA2PostStepTest(ByVal solver As CCoupledNewtonSolver, ByVal measure As Double, _
        ByVal initialLambda As Double, ByRef trialLambda As Double) As Boolean
    Dim offset(1 To 6) As Double, direction(1 To 6) As Double, projection(1 To 60) As Double
    projection(4) = 1#: direction(4) = 100000000#
    TryA2PostStepTest = solver.TryDeformationStep(offset, direction, projection, measure, initialLambda, trialLambda, _
        0.0000005, 0.00000002, 24, consistentControl:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторно решает верхнюю пробу из того же левого состояния и никогда её не принимает.
Private Function ConfirmA2PostSteelTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal response As CCoupledReinforcedResponse, ByVal sides As Collection, _
        ByRef leftField() As Double, ByRef oldSnapshot() As Double, ByRef rightField() As Double, ByVal measure As Double, _
        ByVal initialLambda As Double, ByVal rightLambda As Double, ByVal firstUsage As Double, ByVal leftIndex As Long, _
        ByVal attempt As Long, ByVal leftTwist As Double, ByVal leftLambda As Double, ByRef report As String, ByVal trace As String) As Boolean
    AssertA2PostRollbackTest solver, operators, concrete, response, sides, leftField, oldSnapshot
    Dim replayLambda As Double, sameField As Boolean, repeatUsage As Double, replayed() As Double, loads() As Double
    Dim confirmed As Boolean
    Dim leftUsage As Double: leftUsage = response.AcceptedSteelUtilization
    If leftUsage > 1# Then Err.Raise 5, , "Верхняя проба началась после предельной деформации стали."
    If TryA2PostStepTest(solver, measure, initialLambda, replayLambda) Then
        solver.CopyTrial replayed, loads
        repeatUsage = response.TrialSteelUtilization
        Dim recordedNorm As Double
        recordedNorm = RecordA2PostBalanceTest(solver, operators, response, replayed, loads, measure, replayLambda, _
            leftIndex + 1, attempt, "RepeatUpper", trace)
        Dim j As Long: sameField = True
        For j = 1 To 60
            If Abs(replayed(j) - rightField(j)) > 0.00000000005 Then sameField = False
        Next j
        confirmed = sameField And repeatUsage > 1# And Abs(replayLambda - rightLambda) <= 0.0000001
    End If
    AssertA2PostRollbackTest solver, operators, concrete, response, sides, leftField, oldSnapshot
    AddExperimentTraceTest report, trace, "ROLLBACK_UPPER;" & CStr(attempt) & ";" & CStr(leftIndex)
    If confirmed Then
        AddExperimentTraceTest report, trace, "BRACKET;" & CStr(attempt) & ";" & CStr(leftIndex) & ";" & _
            ExperimentNumberTest(leftTwist) & ";" & ExperimentNumberTest(leftLambda) & ";" & ExperimentNumberTest(leftUsage) & ";" & _
            ExperimentNumberTest(firstUsage) & ";" & ExperimentNumberTest(repeatUsage)
    Else
        AddExperimentTraceTest report, trace, "UNCONFIRMED_UPPER;" & CStr(attempt) & ";" & CStr(leftIndex)
    End If
    ConfirmA2PostSteelTest = confirmed
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все силовые уравнения, условия однозначности и связь по закручиванию до приёмки поля.
Private Function RecordA2PostBalanceTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByRef loads() As Double, ByVal measure As Double, _
        ByVal lambda As Double, ByVal index As Long, ByVal attempt As Long, ByVal role As String, ByVal trace As String) As Double
    Const EC As Double = 36100#
    Dim internal() As Double, dummy() As Double, external() As Double, expected(1 To 6) As Double
    expected(4) = lambda * 100000000#
    Dim usage As Double: usage = response.TrialSteelUtilization
    Dim critical As Long: critical = response.TrialSteelCriticalPoint
    operators.LoadEquations 0#, 0#, 0#, expected(4), 0#, 0#, external
    If Not solver.TestEquilibriumLinearization(field, False, True, internal, dummy) Then Err.Raise 5, , "Нет повторяемого равновесия A2."
    Dim j As Long, weak As Double, gauge As Double, tau As Double, force As Double, controlError As Double
    For j = 1 To 60: internal(j) = internal(j) - external(j): Next j
    For j = 1 To 56: weak = GeomMax(weak, Abs(internal(j))): Next j
    For j = 57 To 60: gauge = GeomMax(gauge, EC * Abs(internal(j))): Next j
    tau = 0.0000005 + 0.00000002 * Abs(external(4))
    force = operators.ResultantResidualNorm(loads, expected)
    controlError = (field(4) - measure) * EC
    If lambda <= 0# Or GeomMax(GeomMax(weak, force), GeomMax(gauge, Abs(controlError))) > tau Then _
        Err.Raise 5, , "Проба A2 превысила исходный допуск равновесия."
    Dim fileNum As Integer: fileNum = FreeFile
    Dim suffix As String: suffix = ";" & role & ";" & CStr(index) & ";" & CStr(attempt)
    Open trace For Append As #fileNum
    Print #fileNum, "BALANCE" & suffix & ";" & ExperimentNumberTest(lambda) & ";" & ExperimentNumberTest(measure) & ";" & _
        ExperimentNumberTest(tau) & ";" & ExperimentNumberTest(weak) & ";" & ExperimentNumberTest(force) & ";" & _
        ExperimentNumberTest(gauge) & ";" & ExperimentNumberTest(controlError) & ";" & ExperimentNumberTest(usage) & ";" & CStr(critical)
    Print #fileNum, "WEAK" & suffix & A2PostVectorTest(internal)
    Print #fileNum, "WRENCH" & suffix & A2PostVectorTest(loads)
    Print #fileNum, "TRIALFIELD" & suffix & A2PostVectorTest(field)
    Dim point As Long, result As ESolverFailureCode, x As Double, y As Double, pointArea As Double, rod As Double
    Dim sectionResponse As ICoupledPointResponse: Set sectionResponse = response
    Dim strain() As Double, stress() As Double, tangent() As Double, axis() As Double
    ReDim strain(1 To 6): ReDim stress(1 To 6): ReDim tangent(1 To 6, 1 To 6): ReDim axis(1 To 6)
    For point = 1 To operators.PointCount
        operators.Point point, x, y, pointArea
        operators.PointStrain point, field, strain
        result = sectionResponse.EvaluatePoint(point, strain, stress, tangent, ctmStressOnly, False)
        If result <> sfcNone Then
            Close #fileNum
            Err.Raise 5, , "Не воспроизведён тензор пробной точки A2."
        End If
        rod = 0#
        If point > operators.ConcretePointCount Then
            operators.SteelProjection point, axis
            For j = 1 To 6: rod = rod + strain(j) * axis(j): Next j
        End If
        Print #fileNum, "POINT" & suffix & ";" & CStr(point) & ";" & ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & _
            ";" & ExperimentNumberTest(pointArea) & ";" & ExperimentNumberTest(rod) & A2PostVectorTest(stress)
    Next point
    Close #fileNum
    If response.TrialSteelUtilization <> usage Or response.TrialSteelCriticalPoint <> critical Then _
        Err.Raise 5, , "Чтение тензоров изменило пробную историю стали."
    RecordA2PostBalanceTest = force
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет точный откат поля и принятых напряжений с энергиями в трёх срезах.
Private Sub AssertA2PostRollbackTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal response As CCoupledReinforcedResponse, ByVal sides As Collection, _
        ByRef expected() As Double, ByRef oldSnapshot() As Double)
    solver.DiscardStep
    Dim actual() As Double, newSnapshot() As Double, j As Long
    solver.CopyAccepted actual
    For j = 1 To 60
        If actual(j) <> expected(j) Then Err.Raise 5, , "При откате изменилось принятое поле A2."
    Next j
    newSnapshot = A2PostSnapshotTest(operators, concrete, response, sides)
    For j = LBound(oldSnapshot) To UBound(oldSnapshot)
        If newSnapshot(j) <> oldSnapshot(j) Then Err.Raise 5, , "При откате изменились наблюдаемые параметры материала A2."
    Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает доступные принятые данные материала в центре и двух продольных срезах.
Private Function A2PostSnapshotTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByVal sides As Collection) As Double()
    Dim states() As Double, stress() As Double, point As Long, side As Long, j As Long, at As Long
    ReDim states(1 To 3 * (9 * operators.PointCount + 2)): ReDim stress(1 To 6)
    Dim material As CCoupledConcreteResponse, bars As CCoupledReinforcedResponse
    For side = -1 To 1
        Select Case side
            Case -1: Set material = sides(1): Set bars = sides(2)
            Case 0: Set material = concrete: Set bars = response
            Case 1: Set material = sides(3): Set bars = sides(4)
        End Select
        states(at + 1) = bars.AcceptedSteelUtilization: states(at + 2) = bars.AcceptedSteelCriticalPoint
        at = at + 2
        For point = 1 To operators.PointCount
            material.CopyAcceptedStress point, stress
            For j = 1 To 6: states(at + j) = stress(j): Next j
            material.AcceptedPointDamage point, states(at + 7), states(at + 8)
            If point > operators.ConcretePointCount Then states(at + 9) = bars.AcceptedSteelStress(point)
            at = at + 9
        Next point
    Next side
    A2PostSnapshotTest = states
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает полный вектор с десятичной точкой при действующей локали книги.
Private Function A2PostVectorTest(ByRef values() As Double) As String
    Dim i As Long
    For i = LBound(values) To UBound(values): A2PostVectorTest = A2PostVectorTest & ";" & ExperimentNumberTest(values(i)): Next i
End Function
