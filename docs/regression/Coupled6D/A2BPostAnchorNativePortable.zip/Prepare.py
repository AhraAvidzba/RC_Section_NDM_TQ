"""Seal only the B continuation test and its authenticated 43-field history."""
from argparse import ArgumentParser
import csv
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
import runpy
import subprocess
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
DONOR=HERE.parent/'a2seed'
PAIR=HERE.parent/'a2pair/A2LaneABExactNative20261116.zip'
PAIR_SHA='CA2C750095DBB1F3DB62D5CC2EE046638E86D79D8CADCD3EF821EFF8DD31AF53'
DONOR_SHA='55F52A46168A537D8D266BFF939971905CCEB4ED43D2236F3339BEF01AF9F2B0'
BOOK='workbook/output/RC_Section_NDM.xlsm'
MODULE='tests/modTestCoupledExperiment.bas'


def sha(data):
    return sha256(data.read_bytes() if isinstance(data,Path) else data).hexdigest().upper()


def blob(repo, revision, name):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{revision}:{name}'])


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def put(name,data):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
    return sha(path)


def replace_one(text, old, new):
    assert text.count(old)==1,old
    return text.replace(old,new)


def donor_module():
    original=(DONOR/MODULE).read_text(encoding='utf-8-sig')
    seed_entry="' Сравнивает два начальных множителя одного шага на точной истории A2."
    # Remove the unused scalar pair only. The tested spatial initializer exposes both side responses.
    marker="' -------------------- ДЛЯ ТЕСТОВ --------------------\n"+seed_entry
    assert original.count(marker)==1
    original=original[:original.index(marker)].rstrip()+'\n\n'
    start=original.index("' Продолжает послетрещинную ветвь A2")
    stop=original.index('End Function',start)+len('End Function')
    entry="' -------------------- ДЛЯ ТЕСТОВ --------------------\n"+original[start:stop]
    entry=entry.replace('RunTestA2ResumeRefined','RunTestA2PostAnchor')
    entry=replace_one(entry,'If values(2) <> lane Then','If values(2) <> "B" Or lane <> "B" Then')
    entry=replace_one(entry,'If n < 3 Then Err.Raise 5, , "Недостаточно полей для продолжения."',
                      'If n <> 43 Then Err.Raise 5, , "Требуется собственная принятая история B до поля 43."')
    entry=replace_one(entry,'gt * tensileScale, (FC / FT) ^ 2 * gt, True','gt * tensileScale, (FC / FT) ^ 2 * gt, True, sides')
    entry=replace_one(entry,'    gt = 0.073 * FC ^ 0.18','    Dim sides As New Collection\n    gt = 0.073 * FC ^ 0.18')
    entry=replace_one(entry,'\\A2RefinedResume.csv','\\A2PostAnchor.csv')
    entry=replace_one(entry,'ContinueA2ResumeTest(solver, operators, concrete, response, previousField, field, _',
                      'ContinueA2PostAnchorTest(solver, operators, concrete, response, sides, previousField, field, _')
    new=original+entry+'\n\n'+(HERE/'PostEntry.bas.txt').read_text(encoding='utf-8-sig').strip()+'\n'
    methods=re.findall(r'(?im)^(?:Public|Private) (?:Function|Sub) (\w+)',new)
    assert len(methods)==len(set(m.lower() for m in methods)) and max(map(len,new.splitlines()))<1024
    return new.replace('\n','\r\n').encode('utf-8-sig')


def stage(repo):
    assert HERE.is_relative_to(repo/'tmp') and not (HERE/'Fixture.json').exists()
    assert sha(DONOR/'Fixture.json')==DONOR_SHA and sha(PAIR)==PAIR_SHA
    donor=read_json(DONOR/'Fixture.json')
    assert all(sha(DONOR/name)==checksum for name,checksum in donor['frozen'].items())
    assert sha(repo/BOOK)==sha(blob(repo,donor['historicalGit'],BOOK))==donor['workbookSHA256']
    frozen={}
    for name in donor['frozen']:
        if name.startswith('tools/') or name in ('Guard-IsolatedOffice.ps1',BOOK):
            frozen[name]=put(name,(DONOR/name).read_bytes())
    assert put('docs/regression/Diagnostic.xlsm',(HERE/BOOK).read_bytes())==donor['workbookSHA256']

    with ZipFile(PAIR) as package:
        expected=json.loads(package.read('ReplayInputs.json'))['files']
        sources={'B-Cold.csv':'Cold/B-Cold.csv','B-ExactVerification.json':'Native/B-1-Exact-Verification.json',
                 'B-FirstResume.csv':'Native/B-1-Resume.csv'}
        for name,member in sources.items():
            assert sha(package.read(member))==expected[member]
            frozen[name]=put(name,package.read(member))
        pair=json.loads(package.read('PairReplay.json'))
        assert pair['lanes']['B']['acceptedFields']==43
        compile_receipt=json.loads(package.read('Native/B-1-Exact.txt.ProcessClosure.json'))
        assert compile_receipt['Passed'] and compile_receipt['Closure']['FinalState']['State']=='Absent'
    prep=runpy.run_path(repo/'tmp/a2-resume/Prepare.py')
    rows, summary=prep['combined'](HERE/'B-Cold.csv','B',[HERE/'B-FirstResume.csv'])
    assert len(rows)==43 and float(rows[-1][3])==0.0309249880704004
    assert float(rows[-1][8])==256022408.119216 and float(rows[-1][8])/1e6==pair['lanes']['B']['lastAcceptedT_kNm']
    next_increment=min(.001,1.25*(float(rows[-1][3])-float(rows[-2][3])))
    assert next_increment==.001
    buffer=StringIO(newline='')
    writer=csv.writer(buffer,delimiter=';',lineterminator='\r\n')
    writer.writerows([[len(rows),format(next_increment,'.17g'),'B'],*[[row[1],row[3],*row[5:]] for row in rows]])
    frozen['B43.csv']=put('B43.csv',buffer.getvalue().encode('ascii'))
    frozen[MODULE]=put(MODULE,donor_module())
    for name in ('Prepare.py','Run-Post.ps1','Verify-Post.py','README.md','PostEntry.bas.txt'):
        frozen[name]=sha(HERE/name)
    for name in ('src','Native','Temp'):
        (HERE/name).mkdir(exist_ok=True)
    fixture={k:donor[k] for k in ('historicalGit','workbookSHA256','sectionSources')}
    fixture.update({'pairArchiveSHA256':PAIR_SHA,'prefixFields':43,'lastTwist_rad_m':summary['last_twist_rad_m'],
                    'lastTorque_kNm':summary['last_T_kNm'],'macroTimeoutSeconds':780,'targetTwist_rad_m':.06,
                    'firstTwist_rad_m':summary['last_twist_rad_m']+next_increment,'frozen':frozen})
    put('Fixture.json',(json.dumps(fixture,indent=2)+'\n').encode('utf8'))


def check(repo):
    fixture=read_json(HERE/'Fixture.json')
    assert sha(blob(repo,fixture['historicalGit'],BOOK))==sha(repo/BOOK)==fixture['workbookSHA256']
    assert all(sha(blob(repo,'HEAD',name))==expected for name,expected in fixture['sectionSources'].items())
    assert all(sha(HERE/name)==expected for name,expected in fixture['frozen'].items())
    assert {x.stem for loc in ('src','tests') for x in (HERE/loc).rglob('*') if x.is_file()}=={'modTestCoupledExperiment'}
    print('A2_B_POST_FIXTURE_PASS',sha(HERE/'Fixture.json'),fixture['frozen'][MODULE],fixture['frozen']['B43.csv'])


if __name__=='__main__':
    parser=ArgumentParser()
    parser.add_argument('--repo-root',type=Path,required=True)
    selection=parser.add_mutually_exclusive_group(required=True)
    selection.add_argument('--stage',action='store_true')
    selection.add_argument('--check',action='store_true')
    args=parser.parse_args()
    repo=args.repo_root.resolve()
    if args.stage:
        stage(repo)
    check(repo)
