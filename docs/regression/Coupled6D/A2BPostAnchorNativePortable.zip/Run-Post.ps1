# Выполняет только частное продолжение B после выделения слота Excel.
param([string]$RepoRoot=(Join-Path $PSScriptRoot '../..'))
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath $RepoRoot).Path
$originalTemp=$env:TEMP
$originalTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
Push-Location -LiteralPath $root
try {
    & python -B -X utf8 'Prepare.py' --repo-root $repo --check
    if ($LASTEXITCODE) {throw 'Контроль собственных входов B не пройден.'}
    $fixture=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $protected[9552]=[long]639304334673501852
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Путь пробной книги слишком длинный.'
    }
    $draft='docs/regression/Diagnostic.xlsm'
    $compile='Native/Compile.log'
    $report='Native/B-Post.txt'
    if ((Test-Path -LiteralPath $compile) -or (Test-Path -LiteralPath $report) -or
        (Get-FileHash -LiteralPath $draft).Hash -cne $fixture.workbookSHA256) {throw 'Требуется свежая частная копия.'}
    Assert-IsolatedOfficeReady 'PreCompileBPost'
    & './tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $draft -ModuleNames @('modTestCoupledExperiment') |
        Tee-Object -FilePath $compile
    Save-OfficeClosure $compile 'Native/CompileClosure.json'
    $built=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    if (!$built.Compiled -or $built.ProductionChanged -or $built.ProductionSHA256 -cne $fixture.workbookSHA256 -or
        ($built.Modules -join ',') -cne 'modTestCoupledExperiment' -or $built.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash) {
        throw 'Компиляция частной книги B не подтверждена.'
    }

    Assert-IsolatedOfficeReady 'PreNativeBPost'
    $inputPath=Join-Path $root 'B43.csv'
    $start=[DateTime]::UtcNow
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $draft `
        -ReportPath $report -Macro 'modTestCoupledExperiment.RunTestA2PostAnchor' -MacroArgument1 $inputPath `
        -MacroArgument2 'B' -Mode No -TimeoutSeconds $fixture.macroTimeoutSeconds -FailFast
    $exit=$LASTEXITCODE
    $seconds=([DateTime]::UtcNow-$start).TotalSeconds
    $entry=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($entry.Count -ne 1) {throw 'В нативном журнале нет пути к пробному протоколу.'}
    $folder=[IO.Path]::GetFullPath((Split-Path -Parent $entry[0].Substring('FIXTURE: '.Length)))
    if (!$folder.StartsWith($env:TEMP+'\RC_NDM_ModeSuite_',[StringComparison]::OrdinalIgnoreCase)) {throw 'Пробный след вне частной копии.'}
    $raw=Join-Path $folder 'A2PostAnchor.csv'
    if (Test-Path -LiteralPath $raw) {Copy-Item -LiteralPath $raw -Destination 'Native/B-Post.csv'}
    [ordered]@{nativeExit=$exit;wallSeconds=$seconds}|ConvertTo-Json|Set-Content -LiteralPath 'Native/Timing.json' -Encoding utf8
    $ended=Get-Content -LiteralPath ($report+'.ProcessClosure.json') -Raw | ConvertFrom-Json
    if ($exit -ne 0 -and ($ended.Stage -cne 'TIMEOUT' -or $ended.After.State -cne 'Absent')) {
        throw "Проба B завершилась с кодом $exit вне подтверждённого тайм-аута. Сырой протокол сохранён."
    }
    & python -B -X utf8 'Verify-Post.py'
    if ($LASTEXITCODE) {throw 'Независимая проверка продолжения B не пройдена.'}
}
finally {
    $env:TEMP=$originalTemp
    $env:TMP=$originalTmp
    Pop-Location
}
