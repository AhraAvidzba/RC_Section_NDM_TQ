"""Replay the independent B trace and audit observed yield and declining samples."""
from argparse import ArgumentParser
from hashlib import sha256
from math import degrees, isclose
from pathlib import Path
import csv
import json
import subprocess

HERE=Path(__file__).resolve().parent
BOOK='workbook/output/RC_Section_NDM.xlsm'


def sha(data):
    return sha256(data).hexdigest().upper()


def j(name):
    return json.loads((HERE/name).read_bytes())


def rows(name):
    with (HERE/name).open(encoding='cp1251',newline='') as stream:
        return [row for row in csv.reader(stream,delimiter=';') if row]


def match(a,b):
    if isinstance(a,dict):
        assert set(a)==set(b)
        for x in a:
            match(a[x],b[x])
    elif isinstance(a,list):
        assert len(a)==len(b)
        for x,y in zip(a,b):
            match(x,y)
    elif isinstance(a,float):
        assert isclose(a,b,rel_tol=1e-12,abs_tol=1e-13),(a,b)
    else:
        assert a==b,(a,b)


def exact_b_prefix():
    cold=rows('B-Cold.csv'); resume=rows('B-FirstResume.csv'); prefix=rows('B43.csv')
    assert prefix[0]==['43','0.001','B'] and resume[0]==['RESUME','9','31','56']
    assert resume[1][:2]==['RESUME_LAW','B'] and resume[-1]==['STOP','MeasuredTorqueBracketed','12']
    fields_cold=[row for row in cold if row[0]=='FIELD']
    fields_resume=[row for row in resume if row[0]=='FIELD']
    assert len(fields_cold)==31 and len(fields_resume)==12
    expected=[[r[1],r[3],*r[5:]] for r in fields_cold]+[[r[1],r[4],*r[10:]] for r in fields_resume]
    assert prefix[1:]==expected
    steps=[r for r in cold if r[0].startswith('A2Step')]
    assert len(steps)==31
    limits=(696.,672.)
    for hoop,long in [(float(x[3]),float(x[4])) for x in steps]+[(float(x[6]),float(x[7])) for x in fields_resume]:
        assert hoop<limits[0] and long<limits[1]
    return len(expected)


def summarize(result):
    states=result['accepted']
    assert states[0]['index']==43 and states[-1]['index']==73 and result['stop']=='TwistLimit'
    assert result['newBalancedAcceptedFields']==30 and result['crossingBracket'] is None
    assert all(p['fullBalanceNormMPa']<=p['tauMPa'] for p in states[1:])
    for s in states[1:]:
        assert abs(s['hoopStressMPa']-min(696.,200000.*s['hoopMaxAbsStrain']))<2e-8
        assert abs(s['longitudinalStressMPa']-min(672.,200000.*s['longitudinalMaxAbsStrain']))<2e-8
    yield_events={}
    for family,ey,sk,ek in (('hoop',696./200000.,'hoopStressMPa','hoopMaxAbsStrain'),
                            ('longitudinal',672./200000.,'longitudinalStressMPa','longitudinalMaxAbsStrain')):
        right=next(i for i,s in enumerate(states[1:],start=1) if s[ek]>=ey)
        p,q=states[right-1:right+1]
        assert p[ek]<ey<=q[ek] and right>1
        yield_events[family]={'elasticYieldStrain':ey,'adjacentAcceptedStates':[
            {'index':s['index'],'twist_rad_m':s['twist_rad_m'],'T_kNm':s['T_kNm'],'steelStressMPa':s[sk],
             'absoluteAxialStrain':s[ek]} for s in (p,q)]}
    best=max(states,key=lambda x:x['T_kNm']); tail=states[-1]
    assert best['index']==51 and len(result['decliningPairs'])==22
    assert result['sampledTurningTriples'][0]['neighbors'][1]['index']==best['index']
    assert all(p['left']==51+i and p['right']==52+i and p['deltaT_kNm']<0 for i,p in enumerate(result['decliningPairs']))
    loss=best['T_kNm']-tail['T_kNm']
    return {'exactAcceptedInputFields':exact_b_prefix(),'modeledYieldBrackets':yield_events,
            'sampledPeakAndNeighbors':result['sampledTurningTriples'][0]['neighbors'],
            'sampledPeakTwist_deg_m':degrees(best['twist_rad_m']),
            'sampledPeakVersusExperimental254_8_percent':100*(best['T_kNm']/254.8-1),
            'decliningStepsAfterSampledPeak':22,'dropFromSampledPeak_kNm':loss,
            'dropFromSampledPeak_percent':100*loss/best['T_kNm'],
            'lastTwist_rad_m':tail['twist_rad_m'],'lastT_kNm':tail['T_kNm'],
            'maximumObservedUltimateSteelUtilization':max(x['steelUtilization'] for x in states),
            'maximumFullEquilibriumResidual_MPa':max(x['fullBalanceNormMPa'] for x in states[1:]),
            'maximumIndependentSixResultantsResidual_MPa':max(x['independentSixForceNormMPa'] for x in states[1:]),
            'noUpperStrainTrialObserved':result['crossingBracket'] is None,'physicalMaximumCertified':False}


def main(repo):
    manifest=j('Manifest.json'); fixture=j('Fixture.json')
    assert manifest['schema']=='A2BPostAnchor/v1' and manifest['bookOmitted']
    assert all(sha((HERE/name).read_bytes())==expected for name,expected in manifest['files'].items())
    assert all(manifest['files'][name]==expected for name,expected in fixture['frozen'].items() if name!=BOOK)
    assert fixture['workbookSHA256']==fixture['frozen'][BOOK]==manifest['sourceWorkbookSHA256']
    assert fixture['historicalGit']==manifest['historicalGit']
    sources={BOOK:fixture['workbookSHA256'],**fixture['sectionSources']}
    for path,expected in sources.items():
        data=subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{fixture["historicalGit"]}:{path}'])
        assert sha(data)==expected,path
    original=j('B-Post-Verification.json')
    path=HERE/'Verify-Post.py'
    code=path.read_text(encoding='utf-8')
    assert code.count("HERE/'B-Post-Verification.json'")==1
    code=code.replace("HERE/'B-Post-Verification.json'","HERE/'Replay-B-Post-Verification.json'")
    ns={'__file__':str(path),'__name__':'detached_b_post'}
    exec(compile(code,str(path),'exec'),ns)
    ns['verify']()
    rebuilt=j('Replay-B-Post-Verification.json')
    match(original,rebuilt)
    artifact=(json.dumps(summarize(rebuilt),indent=2,allow_nan=False)+'\n').encode('utf8')
    (HERE/'B-Post-Observed-Events.json').write_bytes(artifact)
    print('A2_B_POST_PORTABLE_PASS',sha(artifact))


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    main(p.parse_args().repo_root.resolve())
