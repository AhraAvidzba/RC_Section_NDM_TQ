"""Package post-anchor B evidence, without private or installed workbook bytes."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED, ZipInfo
import json

HERE=Path(__file__).resolve().parent
BOOK='workbook/output/RC_Section_NDM.xlsm'
fixture=json.loads((HERE/'Fixture.json').read_bytes())
paths=set(fixture['frozen'])-{BOOK}
paths.update(str(p.relative_to(HERE).as_posix()) for p in (HERE/'Native').glob('*') if p.is_file())
paths.update(('Fixture.json','B-Post-Verification.json','docs/regression/CodeUpdate.json','Run.ndjson',
              'Replay-Post.py','Pack-Post.py','Portable-README.md'))
data={name:(HERE/name).read_bytes() for name in sorted(paths)}
assert all(sha256(data[name]).hexdigest().upper()==expected for name,expected in fixture['frozen'].items() if name!=BOOK)
assert not any(p.endswith(('.xlsm','.xlsx')) for p in paths)
assert sha256(data['B-Post-Verification.json']).hexdigest().upper()=='6BFA97F4CC2144129DB9038FF54C274A0D361B3BD3CE9470D7095104EAA74666'
seal={'schema':'A2BPostAnchor/v1','bookOmitted':True,'historicalGit':fixture['historicalGit'],
      'sourceWorkbookSHA256':fixture['workbookSHA256'],'files':{n:sha256(b).hexdigest().upper() for n,b in data.items()}}
data['Manifest.json']=(json.dumps(seal,indent=2)+'\n').encode('utf8')
dest=HERE/'Portable'
dest.mkdir(exist_ok=True)
output=dest/'A2BPostAnchorNativePortable.zip'
with ZipFile(output,'w',compression=ZIP_DEFLATED,compresslevel=9) as zipout:
    for name,content in data.items():
        zipout.writestr(ZipInfo(name,(2026,11,16,0,0,0)),content,compress_type=ZIP_DEFLATED,compresslevel=9)
with ZipFile(output) as check:
    assert check.testzip() is None and set(check.namelist())==set(data)
print(output,sha256(output.read_bytes()).hexdigest().upper(),output.stat().st_size)
