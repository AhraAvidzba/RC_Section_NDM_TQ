"""Verify captured post-anchor continuation, including complete fields before a watchdog stop."""
from collections import defaultdict
from hashlib import sha256
from io import StringIO
from math import fsum, isfinite
from pathlib import Path
import csv
import json
import re

HERE=Path(__file__).resolve().parent
NATIVE=HERE/'Native'
AREA=216004.
LENGTH=407.293505963451
EC=36100.
SCALES=(AREA,AREA*LENGTH,AREA*LENGTH,AREA*LENGTH,AREA,AREA)


def sha(data):
    return sha256(data).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def vector(items,size):
    values=tuple(map(float,items))
    assert len(values)==size and all(map(isfinite,values))
    return values


def close(a,b,tolerance):
    assert abs(a-b)<=tolerance,(a,b,tolerance)


def peak(values):
    return max(map(abs,values))


def stays_forward(previous,current,trial,ratio):
    delta=tuple(b-a for a,b in zip(current['field'][:56],trial['field'][:56]))
    old=tuple(b-a for a,b in zip(previous['field'][:56],current['field'][:56]))
    return fsum(x*y for x,y in zip(delta,old))>0 and fsum(x*x for x in delta)<=9.00000001*ratio**2*fsum(x*x for x in old)


def process(fixture):
    compiler=read(NATIVE/'CompileClosure.json')
    owner=read(NATIVE/'B-Post.txt.Ownership.json')
    closure=read(NATIVE/'B-Post.txt.ProcessClosure.json')
    timing=read(NATIVE/'Timing.json')
    compiled=read(HERE/'docs/regression/CodeUpdate.json')
    report=(NATIVE/'B-Post.txt').read_text(encoding='utf-8-sig')
    log=(NATIVE/'Compile.log').read_text(encoding='utf-8-sig')
    assert compiled['Compiled'] and not compiled['ProductionChanged']
    assert compiled['ProductionSHA256']==fixture['workbookSHA256']
    assert compiled['Modules']==['modTestCoupledExperiment']
    assert compiler['State']=='Absent' and re.findall(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',log,re.M)==[
        (str(compiler['PID']),compiler['StartTicksUTC'])]
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['ProcessName']=='EXCEL'
    assert re.findall(r'^SOURCE_SHA256: ([0-9A-F]{64})$',report,re.M)==[compiled['WorkbookSHA256']]
    assert owner['SourceSHA256']==compiled['WorkbookSHA256']
    private=HERE/'docs/regression/Diagnostic.xlsm'
    if private.is_file():
        assert sha(private.read_bytes())==compiled['WorkbookSHA256']
    assert f"TEST_EXCEL_PROCESS: id={owner['PID']}; startTicks={owner['StartTicksUTC']}" in report
    if closure['Stage']=='TIMEOUT':
        assert timing['nativeExit']!=0 and not closure['Passed']
        assert closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout'] and closure['ExcelStopRequested']
        assert 'WATCHDOG_FAILURE: timeout=' in report and closure['Before']['State']=='Live'
        tail=closure['After']
        identity=closure['Identity']
        terminal='watchdog timeout; complete committed output only'
    else:
        assert closure['Stage']=='AFTER_CHILD_EXIT' and closure['Passed'] and closure['ChildHasExited']
        assert closure['ChildExitCode']==timing['nativeExit']==0 and closure['Closure']['Passed']
        assert not closure['Closure']['OrdinaryPathKilledAnything']
        tail=closure['Closure']['FinalState']
        identity=closure['Closure']['Identity']
        terminal='completed'
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in report
        assert re.search(r'^TOTAL_A2_POST_ANCHOR: passed=\d+; failed=0$',report,re.M)
    assert tail['State']=='Absent' and identity['Valid']
    assert (tail['PID'],tail['StartTicksUTC'])==(identity['PID'],str(identity['Ticks']))==(owner['PID'],owner['StartTicksUTC'])
    env=[json.loads(row) for row in (HERE/'Run.ndjson').read_text(encoding='utf-8-sig').splitlines()]
    assert [node['phase'] for node in env]==['PreCompileBPost','PreNativeBPost']
    for node in env:
        assert node['ramMiB']>=6500 and node['freeCommitGiB']>=8 and node['freeC_MiB']>=80
        assert all(p['ProtectedUser'] and p['Id'] not in (compiler['PID'],owner['PID']) for p in node['excel'])
    return {'terminal':terminal,'compile':compiler,'native':tail,'wall_seconds':timing['wallSeconds']}


def force_check(key,blocks,points,geometry):
    lam,measure,tau,norm,force,gauge,ctrl,usage,critical=vector(blocks['BALANCE'][key],9)
    expected=(0.,0.,0.,lam*1e8,0.,0.)
    close(tau,5e-7+2e-8*abs(expected[3])/SCALES[3],2e-19)
    weak=vector(blocks['WEAK'][key],60)
    q=vector(blocks['TRIALFIELD'][key],60)
    w=vector(blocks['WRENCH'][key],6)
    close(norm,peak(weak[:56]),1e-14)
    close(gauge,EC*peak(weak[56:]),1e-14)
    close(ctrl,EC*(q[3]-measure),4e-12)
    close(force,peak((a-b)/s for a,b,s in zip(w,expected,SCALES)),3e-13)
    assert lam>0 and max(norm,force,gauge,abs(ctrl))<=tau
    p=points[key]
    assert list(p)==list(range(1,89))
    components=[[] for _ in range(6)]
    strains={}
    for index,data in p.items():
        x,y,area,steel,_,_,zz,_,xz,yz=vector(data,10)
        assert area>0
        assert geometry.setdefault(index,(x,y,area))==(x,y,area)
        for items,value in zip(components,(zz,y*zz,x*zz,x*yz-y*xz,xz,yz)):
            items.append(value*area)
        if index>56:
            strains[index]=steel
        else:
            assert steel==0.
    close(fsum(geometry[i][2] for i in range(1,57)),AREA,2e-7)
    efforts=tuple(map(fsum,components))
    assert peak((a-b)/s for a,b,s in zip(w,efforts,SCALES))<2e-10
    independent_force=peak((a-b)/s for a,b,s in zip(efforts,expected,SCALES))
    assert independent_force<=tau+5e-12
    assert int(critical)==critical and int(critical) in strains
    close(usage,peak(strains.values())/.05,3e-13)
    close(usage,abs(strains[int(critical)])/.05,3e-13)
    return {'lambda':lam,'twist_rad_m':q[3]*1000./LENGTH,'requestedTwist_rad_m':measure*1000./LENGTH,
            'T_kNm':w[3]/1e6,'actualSix_N_Nmm':w,'integratedSix_N_Nmm':efforts,'field':q,
            'steelUtilization':usage,'criticalSteelPoint':int(critical),'criticalSignedAxialStrain':strains[int(critical)],
            'longitudinalMaxAbsStrain':peak(v for i,v in strains.items() if i<=72),
            'hoopMaxAbsStrain':peak(v for i,v in strains.items() if i>72),
            'tauMPa':tau,'fullBalanceNormMPa':max(norm,force,gauge,abs(ctrl)),
            'independentSixForceNormMPa':independent_force,'maxWrenchRoundingUncertainty_kNm':force*SCALES[3]/1e6,
            'allWeakAndGauges':weak,'twistControlNormMPa':ctrl}


def verify():
    fixture=read(HERE/'Fixture.json')
    owned=process(fixture)
    raw=(NATIVE/'B-Post.csv').read_bytes()
    complete=raw if raw.endswith(b'\n') else raw[:raw.rfind(b'\n')+1]
    stream=[r for r in csv.reader(StringIO(complete.decode('cp1251')),delimiter=';') if r]
    assert stream[0]==['RESUME','9','43','56'] and stream[1][0:2]==['RESUME_LAW','B'] and stream[2][0]=='REPLAY'
    g_t,g_c=vector(stream[1][2:],2)
    close(g_t,.1194033324156538,5e-14); close(g_c,26.692180820749954,5e-12)
    replay=vector(stream[2][1:],8)
    assert 0<=replay[0]<=5e-6 and 0<=replay[1]<=5e-6
    n,tw,lam,increment,max_tw,left_usage=vector(stream[3][1:],6)
    assert stream[3][0]=='POST' and n==43 and tw==fixture['lastTwist_rad_m'] and max_tw==.06 and increment==.001
    assert left_usage<=1. and lam>0
    assert sha((HERE/'B43.csv').read_bytes())==fixture['frozen']['B43.csv']
    with (HERE/'B43.csv').open(encoding='ascii',newline='') as f:
        prefix=list(csv.reader(f,delimiter=';'))
    end=vector(prefix[-1],68); prior=vector(prefix[-2],68)
    assert end[0]==43 and end[1]==tw and prior[0]==42 and prior[1]<tw
    close(lam,end[5]/1e8,1e-14)
    close(replay[1],peak((x-y)/s for x,y,s in zip(replay[2:],end[2:8],SCALES)),5e-13)
    anchor={'index':43,'twist_rad_m':tw,'T_kNm':end[5]/1e6,'steelUtilization':left_usage,
            'maxWrenchRoundingUncertainty_kNm':replay[1]*SCALES[3]/1e6,'field':end[8:]}
    previous={'index':42,'twist_rad_m':prior[1],'T_kNm':prior[5]/1e6,'field':prior[8:]}
    blocks=defaultdict(dict); points=defaultdict(dict); geometry={}; events=[]
    for row in stream[4:]:
        tag=row[0]
        if tag in ('BALANCE','WEAK','WRENCH','TRIALFIELD','POINT'):
            role,index,attempt,*vals=row[1:]
            assert role in ('Primary','RepeatUpper')
            key=(role,int(index),int(attempt))
            if tag=='POINT':
                point=int(vals[0]); assert point not in points[key]
                points[key][point]=vals[1:]
            else:
                assert key not in blocks[tag]
                blocks[tag][key]=vals
        else:
            assert tag in ('FIELD','REJECT','ROLLBACK','UPPER_TRIAL','ROLLBACK_UPPER','BRACKET','UNCONFIRMED_UPPER','STOP')
            events.append(row)
    fields=[previous,anchor]; rejects=[]; pending=None; bracket=None; stop=None; attempt=0
    for tag,*row in events:
        s=fields[-1]
        if tag=='FIELD':
            index,step=int(row[0]),int(row[1])
            assert index==s['index']+1 and step==attempt+1 and pending is None and bracket is None and stop is None
            role=row[2]; twist,resid,hoop,long,energy,sec,*rest=vector(row[3:],72)
            assert role in ('LoadSecant','AcceptedField') and 0<=hoop<=696.+1e-7 and 0<=long<=672.+1e-7 and 0<=energy<=1.+1e-9
            key=('Primary',index,step)
            candidate=force_check(key,blocks,points,geometry)
            assert tuple(rest[:6])==candidate['actualSix_N_Nmm'] and tuple(rest[6:])==candidate['field']
            close(twist,candidate['twist_rad_m'],1e-14)
            close(candidate['requestedTwist_rad_m'],min(.06,s['twist_rad_m']+increment),1e-14)
            close(resid,peak((a-b)/v for a,b,v in zip(candidate['actualSix_N_Nmm'],(0.,0.,0.,candidate['lambda']*1e8,0.,0.),SCALES)),3e-13)
            assert sec>=0 and candidate['steelUtilization']<=1. and twist>s['twist_rad_m']
            ratio=(candidate['requestedTwist_rad_m']-s['twist_rad_m'])/(s['twist_rad_m']-fields[-2]['twist_rad_m'])
            forward=stays_forward(fields[-2],s,candidate,ratio)
            if role=='LoadSecant':
                assert 0<ratio<=1.25000002 and forward
            candidate.update({'index':index,'attempt':step,'route':role,'seconds':sec,'hoopStressMPa':hoop,
                              'longitudinalStressMPa':long,'concreteTensionEnergyRatio':energy,'continuedFieldDirection':forward})
            fields.append(candidate); attempt=step; increment=min(.001,1.25*increment)
        elif tag=='REJECT':
            step=int(row[0]); assert step==attempt+1 and pending is None
            close(float(row[1]),min(.06,s['twist_rad_m']+increment),1e-14)
            pending={'attempt':step,'requestedTwist_rad_m':float(row[1]),'diagnostic':';'.join(row[2:])}
        elif tag=='ROLLBACK':
            step,index=map(int,row); assert pending and pending['attempt']==step and index==s['index']
            rejects.append(pending); pending=None; attempt=step; increment*=.5
        elif tag=='BRACKET':
            step,index=int(row[0]),int(row[1]); assert bracket is None and pending is None and index==s['index'] and step==attempt+1
            left_tw,left_lambda,left_u,u0,u1=vector(row[2:],5)
            close(left_tw,s['twist_rad_m'],1e-14); close(left_lambda,s.get('lambda',lam),1e-14)
            assert left_u==s['steelUtilization']<=1. and u0>1. and u1>1.
            assert ['ROLLBACK_UPPER',str(step),str(index)] in events
            primary=force_check(('Primary',index+1,step),blocks,points,geometry)
            repeat=force_check(('RepeatUpper',index+1,step),blocks,points,geometry)
            assert primary['steelUtilization']==u0 and repeat['steelUtilization']==u1
            close(primary['requestedTwist_rad_m'],repeat['requestedTwist_rad_m'],1e-14)
            close(primary['requestedTwist_rad_m'],min(.06,left_tw+increment),1e-14)
            assert primary['twist_rad_m']>left_tw and repeat['twist_rad_m']>left_tw
            ratio=(primary['requestedTwist_rad_m']-left_tw)/(left_tw-fields[-2]['twist_rad_m'])
            assert stays_forward(fields[-2],s,primary,ratio)
            close(primary['lambda'],repeat['lambda'],1e-7)
            qerr=peak(a-b for a,b in zip(primary['field'],repeat['field']))
            assert qerr<=5e-11
            bracket={'left':s,'upperUncommitted':primary,'repeatedUncommittedUpper':repeat,'upperDifferenceFieldMax':qerr,
                     'sameAcceptedLeftStateAfterBothUpperTrials':True}
        elif tag=='STOP':
            assert stop is None and pending is None
            stop=row[0]
            assert int(row[1])==len(fields)-2
    if owned['terminal']=='completed':
        assert stop in ('ConfirmedSteelStrainBracket','TwistLimit','MinimumTwistIncrement','AttemptLimit')
        assert not raw[len(complete):]
    if stop=='ConfirmedSteelStrainBracket':
        assert bracket
    if stop=='TwistLimit':
        close(fields[-1]['requestedTwist_rad_m'],.06,1e-14)
    if stop=='MinimumTwistIncrement':
        assert increment<.000001953125
    if stop=='AttemptLimit':
        assert attempt==125
    accepted=fields[1:]
    changes=[b['T_kNm']-a['T_kNm'] for a,b in zip(accepted,accepted[1:])]
    significant=[abs(d)>a['maxWrenchRoundingUncertainty_kNm']+b['maxWrenchRoundingUncertainty_kNm']
                 for a,b,d in zip(accepted,accepted[1:],changes)]
    triple=[]
    for i,(rise,fall) in enumerate(zip(changes,changes[1:])):
        if rise*fall<0 and significant[i] and significant[i+1]:
            triple.append({'type':'sampled local maximum' if rise>0 else 'sampled local minimum',
                           'neighbors':[{'index':s['index'],'twist_rad_m':s['twist_rad_m'],'T_kNm':s['T_kNm'],
                                        'steelUtilization':s['steelUtilization']} for s in accepted[i:i+3]]})
    known={s['attempt'] for s in fields[2:]}
    if bracket:
        known.add(int(next(row[1] for row in events if row[0]=='BRACKET')))
    uncommitted=sorted({key[2] for key in blocks['BALANCE']}-known)
    best=max(accepted,key=lambda s:s['T_kNm'])
    result={'closure':owned,'stop':stop,'physicalMaximumCertified':False,'newBalancedAcceptedFields':len(fields)-2,
            'highestObservedT_kNm':best['T_kNm'],'highestObservedFieldIndex':best['index'],
            'crossingBracket':bracket,'sampledTurningTriples':triple,
            'decliningPairs':[{'left':a['index'],'right':b['index'],'deltaT_kNm':d} for a,b,d,g in zip(accepted,accepted[1:],changes,significant) if d<0 and g],
            'rejectedAttemptsWithVerifiedRollback':rejects,'uncommittedTrialAttemptsExcluded':uncommitted,
            'tornTrailingBytesExcluded':len(raw)-len(complete),'rawTraceSHA256':sha(raw),'accepted':accepted}
    output=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode('utf8')
    (HERE/'B-Post-Verification.json').write_bytes(output)
    print('A2_B_POST_PROTOCOL_PASS',sha(output),owned['terminal'],stop,len(fields)-2,best['T_kNm'],len(triple),bool(bracket))


if __name__=='__main__':
    verify()
