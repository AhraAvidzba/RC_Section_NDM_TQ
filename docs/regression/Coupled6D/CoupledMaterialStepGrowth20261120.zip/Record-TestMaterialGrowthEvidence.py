"""ДЛЯ ТЕСТОВ. Сохраняет контрольную точку 635 только после точного воспроизведения из чистого архива."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile, ZIP_DEFLATED


def TestRecord(repo, root):
    """Фиксирует исходники и проверенные ограничения; основную книгу и статус физического предела не меняет."""
    proof = (root / 'MaterialGrowthProof.json').read_bytes()
    parsed = json.loads(proof)
    assert len(parsed['working_source_binding']) == 3 and not parsed['physical_capacity_certified']
    for name in ('CCoupledNewtonSolver.cls', 'CCoupledPrincipalTransition.cls', 'CCoupledDeformationContinuation.cls'):
        assert (root / 'WorkingSources' / name).read_bytes() == (repo / 'src/Solver' / name).read_bytes()
    name = Path(__file__).name
    (root / name).write_bytes(Path(__file__).read_bytes())
    pins = json.loads((root / 'Files.json').read_bytes())
    pins[name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / 'Files.json').write_bytes((json.dumps(pins, indent=2, sort_keys=True) + '\n').encode())
    archive = root.parent / 'CoupledMaterialStepGrowth20261120.zip'
    with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as output:
        for file in sorted(root.rglob('*')):
            if file.is_file() and file.name != 'CompiledVBA.bin':
                output.write(file, file.relative_to(root).as_posix())
    clean = root.parent / 'MaterialStepGrowthCleanReplay20261120'
    clean.mkdir()
    with ZipFile(archive) as source:
        for member in source.infolist():
            assert (clean / member.filename).resolve().is_relative_to(clean.resolve())
            source.extract(member, clean)
    repeated = run_path(str(clean / 'Check-TestMaterialGrowthEvidence.py'))['TestProof'](repo, clean)
    repeated_bytes = (json.dumps(repeated, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()
    (clean / 'MaterialGrowthProof.Repeated.json').write_bytes(repeated_bytes)
    assert repeated_bytes == proof
    destination = repo / 'docs/regression/Coupled6D' / archive.name
    with destination.open('xb') as stream:
        stream.write(archive.read_bytes())
    digest = sha256(destination.read_bytes()).hexdigest().upper()
    proof_digest = sha256(proof).hexdigest().upper()
    path = repo / 'docs/reports/Coupled6DEvidence.json'
    original = path.read_text('utf-8-sig')
    old = json.loads(original)
    assert len(old['archives']) == 328 and len(old['cases']) == 388
    anchor = '    "CoupledWorkingMaterialEvent20261120": "' + old['archives']['CoupledWorkingMaterialEvent20261120'] + '"'
    assert original.count(anchor) == 1
    text = original.replace(anchor, anchor + ',\n    "' + archive.stem + '": "' + digest + '"', 1)
    case = {'id': 'coupled-material-step-growth', 'journal_section': 635, 'archive': archive.stem,
        'script': 'Check-TestMaterialGrowthEvidence.py',
        'arguments': ['--repo', '{repo}', '--root', '.', '--out', 'MaterialGrowthProof.json'],
        'stdout_contains': 'MATERIAL STEP GROWTH EVIDENCE PASS; RELOAD OBSERVED; CAPACITY OPEN',
        'outputs': {'MaterialGrowthProof.json': proof_digest}, 'timeout_seconds': 600}
    begin = text.index('  "cases": [\n')
    end = text.index('\n  ],', begin)
    text = text[:end] + ',\n' + '\n'.join('    ' + line for line in json.dumps(case, ensure_ascii=False, indent=2).splitlines()) + text[end:]
    updated = json.loads(text)
    assert updated['cases'][:-1] == old['cases']
    assert {k: v for k, v in updated['archives'].items() if k != archive.stem} == old['archives']
    assert all(updated[k] == v for k, v in old.items() if k not in ('archives', 'cases'))
    path.write_bytes(text.replace('\n', '\r\n').encode())
    stock = parsed['cases']['Stock125']
    note = f'''
### 635. Адаптация шага CDP и восстановление нагрузки при изменении шага

Рабочий контроллер увеличивает шаг после двух согласованных прогнозов
в тензорной метрике; доверенный масштаб берётся из фактически принятого поля.
В трёх нативных повторениях от общей истории 147 состояний получены
205/215/208 равновесий при росте шага 1,25/1,15/1,50 соответственно.
Все усилия и пространственные уравнения проверены независимо.
При 1,25 достигнута λ = 0,04732875; при 1,50 после спада до 1,09986065
получено восстановление до 1,11287202. Это требует дальнейшего разбора
смены меры и зависимости ветви от шага. Общий максимум 1,117159893
не является независимой проверкой пика: исходное событие одинаково.

Штатный Both/Excel: Direct OK, Capacity NumFail, нижняя подтверждённая
λ = {stock['stock_lower_lambda']:.14f}, время {stock['stock_seconds']:.3f} с.
Results сохранены и повторно открыты без изменения; 168 затронутых
регрессионных утверждений пройдены. Ни физический предел, ни цель 10 с
не подтверждены. Основная книга и main сохранены; полные наборы не запускались.

Комплект [CoupledMaterialStepGrowth20261120](../regression/Coupled6D/CoupledMaterialStepGrowth20261120.zip),
{destination.stat().st_size} байт, SHA-256 `{digest}`.
MaterialGrowthProof.json: `{proof_digest}`. Чистое воспроизведение точное.
Всего 329 архивов и 389 случаев; прежние записи сохранены.
Подробности: [проверка шага и состояния материалов](Coupled6DMaterialStepGrowth_2026-11-20.md).
'''
    for name in ('Coupled6DProgress.md', 'Coupled6DAcceptance.md'):
        path = repo / 'docs/reports' / name
        raw = path.read_bytes()
        assert b'### 635.' not in raw
        path.write_bytes(raw + note.replace('\n', '\r\n').encode())
    path = repo / 'docs/reports/Coupled6DMaterialStepGrowth_2026-11-20.md'
    text = path.read_text('utf-8')
    text = text.replace('Этап 635.', 'Контрольная точка 635.', 1)
    text += '\n## Контрольная точка\n\n' + note.strip() + '\n'
    path.write_bytes(text.encode())
    result = {'bytes': destination.stat().st_size, 'sha256': digest, 'proof_sha256': proof_digest,
        'archives': 329, 'cases': 389, 'clean_replay_exact': True,
        'physical_capacity_certified': False, 'installed_workbook_changed': False}
    (root.parent / 'MaterialGrowthRecord.json').write_bytes((json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    print('MATERIAL STEP GROWTH CHECKPOINT 635 RECORDED; CLEAN REPLAY EXACT; CAPACITY OPEN')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=Path.cwd())
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    TestRecord(a.repo.resolve(), a.root.resolve())
