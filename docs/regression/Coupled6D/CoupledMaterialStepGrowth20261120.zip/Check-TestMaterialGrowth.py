"""ДЛЯ ТЕСТОВ. Проверяет равновесие и сравнивает принятые ветви CDP при разных шагах без назначения физического предела."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestWrite(path, value):
    """Фиксирует UTF-8 LF для воспроизводимого независимого отчёта."""
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + '\n').encode())


def TestRead(root, save=True):
    """Считывает фактические напряжения; равновесие пересчитывает независимо от VBA, материал повторно не интегрирует."""
    here = Path(__file__).resolve().parent
    reader = run_path(str(here / 'Validate-TestHardPrepared.py'))
    proof, fields = reader['TestValidate'](root, 'IntegratedEvent.Sequence')
    rows = reader['TestRows'](root / 'Native/IntegratedEvent.Sequence.csv')
    headers = {r[0]: r[1:] for r in rows if r[0] in ('DIM', 'OFFSET', 'DIRECTION', 'LAW', 'OPTIONS')}
    dofs, physical, points, concrete = map(int, headers['DIM'][:4])
    raw = np.zeros((len(fields), 3, points, 9))
    seen = np.zeros((len(fields), 3, points), int)
    for r in rows:
        if r[0] == 'S':
            i, side, p = int(r[1]) - 1, int(r[2]) + 1, int(r[3]) - 1
            raw[i, side, p] = np.asarray(r[4:], float)
            seen[i, side, p] += 1
    assert np.all(seen == 1)
    _, _, _, _, coords, axis, b, gradient = run_path(str(here / 'Check-TestHardHalfSteps.py'))['TestOperators'](
        root / 'Native/IntegratedEvent.Sequence.Operators.csv', dofs, points)
    half = float(headers['DIM'][4])
    strains = np.asarray([np.einsum('pcd,nd->npc', b + s * half * gradient, fields) for s in (-1, 0, 1)]).transpose(1, 0, 2, 3)
    factors = np.asarray([s['lambda'] for s in proof['states']])
    longitudinal = np.abs(axis[:, 2]) > .9
    longitudinal[:concrete] = False
    transverse = ~longitudinal
    transverse[:concrete] = False
    center = np.average(coords[:concrete, :2], axis=0, weights=coords[:concrete, 2])
    x, y = (coords[:, :2] - center).T

    def TestResultants(sigma):
        """Интегрирует шесть усилий в общей системе знаков, Н и Н·мм."""
        weights = coords[:, 2]
        return np.asarray([np.dot(weights, sigma[:, 2]), np.dot(weights * y, sigma[:, 2]),
            np.dot(weights * x, sigma[:, 2]), np.dot(weights, x * sigma[:, 5] - y * sigma[:, 4]),
            np.dot(weights, sigma[:, 4]), np.dot(weights, sigma[:, 5])])

    selected = sorted(set([3, 146, 147, 148, len(fields) - 1] + [148 + int(np.argmin(np.abs(factors[148:] - f))) for f in (1.1, 1., .75, .5, .25, .1)]))
    summaries = []
    for i in selected:
        sigma = raw[i, 1, :, :6].copy()
        sigma[concrete:] = 0
        steel = raw[i, 1, :, 8, None] * axis
        replaced = raw[i, 1, :, :6].copy()
        replaced[:concrete] = 0
        summaries.append(dict(index=i + 1, lambda_value=float(factors[i]),
            concrete_principal_strain_range=TestPrincipalRange(strains[i, :, :concrete]),
            concrete_tension_energy_ratio_max=float(raw[i, :, :concrete, 6].max()),
            concrete_compression_energy_ratio_max=float(raw[i, :, :concrete, 7].max()),
            longitudinal_stress_range_MPa=[float(raw[i, :, longitudinal, 8].min()), float(raw[i, :, longitudinal, 8].max())],
            transverse_stress_range_MPa=[float(raw[i, :, transverse, 8].min()), float(raw[i, :, transverse, 8].max())],
            concrete_resultants=TestResultants(sigma).tolist(), steel_resultants=TestResultants(steel).tolist(),
            replaced_concrete_resultants=TestResultants(replaced).tolist(),
            steel_ultimate_utilization=proof['states'][i]['steel_utilization']))
    assert proof['reversed_fields'] == [149]
    activity = raw[-1, :, :concrete, 6:8] - raw[148, :, :concrete, 6:8]
    assert np.all(np.diff(raw[:, :, :concrete, 6:8], axis=0) >= -1e-14)
    result = dict(root=root.name, states=len(fields), maximum_lambda=float(factors.max()), last_lambda=float(factors[-1]),
        minimum_lambda_after_state149=float(factors[148:].min()),
        largest_recovery_after_state149=float(np.max(factors[148:] - np.minimum.accumulate(factors[148:]))),
        initial_147_fields_retained=True, all_six_and_spatial_equilibrium=True, reversed_fields=proof['reversed_fields'],
        energy_ratios_nondecreasing=True, newly_active_concrete_station_energy_entries=int(np.count_nonzero(activity > 1e-14)),
        largest_tension_energy_ratio_change_after_state149=float(activity[:, :, 0].max()),
        largest_compression_energy_ratio_change_after_state149=float(activity[:, :, 1].max()),
        independent_material_reintegration=False, physical_capacity_certified=False,
        strain_axis_order='xx,yy,zz,engineering_xy,engineering_xz,engineering_yz', selected_states=summaries)
    if save:
        TestWrite(root / 'IndependentMechanicsProof.json', proof)
        TestWrite(root / 'MaterialBranchStateProof.json', result)
    return result, fields, factors, strains, coords, headers


def TestPrincipalRange(strains):
    """Переходит от инженерных сдвигов к симметричным тензорам; одноосный предел на них не назначает."""
    tensor = np.zeros(strains.shape[:-1] + (3, 3))
    for i in range(3):
        tensor[..., i, i] = strains[..., i]
    for c, (i, j) in enumerate(((0, 1), (0, 2), (1, 2)), start=3):
        tensor[..., i, j] = tensor[..., j, i] = .5 * strains[..., c]
    principal = np.linalg.eigvalsh(tensor)
    return [float(principal.min()), float(principal.max())]


def TestCompare(roots, output, save_case_proofs=True, verbose=True):
    """Сравнивает деформации по одинаковой нисходящей нагрузке; линейная интерполяция является только диагностикой шага."""
    data = [TestRead(root, save_case_proofs) for root in roots]
    reference = data[0]
    comparisons = []
    for case in data[1:]:
        assert np.array_equal(reference[1][:147], case[1][:147])
        assert reference[5] == case[5]
        assert np.array_equal(reference[4], case[4])
        levels = []
        for level in (1.117, 1.11, 1.1, 1., .9, .75, .5, .25, .15, .1):
            values = []
            for datum in (reference, case):
                _, _, factors, strains, _, _ = datum
                peak = int(np.argmax(factors))
                right = next((i for i in range(peak + 1, len(factors)) if factors[i] <= level < factors[i - 1]), None)
                if right is None:
                    break
                f = (level - factors[right - 1]) / (factors[right] - factors[right - 1])
                values.append((1 - f) * strains[right - 1] + f * strains[right])
            if len(values) != 2:
                continue
            weights = reference[4][:, 2]
            metric = np.asarray([1., 1., 1., .5, .5, .5])
            norm = lambda v: float(np.sqrt(np.einsum('spc,spc,p,c->', v, v, weights, metric) / (3 * sum(weights))))
            scale = norm(values[0])
            levels.append(dict(lambda_value=level, tensor_relative_difference=norm(values[1] - values[0]) / scale))
        comparisons.append(dict(reference=reference[0]['root'], case=case[0]['root'],
            maximum_lambda_difference=case[0]['maximum_lambda'] - reference[0]['maximum_lambda'], levels=levels))
    proof = dict(cases=[d[0] for d in data], comparisons=comparisons,
        interpolation_is_not_additional_equilibrium_solution=True,
        shared_event_maximum_is_not_peak_sensitivity_validation=True, physical_capacity_certified=False)
    if output is not None:
        TestWrite(output, proof)
    if verbose:
        print(json.dumps(dict(cases=[{k: d[0][k] for k in ('root', 'states', 'maximum_lambda', 'last_lambda')} for d in data],
            comparisons=comparisons), indent=2))
    return proof


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, action='append', required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    TestCompare([r.resolve() for r in a.root], a.out.resolve())
