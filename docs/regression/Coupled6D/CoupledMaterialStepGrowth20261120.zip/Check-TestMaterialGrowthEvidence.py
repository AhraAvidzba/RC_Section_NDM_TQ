"""ДЛЯ ТЕСТОВ. Проверяет адаптацию шага CDP, независимое равновесие и ограничения трёх нативных ветвей."""
from argparse import ArgumentParser
from contextlib import redirect_stdout
from io import StringIO
from hashlib import sha256
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
import json,re,tarfile,csv
import numpy as np


def TestProof(repo,root):
    """Исходный файл книги закреплён внутри комплекта; изменённая текущая книга не подменяет базу проверки."""
    here=Path(__file__).resolve().parent
    for name,digest in json.loads((root/'Files.json').read_bytes()).items():assert sha256((root/name).read_bytes()).hexdigest().upper()==digest,name
    class TestRepo:
        """Перенаправляет только исходную книгу на точную сохранённую копию; закреплённые декодеры берутся из репозитория."""
        def __truediv__(self,name):return root/'BaseWorkbook.xlsm' if str(name)=='workbook/output/RC_Section_NDM.xlsm' else repo/name
    base=TestRepo()
    cases=json.loads((root/'Cases.json').read_bytes());parents=json.loads((root/'ParentProjects.json').read_bytes())
    binaries={};bundle=json.loads((root/'CompiledProjects.json').read_bytes())
    with tarfile.open(root/'CompiledProjects.tar.xz',mode='r|xz') as archive:
        for member in archive:
            assert member.isfile() and '/' not in member.name and member.size<=64*1024*1024
            name=member.name[:-4];raw=archive.extractfile(member).read()
            assert sha256(raw).hexdigest().upper()==bundle['projects'][name]['sha256'];binaries[name]=raw
    helper,_,reader=run_path(str(here/'Inspect-TestResolutionVBA.py'))['TestHelpers'](base)
    decoded={}
    def TestComponents(name):
        """Кэширует только неизменное CFB по точному SHA, без состояния материалов или результатов решения."""
        digest=sha256(binaries[name]).hexdigest().upper()
        if digest not in decoded:_,decoded[digest]=reader(helper['TestContainer'](binaries[name]))
        return decoded[digest]
    def TestIdentifierCase(text):
        """Сохраняет строки, комментарии и символы, учитывая только регистр имён VBE."""
        return re.sub(r'"(?:[^"\n]|"")*"|\'[^\n]*|[A-Za-z_][\w]*',lambda m:m.group() if m.group().startswith(('"',"'")) else m.group().lower(),text)
    source=(here/'Audit-TestPrivateCoupledBook.py').read_text('utf-8-sig')
    before="    assert compilation['Compiled'] and not compilation['ProductionChanged']";assert source.count(before)==1
    source=source.replace(before,before+"\n    assert compilation['Modules']==['CCoupledDeformationContinuation']\n    compilation['Modules']=json.loads((root/'Preparation.json').read_bytes())['modules']",1)
    scope={'__name__':'working_material_event_audit','__file__':str(here/'Audit-TestPrivateCoupledBook.py')};exec(compile(source,scope['__file__'],'exec'),scope)
    proofs={};code_cache={}
    validate=run_path(str(here/'Validate-TestHardPrepared.py'))['TestValidate']
    saved_reader=run_path(str(here/'Compare-TestSavedCoupledTrace.py'))['TestSavedTrace']
    for key in cases:
        folder=root/'Cases'/key;prep=json.loads((folder/'Preparation.json').read_bytes())
        for name,digest in prep['inputs'].items():
            path=base/name if name=='workbook/output/RC_Section_NDM.xlsm' else folder/name
            assert sha256(path.read_bytes()).hexdigest().upper()==digest,(key,name)
        comp=json.loads((folder/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'));imports=comp['Modules']
        signature=(sha256(binaries[key]).hexdigest().upper(),prep['source_book_sha256'],tuple(sorted((n,h) for n,h in prep['inputs'].items() if n.startswith(('src/','tests/')))))
        if signature not in code_cache:
            with TemporaryDirectory() as temporary,redirect_stdout(StringIO()):
                output=Path(temporary)/'Code.json';scope['TestAudit'](base,folder,output);code_cache[signature]=json.loads(output.read_bytes())
        audit=code_cache[signature];assert (audit['components'],audit['imported'],audit['unchanged'])==(253,40,213)
        parent=TestComponents(parents[key]['case']);actual=TestComponents(key)
        assert len(parent)==len(actual)==253 and set(parent)==set(actual)
        assert sha256(binaries[parents[key]['case']]).hexdigest().upper()==parents[key]['sha256']
        assert all(TestIdentifierCase(parent[n])==TestIdentifierCase(actual[n]) for n in actual if n not in imports),(key,imports)
        for name in ('CCoupledConcreteReturn.cls','CCoupledConcreteResponse.cls'):
            before=(root/'WorkingMaterials'/name).read_text('utf-8-sig');after=(folder/'src/Materials'/name).read_text('utf-8-sig')
            if name.startswith('CCoupledConcreteReturn'):assert before==after
            else:
                assert after.startswith(before)
                assert set(re.findall(r'^Friend Function (\w+)\(',after[len(before):],re.M))=={'ReadNewtonYieldEventStateTest','TryReadTrialEnvelopeEnergyTest'}
        native=json.loads((folder/'Native/ExternalResult.json').read_bytes())
        own=json.loads((folder/'Native/ExternalOwnership.json').read_bytes())
        assert native['source_unchanged'] and native['source_sha256']==comp['WorkbookSHA256']
        assert native['owned_excel_final_state']['state']=='Exited' and native['owned_excel_final_state']['filetime']==own['filetime']
        rows=list(csv.reader((folder/'Native/IntegratedEvent.csv').read_text('cp1251').splitlines(),delimiter=';'))
        values={r[0]:r[1:] for r in rows if r and r[0] in ('START','CONTROLLER','PEAK','STEEL')}
        assert values['START'][0]=='147' and values['PEAK'][0]==values['STEEL'][0]=='0'
        proof={'source':audit,'actual_imports':imports,'other_parent_components_exact_except_identifier_case':252,
            'controller_seconds':float(values['CONTROLLER'][0]),'probes':int(values['CONTROLLER'][-1]),'capacity_certified':False}
        if key=='Stock125':
            text=(folder/'Native/Stock.txt').read_text('utf-8-sig')
            lower,=re.findall(r'^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([^;]+); limit=; code=NUMERICAL_FAILURE$',text,re.M)
            seconds,=re.findall(r'^TIMING_SECONDS: ([^ |]+) \| Both \| Excel$',text,re.M)
            assert lower=='1.10777685650622'
            assert 'TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0' in text
            assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
            assert f'SOURCE_SHA256: {comp["WorkbookSHA256"]}' in text
            closure=json.loads((folder/'Native/Stock.txt.ProcessClosure.json').read_bytes())
            assert closure['Passed'] and closure['ChildHasExited'] and closure['Closure']['FinalState']['State']=='Absent'
            saved=saved_reader(folder)
            saved_factors=[float(v['value']) for k,v in saved.items() if '.Capacity.' in k and k.endswith('.Lambda')]
            assert abs(max(saved_factors)-float(lower))<1e-13
            regression=(folder/'Native/PeakRegression.txt').read_text('utf-8-sig')
            totals=re.findall(r'^TOTAL_[^:]+: passed=(\d+); failed=(\d+)$',regression,re.M)
            assert len(totals)==7 and all(f=='0' for _,f in totals) and sum(int(p) for p,_ in totals)==168
            closure=json.loads((folder/'Native/PeakRegression.txt.ProcessClosure.json').read_bytes())
            assert closure['Passed'] and closure['Closure']['FinalState']['State']=='Absent'
            proof.update(stock_lower_lambda=float(lower),stock_seconds=float(seconds),stock_direct='OK',stock_capacity='NumFail',
                reopen_equal=True,directed_regression_assertions=168,physical_limit=None)
        proofs[key]=proof
    bindings={}
    def TestCodeLines(text):
        """Для связи двух исходных текстов исключает только комментарии и пустые строки; исполняемый текст сохраняется."""
        clean=re.sub(r'"(?:[^"\n]|"")*"|\'[^\n]*',lambda m:m.group() if m.group().startswith('"') else '',text)
        return '\n'.join(line.strip() for line in clean.splitlines() if line.strip())
    for name,key in [('CCoupledNewtonSolver.cls','Stock125'),('CCoupledPrincipalTransition.cls','Stock125'),('CCoupledDeformationContinuation.cls','Stock125')]:
        working=(root/'WorkingSources'/name).read_text('utf-8-sig')
        prepared=(root/'Cases'/key/'src/Solver'/name).read_text('utf-8-sig')
        if name=='CCoupledNewtonSolver.cls':
            marker='Friend Function ReadReverseControlTest() As Variant';assert prepared.count(marker)==1
            cut=prepared.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,prepared.index(marker));assert cut>0
            prepared=prepared[:cut]
        assert TestCodeLines(working)==TestCodeLines(prepared),name
        bindings[name]={'tested_case':key,'current_working_code_matches_tested_source_excluding_comments_only':True}
    comparator=run_path(str(here/'Check-TestMaterialGrowth.py'))['TestCompare']
    comparison=comparator([root/'Cases'/key for key in ('Stock125','Slow115','Fast150')],None,save_case_proofs=False,verbose=False)
    assert [case['states'] for case in comparison['cases']]==[205,215,208]
    assert [proofs[key]['probes'] for key in ('Stock125','Slow115','Fast150')]==[72,96,96]
    assert comparison['cases'][2]['largest_recovery_after_state149']>0.01
    variants={}
    base_source=(root/'WorkingSources/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')
    for key,growth in [('Stock125','1.25'),('Slow115','1.15'),('Fast150','1.5')]:
        expected=base_source.replace('Private Const MATERIAL_STEP_GROWTH As Double = 1.25','Private Const MATERIAL_STEP_GROWTH As Double = '+growth)
        actual=(root/'Cases'/key/'src/Solver/CCoupledDeformationContinuation.cls').read_text('utf-8-sig')
        assert TestCodeLines(expected)==TestCodeLines(actual)
        variants[key]={'only_material_growth_constant_varies':True,'growth':float(growth)}
    return {'cases':proofs,'working_source_binding':bindings,'variants':variants,'comparison':comparison,
        'physical_capacity_certified':False,'full_acceptance_completed':False,'installed_workbook_changed':False,
        'original_force_and_material_precision':True,'independent_material_reintegration':False,
        'current_stock_lower_preserved_exactly':True,'stock_limit_and_10second_target_still_open':True}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();proof=TestProof(a.repo.resolve(),a.root.resolve())
    a.out.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode('utf-8'))
    print('MATERIAL STEP GROWTH EVIDENCE PASS; RELOAD OBSERVED; CAPACITY OPEN')
