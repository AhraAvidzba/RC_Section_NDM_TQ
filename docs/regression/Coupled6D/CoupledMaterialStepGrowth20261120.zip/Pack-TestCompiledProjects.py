"""ДЛЯ ТЕСТОВ. Упаковывает точные CFB-проекты одним потоком без изменения их байтов."""

from hashlib import sha256
import json
import lzma
from pathlib import Path
import tarfile


def TestPack(root, names):
    """Полные копии на D сохраняются; общий поток проверяется распаковкой и заменяет их только внутри архива доказательств."""
    target = root / 'CompiledProjects.tar.xz'
    records = {}
    with target.open('xb') as raw, lzma.LZMAFile(raw, 'w', filters=[
            {'id': lzma.FILTER_LZMA2, 'dict_size': 32 * 1024 * 1024, 'preset': 6}]) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.USTAR_FORMAT) as bundle:
            for name in names:
                folder = root / 'Cases' / name
                source = folder / 'CompiledVBA.bin'
                pin = json.loads((folder / 'CompiledVBA.json').read_bytes())
                assert source.stat().st_size == pin['bytes'] <= 64 * 1024 * 1024
                assert sha256(source.read_bytes()).hexdigest().upper() == pin['sha256']
                info = tarfile.TarInfo(name + '.bin')
                info.size = pin['bytes']
                info.mtime = 0
                info.mode = 0o600
                with source.open('rb') as stream:
                    bundle.addfile(info, stream)
                records[name] = {'member': info.name, **pin}
    observed = {}
    with tarfile.open(target, mode='r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name.endswith('.bin') and '/' not in member.name
            assert member.size <= 64 * 1024 * 1024
            data = bundle.extractfile(member).read()
            name = member.name[:-4]
            observed[name] = {'member': member.name, 'bytes': len(data), 'sha256': sha256(data).hexdigest().upper()}
    assert observed == records
    digest = sha256(target.read_bytes()).hexdigest().upper()
    for name, record in records.items():
        (root / 'Cases' / name / 'CompiledVBA.solid.json').write_text(json.dumps({
            'format': 'NDM_TEST_SOLID_CFB_01', 'bundle': target.name, 'bundle_sha256': digest,
            **record}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    result = {'format': 'NDM_TEST_SOLID_CFB_01', 'bundle': target.name, 'bundle_bytes': target.stat().st_size,
        'bundle_sha256': digest, 'projects': records, 'all_CFB_bytes_verified_after_unpack': True,
        'raw_CFB_copies_retained_on_scratch_disk_excluded_from_outer_archive': True}
    (root / 'CompiledProjects.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('EXACT SOLID CFB PACK VERIFIED', len(records), target.stat().st_size)
    return result
