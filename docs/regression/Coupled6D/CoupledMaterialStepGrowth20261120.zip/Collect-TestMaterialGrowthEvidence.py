"""ДЛЯ ТЕСТОВ. Сохраняет три шага CDP, штатный исход и исходные CFB без подмены численного отказа пределом."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile,ZIP_DEFLATED
import json,re

TestCases={'Stock125':'MaterialGrowth12520261120','Slow115':'MaterialGrowth11520261120','Fast150':'MaterialGrowth15020261120'}


def TestCollect(repo,root):
    """Копирует только собственные законченные данные; точные CFB родителя сохраняют происхождение каждого импорта."""
    here=Path(__file__).resolve().parent;root.mkdir()
    projects={};pending={}
    for key,name in TestCases.items():
        source=root.parent/name;target=root/'Cases'/key
        prep=json.loads((source/'Preparation.json').read_bytes())
        for file,digest in prep['inputs'].items():assert sha256((source/file).read_bytes()).hexdigest().upper()==digest,(key,file)
        compilation=json.loads((source/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
        book=source/'docs/regression/Diagnostic.xlsm'
        assert sha256(book.read_bytes()).hexdigest().upper()==compilation['WorkbookSHA256']
        for file in source.rglob('*'):
            if not file.is_file():continue
            relative=file.relative_to(source)
            if relative.parts[0] in ('Temp','workbook','__pycache__') or file.suffix.lower()=='.xlsm' or file.name=='ParentCompiledVBA.bin':continue
            destination=target/relative;destination.parent.mkdir(parents=True,exist_ok=True)
            destination.write_bytes(file.read_bytes())
        with ZipFile(book) as archive:binary=archive.read('xl/vbaProject.bin')
        (target/'CompiledVBA.bin').write_bytes(binary)
        digest=sha256(binary).hexdigest().upper();projects[digest]=key
        (target/'CompiledVBA.json').write_text(json.dumps({'bytes':len(binary),'sha256':digest},indent=2)+'\n',encoding='utf-8')
        parent=(source/'ParentCompiledVBA.bin').read_bytes();pending[key]=(sha256(parent).hexdigest().upper(),parent)
        if key.startswith('Stock'):
            report=(source/'Native/Stock.txt').read_text('utf-8-sig')
            saved,=re.findall(r'^RESULTS_SAVE_REOPEN: .*equal=True; file=([^\r\n]+)$',report,re.M)
            saved=Path(saved);assert saved.resolve().is_relative_to((source/'Temp').resolve())
            with ZipFile(saved) as archive,ZipFile(target/'SavedWorkbookMarkup.zip','x',ZIP_DEFLATED,compresslevel=9) as output:
                for member in sorted(archive.namelist()):
                    if Path(member).suffix.lower() in ('.xml','.rels','.vml'):output.writestr(member,archive.read(member))
            (target/'SavedWorkbookScope.json').write_text(json.dumps({'original_scratch_root':str(source)},indent=2)+'\n',encoding='utf-8')
            execution=saved.parent/'RC_Section_NDM_execution_report.txt'
            (target/'Native/ExecutionReport.txt').write_bytes(execution.read_bytes())
    parents={};pack_names=list(TestCases)
    for key,(digest,binary) in pending.items():
        if digest not in projects:
            name='Ancestor'+str(len(projects));folder=root/'Cases'/name;folder.mkdir()
            (folder/'CompiledVBA.bin').write_bytes(binary)
            (folder/'CompiledVBA.json').write_text(json.dumps({'bytes':len(binary),'sha256':digest},indent=2)+'\n',encoding='utf-8')
            projects[digest]=name;pack_names.append(name)
        parents[key]={'case':projects[digest],'sha256':digest}
    for name,value in [('Cases.json',TestCases),('ParentProjects.json',parents)]:
        (root/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    (root/'BaseWorkbook.xlsm').write_bytes((repo/'workbook/output/RC_Section_NDM.xlsm').read_bytes())
    (root/'WorkingMaterials').mkdir()
    for name in ('CCoupledConcreteReturn.cls','CCoupledConcreteResponse.cls'):
        (root/'WorkingMaterials'/name).write_bytes((repo/'src/Materials'/name).read_bytes())
    (root/'WorkingSources').mkdir()
    for name in ('CCoupledNewtonSolver.cls','CCoupledPrincipalTransition.cls','CCoupledDeformationContinuation.cls'):
        (root/'WorkingSources'/name).write_bytes((repo/'src/Solver'/name).read_bytes())
    (root/'IntegrationReport.md').write_bytes((repo/'docs/reports/Coupled6DMaterialStepGrowth_2026-11-20.md').read_bytes())
    names={Path(__file__).name,'Check-TestMaterialGrowthEvidence.py','Audit-TestPrivateCoupledBook.py',
        'Inspect-TestResolutionVBA.py','Validate-TestHardPrepared.py','Compare-TestSavedCoupledTrace.py','Pack-TestCompiledProjects.py'}
    pending=list(names)
    while pending:
        code=(here/pending.pop()).read_text('utf-8-sig')
        for name in re.findall(r"['\"]([^/'\"\s]+\.py)['\"]",code):
            if name not in names and (here/name).is_file():names.add(name);pending.append(name)
    for name in names:(root/name).write_bytes((here/name).read_bytes())
    run_path(str(here/'Pack-TestCompiledProjects.py'))['TestPack'](root,pack_names)
    pins={p.relative_to(root).as_posix():sha256(p.read_bytes()).hexdigest().upper() for p in root.rglob('*')
        if p.is_file() and p.name not in ('CompiledVBA.bin','Files.json')}
    (root/'Files.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('MATERIAL STEP GROWTH COLLECTED',len(pins),'FILES')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,required=True)
    a=p.parse_args();TestCollect(a.repo.resolve(),a.root.resolve())
