"""Offline replay of signed forces and 60 section equations, with optional native ASD rerun."""
from argparse import ArgumentParser
from hashlib import sha256
from importlib.metadata import version
from math import fsum, isfinite
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import gzip
import json
import runpy
import subprocess
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
CAPTURE=("MVT2GaussTensorCaptureNative20261117", "D2DBF6FDE48CDB5997FD099056DEC49231EEABE6D018D817E809C3F951D801A1")
OPS=("MVT2GaussSpatialOperatorsNative20261117", "8807822311947EDB91EB483B6FDC8F359F95BCE10F9B36286E12DE7F37932D5A")
FIXED=("MVT2GaussFixedHistoryASD20261117", "56F7D14B51F60071DD6FD936663CEBEB3850045C842EDF1A947A54DB7FE7B4FB")
REPORT_SHA="393EA5BED46723E5AA37544B6E8334D982ED15545D1E31F88D1A5716D506C463"
STRESSES_SHA="3CD17995A5AA1056787D26E3479EA55D2BF7EDB5B9A155D12DAB3EBD19121CA1"
WIRES=("Native/MVTGaussMixed.csv","Native/MVTGaussMixed.Tensor.csv","VerificationMVTGaussTensors.json","Verify-Tensors.py")


def digest(data):
    return sha256(data).hexdigest().upper()


def seal():
    names=set()
    for line in (HERE/"SHA256SUMS").read_text(encoding="ascii").splitlines():
        expected,name=line.split("  ",1)
        assert not PurePosixPath(name).is_absolute() and not name.lower().endswith(".xlsm")
        assert ".." not in PurePosixPath(name).parts and name not in names
        assert digest((HERE/name).read_bytes())==expected,name
        names.add(name)
    found={p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file() and p.name!="SHA256SUMS"}
    assert names==found


def read_archive(repo,reference):
    name,expected=reference
    path=repo/"docs/regression/Coupled6D"/(name+".zip")
    assert digest(path.read_bytes())==expected,name
    return ZipFile(path)


def unpack(root, repo):
    with read_archive(repo,CAPTURE) as archive:
        for name in WIRES:
            p=root/name
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(archive.read(name))
    with read_archive(repo,OPS) as archive:
        op_path=root/"Operators.csv"
        op_path.write_bytes(archive.read("Native/Operators.csv"))
    with read_archive(repo,FIXED) as archive:
        source=root/"Replay-History.py"
        source.write_bytes(archive.read("Replay-History.py"))
    return op_path,source


def signed_forces(values,geometry):
    assert all(len(s)==6 and all(map(isfinite,s)) for s in values)
    n=[w*s[2] for (x,y,w),s in zip(geometry,values,strict=True)]
    xz=[w*s[4] for (x,y,w),s in zip(geometry,values,strict=True)]
    yz=[w*s[5] for (x,y,w),s in zip(geometry,values,strict=True)]
    return (fsum(n),fsum(y*a for (x,y,w),a in zip(geometry,n,strict=True)),
            fsum(x*a for (x,y,w),a in zip(geometry,n,strict=True)),
            fsum(x*b-y*a for (x,y,w),a,b in zip(geometry,xz,yz,strict=True)),fsum(xz),fsum(yz))


def check(net,record,geom,dirs,area,length,op):
    field=record["field"]; n=60
    assert len(field)==n and len(net)==3 and all(len(x)==45 for x in net)
    torque,q=record["T_target_Nmm"],record["Q_target_N"]
    target=(0.,-330.*q,0.,torque,0.,q)
    loads=[fsum(l[j]*t for l,t in zip(op["L"],target,strict=True)) for j in range(n)]
    gradient=[[500.*(a-b) for a,b in zip(p,m,strict=True)] for p,m in zip(net[1],net[2],strict=True)]
    flat=lambda x:[e for p in x for e in p]
    center,derivative=flat(net[0]),flat(gradient)
    bt,rt=flat(op["S"]),flat(op["R"])
    result=[]
    for j in range(n):
        terms=[a*b for a,b in zip(op["G"][j],field,strict=True)]
        terms.extend(row[j]*s for row,s in zip(bt,center,strict=True))
        terms.extend(row[j]*s for row,s in zip(rt,derivative,strict=True))
        result.append(fsum(terms)-loads[j])
    weak=max(map(abs,result[:56]))
    gauge=30000.*max(map(abs,result[56:]))
    assert abs(weak-record["weak_norm_MPa"])<2e-12 and abs(gauge-record["gauge_scaled_norm_MPa"])<2e-12
    traction=signed_forces(net[0],geom)
    assert max(abs(a-b) for a,b in zip(traction,record["resultants_N_Nmm"],strict=True))<3e-8
    force=max(abs(a-b)/(area*(length if 1<=j<=3 else 1.)) for j,(a,b) in enumerate(zip(traction,target,strict=True)))
    tol=5e-7+5e-7*max(map(abs,loads))
    all_error=max(weak,gauge,force)
    assert abs(all_error-record["all_weak_and_force_max_MPa"])<2e-12 and all_error<=tol
    assert abs(record["twist_rad_per_m"]-1000*field[3]/length)<1e-17
    steel_use=0.
    for p in range(25,45):
        for side in (-1,0,1):
            strain=[fsum((a+side*.001*b)*v for a,b,v in zip(row,z,field,strict=True))
                    for row,z in zip(op["B"][p],op["Z"][p],strict=True)]
            sig=2e5*fsum(v*d for v,d in zip(strain,dirs[p],strict=True))
            steel_use=max(steel_use,abs(sig)/(498. if p<29 else 450.))
    assert steel_use<1.
    return all_error,steel_use


def verify(native, operators, source):
    program=runpy.run_path(str(HERE/"Reequilibrate.py"))
    shared,report,geom,dirs,area,length,op,seeds,observed,identity=program["read_inputs"](operators,native,source)
    proof_raw=(HERE/"Authoritative.json").read_bytes()
    stresses_raw=(HERE/"Authoritative.stress.json.gz").read_bytes()
    assert digest(proof_raw)==REPORT_SHA and digest(stresses_raw)==STRESSES_SHA
    proof=json.loads(proof_raw)
    stresses=json.loads(gzip.decompress(stresses_raw))
    assert proof["native_crosscheck"]==identity and proof["engine"]=="3.8.0" and proof["numpy"]=="2.3.5"
    assert set(stresses)==set(proof["modes"])=={"default","explicit"}
    result={}
    for mode,batch in proof["modes"].items():
        records=batch["accepted"]
        expected=26 if mode=="default" else 8
        assert len(records)==expected and batch["rejected_trial_interleaving_max_MPa"]==0.
        assert [record["phase"] for record in records]==[f["phase"] for f in report["frames"][:expected]]
        assert all(record["subdivision"]==0 for record in records)
        checked=[check(s,r,geom,dirs,area,length,op) for s,r in zip(stresses[mode],records,strict=True)]
        result[mode]={"fields":len(checked),"max_norm_MPa":max(x[0] for x in checked),
                      "maximum_elastic_steel_utilization_three_stations":max(x[1] for x in checked),
                      "confirmed_Qy_N":records[-1]["Q_target_N"]}
    assert proof["modes"]["explicit"]["terminal"]["reason"]=="bounded_numerical_stop"
    assert proof["modes"]["default"]["terminal"] is None and proof["no_physical_capacity"]
    return result


def main(repo,numpy,runtime):
    seal()
    with tempfile.TemporaryDirectory(prefix="MVTASDEquilibrium_") as tmp:
        root=Path(tmp)
        operators,source=unpack(root,repo)
        maxima=verify(root,operators,source)
        print("MVT2 ASD EQUILIBRIUM OFFLINE PASS",REPORT_SHA,STRESSES_SHA,maxima)
        if runtime:
            assert sys.version_info[:3]==(3,12,10)
            assert version("openseespy")==version("openseespywin")=="3.8.0.0"
            output=root/"repeat.json"
            stress=root/"repeat.stress.json.gz"
            subprocess.run([sys.executable,str(HERE/"Reequilibrate.py"),"--operators",str(operators),
                            "--native",str(root),"--fixed-source",str(source),"--numpy",str(numpy),
                            "--mode","both","--frames","26","--out",str(output),"--raw-out",str(stress)],
                           check=True)
            assert digest(output.read_bytes())==REPORT_SHA and digest(stress.read_bytes())==STRESSES_SHA
            print("MVT2 ASD EQUILIBRIUM OPENSEES EXACT PASS",REPORT_SHA,STRESSES_SHA)


if __name__=="__main__":
    p=ArgumentParser()
    p.add_argument("--repo",type=Path,default=Path.cwd())
    p.add_argument("--runtime",action="store_true")
    p.add_argument("--numpy",type=Path,default=Path("D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython"))
    a=p.parse_args()
    main(a.repo,a.numpy,a.runtime)
