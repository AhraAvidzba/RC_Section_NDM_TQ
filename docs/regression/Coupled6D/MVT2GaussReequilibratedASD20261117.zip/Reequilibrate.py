"""Cold ASD re-equilibration in the exact 60-equation local NDM section."""
from argparse import ArgumentParser
from hashlib import sha256
from itertools import product
from math import isfinite
from pathlib import Path
from time import perf_counter
import gzip
import json
import runpy
import sys

from Operators import make, check_native, field_from_tensors, H, E, D, P

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"mvt-fixed-history/Replay-History.py"
NUMPY=Path("D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython")
EPS=8e-10
MAX_ITER=14
BACKTRACKS=12
SUBDIVISIONS=5


def read_inputs(operators,native=None,fixed_source=BASE):
    shared=runpy.run_path(str(fixed_source))
    source=native if native is not None else shared["D"]/shared["NATIVE"]
    report,geo,dirs,steel,area,length,steel_error=shared["read_native"](source)
    numeric=make(geo,area,length)
    frames=report["frames"]
    decodes=[field_from_tensors(numeric,f["points"]) for f in frames]
    result={"center_tensor_decode_max_error":max(r[1] for r in decodes),
            "native_operators_checked":False}
    seeds={f["phase"]:r[0] for f,r in zip(frames,decodes,strict=True)}
    stresses=None
    if operators:
        seeds,checks,stresses,numeric=check_native(operators,numeric,report)
        result.update({"native_operators_checked":True,"native_export_SHA256":sha256(operators.read_bytes()).hexdigest().upper(),
                       "operator_column_max_absolute_errors":checks})
    return shared,report,geo,dirs,area,length,numeric,seeds,stresses,result


def test_discard(ops,command,replay,stages):
    """Interleave noncommitted excursions; compare identical clean history controls."""
    ops.wipe()
    ops.model("basic","-ndm",3,"-ndf",3)
    selected=(3,23,28,33)
    for tag in range(1,2*len(selected)+1):
        ops.nDMaterial(command[0],tag,*command[1:])
    err=0.
    for frame in stages:
        for j,p in enumerate(selected,1):
            strain=frame["points"][p-1][:6]
            reference=replay(j,strain)
            alter=tuple(x+y for x,y in zip(strain,(.00031,-.00021,.00013,-.00023,.00041,-.00052),strict=True))
            replay(len(selected)+j,alter)
            returned=replay(len(selected)+j,strain)
            err=max(err,*(abs(x-y) for x,y in zip(reference,returned,strict=True)))
            ops.NDTest("CommitState",j)
            ops.NDTest("CommitState",len(selected)+j)
    assert err == 0.,err
    ops.wipe()
    return err


def auditable_residual(np,center,grad,field,G,load,S,R):
    answer=G@field-load
    answer+=np.einsum("pir,pi->r",S,center)
    answer+=np.einsum("pir,pi->r",R,grad)
    return answer


class Section:
    """Three independent ASD states per quadrature point, including steel replacement."""
    def __init__(self,np,ops,command,geo,dirs,area,length,op,deadline):
        self.np=np
        self.ops=ops
        self.geo=np.array(geo)
        self.dirs=np.array(dirs)
        self.area=area
        self.length=length
        self.G=np.array(op["G"])
        self.L=np.array(op["L"])
        b=np.array(op["B"])
        z=np.array(op["Z"])
        self.strain=np.stack((b,b+H*z,b-H*z))
        self.project=np.stack((op["S"],np.array(op["R"])/(2*H),-np.array(op["R"])/(2*H)))
        self.original_S=np.array(op["S"])
        self.original_R=np.array(op["R"])
        self.scale=np.array([1.]*56+[E]*4)
        self.exact_force_scale=area*np.array([1.,length,length,length,1.,1.])
        self.deadline=deadline
        self.eval_count=0
        self.full_matrices=0
        self.committed=0
        self.accepted_stresses=[]
        self.steel_allow=np.array([498.]*4+[450.]*16)
        ops.wipe()
        ops.model("basic","-ndm",3,"-ndf",3)
        for tag in range(1,3*P+1):
            ops.nDMaterial(command[0],tag,*command[1:])

    def trial(self,tag,strain):
        ndt=self.ops.NDTest
        x,y,z,sxy,sxz,syz=strain
        wire=(x,y,z,sxy,syz,sxz)
        ndt("SetStrain",tag,*wire)
        check=ndt("GetStrain",tag)
        if tuple(check)!=wire:
            raise ValueError(f"ASD did not prescribe exact strain at material tag {tag}")
        xx,yy,zz,xy,yz,xz=ndt("GetStress",tag)
        if not all(map(isfinite,(xx,yy,zz,xy,yz,xz))):
            raise ArithmeticError(f"Nonfinite material response at tag {tag}")
        return xx,yy,zz,xy,xz,yz

    def components(self,field):
        np=self.np
        e=self.strain@field
        if np.max(np.abs(e))>.01:
            raise ArithmeticError("trial strain exceeds diagnostic numerical domain")
        axial=2e5*np.einsum("spi,pi->sp",e[:,25:,:],self.dirs[25:])
        if np.any(np.abs(axial)>=self.steel_allow):
            raise ArithmeticError("trial exceeds steel elastic range for this control")
        return e,axial

    def resultant(self,sigma):
        np=self.np
        x,y,w=self.geo.T
        zz=sigma[:,2];xz=sigma[:,4];yz=sigma[:,5]
        return np.array((w@zz,(y*w)@zz,(x*w)@zz,w@(x*yz-y*xz),w@xz,w@yz))

    def equations(self,field,demand,matrix=False):
        if perf_counter()>self.deadline:
            raise TimeoutError("bounded experiment time")
        np=self.np
        eps,steel=self.components(field)
        sigma=np.zeros((3,P,6))
        diff=np.zeros((3,P,6,6)) if matrix else None
        self.eval_count+=1
        if matrix:
            self.full_matrices+=1
        for side,point in product(range(3),range(P)):
            tag=1+side*P+point
            strain=eps[side,point]
            sign=1. if point<25 else -1.
            sigma[side,point]=sign*np.asarray(self.trial(tag,strain))
            if point>=25:
                sigma[side,point]+=steel[side,point-25]*self.dirs[point]
            if not matrix:
                continue
            step=EPS+1.e-5*np.max(np.abs(strain))
            for component in range(6):
                ep=strain.copy();em=strain.copy()
                ep[component]+=step;em[component]-=step
                diff[side,point,:,component]=sign*(np.asarray(self.trial(tag,ep))-np.asarray(self.trial(tag,em)))/(2*step)
            if point>=25:
                diff[side,point]+=2.e5*np.outer(self.dirs[point],self.dirs[point])
        load=demand@self.L
        residual=auditable_residual(np,sigma[0],(sigma[1]-sigma[2])/(2*H),field,self.G,load,
                                    self.original_S,self.original_R)
        forces=self.resultant(sigma[0])
        derivative=None
        if matrix:
            dfield=np.einsum("spik,spkq->spiq",diff,self.strain,optimize=True)
            derivative=self.G+np.einsum("spir,spiq->rq",self.project,dfield,optimize=True)
        force_norm=float(np.max(np.abs(forces-demand)/self.exact_force_scale))
        eqnorm=float(np.max(np.abs(residual*self.scale)))
        tolerance=5e-7+5e-7*float(np.max(np.abs(load[:56])))
        return residual,derivative,sigma,forces,max(eqnorm,force_norm),tolerance

    def commit(self):
        for tag in range(1,3*P+1): self.ops.NDTest("CommitState",tag)
        self.committed+=1


def commands(shared,report,modes):
    e,v,fc,ft=report["model"][:4]
    stocks={"default":["ASDConcrete3D",e,v,"-fc",fc,"-ft",ft,"-tangent"]}
    if "explicit" in modes:
        tables,error=shared["exact_tables"](report)
        explicit=["ASDConcrete3D",e,v]
        for prefix,rows in zip("TC",tables.values(),strict=True):
            for j,kind in enumerate("esd"):
                explicit.extend([f"-{prefix}{kind}",*(r[j] for r in rows)])
        stocks["explicit"]=explicit+["-tangent"]
    return stocks


def loads(np,t,q):
    return np.array((0,-330.*q,0,t,0,q))


def merit(np,rr):
    return float(np.linalg.norm(np.r_[rr[0],rr[4]]))


def q_record(section,field,t,q,confirmed,status,it,resids):
    r,_,stress,actual,error,tol=confirmed
    return {"T_target_Nmm":t,"Q_target_N":q,"twist_rad_per_m":1000.*float(field[3])/section.length,
            "resultants_N_Nmm":actual.tolist(),"weak_norm_MPa":float(max(abs(x) for x in r[:56])),
            "gauge_scaled_norm_MPa":float(max(abs(x)*E for x in r[56:])),
            "all_weak_and_force_max_MPa":error,"tolerance_MPa":tol,"status":status,"newton_iterations":it,
            "accepted_residual_sequence_MPa":resids,"field":field.tolist()}


def try_correct(section,start,t,q):
    np=section.np
    target=loads(np,t,q)
    field=start.copy()
    residuals=[]
    current=None
    for iteration in range(MAX_ITER+1):
        try:
            current=section.equations(field,target,False)
        except ArithmeticError as error:
            return None,{"kind":"invalid_predictor","detail":str(error)}
        zero=merit(np,current)
        residuals.append(current[4])
        if current[4]<=current[5]:
            # Re-evaluate exactly after any tangent/line probes, leaving all 135 trial buffers at this field.
            repeated=section.equations(field,target,False)
            assert np.array_equal(current[2],repeated[2])
            section.accepted_stresses.append(repeated[2].tolist())
            section.commit()
            return field,q_record(section,field,t,q,repeated,"balanced",iteration,residuals)
        if iteration==MAX_ITER:
            break
        assembled=section.equations(field,target,True)
        try:
            step=np.linalg.solve(assembled[1]*section.scale[:,None],-current[0]*section.scale)
        except np.linalg.LinAlgError:
            return None,{"kind":"singular_tangent","weak_or_forces_norm_MPa":current[4],"newton_iterations":iteration}
        for i in range(BACKTRACKS):
            trial=field+(0.5**i)*step
            try:
                candidate=section.equations(trial,target,False)
            except ArithmeticError:
                continue
            if candidate[4]<=candidate[5] or merit(np,candidate)<zero:
                field=trial
                break
        else:
            return None,{"kind":"line_search_no_decrease","weak_or_forces_norm_MPa":current[4],"newton_iterations":iteration}
    return None,{"kind":"maximum_iterations","weak_or_forces_norm_MPa":current[4],"newton_iterations":MAX_ITER}


def native_witness(np,stresses,seeds,geo,area,length,op,frames):
    if not stresses:
        return {}
    s=np.array(op["S"]);r=np.array(op["R"]);g=np.array(op["G"]);l=np.array(op["L"])
    a=np.array(geo)
    findings={}
    for phase in sorted({k[0] for k in stresses}):
        f=next(f for f in frames if f["phase"]==phase)
        field=np.asarray(seeds[phase])
        q,t=f["Qy_N"],f["T_Nmm"]
        data=np.array([[stresses[phase,str(side),str(p)] for p in range(1,P+1)] for side in (0,1,-1)])
        residual=auditable_residual(np,data[0],(data[1]-data[2])/(2*H),field,g,loads(np,t,q)@l,s,r)
        value=float(np.max(np.abs(residual[:56])))
        tol=5e-7+5e-7*float(np.max(np.abs(loads(np,t,q)@l)))
        assert value<=tol+5e-12,(phase,value,tol)
        findings[phase]={"native_weak_norm_MPa":value,"native_gauge_norm":float(np.max(np.abs(residual[56:]))),"tolerance_MPa":tol}
    return findings


def simulate(np,ops,shared,report,geo,dirs,area,length,op,seeds,mode,command,deadline,requested):
    def bare_trial(tag,strain):
        swapped=shared["voigt"](strain)
        ops.NDTest("SetStrain",tag,*swapped)
        assert tuple(ops.NDTest("GetStrain",tag))==swapped
        return shared["voigt"](ops.NDTest("GetStress",tag))
    rejected_equiv=test_discard(ops,command,bare_trial,report["frames"])
    section=Section(np,ops,command,geo,dirs,area,length,op,deadline)
    accepted=[]; attempts=[]
    last=(0.,0.)
    field=np.zeros(D)
    targets=report["frames"][:requested]

    def advance(t,q,label,depth):
        nonlocal field,last
        key=0 if q == 0 else 1
        target_var=(t,q)[key]
        start=field
        if len(accepted)>1:
            prev=accepted[-2]
            new=accepted[-1]
            var=("T_target_Nmm","Q_target_N")[key]
            width=new[var]-prev[var]
            if width>0.:
                factor=(target_var-new[var])/width
                if abs(factor)<4.:
                    start=field+factor*(field-np.array(prev["field"]))
        value,diagnostic=try_correct(section,start,t,q)
        attempts.append({"target_phase":label,"T_Nmm":t,"Q_N":q,
                         "depth":depth,"from_commits":section.committed-(1 if value is not None else 0),
                         **({k:v for k,v in diagnostic.items() if k!="field"})})
        if value is not None:
            field=value
            last=(t,q)
            accepted.append({**diagnostic,"phase":label,"subdivision":depth})
            return True
        if depth>=SUBDIVISIONS:
            return False
        mt,mq=(last[0]+t)/2.,(last[1]+q)/2.
        return advance(mt,mq,label+"a",depth+1) and advance(t,q,label,depth+1)

    # Use distinct compressive principal strains for a differentiable virgin probe.
    # The zero-crossing split is tested within the actual nonlinear residuals.
    test=np.zeros(D);test[0]=-4e-5;test[3]=2.5e-6
    axis=(-120.,-40.,40.,120.)
    for iy,ix in product(range(4),range(4)):
        degree=4+3*(iy*4+ix)
        test[degree]=-2e-5*axis[ix]/length
        test[degree+1]=-3e-5*axis[iy]/length
    zeros=loads(np,0.,0.)
    a=section.equations(test,zeros,True)
    direction=np.array([((j*17)%31-15)/15. for j in range(D)])
    plus=section.equations(test+1e-9*direction,zeros,False)[0]
    minus=section.equations(test-1e-9*direction,zeros,False)[0]
    finite=(plus-minus)/(2e-9)
    err=float(np.max(np.abs(finite-a[1]@direction)))/max(float(np.max(np.abs(finite))),1.)
    assert err<1e-4,err
    terminal=None
    for f in targets:
        t,q=f["T_Nmm"],f["Qy_N"]
        if not advance(t,q,f["phase"],0):
            terminal={"phase":f["phase"],"T_requested_Nmm":t,"Q_requested_N":q,
                      "last_reached_T_Nmm":last[0],"last_reached_Q_N":last[1],
                      "reason":"bounded_numerical_stop"}
            break
    count=section.eval_count
    matrices=section.full_matrices
    ops.wipe()
    summary={"status":"complete" if terminal is None else "numerical_stop","last_confirmed":last,
            "complete_nominal_targets":terminal is None,"physical_limit_established":False,
            "accepted":accepted,"attempts":attempts,"terminal":terminal,
            "equilibrium_evaluations":count,"numerical_tangent_builds":matrices,
            "rejected_trial_interleaving_max_MPa":rejected_equiv,"elastic_directional_jacobian_relative_error":err}
    return summary,section.accepted_stresses


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument("--operators",type=Path)
    cli.add_argument("--native",type=Path)
    cli.add_argument("--fixed-source",type=Path,default=BASE)
    cli.add_argument("--out",type=Path,default=HERE/"Equilibrium.json")
    cli.add_argument("--raw-out",type=Path)
    cli.add_argument("--inputs-only",action="store_true")
    cli.add_argument("--numpy",type=Path,default=NUMPY)
    cli.add_argument("--mode",choices=("default","explicit","both"),default="both")
    cli.add_argument("--frames",type=int,choices=(8,9,26),default=9)
    cli.add_argument("--seconds",type=int,default=115)
    args=cli.parse_args()
    shared,r,geo,dirs,area,length,op,seeds,stresses,proof=read_inputs(args.operators,args.native,args.fixed_source)
    if args.inputs_only:
        print(json.dumps(proof,indent=2))
        return
    sys.path.insert(0,str(args.numpy))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0"
    modes=("default","explicit") if args.mode=="both" else (args.mode,)
    building=commands(shared,r,modes)
    result={};raw={}
    limited_from=perf_counter()+args.seconds
    cert=native_witness(np,stresses,seeds,geo,area,length,op,r["frames"])
    for mode in modes:
        print("START",mode,flush=True)
        try:
            result[mode],raw[mode]=simulate(np,ops,shared,r,geo,dirs,area,length,op,seeds,mode,building[mode],limited_from,args.frames)
        finally:
            ops.wipe()
        print("FINISH",mode,result[mode]["last_confirmed"],result[mode]["equilibrium_evaluations"],flush=True)
    payload={"status":"PASS","engine":ops.version(),"numpy":np.__version__,"capture":shared["INPUTS"],
             "native_crosscheck":proof,"genuine_native_stress_weak_equilibrium":cert,
             "original_target_case_count":args.frames,"modes":result,"no_physical_capacity":True,
             "incremental_numerical_options":{"max_iterations":MAX_ITER,"backtracks":BACKTRACKS,
                                               "max_halvings":SUBDIVISIONS,"minimum_material_difference_strain":EPS}}
    data=(json.dumps(payload,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with args.out.open("xb") as file:
        file.write(data)
    print(sha256(data).hexdigest().upper())
    if args.raw_out:
        compressed=gzip.compress(json.dumps(raw,separators=(",",":"),allow_nan=False).encode(),mtime=0,compresslevel=9)
        with args.raw_out.open("xb") as file:
            file.write(compressed)
        print("RAW",sha256(compressed).hexdigest().upper())


if __name__ == "__main__":
    main()
