"""Independent cubic Bernstein operators for the one-span native MVT2 section."""
from math import fsum, isfinite

D = 60
P = 45
H = .001
E = 30000.


def zero(n,m):
    return [[0.]*m for _ in range(n)]


def dot(a,b):
    return fsum(x*y for x,y in zip(a,b,strict=True))


def pivot_solve(a,b):
    """Small nonsymmetric solve with partial row pivoting."""
    n=len(b)
    rows=[r.copy()+[rhs] for r,rhs in zip(a,b,strict=True)]
    for i in range(n):
        pivot=max(range(i,n),key=lambda j:abs(rows[j][i]))
        rows[pivot],rows[i]=rows[i],rows[pivot]
        here=rows[i]
        if abs(here[i])<1e-13:
            raise ArithmeticError(f"Singular equation pivot {i+1}")
        for j in range(i+1,n):
            other=rows[j]
            if other[i]:
                value=other[i]/here[i]
                for k in range(i+1,n+1):
                    other[k]-=value*here[k]
    x=[0.]*n
    for i in range(n-1,-1,-1):
        x[i]=(rows[i][-1]-fsum(rows[i][j]*x[j] for j in range(i+1,n)))/rows[i][i]
    if not all(map(isfinite,x)):
        raise ArithmeticError("Nonfinite solution")
    return x


def bernstein(x,length):
    t=(x+120.)/240.
    z=1.-t
    factor=3.*length/240.
    return ((z**3,3.*t*z*z,3.*t*t*z,t**3),
            tuple(factor*v for v in (-z*z,z*z-2.*t*z,2.*t*z-t*t,t*t)))


def make(geom,area,length):
    G=zero(D,D)
    L=zero(6,D)
    for column,row in enumerate((0,1,2,3,54,53)):
        L[column][row]=1./(area*(length if 1<=column<=3 else 1.))
    B,Z,S,R=[],[],[],[]
    for j,(x,y,w) in enumerate(geom):
        b=zero(6,D); z=zero(6,D); r=zero(6,D)
        weight=w/area
        xx,yy=x/length,y/length
        b[2][0:3]=1.,yy,xx
        b[4][3],b[5][3]=-yy,xx
        for k in range(6):
            for dof in range(4):
                z[k][52+dof]=b[k][dof]
                r[k][52+dof]=weight*b[k][dof]
        px,dx=bernstein(x,length)
        py,dy=bernstein(y,length)
        for iy in range(4):
            for ix in range(4):
                u=4+3*(iy*4+ix);v=u+1;warp=u+2
                phi=px[ix]*py[iy]
                gx,gy=dx[ix]*py[iy],px[ix]*dy[iy]
                b[0][u],b[3][u]=gx,gy
                b[1][v],b[3][v]=gy,gx
                b[4][warp],b[5][warp]=gx,gy
                r[4][u]=r[5][v]=r[2][warp]=-weight*phi
                if j<25:
                    value=weight*phi
                    for dof,gauge in ((u,56),(v,57),(warp,58)):
                        G[dof][gauge]+=value
                        G[gauge][dof]+=value
                    G[u][59]-=yy*value;G[59][u]-=yy*value
                    G[v][59]+=xx*value;G[59][v]+=xx*value
        B.append(b);Z.append(z)
        S.append([[weight*t for t in row] for row in b]);R.append(r)
    return {"G":G,"L":L,"B":B,"Z":Z,"S":S,"R":R}


def field_from_tensors(op, measurements):
    """Recover only center coefficients, eliminating rigid gauges exactly."""
    gram=zero(56,56)
    rhs=[0.]*56
    for p,stress in enumerate(measurements):
        for row,v in zip(op["B"][p],stress[:6],strict=True):
            sparse=[(j,a) for j,a in enumerate(row[:52]) if a]
            for j,a in sparse:
                rhs[j]+=a*v
                for k,b in sparse:
                    gram[j][k]+=a*b
    for j in range(52):
        for k in range(4):
            val=op["G"][j][56+k]
            gram[j][52+k]=gram[52+k][j]=val
    decoded=pivot_solve(gram,rhs)[:52]+[0.]*8
    error=max(abs(dot(row,decoded)-v) for b,target in zip(op["B"],measurements,strict=True)
              for row,v in zip(b,target[:6],strict=True))
    assert error<1e-14
    return decoded,error


def check_native(path, op, native):
    """Reconcile every operator column, plus captured field strains and bounds."""
    buckets={tag:{} for tag in ("G","L","B","S","R","F","H")}
    data=path.read_text(encoding="utf-8-sig").splitlines()
    if data[0].startswith("SIZE;"):
        _,d,p,h=data.pop(0).split(";")
        assert (int(d),int(p),float(h)) == (D,P,H)
    else:
        raise AssertionError(f"Unknown operator header {data[0]}")
    counts={"G":1,"L":1,"B":2,"S":2,"R":2,"F":1,"H":3}
    for row in data:
        kind,*values=row.split(";")
        if kind not in counts:
            raise AssertionError(f"Unknown native wire record {kind}")
        n=counts[kind]
        key=tuple(values[:n])
        assert key not in buckets[kind]
        val=tuple(map(float,values[n:]))
        assert all(map(isfinite,val))
        buckets[kind][key]=val
    expected_counts={"G":D,"L":6,"B":P*D,"S":P*6,"R":P*6,"F":len(native["frames"])}
    for name,count in expected_counts.items():
        assert len(buckets[name])==count,(name,count,len(buckets[name]))
    errors={}
    def assess(tag, child_key, expected):
        raw=buckets[tag][tuple(map(str,child_key))]
        err=max(abs(a-b) for a,b in zip(raw,expected,strict=True))
        errors[tag]=max(err,errors.get(tag,0.))
    for j in range(D):
        assess("G",(j+1,),[row[j] for row in op["G"]])
    for k in range(6):
        assess("L",(k+1,),op["L"][k])
    for p in range(P):
        for j in range(D):
            assess("B",(p+1,j+1),[r[j] for r in op["B"][p]]+[r[j] for r in op["Z"][p]])
        for k in range(6):
            for tag in ("S","R"):
                assess(tag,(p+1,k+1),op[tag][p][k])
    assert max(errors.values())<5e-13,errors
    frames={phase[0]:v for phase,v in buckets["F"].items()}
    errors["F_center"]=max(abs(dot(row,frames[f["phase"]])-v) for f in native["frames"]
        for b,point in zip(op["B"],f["points"],strict=True) for row,v in zip(b,point[:6],strict=True))
    assert errors["F_center"]<1e-14
    canonical={
        "G":[[buckets["G"][(str(j+1),)][i] for j in range(D)] for i in range(D)],
        "L":[list(buckets["L"][(str(k+1),)]) for k in range(6)],
        "B":[[[buckets["B"][(str(p+1),str(j+1))][k] for j in range(D)] for k in range(6)] for p in range(P)],
        "Z":[[[buckets["B"][(str(p+1),str(j+1))][6+k] for j in range(D)] for k in range(6)] for p in range(P)],
    }
    for tag in ("S","R"):
        canonical[tag]=[[list(buckets[tag][(str(p+1),str(k+1))]) for k in range(6)] for p in range(P)]
    return frames,errors,buckets["H"],canonical
