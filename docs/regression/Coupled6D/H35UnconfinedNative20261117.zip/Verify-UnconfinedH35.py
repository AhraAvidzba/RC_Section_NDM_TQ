"""Сопоставляет одноосный нативный расчёт H35 с экспериментом и скалярным решением."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from statistics import fmean
from zipfile import ZipFile

from H35ScalarOracle import curve


MATERIAL = 'MVT2NativePublicationCutMaterialHistory20261117.zip'
MATERIAL_SHA = '6920EB24A5D01585E510FDBC1064513C0C83AA62583AEB0C2553D6F0D495EE55'
SWEEP = 'MVT2NativePublicationCutDilationSweep20261117.zip'
SWEEP_SHA = '6D10C25C82A02D9C6A25BB568D08C84E3CA808B2D9CF96D9757D47E1928B6355'
THESIS = 'literature/Coupled6D/Osorio-Bustamante-2012-H45-Thesis.pdf'
THESIS_SHA = '07153AC566681CB55797DCA3D0CDC7206FEE4122FC9FA20BA9D8DA52ABA7C18D'
CLASS = 'src/Materials/CCoupledConcreteResponse.cls'
PATHS = ('A20','A26','A32','A40','F32','L32','G32')
STRESS_TOL = 1e-7


def digest(raw):
    return sha256(raw).hexdigest().upper()


def archive(directory, filename, fingerprint):
    path = directory / filename
    assert digest(path.read_bytes()) == fingerprint
    return ZipFile(path)


def measurements(root, repo):
    """Читает контрольные точки и повторяет их оцифровку при наличии исходного PDF."""
    data = json.loads((root / 'H35Targets.json').read_bytes())
    assert data['source_sha256'] == THESIS_SHA and data['specimen'] == 'H35_01'
    if (repo / THESIS).is_file():
        from importlib import util
        spec = util.spec_from_file_location('digitize_h35', root / 'Digitize-OsorioH35.py')
        tool = util.module_from_spec(spec)
        spec.loader.exec_module(tool)
        observed = tool.digitize(repo)
        assert observed == data
    comparison = data['checkpoints']
    assert 36.23 < data['approximate_peak_MPa'] < 36.25
    assert .00166 < data['approximate_peak_axial_compression'] < .00167
    assert max(abs(p['lateral_expansion']-p['lateral_at_stress_from_figure_4_1']) for p in comparison) < 1e-5
    return data


def check_strict_run(root, utility):
    """Подтверждает достигнутую скобку и закрытие первого изолированного процесса."""
    directory = root / 'Strict'
    result = (directory / 'MVTGaussMixed.txt').read_text('utf-8-sig')
    owner = utility['read'](directory / 'MVTGaussMixed.txt.Ownership.json')
    closure = utility['read'](directory / 'MVTGaussMixed.txt.ProcessClosure.json')
    assert owner['VerifiedNewOwner'] and closure['Passed'] and closure['ChildExitCode'] == 1
    assert closure['Closure']['Identity']['PID'] == owner['PID']
    assert int(owner['StartTicksUTC']) == closure['Closure']['Identity']['Ticks']
    assert closure['Closure']['FinalState']['State'] == 'Absent'
    assert 'путь A20, шаг 142.' in result
    phrase = 'Ширина скобки '
    line, = [row for row in result.splitlines() if phrase in row]
    width, remainder = line.split(phrase)[1].split(', невязки ')
    terms = remainder.removesuffix(' МПа.').split(' и ')
    low, high = map(float, terms)
    assert float(width) < 3e-20 and low < -1e-8 < 1e-8 < high < STRESS_TOL
    return {'lower_MPa':low,'upper_MPa':high,'width_strain':float(width), 'excel_closed_pid':owner['PID']}


def parameters(model, key, experiment):
    """Сверяет только заранее заданные параметры расчёта H35."""
    a, e, nu, length, step, fc, peak, ft, gt, gc = model
    assert a == (int(key[1:]))
    expected_stiffness = (34820.8,.23) if key == 'G32' else (35195.,.3)
    assert (e,nu) == expected_stiffness
    assert abs(length - (175. if key == 'L32' else 116.24473515096261)) < 2e-10
    assert step == (2.5e-6 if key == 'F32' else 5e-6)
    assert abs(fc-experiment['approximate_peak_MPa']) < .01
    assert abs(peak-experiment['approximate_peak_axial_compression']) < 1e-6
    assert abs(ft-.302 * fc**(2./3.)) < 1e-12 and abs(gt-.073 * fc**.18) < 1e-12
    assert abs(gc-(fc/ft)**2*gt) < 1e-11


def compare(values, model, experiment, elastic, utility):
    """Проверяет боковые реакции и интеграцию трёхмерного закона на каждом шаге."""
    _, e, nu, _, step, *_ = model
    theoretical = curve(model)
    assert len(values) == len(theoretical)-1
    residual, e_axial, e_lateral, recon = 0., 0., 0., 0.
    axial_volume = [(0.,0.)]
    fixed = {}
    plastic_expansion = None
    for i, data in enumerate(values, 1):
        ex, ey, ez, *shear_strain = data[:6]
        sx, sy, sz, *shear_stress = data[6:12]
        xp, yp, zp, *shear_plastic = data[12:18]
        assert abs(-ez-i*step) < 5e-15 and ex == ey and abs(xp-yp) < 5e-15
        assert shear_strain == shear_stress == shear_plastic == [0.,0.,0.]
        assert max(abs(sx),abs(sy)) <= STRESS_TOL and sz < 0.
        principal = utility['principal'](elastic(tuple(a-b for a,b in zip(data[:6],data[12:18],strict=True)),e,nu))
        fraction = sum(x for x in principal if x > 0.)/sum(map(abs, principal))
        r = (1.-fraction*data[-4])*(1.-data[-3])
        effective = elastic((ex-xp,ey-yp,ez-zp,0.,0.,0.),e,nu)
        error = max(abs(a-b*r) for a,b in zip(data[6:12],effective,strict=True))
        recon = max(recon,error)
        if plastic_expansion is None and xp+yp+zp > 1e-8:
            plastic_expansion = {'axial_compression':-ez, 'compression_energy_fraction':data[-1]}
        residual = max(residual,abs(sx),abs(sy))
        e_axial = max(e_axial,abs(-sz-theoretical[i][1]))
        e_lateral = max(e_lateral,abs(ex-theoretical[i][2]))
        axial_volume.append((-ez, ex+ey+ez))
        fixed[i] = (ex,-sz,ex+ey+ez)
    assert recon < 1e-10 and e_axial < 1e-5 and e_lateral < 1e-9
    checkpoints = []
    for point in experiment['checkpoints']:
        j = round(point['axial_compression']/step)
        assert abs(point['axial_compression']-j*step) < 5e-15
        lateral, nominal, volume = fixed[j]
        checkpoints.append(point | {'NDM_stress_MPa':nominal,'NDM_lateral':lateral,'NDM_volume':volume})
    crossing = None
    for a,b in zip(axial_volume[1:],axial_volume[2:]):
        if a[1] < 0. <= b[1]:
            crossing = a[0]+(b[0]-a[0])*(-a[1])/(b[1]-a[1])
            break
    return {'max_lateral_residual_MPa':residual,'max_oracle_axial_error_MPa':e_axial,
            'max_oracle_lateral_error':e_lateral,'max_nominal_reconstruction_error_MPa':recon,
            'zero_volume_axial':crossing,'detectable_plastic_expansion':plastic_expansion,'checkpoints':checkpoints,
            'lateral_RMS':fmean((p['NDM_lateral']-p['lateral_expansion'])**2 for p in checkpoints)**.5,
            'axial_RMS_MPa':fmean((p['NDM_stress_MPa']-p['compressive_stress_MPa'])**2 for p in checkpoints)**.5}


def verify(repo, root):
    evidence = repo / 'docs/regression/Coupled6D'
    utility, sweep = {'__name__':'__pinned__'}, {'__name__':'__pinned__'}
    with archive(evidence,MATERIAL,MATERIAL_SHA) as source:
        exec(compile(source.read('Verify-NativeMaterialHistory.py'),MATERIAL,'exec'),utility)
        assert source.read(CLASS) == (root/CLASS).read_bytes()
    with archive(evidence,SWEEP,SWEEP_SHA) as source:
        exec(compile(source.read('Verify-DilationSweep.py'),SWEEP,'exec'),sweep)
    native = root / 'Native'
    pid, log = sweep['check_process'](root,utility['BOOK'],utility)
    prep = utility['read'](root/'Preparation.json')
    assert prep['specimen'] == 'H35_01' and prep['source_book_sha256'] == utility['BOOK']
    for name in (CLASS,'Run-Native.ps1','tests/modTestMVT2GaussSpan.bas'):
        assert digest((root/name).read_bytes()) == prep['inputs'][name]
    strict = check_strict_run(root,utility)
    experiment = measurements(root,repo)
    models, records = {}, {}
    for line in (native/'UnconfinedH35.csv').read_text('ascii').splitlines():
        kind,path,*values = line.split(';')
        if kind == 'MODEL':
            assert path not in models and len(values) == 10
            models[path] = tuple(map(float,values))
            records[path] = []
        else:
            assert kind == 'STEP' and len(values) == 27 and int(values[0]) == len(records[path])+1
            records[path].append(tuple(map(float,values[1:])))
    assert tuple(models) == PATHS
    def elastic(strain, e, nu):
        mu, lam = e/(2.*(1.+nu)), e*nu/((1.+nu)*(1.-2.*nu))
        trace = sum(strain[:3])
        return (*[2.*mu*x+lam*trace for x in strain[:3]],*[mu*x for x in strain[3:]])
    comparisons = {}
    passed_states = 0
    for path in PATHS:
        parameters(models[path],path,experiment)
        assert f'H35_FREE_LATERAL;{path};{len(records[path])}' in log
        comparisons[path] = compare(records[path],models[path],experiment,elastic,utility)
        passed_states += len(records[path])
    assert passed_states == 4400
    comp = comparisons['A32']['checkpoints']
    fine = comparisons['F32']['checkpoints']
    difference = max(abs(p['NDM_lateral']-q['NDM_lateral']) for p,q in zip(comp,fine,strict=True))
    assert difference < 2e-7
    assert comp[-1]['NDM_volume'] < 0. < comp[-1]['volume_expansion']
    a,b = experiment['checkpoints'][8:10]
    assert a['volume_expansion'] < 0. < b['volume_expansion']
    experimental_crossing = a['axial_compression'] + (b['axial_compression']-a['axial_compression'])*(
        -a['volume_expansion']/(b['volume_expansion']-a['volume_expansion']))
    return {'comparisons':comparisons,'checked_states':passed_states,'strict_run':strict,'excel_closed_pid':pid,
            'approximate_experimental_zero_volume_axial':experimental_crossing, 'fine_step_lateral_difference':difference,
            'experimental_source_sha256':THESIS_SHA}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',required=True,type=Path)
    args = parser.parse_args()
    result = verify(args.repo.resolve(),args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(result,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('OSORIO H35 OFFLINE PASS',result['checked_states'])
