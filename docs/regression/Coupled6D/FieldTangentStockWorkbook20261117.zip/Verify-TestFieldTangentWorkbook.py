"""ДЛЯ ТЕСТОВ: проверяет контрольный пакет, штатный HardShear и цену резервной касательной."""

from argparse import ArgumentParser
from copy import copy
from hashlib import sha256
from io import BytesIO
import json
from math import isclose
from pathlib import Path
import re
from runpy import run_path
from subprocess import check_output
from zipfile import ZipFile,ZIP_DEFLATED


BASE=('HardShearCoarseGrowthWorkbookRelease20261117.zip','6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63')
STOCK=('HardShearIntegratedSteelWorkbook20261117.zip','5E28B5A6CB9F49855708E91249A3370403A93461E325CDAEE41BB0520A63F9E1')
CORE=('MVT2TorqueRecoveryAndFieldTangent20261117.zip','96CD6F7A847AC8937657E12D9E719EF59ABE72108FB999144C7F0255282ABBDF')
BOOK='workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA='E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
DUMP_SHA='DB8023F9384B0059E1D1C51D59FE0E62F9B8CD94AC4D9B329DD0EE810AF676CC'
REV='826221bfde2fef1e690c65745c0169ef4a342161'
CLASS='src/Solver/CCoupledNewtonSolver.cls'


def TestDigest(raw):
    """Возвращает SHA-256 проверяемых байтов."""
    return sha256(raw).hexdigest().upper()


def TestRead(root,name):
    """Читает квитанции Python и PowerShell, включая UTF-8 BOM."""
    return json.loads((root/name).read_text('utf-8-sig'))


def TestArchive(repo,entry):
    """Открывает архив с точным источником исходников или прежнего результата."""
    file=repo/'docs/regression/Coupled6D'/entry[0]
    assert TestDigest(file.read_bytes())==entry[1]
    return ZipFile(file)


def TestCapture(root):
    """Сохраняет технические части закрытой тестовой книги в рабочем каталоге доказательств."""
    report=(root/'Native/Both.txt').read_text('utf-8-sig')
    filename,=re.findall(r'^RESULTS_SAVE_REOPEN:[^\n]*; file=(.+)$',report,re.M)
    fixture,=re.findall(r'^FIXTURE: (.+)$',report,re.M)
    saved=Path(filename).resolve();folder=Path(fixture).resolve().parent
    assert saved.parent==folder and saved.name=='RC_Section_NDM_saved.xlsm'
    assert folder.name.startswith('RC_NDM_ModeSuite_')
    reader=run_path(str(root/'ReadWorkbookCurve.py'))['read_curve']
    values=reader(saved)
    names=['xl/workbook.xml','xl/_rels/workbook.xml.rels','xl/sharedStrings.xml',values['worksheet']]
    with ZipFile(saved) as source,ZipFile(root/'Native/SavedResultsParts.zip','x',ZIP_DEFLATED,compresslevel=9) as out:
        for name in names:out.writestr(name,source.read(name))
    proof={k:values[k] for k in ('worksheet','worksheet_sha256','saved_workbook_sha256','named_anchor')}
    (root/'Native/SavedResultsProvenance.json').write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())


def TestVerify(repo,root):
    """Подтверждает код и результаты; отсутствие выигрыша и незакрытый предел остаются явными."""
    prep=TestRead(root,'Preparation.json');package=TestRead(root,'Package.json')
    assert prep['baseline_book_sha256']==BOOK_SHA and prep['baseline_dump_sha256']==DUMP_SHA
    assert prep['classes']==[CLASS] and prep['core_evidence']==CORE[1]
    for file in (*prep['classes'],'Stage-TestFieldTangentWorkbook.py','Run-TestFieldTangentWorkbook.ps1'):
        assert TestDigest((root/file).read_bytes())==prep['inputs'][file]
    assert package['unchanged_ooxml_parts']==121 and package['unchanged_modules']==225
    assert package['changed_modules']==['CCoupledNewtonSolver']
    compiler=TestRead(root,'CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and set(compiler['Modules'])=={'CCoupledNewtonSolver'}
    assert compiler['ProductionSHA256']==BOOK_SHA and compiler['WorkbookSHA256']==package['compiled_sha256']
    for name in ('CompileClosure.json','ExportClosure.json'):assert TestRead(root,name)['State']=='Absent'
    with TestArchive(repo,CORE) as z:assert (root/CLASS).read_bytes()==z.read('Field/'+CLASS)
    stock=(repo/BOOK).read_bytes()
    if TestDigest(stock)!=BOOK_SHA:stock=check_output(['git','cat-file','blob',f'{REV}:{BOOK}'],cwd=repo)
    assert TestDigest(stock)==BOOK_SHA
    packet=BytesIO()
    with ZipFile(BytesIO(stock)) as old,ZipFile(packet,'w') as new:
        new.comment=old.comment
        for item in old.infolist():new.writestr(copy(item),(root/'CandidateVBA.bin').read_bytes() if item.filename=='xl/vbaProject.bin' else old.read(item))
    assert TestDigest(packet.getvalue())==package['candidate_sha256']
    with ZipFile(packet) as new:assert {name:TestDigest(new.read(name)) for name in new.namelist()}==package['parts']
    with TestArchive(repo,BASE) as z:
        helper={'__name__':'__pinned__','__file__':'Stage-Release.py'}
        exec(compile(z.read('Stage-Release.py'),'Stage-Release.py','exec'),helper)
    assert TestDigest((root/'Stock.VBA_All_Code.txt').read_bytes())==DUMP_SHA
    before=helper['components']((root/'Stock.VBA_All_Code.txt').read_bytes())
    after=helper['components']((root/'VBA_All_Code.txt').read_bytes())
    assert set(before)==set(after) and len(after)==226
    assert [name for name in before if before[name]!=after[name]]==['CCoupledNewtonSolver']
    observer,sources=helper['parse_vba'](repo)
    _,embedded=sources(BytesIO(packet.getvalue()))
    _,old_embedded=sources(BytesIO(stock))
    fold=observer['literal_safe_fold'];body=observer['compiler_body']
    assert [n for n in embedded if fold(embedded[n])!=fold(old_embedded[n])]==['CCoupledNewtonSolver']
    source=body((root/CLASS).read_text('utf-8-sig'),'CCoupledNewtonSolver')[0]
    assert source==body(embedded['CCoupledNewtonSolver'],'CCoupledNewtonSolver')[0]
    actual='Option Explicit\n'+'\n'.join(after['CCoupledNewtonSolver'][1][1:])
    assert source==body(actual,'CCoupledNewtonSolver')[0]
    export=(root/'Export.log').read_text('utf-8-sig')
    assert f"VBA_READ_ONLY_EXPORT: components=226; sourceSHA256={package['candidate_sha256']}; sourceUnchanged=True;" in export
    for directory in (root,root/'Stock'):
        for row in (directory/'Run.ndjson').read_text('utf-8-sig').splitlines():
            memory=json.loads(row)
            assert memory['ramMiB']>=6500 and memory['freeCommitGiB']>=6 and all(p['ProtectedUser'] for p in memory['excel'])
    reg=(root/'Stock/Native/SteelCoreRegressions.txt').read_text('utf-8-sig')
    totals=re.findall(r'^TOTAL_([^:]+): passed=(\d+); failed=0$',reg,re.M)
    expected=[19,23,10,39,32,228,4,10]
    assert [int(v) for _,v in totals]==expected and not re.search(r'^(FAIL:|RUNTIME ERROR:)',reg,re.M)
    close=TestRead(root,'Stock/Native/SteelCoreRegressions.txt.ProcessClosure.json')
    owner=TestRead(root,'Stock/Native/SteelCoreRegressions.txt.Ownership.json')
    assert close['Passed'] and close['ChildExitCode']==0 and close['Closure']['FinalState']['State']=='Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    stock_compile=TestRead(root,'Stock/CodeUpdate.json')
    assert owner['SourceSHA256']==stock_compile['WorkbookSHA256'] and stock_compile['Compiled'] and not stock_compile['ProductionChanged']
    assert TestRead(root,'Stock/Preparation.json')['source_core'][CLASS]==TestDigest((root/CLASS).read_bytes())
    native=run_path(str(root/'Verify-FullAB.py'))['native'](root/'Native',package['candidate_sha256'])
    with TestArchive(repo,STOCK) as z:
        prior=json.loads(z.read('CleanSteelHardShearProof.json'))
        baseline_curve=run_path(str(root/'ReadWorkbookCurve.py'))['read_curve']
        curve_name='Native/SavedResultsParts.zip'
        # Полный сохранённый Results доступен в компактном архиве четырёх технических частей.
        old_raw=z.read(curve_name)
    for key in ('capacity_status','result_code','limit_lambda','ultimate_N_Nmm','assertions','probes'):
        assert native[key]==prior['native'][key]
    assert isclose(native['lower_lambda'],prior['native']['lower_lambda'],abs_tol=1e-8,rel_tol=0.)
    assert max(abs(a-b) for a,b in zip(native['direct_N_Nmm'],prior['native']['direct_N_Nmm'],strict=True))<.01
    current=baseline_curve(root/'Native/SavedResultsParts.zip')
    import tempfile
    with tempfile.TemporaryDirectory(dir=root) as directory:
        file=Path(directory)/'Previous.zip';file.write_bytes(old_raw)
        old=baseline_curve(file)
    assert len(current['entries'])==len(old['entries'])==136
    assert all(a[:-1]==b[:-1] for a,b in zip(current['entries'],old['entries'],strict=True))
    difference=max(abs(float(a[-1])-float(b[-1])) for a,b in zip(current['entries'],old['entries'],strict=True))
    assert difference<1e-8
    provenance=TestRead(root,'Native/SavedResultsProvenance.json')
    assert all(current[k]==provenance[k] for k in ('worksheet','worksheet_sha256','named_anchor'))
    return {'candidate_sha256':package['candidate_sha256'],'source_class_sha256':TestDigest((root/CLASS).read_bytes()),
            'native_dump_sha256':TestDigest((root/'VBA_All_Code.txt').read_bytes()),'components':226,
            'unchanged_modules':225,'unchanged_ooxml_parts':121,'stock_assertions':sum(expected),
            'native':native,'accepted_curve_states':68,'maximum_curve_difference':difference,
            'previous_results_time_s':prior['native']['timing_s']['results'],'paired_performance_run':False,
            'physical_limit_certified':False,'candidate_installed':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--capture',action='store_true');p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    if a.capture:TestCapture(a.root.resolve())
    proof=TestVerify(a.repo.resolve(),a.root.resolve())
    a.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('FIELD TANGENT WORKBOOK VERIFIED 365 28 68')
