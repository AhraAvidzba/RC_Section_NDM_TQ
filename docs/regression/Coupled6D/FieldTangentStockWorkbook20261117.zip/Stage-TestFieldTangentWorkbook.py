"""ДЛЯ ТЕСТОВ: собирает контрольную книгу с резервной бетонной касательной до текучести стали."""

from argparse import ArgumentParser
from copy import copy
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile


HERE=Path(__file__).resolve().parent
BOOK='workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA='E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
DUMP='workbook/output/VBA_All_Code.txt'
DUMP_SHA='DB8023F9384B0059E1D1C51D59FE0E62F9B8CD94AC4D9B329DD0EE810AF676CC'
CLASS='src/Solver/CCoupledNewtonSolver.cls'
DRAFT='docs/regression/Diagnostic.xlsm'
CANDIDATE='docs/regression/Audit03/RC_Section_NDM.xlsm'
PART='xl/vbaProject.bin'
EVIDENCE=('MVT2TorqueRecoveryAndFieldTangent20261117.zip','96CD6F7A847AC8937657E12D9E719EF59ABE72108FB999144C7F0255282ABBDF')
BASELINE=('HardShearCoarseGrowthWorkbookRelease20261117.zip','6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63')
TEMPLATE=Path('D:/CodexScratch/RC_Section_NDM_TQ/VBAFlowIntegratedCore')


def TestDigest(data):
    """Возвращает отпечаток полных байтов файла."""
    return sha256(data).hexdigest().upper()


def TestArchive(repo,entry):
    """Открывает проверенные исходники и автономный декодер VBA."""
    file=repo/'docs/regression/Coupled6D'/entry[0]
    assert TestDigest(file.read_bytes())==entry[1]
    return ZipFile(file)


def TestPut(path,data):
    """Создаёт файл только в новой частной сборке."""
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as output:output.write(data)


def TestStage(repo,root):
    """Копирует текущую книгу и проверенный класс; листы и остальные модули не перестраивает."""
    installed=(repo/BOOK).read_bytes();dump=(repo/DUMP).read_bytes()
    assert (TestDigest(installed),TestDigest(dump))==(BOOK_SHA,DUMP_SHA)
    files={BOOK:installed,DRAFT:installed,'Stock.VBA_All_Code.txt':dump}
    with TestArchive(repo,EVIDENCE) as z:
        files[CLASS]=z.read('Field/'+CLASS)
        assert (repo/CLASS).read_bytes()==z.read('Base/'+CLASS)
        files['Guard-IsolatedOffice.ps1']=z.read('Field/Guard-IsolatedOffice.ps1')
    for file in (TEMPLATE/'tools/build_workbook').glob('*'):
        if file.is_file():files[file.relative_to(TEMPLATE).as_posix()]=file.read_bytes()
    exporter='tools/build_workbook/Export-Audit03VbaSnapshot.ps1'
    files[exporter]=(repo/exporter).read_bytes()
    files[Path(__file__).name]=Path(__file__).read_bytes()
    driver=(HERE/'CleanSteelWorkbookBundle/Run-IntegratedSteelWorkbook.ps1').read_text('utf-8-sig')
    assert driver.count('./Stage-IntegratedSteelWorkbook.py')==1
    driver=driver.replace('./Stage-IntegratedSteelWorkbook.py','./Stage-TestFieldTangentWorkbook.py')
    files['Run-TestFieldTangentWorkbook.ps1']=driver.encode('utf-8-sig')
    with TestArchive(repo,BASELINE) as z:
        for name in ('ReadWorkbookCurve.py','Verify-FullAB.py'):files[name]=z.read(name)
    prep={'baseline_book_sha256':BOOK_SHA,'baseline_dump_sha256':DUMP_SHA,'classes':[CLASS],
          'core_evidence':EVIDENCE[1],'inputs':{name:TestDigest(raw) for name,raw in files.items() if name!=DRAFT}}
    root.mkdir()
    (root/'Native').mkdir();(root/'Temp').mkdir()
    (root/'tests').mkdir()
    files['Preparation.json']=(json.dumps(prep,indent=2,sort_keys=True)+'\n').encode()
    for name,raw in files.items():TestPut(root/name,raw)
    print('FIELD TANGENT CLEAN INPUTS READY')


def TestPackage(repo,root):
    """Переносит только скомпилированный VBA и сверяет все 226 компонентов и 122 части книги."""
    installed=(root/BOOK).read_bytes();compiled=(root/DRAFT).read_bytes()
    read=lambda name:json.loads((root/name).read_text('utf-8-sig'))
    compiler=read('docs/regression/CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged']
    assert compiler['ProductionSHA256']==TestDigest(installed)==BOOK_SHA
    assert compiler['WorkbookSHA256']==TestDigest(compiled) and set(compiler['Modules'])=={'CCoupledNewtonSolver'}
    assert read('CompileClosure.json')['State']=='Absent'
    with TestArchive(repo,BASELINE) as z:
        utility={'__name__':'__pinned__','__file__':'Stage-Release.py'}
        exec(compile(z.read('Stage-Release.py'),'Stage-Release.py','exec'),utility)
    observer,sources=utility['parse_vba'](repo)
    output=BytesIO()
    with ZipFile(BytesIO(installed)) as old,ZipFile(BytesIO(compiled)) as draft,ZipFile(output,'w') as new:
        new.comment=old.comment
        for item in old.infolist():new.writestr(copy(item),draft.read(PART) if item.filename==PART else old.read(item))
    packet=output.getvalue()
    with ZipFile(BytesIO(installed)) as old,ZipFile(BytesIO(packet)) as new:
        assert old.namelist()==new.namelist() and len(old.namelist())==122
        assert [name for name in old.namelist() if old.read(name)!=new.read(name)]==[PART]
        parts={name:TestDigest(new.read(name)) for name in new.namelist()}
    _,before=sources(BytesIO(installed));_,after=sources(BytesIO(packet))
    assert set(before)==set(after) and len(after)==226
    changed=[name for name in before if observer['literal_safe_fold'](before[name])!=observer['literal_safe_fold'](after[name])]
    assert changed==['CCoupledNewtonSolver']
    body=observer['compiler_body']
    source,conversions=body((root/CLASS).read_text('utf-8-sig'),'CCoupledNewtonSolver')
    packed,packed_conversions=body(after['CCoupledNewtonSolver'],'CCoupledNewtonSolver')
    assert source==packed and not packed_conversions
    assert conversions==[['2e-12','0.000000000002'],['1e-12','0.000000000001']]
    proof={'source_sha256':BOOK_SHA,'candidate_sha256':TestDigest(packet),'compiled_sha256':TestDigest(compiled),
           'unchanged_ooxml_parts':121,'unchanged_modules':225,'changed_modules':changed,'parts':parts,
           'numeric_literal_normalizations':conversions,'source_class_sha256':TestDigest((root/CLASS).read_bytes())}
    TestPut(root/CANDIDATE,packet)
    TestPut(root/'Package.json',(json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('FIELD TANGENT CLEAN PACKAGE',proof['candidate_sha256'])


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--root',type=Path,required=True);p.add_argument('--package',action='store_true')
    a=p.parse_args()
    if a.package:TestPackage(a.repo.resolve(),a.root.resolve())
    else:TestStage(a.repo.resolve(),a.root.resolve())
