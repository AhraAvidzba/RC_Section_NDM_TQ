﻿# Собирает, читает и запускает отдельную книгу без изменения установленного файла.
param([Parameter(Mandatory=$true)][string]$Repository,
      [ValidateSet('All','Compile','Export','Native')][string]$Phase='All')

$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$oldTemp=$env:TEMP
$oldTmp=$env:TMP
$draft='docs/regression/Diagnostic.xlsm'
$package='docs/regression/Audit03/RC_Section_NDM.xlsm'
$dump='docs/regression/Audit03/VBA_All_Code.txt'
$report='Native/Both.txt'
Push-Location -LiteralPath $root
try {
    . './Guard-IsolatedOffice.ps1'
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    foreach ($inputFile in $prep.inputs.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $inputFile.Name).Hash -cne $inputFile.Value) {throw "Не совпал вход $($inputFile.Name)."}
    }
    if ($Phase -in 'All','Compile') {
        if ((Get-FileHash -LiteralPath $draft).Hash -cne $prep.baseline_book_sha256 -or (Test-Path -LiteralPath 'Compile.log')) {
            throw 'Компиляция требует нетронутую частную копию.'
        }
        Assert-IsolatedOfficeReady 'CompileCleanSteelWorkbook'
        $modules=@($prep.classes|ForEach-Object {[IO.Path]::GetFileNameWithoutExtension($_)})
        & './tools/build_workbook/Update-IsolatedOptimizerCode.ps1' -WorkbookPath $draft -ModuleNames $modules |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
        python -B -X utf8 './Stage-TestFieldTangentWorkbook.py' --repo $Repository --root $root --package
        if ($LASTEXITCODE -ne 0) {throw 'Автономная сверка VBA-контейнера не прошла.'}
        if ($Phase -eq 'Compile') {return}
    }
    $fingerprint=Get-Content -LiteralPath 'Package.json' -Raw | ConvertFrom-Json
    if ((Get-FileHash -LiteralPath $package).Hash -cne $fingerprint.candidate_sha256) {throw 'Изменена контрольная книга.'}
    if ($Phase -in 'All','Export') {
        if ((Test-Path -LiteralPath 'Export.log') -or (Test-Path -LiteralPath $dump)) {throw 'Выгрузка VBA уже существует.'}
        Assert-IsolatedOfficeReady 'ExportCleanSteelWorkbook'
        & './tools/build_workbook/Export-Audit03VbaSnapshot.ps1' -WorkbookPath $package -OutputPath $dump |
            Tee-Object -FilePath 'Export.log'
        Save-OfficeClosure 'Export.log' 'ExportClosure.json'
        if ($Phase -eq 'Export') {return}
    }
    if (Test-Path -LiteralPath $report) {throw 'Протокол штатного расчёта уже существует.'}
    Assert-IsolatedOfficeReady 'RunCleanSteelHardShear'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-FocusedKaniWatchdog.ps1' `
        -SourceWorkbook $package -ReportPath $report -Macro 'modTestCoupledElasticState.RunTestCoupledWorkbookTiming' `
        -MacroArgument1 Both -MacroArgument2 Excel -Mode No -TimeoutSeconds 170 -FailFast -VerifyResultsReopen
    if ($LASTEXITCODE -ne 0) {throw "Штатная проверка завершилась с кодом $LASTEXITCODE."}
    $fixture=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixture.Count -ne 1) {throw 'Нет единственного пути к тестовой копии.'}
    $folder=Split-Path -Parent $fixture[0].Substring('FIXTURE: '.Length)
    if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь тестовой копии лежит вне Temp.'}
    Copy-Item -LiteralPath (Join-Path $folder 'RC_Section_NDM_execution_report.txt') -Destination 'Native/Both.Execution.txt'
} finally {
    $env:TEMP=$oldTemp
    $env:TMP=$oldTmp
    Pop-Location
}
