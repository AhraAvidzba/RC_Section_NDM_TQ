MVT2 nonlinear OpenSees 3.8.0 with distributed bearing pads, held T=10.51 kNm.
Autonomous replay from this extracted directory:
python -B -X utf8 Verify-HeldTSmallSteps.py --archives <project>/docs/regression/Coupled6D --out Replayed.json
The verifier pins four upstream packages. The native producer uses the archived MVT2DamageReplay.py and its original inputs.
The first launch used the wrong support-load vector. Its native record is preserved in FixtureMismatch and has no accepted shear state.
The main run rebuilt the right distributed preload and stopped immediately at the first rejected shear trial.
