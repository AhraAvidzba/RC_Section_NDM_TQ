"""Reconstruct a verified MVT2 field, then follow a smaller fixed-torsion load schedule."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from time import monotonic
from types import SimpleNamespace

import MVT2DamageReplay as damage


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "NonlinearDistributedHeldTSmallSteps.json"
PRIOR_DAMAGE = "FE85EB96F57B45E755DBA4B4790659371241B327A8A07927617C6231E35CF241"
PRIOR_SCRIPT = "EE284CD98841403F76E6BD60655CF7AF37FEA1CE07840A2D657CF0F337B8150A"
VERTICAL_SCALE_N = 30000.0
TARGETS_QY_KN = (6.25, 7.5, 8.75, 10.0, 11.25, 12.5, 13.75, 15.0)
SHEAR = damage.shear


def inputs(wall_seconds):
    """Pin the verified restart and all parameters of the existing material and rig."""
    if sha256(damage.RESULT.read_bytes()).hexdigest().upper() != PRIOR_DAMAGE:
        raise ValueError("The previous rollback diagnosis differs from the frozen run")
    if sha256(Path(damage.__file__).read_bytes()).hexdigest().upper() != PRIOR_SCRIPT:
        raise ValueError("The verified restart implementation differs from the frozen copy")
    geometry, report, reference, q5 = damage.inputs(SimpleNamespace(wall_seconds=wall_seconds))
    report.update(scope="cold reference replay followed by a fixed 1.25 kN shear increment at constant T",
                  source_rollback_diagnosis_sha256=PRIOR_DAMAGE, source_rollback_code_sha256=PRIOR_SCRIPT,
                  planned_Qy_kN=list(TARGETS_QY_KN), maximum_shear_attempts=len(TARGETS_QY_KN),
                  shear_confirmed_states=[], physical_limit_established=False)
    return geometry, report, reference, q5


def snapshot(model, qy):
    """Independently certify section resultants and capture local material and kinematic fields."""
    state = SHEAR.assess_state(model, damage.RIG.TORQUE, 2000.0 * qy)
    SHEAR.summarize(model, state, True)
    state.update(Qy_kN=qy, nominal_midspan_Mx_kNm=0.60 * qy)
    return state


def trace(model, vertical_unit, report, reference, previous, deadline):
    """Accept only each originally verified stage and stop at the first rejected trial."""
    ops = model.ops
    termination = SHEAR.replay_torsion(model, reference, report, OUTPUT, deadline)
    if termination is not None:
        return termination

    ops.loadConst("-time", 0.0)
    SHEAR.set_load(ops, 2, vertical_unit, VERTICAL_SCALE_N)
    ops.integrator("LoadControl", 1.0 / 3.0)
    code = ops.analyze(1)
    report["base_replay_attempt"] = {"solver_code": code, "iterations": ops.testIter(), "time": ops.getTime()}
    if (code, ops.testIter(), ops.getTime()) != (0, 6, 1.0 / 3.0):
        return "Q5_replay_solver_mismatch"

    state = snapshot(model, 5.0)
    group_tolerances = report["replay_component_absolute_tolerances"]
    groups = {"rig_balance": "balance", "displacement": "displacement",
              "concrete_damage_by_station_band": "materials", "steel_signed_extrema_by_band": "materials",
              "concrete_peak_stress_by_longitudinal_and_surface_band": "stress_tensor"}
    report["base_Q5_replayed"] = {
        key: SHEAR.torsion.replay_error(previous[key], json.loads(json.dumps(state[key])), group_tolerances[tolerance], key)
        for key, tolerance in groups.items()
    }
    report["base_Q5_state"] = state
    SHEAR.persist(OUTPUT, report)

    for target in TARGETS_QY_KN:
        if monotonic() >= deadline:
            return "bounded_time_before_next_shear_step"
        goal = target / 15.0
        before = damage.ORIGINAL.rollback_sample(model)
        ops.integrator("LoadControl", goal - before[0])
        code = ops.analyze(1)
        arrived = ops.getTime()
        attempt = {"phase": "fixed_T_small_shear_step", "from_Qy_kN": before[0] * 15.0, "target_Qy_kN": target,
                   "observed_Qy_kN": arrived * 15.0, "solver_code": code, "iterations": ops.testIter()}
        report["attempts"].append(attempt)
        if code:
            after = damage.ORIGINAL.rollback_sample(model)
            attempt.update(rollback_time_exact=after[0] == before[0], rollback_all_nodes_exact=after[1] == before[1],
                           rollback_sampled_damage_exact=after[2] == before[2])
            return "first_small_step_rejected_engine_discarded"
        if abs(arrived - goal) > 2e-12:
            return "committed_load_time_mismatch"
        report["shear_confirmed_states"].append(snapshot(model, arrived * 15.0))
        SHEAR.persist(OUTPUT, report)
    return "all_small_steps_verified"


def run(geometry, report, reference, q5, hard_limit):
    """Run in a fresh OpenSees process through the original accepted history."""
    sys.path.insert(0, str(damage.RIG.UTILITY.parent))
    import validate_opensees_hardshear as utility

    ops = utility.ops
    material = damage.ORIGINAL.MaterialCommands(ops, "default")
    deadline = monotonic() + hard_limit - 15.0
    model = SHEAR.STARTUP.PadModel(geometry, SimpleNamespace(ops=material, Prism=utility.Prism))
    SHEAR.set_load(ops, 1, geometry.torque_unit, damage.RIG.TORQUE)
    SHEAR.configure_analysis(ops)
    report.update(termination="running", opensees_version=ops.version())
    try:
        report["termination"] = trace(model, geometry.vertical_unit, report, reference, q5, deadline)
    except Exception as failure:
        report.update(termination="verification_or_engine_exception", detail=str(failure))
        raise
    finally:
        SHEAR.persist(OUTPUT, report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs", action="store_true")
    mode.add_argument("--start", action="store_true")
    mode.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--wall-seconds", type=int, default=180, choices=range(150, 181))
    opts = parser.parse_args()
    geometry, report, reference, q5 = inputs(opts.wall_seconds)
    if opts.check_inputs:
        print("MVT2_SMALL_SHEAR_INPUTS_OK", report["held_torsion_kNm"], report["planned_Qy_kN"])
        return 0
    if OUTPUT.exists() or OUTPUT.with_suffix(".json.part").exists():
        raise FileExistsError(OUTPUT)
    if opts.child:
        run(geometry, report, reference, q5, opts.wall_seconds)
        print("MVT2_SMALL_SHEAR", report["termination"], len(report["shear_confirmed_states"]))
        return 0
    command = [sys.executable, "-B", "-X", "utf8", str(Path(__file__).resolve()),
               "--child", "--wall-seconds", str(opts.wall_seconds)]
    with OUTPUT.with_suffix(".stdout.log").open("xb") as stdout, OUTPUT.with_suffix(".stderr.log").open("xb") as stderr:
        try:
            code = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=opts.wall_seconds).returncode
        except subprocess.TimeoutExpired:
            print("MVT2_SMALL_SHEAR_WATCHDOG", opts.wall_seconds, OUTPUT.name)
            return 124
    print("MVT2_SMALL_SHEAR_CLOSED", code, OUTPUT.name)
    return code


if __name__ == "__main__":
    sys.exit(main())
