"""Independently check branch evidence at accepted Kani H45, without probing beyond it."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from io import BytesIO
from argparse import ArgumentParser
import csv,json,runpy
import numpy as np
from scipy.linalg import null_space

H=Path(__file__).resolve().parent
FILES={'accepted':('KaniCommitNear48Portable.zip','EA0A80006AF81D99799B53FDCB75B18CDDE7B7DF730AB16039902F12C6431488'),
       'past':('KaniMechanics44Portable.zip','FECD6E310F9C465AC2AA6A43978B12F67A57A4655D8599AFE404B8B789546B5F'),
       'geom':('KaniHydrostaticApex46Portable.zip','B920F591EA6436DB65914CEF8582EA8EB42301679A15311A924253942FEAAEA5'),
       'endpoint':('PhysicalEndpointAudit20261116.zip','D99ADF7C96067DA3361FED43E40DE358E71D6BDADC2EE50F9D2AE129A0569A17')}
sha=lambda x:sha256(x).hexdigest().upper(); pk=lambda x:float(np.max(abs(x)))


def payload(root,k):
    f,needed=FILES[k]; p=root/'docs/regression/Coupled6D'/f; assert sha(p.read_bytes())==needed,f
    return ZipFile(p)


def eig(stress):
    x,y,z,xy,xz,yz=np.moveaxis(stress,-1,0); a=np.stack((x,xy,xz,xy,y,yz,xz,yz,z),axis=-1).reshape(stress.shape[:-1]+(3,3))
    return np.linalg.eigvalsh(a)


def verify(root):
    with payload(root,'accepted') as z:
        A=dict(np.load(BytesIO(z.read('MeasuredSamples.npz')),allow_pickle=False)); receipt=json.loads(z.read('Commit48Verification.json'))
        ctl=json.loads(z.read('Commit48Conditioning.json'))
        matrices={}; checks={}
        for row in csv.reader(z.read('KaniV4Tangents.csv').decode('cp1251').splitlines(),delimiter=';'):
            if row[0]=='MATRIX': matrices.setdefault(row[1],np.zeros((88,88)))[int(row[2])-1]=np.array(row[3:],float)
        for row in csv.reader(z.read('KaniV4Trace.csv').decode('cp1251').splitlines(),delimiter=';'):
            if row[0]=='CHECK': checks[row[1]]=list(map(float,row[2:]))
    with payload(root,'past') as z: prior=json.loads(z.read('Verification.json'))
    with payload(root,'geom') as z:
        geo=np.loadtxt(BytesIO(z.read('GeometryAndDirections.csv')),delimiter=';'); priorSteel=json.loads(z.read('HydrostaticApexDecomposition.json'))
        xp=H/'BuildOperators.py'; xp.write_bytes(z.read('BuildOperators.py'))
    with payload(root,'endpoint') as z:
        assert 'README.md' in z.namelist(); endpoint_files=[p for p in z.namelist() if p.endswith('.json')]; assert endpoint_files
    build=runpy.run_path(xp)['operators']; L=float(A['length']); area=305.*610.; H0,N,g,W,weights,normalization=build(A['geometry'],L)
    ids={name:i for i,name in enumerate(A['names'])}; fields={k:A['fields'][ids[k]] for k in ('Base43','Base44','Committed45','ZeroFrom45','Restore44','Restore43')}
    st={k:A['stations'][A['station_index'][i]] for k,i in ids.items()};
    assert np.array_equal(geo[:,:3],A['geometry']); assert np.array_equal(st['Committed45'],st['ZeroFrom45'])
    assert np.array_equal(fields['Committed45'],fields['ZeroFrom45'])
    Tp=st['Committed45']; eps=Tp[:,:,:6]; stress=Tp[:,:,6:]; D=np.zeros((3,184,6,83)); D[:,:,:,:79]=H0[None,:,:,:]
    D[0,:,:,79:]=-.001*H0[:,:,:4]; D[2,:,:,79:]=.001*H0[:,:,:4]; S=D.reshape(-1,83)
    assert pk(D@fields['Committed45'][2:85]-eps)<2e-12
    # Positive scalar damage preserves the invariant principal signs. Convert the engineering strain shears first.
    strain=eps.copy(); strain[:,:144,3:]/=2.; es=eig(strain[:,:144]); sigma=eig(stress[:,:144]);
    en=np.array(receipt['energiesByStation_minus0plus']['Committed45']); t=en[:,:144,0]; c=en[:,:144,1]
    E=25600.; fc=28.2; ft=1.75; fc0=.6*fc; gt=.073*fc**.18; gc=(fc/ft)**2*gt; peakCompression=.0022
    compressDamage=.423*(1.-fc/(peakCompression*E)); plasticPeak=peakCompression-fc/((1.-compressDamage)*E)
    compressionEnergyAtPeak=.5*(fc0+fc)*plasticPeak/(gc/125.)
    assert float(c.max())<compressionEnergyAtPeak
    # Longitudinal and transverse steel have separately verified elastic thresholds and geometry.
    directions=np.zeros((40,6)); directions[:,:4]=geo[144:,3:]; ax=np.einsum('sij,ij->si',eps[:,144:],directions)
    assert priorSteel['maximumReplayedSteelStress_MPa']<181.
    steel=2e5*ax; transverse=steel[:,8:]; longitudinal=steel[:,:8]; closest=np.argmax(abs(transverse[1]));
    assert abs(transverse[1,closest]-checks['Committed45'][-2])<1e-8
    indicators={'directConcreteMinPrincipalStrain':float(es[:,:,0].min()),'directConcreteMaxPrincipalStrain':float(es[:,:,2].max()),
                'directConcreteMinNominalPrincipalStress_MPa':float(sigma[:,:,0].min()),'tensionEnergyMaximumDirect':float(t.max()),
                'tensionEnergyMaximumAll':float(en[:,:,0].max()),'compressionEnergyMaximumDirect':float(c.max()),
                'compressionEnergyMaximumAll':float(en[:,:,1].max()),'compressionEnergyAtCalibratedPeak':compressionEnergyAtPeak,
                'longitudinalSteelMaxAbsStress_MPa':pk(longitudinal),'transverseSteelMaxAbsStress_MPa':pk(transverse),
                'steelYieldRatios':[pk(longitudinal)/442,pk(transverse)/400],
                'nativeMaxSteelUltimateStrainUtilizationCenter':checks['Committed45'][-1],
                'maxSteelUltimateStrainRatioAllStations':pk(ax)/.05,
                'currentTensionPredictorNearNumericalToleranceStations':ctl['predictorIndicators']['Committed45']['numAbsBelow1e-12']}
    y=[(k,fields[k][0]*1e5,fields[k][1]) for k in ('Base43','Base44','Committed45')]
    examples=[{'left':a,'right':aa,'dQy_N':float(qq-q),'dGamma':float(gg-g),'acceptedSecantLoad_NPerGamma':float((qq-q)/(gg-g))}
              for (a,q,g),(aa,qq,gg) in zip(y,y[1:])]
    oldU=float(prior['commit']['lambda_uncertainty']*1e5); newU=float(receipt['adjointUncertainty_N']['FromHistory45'])
    assert newU>0 and oldU>0
    # Five compatibility rows in the native square layout are four gauges and the actual control.
    assert all(pk(matrices[n][83:]-matrices['H45Stock'][83:])<2e-10 for n in matrices)
    gauge=matrices['H45Stock'][83:87,:83]; Z=null_space(gauge,rcond=1e-12); assert Z.shape==(83,79)
    gamma_y=A['projection'][:83]; dt=np.asarray(fields['Committed45'][2:85]-fields['Base44'][2:85]); native_direction=S@dt
    Sbasis=S@Z; _,sv,right=np.linalg.svd(Sbasis,full_matrices=False); assert sv[-1]>1e-6
    shape_coord=(Z@right.T)/sv; strainOrtho=S@shape_coord; assert pk(strainOrtho.T@strainOrtho-np.eye(79))<3e-11
    # A control covector aligned with the only actual recent accepted mechanical displacement in station strain metric.
    direction=native_direction/np.linalg.norm(native_direction); physical_covector=S.T@direction
    csec=physical_covector/(np.linalg.norm(physical_covector)); vdt=float(csec@dt); assert vdt>0
    gModes={'measuredMeanYz':gamma_y,'acceptedStationProjection':csec,'axial':np.eye(83)[0],'bendingAboutX':np.eye(83)[1]}
    h45=matrices['H45Stock']; gnull=null_space(h45[:83,83:87].T,rcond=1e-12)
    Mw=gnull.T@h45[:83,:83]@shape_coord; _,_,Vw=np.linalg.svd(Mw,full_matrices=False)
    weakest=strainOrtho@Vw[-1]
    if weakest@direction<0: weakest=-weakest
    combined=direction+weakest; combined/=np.linalg.norm(combined)
    cweak=S.T@combined; cweak/=np.linalg.norm(cweak)
    assert cweak@dt>0
    gModes['balancedPhysicalControl']=cweak
    labs=('H44TrialStock','H45Stock','H45Refined'); models={}; nmode={}
    for n in labs:
        operator=matrices[n]; F0=operator[:83,:83]; L0=operator[:83,83:87]; q_column=operator[:83,87];
        assert abs(q_column[80]+1e5/area)<2e-14
        left=null_space(L0.T,rcond=1e-12); assert left.shape==(83,79)
        W0=left.T@F0@shape_coord; f=left.T@q_column
        u,ss,vh=np.linalg.svd(W0,full_matrices=False); ncoord=vh[-1]; ns=shape_coord@ncoord; nshape=strainOrtho@ncoord
        if np.dot(nshape,direction)<0: ns=-ns; nshape=-nshape
        nmode[n]=nshape
        weights_adj={}; changes={}
        for mode,p in gModes.items():
            chart=np.block([[W0,f[:,None]],[(p@shape_coord)[None,:],np.zeros((1,1))]])
            # Solve in the native layout to reproduce the actual Qy uncertainty metric as defined in VBA.
            P=operator.copy(); P[87,:]=0; P[87,:83]=p*25600
            right0=np.zeros(88); right0[-1]=25600
            dq=np.linalg.solve(P,right0); error=pk(P@dq-right0)
            alt=np.zeros(88); alt[-1]=1.; uu=np.linalg.solve(P.T,alt)
            uncertainty=float(1e5*(np.sum(abs(uu))*5.59190995944018e-7+2e-12*(1+fields['Committed45'][0])))
            Mp=P/np.maximum(np.max(abs(P),axis=0),1e-28)
            changes[mode]={'nativeConditionAfterColumnScaling':float(np.linalg.cond(Mp)),
                           'dQy_dControl_NPerStrain':float(dq[-1]*1e5), 'trialLambdaUncertainty_N_atArchiveTau':uncertainty,
                           'linearEqVerificationMPaScaled':error,
                           'projectionOfRecentAcceptedIncrement':float(p@dt),
                           'normalizedControlAlignmentToWeakFixedLoadMode':float((p@ns)/np.linalg.norm(p@shape_coord)),
                           'stationChangePerUnitOfControl':pk(S@dq[:83]),
                           'slopeDirectionCosineWithAcceptedIncrement':float((S@dq[:83])@direction/np.linalg.norm(S@dq[:83]))}
        models[n]={'fixedLoadPhysicalGaugeEliminatedCondition':float(ss[0]/ss[-1]),'fixedLoadPhysicalSmallestSingValue':float(ss[-1]),
                   'fixedLoadPhysicalLargestSingValue':float(ss[0]),'fixedLoadRankAt1eMinus10Relative':int(np.sum(ss>1e-10*ss[0])),
                   'leftWeakModeRelativeCouplingToLoadColumn':float(abs(u[:,-1]@f)/np.linalg.norm(f)),
                   'weakFixedLoadModeStationCosineAgainstRecentIncrement':float(nshape@direction),
                   'varyingControlComparisons':changes}
    assert abs(models['H45Stock']['varyingControlComparisons']['measuredMeanYz']['trialLambdaUncertainty_N_atArchiveTau']-newU)<2e-6
    projections={'smallestFixedLoadModeCosineFreshStockRefined':float(nmode['H45Stock']@nmode['H45Refined']),
                 'smallestFixedLoadModeCosineBeforeAfterStock':float(nmode['H45Stock']@nmode['H44TrialStock'])}
    report={'assumptions':['Steel stress reconstructed in elastic range, confirmed by the accepted path and native hoop record.',
                           'Compression peak here is a material calibration marker, not a section failure criterion.',
                           'Native per-column tangents at a yield surface need not represent the signed derivative of a continued branch.'],
            'sourcesSHA256':{x:k[1] for x,k in FILES.items()},'acceptedOnlyIntervals':examples,'freshH45AdjointN':newU,
            'base44AdjointN':oldU,'mostRecentAcceptedLoadIncrementOverSumOfAdjoints':examples[-1]['dQy_N']/(oldU+newU),
            'material':indicators,'freshAndSameFieldBeforeCommit':models,'physicalWeakModeComparisons':projections,
            'candidateControlsPurePhysicalVectors':{'acceptedStationProjection':np.r_[csec,np.zeros(4)].tolist(),'balancedPhysicalControl':np.r_[cweak,np.zeros(4)].tolist()},
            'scope':'Calculations exclude non-equilibrated +18N rows and other rejected/collinear trial fields. Slope is conditional on operator, not a measured postcommit load.'}
    return report

if __name__=='__main__':
    ap=ArgumentParser(); ap.add_argument('--repo-root',type=Path,required=True); p=ap.parse_args()
    r=verify(p.repo_root.resolve()); out=H/'H45PhysicalBranchAudit.json'; out.write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
    print(out,sha(out.read_bytes()),r['material'],r['acceptedOnlyIntervals'])
    for name,case in r['freshAndSameFieldBeforeCommit'].items():
        print(name,case['fixedLoadPhysicalGaugeEliminatedCondition'],case['fixedLoadPhysicalSmallestSingValue'],case['leftWeakModeRelativeCouplingToLoadColumn'],case['weakFixedLoadModeStationCosineAgainstRecentIncrement'])
        for k,v in case['varyingControlComparisons'].items(): print(k,v)
    print(r['physicalWeakModeComparisons'])
