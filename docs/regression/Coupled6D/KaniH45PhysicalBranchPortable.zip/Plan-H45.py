"""Freeze the accepted-path displacement coordinate for one discriminating measurement."""
from pathlib import Path
from argparse import ArgumentParser
from zipfile import ZipFile
from io import BytesIO
from hashlib import sha256
import csv,json,runpy
import numpy as np

H=Path(__file__).resolve().parent; m=runpy.run_path(H/'Audit-H45.py');

def make(repo):
    a=m['verify'](repo)
    with m['payload'](repo,'accepted') as z:
        p=dict(np.load(BytesIO(z.read('MeasuredSamples.npz')),allow_pickle=False)); q0=p['fields'][list(p['names']).index('Committed45')];
        seed=z.read('History45Verified.csv'); assert m['sha'](seed)=='97FF3089BA40A3B7349B1A0588B21FAFB3689E33DB7BA95892163C80B83CA9EE'
    with m['payload'](repo,'geom') as za:
        older=list(csv.reader(za.read('KaniV4Input.csv').decode('ascii').splitlines()[1:],delimiter=';'))
    r=a['freshAndSameFieldBeforeCommit']; c=np.array(a['candidateControlsPurePhysicalVectors']['acceptedStationProjection']); assert len(c)==87 and np.all(c[-4:]==0.)
    sec=float(c@q0[2:]); da=1.5e-8
    mode={name:r[name]['varyingControlComparisons']['acceptedStationProjection'] for name in ('H45Stock','H45Refined')}
    assert all(d['projectionOfRecentAcceptedIncrement']>0 and d['dQy_dControl_NPerStrain']>0 for d in mode.values())
    local_reference={'freshLinearExpectedIncrementPlanningScale_N':[d['dQy_dControl_NPerStrain']*da for d in mode.values()],
                     'freshLinearExpectedStationStrainScale':[d['stationChangePerUnitOfControl']*da for d in mode.values()],
                     'original H45 uncertainty in mean shear N':a['freshH45AdjointN'],
                     'H45 uncertainty estimate in this candidate measure N':[d['trialLambdaUncertainty_N_atArchiveTau'] for d in mode.values()],
                     'planningUse':True,'rejectedFieldsUsed':False}
    older_out=[]
    for v in older:
        i=int(v[1]); f=1e5*float(v[3]); q=np.array(v[4:],float)
        dif=sec-c@q; dQ=q0[0]*1e5-f
        if i>=30:
            older_out.append({'acceptedHistoryIndex':i,'oppositeControlGapFromH45':float(dif),'observedQy_N':f,'QyGapFromH45_N':dQ})
    left=[v for v in older_out if v['acceptedHistoryIndex']==32][0];
    left['clarification']='This is an earlier observed load on the same stored initial path. Its adjoint in the alternative control is not verified.'
    row=';'.join(['KANI_ALT_CONTROL_H45','StationProjectionFromLastAcceptedIncrement',format(sec,'.17g'),
                  format(sec+da,'.17g'),format(da,'.17g'),*[format(v,'.17g') for v in c]])
    field=H/'H45ForDiscriminatingMeasurement.csv'; field.write_bytes(seed)
    geometry=H/'H45DiscriminatingControl.csv'; geometry.write_bytes((row+'\r\n').encode('ascii'))
    meta={'label':'One controlled forward shoulder measurement starting from exact accepted H45',
          'baseQy_N':float(q0[0]*1e5),'currentGamma':float(q0[1]),'targetVariable':'acceptedStationProjection','currentAlpha':sec,
          'targetAlpha':sec+da,'incrementAlpha':da,'originalTauMPa':5.59190995944018e-7,'otherPrescribedEfforts_N_Nmm':[0.]*5,
          'QyIsSolvedNotImposed':True,'initialFieldExactH45':True, 'rejectedFieldsUsed':False,
          'branchChecks':['Require all native 89 force rows and 5 compatibility equations within the original tolerances.',
                          'Require forward progress in the control and check actual strain continuity and material energies against H45.',
                          'Report the computed right-hand load, adjoint, resolved secant and separate steel yield/ultimate and concrete markers.',
                          'A higher separated load on the same continuous branch rules out H45 as determining maximum over the measured interval. A lower separated load shows one descending shoulder only.',
                          'A failed trial remains numerical. An earlier left field from the actual prefix requires an independent adjoint and continuity check before a maximum can be claimed.'],
          'oldLeftFieldForContext':left,'storedPrefixContext':older_out,'localReference':local_reference, 'controlInputSHA256':m['sha'](geometry.read_bytes()),
          'baseFieldSHA256':m['sha'](field.read_bytes()), 'importantLimit':'No finite-load target, signed direction, or branch equilibrium has been extrapolated from rejected fields.'}
    return meta

if __name__=='__main__':
    p=ArgumentParser(); p.add_argument('--repo-root',type=Path,required=True); a=p.parse_args(); r=make(a.repo_root.resolve());
    file=H/'DiscriminatingH45Measurement.json'; file.write_text(json.dumps(r,indent=2)+'\n',encoding='utf8'); print(file,m['sha'](file.read_bytes()),r['currentAlpha'],r['targetAlpha'],r['oldLeftFieldForContext'])
