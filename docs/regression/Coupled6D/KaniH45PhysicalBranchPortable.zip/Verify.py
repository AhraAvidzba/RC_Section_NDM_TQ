from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import json,runpy,os

H=Path(__file__).resolve().parent; os.environ['OPENBLAS_NUM_THREADS']='1'
p=ArgumentParser(); p.add_argument('--repo-root',type=Path,required=True); a=p.parse_args(); root=a.repo_root.resolve()
read=lambda n:json.loads((H/n).read_text(encoding='utf8')); sha=lambda p:sha256(p.read_bytes()).hexdigest().upper()
assert all(sha(H/n)==v for n,v in read('Manifest.json')['files'].items())
audit=runpy.run_path(H/'Audit-H45.py')['verify'](root)
plan=runpy.run_path(H/'Plan-H45.py')['make'](root)
assert audit==read('H45PhysicalBranchAudit.json') and plan==read('DiscriminatingH45Measurement.json')
assert sha(H/'H45DiscriminatingControl.csv')==plan['controlInputSHA256'] and sha(H/'H45ForDiscriminatingMeasurement.csv')==plan['baseFieldSHA256']
print(json.dumps({'signedFreshSlope_NPerGamma':[audit['freshAndSameFieldBeforeCommit'][k]['varyingControlComparisons']['measuredMeanYz']['dQy_dControl_NPerStrain'] for k in ('H45Stock','H45Refined')],
 'twoAcceptedLoadIncrements_N':[d['dQy_N'] for d in audit['acceptedOnlyIntervals']], 'gammaControlBaseAdjoint_N':audit['freshH45AdjointN'],
 'acceptedDirectionControlTarget':plan['targetAlpha'],'plannedControlIncrement':plan['incrementAlpha'],'fixedH45FieldSHA256':plan['baseFieldSHA256']},indent=2))
