# Kani V4 linear equilibrium at the native reserve radius

From this folder, run python verify.py with Python 3.10 or newer, NumPy and SciPy installed. It has no Excel, repository or Windows-specific dependencies. The trace uses its original CP1251 encoding.

The script reconstructs the V4 reserve's linear feasibility problem from the archived 88-row matrices. It uses 83 weak equilibrium rows plus six separately checked signed physical resultants. Four gauges and one controlled deformation are held as exact equalities. The allowable infinity norm of a correction in the original column scaling is read from the native reserve trace as 1.52655091492458e-6. The refined matrix is the one used in the native V4 reserve. The stock matrix is an independent comparison at the same numeric radius under its own native column scaling.

The independent LP yields about 5.925648124e-7 and 5.909183957e-7 MPa for stock and refined. Both values exceed the native acceptance tolerance and the more restrictive reserve target. The optimizer's recorded refusal after 53 linear solves is consistent with these independently checked primal and dual bounds. The minimax problem has only the radius and exact constraints, so adding a material-strain objective or cap cannot make the native linear force target feasible at this radius. This test reproduces a local linear result on a frozen, uncommitted trial. It does not certify the nonlinear outcome, material failure, or section capacity.

The numerical subset includes the smallest archived arrays required to reconstruct the operators, along with a hash-checked copy of the native reserve trace. Source archives and extraction details are listed in provenance.json.

