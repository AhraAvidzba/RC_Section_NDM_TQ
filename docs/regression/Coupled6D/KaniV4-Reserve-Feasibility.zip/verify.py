"""Replay the linear equilibrium minima at the exact Kani V4 reserve radius."""
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parent
META = json.loads((ROOT / "provenance.json").read_text(encoding="utf-8"))
CHECKS = {
    "stock": 5.925648123543384e-7,
    "refined": 5.909183956738312e-7,
}


def verify_file(path, expected):
    if hashlib.sha256(path.read_bytes()).hexdigest().upper() != expected:
        raise ValueError(f"Input digest differs for {path.name}")


def native_controls():
    raw = ROOT / "KaniReserve.csv"
    verify_file(raw, META["reserve_sha256"])
    rows = [row.split(";") for row in raw.read_text(encoding="cp1251").splitlines()]
    if rows[0][0] != "ReserveEnter" or rows[3][0:3] != ["Optimizer","0","53"]:
        raise ValueError("Unexpected reserve trace")
    baseline, tolerance = map(float, rows[0][1:])
    radius = float(next(row[1] for row in rows if row[0] == "SystemBuilt"))
    if abs(radius / baseline - 2.5) > 1e-13:
        raise ValueError("Wrong native reserve radius")
    return tolerance, radius


def peak(values):
    return float(np.max(np.abs(values)))


def case(data, name, projection, tolerance, radius):
    raw = data[name + "_augmented_matrix_MPa"]
    residual = data[name + "_augmented_residual_MPa"]
    signed = data[name + "_direct_wrench_residual_MPa"]
    if raw.shape != (88,88) or residual.shape != (88,) or signed.shape != (6,):
        raise ValueError("Wrong equilibrium dimensions")
    if peak(projection @ residual[:83] - signed) > 3e-10:
        raise ValueError("The six signed resultants do not agree with weak equilibrium")
    column = np.max(np.abs(raw), axis=0)
    if np.any(column == 0):
        raise ValueError("A native Newton column has zero scale")
    matrix = raw / column
    force = np.vstack((matrix[:83], projection @ matrix[:83])) * radius / tolerance
    rhs = np.r_[residual[:83],signed] / tolerance
    constraint_scale = np.max(np.abs(matrix[83:]), axis=1)
    eql = matrix[83:] / constraint_scale[:, None]
    q = residual[83:] / (constraint_scale * radius)
    rows = np.r_[np.c_[force, -np.ones(89)], np.c_[-force, -np.ones(89)]]
    b = np.r_[-rhs,rhs]
    equ = np.c_[eql,np.zeros(5)]
    c = np.r_[np.zeros(88),1.]
    fit = linprog(c,A_ub=rows,b_ub=b,A_eq=equ,b_eq=-q,bounds=[(-1.,1.)]*88+[(0.,None)],
                  method="highs",options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
    if not fit.success:
        raise ValueError(fit.message)
    optimum = peak(force @ fit.x[:88] + rhs) * tolerance
    equality_error = peak(eql @ fit.x[:88] + q)
    stationarity = peak(c-rows.T@fit.ineqlin.marginals-equ.T@fit.eqlin.marginals
                        -fit.lower.marginals-fit.upper.marginals)
    lower_bound = float(b@fit.ineqlin.marginals - q@fit.eqlin.marginals
                        - np.sum(fit.lower.marginals[:88]) + np.sum(fit.upper.marginals[:88]))
    if (abs(optimum-CHECKS[name])>5e-13 or equality_error>1e-8 or stationarity>1e-8
            or abs(fit.fun-lower_bound)>1e-8 or lower_bound*tolerance<=tolerance
            or peak(fit.x[:88])>1.+1e-9):
        raise ValueError(f"Verification failed for {name}")
    return {"linear_min_MPa": optimum, "dual_lower_MPa": lower_bound*tolerance,
            "primal_dual_gap_MPa": abs(fit.fun-lower_bound)*tolerance,
            "scaled_equality_error": equality_error,"scaled_dual_error": stationarity}


def main():
    datafile=ROOT / "operators.npz"
    verify_file(datafile,META["subset_sha256"])
    tolerance,radius=native_controls()
    with np.load(datafile,allow_pickle=False) as data:
        projection=data["resultant_projection"]
        if projection.shape != (6,83) or not all(np.isfinite(data[k]).all() for k in data.files):
            raise ValueError("Invalid matrix data")
        results={name:case(data,name,projection,tolerance,radius) for name in CHECKS}
    print(json.dumps({"status":"PASS","force_rows":89,"equalities":5,"radius":radius,
                      "acceptance_tolerance_MPa":tolerance,"native_linear_cap_MPa":.92*tolerance,
                      "results":results},indent=2,allow_nan=False))


if __name__ == "__main__":
    main()
