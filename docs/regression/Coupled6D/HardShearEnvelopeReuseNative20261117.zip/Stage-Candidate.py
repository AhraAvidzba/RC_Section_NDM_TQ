"""Prepare the exact-coordinate concrete-envelope reuse candidate for native A/B."""

from argparse import ArgumentParser
import json
from pathlib import Path

from Stage import BASE_SHA, BOOK, CONCRETE, HERE, REPO, STOCK, STORAGE, TEST, decode, digest, encode, one, wrap


ENVELOPE = 'src/Materials/CCoupledConcreteEnvelope.cls'


def envelope_update(code):
    code = one(code, '    Dim exponent As Double, consumed As Double',
               '    Dim exponent As Double, consumed As Double, softening As Double')
    code = one(code, '        stress = mPeak * Exp(exponent)',
               '        softening = Exp(exponent)\n        stress = mPeak * softening')
    return one(code, '(1# - Exp(exponent)) / mSoftening', '(1# - softening) / mSoftening')


def response_update(code):
    code = one(code, '        mTension.Evaluate nextTension, unusedStress, ct, dt, kt\n'
                     '        mCompression.Evaluate nextCompression, unusedStress, cc, dc, kc',
               '        \' Ветвь сохраняет сцепление, повреждение и энергию при точно той же пластической координате.\n'
               '        If nextTension <> tension Then mTension.Evaluate nextTension, unusedStress, ct, dt, kt\n'
               '        If nextCompression <> compression Then mCompression.Evaluate nextCompression, unusedStress, cc, dc, kc')
    return one(code, '        mTension.Evaluate tension, unusedStress, ct, dt, kt\n'
                     '        mCompression.Evaluate compression, unusedStress, cc, dc, kc',
               '        If tension <> nextTension Then mTension.Evaluate tension, unusedStress, ct, dt, kt\n'
               '        If compression <> nextCompression Then mCompression.Evaluate compression, unusedStress, cc, dc, kc')


def tests(code):
    return code.rstrip() + '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сопоставляет штатный запуск HardShear и проверки бетона в частной копии.
Public Function RunTestConcreteEnvelopeReuse() As String
    Dim report As String
    report = RunTestCoupledWorkbookTiming("Both", "Excel") & vbCrLf
    report = report & RunTestCoupledConcreteTensor() & vbCrLf
    report = report & RunTestCoupledConcreteReturn() & vbCrLf
    report = report & RunTestCoupledConcreteResponse()
    RunTestConcreteEnvelopeReuse = report
End Function
'''


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--destination', type=Path, required=True)
    target = cli.parse_args().destination.resolve()
    assert target.is_relative_to(STORAGE.resolve()) and target != STORAGE.resolve()
    stock_plan = json.loads((STOCK/'Fixture.json').read_bytes())
    original = (REPO/BOOK).read_bytes()
    assert stock_plan['book_sha256'] == digest(original) == BASE_SHA
    files = {key:(STOCK/key).read_bytes() for key in stock_plan['inputs'] if key.startswith(('tools/', 'Guard-'))}
    assert all(digest(data) == stock_plan['inputs'][name] for name, data in files.items())
    conversions = {ENVELOPE:envelope_update,
                   CONCRETE:lambda source:wrap(source,'UpdatePoint',response_update), TEST:tests}
    raw_hashes = {}
    for name, instrument in conversions.items():
        raw = (REPO/name).read_bytes()
        raw_hashes[name] = digest(raw)
        files[name] = encode(instrument(decode(raw)))
    for name in ('Stage.py', 'Stage-Candidate.py', 'Verify.py'):
        files[name] = (HERE/name).read_bytes()
    runner = (HERE/'Run.ps1').read_text(encoding='utf-8')
    runner = runner.replace('RunTestHardShearProfile','RunTestConcreteEnvelopeReuse').replace('HardShearProfile','EnvelopeReuse')
    runner = runner.replace("python -B -X utf8 'Verify.py'\n", "python -B -X utf8 'Verify-Candidate.py'\n")
    files['Run.ps1'] = runner.encode('utf-8')
    files['Verify-Candidate.py'] = (HERE/'Verify-Candidate.py').read_bytes()
    for name in ('Both.txt','Both.Execution.txt'):
        files['Stock/'+name] = (STOCK/'Native'/name).read_bytes()
    manifest = {'workbook':BOOK,'source_workbook_sha256':BASE_SHA,'original_sources':raw_hashes,
                'modules':[Path(name).stem for name in conversions],
                'inputs':{name:digest(raw) for name,raw in files.items()}}
    target.mkdir()
    for directory in ('Temp','Native'):
        (target/directory).mkdir()
    files.update({'docs/regression/Diagnostic.xlsm':original,BOOK:original,
                  'Fixture.json':(json.dumps(manifest,indent=2)+'\n').encode()})
    for name,data in files.items():
        destination = target/name
        destination.parent.mkdir(exist_ok=True,parents=True)
        with destination.open('xb') as stream:
            stream.write(data)
    print('ENVELOPE_REUSE_INPUTS:',digest(files['Fixture.json']))


if __name__ == '__main__':
    main()
