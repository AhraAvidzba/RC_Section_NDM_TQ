"""Recheck the native envelope candidate against the stock workbook and material controls."""

import json
import re

from Verify import ROOT, digest, line, read, verify_inputs


plan = json.loads(read('Fixture.json'))
verify_inputs(plan)
stock, candidate = read('Stock/Both.txt'), read('Native/Report.txt')
compiled = json.loads(read('docs/regression/CodeUpdate.json'))
closure = json.loads(read('CompileClosure.json'))
assert compiled['Compiled'] and not compiled['ProductionChanged'] and closure['State']=='Absent'
assert sorted(compiled['Modules']) == sorted(plan['modules'])
assert line(candidate,'SOURCE_SHA256: ') == 'SOURCE_SHA256: ' + compiled['WorkbookSHA256']
assert line(stock,'SOURCE_SHA256: ') == 'SOURCE_SHA256: ' + plan['source_workbook_sha256']
assert 'RUNTIME ERROR:' not in candidate and '\nFAIL:' not in candidate
for prefix in ('TIMING_STATES:','TIMING_LIMIT_REASON:','TOTAL_COUPLED_WORKBOOK_TIMING:'):
    assert line(stock,prefix) == line(candidate,prefix)
assert line(candidate,'TOTAL_COUPLED_WORKBOOK_TIMING:') == 'TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0'
count = {}
elapsed = []
results = []
for report in (stock,candidate):
    before,after = re.search(r'^RESULTS_SAVE_REOPEN: before=([\dA-F]{64}); after=([\dA-F]{64}); equal=True;',report,re.M).groups()
    assert before == after
    results.append(before)
    assert line(report,'SOURCE_UNCHANGED:') == 'SOURCE_UNCHANGED: True'
    elapsed.append(float(line(report,'TIMING_SECONDS: ').split(' | ')[0].split(': ')[1].replace(',','.')))
assert [row for row in stock.splitlines() if row.startswith('OK: ')] == [row for row in candidate.split('TOTAL_COUPLED_WORKBOOK_TIMING:')[0].splitlines() if row.startswith('OK: ')]
for label in ('TENSOR','RETURN','RESPONSE'):
    tag = line(candidate,'TOTAL_COUPLED_CONCRETE_'+label+':')
    passed = re.fullmatch(r'.*: passed=(\d+); failed=0',tag)
    assert passed and int(passed[1]) > 0
    count[label] = int(passed[1])
traces = []
for path in ('Stock/Both.Execution.txt','Native/Execution.txt'):
    trace = [row for row in read(path).splitlines() if '| Мера деформации:' in row]
    assert len(trace)==1
    traces.append(trace[0].split('] ',1)[1])
assert traces[0]==traces[1]
report={'stock_seconds':elapsed[0],'candidate_seconds':elapsed[1],'native_material_assertions':count,
        'same_status_and_six_wrench':True,'same_trace_diagnostics':True,'results_fingerprints':results,
        'report_sha256':digest('Native/Report.txt'),'stock_report_sha256':digest('Stock/Both.txt')}
(ROOT/'Native/Verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('ENVELOPE REUSE NATIVE VERIFIED',report)
