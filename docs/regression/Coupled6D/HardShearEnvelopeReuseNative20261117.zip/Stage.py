"""Stage timing-only instrumentation in a disposable copy of the installed HardShear workbook."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
STORAGE = Path('D:/CodexScratch/RC_Section_NDM_TQ')
STOCK = STORAGE / 'HardStockNow'
SOLVER = 'src/Solver/CCoupledNewtonSolver.cls'
CONCRETE = 'src/Materials/CCoupledConcreteResponse.cls'
TEST = 'tests/modTestCoupledElasticState.bas'
BASE_SHA = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
BOOK = 'workbook/output/RC_Section_NDM.xlsm'


def decode(raw):
    return raw.decode('utf-8-sig').replace('\r\n', '\n')


def encode(source):
    return source.replace('\n', '\r\n').encode('utf-8')


def digest(data):
    return sha256(data).hexdigest().upper()


def one(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


def wrap(code, name, edit):
    start = code.index('Private Function ' + name + '(')
    end = code.index('\nEnd Function', start)
    return code[:start] + edit(code[start:end]) + code[end:]


def solver_body(code):
    code = one(code, '    mEvaluations =',
               '    Dim perfWhole As Currency, perfPoint As Currency, perfSlot As Long\n'
               '    If withMatrix Then perfSlot = 0 Else perfSlot = 1\n'
               '    HardPerfCounterTest perfWhole\n'
               '    mEvaluations =')
    code = one(code, '        mFailureCode = EvaluatePointResponses(point, field, tangentMode, recordTrial, failedSide)\n',
               '        HardPerfCounterTest perfPoint\n'
               '        mFailureCode = EvaluatePointResponses(point, field, tangentMode, recordTrial, failedSide)\n'
               '        HardPerfFinishTest perfSlot + 2, perfPoint\n')
    assert code.count('Exit Function') == 2
    code = code.replace('Exit Function', 'GoTo PerfDone')
    return code + '\nPerfDone:\n    HardPerfFinishTest perfSlot, perfWhole'


def response_body(code):
    code = one(code, '    Dim branchConsistent As Boolean\n',
               '    Dim branchConsistent As Boolean, perfPoint As Currency, perfOK As Boolean\n')
    code = one(code, '        If Not UpdateWithSubsteps(strain, mHistory(point, mCommitted), updated, stress, virginElastic, baseSubsteps) Then GoTo Failure',
               '        HardPerfCounterTest perfPoint\n'
               '        perfOK = UpdateWithSubsteps(strain, mHistory(point, mCommitted), updated, stress, virginElastic, baseSubsteps)\n'
               '        HardPerfFinishTest 4 + tangentMode, perfPoint\n'
               '        If Not perfOK Then GoTo Failure')
    return one(code, '        If Not NonlinearTangent(point, strain, stress, tangent, tangentMode, cachedMode, recordTrial, _\n'
                     '                updated, baseSubsteps) Then GoTo Failure',
               '        HardPerfCounterTest perfPoint\n'
               '        perfOK = NonlinearTangent(point, strain, stress, tangent, tangentMode, cachedMode, recordTrial, _\n'
               '                updated, baseSubsteps)\n'
               '        HardPerfFinishTest 9 + tangentMode, perfPoint\n'
               '        If Not perfOK Then GoTo Failure')


def test_source(source):
    extra = decode((HERE / 'Telemetry.bas').read_bytes())
    declarations, procedures = extra.split('\n\n', 1)
    source = one(source, 'Option Explicit\n', 'Option Explicit\n\n' + declarations + '\n')
    return source.rstrip() + '\n\n' + procedures


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, required=True)
    target = parser.parse_args().destination.resolve()
    assert target.is_relative_to(STORAGE.resolve()) and target != STORAGE.resolve()
    stock_plan = json.loads((STOCK/'Fixture.json').read_bytes())
    original = (REPO/BOOK).read_bytes()
    assert stock_plan['book_sha256'] == digest(original) == BASE_SHA
    files = {key:(STOCK/key).read_bytes() for key in stock_plan['inputs'] if key.startswith(('tools/', 'Guard-'))}
    assert all(digest(data) == stock_plan['inputs'][name] for name, data in files.items())
    conversion = {SOLVER:lambda source:wrap(source,'Evaluate',solver_body),
                  CONCRETE:lambda source:wrap(source,'ICoupledPointResponse_EvaluatePoint',response_body),
                  TEST:test_source}
    raw_hashes = {}
    for name, instrument in conversion.items():
        raw = (REPO/name).read_bytes()
        raw_hashes[name] = digest(raw)
        files[name] = encode(instrument(decode(raw)))
    for name in ('Stage.py', 'Telemetry.bas', 'Run.ps1', 'Verify.py'):
        files[name] = (HERE/name).read_bytes()
    for name in ('Both.txt', 'Both.Execution.txt'):
        files['Stock/'+name] = (STOCK/'Native'/name).read_bytes()
    manifest = {'workbook': BOOK, 'source_workbook_sha256':BASE_SHA, 'original_sources':raw_hashes,
                'modules':[Path(name).stem for name in conversion],
                'inputs':{name:digest(raw) for name, raw in files.items()}}
    target.mkdir()
    for directory in ('Temp','Native'):
        (target/directory).mkdir()
    files.update({'docs/regression/Diagnostic.xlsm':original, BOOK:original,
                  'Fixture.json':(json.dumps(manifest,indent=2)+'\n').encode()})
    for name, data in files.items():
        destination = target/name
        destination.parent.mkdir(exist_ok=True,parents=True)
        with destination.open('xb') as stream:
            stream.write(data)
    print('HARDSHEAR_PROFILE_INPUTS:', digest(files['Fixture.json']))


if __name__ == '__main__':
    main()
