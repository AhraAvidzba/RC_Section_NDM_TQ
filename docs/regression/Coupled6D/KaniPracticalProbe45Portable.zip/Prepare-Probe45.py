"""Prepare a frozen private workbook snapshot and protect production files."""
from argparse import ArgumentParser
import json
from pathlib import Path
import runpy

HERE=Path(__file__).resolve().parent
W=HERE.parent/'KaniMechanicsBeyond44'
P=runpy.run_path(W/'Prepare-Mechanics44.py')
BOOK,SHADOW,SOLVER,ELASTIC,MODULE,CAPTURED=(P[k] for k in ('BOOK','SHADOW','SOLVER','ELASTIC','MODULE','CAPTURED'))
BOOK_SHA=P['BOOK_SHA']; digest=P['digest']; one=P['one']
PROBE_SHA='27EBB320D1C0521C11E864A4CB522133F03F4B1A5C259ACF054AFCF11E193685'
PLAN_SHA='574C552C713620E89E6BF5BA243C0F65C6EE97491ED68295BF154FEB5938161C'


def prep(repo):
    assert not (HERE/'Preparation.json').exists()
    prior=P['check']()
    assert digest(repo/BOOK)==BOOK_SHA
    assert all(digest(repo/k)==v for k,v in prior['production_source_sha256'].items())
    assert digest(HERE/'ProbeFields.csv')==PROBE_SHA and digest(HERE/'ProbePlan.json')==PLAN_SHA
    fixture=(W/MODULE).read_text(encoding='utf8')
    begin=fixture.index('    Dim rootPath As String')
    end=fixture.index('    Close #tangents:',begin)
    fixture=fixture[:begin]+(HERE/'ProbeMain.bas.txt').read_text(encoding='utf8').rstrip()+'\n'+fixture[end:]
    fixture=one(fixture,'    For i = 1 To 6: forces(i) = 0#: Next i',
                '    Dim plasticIncrement As Boolean, principalSign As Long, substeps As Long\n    For i = 1 To 6: forces(i) = 0#: Next i')
    needle='            Print #stations, row\n            If side = 0 Then'
    fixture=one(fixture,needle,'            Print #stations, row\n'+(HERE/'StationBranch.bas.txt').read_text(encoding='utf8').rstrip()+'\n            If side = 0 Then')
    fixture=one(fixture,'If entries.Count <> 4 Or history.Count <> 43','If entries.Count <> 23 Or history.Count <> 43')
    runner=(W/'Run-Mechanics44.ps1').read_text(encoding='utf-8-sig')
    for old,new in (('Prepare-Mechanics44.py','Prepare-Probe45.py'),('Verify-Mechanics44.py','Verify-Probe45.py'),
                    ('# Изолированная проверка механического поля Kani на отметке 19/512.','# Изолированные знаковые пробы Kani вокруг принятого поля 19/512.'),
                    ('Независимая сверка механического поля Kani не пройдена.','Независимая сверка знаковых проб Kani не пройдена.')):
        runner=one(runner,old,new)
    history=[line for line in (W/'KaniGaugeInput.csv').read_text(encoding='ascii').splitlines() if line.startswith('KANI_B_FIELD;History')]
    assert len(history)==6 and history[-1].startswith('KANI_B_FIELD;History43;')
    probes=(HERE/'ProbeFields.csv').read_text(encoding='ascii').splitlines()
    assert len(probes)==23 and all(len(row.split(';'))==92 for row in history+probes)
    (HERE/'Native').mkdir(exist_ok=True); (HERE/'Temp').mkdir(exist_ok=True)
    solver=(W/SOLVER).read_text(encoding='utf8')+'\n'+(HERE/'ProbeSolver.bas.txt').read_text(encoding='utf8').rstrip()+'\n'
    files={MODULE:fixture.encode('utf8'),SOLVER:solver.encode('utf8'),Path('Run-Probe45.ps1'):runner.encode('utf-8-sig'),
           Path('KaniGaugeInput.csv'):('\r\n'.join(history+probes)+'\r\n').encode('ascii')}
    copies={Path(k):W/k for k in prior['frozen'] if k.startswith('tools/') or k in
            ('KaniV4Input.csv','KaniChartInput.csv',ELASTIC.as_posix(),CAPTURED.as_posix())}
    copies[BOOK]=repo/BOOK; copies[SHADOW]=repo/BOOK
    for path,source in copies.items(): files[path]=source.read_bytes()
    for relative,data in files.items():
        path=HERE/relative
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
    frozen=(set(files)-{SHADOW})|{Path(x) for x in ('ProbeMain.bas.txt','ProbeSolver.bas.txt','StationBranch.bas.txt','ProbeFields.csv','ProbePlan.json',
                    'Plan-Probe45.py','Prepare-Probe45.py','Verify-Probe45.py')}
    receipt={'workbook_sha256':BOOK_SHA,'production_source_sha256':prior['production_source_sha256'],
          'frozen':{x.as_posix():digest(HERE/x) for x in sorted(frozen)}}
    (HERE/'Preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
    return check()


def check():
    receipt=json.loads((HERE/'Preparation.json').read_text(encoding='utf8'))
    assert receipt['workbook_sha256']==BOOK_SHA and digest(HERE/BOOK)==BOOK_SHA
    prior=P['check']()
    assert receipt['production_source_sha256']==prior['production_source_sha256']
    assert all(digest(HERE/k)==v for k,v in receipt['frozen'].items())
    assert digest(HERE/CAPTURED)==receipt['production_source_sha256'][SOLVER.as_posix()]
    assert digest(HERE/ELASTIC)==receipt['production_source_sha256'][ELASTIC.as_posix()]
    assert (HERE/SOLVER).read_text(encoding='utf8')==(W/SOLVER).read_text(encoding='utf8')+'\n'+(HERE/'ProbeSolver.bas.txt').read_text(encoding='utf8').rstrip()+'\n'
    assert receipt['frozen']['ProbeFields.csv']==PROBE_SHA and receipt['frozen']['ProbePlan.json']==PLAN_SHA
    return receipt

if __name__=='__main__':
    ap=ArgumentParser(); ap.add_argument('--repo',type=Path); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    print((check() if a.check else prep(a.repo))['workbook_sha256'],digest(HERE/'Preparation.json'))
