"""Verify the signed native station probes and the fresh base matrices independently."""
from pathlib import Path
import csv, json, runpy

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
M=ROOT/'KaniMechanicsBeyond44'; P=runpy.run_path(HERE/'Prepare-Probe45.py')
old=runpy.run_path(ROOT/'KaniWarpBeyond43/Check-KaniBeyond43.py'); np=old['np']; pk=old['peak']; sec=old['section']; sha=P['digest']
base_arch=np.load(ROOT/'KaniV4Rebase3/RebasedLinearSystems.npz',allow_pickle=False)


def traces(native,labels):
    table={name:np.full((3,184,3),-20,dtype=np.int16) for name in labels}
    matrices={name:np.full((88,88),np.nan) for name in ('Stock','Refined')}
    branch_count=0
    for kind,name,*row in csv.reader((native/'KaniV4Tangents.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        if kind=='BRANCH':
            ip,side,active,sign,count=map(int,row); assert 1<=ip<=184 and side in (-1,0,1)
            tag=table[name][side+1,ip-1]; assert tag[0]==-20 and active in (0,1) and sign in (-1,0,1) and 0<=count<32767
            tag[:]=active,sign,count; branch_count+=1
        elif kind=='MATRIX':
            i=int(row[0]); assert 1<=i<=88 and len(row)==89 and np.isnan(matrices[name][i-1]).all()
            matrices[name][i-1]=np.asarray(row[1:],float)
        else: raise ValueError((kind,name))
    assert branch_count==len(labels)*552 and all(np.isfinite(a).all() for a in matrices.values())
    return table,matrices


def verify():
    receipt=P['check'](); plan=json.loads((HERE/'ProbePlan.json').read_text(encoding='utf8'))
    native=HERE/'Native'; rep=native/'KaniV4.txt'; result=json.loads((native/'KaniV4.txt.ProcessClosure.json').read_text(encoding='utf-8-sig'))
    stop=result['Closure']['FinalState']; owner=json.loads((native/'KaniV4.txt.Ownership.json').read_text(encoding='utf-8-sig'))
    compilation=json.loads((HERE/'docs/regression/CodeUpdate.json').read_text(encoding='utf-8-sig'))
    close=json.loads((native/'CompileClosure.json').read_text(encoding='utf-8-sig'))
    assert result['Passed'] and result['ChildExitCode']==0 and stop['State']==close['State']=='Absent'
    assert stop['PID']==owner['PID'] and stop['StartTicksUTC']==owner['StartTicksUTC'] and owner['VerifiedNewOwner']
    assert compilation['Compiled'] and not compilation['ProductionChanged'] and compilation['ProductionSHA256']==receipt['workbook_sha256']
    assert compilation['WorkbookSHA256']==sha(HERE/P['SHADOW'])
    assert sorted(compilation['Modules'])==['CCoupledElasticState','CCoupledNewtonSolver','modTestKaniStage38']
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in rep.read_text(encoding='utf-8-sig')
    samples=old['trs'](HERE); a,f,p,s,hashes=samples; prev=old['trs'](M)
    labels={'Original43','ReferenceBefore','BaseAccepted','EndAccepted','Restore43',*plan['probes']}; assert set(a)==labels and np.array_equal(p,prev[2])
    for now,arch in (('Original43','History43/Base'),('ReferenceBefore','History43/OffAxis19of512/Probe'),
                     ('BaseAccepted','History43/Committed'),('Restore43','History43/Restore')):
        assert np.array_equal(f[now],prev[1][arch]),now
        assert pk(s[now]-prev[3][arch])<2e-10,now
    assert np.array_equal(f['BaseAccepted'],f['EndAccepted']) and np.array_equal(s['BaseAccepted'],s['EndAccepted'])
    branches,mats=traces(native,labels)
    assert np.array_equal(branches['BaseAccepted'],branches['EndAccepted']) and np.array_equal(branches['Original43'],branches['Restore43'])
    E=base_arch['stock_equality_matrix_MPa']; back=base_arch['resultant_projection']; force={}
    for m,v in mats.items():
        assert pk(v[83:]-E)<5e-10
        assert np.linalg.norm(v[:83,:83])>0
        force[m]=np.vstack((v[:83],back@v[:83]))
    reference='BaseAccepted'; rows0=old['independent'](samples,reference); state0=s[reference]
    reference_q=np.r_[f[reference][2:],f[reference][0]]
    expected_gamma=float(plan['exactGamma']); assert abs(f[reference][1]-expected_gamma)<1e-16
    provenance={}; diagnostics={}; storage={}
    for name,probe in plan['probes'].items():
        rr=old['independent'](samples,name); aq=f[name]; xx=np.r_[aq[2:],aq[0]]
        assert pk(xx[:-1]-np.array(probe['rawField'][:-1]))<3e-16 and abs(xx[-1]-probe['rawField'][-1])<1e-14
        stored=a[name]; equality=np.r_[25600*sec.gauges@aq[2:81],25600*(p@aq[2:]-aq[1])]
        assert len(rr)==89 and len(equality)==5 and pk(equality)<1e-10
        assert abs(aq[1]-expected_gamma-probe['gammaIncrement'])<1e-16
        amplitude=pk(s[name][:,:,:6]-state0[:,:,:6]); assert abs(amplitude/probe['radius']-1)<3e-6
        delta=rr-rows0; dd=xx-reference_q
        current={m:v@dd for m,v in force.items()}
        archived={m:pk(delta-v) for m,v in [(k,np.array(g)) for k,g in probe['archiveDeltas'].items()]}
        diagnostics[name]={'prescribedLoad_N':float(aq[0]*1e5),'increment_N':float(dd[-1]*1e5),'tau_MPa':float(stored[3]),'actualNorm_MPa':pk(rr),
            'withinEquilibriumTolerance':bool(pk(rr)<=stored[3]), 'maxStationStrainDelta':amplitude,'fiveControls_MPa':equality.tolist(),
            'freshMatrixErrors_MPa':{k:pk(delta-v) for k,v in current.items()},'archivedMatrixErrors_MPa':archived,
            'worst_row_fresh_refined':int(np.argmax(abs(delta-current['Refined']))+1),
            'matrixPredictedForceChanges_MPa':{k:v.tolist() for k,v in current.items()},'signedActualDeltaAll89_MPa':delta.tolist(),
            'actualQy_N':float(stored[11]),'actualForceNorm_MPa':pk(rr[83:]),'actualWeakNorm_MPa':pk(rr[:83])}
        storage[name]=(delta, s[name][:,:,6:]-state0[:,:,6:]);
    for name,probe in plan['probes'].items():
        if probe['sign']!=1: continue
        pair=name.removesuffix('Plus'); mn=pair+'Minus'; radius=probe['radius']; plus,plus_stress=storage[name]; minus,minus_stress=storage[mn]
        bp,bm=branches[name],branches[mn]
        active=(bp[:,:,:2]!=bm[:,:,:2]).any(axis=2); substeps=(bp[:,:,2]!=bm[:,:,2])
        branch_only=substeps & ~active
        nonodd=plus_stress+minus_stress
        stress_even_weights=np.linalg.norm(nonodd,axis=2)**2
        sq=float(stress_even_weights.sum())
        peak_station=np.unravel_index(int(np.argmax(stress_even_weights)),stress_even_weights.shape)
        provenance[pair]={'radius':radius,'mechanicalActiveOrPrincipalSignDifferences':int(np.count_nonzero(active)),
            'substepCountDifferencesWithoutBranchLabel':int(np.count_nonzero(branch_only)),
            'evenForceCombined_MPa':pk(plus+minus),'oddForceCombined_MPa':pk(plus-minus),
            'maxSignedDerivativeDisagreement_MPaPerStrain':pk((plus+minus)/radius),
            'evenStationStress_MPa':pk(nonodd),'evenStationStressSquaredFractionAtFlaggedStations':float(stress_even_weights[active].sum()/sq) if sq>0 else 0.,
            'evenStressPeakStation':[int(peak_station[0])-1,int(peak_station[1])+1],
            'evenStressPeakStationChangesBranch':bool(active[peak_station]),
            'flaggedStationsWithSide':[[int(side)-1,int(station)+1] for side,station in zip(*np.where(active))]}
    scaling={}
    for family in plan['dirs']:
        keys=[k for k in provenance if k[:-2]==family and k[-2:] not in ('18',)]
        points=sorted((provenance[k]['radius'], k) for k in keys)
        witnesses=[]
        for (h1,k1),(h2,k2) in zip(points,points[1:]):
            for sign in ('Plus','Minus'):
                a1,b1=storage[k1+sign]; a2,b2=storage[k2+sign]; denom=h2-h1
                witnesses.append({'smaller':k1,'larger':k2,'sign':sign,
                    'linearExtrapolationToZeroForce_MPa':pk((h2*a1-h1*a2)/denom),
                    'linearExtrapolationToZeroStationStress_MPa':pk((h2*b1-h1*b2)/denom),
                    'sameBranchLabels':bool(np.array_equal(branches[k1+sign][:,:,:2],branches[k2+sign][:,:,:2]))})
        scaling[family]=witnesses
    report={'workbook':receipt['workbook_sha256'],'signedProbes':len(diagnostics),'nativeStationStates':len(labels),'stationsPerState':552,
        'compiledProcess':close,'calculationProcess':stop,'all89AndFiveControlsCompared':True,
        'probeDiagnostics':diagnostics,'signedPairs':provenance,'scaling':scaling,'anchoredBaseNorm_MPa':pk(rows0),
        'hashes':{**{path.name:d for path,d in hashes},'KaniV4Tangents.csv':sha(native/'KaniV4Tangents.csv')},
        'scope':'Independent measured response and matrix comparisons at 3 directions. Fixed trial probes never publish their history.'}
    path=HERE/'Verification.json'; path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(path,sha(path),'probes',len(diagnostics), 'target',diagnostics['LoadShape18Plus']['actualNorm_MPa'])

if __name__=='__main__': verify()
