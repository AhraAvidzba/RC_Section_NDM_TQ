"""Plan signed material probes around the exact 19/512 field accepted from history 43."""
from pathlib import Path
import json, runpy
from hashlib import sha256
from scipy.optimize import linprog
from scipy.linalg import null_space

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
ME=ROOT/'KaniMechanicsBeyond44'
S=runpy.run_path(ME/'Solve.py'); O=S['old']; np=S['np']; B=S['B']; E=S['geometry']; pk=S['peak']
measured=O['trs'](ME); history=O['trs'](ROOT/'KaniWarpBeyond43'); P=measured[2]
record=json.loads((ME/'Verification.json').read_text(encoding='utf8')); hit=measured[1]['History43/Committed']
line=next(row.split(';') for row in (ME/'Mechanics44.csv').read_text(encoding='ascii').splitlines() if row.startswith('KANI_B_FIELD;OffAxis19of512;'))
q=np.r_[list(map(float,line[4:-1])),float(line[-1])]; gamma=float(line[3]); assert pk(q[:87]-hit[2:])<3e-16 and abs(q[-1]-hit[0])<1e-14
assert record['outcome']=='EXACT_ACCEPTED' and abs(P@q[:87]-gamma)<3e-17
r=O['independent'](measured,'History43/Committed'); tau=measured[0]['History43/Committed'][3]
practical=18.; force_step=practical/1e5

# Minimal measured-station strain under one archived local material derivative family.
M=S['families']['Rebase38/refined']; scale=np.r_[np.full(83,1e-7),np.full(4,1e-4)]
upper=M[:,:87]*scale/tau; constant=(r+M[:,-1]*force_step)/tau
BV=B[:,:87]*scale/1e-7
J=np.vstack((np.c_[upper,np.zeros(89)],np.c_[-upper,np.zeros(89)],np.c_[BV,-np.ones(len(BV))],np.c_[-BV,-np.ones(len(BV))]))
rhs=np.r_[1-constant,1+constant,np.zeros(2*len(BV))]
C=np.c_[(E[:4,:87]*scale)/1e-3,np.zeros(4)]
sol=linprog(np.r_[np.zeros(87),1.],J,rhs,C,-(E[:4,:87]@q[:87])/1e-3,bounds=[(-1e3,1e3)]*87+[(0,None)],method='highs')
assert sol.success
opt=np.r_[sol.x[:87]*scale,force_step]; assert 4.6e-8<pk(B@opt)<4.9e-8

# Physical direction along the old measured section chart.
raw_start=O['F'][O['gtag'](42,'Nominal1of32')]; raw_end=O['F'][O['gtag'](42,'Nominal5of128')]
sec=np.r_[raw_end[2:]-raw_start[2:],raw_end[0]-raw_start[0]]
sec[83:87]=0.

# The third vector is orthogonal to the first two in station strain space.
# Maximize discrimination among archived derivatives with no imposed load change.
Bm=B[:,:83]; paths=np.stack((B@sec,B@opt)); paths/=np.linalg.norm(paths,axis=1)[:,None]
constraint=np.vstack((E[:4,:83],paths@Bm))
Z=null_space(constraint,rcond=1e-10)
_,sing,Vh=np.linalg.svd(Bm@Z,full_matrices=False); assert min(sing)>1e-5
metric=(Z@Vh.T)/sing
raw_families=np.array([M[:,:83]@metric for M in S['families'].values()]); raw_families-=raw_families.mean(axis=0)
_,sig,V=np.linalg.svd(raw_families.reshape(-1,metric.shape[1]),full_matrices=False)
x=np.r_[metric@V[0],np.zeros(5)]; assert pk(paths@(B@x))<1e-9
if (S['families']['Rebase3/refined']@x)[80]<0: x=-x
axes={'PriorSecant':sec,'LoadShape':opt,'TangentContrast':x}
G=E[:4,:83]
for direction in axes.values(): direction[:83]-=G.T@np.linalg.solve(G@G.T,G@direction[:83])
units={name:d/pk(B@d) for name,d in axes.items()}
np.testing.assert_allclose([pk(B@d) for d in units.values()],1.,rtol=1e-12,atol=1e-12)
for v in units.values(): assert pk(E[:4]@v)<1e-8

fixture=[]; job={}; signs=('Minus','Plus')
def flat(name,xx):
    target=gamma+float(P@(xx[:87]-q[:87])); assert abs(P@xx[:87]-target)<2e-17
    return ';'.join(['KANI_B_FIELD',name,'1',format(target,'.17g'),*[format(p,'.17g') for p in xx[:87]],format(xx[-1],'.17g')])
line[1]='Accepted19of512'; fixture.append(';'.join(line))
for name,u in units.items():
    for radius,level in ([(1e-8,'01'),(2.5e-8,'25'),(5e-8,'50')]+([(force_step/u[-1],'18')] if name=='LoadShape' else [])):
        for sign,di in zip(signs,(-1,1)):
            tag=f'{name}{level}{sign}'; xx=q+di*radius*u
            fixture.append(flat(tag,xx)); job[tag]={'name':name,'level':level,'radius':radius,'sign':di,'rawField':xx.tolist(),
              'lambdaIncrement':float(xx[-1]-q[-1]),'loadIncrement_N':float(1e5*(xx[-1]-q[-1])),
              'gammaIncrement':float(P@(xx[:87]-q[:87])),'archiveDeltas':{k:(a@(xx-q)).tolist() for k,a in S['families'].items()}}
# Central and one-sided local controls for the targeted +18 N shape.
for sign,di in zip(signs,(-1,1)):
    u=units['LoadShape']; radius=1e-10; tag=f'LoadShape00{sign}'; xx=q+di*radius*u
    fixture.append(flat(tag,xx)); job[tag]={'name':'LoadShape','level':'00','radius':radius,'sign':di,'rawField':xx.tolist(),
      'lambdaIncrement':float(xx[-1]-q[-1]),'loadIncrement_N':float(1e5*(xx[-1]-q[-1])),
      'gammaIncrement':float(P@(xx[:87]-q[:87])),'archiveDeltas':{k:(a@(xx-q)).tolist() for k,a in S['families'].items()}}
path=HERE/'ProbeFields.csv'; path.write_bytes(('\r\n'.join(fixture)+'\r\n').encode('ascii'))
receipt={'fixtureSHA256':sha256(path.read_bytes()).hexdigest().upper(),'book':record['workbook'],'referenceVerificationSHA256':S['sha'](ME/'Verification.json'),
      'exactAcceptedQyN':float(q[-1]*1e5),'exactGamma':gamma,'referenceAcceptedField':q.tolist(),'targetIncrementN':practical,
      'loadShapeRadiusAtExactly18N':pk(B@opt),'dirs':{name:x.tolist() for name,x in units.items()},'probes':job,
      'shapeCosine':np.corrcoef(np.array([B@d for d in units.values()])).tolist(),
      'amplitudesLoadAt5e8N':{name:float(5e-8*d[-1]*1e5) for name,d in units.items()}}
result=HERE/'ProbePlan.json'; result.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(path,S['sha'](path),result,S['sha'](result),receipt['amplitudesLoadAt5e8N'],receipt['loadShapeRadiusAtExactly18N'])
