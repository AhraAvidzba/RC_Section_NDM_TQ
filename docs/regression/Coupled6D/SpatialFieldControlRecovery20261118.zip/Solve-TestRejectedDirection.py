"""ДЛЯ ТЕСТОВ: сравнивает ограниченные способы пройти локальный материальный переход при неизменном контроле."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestRestore(repo,root):
    """Восстанавливает собственную историю и точную диагностическую задачу с одной фиксированной мерой."""
    here=Path(__file__).resolve().parent
    helper=run_path(str(here/'TestResolutionSection.py'))
    reference=run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        for a,b in (('Operators.csv','ControlProbe.Operators.csv'),('MVTGaussMixed.csv','ControlProbe.csv')):
            (scratch/a).write_bytes((root/'Native'/b).read_bytes())
        section=helper['TestResolutionSection'](scratch,reference,True)
    history=section.TestInitial()
    for line in (root/'AcceptedHistory.csv').read_text().splitlines():
        row=line.split(';'); torque,q=map(float,row[1:3]); field=np.asarray(row[3:],float)
        result=section.TestEvaluate(field,history,np.array([0.,-396.*q,0.,torque,0.,q]))
        history=result[4]
    rows=[line.split(';') for line in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    unique=lambda key:[row for row in rows if row[0]==key]
    base,=unique('REJECTED_BASE'); field,=unique('REJECTED_FIELD'); projection,=unique('CONTROL_PROJECTION')
    return section,history,np.asarray(field[2:],float),float(base[2]),np.asarray(projection[2:],float),float(base[3])


def TestSolve(section,history,initial,initial_lambda,projection,target,mode,load_projection=0.):
    """Все варианты используют те же 32 итерации, шесть нагрузок, допуски и неизменённую историю."""
    tangent=run_path(str(Path(__file__).with_name('TestClosedASDTangent.py')))['TestGlobalMatrix']
    constant=np.array([0.,0.,0.,10510000.,0.,0.]); direction=np.array([0.,-396.*75000.,0.,0.,0.,75000.])
    field=initial.copy(); lam=initial_lambda; log=[]; n=len(field); last_step=None
    def evaluate(value,factor):
        """Возвращает полный остаток расширенной системы и контроль исходных уравнений."""
        load=constant+factor*direction
        data=section.TestEvaluate(value,history,load)
        control=30000.*(projection@value+load_projection*factor-target)
        residual=np.r_[data[0],control]
        norm=max(float(data[1]),abs(float(control)))
        tolerance=float(5e-7+5e-7*np.max(np.abs((load@section.l)[:-4])))
        return residual,norm,tolerance,data
    def correction(matrix,residual):
        """Решает расширенную систему с точной строкой управления и масштабированием строк и столбцов."""
        augmented=np.zeros((n+1,n+1)); augmented[:n,:n]=matrix
        augmented[:n,n]=-direction@section.l; augmented[n,:n]=30000.*projection
        augmented[n,n]=30000.*load_projection
        row=np.maximum(1e-30,np.max(np.abs(augmented),axis=1)); scaled=augmented/row[:,None]
        col=np.maximum(1e-30,np.max(np.abs(scaled),axis=0)); scaled/=col
        return np.linalg.solve(scaled,-residual/row)/col
    state=evaluate(field,lam); reason='Iteration budget'
    for iteration in range(32):
        log.append({'iteration':iteration,'lambda':lam,'norm_MPa':state[1]})
        if state[1]<=state[2]: reason='Equilibrium'; break
        matrix=tangent(section,field,history)[0]
        if mode=='field_fd':
            delta=2e-9; eye=np.eye(n)
            matrix=np.column_stack([(section.TestEvaluate(field+delta*v,history,constant+lam*direction)[0]-
                                     section.TestEvaluate(field-delta*v,history,constant+lam*direction)[0])/(2.*delta) for v in eye])
        step=correction(matrix,state[0]); accepted=False
        for recovery in range(2 if mode in ('post_tangent','secant') else 1):
            for fraction in 2.**-np.arange(13):
                try: trial=evaluate(field+fraction*step[:n],lam+fraction*step[n])
                except ArithmeticError: continue
                if trial[1]<=trial[2] or trial[1]<state[1]*(1.-1e-4*fraction):
                    field=field+fraction*step[:n]; lam+=fraction*step[n]; state=trial; accepted=True
                    log[-1].update({'fraction':float(fraction),'recovery':recovery}); break
            if accepted: break
            if recovery==0 and mode in ('post_tangent','secant'):
                fraction=1./128.
                sample=evaluate(field+fraction*step[:n],lam+fraction*step[n])
                if mode=='post_tangent':
                    matrix=tangent(section,field+fraction*step[:n],history)[0]
                else:
                    direction_field=fraction*step[:n]
                    change=sample[0][:n]-state[0][:n]+fraction*(direction@section.l)*step[n]
                    matrix+=np.outer(change-matrix@direction_field,direction_field)/(direction_field@direction_field)
                step=correction(matrix,state[0])
        if not accepted: reason='No decreasing step'; break
    success=bool(state[1]<=state[2])
    return {'solved':success,'reason':reason,'lambda':lam,'Qy_N':75000.*lam,'norm_MPa':state[1],
            'tolerance_MPa':state[2],'field':field.tolist(),'steps':log,'physical_capacity_certified':False}


def TestRun(repo,root,output):
    """Сравнивает текущую, соседнюю и секущую линеаризации без подбора материальных параметров."""
    section,history,field,lam,projection,target=TestRestore(repo,root)
    result={}
    for mode in ('local','post_tangent','secant','field_fd'):
        try: record=TestSolve(section,history,field,lam,projection,target,mode)
        except (ArithmeticError,np.linalg.LinAlgError) as error: record={'solved':False,'failure':str(error)}
        result[mode]=record
        output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
        print(mode,record.get('solved'),record.get('Qy_N'),record.get('norm_MPa'),len(record.get('steps',[])),flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True); args=parser.parse_args(); TestRun(args.repo.resolve(),args.root.resolve(),args.out.resolve())
