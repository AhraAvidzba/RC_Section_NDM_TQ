"""ДЛЯ ТЕСТОВ: готовит направленный общий поиск с заранее указанным временем наблюдения всех 96 проб."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root):
    """Меняет только предел наблюдения длинного Trace74; лимиты итераций, проб и точность ядра не меняются."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingASD.py'))['TestStage'](repo,root)
    prep=json.loads((root/'Preparation.json').read_bytes())
    relative='Run-TestWorkingASD.ps1'; code=(root/relative).read_text('utf-8-sig')
    marker="'-MacroArgument1',$caseName,'-TimeoutSeconds','240')"
    assert code.count(marker)==1
    code=code.replace(marker,"'-MacroArgument1',$caseName,'-TimeoutSeconds',$(if ($Phase -eq 'Trace74') {'480'} else {'240'}))")
    (root/relative).write_text(code,encoding='utf-8-sig')
    prep['inputs'][relative]=sha256((root/relative).read_bytes()).hexdigest().upper()
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name]=sha256((root/Path(__file__).name).read_bytes()).hexdigest().upper()
    prep['directed_scope']={'trace':'Trace74','maximum_probe_count':96,'observation_seconds':480,'full_acceptance':False}
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('GENERAL CONTINUATION READY; 96 TOTAL PROBES; TRACE74 WATCHDOG 480 SECONDS')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestStage(args.repo.resolve(),args.root.resolve())
