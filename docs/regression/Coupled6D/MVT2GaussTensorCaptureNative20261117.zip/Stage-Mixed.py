"""Stage a later right-window shear test after a fresh exact Gauss25 preload."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json
import runpy

HERE = Path(__file__).resolve().parent
FIRST = HERE.parent
REPO = HERE.parents[2]
BASE = "71DC4A17F7E648043DF52F423C8419E74A93B96944F9501D48102E04CFDC14C2"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def freeze():
    stage = runpy.run_path(str(FIRST / "Stage-Native.py"))
    substitute = runpy.run_path(str(FIRST / "Stage.py"))["replace_one"]
    archive = (FIRST / "MVT2GaussSpanNative20261117.zip").read_bytes()
    assert digest(archive) == BASE
    book = (REPO / stage["BOOK"]).read_bytes()
    assert digest(book) == BOOK_SHA
    with ZipFile(BytesIO(archive)) as z:
        prep = json.loads(z.read("Preparation.json"))
        inputs = {name: z.read(name) for name in prep["inputs"] if not name.lower().endswith(".xlsm")}
        assert {name: digest(raw) for name,raw in inputs.items()} == {
            name:h for name,h in prep["inputs"].items() if not name.lower().endswith(".xlsm")
        }
        frozen = z.read("Native/MVTGauss.csv")
        prefix = frozen.splitlines(keepends=True)[:-1]
        assert frozen.splitlines()[-1].startswith(b"CASE_FINISHED;MVTGauss;True;")
    inputs["Native/ColdPreload.csv"] = b"".join(prefix)
    inputs["Verify-Preload.py"] = inputs.pop("Verify-Native.py")
    inputs["Verify-Mixed.py"] = (HERE / "Verify-Mixed.py").read_bytes()
    raw = inputs[stage["MACRO"]]
    vb = raw.decode("utf-8-sig").replace("\r\n", "\n")
    vb = substitute(vb, '        Case Else\n            Err.Raise 5, , "Укажите Geometry, MVTStock или MVTGauss."',
                     '        Case "MVTGaussMixed"\n'
                     '            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True)\n'
                     '        Case Else\n            Err.Raise 5, , "Неизвестный режим проверки квадратуры."')
    vb = substitute(vb, "ByVal tracePath As String, ByVal useGauss As Boolean) As Boolean",
                    "ByVal tracePath As String, ByVal useGauss As Boolean, _\n"
                    "        Optional ByVal followMixed As Boolean = False) As Boolean")
    vb = substitute(vb, "    RunMVT2TorqueContinuationTest = True\nEnd Function",
                    "    If followMixed Then\n"
                    "        operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist\n"
                    "        If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _\n"
                    '            Err.Raise 5, , "История чистого кручения перед совместной пробой отличается."\n'
                    '        AddExperimentTraceTest report, tracePath, "MVT_PRELOAD_END;8;10.51"\n'
                    "        RunMVT2TorqueContinuationTest = RunMVT2ShearAfterPreloadTest(operators, concrete, response, solver, shearY, _\n"
                    "            ATOL, RTOL, report, tracePath)\n"
                    "        Exit Function\n"
                    "    End If\n"
                    "    RunMVT2TorqueContinuationTest = True\nEnd Function")
    vb = substitute(vb, "    If followMixed Then\n        operators.GeneralizedDeformation",
                    "    Dim eps0 As Double, kappaX As Double, kappaY As Double, twist As Double\n"
                    "    If followMixed Then\n        operators.GeneralizedDeformation")
    cut_raw = (REPO / "tmp/mvt-cut-ndm/CutTest.txt").read_bytes()
    assert digest(cut_raw) == stage["CUT_SHA"]
    cut = cut_raw.decode("utf-8-sig").replace("\r\n", "\n")
    shear = stage["procedure"](cut, "RunMVT2ShearAfterPreloadTest")
    shear = substitute(shear,
                       "        If Not solved Then\n            solver.DiscardStep\n            Exit Function",
                       "        If Not solved Then\n"
                       "            solver.DiscardStep\n"
                       "            solver.CopyAccepted field\n"
                       "            RecordGaussRetainedTest operators, concrete, response, field, report, tracePath\n"
                       "            Exit Function")
    shear = substitute(shear,
                       "            qy / 1000#, qy / 1000#, actual(4), residual, report, tracePath",
                       "            qy / 1000#, qy / 1000#, actual(4), residual, report, tracePath\n"
                       "        RecordGaussMixedStressesTest operators, concrete, response, phase, report, tracePath")
    emit = stage["procedure"](vb, "RecordGaussStressesTest")
    emit = substitute(emit, "RecordGaussStressesTest", "RecordGaussMixedStressesTest")
    emit = substitute(emit, "ByVal stage As Long", "ByVal phase As String")
    emit = substitute(emit, '"MVT_STRESS;R" & CStr(stage)', '"MVT_SHEAR_STRESS;" & phase')
    retain = """Private Sub RecordGaussRetainedTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByRef report As String, ByVal tracePath As String)
    Dim eps0 As Double, kappaX As Double, kappaY As Double, twist As Double
    operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist
    AddExperimentTraceTest report, tracePath, "MVT_SHEAR_RETAINED;" & ExperimentNumberTest(1000# * twist)
    RecordGaussMixedStressesTest operators, concrete, response, "END", report, tracePath
End Sub"""
    for method in (shear, stage["procedure"](cut,"BisectWangCutTest"), emit, retain):
        vb += "\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n"
        vb += "' Контроль совместного нагружения после подтверждённой истории кручения.\n"
        vb += method + "\n"
    assert vb.count("branch.Initialize solver, wire, 1, 44, 26, ATOL, RTOL, True") == 1
    assert vb.count('BisectWangCutTest(solver, operators, ARM, TORQUE, previousQ, qy, 3, atol, rtol, MAX_ITERATIONS') == 1
    vb.encode("cp1251")
    inputs[stage["MACRO"]] = vb.replace("\n","\r\n").encode("utf-8-sig")
    run = inputs["Run-Native.ps1"].decode("utf-8-sig")
    run = substitute(run, "[ValidateSet('Geometry','MVTStock','MVTGauss')][string]$Case = 'Geometry'",
                     "[ValidateSet('MVTGaussMixed')][string]$Case = 'MVTGaussMixed'")
    run = substitute(run, "$timeout=if ($Case -eq 'Geometry') {'90'} else {'180'}",
                     "$timeout='285'")
    run = substitute(run, "python './Verify-Native.py' --case $Case",
                     "python './Verify-Mixed.py'")
    inputs["Run-Native.ps1"] = run.encode("utf-8")
    inputs[stage["BOOK"]] = book
    return stage, book, inputs


def main(destination):
    stage, book, files = freeze()
    proof = {"source_book_sha256": BOOK_SHA, "native_preload_archive_sha256": BASE,
             "inputs": {name:digest(body) for name,body in sorted(files.items())}}
    if destination is not None:
        root = destination.resolve()
        allowed = (REPO / "tmp", Path("D:/CodexScratch/RC_Section_NDM_TQ").resolve())
        assert any(root != storage and root.is_relative_to(storage) for storage in allowed)
        root.mkdir()
        (root / "Temp").mkdir()
        stage["write_fresh"](root, {**files, "docs/regression/Diagnostic.xlsm":book,
                                   "Preparation.json":(json.dumps(proof,indent=2)+"\n").encode()})
    print(json.dumps(proof,indent=2))


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--stage",type=Path)
    main(parser.parse_args().stage)
