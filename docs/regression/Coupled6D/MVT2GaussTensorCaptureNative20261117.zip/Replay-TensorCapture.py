"""Replay the independent proof of a frozen MVT2 native strain history."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import runpy
from subprocess import check_output
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
REFERENCE_SHA = "A3EC01957BB5D9AC49A11C1D23678FE874D53367524C4F76192C16002212BC09"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
BOOK_COMMIT = "709e7dfa16c192748fc2c6d999925bdbf9948a4c"
TRACE_PROOF = "68A750B102451C5C4891C9A2B391737F18D1A8C188E671B3C8E64BB37BFD5CB3"
TENSOR_PROOF = "104F5BAD5351EDE4BA46A0F390253D2C1A8A1662C00FCE535FC0D90EBC24C5CC"


def digest(data):
    return sha256(data).hexdigest().upper()


def verify(repo):
    manifest = json.loads((ROOT / "Preparation.json").read_bytes())
    assert manifest["source_book_sha256"] == BOOK_SHA
    workbook = "workbook/output/RC_Section_NDM.xlsm"
    assert manifest["inputs"][workbook] == BOOK_SHA
    for rel, expected in manifest["inputs"].items():
        if rel != workbook:
            assert digest((ROOT / rel).read_bytes()) == expected, rel

    reference = repo / "docs/regression/Coupled6D/MVT2GaussMixedNative20261117.zip"
    assert digest(reference.read_bytes()) == REFERENCE_SHA
    name = "Native/MVTGaussMixed.csv"
    trace = (ROOT / name).read_bytes()
    with ZipFile(reference) as archive:
        previous = archive.read(name).splitlines(keepends=True)
    current = trace.splitlines(keepends=True)
    assert current[:-1] == previous[:-1]
    assert all(last.startswith(b"CASE_FINISHED;MVTGaussMixed;True;") for last in (current[-1], previous[-1]))

    current_book = repo / workbook
    input_book = current_book.read_bytes() if current_book.is_file() else b""
    if digest(input_book) != BOOK_SHA:
        input_book = check_output(["git", "-C", str(repo), "show", f"{BOOK_COMMIT}:{workbook}"])
    assert digest(input_book) == BOOK_SHA
    proof_book = ROOT / workbook
    proof_book.parent.mkdir(parents=True, exist_ok=True)
    with proof_book.open("xb") as handle:
        handle.write(input_book)
    try:
        runpy.run_path(str(ROOT / "Verify-Mixed.py"))["main"]()
    finally:
        proof_book.unlink()
    assert digest((ROOT / "VerificationMVTGaussMixed.json").read_bytes()) == TRACE_PROOF
    runpy.run_path(str(ROOT / "Verify-Tensors.py"), run_name="__main__")
    assert digest((ROOT / "VerificationMVTGaussTensors.json").read_bytes()) == TENSOR_PROOF
    print("MVT2 FIXED HISTORY NATIVE CAPTURE PASS", TENSOR_PROOF)


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    verify(parser.parse_args().repo.resolve())
