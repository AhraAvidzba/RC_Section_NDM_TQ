"""Pack the native central-strain proof without the Excel binaries."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
NATIVE = Path("D:/CodexScratch/RC_Section_NDM_TQ/MVTGauss25Tensors")


def digest(data):
    return sha256(data).hexdigest().upper()


def contents():
    manifest = json.loads((NATIVE / "Preparation.json").read_bytes())
    inputs = {name: h for name, h in manifest["inputs"].items() if not name.endswith(".xlsm")}
    files = set(inputs) | {"Preparation.json", "Compile.log", "CompileClosure.json", "docs/regression/CodeUpdate.json",
                           "VerificationMVTGaussMixed.json", "VerificationMVTGaussTensors.json"}
    files |= {f"Native/{item.name}" for item in (NATIVE / "Native").iterdir() if item.is_file()}
    for name in sorted(files):
        raw = (NATIVE / name).read_bytes()
        if name in inputs:
            assert digest(raw) == inputs[name]
        yield name, raw
    for name in ("Replay-TensorCapture.py", "Pack-TensorCapture.py", "Stage-Tensors.py", "Stage-Mixed.py",
                 "TensorCaptureTests.txt"):
        yield name, (HERE / name).read_bytes()


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    target = parser.parse_args().archive
    with ZipFile(target, "x", ZIP_DEFLATED, compresslevel=9) as output:
        for name, raw in contents():
            output.writestr(ZipInfo(name), raw, ZIP_DEFLATED, compresslevel=9)
    print(target.name, digest(target.read_bytes()))
