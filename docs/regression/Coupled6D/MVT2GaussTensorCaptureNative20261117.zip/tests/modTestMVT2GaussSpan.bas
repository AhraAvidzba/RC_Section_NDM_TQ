﻿Attribute VB_Name = "modTestMVT2GaussSpan"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет квадратуру Гаусса в изолированной книге и сохраняет исходные поля.
Public Function RunTestMVT2GaussSpan(ByVal caseKey As String) As String
    Dim report As String, tracePath As String, completed As Boolean, started As Double, elapsed As Double
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для сравнения квадратуры нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\MVT2GaussSpan.csv"
    started = Timer
    Select Case caseKey
        Case "Geometry"
            RunGaussGeometryTest "SquareStock", False, False, report, tracePath
            RunGaussGeometryTest "SquareGauss", False, True, report, tracePath
            RunGaussGeometryTest "HoleStock", True, False, report, tracePath
            RunGaussGeometryTest "HoleGauss", True, True, report, tracePath
            completed = True
        Case "MVTStock", "MVTGauss"
            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, caseKey = "MVTGauss")
        Case "MVTGaussMixed"
            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True)
        Case Else
            Err.Raise 5, , "Неизвестный режим проверки квадратуры."
    End Select
    elapsed = Timer - started
    If elapsed < 0# Then elapsed = elapsed + 86400#
    AddExperimentTraceTest report, tracePath, "CASE_FINISHED;" & caseKey & ";" & CStr(completed) & ";" & ExperimentNumberTest(elapsed)
    RunTestMVT2GaussSpan = report & "TOTAL_MVT2_GAUSS_SPAN: passed=1; failed=0; target_reached=" & CStr(completed)
    Exit Function
Failed:
    RunTestMVT2GaussSpan = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description & vbCrLf
    RunTestMVT2GaussSpan = RunTestMVT2GaussSpan & "TOTAL_MVT2_GAUSS_SPAN: passed=0; failed=1"
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Использует замкнутое отверстие 4x4 мм внутри центрального интервала сплайна.
Private Function BuildGaussTestSection(ByVal withHole As Boolean) As CSectionModel
    If Not withHole Then
        Set BuildGaussTestSection = BuildBareMVT2SquareTest()
        Exit Function
    End If
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion, concrete As CConcreteRegion
    Set concrete = query.SubtractContainedRegion(query.RectangleRegion(0#, 0#, 240#, 240#), _
                                                 query.RectangleRegion(13#, -20#, 4#, 4#))
    region.Initialize concrete
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Set BuildGaussTestSection = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет действительные узлы и напряжения при чистом кручении и смешанной нагрузке.
Private Sub RunGaussGeometryTest(ByVal caseKey As String, ByVal withHole As Boolean, ByVal useGauss As Boolean, _
        ByRef report As String, ByVal tracePath As String)
    Dim operators As New CCoupledElasticState, frame As New CSectionNumericalFrame, section As CSectionModel
    Dim area As Double, lengthScale As Double, spans As Long, point As Long, component As Long, testLoad As Long
    Dim x As Double, y As Double, weight As Double, row As String, loadValue As Variant
    Dim deformation() As Double, forces() As Double, stress() As Double
    spans = 1: If withHole Then spans = 3
    Set section = BuildGaussTestSection(withHole)
    frame.Initialize section
    operators.PrepareModel section, 30000#, 0.2, spans, spans, 5, useFullSpanGauss5:=useGauss
    operators.CopyResultantResidualScales area, lengthScale
    AddExperimentTraceTest report, tracePath, "GEO_SETUP;" & caseKey & ";" & CStr(spans) & ";" & _
        CStr(operators.ConcretePointCount) & ";" & CStr(operators.PointCount) & ";" & ExperimentNumberTest(frame.OriginX) & ";" & _
        ExperimentNumberTest(frame.OriginY) & ";" & ExperimentNumberTest(area) & ";" & ExperimentNumberTest(lengthScale)
    For point = 1 To operators.PointCount
        operators.Point point, x, y, weight
        AddExperimentTraceTest report, tracePath, "GEO_POINT;" & caseKey & ";" & CStr(point) & ";" & _
            ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(weight)
    Next point
    For testLoad = 1 To 2
        If testLoad = 1 Then
            loadValue = Array(0#, 0#, 0#, 262750#, 0#, 0#)
        Else
            loadValue = Array(-3600#, -95000#, 73500#, 262750#, 830#, -1020#)
        End If
        If Not operators.Solve(CDbl(loadValue(0)), CDbl(loadValue(1)), CDbl(loadValue(2)), CDbl(loadValue(3)), _
                CDbl(loadValue(4)), CDbl(loadValue(5)), deformation, forces, stress) Then _
            Err.Raise 5, , "Не подтверждено упругое равновесие при проверке квадратуры."
        row = "GEO_LOAD;" & caseKey & ";" & CStr(testLoad) & ";" & ExperimentNumberTest(1000# * deformation(4))
        For component = 0 To 5: row = row & ";" & ExperimentNumberTest(CDbl(loadValue(component))): Next component
        For component = 1 To 6: row = row & ";" & ExperimentNumberTest(forces(component)): Next component
        AddExperimentTraceTest report, tracePath, row
        For point = 1 To operators.PointCount
            row = "GEO_STRESS;" & caseKey & ";" & CStr(testLoad) & ";" & CStr(point)
            For component = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(component, point)): Next component
            AddExperimentTraceTest report, tracePath, row
        Next point
    Next testLoad
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет координаты и веса бетона и поправок стали для независимых интегралов.
Private Sub RecordGaussPointsTest(ByVal section As CSectionModel, ByVal operators As CCoupledElasticState, _
        ByRef report As String, ByVal tracePath As String)
    Dim frame As New CSectionNumericalFrame, area As Double, lengthScale As Double
    Dim p As Long, i As Long, x As Double, y As Double, weight As Double, direction(1 To 6) As Double, row As String
    frame.Initialize section
    operators.CopyResultantResidualScales area, lengthScale
    AddExperimentTraceTest report, tracePath, "MVT_GEOM;" & CStr(operators.ConcretePointCount) & ";" & _
        CStr(operators.PointCount) & ";" & CStr(operators.DegreeCount) & ";" & ExperimentNumberTest(frame.OriginX) & ";" & _
        ExperimentNumberTest(frame.OriginY) & ";" & ExperimentNumberTest(area) & ";" & ExperimentNumberTest(lengthScale)
    For p = 1 To operators.PointCount
        operators.Point p, x, y, weight
        If p > operators.ConcretePointCount Then operators.SteelProjection p, direction
        row = "MVT_POINT;" & CStr(p) & ";" & ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(weight)
        For i = 1 To 6: row = row & ";" & ExperimentNumberTest(direction(i)): Next i
        AddExperimentTraceTest report, tracePath, row
    Next p
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет принятые центральные напряжения бетона и отдельно напряжение стержня.
Private Sub RecordGaussStressesTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByVal stage As Long, ByRef report As String, ByVal tracePath As String)
    Dim p As Long, i As Long, row As String, values(1 To 6) As Double, steelStress As Double
    For p = 1 To operators.PointCount
        concrete.CopyAcceptedStress p, values
        steelStress = 0#
        If p > operators.ConcretePointCount Then steelStress = response.AcceptedSteelStress(p)
        row = "MVT_STRESS;R" & CStr(stage) & ";" & CStr(p)
        For i = 1 To 6: row = row & ";" & ExperimentNumberTest(values(i)): Next i
        row = row & ";" & ExperimentNumberTest(steelStress)
        AddExperimentTraceTest report, tracePath, row
    Next p
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function RunMVT2TorqueContinuationTest(ByVal quadraturePoints As Long, ByRef report As String, _
        ByVal tracePath As String, ByVal useGauss As Boolean, _
        Optional ByVal followMixed As Boolean = False) As Boolean
    Const EC As Double = 30000#, NU As Double = 0.2, PEAK As Double = 0.0022, FT As Double = 2.10667357864589
    Const ATOL As Double = 0.0000005, RTOL As Double = 0.0000005
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim branch As New CCoupledLoadContinuation, wire As New CLoadPathVector
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#)
    nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, EC, NU, 1, 1, quadraturePoints, transverse, steelModels:=steel, useFullSpanGauss5:=useGauss
    If operators.ConcretePointCount <> quadraturePoints ^ 2 Or _
            operators.PointCount <> operators.ConcretePointCount + 20 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура уточнённого кручения MVT2 не совпала с контрольной."
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, FT, PEAK, gt, gc, True
    wire.Initialize 0#, 0#, 0#, 0#, 0#, 0#, 0#, 1000000#, 0#, 0#, 0#, 0#
    branch.Initialize solver, wire, 1, 44, 26, ATOL, RTOL, True
    AddExperimentTraceTest report, tracePath, "MVT2_ADAPT_SETUP;" & CStr(quadraturePoints) & ";" & _
        ExperimentNumberTest(fc) & ";" & ExperimentNumberTest(FT) & ";" & ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc)
    RecordGaussPointsTest section, operators, report, tracePath
    AddExperimentTraceTest report, tracePath, "MVT_BUDGET;1;44;26;5e-7;5e-7"
    Dim targets As Variant, target As Variant, stage As Long, reached As Double, previousCount As Long, item As Long
    Dim solved As Boolean, meta As CResultMeta, expected(1 To 6) As Double, trace As CCoupledLoadTrace
    Dim fraction As Double, acceptedLambda As Double, field() As Double, actual() As Double, residual As Double
    Dim shearX() As Double, shearY() As Double
    operators.MeanShearProjections shearX, shearY
    targets = Array(0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 10.51)
    For Each target In targets
        stage = stage + 1
        solved = branch.Advance(CDbl(target))
        Set meta = branch.ResultMeta
        reached = branch.AcceptedLambda
        AddExperimentTraceTest report, tracePath, "MVT2_ADAPT_TRIAL;R" & CStr(stage) & ";" & _
            ExperimentNumberTest(CDbl(target)) & ";" & ExperimentNumberTest(reached) & ";" & CStr(solved) & ";" & _
            CStr(meta.InternalStatus) & ";" & CStr(meta.ResultCode) & ";" & meta.DiagnosticDetails
        AddExperimentTraceTest report, tracePath, "MVT_WORK;R" & CStr(stage) & ";" & _
            CStr(branch.RejectedAttempts)
        Set trace = branch.SavedTrace
        If branch.SavedFieldCount <> trace.Count Then Err.Raise 5, , "Не согласованы история и траектория кручения."
        For item = previousCount + 1 To trace.Count
            trace.ReadPoint item, fraction, acceptedLambda
            If fraction <> 1# Then Err.Raise 5, , "Изменилась заданная чисто крутящая траектория."
            AddExperimentTraceTest report, tracePath, "MVT2_ADAPT_HISTORY;R" & CStr(stage) & ";" & CStr(item) & _
                ";" & ExperimentNumberTest(acceptedLambda)
        Next item
        previousCount = trace.Count
        If previousCount > 0 Then
            branch.CopyAccepted field, actual
            expected(4) = reached * 1000000#
            residual = operators.ResultantResidualNorm(actual, expected)
            If residual > 0.000005 Then Err.Raise 5, , "Контроль усилий уточнённого кручения не подтверждён."
            RecordWangMVT2StateTest operators, concrete, response, field, actual, shearY, "R" & CStr(stage), _
                CDbl(target), reached, actual(4), residual, report, tracePath
            RecordGaussStressesTest operators, concrete, response, stage, report, tracePath
        End If
        If Not solved Then Exit Function
        If reached <> CDbl(target) Then Err.Raise 5, , "Не подтверждена фактическая запрошенная цель кручения."
    Next target
    Dim eps0 As Double, kappaX As Double, kappaY As Double, twist As Double
    If followMixed Then
        operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist
        If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _
            Err.Raise 5, , "История чистого кручения перед совместной пробой отличается."
        WriteMVT2TorqueTensorsTest operators, concrete, branch, EC, NU, fc, FT, PEAK, gt, gc, tracePath
        AddExperimentTraceTest report, tracePath, "MVT_PRELOAD_END;8;10.51"
        RunMVT2TorqueContinuationTest = RunMVT2ShearAfterPreloadTest(operators, concrete, response, solver, shearY, _
            ATOL, RTOL, report, tracePath)
        Exit Function
    End If
    RunMVT2TorqueContinuationTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function BuildBareMVT2SquareTest() As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("MVT2_Outer", Array(Array(-120#, -120#, 240#, 240#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Set BuildBareMVT2SquareTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function BuildWangMVT2SectionTest(ByRef transverse As CTransverseRebarLayout, ByRef steel As Object) As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("MVT2_Outer", Array(Array(-120#, -120#, 240#, 240#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Dim xSign As Long, ySign As Long
    For xSign = -1 To 1 Step 2
        For ySign = -1 To 1 Step 2
            section.AddRebarElement 84# * xSign, 84# * ySign, 16#, GEOM_PI * 64#, "MVT2_LONG"
        Next ySign
    Next xSign
    Set transverse = New CTransverseRebarLayout
    transverse.AddContourGroup section, "MVT2_HOOP", vbNullString, 8#, 60#, 20#, "MVT2_HOOP"
    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "MVT2_LONG", ExperimentBilinearSteelTest(200000#, 498#, 0#)
    steel.Add "MVT2_HOOP", ExperimentBilinearSteelTest(200000#, 450#, 0#)
    Set BuildWangMVT2SectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Sub InitializeExperimentSolverTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal center As CCoupledReinforcedResponse, ByVal steel As Object, _
        ByVal ec As Double, ByVal nu As Double, ByVal fc As Double, ByVal ft As Double, ByVal peakStrain As Double, _
        ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean)
    Const LOCALIZATION_LENGTH As Double = 125# ' мм, принятое значение во всех трёх сопоставлениях.
    Dim pointCount As Long: pointCount = operators.PointCount
    Dim fc0 As Double: fc0 = 0.6 * fc ' Начальная прочность сжатия в материальной модели.
    concrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    center.Initialize operators, concrete, steel
    If Not spatialHistory Then
        solver.Initialize operators, center, ec
        Exit Sub
    End If
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    plusConcrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, center, ec, plusSide, minusSide
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function ExperimentBilinearSteelTest(ByVal modulus As Double, ByVal strength As Double, ByVal hardening As Double) As CCoupledSteelModel
    Dim steel As New CCoupledSteelModel
    steel.Initialize modulus, strength, strength, hardening, hardening, 0.05, 0.05
    Set ExperimentBilinearSteelTest = steel
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Sub RecordWangMVT2StateTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByRef resultants() As Double, ByRef shearY() As Double, _
        ByVal stage As String, ByVal requested As Double, ByVal reached As Double, ByVal torque As Double, ByVal residual As Double, _
        ByRef report As String, ByVal tracePath As String)
    Const LONG_YIELD As Double = 498#
    Const HOOP_YIELD As Double = 450#
    Dim point As Long, i As Long, gamma As Double, eps0 As Double, kappaX As Double, kappaY As Double, twist As Double
    Dim maxLong As Double, maxHoop As Double, atLong As Long, atHoop As Long, steelStress As Double
    Dim maximumTension As Double, maximumCompression As Double, tension As Double, compression As Double
    Dim minPrincipal As Double, maxPrincipal As Double, trace As Double, q As Double, high As Double, mid As Double, low As Double
    Dim stress(1 To 6) As Double
    operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist
    For i = 1 To UBound(shearY): gamma = gamma + shearY(i) * field(i): Next i
    For point = 1 To operators.PointCount
        If point <= operators.ConcretePointCount Then
            concrete.AcceptedPointDamage point, tension, compression
            maximumTension = GeomMax(maximumTension, tension): maximumCompression = GeomMax(maximumCompression, compression)
            concrete.CopyAcceptedStress point, stress
            CoupledStressInvariants stress, trace, q, high, mid, low
            If point = 1 Or low < minPrincipal Then minPrincipal = low
            If point = 1 Or high > maxPrincipal Then maxPrincipal = high
        Else
            steelStress = Abs(response.AcceptedSteelStress(point))
            If operators.TransverseGroupAt(point) > 0 Then
                maxHoop = GeomMax(maxHoop, steelStress)
                If steelStress >= HOOP_YIELD * (1# - 0.00000001) Then atHoop = atHoop + 1
            Else
                maxLong = GeomMax(maxLong, steelStress)
                If steelStress >= LONG_YIELD * (1# - 0.00000001) Then atLong = atLong + 1
            End If
        End If
    Next point
    AddExperimentTraceTest report, tracePath, "MVT2_STATE;" & stage & ";" & ExperimentNumberTest(requested) & ";" & _
        ExperimentNumberTest(reached) & ";" & ExperimentNumberTest(resultants(1) / 1000#) & ";" & ExperimentNumberTest(resultants(2) / 1000000#) & ";" & _
        ExperimentNumberTest(resultants(3) / 1000000#) & ";" & ExperimentNumberTest(torque / 1000000#) & ";" & _
        ExperimentNumberTest(resultants(5) / 1000#) & ";" & ExperimentNumberTest(resultants(6) / 1000#) & ";" & _
        ExperimentNumberTest(eps0) & ";" & ExperimentNumberTest(1000# * kappaX) & ";" & ExperimentNumberTest(1000# * kappaY) & ";" & _
        ExperimentNumberTest(1000# * twist) & ";" & ExperimentNumberTest(gamma) & ";" & ExperimentNumberTest(maxLong) & ";" & _
        ExperimentNumberTest(maxHoop) & ";" & CStr(atLong) & ";" & CStr(atHoop) & ";" & ExperimentNumberTest(maximumTension) & ";" & _
        ExperimentNumberTest(maximumCompression) & ";" & ExperimentNumberTest(minPrincipal) & ";" & _
        ExperimentNumberTest(maxPrincipal) & ";" & ExperimentNumberTest(residual)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Function ExperimentNumberTest(ByVal value As Double) As String
    ExperimentNumberTest = Trim$(Str$(value))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вспомогательная процедура архивного контрольного сценария MVT2.
Private Sub AddExperimentTraceTest(ByRef report As String, ByVal path As String, ByVal row As String)
    report = report & row & vbCrLf
    If Len(path) = 0 Then Exit Sub
    Dim file As Integer: file = FreeFile
    Open path For Append As #file
    Print #file, row
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль совместного нагружения после подтверждённой истории кручения.
Private Function RunMVT2ShearAfterPreloadTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByVal solver As CCoupledNewtonSolver, ByRef shearY() As Double, _
        ByVal atol As Double, ByVal rtol As Double, ByRef report As String, ByVal tracePath As String) As Boolean
    Const TORQUE As Double = 10510000#, ARM As Double = 330#, MAX_ITERATIONS As Long = 26
    Dim goals As Variant, i As Long, qy As Double, previousQ As Double, solved As Boolean, phase As String
    Dim expected(1 To 6) As Double, field() As Double, actual() As Double, residual As Double, meta As CResultMeta
    goals = Array(5000#, 6250#, 7500#, 8750#, 10000#, 11250#, 11562.5, 11875#, 12187.5, 12500#, _
        12812.5, 13125#, 13437.5, 13750#, 14062.5, 14375#, 14687.5, 15000#)
    expected(4) = TORQUE
    For i = LBound(goals) To UBound(goals)
        qy = goals(i): expected(6) = qy: expected(2) = -ARM * qy
        phase = "S" & CStr(i + 1)
        solved = solver.TryStep(0#, expected(2), 0#, TORQUE, 0#, qy, atol, rtol, MAX_ITERATIONS)
        Set meta = solver.ResultMeta
        If Not solved And meta.InternalStatus = rsNumericalFailure Then
            AddExperimentTraceTest report, tracePath, "MVT2_CUT_DIRECT_STOP;" & phase & ";" & meta.DiagnosticDetails
            solver.DiscardStep
            solved = BisectWangCutTest(solver, operators, ARM, TORQUE, previousQ, qy, 3, atol, rtol, MAX_ITERATIONS, _
                phase, report, tracePath)
            Set meta = solver.ResultMeta
        End If
        AddExperimentTraceTest report, tracePath, "MVT2_CUT_TRIAL;" & phase & ";" & ExperimentNumberTest(TORQUE) & ";" & _
            ExperimentNumberTest(qy) & ";" & ExperimentNumberTest(expected(2)) & ";" & CStr(solved) & ";" & _
            CStr(meta.InternalStatus) & ";" & CStr(meta.ResultCode) & ";" & meta.DiagnosticDetails
        If Not solved Then
            solver.DiscardStep
            solver.CopyAccepted field
            RecordGaussRetainedTest operators, concrete, response, field, report, tracePath
            Exit Function
        End If
        solver.CopyTrial field, actual
        residual = operators.ResultantResidualNorm(actual, expected)
        If residual > 0.000005 Then Err.Raise 5, , "Контроль шести усилий на правом срезе не подтверждён."
        solver.AcceptStep
        previousQ = qy
        RecordWangMVT2StateTest operators, concrete, response, field, actual, shearY, phase, _
            qy / 1000#, qy / 1000#, actual(4), residual, report, tracePath
        RecordGaussMixedStressesTest operators, concrete, response, phase, report, tracePath
        WriteMVT2ShearTensorsTest operators, concrete, field, phase, TORQUE, qy, tracePath
    Next i
    RunMVT2ShearAfterPreloadTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль совместного нагружения после подтверждённой истории кручения.
Private Function BisectWangCutTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal armMm As Double, ByVal torque As Double, ByVal lowerQ As Double, ByVal upperQ As Double, ByVal depth As Long, _
        ByVal atol As Double, ByVal rtol As Double, ByVal maximum As Long, ByVal phase As String, _
        ByRef report As String, ByVal tracePath As String) As Boolean
    Dim midQ As Double, solved As Boolean, meta As CResultMeta
    midQ = (lowerQ + upperQ) / 2#
    solved = solver.TryStep(0#, -armMm * midQ, 0#, torque, 0#, midQ, atol, rtol, maximum)
    If Not solved Then
        Set meta = solver.ResultMeta
        If depth <= 1 Or meta.InternalStatus <> rsNumericalFailure Then Exit Function
        solver.DiscardStep
        If Not BisectWangCutTest(solver, operators, armMm, torque, lowerQ, midQ, depth - 1, atol, rtol, maximum, _
                phase, report, tracePath) Then Exit Function
    End If
    Dim field() As Double, actual() As Double, expected(1 To 6) As Double, residual As Double, i As Long, wire As String
    expected(2) = -armMm * midQ: expected(4) = torque: expected(6) = midQ
    solver.CopyTrial field, actual
    residual = operators.ResultantResidualNorm(actual, expected)
    If residual > 0.000005 Then Err.Raise 5, , "Невязка промежуточной ступени MVT2 превышает допуск."
    For i = 1 To 6: wire = wire & ";" & ExperimentNumberTest(actual(i)): Next i
    solver.AcceptStep
    AddExperimentTraceTest report, tracePath, "MVT2_CUT_INSERTED;" & phase & ";" & ExperimentNumberTest(midQ) & _
        ";" & ExperimentNumberTest(residual) & wire
    solved = solver.TryStep(0#, -armMm * upperQ, 0#, torque, 0#, upperQ, atol, rtol, maximum)
    If Not solved And depth > 1 Then
        Set meta = solver.ResultMeta
        If meta.InternalStatus = rsNumericalFailure Then
            solver.DiscardStep
            solved = BisectWangCutTest(solver, operators, armMm, torque, midQ, upperQ, depth - 1, atol, rtol, maximum, _
                phase, report, tracePath)
        End If
    End If
    BisectWangCutTest = solved
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль совместного нагружения после подтверждённой истории кручения.
Private Sub RecordGaussMixedStressesTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByVal phase As String, ByRef report As String, ByVal tracePath As String)
    Dim p As Long, i As Long, row As String, values(1 To 6) As Double, steelStress As Double
    For p = 1 To operators.PointCount
        concrete.CopyAcceptedStress p, values
        steelStress = 0#
        If p > operators.ConcretePointCount Then steelStress = response.AcceptedSteelStress(p)
        row = "MVT_SHEAR_STRESS;" & phase & ";" & CStr(p)
        For i = 1 To 6: row = row & ";" & ExperimentNumberTest(values(i)): Next i
        row = row & ";" & ExperimentNumberTest(steelStress)
        AddExperimentTraceTest report, tracePath, row
    Next p
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Контроль совместного нагружения после подтверждённой истории кручения.
Private Sub RecordGaussRetainedTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByRef report As String, ByVal tracePath As String)
    Dim eps0 As Double, kappaX As Double, kappaY As Double, twist As Double
    operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist
    AddExperimentTraceTest report, tracePath, "MVT_SHEAR_RETAINED;" & ExperimentNumberTest(1000# * twist)
    RecordGaussMixedStressesTest operators, concrete, response, "END", report, tracePath
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Восстанавливает центральную историю чистого кручения по всем принятым полям.
' В основных точках проверяет повтор по фактическим принятым напряжениям.
Private Sub WriteMVT2TorqueTensorsTest(ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal branch As CCoupledLoadContinuation, _
        ByVal modulus As Double, ByVal poisson As Double, ByVal fc As Double, ByVal ft As Double, _
        ByVal peak As Double, ByVal gt As Double, ByVal gc As Double, ByVal tracePath As String)
    Dim replay As New CCoupledConcreteResponse, material As ICoupledPointResponse
    replay.Initialize operators.PointCount, modulus, poisson, 0.6 * fc, fc, ft, peak, gt, gc, 125#
    Set material = replay
    Dim path As String: path = tracePath & ".Tensor.csv"
    Dim handle As Integer: handle = FreeFile
    Open path For Output As #handle
    Print #handle, "MODEL;" & ExperimentNumberTest(modulus) & ";" & ExperimentNumberTest(poisson) & ";" & _
        ExperimentNumberTest(fc) & ";" & ExperimentNumberTest(ft) & ";" & ExperimentNumberTest(peak) & ";" & _
        ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc) & ";125"
    PrintMVT2CurveTest concrete, modulus, False, "TENSION", handle
    PrintMVT2CurveTest concrete, modulus, True, "COMPRESSION", handle
    Dim trace As CCoupledLoadTrace: Set trace = branch.SavedTrace
    Dim item As Long, point As Long, fraction As Double, lambda As Double, field() As Double, component As Long
    Dim strain(1 To 6) As Double, stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim reference(1 To 6) As Double, row As String
    For item = 1 To trace.Count
        trace.ReadPoint item, fraction, lambda
        If fraction <> 1# Then Err.Raise 5, , "Неверная принятая доля начального кручения."
        branch.CopySavedField item, field
        Print #handle, "FRAME;R" & CStr(item) & ";" & ExperimentNumberTest(lambda * 1000000#) & ";0"
        For point = 1 To operators.PointCount
            operators.PointStrain point, field, strain
            If material.EvaluatePoint(point, strain, stress, tangent, ctmStressOnly) <> sfcNone Then _
                Err.Raise 5, , "Материал не воспроизвёл принятое поле кручения."
            If item = trace.Count Then
                concrete.CopyAcceptedStress point, reference
                For component = 1 To 6
                    If Abs(stress(component) - reference(component)) > 0.000000001 Then _
                        Err.Raise 5, , "Конечное напряжение кручения в повторе отличается от принятого."
                Next component
            End If
            PrintMVT2TensorTest handle, point, strain, stress
        Next point
        material.AcceptTrial
    Next item
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет центральный срез после принятия равновесного шага сдвига.
Private Sub WriteMVT2ShearTensorsTest(ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByRef field() As Double, ByVal phase As String, _
        ByVal torque As Double, ByVal qy As Double, ByVal tracePath As String)
    Dim handle As Integer: handle = FreeFile
    Open tracePath & ".Tensor.csv" For Append As #handle
    Print #handle, "FRAME;" & phase & ";" & ExperimentNumberTest(torque) & ";" & ExperimentNumberTest(qy)
    Dim point As Long, strain(1 To 6) As Double, stress(1 To 6) As Double
    For point = 1 To operators.PointCount
        operators.PointStrain point, field, strain
        concrete.CopyAcceptedStress point, stress
        PrintMVT2TensorTest handle, point, strain, stress
    Next point
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает шесть инженерных деформаций и шесть сопряжённых напряжений.
Private Sub PrintMVT2TensorTest(ByVal handle As Integer, ByVal point As Long, _
        ByRef strain() As Double, ByRef stress() As Double)
    Dim row As String: row = "POINT;" & CStr(point)
    Dim component As Long
    For component = 1 To 6: row = row & ";" & ExperimentNumberTest(strain(component)): Next component
    For component = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(component)): Next component
    Print #handle, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет фактические точки огибающей из того же объекта материала.
Private Sub PrintMVT2CurveTest(ByVal concrete As CCoupledConcreteResponse, ByVal modulus As Double, _
        ByVal compression As Boolean, ByVal name As String, ByVal handle As Integer)
    Dim strain() As Double, stress() As Double, point As Long
    concrete.CopyCalibrationPoints compression, modulus, strain, stress
    For point = LBound(strain) To UBound(strain)
        Print #handle, "CURVE;" & name & ";" & ExperimentNumberTest(strain(point)) & ";" & ExperimentNumberTest(stress(point))
    Next point
End Sub
