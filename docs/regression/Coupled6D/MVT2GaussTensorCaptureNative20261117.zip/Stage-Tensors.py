"""Prepare a private deterministic rerun with a central accepted-tensor capture."""

from argparse import ArgumentParser
import json
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
BASE = runpy.run_path(str(HERE / "Stage-Mixed.py"))


def stage_tensors(root):
    stage, book, files = BASE["freeze"]()
    replace = runpy.run_path(str(HERE.parent / "Stage.py"))["replace_one"]
    source_path = stage["MACRO"]
    vb = files[source_path].decode("utf-8-sig").replace("\r\n", "\n")
    vb = replace(vb, '        AddExperimentTraceTest report, tracePath, "MVT_PRELOAD_END;8;10.51"',
                 "        WriteMVT2TorqueTensorsTest operators, concrete, branch, EC, NU, fc, FT, PEAK, gt, gc, tracePath\n"
                 '        AddExperimentTraceTest report, tracePath, "MVT_PRELOAD_END;8;10.51"')
    vb = replace(vb, '        RecordGaussMixedStressesTest operators, concrete, response, phase, report, tracePath',
                 '        RecordGaussMixedStressesTest operators, concrete, response, phase, report, tracePath\n'
                 '        WriteMVT2ShearTensorsTest operators, concrete, field, phase, TORQUE, qy, tracePath')
    vb += "\n" + (HERE / "TensorCaptureTests.txt").read_text(encoding="utf-8")
    vb.encode("cp1251")
    files[source_path] = vb.replace("\n", "\r\n").encode("utf-8-sig")
    run = files["Run-Native.ps1"].decode("utf-8")
    run = replace(run, "    python './Verify-Mixed.py'", "    $tensorWire=$trace+'.Tensor.csv'\n"
                  "    Copy-Item -LiteralPath $tensorWire -Destination \"Native/$Case.Tensor.csv\"\n"
                  "    python './Verify-Mixed.py'")
    run = replace(run, '    if ($LASTEXITCODE -ne 0) {throw "Независимая проверка сырого результата завершилась с кодом $LASTEXITCODE."}',
                  '    if ($LASTEXITCODE -ne 0) {throw "Независимая проверка сырого результата завершилась с кодом $LASTEXITCODE."}\n'
                  "    python './Verify-Tensors.py'\n"
                  '    if ($LASTEXITCODE -ne 0) {throw "Проверка тензоров завершилась с кодом $LASTEXITCODE."}')
    files["Run-Native.ps1"] = run.encode("utf-8")
    files["Verify-Tensors.py"] = (HERE / "Verify-Tensors.py").read_bytes()
    proof = {"source_book_sha256": BASE["BOOK_SHA"], "native_preload_archive_sha256": BASE["BASE"],
             "inputs": {name: BASE["digest"](body) for name, body in sorted(files.items())}}
    if root is not None:
        root = root.resolve()
        allowed = Path("D:/CodexScratch/RC_Section_NDM_TQ").resolve()
        assert root != allowed and root.is_relative_to(allowed)
        root.mkdir()
        (root / "Temp").mkdir()
        stage["write_fresh"](root, {**files, "docs/regression/Diagnostic.xlsm":book,
                                   "Preparation.json": (json.dumps(proof, indent=2) + "\n").encode()})
    print("PINNED", proof["inputs"][source_path], proof["inputs"]["Run-Native.ps1"])


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path)
    stage_tensors(parser.parse_args().stage)
