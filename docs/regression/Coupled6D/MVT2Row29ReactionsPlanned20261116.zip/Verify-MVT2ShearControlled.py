"""Independently check Qy calibration, exact reaction law, and unchanged accepted H24."""
import csv
import json
import math
import sys

from VerifyBase import (
    AREA, EFFORT_NAMES, HERE, MODULUS, NATIVE, SCALES, diff, digest, near, operators,
    peak, read, read_native, reconstruct, tensor_radius, vec, verified_states, verify_run, verify_steel,
)

ANCHORS = ("Anchor","Large","AxialPlus","MeasuredRobust")
TRIALS = ("SameStrain","Reacted")


def full(state,stations):
    raw,_,_ = reconstruct(state["field"],state["q"],stations)
    return (*state["r"],*(x*MODULUS for x in raw[56:]))


def exact_reactions_coordinates(dq, geometry):
    rows = [0.]*66
    for point in range(1,26):
        x,y,area = geometry[point,0]
        _,shape,xn,yn = operators(x,y)
        for node,b in enumerate(shape):
            w = area/AREA*b
            rows[4+3*node] += w*(dq[0]-yn*dq[3])
            rows[5+3*node] += w*(dq[1]+xn*dq[3])
            rows[6+3*node] += w*dq[2]
    return rows


def inputs(prep):
    assert all(digest(HERE/name)==value for name,value in prep["prior_input_sha256"].items())
    assert digest(HERE/"Replay.csv")==prep["replay_sha256"]
    assert digest(HERE/"tests/modTestCoupledExperiment.bas")==prep["module_sha256"]
    plan = read(HERE/"Row29Plan.json")
    old, old_stations = verified_states(read_native(HERE/"PreviousNative.csv"))
    q = plan["load_Qy_kN"]
    current = old["MeasuredRobust"]
    assert all(old[name]["q"]==q for name in ANCHORS)
    tau = current["tol_MPa"]
    near(tau,plan["tau_MPa"],2e-15)
    near(plan["lower_norm_gate_MPa"],current["norm_MPa"]-tau,4e-10)
    caps = tuple(max(abs(x),tau) for x in old["Anchor"]["r"][56:])
    assert peak(diff(caps,plan["original_caps_MPa"]))<4e-10
    rows=list(csv.reader((HERE/"Anchors.csv").read_text().splitlines(),delimiter=";"))[1:]
    assert [row[0] for row in rows]==list(ANCHORS)
    for label, load,*items in rows:
        vals=tuple(map(float,items))
        assert float(load)==q and vals[:60]==old[label]["field"]
        old_r=full(old[label],old_stations[label])
        assert peak(diff(vals[60:],(*old_r[:56],*old_r[-4:],*old_r[56:62])))<4e-10
    rows = list(csv.reader((HERE/"CandidateFields.csv").read_text().splitlines(),delimiter=";"))[1:]
    assert len(rows)==2 and plan["names"]==list(TRIALS)
    fields = {}
    geometry = current["geometry"]
    for (name,load,expected,*coords),key in zip(rows,("before","after"),strict=True):
        field=tuple(map(float,coords))
        assert name in TRIALS and float(load)==q and field==tuple(plan[key]) and len(field)==60
        assert tensor_radius(diff(field,current["field"]),geometry)<=plan["solved_relative_radius_cap"]
        near(float(expected),plan[key+"_predicted_norm_MPa"],3e-15)
        fields[name]=field
    assert list(fields)==list(TRIALS)
    before,after=(fields[label] for label in TRIALS)
    assert before[:56]==after[:56] and before[56:]!=after[56:]
    physics = exact_reactions_coordinates(diff(after[56:],before[56:]),geometry)
    assert peak(diff(physics,plan["exact_reaction_action_all66_MPa"]))<4e-12
    weights=plan["archived_combination_weights"]
    assert 0.<sum(weights.values())<1. and all(w>=0. for w in weights.values())
    recomputed=list(current["field"])
    for key,w in weights.items():
        label=key.split(":",1)[1]
        for i in range(60):
            recomputed[i]+=w*(old[label]["field"][i]-current["field"][i])
    assert peak(diff(recomputed,before))<3e-15
    assert plan["expected_lower_bound_on_improvement_after_empirical_padding_MPa"]>tau
    return plan, old, old_stations, fields


def final_report(prep,plan,old,old_stations,fields):
    compiler,owner,wall=verify_run(prep)
    tags=read_native(NATIVE/"MVT2.csv")
    native,stations=verified_states(tags)
    history=vec(tags,"MVT2_CONTROL_FIELD")
    saved=list(csv.reader((HERE/"Replay.csv").read_text().splitlines(),delimiter=";"))[1:]
    assert len(history)==len(saved)==24
    for i,row in enumerate(saved,1):
        assert int(row[0])==i and peak(diff(tuple(map(float,row[9:])),history[f"Replay{i}"]))<1e-15
    [[q_base,q]]=tags["B_TANGENT_LOAD"]
    q_base,q=map(float,(q_base,q))
    near(q_base,float(saved[-1][2]),2e-13)
    near(q,q_base+(q_base-float(saved[-2][2]))/64,2e-13)
    assert q==plan["load_Qy_kN"]
    check={name:(float(v),bool(int(ok))) for name,v,ok in tags["B_MIXED_ANCHOR"]}
    absent={row[0] for row in tags["B_MIXED_ANCHOR_UNAVAILABLE"]}
    assert set(check)|absent==set(ANCHORS)
    discrepancies={}
    for name,(_,matches) in check.items():
        assert native[name]["q"]==q and peak(diff(native[name]["field"],old[name]["field"]))<3e-15
        discrepancy=peak(diff(full(native[name],stations[name]),full(old[name],old_stations[name])))
        discrepancies[name]=discrepancy
        if abs(discrepancy-plan["archive_vector_guard_MPa"])>4e-10:
            assert matches==(discrepancy<=plan["archive_vector_guard_MPa"])
    deferred=bool(absent) or any(not info[1] for info in check.values())
    assert bool(tags["B_MIXED_DEFER"])==deferred
    restore=("Restored24",) if deferred else ("Restored24",*(name+"/Rollback" for name in TRIALS))
    for label in restore:
        assert native[label]==native["Base24"] and native[label]["field"]==history["Replay24"]
        assert stations[label]==stations["Base24"]
    steel=verify_steel(tags,native,stations,history)
    final={"book_sha256":prep["book_sha256"],"H24_sha256":prep["replay_sha256"],
           "trace_sha256":digest(NATIVE/"MVT2.csv"),"native_wall_s":wall,"compiler":compiler,"owner":owner,
           "q_base_kN":q_base,"q_trial_kN":q,"exact_H24_restore":True,"history_published":False,
           "archive_discrepancy_MPa":discrepancies,"deferred":deferred,"tau_MPa":plan["tau_MPa"],
           "meaningful_reduction_target_MPa":plan["lower_norm_gate_MPa"]}
    if deferred:
        assert all(name not in native for name in TRIALS)
        return final
    tau = native["MeasuredRobust"]["tol_MPa"]
    caps = tuple(max(abs(x),tau) for x in native["Anchor"]["r"][56:])
    current_caps = tuple(min(c,max(tau,abs(x))) for c,x in zip(caps,native["MeasuredRobust"]["r"][56:],strict=True))
    logged_caps = next(tuple(map(float,x)) for name,*x in tags["B_MEASURE_CAPS"] if name=="Anchor")
    assert peak(diff(logged_caps,caps))<4e-10
    decisions={}
    for name,suffix in zip(TRIALS,("before","after"),strict=True):
        if name not in native:
            assert [name,"Residual"] in tags["B_TANGENT_UNAVAILABLE"]
            decisions[name]={"available":False}
            continue
        state=native[name]
        assert state["q"]==q and state["geometry"]==native["MeasuredRobust"]["geometry"]
        assert peak(diff(state["field"],fields[name]))<3e-15
        vector=full(state,stations[name])
        effort=vector[56:62]
        cap_losses=[key for key,value,c in zip(EFFORT_NAMES,effort,caps,strict=True) if abs(value)>c]
        strict_losses=[key for key,value,c in zip(EFFORT_NAMES,effort,current_caps,strict=True) if abs(value)>c]
        norm=peak(vector)
        decisions[name]={"available":True,"actual_norm_MPa":norm,"governing_index":max(range(66),key=lambda i:abs(vector[i]))+1,
            "signed_six_N_Nmm":state["signed_force_N_Nmm"],"fails_original_caps":cap_losses,
            "fails_no_worsening_vs_mixed":strict_losses,"actual_all66_MPa":vector,"gauge_MPa":state["gauge_MPa"],
            "peak_steel_stress_MPa":steel[name],"actual_predictor_error_MPa":peak(diff(vector,plan[suffix+"_predicted_all66_MPa"])),
            "passes_tau_and_six_progress_gate":norm<=peak(full(native["MeasuredRobust"],stations["MeasuredRobust"]))-tau and not cap_losses,
            "equilibrium":norm<=tau}
    final["candidates"]=decisions
    if all(decisions[name]["available"] for name in TRIALS):
        before,after=(native[k] for k in TRIALS)
        assert before["field"][:56]==after["field"][:56]
        assert stations["SameStrain"]==stations["Reacted"]
        assert before["signed_force_N_Nmm"]==after["signed_force_N_Nmm"] and before["gauge_MPa"]==after["gauge_MPa"]
        actual=diff(decisions["Reacted"]["actual_all66_MPa"],decisions["SameStrain"]["actual_all66_MPa"])
        discrepancy=peak(diff(actual,plan["exact_reaction_action_all66_MPa"]))
        assert discrepancy<=plan["archive_vector_guard_MPa"]
        final["reaction_only_identity"]={"exact_same_stations_and_six_efforts":True,"numerical_closure_error_MPa":discrepancy}
    return final


if __name__=="__main__":
    prep=read(HERE/"Preparation.json")
    plan,old,old_stations,fields=inputs(prep)
    if "--inputs-only" in sys.argv:
        result={"native_pending":True,"frozen_harness":prep,"lower_norm_gate_MPa":plan["lower_norm_gate_MPa"],
                "planned_after_norm_MPa":plan["after_predicted_norm_MPa"],"pair_identical_physical_coordinates":True,
                "original_effort_caps_MPa":plan["original_caps_MPa"],
                "exact_predicted_reaction_closure_MPa":0.}
        path=HERE/"InputCheck.json"
    else:
        result=final_report(prep,plan,old,old_stations,fields)
        path=HERE/"Verification.json"
    path.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(path,digest(path))
