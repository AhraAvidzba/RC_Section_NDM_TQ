"""Audit fixed-load MVT2 candidates and the measured torque--axial coupling."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import argparse
import csv
import json
import math

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def read_native(path,encoding="cp1251"):
    tables=defaultdict(list)
    for marker,*row in csv.reader(path.read_text(encoding=encoding).splitlines(),delimiter=";"):
        tables[marker].append(row)
    return tables


PREFIX = "504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8"
SOURCES = {
    "312": ("MVT2ShearTangent20261116.zip", "3E060F449D886074133E679A8B8CCEF293F3FC9604F265AF018FEE492ACF1835", ("Native/MVT2.csv",)),
    "316": ("MVT2BoundedReplay20261116.zip", "7E7E4274767518BA473007113F51DD0E27FC4CA792882B1B1D41BCCDC24772A2", ("Native/MVT2.csv",)),
    "322": ("MVT2FreshBounded20261116.zip", "48EAAC2597C4A5691072E698E56EEAE14F45B92B58BF85FF3515BEB451A2CA8C", ("NativeA/MVT2.csv","NativeB/MVT2.csv")),
    "325": ("MVT2GradientCorrection20261116.zip", "FA407B0A7625E2CC09C240470D205A5C70CE86BDC67AE04443C3B5306B323CA9", ("NativeA/MVT2.csv","NativeB/MVT2.csv")),
    "328": ("MVT2RepeatedFixed20261116.zip", "2A4127B75031E56AA35AD06FC2C6CA52EF4DF51E9E69EE3BCC75358B4401A1A2", ("NativeA/MVT2.csv",)),
    "334": ("MVT2MeasuredNative20261116.zip", "0D19814EB74BA458E56B40BF7E5D2E58CE057FDC724CB79A610DC6D56A77BA5E", ("Native/MVT2.csv",)),
    "338": ("MVT2AxialNative20261116.zip", "82B8388B418852B9966D02DDCA7A4229A94AE141E7FB97B560F8D9241EB8AA91", ("Native/MVT2.csv",)),
}
QY = 18.5720088671875


def parse(data):
    buckets=defaultdict(list)
    for tag,*row in csv.reader(data.decode("cp1251").splitlines(),delimiter=";"):
        buckets[tag].append(row)
    return buckets


def load_traces(evidence):
    traces={}
    identities={}
    for section,(name,expected_hash,files) in SOURCES.items():
        archive=evidence/name
        assert digest(archive)==expected_hash
        with ZipFile(archive) as proof:
            assert sha256(proof.read("Replay.csv")).hexdigest().upper()==PREFIX
            for i,file in enumerate(files):
                raw=proof.read(file)
                key=section+('/'+chr(ord('A')+i) if len(files)>1 else '')
                traces[key]=parse(raw)
                identities[key]=sha256(raw).hexdigest().upper()
    return traces,identities


def select_states(tags):
    fields={name:(int(h),float(f),tuple(map(float,v))) for name,h,f,*v in tags['B_TANGENT_FIELD']}
    native_res=vec(tags,'B_TANGENT_RESIDUAL')
    station=defaultdict(dict)
    for name,i,side,*v in tags['B_TANGENT_STATION']:
        k=int(i),int(side)
        assert k not in station[name]
        station[name][k]=tuple(map(float,v))
    states={}
    for label,(history,load,field) in fields.items():
        if history!=24 or abs(load-QY)>1e-12:
            continue
        if len(station[label])!=135:
            assert label not in native_res
            continue
        r,actual,geom_error=reconstruct(field,load,station[label])
        assert geom_error<4e-15
        check_error=peak(diff(r,native_res[label])); assert check_error<4e-10
        six=diff(actual,force(load))
        norm=max(peak(r[:56]),MODULUS*peak(r[56:]),peak(a/s for a,s in zip(six,SCALES,strict=True)))
        states[label]={"field":field,"norm_MPa":norm,"six_N_Nmm":six,"gauge_MPa":MODULUS*peak(r[56:]),
            "geometry":{key:row[:3] for key,row in station[label].items()},"stress_rows":station[label],
            "normalized_measurement_error_MPa":check_error}
    return states


def split_torque_and_bending(anchor, trial):
    points=[]
    for i in range(1,46):
        row=anchor['stress_rows'][i,0]
        x,y,computed_area=row[:3]
        other=trial['stress_rows'][i,0]
        assert row[:3]==other[:3]
        dz,dxz,dyz=(other[j]-row[j] for j in (15,17,18))
        points.append({"point":i,"x_mm":x,"y_mm":y,"axial_change_N":computed_area*dz,
            "bending_change_Nmm":computed_area*y*dz,"torque_change_Nmm":computed_area*(x*dyz-y*dxz)})
    total_axial=math.fsum(k['axial_change_N'] for k in points)
    total_bending=math.fsum(k['bending_change_Nmm'] for k in points)
    total_torque=math.fsum(k['torque_change_Nmm'] for k in points)
    exact=diff(trial['six_N_Nmm'],anchor['six_N_Nmm'])
    assert peak(diff((total_axial,total_bending,total_torque),(exact[0],exact[1],exact[3])))<2e-6
    concrete=math.fsum(k['torque_change_Nmm'] for k in points if k['point']<=25)
    replaced=math.fsum(k['torque_change_Nmm'] for k in points if k['point']>25)
    top=sorted(points,key=lambda x:abs(x['torque_change_Nmm']),reverse=True)[:9]
    torque_sum_abs=math.fsum(abs(x['torque_change_Nmm']) for x in points)
    return {'whole_signed_change_N_Nmm':exact,'concrete_torque_change_Nmm':concrete,
        'replaced_concrete_torque_change_Nmm':replaced,'absolute_sum_torque_change_Nmm':torque_sum_abs,
        'nine_largest_torque_share':math.fsum(abs(x['torque_change_Nmm']) for x in top)/torque_sum_abs,
        'station_contributions':points}


def matrix_component(tags, mode, row):
    return next(tuple(map(float,v)) for key,i,*v in tags['B_FRESH_MATRIX'] if key==mode and int(i)==row)


def tensor_radius(field, geometry):
    return max(abs(value)/(1. if i<3 else math.sqrt(2.)) for (_,side),(x,y,_) in geometry.items()
            for i,value in enumerate(strain_at(field,operators(x,y),side)))


def main(evidence, output):
    traces,hashes=load_traces(evidence)
    states={tag:select_states(rows) for tag,rows in traces.items()}
    ref=states['338']['Anchor']
    qref=ref['field']
    centre=states['334']['MeasuredCombination']
    assert peak(diff(qref,centre['field']))<3e-15 and centre['geometry']==ref['geometry']
    assert peak(diff(ref['six_N_Nmm'],centre['six_N_Nmm']))<2e-7
    tolerance=5e-7*(1.+peak(loading(QY)))
    caps=tuple(max(abs(x),tolerance*scale) for x,scale in zip(ref['six_N_Nmm'],SCALES,strict=True))
    entries=[]
    for key,rows in states.items():
        for label,value in rows.items():
            assert value['geometry']==ref['geometry']
            violations=[force for force,v,cap,scale in zip(EFFORT_NAMES,value['six_N_Nmm'],caps,SCALES,strict=True)
                        if abs(v)>cap+4e-10*scale]
            entries.append({'trace':key,'field':label,'norm_MPa':value['norm_MPa'],'source_delta_r_MPa':value['normalized_measurement_error_MPa'],
                'signed_effort_error_N_Nmm':value['six_N_Nmm'],'worsened_efforts':violations,
                'beats_reference_by_original_tolerance':value['norm_MPa']<=ref['norm_MPa']-tolerance})
    better=[r for r in entries if r['norm_MPa']<ref['norm_MPa']-4e-10]
    meaningful=[r for r in entries if r['beats_reference_by_original_tolerance'] and not r['worsened_efforts']]
    assert not meaningful and all(r['worsened_efforts'] for r in better)
    assert [(r['trace'],r['field']) for r in better]==[('328','FinalProvisional')]
    repeated=traces['328']
    increments={int(i):tuple(map(float,v)) for i,*v in repeated['BOUNDED_FIELD']}
    norms={int(i):float(val) for i,val in repeated['BOUNDED_UPDATE']}
    assert set(increments)==set(norms)=={1,2,3,4}
    assert increments[4]==states['328']['FinalProvisional']['field']
    masked=[i for i in range(1,4) if norms[i]<ref['norm_MPa']-tolerance]
    assert masked==[3]
    d34=diff(increments[4],increments[3]); final_my=states['328']['FinalProvisional']['six_N_Nmm'][2]
    original_my_limit=caps[2]
    old_shift={}
    for mode in ('Stock','Consistent'):
        my_row=matrix_component(traces['325/A'],mode,3)
        my_delta=dot(my_row,d34)*SCALES[2]
        old_shift[mode]={'final_step_My_prediction_Nmm':my_delta,'only_a_prior_tangent_step3_estimate_Nmm':final_my-my_delta}
    censored={'saved_field':3,'saved_driver_true_norm_MPa':norms[3],'advantage_over_current_norm_MPa':ref['norm_MPa']-norms[3],
        'weak_norm_only_upper_bound_on_abs_My_Nmm':norms[3]*SCALES[2],
        'required_max_abs_My_Nmm':original_my_limit,'known_step4_actual_My_Nmm':final_my,
        'last_step_My_change_if_step3_meets_cap_Nmm':[final_my-original_my_limit,final_my+original_my_limit],
        'previous_tangent_diagnostic':old_shift,
        'minimal_missing_measurement':'replay exact saved field 3 from the common H24 history and measure all six signed centre effort components',
        'exact_saved_step3_field':increments[3]}
    torque={name:split_torque_and_bending(ref,states['338'][name]) for name in ('AxialCompPlus','AxialCompMinus')}
    dt=torque['AxialCompPlus']['whole_signed_change_N_Nmm'][3]
    assert dt<0.
    old_tangent=matrix_component(traces['325/A'],'Stock',4)[3]
    q4step=-dt/(SCALES[3]*old_tangent)
    torsion=[0.]*60;torsion[3]=q4step
    summary={'target_Qy_kN':QY,'history_prefix_sha256':PREFIX,'trace_sha256':hashes,
        'same_load_fully_observed_records':len(entries),'distinct_fields_exact':len({value['field'] for rows in states.values() for value in rows.values()}),
        'reference_norm_MPa':ref['norm_MPa'],'original_tolerance_MPa':tolerance,'reference_signed_effort_error_N_Nmm':ref['six_N_Nmm'],
        'individual_caps_N_Nmm':caps,'all_fully_measured_lower_norm_fields':better,'fully_measured_meaningful_and_capped':meaningful,
        'archived_field_comparison':entries,'only_masked_lower_norm_field':censored,
        'axial_torque_material_decomposition':torque,
        'alternative_mechanical_measurement':{
            'reason':'The axial increment changes centre concrete shear, whereas axial-gradient-only updates leave all six centre efforts invariant.',
            'test':'single positive centre twist probe at the same H24 and load, with fixed remaining coordinates; record complete action',
            'q4_positive_sizing_from_old_T_tangent':q4step,'tensor_radius':tensor_radius(torsion,ref['geometry']),
            'normalized_old_T_derivative_MPa':old_tangent,'known_axial_torque_debt_Nmm':-dt,
            'scope':'Sizing only. The actual torsional perturbation and combined response are absent from the archive.'},
        'physical_limit_confirmed':False}
    output.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
    print(output.name,digest(output))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_directory',type=Path)
    parser.add_argument('output',type=Path)
    options=parser.parse_args()
    main(options.evidence_directory,options.output)
