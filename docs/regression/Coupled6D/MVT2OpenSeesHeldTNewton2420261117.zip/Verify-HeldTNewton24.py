"""Verify the paired OpenSees Newton experiment from retained data and tracked references."""

import argparse
from decimal import Decimal
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isfinite
from pathlib import Path
import re
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
ARCHIVES = HERE.parents[1] / "docs/regression/Coupled6D"
BASE_ARCHIVE = "MVT2OpenSeesHeldTFinerNewton20261117.zip"
BASE_ARCHIVE_SHA = "33E7D256CC31228934BC4C58811CF1B62824CAD21D9AB4B98FB2FA72BB3D7766"
BASE_PROOF_SHA = "1E1338E7014CAC33841B1F7BE41EE2540B2964D0FA57BC868C11F2C66B6715CE"
LINE_ARCHIVE = "MVT2OpenSeesHeldTLineSearch20261117.zip"
LINE_ARCHIVE_SHA = "F145B06B77BDF0D1261C595FCC0F812CDBCB613DC92F327EC67040A8DD788654"
RAW = "Newton24HeldTNative.json"
RECEIPT = "Newton24HeldTNative.receipt.json"
IDENTITY = "Newton24Identity.json"
PROOF = "VerificationHeldTNewton24.json"
Q_BASE = 11.25
Q_TARGET = 11.5625
ITERATION_CAP = 24
GLOBAL_LIMIT = 1e-5
OUTPUT_FILES = (RAW, RECEIPT, IDENTITY, "Newton24HeldTNative.stdout.log", "Newton24HeldTNative.stderr.log")


def digest(content):
    return sha256(content).hexdigest().upper()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def representation(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def matches_native_print(actual, printed):
    """OpenSees formats its terminal residual with six significant digits."""
    value = Decimal(str(printed))
    return abs(Decimal(str(actual)) - value) <= Decimal(5).scaleb(value.adjusted()-6)


def reprove_prior(archives, temp):
    """Re-run the independent 12-iteration proof and pin the line-search observation."""
    upstream = temp / "Upstream"
    upstream.mkdir()
    with ZipFile(archives / BASE_ARCHIVE) as original:
        require(digest((archives / BASE_ARCHIVE).read_bytes()) == BASE_ARCHIVE_SHA, "Tracked Newton12 archive hash")
        manifest = json.loads(original.read("SHA256SUMS.json"))
        needed = ("Verify-FinerHeldT.py", "FinerHeldTNative.json", "FinerHeldTNative.receipt.json", "FinerHeldTNative.stderr.log",
                  "FinerHeldTNative.stdout.log", "InterpreterOwnership.json", "Upstream/NonlinearDistributedHeldTSmallSteps.json",
                  "Upstream/Verify-HeldTSmallSteps.py", "Upstream/Verify-Pads.py", "Upstream/Verify-Shear.py", "Upstream/Verify-Torsion.py")
        for name in needed:
            data = original.read(name)
            require(digest(data) == manifest[name], f"Tracked Newton12 dependency {name}")
            (temp / name).write_bytes(data)
        proof = original.read("VerificationFinerHeldT.json")
        require(digest(proof) == BASE_PROOF_SHA == manifest["VerificationFinerHeldT.json"], "Matched Newton12 proof hash")
    spec = spec_from_file_location("previous_newton_proof", temp / "Verify-FinerHeldT.py")
    v = module_from_spec(spec)
    spec.loader.exec_module(v)
    previous = v.verify(temp / "FinerHeldTNative.json", temp / "FinerHeldTNative.receipt.json", archives,
                        upstream, temp / "InterpreterOwnership.json")
    require(previous == json.loads(proof), "Independent reproduction of prior Newton12")
    require(previous["verified_Qy_kN"] == Q_BASE and previous["rejection"]["target_Qy_kN"] == Q_TARGET,
            "Matched comparison target")
    require(previous["rejection"]["native_iteration_tolerance_N"] == GLOBAL_LIMIT and not previous["rejection"]["rollback_sampled_damage_exact"],
            "Baseline stopping criterion and material rollback")
    old, old_sha, old_source = v.reference(archives, upstream)
    with ZipFile(archives / LINE_ARCHIVE) as line_search:
        require(digest((archives / LINE_ARCHIVE).read_bytes()) == LINE_ARCHIVE_SHA, "Tracked line-search archive hash")
        line_result = json.loads(line_search.read("VerificationHeldTLineSearch.json"))
        line_bytes = line_search.read("LineSearchHeldTNative.json")
        require(line_result["native_sha256"] == digest(line_bytes) and line_result["status"] == "PASS" and
                line_result["trial"]["target_Qy_kN"] == Q_TARGET and line_result["global_iteration_tolerance_N"] == GLOBAL_LIMIT,
                "Verified line-search comparison at same trial")
        require(v.prepared_prefix(json.loads(line_bytes)) == v.prepared_prefix(old), "Line-search replay prefix")
    return v, upstream, old, old_sha, old_source, previous, line_result


def validate_candidate(record, closure, owner, v, old, old_sha, old_source):
    require(closure["wait_returned"] and closure["timeout_cleanup"] is None and closure["launcher_exit"] == 0, "Native process closure")
    require(owner["engine_pid"] == record["owned_engine_pid"] == closure["engine_pid"] > 0 and
            owner["parent_pid"] == record["engine_parent_pid"] == closure["parent_pid"] and
            owner["kernel_created_filetime"] == record["engine_created_filetime"] == closure["kernel_created_filetime"] and
            closure["popen_pid"] in (owner["engine_pid"], owner["parent_pid"]), "Fresh exact interpreter identity")
    require(int(owner["kernel_created_filetime"]) > 0 and closure["hard_cap_seconds"] == record["process_deadline_seconds"] == 300 and
            0. < record["engine_elapsed_seconds"] <= closure["wall_elapsed_seconds"] <= 301., "Bounded run")
    require(record["reference_archive_sha256"] == v.UPSTREAM_SHA and record["reference_raw_sha256"] == old_sha and
            record["reference_source_sha256"] == old_source and record["archived_newton_check_sha256"] == BASE_PROOF_SHA,
            "Exact frozen reference SHA")
    require(record["prefix_exact"] and record["accepted_torsion_replayed"] == 7 and record["replay_passed"] and
            record["prefix_expected_sha256"] == record["prefix_observed_sha256"] == v.START_STATE_SHA and
            v.prepared_prefix(record) == v.prepared_prefix(old), "Exact 13 accepted states before changing only iteration cap")
    require(record["planned_prefix_Qy_kN"] == v.PREFIX and record["planned_new_Qy_kN"] == [Q_TARGET] and
            record["planned_Qy_kN"] == v.PREFIX + [Q_TARGET], "Single matched applied load target")
    require(record["accepted_prefix_algorithm"] == record["solver_algorithm"] == "Newton" and record["newton24_activated"] and
            record["accepted_prefix_Newton_iteration_cap"] == old["Newton_iteration_cap"] == 12 and
            record["Newton_iteration_cap"] == ITERATION_CAP and record["norm_unbalance_force"] == GLOBAL_LIMIT and
            record["convergence_test_command"] == ["NormUnbalance", GLOBAL_LIMIT, ITERATION_CAP], "Iteration cap only")
    for key in ("opensees_version", "E_MPa", "nu", "fc_MPa", "ft_MPa", "steel_E_MPa", "steel_yield_MPa", "held_torsion_kNm",
                "steel_post_yield_slope_MPa", "explicit_Gt_N_per_mm", "explicit_Gc_N_per_mm", "explicit_Lch_mm", "ASD_autoRegularization",
                "explicit_compression_peak_strain", "tensile_knots", "compressive_knots", "support_mode", "asd_linearization", "kinematics",
                "pad_xz_size_mm", "validated_input_sha256", "norm_unbalance_force", "integrator_sha256"):
        require(record[key] == old[key], f"Changed physical model, equilibrium criterion, or rig: {key}")
    require(not (record["physical_limit_established"] or record["prior_Q12_5_damaged_engine_reused"] or
                 record["recoverable_continuation_after_rejection"] or record["restart_from_archived_material_state"]),
            "Fresh equilibria only and no continuation after damage rollback failure")


def physical_audit(v, upstream, row):
    pad = v.load_module("held_newton24_pad", upstream / "Verify-Pads.py")
    concrete = v.load_module("held_newton24_tensor", upstream / "Verify-Torsion.py")
    q = row["Qy_kN"]
    require(abs(row["nominal_midspan_Mx_kNm"] - .6 * q) < 2e-12, "Nominal midspan moment")
    return {"Qy_kN": q, "section_force_check": pad.verify_state(row["rig_balance"], v.TORQUE_NMM, 2000.*q),
            "raw_cuts": [{key: cut[key] for key in ("z_mm", "low_and_high_face", "left_right_free_bodies")}
                         for cut in row["rig_balance"]["cuts"]],
            "concrete_peak_stresses_MPa": concrete.tensors(row),
            "observed_clear_twist_rad_per_m": row["displacement"]["clear_twist_rad_per_m"]}


def verify(raw, receipt, identity, archives, temp):
    v, upstream, old, old_sha, old_source, previous, line_search = reprove_prior(archives, temp)
    payload = raw.read_bytes()
    record, host, owner = json.loads(payload), json.loads(receipt.read_bytes()), json.loads(identity.read_bytes())
    validate_candidate(record, host, owner, v, old, old_sha, old_source)
    (step,) = record["attempts"][12:]
    require(step["phase"] == "fixed_T_matched_newton24" and (step["from_Qy_kN"], step["target_Qy_kN"]) == (Q_BASE, Q_TARGET),
            "Exactly one new attempt on undamped Newton with increased iteration cap")
    trace = step["native_global_L2_trace_N"]
    require(len(trace) == min(step["iterations"], ITERATION_CAP) > 0 and all(isfinite(x) and x >= 0. for x in trace),
            "Full finite global L2 iteration trace")
    require(0. < step["solver_elapsed_seconds"] <= record["engine_elapsed_seconds"], "Trial timing")
    require(raw.with_suffix(".stdout.log").stat().st_size > 0, "Native engine completion log")
    rows = record["shear_confirmed_states"]
    retained = physical_audit(v, upstream, rows[4])
    require(retained["Qy_kN"] == Q_BASE, "Last archived Q11.25 section field")
    new_physical = None
    if step["solver_code"]:
        require(record["termination"] == "first_finer_step_rejected_engine_discarded" and len(rows) == 5 and step["solver_code"] == -3,
                "Rejected trial never became a section-equilibrium result")
        require(step["observed_Qy_kN"] == Q_BASE and step["rollback_time_exact"] and step["rollback_all_nodes_exact"] and
                type(step["rollback_sampled_damage_exact"]) is bool, "Rollback time, displacement, and sampled damage evidence")
        stderr = raw.with_suffix(".stderr.log").read_text(encoding="utf-8")
        require("NewtonRaphson::solveCurrentStep()" in stderr and "NewtonLineSearch" not in stderr, "Stock Newton native error path")
        ((cap, norm, limit),) = re.findall(r"after:\s*(\d+)\s+iterations\s+current Norm:\s*(\S+)\s+\(max:\s*(\S+),", stderr)
        require(int(cap) == ITERATION_CAP and len(trace) == ITERATION_CAP and float(limit) == GLOBAL_LIMIT and trace[-1] > GLOBAL_LIMIT,
                "Original absolute norm criterion exhausted at the new cap")
        require(matches_native_print(trace[-1], norm), "Native diagnostic vs full-precision iteration trace")
        require(all(d > GLOBAL_LIMIT for d in trace), "No successful norm step hidden in rejection")
    else:
        require(record["termination"] == "all_finer_steps_verified" and len(rows) == 6 and trace[-1] <= GLOBAL_LIMIT,
                "Accepted trial also satisfies original iterative tolerance")
        require(all(d > GLOBAL_LIMIT for d in trace[:-1]), "No unchecked iterations after convergence")
        row = rows[-1]
        require(row["Qy_kN"] == step["observed_Qy_kN"] and abs(row["Qy_kN"]-Q_TARGET) < 2e-12, "Actual new committed load")
        new_physical = physical_audit(v, upstream, row)
    newton12 = previous["rejection"]["native_global_L2_unbalance_N"]
    require(len(trace) >= 12 and matches_native_print(trace[11], newton12),
            "The paired Newton trials disagree at the old stopping iteration")
    return {"status": "PASS", "native_sha256": digest(payload), "initial_prefix_sha256": v.START_STATE_SHA,
            "accepted_prefix_state_count": 13, "trial": step, "termination": record["termination"],
            "global_iteration_tolerance_N": GLOBAL_LIMIT, "prior_Newton12_L2_N": newton12,
            "prior_line_search12_L2_N": line_search["LineSearch_global_L2_N"], "Newton24_last_L2_N": trace[-1],
            "global_L2_ratio_newton24_over_newton12": trace[-1] / newton12,
            "iteration12_global_L2_N": trace[11], "iteration12_matches_prior_printed_norm": True,
            "minimum_native_global_L2_N": min(trace),
            "prefix_last_state_Q11_25": retained, "tested_new_cut_equilibrium": new_physical,
            "last_verified_Qy_kN": new_physical["Qy_kN"] if new_physical else Q_BASE, "physical_limit_established": False,
            "engine_pid": owner["engine_pid"], "launcher_pid": host["popen_pid"], "process_closed": True,
            "wall_seconds": host["wall_elapsed_seconds"]}


def from_data(data, archives, helpers):
    return verify(data / RAW, data / RECEIPT, data / IDENTITY, archives, helpers)


def from_bundle(bundle, archives, temp):
    data = temp / "Native"
    data.mkdir()
    with ZipFile(bundle) as packet:
        manifest = json.loads(packet.read("SHA256SUMS.json"))
        require(set(packet.namelist()) == set(manifest) | {"SHA256SUMS.json"}, "Exact portable members")
        for name, wanted in manifest.items():
            require(digest(packet.read(name)) == wanted, name)
        for name in OUTPUT_FILES:
            (data / name).write_bytes(packet.read(name))
        result = from_data(data, archives, temp)
        require(representation(result) == packet.read(PROOF), "Exact archived independent proof")
    return result


def seal(bundle, data, proof):
    names = (*OUTPUT_FILES, "Run-HeldTNewton24.py", "Verify-HeldTNewton24.py", "README.md")
    files = {name: (data / name).read_bytes() for name in names}
    files[PROOF] = proof
    files["SHA256SUMS.json"] = representation({name: digest(value) for name, value in files.items()})
    with bundle.open("xb") as handle, ZipFile(handle, "w") as packet:
        for name, value in sorted(files.items()):
            item = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            item.compress_type = ZIP_DEFLATED
            packet.writestr(item, value, compresslevel=9)
    print("SEALED NEWTON24 EVIDENCE", digest(bundle.read_bytes()), bundle)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives", type=Path, default=ARCHIVES)
    parser.add_argument("--data", type=Path, default=HERE)
    parser.add_argument("--out", type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--bundle", type=Path)
    mode.add_argument("--pack", type=Path)
    mode.add_argument("--reference-only", action="store_true")
    args = parser.parse_args()
    with TemporaryDirectory(prefix="MVT2Newton24Proof_") as helpers:
        if args.reference_only:
            v, _upstream, _old, _, _, previous, limits = reprove_prior(args.archives, Path(helpers))
            print("NEWTON24 REFERENCE PASS", v.START_STATE_SHA, previous["rejection"]["native_global_L2_unbalance_N"], limits["LineSearch_global_L2_N"])
            return
        result = from_bundle(args.bundle, args.archives, Path(helpers)) if args.bundle else from_data(args.data, args.archives, Path(helpers))
    output = representation(result)
    if args.pack:
        seal(args.pack, args.data, output)
    if args.out or not (args.bundle or args.pack):
        path = args.out or (args.data / PROOF)
        with path.open("xb") as proof:
            proof.write(output)
    print("MVT2 NEWTON24 PROOF PASS", result["last_verified_Qy_kN"], result["Newton24_last_L2_N"], digest(output))


if __name__ == "__main__":
    main()
