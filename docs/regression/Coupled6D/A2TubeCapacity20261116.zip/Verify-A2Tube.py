"""Sectional shear-flow check for the pure-torsion tests of Lopes and Bernardo."""
from argparse import ArgumentParser
from collections import defaultdict
from csv import DictReader
from hashlib import sha256
from math import atan, degrees, hypot, isclose, pi, radians, sqrt, tan
from pathlib import Path
from PeakReference import native_reference
import json

HERE = Path(__file__).resolve().parent
PUBLICATIONS = {
    "Lopes-Bernardo-2009-PureTorsion.pdf": "E1A825DE9F4099A2E8CDF355696DA22BBC75F2A6AE0582A76BD844E4B1E9A6B6",
    "Lopes-Bernardo-2014-TorsionFailure.pdf": "C5ACB30732F7EBA9300798173B94CA0AE47FF60F569935A2D7F1C55F707313A1",
    "Bernardo-et-al-2013-A2-HollowBeams.pdf": "FEA12ECCF7C9C1BBD29E928BB43A348975D7DC6121A516D6372379514D7CAA4B",
    "Bernardo-et-al-2020-A2-SoftenedTruss.pdf": "83BF3DB6BABE0D01009D1A098A0FDA8BBA40CB3AF71939E929E55128261C8564",
}
NMM_TO_KNM = 1.e-6
MEAN_YIELD_MPA = 686.


def equilibrium(width, height, longitudinal_area, hoop_area, spacing, fy_long, fy_hoop):
    """Return the line capacities along the two axes and the torque scale."""
    perimeter = 2. * (width + height)
    longitudinal = longitudinal_area * fy_long / perimeter
    transverse = hoop_area * fy_hoop / spacing
    conversion = 2. * width * height * NMM_TO_KNM
    flow = sqrt(longitudinal * transverse)
    angle = degrees(atan(sqrt(transverse / longitudinal)))
    # Directly verify the four-wall torque integral and the equality of both tie bounds.
    integrated = flow * ((height / 2. * width + width / 2. * height) * 2.) * NMM_TO_KNM
    assert isclose(integrated, flow * conversion, rel_tol=2.e-15)
    assert isclose(longitudinal * tan(radians(angle)), transverse / tan(radians(angle)), rel_tol=2.e-15)
    return {
        "long_capacity_N_per_mm": longitudinal,
        "hoop_capacity_N_per_mm": transverse,
        "angle_to_axis_deg": angle,
        "balanced_torque_kNm": flow * conversion,
        "nominal_long_yield_at_45_deg_kNm": longitudinal * conversion,
        "nominal_hoop_yield_at_45_deg_kNm": transverse * conversion,
        "conversion": conversion,
    }


def stress_requirements(state, torque, thickness):
    """Invert the membrane eigenvalues when both types of steel are at yield."""
    longitudinal = state["long_capacity_N_per_mm"]
    transverse = state["hoop_capacity_N_per_mm"]
    flow = torque / state["conversion"]
    radius = hypot((longitudinal - transverse) / 2., flow)
    average = (longitudinal + transverse) / 2.
    return {
        "torque_kNm": torque,
        "flow_N_per_mm": flow,
        "least_positive_principal_force_N_per_mm": max(0., radius - average),
        "principal_tension_at_both_yield_MPa": (radius - average) / thickness,
        "principal_compression_at_both_yield_MPa": (radius + average) / thickness,
    }


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    options = parser.parse_args()
    publications = options.repo / "literature" / "Coupled6D"
    assert all(digest(publications / path) == value for path, value in PUBLICATIONS.items())
    reference = native_reference()
    test_data = HERE / "Specimens.csv"
    modes = defaultdict(list)
    beams = {}
    with test_data.open(encoding="utf-8", newline="") as source:
        for row in DictReader(source):
            beam = row.pop("beam")
            mode = row.pop("observed_mode")
            inputs = {name: float(value) if value else None for name, value in row.items()}
            static = equilibrium(inputs["b_mm"], inputs["h_mm"], inputs["steel_long_mm2"],
                                 inputs["steel_hoop_mm2"], inputs["spacing_mm"],
                                 MEAN_YIELD_MPA, MEAN_YIELD_MPA)
            test_peak = inputs["observed_peak_kNm"]
            static["difference_from_peak_percent"] = 100. * (static["balanced_torque_kNm"] / test_peak - 1.)
            modes[mode].append(static["difference_from_peak_percent"])
            beams[beam] = {"inputs": inputs, "observed_mode": mode, "reference": static}
    assert len(beams) == 16 and set(modes) == {"ductile", "low_reinforcement", "corner", "strut", "mixed"}

    exact_long = pi * (4. * 12.**2 + 12. * 10.**2) / 4.
    exact_hoop = pi * 8.**2 / 4.
    a2 = equilibrium(538., 531., exact_long, exact_hoop, 80., 672., 696.)
    a2_midwall = equilibrium(493., 493., exact_long, exact_hoop, 80., 672., 696.)
    reference_torques = [reference["peak"]["T_applied_kNm"], beams["A2"]["inputs"]["observed_peak_kNm"]]
    thickness_assumptions = {
        "effective_layer_with_centerline_mean_offset_mm": 600. - (538. + 531.) / 2.,
        "full_wall_mm": 107.,
    }
    requirements = {
        name: [stress_requirements(a2, torque, t) for torque in reference_torques]
        for name, t in thickness_assumptions.items()
    }
    peak = reference["peak"]
    assert isclose(peak["negative_principal_torque_kNm"] + peak["positive_principal_torque_kNm"],
                   peak["T_applied_kNm"], abs_tol=1.e-7)
    a2["observed_peak_minus_steel_scale_kNm"] = reference_torques[1] - a2["balanced_torque_kNm"]
    a2["NDM_peak_minus_steel_scale_kNm"] = reference_torques[0] - a2["balanced_torque_kNm"]
    a2["NDM_negative_principal_minus_steel_scale_kNm"] = (
        peak["negative_principal_torque_kNm"] - a2["balanced_torque_kNm"]
    )
    # Sweep the exact piecewise bound as an independent check of the stationary point.
    best_discrete = max(
        min(a2["long_capacity_N_per_mm"] * tan(radians(i / 100.)),
            a2["hoop_capacity_N_per_mm"] / tan(radians(i / 100.)))
        for i in range(1500, 7501)
    ) * a2["conversion"]
    assert 0. <= a2["balanced_torque_kNm"] - best_discrete < .06

    output = {
        "definition": "Single compression diagonal, steel with plateau, measured hoop axis contour unless specified.",
        "sources": PUBLICATIONS,
        "transcribed_specimens_sha256": digest(test_data),
        "by_beam": beams,
        "mode_error_ranges_percentage": {mode: [min(values), max(values)] for mode, values in modes.items()},
        "A2": {"individual_classes": a2, "full_wall_midline_sensitivity": a2_midwall,
               "effective_thickness_inputs": thickness_assumptions, "membrane_stress_diagnostics": requirements,
               "independent_angle_grid_torque_kNm": best_discrete, "native_record": reference},
    }
    path = HERE / "Verification.json"
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(digest(path))
    print(json.dumps(output["mode_error_ranges_percentage"]))
    print(json.dumps(output["A2"], ensure_ascii=False))


if __name__ == "__main__":
    main()

