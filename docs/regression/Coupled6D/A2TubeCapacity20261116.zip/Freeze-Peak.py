from pathlib import Path
from hashlib import sha256
import json, shutil
here=Path(__file__).resolve().parent
cache=Path.cwd()/"docs/regression/Audit03/LocalGradientDerivative20261115"
sources={
    "NativePrincipal.json": (cache/"A2MatchedEquilibrium/A2NativeTorsionByPrincipalStressSign.json", "51FE908798C88ECDC880F6A7EB1F9A91483544F0614D6618BA3D2811C3E51764"),
    "NativeFirstYield.json": (cache/"A2ColdQuadrature20261116/Resume/FirstYield/A2FirstYieldChecks.json", "1CB1D3989B99C76A630CE291F9110E76CC7C9FC05004A05A908F703EAAE341EF"),
    "NativePeak.csv": (cache/"A2MatchedEquilibrium/A2_NativePointSnapshots.csv", "6F1BED3BAD536A8F1B1F6599F692648F278A07E7356E587ACE49A11AF593E8DE"),
    "NativeGeometry.csv": (cache/"A2LambdaTLong/Native/A2_Trace.csv", None),
}
def digest(p):
    return sha256(p.read_bytes()).hexdigest().upper()
predicates={"NativePeak.csv":"Point;170;","NativeGeometry.csv":"A2_POINT;"}
for name,(path,expected) in sources.items():
    if expected is not None: assert digest(path)==expected
    if name in predicates:
        rows=[r for r in path.read_text(encoding="cp1251").splitlines() if r.startswith(predicates[name])]
        assert len(rows)==52
        (here/name).write_text("\n".join(rows)+"\n",encoding="ascii",newline="\n")
    else:
        shutil.copyfile(path,here/name)
proof={
    "existing_records_sha256":{path.name:digest(path) for path,expected in sources.values()},
    "portable_input_sha256":{name:digest(here/name) for name in sources},
}
(here/"SourceProof.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8",newline="\n")

