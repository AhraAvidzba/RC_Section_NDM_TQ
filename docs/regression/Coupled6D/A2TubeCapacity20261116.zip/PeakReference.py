"""Repeat the native A2 peak split with an independent 3-by-3 Jacobi rotation."""
from collections import Counter
from hashlib import sha256
from math import atan2, cos, fsum, isclose, sin
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
PEAK_INDX = 170


def principal_stresses(tensor):
    matrix = [row[:] for row in tensor]
    vectors = [[float(i == j) for j in range(3)] for i in range(3)]
    for _ in range(30):
        p, q = max(((0, 1), (0, 2), (1, 2)), key=lambda pair: abs(matrix[pair[0]][pair[1]]))
        x, y, z = matrix[p][p], matrix[q][q], matrix[p][q]
        if abs(z) < 2.e-14:
            break
        theta = .5 * atan2(2. * z, y - x)
        c, s = cos(theta), sin(theta)
        for k in range(3):
            if k != p and k != q:
                u, v = matrix[k][p], matrix[k][q]
                matrix[k][p] = matrix[p][k] = c * u - s * v
                matrix[k][q] = matrix[q][k] = s * u + c * v
            u, v = vectors[k][p], vectors[k][q]
            vectors[k][p], vectors[k][q] = c * u - s * v, s * u + c * v
        matrix[p][p] = c*c*x + s*s*y - 2.*c*s*z
        matrix[q][q] = s*s*x + c*c*y + 2.*c*s*z
        matrix[p][q] = matrix[q][p] = 0.
    values = [matrix[i][i] for i in range(3)]
    error = max(
        abs(tensor[i][j] - fsum(values[k]*vectors[i][k]*vectors[j][k] for k in range(3)))
        for i in range(3) for j in range(3)
    )
    assert error < 2.e-12
    return values, vectors, error


def native_reference():
    expected = json.loads((HERE / "SourceProof.json").read_text(encoding="utf-8"))
    for name, value in expected["portable_input_sha256"].items():
        assert sha256((HERE / name).read_bytes()).hexdigest().upper() == value
    sources = expected["existing_records_sha256"]
    principal = json.loads((HERE / "NativePrincipal.json").read_text(encoding="utf-8"))
    prior = max(principal["Stages"], key=lambda row: row["Torque_kNm"])
    assert prior["Index"] == PEAK_INDX
    steel = json.loads((HERE / "NativeFirstYield.json").read_text(encoding="utf-8"))
    geometry = {}
    for row in (HERE / "NativeGeometry.csv").read_text(encoding="ascii").splitlines():
        _, tag, name, group, x, y, area, *_ = row.split(";")
        geometry[int(tag)] = (name, float(x), float(y), float(area))
    assert Counter(name for name, *_ in geometry.values()) == {"Concrete": 20, "A2_LONG": 16, "A2_HOOP": 16}
    torques = [[], [], []]
    independently_seen = set()
    peak_tension, error = 0., 0.
    for row in (HERE / "NativePeak.csv").read_text(encoding="ascii").splitlines():
        _, step, tag, _, _, _, *raw = row.split(";")
        tag = int(tag)
        assert int(step) == PEAK_INDX and tag not in independently_seen
        independently_seen.add(tag)
        name, x, y, area = geometry[tag]
        sign = 1. if name == "Concrete" else -1.  # Вытесненный стержнем бетон.
        xx, yy, zz, xy, xz, yz = map(float, raw[6:])
        tensor = [[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]]
        values, vectors, local_error = principal_stresses(tensor)
        coeff = [sign * area * vectors[2][i] * (x*vectors[1][i]-y*vectors[0][i])*1.e-6 for i in range(3)]
        torques[0].append(sign * area * (x*yz-y*xz)*1.e-6)
        torques[1].append(fsum(weight*min(0., stress) for weight, stress in zip(coeff, values)))
        torques[2].append(fsum(weight*max(0., stress) for weight, stress in zip(coeff, values)))
        peak_tension = max(peak_tension, max(values))
        error = max(error, local_error)
    assert independently_seen == geometry.keys()
    total, negative, positive = map(fsum, torques)
    for computed, archive_key in ((total, "Torque_kNm"), (negative, "NegativePrincipalTorque_kNm"),
                                  (positive, "PositivePrincipalTorque_kNm"), (peak_tension, "HighestTensilePrincipalStress_MPa")):
        assert isclose(computed, prior[archive_key], abs_tol=3.e-10, rel_tol=0.)
    brackets = {"hoop": {}, "longitudinal": {}}
    stress_limits = {"hoop": 696. / 200000., "longitudinal": 672. / 200000.}
    for points, n in ((40, "7"), (56, "9")):
        for group, results in brackets.items():
            event = steel[n]["first_yield_brackets"][group]
            assert event["strains"][0] < stress_limits[group] <= event["strains"][1]
            results[f"quadrature{points}"] = {"T_kNm": event["T_kNm"], "theta_rad_per_m": event["twists"]}
    return {
        "source_provenance": sources,
        "peak":{"stage": PEAK_INDX, "T_applied_kNm": total,
                "negative_principal_torque_kNm": negative, "positive_principal_torque_kNm": positive,
                "max_positive_principal_stress_MPa": peak_tension, "max_tensor_reconstruction_error_MPa": error},
        "first_yield": brackets,
    }

