"""Сверяет автоматическую пробу с точной исходной дугой и ручной проверкой ARC31."""
from math import isclose
from pathlib import Path

import PriorVerify as prior

HERE=Path(__file__).resolve().parent
ARC56='FA02F66488C612238C74228C22562569EC4422197EF3FFF3696D843F84067FDF'
RESUME='14272540278AEE5CCA7BA234192B8D2CE2E7C8FC8A28B5EB76F05D7BFC1A8B6B'
GENERIC='5F201EDF38B5B1268D08D8A0309F0ED74A2AAFDBB612160C1A20842A2B0284A7'


def inputs(fixture,extract):
    assert prior.file_hash(HERE/'Support/GenericNewton.cls')==fixture['branch_source_sha256']==GENERIC
    assert prior.file_hash(HERE/'Manual/Arc56.csv')==ARC56
    assert prior.file_hash(HERE/'Manual/ResumeVerification.json')==RESUME
    _,_,_,steps,_,final=extract(HERE/'Manual/Arc56.csv')
    assert len(steps)==14 and final==['MINIMUM_RADIUS','9','9744']
    manual=prior.read(HERE/'Manual/ResumeVerification.json')['arc31_follow_on']
    assert manual['attempt14']=='ACCEPTED' and manual['stock_attempt15']=='LOCALITY_OR_BALANCE'


def verify(path,extract,steps,final,accepted,geometry):
    _,_,_,before,_,_=extract(HERE/'Manual/Arc56.csv')
    assert steps[:13]==before[:13]
    current=steps[13]
    assert current['args'][:7]==before[13]['args'][:7]
    assert all(current[k]==before[13][k] for k in ('TRACE-PROJECTION','TRACE-SEED'))
    extra={}
    for line in path.read_text(encoding='cp1251').splitlines():
        if line.startswith('AUTO-'):
            key,*args=line.split(';')
            assert key not in extra
            extra[key]=args
    attempted=prior.received(extra['AUTO-DETAIL'][0])
    result={'exact_prior_13_attempts':True,'same_34_fields_before_retry':True,'restored_original_history_words':9744,
            'automatic_retry_attempted':attempted,'automatic_retry_detail':';'.join(extra['AUTO-DETAIL'][1:]),
            'attempt14':current['TRACE-DECISION'][0],'attempt15':None,'physical_limit_certified':False}
    event=None
    if 'AUTO-SELECT' in extra:
        point,side,row=map(int,extra['AUTO-SELECT'][:3])
        fraction,start,end=prior.numbers(extra['AUTO-SELECT'][3:6])
        branch=int(extra['AUTO-SELECT'][6])
        contribution,departure=prior.numbers(extra['AUTO-SELECT'][7:])
        assert attempted and 1<=point<=100 and side in (-1,0,1) and 1<=row<=56
        assert 0.<fraction<=1. and start*end<0. and branch in (-1,1)
        assert contribution*departure>0.
        event=dict(point=point,side=side,weak_equation=row,rejected_fraction=fraction,
                   F_start_MPa=start,F_rejected_MPa=end,principal_sign=branch,
                   station_departure_MPa=contribution,total_departure_MPa=departure)
        result['selected_station']=event
    if 'AUTO-BALANCE' in extra:
        h,factor,norm,tau,F=prior.numbers(extra['AUTO-BALANCE'])
        assert event and h in (1.,.5,.25,.125) and F*event['F_start_MPa']>0.
        assert norm<=tau and prior.received(current['args'][7])
        logged=prior.numbers(current['TRACE-BALANCE'][:3])
        assert all(isclose(a,b,rel_tol=1e-11) for a,b in zip(logged,(factor,norm,tau),strict=True))
        candidate=prior.read(HERE/'Manual/ExpectedCandidate.json')
        result['calculated_field_bit_identical_to_manual']=current['TRACE-FIELD']==candidate['field']
        result['calculated_factor_bit_identical_to_manual']=extra['AUTO-BALANCE'][1]==candidate['candidate_lambda']
        result['balanced_fraction']=h
    if result['attempt14']=='ACCEPTED':
        assert len(steps)==15 and final[0]=='SINGLE_STOCK_PROBE'
        result['attempt15']=steps[14]['TRACE-DECISION'][0]
        assert accepted[-1]['attempt']==(15 if result['attempt15']=='ACCEPTED' else 14)
        byStep={item['attempt']:item for item in accepted}
        a,b=byStep[11],byStep[14]
        delta=b['lambda']-a['lambda']
        uncertainty=a['lambda_uncertainty']+b['lambda_uncertainty']
        result['delta_lambda_from_last_stock_interval']=[delta-uncertainty,delta+uncertainty]
    else:
        assert len(steps)==14 and final==['MINIMUM_RADIUS','9','9744']
    result['generic_confirmed_balanced']='AUTO-BALANCE' in extra
    return result
