"""Проверяет точный архив ARC31Auto без Excel и без рабочей книги."""

from argparse import ArgumentParser
import json
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory

import PortableSupport as support

HERE=Path(__file__).resolve().parent


def safe_path(name):
    path=Path(name)
    assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
    assert path.suffix.lower()!='.xlsm'
    return path


def replay(folder,baselines):
    expected=json.loads((folder/support.SUMS).read_bytes())
    entries={item.relative_to(folder).as_posix():item.read_bytes() for item in folder.rglob('*') if item.is_file()}
    assert set(entries)==set(expected)|{support.SUMS}
    for name,digest in expected.items():
        safe_path(name)
        assert support.sha(entries[name])==digest,name
    files=support.restore_files(entries,baselines)
    receipt=json.loads(files[support.REPORT])
    assert receipt['native_trace_sha256']==support.sha(files[support.TRACE])
    with TemporaryDirectory(prefix='decoded-',dir=folder.parent) as name:
        target=Path(name)
        for filename,data in files.items():
            out=target/safe_path(filename)
            out.parent.mkdir(parents=True,exist_ok=True)
            out.write_bytes(data)
        checked=run([sys.executable,'-B','-X','utf8','Verify.py','--order','10'],cwd=target,stdout=PIPE,check=True)
        assert 'OFFLINE PASS' in checked.stdout.decode('utf-8')
        assert (target/support.REPORT).read_bytes()==files[support.REPORT]
    case=receipt['automatic_branch_retry']
    assert receipt['status']=='PASS' and not receipt['physical_limit_certified']
    assert case['same_34_fields_before_retry'] and case['restored_original_history_words']==9744
    print(support.json_bytes(case).decode('utf-8').strip())
    print('HARDSHEAR_ARC31_AUTO_PORTABLE: VERIFIED_EVIDENCE; '
          f'TRY14={case["attempt14"]}; TRY15={case["attempt15"] or "NOT_RUN"}; physical_limit_certified=False')


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('arc56',type=Path)
    cli.add_argument('resume',type=Path)
    args=cli.parse_args()
    replay(HERE,support.read_baselines(args.arc56,args.resume))


if __name__=='__main__':
    main()
