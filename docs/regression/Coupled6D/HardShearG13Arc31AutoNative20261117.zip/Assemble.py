"""Prepares exactly one automatically chosen branch retry from the frozen extended fixture."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from subprocess import PIPE, run
from tempfile import TemporaryDirectory
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ARC56=ROOT/'tmp/hs-arc56/proof/HardShearG13SerialArcAttempt14DirectionNative20261117.zip'
ARC56_SHA='6CA5C64823399B7385635AA50F31C132A221164C47DE8D8E96B42DBC23037318'
RESUME=ROOT/'tmp/hs-p31-resume/proof/HardShearG13Arc31ResumeNative20261117.zip'
RESUME_SHA='819291EB230833351A6A9742D57B8FCC4473146176D5442BEDD7BB5557ED0978'
GENERIC=ROOT/'tmp/hs-p31-generic/src/Solver/CCoupledNewtonSolver.cls'
GENERIC_SHA='5F201EDF38B5B1268D08D8A0309F0ED74A2AAFDBB612160C1A20842A2B0284A7'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'
TRACE='Native/Order10/HardG14Direction.csv'
REPORT='Native/Order10/Verification.json'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def once(src,a,b):
    assert src.count(a)==1,a
    return src.replace(a,b)


def seal(dest,name,data):
    target=dest/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_bytes()==data,name
    else:
        target.write_bytes(data)
    return sha(data)


def merged(generic,original,fixture):
    with TemporaryDirectory(dir=HERE) as scratch:
        folder=Path(scratch)
        for name,raw in (('generic',generic),('original',original),('fixture',fixture)):
            (folder/name).write_bytes(text(raw).encode())
        result=run(['git','merge-file','-p','generic','original','fixture'],cwd=folder,check=True,stdout=PIPE)
    return text(result.stdout)


def compose(generic,original,fixture):
    v=merged(generic,original,fixture)
    v=once(v,'Private mHardG14ArmedTest As Boolean','Private mHardAutoEnabledTest As Boolean\nPrivate mHardG14ArmedTest As Boolean')
    v=once(v,'If ENABLE_BRANCH_CONSTRAINED_RETRY And Not mBranchCorrectionAttempted',
           'If ENABLE_BRANCH_CONSTRAINED_RETRY And mHardAutoEnabledTest And Not mBranchCorrectionAttempted')
    v=once(v,'If ENABLE_BRANCH_CONSTRAINED_RETRY Then mCurrentControlLambda',
           'If ENABLE_BRANCH_CONSTRAINED_RETRY And mHardAutoEnabledTest Then mCurrentControlLambda')
    v=once(v,'If Not ENABLE_BRANCH_CONSTRAINED_RETRY Or mBranchCorrectionAttempted Then Exit Function',
           'If Not ENABLE_BRANCH_CONSTRAINED_RETRY Or Not mHardAutoEnabledTest Or mBranchCorrectionAttempted Then Exit Function')
    v=once(v,'    Next attempt\n    If Not ReplayAcceptedFields(history, 25) Then Exit Function',
           '        If attempt = 15 Then outcome = "SINGLE_STOCK_PROBE": Exit For\n'
           '    Next attempt\n    If Not ReplayAcceptedFields(history, 25) Then Exit Function')
    marker='    seed = predicted\n    solved = TryDeformationStep(offset, direction, projection, target, estimate, lambda, TOLERANCE, TOLERANCE, _\n'
    v=once(v,marker,marker.replace('    solved','    mHardAutoEnabledTest = (attempt = 14)\n    solved'))
    v=once(v,'        MAX_ITER, consistentControl:=True, initialField:=seed)\n    WriteHardRankRowTest "TRACE-TRY;"',
           '        MAX_ITER, consistentControl:=True, initialField:=seed)\n'
           '    If mHardAutoEnabledTest Then WriteHardRankRowTest "AUTO-DETAIL;" & CStr(mBranchCorrectionAttempted) & ";" & BranchCorrectionDetails\n'
           '    mHardAutoEnabledTest = False\n    WriteHardRankRowTest "TRACE-TRY;"')
    v=once(v,'    Dim reason As String\n    reason = "Точка "',
           '    WriteHardRankRowTest "AUTO-SELECT;" & CStr(selected.Point) & ";" & CStr(selected.Side) & ";" & CStr(governingRow) & ";" & _\n'
           '        HardRankBitsTest(rejectedFraction) & ";" & HardRankBitsTest(selected.FromValue) & ";" & _\n'
           '        HardRankBitsTest(selected.ToValue) & ";" & CStr(selected.PrincipalSign) & ";" & _\n'
           '        HardRankBitsTest(departure) & ";" & HardRankBitsTest(branchDeparture)\n'
           '    Dim reason As String\n    reason = "Точка "')
    marker='                            TryDampedSmallStrain = True'
    v=once(v,marker,'''                            If station.Point > 0 Then
                                WriteHardRankRowTest "AUTO-BALANCE;" & HardRankBitsTest(fraction) & ";" & _
                                    HardRankBitsTest(trialLambda) & ";" & HardRankBitsTest(mLastNorm) & ";" & _
                                    HardRankBitsTest(trialTolerance) & ";" & HardRankBitsTest(yieldValue)
                            End If
'''+marker)
    v.encode('cp1251')
    assert 'RestoreHardArc31Test' not in v and 'mHardArc56ArmedTest' not in v
    assert max(map(len,v.splitlines()))<1024
    return v.replace('\n','\r\n').encode()


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready')
    cli.add_argument('--with-workbook',action='store_true')
    args=cli.parse_args()
    dest=args.destination.resolve()
    assert dest.is_relative_to(HERE) or dest.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(ARC56.read_bytes())==ARC56_SHA and sha(RESUME.read_bytes())==RESUME_SHA
    generic=GENERIC.read_bytes(); assert sha(generic)==GENERIC_SHA
    files={}
    with ZipFile(ARC56) as arc, ZipFile(RESUME) as resume:
        plan=json.loads(arc.read('Fixture.json'))
        base=(ROOT/plan['workbook']).read_bytes()
        assert sha(base)==plan['source_workbook_sha256']
        for name,digest in plan['inputs'].items():
            raw=arc.read(name)
            assert sha(raw)==digest,name
            if name in ('Stage.py','Arc56Proof.py','Hooks.bas'):
                continue
            if name==SOLVER:
                stock=arc.read('Production/'+name)
                assert sha(stock)==plan['production'][name]
                raw=compose(generic,stock,(HERE/'ExtendedSolver.cls').read_bytes())
            elif name=='Verify.py':
                v=text(raw)
                v=once(v,'import Arc56Proof as row56','import AutoProof as auto')
                v=once(v,'    row56.inputs(fixture, extract)','    auto.inputs(fixture, extract)')
                v=once(v,"        if line.startswith('ARC56-'):","        if line.startswith(('ARC56-','AUTO-')):")
                v=once(v,"{'ATTEMPT_LIMIT','MINIMUM_RADIUS','STEP_LIMIT','TIME_LIMIT','NO_SECANT'}",
                       "{'MINIMUM_RADIUS','SINGLE_STOCK_PROBE'}")
                v=once(v,"    result['attempt14_direction']=row56.verify(fixture, extract, path, records, geometry, weights, steps)",
                        "    result['automatic_branch_retry']=auto.verify(path,extract,steps,final,accepted,geometry)")
                raw=v.encode()
            elif name=='Run.ps1':
                raw=text(raw).replace('HardArc56','HardArc31Auto').encode()
            files[name]=seal(dest,name,raw)
        extras=[('AutoProof.py',(HERE/'AutoProof.py').read_bytes()),('Assemble.py',(HERE/'Assemble.py').read_bytes()),
                ('Support/GenericNewton.cls',generic),('Support/ExtendedNewton.cls',(HERE/'ExtendedSolver.cls').read_bytes()),
                ('Manual/Arc56.csv',arc.read(TRACE)),('Manual/ResumeVerification.json',resume.read(REPORT)),
                ('Manual/ExpectedCandidate.json',resume.read('Candidate.json'))]
        for name,raw in extras:
            files[name]=seal(dest,name,raw)
        if args.with_workbook:
            seal(dest,plan['workbook'],base)
            seal(dest,'docs/regression/Diagnostic.xlsm',base)
            for name in ('Native/Order10','Temp'):
                (dest/name).mkdir(parents=True,exist_ok=True)
    manifest={**plan,'inputs':files,'watchdog_seconds':215,'branch_source_sha256':GENERIC_SHA,
              'manual_follow_on_archive_sha256':RESUME_SHA,'scope':'Automatic recovery only on attempt14, a single stock follow-on, exact prior history'}
    print(dest,seal(dest,'Fixture.json',(json.dumps(manifest,indent=2)+'\n').encode()))


if __name__=='__main__':
    main()
