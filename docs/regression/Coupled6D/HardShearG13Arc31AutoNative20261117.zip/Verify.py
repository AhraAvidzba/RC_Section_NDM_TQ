"""Verify accepted fields, material rollback and strain-based advancement of the G13 trace."""

from argparse import ArgumentParser
import json
from math import fsum, isclose, sqrt
from pathlib import Path

import ArcVerify as arc
import ExtendedProof as extra
import AutoProof as auto
import DirectionVerify as reference
import PriorVerify as native


HERE=Path(__file__).resolve().parent


def inputs():
    fixture,expected,original,old=arc.inputs()
    source=HERE/'ArcPrior/HardG14Direction.csv'
    receipt=native.read(HERE/'ArcPrior/Verification.json')
    assert receipt['status']=='PASS' and receipt['native_trace_sha256']==native.file_hash(source)
    _,weights,op,_,measure,points=arc.extract(source)
    row=next(item for item in points if item['args'][0]=='FIELD' and native.number(item['args'][1])==.25)
    assert native.received(row['ARC-BALANCE'][-1])
    extra.inputs(fixture, extract)
    auto.inputs(fixture, extract)
    return fixture,expected,original,old,weights,op,row


def physical_dual(weights,operator,movement,norm):
    values=[[] for _ in range(56)]
    for point,area in weights.items():
        rows=[operator[point,r] for r in range(1,10)]
        strain=[fsum(movement[k]*value for k,value in row.items()) for row in rows]
        dual=[3*strain[0],3*strain[1],1.5*strain[2]]
        for pos,coef in ((3,1.),(5,.5),(7,.5)):
            low,high=strain[pos:pos+2]
            dual.extend((coef*(1.25*low+.25*high),coef*(.25*low+1.25*high)))
        for row,factor in zip(rows,dual,strict=True):
            for k,value in row.items():
                values[k].append(value*area*factor)
    norm_scale=3.*fsum(weights.values())*norm
    return [fsum(items)/norm_scale for items in values]+[0.]*4


def extract(path):
    points={}; op={}; trace=[]; steps=[]; budget=None; final=None
    for line in path.read_text(encoding='cp1251').splitlines():
        if line.startswith(('ARC56-','AUTO-')):
            continue
        key,*args=line.split(';')
        if key=='TRACE-BUDGET':
            assert budget is None
            budget=args
        elif key=='TRACE-AREA':
            assert int(args[0]) not in points
            points[int(args[0])]=native.number(args[1])
        elif key=='TRACE-OP':
            label=tuple(map(int,args[:2]))
            assert label not in op
            op[label]={int(index)-1:native.number(value) for index,value in [part.split('=') for part in args[2:]]}
        elif key=='TRACE-TRY':
            steps.append({'args':args})
        elif key=='TRACE-FINISH':
            assert final is None
            final=args
        elif key.startswith('TRACE-'):
            assert steps and key not in steps[-1]
            steps[-1][key]=args
        else:
            trace.append(line)
    return reference.read_probe(reference.TextTrace(trace)),points,op,steps,budget,final


def verify(fixture,expected,original,baseline_path,old_weights,old_op,first_arc):
    folder=HERE/'Native/Order10'
    proof=native.native_proof(fixture,folder)
    path=folder/'HardG14Direction.csv'
    saved,tags,matrices,samples=reference.read_probe(baseline_path)
    (raw,actual_tags,actual_matrices,actual_samples),weights,op,steps,budget,final=extract(path)
    geometry,points,_,_,_,records=raw
    assert all(a==b for a,b in zip(raw[1:],saved[1:],strict=True))
    assert (tags,matrices,samples)==(actual_tags,actual_matrices,actual_samples) and weights==old_weights and op==old_op
    assert {name:geometry[name] for name in expected['geometry']}==expected['geometry']
    assert geometry['FINISH']==['COMPLETE','25',str(1+len(steps))]
    assert budget[:2]==['32','64'] and len(steps)<=64 and final[-1]=='9744'
    prefix_size=extra.require_bit_identical_prefix(extract, weights, op, steps, budget)
    area,length,modulus,_=native.verify_geometry(fixture,10,geometry,points)
    scales=(area,area*length,area*length,area*length,area,area)
    direction,offset,orig_projection=(native.numbers(geometry[name]) for name in ('DIRECTION','OFFSET','PROJECTION'))
    prior,current=(native.numbers(records[i]['FIELD']) for i in (23,24))
    prior_lambda,current_lambda=(native.number(records[i]['BALANCE'][0]) for i in (23,24))
    initial_lambda=current_lambda
    initial_coord=native.number(records[24]['CONTROL'][0])
    estimate_shift=arc.metric_value(weights,op,[b-a for a,b in zip(prior,current,strict=True)])**.5
    size,usual,least=native.numbers(budget[2:])
    assert all(isclose(a*estimate_shift,b,rel_tol=5e-12) for a,b in zip((.25,.125,1/32),(size,usual,least),strict=True))
    rows=[]
    accepted=[]
    for attempt,item in enumerate(steps,start=1):
        idx,prospect,travel,target,fraction,last,guess,success,iterations,evaluations=item['args']
        assert int(idx)==attempt and int(prospect)==len(accepted)+1 and int(iterations)<=12 and int(evaluations)>=int(iterations)
        travel,target,fraction,last,guess=native.numbers((travel,target,fraction,last,guess))
        assert travel==size and travel>=least and last==current_lambda
        change=[b-a for a,b in zip(prior,current,strict=True)]
        norm=sqrt(arc.metric_value(weights,op,change))
        primary=physical_dual(weights,op,change,norm)
        projection=native.numbers(item['TRACE-PROJECTION'])
        assert all(isclose(a,b,rel_tol=4e-11,abs_tol=2e-15) for a,b in zip(primary,projection,strict=True))
        assert isclose(fraction,size/norm,rel_tol=5e-12)
        assert isclose(target,reference.dot(projection,current)+size,abs_tol=1e-16)
        assert guess==current_lambda+fraction*(current_lambda-prior_lambda)
        seed=native.numbers(item['TRACE-SEED'])
        assert seed[:56]==[a+fraction*d for a,d in zip(current[:56],change[:56],strict=True)] and seed[56:]==current[56:]
        solved=native.received(success)
        decision=item['TRACE-DECISION'][0]
        row={'attempt':attempt,'decision':decision,'solver_returned':solved,'requested_distance':travel,
             'iterations':int(iterations),'evaluations':int(evaluations)}
        if solved:
            factor,eq_res,tau,advance,distance,steel,ctrl_err,xz=native.numbers(item['TRACE-BALANCE'][:-1])
            verified=native.received(item['TRACE-BALANCE'][-1])
            field,res,load,wrench=(native.numbers(item[name]) for name in ('TRACE-FIELD','TRACE-RESIDUAL','TRACE-LOAD','TRACE-WRENCH'))
            assert load==[base+factor*d for base,d in zip(offset,direction,strict=True)]
            delta=[b-a for a,b in zip(current,field,strict=True)]
            assert isclose(advance,reference.dot(projection,delta),abs_tol=2e-20)
            assert isclose(distance,sqrt(arc.metric_value(weights,op,delta)),rel_tol=3e-11,abs_tol=1e-20)
            assert isclose(ctrl_err,modulus*(advance-size),abs_tol=1e-12)
            assert isclose(eq_res,arc.norm_equations(load,wrench,res,ctrl_err,scales),abs_tol=1e-13)
            assert isclose(xz,reference.dot(orig_projection,field),abs_tol=2e-16)
            if not any(offset):
                assert isclose(tau,5e-7*(1.+factor*max(map(abs,native.numbers(tags['DIRECTION-EQ'])[:56]))),abs_tol=2e-15)
            assert verified==(factor>0. and eq_res<=tau and max(map(abs,res[56:]))<=tau/modulus and steel<=1.
                              and advance>0. and abs(advance-size)<=.125*size and distance<=3.*size)
            row.update({'lambda':factor,'lambda_from_G13':factor-initial_lambda,'xz':xz,'xz_from_G13':xz-initial_coord,
                        'norm_MPa':eq_res,'tau_MPa':tau,'steel':steel,'actual_distance':distance,'projected_distance':advance})
            if decision=='ACCEPTED':
                bounded,value=item['TRACE-BOUND']
                assert verified and native.received(bounded) and native.number(value)>0.
                assert item['TRACE-COMMIT']==item['TRACE-FIELD']
                if not accepted:
                    row['first_same_as_prior_VBA_probe']=item['TRACE-FIELD']==first_arc['ARC-FIELD']
                    assert row['first_same_as_prior_VBA_probe'] and factor==native.number(first_arc['ARC-BALANCE'][0])
                row['lambda_uncertainty']=native.number(value)
                accepted.append(row)
                prior,current=current,field
                prior_lambda,current_lambda=current_lambda,factor
                size=usual
            else:
                assert decision in {'LOCALITY_OR_BALANCE','BOUND_UNAVAILABLE'} and 'TRACE-COMMIT' not in item
                size*=.5
        else:
            assert decision=='REFUSED' and 'TRACE-FIELD' not in item
            row['diagnostic']=item['TRACE-DECISION'][1]
            size*=.5
        rows.append(row)
    assert int(final[1])==len(accepted) and final[0] in {'MINIMUM_RADIUS','SINGLE_STOCK_PROBE'}
    result={'status':'PASS','terminal':final[0],'exact_prefix':25,'restored_state_words':9744,'initial_xz':initial_coord,
            'initial_lambda':initial_lambda,'old_G14_target':original['control'],'accepted_count':len(accepted),
            'trials':rows,'proof':proof,'native_trace_sha256':native.file_hash(path),'physical_limit_certified':False}
    result.update(extra.summarize(prefix_size, accepted, initial_lambda, initial_coord, original['control']))
    result['automatic_branch_retry']=auto.verify(path,extract,steps,final,accepted,geometry)
    output=folder/'Verification.json'
    content=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
    if output.exists():
        assert output.read_bytes()==content
    else:
        output.write_bytes(content)
    print('HARDSHEAR G13 SERIAL STRAIN ARC OFFLINE PASS',len(accepted),final[0],json.dumps(accepted,ensure_ascii=False))


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--inputs',action='store_true')
    cli.add_argument('--order',type=int,choices=(10,))
    args=cli.parse_args()
    bundle=inputs()
    if args.inputs:
        print('HARDSHEAR G13 SERIAL STRAIN ARC INPUTS: PASS')
    else:
        assert args.order==10
        verify(*bundle)
