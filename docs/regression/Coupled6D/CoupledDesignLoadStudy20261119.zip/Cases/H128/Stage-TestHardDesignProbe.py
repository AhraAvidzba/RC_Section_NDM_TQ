"""ДЛЯ ТЕСТОВ. Сравнивает начальное поле точной силовой пробы на уточнённом продольном шаге."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, half):
    """Не меняет материалы, уравнения и допуски; прогноз ограничен интервалом двух уже найденных состояний."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardFineTangent.py'))['TestStage'](repo, root, half)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    def TestOnce(code, old, new):
        """Не позволяет внедрить проверку в неоднозначный участок кода."""
        assert code.count(old) == 1, old
        return code.replace(old, new, 1)
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '    designVerified = VerifyDesignLoad(current.Coordinate, trial.Coordinate, designCoordinate)'
    new = '''    ' -------------------- ДЛЯ ТЕСТОВ --------------------
    ' Начальное поле не принимает новую историю и не изменяет точную нагрузку lambda=1.
    Dim testInitial As Variant, testLeft() As Double, testRight() As Double, testActual() As Double
    Dim testRatio As Double, testDegree As Long
    If modTestCoupledElasticState.HardDesignSeedRequestedTest Then
        mSolver.CopyTrial testRight, testActual
        testLeft = mCurrentFields.Item(mCurrentFields.Count)
        testRatio = (1# - current.Lambda) / (trial.Lambda - current.Lambda)
        If testRatio < 0# Or testRatio > 1# Then Err.Raise 5, , "Прогноз исходной нагрузки вне интервала."
        For testDegree = 1 To UBound(testLeft)
            testRight(testDegree) = testLeft(testDegree) + testRatio * (testRight(testDegree) - testLeft(testDegree))
        Next testDegree
        testInitial = testRight
        designVerified = VerifyDesignLoad(current.Coordinate, trial.Coordinate, designCoordinate, testInitial)
    Else
        designVerified = VerifyDesignLoad(current.Coordinate, trial.Coordinate, designCoordinate)
    End If'''
    code = TestOnce(code, old, new)
    code = TestOnce(code, '        Optional ByRef coordinate As Double = 0#) As Boolean',
        '        Optional ByRef coordinate As Double = 0#, Optional ByRef initialField As Variant) As Boolean')
    old = '    If Not mSolver.TryStep(load(1), load(2), load(3), load(4), load(5), load(6), mAbsTol, mRelTol, mMaxIterations) Then Exit Function'
    new = '''    Dim testSolved As Boolean
    If IsMissing(initialField) Then
        testSolved = mSolver.TryStep(load(1), load(2), load(3), load(4), load(5), load(6), mAbsTol, mRelTol, mMaxIterations)
    Else
        testSolved = mSolver.TryStep(load(1), load(2), load(3), load(4), load(5), load(6), mAbsTol, mRelTol, mMaxIterations, initialField:=initialField)
    End If
    If modTestCoupledElasticState.HardDesignProbeRequestedTest Then _
        modTestCoupledElasticState.TestWriteHardDesignSolve leftCoordinate, rightCoordinate, testSolved, mSolver.ResultMeta
    If Not testSolved Then Exit Function'''
    code = TestOnce(code, old, new)
    old = '    coordinate = CoordinateOf(field)\n    If Not BeyondSteelLimit() Then VerifyDesignLoad = (coordinate >= leftCoordinate And coordinate <= rightCoordinate)'
    new = '''    coordinate = CoordinateOf(field)
    If modTestCoupledElasticState.HardDesignProbeRequestedTest Then _
        modTestCoupledElasticState.TestWriteHardDesignField coordinate, leftCoordinate, rightCoordinate, Not BeyondSteelLimit()
    If Not BeyondSteelLimit() Then VerifyDesignLoad = (coordinate >= leftCoordinate And coordinate <= rightCoordinate)'''
    code = TestOnce(code, old, new)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, 'Public FineOrdinaryCDPTangentTest As Boolean', '''Public FineOrdinaryCDPTangentTest As Boolean
Public HardDesignProbeRequestedTest As Boolean, HardDesignSeedRequestedTest As Boolean
Private mHardDesignProbeFileTest As String, mHardDesignProbeCountTest As Long''')
    old = '    mHardPreparedPathTest = outputRoot & "\\Native\\Hard" & mode'
    new = old + '''
    If HardDesignProbeRequestedTest Then mHardPreparedPathTest = outputRoot & "\\Native\\HardDesign" & IIf(HardDesignSeedRequestedTest, "Seed", "Base")'''
    code = TestOnce(code, old, new)
    code += '\n' + (here / 'TestNativeHardDesignProbe.bas.txt').read_text('utf-8-sig')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, "'Compile','FineTangent'", "'Compile','DesignBase','DesignSeed','FineTangent'")
    code = TestOnce(code, "        if ($Phase -eq 'FineTangent') {", '''        if ($Phase -in @('DesignBase','DesignSeed')) {
            $designMode=if ($Phase -eq 'DesignSeed') {'Seed'} else {'Base'}
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardDesignProbe','-MacroArgument1',$PSScriptRoot,
                '-MacroArgument2',$designMode,'-TimeoutSeconds','360')
        } elseif ($Phase -eq 'FineTangent') {''')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledDeformationContinuation.cls', 'tests/modTestCoupledElasticState.bas', 'Run-TestWorkingASD.ps1'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeHardDesignProbe.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'cases': ['DesignBase', 'DesignSeed'], 'interpolated_initial_field_only': True,
        'load_path_changed': False, 'accepted_material_history_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRIVATE DESIGN LOAD PROBE READY', half, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--half-step', type=float, default=.001 / 256)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.half_step)
