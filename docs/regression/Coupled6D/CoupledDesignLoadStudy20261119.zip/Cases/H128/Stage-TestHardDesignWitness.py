"""ДЛЯ ТЕСТОВ. Сохраняет независимо проверяемое точное исходное сочетание и его префикс истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, half):
    """Добавляет только копирование успешного поля и его повтор после завершения основной траектории."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardDesignProbe.py'))['TestStage'](repo, root, half)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '    If Not BeyondSteelLimit() Then VerifyDesignLoad = (coordinate >= leftCoordinate And coordinate <= rightCoordinate)'
    assert code.count(old) == 1
    code = code.replace(old, old + '''
    If VerifyDesignLoad And modTestCoupledElasticState.HardDesignProbeRequestedTest Then _
        modTestCoupledElasticState.TestCaptureHardDesignWitness field, mCurrentFields, mTrace''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = 'Private mHardDesignProbeFileTest As String, mHardDesignProbeCountTest As Long'
    assert code.count(old) == 1
    code = code.replace(old, old + '\nPrivate mHardDesignWitnessFieldsTest As Collection, mHardDesignWitnessTraceTest As CCoupledLoadTrace', 1)
    old = '    mHardDesignProbeCountTest = 0'
    assert code.count(old) == 1
    code = code.replace(old, old + '\n    Set mHardDesignWitnessFieldsTest = Nothing: Set mHardDesignWitnessTraceTest = Nothing', 1)
    old = '    Close #handle\n    mHardPreparedReportTest = '
    assert code.count(old) == 1
    code = code.replace(old, '''    Close #handle
    If HardDesignSeedRequestedTest Then TestWriteHardDesignWitness solver, operators, concrete, reinforced, sides, _
        calibration, offset, direction, initialSteps, attempts, maxIterations, absTol, relTol, lambdaTolerance
    mHardPreparedReportTest = ''', 1)
    code += '\n' + (here / 'TestNativeHardDesignWitness.bas.txt').read_text('utf-8-sig')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledDeformationContinuation.cls', 'tests/modTestCoupledElasticState.bas'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeHardDesignWitness.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'exact_design_witness_exported': True, 'witness_does_not_change_main_history': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('EXACT DESIGN LOAD WITNESS READY', half, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--half-step', type=float, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.half_step)
