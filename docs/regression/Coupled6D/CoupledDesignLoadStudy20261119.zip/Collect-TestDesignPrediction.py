"""ДЛЯ ТЕСТОВ. Закрепляет прогноз точной исходной нагрузки и проверку его рабочего бюджета."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestCollect(repo, root, scope):
    """Сохраняет реальные источники всех 30 компонентов, нативные книги и проверяемую исходную историю."""
    here = Path(__file__).resolve().parent
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    cases = {'Probe': 'HardDesignH25620261119', 'H128': 'HardDesignWitnessH12820261119',
        'H256': 'HardDesignWitnessH25620261119'} if scope == 'study' else {
        'Final': 'DesignPredictionWorking20261119', 'Witness': 'WorkingDesignWitness20261119'}
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for folder in (root / 'Cases').iterdir():
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            destination = folder / relative
            if not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(destination.read_bytes()).hexdigest().upper()
        assert len(sources) == 30
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    for name in ('Collect-TestDesignPrediction.py', 'Check-TestDesignPrediction.py', 'Canonical-TestCoreVBA.py',
        'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py', 'Stage-TestHardPrepared.py',
        'Stage-TestHardSpatialStep.py', 'Stage-TestHardFineTangent.py', 'Stage-TestHardDesignProbe.py',
        'Stage-TestHardDesignWitness.py', 'Stage-TestWorkingDesignWitness.py', 'TestNativeHardDesignProbe.bas.txt',
        'TestNativeHardDesignWitness.bas.txt', 'TestNativeHardPrepared.bas.txt',
        'Stage-TestClosedBranchPeak.py', 'Stage-TestSteelHistory.py'):
        (root / name).write_bytes((here / name).read_bytes())
    baseline = repo / 'docs/regression/Coupled6D' / ('CoupledSpatialHalfSolves20261119.zip' if scope == 'study' else 'CoupledDesignLoadStudy20261119.zip')
    digest = sha256(baseline.read_bytes()).hexdigest().upper()
    if scope == 'study':
        assert digest == 'A39A38F713FC3A8CED10C208A20B5407B4F25CC036740950C7EAF7328904DDC0'
    (root / 'Baseline').mkdir()
    entries = {}
    with ZipFile(baseline) as archive:
        for name in ('HardEarlyField.csv', 'HardEarlyField.Operators.csv'):
            entry = 'Cases/H128FineTangent/Native/' + name if scope == 'study' else 'Cases/H128/Native/' + name.replace('HardEarlyField', 'HardDesignSeed')
            raw = archive.read(entry)
            (root / 'Baseline' / name).write_bytes(raw)
            entries[name] = {'entry': entry, 'sha256': sha256(raw).hexdigest().upper()}
        if scope == 'working':
            for suffix in ('.csv', '.Operators.csv'):
                entry = 'Cases/H128/Native/HardDesignSeed.Witness' + suffix
                name = 'DesignWitness' + suffix
                raw = archive.read(entry)
                (root / 'Baseline' / name).write_bytes(raw)
                entries[name] = {'entry': entry, 'sha256': sha256(raw).hexdigest().upper()}
    (root / 'Baseline/Origin.json').write_text(json.dumps({'archive': baseline.name,
        'sha256': digest, 'entries': entries}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    checkpoint = {'scope': scope, 'base': 'd9f37a5', 'physical_capacity_certified': False,
        'full_acceptance_completed': False, 'installed_workbook_changed': False}
    for name in ('Scope.json', 'SourceCheckpoint.json'):
        (root / name).write_text(json.dumps(checkpoint, indent=2) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('DESIGN LOAD PREDICTION EVIDENCE COLLECTED', scope, len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('study', 'working'), required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve(), args.scope)
