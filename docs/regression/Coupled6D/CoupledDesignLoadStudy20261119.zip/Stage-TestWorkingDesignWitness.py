"""ДЛЯ ТЕСТОВ. Проверяет рабочий ограниченный резерв начального поля с независимым выводом точного сочетания."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Сохраняет рабочий контроль бюджета и истории; тестовые добавления только копируют проверенное поле."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardFineTangent.py'))['TestStage'](repo, root, .001 / 128)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    code = (root / name).read_text('utf-8-sig')
    assert 'fallbackField:=prediction' in code
    old = '    Dim solved As Boolean\n    If IsMissing(prediction) Then'
    assert code.count(old) == 1
    code = code.replace(old, '''    If modTestCoupledElasticState.HardDesignSeedRequestedTest And Not IsMissing(prediction) Then _
        modTestCoupledElasticState.TestWorkingDesignBudgetTest mSolver, load, prediction, mAbsTol, mRelTol
    Dim solved As Boolean
    If IsMissing(prediction) Then''', 1)
    old = '    If Not solved Then Exit Function\n    Dim field() As Double, resultants() As Double'
    assert code.count(old) == 1
    code = code.replace(old, '''    If modTestCoupledElasticState.HardDesignSeedRequestedTest Then _
        modTestCoupledElasticState.TestWriteWorkingDesignMetaTest mSolver.ResultMeta
    If Not solved Then Exit Function
    Dim field() As Double, resultants() As Double''', 1)
    old = '    If Not BeyondSteelLimit() Then VerifyDesignLoad = (coordinate >= leftCoordinate And coordinate <= rightCoordinate)'
    assert code.count(old) == 1
    code = code.replace(old, old + '''
    If VerifyDesignLoad And modTestCoupledElasticState.HardDesignSeedRequestedTest Then _
        modTestCoupledElasticState.TestCaptureHardDesignWitness field, mCurrentFields, mTrace''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = 'Public FineOrdinaryCDPTangentTest As Boolean'
    assert code.count(old) == 1
    code = code.replace(old, old + '''
Public HardDesignSeedRequestedTest As Boolean
Private mHardDesignWitnessFieldsTest As Collection, mHardDesignWitnessTraceTest As CCoupledLoadTrace''', 1)
    old = '    Close #handle\n    mHardPreparedReportTest = '
    assert code.count(old) == 1
    code = code.replace(old, '''    Close #handle
    If HardDesignSeedRequestedTest Then TestWriteHardDesignWitness solver, operators, concrete, reinforced, sides, _
        calibration, offset, direction, initialSteps, attempts, maxIterations, absTol, relTol, lambdaTolerance
    mHardPreparedReportTest = ''', 1)
    code += '\n' + (here / 'TestNativeHardDesignWitness.bas.txt').read_text('utf-8-sig')
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Включает только чтение рабочего ограниченного восстановления точной исходной нагрузки.
Public Function RunTestWorkingDesignWitness(ByVal outputRoot As String) As String
    HardDesignSeedRequestedTest = True
    Set mHardDesignWitnessFieldsTest = Nothing: Set mHardDesignWitnessTraceTest = Nothing
    RunTestWorkingDesignWitness = RunTestHardFineTangent(outputRoot)
    HardDesignSeedRequestedTest = False
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет суммарные затраты и статус после обычной пробы и разрешённого прогноза.
Public Sub TestWriteWorkingDesignMetaTest(ByVal meta As CResultMeta)
    Dim handle As Integer: handle = FreeFile
    Open mHardPreparedPathTest & ".Design.csv" For Append As #handle
    Print #handle, "SOLVE;" & CStr(meta.InternalStatus) & ";" & CStr(meta.ResultCode) & ";" & meta.DiagnosticDetails
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет исчерпание общей итерации и неизменность принятого поля перед штатным решением.
Public Sub TestWorkingDesignBudgetTest(ByVal solver As CCoupledNewtonSolver, ByRef load() As Double, _
        ByRef prediction As Variant, ByVal absTol As Double, ByVal relTol As Double)
    Dim before() As Double, after() As Double, revision As Long, degree As Long, solved As Boolean
    solver.CopyAccepted before: revision = solver.AcceptedRevision
    solved = solver.TryStep(load(1), load(2), load(3), load(4), load(5), load(6), absTol, relTol, 1, fallbackField:=prediction)
    solver.CopyAccepted after
    If solved Or solver.TestIterationCount > 1 Or solver.AcceptedRevision <> revision Then Err.Raise 5, , "Нарушен общий бюджет пробного восстановления."
    For degree = 1 To UBound(before)
        If before(degree) <> after(degree) Then Err.Raise 5, , "Неудачная бюджетная проба изменила принятое поле."
    Next degree
    Dim handle As Integer: handle = FreeFile
    Open mHardPreparedPathTest & ".Design.csv" For Append As #handle
    Print #handle, "BUDGET;1;" & CStr(solved) & ";" & CStr(solver.TestIterationCount) & ";accepted_unchanged=True"
    Close #handle
    solver.DiscardStep
End Sub
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает фактический суммарный счётчик без изменения численного состояния.
Friend Property Get TestIterationCount() As Long
    TestIterationCount = mIterations
End Property
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'Compile','FineTangent'"
    assert code.count(old) == 1
    code = code.replace(old, "'Compile','WorkingDesign','FineTangent'", 1)
    old = "        if ($Phase -eq 'FineTangent') {"
    assert code.count(old) == 1
    code = code.replace(old, '''        if ($Phase -eq 'WorkingDesign') {
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestWorkingDesignWitness','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','360')
        } elseif ($Phase -eq 'FineTangent') {''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledDeformationContinuation.cls', 'src/Solver/CCoupledNewtonSolver.cls',
        'tests/modTestCoupledElasticState.bas', 'Run-TestWorkingASD.ps1'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeHardDesignWitness.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'working_bounded_force_prediction': True, 'exact_design_witness_exported': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('WORKING BOUNDED DESIGN PREDICTION WITNESS READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
