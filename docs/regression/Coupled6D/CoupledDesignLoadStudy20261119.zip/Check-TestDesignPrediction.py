"""ДЛЯ ТЕСТОВ. Проверяет реальный VBA, точную исходную нагрузку и ограниченный резерв прогноза."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import numpy as np


def TestRead(file):
    """Читает закреплённые данные без изменения чисел и кодов результата."""
    return json.loads(file.read_text('utf-8-sig'))


def TestCheckpoint(root):
    """Проверяет действительную базу всех пяти книг, без метки другого общего сборщика."""
    record = TestRead(root / 'Scope.json')
    assert record == TestRead(root / 'SourceCheckpoint.json') and record['base'] == 'd9f37a5'
    assert record['scope'] in ('study', 'working')
    for key in TestRead(root / 'Cases.json'):
        assert TestRead(root / 'Cases' / key / 'Preparation.json')['base_stage_commit'].startswith('d9f37a5')
    return record['scope']


def TestBaseline(repo, root):
    """Сверяет не только хеш извлечённого файла, но и соответствующую запись закреплённого архива."""
    record = TestRead(root / 'Baseline/Origin.json')
    archive = repo / 'docs/regression/Coupled6D' / record['archive']
    assert sha256(archive.read_bytes()).hexdigest().upper() == record['sha256']
    with ZipFile(archive) as source:
        for name, pin in record['entries'].items():
            raw = (root / 'Baseline' / name).read_bytes()
            assert sha256(raw).hexdigest().upper() == pin['sha256'] and source.read(pin['entry']) == raw


def TestNative(repo, root, output):
    """Сверяет все компоненты реальных книг и каждую завершённую нативную фазу с её собственной личностью Excel."""
    scope = TestCheckpoint(root)
    shared = run_path(str(root / 'Check-TestMaterialRoundoff.py'))
    shared['TestFiles'](root)
    source, _ = run_path(str(root / 'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root / 'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    canonical = run_path(str(root / 'Canonical-TestCoreVBA.py'))
    normal = lambda text: canonical['TestCanonical'](text)[0]
    core_body = canonical['TestWrap'](body)
    def TestImportedBody(text, name):
        """Учитывает точный формат числовых литералов Newton без изменения типов, значений или строк."""
        record = core_body(text, name)
        return (normal(record[0]), *record[1:]) if name == 'CCoupledNewtonSolver' else record
    controls = [normal('x=1e-8') == normal('x=0.00000001'), normal('x=1e-8') != normal('x=1e-7'),
        normal('x=200000#') != normal('x=200000'), normal('s="ε"') != normal('s="?"'),
        normal('s="1e-8"') != normal('s="0.00000001"'), normal("x=1 'бетон") != normal("x=1 'сталь"),
        normal("x=1 'ν") == normal("x=1 '?"), normal('x=10000000000#') != normal('x=10000000001#')]
    assert all(controls)
    phases = {'Probe': {'DesignBase': 1, 'DesignSeed': 1}, 'H128': {'DesignSeed': 1},
        'H256': {'DesignSeed': 1}} if scope == 'study' else {
        'Final': {'Core': 382, 'PeakRegression': 168, 'Stock': 28}, 'Witness': {'WorkingDesign': 1}}
    assert set(TestRead(root / 'Cases.json')) == set(phases)
    cases = {}
    for key, expected_phases in phases.items():
        folder = root / 'Cases' / key
        result = shared['TestSourceComparison'](repo, root, folder, source, original, helper, TestImportedBody, reader)
        assert (result['components'], result['imported'], result['unchanged']) == (239, 25, 214)
        compiler = TestRead(folder / 'docs/regression/CodeUpdate.json')
        _, actual = reader(helper['TestContainer']((folder / 'CompiledVBA.bin').read_bytes()))
        coupled = []
        for relative in TestRead(folder / 'AllCoupledSources.json'):
            file = folder / relative
            expected, _ = helper['TestMVTCompilerBody'](body, file.read_text('utf-8-sig'), file.stem)
            observed = body(actual[file.stem], file.stem)[0]
            if file.stem == 'CCoupledConcreteReturn':
                def TestSpacing(text):
                    """Учитывает известное выравнивание одной константы VBE перед тем же комментарием."""
                    rows = text.splitlines(keepends=True)
                    for index, line in enumerate(rows):
                        if line.startswith('private const rounding_limit as double = '):
                            code, comment = line.split("'", 1)
                            rows[index] = code.rstrip() + " '" + comment
                    return ''.join(rows)
                expected, observed = TestSpacing(expected), TestSpacing(observed)
            assert normal(expected) == normal(observed), (key, file.stem)
            coupled.append(file.stem)
        assert len(coupled) == 30
        result['all_coupled_sources_match'] = coupled
        assert {file.stem for file in (folder / 'Native').glob('*.txt')} == set(expected_phases)
        reports = {}
        for phase, count in expected_phases.items():
            file = folder / 'Native' / (phase + '.txt')
            log = file.read_text('utf-8-sig')
            owner = TestRead(file.with_name(file.name + '.Ownership.json'))
            closure = TestRead(file.with_name(file.name + '.ProcessClosure.json'))
            identity = closure['Closure']['Identity']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
            assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
            assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
            assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['Closure']['FinalState']['State'] == 'Absent'
            assert 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
            totals = [tuple(map(int, pair)) for pair in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', log, re.M)]
            assert totals and sum(passed for passed, _ in totals) == count and all(failed == 0 for _, failed in totals)
            if phase in ('DesignBase', 'DesignSeed', 'WorkingDesign'):
                assert re.search(r'^HARD_PREPARED_RESULT;\d+;[\d.E+-]+;6;', log, re.M)
            if phase == 'Stock':
                assert 'TIMING_STATES: direct=OK; capacity=NumFail;' in log
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;', log, re.M)
                result['stock_seconds'] = float(re.search(r'^TIMING_SECONDS: ([\d.]+)', log, re.M)[1])
            reports[phase] = totals
        safety = [json.loads(line) for line in (folder / 'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in safety)
        assert all(all(p['ProtectedUser'] for p in row['excel']) for row in safety)
        result['reports'] = reports
        cases[key] = result
    output.write_text(json.dumps({'cases': cases, 'scope': scope, 'canonical_controls': controls,
        'physical_capacity_certified': False, 'installed_workbook_changed': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('DESIGN PREDICTION ACTUAL VBA REPORTS AND OWNED PROCESS CLOSURE VERIFIED', flush=True)


def TestMechanics(repo, root, output):
    """Повторяет точную нагрузку и её собственную историю, не подменяя ими физический предел."""
    scope = TestCheckpoint(root)
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    TestBaseline(repo, root)
    validate = run_path(str(root / 'Validate-TestHardPrepared.py'))['TestValidate']
    with TemporaryDirectory() as temporary:
        temporary = Path(temporary)
        (temporary / 'Native').mkdir()
        for name in ('HardEarlyField.csv', 'HardEarlyField.Operators.csv'):
            (temporary / 'Native' / name).write_bytes((root / 'Baseline' / name).read_bytes())
        baseline, baseline_fields = validate(temporary, 'HardEarlyField')
        if scope == 'working':
            for suffix in ('.csv', '.Operators.csv'):
                (temporary / 'Native' / ('DesignWitness' + suffix)).write_bytes((root / 'Baseline' / ('DesignWitness' + suffix)).read_bytes())
            original_witness, original_witness_fields = validate(temporary, 'DesignWitness')
    cases = {}
    if scope == 'study':
        base, a = validate(root / 'Cases/Probe', 'HardDesignBase')
        seed, b = validate(root / 'Cases/Probe', 'HardDesignSeed')
        assert np.array_equal(a, b) and len(a) == 17
        assert any('lambda = 1 подтверждено: False' in part for part in base['details'])
        assert any('lambda = 1 подтверждено: True' in part for part in seed['details'])
        cases['ProbeBase'], cases['ProbeSeed'] = base, seed
        for key, count in (('H128', 22), ('H256', 17)):
            proof, fields = validate(root / 'Cases' / key, 'HardDesignSeed')
            witness, witness_fields = validate(root / 'Cases' / key, 'HardDesignSeed.Witness')
            assert len(fields) == count and len(witness_fields) == 8 and np.array_equal(witness_fields[:7], fields[:7])
            assert np.array_equal(fields, baseline_fields if key == 'H128' else a)
            cases[key], cases[key + 'Witness'] = proof, witness
        folder_a, folder_b = root / 'Cases/H128', root / 'Cases/H256'
        name = 'HardDesignSeed.Witness'
        operators = name + '.Operators.csv'
        assert (folder_a / 'Native' / operators).read_bytes() == (folder_b / 'Native' / operators).read_bytes()
        raw_reader = run_path(str(root / 'Check-TestHardHalfSteps.py'))
        _, field_a = validate(folder_a, name)
        _, field_b = validate(folder_b, name)
        g, load, w, v, coordinate, axis, b, slope = raw_reader['TestOperators'](folder_a / 'Native' / operators, 60, 43)
        def TestCentral(file):
            """Выбирает фактические тензоры и сталь центральной станции последней точной точки."""
            rows = raw_reader['TestRows'](file)
            return np.asarray([row[4:] for row in rows if len(row) > 4 and row[:3] == ['S', '8', '0']], float)
        central_a = TestCentral(folder_a / 'Native' / (name + '.csv'))
        central_b = TestCentral(folder_b / 'Native' / (name + '.csv'))
        assert central_a.shape == central_b.shape == (43, 9)
        difference = field_a[-1] - field_b[-1]
        cases['StepComparison'] = {
            'maximum_central_strain_difference': float(np.max(np.abs(np.einsum('pcd,d->pc', b, difference)))),
            'maximum_axial_gradient_difference': float(np.max(np.abs(np.einsum('pcd,d->pc', slope, difference)))),
            'maximum_central_stress_difference_MPa': float(np.max(np.abs(central_a[:, :6] - central_b[:, :6]))),
            'maximum_central_steel_stress_difference_MPa': float(np.max(np.abs(central_a[:, 8] - central_b[:, 8]))),
            'exact_lambda': 1, 'physical_capacity_certified': False}
    else:
        proof, fields = validate(root / 'Cases/Witness', 'HardEarlyField')
        witness, witness_fields = validate(root / 'Cases/Witness', 'HardEarlyField.Witness')
        assert np.array_equal(fields, baseline_fields) and np.array_equal(witness_fields, original_witness_fields)
        assert len(fields) == 22 and len(witness_fields) == 8
        budget = (root / 'Cases/Witness/Native/HardEarlyField.Design.csv').read_text('cp1251')
        assert 'BUDGET;1;False;1;accepted_unchanged=True' in budget
        assert 'SOLVE;4;0;Итерации: 4;' in budget and 'подтверждён межузловой прогноз' in budget
        cases['WitnessMain'], cases['ExactDesignWitness'] = proof, witness
        cases['Budget'] = {'maximum_iterations': 1, 'used_iterations': 1, 'solved': False, 'accepted_unchanged': True,
            'working_complete_solve_iterations': 4, 'main_fields_exact': 22, 'witness_fields_exact': 8}
    for key, proof in cases.items():
        if key.endswith('Witness'):
            assert proof['states'][-1]['fraction'] == proof['states'][-1]['lambda'] == 1
            assert proof['maximum_lambda'] == 1 and proof['meta'][:2] == ['4', '0'] and not proof['reversed_fields']
    output.write_text(json.dumps({'scope': scope, 'cases': cases, 'independent_material_reintegration': False,
        'physical_capacity_certified': False}, indent=2, sort_keys=True, ensure_ascii=False) + '\n', encoding='utf-8')
    print('DESIGN PREDICTION EXACT LOAD ALL EQUATIONS HISTORY AND BUDGET VERIFIED; CAPACITY OPEN', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
