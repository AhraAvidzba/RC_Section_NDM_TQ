"""Сопоставляет две завершённые нативные серии по одному управлению деформацией."""

from argparse import ArgumentParser
import importlib.util
import json
from pathlib import Path


def independent_reader():
    path = Path(__file__).resolve().with_name("Verify.py")
    spec = importlib.util.spec_from_file_location("hard_mesh_verify", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def entry(native, order, reader):
    folder = native / f"Order{order}"
    report = reader.read(folder / "Verification.json")
    trace = folder / "HardYieldGate.csv"
    assert report["order"] == order and not report["physical_limit_certified"]
    assert report["native_trace_sha256"] == reader.file_hash(trace)
    tags, points, steps = reader.parse(trace, order)
    plan = reader.read(native.resolve().parent / "Fixture.json")
    area, length, modulus, _ = reader.verify_geometry(plan, order, tags, points)
    projection, direction = (reader.numbers(tags[key]) for key in ("PROJECTION", "DIRECTION"))
    accepted = []
    for step in steps:
        reader.verify_field(step, projection, direction, area, length, modulus)
        if step["committing"] and step["ready"]:
            accepted.append({key: step[key] for key in ("label", "control", "factor", "norm", "tau")})
    return report, accepted


def common_prefix(stock, nested):
    paired = []
    for a, b in zip(stock, nested):
        if a["control"] != b["control"]:
            break
        paired.append({"control": a["control"], "stock": a, "nested": b,
                       "nested_minus_stock": b["factor"] - a["factor"]})
    return paired


def observed_extremes(stock, nested, stock_accepted, nested_accepted):
    def original_state(record):
        return {k: record[k] for k in ("control", "factor", "norm", "tau", "uncertainty")}

    stock_samples = [original_state(w) for w in stock["window"] if w["ready"]]
    nested_samples = [original_state(w) for w in nested["window"] if w["ready"]]
    stock_peak_sample = max(stock_samples, key=lambda state: state["factor"], default=None)
    nested_peak_sample = max(nested_accepted + nested_samples, key=lambda state: state["factor"], default=None)
    shared = common_prefix(stock_accepted, nested_accepted)
    nested_peak_common = max((p["nested"] for p in shared), key=lambda state: state["factor"], default=None)
    return {"stock_window_highest_sample": stock_peak_sample, "nested_highest_sample": nested_peak_sample,
            "nested_highest_at_common_prefix": nested_peak_common,
            "nested_minus_stock_window_samples": None if not stock_peak_sample or not nested_peak_sample
            else nested_peak_sample["factor"] - stock_peak_sample["factor"],
            "nested_common_minus_stock_window_samples": None if not stock_peak_sample or not nested_peak_common
            else nested_peak_common["factor"] - stock_peak_sample["factor"]}


def comparison(stock, nested, same_schedule):
    intervals = []
    if len(stock["window"]) == len(nested["window"]) == 6:
        for a, b in zip(stock["window"], nested["window"], strict=True):
            assert a["control"] == b["control"]
            if a["uncertainty"] is None or b["uncertainty"] is None:
                continue
            delta = b["factor"] - a["factor"]
            bound = a["uncertainty"] + b["uncertainty"]
            intervals.append({"control": a["control"], "nested_minus_stock": delta,
                              "equilibrium_uncertainty_interval": [delta-bound, delta+bound]})
    both_complete = all(row["outcome"] != "control_window_incomplete" for row in (stock, nested))
    if not both_complete:
        conclusion = "control_window_incomplete"
    elif not same_schedule:
        conclusion = "different_accepted_control_substeps"
    elif stock["outcome"] != "signed_local_bracket":
        conclusion = "stock_bracket_not_reproduced_from_resolved_prefix"
    elif nested["outcome"] == "signed_local_bracket":
        conclusion = "both_meshes_show_a_local_rise_then_fall_among_samples"
    elif len(set(nested["secant_signs"])) == 1 and 0 not in nested["secant_signs"]:
        conclusion = "stock_bracket_and_uniform_nested_secant_sign_among_samples"
    else:
        conclusion = "stock_bracket_only_with_unresolved_nested_secants"
    return conclusion, intervals


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("native", type=Path)
    args = parser.parse_args()
    reader = independent_reader()
    stock, stock_accepted = entry(args.native, 5, reader)
    nested, nested_accepted = entry(args.native, 10, reader)
    stock_schedule = [p["control"] for p in stock_accepted]
    nested_schedule = [p["control"] for p in nested_accepted]
    assert stock["proof"]["compiled_workbook_sha256"] == nested["proof"]["compiled_workbook_sha256"]
    same = stock_schedule == nested_schedule
    conclusion, intervals = comparison(stock, nested, same)
    result = {"outcome": conclusion, "accepted_control_schedule_equal": same,
              "stock_control_schedule": stock_schedule, "nested_control_schedule": nested_schedule,
              "common_committed_prefix": common_prefix(stock_accepted, nested_accepted),
              "highest_observed_states": observed_extremes(stock, nested, stock_accepted, nested_accepted),
              "common_control_comparison": intervals, "physical_limit_certified": False}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
