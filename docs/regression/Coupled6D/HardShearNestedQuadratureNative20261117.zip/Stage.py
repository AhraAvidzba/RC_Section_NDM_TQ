"""Готовит изолированную парную проверку квадратур HardShear с независимыми историями."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from struct import unpack
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ARCHIVE = ROOT / "docs/regression/Coupled6D/HardShearH9EquilibriumNative20261117.zip"
ARCHIVE_HASH = "A1D2C8D0D2FD7DEA397AF8846C024FE3961673AB59BA078D77AEF0475892912C"
CHECK_HASH = "D84FFD33C26BF9A6E4F66D931BC2FD38168DC996E6BA5DCD6DF7315944039FFA"
BOOK_HASH = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
ANALYSIS = "src/Solver/CCoupledSectionAnalysis.cls"
SOLVER = "src/Solver/CCoupledNewtonSolver.cls"
STEEL = "src/Materials/CCoupledReinforcedResponse.cls"
TESTS = "tests/modTestCoupledElasticState.bas"
MODULES = (ANALYSIS, SOLVER, STEEL, TESTS)
DELTAS = (-5e-7, -1.2e-7, -6e-9, 6e-9, 1.2e-7, 5e-7)


def digest(raw):
    return sha256(raw).hexdigest().upper()


def code(raw):
    return raw.decode("utf-8-sig").replace("\r\n", "\n")


def encoded(source):
    assert max(map(len, source.splitlines())) < 1024
    return (source.rstrip().replace("\n", "\r\n") + "\r\n").encode("utf-8")


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def seal(directory, path, raw):
    target = directory / path
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, path
    else:
        target.write_bytes(raw)
    return digest(raw)


def diagnostic_solver(stock, inherited):
    source = code(inherited)
    start = source.index("Friend Function ProbeHardYieldEquilibriumTest(")
    end = source.index("\nEnd Function", start) + len("\nEnd Function")
    first = source.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, start)
    assert source[:first].rstrip() == code(stock).rstrip()
    diagnostic = code((HERE / "Probe.bas").read_bytes())
    diagnostic.encode("cp1251")
    return encoded(source[:first] + diagnostic + source[end:])


def diagnostic_test(stock, inherited):
    source = code(inherited)
    assert "Private Function TestPrepareCoupledTimingBook(" in code(stock)
    source = once(source, "Public HardRankRequestedTest As Boolean, HardRankFinishedTest As Boolean",
                  "Public HardRankRequestedTest As Boolean, HardRankFinishedTest As Boolean\nPublic HardMeshOrderTest As Long")
    source = once(source, "Public Function RunTestHardShearYieldGate() As String\n    On Error GoTo Failed",
                  "Public Function RunTestHardShearYieldGate(ByVal requestedOrder As String) As String\n"
                  "    On Error GoTo Failed\n"
                  "    If requestedOrder <> \"5\" And requestedOrder <> \"10\" Then Err.Raise 5, , \"Требуется 5 или 10.\"\n"
                  "    HardMeshOrderTest = CLng(requestedOrder)")
    # В диагностике используется собственный решатель нового пути из ядра Capacity.
    start = source.index("Public Function RunTestHardShearYieldGate(")
    end = source.index("\nEnd Function", start)
    body = once(source[start:end], 'TestPrepareCoupledTimingBook(book, "Both", "Excel", loads)',
                'TestPrepareCoupledTimingBook(book, "Capacity", "Excel", loads)')
    body = once(body, 'WriteHardRankRowTest "HARDSHEAR-YIELD-GATE;1"',
                'WriteHardRankRowTest "HARDSHEAR-MESH-GATE;1;" & CStr(HardMeshOrderTest)')
    return encoded(source[:start] + body + source[end:])


def diagnostic_analysis(stock):
    source = code(stock)
    entry = "    Set solver = CreateNewtonSolver(response, fc, ft, models)\n    branch.Initialize solver, path,"
    hook = '''    If HardRankRequestedTest Then
        Dim testOffset() As Double, testDirection() As Double, testComponent As Long
        path.TargetSix 0#, testOffset
        path.TargetSix 1#, testDirection
        For testComponent = 1 To 6: testDirection(testComponent) = testDirection(testComponent) - testOffset(testComponent): Next testComponent
        HardRankFinishedTest = ReplayHardYieldGateTest(solver, testOffset, testDirection)
        meta.SetResult rsNumericalFailure, rcNumericalFailure, rkCapacity, "Диагностическая проверка полей HardShear."
        capacity.InitializeCoupledUnresolved meta, loadPath
        Exit Function
    End If
'''
    source = once(source, entry, entry.split("    branch.Initialize", 1)[0] + hook + "    branch.Initialize solver, path,")
    old = "        prepared.PrepareModel mSection, mEb, mPoisson, 1, 1, 5, mTransverse,"
    new = "        Dim testDivisions As Long: testDivisions = 5\n"
    new += "        If HardRankRequestedTest Then testDivisions = HardMeshOrderTest\n"
    new += "        prepared.PrepareModel mSection, mEb, mPoisson, 1, 1, testDivisions, mTransverse,"
    return encoded(once(source, old, new))


def steel(stock):
    extra = '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Раздельные фактические запасы двух групп подтверждённой пробной точки.
Friend Sub ReadHardMeshSteelTest(ByRef longitudinal As Double, ByRef transverse As Double)
    longitudinal = mTrialLongitudinalUtilization: transverse = mTrialTransverseUtilization
End Sub
'''
    return encoded(code(stock).rstrip() + "\n" + extra)


def runner(stock):
    result = code(stock)
    result = once(result, "[string]$Phase='Inputs'", "[string]$Phase='Inputs',\n    [ValidateSet(5,10)][int]$Order=10")
    result = once(result, "$report='Native/HardShear.txt'", "$nativeDir=\"Native/Order$Order\"\n$report=\"$nativeDir/HardShear.txt\"")
    old = "'CCoupledDeformationContinuation','CCoupledNewtonSolver','modTestCoupledElasticState'"
    result = once(result, old, ",".join("'" + Path(name).stem + "'" for name in MODULES))
    old = "        ($code.Modules -join ',') -cne ($modules -join ',') -or"
    result = once(result, old, "        @($code.Modules).Count -ne $modules.Count -or\n"
                  "        ((@($code.Modules) | Sort-Object -CaseSensitive) -join ',') -cne (($modules | Sort-Object -CaseSensitive) -join ',') -or")
    result = once(result, "PRIVATE_CODE_READY: modules=3;", "PRIVATE_CODE_READY: modules=4;")
    result = once(result, "if (@(Get-ChildItem -LiteralPath 'Native' -Force).Count -or\n"
                  "        @(Get-ChildItem -LiteralPath 'Temp' -Force -Filter 'RC_NDM_ModeSuite_*').Count)",
                  "if (@(Get-ChildItem -LiteralPath $nativeDir -Force).Count)")
    result = once(result, "-Mode No -TimeoutSeconds $data.watchdog_seconds -FailFast -VerifyResultsReopen",
                  "-MacroArgument1 ([string]$Order) -Mode No -TimeoutSeconds $data.watchdog_seconds -FailFast -VerifyResultsReopen")
    result = once(result, "-Destination 'Native/HardYieldGate.csv'", '-Destination (Join-Path $nativeDir "HardYieldGate.csv")')
    result = once(result, "python -B -X utf8 'Verify.py'\n", "python -B -X utf8 'Verify.py' --order $Order\n")
    return result.replace("CompileHardShearYieldGate", "CompileHardShearMeshGate").replace(
        "Assert-IsolatedOfficeReady 'RunHardShearYieldGate'", "Assert-IsolatedOfficeReady 'RunHardShearMeshGate'").encode("utf-8")


def value(token):
    return unpack(">d", bytes.fromhex(token))[0]


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--destination", type=Path, default=HERE / "ready")
    cli.add_argument("--with-workbook", action="store_true")
    args = cli.parse_args()
    destination = args.destination.resolve()
    assert destination.is_relative_to(HERE) or destination.is_relative_to(Path("D:/CodexScratch/RC_Section_NDM_TQ").resolve())
    assert digest(ARCHIVE.read_bytes()) == ARCHIVE_HASH
    workbook = (ROOT / BOOK).read_bytes()
    assert digest(workbook) == BOOK_HASH
    with ZipFile(ARCHIVE) as archive:
        witness = archive.read("Native/Verification.json")
        assert digest(witness) == CHECK_HASH
        frozen = json.loads(archive.read("Fixture.json"))
        assert frozen["source_workbook_sha256"] == BOOK_HASH
        inputs = {}
        for path, expected in frozen["inputs"].items():
            raw = archive.read(path)
            assert digest(raw) == expected, path
            if path == "Expected.json" or path.startswith("tools/") or path == "Guard-IsolatedOffice.ps1":
                inputs[path] = seal(destination, path, raw)
            elif path == "Run.ps1":
                inputs[path] = seal(destination, path, runner(raw))
        exact = json.loads(archive.read("Expected.json"))
        production = {}
        for path in MODULES:
            raw = (ROOT / path).read_bytes()
            if path in frozen["production"]:
                assert digest(raw) == frozen["production"][path], path
            production[path] = digest(raw)
            builders = {ANALYSIS: diagnostic_analysis, STEEL: steel}
            if path == SOLVER:
                staged = diagnostic_solver(raw, archive.read(path))
            elif path == TESTS:
                staged = diagnostic_test(raw, archive.read(path))
            else:
                staged = builders[path](raw)
            inputs[path] = seal(destination, path, staged)
        inputs["PriorVerification.json"] = seal(destination, "PriorVerification.json", witness)
    for path in ("Verify.py", "Stage.py", "Probe.bas"):
        inputs[path] = seal(destination, path, (HERE / path).read_bytes())
    projection = list(map(value, exact["projection"]))
    controls = [sum(p * value(v) for p, v in zip(projection[:56], values[:56], strict=True)) for values in exact["prefix"]]
    assert all(a < b for a, b in zip([0.] + controls, controls))
    assert controls[-1] < exact["peak_control"] + min(DELTAS)
    if args.with_workbook:
        seal(destination, BOOK, workbook)
        seal(destination, "docs/regression/Diagnostic.xlsm", workbook)
        for path in ("Temp", "Native/Order5", "Native/Order10"):
            (destination / path).mkdir(parents=True, exist_ok=True)
    plan = {"source_workbook_sha256": BOOK_HASH, "source_revision": frozen["source_revision"],
            "workbook": BOOK, "prior_archive_sha256": ARCHIVE_HASH, "prior_report_sha256": CHECK_HASH,
            "inputs": inputs, "production": production, "modules": [Path(path).stem for path in MODULES],
            "watchdog_seconds": 220, "orders": [5, 10], "prefix": controls,
            "probes": [exact["peak_control"] + delta for delta in DELTAS],
            "ray": [28000., 510000., 180000., 1500000., 17000., -7100.],
            "basis_spans": [1, 1], "geometry_mm": [180., 120.], "area_mm2": 21600.,
            "length_scale_mm": 2219577.365175632 / 21600.,
            "material": {"E_MPa": 30000., "fc_MPa": 30., "ft_MPa": 3., "Gt_N_mm": .12, "Gc_N_mm": 80.,
                         "length_mm": 125., "nu": .2, "initial_yield_MPa": 16., "peak_strain": .002},
            "scope": "section fixed-ray equilibrium and spatial sampling at the old local peak; no physical limit status"}
    print(destination, seal(destination, "Fixture.json", (json.dumps(plan, indent=2) + "\n").encode("utf-8")))


if __name__ == "__main__":
    main()
