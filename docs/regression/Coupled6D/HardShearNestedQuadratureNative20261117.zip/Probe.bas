' -------------------- ДЛЯ ТЕСТОВ --------------------
' Решает контрольную последовательность с нуля для данной квадратуры.
' Поля другого разбиения служат начальным приближением, а не историей.
Friend Function ProbeHardYieldEquilibriumTest(ByVal reference As Collection, ByRef peak() As Double, _
        ByRef secant() As Double, ByVal secantFactor As Double, ByRef projection() As Double, _
        ByVal peakControl As Double, ByVal peakFactor As Double, ByRef offset() As Double, ByRef direction() As Double) As Boolean
    If reference.Count <> 8 Or Not mUseSpatialHistory Or mDegreeCount <> 60 Then Exit Function
    Dim point As Long, x As Double, y As Double, area As Double, lengthScale As Double
    Dim count As Long: count = mSection.ConcretePointCount
    If count <> HardMeshOrderTest ^ 2 Then Exit Function
    mSection.CopyResultantResidualScales area, lengthScale
    WriteHardRankRowTest "MESH;" & CStr(HardMeshOrderTest) & ";" & CStr(count) & ";" & CStr(mPointCount) & ";" & _
        HardRankBitsTest(area) & ";" & HardRankBitsTest(lengthScale) & ";" & HardRankBitsTest(mReferenceModulus)
    WriteHardRankRowTest "OFFSET;" & HardRankVectorTest(offset)
    WriteHardRankRowTest "DIRECTION;" & HardRankVectorTest(direction)
    WriteHardRankRowTest "PROJECTION;" & HardRankVectorTest(projection)
    For point = 1 To count
        mSection.Point point, x, y, area
        WriteHardRankRowTest "QUAD;" & CStr(point) & ";" & HardRankBitsTest(x) & ";" & HardRankBitsTest(y) & ";" & HardRankBitsTest(area)
    Next point
    ResetHistory
    Dim accepted() As Double, acceptedCoordinate As Double, acceptedFactor As Double
    CopyAccepted accepted
    For point = 1 To mDegreeCount
        If accepted(point) <> 0# Then Exit Function
    Next point
    WriteHardRankRowTest "VIRGIN;" & HardRankVectorTest(accepted)

    Dim index As Long, field() As Double, oldCoordinate As Double, target As Double, seed As Variant
    Dim trialFactor As Double, nextSeed() As Double, stepNumber As Long
    For index = 1 To reference.Count
        field = reference(index): target = HardMeshControlTest(projection, field): seed = field
        oldCoordinate = acceptedCoordinate
        stepNumber = stepNumber + 1
        If Not TryHardMeshStepTest("P" & CStr(index), target, acceptedFactor, offset, direction, projection, seed, trialFactor, True) Then
            target = 0.5 * (oldCoordinate + target)
            CopyAccepted nextSeed: seed = nextSeed
            stepNumber = stepNumber + 1
            If Not TryHardMeshStepTest("I" & CStr(index), target, acceptedFactor, offset, direction, projection, seed, trialFactor, True) Then Exit For
            acceptedCoordinate = target: acceptedFactor = trialFactor
            target = HardMeshControlTest(projection, field): seed = field
            stepNumber = stepNumber + 1
            If Not TryHardMeshStepTest("R" & CStr(index), target, acceptedFactor, offset, direction, projection, seed, trialFactor, True) Then Exit For
        End If
        acceptedCoordinate = target: acceptedFactor = trialFactor
    Next index
    WriteHardRankRowTest "PREFIX-END;" & CStr(index - 1) & ";" & CStr(stepNumber)
    If index > reference.Count Then
        CopyAccepted accepted
        WriteHardRankRowTest "ANCHOR;" & HardRankVectorTest(accepted)
        Dim delta As Variant, guess As Double, i As Long, secantAmplitude As Double, stride As Double
        For i = 1 To mGaugeStart - 1: secantAmplitude = GeomMax(secantAmplitude, Abs(secant(i))): Next i
        For i = 1 To mGaugeStart - 1: stride = stride + projection(i) * secant(i) / secantAmplitude: Next i
        If stride <= 0# Then Exit Function
        ' Три плеча по обе стороны прежней вершины. Одинаковый принятый буфер для всех целей данного разбиения.
        For Each delta In Array(-0.0000005, -0.00000012, -0.000000006, 0.000000006, 0.00000012, 0.0000005)
            target = peakControl + CDbl(delta)
            If target <= acceptedCoordinate Then Exit Function
            field = accepted
            For i = 1 To mDegreeCount: field(i) = field(i) + (target - acceptedCoordinate) * secant(i) / secantAmplitude / stride: Next i
            seed = field: guess = acceptedFactor + (target - acceptedCoordinate) * secantFactor / secantAmplitude / stride
            stepNumber = stepNumber + 1
            If TryHardMeshStepTest("W" & CStr(stepNumber), target, guess, offset, direction, projection, seed, trialFactor, False) Then
                WriteHardRankRowTest "SAMPLE;" & HardRankBitsTest(CDbl(delta))
            End If
            CopyAccepted field
            For i = 1 To mDegreeCount
                If field(i) <> accepted(i) Then Err.Raise 5, "ProbeHardYieldEquilibriumTest", "Проба изменила принятую точку данного разбиения."
            Next i
        Next delta
    End If
    WriteHardRankRowTest "DONE;" & CStr(stepNumber)
    ProbeHardYieldEquilibriumTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет действительные усилия, невязку и историю только после проверки.
Private Function TryHardMeshStepTest(ByVal label As String, ByVal target As Double, ByVal estimate As Double, _
        ByRef offset() As Double, ByRef direction() As Double, ByRef projection() As Double, ByRef seed As Variant, _
        ByRef trialFactor As Double, ByVal commit As Boolean) As Boolean
    Dim absolute As Double, relative As Double, limit As Long
    If commit Then
        absolute = 0.0000005: relative = 0.0000005: limit = 18
    Else
        absolute = 0.00000000005: relative = 0.00000000005: limit = 12
    End If
    WriteHardRankRowTest "BEGIN;" & label & ";" & HardRankBitsTest(target) & ";" & HardRankBitsTest(estimate) & ";" & CStr(commit)
    Dim ok As Boolean, status As CResultMeta
    ok = TryDeformationStep(offset, direction, projection, target, estimate, trialFactor, absolute, relative, _
        limit, consistentControl:=True, initialField:=seed)
    Set status = ResultMeta
    WriteHardRankRowTest "SOLVER;" & CStr(ok) & ";" & CStr(status.InternalStatus) & ";" & CStr(status.ResultCode) & ";" & _
        CStr(mIterations) & ";" & CStr(mEvaluations) & ";" & Replace(status.DiagnosticDetails, ";", "|")
    If ok Then
        Dim field() As Double, actual() As Double, load(1 To COMPONENT_COUNT) As Double, i As Long
        CopyTrial field, actual
        For i = 1 To COMPONENT_COUNT: load(i) = offset(i) + trialFactor * direction(i): Next i
        Dim tolerance As Double, norm As Double, verified As Boolean, uncertainty As Double, bounded As Boolean
        tolerance = EquilibriumTolerance(absolute, relative): norm = EquilibriumNorm(load, field)
        verified = trialFactor > 0# And norm <= tolerance And GaugesVerified(tolerance) And _
            Abs(ControlResidual(field)) <= tolerance
        Dim response As CCoupledReinforcedResponse, longitudinal As Double, transverse As Double
        Set response = YieldResponse(0)
        response.ReadHardMeshSteelTest longitudinal, transverse
        WriteHardRankRowTest "FIELD;" & HardRankVectorTest(field)
        WriteHardRankRowTest "TARGET;" & HardRankVectorTest(load)
        WriteHardRankRowTest "ACTUAL;" & HardRankVectorTest(actual)
        WriteHardRankRowTest "RESIDUAL;" & HardRankVectorTest(mResidual)
        WriteHardRankRowTest "BALANCE;" & HardRankBitsTest(trialFactor) & ";" & HardRankBitsTest(norm) & ";" & _
            HardRankBitsTest(tolerance) & ";" & HardRankBitsTest(ControlResidual(field)) & ";" & _
            HardRankBitsTest(longitudinal) & ";" & HardRankBitsTest(transverse) & ";" & CStr(verified)
        If verified And Not commit Then
            RecordHardSwitchStationsTest field, target
            bounded = TrialLambdaUncertainty(absolute, relative, uncertainty)
            WriteHardRankRowTest "BOUND;" & CStr(bounded) & ";" & HardRankBitsTest(uncertainty)
        End If
        TryHardMeshStepTest = verified And response.TrialSteelUtilization <= 1#
    End If
    If TryHardMeshStepTest And commit Then AcceptStep Else DiscardStep
    WriteHardRankRowTest "END;" & label & ";" & CStr(TryHardMeshStepTest)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Действительное значение замороженной координаты в общем базисе.
Private Function HardMeshControlTest(ByRef projection() As Double, ByRef field() As Double) As Double
    Dim i As Long
    For i = 1 To mGaugeStart - 1
        HardMeshControlTest = HardMeshControlTest + projection(i) * field(i)
    Next i
End Function
