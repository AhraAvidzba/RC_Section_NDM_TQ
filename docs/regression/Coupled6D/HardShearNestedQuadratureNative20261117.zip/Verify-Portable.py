"""Воспроизводит независимые проверки по протоколам из распакованного архива."""

from hashlib import sha256
import json
from pathlib import Path
from subprocess import PIPE, run
import sys


HERE = Path(__file__).resolve().parent


def json_file(path):
    return json.loads((HERE / path).read_text(encoding="utf-8-sig"))


def checksum(path):
    return sha256((HERE / path).read_bytes()).hexdigest().upper()


def validate(mode):
    root = HERE / "Native" / ("Order" + str(mode))
    report = json_file(root / "Verification.json")
    assert report["order"] == mode and not report["physical_limit_certified"]
    closed = json_file(root / "HardShear.txt.ProcessClosure.json")
    assert closed["ChildHasExited"] and not closed["OrdinaryPathKilledAnything"]
    assert closed["Closure"]["FinalState"]["State"] == "Absent"
    env = run([sys.executable, "-B", "-X", "utf8", "Verify.py", "--order", str(mode)], cwd=HERE, stdout=PIPE, check=True)
    print(env.stdout.decode("utf-8").strip())
    return {"order": mode, "outcome": report["outcome"], "prefix": report["prefix_reached"],
            "successes": sum(sample["ready"] for sample in report["window"]),
            "slope_intervals": report["secant_intervals"], "native_seconds": report["proof"]["seconds"],
            "report_sha256": checksum(root / "Verification.json")}


def main():
    hashes = json_file("SHA256SUMS.json")
    actual_files = {file.relative_to(HERE).as_posix() for file in HERE.rglob("*") if file.is_file()}
    assert actual_files == set(hashes) | {"SHA256SUMS.json"}
    for path, expected in hashes.items():
        assert not path.lower().endswith(".xlsm") and checksum(path) == expected, path
    plan = json_file("Fixture.json")
    for source, expected in plan["production"].items():
        assert checksum("Production/" + source) == expected
    compiled = json_file("docs/regression/CodeUpdate.json")
    assert checksum("PriorVerification.json") == plan["prior_report_sha256"]
    assert compiled["ProductionSHA256"] == plan["source_workbook_sha256"]
    data = [validate(order) for order in plan["orders"]]
    pair = run([sys.executable, "-B", "-X", "utf8", "Compare.py", "Native"], cwd=HERE, stdout=PIPE, check=True)
    result = json.loads(pair.stdout)
    assert not result["physical_limit_certified"]
    print(json.dumps({"native": data, "paired": result}, indent=2))
    print("HARDSHEAR_NESTED_QUADRATURE_PORTABLE: VERIFIED_EVIDENCE; physical_limit_certified=False")


if __name__ == "__main__":
    main()
