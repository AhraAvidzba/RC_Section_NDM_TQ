"""Fork only the first MVT2 finer step using the OpenSees 3.8 bounded bisection search."""

import argparse
import ctypes as ct
from ctypes import wintypes
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isfinite
from os import getpid, getppid
from pathlib import Path
import subprocess
import sys
from time import monotonic


HERE = Path(__file__).resolve().parent
BASE_DIR = HERE.parent / "mvt-held-fixed"
BASE_SOURCE_SHA = "7F3CB1E34B206E00ABDA241B7FA585BE376D74A806C75716B8443AD854C3DC15"
BASE_REPLAY_SHA = "1E1338E7014CAC33841B1F7BE41EE2540B2964D0FA57BC868C11F2C66B6715CE"
TARGET = 11.5625
ARGUMENTS = ("NewtonLineSearch", "-type", "Bisection", "-tol", 0.8, "-maxIter", 5, "-maxEta", 1., "-pFlag", 0)
RAW = HERE / "LineSearchHeldTNative.json"
IDENTITY = HERE / "LineSearchIdentity.json"
RECEIPT = HERE / "LineSearchHeldTNative.receipt.json"

sys.dont_write_bytecode = True


def load_base():
    path = BASE_DIR / "Run-FinerHeldT.py"
    digest = lambda data: sha256(data).hexdigest().upper()
    if digest(path.read_bytes()) != BASE_SOURCE_SHA:
        raise ValueError("Frozen Newton prefix controller changed")
    raw = (BASE_DIR / "VerificationFinerHeldTFinal.json").read_bytes()
    report = json.loads(raw)
    if digest(raw) != BASE_REPLAY_SHA or report["verified_Qy_kN"] != 11.25 or report["rejection"]["target_Qy_kN"] != TARGET:
        raise ValueError("Matched Newton failure is unverified")
    spec = spec_from_file_location("held_t_newton", path)
    base = module_from_spec(spec)
    spec.loader.exec_module(base)
    return base


def clock_ticks(handle):
    kernel = ct.WinDLL("kernel32", use_last_error=True)
    kernel.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ct.POINTER(wintypes.FILETIME),) * 4
    times = [wintypes.FILETIME() for _ in range(4)]
    if not kernel.GetProcessTimes(handle, *(ct.byref(field) for field in times)):
        raise ct.WinError(ct.get_last_error())
    return (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime


def current_identity():
    kernel = ct.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    return {"engine_pid": getpid(), "parent_pid": getppid(),
            "kernel_created_filetime": str(clock_ticks(kernel.GetCurrentProcess()))}


def terminate_exact_engine(launcher):
    identity = json.loads(IDENTITY.read_bytes())
    if identity["parent_pid"] != launcher and identity["engine_pid"] != launcher:
        raise ValueError("Timeout owner differs from the launched interpreter")
    kernel = ct.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.TerminateProcess.argtypes = (wintypes.HANDLE, wintypes.UINT)
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    handle = kernel.OpenProcess(0x1001, False, identity["engine_pid"])
    if not handle:
        if ct.get_last_error() == 87:
            return {"target": identity, "requested": False, "state": "already_absent"}
        raise ct.WinError(ct.get_last_error())
    try:
        if clock_ticks(handle) != int(identity["kernel_created_filetime"]):
            raise ValueError("The interpreter PID was reused")
        if not kernel.TerminateProcess(handle, 124):
            raise ct.WinError(ct.get_last_error())
    finally:
        kernel.CloseHandle(handle)
    return {"target": identity, "requested": True, "state": "exact_owned_timeout_termination_requested"}


def prepare(base, wall_seconds):
    # NEXT is empty only while calling the original prefix routine, which then
    # performs no new shear work. Its five archived states still have to match.
    base.NEXT = ()
    stock, geometry, report, torsion, q5, reference = base.preflight(wall_seconds)
    report.update(scope="same held-T accepted prefix then one matched search trial", planned_Qy_kN=list(base.PREFIX + (TARGET,)),
                  planned_new_Qy_kN=[TARGET], maximum_shear_attempts=len(base.PREFIX) + 1,
                  solver_algorithm="NewtonLineSearch", algorithm_command=list(ARGUMENTS),
                  accepted_prefix_algorithm="Newton", archived_newton_check_sha256=BASE_REPLAY_SHA,
                  reference_line_search_api="https://opensees.github.io/OpenSeesDocumentation/user/manual/analysis/algorithm/NewtonLineSearch.html",
                  line_search_activated=False)
    return stock, geometry, report, torsion, q5, reference


def one_probe(base, stock, model, geometry, report, torsion, q5, reference, output, deadline):
    prefix_stop = base.run_schedule(stock, model, geometry, report, torsion, q5, reference, output, deadline)
    if prefix_stop != "all_finer_steps_verified" or not report["prefix_exact"]:
        return prefix_stop
    if monotonic() >= deadline:
        return "bounded_time_before_next_finer_step"
    ops = model.ops
    before = stock.damage.ORIGINAL.rollback_sample(model)
    if before[0] * 15. != 11.25:
        return "prefix_load_mismatch_before_line_search"
    ops.algorithm(*ARGUMENTS)
    report["line_search_activated"] = True
    stock.SHEAR.persist(output, report)
    ops.integrator("LoadControl", TARGET / 15. - before[0])
    started = monotonic()
    code = ops.analyze(1)
    arrived, iterations = ops.getTime(), ops.testIter()
    norms = list(map(float, ops.testNorms()))[:min(iterations, report["Newton_iteration_cap"])]
    if not norms or not all(isfinite(value) and value >= 0. for value in norms):
        raise ValueError("No finite native NormUnbalance trace for the trial")
    step = {"phase": "fixed_T_matched_line_search", "from_Qy_kN": before[0] * 15., "target_Qy_kN": TARGET,
            "observed_Qy_kN": arrived * 15., "solver_code": code, "iterations": iterations,
            "native_global_L2_trace_N": norms, "solver_elapsed_seconds": monotonic() - started}
    report["attempts"].append(step)
    if code:
        after = stock.damage.ORIGINAL.rollback_sample(model)
        step.update(rollback_time_exact=after[0] == before[0], rollback_all_nodes_exact=after[1] == before[1],
                    rollback_sampled_damage_exact=after[2] == before[2])
        return "first_finer_step_rejected_engine_discarded"
    if abs(arrived - TARGET / 15.) > 2e-12:
        return "committed_load_time_mismatch"
    report["shear_confirmed_states"].append(stock.snapshot(model, arrived * 15.))
    return "all_finer_steps_verified"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs", action="store_true")
    mode.add_argument("--start", action="store_true")
    mode.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--wall-seconds", type=int, default=270, choices=range(180, 361))
    opts = parser.parse_args()
    base = load_base()
    if opts.check_inputs:
        prepared = prepare(base, opts.wall_seconds)
        print("LINE_SEARCH_INPUTS_PASS", prepared[2]["prefix_expected_sha256"], TARGET, ARGUMENTS)
        return 0
    if any(path.exists() for path in (RAW, RECEIPT, IDENTITY)):
        raise FileExistsError("A separate new directory is needed for any repeat.")
    if opts.child:
        identity = current_identity()
        with IDENTITY.open("x", encoding="utf-8", newline="\n") as file:
            json.dump(identity, file, sort_keys=True)
        prepared = prepare(base, opts.wall_seconds)
        prepared[2].update(engine_parent_pid=identity["parent_pid"], engine_created_filetime=identity["kernel_created_filetime"])
        wrapper = lambda *args: one_probe(base, *args)
        original = base.run_schedule
        # base.child is the same checked construction of the engine and model.
        # The new child uses its original prefix routine once through the closure.
        def trial(*args):
            base.run_schedule = original
            return wrapper(*args)
        base.run_schedule = trial
        return base.child(prepared, RAW, opts.wall_seconds)
    command = [sys.executable, "-B", "-X", "utf8", str(Path(__file__).resolve()),
               "--child", "--wall-seconds", str(opts.wall_seconds)]
    stdout_path, stderr_path = RAW.with_suffix(".stdout.log"), RAW.with_suffix(".stderr.log")
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        with subprocess.Popen(command, stdout=stdout, stderr=stderr) as launcher:
            started = monotonic()
            cleanup = None
            try:
                exit_code = launcher.wait(timeout=opts.wall_seconds)
            except subprocess.TimeoutExpired:
                cleanup = terminate_exact_engine(launcher.pid)
                exit_code = launcher.wait(timeout=15)
            identity = json.loads(IDENTITY.read_bytes())
            if identity["engine_pid"] != launcher.pid and identity["parent_pid"] != launcher.pid:
                raise ValueError("Windows launcher is unrelated to recorded OpenSees interpreter")
            receipt = {**identity, "popen_pid": launcher.pid, "launcher_exit": exit_code,
                       "wait_returned": launcher.poll() is not None, "timeout_cleanup": cleanup,
                       "wall_elapsed_seconds": monotonic() - started, "hard_cap_seconds": opts.wall_seconds}
    with RECEIPT.open("x", encoding="utf-8", newline="\n") as file:
        file.write(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print("LINE_SEARCH_CLOSED", receipt)
    return 124 if cleanup else exit_code


if __name__ == "__main__":
    sys.exit(main())
