"""Compare retained Newton and NewtonLineSearch observations on the same physical path."""

import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isfinite
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "mvt-held-fixed"
NEWTON_SHA = "1E1338E7014CAC33841B1F7BE41EE2540B2964D0FA57BC868C11F2C66B6715CE"
TARGET = 11.5625
COMMAND = ["NewtonLineSearch", "-type", "Bisection", "-tol", 0.8, "-maxIter", 5, "-maxEta", 1., "-pFlag", 0]


def load_verifier(base):
    spec = spec_from_file_location("previous_newton_proof", base / "Verify-FinerHeldT.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify(previous, raw, receipt, identity, archives, upstream, newton_proof=None):
    v = load_verifier(previous)
    require, digest = v.require, v.digest
    old, old_sha, old_source = v.reference(archives, upstream)
    matched = (newton_proof or previous / "VerificationFinerHeldTFinal.json").read_bytes()
    require(digest(matched) == NEWTON_SHA, "Same target under undamped Newton")
    matched = json.loads(matched)
    prior_residue = matched["rejection"]["native_global_L2_unbalance_N"]
    require(matched["native_sha256"] == digest((previous / "FinerHeldTNative.json").read_bytes()) and
            matched["verified_Qy_kN"] == 11.25 and matched["rejection"]["target_Qy_kN"] == TARGET and
            not matched["rejection"]["rollback_sampled_damage_exact"], "Frozen same-load failure")
    raw_bytes = raw.read_bytes()
    record, closure, owner = json.loads(raw_bytes), json.loads(receipt.read_bytes()), json.loads(identity.read_bytes())
    require(closure["wait_returned"] and closure["timeout_cleanup"] is None and closure["launcher_exit"] == 0, "Engine closure")
    require(owner["engine_pid"] == record["owned_engine_pid"] == closure["engine_pid"] > 0 and
            owner["parent_pid"] == record["engine_parent_pid"] == closure["parent_pid"] and
            owner["kernel_created_filetime"] == record["engine_created_filetime"] == closure["kernel_created_filetime"] and
            closure["popen_pid"] in (owner["engine_pid"], owner["parent_pid"]), "Fresh exact process identity")
    require(record["process_deadline_seconds"] == closure["hard_cap_seconds"] and
            0. < record["engine_elapsed_seconds"] <= closure["wall_elapsed_seconds"] <= closure["hard_cap_seconds"] + 1., "Bounded run")
    require(record["reference_archive_sha256"] == v.UPSTREAM_SHA and record["reference_raw_sha256"] == old_sha and
            record["reference_source_sha256"] == old_source and record["archived_newton_check_sha256"] == NEWTON_SHA, "Source archives")
    require(record["prefix_exact"] and record["replay_passed"] and record["accepted_torsion_replayed"] == 7 and
            record["prefix_expected_sha256"] == record["prefix_observed_sha256"] == v.START_STATE_SHA and
            v.prepared_prefix(record) == v.prepared_prefix(old), "Exact 13 accepted states before solver change")
    require(record["planned_prefix_Qy_kN"] == v.PREFIX and record["planned_new_Qy_kN"] == [TARGET] and
            record["planned_Qy_kN"] == v.PREFIX + [TARGET], "Same single next load target")
    require(record["accepted_prefix_algorithm"] == "Newton" and record["solver_algorithm"] == "NewtonLineSearch" and
            record["algorithm_command"] == COMMAND and record["line_search_activated"], "Bounded algorithm introduced only after prefix")
    require(not (record["physical_limit_established"] or record["prior_Q12_5_damaged_engine_reused"] or
                 record["recoverable_continuation_after_rejection"] or record["restart_from_archived_material_state"]), "Physical scope")
    for name in ("opensees_version", "E_MPa", "nu", "fc_MPa", "ft_MPa", "steel_E_MPa", "steel_yield_MPa", "held_torsion_kNm",
                 "steel_post_yield_slope_MPa", "explicit_Gt_N_per_mm", "explicit_Gc_N_per_mm", "explicit_Lch_mm",
                 "explicit_compression_peak_strain", "ASD_autoRegularization", "compressive_knots", "tensile_knots", "support_mode",
                 "asd_linearization", "kinematics", "pad_xz_size_mm", "validated_input_sha256", "Newton_iteration_cap", "norm_unbalance_force"):
        require(record[name] == old[name], f"Material, loading, or iterative criterion changed: {name}")
    (attempt,) = record["attempts"][12:]
    require(attempt["phase"] == "fixed_T_matched_line_search" and (attempt["from_Qy_kN"], attempt["target_Qy_kN"]) == (11.25, TARGET),
            "One and only one matched new trial")
    norms = attempt["native_global_L2_trace_N"]
    cap, tol = record["Newton_iteration_cap"], record["norm_unbalance_force"]
    require(len(norms) == min(attempt["iterations"], cap) > 0 and all(isfinite(x) and x >= 0. for x in norms), "Global iterative norm trace")
    stderr = raw.with_suffix(".stderr.log").read_text(encoding="utf-8")
    printed = [(int(i), float(eta), float(ratio)) for i, eta, ratio in re.findall(
        r"Bisection Line Search - iteration:\s*(\d+)\s*,\s*eta\(j\)\s*:\s*(\S+)\s*,\s*Ratio \|sj/s0\|\s*=\s*(\S+)", stderr)]
    require(len(printed) <= cap * 5 and all(1 <= i <= 5 and 1./32. <= eta <= 1. and isfinite(rel) for i, eta, rel in printed),
            "Bounded native line-search evaluations")
    result = {"status": "PASS", "native_sha256": digest(raw_bytes), "same_original_prefix_sha256": v.START_STATE_SHA,
              "process_closed": True, "engine_pid": owner["engine_pid"], "launcher_pid": closure["popen_pid"],
              "termination": record["termination"], "trial": attempt, "wall_seconds": closure["wall_elapsed_seconds"],
              "bisection_iterations_observed": printed, "Newton_global_L2_N": prior_residue,
              "LineSearch_global_L2_N": norms[-1], "global_L2_ratio_line_search_over_Newton": norms[-1] / prior_residue,
              "global_iteration_tolerance_N": tol, "physical_limit_established": False}
    rows = record["shear_confirmed_states"][5:]
    if attempt["solver_code"]:
        require(record["termination"] == "first_finer_step_rejected_engine_discarded" and not rows and attempt["solver_code"] == -3,
                "Rejected trial remains unavailable")
        require("NewtonLineSearch::solveCurrentStep()" in stderr and norms[-1] > tol and len(norms) == cap, "Native algorithm and nonconvergence")
        require(attempt["observed_Qy_kN"] == 11.25 and attempt["rollback_time_exact"] and attempt["rollback_all_nodes_exact"] and
                type(attempt["rollback_sampled_damage_exact"]) is bool, "Rollback evidence and retained load")
        result.update(last_verified_Qy_kN=11.25, physical_cut_verification=None)
    else:
        (row,) = rows
        q = row["Qy_kN"]
        require(record["termination"] == "all_finer_steps_verified" and abs(q - TARGET) < 2e-12 and q == attempt["observed_Qy_kN"] and
                abs(row["nominal_midspan_Mx_kNm"] - 0.6 * q) < 2e-12 and norms[-1] <= tol, "Exact committed state and global tolerance")
        pad = v.load_module("line_search_pad_verify", upstream / "Verify-Pads.py")
        tensor = v.load_module("line_search_tensor_verify", upstream / "Verify-Torsion.py")
        result.update(last_verified_Qy_kN=q, physical_cut_verification=pad.verify_state(row["rig_balance"], v.TORQUE_NMM, 2000. * q),
                      concrete_peak_stresses_MPa=tensor.tensors(row), twist_rad_per_m=row["displacement"]["clear_twist_rad_per_m"])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=BASE)
    parser.add_argument("--newton-proof", type=Path)
    parser.add_argument("--raw", type=Path, default=HERE / "LineSearchHeldTNative.json")
    parser.add_argument("--receipt", type=Path, default=HERE / "LineSearchHeldTNative.receipt.json")
    parser.add_argument("--identity", type=Path, default=HERE / "LineSearchIdentity.json")
    parser.add_argument("--archives", type=Path, default=HERE.parents[1] / "docs/regression/Coupled6D")
    parser.add_argument("--upstream", type=Path, default=HERE.parent / "mvt-external/distributed")
    parser.add_argument("--out", type=Path, default=HERE / "VerificationHeldTLineSearch.json")
    parser.add_argument("--reference-only", action="store_true")
    options = parser.parse_args()
    if options.reference_only:
        v = load_verifier(options.base)
        _, old_sha, _ = v.reference(options.archives, options.upstream)
        v.require(v.digest((options.base / "VerificationFinerHeldTFinal.json").read_bytes()) == NEWTON_SHA, "Newton failure proof")
        print("MATCHED LINE SEARCH REFERENCE PASS", old_sha, v.START_STATE_SHA)
        return
    evidence = verify(options.base, options.raw, options.receipt, options.identity, options.archives, options.upstream,
                      options.newton_proof)
    output = (json.dumps(evidence, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    with options.out.open("xb") as report:
        report.write(output)
    print("MATCHED LINE SEARCH PROOF PASS", evidence["last_verified_Qy_kN"], evidence["LineSearch_global_L2_N"], sha256(output).hexdigest().upper())


if __name__ == "__main__":
    main()
