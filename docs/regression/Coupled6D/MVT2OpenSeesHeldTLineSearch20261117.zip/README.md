# Парная проба OpenSees с поиском по направлению Ньютона

Новый процесс сначала повторяет 13 принятых состояний по штатному Newton. В Qy = 11,25 кН сравниваются записанные нагрузки, срезы, перемещения, экстремумы материалов и счётчики всех ступеней. При полном совпадении выполняется одна проба Qy = 11,5625 кН при T = 10,51 кН·м. Именно эту цель исходный Newton отверг при глобальной норме 0,00854183 Н.

`NewtonLineSearch` использует текущую касательную и Bisection с внутренней относительной целью 0,8 и максимумом пятью половинными поправками. Для OpenSees 3.8.0 `maxEta=1` блокирует расширение интервала выше полной поправки. Исходный код бисекции использует интервал [0;1] и до пяти делений, что ограничивает ненулевые показанные множители снизу величиной 1/32. Измерение `NormUnbalance` сохраняет прежние 1e−5 Н и 12 внешних итераций. Записываются все значения глобальной нормы и показанные множители шага. [Описание NewtonLineSearch](https://opensees.github.io/OpenSeesDocumentation/user/manual/analysis/algorithm/NewtonLineSearch.html), [реализация BisectionLineSearch в OpenSees 3.8.0](https://raw.githubusercontent.com/OpenSees/OpenSees/v3.8.0/SRC/analysis/algorithm/equiSolnAlgo/BisectionLineSearch.cpp).

Состояние принимается только при успехе решателя, нужной фактической нагрузке и независимом подтверждении равновесия реакций и шести усилий на контрольных срезах. Глобальная норма относится к системе свободных степеней свободы балки. Проверки усилий относятся к интегралам тензоров на срезах и свободным телам. После первого отказа процесс завершается с точной записью возврата глобальной нагрузки, узлов и выборочных переменных повреждения. [Описание NormUnbalance](https://opensees.github.io/OpenSeesDocumentation/user/manual/analysis/test/NormUnbalance.html).

```powershell
& 'D:/CodexScratch/RC_Section_NDM_TQ/OpenSeesCoupled/Scripts/python.exe' -B -X utf8 tmp/mvt-held-line/Run-HeldTLineSearch.py --check-inputs
python -B -X utf8 tmp/mvt-held-line/Verify-HeldTLineSearch.py --reference-only
& 'D:/CodexScratch/RC_Section_NDM_TQ/OpenSeesCoupled/Scripts/python.exe' -B -X utf8 tmp/mvt-held-line/Run-HeldTLineSearch.py --start --wall-seconds 270
python -B -X utf8 tmp/mvt-held-line/Verify-HeldTLineSearch.py
```
