"""Repeat the signed equilibrium check and compare common exact MVT2 force states."""
from __future__ import annotations

import argparse
import json
from math import degrees
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent
_helpers = runpy.run_path(str(HERE / "Verify-MVT2CrackSensitivity.py"))
BASELINE_FIELDS, data, digest, norm, read, verify = (_helpers[name] for name in
    ("BASELINE_FIELDS", "data", "digest", "norm", "read", "verify"))
source_table = runpy.run_path(str(HERE / "Verify-MarkerOffline.py"))["source_table"]
PREVIOUS = HERE.parent / "MVT2TurnV4"
NATIVE = HERE / "Native"
A_TRACE_SHA256 = "2E362A0EDC31616253D79A15F9B81AC93197A02C6673246028B2F20CE07D3AA5"
A_PROOF_SHA256 = "59835E1D58AF19F5FA958C28621717AE62B45FE7D0FD2AF9577C4C2F19352B71"

def confirm_owner(owner_path: Path, closure_path: Path, compilation_path: Path, preparation_path: Path) -> dict:
    owner, closure, compiler, prep = map(data, (owner_path, closure_path, compilation_path, preparation_path))
    final = closure["Closure"]["FinalState"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and closure["Passed"]
    assert final["State"] == "Absent" and owner["PID"] == final["PID"] and owner["StartTicksUTC"] == final["StartTicksUTC"]
    assert compiler["Compiled"] and not compiler["ProductionChanged"]
    assert compiler["ProductionSHA256"] == prep["book_sha256"] and compiler["Modules"] == ["modTestCoupledExperiment"]
    assert owner["SourceSHA256"] == compiler["WorkbookSHA256"]
    return {"pid": owner["PID"], "start_ticks_UTC": owner["StartTicksUTC"], "source_book_sha256": prep["book_sha256"],
            "isolated_book_sha256": owner["SourceSHA256"], "state": final["State"]}

def a_route() -> tuple[list[dict], dict]:
    raw = PREVIOUS / "Native/MVT2.csv"
    evidence = PREVIOUS / "TurnVerification.json"
    assert digest(raw) == A_TRACE_SHA256 and digest(evidence) == A_PROOF_SHA256
    prior = data(evidence)
    assert prior["trace_sha256"] == A_TRACE_SHA256
    assert prior["status"] == "VerifiedDirected" and prior["matched_force_route_stages"] == 5
    raw_rows = read(raw)
    states = [dict(zip(BASELINE_FIELDS, map(float, row[2:]), strict=True)) for row in raw_rows
              if row[:2] in (["MVT2_STATE", "Combined"], ["MVT2_STATE", "Offset"])]
    statuses = [row for row in raw_rows if row[:3] in (["WANG_PAIR_STATUS", "MVT2", "Combined"],
                                                       ["WANG_PAIR_STATUS", "MVT2", "Offset"])]
    assert len(states) == len(statuses) == 5
    states[0].update(request=0., reached=0.)
    for i, (state, status) in enumerate(zip(states, statuses, strict=True)):
        if i:
            assert (state["request"], state["reached"]) == (float(status[3]), float(status[4]))
        q = state["reached"]
        err = norm(state, [0., 0.6 * q, 0., 10.51, 0., q])
        assert abs(state["residual"] - err) <= 5.e-12 and err <= 5.e-6
    end = statuses[-1]
    assert end[5:9] == ["False", "NumFail", "6", "10"]
    return states, {"last_accepted_Qy_kN": states[-1]["reached"], "requested_Qy_kN": states[-1]["request"],
                    "status": end[6], "code": int(end[8]), "accepted_fields": int(end[10])}

def extract(state: dict) -> dict:
    keys = ("N", "Mx", "My", "T", "Qx", "Qy")
    return {"reached_Qy_kN": state["reached"], "signed_N_Mx_My_T_Qx_Qy_in_kN_and_kNm": [state[key] for key in keys],
            "twist_deg_per_m": degrees(state["twist"]), "kappa_x_per_m": state["kx"],
            "gamma_y": state["gamma"], "max_abs_long_MPa": state["long_MPa"],
            "max_abs_hoop_MPa": state["hoop_MPa"], "long_points_at_yield": int(state["long_at_yield"]),
            "hoop_points_at_yield": int(state["hoop_at_yield"]), "max_tensile_energy_variable": state["tension_energy"],
            "max_compression_energy_variable": state["compression_energy"],
            "min_concrete_principal_MPa": state["min_principal"], "max_concrete_principal_MPa": state["max_principal"],
            "signed_effort_norm_MPa": state["residual"]}

def compare(repo: Path) -> dict:
    physics = data(HERE / "IndependentCrackControl.json")
    source_table(repo, physics)
    manifest = HERE.parent / "ShearManifest.json"
    if manifest.exists():
        assert all(digest(HERE.parent / name) == recorded for name, recorded in data(manifest).items())
    a_owner = confirm_owner(PREVIOUS / "Native/MVT2.txt.Ownership.json", PREVIOUS / "Native/MVT2.txt.ProcessClosure.json",
                            PREVIOUS / "docs/regression/CodeUpdate.json", PREVIOUS / "Preparation.json")
    b_owner = confirm_owner(NATIVE / "ShearB.txt.Ownership.json", NATIVE / "ShearB.txt.ProcessClosure.json",
                            HERE / "docs/regression/CodeUpdate.json", HERE / "Preparation.json")
    a, terminal_a = a_route()
    verify("ShearB")
    proof = data(HERE / "ShearB.Verification.json")
    b = proof["routes"]["B/Shear"]
    b_states = b["states"]
    common = []
    for state_a in a:
        if state_a["reached"] != state_a["request"]:
            continue
        for state_b in b_states:
            if state_b["request"] == state_b["reached"] == state_a["request"]:
                common.append({"Qy_kN": state_a["reached"], "A": extract(state_a), "B": extract(state_b)})
    assert common and common[0]["Qy_kN"] == 0.
    published = repo / "literature/Coupled6D/Wang-Huang-2017-MVT-NMVT.pdf"
    import fitz
    with fitz.open(published) as pdf:
        group = pdf[6].get_text()
        continuation = " ".join(pdf[8].get_text().split())
        assert "67.5 kN" in group and "yielding of the longitudinal reinforcement" in continuation
        assert "shear force reached 80 kN" in continuation and "MVT2 reached its ultimate strength" in continuation
    return {
        "A_owner": a_owner, "B_owner": b_owner, "A_ft_MPa": physics["A_ft_MPa"], "B_ft_MPa": physics["B_ft_MPa"],
        "Gt_N_per_mm": physics["parameters"]["Gt_N_per_mm"], "Gc_N_per_mm": physics["parameters"]["Gc_N_per_mm"],
        "common_exact_force_states": common,
        "A_terminal": {**terminal_a, **extract(a[-1])},
        "B_terminal": {"last_accepted_Qy_kN": b_states[-1]["reached"], "requested_Qy_kN": b_states[-1]["request"],
                       "status": b["terminal_external_status"], "code": b["terminal_code"],
                       "accepted_fields": b["steps_trace"], **extract(b_states[-1])},
        "B_wall_s": proof["wall_s"], "B_route_s": b["elapsed_s"],
        "experiment": {"first_visible_torsion_crack_kNm": 6.5, "preload_torsion_kNm": 10.51,
                       "longitudinal_steel_yield_indicator_Qy_kN": 67.5,
                       "compression_crush_Qy_kN": 80., "compression_crush_Mx_kNm": 48.,
                       "publication_doi": "10.1371/journal.pone.0175834"},
        "limits": "The archived A and new B are directed equilibrium runs. Their terminal accepted forces do not identify physical capacity. Steel maxima on terminal states at different Qy are not paired stress comparisons."
    }

def run(repo: Path) -> None:
    artifact = HERE / "ShearComparison.json"
    artifact.write_text(json.dumps(compare(repo), indent=2) + "\n", encoding="utf-8")
    expected = HERE / "ShearComparison.Expected.json"
    if expected.exists():
        assert artifact.read_bytes() == expected.read_bytes()
    print("MVT2_SHEAR_OFFLINE_PASS", digest(artifact))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path, help="Project containing literature/Coupled6D.")
    run(parser.parse_args().repo.resolve(strict=True))