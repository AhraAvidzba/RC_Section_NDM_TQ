"""ДЛЯ ТЕСТОВ: различает табличные, спектральные и исторические переходы в бетонной точке заблокированного шага."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestAnalyze(repo,root,output):
    """Повторяет неизменённый спектральный закон и сохраняет его действительные внутренние ветви."""
    here=Path(__file__).resolve().parent
    section,history,field,lam,projection,target=run_path(str(here/'Solve-TestRejectedDirection.py'))['TestRestore'](repo,root)
    module=run_path(str(here/'TestClosedASDTangent.py'))
    rows=[line.split(';') for line in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    correction,=[row for row in rows if row[0]=='REJECTED_CORRECTION']; correction=np.asarray(correction[2:],float)
    constant=np.array([0.,0.,0.,10510000.,0.,0.]); direction=np.array([0.,-396.*75000.,0.,0.,0.,75000.])
    states=[]
    for fraction in (0.,1./128.,1./256.,1./512.,1./1024.):
        current=field+fraction*correction[:-1]; factor=lam+fraction*correction[-1]
        strain=section.b@current
        checked=section.TestEvaluate(current,history,constant+factor*direction)
        for station in range(3):
            section.TestTraceLocation=(station,62); trace=[]
            nominal,proposed,tangent,iterations=module['TestConcrete'](section,strain,history,trace=trace)
            assert np.max(np.abs(nominal[:,:section.TestConcreteCount]-checked[3][:,:section.TestConcreteCount]))<8e-7
            for row in trace:
                curve=section.curves[row['branch']]
                row['old_table_segment']=int(np.clip(np.searchsorted(curve.edges,row['old_coordinate']),1,len(curve.x)-1))
                row['new_table_segment']=int(np.clip(np.searchsorted(curve.edges,row['new_coordinate']),1,len(curve.x)-1))
                row['negative_principal_count']=sum(value<0. for value in row['principal'])
            point=62; local_stress=nominal[station,point]
            eigen=np.linalg.eigvalsh(module['TestTensorize'](local_stress))
            states.append({'fraction':fraction,'station':(0,1,-1)[station],'closure_iterations':iterations,'point_ID':63,
                           'principal_nominal_MPa':eigen.tolist(),'strain':strain[station,point].tolist(),
                           'coordinates':proposed[2][:,station,point].tolist(),'closure_trace':trace,
                           'norm_MPa':float(checked[1])})
            print(fraction,'station',(0,1,-1)[station],'nominal principal',eigen,'iterations',iterations,
                  'segments',sorted({(r['branch'],r['old_table_segment'],r['new_table_segment']) for r in trace}),
                  'negative counts',sorted({r['negative_principal_count'] for r in trace}),flush=True)
    result={'point_ID':63,'states':states,'physical_capacity_certified':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); TestAnalyze(args.repo.resolve(),args.root.resolve(),args.out.resolve())
