"""ДЛЯ ТЕСТОВ: проверяет ревизионное продолжение и фактическую нелинейность материала без назначения физического предела."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


def TestRead(file):
    """Читает точные записи, включая численные отказы."""
    return json.loads(file.read_text('utf-8-sig'))


def TestFiles(root):
    """Проверяет исходные байты комплекта перед исполнением проверяющих сценариев."""
    for name,expected in TestRead(root/'Files.json').items(): assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name


def TestNative(repo,root,output):
    """Декодирует все компоненты книг и отличает выполненный численный набор от подтверждённой несущей способности."""
    TestFiles(root)
    source,_=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _,original=reader(BytesIO(source)); shared=run_path(str(root/'Check-TestMaterialRoundoff.py')); cases={}
    for key in TestRead(root/'Cases.json'):
        folder=root/'Cases'/key; reports={}
        record=shared['TestSourceComparison'](repo,root,folder,source,original,helper,body,reader)
        assert record['components']==236 and record['imported']==20 and record['unchanged']==216
        compiler=TestRead(folder/'docs/regression/CodeUpdate.json')
        for log in sorted((folder/'Native').glob('*.txt')):
            text=log.read_text('utf-8-sig'); phase=log.stem
            closure=TestRead(log.with_name(log.name+'.ProcessClosure.json')); owner=TestRead(log.with_name(log.name+'.Ownership.json'))
            assert closure['Passed'] and closure['ChildExitCode']==0 and closure['RunnerCleanupValid']
            assert closure['Closure']['FinalState']['State']=='Absent'
            identity=closure['Closure']['Identity']; assert owner['PID']==identity['PID'] and int(owner['StartTicksUTC'])==identity['Ticks']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==compiler['WorkbookSHA256']
            assert 'SOURCE_UNCHANGED: True' in text and 'RUNTIME ERROR:' not in text
            totals=[tuple(map(int,row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',text,re.M)]
            assert totals and all(failed==0 for passed,failed in totals)
            if phase=='Material': assert totals==[(368,0)]
            if phase=='Core': assert sum(passed for passed,failed in totals)==365
            if phase=='Stock':
                assert totals==[(28,0)]
                assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10460833943358; limit=;' in text
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;',text,re.M)
                reports['stock_seconds']=float(re.search(r'^TIMING_SECONDS: ([\d.]+)',text,re.M)[1])
            if phase in ('Trace44','Trace74'):
                count,=re.findall(r'^PRODUCTION_PATH_COUNT;(\d+)$',text,re.M)
                expected=108 if phase=='Trace74' else {'AllValid':87,'Final':90,'Near':98}[key]
                assert int(count)==expected
                if phase=='Trace44':
                    assert 'смен пространственной меры после отказа: '+str({'AllValid':2,'Final':4,'Near':2}[key]) in text
                    if key in ('Final','Near'): assert 'Исчерпан общий лимит проб' in text and 'проб: 96;' in text
                reports[phase+'_states']=expected
            reports[phase]={'assertions':sum(passed for passed,failed in totals),'scope_execution_completed':True,'physical_capacity_certified':False}
        safety=[json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB']>=6500 and row['freeCommitGiB']>=6 for row in safety)
        assert all(all(item['ProtectedUser'] for item in row['excel']) for row in safety)
        record['reports']=reports; cases[key]=record
    final=root/'Cases/Final'; near=root/'Cases/Near'
    assert set(cases['Final']['reports'])>=set(('Core','Material','Stock','Trace44','Trace74'))
    before=(near/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    rejected='If mControlActive And mUseSpatialHistory And norm <= SMALL_STRAIN_MAX_NORM * tolerance Then'
    retained='If mControlActive And mConsistentControl And norm <= SMALL_STRAIN_MAX_NORM * tolerance Then'
    assert before.count(rejected)==1
    assert before.replace(rejected,retained)==(final/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    for name in ('src/Solver/CCoupledDeformationContinuation.cls','tests/modTestCoupledASDMaterial.bas'):
        assert (near/name).read_bytes()==(final/name).read_bytes()
    prep=TestRead(final/'Preparation.json')
    assert prep['directed_scope']=={'traces':['Trace44','Trace74'],'maximum_probe_count':96,'observation_seconds':480,'full_acceptance':False}
    with TemporaryDirectory() as scratch:
        restored=Path(scratch)
        for name,expected in prep['inputs'].items():
            raw=source if name=='workbook/output/RC_Section_NDM.xlsm' else (final/name).read_bytes()
            file=restored/name; file.parent.mkdir(parents=True,exist_ok=True); file.write_bytes(raw)
            assert sha256(raw).hexdigest().upper()==expected,name
        for name in ('Native','Temp','docs/regression'): (restored/name).mkdir(parents=True,exist_ok=True)
        (restored/'Preparation.json').write_bytes((final/'Preparation.json').read_bytes())
        (restored/'docs/regression/Diagnostic.xlsm').write_bytes(source)
        restoration={'inputs':len(prep['inputs']),'compiled_or_calculated_state_reused':False,'excel_started':False}
    output.write_bytes((json.dumps({'cases':cases,'clean_input_restoration':restoration,'installed_workbook_changed':False,
        'full_acceptance_completed':False,'physical_capacity_certified':False},indent=2,sort_keys=True)+'\n').encode())
    print('ACCEPTED REVISION EXACT VBA AND DIRECTED NATIVE REGRESSIONS VERIFIED; SMALL CORRECTION EXTENSION REJECTED; CAPACITY OPEN')


def TestMechanics(repo,root,output):
    """Повторяет собственные пути и проверяет все три станции выбранной бетонной точки на сохранённых долях поправки."""
    TestFiles(root); records={}
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        for key,phase in (('AllValid','Trace44'),('Final','Trace44'),('Near','Trace44'),('Final','Trace74')):
            result=scratch/(key+phase+'.json')
            run_path(str(root/'Validate-TestGeneralContinuation.py'))['TestValidate'](repo,root/'Cases'/key,phase,result,44 if phase=='Trace44' else 74)
            records[key+phase]=TestRead(result)
        result=scratch/'LocalTransition.json'
        run_path(str(root/'Analyze-TestLocalTransition.py'))['TestAnalyze'](repo,root/'Reference/Direction',result)
        transition=TestRead(result); assert len(transition['states'])==15
        for row in transition['states']:
            assert row['point_ID']==63 and row['station'] in (0,1,-1)
            assert {item['negative_principal_count'] for item in row['closure_trace']}=={1}
            assert {(item['branch'],item['old_table_segment'],item['new_table_segment']) for item in row['closure_trace']}=={(0,3,3),(1,1,1)}
        # Конечная разность не считается переключением ветви без подтверждения локальных состояний.
        direction=TestRead(root/'Reference/Direction/DirectionProof.json')
        second=[]
        for fraction in (1./128.,1./256.,1./512.):
            row,=[item for item in direction['samples'] if item['fraction']==fraction]
            second.append((row['row80_directional_derivative_MPa']-direction['row80_spectral_matrix_action_MPa'])/fraction)
        assert max(second)/min(second)<1.02 and min(second)>0.
        records['LocalTransition']={'point_ID':63,'states':15,'table_segments_unchanged':True,'spectral_sign_counts_unchanged':True,
                                    'row80_quadratic_coefficients_MPa':second,'physical_capacity_certified':False}
    output.write_bytes((json.dumps({'cases':records,'physical_capacity_certified':False,'full_acceptance_completed':False},indent=2,sort_keys=True)+'\n').encode())
    print('ACCEPTED REVISION ALL SIX EQUILIBRIA AND THREE-STATION LOCAL NONLINEARITY VERIFIED; PHYSICAL LIMIT OPEN')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--scope',choices=('native','mechanics'),required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); (TestNative if args.scope=='native' else TestMechanics)(args.repo.resolve(),args.root.resolve(),args.out.resolve())
