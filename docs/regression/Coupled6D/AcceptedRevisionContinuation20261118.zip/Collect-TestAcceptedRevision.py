"""ДЛЯ ТЕСТОВ: сохраняет полный отказавший шаг, ревизии принятой истории и отвергнутую малую поправку."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestCollect(repo,root):
    """Переиспользует точное сохранение нативных книг; первичную позднюю итерацию берёт из закреплённого архива."""
    here=Path(__file__).resolve().parent
    collector=run_path(str(here/'Collect-TestFieldRecovery.py'))
    collector['TestCases'].clear(); collector['TestCases'].update({
        'AllValid':'CompleteRejectedDirection20261118','Final':'AcceptedRevisionControl20261118','Near':'SpatialNearEquilibrium20261118'})
    collector['TestCollect'](repo,root)
    for name in ('Collect-TestAcceptedRevision.py','Check-TestAcceptedRevision.py','Analyze-TestLocalTransition.py'):
        collector['TestCopy'](here/name,root/name)
    raw=(repo/'docs/regression/Coupled6D/SpatialFieldControlRecovery20261118.zip').read_bytes()
    expected='39E04FF77B8845FCE4A3EBE0F091F1B1ABB44155FB9E3734E2906CD86D4A8539'; assert sha256(raw).hexdigest().upper()==expected
    names=('AcceptedHistory.csv','Native/ControlProbe.csv','Native/ControlProbe.Operators.csv','DirectionProof.json')
    pins={}
    with ZipFile(BytesIO(raw)) as archive:
        for name in names:
            value=archive.read('Cases/Direction/'+name); target=root/'Reference/Direction'/name
            target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(value); pins[name]=sha256(value).hexdigest().upper()
    (root/'Reference/SourceArchive.json').write_bytes((json.dumps({'archive_sha256':expected,'files':pins},indent=2,sort_keys=True)+'\n').encode())
    (root/'SourceCheckpoint.json').write_bytes((json.dumps({'base':'6c9f1fa','installed_workbook_changed':False,
        'physical_capacity_certified':False,'full_acceptance_completed':False},indent=2)+'\n').encode())
    files={p.relative_to(root).as_posix():sha256(p.read_bytes()).hexdigest().upper()
           for p in root.rglob('*') if p.is_file() and p.name!='Files.json'}
    (root/'Files.json').write_bytes((json.dumps(files,indent=2,sort_keys=True)+'\n').encode())
    print('ACCEPTED REVISION EVIDENCE COLLECTED',len(files))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestCollect(args.repo.resolve(),args.root.resolve())
