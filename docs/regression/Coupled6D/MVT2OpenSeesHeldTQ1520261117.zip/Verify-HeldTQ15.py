"""Verify MVT2 continuation and, if reached, its exact Q15 comparison with NDM."""

import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isfinite
from pathlib import Path
import re
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
ARCHIVES = HERE.parents[1] / "docs/regression/Coupled6D"
PREVIOUS_NAME = "MVT2OpenSeesHeldTNewton2420261117.zip"
PREVIOUS_SHA = "2F7A8A5F21C91FA0122CCC24817069B8369D7654EC19271A5BA223742F7F6005"
PREVIOUS_PROOF = "FC5D9E7235D78530484B410CCD97F48EFBF4780292D08991C07AFBE1420F4843"
NDM_SHA = "DEA4CCBB06ECCCECE9B076BF4D1B2ACA2DD7FCC4E84786FCE740FDFD6581FAB3"
BASE_Q = 11.5625
QY = [11.875, 12.1875, 12.5, 12.8125, 13.125, 13.4375, 13.75, 14.0625, 14.375, 14.6875, 15.]
RAW = "HeldTQ15Native.json"
RECEIPT = "HeldTQ15Native.receipt.json"
IDENTITY = "HeldTQ15Identity.json"
RESOURCES = "HeldTQ15Resources.json"
PROOF = "VerificationHeldTQ15.json"
OUTPUT_FILES = (RAW, RECEIPT, IDENTITY, RESOURCES, "HeldTQ15Native.stdout.log", "HeldTQ15Native.stderr.log")


def digest(data):
    return sha256(data).hexdigest().upper()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def require(condition, diagnostic):
    if not condition:
        raise ValueError(diagnostic)


def predecessor(packet, archives, temp):
    require(digest(packet.read_bytes()) == PREVIOUS_SHA, "Exact archived accepted Q11.5625 run")
    with ZipFile(packet) as original:
        manifest = json.loads(original.read("SHA256SUMS.json"))
        require(set(original.namelist()) == set(manifest) | {"SHA256SUMS.json"}, "Previous manifest")
        for name, wanted in manifest.items():
            data = original.read(name)
            require(digest(data) == wanted, name)
            (temp / name).write_bytes(data)
        proof = original.read("VerificationHeldTNewton24.json")
    require(digest(proof) == PREVIOUS_PROOF, "Independent Q11.5625 evidence hash")
    spec = spec_from_file_location("previous_engine_proof", temp / "Verify-HeldTNewton24.py")
    verifier = module_from_spec(spec)
    spec.loader.exec_module(verifier)
    helper_path = temp / "Helpers"
    helper_path.mkdir()
    previous = verifier.from_data(temp, archives, helper_path)
    require(previous == json.loads(proof) and previous["last_verified_Qy_kN"] == BASE_Q, "Exact reproduced prior result")
    old = json.loads((temp / "Newton24HeldTNative.json").read_bytes())
    again = helper_path / "Again"
    again.mkdir()
    prior_v, upstream, _original, _old_sha, _old_source, _base12, _line_search = verifier.reprove_prior(archives, again)
    return verifier, prior_v, upstream, old, previous


def confirm_close(record, host, owner, memory):
    require(host["wait_returned"] and host["hard_cap_seconds"] == record["process_deadline_seconds"] == 600,
            "Exact owned process after bounded launcher wait")
    require(owner["engine_pid"] == record["owned_engine_pid"] == host["engine_pid"] > 0 and
            owner["parent_pid"] == record["engine_parent_pid"] == host["parent_pid"] and
            owner["kernel_created_filetime"] == record["engine_created_filetime"] == host["kernel_created_filetime"] and
            host["popen_pid"] in (owner["parent_pid"], owner["engine_pid"]), "PID, Windows parent and exact creation tick")
    require(memory["available_RAM_MiB"] >= 6500 and memory["free_commit_GiB"] >= 8 and
            memory["free_workspace_drive_MiB"] >= 16 and memory["free_scratch_D_GiB"] >= 4, "Resource headroom")
    if host["timeout_cleanup"] is None:
        require(host["launcher_exit"] == 0 and 0. < record["engine_elapsed_seconds"] <= host["wall_elapsed_seconds"] <= 601., "Ordinary closure")
        return False
    cleanup = host["timeout_cleanup"]
    require(cleanup["target"] == owner and record["termination"] == "running" and
            cleanup["requested"] and 600 <= host["wall_elapsed_seconds"] <= 616., "Exact watchdog termination")
    return True


def exact_prefix(record, old, previous, v, native_sha):
    require(record["prior_newton24_archive_sha256"] == PREVIOUS_SHA and record["prior_newton24_proof_sha256"] == PREVIOUS_PROOF and
            record["prior_newton24_native_sha256"] == native_sha, "Original accepted Q11.5625 archive")
    require(record["prefix_exact"] and record["Q11_5625_exact"] and old["prefix_exact"] and
            record["prefix_observed_sha256"] == record["prefix_expected_sha256"] == previous["initial_prefix_sha256"], "Two accepted prefix gates")
    require(v.prepared_prefix(record) == v.prepared_prefix(old), "Every archived initial record exactly reproduced")
    require(record["shear_confirmed_states"][:6] == old["shear_confirmed_states"], "All data at Q11.5625 exactly reproduced")
    archived = old["attempts"][-1]
    observed = record["attempts"][12]
    require(all(observed[key] == value for key, value in archived.items() if key != "solver_elapsed_seconds"),
            "Complete 13-iteration Q11.5625 trace exactly reproduced")
    for key in ("reference_archive_sha256", "reference_raw_sha256", "reference_source_sha256", "archived_newton_check_sha256", "opensees_version",
                "E_MPa", "nu", "fc_MPa", "ft_MPa", "steel_E_MPa", "steel_yield_MPa", "held_torsion_kNm", "steel_post_yield_slope_MPa",
                "explicit_Gt_N_per_mm", "explicit_Gc_N_per_mm", "explicit_Lch_mm", "ASD_autoRegularization", "explicit_compression_peak_strain",
                "tensile_knots", "compressive_knots", "support_mode", "asd_linearization", "kinematics", "pad_xz_size_mm", "validated_input_sha256",
                "integrator_sha256", "norm_unbalance_force", "Newton_iteration_cap", "accepted_prefix_Newton_iteration_cap", "convergence_test_command",
                "accepted_prefix_algorithm", "solver_algorithm", "newton24_activated"):
        require(record[key] == old[key], f"Unchanged model or criteria: {key}")
    require(record["Newton_iteration_cap"] == 24 and record["norm_unbalance_force"] == 1e-5 and record["held_torsion_kNm"] == 10.51,
            "Frozen Newton, cut criteria and torsion scope")
    require(not (record["physical_limit_established"] or record["prior_Q12_5_damaged_engine_reused"] or
                 record["recoverable_continuation_after_rejection"] or record["restart_from_archived_material_state"]), "No reuse or physical inference")


def verified_steps(record, v, previous_verifier, upstream, old_result, prescribed, stderr, hard_timeout):
    remaining = iter(record["shear_confirmed_states"][6:])
    attempts = record["attempts"][13:]
    require(len(attempts) <= len(prescribed), "Maximum eleven new advances")
    old_tol = record["norm_unbalance_force"]
    cap = record["Newton_iteration_cap"]
    last = BASE_Q
    accepted, rejection = [], None
    for index, trial in enumerate(attempts):
        target = prescribed[index]
        require(trial["phase"] == "fixed_T_newton24_continuation" and trial["target_Qy_kN"] == target and
                abs(trial["from_Qy_kN"] - last) < 2e-12 and 0. < trial["solver_elapsed_seconds"], "Fixed step from last certified load")
        norms = trial["native_global_L2_trace_N"]
        require(len(norms) == min(trial["iterations"], cap) > 0 and all(isfinite(n) and n >= 0. for n in norms), "Full finite Newton trace")
        if trial["solver_code"]:
            require(index == len(attempts) - 1 and not hard_timeout and trial["solver_code"] == -3, "Terminal rejection without reuse")
            require(all(type(trial[key]) is bool for key in ("rollback_time_exact", "rollback_all_nodes_exact", "rollback_sampled_damage_exact")), "Rollback readout")
            if trial["rollback_time_exact"]:
                require(abs(trial["observed_Qy_kN"] - last) < 2e-12, "Observed retained load")
            require("NewtonRaphson::solveCurrentStep()" in stderr and "NewtonLineSearch" not in stderr, "Declared Newton error path")
            printed = re.findall(r"after:\s*(\d+)\s+iterations\s+current Norm:\s*(\S+)\s+\(max:\s*(\S+),", stderr)
            rejection = dict(trial)
            if printed:
                ((iterations, value, limit),) = printed
                require(int(iterations) == cap and float(limit) == old_tol and
                        previous_verifier.matches_native_print(norms[-1], value) and all(n > old_tol for n in norms), "Exhaustion of original convergence criterion")
                rejection["reason"] = "global_iteration_limit"
            else:
                rejection["reason"] = "other_Newton_step_error"
            break
        require(norms[-1] <= old_tol and all(n > old_tol for n in norms[:-1]), "Original global convergence criterion")
        row = next(remaining)
        require(abs(row["Qy_kN"] - target) < 2e-12 and row["Qy_kN"] == trial["observed_Qy_kN"], "Independent accepted load observation")
        audit = previous_verifier.physical_audit(v, upstream, row)
        accepted.append({"trial": trial, **audit})
        last = row["Qy_kN"]
    require(next(remaining, None) is None, "Unexplained new accepted state")
    require(abs(record["last_certified_Qy_kN"] - last) < 2e-12, "Last certified load summary")
    if hard_timeout:
        require(len(attempts) < len(prescribed) and record["in_flight_Qy_kN"] == prescribed[len(attempts)], "Unverified in-flight watchdog trial")
        termination = "bounded_watchdog_discarded_engine"
    else:
        require(record["in_flight_Qy_kN"] is None, "No trial pending after ordinary exit")
        termination = record["termination"]
        expected = "first_finer_step_rejected_engine_discarded" if rejection else (
            "all_finer_steps_verified" if len(accepted) == len(prescribed) else "bounded_time_before_next_finer_step")
        require(termination == expected, "Terminal transition matches evidence")
    require(old_result["tested_new_cut_equilibrium"]["Qy_kN"] == BASE_Q, "Independent Q11.5625 foundation")
    return last, accepted, rejection, termination


def verify(data, previous, archives, temp):
    old_dir = temp / "Old"
    old_dir.mkdir()
    prior_verifier, v, upstream, old, old_proof = predecessor(previous, archives, old_dir)
    raw_bytes = (data / RAW).read_bytes()
    record, host, owner, memory = [json.loads((data / name).read_bytes()) for name in (RAW, RECEIPT, IDENTITY, RESOURCES)]
    timeout = confirm_close(record, host, owner, memory)
    exact_prefix(record, old, old_proof, v, old_proof["native_sha256"])
    require(record["planned_prefix_Qy_kN"] == [6.25, 7.5, 8.75, 10., 11.25] and record["planned_new_Qy_kN"] == [BASE_Q, *QY] and
            record["planned_Qy_kN"] == [*record["planned_prefix_Qy_kN"], BASE_Q, *QY] and record["maximum_shear_attempts"] == 17,
            "Exact input schedule including Q15")
    stderr = (data / "HeldTQ15Native.stderr.log").read_text(encoding="utf-8")
    last, accepted, rejected, stop = verified_steps(record, v, prior_verifier, upstream, old_proof, QY, stderr, timeout)
    comparison = None
    if abs(last-15.) < 2e-12:
        archived_ndm = archives / "MVT2ShearABOffline.zip"
        require(digest(archived_ndm.read_bytes()) == NDM_SHA, "Exact NDM comparison archive")
        shear = v.load_module("held_newton24_shear", upstream / "Verify-Shear.py")
        comparison = {"Qy_kN": last, "T_kNm": 10.51, "nominal_midspan_Mx_kNm": 9.,
                      "OpenSees_twist_interval_local_Mx_kNm": [4.5, 5.4],
                      "OpenSees_clear_twist_rad_per_m": accepted[-1]["observed_clear_twist_rad_per_m"],
                      "NDM_nominal_combination": shear.validated_ndm(archived_ndm, record)[15.],
                      "identical_ft_and_nominal_forces_only": "B; material tensor law and local Mx in the twist readout differ"}
    return {"status": "PASS", "native_sha256": digest(raw_bytes), "reproduced_prefix_state_count": 14,
            "prefix_Q11_5625_matches_archived_trace_and_cut_record": True, "last_verified_Qy_kN": last,
            "termination": stop, "new_accepted_states": accepted, "rejection": rejected,
            "comparison_at_Q15": comparison, "physical_limit_established": False,
            "engine_pid": owner["engine_pid"], "launcher_pid": host["popen_pid"], "process_closed": True,
            "wall_seconds": host["wall_elapsed_seconds"], "resources_before_start": memory}


def bundle_data(bundle, previous, archives, scratch):
    native = scratch / "Native"
    native.mkdir()
    with ZipFile(bundle) as packet:
        manifest = json.loads(packet.read("SHA256SUMS.json"))
        require(set(packet.namelist()) == set(manifest) | {"SHA256SUMS.json"}, "Exact portable package contents")
        require(all(digest(packet.read(name)) == wanted for name, wanted in manifest.items()), "Portable bytes match manifest")
        for name in OUTPUT_FILES:
            (native / name).write_bytes(packet.read(name))
        result = verify(native, previous, archives, scratch)
        require(encode(result) == packet.read(PROOF), "Identical archived proof")
    return result


def seal(bundle, data, verified):
    names = (*OUTPUT_FILES, "Run-HeldTQ15.py", "Verify-HeldTQ15.py", "README.md")
    files = {name: (data / name).read_bytes() for name in names}
    files[PROOF] = verified
    files["SHA256SUMS.json"] = encode({name: digest(value) for name, value in files.items()})
    with bundle.open("xb") as stream, ZipFile(stream, "w") as packet:
        for name, value in sorted(files.items()):
            item = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0)); item.compress_type = ZIP_DEFLATED
            packet.writestr(item, value, compresslevel=9)
    print("SEALED Q15 EVIDENCE", digest(bundle.read_bytes()), bundle)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives", type=Path, default=ARCHIVES)
    parser.add_argument("--previous", type=Path)
    parser.add_argument("--data", type=Path, default=HERE)
    parser.add_argument("--out", type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--bundle", type=Path)
    mode.add_argument("--pack", type=Path)
    mode.add_argument("--reference-only", action="store_true")
    options = parser.parse_args()
    previous = options.previous or (options.archives / PREVIOUS_NAME)
    if options.previous is None and not previous.is_file():
        previous = HERE.parent / "mvt-held-newton24" / PREVIOUS_NAME
    with TemporaryDirectory(prefix="MVT2HeldQ15Proof_") as temp:
        folder = Path(temp)
        if options.reference_only:
            _, _, _, _, pre = predecessor(previous, options.archives, folder)
            print("Q15 REFERENCE PASS", pre["last_verified_Qy_kN"], pre["native_sha256"])
            return
        result = bundle_data(options.bundle, previous, options.archives, folder) if options.bundle else verify(options.data, previous, options.archives, folder)
    evidence = encode(result)
    if options.pack:
        seal(options.pack, options.data, evidence)
    if options.out or not (options.bundle or options.pack):
        with (options.out or options.data / PROOF).open("xb") as output:
            output.write(evidence)
    print("Q15 PROOF PASS", result["last_verified_Qy_kN"], result["termination"], digest(evidence))


if __name__ == "__main__":
    main()
