"""Cold replay the accepted MVT2 history, then follow fixed steps to Qy=15 kN."""

import argparse
import ctypes as ct
from ctypes import wintypes
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isfinite
from pathlib import Path
import shutil
import subprocess
import sys
from time import monotonic
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / "mvt-held-newton24"
ARCHIVES = HERE.parents[1] / "docs/regression/Coupled6D"
PRIOR_NAME = "MVT2OpenSeesHeldTNewton2420261117.zip"
PRIOR_ARCHIVE = "2F7A8A5F21C91FA0122CCC24817069B8369D7654EC19271A5BA223742F7F6005"
PRIOR_RUN = "96633FA97CA477E160EF55A897D0CB08E189AE97800D69C848F268954CF4A426"
PRIOR_RAW = "A93723D1539B8DFE974083C385951E4815C4BCB1860743CA82586B59A8BEAB15"
PRIOR_PROOF = "FC5D9E7235D78530484B410CCD97F48EFBF4780292D08991C07AFBE1420F4843"
TARGETS = tuple(11.5625 + i * 0.3125 for i in range(1, 12))
RAW = HERE / "HeldTQ15Native.json"
IDENTITY = HERE / "HeldTQ15Identity.json"
RECEIPT = HERE / "HeldTQ15Native.receipt.json"
RESOURCES = HERE / "HeldTQ15Resources.json"
WALL_SECONDS = 600

sys.dont_write_bytecode = True


def digest(value):
    return sha256(value).hexdigest().upper()


def pin_prior():
    packet = ARCHIVES / PRIOR_NAME
    if not packet.is_file():
        packet = PRIOR / PRIOR_NAME
    assert digest(packet.read_bytes()) == PRIOR_ARCHIVE
    script = PRIOR / "Run-HeldTNewton24.py"
    with ZipFile(packet) as archive:
        native = archive.read("Newton24HeldTNative.json")
        proof = archive.read("VerificationHeldTNewton24.json")
        assert digest(native) == PRIOR_RAW and digest(proof) == PRIOR_PROOF
        assert script.read_bytes() == archive.read(script.name) and digest(script.read_bytes()) == PRIOR_RUN
    old = json.loads(native)
    verified = json.loads(proof)
    assert old["termination"] == "all_finer_steps_verified" and old["prefix_exact"]
    assert old["attempts"][-1]["solver_code"] == 0 and old["attempts"][-1]["iterations"] == 13
    assert verified["last_verified_Qy_kN"] == 11.5625 and verified["tested_new_cut_equilibrium"]
    spec = spec_from_file_location("pinned_newton24", script)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, old


def preparation(prior, base):
    prepared = prior.prepare(base, WALL_SECONDS)
    report = prepared[2]
    report.update(scope="cold full accepted path through Q11.5625, then Q15 by fixed increments",
                  prior_newton24_archive_sha256=PRIOR_ARCHIVE, prior_newton24_native_sha256=PRIOR_RAW,
                  prior_newton24_proof_sha256=PRIOR_PROOF, Q11_5625_exact=False,
                  planned_new_Qy_kN=[11.5625, *TARGETS], planned_Qy_kN=[*base.PREFIX, 11.5625, *TARGETS],
                  maximum_shear_attempts=len(base.PREFIX)+1+len(TARGETS), in_flight_Qy_kN=None,
                  last_certified_Qy_kN=None)
    return prepared


def exact_replay(base, report, expected):
    keys = ("phase", "from_Qy_kN", "target_Qy_kN", "observed_Qy_kN", "solver_code", "iterations", "native_global_L2_trace_N")
    actual, prior = report["attempts"][-1], expected["attempts"][-1]
    if any(actual[key] != prior[key] for key in keys):
        return False
    return base.wire(report["shear_confirmed_states"][-1]) == base.wire(expected["shear_confirmed_states"][-1])


def continue_path(prior, base, expected, stock, model, geometry, report, torsion, q5, reference, output, deadline):
    prelude = prior.one_probe(base, stock, model, geometry, report, torsion, q5, reference, output, deadline)
    if prelude != "all_finer_steps_verified":
        return prelude
    if not exact_replay(base, report, expected):
        return "Q11_5625_exact_replay_mismatch"
    report.update(Q11_5625_exact=True, last_certified_Qy_kN=11.5625)
    stock.SHEAR.persist(output, report)

    ops = model.ops
    for target in TARGETS:
        if monotonic() >= deadline:
            return "bounded_time_before_next_finer_step"
        before = stock.damage.ORIGINAL.rollback_sample(model)
        if abs(before[0] * 15. - report["last_certified_Qy_kN"]) > 2e-12:
            return "accepted_load_drift_before_next_step"
        report["in_flight_Qy_kN"] = target
        stock.SHEAR.persist(output, report)
        ops.integrator("LoadControl", target / 15. - before[0])
        started = monotonic()
        code = ops.analyze(1)
        arrived, iterations = ops.getTime(), ops.testIter()
        norms = list(map(float, ops.testNorms()))[:min(iterations, report["Newton_iteration_cap"])]
        if not norms or not all(isfinite(value) and value >= 0. for value in norms):
            raise ValueError("Missing finite Newton iteration history at fixed T")
        trial = {"phase": "fixed_T_newton24_continuation", "from_Qy_kN": before[0] * 15., "target_Qy_kN": target,
                 "observed_Qy_kN": arrived * 15., "solver_code": code, "iterations": iterations,
                 "native_global_L2_trace_N": norms, "solver_elapsed_seconds": monotonic() - started}
        report["attempts"].append(trial)
        if code:
            after = stock.damage.ORIGINAL.rollback_sample(model)
            trial.update(rollback_time_exact=before[0] == after[0], rollback_all_nodes_exact=before[1] == after[1],
                         rollback_sampled_damage_exact=before[2] == after[2])
            report["in_flight_Qy_kN"] = None
            return "first_finer_step_rejected_engine_discarded"
        if abs(arrived * 15. - target) > 2e-12:
            return "committed_load_time_mismatch"
        report["shear_confirmed_states"].append(stock.snapshot(model, arrived * 15.))
        report.update(last_certified_Qy_kN=arrived * 15., in_flight_Qy_kN=None)
        stock.SHEAR.persist(output, report)
    return "all_finer_steps_verified"


def resource_check():
    class Perf(ct.Structure):
        _fields_ = [("size", wintypes.DWORD)] + [(name, ct.c_size_t) for name in
                    ("commit", "limit", "peak", "physical", "available", "cache", "kernel", "paged", "nonpaged", "page")] + [
                    (name, wintypes.DWORD) for name in ("handles", "processes", "threads")]
    data = Perf()
    data.size = ct.sizeof(data)
    if not ct.WinDLL("psapi", use_last_error=True).GetPerformanceInfo(ct.byref(data), data.size):
        raise ct.WinError(ct.get_last_error())
    result = {"available_RAM_MiB": data.available*data.page/2**20,
              "free_commit_GiB": (data.limit-data.commit)*data.page/2**30,
              "free_workspace_drive_MiB": shutil.disk_usage(HERE).free/2**20,
              "free_scratch_D_GiB": shutil.disk_usage("D:/").free/2**30}
    # OpenSees writes the small JSON twice during an atomic save plus its logs.
    # The workspace has no workbook copy or other large generated files here.
    if result["available_RAM_MiB"] < 6500 or result["free_commit_GiB"] < 8 or result["free_workspace_drive_MiB"] < 16 or result["free_scratch_D_GiB"] < 4:
        raise RuntimeError(f"Insufficient memory or disk reserve: {result}")
    return result


def write_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs", action="store_true")
    mode.add_argument("--start", action="store_true")
    mode.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    opts = parser.parse_args()
    prior, expected = pin_prior()
    base = prior.load_base()
    if opts.check_inputs:
        data = preparation(prior, base)
        print("Q15 INPUTS PASS", data[2]["prefix_expected_sha256"], PRIOR_RAW, TARGETS, resource_check())
        return 0
    if opts.child:
        identity = prior.current_identity()
        write_new(IDENTITY, identity)
        prepared = preparation(prior, base)
        prepared[2].update(engine_parent_pid=identity["parent_pid"], engine_created_filetime=identity["kernel_created_filetime"])
        original = base.run_schedule

        def route(*args):
            base.run_schedule = original
            return continue_path(prior, base, expected, *args)

        base.run_schedule = route
        return base.child(prepared, RAW, WALL_SECONDS)
    if any(path.exists() for path in (RAW, RECEIPT, IDENTITY, RESOURCES)):
        raise FileExistsError("Archive the original run and use a new lane for repetitions.")
    write_new(RESOURCES, resource_check())
    command = [sys.executable, "-B", "-X", "utf8", str(Path(__file__).resolve()), "--child"]
    with RAW.with_suffix(".stdout.log").open("xb") as stdout, RAW.with_suffix(".stderr.log").open("xb") as stderr:
        with subprocess.Popen(command, stdout=stdout, stderr=stderr) as launcher:
            started = monotonic()
            print("Q15 NATIVE LAUNCHER PID", launcher.pid, flush=True)
            cleanup = None
            try:
                exit_code = launcher.wait(timeout=WALL_SECONDS)
            except subprocess.TimeoutExpired:
                prior.IDENTITY = IDENTITY
                cleanup = prior.terminate_exact_engine(launcher.pid)
                exit_code = launcher.wait(timeout=15)
            identity = json.loads(IDENTITY.read_bytes())
            if launcher.pid not in (identity["parent_pid"], identity["engine_pid"]):
                raise ValueError("Engine startup is not owned by this launcher")
            write_new(RECEIPT, {**identity, "popen_pid": launcher.pid, "launcher_exit": exit_code,
                               "wait_returned": launcher.poll() is not None, "timeout_cleanup": cleanup,
                               "wall_elapsed_seconds": monotonic()-started, "hard_cap_seconds": WALL_SECONDS})
    print("Q15 NATIVE CLOSED", RECEIPT.name, exit_code, flush=True)
    return 124 if cleanup else exit_code


if __name__ == "__main__":
    sys.exit(main())
