"""ДЛЯ ТЕСТОВ. Проверяет локальное включение резерва, сохраняя отрицательные результаты и открытый предел."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def TestFiles(root):
    """Каждый исходник и нативный протокол должен совпадать с закреплёнными байтами."""
    for name, digest in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == digest, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == '1387effe7f9e669afcd78959a40b9405fbf0e875'


def TestNative(repo, root, output):
    """Проверяет фактический код всех четырёх книг и отличает завершённый отрицательный опыт от общего PASS."""
    TestFiles(root)
    audit = run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit']
    plans = {'Sensitivity': {'HybridSensitivity': (1, 3, 1)},
             'Unconditional': {'HybridCore': (0, 31, 0), 'Core': (0, 382, 0), 'PeakRegression': (0, 168, 0), 'Stock': (0, 28, 0)},
             'Final': {'HybridCore': (0, 31, 0), 'Core': (0, 382, 0), 'PeakRegression': (0, 168, 0), 'Stock': (0, 28, 0)},
             'API': {'IntegratedHybrid': (0, 4, 0)}}
    cases = {}
    for case, phases in plans.items():
        folder = root / 'Cases' / case
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'VBA.json'
            audit(repo, folder, proof)
            record = json.loads(proof.read_bytes())
        assert (record['components'], record['imported'], record['unchanged']) == ((244, 30, 214) if case in ('Unconditional', 'Final') else (245, 31, 214))
        assert len(record['checked_coupled_sources']) == 33
        assert {file.stem for file in (folder / 'Native').glob('*.txt')} == set(phases)
        reports = {}
        for phase, (expected_exit, passed, failed) in phases.items():
            log_path = folder / 'Native' / (phase + '.txt')
            log = log_path.read_text('utf-8-sig')
            closure = json.loads(log_path.with_name(log_path.name + '.ProcessClosure.json').read_bytes())
            assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == expected_exit
            assert closure['Closure']['FinalState']['State'] == 'Absent'
            assert closure['RunnerCleanupValid'] and not closure['OrdinaryPathKilledAnything']
            assert 'RUNTIME ERROR:' not in log and 'SOURCE_UNCHANGED: True' in log
            assert f'WATCHDOG_COMPLETED: exit={expected_exit}; source unchanged=True' in log
            totals = re.findall(r'^TOTAL[^:\r\n]*:\s*passed=(\d+);\s*failed=(\d+)', log, re.M)
            assert (sum(int(a) for a, b in totals), sum(int(b) for a, b in totals)) == (passed, failed), (case, phase, totals)
            source_hash, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
            assert source_hash == record['compiled_workbook_sha256']
            reports[phase] = {'exit': expected_exit, 'passed': passed, 'failed': failed, 'owned_excel_closed': True}
        record['native_reports'] = reports
        cases[case] = record
    api = json.loads((root / 'Cases/API/Preparation.json').read_bytes())['directed_scope']
    assert api['setup_controller_commit'] == '1387effe7f9e669afcd78959a40b9405fbf0e875'
    result = {'cases': cases, 'sensitivity_has_one_retained_failed_variant': True,
              'API_controller_is_setup_baseline': True, 'working_controller_tested_in_Final': True,
              'installed_workbook_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('LOCAL HYBRID FOUR ACTUAL VBA BOOKS NATIVE REGRESSIONS AND NEGATIVE STUDY VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Повторяет все уравнения контрольных точек и точные сохранённые нагрузки, не выдавая нижнюю границу за предел."""
    TestFiles(root)
    baseline_archive = repo / 'docs/regression/Coupled6D/CoupledDesignLoadWorking20261119.zip'
    scope = json.loads((root / 'Baseline/SavedWorkbookScope.json').read_bytes())
    assert sha256(baseline_archive.read_bytes()).hexdigest().upper() == scope['source_archive_sha256']
    with ZipFile(baseline_archive) as bundle:
        for name in ('Native/Stock.txt', 'SavedWorkbookMarkup.zip'):
            assert bundle.read('Cases/Final/' + name) == (root / 'Baseline' / name).read_bytes()
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        temporary = Path(temporary)
        api_out, sensitivity_out = temporary / 'API.json', temporary / 'Sensitivity.json'
        run_path(str(root / 'Check-TestIntegratedHybridPoint.py'))['TestCheck'](repo, root / 'Cases/API', api_out)
        run_path(str(root / 'Analyze-TestHybridSensitivity.py'))['TestAnalyze'](root / 'Cases/Sensitivity', sensitivity_out)
        compare = run_path(str(root / 'Compare-TestSavedCoupledTrace.py'))['TestCompare']
        bad_out, local_out = temporary / 'Unconditional.json', temporary / 'Local.json'
        compare(root / 'Baseline', root / 'Cases/Unconditional', bad_out)
        compare(root / 'Baseline', root / 'Cases/Final', local_out)
        api, sensitivity = json.loads(api_out.read_bytes()), json.loads(sensitivity_out.read_bytes())
        bad, local = json.loads(bad_out.read_bytes()), json.loads(local_out.read_bytes())
    assert bad['capacity_trace_exact_common_prefix'] == 15
    assert local['capacity_trace_exact_common_prefix'] == 25
    assert local['before'] == local['after']
    timings = {}
    for case, seconds, low in (('Unconditional', 360.1953125, 1.10570660163947), ('Final', 154.826171875, 1.10776538831823)):
        report = (root / 'Cases' / case / 'Native/Stock.txt').read_text('utf-8-sig')
        value, = re.findall(r'^TIMING_SECONDS: ([\d.]+) \| Both \| Excel$', report, re.M)
        assert float(value) == seconds
        assert 'direct=OK; capacity=NumFail' in report and f'confirmed lower={low}; limit=;' in report
        assert 'code=NUMERICAL_FAILURE' in report and 'equal=True;' in report
        timings[case] = {'seconds': seconds, 'lower_lambda': low, 'direct': 'OK', 'capacity': 'NumFail', 'limit_found': False}
    result = {'API': api, 'sensitivity': sensitivity, 'saved_trace_comparisons': {'unconditional': bad, 'local': local},
              'timings': timings, 'working_path_preserved_but_no_capacity_advance': True,
              'full_field_prefix_not_verified_by_saved_load_trace_alone': True,
              'independent_material_reintegration': False, 'physical_capacity_certified': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('LOCAL HYBRID API EQUILIBRIUM HISTORY BUDGET SENSITIVITY AND SAVED STOCK LOAD PATH VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    (TestNative if args.scope == 'native' else TestMechanics)(args.repo.resolve(), args.root.resolve(), args.out.resolve())
