"""ДЛЯ ТЕСТОВ. Проверяет найденные точки и сохраняет неудачный увеличенный шаг как незавершённый численный исход."""

from argparse import ArgumentParser
import csv
from io import StringIO
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestAnalyze(folder, output):
    """Независимо собирает уравнения и напряжения двух корней; третий вариант не объявляет пройденным."""
    here = Path(__file__).resolve().parent
    validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
    main, main_fields = validate(folder, 'HardEarlyField')
    data = list(csv.reader(StringIO((folder / 'Native/HybridSensitivity.csv').read_text('cp1251')), delimiter=';'))
    trials = [row for row in data if row and row[0] == 'HYBRID_SENSITIVITY']
    assert len(trials) == 3
    assert [float(row[2]) for row in trials] == [2.5e-7, 1e-6, 4e-6]
    assert [row[3:5] for row in trials] == [['True', 'True'], ['True', 'True'], ['False', 'False']]
    assert all(row[-1] == 'history_unchanged=True' and int(row[7]) <= 2000 and int(row[9]) <= 350 for row in trials)
    proofs, fields = {}, {}
    for case in (1, 2):
        phase = 'HardEarlyField.FD' + str(case) + '.HybridCandidate'
        proof, values = validate(folder, phase)
        assert len(values) == 22 and np.array_equal(values[:21], main_fields[:21])
        assert proof['meta'][:2] == ['4', '0'] and not proof['reversed_fields']
        proofs[str(case)], fields[case] = proof, values
    assert not (folder / 'Native/HardEarlyField.FD3.HybridCandidate.csv').exists()
    helpers = run_path(str(here / 'Check-TestHardHalfSteps.py'))
    _, _, _, _, _, _, b, slope = helpers['TestOperators'](folder / 'Native/HardEarlyField.Operators.csv', 60, 43)
    difference = fields[1][-1] - fields[2][-1]
    strain = np.einsum('pcd,d->pc', b, difference)
    gradient = np.einsum('pcd,d->pc', slope, difference)
    strain_error = max(float(np.max(np.abs(strain + side * (.001 / 128) * gradient))) for side in (-1, 0, 1))
    lambda_error = abs(proofs['1']['maximum_lambda'] - proofs['2']['maximum_lambda'])
    assert strain_error < 1e-8 and lambda_error < 1e-6
    proof = {'main': main, 'converged_cases': proofs, 'observed_outcomes': trials,
        'converged_lambda_difference': lambda_error, 'converged_three_station_strain_difference': strain_error,
        'larger_difference_step_failed': True, 'all_three_parameter_variants_passed': False,
        'physical_capacity_certified': False, 'independent_material_reintegration': False}
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('HYBRID DIFFERENCE STUDY VERIFIED: TWO EQUILIBRIA, ONE FAILED LARGER STEP RETAINED')
    print('CONVERGED DIFFERENCES', lambda_error, strain_error)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
