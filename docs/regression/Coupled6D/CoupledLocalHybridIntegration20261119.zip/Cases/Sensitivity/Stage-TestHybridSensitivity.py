"""ДЛЯ ТЕСТОВ. Готовит три шага производной рабочего HYBRJ без изменения физической задачи."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Каждая точка стартует с собственного повтора исходной принятой истории и имеет один полный бюджет."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestOwnGlobalDifference.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig') + '\n' + (here / 'TestNativeHybridSensitivity.bas.txt').read_text('utf-8-sig')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'Compile','HybridCore'"
    assert code.count(old) == 1
    code = code.replace(old, "'Compile','HybridSensitivity','HybridCore'", 1)
    old = "        if ($Phase -eq 'HybridCore') {"
    assert code.count(old) == 1
    code = code.replace(old, '''        if ($Phase -eq 'HybridSensitivity') {
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestOwnHybridSensitivity','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','480')
        } elseif ($Phase -eq 'HybridCore') {''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeHybridSensitivity.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'relative_coordinate_steps': [2.5e-7, 1e-6, 4e-6],
        'each_case_replays_own_original_history': True, 'case_budget_function_calls': 2000, 'case_budget_steps': 350})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('OWN HYBRID THREE DIFFERENCE STEPS READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
