"""ДЛЯ ТЕСТОВ. Проверяет рабочее подключение HYBRJ к штатной деформационной пробе, сохраняя исходный контрольный контекст."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from subprocess import check_output


def TestStage(repo, root):
    """Обычная подготовка не включает резерв; положительная проверка запрашивает его через рабочий аргумент API."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestOwnGlobalDifference.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    raw = check_output(['git', 'cat-file', 'blob', '1387effe7f9e669afcd78959a40b9405fbf0e875:' + name], cwd=repo)
    raw = raw.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
    (root / name).write_bytes(raw)
    prep['inputs'][name] = sha256(raw).hexdigest().upper()
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает фактические затраты и признаки публикации для проверки общего бюджета.
Friend Function ReadHybridEffortTest() As Variant
    ReadHybridEffortTest = Array(mIterations, mEvaluations, mHybridSteps, mHybridMatrices, mHybridEvaluations, _
        IIf(mCandidateReady, 1, 0), mAcceptedRevision)
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code += '\n' + (here / 'TestNativeIntegratedHybrid.bas.txt').read_text('utf-8-sig')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'Compile','HybridCore'"
    assert code.count(old) == 1
    code = code.replace(old, "'Compile','IntegratedHybrid','HybridCore'", 1)
    old = "        if ($Phase -eq 'HybridCore') {"
    assert code.count(old) == 1
    code = code.replace(old, '''        if ($Phase -eq 'IntegratedHybrid') {
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestIntegratedHybridControl','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','480')
        } elseif ($Phase -eq 'HybridCore') {''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeIntegratedHybrid.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'production_controlled_API': True, 'budgets': [1, 60],
        'private_preparation_switches': False, 'default_call_keeps_recovery_disabled': True,
        'setup_controller_commit': '1387effe7f9e669afcd78959a40b9405fbf0e875',
        'current_controller_validated_separately_by_stock': True,
        'checked_calls_explicitly_request_working_recovery': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRODUCTION CONTROLLED HYBRID API AND BUDGET FIXTURE READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
