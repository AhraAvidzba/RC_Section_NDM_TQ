"""ДЛЯ ТЕСТОВ. Проверяет публикацию штатного гибридного резерва, общий бюджет и независимое равновесие."""

from argparse import ArgumentParser
import csv
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile
import numpy as np


def TestCheck(repo, folder, output):
    """Использует исходные строки API без подмены диагностического формата или результата неудачной пробы."""
    here = Path(__file__).resolve().parent
    rows = list(csv.reader(StringIO((folder / 'Native/IntegratedHybrid.csv').read_text('cp1251')), delimiter=';'))
    budget = next(row for row in rows if row and row[0] == 'BUDGET1')
    ordinary = next(row for row in rows if row and row[0] == 'DEFAULT60')
    actual = next(row for row in rows if row and row[0] == 'CONTROL60')
    assert budget[1] == 'False' and actual[1] == 'True'
    assert ordinary[1] == 'False'
    low, used = np.asarray(budget[2:], float), np.asarray(actual[4:], float)
    default = np.asarray(ordinary[2:], float)
    assert default.shape == (7,) and np.all(default[2:6] == 0) and default[6] == low[6]
    assert low.shape == used.shape == (7,) and low[0] <= 1 and np.all(low[2:6] == 0)
    assert used[0] <= 60 and used[0] == used[2] + 1 and used[5] == 1 and used[6] == low[6]
    assert used[1] >= used[4] + 1 and used[2] > 0 and used[3] > 0 and used[4] > 0
    native = np.asarray(next(row[1:] for row in rows if row and row[0] == 'NATIVE_VALIDATION'), float)
    assert native[0] == native[1] == 1 and native[3] <= native[2] and native[4] <= 1 and native[5] > 0
    validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
    main, main_fields = validate(folder, 'HardEarlyField')
    proof, fields = validate(folder, 'HardEarlyField.HybridCandidate')
    assert len(fields) == 22 and np.array_equal(fields[:21], main_fields[:21])
    assert proof['meta'][:2] == ['4', '0'] and not proof['reversed_fields']
    archive = repo / 'docs/regression/Coupled6D/CoupledHybridStallControl20261119.zip'
    assert sha256(archive.read_bytes()).hexdigest().upper() == '078F40F2E1C2120BE493068F187AE128299B72EA02A24DC34762DE6317DD5FE3'
    with ZipFile(archive) as bundle:
        original = list(csv.reader(StringIO(bundle.read('Cases/Hybrid/Native/HardEarlyField.HybridCandidate.csv').decode('cp1251')), delimiter=';'))
        reference = np.asarray([row[4:] for row in original if row and row[0] == 'F'], float)
        reference_factor = float([row[3] for row in original if row and row[0] == 'F'][-1])
    assert np.array_equal(fields[:21], reference[:21])
    operators = run_path(str(here / 'Check-TestHardHalfSteps.py'))
    _, _, _, _, _, _, b, slope = operators['TestOperators'](folder / 'Native/HardEarlyField.HybridCandidate.Operators.csv', 60, 43)
    difference = fields[-1] - reference[-1]
    strain = np.einsum('pcd,d->pc', b, difference)
    gradient = np.einsum('pcd,d->pc', slope, difference)
    maximum = max(float(np.max(np.abs(strain + side * (.001 / 128) * gradient))) for side in (-1, 0, 1))
    factor_error = abs(float(actual[2]) - reference_factor)
    assert maximum < 1e-8 and factor_error < 1e-6
    result = {'main': main, 'integrated_point': proof, 'default60': default.tolist(), 'budget1': low.tolist(), 'budget60': used.tolist(),
        'native_validation': native.tolist(), 'seconds_in_controlled_API': float(actual[3]),
        'external_control_lambda_difference': factor_error, 'maximum_three_station_strain_difference': maximum,
        'original_accepted_prefix_exact': 21, 'rejected_Newton_correction_charged': True,
        'physical_capacity_certified': False, 'independent_material_reintegration': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRODUCTION CONTROLLED HYBRID POINT BUDGET HISTORY ALL EQUATIONS AND SIX FORCES VERIFIED; CAPACITY OPEN')
    print('CONTROL DIFFERENCES', factor_error, maximum)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestCheck(args.repo.resolve(), args.root.resolve(), args.out.resolve())
