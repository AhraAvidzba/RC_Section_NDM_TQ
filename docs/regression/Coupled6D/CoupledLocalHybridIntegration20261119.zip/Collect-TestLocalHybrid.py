"""ДЛЯ ТЕСТОВ. Сохраняет чувствительность, ухудшивший путь вариант и явное локальное подключение HYBRJ."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path
from zipfile import ZIP_DEFLATED, ZipFile


def TestCollect(repo, root):
    """Сохраняет фактический VBA и XML Results; полные пользовательские книги не дублирует и не устанавливает."""
    here = Path(__file__).resolve().parent
    cases = {'Sensitivity': 'OwnHybridSensitivity20261119', 'Unconditional': 'IntegratedHybridStock0320261119',
             'Final': 'LocalHybridStock20261119', 'API': 'LocalHybridAPI0220261119'}
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    for key, directory in cases.items():
        folder = root / 'Cases' / key
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(sources) == 33
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        if key in ('Unconditional', 'Final'):
            source = scratch / directory
            if key == 'Unconditional':
                saved, = re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$',
                                    (source / 'Native/Stock.txt').read_text('utf-8-sig'), re.M)
                assert Path(saved).resolve().is_relative_to((source / 'Temp').resolve())
                with ZipFile(saved) as book, ZipFile(folder / 'SavedWorkbookMarkup.zip', 'x', ZIP_DEFLATED, compresslevel=9) as output:
                    for name in sorted(book.namelist()):
                        if Path(name).suffix.lower() in ('.xml', '.rels', '.vml'):
                            output.writestr(name, book.read(name))
            (folder / 'SavedWorkbookScope.json').write_text(json.dumps({'original_scratch_root': str(source),
                'results_saved_and_reopened': True, 'whole_workbook_preserved': False}, indent=2) + '\n', encoding='utf-8')
    archive = repo / 'docs/regression/Coupled6D/CoupledDesignLoadWorking20261119.zip'
    expected = 'A041180F70DBD0E1F7A6A32BAC4256DACF89484A2EA44325E87481F863D82A30'
    assert sha256(archive.read_bytes()).hexdigest().upper() == expected
    baseline = root / 'Baseline'
    baseline.mkdir()
    with ZipFile(archive) as bundle:
        for name in ('SavedWorkbookMarkup.zip', 'Native/Stock.txt'):
            target = baseline / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(bundle.read('Cases/Final/' + name))
    (baseline / 'SavedWorkbookScope.json').write_text(json.dumps({
        'original_scratch_root': str(scratch / 'DesignPredictionWorking20261119'),
        'source_archive': archive.name, 'source_archive_sha256': expected}, indent=2) + '\n', encoding='utf-8')
    names = ('Collect-TestLocalHybrid.py', 'Check-TestLocalHybrid.py', 'Audit-TestPrivateCoupledBook.py',
             'Compare-TestSavedCoupledTrace.py', 'Check-TestIntegratedHybridPoint.py', 'Analyze-TestHybridSensitivity.py',
             'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py', 'Canonical-TestCoreVBA.py',
             'Stage-TestIntegratedHybrid.py', 'Stage-TestIntegratedHybridStock.py', 'TestNativeIntegratedHybrid.bas.txt')
    for name in names:
        (root / name).write_bytes((here / name).read_bytes())
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '1387effe7f9e669afcd78959a40b9405fbf0e875',
        'production_continuation_connected': True, 'physical_capacity_certified': False,
        'installed_workbook_changed': False, 'full_acceptance_completed': False}, indent=2) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('LOCAL HYBRID EVIDENCE COLLECTED', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
