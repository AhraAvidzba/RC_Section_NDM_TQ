"""Independently verify the distributed MVT2 torsion run and its measured extrema."""
import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import hypot, isfinite
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
STARTUP_SHA = "57C87DEE79BF7626C39D67393726FFE3873695946D2CD53718136F6D72EE429B"
PAD_VERIFIER_SHA = "D51259714DA379A77A63E551EDE59C073E63079613893FFFC1D695D11C3C5E40"
NATIVE_SHA = "838616633F6F4652504D4D8567CB17D302D62806C2D64481C01A768308E399A1"
SOURCE_SHA = "7DA286A5CEF4456B2FBC81E04AA7261B95433406E9AB70FE6F7308C6033F5225"
LEVELS = (.025,.05,.1,.2,.4,.65,1.)
ITERATIONS = (3,2,3,2,2,4,6)


def require(condition,label):
    if not condition:
        raise ValueError(label)


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def zone(z):
    if z<=500. or z>=1700.:
        return "reinforced_end"
    if z<740. or z>1460.:
        return "support_band"
    if 860.<z<1340.:
        return "load_band"
    return "central_clear"


def verify_extreme(name,s,value):
    require(len(s)==6 and all(map(isfinite,s)),"six measured concrete stresses")
    x,y,z,xy,yz,xz = s
    if name=="maximum_abs_z_shear_MPa":
        require(abs(hypot(xz,yz)-value)<1e-10,"independent shear magnitude")
        return
    sign = 1. if name=="minimum_principal_MPa" else -1.
    a,b,c = (sign*(diagonal-value) for diagonal in (x,y,z))
    d,e,f = (sign*off_diagonal for off_diagonal in (xy,yz,xz))
    det = a*b*c+2.*d*e*f-a*e*e-b*f*f-c*d*d
    require(abs(det)<5e-10 and min(a,b,c,a*b-d*d,b*c-e*e,c*a-f*f)>-5e-10,"eigenvalue and extreme sign by PSD minors")


def tensors(row):
    by_band = row["concrete_peak_stress_by_longitudinal_and_surface_band"]
    require(set(by_band)=={"reinforced_end","support_band","central_clear","load_band"},"longitudinal survey bands")
    for band,sub in by_band.items():
        require(set(sub)=={"perimeter_25mm","interior"},"through-thickness survey bands")
        for surface,extrema in sub.items():
            require(set(extrema)=={"minimum_principal_MPa","maximum_principal_MPa","maximum_abs_z_shear_MPa"},"three stress extrema")
            for name,item in extrema.items():
                x,y,z = item["xyz_mm"]
                require(zone(z)==band,"stress station longitudinal assignment")
                require((120.-max(abs(x),abs(y))<25.)==(surface=="perimeter_25mm"),"stress station edge assignment")
                verify_extreme(name,item["signed_tensor_11_22_33_12_23_13_MPa"],item["value"])
    return by_band


def verify(startup):
    require(digest(startup)==STARTUP_SHA,"frozen distributed startup evidence")
    require(digest(HERE/"MVT2PadsContinue.py")==SOURCE_SHA,"frozen executed source")
    require(digest(HERE/"NonlinearDistributedContinue.json")==NATIVE_SHA,"actual native result")
    require(digest(HERE/"Verify-Pads.py")==PAD_VERIFIER_SHA,"equilibrium verifier identity")
    require((HERE/"NonlinearDistributedContinue.stdout.log").read_text(encoding="utf-8").strip()==
            "MVT2_PADS_CONTINUATION pure_torsion_target_reached 7 NonlinearDistributedContinue.json","child terminal")
    require((HERE/"NonlinearDistributedContinue.stderr.log").read_text(encoding="utf-8").strip()==
            "Using ASDConcrete3D - Developed by: Massimo Petracca, Guido Camata, ASDEA Software Technology","pure ASD runtime output")
    terminal = json.loads((HERE/"TorsionPadsReceipt.json").read_bytes())
    require(terminal=={"outer_tool_exit_code":0,"outer_tool_stdout":"MVT2_PADS_CONTINUATION_CLOSED code=0 result=NonlinearDistributedContinue.json"},"outer launch closure")
    with ZipFile(startup) as evidence:
        first = json.loads(evidence.read("NonlinearDistributedStartup.json"))
    data = json.loads((HERE/"NonlinearDistributedContinue.json").read_bytes())
    require(data["termination"]=="pure_torsion_target_reached" and data["replay_passed"] and not data["physical_limit_established"],"reported outcome")
    require(data["shear_knots_kN"]==[] and data["opensees_version"]==first["opensees_version"]=="3.8.0","pure torsion/OpenSees runtime")
    for key in ("E_MPa","nu","fc_MPa","ft_MPa","steel_E_MPa","steel_yield_MPa","steel_post_yield_slope_MPa",
                "Newton_iteration_cap","norm_unbalance_force","elastic_rig_sha256","elastic_result_sha256","integrator_sha256","validated_input_sha256"):
        require(data[key]==first[key],f"reused {key}")
    spec = spec_from_file_location("pad_equilibrium",HERE/"Verify-Pads.py")
    balance = module_from_spec(spec)
    spec.loader.exec_module(balance)
    observations = []
    previous = 0.
    for i,(state,candidate,scale,iters) in enumerate(zip(data["states"],data["candidates"],LEVELS,ITERATIONS,strict=True)):
        replay = i<3
        require(candidate=={"from_scale":previous,"attempted_scale":scale,"observed_scale":scale,"code":0,"iterations":iters,"replay":replay},"seven exact accepted history points")
        require(state["load_scale"]==scale and state["replay"]==replay and state["nominal_milestone"],"survey on exact requested level")
        independently = balance.verify_state(state["rig_balance"],scale*10510000.,0.)
        damage = state["concrete_damage_by_station_band"]
        for name,extrema in damage.items():
            for kind in ("tension","compression"):
                item = extrema[kind]
                require(zone(item["xyz_mm"][2])==name and 0.<=item["damage"]<1.,"band damage assignment")
        if replay:
            old = first["states"][i]
            for key in ("rig_balance","displacement","concrete_damage_by_station_band","steel_signed_extrema_by_band"):
                require(state[key]==old[key],f"exact zero replay error for {key}")
            require(all(v==0. for v in state["replay_max_errors"].values()),"zero replay marker")
        stresses = None if replay else tensors(state)
        steel = state["steel_signed_extrema_by_band"]
        axial = [s["axial_strain"] for band in steel.values() for bar in band.values() for s in bar.values()]
        require(max(map(abs,axial))<.00225,"all steel remains elastic")
        independently.update(replay_exact=replay,iterations=iters,concrete_damage_max_by_band=damage,retained_extreme_stress_by_band=stresses,
                             peak_steel_stress_abs_MPa=200000.*max(map(abs,axial)),clear_twists_rad_per_m=state["displacement"]["clear_twist_rad_per_m"])
        observations.append(independently)
        previous = scale
    return {"checks":"PASS","states":observations,"outer_closure":terminal,"physical_limit_established":False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("startup",type=Path)
    parser.add_argument("--out",type=Path)
    opts = parser.parse_args()
    proof = verify(opts.startup)
    if opts.out:
        opts.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True,allow_nan=False)+"\n").encode("utf-8"))
    print("MVT2_DISTRIBUTED_TORSION_DETACHED_PASS", len(proof["states"]),proof["states"][-1]["T_kNm"])


if __name__ == "__main__":
    main()
