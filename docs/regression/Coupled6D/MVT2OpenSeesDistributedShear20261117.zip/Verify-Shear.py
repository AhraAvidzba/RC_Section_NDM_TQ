"""Verify the retained MVT2 fixed-torsion pilot and compare exact nominal NDM loads."""
import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import pi
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
TORSION_SHA = "E330C5999357A5E56847488315AE25384B507AEF2ED650071672938A1A5D32FB"
NDM_SHA = "DEA4CCBB06ECCCECE9B076BF4D1B2ACA2DD7FCC4E84786FCE740FDFD6581FAB3"
LEVELS = (.025,.05,.1,.2,.4,.65,1.)
ITERATIONS = (3,2,3,2,2,4,6)
TORQUE = 10510000.
FILE = "NonlinearDistributedShear15.json"


def require(condition,label):
    if not condition:
        raise ValueError(label)


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def module(name,path):
    spec = spec_from_file_location(name,path)
    target = module_from_spec(spec)
    spec.loader.exec_module(target)
    return target


def validated_ndm(archive, external):
    with ZipFile(archive) as source:
        ndm = json.loads(source.read("MVT2CrackSensitivity/ShearComparison.Expected.json"))
    require(abs(ndm["B_ft_MPa"]-external["ft_MPa"])<1e-13,"comparable uniaxial tensile strength B")
    require(abs(ndm["A_ft_MPa"]-external["ft_MPa"])>1.,"model A tensile input differs")
    nominal = {}
    for state in ndm["common_exact_force_states"]:
        q = state["Qy_kN"]
        candidate = (0., .6*q, 0., 10.51, 0., q)
        values = {}
        for lane in ("A","B"):
            row = state[lane]
            actual = row["signed_N_Mx_My_T_Qx_Qy_in_kN_and_kNm"]
            require(len(actual)==6 and max(abs(x-y) for x,y in zip(candidate,actual,strict=True))<3e-6,"exact reported NDM nominal force")
            values[lane] = {"twist_rad_per_m":row["twist_deg_per_m"]*pi/180.,"section_steel_abs_MPa":[row["max_abs_long_MPa"],row["max_abs_hoop_MPa"]],
                            "actual_N_Mx_My_T_Qx_Qy_kN_kNm":actual,"ft_MPa":ndm[f"{lane}_ft_MPa"]}
        nominal[q] = values
    require(set(nominal)=={0.,15.},"two published exact common states")
    return nominal


def verify(torsion_archive,ndm_archive):
    require(digest(torsion_archive)==TORSION_SHA and digest(ndm_archive)==NDM_SHA,"upstream archives")
    receipt = json.loads((HERE/"ShearArtifactReceipt.json").read_bytes())
    for name,sha in receipt["native_sha256"].items():
        require(digest(HERE/name)==sha,name)
    with ZipFile(torsion_archive) as site:
        raw_torsion = site.read("NonlinearDistributedContinue.json")
        proof_torsion = json.loads(site.read("VerificationTorsionPads.json"))
        require(proof_torsion["checks"]=="PASS" and len(proof_torsion["states"])==7,"qualified torsion proof")
        for name in ("Verify-Pads.py","Verify-Torsion.py"):
            require(sha256(site.read(name)).hexdigest().upper()==digest(HERE/name),f"independent retained {name}")
    prior = json.loads(raw_torsion)
    data = json.loads((HERE/FILE).read_bytes())
    require(digest(HERE/FILE)==receipt["native_sha256"][FILE],"actual shear evidence identity")
    require(data["torsion_execution_reference_sha256"]==sha256(raw_torsion).hexdigest().upper(),"exact native torsion source")
    require(data["replay_passed"] and data["accepted_torsion_replayed"]==7 and not data["physical_limit_established"],"phase gate")
    require(data["termination"]==receipt["raw_termination"] and data["opensees_version"]==prior["opensees_version"]=="3.8.0","stored scope and runtime")
    require(data["termination"]=="unverified_solver_rollback" and receipt["outer_closure"]=={
        "outer_tool_exit_code":0,"outer_tool_stdout":"MVT2_PADS_SHEAR_CLOSED code=0 result=NonlinearDistributedShear15.json"},"outer/child distinction")
    require((HERE/"NonlinearDistributedShear15.stdout.log").read_text(encoding="utf-8").strip()==
            "MVT2_PADS_SHEAR unverified_solver_rollback 1 NonlinearDistributedShear15.json","child terminal stop")
    require("current Norm: 3.93841e+12 (max: 1e-05" in (HERE/"NonlinearDistributedShear15.stderr.log").read_text(encoding="utf-8"),"genuine numerical rejected step")
    require(data["held_torsion_kNm"]==10.51 and data["shear_knots_kN"]==[5.,10.,15.],"physical combined path")
    for key in ("E_MPa","nu","fc_MPa","ft_MPa","steel_E_MPa","steel_yield_MPa","steel_post_yield_slope_MPa","elastic_rig_sha256",
                "elastic_result_sha256","validated_input_sha256","integrator_sha256","norm_unbalance_force","Newton_iteration_cap"):
        require(data[key]==prior[key],f"same preload/material input {key}")
    pad = module("pad_equilibrium",HERE/"Verify-Pads.py")
    stress = module("torsion_tensors",HERE/"Verify-Torsion.py")
    for event,row,base,scale,iters in zip(data["attempts"][:7],data["replay_states"],prior["states"],LEVELS,ITERATIONS,strict=True):
        require(event=={"phase":"torsion_replay","target_scale":scale,"observed_scale":scale,"solver_code":0,"iterations":iters},"exact preload session")
        for key in set(row)-{"maximum_replay_differences"}:
            require(row[key]==base[key],"exact zero drift in replayed field "+key)
        require(all(v==0. for v in row["maximum_replay_differences"].values()),"zero drift native marker")
        pad.verify_state(row["rig_balance"],scale*TORQUE,0.)
    accepted = iter(data["shear_confirmed_states"])
    result = []
    previous = 0.
    failed = []
    for index,event in enumerate(data["attempts"][7:],start=7):
        require(event["phase"]=="fixed_T_shear" and abs(event["from_Qy_kN"]-previous)<1e-12,"monotone applied path from own history")
        q = event["observed_Qy_kN"]
        if event["solver_code"]:
            require(index==len(data["attempts"])-1 and (previous,event["target_Qy_kN"],q)==(5.,10.,5.) and
                    event["rollback_time_exact"] and event["rollback_all_nodes_exact"] and
                    event["rollback_sampled_damage_exact"] is False,"incomplete sampled damage restoration on final shear probe")
            failed.append(event)
            continue
        row = next(accepted)
        require(q==row["Qy_kN"] and q==event["target_Qy_kN"] and previous<q<=15.,"exact accepted load")
        require(abs(row["nominal_midspan_Mx_kNm"]-.6*q)<1e-12,"nominal affine moment")
        model = pad.verify_state(row["rig_balance"],TORQUE,row["rig_balance"]["P_N"])
        require(abs(model["P_kN"]/2.-q)<1e-12,"physical force is twice cut shear")
        survey = row.get("concrete_damage_by_station_band")
        if survey:
            for band,extrema in survey.items():
                for item in extrema.values():
                    require(stress.zone(item["xyz_mm"][2])==band and 0.<=item["damage"]<1.,"damage range and station attribution")
        actual = stress.tensors(row) if "concrete_peak_stress_by_longitudinal_and_surface_band" in row else None
        model.update(Qy_kN=q,Mx_nominal_midspan_kNm=.6*q,iterations=event["iterations"],nominal_milestone=row["nominal_milestone"],
                     clear_twist_rad_per_m=row["displacement"]["clear_twist_rad_per_m"],midspan_top_y_mm=row["displacement"]["midspan_top_y_mm"],
                     damage=survey,signed_steel_strain_extrema=row.get("steel_signed_extrema_by_band"),concrete_stress=actual)
        result.append(model)
        previous = q
    require(next(accepted,None) is None,"all accepted states matched to actual solver attempts")
    require([row["Qy_kN"] for row in result]==[5.] and len(failed)==1,"only confirmed fixed-T load before terminal")
    ndm = validated_ndm(ndm_archive,data)
    external = {0.:data["replay_states"][-1]["displacement"]["clear_twist_rad_per_m"]}
    external.update({row["Qy_kN"]:row["clear_twist_rad_per_m"] for row in result})
    comparison = [{"nominal_Qy_kN":q,"nominal_midspan_Mx_kNm":.60*q,"T_kNm":10.51,"NDM":ndm[q],
                   "OpenSees_clear_window_twist_rad_per_m":external[q],"OpenSees_clear_window_abs_Mx_kNm":[.30*q,.36*q],
                   "comparison_scope":"nominal load match; measured twist on 60 mm windows away from the nominal midspan"}
                  for q in sorted(set(ndm)&set(external))]
    return {"checks":"PASS","verified_zero_drift_preload_states":7,"states":result,"nominal_comparison":comparison,
            "failed_unrestored_damage_observation":failed[0],"outer_closure":receipt["outer_closure"],"physical_limit_established":False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("torsion",type=Path)
    parser.add_argument("ndm",type=Path)
    parser.add_argument("--out",type=Path)
    opts = parser.parse_args()
    report = verify(opts.torsion,opts.ndm)
    if opts.out:
        opts.out.write_bytes((json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+"\n").encode("utf-8"))
    print("MVT2_DISTRIBUTED_SHEAR_DETACHED_PASS",[row["Qy_kN"] for row in report["states"]])


if __name__ == "__main__":
    main()
