"""Replay all seven accepted MVT2 torsion steps, then increase shear at held T."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from time import monotonic
from types import SimpleNamespace


sys.dont_write_bytecode = True
import MVT2PadsContinue as torsion


HERE = Path(__file__).resolve().parent
STARTUP, ORIGINAL, RIG = torsion.startup,torsion.ORIGINAL,torsion.RIG
REFERENCE = HERE / "NonlinearDistributedContinue.json"
T_SOURCE_SHA = "7DA286A5CEF4456B2FBC81E04AA7261B95433406E9AB70FE6F7308C6033F5225"
T_RAW_SHA = "838616633F6F4652504D4D8567CB17D302D62806C2D64481C01A768308E399A1"
T_ITERATIONS = (3,2,3,2,2,4,6)
BALANCE_TOL = torsion.REPLAY_TOL["balance"]
DISP_TOL = torsion.REPLAY_TOL["displacement"]
MATERIAL_TOL = torsion.REPLAY_TOL["materials"]
STRESS_TOL = 1e-9
MAX_SHEAR_ATTEMPTS = 12


def inputs(opts):
    actual_torsion_shas = tuple(sha256(path.read_bytes()).hexdigest().upper() for path in (HERE/"MVT2PadsContinue.py",REFERENCE))
    if actual_torsion_shas != (T_SOURCE_SHA,T_RAW_SHA):
        raise ValueError("Frozen native torsion reference identity changed")
    geometry,meta,_ = torsion.inputs(opts)
    reference = json.loads(REFERENCE.read_bytes())
    if (reference["termination"]!="pure_torsion_target_reached" or not reference["replay_passed"] or
            tuple(row["observed_scale"] for row in reference["candidates"])!=torsion.LEVELS or
            tuple(row["iterations"] for row in reference["candidates"])!=T_ITERATIONS or
            any(row["code"]!=0 for row in reference["candidates"]) or len(reference["states"])!=7):
        raise ValueError("Missing complete accepted torsion sequence")
    shear_knots = (5.,10.,15.,20.) if opts.max_qy==20 else (5.,10.,15.)
    meta.update(scope="complete torsion cold replay then low shear at held T",torsion_execution_reference_sha256=T_RAW_SHA,
                held_torsion_kNm=10.51,shear_knots_kN=shear_knots,maximum_shear_attempts=MAX_SHEAR_ATTEMPTS,
                replay_component_absolute_tolerances={**torsion.REPLAY_TOL,"stress_tensor":STRESS_TOL},max_attempts=None,
                accepted_torsion_replayed=0,shear_confirmed_states=[],replay_states=[],attempts=[])
    return geometry,meta,reference


def persist(output,report):
    part = output.with_suffix(".json.part")
    part.write_text(json.dumps(report,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    part.replace(output)


def set_load(ops,tag,values,magnitude):
    ops.timeSeries("Linear",tag)
    ops.pattern("Plain",tag,tag)
    for node,force in values.items():
        ops.load(node,*RIG.scale(magnitude,force))


def configure_analysis(ops):
    ops.constraints("Transformation")
    ops.numberer("RCM")
    ops.system("UmfPack")
    ops.test("NormUnbalance",1e-5,12)
    ops.algorithm("Newton")
    ops.integrator("LoadControl",.1)
    ops.analysis("Static")


def assess_state(model,t,p):
    balance = model.inspect(t,p)
    displacement = STARTUP.physical_displacements(model)
    return {"rig_balance":balance,"displacement":displacement}


def summarize(model,row,include_stress):
    row.update(ORIGINAL.field_summary(model))
    if include_stress:
        row["concrete_peak_stress_by_longitudinal_and_surface_band"] = torsion.stress_by_band(model)


def replay_torsion(model,reference,report,output,deadline):
    ops = model.ops
    for number,(goal,known,old_row) in enumerate(zip(torsion.LEVELS,T_ITERATIONS,reference["states"],strict=True)):
        if monotonic()>=deadline:
            return "bounded_budget_during_torsion_replay"
        before = ORIGINAL.rollback_sample(model)
        ops.integrator("LoadControl",goal-before[0])
        code = ops.analyze(1)
        arrived = ops.getTime()
        attempt = {"phase":"torsion_replay","target_scale":goal,"observed_scale":arrived,"solver_code":code,"iterations":ops.testIter()}
        report["attempts"].append(attempt)
        if code:
            attempt["rollback_exact"] = ORIGINAL.rollback_sample(model)==before
            persist(output,report)
            return "torsion_replay_solver_mismatch"
        if arrived!=goal or attempt["iterations"]!=known:
            persist(output,report)
            return "torsion_replay_load_or_iteration_mismatch"
        row = assess_state(model,arrived*RIG.TORQUE,0.)
        summarize(model,row,number>=3)
        tolerances = {"rig_balance":BALANCE_TOL,"displacement":DISP_TOL,"concrete_damage_by_station_band":MATERIAL_TOL,
                      "steel_signed_extrema_by_band":MATERIAL_TOL,"concrete_peak_stress_by_longitudinal_and_surface_band":STRESS_TOL}
        row["maximum_replay_differences"] = {
            key:torsion.replay_error(old_row[key],json.loads(json.dumps(value)),tolerances[key],key) for key,value in row.items()}
        report["replay_states"].append(row)
        report["accepted_torsion_replayed"]=number+1
        report["replay_passed"]=number==6
        persist(output,report)
    return None


def follow_shear(model,report,output,deadline):
    ops = model.ops
    knots = report["shear_knots_kN"]
    high = knots[-1]
    attempts = 0
    for target_qy in knots:
        goal = target_qy/high
        increment = goal-ops.getTime()
        while goal-ops.getTime()>2e-12:
            if monotonic()>=deadline or attempts>=MAX_SHEAR_ATTEMPTS:
                return "bounded_budget_during_shear"
            before = ORIGINAL.rollback_sample(model)
            step = min(increment,goal-before[0])
            if step<.002:
                return "step_floor_after_failed_equilibrium"
            ops.integrator("LoadControl",step)
            code = ops.analyze(1)
            arrived = ops.getTime()
            attempts += 1
            attempt = {"phase":"fixed_T_shear","from_Qy_kN":before[0]*high,"target_Qy_kN":(before[0]+step)*high,
                       "observed_Qy_kN":arrived*high,"solver_code":code,"iterations":ops.testIter()}
            report["attempts"].append(attempt)
            if code:
                rolled = ORIGINAL.rollback_sample(model)
                attempt.update(rollback_time_exact=rolled[0]==before[0],rollback_all_nodes_exact=rolled[1]==before[1],
                               rollback_sampled_damage_exact=rolled[2]==before[2])
                persist(output,report)
                if rolled!=before:
                    return "unverified_solver_rollback"
                increment = step/2.
                continue
            if abs(arrived-before[0]-step)>1e-12:
                persist(output,report)
                return "committed_load_time_mismatch"
            row = assess_state(model,RIG.TORQUE,2000.*high*arrived)
            row.update(Qy_kN=arrived*high,nominal_midspan_Mx_kNm=.60*arrived*high,
                       nominal_milestone=abs(arrived-goal)<=2e-12)
            report["shear_confirmed_states"].append(row)
            persist(output,report)
            if row["nominal_milestone"]:
                summarize(model,row,True)
                persist(output,report)
    return "shear_pilot_targets_reached"


def run(opts, geometry, report, reference, output):
    sys.path.insert(0,str(RIG.UTILITY.parent))
    import validate_opensees_hardshear as utility

    ops = utility.ops
    commands = ORIGINAL.MaterialCommands(ops,"default")
    deadline = monotonic()+opts.wall_seconds-15.
    model = STARTUP.PadModel(geometry,SimpleNamespace(ops=commands,Prism=utility.Prism))
    set_load(ops,1,geometry.torque_unit,RIG.TORQUE)
    configure_analysis(ops)
    report.update(termination="running",opensees_version=ops.version())
    persist(output,report)
    try:
        termination = replay_torsion(model,reference,report,output,deadline)
        if termination is None:
            ops.loadConst("-time",0.)
            set_load(ops,2,geometry.vertical_unit,2000.*report["shear_knots_kN"][-1])
            termination = follow_shear(model,report,output,deadline)
        report["termination"] = termination
    except Exception as problem:
        report.update(termination="verification_or_engine_exception",detail=str(problem))
        raise
    finally:
        persist(output,report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check-inputs",action="store_true")
    mode.add_argument("--start",action="store_true")
    mode.add_argument("--child",action="store_true",help=argparse.SUPPRESS)
    parser.add_argument("--wall-seconds",type=int,default=165)
    parser.add_argument("--max-qy",type=int,choices=(15,20),default=15)
    opts = parser.parse_args()
    if not 60<=opts.wall_seconds<=180:
        parser.error("Use 60–180 watchdog seconds.")
    geometry,report,reference = inputs(opts)
    if opts.check_inputs:
        print("MVT2_PADS_SHEAR_INPUTS_OK",json.dumps(report,allow_nan=False))
        return 0
    output = HERE/f"NonlinearDistributedShear{opts.max_qy}.json"
    if output.exists() or output.with_suffix(".json.part").exists():
        raise FileExistsError(output)
    if opts.child:
        run(opts,geometry,report,reference,output)
        print("MVT2_PADS_SHEAR",report["termination"],len(report["shear_confirmed_states"]),output.name)
        return 0
    args = [sys.executable,"-B","-X","utf8",str(Path(__file__).resolve()),"--child","--wall-seconds",str(opts.wall_seconds),"--max-qy",str(opts.max_qy)]
    with output.with_suffix(".stdout.log").open("xb") as stdout,output.with_suffix(".stderr.log").open("xb") as stderr:
        try:
            code = subprocess.run(args,stdout=stdout,stderr=stderr,timeout=opts.wall_seconds).returncode
        except subprocess.TimeoutExpired:
            print(f"MVT2_PADS_SHEAR_WATCHDOG {opts.wall_seconds}s; see {output.name} if created")
            return 124
    print(f"MVT2_PADS_SHEAR_CLOSED code={code} result={output.name}")
    return code


if __name__ == "__main__":
    sys.exit(main())
