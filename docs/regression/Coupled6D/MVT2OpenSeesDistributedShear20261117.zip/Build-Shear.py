"""Pack the terminal held-torsion OpenSees pilot and its detached verification."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parent
MANIFEST = ("Build-Shear.py","MVT2PadsShear.py","NonlinearDistributedShear15.json","NonlinearDistributedShear15.stderr.log",
            "NonlinearDistributedShear15.stdout.log","Shear-Pilot.md","Shear-Proof.md","ShearArtifactReceipt.json",
            "VerificationShearPads.json","Verify-Pads.py","Verify-Shear.py","Verify-Torsion.py")
OUT = ROOT / "MVT2OpenSeesDistributedShear20261117.zip"


def add(archive,name,payload):
    entry = ZipInfo(name,(2026,11,17,0,0,0))
    entry.create_system = 3
    entry.external_attr = 0o100644 << 16
    entry.compress_type = ZIP_STORED
    archive.writestr(entry,payload)


def main():
    records = []
    with ZipFile(OUT,"w") as archive:
        for name in MANIFEST:
            payload = (ROOT/name).read_bytes()
            records.append(f"{sha256(payload).hexdigest()}  {name}\n")
            add(archive,name,payload)
        add(archive,"SHA256SUMS","".join(records).encode("ascii"))
    print(sha256(OUT.read_bytes()).hexdigest().upper())


if __name__ == "__main__":
    main()
