"""Replay native cache checks and reproduce the exact imported class and test code."""

from hashlib import sha256
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory

import Stage


HERE = Path(__file__).resolve().parent
EVIDENCE = {
    "Old": {
        "fixture": "2662BFE2F9532FC6277B6488C606052165ECB0E1D8EC69FB58B58E4F48167B97",
        "workbook": "16C64188FE6EC78D995A71247EB0B8D53F69A017B13370A5688BB996771405BB",
        "raw": "B7DCF42D0BB0C416644D1B02CBF14B3C3284D78F159BDFCC23216E89432C22BA",
        "replay": "11210BD2EABCF95B363658EF7C25FCBAFDF1C847EAEA6B17047C7567A69027F1",
    },
    "Candidate": {
        "fixture": "1BE53D71F7D8A82D3555CEB9C50288F40133E9C7B5F4149E8E094CC332F316D8",
        "workbook": "90D6C9365EE33EECA1D7AA5361A1073FFCBB2441701069E4A65A2307AC2C6D0A",
        "raw": "DBC1454B5DAAC940DD4DF4F360A495F619F6249F2DE72932E1764917F649497F",
        "replay": "F8CDBA8ABB9579888B1CF552F2C78A34A686CC74E6656A445333E4524B5283D5",
    },
}
PRODUCTION = "A8BB972211F812F61E6748DF2B5691E32EDC8E0037DEBEA9F94C7ACB19F0A527"


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_bytes())


def code(text):
    return (text.rstrip() + "\n").replace("\n", "\r\n").encode("utf-8")


def verify_sources(lane, fixture):
    root = HERE / lane
    assert fixture["lane"] == lane and fixture["git_revision"] == Stage.COMMIT
    assert fixture["workbook_sha256"] == Stage.BOOK_SHA
    assert fixture["production_class_base_git_sha256"] == Stage.BASE_CLASS
    assert fixture["candidate_production_class_sha256"] == PRODUCTION
    assert fixture["modules"] == [Path(Stage.MATERIAL).stem, Path(Stage.TEST).stem]
    for name, expected in fixture["frozen"].items():
        if name == Stage.BOOK:
            assert expected == Stage.BOOK_SHA
            continue
        path = root / name
        assert digest(path if path.exists() else HERE / name) == expected, name
    baseline = HERE / "Baseline" / Stage.MATERIAL
    assert digest(baseline) == Stage.BASE_CLASS
    original = baseline.read_text(encoding="utf-8")
    production = HERE / "Production" / Stage.MATERIAL
    candidate = Stage.cached_base(original)
    assert code(candidate) == production.read_bytes() and digest(production) == PRODUCTION
    source = candidate if lane == "Candidate" else original
    assert code(Stage.instrument(source, lane == "Candidate")) == (root / Stage.MATERIAL).read_bytes()
    base_test = HERE / "Baseline" / Stage.TEST
    assert digest(base_test) == Stage.BASE_TEST
    test = base_test.read_text(encoding="utf-8").rstrip() + "\n\n" + (HERE / "BaseResponseTest.txt").read_text(encoding="utf-8").strip()
    assert code(test) == (root / Stage.TEST).read_bytes()


def verify_native(lane, fixture, proof, identities):
    root = HERE / lane
    compiled = read(root / "docs/regression/CodeUpdate.json")
    assert compiled["Compiled"] and not compiled["ProductionChanged"] and not compiled["RetiredModules"]
    assert compiled["ProductionSHA256"] == fixture["workbook_sha256"]
    assert compiled["WorkbookSHA256"] == proof["workbook"]
    assert sorted(compiled["Modules"]) == fixture["modules"]
    compiler = read(root / "CompileClosure.json")
    log = (root / "Compile.log").read_text(encoding="utf-8-sig")
    strings = re.findall(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", log, re.M)
    assert strings == [(str(compiler["PID"]), compiler["StartTicksUTC"])] and compiler["State"] == "Absent"
    assert "PRIVATE_CODE_READY: modules=2; production unchanged=True" in log
    compiler_identity = strings[0]
    assert compiler_identity not in identities
    identities.add(compiler_identity)
    report = root / "Native/Cache.txt"
    assert digest(report) == proof["raw"]
    raw = report.read_text(encoding="utf-8-sig")
    assert re.search(r"^SOURCE_SHA256: " + proof["workbook"] + "$", raw, re.M)
    assert "===== modTestCoupledElasticState.RunTestConcreteBaseResponseCache =====" in raw
    assert "SOURCE_UNCHANGED: True" in raw
    owner = read(report.with_suffix(".txt.Ownership.json"))
    expected = str(owner["PID"]), owner["StartTicksUTC"]
    assert owner["SourceSHA256"] == proof["workbook"] and owner["BeforeWorkbookOpen"] and owner["VerifiedNewOwner"]
    assert expected not in identities
    identities.add(expected)
    assert re.findall(r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$", raw, re.M) == [expected]
    assert read(report.with_name("Exit.json")) == {"lane": lane, "exit_code": 0}
    closure = read(report.with_suffix(".txt.ProcessClosure.json"))
    assert closure["Passed"] and closure["ChildExitCode"] == 0 and closure["ChildHasExited"]
    assert closure["RunnerCleanupValid"] and not closure["OrdinaryPathKilledAnything"]
    final = closure["Closure"]["FinalState"]
    assert (str(final["PID"]), final["StartTicksUTC"]) == expected and final["State"] == "Absent"
    with TemporaryDirectory(prefix="concrete-cache-") as directory:
        copied = Path(directory) / report.name
        copyfile(report, copied)
        copyfile(report.with_suffix(".txt.ProcessClosure.json"), copied.with_suffix(".txt.ProcessClosure.json"))
        check_output([sys.executable, "-B", "-X", "utf8", str(HERE / "Verify.py"), lane, str(copied)])
        replay = read(copied.with_suffix(".Verification.json"))
    expected_replay = report.with_suffix(".Verification.json")
    assert digest(expected_replay) == proof["replay"] and replay == read(expected_replay)
    print("PASS NONLINEAR CONCRETE BASE CACHE", lane, proof["raw"], replay["branch_base_cache_hits"])
    return replay


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions")
    for name, expected in read(HERE / "SHA256SUMS.json").items():
        assert digest(HERE / name) == expected
    identities = set()
    for lane, proof in EVIDENCE.items():
        fixture = HERE / lane / "Fixture.json"
        assert digest(fixture) == proof["fixture"]
        metadata = read(fixture)
        verify_sources(lane, metadata)
        verify_native(lane, metadata, proof, identities)
    assert len(identities) == 4


if __name__ == "__main__":
    main()
