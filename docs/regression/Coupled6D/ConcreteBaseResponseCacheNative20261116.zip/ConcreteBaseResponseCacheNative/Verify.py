"""Check exact cold/warm material comparisons and invalidation in the native output."""

from hashlib import sha256
import json
from pathlib import Path
import re
import sys


lane, path = sys.argv[1:]
report = Path(path)
raw = report.read_text(encoding="utf-8-sig")
expected_hits = {"Old": 0, "Candidate": 3}[lane]
assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in raw
assert "TOTAL_CONCRETE_BASE_RESPONSE_CACHE: passed=38; failed=0" in raw
assert not re.search(r"^(?:FAIL|RUNTIME ERROR):", raw, re.M)
assert raw.count("exactly matches the cold six stresses and 36 tangent values") == 13
assert raw.count("leaves its own accepted stress and energies unchanged") == 13
for caption in (
    "one changed strain component invalidates the exact key",
    "another material point cannot use the original point cache",
    "acceptance invalidates hits from the previous committed history",
    "zero-substep branch base is reusable within its own epoch",
    "output writer invalidates its point cache even at equal strain",
    "clearing history cannot reuse an earlier trial response",
):
    assert "OK: " + caption in raw
result = re.search(r"^BASE_CACHE_HITS;([^;]+);([0-9]+);([0-9]+)$", raw, re.M)
assert result and result[1] == lane and int(result[2]) == expected_hits and int(result[3]) >= 1
closure = json.loads(report.with_suffix(".txt.ProcessClosure.json").read_bytes())
assert closure["Passed"] and closure["ChildExitCode"] == 0 and closure["Closure"]["FinalState"]["State"] == "Absent"
record = {
    "lane": lane, "report_sha256": sha256(report.read_bytes()).hexdigest().upper(),
    "checks": 38, "six_stress_and_36_tangent_comparisons": 13, "branch_base_cache_hits": expected_hits,
    "positive_trial_substeps": int(result[3]),
}
report.with_suffix(".Verification.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print("PASS CONCRETE BASE RESPONSE", lane, record["report_sha256"], expected_hits)
