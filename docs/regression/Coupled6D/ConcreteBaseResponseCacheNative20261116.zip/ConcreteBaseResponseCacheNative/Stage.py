"""Freeze paired concrete base-response cache probes on the published c9e7268 book."""

from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from subprocess import check_output


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
TOOLS = HERE.parent / "dplot"
RUNNER = HERE.parent / "dstale/Run.ps1"
COMMIT = "c9e7268fe8b7c3c40edca958d137eb0531a53c19"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
BOOK_SHA = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
MATERIAL = "src/Materials/CCoupledConcreteResponse.cls"
BASE_CLASS = "A66098447E4A7203D5E5088C609976228C728F78E671E0AB7AC06DB3D0ED8A03"
TEST = "tests/modTestCoupledElasticState.bas"
BASE_TEST = "2451F24F8661DA1C1C66E96192A349EB677C96BC01AC7944F20D1D5BFCD35E47"


def digest(value):
    return sha256(value).hexdigest().upper()


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    copyfile(source, target)


def read(path):
    return json.loads(path.read_bytes())


def write_code(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((text.rstrip() + "\n").replace("\n", "\r\n").encode("utf-8"))


def once(text, needle, replacement):
    assert text.count(needle) == 1, needle
    return text.replace(needle, replacement)


def source(name, expected):
    contents = check_output(["git", "show", f"{COMMIT}:{name}"], cwd=REPO)
    assert digest(contents) == expected
    assert contents == (REPO / name).read_bytes().replace(b"\r\n", b"\n")
    return contents.decode("utf-8")


def cached_base(text):
    marker = "Private mCachedEpoch() As Long, mCachedMode() As ECoupledTangentMode"
    text = once(text, marker, marker + "\nPrivate mCachedBaseSubsteps() As Long ' Число подшагов точного пробного отклика.")
    text = once(text, "    If Not branchConsistent Then sameTrial = MatchesNonlinearTrial(point, strain)",
                "    sameTrial = MatchesNonlinearTrial(point, strain)")
    text = once(
        text,
        "        cachedMode = mCachedMode(point)",
        "        baseSubsteps = mCachedBaseSubsteps(point)\n"
        "        If Not branchConsistent Then cachedMode = mCachedMode(point) ' Столбцы другой касательной не используются.",
    )
    marker = "        mCachedEpoch(point) = mTrialEpoch"
    text = once(text, marker, marker + "\n        mCachedBaseSubsteps(point) = baseSubsteps")
    marker = "    ReDim mCachedEpoch(1 To mPointCount): ReDim mCachedMode(1 To mPointCount)"
    return once(text, marker, marker + "\n    ReDim mCachedBaseSubsteps(1 To mPointCount)")


def instrument(text, candidate):
    marker = "Private mTrialEpoch As Long"
    assert text.count(marker) == 1
    text = text.replace(marker, "Private mTestBranchBaseHits As Long\n" + marker)
    marker = "    If sameTrial Then\n        updated = mHistory(point, mTrial)"
    text = once(text, marker, marker + "\n        If branchConsistent Then mTestBranchBaseHits = mTestBranchBaseHits + 1")
    read_probe = "mCachedBaseSubsteps(1)" if candidate else "-1"
    return text.rstrip() + f'''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает число попаданий в базовый отклик для касательной материальной ветви.
Friend Property Get TestBranchBaseHits() As Long
    TestBranchBaseHits = mTestBranchBaseHits
End Property

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает число подшагов записанного базового отклика первой точки.
Friend Property Get TestCachedBaseSubsteps() As Long
    TestCachedBaseSubsteps = {read_probe}
End Property
'''


def stage_runner():
    original = RUNNER.read_text(encoding="utf-8")
    changes = (
        ("'Old','Corrected'", "'Old','Candidate'"),
        ("'Native/Stale.txt'", "'Native/Cache.txt'"),
        ("DirectStale", "ConcreteBaseCache"),
        ("RunTestCoupledStaleSteelFactor", "RunTestConcreteBaseResponseCache"),
        ("(($Lane -eq 'Old' -and $code -ne 1) -or ($Lane -eq 'Corrected' -and $code -ne 0))", "($code -ne 0)"),
    )
    for original_text, replacement in changes:
        assert original_text in original
        original = original.replace(original_text, replacement)
    (HERE / "Run.ps1").write_bytes(original.encode("utf-8"))


def main():
    assert not (HERE / "Candidate/Fixture.json").exists()
    assert digest((REPO / BOOK).read_bytes()) == BOOK_SHA
    material = source(MATERIAL, BASE_CLASS)
    candidate = cached_base(material)
    write_code(HERE / "Production" / MATERIAL, candidate)
    numerical = digest((HERE / "Production" / MATERIAL).read_bytes())
    test = source(TEST, BASE_TEST).rstrip() + "\n\n" + (HERE / "BaseResponseTest.txt").read_text(encoding="utf-8").strip()
    fixture = read(TOOLS / "Fixture.json")["frozen"]
    names = [name for name in fixture if name.startswith("tools/") or name == "Guard-IsolatedOffice.ps1"]
    stage_runner()
    for lane, contents in (("Old", material), ("Candidate", candidate)):
        root = HERE / lane
        for name in names:
            assert digest((TOOLS / name).read_bytes()) == fixture[name]
            copy(TOOLS / name, root / name)
        copy(REPO / BOOK, root / BOOK)
        copy(REPO / BOOK, root / "docs/regression/Diagnostic.xlsm")
        copy(HERE / "Verify.py", root / "Verify.py")
        write_code(root / MATERIAL, instrument(contents, lane == "Candidate"))
        write_code(root / TEST, test)
        for directory in ("Native", "Temp"):
            (root / directory).mkdir(exist_ok=True)
        extra = (BOOK, MATERIAL, TEST, "Verify.py")
        record = {"lane": lane, "workbook_sha256": BOOK_SHA, "git_revision": COMMIT,
                  "modules": [Path(MATERIAL).stem, Path(TEST).stem],
                  "production_class_base_git_sha256": BASE_CLASS,
                  "candidate_production_class_sha256": numerical,
                  "frozen": {name: digest((root / name).read_bytes()) for name in (*names, *extra)}}
        path = root / "Fixture.json"
        path.write_bytes((json.dumps(record, indent=2) + "\n").encode("utf-8"))
        print("BASE_RESPONSE_CACHE_FIXTURE", lane, digest(path.read_bytes()), "candidate production", numerical)


if __name__ == "__main__":
    main()
