"""Analyze eight paired HardShear runtime comparisons after semantic validation."""

import argparse
import csv
from itertools import combinations
import json
from math import exp, isfinite, log
from pathlib import Path
from random import Random
import re
from statistics import mean, median


PAIR_COUNT = 8
ORDER_SEED = 20261116
BOOTSTRAP_SEED = 231016


def orders():
    pairs = ["Old"] * (PAIR_COUNT // 2) + ["Candidate"] * (PAIR_COUNT // 2)
    Random(ORDER_SEED).shuffle(pairs)
    return pairs


def speedup(values):
    return (1.0 - exp(mean(values))) * 100.0


def elapsed(row, label):
    value = float(row[label])
    if not isfinite(value) or value <= 0:
        raise ValueError(f"Invalid elapsed time for pair {row['pair']}")
    return value


def percentile(sorted_values, probability):
    position = probability * (len(sorted_values) - 1)
    lower = int(position)
    return sorted_values[lower] + (position - lower) * (sorted_values[lower + 1] - sorted_values[lower])


def analyze(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if [int(row["pair"]) for row in rows] != list(range(1, PAIR_COUNT + 1)):
        raise ValueError("Provide one row for each of the eight numbered measured pairs")
    if [row["first"] for row in rows] != orders():
        raise ValueError("Unexpected measured order")
    results = []
    for row in rows:
        previous = row["old_semantics_sha256"].upper()
        candidate = row["candidate_semantics_sha256"].upper()
        if not re.fullmatch(r"[0-9A-F]{64}", previous) or previous != candidate:
            raise ValueError(f"Saved calculation results differ in pair {row['pair']}")
        if row["old_closed"] != "true" or row["candidate_closed"] != "true":
            raise ValueError(f"Native closure is absent from pair {row['pair']}")
        results.append((
            row["first"], elapsed(row, "old_seconds"), elapsed(row, "candidate_seconds"),
        ))

    differences = [log(candidate / old) for _, old, candidate in results]
    observed = mean(differences)
    period = [d if first == "Old" else -d for d, (first, _, _) in zip(differences, results, strict=True)]
    # The order was randomized with exactly four candidate-second assignments.
    permutation = []
    for assignments in combinations(range(PAIR_COUNT), PAIR_COUNT // 2):
        second = set(assignments)
        permutation.append(mean(d if index in second else -d for index, d in enumerate(period)))
    p_value = sum(abs(value) + 1e-14 >= abs(observed) for value in permutation) / len(permutation)

    generator = Random(BOOTSTRAP_SEED)
    draws = sorted(speedup(generator.choices(differences, k=PAIR_COUNT)) for _ in range(10000))
    return {
        "paired_runs": PAIR_COUNT,
        "order_seed": ORDER_SEED,
        "primary_old_geomean_relative_speedup_percent": speedup(differences),
        "paired_median_relative_speedup_percent": (1.0 - exp(median(differences))) * 100.0,
        "paired_bootstrap_percentile_95": [percentile(draws, .025), percentile(draws, .975)],
        "balanced_order_randomization_two_sided_p": p_value,
        "balanced_order_randomization_assignments": len(permutation),
        "median_old_seconds": median(old for _, old, _ in results),
        "median_candidate_seconds": median(candidate for _, _, candidate in results),
        "candidate_runs_within_ten_seconds": sum(candidate <= 10 for _, _, candidate in results),
        "speedup_by_first_arm_percent": {
            first: speedup(d for d, (order, _, _) in zip(differences, results, strict=True) if order == first)
            for first in ("Old", "Candidate")
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path, nargs="?")
    parser.add_argument("--show-order", action="store_true")
    args = parser.parse_args()
    if args.show_order:
        for index, label in enumerate(orders(), 1):
            print(index, label)
        return
    if args.csv is None:
        parser.error("provide a CSV of measured pairs or use --show-order")
    print(json.dumps(analyze(args.csv), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
