"""ДЛЯ ТЕСТОВ. Проверяет точный исходный текст новых компонентов в фактически скомпилированной книге."""

from argparse import ArgumentParser
from difflib import unified_diff
from io import BytesIO
from pathlib import Path
from runpy import run_path


def TestInspect(repo, folder):
    """Числа сравниваются по точным Decimal-значениям и типам, без округления или разрешения потери точности."""
    _, body, reader = run_path(str(repo / 'tmp/material-consistency/Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, actual = reader(BytesIO((folder / 'docs/regression/Diagnostic.xlsm').read_bytes()))
    normal = run_path(str(repo / 'tmp/material-consistency/Canonical-TestCoreVBA.py'))['TestCanonical']
    passed = []
    for name in ('ICoupledEquationSystem', 'CCoupledHybridFactorization', 'CCoupledHybridSolver'):
        file, = (folder / 'src').rglob(name + '.cls')
        expected = normal(body(file.read_text('utf-8-sig'), name)[0])[0]
        observed = normal(body(actual[name], name)[0])[0]
        if expected != observed:
            print('\n'.join(list(unified_diff(expected.splitlines(), observed.splitlines()))[:40]))
        assert expected == observed, name
        passed.append(name)
    print('NEW HYBRID ACTUAL SOURCE PRECISE NUMBERS VERIFIED', passed)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestInspect(args.repo.resolve(), args.root.resolve())
