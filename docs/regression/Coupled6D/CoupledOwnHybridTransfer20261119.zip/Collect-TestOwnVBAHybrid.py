"""ДЛЯ ТЕСТОВ. Сохраняет проверяемый перенос HYBRJ, неудачные гипотезы и найденное собственное равновесие."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestCollect(repo, root):
    """Не дублирует книги и Temp; фактические CFB и все попытки сохраняет отдельно с закреплёнными входами."""
    here = Path(__file__).resolve().parent
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = {'Initial': 'OwnVBAHybrid20261119', 'Trace': 'OwnVBAHybridTrace0220261119',
        'Restart': 'OwnVBAHybridRestart20261119', 'Radii': 'OwnVBAHybridRadii20261119', 'Global': 'OwnVBAHybridGlobalJac20261119',
        'Own': 'OwnWorkingGlobalDiff20261119'}
    collect(repo, root)
    for folder in (root / 'Cases').iterdir():
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            destination = folder / relative
            if not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(destination.read_bytes()).hexdigest().upper()
        assert len(sources) == 33
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    for name in ('Collect-TestOwnVBAHybrid.py', 'Check-TestOwnVBAHybrid.py', 'Analyze-TestVBAHybridTrace.py',
        'Check-TestVBAHybridGlobalPoint.py', 'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py', 'Stage-TestOwnGlobalDifference.py',
        'Canonical-TestCoreVBA.py', 'Stage-TestVBAHybrid.py', 'Stage-TestVBAHybridTrace.py', 'Stage-TestVBAHybridRadii.py',
        'Stage-TestVBAHybridGlobalJacobian.py', 'Stage-TestStoredStall.py', 'Stage-TestHardStallTangent.py',
        'Stage-TestHardFineTangent.py', 'Stage-TestHardPrepared.py', 'TestNativeVBAHybrid.bas.txt',
        'TestNativeHybridTrace.bas.txt', 'TestNativeStoredStall.bas.txt', 'TestNativeHardStallTangent.bas.txt',
        'TestNativeHardPrepared.bas.txt', 'TestHybridOptimizer.py', 'CHeldHybridEquationsTest.cls.txt',
        'CHeldGlobalJacobianTest.cls.txt', 'Inspect-TestHybridSources.py', 'Analyze-TestHybridFirst.py'):
        destination = root / name
        if not destination.exists():
            destination.write_bytes((here / name).read_bytes())
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': 'fd4c65d',
        'installed_workbook_changed': False, 'new_runtime_components': 3, 'production_continuation_connected': False,
        'global_difference_in_working_solver': True, 'physical_response_adapter_test_only': True,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('OWN VBA HYBRID TRANSFER EVIDENCE COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
