"""ДЛЯ ТЕСТОВ. Проверяет состав первого переноса, начальный контекст и независимый аналитический корень."""

from difflib import unified_diff
from io import BytesIO
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile
import numpy as np
from scipy.optimize import root


def TestMain():
    """Не трактует направленный отказ реального контекста как разрушение сечения."""
    repo = Path.cwd()
    folder = Path('D:/CodexScratch/RC_Section_NDM_TQ/OwnVBAHybrid20261119')
    _, body, reader = run_path(str(repo / 'tmp/material-consistency/Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, actual = reader(BytesIO((folder / 'docs/regression/Diagnostic.xlsm').read_bytes()))
    normal = run_path(str(repo / 'tmp/material-consistency/Canonical-TestCoreVBA.py'))['TestCanonical']
    for file in (repo / 'src').rglob('*.cls'):
        if file.stem not in ('CCoupledHybridSolver', 'CCoupledHybridFactorization', 'ICoupledEquationSystem'):
            continue
        expected = normal(body(file.read_text('utf-8-sig'), file.stem)[0])[0]
        observed = normal(body(actual[file.stem], file.stem)[0])[0]
        print('ACTUAL VBA', file.stem, expected == observed)
        if expected != observed:
            print('\n'.join(list(unified_diff(expected.splitlines(), observed.splitlines()))[:60]))
    rows = [row.split(';') for row in (folder / 'Native/VBAHybrid.csv').read_text('cp1251').splitlines()]
    seed = np.asarray(next(row[1:] for row in rows if row[0] == 'SEED'), float)
    scales = np.asarray(next(row[1:] for row in rows if row[0] == 'SCALES'), float)
    with ZipFile(repo / 'docs/regression/Coupled6D/CoupledHybridStallControl20261119.zip') as bundle:
        prefix = 'Cases/Hybrid/Native/HybridBridge/response-'
        original_seed = np.frombuffer(bundle.read(prefix + '1.bin'), '<f8')
        original_scales = np.frombuffer(bundle.read(prefix + '2.bin'), '<f8')
    print('SEED MAXIMUM CSV ROUNDING', np.max(np.abs(seed - original_seed)))
    print('SCALES MAXIMUM CSV ROUNDING', np.max(np.abs(scales - original_scales)))
    log = (folder / 'Native/HybridCore.txt').read_text('utf-8-sig')
    line = log.split('HYBRID_TRIDIAGONAL_TEST;', 1)[1].split('\nPASS:', 1)[0]
    values = np.asarray(line.replace('\r', '').replace('\n', '').split(';'), float)
    def TestFunction(x):
        """Стандартная девятимерная трёхдиагональная задача MINPACK; без диаграмм материалов."""
        f = (3 - 2 * x) * x + 1
        f[1:] -= x[:-1]
        f[:-1] -= 2 * x[1:]
        return f
    reference = root(TestFunction, -np.ones(9), method='hybr', options={'xtol': 1e-11})
    assert reference.success and values.shape == (9,)
    difference = float(np.max(np.abs(values - reference.x)))
    residual = float(np.max(np.abs(TestFunction(values))))
    assert difference < 1e-9 and residual < 1e-10
    print('INDEPENDENT TRIDIAGONAL ROOT VERIFIED', difference, residual)


if __name__ == '__main__':
    TestMain()
