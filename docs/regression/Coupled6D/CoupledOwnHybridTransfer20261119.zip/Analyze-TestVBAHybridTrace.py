"""ДЛЯ ТЕСТОВ. Независимо проверяет каждую QR-факторизацию и секущее обновление VBA, не меняя допуски равновесия."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile
import numpy as np


def TestAnalyze(repo, root, output):
    """Восстанавливает математические Q,R; сравнивает первый нативный контекст с точными ответами SciPy-контроля."""
    archive = repo / 'docs/regression/Coupled6D/CoupledHybridStallControl20261119.zip'
    assert sha256(archive.read_bytes()).hexdigest().upper() == '078F40F2E1C2120BE493068F187AE128299B72EA02A24DC34762DE6317DD5FE3'
    with ZipFile(archive) as bundle:
        bridge = 'Cases/Hybrid/Native/HybridBridge/'
        requests = [json.loads(row) for row in bundle.read(bridge + 'Requests.ndjson').decode().splitlines()]
        first_j = next(row for row in requests if row['operation'] == 'J')
        first_r = next(row for row in requests if row['operation'] == 'R')
        external_j = np.frombuffer(bundle.read(bridge + 'response-' + str(first_j['sequence']) + '.bin'), '<f8').reshape(61, 61)
        external_r = np.frombuffer(bundle.read(bridge + 'response-' + str(first_r['sequence']) + '.bin'), '<f8')
        scales = np.frombuffer(bundle.read(bridge + 'response-2.bin'), '<f8')
    maximum = lambda value: float(np.max(np.abs(value)))
    rows, context, repeated = [], {}, {}
    repeat_errors = []
    last_trial = last_jacobian = previous = base_x = None
    for file in sorted((root / 'Native/HybridTrace').glob('*.bin'), key=lambda path: int(path.name.split('-')[0])):
        raw = file.read_bytes()
        size = int.from_bytes(raw[:4], 'little', signed=True)
        assert size == 61
        values = np.frombuffer(raw[4:], '<f8')
        kind = file.stem.split('-')[1]
        if kind in ('R', 'J'):
            x, residual = values[:size], values[size:2 * size]
            key = x.tobytes()
            if key in repeated:
                repeat_errors.append(maximum(residual - repeated[key]))
            repeated[key] = residual.copy()
            if kind == 'R':
                assert len(values) == 2 * size
                last_trial = (x, residual)
                if 'first_residual_difference_MPa' not in context:
                    assert np.all(x == 0)
                    context['first_residual_difference_MPa'] = maximum(residual - external_r)
            else:
                matrix = values[2 * size:].reshape(size, size)
                last_jacobian = (x, residual, matrix)
                if 'first_scaled_jacobian_difference' not in context:
                    context['first_scaled_jacobian_difference'] = maximum(matrix - external_j * scales[None, :])
        else:
            assert kind in ('F', 'U') and len(values) == size * size + size * (size + 1) // 2 + size
            q = values[:size * size].reshape(size, size)
            packed = values[size * size:-size]
            r = np.zeros((size, size))
            r[np.triu_indices(size)] = packed
            qtf = values[-size:]
            current = (q, r, qtf)
            orthogonality = maximum(q.T @ q - np.eye(size))
            if kind == 'F':
                x, residual, target = last_jacobian
                base_x = x.copy()
                qtf_error = maximum(qtf - q.T @ residual)
            else:
                old_q, old_r, old_qtf = previous
                trial_x, residual = last_trial
                movement = trial_x - base_x
                movement_square = float(movement @ movement)
                assert movement_square > 0
                model = old_qtf + old_r @ movement
                target = old_q @ old_r + np.outer(residual - old_q @ model, movement) / movement_square
                old_norm, next_norm, model_norm = np.linalg.norm(old_qtf), np.linalg.norm(residual), np.linalg.norm(model)
                actual = 1 - (next_norm / old_norm) ** 2 if next_norm < old_norm else -1
                predicted = 1 - (model_norm / old_norm) ** 2 if model_norm < old_norm else 0
                accepted = predicted > 0 and actual / predicted >= .0001
                expected = residual if accepted else old_q @ old_qtf
                qtf_error = maximum(qtf - q.T @ expected)
                if accepted:
                    base_x = trial_x.copy()
            error = maximum(q @ r - target)
            relative = error / max(1, maximum(target))
            rows.append({'sequence': int(file.name.split('-')[0]), 'kind': kind,
                'matrix_absolute_error': error, 'matrix_scaled_error': relative,
                'orthogonality_error': orthogonality, 'qtf_error': qtf_error})
            previous = current
    context['repeated_exact_coordinate_comparisons'] = len(repeat_errors)
    context['repeated_exact_coordinate_residual_difference_MPa'] = max(repeat_errors, default=0)
    report = {'context': context, 'decompositions': rows, 'physical_capacity_certified': False}
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('HYBRID FACTOR TRACE CONTEXT', context)
    print('HYBRID FACTOR TRACE MAXIMUM', {key: max(row[key] for row in rows)
        for key in ('matrix_absolute_error', 'matrix_scaled_error', 'orthogonality_error', 'qtf_error')})
    assert context['first_residual_difference_MPa'] < 1e-12
    assert context['first_scaled_jacobian_difference'] < 1e-12
    assert all(row['matrix_scaled_error'] < 1e-11 and row['orthogonality_error'] < 1e-11 and row['qtf_error'] < 1e-11 for row in rows)
    print('OWN VBA HYBRID QR AND EVERY RANK ONE UPDATE VERIFIED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.repo.resolve(), args.root.resolve(), args.out.resolve())
