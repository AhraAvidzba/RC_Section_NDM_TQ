"""ДЛЯ ТЕСТОВ. Различает корректность переноса, неудачные управляемые пробы и найденное собственное равновесие."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from io import BytesIO, StringIO
import json
from pathlib import Path
import re
from runpy import run_path
import numpy as np
from scipy.optimize import root as scipy_root


def TestRead(path):
    """Читает закреплённые JSON без подмены статусов и точности чисел."""
    return json.loads(path.read_text('utf-8-sig'))


def TestWrite(path, value):
    """Сохраняет воспроизводимое доказательство с явным незавершённым статусом предела."""
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def TestFiles(root):
    """Сверяет каждый исходный байт и фактическую общую базу всех частных книг."""
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    assert TestRead(root / 'SourceCheckpoint.json')['base'] == 'fd4c65d'
    for case in TestRead(root / 'Cases.json'):
        assert TestRead(root / 'Cases' / case / 'Preparation.json')['base_stage_commit'].startswith('fd4c65d')


def TestNative(repo, root, output):
    """Проверяет фактический VBA шести книг, включая отдельно помеченную потерю точности до исправления констант."""
    TestFiles(root)
    shared = run_path(str(root / 'Check-TestMaterialRoundoff.py'))
    source, _ = run_path(str(root / 'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root / 'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    canonical = run_path(str(root / 'Canonical-TestCoreVBA.py'))
    normal = lambda code: canonical['TestCanonical'](code)[0]
    ordinary = canonical['TestWrap'](body)
    plans = {'Initial': {'HybridCore': (0, 24), 'VBAHybridStall': (1, None)},
        'Trace': {'VBAHybridStall': (1, None)}, 'Restart': {'HybridCore': (0, 27), 'VBAHybridStall': (1, None)},
        'Radii': {'VBAHybridStall': (1, None)}, 'Global': {'VBAHybridStall': (0, 2)},
        'Own': {'HybridCore': (0, 30), 'VBAHybridStall': (0, 2)}}
    cases = {}
    for case, phases in plans.items():
        folder = root / 'Cases' / case
        legacy = case in ('Initial', 'Trace')
        def TestNormalize(code, name):
            """Не объявляет первоначальный источник точным: три явные потери VBE разрешены только в сохранённых неудачных попытках."""
            result = normal(code)
            if legacy and name in ('CCoupledHybridSolver', 'CCoupledHybridFactorization'):
                for before, after in (('2.2204460492503131e-16', '2.22044604925031e-16'),
                    ('5.5626846462680035e-309', '5.562684646268e-309'), ('1.7976931348623157e308', '1.79769313486232e308')):
                    old = normal('x=' + before).split('=', 1)[1]
                    new = normal('x=' + after).split('=', 1)[1]
                    result = result.replace(old, new)
                rows = result.splitlines(keepends=True)
                for index, line in enumerate(rows):
                    if 'then tau =' in line and "'" in line:
                        value, comment = line.split("'", 1)
                        rows[index] = value.rstrip() + " '" + comment
                result = ''.join(rows)
            return result
        def TestBody(code, name):
            """Сохраняет значения и типы всех остальных чисел и строк; рабочие кандидаты проверяются без потерь точности."""
            result = ordinary(code, name)
            if name == 'modTestCoupledElasticState':
                before = normal('x=1.0949918086043462').split('=', 1)[1]
                after = normal('x=1.09499180860435').split('=', 1)[1]
                result = (result[0].replace(before, after), *result[1:])
            if name in ('CCoupledNewtonSolver', 'CCoupledHybridSolver', 'CCoupledHybridFactorization'):
                return (TestNormalize(result[0], name), *result[1:])
            return result
        result = shared['TestSourceComparison'](repo, root, folder, source, original, helper, TestBody, reader)
        assert (result['components'], result['imported'], result['unchanged']) == (245, 31, 214)
        _, actual = reader(helper['TestContainer']((folder / 'CompiledVBA.bin').read_bytes()))
        checked = []
        for relative in TestRead(folder / 'AllCoupledSources.json'):
            file = folder / relative
            expected, _ = helper['TestMVTCompilerBody'](body, file.read_text('utf-8-sig'), file.stem)
            observed = body(actual[file.stem], file.stem)[0]
            if file.stem == 'CCoupledConcreteReturn':
                def TestSpacing(code):
                    """Учитывает выравнивание одной известной константы VBE без изменения комментария."""
                    lines = code.splitlines(keepends=True)
                    for i, line in enumerate(lines):
                        if line.startswith('private const rounding_limit as double = '):
                            value, comment = line.split("'", 1)
                            lines[i] = value.rstrip() + " '" + comment
                    return ''.join(lines)
                expected, observed = TestSpacing(expected), TestSpacing(observed)
            assert TestNormalize(expected, file.stem) == TestNormalize(observed, file.stem), (case, file.stem)
            checked.append(file.stem)
        assert len(checked) == 33
        result['checked_coupled_sources'] = checked
        result['initial_source_precision_loss_present'] = legacy
        result['current_numerical_sources_exact'] = not legacy
        result['first_test_reference_literal_rounded_by_VBE'] = case != 'Own'
        assert {p.stem for p in (folder / 'Native').glob('*.txt')} == set(phases)
        reports = {}
        for phase, (exit_code, count) in phases.items():
            file = folder / 'Native' / (phase + '.txt')
            log = file.read_text('utf-8-sig')
            owner = TestRead(file.with_name(file.name + '.Ownership.json'))
            closure = TestRead(file.with_name(file.name + '.ProcessClosure.json'))
            compiler = TestRead(folder / 'docs/regression/CodeUpdate.json')
            identity = closure['Closure']['Identity']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
            assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
            assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
            assert closure['ChildExitCode'] == exit_code and closure['Closure']['FinalState']['State'] == 'Absent'
            assert 'SOURCE_UNCHANGED: True' in log
            if exit_code:
                assert 'RUNTIME ERROR: VBAProject VBA HYBRJ не нашёл контрольное равновесие.' in log
                assert 'VBA_HYBRID;False;' in log
            else:
                assert 'RUNTIME ERROR:' not in log
                totals = [tuple(map(int, pair)) for pair in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', log, re.M)]
                assert totals and sum(a for a, _ in totals) == count and all(b == 0 for _, b in totals)
            reports[phase] = {'native_exit_code': exit_code, 'assertions': count, 'equilibrium_test_passed': exit_code == 0}
        safety = [json.loads(row) for row in (folder / 'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in safety)
        assert all(all(p['ProtectedUser'] for p in row['excel']) for row in safety)
        result['reports'] = reports
        cases[case] = result
    TestWrite(output, {'cases': cases, 'production_continuation_connected': False, 'installed_workbook_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False})
    print('OWN VBA HYBRID SIX ACTUAL BOOKS AND EXPECTED FAILED ATTEMPTS VERIFIED')


def TestMechanics(repo, root, output):
    """Проверяет все основные поля, собственную найденную точку и независимый девятимерный корень."""
    TestFiles(root)
    validate = run_path(str(root / 'Validate-TestHardPrepared.py'))['TestValidate']
    cases, original = {}, None
    for case in TestRead(root / 'Cases.json'):
        proof, fields = validate(root / 'Cases' / case, 'HardEarlyField')
        assert len(fields) == 22 and not proof['reversed_fields'] and proof['meta'][0] == '6'
        if original is None: original = fields
        else: assert np.array_equal(fields, original)
        cases[case] = proof
    with redirect_stdout(StringIO()):
        run_path(str(root / 'Check-TestVBAHybridGlobalPoint.py'))['TestCheck'](repo, root / 'Cases/Global', output)
    point = TestRead(output)
    with redirect_stdout(StringIO()):
        run_path(str(root / 'Check-TestVBAHybridGlobalPoint.py'))['TestCheck'](repo, root / 'Cases/Own', output)
    own = TestRead(output)
    _, prototype_fields = validate(root / 'Cases/Global', 'HardEarlyField.HybridCandidate')
    _, own_fields = validate(root / 'Cases/Own', 'HardEarlyField.HybridCandidate')
    assert np.array_equal(prototype_fields, own_fields)
    budget = (root / 'Cases/Own/Native/VBAHybrid.csv').read_text('cp1251')
    assert 'OWN_GLOBAL_DIFFERENCE;native_calls=1148;solver_calls=1147;preflight_calls=1;' in budget
    assert 'function_limit=2000;step_limit=350' in budget
    logs = {}
    for case in ('Initial', 'Restart', 'Own'):
        text = (root / 'Cases' / case / 'Native/HybridCore.txt').read_text('utf-8-sig')
        line = text.split('HYBRID_TRIDIAGONAL_TEST;', 1)[1].split('\nPASS:', 1)[0]
        values = np.asarray(line.replace('\r', '').replace('\n', '').split(';'), float)
        def TestFunction(x):
            """Стандартная трёхдиагональная задача MINPACK с независимым контрольным решением SciPy."""
            result = (3 - 2 * x) * x + 1
            result[1:] -= x[:-1]
            result[:-1] -= 2 * x[1:]
            return result
        reference = scipy_root(TestFunction, -np.ones(9), method='hybr', options={'xtol': 1e-11})
        difference = float(np.max(np.abs(values - reference.x)))
        residual = float(np.max(np.abs(TestFunction(values))))
        assert reference.success and difference < 1e-9 and residual < 1e-10
        logs[case] = {'maximum_root_difference': difference, 'maximum_residual': residual}
    TestWrite(output, {'main_fields': cases, 'main_fields_exact_across_six_books': 22, 'prototype_global_point': point,
        'working_global_point': own, 'prototype_and_working_candidate_fields_exact': 22,
        'working_function_calls': 1147, 'actual_adapter_calls_including_preflight': 1148,
        'independent_tridiagonal_controls': logs, 'physical_capacity_certified': False})
    print('OWN VBA HYBRID GLOBAL POINT ALL EQUATIONS AND INDEPENDENT ROOTS VERIFIED; CAPACITY OPEN')


def TestAlgebra(repo, root, output):
    """Проверяет каждое разложение и обновление ранга один независимо от исхода поиска нелинейного корня."""
    TestFiles(root)
    with redirect_stdout(StringIO()):
        run_path(str(root / 'Analyze-TestVBAHybridTrace.py'))['TestAnalyze'](repo, root / 'Cases/Trace', output)
    record = TestRead(output)
    assert record['context']['repeated_exact_coordinate_residual_difference_MPa'] == 0
    print('OWN VBA HYBRID EVERY QR AND RANK ONE UPDATE INDEPENDENTLY VERIFIED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics', 'algebra'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics, 'algebra': TestAlgebra}[args.scope](
        args.repo.resolve(), args.root.resolve(), args.out.resolve())
