"""ДЛЯ ТЕСТОВ. Сравнивает допустимые начальные радиусы одного HYBRJ при неизменном исходном контексте."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Все старты делят один бюджет 350 невязок и 350 поправок; пределы материалов не меняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestVBAHybrid.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '    Dim solved As Boolean: solved = solver.TrySolve(equations, coordinates, 350, 350, 0.0000000001, 0.00000000001, 0.2, solution, maxRestarts:=3)'
    assert code.count(old) == 1
    code = code.replace(old, '''    Dim solved As Boolean, radius As Variant, attempt As Long, radiiDetails As String
    Dim usedFunctions As Long, usedJacobians As Long, usedSteps As Long, usedAccepted As Long
    For Each radius In Array(0.2, 0.1, 0.5, 1#)
        If usedFunctions >= 350 Or usedSteps >= 350 Then Exit For
        attempt = attempt + 1: ReDim coordinates(1 To UBound(seed))
        solved = solver.TrySolve(equations, coordinates, 350 - usedFunctions, 350 - usedSteps, _
            0.0000000001, 0.00000000001, CDbl(radius), solution)
        usedFunctions = usedFunctions + solver.FunctionCalls: usedJacobians = usedJacobians + solver.JacobianCalls
        usedSteps = usedSteps + solver.Steps: usedAccepted = usedAccepted + solver.AcceptedSteps
        radiiDetails = radiiDetails & "RADII_ATTEMPT;" & CStr(attempt) & ";" & TestOnsetNumber(CDbl(radius)) & ";" & CStr(solved) & _
            ";" & TestOnsetNumber(solver.BestResidual) & ";" & CStr(solver.FunctionCalls) & ";" & CStr(solver.JacobianCalls) & _
            ";" & CStr(solver.Steps) & ";" & CStr(solver.StopCode) & vbCrLf
        If solved Then Exit For
    Next radius''', 1)
    old = '    Print #handle, result\n    Print #handle, "SEED"'
    assert code.count(old) == 1
    code = code.replace(old, '''    Print #handle, result
    Print #handle, radiiDetails;
    Print #handle, "RADII_TOTAL;" & CStr(usedFunctions) & ";" & CStr(usedJacobians) & ";" & CStr(usedSteps) & ";" & CStr(usedAccepted)
    Print #handle, "SEED"''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'initial_radii': [.2, .1, .5, 1], 'shared_function_and_step_budget': 350})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('OWN VBA HYBRID INITIAL RADIUS CONTROL READY; SHARED BUDGET 350', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
