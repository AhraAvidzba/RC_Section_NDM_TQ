VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CHeldHybridEquationsTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: центральная разность полной системы на точной принятой истории
' ==========================================================================
' Отличается только способом численного дифференцирования. Полные невязки,
' закон материала, история, нагрузка и окончательная проверка остаются штатными.
Implements ICoupledEquationSystem
Private mSeed() As Double, mScales() As Double, mCallsTest As Long, mMatricesTest As Long

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет исходное приближение и масштабы; сбрасывает независимые счётчики внутренних проб.
Friend Sub InitializeTest(ByRef seed() As Double, ByRef scales() As Double)
    mSeed = seed: mScales = scales: mCallsTest = 0: mMatricesTest = 0
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает фактические чтения механической невязки, включая все столбцы численной касательной.
Friend Property Get NativeResidualCallsTest() As Long
    NativeResidualCallsTest = mCallsTest
End Property

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает число полных глобальных касательных; материальные касательные при их построении не запрашиваются.
Friend Property Get GlobalMatricesTest() As Long
    GlobalMatricesTest = mMatricesTest
End Property

' Реализация тестового интерфейса: численная производная имеет первый индекс столбца.
Private Function ICoupledEquationSystem_TryEvaluate(ByRef coordinates() As Double, ByVal withJacobian As Boolean, _
        ByRef residual() As Double, ByRef jacobian() As Double) As Boolean
    On Error GoTo Failed
    residual = ReadResidualTest(coordinates)
    If withJacobian Then
        mMatricesTest = mMatricesTest + 1
        Dim size As Long: size = UBound(coordinates)
        Dim plus() As Double, minus() As Double, point() As Double, row As Long, column As Long, delta As Double
        ReDim jacobian(1 To size, 1 To size)
        For column = 1 To size
            delta = 0.000001 * (1# + Abs(coordinates(column)))
            point = coordinates: point(column) = coordinates(column) + delta: plus = ReadResidualTest(point)
            point(column) = coordinates(column) - delta: minus = ReadResidualTest(point)
            For row = 1 To size: jacobian(column, row) = (plus(row) - minus(row)) / (2# * delta): Next row
        Next column
    End If
    ICoupledEquationSystem_TryEvaluate = True
    Exit Function
Failed:
    ICoupledEquationSystem_TryEvaluate = False
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вычисляет неизменённую полную невязку; жёсткий отдельный предел не позволяет скрыть внутренние разностные пробы.
Private Function ReadResidualTest(ByRef coordinates() As Double) As Double()
    mCallsTest = mCallsTest + 1
    If mCallsTest > 10000 Then Err.Raise 5, , "Достигнут отдельный бюджет внутренних разностных проб."
    Dim size As Long: size = UBound(mSeed)
    Dim values() As Double, result As Variant, residual() As Double, degree As Long
    ReDim values(1 To size): ReDim residual(1 To size)
    For degree = 1 To size: values(degree) = mSeed(degree) + mScales(degree) * coordinates(degree): Next degree
    result = modTestCoupledElasticState.TestEvaluateStoredForHybrid(values, False)
    For degree = 1 To size: residual(degree) = result(degree): Next degree
    ReadResidualTest = residual
End Function
