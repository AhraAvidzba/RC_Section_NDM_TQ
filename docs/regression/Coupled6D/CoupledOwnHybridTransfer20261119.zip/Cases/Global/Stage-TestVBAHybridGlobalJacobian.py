"""ДЛЯ ТЕСТОВ. Различает численный метод и материальную касательную через производную полной неизменённой системы."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Меняет только частную реализацию интерфейса; рабочие материалы и допуски равновесия исходны."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestVBAHybrid.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/CHeldHybridEquationsTest.cls'
    (root / name).write_bytes((here / 'CHeldGlobalJacobianTest.cls.txt').read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '0.2, solution, maxRestarts:=3)'
    assert code.count(old) == 1
    code = code.replace(old, '0.2, solution)', 1)
    old = '    Print #handle, result\n    Print #handle, "SEED"'
    assert code.count(old) == 1
    code = code.replace(old, '''    Print #handle, result
    Print #handle, "GLOBAL_JACOBIAN;native_residual_calls=" & CStr(adapter.NativeResidualCallsTest) & _
        ";global_matrices=" & CStr(adapter.GlobalMatricesTest) & ";relative_step=0.000001;inner_probe_limit=10000"
    Print #handle, "SEED"''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'jacobian': 'central difference of complete system', 'relative_coordinate_step': 1e-6,
        'internal_residual_budget': 10000, 'function_counter_excludes_internal_jacobian_probes': True})
    for file in (Path(__file__), here / 'CHeldGlobalJacobianTest.cls.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('OWN VBA HYBRID GLOBAL JACOBIAN CONTROL READY; PHYSICAL EQUATIONS UNCHANGED', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
