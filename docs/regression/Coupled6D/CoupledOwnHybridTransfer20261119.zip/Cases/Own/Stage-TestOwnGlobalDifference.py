"""ДЛЯ ТЕСТОВ. Проверяет собственную глобальную касательную рабочего HYBRJ без дублирования математики в адаптере."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Каждая разностная проба теперь учитывается самим рабочим решателем; адаптер только читает штатный отклик."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestVBAHybrid.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/CHeldHybridEquationsTest.cls'
    code = (root / name).read_text('utf-8-sig')
    old = 'Private mSeed() As Double, mScales() As Double'
    assert code.count(old) == 1
    code = code.replace(old, old + ', mNativeCallsTest As Long', 1)
    old = '    result = modTestCoupledElasticState.TestEvaluateStoredForHybrid(values, False)'
    assert code.count(old) == 1
    code = code.replace(old, '    mNativeCallsTest = mNativeCallsTest + 1\n' + old, 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает фактическое число чтений полной невязки независимо от счётчиков рабочего решателя.
Friend Property Get NativeCallsTest() As Long
    NativeCallsTest = mNativeCallsTest
End Property
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = 'solver.TrySolve(equations, coordinates, 350, 350, 0.0000000001, 0.00000000001, 0.2, solution, maxRestarts:=3)'
    assert code.count(old) == 1
    code = code.replace(old, 'solver.TrySolve(equations, coordinates, 2000, 350, 0.0000000001, 0.00000000001, 0.2, solution, relativeDifferenceStep:=0.000001)', 1)
    old = '    Print #handle, result\n    Print #handle, "SEED"'
    assert code.count(old) == 1
    code = code.replace(old, '''    Print #handle, result
    Print #handle, "OWN_GLOBAL_DIFFERENCE;native_calls=" & CStr(adapter.NativeCallsTest) & _
        ";solver_calls=" & CStr(solver.FunctionCalls) & ";preflight_calls=1;relative_step=0.000001;function_limit=2000;step_limit=350"
    Print #handle, "SEED"''', 1)
    old = '    If Not solved Then Err.Raise 5, , "VBA HYBRJ не нашёл контрольное равновесие. " & result'
    assert code.count(old) == 1
    code = code.replace(old, '''    If adapter.NativeCallsTest <> solver.FunctionCalls + 1 Then Err.Raise 5, , "Не учтены внутренние разностные пробы."
    If solver.FunctionCalls > 2000 Or solver.Steps > 350 Then Err.Raise 5, , "Нарушен общий бюджет рабочего HYBRJ."
''' + old, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'jacobian_in_working_solver': True, 'relative_coordinate_step': 1e-6,
        'shared_all_residual_evaluation_budget': 2000, 'shared_dogleg_step_budget': 350,
        'internal_probes_counted_in_working_solver': True, 'test_adapter_contains_no_differentiation': True})
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('OWN WORKING GLOBAL DIFFERENCE AND COMPLETE BUDGET CONTROL READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
