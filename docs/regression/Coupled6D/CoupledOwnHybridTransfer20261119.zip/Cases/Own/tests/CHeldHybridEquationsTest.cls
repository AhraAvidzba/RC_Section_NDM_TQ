﻿VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CHeldHybridEquationsTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ==========================================================================
' ДЛЯ ТЕСТОВ: адаптер точного удержанного материального контекста
' ==========================================================================
' Только частная книга содержит читающие методы modTestCoupledElasticState.
' Масштабы и начало совпадают с независимой пробой SciPy; история не принимается.
Implements ICoupledEquationSystem
Private mSeed() As Double, mScales() As Double, mNativeCallsTest As Long

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет начало и масштабы всех неизвестных без текстового округления.
Friend Sub InitializeTest(ByRef seed() As Double, ByRef scales() As Double)
    mSeed = seed: mScales = scales
End Sub

' Реализация тестового интерфейса: механическая матрица имеет первый индекс столбца.
Private Function ICoupledEquationSystem_TryEvaluate(ByRef coordinates() As Double, ByVal withJacobian As Boolean, _
        ByRef residual() As Double, ByRef jacobian() As Double) As Boolean
    On Error GoTo Failed
    Dim size As Long: size = UBound(mSeed)
    Dim values() As Double, result As Variant, matrix As Variant, row As Long, column As Long
    ReDim values(1 To size): ReDim residual(1 To size)
    For column = 1 To size: values(column) = mSeed(column) + mScales(column) * coordinates(column): Next column
    mNativeCallsTest = mNativeCallsTest + 1
    result = modTestCoupledElasticState.TestEvaluateStoredForHybrid(values, False)
    For row = 1 To size: residual(row) = result(row): Next row
    If withJacobian Then
        matrix = modTestCoupledElasticState.TestEvaluateStoredForHybrid(values, True)
        ReDim jacobian(1 To size, 1 To size)
        For row = 1 To size
            For column = 1 To size
                jacobian(column, row) = CDbl(matrix((row - 1) * size + column)) * mScales(column)
            Next column
        Next row
    End If
    ICoupledEquationSystem_TryEvaluate = True
    Exit Function
Failed:
    ICoupledEquationSystem_TryEvaluate = False
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает фактическое число чтений полной невязки независимо от счётчиков рабочего решателя.
Friend Property Get NativeCallsTest() As Long
    NativeCallsTest = mNativeCallsTest
End Property
