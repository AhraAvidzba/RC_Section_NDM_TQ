"""ДЛЯ ТЕСТОВ. Снимает точные QR и секущие обновления собственного гибридного метода, не меняя его арифметику."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Добавляет читающие двоичные записи только в частные компоненты, сохраняя первый неудачный перенос отдельно."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestVBAHybrid.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    def TestOnce(code, old, new):
        """Запрещает неоднозначную вставку наблюдения."""
        assert code.count(old) == 1, old
        return code.replace(old, new, 1)
    name = 'src/Solver/CCoupledHybridSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, '        algebra.Factor matrix, residual, count', '''        modTestCoupledElasticState.TestTraceHybridEvaluation "J", x, residual, matrix
        algebra.Factor matrix, residual, count
        modTestCoupledElasticState.TestTraceHybridFactors "F", algebra''')
    code = TestOnce(code, '            algebra.Update movement, nextResidual, model, movementNorm, accepted', '''            algebra.Update movement, nextResidual, model, movementNorm, accepted
            modTestCoupledElasticState.TestTraceHybridFactors "U", algebra''')
    code = TestOnce(code, '    ReadResidual = True', '    modTestCoupledElasticState.TestTraceHybridEvaluation "R", x, residual, matrix\n    ReadResidual = True')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'src/Solver/CCoupledHybridFactorization.cls'
    code = (root / name).read_text('utf-8-sig') + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает точные копии разложения для независимой проверки матричного обновления.
Friend Sub TestCopyHybridFactors(ByRef q() As Double, ByRef r() As Double, ByRef qtf() As Double)
    q = mQ: r = mR: qtf = mQtf
End Sub
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code = TestOnce(code, 'Option Explicit\n', 'Option Explicit\nPublic HybridTraceFolderTest As String, HybridTraceCountTest As Long\n')
    code = TestOnce(code, '    Dim started As Double: started = Timer\n    Dim solved As Boolean: solved = solver.TrySolve(equations, coordinates, 350, 350,', '''    HybridTraceFolderTest = outputRoot & "\\Native\\HybridTrace": MkDir HybridTraceFolderTest
    Dim started As Double: started = Timer
    Dim solved As Boolean: solved = solver.TrySolve(equations, coordinates, 350, 350,''')
    code += '\n' + (here / 'TestNativeHybridTrace.bas.txt').read_text('utf-8-sig')
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledHybridSolver.cls', 'src/Solver/CCoupledHybridFactorization.cls', 'tests/modTestCoupledElasticState.bas'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeHybridTrace.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope']['binary_QR_trace_only'] = True
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('OWN HYBRID EXACT FACTOR TRACE READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
