"""ДЛЯ ТЕСТОВ. Проверяет собственное гибридное равновесие и его совпадение с независимым численным контролем."""

from argparse import ArgumentParser
import csv
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile
import numpy as np


def TestCheck(repo, folder, output):
    """Собирает уравнения и силы по напряжениям трёх станций; первичную историю не заменяет чужой ветвью."""
    here = Path(__file__).resolve().parent
    validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
    main, main_fields = validate(folder, 'HardEarlyField')
    point, fields = validate(folder, 'HardEarlyField.HybridCandidate')
    assert len(main_fields) == len(fields) == 22 and np.array_equal(fields[:21], main_fields[:21])
    assert point['meta'][:2] == ['4', '0'] and not point['reversed_fields']
    archive = repo / 'docs/regression/Coupled6D/CoupledHybridStallControl20261119.zip'
    assert sha256(archive.read_bytes()).hexdigest().upper() == '078F40F2E1C2120BE493068F187AE128299B72EA02A24DC34762DE6317DD5FE3'
    with ZipFile(archive) as bundle:
        data = bundle.read('Cases/Hybrid/Native/HardEarlyField.HybridCandidate.csv').decode('cp1251')
        original_rows = list(csv.reader(StringIO(data), delimiter=';'))
        original_fields = np.asarray([row[4:] for row in original_rows if row and row[0] == 'F'], float)
        original_factor = float([row[3] for row in original_rows if row and row[0] == 'F'][-1])
    assert np.array_equal(fields[:21], original_fields[:21])
    helpers = run_path(str(here / 'Check-TestHardHalfSteps.py'))
    _, _, _, _, _, _, b, slope = helpers['TestOperators'](folder / 'Native/HardEarlyField.HybridCandidate.Operators.csv', 60, 43)
    difference = fields[-1] - original_fields[-1]
    strain = np.einsum('pcd,d->pc', b, difference)
    gradient = np.einsum('pcd,d->pc', slope, difference)
    half = .001 / 128
    strain_difference = max(float(np.max(np.abs(strain + side * half * gradient))) for side in (-1, 0, 1))
    def TestCentral(rows):
        """Выбирает действительные тензоры, повреждения и сталь последней центральной станции."""
        return np.asarray([row[4:] for row in rows if len(row) > 4 and row[:3] == ['S', '22', '0']], float)
    actual_rows = helpers['TestRows'](folder / 'Native/HardEarlyField.HybridCandidate.csv')
    actual_stress, original_stress = TestCentral(actual_rows), TestCentral(original_rows)
    assert actual_stress.shape == original_stress.shape == (43, 9)
    stress_difference = float(np.max(np.abs(actual_stress[:, :6] - original_stress[:, :6])))
    factor_difference = abs(point['maximum_lambda'] - original_factor)
    assert factor_difference < 1e-6 and strain_difference < 1e-8 and stress_difference < .01
    rows = list(csv.reader(StringIO((folder / 'Native/VBAHybrid.csv').read_text('cp1251')), delimiter=';'))
    native = np.asarray(next(row[1:] for row in rows if row and row[0] == 'NATIVE_VALIDATION'), float)
    assert native.shape == (8,) and native[0] == native[1] == 1 and native[3] <= native[2]
    assert native[4] <= 1 and native[5] > 0 and native[6] > native[7]
    assert any(row[:2] == ['ACCEPTED_HISTORY_UNCHANGED', 'True'] for row in rows)
    assert any(row[:2] == ['BUDGET1', 'False'] for row in rows)
    proof = {'main': main, 'candidate': point, 'candidate_own_prefix_exact': 21,
        'external_control_lambda_difference': factor_difference,
        'maximum_three_station_strain_difference': strain_difference,
        'maximum_central_concrete_stress_difference_MPa': stress_difference,
        'native_validation': native.tolist(), 'independent_material_reintegration': False,
        'physical_capacity_certified': False}
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('OWN VBA HYBRID POINT ALL EQUATIONS SIX FORCES AND EXTERNAL CONTROL VERIFIED; CAPACITY OPEN')
    print('CONTROL DIFFERENCES', factor_difference, strain_difference, stress_difference)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestCheck(args.repo.resolve(), args.root.resolve(), args.out.resolve())
