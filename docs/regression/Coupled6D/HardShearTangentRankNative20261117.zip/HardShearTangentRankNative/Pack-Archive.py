"""Создаёт отдельно проверяемый архив диагностики касательной HardShear."""

from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_call, check_output
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from RankSummary import summarize
from Verify import inputs, obj, parse

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
PREFIX = "HardShearTangentRankNative"
ARCHIVE = HERE / f"{PREFIX}20261117.zip"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def serialized(x):
    return (json.dumps(x, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def main():
    fixture = obj("Fixture.json")
    inputs(fixture)
    files = {}
    for name, expected in fixture["inputs"].items():
        raw = (HERE / name).read_bytes()
        assert digest(raw) == expected
        files[name] = raw
    for name, expected in fixture["production"].items():
        raw = check_output(["git", "show", f"{fixture['source_revision']}:{name}"], cwd=REPO)
        assert digest(raw) == expected
        files[f"Baseline/{name}"] = raw
    for name in ("Fixture.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "Run-Compiled.ps1",
                 "docs/regression/CodeUpdate.json", "Pack-Archive.py", "Verify-Archive.py", "RankSummary.py", "README-Archive.md"):
        files[name] = (HERE / name).read_bytes()
    for path in sorted((HERE / "Native").iterdir()):
        if path.is_file() and path.suffix.lower() != ".xlsm":
            files[path.relative_to(HERE).as_posix()] = path.read_bytes()
    source = (HERE.parent / "hs-fold/Native/Verification.json").read_bytes()
    assert digest(source) == fixture["source_shoulder_report_sha256"]
    files["Inputs/NativeShoulderVerification.json"] = source
    report = obj("Native/Verification.json")
    actual = parse(HERE / "Native/HardRank.csv")
    audit = summarize(actual, report)
    log = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    saved = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", log, re.M)
    elapsed = re.search(r"^RANK_TIME: ([0-9.,]+)$", log, re.M)
    assert saved and elapsed
    saved_path = Path(saved[2]).resolve(strict=True)
    assert saved_path.is_relative_to(HERE / "Temp")
    audit.update(native_seconds=float(elapsed[1].replace(",", ".")), saved_results_reopen_sha256=saved[1],
                 saved_workbook_sha256=digest(saved_path.read_bytes()),
                 native_log_sha256=digest(files["Native/HardShear.txt"]), report_sha256=digest(files["Native/Verification.json"]))
    files["Audit.json"] = serialized(audit)
    files["SHA256SUMS.json"] = serialized({name: digest(raw) for name, raw in sorted(files.items())})
    with TemporaryDirectory(prefix="rank-proof-", dir=HERE) as directory:
        scratch = Path(directory)
        artifact = scratch / ARCHIVE.name
        with ZipFile(artifact, "w", ZIP_DEFLATED, compresslevel=9) as bundle:
            for name, raw in sorted(files.items()):
                entry = ZipInfo(f"{PREFIX}/{name}", date_time=(2026, 11, 17, 0, 0, 0))
                bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(artifact) as bundle:
            assert bundle.testzip() is None and not any(n.lower().endswith(".xlsm") for n in bundle.namelist())
            bundle.extractall(scratch / "detached")
        cmd = [sys.executable, "-B", "-X", "utf8", "Verify-Archive.py"]
        cwd = scratch / "detached" / PREFIX
        check_call(cmd, cwd=cwd)
        check_call([*cmd, "--saved-workbook", str(saved_path)], cwd=cwd)
        ARCHIVE.write_bytes(artifact.read_bytes())
    checksum = digest(ARCHIVE.read_bytes())
    ARCHIVE.with_suffix(".zip.sha256").write_bytes(f"{checksum}  {ARCHIVE.name}\n".encode("ascii"))
    print("PORTABLE HARD SHEAR RANK VERIFIED", checksum, ARCHIVE.stat().st_size)


if __name__ == "__main__":
    main()
