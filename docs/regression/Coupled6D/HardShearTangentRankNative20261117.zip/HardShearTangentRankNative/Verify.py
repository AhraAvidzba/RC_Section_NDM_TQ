"""Сверяет повторные равновесия, проектирует касательную и сравнивает стороны."""

import argparse
from hashlib import sha256
import json
from math import copysign, fsum, hypot, isclose, isfinite, sqrt
from pathlib import Path
import re
from struct import unpack
from subprocess import check_output

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def obj(name):
    return json.loads((HERE / name).read_text(encoding="utf-8-sig"))


def val(raw):
    assert re.fullmatch(r"[0-9A-F]{16}", raw)
    x, = unpack(">d", bytes.fromhex(raw))
    assert isfinite(x)
    return x


def dot(a, b):
    return fsum(x*y for x, y in zip(a, b, strict=True))


def norm(a):
    return sqrt(dot(a, a))


def matvec(a, x):
    return [dot(row, x) for row in a]


def transpose(a):
    return list(zip(*a, strict=True))


def unit(a):
    length = norm(a)
    assert length
    return [x/length for x in a]


def null_basis(constraints):
    n = len(constraints[0])
    rank = len(constraints)
    identity = [[float(i == j) for i in range(n)] for j in range(n)]
    basis = []
    for input_vector in [*(unit(row) for row in constraints), *identity]:
        vector = list(input_vector)
        for _ in range(2):
            for direction in basis:
                coefficient = dot(vector, direction)
                vector = [v-coefficient*d for v, d in zip(vector, direction, strict=True)]
        if norm(vector) > 2e-13:
            basis.append(unit(vector))
    assert len(basis) == n
    free = basis[rank:]
    assert all(abs(dot(c, z)) < 5e-12*norm(c) for c in constraints for z in free)
    return free


def singular(a):
    """Односторонние вращения Якоби сохраняют малые σ без построения AᵀA."""
    cols = [list(col) for col in transpose(a)]
    n = len(cols)
    right = [[float(i == j) for i in range(n)] for j in range(n)]
    for sweep in range(80):
        changes = 0
        for i, x in enumerate(cols):
            for j in range(i+1, n):
                y = cols[j]
                xx, yy, xy = dot(x, x), dot(y, y), dot(x, y)
                if not xx or not yy or abs(xy) <= 8e-15*sqrt(xx*yy):
                    continue
                tau = (yy-xx)/(2*xy)
                tangent = copysign(1., tau)/(abs(tau)+hypot(1., tau))
                c = 1/hypot(1., tangent)
                s = c*tangent
                cols[j] = [s*u+c*v for u, v in zip(x, y, strict=True)]
                cols[i] = x = [c*u-s*v for u, v in zip(x, y, strict=True)]
                v, w = right[i], right[j]
                right[i] = [c*u-s*z for u, z in zip(v, w, strict=True)]
                right[j] = [s*u+c*z for u, z in zip(v, w, strict=True)]
                changes += 1
        if not changes:
            break
    else:
        raise ArithmeticError("Jacobi SVD did not converge")
    sigmas = [norm(col) for col in cols]
    k = min(range(n), key=lambda i: sigmas[i])
    u, v = unit(cols[k]) if sigmas[k] else None, right[k]
    assert max(abs(x-y) for x, y in zip(matvec(a, v), cols[k], strict=True)) <= 1e-11*max(sigmas)
    return sigmas[k], max(sigmas), u, v


def parse(path):
    rows = [line.split(";") for line in path.read_text(encoding="ascii").splitlines()]
    assert rows[0] == ["HARDSHEAR-RANK", "1"]
    cases = {}
    record = None
    for line in rows[1:]:
        kind, *value = line
        if kind == "BEGIN":
            assert record is None
            name, history, gauge, modulus, factor, target = value
            record = {"name": name, "history": int(history), "gauge": int(gauge),
                      "modulus": val(modulus), "factor": val(factor), "target": val(target),
                      "matrix": [], "fd": [], "failed": []}
        elif kind == "END":
            assert record and value == [record["name"]]
            cases[record["name"]] = record
            record = None
        elif kind == "K":
            assert int(value[0]) == len(record["matrix"])+1 and len(value) == 61
            record["matrix"].append(list(map(val, value[1:])))
        elif kind == "FD":
            assert len(value) == 61
            record["fd"].append((val(value[0]), list(map(val, value[1:]))))
        elif kind in ("FD-FAIL", "TANGENT-FAIL"):
            record["failed"].append(line)
        else:
            assert kind in ("FIELD", "FORCE", "MEASURED", "BASE", "DIRECTION", "PROJECTION", "TANGENT")
            record[kind] = list(map(val, value))
    assert record is None
    return cases


def study(case, baseline, guide):
    assert case["history"] == baseline["accepted_before"]
    assert case["FIELD"] == list(map(val, baseline["field_bits"]))
    assert case["PROJECTION"] == list(map(val, guide))
    assert (case["factor"], case["target"]) == (baseline["lambda"], baseline["requested"])
    assert case["FORCE"] == baseline["target"]
    force_scales = (21600., 2219577.365175632, 2219577.365175632, 2219577.365175632, 21600., 21600.)
    replay_force_gap = max(abs(a-b)/s for a, b, s in zip(case["MEASURED"], baseline["resultants"], force_scales, strict=True))
    assert replay_force_gap < 3e-12
    dof, gauge = 60, case["gauge"]-1
    assert gauge == 56 and len(case["matrix"]) == dof
    wp = max(map(abs, case["BASE"][:gauge]))
    gp = case["modulus"]*max(map(abs, case["BASE"][gauge:]))
    assert isclose(wp, baseline["weak_residual_MPa"], abs_tol=3e-12)
    assert isclose(gp, baseline["gauge_residual_MPa"], abs_tol=3e-12)
    k = case["matrix"]
    g = [row[:gauge] for row in k[gauge:]]
    assert all(k[i][j] == k[j][i] for i in range(gauge, dof) for j in range(gauge))
    assert all(k[i][j] == 0. for i in range(gauge, dof) for j in range(gauge, dof))
    assert all(x == 0. for x in case["PROJECTION"][gauge:]+case["DIRECTION"][gauge:])
    z = null_basis(g)
    kfree = [row[:gauge] for row in k[:gauge]]
    kz = [matvec(kfree, column) for column in z]
    reduced = [[dot(left, right) for right in kz] for left in z]
    projected_force = matvec(z, case["DIRECTION"][:gauge])
    projected_control = matvec(z, case["PROJECTION"][:gauge])
    sigma_min, sigma_max, u, v = singular(reduced)
    border = [[x/sigma_max for x in row]+[-f/norm(projected_force)] for row, f in zip(reduced, projected_force, strict=True)]
    border.append(unit(projected_control) + [0.])
    border_min, border_max, _, _ = singular(border)
    summary = {"case": case["name"], "force_replay_gap_MPa": replay_force_gap,
               "projected_force_control_singular_ratio": sigma_min/sigma_max,
               "projected_force_control_sigma_min": sigma_min,
               "scaled_border_singular_ratio": border_min/border_max,
               "left_load_projection": dot(u, unit(projected_force)) if u else None,
               "right_control_projection": dot(v, unit(projected_control)),
               "failed_probes": case["failed"], "one_sided": []}
    if "TANGENT" in case:
        with_lambda = case["TANGENT"]
        t, slope = with_lambda[:-1], with_lambda[-1]
        assert isclose(slope, baseline["slope"], abs_tol=1e-6, rel_tol=2e-8)
        assert abs(dot(t, case["PROJECTION"])-1) < 5e-10
        assert max(abs(a-slope*b) for a, b in zip(matvec(k, t), case["DIRECTION"], strict=True)) < 1e-5
        normalization = max(map(abs, t[:gauge]))
        local_tangent = [x/normalization for x in t]
        predicted = matvec(z, matvec(k, local_tangent)[:gauge])
        summary["slope"] = slope
        for h, residual in case["fd"]:
            difference = [(observed-reference)/h for observed, reference in zip(residual[:gauge], case["BASE"][:gauge], strict=True)]
            force_direction = matvec(z, difference)
            error = [a-b for a, b in zip(force_direction, predicted, strict=True)]
            summary["one_sided"].append({"signed_step": h, "difference_norm": norm(force_direction),
                                         "projected_action_error": norm(error),
                                         "critical_left_action_error": dot(u, error) if u else None})
    return summary


def inputs(fixture):
    assert all(digest(HERE / path) == expected for path, expected in fixture["inputs"].items())
    assert digest(REPO / fixture["workbook"]) == fixture["source_workbook_sha256"]
    assert digest(HERE / fixture["workbook"]) == fixture["source_workbook_sha256"]
    for path, expected in fixture["production"].items():
        raw = check_output(["git", "show", f"{fixture['source_revision']}:{path}"], cwd=REPO)
        assert sha256(raw).hexdigest().upper() == expected


def main():
    arg = argparse.ArgumentParser(description=__doc__)
    arg.add_argument("--inputs", action="store_true")
    args = arg.parse_args()
    fixture = obj("Fixture.json")
    inputs(fixture)
    if args.inputs:
        print("INPUTS OK", digest(HERE / "Fixture.json"))
        return
    raw = HERE / "Native/HardRank.csv"
    report = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_RANK: passed=1; failed=0" in report
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in report
    compiled = obj("docs/regression/CodeUpdate.json")
    compiler_closed = obj("CompileClosure.json")
    assert compiled["Compiled"] and compiled["ProductionSHA256"] == fixture["source_workbook_sha256"]
    assert compiler_closed["State"] == "Absent"
    owner = obj("Native/HardShear.txt.Ownership.json")
    receipt = obj("Native/HardShear.txt.ProcessClosure.json")
    final = receipt["Closure"]["FinalState"]
    assert receipt["Passed"] and final["State"] == "Absent"
    assert owner["SourceSHA256"] == compiled["WorkbookSHA256"]
    assert owner["PID"] == final["PID"] and owner["StartTicksUTC"] == final["StartTicksUTC"]
    cases = parse(raw)
    expected = obj("Expected.json")
    assert set(cases) == set(expected["fields"])
    result = {"trace_sha256": digest(raw), "cases": [study(case, expected["fields"][name], expected["projection"])
                                                   for name, case in cases.items()],
              "physical_or_global_limit_certified": False,
              "rank_between_sampled_fields": "open"}
    output = HERE / "Native/Verification.json"
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("HARDSHEAR TANGENTS", digest(output))


if __name__ == "__main__":
    main()
