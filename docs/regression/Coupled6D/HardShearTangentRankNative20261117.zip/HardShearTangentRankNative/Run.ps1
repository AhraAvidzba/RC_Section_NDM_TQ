# Проверяет уточнённые плечи в изолированной копии установленной книги.
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../..')).Path
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$report='Native/HardShear.txt'
Push-Location -LiteralPath $root
try {
    python -B -X utf8 'Verify.py' --inputs
    if ($LASTEXITCODE) {throw 'Входы проверки HardShear не подтверждены.'}
    $data=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    if ((Get-FileHash -LiteralPath (Join-Path $repo $data.workbook)).Hash -cne $data.source_workbook_sha256) {throw 'Изменилась установленная книга.'}
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Превышена длина пути фикстуры Excel.'
    }
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    if ((Test-Path -LiteralPath 'Compile.log') -or (Test-Path -LiteralPath $report)) {throw 'Оператор уже начал проверку.'}
    if ((Get-FileHash -LiteralPath $draft).Hash -cne $data.source_workbook_sha256) {throw 'Неверная изолированная книга.'}
    Assert-IsolatedOfficeReady 'CompileHardShearRank'
    & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft `
        -ModuleNames @('CCoupledDeformationContinuation','CCoupledNewtonSolver','modTestCoupledElasticState') | Tee-Object -FilePath 'Compile.log'
    Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    Assert-IsolatedOfficeReady 'RunHardShearRank'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $draft -ReportPath $report -Macro 'modTestCoupledElasticState.RunTestHardShearRank' `
        -Mode No -TimeoutSeconds $data.watchdog_seconds -FailFast -VerifyResultsReopen
    $nativeExit=$LASTEXITCODE
    if (Test-Path -LiteralPath $report) {
        $origin=@(Get-Content -LiteralPath $report -Encoding utf8 | Where-Object {$_ -like 'FIXTURE: *'})
        if ($origin.Count -eq 1) {
            $folder=Split-Path -Parent $origin[0].Substring('FIXTURE: '.Length)
            if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Нативная фикстура за рабочим каталогом.'}
            $trace=Join-Path $folder 'HardRank.csv'
            if (Test-Path -LiteralPath $trace) {Copy-Item -LiteralPath $trace -Destination 'Native/HardRank.csv'}
        }
    }
    if ($nativeExit) {throw "Нативная проверка HardShear завершилась с кодом $nativeExit."}
    python -B -X utf8 'Verify.py'
    if ($LASTEXITCODE) {throw 'Независимая сверка плеч не пройдена.'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
