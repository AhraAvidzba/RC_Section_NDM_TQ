"""Сводка с оценкой масштаба перехода по двум ближайшим положительным пробам."""

from Verify import dot, matvec, norm, null_basis


def summarize(cases, report):
    peaks = ("Stock-2", "Short4-4")
    other = {entry["case"] for entry in report["cases"]} - set(peaks)
    limits = {}
    for case in report["cases"]:
        assert not case["failed_probes"] and len(case["one_sided"]) == 8
        minus, plus = case["one_sided"][-2:]
        assert (minus["signed_step"], plus["signed_step"]) == (-6.25e-10, 6.25e-10)
        limits[case["case"]] = {"minus_action_relative_gap": minus["projected_action_error"]/minus["difference_norm"],
                                "plus_action_relative_gap": plus["projected_action_error"]/minus["difference_norm"]}
    transitions = {}
    for name in peaks:
        assert limits[name]["minus_action_relative_gap"] < 2e-5 and limits[name]["plus_action_relative_gap"] > 120.
        case = cases[name]
        k = case["matrix"]
        z = null_basis([row[:56] for row in k[56:]])
        tangent = case["TANGENT"][:-1]
        amplitude = max(map(abs, tangent[:56]))
        predicted = matvec(z, matvec(k, [x/amplitude for x in tangent])[:56])
        small = []
        for h, values in case["fd"]:
            if h > 0.:
                achieved = matvec(z, [r-base for r, base in zip(values[:56], case["BASE"][:56], strict=True)])
                small.append((h, [a-h*p for a, p in zip(achieved, predicted, strict=True)]))
        estimates = []
        for first, later in zip(small[1:], small[2:]):
            h1, y1 = first
            h2, y2 = later
            direction = [(x-y)/(h1-h2) for x, y in zip(y1, y2, strict=True)]
            offset = [x-h1*t for x, t in zip(y1, direction, strict=True)]
            switch = -dot(direction, offset)/dot(direction, direction)
            shape_error = norm([x+switch*t for x, t in zip(offset, direction, strict=True)])/norm(offset)
            estimates.append({"signed_positive_steps": [h1, h2],
                              "linear_extrapolation_only": switch, "relative_vector_misfit": shape_error})
        transitions[name] = estimates
    assert all(max(limits[name].values()) < 2e-4 for name in other)
    minima = [entry["projected_force_control_sigma_min"] for entry in report["cases"]]
    normalized = [entry["projected_force_control_singular_ratio"] for entry in report["cases"]]
    bordered = [entry["scaled_border_singular_ratio"] for entry in report["cases"]]
    return {"smallest_projected_singular_values_MPa": [min(minima), max(minima)],
            "projected_sigma_min_over_max": [min(normalized), max(normalized)],
            "scaled_bordered_sigma_min_over_max": [min(bordered), max(bordered)],
            "smallest_step_directional_comparison": limits,
            "unconfirmed_linear_extrapolations_near_center": transitions,
            "material_transition_bracket_or_right_jacobian_at_same_state": "open",
            "physical_or_global_limit_certified": False}
