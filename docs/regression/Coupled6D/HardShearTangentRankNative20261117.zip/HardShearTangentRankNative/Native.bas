' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подготавливает штатный HardShear, чтобы снять касательные с готовых операторов и материалов.
Public Function RunTestHardShearRank() As String
    On Error GoTo Failed
    Dim book As Object: Set book = ThisWorkbook
    Dim loads As Variant: loads = TestHardShearLoads()
    Dim units As CUnitSystem: Set units = TestPrepareCoupledTimingBook(book, "Both", "Excel", loads)
    HardRankRequestedTest = True: HardRankFinishedTest = False
    WriteHardRankRowTest "HARDSHEAR-RANK;1"
    Dim started As Double: started = Timer
    Dim message As String: message = RunSectionCalculationForWorkbook(book)
    Dim elapsed As Double: elapsed = Timer - started
    If elapsed < 0# Then elapsed = elapsed + 86400#
    HardRankRequestedTest = False
    RunTestHardShearRank = "RANK_TIME: " & CStr(elapsed) & vbCrLf & "RANK_MESSAGE: " & Replace(message, vbCrLf, " | ")
    If HardRankFinishedTest Then
        RunTestHardShearRank = RunTestHardShearRank & vbCrLf & "TOTAL_HARD_SHEAR_RANK: passed=1; failed=0"
    Else
        RunTestHardShearRank = RunTestHardShearRank & vbCrLf & "TOTAL_HARD_SHEAR_RANK: passed=0; failed=1"
    End If
    Exit Function
Failed:
    HardRankRequestedTest = False
    RunTestHardShearRank = "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Восстанавливает общие H1–H7 и отдельно записанные приращения каждого прохода.
Public Function ReplayHardRankTest(ByVal solver As CCoupledNewtonSolver, ByRef offset() As Double, _
        ByRef direction() As Double) As Boolean
    Dim prefix As New Collection, history As Collection, data As Collection, table As Collection
    Dim packed As Variant, inputs As Variant, field() As Double, projection() As Double
    HardRankInputTest prefix, table, projection
    For Each packed In table
        Set data = packed
        Set history = New Collection
        Dim item As Variant
        For Each item In prefix: history.Add item: Next item
        For Each item In data
            inputs = Split(CStr(item), ";")
            HardRankUnpackTest CStr(inputs(3)), field
            If Len(inputs(0)) > 0 Then
                If Not solver.RecordHardRankFieldTest(CStr(inputs(0)), history, field, projection, offset, direction, _
                        HardRankValueTest(CStr(inputs(1))), HardRankValueTest(CStr(inputs(2)))) Then _
                    Err.Raise 5, "ReplayHardRankTest", "Не удалось повторить поле " & CStr(inputs(0))
            End If
            history.Add field
        Next item
    Next packed
    ReplayHardRankTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает диагностические данные только рядом с нативной копией.
Public Sub WriteHardRankRowTest(ByVal row As String)
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, "WriteHardRankRowTest", "Запись касательной доступна в изолированной книге."
    Dim channel As Integer: channel = FreeFile
    Open ThisWorkbook.Path & "\HardRank.csv" For Append As #channel
    Print #channel, row
    Close #channel
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет в строке полную двоичную запись Double.
Public Function HardRankBitsTest(ByVal value As Double) As String
    Dim number As THardRankNumberTest, words As THardRankWordsTest
    number.Value = value: LSet words = number
    HardRankBitsTest = Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает Double из двух 32-разрядных слов.
Private Function HardRankValueTest(ByVal token As String) As Double
    Dim number As THardRankNumberTest, words As THardRankWordsTest
    words.High = CLng("&H" & Left$(token, 8)): words.Low = CLng("&H" & Right$(token, 8))
    LSet number = words
    HardRankValueTest = number.Value
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Декодирует 60 координат из строки в точном порядке.
Private Sub HardRankUnpackTest(ByVal packed As String, ByRef values() As Double)
    If Len(packed) <> 960 Then Err.Raise 5, "HardRankUnpackTest", "Неверное число координат."
    ReDim values(1 To 60)
    Dim i As Long
    For i = 1 To 60: values(i) = HardRankValueTest(Mid$(packed, 16 * i - 15, 16)): Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сериализует одномерный массив без округления.
Public Function HardRankVectorTest(ByRef values() As Double) As String
    Dim i As Long
    For i = LBound(values) To UBound(values)
        If i > LBound(values) Then HardRankVectorTest = HardRankVectorTest & ";"
        HardRankVectorTest = HardRankVectorTest & HardRankBitsTest(values(i))
    Next i
End Function
