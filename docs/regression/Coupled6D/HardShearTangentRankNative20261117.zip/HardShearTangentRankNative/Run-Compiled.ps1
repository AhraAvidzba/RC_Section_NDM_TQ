﻿# Запускает уже проверенную компилятором копию HardShear.
param(
    [Parameter(Mandatory)]
    [switch]$CompiledOnly,
    [switch]$VerifyInputsOnly
)

$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$report='Native/HardShear.txt'
$compiledSha='47C339546C96A56292C1E059C9365C5938AC61CC5F3ADDC9A41F06DCDAA1B492'
$compileFiles=[ordered]@{
    'Compile.log'='89946B5637690AA322CC51B0E6841079711A60BA6445FC3B2177E81FED9BF2C5'
    'CompileClosure.json'='7850B19B58C5D850EF5D51218BF097E728322FBB78C74F30A5C25B95FFFB3DD8'
    'docs/regression/CodeUpdate.json'='C0A0B2139A21010428483E045780292083FDF7BA73EAB191C5A446AD45282D01'
}

Push-Location -LiteralPath $root
try {
    if (!$CompiledOnly) {throw 'Укажите CompiledOnly для запуска из уже скомпилированной книги.'}
    python -B -X utf8 'Verify.py' --inputs
    if ($LASTEXITCODE) {throw 'Входы проверки HardShear не подтверждены.'}
    $fixture=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    foreach ($file in $compileFiles.Keys) {
        if ((Get-FileHash -LiteralPath $file).Hash -cne $compileFiles[$file]) {throw "Изменился протокол компиляции $file."}
    }
    $info=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closed=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$info.Compiled -or $info.ProductionChanged -or $info.ProductionSHA256 -cne $fixture.source_workbook_sha256 -or
        $info.Workbook -ine (Resolve-Path -LiteralPath $draft).Path -or $info.WorkbookSHA256 -cne $compiledSha -or
        (Get-FileHash -LiteralPath $draft).Hash -cne $compiledSha -or $info.RetiredModules.Count -or
        $info.EntryPointNames.Count -or $info.TraceGeometry -or
        ($info.Modules -join ',') -cne 'CCoupledDeformationContinuation,CCoupledNewtonSolver,modTestCoupledElasticState') {
        throw 'Хеш и состав скомпилированной книги должны совпадать с протоколом.'
    }
    $records=@(Get-Content -LiteralPath 'Compile.log' -Encoding utf8)
    $owner=@($records | Where-Object {$_ -ceq "OWNED_EXCEL: id=$($closed.PID); utcStartTicks=$($closed.StartTicksUTC)"})
    if ($closed.State -cne 'Absent' -or $owner.Count -ne 1 -or
        $records[-1] -cne 'PRIVATE_CODE_READY: modules=3; production unchanged=True') {
        throw 'Нет подтверждения закрытия Excel после компиляции.'
    }
    if (Get-Process -Id $closed.PID -ErrorAction SilentlyContinue) {throw "PID $($closed.PID) ещё занят."}
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Превышена длина пути фикстуры Excel.'
    }
    if (@(Get-ChildItem -LiteralPath 'Native' -Force).Count -or
        @(Get-ChildItem -LiteralPath 'Temp' -Force -Filter 'RC_NDM_ModeSuite_*').Count) {
        throw 'Есть данные уже запущенной нативной проверки.'
    }
    Write-Output "COMPILED_INPUTS_OK: sha256=$compiledSha; compilerPID=$($closed.PID); state=Absent"
    if ($VerifyInputsOnly) {return}
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    Assert-IsolatedOfficeReady 'RunHardShearRankCompiledOnly'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $draft -ReportPath $report -Macro 'modTestCoupledElasticState.RunTestHardShearRank' `
        -Mode No -TimeoutSeconds $fixture.watchdog_seconds -FailFast -VerifyResultsReopen
    $nativeExit=$LASTEXITCODE
    if (Test-Path -LiteralPath $report) {
        $origin=@(Get-Content -LiteralPath $report -Encoding utf8 | Where-Object {$_ -like 'FIXTURE: *'})
        if ($origin.Count -eq 1) {
            $folder=Split-Path -Parent $origin[0].Substring('FIXTURE: '.Length)
            if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Нативная фикстура за рабочим каталогом.'}
            $trace=Join-Path $folder 'HardRank.csv'
            if (Test-Path -LiteralPath $trace) {Copy-Item -LiteralPath $trace -Destination 'Native/HardRank.csv'}
        }
    }
    if ($nativeExit) {throw "Нативная проверка HardShear завершилась с кодом $nativeExit."}
    python -B -X utf8 'Verify.py'
    if ($LASTEXITCODE) {throw 'Независимая сверка касательных не пройдена.'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
