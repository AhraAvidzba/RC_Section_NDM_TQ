"""Подготавливает нативное чтение касательных в шести сохранённых полях."""

from hashlib import sha256
import json
from pathlib import Path
from struct import pack
from subprocess import check_output

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
FOLD = HERE.parent / "hs-fold"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
CONT = "src/Solver/CCoupledDeformationContinuation.cls"
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
TEST = "tests/modTestCoupledElasticState.bas"
VERIFY_SHA = "BB2D2FA462BB238E1EF28D69B87CD4A408B064B7EF14B57832B2215DB859FB7F"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, raw):
    dest = HERE / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        assert dest.read_bytes() == raw, dest
    else:
        dest.write_bytes(raw)
    return digest(raw)


def vba(text):
    assert max(map(len, text.splitlines())) <= 1023
    return text.rstrip().replace("\n", "\r\n").encode() + b"\r\n"


def replace(src, old, new):
    assert src.count(old) == 1, old
    return src.replace(old, new)


def bits(number):
    return pack(">d", number).hex().upper()


def embedded_fixture(record):
    arms = record["arms"][:2]
    stock, fine = arms
    assert [arm["id"][0] for arm in arms] == ["Stock", "Short4"]
    assert stock["prefix_bits"] == fine["prefix_bits"] and stock["guide"] == fine["guide"]
    source = [
        "' -------------------- ДЛЯ ТЕСТОВ --------------------",
        "' Точные двоичные поля из сверенного нативного архива HardShear.",
        "Private Sub HardRankInputTest(ByRef prefix As Collection, ByRef table As Collection, ByRef projection() As Double)",
        "    Set table = New Collection",
        "    Dim field() As Double, rows As Collection",
        f'    HardRankUnpackTest "{"".join(stock["guide"])}", projection',
    ]
    for saved in stock["prefix_bits"]:
        source.extend([f'    HardRankUnpackTest "{"".join(saved)}", field', "    prefix.Add field"])
    expected = {}
    for arm, indexes in zip(arms, ({1, 2, 3}, {3, 4, 5}), strict=True):
        source.append("    Set rows = New Collection")
        for p in arm["points"][:max(indexes)]:
            assert p["branch_consistent_mode"]
            name = arm["id"][0] + "-" + str(p["order"]) if p["order"] in indexes else ""
            source.append(f'    rows.Add "{name};{bits(p["requested"])};{bits(p["lambda"])};{"".join(p["field_bits"])}"')
            if name:
                expected[name] = {**p, "accepted_before": 7 + p["order"] - 1}
        source.append("    table.Add rows")
    source.append("End Sub")
    return "\n".join(source), {"fields": expected, "projection": stock["guide"]}


def main():
    original = json.loads((FOLD / "Fixture.json").read_bytes())
    book_hash = original["source_workbook_sha256"]
    book_copy = (REPO / BOOK).read_bytes()
    assert digest(book_copy) == book_hash
    save(BOOK, book_copy)
    save("docs/regression/Diagnostic.xlsm", book_copy)
    for directory in ("Temp", "Native"):
        (HERE / directory).mkdir(exist_ok=True)
    report = (FOLD / "Native/Verification.json").read_bytes()
    assert digest(report) == VERIFY_SHA
    embedded, expected = embedded_fixture(json.loads(report))
    inputs = {"Expected.json": save("Expected.json", (json.dumps(expected, indent=2) + "\n").encode())}
    sources = {}
    for name in (CONT, NEWTON, TEST):
        raw = check_output(["git", "show", f"{original['source_revision']}:{name}"], cwd=REPO)
        assert digest(raw) == original["production"][name]
        sources[name] = raw.decode("utf-8-sig").replace("\r\n", "\n")
    src = replace(sources[CONT], "    mDesignHistoryIndex = InitialDesignHistoryIndex", """    If HardRankRequestedTest Then
        HardRankFinishedTest = ReplayHardRankTest(mSolver, mOffset, mDirection)
        StopSearch "Диагностическая остановка после чтения касательных HardShear."
        Exit Sub
    End If
    mDesignHistoryIndex = InitialDesignHistoryIndex""")
    inputs[CONT] = save(CONT, vba(src))
    inputs[NEWTON] = save(NEWTON, vba(sources[NEWTON] + "\n" + (HERE / "Newton.bas").read_text(encoding="utf-8")))
    src = replace(sources[TEST], "Option Explicit", """Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Флаги включаются отдельной изолированной нативной проверкой.
Public HardRankRequestedTest As Boolean, HardRankFinishedTest As Boolean

Private Type THardRankNumberTest
    Value As Double
End Type

Private Type THardRankWordsTest
    Low As Long
    High As Long
End Type""")
    inputs[TEST] = save(TEST, vba(src + "\n" + (HERE / "Native.bas").read_text(encoding="utf-8") + "\n" + embedded))
    for name, expected_hash in original["inputs"].items():
        if not (name.startswith("tools/build_workbook/") or name == "Guard-IsolatedOffice.ps1"):
            continue
        raw = (FOLD / name).read_bytes()
        assert digest(raw) == expected_hash
        inputs[name] = save(name, raw)
    runner = (FOLD / "Run.ps1").read_text(encoding="utf-8")
    runner = (runner.replace("HardFold.csv", "HardRank.csv").replace("HardShearFold", "HardShearRank")
              .replace("150", "120"))
    inputs["Run.ps1"] = save("Run.ps1", runner.encode("utf-8"))
    for name in ("Stage.py", "Verify.py", "Native.bas", "Newton.bas"):
        inputs[name] = digest((HERE / name).read_bytes())
    fixture = {"source_workbook_sha256": book_hash, "source_revision": original["source_revision"],
               "workbook": BOOK, "source_shoulder_report_sha256": VERIFY_SHA,
               "production": original["production"], "inputs": inputs, "watchdog_seconds": 120}
    print(save("Fixture.json", (json.dumps(fixture, indent=2) + "\n").encode()))


if __name__ == "__main__":
    main()
