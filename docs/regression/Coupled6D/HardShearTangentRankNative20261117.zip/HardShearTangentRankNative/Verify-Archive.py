"""Повторно вычисляет приведённые сингулярные числа из замороженных данных."""

import argparse
from math import isclose
from pathlib import Path
import re

from RankSummary import summarize
from Verify import digest, obj, parse, study

HERE = Path(__file__).resolve().parent


def compare(actual, expected):
    if isinstance(expected, float):
        assert isclose(actual, expected, rel_tol=2e-10, abs_tol=2e-14)
    elif isinstance(expected, dict):
        assert set(actual) == set(expected)
        for key, value in expected.items():
            compare(actual[key], value)
    elif isinstance(expected, list):
        for found, value in zip(actual, expected, strict=True):
            compare(found, value)
    else:
        assert actual == expected


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--saved-workbook", type=Path)
    args = cli.parse_args()
    manifest = obj("SHA256SUMS.json")
    recorded_files = {file.relative_to(HERE).as_posix() for file in HERE.rglob("*")
                      if file.is_file() and file.name != "SHA256SUMS.json"}
    assert recorded_files == set(manifest)
    assert all(digest(HERE / name) == expected for name, expected in manifest.items())
    fixture = obj("Fixture.json")
    assert all(manifest[name] == expected for name, expected in fixture["inputs"].items())
    assert all(manifest[f"Baseline/{name}"] == expected for name, expected in fixture["production"].items())
    assert manifest["Inputs/NativeShoulderVerification.json"] == fixture["source_shoulder_report_sha256"]
    source = obj("Inputs/NativeShoulderVerification.json")
    assert source["source_workbook_sha256"] == fixture["source_workbook_sha256"]
    expected = obj("Expected.json")
    assert expected["projection"] == source["arms"][0]["guide"] == source["arms"][1]["guide"]
    assert source["arms"][0]["prefix_bits"] == source["arms"][1]["prefix_bits"]
    for arm, picks in zip(source["arms"][:2], ((1, 2, 3), (3, 4, 5)), strict=True):
        for i in picks:
            name = f"{arm['id'][0]}-{i}"
            assert expected["fields"][name] == {**arm["points"][i-1], "accepted_before": 7+i-1}
    code = obj("docs/regression/CodeUpdate.json")
    compiler = obj("CompileClosure.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    receipt = obj("Native/HardShear.txt.ProcessClosure.json")
    final = receipt["Closure"]["FinalState"]
    assert code["Compiled"] and not code["ProductionChanged"] and code["ProductionSHA256"] == fixture["source_workbook_sha256"]
    assert code["Modules"] == ["CCoupledDeformationContinuation", "CCoupledNewtonSolver", "modTestCoupledElasticState"]
    assert compiler["State"] == "Absent" and f"OWNED_EXCEL: id={compiler['PID']}; utcStartTicks={compiler['StartTicksUTC']}" in (
        HERE / "Compile.log").read_text(encoding="utf-8-sig")
    assert owner["SourceSHA256"] == code["WorkbookSHA256"]
    assert receipt["Passed"] and receipt["ChildExitCode"] == 0 and final["State"] == "Absent"
    assert (owner["PID"], owner["StartTicksUTC"]) == (final["PID"], final["StartTicksUTC"])
    report = obj("Native/Verification.json")
    assert report["trace_sha256"] == manifest["Native/HardRank.csv"]
    cases = parse(HERE / "Native/HardRank.csv")
    assert set(cases) == set(expected["fields"])
    metrics = [study(case, expected["fields"][name], expected["projection"]) for name, case in cases.items()]
    compare(metrics, report["cases"])
    audit = obj("Audit.json")
    for key, value in summarize(cases, report).items():
        compare(audit[key], value)
    assert audit["native_log_sha256"] == manifest["Native/HardShear.txt"]
    assert audit["report_sha256"] == manifest["Native/Verification.json"]
    log = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_RANK: passed=1; failed=0" in log
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    assert f"RESULTS_SAVE_REOPEN: before={audit['saved_results_reopen_sha256']}; after={audit['saved_results_reopen_sha256']}; equal=True" in log
    elapsed = re.search(r"^RANK_TIME: ([0-9.,]+)$", log, re.M)
    assert elapsed and float(elapsed[1].replace(",", ".")) == audit["native_seconds"]
    if args.saved_workbook:
        assert digest(args.saved_workbook) == audit["saved_workbook_sha256"]
    print("HARDSHEAR RANK PORTABLE VERIFIED")
    print("Six matrices, 48 one-sided residual probes, saved equilibrium replay confirmed")


if __name__ == "__main__":
    main()
