' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает блочную касательную в заданном поле и односторонние невязки.
' Вызывается только на диагностической остановке после восстановления истории.
Friend Function RecordHardRankFieldTest(ByVal caseName As String, ByRef history As Collection, _
        ByRef field() As Double, ByRef projection() As Double, ByRef offset() As Double, _
        ByRef direction() As Double, ByVal target As Double, ByVal multiplier As Double) As Boolean
    If Not mUseSpatialHistory Or mDegreeCount <> 60 Then Exit Function
    If Not ReplayAcceptedFields(history, history.Count) Then Exit Function
    mBaseLoad = offset: mLoadDirection = direction
    mSection.LoadEquations offset(1), offset(2), offset(3), offset(4), offset(5), offset(6), mBaseEquations
    mSection.LoadEquations direction(1), direction(2), direction(3), direction(4), direction(5), direction(6), mDirectionEquations
    ReDim mExternal(1 To mDegreeCount)
    mControlActive = True: mConsistentControl = True
    mControlProjection = projection: mTargetControl = target
    Dim load(1 To COMPONENT_COUNT) As Double
    SetControlledLoad multiplier, load
    If Not Evaluate(field, True, True, recordTrial:=False, consistentBranch:=True) Then Exit Function
    WriteHardRankRowTest "BEGIN;" & caseName & ";" & CStr(history.Count) & ";" & CStr(mGaugeStart) & ";" & _
        HardRankBitsTest(mReferenceModulus) & ";" & HardRankBitsTest(multiplier) & ";" & HardRankBitsTest(target)
    WriteHardRankRowTest "FIELD;" & HardRankVectorTest(field)
    WriteHardRankRowTest "FORCE;" & HardRankVectorTest(load)
    WriteHardRankRowTest "MEASURED;" & HardRankVectorTest(mTrialResultants)
    WriteHardRankRowTest "BASE;" & HardRankVectorTest(mResidual)
    WriteHardRankRowTest "DIRECTION;" & HardRankVectorTest(mDirectionEquations)
    WriteHardRankRowTest "PROJECTION;" & HardRankVectorTest(mControlProjection)
    Dim rowValues() As Double: ReDim rowValues(1 To mDegreeCount)
    Dim rowIndex As Long, column As Long
    For rowIndex = 1 To mDegreeCount
        For column = 1 To mDegreeCount: rowValues(column) = mMatrix(column, rowIndex): Next column
        WriteHardRankRowTest "K;" & CStr(rowIndex) & ";" & HardRankVectorTest(rowValues)
    Next rowIndex
    Dim size As Long: size = mDegreeCount + 1
    Dim bordered() As Double, tangent() As Double
    BuildControlledMatrix bordered, size
    ReDim tangent(1 To size): tangent(size) = mReferenceModulus
    Dim system As New CCoupledLinearSystem
    If system.Solve(bordered, tangent, size) Then
        WriteHardRankRowTest "TANGENT;" & HardRankVectorTest(tangent)
        RecordHardRankDifferencesTest field, tangent
    Else
        WriteHardRankRowTest "TANGENT-FAIL"
    End If
    WriteHardRankRowTest "END;" & caseName
    RecordHardRankFieldTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Обе стороны проверяются от одного и того же последнего принятого буфера.
' Нагрузки фиксированы, поэтому разность невязок даёт действие K, без столбца нагрузки.
Private Sub RecordHardRankDifferencesTest(ByRef field() As Double, ByRef tangent() As Double)
    Dim i As Long, normalization As Double
    For i = 1 To mGaugeStart - 1: normalization = GeomMax(normalization, Abs(tangent(i))): Next i
    If normalization = 0# Then
        WriteHardRankRowTest "FD-FAIL;zero"
        Exit Sub
    End If
    Dim probe() As Double: ReDim probe(1 To mDegreeCount)
    Dim signedStep As Double, magnitude As Double, side As Long, level As Long
    magnitude = 4E-8
    For level = 1 To 4
        For side = -1 To 1 Step 2
            signedStep = side * magnitude
            For i = 1 To mDegreeCount: probe(i) = field(i) + signedStep * tangent(i) / normalization: Next i
            If Evaluate(probe, False, recordTrial:=False) Then
                WriteHardRankRowTest "FD;" & HardRankBitsTest(signedStep) & ";" & HardRankVectorTest(mResidual)
            Else
                WriteHardRankRowTest "FD-FAIL;" & HardRankBitsTest(signedStep) & ";" & CStr(mMaterialPoint) & ";" & CStr(mLastFailedSide)
            End If
        Next side
        magnitude = magnitude * 0.25
    Next level
End Sub
