"""Freeze single-parameter tensile sensitivity cases in an isolated NDM workbook."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import runpy


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
STORAGE = Path("D:/CodexScratch/RC_Section_NDM_TQ")
PREVIOUS = STORAGE / "MVTGauss25Mixed"
MACRO = "tests/modTestMVT2GaussSpan.bas"
MATERIAL = "src/Materials/CCoupledConcreteResponse.cls"
CASES = ("MVTGaussMixed", "MVTEnergy2", "MVTEnergyReference", "MVTDamage25")


def digest(raw):
    return sha256(raw).hexdigest().upper()


def normalized(raw):
    return raw.decode("utf-8-sig").replace("\r\n", "\n")


def vbe(source):
    assert max(map(len, source.splitlines())) < 1024
    return source.replace("\n", "\r\n").encode("utf-8-sig")


def freeze():
    manifest = json.loads((PREVIOUS / "Preparation.json").read_bytes())
    packed = {name: (PREVIOUS / name).read_bytes() for name in manifest["inputs"]}
    assert {name: digest(raw) for name, raw in packed.items()} == manifest["inputs"]
    assert manifest["inputs"][MACRO] == "BEA78E82945EC4683E75433AAEEA10899B5439E4B36FCAE435FC7BEAA62B1541"
    once = runpy.run_path(str(HERE.parent / "Stage.py"))["replace_one"]
    src = normalized(packed[MACRO])
    src = once(src, '        Case "MVTGaussMixed"\n            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True)',
               '        Case "MVTGaussMixed"\n            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True)\n'
               '        Case "MVTEnergy2"\n            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True, 2#)\n'
               '        Case "MVTEnergyReference"\n'
               '            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True, 125# / 18.621285527678477)\n'
               '        Case "MVTDamage25"\n            completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True, 1#, 0.25)')
    src = once(src, '        Optional ByVal followMixed As Boolean = False) As Boolean',
               '        Optional ByVal followMixed As Boolean = False, Optional ByVal energyFactor As Double = 1#, _\n'
               '        Optional ByVal tensileDamage As Double = 0.5) As Boolean')
    src = once(src, '    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt',
               '    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt\n'
               '    gt = gt * energyFactor \' Изменяется только удельная энергия растянутой ветви.\n'
               '    AddExperimentTraceTest report, tracePath, "MVT_PARAMETERS;" & ExperimentNumberTest(energyFactor) & _\n'
               '        ";" & ExperimentNumberTest(tensileDamage)')
    src = once(src, '    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, FT, PEAK, gt, gc, True',
               '    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, FT, PEAK, gt, gc, True, tensileDamage')
    src = once(src, '        If branch.SavedFieldCount <> 8 Or Abs(1000# * twist - 0.00369107609535158) > 0.00000000000001 Then _\n'
               '            Err.Raise 5, , "История чистого кручения перед совместной пробой отличается."\n'
               '        AddExperimentTraceTest report, tracePath, "MVT_PRELOAD_END;8;10.51"',
               '        AddExperimentTraceTest report, tracePath, "MVT_PRELOAD_END;" & CStr(branch.SavedFieldCount) & ";10.51"')
    src = once(src, '        ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean)',
               '        ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean, ByVal tensileDamage As Double)')
    assert src.count('peakStrain, gt, gc, LOCALIZATION_LENGTH') == 3
    src = src.replace('peakStrain, gt, gc, LOCALIZATION_LENGTH',
                      'peakStrain, gt, gc, LOCALIZATION_LENGTH, tensileDamageAtHalf:=tensileDamage')
    src.encode("cp1251")
    packed[MACRO] = vbe(src)

    material_raw = (REPO / MATERIAL).read_bytes()
    assert digest(material_raw) == "92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C"
    source = normalized(material_raw)
    source = once(source, '        Optional ByVal eccentricity As Double = 0.1)',
                  '        Optional ByVal eccentricity As Double = 0.1, Optional ByVal tensileDamageAtHalf As Double = 0.5)')
    source = once(source, '    mTension.Initialize ft, ft, 0#, gt, localizationLength, 0.5, halfTension',
                  '    mTension.Initialize ft, ft, 0#, gt, localizationLength, tensileDamageAtHalf, halfTension')
    packed[MATERIAL] = vbe(source)

    run = normalized(packed["Run-Native.ps1"])
    choices = ",".join(f"'{case}'" for case in CASES)
    run = once(run, "[ValidateSet('MVTGaussMixed')]", f"[ValidateSet({choices})]")
    run = once(run, "'CCoupledElasticState','modTestMVT2GaussSpan')",
               "'CCoupledElasticState','modTestMVT2GaussSpan','CCoupledConcreteResponse')")
    run = once(run, "$timeout='285'", "$timeout='200'")
    run = once(run, "    python './Verify-Mixed.py'", "    python -B './Verify-NdmTension.py' --case $Case")
    packed["Run-Native.ps1"] = run.encode()
    mixed = normalized(packed["Verify-Mixed.py"])
    mixed = once(mixed, "def test_wire(raw, locked, base):", "def test_wire(raw, locked, base, marker=MARKER, case='MVTGaussMixed'):")
    mixed = once(mixed, '    assert lines[0] == MARKER and lines[-1].startswith(b"CASE_FINISHED;MVTGaussMixed;")',
                 '    assert lines[0] == marker and lines[-1].startswith(f"CASE_FINISHED;{case};".encode())')
    packed["Verify-Mixed.py"] = mixed.encode()
    packed["Verify-NdmTension.py"] = (HERE / "Verify-NdmTension.py").read_bytes()
    manifest["inputs"] = {name: digest(raw) for name, raw in sorted(packed.items())}
    manifest["stock_material_sha256"] = digest(material_raw)
    return manifest, packed


def main(root):
    manifest, files = freeze()
    if root is not None:
        root = root.resolve()
        scratch = STORAGE.resolve()
        assert root != scratch and root.is_relative_to(scratch)
        root.mkdir()
        (root / "Temp").mkdir()
        files["docs/regression/Diagnostic.xlsm"] = files["workbook/output/RC_Section_NDM.xlsm"]
        for name, raw in files.items():
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(raw)
        (root / "Preparation.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("PINNED", manifest["inputs"][MACRO], manifest["inputs"][MATERIAL], manifest["stock_material_sha256"])


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--stage", type=Path)
    main(parser.parse_args().stage)
