"""Verify fresh Gauss25 preload and signed right-window Qy continuation."""
from pathlib import Path
import json
import runpy

HERE = Path(__file__).resolve().parent
MARKER = b"MVT_PRELOAD_END;8;10.51"
GOALS = (5., 6.25, 7.5, 8.75, 10., 11.25, 11.5625, 11.875, 12.1875, 12.5, 12.8125,
         13.125, 13.4375, 13.75, 14.0625, 14.375, 14.6875, 15.)
T = 10510000.


def test_wire(raw, locked, base, marker=MARKER, case='MVTGaussMixed'):
    assert raw.startswith(locked), "Fresh pure-torsion native prefix differs"
    lines = raw[len(locked):].splitlines()
    assert lines[0] == marker and lines[-1].startswith(f"CASE_FINISHED;{case};".encode())
    assert lines[-1].split(b";")[2] in {b"True",b"False"}
    finished = lines[-1].split(b";")[2] == b"True"
    elapsed, = base["floats"](lines[-1].decode("ascii").split(";")[3:])
    pure_rows = [r.split(";") for r in locked.decode("cp1251").splitlines()]
    preload = base["verify_mvt"](pure_rows,"MVTGauss",True)
    preload_geom, = [r for r in pure_rows if r[0] == "MVT_GEOM"]
    ox,oy,area,scale = base["floats"](preload_geom[4:])
    samples = [base["floats"](r[2:]) for r in pure_rows if r[0] == "MVT_POINT"]
    points,directions = [p[:3] for p in samples], [p[3:] for p in samples]
    rows = [r.split(";") for r in b"\n".join(lines[1:-1]).decode("cp1251").splitlines()]
    states = base["keyed"]((r[1],base["floats"](r[2:])) for r in rows if r[0] == "MVT2_STATE")
    stress_rows = base["keyed"](((r[1],int(r[2])),base["floats"](r[3:])) for r in rows if r[0]=="MVT_SHEAR_STRESS")
    trials = [r for r in rows if r[0]=="MVT2_CUT_TRIAL"]
    stops = base["keyed"]((r[1],r[2:]) for r in rows if r[0]=="MVT2_CUT_DIRECT_STOP")
    retained = [base["floats"](r[1:])[0] for r in rows if r[0]=="MVT_SHEAR_RETAINED"]
    inserted = [(r[1],base["floats"](r[2:])) for r in rows if r[0]=="MVT2_CUT_INSERTED"]
    assert len(trials) <= 18
    assert len(trials) == 18 if finished else 1 <= len(trials) <= 18
    accepted_qn = 0.0
    corresponding = preload["stages"][-1]
    last_measured = corresponding["forces_N_Nmm"]
    successful = []
    failure = None

    def signed_check(qn, actual):
        target = (0., -330.*qn, 0., T, 0., qn)
        mtol = 5e-7 + 5e-7 * max(T/(area*scale), abs(target[1])/(area*scale), qn/area) + 5e-14
        base["compare_forces"](actual,target,mtol*area,mtol*area*scale)
        return mtol

    def reconstruct(phase):
        stress = []
        for k in range(1,46):
            raw_s = stress_rows.pop((phase,k))
            assert len(raw_s) == 7
            if k<=25:
                assert raw_s[-1] == 0.
                stress.append(raw_s[:6])
            else:
                stress.append(tuple(raw_s[-1]*d-s for d,s in zip(directions[k-1],raw_s[:6],strict=True)))
        return base["integrate"](points,stress,ox,oy)

    parsed_inserted = []
    for i,trial in enumerate(trials,1):
        phase = f"S{i}"
        requested = GOALS[i-1]*1000.
        assert trial[1] == phase and base["floats"](trial[2:5]) == (T, requested, -330.*requested)
        assert trial[5] in ("True","False")
        status,code = map(int,trial[6:8])
        for inserted_phase, details in inserted:
            if inserted_phase != phase:
                continue
            assert len(details) == 8 and 0.0 <= details[1] <= 5e-6
            num, native = details[0], details[2:]
            assert accepted_qn < num < requested and phase in stops
            signed_check(num,native)
            accepted_qn,last_measured = num,native
            parsed_inserted.append({"phase":phase,"Qy_kN":num/1000.,"resultants_N_Nmm":native})
        if trial[5] == "False":
            assert not finished and i == len(trials) and (status,code) in {(6,10),(6,11),(5,5),(5,6),(5,7)}
            assert len(retained) == 1 and retained[0]>0
            integrated = reconstruct("END")
            signed_check(accepted_qn,integrated)
            base["compare_forces"](integrated,last_measured,2e-7,2e-5)
            failure = {"requested_Qy_kN":requested/1000., "status":status, "code":code,
                       "last_accepted_Qy_kN":accepted_qn/1000., "last_accepted_twist_rad_per_m":retained[0],
                       "last_accepted_signed_resultants_N_Nmm":integrated}
            break
        assert (status,code)==(4,0)
        req,rea,n,mx,my,torque,qx,qy,eps,kx,ky,twist,gamma,sl,sh,nl,nh,dt,dc,pmin,pmax,rnorm = states.pop(phase)
        assert req == rea == GOALS[i-1] and requested > accepted_qn
        measured = (n*1e3,mx*1e6,my*1e6,torque*1e6,qx*1e3,qy*1e3)
        mtol = signed_check(requested,measured)
        assert 0 <= rnorm <= mtol and twist > 0.
        integrated = reconstruct(phase)
        base["compare_forces"](integrated,measured,2e-7,2e-5)
        signed_check(requested,integrated)
        successful.append({"Qy_kN":requested/1000.,"Mx_kNm":-330.*requested/1e6,"T_kNm":10.51,
                           "twist_rad_per_m":twist,"measured_resultants_N_Nmm":measured,
                           "independent_resultants_N_Nmm":integrated,"residual_MPa":rnorm,
                           "max_tensile_damage":dt,"max_compressive_damage":dc})
        accepted_qn,last_measured = requested,measured
    assert not stress_rows and not states
    assert len(parsed_inserted) == len(inserted)
    assert set(stops) <= {r[1] for r in trials}
    assert (finished and accepted_qn == 15000. and not retained) or (not finished and failure is not None)
    return {"reached_Qy15":finished,"cold_gauss_preload_identical":True,"native_elapsed_s":elapsed,
            "accepted_goals":successful,"accepted_halves":parsed_inserted,"stop":failure,
            "last_accepted_Qy_kN":accepted_qn/1e3,
            "physical_limit_established": bool(failure and failure["status"]==5)}


def main():
    base = runpy.run_path(str(HERE/ "Verify-Preload.py"))
    owner = base["ownership"]("MVTGaussMixed")
    raw = (HERE/"Native/MVTGaussMixed.csv").read_bytes()
    locked = (HERE/"Native/ColdPreload.csv").read_bytes()
    proof = {"status":"PASS","ownership":owner,"native_sha256":base["digest"](raw),
             "pure_preload_sha256":base["digest"](locked),**test_wire(raw,locked,base)}
    output = HERE/"VerificationMVTGaussMixed.json"
    content=(json.dumps(proof,indent=2,sort_keys=True)+"\n").encode()
    if output.is_file():
        assert output.read_bytes()==content
    else:
        output.write_bytes(content)
    print(f"PASS {output.name} SHA256 {base['digest'](content)}")


if __name__=="__main__":
    main()
