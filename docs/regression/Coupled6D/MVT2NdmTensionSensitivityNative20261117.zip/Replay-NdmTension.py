"""Replay the native NDM material sensitivity and the exact centered baseline comparison."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import runpy
from subprocess import check_output
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
BASE_SHA = "A3EC01957BB5D9AC49A11C1D23678FE874D53367524C4F76192C16002212BC09"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def verify(repo):
    plan = json.loads((ROOT / "Preparation.json").read_bytes())
    capture = json.loads((ROOT / "CapturedCases.json").read_bytes())
    reference = repo / "docs/regression/Coupled6D/MVT2GaussMixedNative20261117.zip"
    assert digest(reference.read_bytes()) == BASE_SHA
    with ZipFile(reference) as archive:
        baseline = json.loads(archive.read("VerificationMVTGaussMixed.json"))
        previous_trace = archive.read("Native/MVTGaussMixed.csv")
        assert archive.read("Native/ColdPreload.csv") == (ROOT / "Native/ColdPreload.csv").read_bytes()
    assert baseline["reached_Qy15"] and len(baseline["accepted_goals"]) == 18
    data = (repo / BOOK).read_bytes()
    if digest(data) != BOOK_SHA:
        data = check_output(["git", "-C", str(repo), "show", f"709e7dfa16c192748fc2c6d999925bdbf9948a4c:{BOOK}"])
    assert digest(data) == BOOK_SHA == plan["source_book_sha256"]
    temporary_book = ROOT / BOOK
    temporary_book.parent.mkdir(parents=True, exist_ok=True)
    with temporary_book.open("xb") as file:
        file.write(data)
    variants = {}
    try:
        check = runpy.run_path(str(ROOT / "Verify-NdmTension.py"))["verify"]
        for case, seal in capture.items():
            value = check(case)
            raw = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
            assert digest(raw) == seal and (ROOT / f"Verified{case}.json").read_bytes() == raw
            variants[case] = value
    finally:
        temporary_book.unlink()
    if "MVTGaussMixed" in variants:
        current = (ROOT / "Native/MVTGaussMixed.csv").read_bytes().splitlines()[:-1]
        assert [line for line in current if not line.startswith(b"MVT_PARAMETERS;")] == previous_trace.splitlines()[:-1]
    double = variants["MVTEnergy2"]
    assert double["mixed"]["stop"]["last_accepted_Qy_kN"] == 11.3671875
    assert double["preload"]["stages"][-1]["twist_rad_per_m"] == 0.00406162781325114
    higher = variants["MVTEnergyReference"]
    assert higher["mixed"] is None and higher["preload"]["stages"][-1]["accepted_T_kNm"] == 8.785703125
    print("MVT2 NDM TENSION PORTABLE PASS", " ".join(capture.values()))


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    verify(parser.parse_args().repo.resolve())
