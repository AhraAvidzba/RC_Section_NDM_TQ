"""Reintegrate every reported section state on unchanged 25-point geometry."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import isclose
from pathlib import Path
import runpy


ROOT = Path(__file__).resolve().parent
L = 18.621285527678477
CASES = {"MVTGaussMixed": (1., .5), "MVTEnergy2": (2., .5),
         "MVTEnergyReference": (125. / L, .5), "MVTDamage25": (1., .25)}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def verify(case):
    base = runpy.run_path(str(ROOT / "Verify-Preload.py"))
    base["MODULES"].add("CCoupledConcreteResponse")
    owner = base["ownership"](case)
    original = (ROOT / "Native/ColdPreload.csv").read_bytes()
    previous_rows = [row.split(";") for row in original.decode("cp1251").splitlines()]
    previous_geometry = [row for row in previous_rows if row[0] in {"MVT_GEOM", "MVT_POINT"}]
    previous_setup, = [row for row in previous_rows if row[0] == "MVT2_ADAPT_SETUP"]
    raw = (ROOT / f"Native/{case}.csv").read_bytes()
    lines = raw.splitlines(keepends=True)
    end = lines[-1].decode("ascii").strip().split(";")
    assert end[:2] == ["CASE_FINISHED", case] and end[2] in {"True", "False"}
    markers = [index for index, line in enumerate(lines) if line.startswith(b"MVT_PRELOAD_END;")]
    assert len(markers) <= 1
    prefix = b"".join(lines[:markers[0] if markers else -1])
    rows = [row.split(";") for row in prefix.decode("cp1251").splitlines()]
    assert [row for row in rows if row[0] in {"MVT_GEOM", "MVT_POINT"}] == previous_geometry
    assert len([row for row in rows if row[0] == "MVT_PARAMETERS"]) == 1
    parameters, = [base["floats"](row[1:]) for row in rows if row[0] == "MVT_PARAMETERS"]
    assert all(isclose(a, b, rel_tol=3e-14) for a, b in zip(parameters, CASES[case], strict=True))
    setup, = [row for row in rows if row[0] == "MVT2_ADAPT_SETUP"]
    assert setup[:4] == previous_setup[:4] and setup[5:] == previous_setup[5:]
    assert isclose(float(setup[4]), float(previous_setup[4]) * parameters[0], rel_tol=3e-14)
    checked = dict(base)
    def parse_pure(records, mode, finished):
        normalized = [previous_setup if row[0] == "MVT2_ADAPT_SETUP" else row for row in records]
        return base["verify_mvt"](normalized, mode, finished)
    checked["verify_mvt"] = parse_pure
    preload = parse_pure(rows, "MVTGauss", bool(markers))
    baseline_identical = (b"".join(line for line in prefix.splitlines(keepends=True)
                                    if not line.startswith(b"MVT_PARAMETERS;")) == original)
    if case == "MVTGaussMixed":
        assert baseline_identical
    if markers:
        marker = lines[markers[0]].strip()
        assert marker.decode("ascii").split(";") == ["MVT_PRELOAD_END", str(len(preload["accepted_history_torque_kNm"])), "10.51"]
        mixed = runpy.run_path(str(ROOT / "Verify-Mixed.py"))["test_wire"](raw, prefix, checked, marker=marker, case=case)
        del mixed["cold_gauss_preload_identical"]
    else:
        assert end[2] == "False"
        mixed = None
    return {"case": case, "owner": owner, "status": "PASS", "native_sha256": digest(raw),
            "energy_factor": parameters[0], "damage_at_half_nominal_stress": parameters[1],
            "baseline_prefix_identical": baseline_identical, "preload": preload, "mixed": mixed}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=CASES, required=True)
    case = parser.parse_args().case
    proof = verify(case)
    output = ROOT / f"Verified{case}.json"
    raw = (json.dumps(proof, indent=2, sort_keys=True) + "\n").encode()
    if output.exists():
        assert output.read_bytes() == raw
    else:
        output.write_bytes(raw)
    print("MVT2 NDM TENSION VERIFIED", case, digest(raw))
