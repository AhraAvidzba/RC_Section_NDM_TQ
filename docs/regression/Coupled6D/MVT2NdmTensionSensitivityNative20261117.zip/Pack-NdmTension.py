"""Pack the private native response cases and immutable audit records."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
NATIVE = Path("D:/CodexScratch/RC_Section_NDM_TQ/MVTNdmTension")


def digest(raw):
    return sha256(raw).hexdigest().upper()


def pack(archive, cases):
    assert len(cases) == len(set(cases)) and {"MVTEnergy2", "MVTEnergyReference"} <= set(cases)
    manifest = json.loads((NATIVE / "Preparation.json").read_bytes())
    frozen = {name: h for name, h in manifest["inputs"].items() if not name.endswith(".xlsm")}
    files = set(frozen) | {"Preparation.json", "Compile.log", "CompileClosure.json", "docs/regression/CodeUpdate.json"}
    reports = [f"Verified{case}.json" for case in cases]
    files.update(reports)
    files |= {f"Native/{p.name}" for p in (NATIVE / "Native").iterdir()
              if p.is_file() and p.name.split(".")[0] in cases}
    raw = {name: (NATIVE / name).read_bytes() for name in sorted(files)}
    assert all(digest(raw[name]) == h for name, h in frozen.items())
    raw["CapturedCases.json"] = (json.dumps({case: digest(raw[name]) for case, name in zip(cases, reports, strict=True)},
                                             indent=2) + "\n").encode()
    for name in ("Stage-NdmTension.py", "Replay-NdmTension.py", "Pack-NdmTension.py"):
        raw[name] = (HERE / name).read_bytes()
    with ZipFile(archive, "x", ZIP_DEFLATED, compresslevel=9) as z:
        for name, content in raw.items():
            z.writestr(ZipInfo(name), content, ZIP_DEFLATED, compresslevel=9)
    print(digest(archive.read_bytes()))


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("cases", nargs="+")
    args = parser.parse_args()
    pack(args.archive, args.cases)
