"""Verify both closed A2 lanes and compare matched torque anchors with experiment."""
from argparse import Namespace
from math import degrees, isclose
from pathlib import Path
from runpy import run_path
import json
import re

import AuditResume as independent
from ReplayAOnly import compare_receipt

HERE=Path(__file__).resolve().parent
NATIVE=HERE/'Native'
COLD=HERE/'Cold'


def read(name):
    return json.loads((HERE/name).read_text(encoding='utf-8-sig'))


def write(name,data):
    path=HERE/name
    path.write_bytes((json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode('utf8'))
    return independent.digest(path)


def verified_lane(lane, exact_gate):
    stem=f'{lane}-1'
    cold_trace=COLD/f'{lane}-Cold.csv'
    proof=independent.audit(Namespace(work_root=HERE,cold=cold_trace,lane=lane,stem=stem))
    cold,cold_sha=compare_receipt(COLD,f'{lane}-Cold')
    resume,resume_sha=compare_receipt(NATIVE,f'{stem}-Resume')
    exact,exact_sha=compare_receipt(NATIVE,f'{stem}-Exact')
    assert cold['terminal']=='watchdog_timeout' and resume['terminal']==exact['terminal']=='completed'
    cold_exit=read(f'Cold/{lane}-Cold-Receipt.json')
    assert cold_exit['NativeExit']!=0
    assert proof['exact_anchor_status']=='attested' and proof['resume_receipt']==resume
    assert proof['stop']=='MeasuredTorqueBracketed'
    assert proof['complete_prefix_count']==(48 if lane=='A' else 43)
    assert len(proof['native_new_fields'])==(21 if lane=='A' else 12)
    ver_name=f'Native/{stem}-Exact-Verification.json'
    receipt=read(ver_name)
    measured=exact_gate(NATIVE/f'{stem}-Exact.csv',list(independent.GOALS))
    assert [x['target_kNm'] for x in measured]==list(independent.GOALS)
    assert receipt['anchors']==measured and receipt['all_anchors_verified']
    assert receipt['exact_trace_sha256']==independent.digest(NATIVE/f'{stem}-Exact.csv')
    assert receipt['exact_input_sha256']==independent.digest(NATIVE/f'{stem}-ExactInput.csv')
    assert receipt['trace_sha256']==proof['cold_trace_sha256']
    assert receipt['cold_states']==(27 if lane=='A' else 31)
    for val,check in zip(measured,proof['exact_native_anchors'],strict=True):
        assert val['target_kNm']==check['target_T_kNm']
        assert val['twist_rad_m']==check['twist_rad_m'] and val['method']==check['method']
        assert val['history_left']==check['actual_left_field']
        assert tuple(val['independent_resultants_N_Nmm'])==tuple(check['signed_integrated_N_Nmm'])
        val.update({'twist_deg_m':degrees(val['twist_rad_m']),
                    'exactTorqueResidual_kNm':val['independent_resultants_N_Nmm'][3]/1e6-val['target_kNm'],
                    'differenceFromNativeSixResultants_MPa':check['difference_from_VBA_MPa']})
    digest=write(f'Independent{lane}.json',proof)
    return {'material_constants':proof['material_constants'],'coldFields':receipt['cold_states'],
            'acceptedFields':proof['complete_prefix_count'],'coldOwner':cold,'resumeOwner':resume,'exactOwner':exact,
            'nativeColdWallSeconds':cold_exit['ElapsedSeconds'],'coldCompiledWorkbookSHA256':cold_sha,
            'resumeCompiledWorkbookSHA256':resume_sha,'exactCompiledWorkbookSHA256':exact_sha,
            'lastAcceptedT_kNm':proof['native_new_fields'][-1]['T_kNm'],
            'lastAcceptedTwist_rad_m':proof['native_new_fields'][-1]['twist_rad_m'],
            'maxAcceptedSampleT_kNm':proof['maximum_of_accepted_samples_kNm'],
            'fallbackDirectionGaps':proof['methods_without_direction_guard'],'independentReplaySHA256':digest,
            'nativeExactVerificationSHA256':independent.digest(HERE/ver_name),'exactAnchors':measured}


def paired(anchors,exp):
    model=exp['modelParameters']
    for a,b,s in zip(anchors['A'],anchors['B'],exp['anchors'],strict=True):
        t=s['T_kNm']
        assert a['target_kNm']==b['target_kNm']==t
        for val in (a,b):
            val['twistMinusExperiment_deg_m']=val['twist_deg_m']-s['expTwist_deg_m']
            val['twistMinusExperiment_percent']=100*val['twistMinusExperiment_deg_m']/s['expTwist_deg_m']
            val['hoopMinusModelYield_MPa']=val['hoop_quadrature_max_MPa']-model['hoopYieldStress_MPa']
            val['longitudinalMinusModelYield_MPa']=val['longitudinal_max_MPa']-model['longitudinalYieldStress_MPa']
        keys=('twist_deg_m','hoop_quadrature_max_MPa','longitudinal_max_MPa',
              'positive_principal_T_kNm','negative_principal_T_kNm','hoop_leg_max_microstrain','corner_long_max_microstrain')
        yield {**s,'A':a,'B':b,'BMinusA':{k:b[k]-a[k] for k in keys}}


def main():
    manifest=read('ReplayInputs.json')
    assert manifest['schema']=='A2TwoLanesNative/v1'
    assert all(independent.digest(HERE/name)==expected for name,expected in manifest['files'].items())
    experiment=read('Experiment.json')
    exact_gate=run_path(str(HERE/'Verify-A2.py'))['exact_gate']
    lanes={lane:verified_lane(lane,exact_gate) for lane in ('A','B')}
    fixture=read('Fixture.json')
    cold_fixture=read('Cold/Fixture.json')
    code=read('docs/regression/CodeUpdate.json')
    compiled=read('CompileClosure.json')
    assert compiled['State']=='Absent' and code['Compiled'] and not code['ProductionChanged']
    assert code['Modules']==['modTestCoupledExperiment'] and code['ProductionSHA256']==fixture['workbook_sha256']
    assert cold_fixture['workbook_sha256']==fixture['workbook_sha256']
    log=(HERE/'Compile.log').read_text(encoding='utf-8-sig')
    assert re.findall(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',log,re.M)==[(str(compiled['PID']),compiled['StartTicksUTC'])]
    assert lanes['A']['coldCompiledWorkbookSHA256']==lanes['B']['coldCompiledWorkbookSHA256']
    for row in lanes.values():
        assert code['WorkbookSHA256']==row['resumeCompiledWorkbookSHA256']==row['exactCompiledWorkbookSHA256']
        assert code['WorkbookSHA256']!=row['coldCompiledWorkbookSHA256']
    assert isclose(lanes['B']['material_constants'][2]/lanes['A']['material_constants'][2],
                   experiment['modelParameters']['GtBtoA'],rel_tol=1e-14)
    assert [x['T_kNm'] for x in experiment['anchors']]==list(independent.GOALS)
    compared=list(paired({k:v.pop('exactAnchors') for k,v in lanes.items()},experiment))
    result={'lanes':lanes,'sourceWorkbookSHA256':fixture['workbook_sha256'],'resumeCompiler':compiled,
            'experimentalSource':experiment['source'],'crackSpacingSource':experiment['crackSpacingSource'],
            'modelParameters':experiment['modelParameters'],'matchedAnchors':compared,
            'interpretation':{'bothLanesOverpredictTwistAtEveryAnchor':all(x[l]['twistMinusExperiment_deg_m']>0 for x in compared for l in lanes),
                              'BLowerTwistAtEveryMatchedTorque':all(x['BMinusA']['twist_deg_m']<0 for x in compared),
                              'bothSteelFamiliesBelowAdoptedYieldAtAllAnchors':all(x[l][k]<0 for x in compared for l in lanes
                                                for k in ('hoopMinusModelYield_MPa','longitudinalMinusModelYield_MPa')),
                              'physicalMaximumEstablished':False}}
    print('A2_PAIRED_NATIVE_PASS',write('PairReplay.json',result))


if __name__=='__main__':
    main()
