"""Assemble a standalone ZIP from the passed A archive and terminal canonical B data."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
WORK=HERE/'Assembly'
DONOR=HERE.parent/'a2-audit/A2LaneAResumeNative20261116.zip'
A_SHA='ACF2D94715C705AC9FCFC99788B5F3F4ECB8A76A557254E29E227FDB831DE076'
B_EXACT_SHA='F0C38200F7BAB812B2D7164B13456222E8E6B7DC20E9E0E93BF6504236AF07F1'
B_COLD_SHA='B735F9679B91FFC9A60D8AE849308BEF3BCE26027C11DADE842216963139BF3E'


def digest(data):
    return sha256(data).hexdigest().upper()


def stage():
    assert digest(DONOR.read_bytes())==A_SHA
    origin=HERE.parent/'a2-resume'
    cold=HERE.parent/'a2ab'
    exact=origin/'Native/B-1-Exact-Verification.json'
    assert digest(exact.read_bytes())==B_EXACT_SHA
    assert digest((cold/'Native/B-Cold.csv').read_bytes())==B_COLD_SHA
    with ZipFile(DONOR) as archived:
        receipt=json.loads(archived.read('ReplayInputs.json'))
        files={name:archived.read(name) for name in receipt['files']}
        assert all(digest(data)==receipt['files'][name] for name,data in files.items())
        files['Provenance-A-PortableReplay.json']=archived.read('PortableReplay.json')
    files.update({name:(HERE/name).read_bytes() for name in ('AuditResume.py','ReplayPair.py','Experiment.json','README.md','Package.py')})
    files.update({f'Cold/{path.name}':path.read_bytes() for path in (cold/'Native').glob('B-Cold*') if path.is_file()})
    files.update({f'Native/{path.name}':path.read_bytes() for path in (origin/'Native').glob('B-1-*') if path.is_file()})
    assert {'Native/B-1-Exact.csv','Native/B-1-Exact.txt.ProcessClosure.json','Native/B-1-Resume.txt.ProcessClosure.json',
            'Cold/B-Cold.txt.ProcessClosure.json'} <= set(files)
    for name in ('Fixture.json','Compile.log','CompileClosure.json','docs/regression/CodeUpdate.json'):
        files['Cold/'+name]=(cold/name).read_bytes()
    files['Run.ndjson']=(origin/'Run.ndjson').read_bytes()
    exp=json.loads(files['Experiment.json'])
    for ref in ('source','crackSpacingSource'):
        record=exp[ref]
        assert digest((REPO/record['path']).read_bytes())==record['sha256']
    assert not any(name.lower().endswith(('.xlsm','.xlsx','.xls','.pdf')) for name in files)
    manifest={'schema':'A2TwoLanesNative/v1','originalAArchiveSHA256':A_SHA,
              'files':{name:digest(value) for name,value in sorted(files.items())}}
    files['ReplayInputs.json']=(json.dumps(manifest,indent=2)+'\n').encode('utf8')
    for name,data in files.items():
        out=WORK/name
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_bytes(data)
    return files


def pack():
    entries=stage()
    subprocess.run([sys.executable,'-B','-X','utf8','ReplayPair.py'],cwd=WORK,check=True)
    for name in ('PairReplay.json','IndependentA.json','IndependentB.json'):
        entries[name]=(WORK/name).read_bytes()
    output=HERE/'A2LaneABExactNative20261116.zip'
    with ZipFile(output,'w',compression=ZIP_DEFLATED,compresslevel=9) as package:
        for name,data in sorted(entries.items()):
            package.writestr(ZipInfo(name,(2026,11,16,0,0,0)),data,compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(output) as check:
        assert check.testzip() is None and set(check.namelist())==set(entries)
    print(output,digest(output.read_bytes()),output.stat().st_size)


if __name__=='__main__':
    pack()
