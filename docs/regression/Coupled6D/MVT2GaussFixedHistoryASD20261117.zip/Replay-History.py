"""Commit the captured MVT2 center strains to distinct ASDConcrete3D histories."""
from argparse import ArgumentParser
from hashlib import sha256
from itertools import groupby
from math import exp, expm1, fsum, isfinite, log, log1p
from pathlib import Path
from time import perf_counter
from types import SimpleNamespace
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
D = Path("D:/CodexScratch/RC_Section_NDM_TQ")
NATIVE = "MVTGauss25Tensors"
INPUTS = {
    "VerificationMVTGaussTensors.json": "104F5BAD5351EDE4BA46A0F390253D2C1A8A1662C00FCE535FC0D90EBC24C5CC",
    "Native/MVTGaussMixed.Tensor.csv": "8D5BF7E9D9B688A9C18CB6AFF4972142752C232999CAC4AFD2A4821BC86CB33B",
    "Native/MVTGaussMixed.csv": "A04ABC59AE4A09670A18785884DF3CCED9712C50812A81FE6C41FD9FF48A0757",
    "Verify-Tensors.py": "27EF62D1167389F379E524A16728A23C6CE46C5C359A48C672AB7B1A5DCC7E16",
}
BRICK = "ArchivedEvidence/LocalGradientDerivative20261115/TBU3MatchedMaterial/Verify-TBU3PointBrick.py"
BRICK_SHA = "B1ABBD4D7FAF2FAFDD2B54B41F86EF0A73C0D85C5720D888FB521442256365DA"
ENVELOPE = "OpenSeesExplicitUniaxial20261115/VerifyExplicitAsdEnvelope.py"
ENVELOPE_SHA = "879D4254404077F3EBF0F0ED680E7AD6342E3C0E873F3CFE4064CD1161895B18"
FAMILIES = ("N", "Mx", "My", "T", "Qx", "Qy")
ASD_CASES = ("ASD_default", "ASD_explicit_NDM_envelopes")


def digest(data):
    return sha256(data).hexdigest().upper()


def pinned(path, expected):
    data = path.read_bytes()
    if digest(data) != expected:
        raise ValueError(f"Unexpected SHA-256 for {path}")
    return data


def finite(raw, count):
    x = tuple(map(float, raw))
    assert len(x) == count and all(map(isfinite, x))
    return x


def keyed(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result
        result[key] = value
    return result


def read_native(root):
    data = {name:pinned(root/name,sha) for name,sha in INPUTS.items()}
    raw = data["Native/MVTGaussMixed.csv"]
    report = json.loads(data["VerificationMVTGaussTensors.json"])
    check = runpy.run_path(str(root/"Verify-Tensors.py"))["verify"]
    regenerated = check(data["Native/MVTGaussMixed.Tensor.csv"],raw)
    assert json.loads(json.dumps(regenerated)) == report
    assert report["accepted_stress_rows_checked"] == 1125 and report["max_accepted_stress_difference_MPa"] == 0.0
    wire = [line.split(";") for line in raw.decode("cp1251").splitlines()]
    header, = [r for r in wire if r[0] == "MVT_GEOM"]
    assert tuple(map(int,header[1:4])) == (25,45,60)
    ox,oy,area,length = finite(header[4:],4)
    points = keyed((int(r[1]),finite(r[2:],9)) for r in wire if r[0]=="MVT_POINT")
    assert tuple(points) == tuple(range(1,46))
    positions = tuple((r[0]-ox,r[1]-oy,r[2]) for r in points.values())
    dirs = tuple(r[3:] for r in points.values())
    assert all(w > 0.0 for x,y,w in positions) and abs(fsum(w for x,y,w in positions[:25])-area)<2e-8
    assert all(x == (0.,)*6 for x in dirs[:25])
    assert all(x == (0.,0.,1.,0.,0.,0.) for x in dirs[25:29])
    assert all(abs(x[0]+x[1]-1.0)<1e-13 and x[2]==x[4]==x[5]==0. for x in dirs[29:])
    steel_archive = keyed(((r[1],int(r[2])),finite(r[3:],7)[-1]) for r in wire
                          if r[0] in ("MVT_STRESS","MVT_SHEAR_STRESS") and int(r[2]) > 25)
    frames = report["frames"]
    assert len(frames)==26 and [s["phase"] for s in frames]==[f"R{i}" for i in range(1,9)]+[f"S{i}" for i in range(1,19)]
    steel = []
    steel_error = 0.0
    for frame in frames:
        values = []
        for i in range(25,45):
            projection = fsum(a*b for a,b in zip(frame["points"][i][:6],dirs[i],strict=True))
            elastic = 2e5*projection
            assert abs(elastic) < (498. if i <29 else 450.)
            phase = frame["phase"]
            key = ("R7" if phase == "R8" else phase,i+1)
            if phase == "R7":
                # This internal accepted torque substep has concrete tensors without a steel report row.
                values.append(elastic)
            else:
                observed = steel_archive.pop(key)
                steel_error=max(steel_error,abs(observed-elastic))
                values.append(observed)
        steel.append(values)
    assert not steel_archive and steel_error < 2e-10
    return report,positions,dirs,steel,area,length,steel_error


def law(model):
    e,nu,fc,ft,peak,gt,gc,length = model
    compress_damage = .423*(1. - fc/(peak*e))
    p_peak = peak - fc/((1. - compress_damage)*e)
    coeff = {"TENSION":(ft,ft,0.,ft*length/gt,gt/length),
             "COMPRESSION":(.6*fc,fc,p_peak,-log1p(-compress_damage)/p_peak,gc/length)}
    def definition(branch):
        sy,sp,pp,alpha,energy = coeff[branch]
        decay = sp/(energy - .5*(sy+sp)*pp)
        def sample(p):
            nominal = sy+(sp-sy)*p/pp if p < pp else sp*exp(-decay*(p-pp))
            d = -expm1(-alpha*p)
            strain = p + nominal/((1.-d)*e)
            return strain,nominal,d
        return pp,decay,sample
    return definition


def exact_tables(report):
    e = report["model"][0]
    definitions = law(report["model"])
    max_knot_diff = 0.0
    branches = {}
    for name in ("TENSION","COMPRESSION"):
        peak,decay,sample = definitions(name)
        native = report["curves_MPa"][name]
        knots = [0.] + ([peak*k/4 for k in range(1,5)] if peak else [])
        knots += [peak-log(r)/decay for r in (.9,.75,.5,.25,.1,.03,.01)]
        expected = [(0.,0.,0.)] + [sample(p) for p in knots]
        for a,b in zip(native,expected,strict=True):
            max_knot_diff=max(max_knot_diff,*(abs(x-y) for x,y in zip(a,b[:2],strict=True)))
        grid = [peak*k/40 for k in range(40)] if peak else []
        grid += [peak+k/(20*decay) for k in range(277)]
        rows = [(0.,0.,0.)]
        for p in grid:
            strain,nominal,damage=sample(p)
            if damage < 1.-1e-12 and strain <= .1:
                rows.append((strain,nominal,damage))
            else:
                break
        assert len(rows) > 200
        assert abs(rows[1][1]-e*rows[1][0]) < 1e-12
        branches[name]=tuple(rows)
    assert max_knot_diff < 2e-12
    return branches,max_knot_diff


def action(position, stress):
    x,y,w = position
    _,_,zz,_,xz,yz = stress
    return w*zz,w*y*zz,w*x*zz,w*(x*yz-y*xz),w*xz,w*yz


def net_tensor(concrete, direction, steel, i):
    if i <25:
        return tuple(concrete)
    return tuple(steel[i-25]*d-s for d,s in zip(direction,concrete,strict=True))


def response(ops, args, strain_frames):
    ops.wipe()
    ops.model("basic","-ndm",3,"-ndf",3)
    for tag in range(1,46):
        ops.nDMaterial(args[0],tag,*args[1:])
    return [[direct_step(ops,tag,strain) for tag,strain in enumerate(stage,1)] for stage in strain_frames]


def voigt(values):
    return *values[:4], values[5], values[4]


def direct_step(ops, tag, strain):
    target = voigt(strain)
    ops.NDTest("SetStrain",tag,*target)
    assert tuple(ops.NDTest("GetStrain",tag))==target
    stress = voigt(ops.NDTest("GetStress",tag))
    assert len(stress)==6 and all(map(isfinite,stress))
    ops.NDTest("CommitState",tag)
    return stress


def stock_elastic(strain,e,nu):
    g=e/(2*(1+nu))
    lam=nu*e/((1+nu)*(1-2*nu))
    tr=fsum(strain[:3])
    return tuple(2*g*x+lam*tr for x in strain[:3])+tuple(g*x for x in strain[3:])


def brick_checks(path, law_file, ops, args, variants, stages, geom, tables):
    pinned(path,BRICK_SHA)
    pinned(law_file,ENVELOPE_SHA)
    brick_module=runpy.run_path(str(path))
    brick=brick_module["brick"]
    # Two opposite y-face concrete points and one concrete replacement point.
    picks=(3,23,28)
    checks={}
    for name,concrete in variants.items():
        case={}
        for point in picks:
            compare,quality=brick(lambda tag:ops.nDMaterial(args[name][0],tag,*args[name][1:]),
                                  [p[point-1] for p in stages],SimpleNamespace(components=voigt),125.)
            direct=[s[point-1] for s in concrete]
            err=max(abs(a-b) for x,y in zip(compare,direct,strict=True) for a,b in zip(x,y,strict=True))
            assert quality["strain"]<1e-12 and max(err,quality["gauss_stress_MPa"],quality["face_stress_MPa"])<2e-8
            case[str(point)]={**quality,"max_direct_difference_MPa":err,"x_y_mm":geom[point-1][:2]}
        if name==ASD_CASES[1]:
            explicit=runpy.run_path(str(law_file))
            for branch, table in tables.items():
                actual=explicit["read_installed_branch"](1,1,branch.lower())
                delta=max(abs(a-b) for n,o in zip(actual,table,strict=True) for a,b in zip(n,o,strict=True))
                assert delta < 1e-8
                case[f"installed_{branch}"]={"knots":len(table),"max_absolute_entry_difference":delta}
        checks[name]=case
    ops.wipe()
    return checks


def brick_elastic_control(brick_file, ops, e, nu):
    # OpenSees ElasticIsotropic creates its 3D subtype through the element.
    # Distinct components make both shear-order swaps and signs observable.
    brick=runpy.run_path(str(brick_file))["brick"]
    strain=(2e-5,-3e-5,6e-5,-4e-5,9e-5,-7e-5)
    control,quality=brick(lambda tag:ops.nDMaterial("ElasticIsotropic",tag,e,nu),
                          [strain],SimpleNamespace(components=voigt),125.)
    target=stock_elastic(strain,e,nu)
    error=max(abs(a-b) for a,b in zip(control[0],target,strict=True))
    assert error<1e-12 and quality["strain"]<1e-12
    return error


def band(i, pos):
    if i >=29:
        return "hoop_position"
    if i >=25:
        return "longitudinal_bar_position"
    x,y,w=pos
    if abs(x) >=84 and abs(y) >=84:
        return "corner"
    if abs(x) >=84:
        return "left_face" if x<0 else "right_face"
    if abs(y) >=84:
        return "lower_face" if y<0 else "upper_face"
    return "interior"


def series(frames,positions,dirs,steel,inputs,stages,area,length):
    ans={}
    for mode,concrete in inputs.items():
        previous=None
        work=0.
        by_case=[]
        for i,(frame,strains,stresses) in enumerate(zip(frames,stages,concrete,strict=True)):
            net=tuple(net_tensor(s,d,steel[i],j) for j,(s,d) in enumerate(zip(stresses,dirs,strict=True)))
            actions=[action(p,s) for p,s in zip(positions,net,strict=True)]
            totals=tuple(map(fsum,zip(*actions,strict=True)))
            q,t=frame["Qy_N"],frame["T_Nmm"]
            target=(0.,-330.*q,0.,t,0.,q)
            residual=max(abs(a-b)/(area*(length if idx in (1,2,3) else 1.)) for idx,(a,b) in enumerate(zip(totals,target,strict=True)))
            if mode=="NDM":
                tolerance=5e-7+5e-7*max(abs(t)/(area*length),abs(q)/area,abs(target[1])/(area*length))
                assert residual <= tolerance+5e-14
            families={}
            for label,indices in groupby(sorted(range(45),key=lambda j:band(j,positions[j])),key=lambda j:band(j,positions[j])):
                families[label]=tuple(map(fsum,zip(*(actions[j] for j in indices),strict=True)))
            old_strains,old_tensors=previous if previous is not None else ([(0.,)*6]*45,[(0.,)*6]*45)
            work += fsum(.5*pos[2]*( (a[4]+b[4])*(e[4]-f[4]) + (a[5]+b[5])*(e[5]-f[5]) )
                         for pos,a,b,e,f in zip(positions,net,old_tensors,strains,old_strains,strict=True))
            previous=strains,net
            by_case.append({"phase":frame["phase"],"Qy_N":q,"T_target_Nmm":t,
                            "resultants_N_Nmm":totals,"bands_N_Nmm":families,
                            "integrated_shear_work_N_per_section_length_unit":work,
                            "distance_to_NDM_applied_loads_normalized_MPa":residual})
        base=by_case[7]
        for entry in by_case[7:]:
            entry["change_since_own_Q0_N_Nmm"]=[a-b for a,b in zip(entry["resultants_N_Nmm"],base["resultants_N_Nmm"],strict=True)]
            entry["band_change_since_own_Q0_N_Nmm"]={key:[a-b for a,b in zip(values,base["bands_N_Nmm"][key],strict=True)]
                                                       for key,values in entry["bands_N_Nmm"].items()}
            entry["additional_shear_work_since_Q0_N_per_section_length_unit"]=entry["integrated_shear_work_N_per_section_length_unit"]-base["integrated_shear_work_N_per_section_length_unit"]
        ans[mode]=by_case
    return ans


def exclusive_json(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with path.open("xb") as fp:
        fp.write(raw)
    return digest(raw)


def main(root, helpers, out, mode, inputs_only):
    started=perf_counter()
    report,pos,dirs,steel,area,length,steel_error=read_native(root)
    frames=report["frames"]
    inputs=[[p[:6] for p in f["points"]] for f in frames]
    native=[[p[6:] for p in f["points"]] for f in frames]
    model=report["model"]
    e,nu,fc,ft=model[:4]
    tables,knot_error=exact_tables(report)
    ndm_first=max(abs(a-b) for s,t in zip(inputs[0],native[0],strict=True)
                  for a,b in zip(stock_elastic(s,e,nu),t,strict=True))
    assert ndm_first<1e-10
    if inputs_only:
        print(json.dumps({"status":"INPUTS_PASS","states":len(inputs),"points":len(pos),"common_native_rows":1125,
                          "max_steel_MPa_difference":steel_error,"max_envelope_anchor_entry_difference":knot_error,
                          "native_initial_isotropic_stress_error_MPa":ndm_first},indent=2))
        return
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0"
    pinned(helpers/ENVELOPE,ENVELOPE_SHA)
    valid=runpy.run_path(str(helpers/ENVELOPE))["validate_branch"]
    args={ASD_CASES[0]:["ASDConcrete3D",e,nu,"-fc",fc,"-ft",ft,"-tangent"]}
    if mode=="both":
        line=["ASDConcrete3D",e,nu]
        for (name,rows),prefix in zip(tables.items(),("T","C"),strict=True):
            valid(rows,e,name)
            for i,s in enumerate("esd"):
                line += [f"-{prefix}{s}",*(r[i] for r in rows)]
        args[ASD_CASES[1]]=[*line,"-tangent"]
    try:
        histories={name:response(ops,command,inputs) for name,command in args.items()}
        checks=brick_checks(helpers/BRICK,helpers/ENVELOPE,ops,args,histories,inputs,pos,tables)
        elastic_error=brick_elastic_control(helpers/BRICK,ops,e,nu)
    finally:
        ops.wipe()
    virgin={name:max(abs(a-b) for s,t in zip(inputs[0],record[0],strict=True)
                 for a,b in zip(stock_elastic(s,e,nu),t,strict=True)) for name,record in histories.items()}
    models=series(frames,pos,dirs,steel,{"NDM":native,**histories},inputs,area,length)
    raw=json.dumps(histories,separators=(",",":"),allow_nan=False).encode()
    raw_file=out.with_suffix(".stress.json.gz")
    with raw_file.open("xb") as fp:
        fp.write(gzip.compress(raw,compresslevel=9,mtime=0))
    result={"status":"PASS","interpretation":"same prescribed central tensors and committed history steps, no re-equilibration",
            "physical_limit_established":False,"equilibrium_solved_by_ASD":False,"ops_version":ops.version(),
            "input_sha256":INPUTS,"source_method_controls_sha256":{BRICK:BRICK_SHA,ENVELOPE:ENVELOPE_SHA},
            "ASD_stresses_wire_sha256":digest(raw_file.read_bytes()),"native_constitutive_model":model,
            "state_count":len(frames),"points_per_state":len(pos),"common_native_stress_rows":1125,
            "elastic_steel_reference_max_error_MPa":steel_error,
            "first_frame_difference_from_isotropic_MPa":{**virgin,"NDM":ndm_first},
            "independent_ElasticIsotropic_brick_error_MPa":elastic_error,
            "NDM_envelope_knot_max_error":knot_error,"ASD_installed_laws_and_brick_agreement":checks,
            "ASD_modes":list(histories),"resultant_order":FAMILIES,"models":models}
    print("PASS",exclusive_json(out,result),f"elapsed={perf_counter()-started:.3f}s")


if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("--native",type=Path,default=D/NATIVE)
    parser.add_argument("--helpers",type=Path,default=D)
    parser.add_argument("--out",type=Path,default=HERE/"FixedHistory.json")
    parser.add_argument("--mode",choices=("default","both"),default="both")
    parser.add_argument("--inputs-only",action="store_true")
    args=parser.parse_args()
    main(args.native,args.helpers,args.out,args.mode,args.inputs_only)
