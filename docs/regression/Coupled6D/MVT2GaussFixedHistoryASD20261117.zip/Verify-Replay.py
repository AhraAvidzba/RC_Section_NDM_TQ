"""Verify the stored full signed action offline, then optionally rerun OpenSees 3.8."""
from argparse import ArgumentParser
from hashlib import sha256
from importlib.metadata import version
from math import fsum, isfinite
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

HERE = Path(__file__).resolve().parent
CAPTURE = "MVT2GaussTensorCaptureNative20261117"
CAPTURE_SHA = "D2DBF6FDE48CDB5997FD099056DEC49231EEABE6D018D817E809C3F951D801A1"
PROOF_SHA = "DD583CAF5C80D26AE2ED821D0E44C284E094FAB1559D66B7006374E5EF0F2F58"
RAW_SHA = "D0B49CF7F92FF496AB641B70EC80021F9D563EF35297DFEEE2D6E12556534787"
PROOF_NAME = "FixedHistory.json"
RAW_NAME = "FixedHistory.stress.json.gz"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def check_manifest():
    seen = set()
    for line in (HERE/"SHA256SUMS").read_text(encoding="ascii").splitlines():
        expected,name = line.split("  ",1)
        lp = PurePosixPath(name)
        assert not lp.is_absolute() and ".." not in lp.parts
        assert name not in seen and not name.lower().endswith(".xlsm")
        assert digest((HERE/name).read_bytes()) == expected, name
        seen.add(name)
    assert seen == {p.relative_to(HERE).as_posix() for p in HERE.rglob("*")
                    if p.is_file() and p.name != "SHA256SUMS"}


def get_native(repo, temp, expected):
    capsule = repo / "docs/regression/Coupled6D" / (CAPTURE + ".zip")
    assert digest(capsule.read_bytes()) == CAPTURE_SHA
    root = temp / "NativeCapture"
    with ZipFile(capsule) as prior:
        for name, sha in expected.items():
            target = root / name
            data = prior.read(name)
            assert digest(data) == sha, name
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
    return root


def integrated(frame_stresses, xy_area, directions, steel):
    """Independent projection. Sum concrete, displaced concrete and steel by component."""
    strains = []
    for j,(s,d) in enumerate(zip(frame_stresses,directions,strict=True)):
        assert len(s)==6 and all(map(isfinite,s))
        strains.append(s if j<25 else [steel[j-25]*d[k]-s[k] for k in range(6)])
    normal = [w*s[2] for (_,_,w),s in zip(xy_area,strains,strict=True)]
    shear_x = [w*s[4] for (_,_,w),s in zip(xy_area,strains,strict=True)]
    shear_y = [w*s[5] for (_,_,w),s in zip(xy_area,strains,strict=True)]
    return (fsum(normal),fsum(y*f for (_,y,_),f in zip(xy_area,normal,strict=True)),
            fsum(x*f for (x,_,_),f in zip(xy_area,normal,strict=True)),
            fsum(x*fy-y*fx for (x,y,_),fx,fy in zip(xy_area,shear_x,shear_y,strict=True)),
            fsum(shear_x),fsum(shear_y))


def roundtrip(native, source):
    proof_wire=(HERE/PROOF_NAME).read_bytes()
    raw_wire=(HERE/RAW_NAME).read_bytes()
    assert digest(proof_wire)==PROOF_SHA and digest(raw_wire)==RAW_SHA
    proof=json.loads(proof_wire)
    model,pos,dirs,steel,area,length,steel_error = source["read_native"](native)
    assert proof["status"]=="PASS" and proof["ops_version"]=="3.8.0"
    assert proof["ASD_stresses_wire_sha256"]==RAW_SHA and proof["input_sha256"]==source["INPUTS"]
    assert proof["physical_limit_established"] is False and proof["equilibrium_solved_by_ASD"] is False
    assert steel_error==proof["elastic_steel_reference_max_error_MPa"]
    fields=model["frames"]
    captures=json.loads(gzip.decompress(raw_wire))
    assert set(captures)==set(source["ASD_CASES"])
    captures["NDM"]=[[p[6:] for p in f["points"]] for f in fields]
    checked={}
    for key, snapshots in captures.items():
        assert len(snapshots)==26
        original=[r["resultants_N_Nmm"] for r in proof["models"][key]]
        evaluated=[integrated(frame,pos,dirs,steel[k]) for k,frame in enumerate(snapshots)]
        maximum=max(abs(a-b) for x,y in zip(original,evaluated,strict=True) for a,b in zip(x,y,strict=True))
        # Changing product order in double precision can round a large moment by a few nanonewton mm.
        assert maximum < 2e-8
        for j in range(7,26):
            old=proof["models"][key][j]["change_since_own_Q0_N_Nmm"]
            change=[a-b for a,b in zip(evaluated[j],evaluated[7],strict=True)]
            assert max(abs(a-b) for a,b in zip(old,change,strict=True))<4e-8
        checked[key]=maximum
    all_strains=[[p[:6] for p in f["points"]] for f in fields]
    measured=source["series"](fields,pos,dirs,steel,captures,all_strains,area,length)
    assert json.loads(json.dumps(measured)) == proof["models"]
    return checked


def main(repo, runtime):
    check_manifest()
    source=runpy.run_path(str(HERE/"Replay-History.py"))
    with tempfile.TemporaryDirectory(prefix="MVTMaterialReplay_") as temp:
        work=Path(temp)
        native=get_native(repo,work,source["INPUTS"])
        error=roundtrip(native,source)
        print("MVT2 FIXED HISTORY OFFLINE PASS", PROOF_SHA, RAW_SHA, error)
        if runtime:
            assert sys.version_info[:3] == (3,12,10)
            assert version("openseespy") == version("openseespywin") == "3.8.0.0"
            replay=work/PROOF_NAME
            source["main"](native,HERE/"Controls",replay,"both",False)
            assert digest(replay.read_bytes())==PROOF_SHA
            assert digest(replay.with_suffix(".stress.json.gz").read_bytes())==RAW_SHA
            print("MVT2 FIXED HISTORY OPENSEES RUNTIME PASS",PROOF_SHA,RAW_SHA)


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--repo",type=Path,default=Path.cwd())
    parser.add_argument("--runtime",action="store_true")
    args=parser.parse_args()
    main(args.repo,args.runtime)
