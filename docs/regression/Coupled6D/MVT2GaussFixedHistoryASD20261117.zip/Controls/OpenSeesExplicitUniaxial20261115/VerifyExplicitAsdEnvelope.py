"""Import signed nominal concrete stress-strain tables and verify the actual ASD law."""
import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
import math
from pathlib import Path

import openseespy.opensees as ops


BRANCHES = {"tension": ("T", 1, 0), "compression": ("C", -1, 1)}
NODE_ORDER = ((0,0),(1,0),(1,1),(0,1))
SOURCE = "https://github.com/OpenSees/OpenSees/blob/v3.8.0/SRC/material/nD/ASDConcrete3DMaterial.cpp"


@dataclass(frozen=True)
class Envelope:
    provenance: str
    modulus: float
    poisson: float
    branch: dict
    damage_mode: str
    length_ref_mm: float | None


def finite_number(value, label):
    if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value):
        raise ValueError(f"{label}: expected a finite number")
    return float(value)


def load_envelope(path):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if data.get("schema") != 1 or not isinstance(data.get("provenance"),str) or not data["provenance"].strip():
        raise ValueError("schema=1 and nonempty provenance required")
    modulus = finite_number(data.get("E_MPa"),"E_MPa")
    poisson = finite_number(data.get("nu"),"nu")
    if modulus <= 0.0 or not -1.0 < poisson < 0.5:
        raise ValueError("Require E_MPa > 0 and -1 < nu < 0.5")
    mode = data.get("damage_mode")
    if mode not in ("explicit","zero_assumed"):
        raise ValueError("damage_mode must be explicit or zero_assumed")
    regularization = data.get("regularization")
    if not isinstance(regularization,dict):
        raise ValueError("Declare regularization.mode")
    if regularization == {"mode":"as_tabulated"}:
        reference = None
    elif regularization.get("mode") == "crack_band" and set(regularization)=={"mode","reference_length_mm"}:
        reference = finite_number(regularization["reference_length_mm"],"reference_length_mm")
        if reference <= 0.0:
            raise ValueError("reference_length_mm must be positive")
    else:
        raise ValueError("Use as_tabulated or crack_band with reference_length_mm")
    branches = {}
    for name, (_,sign,_) in BRANCHES.items():
        raw = data.get(name)
        if not isinstance(raw,list) or len(raw)<3:
            raise ValueError(f"{name}: expected origin, elastic knot and at least one further knot")
        expected_columns = 3 if mode=="explicit" else 2
        rows = []
        for i,row in enumerate(raw):
            if not isinstance(row,list) or len(row)!=expected_columns:
                raise ValueError(f"{name}[{i}]: expected {expected_columns} values")
            eps,stress,*damage = [finite_number(value,f"{name}[{i}]") for value in row]
            d = damage[0] if damage else 0.0
            if i==0 and (eps,stress,d)!=(0.0,0.0,0.0):
                raise ValueError(f"{name}: first row must be the zero origin with zero damage")
            rows.append((sign*eps,sign*stress,d))
        validate_branch(rows,modulus,name)
        branches[name] = tuple(rows)
    return Envelope(data["provenance"],modulus,poisson,branches,mode,reference)


def validate_branch(rows, modulus, label):
    if not math.isclose(rows[1][1],modulus*rows[1][0],rel_tol=1e-9,abs_tol=1e-10) or rows[1][2]!=0:
        raise ValueError(f"{label}: first nonzero knot must be elastic with stress = E*strain and d=0")
    ep_old = 0.0
    for i, (row,old) in enumerate(zip(rows[1:],rows),1):
        eps,stress,d = row
        e_old,s_old,d_old = old
        if eps<=e_old or stress<=0 or not 0.0<=d<1.0 or d<d_old:
            raise ValueError(f"{label}[{i}]: require increasing strain magnitude, positive stress and nondecreasing 0<=d<1")
        ep = eps - stress/((1.0-d)*modulus)
        if ep < ep_old - 1e-11 or (stress-s_old)/(eps-e_old) > (1.0-d)*modulus*(1+1e-9):
            raise ValueError(f"{label}[{i}]: ASD would adjust this knot (plastic strain or secant constraints)")
        ep_old = ep


def material_arguments(envelope, tag):
    arguments = ["ASDConcrete3D",tag,envelope.modulus,envelope.poisson]
    for name,(prefix,_,_) in BRANCHES.items():
        table = envelope.branch[name]
        for j,field in enumerate(("e","s","d")):
            arguments.extend([f"-{prefix}{field}", *(row[j] for row in table)])
    arguments.append("-tangent")
    if envelope.length_ref_mm is not None:
        arguments.extend(["-autoRegularization",envelope.length_ref_mm])
    return arguments


def install_envelope(envelope, tag):
    ops.nDMaterial(*material_arguments(envelope,tag))


def read_installed_branch(element, point, name):
    prefix,_,_ = BRANCHES[name]
    arrays = [ops.eleResponse(element,"material",point,prefix+field) for field in ("e","s","q")]
    if any(not array or not all(map(math.isfinite,array)) for array in arrays):
        raise RuntimeError(f"Invalid installed-law response for {name}")
    return [(eps,stress,1.0-stress/effective if effective>0 else 0.0)
            for eps,stress,effective in zip(*arrays,strict=True)]


def nominal_at(rows,eps):
    for left,right in zip(rows,rows[1:]):
        if eps<=right[0]+1e-13:
            t=(eps-left[0])/(right[0]-left[0])
            return left[1]+t*(right[1]-left[1])
    raise RuntimeError("Uniaxial probe outside tabulated strain range")


def samples_at_knots(rows, subdivisions):
    samples=[0.0]
    for left,right in zip(rows,rows[1:]):
        samples.extend(left[0]+(right[0]-left[0])*k/subdivisions for k in range(1,subdivisions+1))
    return samples


def make_cube(envelope, side):
    """A single brick with free lateral surfaces and minimal rigid-body constraints."""
    ops.wipe()
    ops.model("basic","-ndm",3,"-ndf",3)
    install_envelope(envelope,1)
    for layer in range(2):
        for i,(x,y) in enumerate(NODE_ORDER):
            tag=4*layer+i+1
            ops.node(tag,x*side,y*side,layer*side)
    ops.fix(1,1,1,1)
    ops.fix(2,0,1,1)
    ops.fix(3,0,0,1)
    ops.fix(4,0,0,1)
    ops.element("stdBrick",1,*range(1,9),1)


def run_case(envelope, side_mm, name, subdivisions=6):
    sign = BRANCHES[name][1]
    make_cube(envelope, side_mm)
    # Run an infinitesimal virgin axial step to initialize the installed-law response.
    factor_probe = 1e-8
    ops.timeSeries("Linear",1)
    ops.pattern("Plain",1,1)
    for node in range(5,9):
        ops.sp(node,3,sign*side_mm)
    ops.constraints("Transformation")
    ops.numberer("Plain")
    ops.system("BandGeneral")
    ops.test("NormUnbalance",2e-8*side_mm**2,80)
    ops.algorithm("Newton")
    ops.integrator("LoadControl",factor_probe)
    ops.analysis("Static")
    if ops.analyze(1)!=0:
        raise RuntimeError(f"ASD failed initial {name} probe")
    installed = {branch: read_installed_branch(1,1,branch) for branch in BRANCHES}
    rows = installed[name]
    for i in range(2,9):
        if rows != read_installed_branch(1,i,name):
            raise RuntimeError("Gauss points have different installed curves")
    target = samples_at_knots(rows,subdivisions)
    max_envelope = max_transverse = max_spread = max_force = max_strain = 0.0
    frames = []
    previous_eps = factor_probe
    for eps in target[1:]:
        # LoadControl does not create a new load pattern or discard committed material history.
        incr=eps-previous_eps
        if incr<=0.0:
            raise ValueError("Nonzero tabulated knots are too small for the initialization probe")
        ops.integrator("LoadControl",incr)
        if ops.analyze(1)!=0:
            raise RuntimeError(f"ASD {name} failed at |epsilon|={eps}")
        previous_eps = eps
        nominal = sign*nominal_at(rows,eps)
        stresses = [ops.eleResponse(1,"material",point,"stress") for point in range(1,9)]
        strains = [ops.eleResponse(1,"material",point,"strain") for point in range(1,9)]
        if any(len(row)!=6 or not all(map(math.isfinite,row)) for row in stresses+strains):
            raise RuntimeError("Invalid stress or strain tensor")
        max_envelope=max(max_envelope,*(abs(stress[2]-nominal) for stress in stresses))
        max_transverse=max(max_transverse,*(abs(row[i]) for row in stresses for i in (0,1,3,4,5)))
        max_spread=max(max_spread,*(abs(stress[2]-stresses[0][2]) for stress in stresses))
        max_strain=max(max_strain,*(abs(strain[2]-sign*eps) for strain in strains))
        ops.reactions()
        face=sum(ops.nodeReaction(i,3) for i in range(5,9))/side_mm**2
        max_force=max(max_force,abs(face-stresses[0][2]))
        frames.append(dict(strain_zz=sign*eps,input_interpolated_stress_MPa=nominal,
                           axial_stress_MPa=stresses[0][2],face_stress_MPa=face,
                           tension_compression_damage=ops.eleResponse(1,"material",1,"damage")))
    errors = dict(envelope_MPa=max_envelope,transverse_stress_MPa=max_transverse,
                  spatial_stress_spread_MPa=max_spread,face_stress_MPa=max_force,strain=max_strain)
    if max_envelope>2e-5 or max(max_transverse,max_spread,max_force)>2e-7 or max_strain>1e-12:
        raise RuntimeError((name,"uniaxial verification failed",errors))
    ops.wipe()
    return dict(mode=name,cube_side_mm=side_mm,installed_laws=installed,errors=errors,frames=frames)


def check_installed(envelope,runs):
    for run in runs:
        if envelope.length_ref_mm is None or run["cube_side_mm"]==envelope.length_ref_mm:
            for name in BRANCHES:
                original = envelope.branch[name]
                actual = run["installed_laws"][name]
                if len(original)!=len(actual) or any(
                    abs(actual_value-input_value)>1e-8
                    for original_row,actual_row in zip(original,actual,strict=True)
                    for input_value,actual_value in zip(original_row,actual_row,strict=True)
                ):
                    raise RuntimeError(f"Engine altered {name} inputs at the tabulated reference scale")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",required=True,type=Path)
    parser.add_argument("--out",required=True,type=Path)
    parser.add_argument("--cube-mm",type=float,nargs="+",default=[100.0])
    parser.add_argument("--subdivisions",type=int,default=6)
    args=parser.parse_args()
    if args.subdivisions<2 or any(not math.isfinite(dim) or dim<=0 for dim in args.cube_mm):
        parser.error("Supply positive cube sides and at least two subdivisions")
    envelope=load_envelope(args.input)
    runs=[run_case(envelope,side,branch,args.subdivisions) for side in args.cube_mm for branch in BRANCHES]
    check_installed(envelope,runs)
    evidence=dict(status="UNIAXIAL_VERIFIED",engine=ops.version(),engine_source=SOURCE,
                  source=str(args.input),input_sha256=sha256(args.input.read_bytes()).hexdigest(),
                  provenance=envelope.provenance,opensees_args=material_arguments(envelope,1),runs=runs)
    with args.out.open("x",encoding="utf-8") as file:
        file.write(json.dumps(evidence,indent=2,allow_nan=False)+"\n")
    for run in runs:
        print(run["mode"],run["cube_side_mm"], len(run["frames"]),run["errors"])


if __name__=="__main__":
    main()
