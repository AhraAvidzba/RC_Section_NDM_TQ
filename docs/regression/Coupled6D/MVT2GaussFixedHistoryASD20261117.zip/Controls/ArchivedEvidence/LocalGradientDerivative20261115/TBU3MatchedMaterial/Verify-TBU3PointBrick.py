"""Verify direct ASD updates in two nonlinear TBU3 point histories with a brick."""
import argparse
import json
from math import isfinite
from pathlib import Path
import sys

import openseespy.opensees as ops


CORNERS = ((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0),
           (0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1))


def displacement(position, strain):
    x, y, z = position
    ex, ey, ez, gxy, gxz, gyz = strain
    return (ex*x + .5*(gxy*y + gxz*z),
            ey*y + .5*(gxy*x + gyz*z),
            ez*z + .5*(gxz*x + gyz*y))


def brick(install, history, direct, side):
    """Impose nodal displacements corresponding to each strain tensor in the history."""
    ops.wipe()
    ops.model("basic", "-ndm", 3, "-ndf", 3)
    install(1)
    seq = 1
    for tag, corner in enumerate(CORNERS, start=1):
        position = tuple(value*side for value in corner)
        ops.node(tag, *position)
        paths = zip(*(displacement(position, strain) for strain in history), strict=True)
        for component, values in enumerate(paths, start=1):
            ops.timeSeries("Path", seq, "-dt", 1., "-values", 0., *values, "-useLast")
            ops.pattern("Plain", seq, seq)
            ops.sp(tag, component, 1.)
            seq += 1
    ops.element("stdBrick", 1, *range(1,9), 1)
    ops.node(9, -side, 0., 0.)
    ops.node(10, -side, 0., 0.)
    ops.fix(9, 1, 1, 1)
    ops.fix(10, 0, 1, 1)
    ops.uniaxialMaterial("Elastic", 2, 1.)
    ops.element("zeroLength", 2, 9, 10, "-mat", 2, "-dir", 1)
    ops.constraints("Transformation")
    ops.numberer("Plain")
    ops.system("BandGeneral")
    ops.algorithm("Linear")
    ops.integrator("LoadControl", 1.)
    ops.analysis("Static")
    answer = []
    max_phase = max_uniformity = max_reaction = 0.
    for strain in history:
        if ops.analyze(1):
            raise ValueError("The imposed-strain brick did not converge.")
        stresses = [direct.components(ops.eleResponse(1, "material", gp, "stress")) for gp in range(1,9)]
        strains = [direct.components(ops.eleResponse(1, "material", gp, "strain")) for gp in range(1,9)]
        if any(not all(map(isfinite,row)) for row in stresses + strains):
            raise ValueError("The test brick returned a nonfinite component.")
        max_phase = max(max_phase, *(abs(a-b) for field in strains for a,b in zip(field,strain,strict=True)))
        tensor = stresses[0]
        max_uniformity = max(max_uniformity, *(abs(a-b) for field in stresses for a,b in zip(field,tensor,strict=True)))
        ops.reactions()
        for i,value in enumerate((tensor[4],tensor[5],tensor[2]), start=1):
            force = sum(ops.nodeReaction(tag,i) for tag in range(5,9))
            max_reaction = max(max_reaction,abs(force/side**2-value))
        answer.append(tensor)
    return answer, {"strain": max_phase, "gauss_stress_MPa": max_uniformity, "face_stress_MPa": max_reaction}


def verify(history, envelope, install, direct):
    ops.wipe()
    ops.model("basic", "-ndm", 3, "-ndf", 3)
    callable_install = lambda tag: install(envelope, tag)
    callable_install(1)
    direct_responses = [direct.nd_step(1,strain) for strain in history]
    brick_responses, checks = brick(callable_install, history, direct, 125.)
    max_error = max(abs(a-b) for row,ref in zip(direct_responses,brick_responses,strict=True)
                    for a,b in zip(row,ref,strict=True))
    checks["max_brick_vs_direct_MPa"] = max_error
    if checks["strain"] > 1e-12 or max(max_error, checks["gauss_stress_MPa"], checks["face_stress_MPa"]) > 2e-8:
        raise ValueError(f"The TBU3 brick fails verification: {checks}")
    return checks


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("tensors", type=Path)
    p.add_argument("envelope", type=Path)
    p.add_argument("helpers", type=Path)
    p.add_argument("point", type=int, choices=(31,121))
    args = p.parse_args()
    sys.path.insert(0, str(args.helpers))
    from VerifyExplicitAsdEnvelope import load_envelope, install_envelope
    from importlib.machinery import SourceFileLoader
    base = Path(__file__).resolve().parent
    native = SourceFileLoader("tbu3native", str(args.tensors/"Verify-TBU3AcceptedTensors.py")).load_module()
    direct = SourceFileLoader("verifydirect", str(base/"Verify-NDTestAgainstBrick.py")).load_module()
    _, steps = native.load_states(args.tensors/"Native2x6/TBU3_AcceptedTensors.csv")
    law = load_envelope(args.envelope)
    try:
        print(json.dumps({point: verify([states[(point,0)][:6] for _,states in steps.values()],
                                        law, install_envelope, direct) for point in (args.point,)},
                         indent=2, allow_nan=False))
    finally:
        ops.wipe()
