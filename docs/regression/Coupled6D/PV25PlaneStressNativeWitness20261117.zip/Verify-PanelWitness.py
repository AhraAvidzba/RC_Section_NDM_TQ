"""Сверяет принятые нативные поля PV25 с независимым прогнозом деформаций."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile

from PV25PlaneStressOracle import E


CHART_ARCHIVE='PV25NormalChartAndPlaneStress20261117.zip'
CHART_SHA='832C238395CDBC687230495F10D1FED61480AC62874BC70DB3ABAA7155B20B73'


def digest(data):
    return sha256(data).hexdigest().upper()


def verify(repo,root):
    chart=repo/'docs/regression/Coupled6D'/CHART_ARCHIVE
    assert digest(chart.read_bytes())==CHART_SHA
    with ZipFile(chart) as source:
        assert source.read('Replay.Fields.csv')==(root/'Replay.Fields.csv').read_bytes()
        assert source.read('src/Materials/CCoupledConcreteResponse.cls')==(root/'src/Materials/CCoupledConcreteResponse.cls').read_bytes()
    control=run_path(str(root/'Verify-PV25Chart.py'))
    helper=run_path(str(root/'Verify-MixedPanels.py'))
    replay,published=control['read_reference'](repo,root)
    model=repo/'docs/regression/Coupled6D'/control['MATERIAL']
    assert digest(model.read_bytes())==control['MATERIAL_SHA']
    utility={'__name__':'__pinned__'}
    with ZipFile(model) as source:
        exec(compile(source.read('Verify-NativeMaterialHistory.py'),str(model),'exec'),utility)
    ending,pid=helper['validate_owner'](root,utility['read'],False,utility['BOOK'])
    assert ending=='completed'
    prep=utility['read'](root/'Preparation.json')
    for name in ('Guard-IsolatedOffice.ps1','Run-Native.ps1','PV25.Witness.csv','Replay.Fields.csv','tests/modTestMVT2GaussSpan.bas'):
        assert digest((root/name).read_bytes())==prep['inputs'][name]

    independent=control['run_oracle'](replay[20],20,2.5e-5)['states']
    seeds=[';'.join((str(i),*(f'{row[key]:.15g}' for key in ('epsilon_x','epsilon_z','gamma','tau'))))
           for i,row in enumerate(independent,1)]
    assert (root/'PV25.Witness.csv').read_bytes()==('\r\n'.join(seeds)+'\r\n').encode('ascii')
    native=root/'Native'
    records=[row.split(';') for row in (native/'PanelWeights.csv').read_text('ascii').splitlines()]
    attempts=[row[1:] for row in records if row[0]=='ATTEMPT']
    states={int(row[1]):tuple(map(float,row[2:])) for row in records if row[0]=='STATE'}
    assert len(attempts)+len(states)==len(records)
    for i,(index,ok,raw) in enumerate(attempts,1):
        assert int(index)==i and raw==seeds[i-1].split(';')[3]
        assert (i in states)==(ok=='True')
        if ok=='False':
            assert i==len(attempts)
        else:
            assert abs(states[i][3]-float(raw))<1e-16
    trace=(native/'MVTGaussMixed.csv').read_text('cp1251').splitlines()
    assert f'WITNESS_END;{len(states)};{len(attempts)}' in trace
    summary=helper['metrics']('PV25',replay[20]+list(states.values()),published,{})
    history=helper['check_curve'](replay[20]+list(states.values()),published['panels']['PV25'],(E,),20,utility['principal'])
    delta_tau=max((abs(state[9]-independent[i-1]['tau']) for i,state in states.items()),default=0.)
    delta_normal=max((abs(state[0]-independent[i-1]['epsilon_x']) for i,state in states.items()),default=0.)
    return {'excel_pid':pid,'native_fields':len(states),'attempts':len(attempts),'history':history,'summary':summary,
            'maximum_shear_stress_delta_MPa':delta_tau,'maximum_plane_strain_delta':delta_normal,
            'reached_end':len(states)==len(independent), 'experimental_failure_confirmed':False}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args()
    result=verify(args.repo.resolve(),args.root.resolve())
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(result,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('PV25 NATIVE WITNESS OFFLINE PASS',result['native_fields'])
