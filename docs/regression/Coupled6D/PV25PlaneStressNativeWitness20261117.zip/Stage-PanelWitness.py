"""Готовит проверку предсказанных полей PV25 штатным законом VBA."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


HERE=Path(__file__).resolve().parent


def stage(repo,root,proof,guard_pid,guard_ticks):
    base=run_path(str(HERE/'Stage-PanelChart.py'))
    base['stage'](repo,root)
    source=json.loads(proof.read_bytes())
    sha=sha256(proof.read_bytes()).hexdigest().upper()
    assert sha=='624391AF60B1F12D18C3E6BE5285993AB8A7AFCD7DDA672A9FE80FE74ADC1F9E'
    states=source['independent']['20'][1]['states']
    assert len(states)==361
    seeds=root/'PV25.Witness.csv'
    data=[';'.join((str(i),*(f'{row[key]:.15g}' for key in ('epsilon_x','epsilon_z','gamma','tau'))))
          for i,row in enumerate(states,1)]
    seeds.write_bytes(('\r\n'.join(data)+'\r\n').encode('ascii'))
    test=root/'tests/modTestMVT2GaussSpan.bas'
    body=test.read_text(encoding='utf-8-sig')
    body=body.replace('completed = TestPanelCharts(report, tracePath)','completed = TestPanelWitness(report, tracePath)')
    body+=(HERE/'PanelWitness.bas.txt').read_text(encoding='utf-8')
    body.encode('cp1251')
    test.write_bytes(body.replace('\n','\r\n').encode('utf-8-sig'))
    driver=root/'Run-Native.ps1'
    text=driver.read_text(encoding='utf-8')
    anchor="    $env:NDM_MVT_REPLAY=(Resolve-Path -LiteralPath 'Replay.Fields.csv').Path"
    assert text.count(anchor)==1
    driver.write_bytes(text.replace(anchor,anchor+"\n    $env:NDM_PV25_WITNESS=(Resolve-Path -LiteralPath 'PV25.Witness.csv').Path").encode())
    guard=root/'Guard-IsolatedOffice.ps1'
    changed=[test,seeds,driver]
    if guard_pid:
        text=guard.read_text('utf-8')
        guard.write_bytes(text.replace('$protected=@{',f'$protected=@{{{guard_pid}=[long]{guard_ticks};',1).encode())
        changed.append(guard)
    meta=root/'Preparation.json'
    setup=json.loads(meta.read_bytes())
    setup['independent_proof_sha256']=sha
    for item in changed:
        setup['inputs'][item.relative_to(root).as_posix()]=sha256(item.read_bytes()).hexdigest().upper()
    meta.write_bytes((json.dumps(setup,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',type=Path,required=True)
    parser.add_argument('--proof',type=Path,required=True)
    parser.add_argument('--guard-pid',type=int)
    parser.add_argument('--guard-ticks',type=int)
    args=parser.parse_args()
    if bool(args.guard_pid)!=bool(args.guard_ticks):
        parser.error('Нужны оба значения идентификатора процесса.')
    stage(args.repo.resolve(),args.stage.resolve(),args.proof,args.guard_pid,args.guard_ticks)
