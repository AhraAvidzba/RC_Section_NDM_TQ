"""Verify the three measured direction model for MVT2 B at fixed H24 and load."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import argparse
from itertools import product
import csv
import json
import math

import numpy as np
from scipy.optimize import linprog

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def read_native(path,encoding="cp1251"):
    tables=defaultdict(list)
    for marker,*row in csv.reader(path.read_text(encoding=encoding).splitlines(),delimiter=";"):
        tables[marker].append(row)
    return tables


def verified_states(tags):
    fields, stations = {}, defaultdict(dict)
    for name, history, q, *x in tags["B_TANGENT_FIELD"]:
        assert name not in fields and len(x) == 60
        fields[name] = (int(history), float(q), tuple(map(float, x)))
    for name, point, side, *row in tags["B_TANGENT_STATION"]:
        key = int(point), int(side)
        assert key not in stations[name] and len(row) == 19
        stations[name][key] = tuple(map(float, row))
    raw_r = vec(tags, "B_TANGENT_RESIDUAL")
    raw_force = {name: tuple(map(float, row)) for name, *row in tags["B_BOUND_ACTUAL"]}
    raw_norm = {name: float(value) for name, value in tags["B_BOUND_NORM"]}
    output = {}
    assert set(fields) == set(stations) == set(raw_r) == set(raw_force) == set(raw_norm)
    for name, (history, q, x) in fields.items():
        assert history == 24 and len(stations[name]) == 135
        rows, actual, strain_error = reconstruct(x, q, stations[name])
        error = peak(diff(rows, raw_r[name]))
        assert strain_error < 4e-15 and error < 3e-10
        assert max(abs(a-b)/s for a,b,s in zip(actual, raw_force[name], SCALES, strict=True)) < 4e-12
        signed = diff(actual, force(q))
        efforts = tuple(r/s for r, s in zip(signed, SCALES, strict=True))
        residual = (*rows[:56], *efforts)
        gauge_norm = MODULUS*peak(rows[56:])
        tol = 5e-7*(1.+peak(loading(q)))
        near(max(peak(residual), gauge_norm),raw_norm[name], 4e-10)
        assert gauge_norm <= tol
        output[name] = {"q": q, "field": x, "r": residual, "gauge_MPa": gauge_norm, "tol_MPa": tol,
            "signed_force_N_Nmm": signed, "norm_MPa": peak(residual), "reconstruction_error_MPa": error,
            "geometry": {key: row[:3] for key, row in stations[name].items()}}
    return output, stations


def tensor_radius(field, geometry):
    maximum = 0.
    for (_, side), (x, y, _) in geometry.items():
        strain = strain_at(field, operators(x, y), side)
        maximum = max(maximum, peak(s/(1. if i < 3 else math.sqrt(2.)) for i, s in enumerate(strain)))
    return maximum


SOURCES = {
    "gradient": ("MVT2GradientCorrection20261116.zip", "FA407B0A7625E2CC09C240470D205A5C70CE86BDC67AE04443C3B5306B323CA9", "NativeB/MVT2.csv"),
    "measured": ("MVT2MeasuredNative20261116.zip", "0D19814EB74BA458E56B40BF7E5D2E58CE057FDC724CB79A610DC6D56A77BA5E", "Native/MVT2.csv"),
    "axial": ("MVT2AxialNative20261116.zip", "82B8388B418852B9966D02DDCA7A4229A94AE141E7FB97B560F8D9241EB8AA91", "Native/MVT2.csv"),
}


def archive_states(folder, key):
    filename, identity, trace_file = SOURCES[key]
    archive=folder/filename
    assert digest(archive)==identity
    with ZipFile(archive) as evidence:
        trace=evidence.read(trace_file)
    tables=defaultdict(list)
    for tag,*row in csv.reader(trace.decode("cp1251").splitlines(),delimiter=";"):
        tables[tag].append(row)
    return verified_states(tables),sha256(trace).hexdigest().upper()


def tensor(field, geometry):
    return np.array([value/(1. if i<3 else math.sqrt(2.)) for (_,side),(x,y,_) in geometry.items()
        for i,value in enumerate(strain_at(field,operators(x,y),side))])


TWIST_HASH='4920B773CAF518ABDC3B7B553472C66B815E1E203C6FAF8A6577916C01F87962'
H24_HASH='504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8'
RADIUS=1e-8


def gauges(q, geometry):
    values=[[] for _ in range(4)]
    for (point,side),(x,y,area) in geometry.items():
        if point>25 or side!=0:
            continue
        _,shapes,xn,yn=operators(x,y)
        for n,shape in enumerate(shapes):
            w=shape*area/AREA
            u,v,z=q[4+3*n:7+3*n]
            values[0].append(w*u)
            values[1].append(w*v)
            values[2].append(w*z)
            values[3].append(w*(-yn*u+xn*v))
    return np.array(list(map(math.fsum,values)))*MODULUS


def read_twist(archive):
    assert digest(archive)==TWIST_HASH
    with ZipFile(archive) as proof:
        assert sha256(proof.read('Replay.csv')).hexdigest().upper()==H24_HASH
        trace=proof.read('Native/MVT2.csv')
    tags=defaultdict(list)
    for name,*values in csv.reader(trace.decode('cp1251').splitlines(),delimiter=';'):
        tags[name].append(values)
    return verified_states(tags),sha256(trace).hexdigest().upper()


def max_case(constitutive_actions, beta, reference, cap):
    r=reference['r']
    values=[]
    for name,action in constitutive_actions:
        y=r+action@beta
        slack=cap-abs(y[56:])
        assert min(slack)>=-5e-12
        values.append({'axial_and_twist':name,'max_MPa':float(max(abs(y))),
             'governing_row':int(np.argmax(abs(y))+1),'row1_MPa':float(y[0]),'row53_MPa':float(y[52]),
             'signed_effort_N_Nmm':(y[56:]*np.array(SCALES)).tolist(),
             'effort_margin_MPa':slack.tolist(),'full_action_MPa':(action@beta).tolist()})
    return max(s['max_MPa'] for s in values),values


def solve_cell(reference,directions,axes,kind):
    pressure=1e4
    r=reference['r']; geometry=reference['geometry']; tau=reference['tol_MPa']
    caps=np.maximum(abs(r[56:]),tau)
    old_norm=max(abs(r))
    reflected={'AxialPlus':'AxialMinus','AxialMinus':'AxialPlus','TwistPlus':'TwistMinus','TwistMinus':'TwistPlus'}
    secant,axial,twist=axes
    action_options=[]
    for name in (axial,twist):
        plus=(name,directions[name]['r'])
        other=reflected[name]
        action_options.append([plus] if kind=='nominal' else [plus,('reflected '+other,-directions[other]['r'])])
    cases=[((lx,ly),np.stack((directions[secant]['r'],vx,vy),axis=1)) for (lx,vx),(ly,vy) in product(*action_options)]
    row=[]; upper=[]
    for name,u in cases:
        full=u*pressure
        efforts=full[56:]
        if kind=='margin':
            # The benchmark is a decrease of one original tolerance; optimize the smallest force slack.
            row.extend((np.c_[full,np.zeros(62)],np.c_[-full,np.zeros(62)],np.c_[efforts,np.ones(6)],np.c_[-efforts,np.ones(6)]))
            upper.extend((pressure*(old_norm-tau-r),pressure*(old_norm-tau+r),pressure*(caps-r[56:]),pressure*(caps+r[56:])))
        else:
            row.extend((np.c_[full,-np.ones(62)],np.c_[-full,-np.ones(62)],np.c_[efforts,np.zeros(6)],np.c_[-efforts,np.zeros(6)]))
            upper.extend((-pressure*r,pressure*r,pressure*(caps-r[56:]),pressure*(caps+r[56:])))
    shape=np.stack([directions[k]['strain_column']/RADIUS for k in axes],axis=1)
    row.extend((np.array([[1.,1.,1.,0.]]),np.c_[shape,np.zeros(len(shape))],np.c_[-shape,np.zeros(len(shape))]))
    upper.extend((np.array([1.]),np.ones(len(shape)),np.ones(len(shape))))
    constraints=gauges(reference['field'],geometry)
    g=np.stack([gauges(directions[k]['q'],geometry) for k in axes],axis=1)
    row.extend((np.c_[g/tau,np.zeros(4)],np.c_[-g/tau,np.zeros(4)]))
    upper.extend((1.-constraints/tau,1.+constraints/tau))
    coefficient=[0.,0.,0.,-1. if kind=='margin' else 1.]
    solved=linprog(coefficient,A_ub=np.vstack(row),b_ub=np.concatenate(upper),bounds=[(0.,1.)]*3+[(0.,None)],
        method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    if kind=='margin' and not solved.success:
        return None
    assert solved.success,solved.message
    beta=np.maximum(solved.x[:3],0.)
    assert sum(beta)<=1.+2e-12
    optimum,predictions=max_case(cases,beta,reference,caps)
    q=reference['field']+np.stack([directions[n]['q'] for n in axes],axis=1)@beta
    distance=tensor_radius(q-reference['field'],geometry)
    assert distance<=RADIUS+3e-15 and max(abs(gauges(q,geometry)))<=tau
    slack=min(min(s['effort_margin_MPa']) for s in predictions)
    if kind=='margin':
        near(slack,float(solved.x[3]/pressure),6e-12)
        assert optimum<=old_norm-tau+6e-12
    else:
        near(optimum,float(solved.fun/pressure),6e-12)
    return {'kind':kind,'axes':axes,'coefficients':beta.tolist(),'shape_component_peak':distance,
        'linear_worst_case_MPa':optimum,'decrease_MPa':float(old_norm-optimum),'decrease_over_original_tol':float((old_norm-optimum)/tau),
        'smallest_signed_effort_margin_MPa':slack,'gauge_MPa':float(max(abs(gauges(q,geometry)))),
        'affine_predictions':predictions,'coordinates':q.tolist()}


def run(evidence, twist_archive, report, candidates):
    (gradient,_), gradient_hash=archive_states(evidence,'gradient')
    (measured,_), measured_hash=archive_states(evidence,'measured')
    (axial,_), axial_hash=archive_states(evidence,'axial')
    (twist,station), twist_hash=read_twist(twist_archive)
    centre=twist['Anchor']
    for n in ('TwistPlus/Rollback','TwistMinus/Rollback','Restored24'):
        assert twist[n]==twist['Base24'] and station[n]==station['Base24']
    for u in (axial['Anchor'],measured['MeasuredCombination']):
        assert u['q']==centre['q'] and u['geometry']==centre['geometry']
        assert peak(diff(u['field'],centre['field']))<3e-15 and peak(diff(u['r'],centre['r']))<4e-10
    base={**centre,'r':np.array(centre['r']),'field':np.array(centre['field'])}
    endpoints={'Line':measured['MeasuredLine'],'Large':gradient['BothBest'],'AxialPlus':axial['AxialCompPlus'],
        'AxialMinus':axial['AxialCompMinus'],'TwistPlus':twist['TwistPlus'],'TwistMinus':twist['TwistMinus']}
    directions={}
    for name,state in endpoints.items():
        assert state['q']==base['q'] and state['geometry']==base['geometry']
        increment=np.array(state['field'])-base['field']
        vector=np.array(state['r'])-base['r']
        directions[name]={'q':increment,'r':vector,'strain_column':tensor(increment,base['geometry'])}
    only_grid=list(product(('Line','Large'),('AxialPlus','AxialMinus'),('TwistPlus','TwistMinus')))
    results={kind:[solve_cell(base,directions,axes,kind) for axes in only_grid] for kind in ('nominal','robust')}
    best_nom,best_rob=(min(rows,key=lambda row:row['linear_worst_case_MPa']) for rows in results.values())
    assert best_nom['axes']==best_rob['axes']==('Large','AxialPlus','TwistPlus')
    margin=solve_cell(base,directions,best_rob['axes'],'margin')
    assert margin and margin['smallest_signed_effort_margin_MPa']>0.
    # All three weighted tensor directions must have nonzero independent singular values.
    U=np.stack([directions[n]['strain_column']/np.linalg.norm(directions[n]['strain_column']) for n in best_rob['axes']],axis=1)
    sing=np.linalg.svd(U,compute_uv=False)
    assert sing.min()>0.1
    even={}
    for stem in ('Axial','Twist'):
        u=directions[stem+'Plus']['r']+directions[stem+'Minus']['r']
        even[stem]={'peak_MPa':float(max(abs(u))),'governing_row':int(np.argmax(abs(u))+1)}
    tolerance=base['tol_MPa']
    assert best_nom['linear_worst_case_MPa']>tolerance and best_rob['decrease_MPa']>tolerance
    output={'trace_sha256':{'325':gradient_hash,'334':measured_hash,'338':axial_hash,'twist':twist_hash},
        'q_H24_kN':base['q'],'H24_sha256':H24_HASH,'reference_norm_MPa':base['norm_MPa'],'original_tolerance_MPa':tolerance,
        'input_pure_twist_archive_sha256':TWIST_HASH,'station_shape_component_cap':RADIUS,
        'original_six_caps_MPa':np.maximum(abs(base['r'][56:]),tolerance).tolist(),
        'three_measurement_singular_values':sing.tolist(),'measured_axis_even_residual':even,
        'nominal_minimum':best_nom,'reflected_sign_minimum':best_rob,'maximum_cap_margin_at_one_tolerance_decrease':margin,
        'all_signed_cells':{key:[{k:row[k] for k in ('kind','axes','coefficients','linear_worst_case_MPa','decrease_MPa','smallest_signed_effort_margin_MPa')} for row in values]
                            for key,values in results.items()},
        'affine_model_reaches_original_tolerance':False,'mixed_interaction_measured':False,'proposed_fields_have_native_equilibrium':False,
        'scope':'Only frozen directional measurements are native. Reflected scenarios test sign sensitivity, not mixed nonlinear bounds.'}
    report.write_text(json.dumps(output,indent=2)+'\n',encoding='utf8')
    with candidates.open('w',encoding='ascii',newline='') as stream:
        writer=csv.writer(stream,delimiter=';',lineterminator='\r\n')
        writer.writerow(['field_label','Qy_kN','predicted_residual_MPa',*[f'q{i}' for i in range(1,61)]])
        for name,result in (('MeasuredRobust',best_rob),('MeasuredMargin',margin)):
            writer.writerow([name,base['q'],result['linear_worst_case_MPa'],*result['coordinates']])
    print(report.name,digest(report)); print(candidates.name,digest(candidates))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence_directory',type=Path)
    parser.add_argument('twist_native_archive',type=Path)
    parser.add_argument('report_json',type=Path)
    parser.add_argument('candidate_csv',type=Path)
    a=parser.parse_args()
    run(a.evidence_directory,a.twist_native_archive,a.report_json,a.candidate_csv)
