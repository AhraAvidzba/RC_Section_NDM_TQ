# Первичные источники

- Kagermanov и Ceresa, 2018, “3D Fiber-Based Frame Element with Multiaxial Stress Interaction for RC Structures”. DOI 10.1155/2018/8596970. Авторы публикуют статью с лицензией CC BY. Байт-в-байт копия из literature/Coupled6D в проекте приложена в этой папке. SHA-256 7D9B0FD7D0BC62E5D77FA7A7727733BC109EF8C3AD33149E2F50B7F4C64F08B7. [Статья](https://doi.org/10.1155/2018/8596970)
- Popovics, 1973, “A numerical approach to the complete stress-strain curve of concrete”. DOI 10.1016/0008-8846(73)90096-3. Авторское уравнение и его производная просмотрены в доступном представлении текста первичной статьи. Кривая и нормировка показателя воспроизведены в README и коде. Загрузка из зеркала вернула HTTP 403. Исходный PDF и его SHA-256 отсутствуют. Издатель Elsevier, свободная лицензия полного текста не подтверждена. [Издатель](https://doi.org/10.1016/0008-8846(73)90096-3) · [Просмотр исходной статьи](https://studylib.net/doc/29018448/0008-8846-2873-2990096-3)
- Kupfer, Hilsdorf и Rüsch, 1969, “Behavior of Concrete Under Biaxial Stresses”. DOI 10.14359/7388. Использовано только отношение 1,16, сообщённое в опубликованной авторами аннотации ACI. Загруженный PDF не нужен для этого численного ориентира. Свободная лицензия полного текста не подтверждена. [Аннотация ACI](https://www.concrete.org/publications/internationalconcreteabstractsportal.aspx?id=7388&m=details)

Редакция исходников НДМ при подготовке fe48eeb.

- CCoupledConcreteEnvelope.cls SHA-256 C82EE69DF1582CA307FCBD30A42335FF6CFA3250B09481833B9033CFC3FEE8E8
- CCoupledConcreteResponse.cls SHA-256 92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C
- modCoupledConcreteTensor.bas SHA-256 E7739A8C9200C6F5F56AF5AEA5E226101AF48DE6FDA00ADD29AFB7799F29C30B

