"""Independent fixed-crack material patch and Barcelona proportional stress-ray checks."""
import json
from hashlib import sha256
from math import cos, exp, hypot, log, pi, sin, sqrt
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
FC, EPS0 = 29., .002  # Kagermanov–Ceresa §5.1, Table 1, specimen S1.
E, NU, FT, GC, GT, LENGTH = 30000., .2, 3., 80., .12, 125.  # Fixed diagnostic, MPa, N/mm, mm.
FC0 = .6 * FC
ALPHA, GAMMA = .12, 3.
FRICTION, DILATION, ECCENTRICITY = 65.*pi/180., 32.*pi/180., .1
N = E/(E-FC/EPS0)
DC_PEAK = .423*(1.-FC/(E*EPS0))
KC_PEAK = EPS0-FC/((1.-DC_PEAK)*E)

def eq_close(a,b,tol=3e-10):
    assert abs(a-b) <= tol*max(1.,abs(a),abs(b)), (a,b)

def rot(angle):
    a=angle*pi/180.
    return ((cos(a),-sin(a),0.),(sin(a),cos(a),0.),(0.,0.,1.))

def transpose(a):
    return tuple(zip(*a,strict=True))

def multiply(a,b):
    return tuple(tuple(sum(x*y for x,y in zip(u,v,strict=True)) for v in transpose(b)) for u in a)

def rotate(a,r):
    return multiply(multiply(r,a),transpose(r))

def diag(a):
    return tuple(tuple(a[i] if i==j else 0. for j in range(3)) for i in range(3))

def power(a,b):
    return sum(x*y for row_a,row_b in zip(a,b,strict=True) for x,y in zip(row_a,row_b,strict=True))

def spectrum_a2(a):
    x,y=a[0][0],a[1][1]
    spread=hypot((x-y)*.5,a[0][1])
    return tuple(sorted(((x+y)*.5-spread,(x+y)*.5+spread,a[2][2])))

def popovics(strain):
    v=abs(strain)/EPS0
    return -FC*N*v/(N-1.+v**N)

def orthogonal_softening(ej,ek):
    lateral=(max(ej,0.)+max(ek,0.))*.5
    return min(1.,1./(.8+.34*lateral/EPS0))

def fixed_crack(strain, crack, confinement):
    """Patch settings restrict the open direction to prescribed zero concrete tension."""
    assert confinement in (1.,1.1)
    local=rotate(strain,transpose(crack))
    assert max(abs(local[2][i]) for i in range(3)) < 1e-14  # prescribed e_zz=0 in reduced patch
    ex,ey=local[0][0],local[1][1]
    assert ex < 0. and ey >= 0.
    beta=orthogonal_softening(ey,0.)
    sx=confinement*beta*popovics(ex)
    sy=0.
    G=.5*(sx-sy)/(ex-ey)
    gamma=2.*local[0][1]
    # Eq. (16) with prescribed diagnostic aggregate size 16 mm and crack spacing 100 mm.
    w=100.*ey
    vmax=.18*sqrt(FC)/(.31+24.*w/(16.+16.))
    trial_shear=G*gamma
    shear=max(-vmax,min(vmax,trial_shear))
    local_stress=((sx,shear,0.),(shear,sy,0.),(0.,0.,0.))
    stress=rotate(local_stress,crack)
    eq_close(power(stress,strain),power(local_stress,local))
    return dict(strain=strain,stress=stress,crack_strain=local,crack_stress=local_stress,
                beta=beta,confinement=confinement,G_MPa=G,crack_width_mm=w,
                shear_cap_MPa=vmax,unlimited_shear_MPa=trial_shear)

def envelope(k,c0,cmax,kmax,G):
    density=G/LENGTH
    ascending=.5*(c0+cmax)*kmax
    damage_at_reference=DC_PEAK if kmax>0. else .5
    damage_reference=kmax if kmax>0. else log(2.)*density/cmax
    d=1.-exp(log(1.-damage_at_reference)*k/damage_reference)
    if k<kmax:
        nominal=c0+(cmax-c0)*k/kmax
        consumed=.5*(c0+nominal)*k
    else:
        softening=cmax/(density-ascending)
        remaining=exp(-softening*(k-kmax))
        nominal=cmax*remaining
        consumed=ascending+(density-ascending)*(1.-remaining)
    return nominal/(1.-d),d,consumed/density

def invariants(s):
    tr=sum(s)
    q=sqrt(1.5*sum((x-tr/3.)**2 for x in s))
    return tr,q,max(s)

def pressure_dilation(kt,kc,rt,tr,q):
    w=min(1.,1.-(1.-(1.+20.*rt)*kt)*(1.-(1.-rt)*kc))
    assert w>=0.
    confinement=min(1.,exp(-(1.+tr/q)*tr/FC))
    sf,sp=sin(FRICTION*confinement),sin(DILATION*confinement)
    vol=(sf-sp)/(1.-sf*sp)
    cur=2.*sqrt(w)/(1.+w)*sf
    if cur<=vol:
        return 0.
    sd=(cur-vol)/(1.-cur*vol)
    return sd/sqrt(1.-sd*sd)

def yield_value(components, cc,ct):
    tr,q,hi=invariants(components)
    k=cc/ct*(1.-ALPHA)-(1.+ALPHA) if hi>0. else GAMMA
    return (ALPHA*tr+q+k*hi)/(1.-ALPHA)-cc

def state_at_history(direction, ep, tension, compression, dk):
    tr_dir,q_dir,high_dir=invariants(direction)
    rt=sum(max(v,0.) for v in direction)/sum(abs(v) for v in direction)
    cc,dc,kc=envelope(compression,FC0,FC,KC_PEAK,GC)
    def evaluate(kt_plastic):
        ct,dt,kt=envelope(kt_plastic,FT,FT,0.,GT)
        coefficient=cc/ct*(1.-ALPHA)-(1.+ALPHA) if high_dir>0. else GAMMA
        amplitude=(1.-ALPHA)*cc/(ALPHA*tr_dir+q_dir+coefficient*high_dir)
        s=tuple(v*amplitude for v in direction)
        tr,q,hi=invariants(s)
        dilation=pressure_dilation(kt,kc,rt,tr,q)
        radius=hypot(ECCENTRICITY*dilation*FT,sqrt(2./3.)*q)
        flow=tuple((v-tr/3.)/radius+dilation for v in s)
        assert min(flow)<0. and 0.<=rt<1.
        increment=dk/(-(1.-rt)*min(flow))
        step=tuple(increment*d for d in flow)
        next_tension=tension+max(0.,max(step))*rt
        return s,step,next_tension,dilation,ct,dt,kt
    if rt==0. or dk==0.:
        new_tension=tension
    else:
        # Complete the scalar consistency equation, then re-evaluate the constitutive residuals.
        low=tension
        high=low+dk
        while evaluate(high)[2]>high:
            high=low+2.*(high-low)
            assert high<.02
        for _ in range(65):
            mid=(low+high)*.5
            if evaluate(mid)[2]>mid:
                low=mid
            else:
                high=mid
        new_tension=(low+high)*.5
    s,step,next_tension,dilation,ct,dt,kt=evaluate(new_tension)
    eq_close(next_tension,new_tension,1e-13)
    eq_close(yield_value(s,cc,ct),0.)
    eq_close(-(1.-rt)*min(step),dk,1e-13)
    old_ep=ep
    ep=tuple(x+y for x,y in zip(old_ep,step,strict=True))
    elastic=tuple(((1.+NU)*x-NU*sum(s))/E for x in s)
    total=tuple(x+y for x,y in zip(elastic,ep,strict=True))
    nominal_scale=(1.-rt*dt)*(1.-dc)
    nominal=tuple(nominal_scale*x for x in s)
    return dict(total_strain=total, plastic_strain=ep, plastic_increment=step, effective_stress=s,
                nominal_stress=nominal, tension_coordinate=new_tension, compression_coordinate=compression,
                tension_energy=kt,compression_energy=kc,dilation=dilation,
                trial_check_needed=dk>0., plastic_work_MPa=power(diag(s),diag(step)))

def path(direction, steps):
    states=[state_at_history(direction,(0.,0.,0.),0.,0.,0.)]
    for i in range(1,steps+1):
        old=states[-1]
        compression=i*2.*KC_PEAK/steps
        dk=compression-old["compression_coordinate"]
        s=state_at_history(direction,old["plastic_strain"],old["tension_coordinate"],compression,dk)
        old_cc=envelope(old["compression_coordinate"],FC0,FC,KC_PEAK,GC)[0]
        old_ct=envelope(old["tension_coordinate"],FT,FT,0.,GT)[0]
        old_residual=yield_value(s["effective_stress"],old_cc,old_ct)
        # Check the elastic trial implied by this strain and previous accepted plastic history.
        delta=tuple(x-y for x,y in zip(s["total_strain"],old["plastic_strain"],strict=True))
        bulk=E/(3.*(1.-2.*NU)); two_g=E/(1.+NU)
        trial=tuple(bulk*sum(delta)+two_g*(x-sum(delta)/3.) for x in delta)
        trial_residual=yield_value(trial,old_cc,old_ct)
        assert trial_residual>0., (direction,i,trial_residual,old_residual)
        tr_trial,q_trial,_=invariants(trial)
        tr_end,q_end,_=invariants(s["effective_stress"])
        assert 0. < q_end <= q_trial
        for a,b in zip(s["effective_stress"],trial,strict=True):
            eq_close(a-tr_end/3., (b-tr_trial/3.)*q_end/q_trial)
        assert s["plastic_work_MPa"]>=0., (direction,i,s["plastic_work_MPa"])
        assert s["tension_energy"]>=old["tension_energy"]
        assert s["compression_energy"]>=old["compression_energy"]
        st=diag(s["nominal_stress"])
        sr=rotate(st,rot(37.))
        for orig,rotated in zip(spectrum_a2(st),spectrum_a2(sr),strict=True):
            eq_close(orig,rotated)
        s["elastic_predictor_yield_residual_MPa"]=trial_residual
        states.append(s)
    return states

def prove():
    diag_strain=diag((-.002,.004,0.))
    pure=fixed_crack(diag((-.002,0.,0.)),rot(0.),1.)
    tensile=fixed_crack(diag_strain,rot(0.),1.)
    confinement=fixed_crack(diag((-.002,0.,0.)),rot(0.),1.1)
    coupled=fixed_crack(diag_strain,rot(0.),1.1)
    eq_close(pure["crack_stress"][0][0],-29.)
    eq_close(tensile["crack_stress"][0][0],-29./1.14)
    eq_close(confinement["crack_stress"][0][0],-31.9)
    eq_close(coupled["crack_stress"][0][0],-31.9/1.14)
    eq_close((popovics(-1e-9)/-1e-9),E,1e-5)
    angle_controls={}
    for relative in (2.,15.,-15.):
        actual_strain=rotate(diag_strain,rot(relative))
        fixed=fixed_crack(actual_strain,rot(0.),1.1)
        co_rotating=fixed_crack(actual_strain,rot(relative),1.1)
        global_rotation=rot(37.)
        same=fixed_crack(rotate(actual_strain,global_rotation),global_rotation,1.1)
        expected=rotate(fixed["stress"],global_rotation)
        for computed,predicted in zip(same["stress"],expected,strict=True):
            for a,b in zip(computed,predicted,strict=True):
                eq_close(a,b)
        assert abs(fixed["crack_stress"][0][1])>0.
        assert abs(co_rotating["crack_stress"][0][1])<1e-12
        if abs(relative)==15.:
            eq_close(abs(fixed["crack_stress"][0][1]),fixed["shear_cap_MPa"])
        else:
            eq_close(fixed["crack_stress"][0][1],fixed["unlimited_shear_MPa"])
        angle_controls[str(relative)]={"fixed_crack":fixed,"crack_co_rotates":co_rotating}
    eq_close(angle_controls["15.0"]["fixed_crack"]["crack_stress"][0][1],
             -angle_controls["-15.0"]["fixed_crack"]["crack_stress"][0][1])
    out={}
    directions={"Free":(-1.,0.,0.), "CompressEqual":(-1.,-1.,0.),
                "CompressQuarter":(-1.,-.25,0.), "TransverseTension":(-1.,.05,0.),
                "Combined3D":(-1.,.05,-.15)}
    for name, direction in directions.items():
        coarse=path(direction,200)
        fine=path(direction,400)
        result=dict(direction=direction,plane_stress=direction[2]==0.)
        for key, i in (("onset",0),("uniaxial_compression_energy_peak",200),
                      ("later_history",400)):
            result[key]=fine[i]
        result["grid_comparison_max_axial_stress_gap_MPa"]=max(abs(a["nominal_stress"][0]-b["nominal_stress"][0])
                                                               for a,b in zip(coarse,fine[::2],strict=True))
        result["nominal_axial_peak_on_this_ray_MPa"]=max(-s["nominal_stress"][0] for s in fine)
        result["max_tension_energy"]=fine[-1]["tension_energy"]
        if result["plane_stress"]:
            assert all(s["nominal_stress"][2]==0. for s in fine)
        if name=="Combined3D":
            assert all(s["nominal_stress"][2]<0.<s["nominal_stress"][1] for s in fine)
        out[name]=result
    onset=lambda name: -out[name]["onset"]["nominal_stress"][0]
    nominal_at_calibration=lambda name: -out[name]["uniaxial_compression_energy_peak"]["nominal_stress"][0]
    eq_close(onset("Free"),FC0)
    eq_close(nominal_at_calibration("Free"),FC)
    eq_close(onset("CompressEqual")/onset("Free"),(1.-ALPHA)/(1.-2.*ALPHA))
    eq_close(nominal_at_calibration("CompressEqual")/FC,(1.-ALPHA)/(1.-2.*ALPHA))
    assert nominal_at_calibration("TransverseTension")<FC<nominal_at_calibration("CompressEqual")
    # Derive valid NDM strain inputs on a selected inverse ray, then prescribe exactly
    # those two in-plane strain components to both fixed-crack confinement scenarios.
    transfer=path((-1.,.2,0.),400)
    matched=[]
    for i in (0,100,200,300,400):
        n=transfer[i]
        ex,ey,ez=n["total_strain"]
        assert ex < 0. < ey and n["nominal_stress"][2]==0.
        reference_free=fixed_crack(diag((ex,ey,0.)),rot(0.),1.)
        reference_confined=fixed_crack(diag((ex,ey,0.)),rot(0.),1.1)
        # Alternative beta sensitivity provides explicit traceability of epsilon_z closure.
        beta_using_ndm_ez=orthogonal_softening(ey,ez)
        row=dict(step=i,ex=ex,ey=ey,ndm_ez=ez,ndm_sx_MPa=n["nominal_stress"][0],
                 ndm_sy_MPa=n["nominal_stress"][1],ndm_sz_MPa=n["nominal_stress"][2],
                 ndm_dilation=n["dilation"],fixed_crack_beta=reference_free["beta"],
                 fixed_crack_free_MPa=reference_free["crack_stress"][0][0],
                 fixed_crack_confined_MPa=reference_confined["crack_stress"][0][0],
                 beta_if_ndm_ez_imposed=beta_using_ndm_ez,
                 fixed_crack_free_at_ndm_ez_MPa=beta_using_ndm_ez*popovics(ex))
        eq_close(row["fixed_crack_confined_MPa"],1.1*row["fixed_crack_free_MPa"])
        matched.append(row)
    assert matched[2]["fixed_crack_beta"]<1.
    return dict(fixed_crack_controls=dict(free=pure,open_crack=tensile,confinement=confinement,
                                both=coupled,rotation=angle_controls),
                NDM_proportional_rays=out, matched_in_plane_strain_checks=matched,
                common=dict(f_c_MPa=FC,peak_compressive_strain=EPS0,E_MPa=E,nu=NU,f_t_MPa=FT,
                           Gc_N_mm=GC,Gt_N_mm=GT,localization_length_mm=LENGTH,popovics_n=N))

if __name__=="__main__":
    path_out=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/"AxisPatchChecks.json"
    proof=prove()
    path_out.write_text(json.dumps(proof,indent=2,allow_nan=False)+"\n","utf-8")
    print(sha256(path_out.read_bytes()).hexdigest().upper())
    for name, r in proof["NDM_proportional_rays"].items():
        print(name, -r["onset"]["nominal_stress"][0],-r["uniaxial_compression_energy_peak"]["nominal_stress"][0],
              r["uniaxial_compression_energy_peak"]["total_strain"], r["nominal_axial_peak_on_this_ray_MPa"],
              r["grid_comparison_max_axial_stress_gap_MPa"])

