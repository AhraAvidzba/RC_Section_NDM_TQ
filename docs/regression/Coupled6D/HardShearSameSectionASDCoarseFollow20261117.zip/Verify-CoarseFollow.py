"""Audit exact-prefix HardShear ASD continuation and discarded zero increments."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WIRE='5220D142B5A0EA8F87DDA0E358AC46320B76E20EC0C02B360B6A01F8133F39AF'
PRIOR=('HardShearSameSectionASDCoarsePilot20261117.zip','67DE39B8362615DC3045BF8F0DF18D9859B75478EA8386F8751C4E2B78CAB904')


def sha(b):
    return sha256(b).hexdigest().upper()


def signed_range(values):
    return [min(values),max(values)]


def limits(info,ray,lam,area,length):
    scales=(area,area*length,area*length,area*length,area,area)
    force_error=[(r-lam*d)/s for r,d,s in zip(info['signed_six'],ray,scales,strict=True)]
    return {'weak_signed_range_MPa':signed_range(info['weak'][:56]),
            'gauge_signed_scaled_range_MPa':signed_range([30000.*v for v in info['weak'][56:]]),
            'six_signed_force_errors_MPa':force_error,'six_integrated_N_Nmm':info['signed_six'],
            'max_all60_and_six_MPa':info['combined_norm_MPa'],'tolerance_MPa':info['original_tolerance_MPa']}


def main(repo):
    source=runpy.run_path(str(HERE/'HardShearSameSection.py'))
    raw=(HERE/'CoarseFollowDetailed.json.gz').read_bytes(); assert sha(raw)==WIRE
    proof=json.loads(gzip.decompress(raw))
    with source['archived'](repo,PRIOR) as z:
        accepted_raw=z.read('CoarsePilot.json.gz')
        assert sha(accepted_raw)==source['PILOT']==proof['frozen_prefix_wire_sha256']
    first=json.loads(gzip.decompress(accepted_raw))
    assert first['identity']==proof['identity'] and first['ray_N_Nmm']==proof['ray_N_Nmm']
    assert first['material_command']==proof['material_command']
    assert proof['match_to_archived_material_source_sha256']==source['MATERIAL']
    assert sha((repo/'tools/validate_opensees_hardshear.py').read_bytes())==source['MATERIAL']
    flags=[q for q in proof['material_command'] if isinstance(q,str)]
    assert flags==['ASDConcrete3D','-Te','-Ts','-Td','-Ce','-Cs','-Cd','-tangent']
    assert proof['runtime']=='3.8.0' and proof['numpy']=='2.3.5'
    assert proof['exact_replayed_accepted_fields']==6 and proof['total_exact_cold_history_with_rejected_excursions']==9
    assert proof['targets_after_exact_prefix']==list(source['FOLLOW'])
    assert proof['premature_stop'] is None and not proof['physical_limit_established']
    geo,dirs,area,length,logged,_=source['fixture'](repo)
    op=source['operators'](geo,area,length)
    assert sha(source['packed'](op))==proof['identity']['exact_built_operator_sha256']
    verify=source['verify_rows']; ray=source['RAY']; report=[]
    for idx,item in enumerate(first['accepted_targets']+proof['accepted_targets']):
        lam=item['lambda']; field=item['field']; raw_net=item['net_stress_MPa']; steel=item['steel_stress_MPa']
        exact=verify(geo,dirs,area,length,op,field,raw_net,lam,steel)
        assert exact==item['independent']
        if idx<6:
            continue
        virgin=item['post_commit_new_zero_increment']; new=virgin['net_stress_MPa']; assert len(new)==3
        recomputed=verify(geo,dirs,area,length,op,field,new,lam,steel,False)
        assert recomputed==virgin['independent']
        delta=[b-a for t,s in zip(raw_net,new,strict=True) for aa,bb in zip(t,s,strict=True) for a,b in zip(aa,bb,strict=True)]
        assert max(map(abs,delta))==item['post_commit_zero_increment_stress_difference_MPa']
        assert item['immediate_committed_stress_identical']
        state=item['ASD_concrete_indicators']; data=state['raw_indicators']
        assert len(data)==75 and all(len(v)==6 for v in data)
        maximum=list(map(max,zip(*data,strict=True)))
        assert [maximum[i:i+2] for i in (0,2,4)]==state['native_max_indicator_each_T_C']
        assert state['table_peak_T_C_ordinates']==[.0001,.002]
        hits=[sum(v[j]>limit for v in data) for j,limit in enumerate((.0001,.002))]
        assert hits==state['number_above_tension_compression_table_peak']
        assert hits=={.625:[0,0],.75:[3,0],.875:[9,0]}[lam]
        assert (recomputed['combined_norm_MPa']<recomputed['original_tolerance_MPa'])==(lam==.625)
        report.append({'lambda':lam,'exact_accepted_transition':limits(exact,ray,lam,area,length),
            'immediate_committed_stress_identical':True,
            'new_zero_increment_trial_discarded':limits(recomputed,ray,lam,area,length),
            'signed_zero_trial_stress_change_extremes_MPa':signed_range(delta),
            'concrete_states_above_T_C_table_peaks':hits,'max_equivalent_T_C':maximum[:2],
            'max_plastic_T_C':maximum[2:4],'max_damage_T_C':maximum[4:],
            'largest_absolute_elastic_steel_MPa':max(abs(v) for row in steel for v in row)})
    assert len(report)==3 and [e['lambda'] for e in report]==list(source['FOLLOW'])
    return {'status':'PASS','same_deck_signed_ray':ray,'native_stress_and_state_wire_sha256':WIRE,
            'archived_original_operator_sha256':proof['identity']['exact_built_operator_sha256'],
            'exact_committed_transitions_replayed_from_virgin':9,'independent_reassembled_new_transitions':3,
            'matched_ASD_command_flags':flags,'explicit_integration_and_viscosity_overrides_absent':True,
            'new_zero_increment_trials_committed':False,'physical_limit_established':False,'states':report}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--report',type=Path)
    options=parser.parse_args()
    result=main(options.repo)
    data=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if options.report:
        with options.report.open('xb') as out: out.write(data)
    print('HARDSHEAR_MATCHED_ASD_SAME_SECTION_FOLLOW_OFFLINE_PASS',sha(data),result['states'][-1]['lambda'])
