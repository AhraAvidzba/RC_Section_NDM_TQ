"""Independently bound the H45 material state and compare physical benchmark endpoints."""
from pathlib import Path
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
import json,math,sys
import fitz
import numpy as np
from scipy.interpolate import BSpline, PPoly

root=Path(sys.argv[1]).resolve(strict=True)
out=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).with_name("PhysicalEndpointChecks.json")
assets=root/"docs/regression/Coupled6D"
lit=root/"literature/Coupled6D"
receipts={}
def digest(p):return sha256(p.read_bytes()).hexdigest().upper()
def pin(p):
    receipts[p.relative_to(root).as_posix()]=digest(p)
    return p
def archive(n):return ZipFile(pin(assets/n))
def pin_pdf(n,expected):
    p=pin(lit/n)
    assert digest(p)==expected
    return fitz.open(p)
def value(p,a):
    return json.loads(p.read(a))
def peak(x):return np.max(np.abs(x))
def tensor(x):
    return x[...,np.array([0,3,4,3,1,5,4,5,2])].reshape((*x.shape[:-1],3,3))

def archive_h45():
    with archive("KaniCommitNear48Portable.zip") as z:
        r=dict(np.load(BytesIO(z.read("MeasuredSamples.npz")),allow_pickle=False))
        proof=value(z,"Commit48Verification.json")
    with archive("KaniHydrostaticApex46Portable.zip") as z:
        g=np.loadtxt(BytesIO(z.read("GeometryAndDirections.csv")),delimiter=";")
    assert np.array_equal(r["geometry"],g[:,:3]) and len(g)==184
    names=list(r["names"])
    index=names.index("Committed45")
    arr=r["stations"][r["station_index"][index]]
    assert proof["fixedFieldActuallyCommitted"]
    assert proof["exactZeroStepReproduced"]
    L=float(r["length"])
    Ax=np.zeros((40,6))
    Ax[:,:4]=g[144:,3:]
    sl=2.e5*np.einsum("spi,pi->sp",arr[:,144:,:6],Ax)
    assert np.all(abs(sl)<np.r_[np.full(8,442.),np.full(32,400.)])
    integrated=np.einsum("p,p->",g[:,2],arr[1,:,11])
    assert abs(integrated-proof["committedQy_N"]) < .10
    strains=arr[:,:,:6].copy()
    strains[:,:,3:]*=.5
    ev=np.linalg.eigvalsh(tensor(strains))
    sig=np.linalg.eigvalsh(tensor(arr[:,:144,6:]))
    ene=np.asarray(proof["energiesByStation_minus0plus"]["Committed45"])
    fc,ft,ec,eps,l=28.2,1.75,25600.,.0022,125.
    GT=.073*fc**.18
    GC=(fc/ft)**2*GT
    pp=eps-fc/(ec*(1.-.423*(1.-fc/(ec*eps))))
    kpeak=.8*fc*pp/(GC/l)
    assert np.max(ene[:,:144,1])<kpeak
    area=305.*610.
    proper=dict(Qy_request_N=proof["committedQy_N"],Qy_integrated_N=float(integrated),mean_gamma=proof["committedGamma"],
         Qy_adjoint_uncertainty_N=proof["independentlyRepeatedAdjoint_N"]["FromHistory45"],
         paired_Steel_nominal_max_MPa=dict(longitudinal=float(peak(sl[:,:8])),transverse=float(peak(sl[:,8:]))),
         concrete_nominal_min_principal_MPa=float(np.min(sig)),
         concrete_strain_principal_min_sampled=float(np.min(ev[:,:144])),
         compressive_k_peak=float(kpeak),max_compressive_k=float(np.max(ene[:,:144,1])),
         max_tensile_k=float(np.max(ene[:,:144,0])),
         min_compressive_stress_over_fc=float(-np.min(sig)/fc),
         normalized_stress_gross_MPa=float(integrated/area),
         observed_residual=proof["normAfterCommit_MPa"])
    return arr,g,r["fields"][index][2:],L,proper

def strain_splines(field,L):
    span_x,span_y=152.5,305.
    tx=np.r_[[-span_x]*4,0.,[span_x]*4]
    ty=np.r_[[-span_y]*4,0.,[span_y]*4]
    bx=BSpline(tx,np.eye(5),3)
    by=BSpline(ty,np.eye(5),3)
    bdx=bx.derivative()
    bdy=by.derivative()
    u,v,w=(field[4+i:79:3].reshape(5,5) for i in range(3))
    def evaluate(x,y,side=0):
        x,y=np.broadcast_arrays(x,y)
        bxv,bxd,byv,byd=bx(x),bdx(x),by(y),bdy(y)
        def arg(a,b,coeff):return L*np.einsum("...i,ij,...j->...",a,coeff,b)
        e0,kx,ky, twist=field[:4]+side*.001*field[79:83]
        return np.stack((arg(byv,bxd,u),arg(byd,bxv,v),e0+(kx*y+ky*x)/L,
                         arg(byd,bxv,u)+arg(byv,bxd,v),
                         arg(byv,bxd,w)-twist*y/L,
                         arg(byd,bxv,w)+twist*x/L),axis=-1)
    def steel_bounds():
        values=[]
        for fixed in (-122.5,122.5):
            c=v@bx(fixed)
            pp=BSpline(ty,c,3).derivative()
            critical=PPoly.from_spline(pp).derivative().roots(extrapolate=False)
            coords=np.r_[[-275.,0.,275.],critical[np.isfinite(critical)&(critical>=-275.)&(critical<=275.)]]
            i=np.argmax(abs(pp(coords)))
            values.append(dict(leg="vertical",X_mm=fixed,Y_mm=float(coords[i]),strain=float(L*pp(coords[i]))))
        for fixed in (-275.,275.):
            c=by(fixed)@u
            pp=BSpline(tx,c,3).derivative()
            critical=PPoly.from_spline(pp).derivative().roots(extrapolate=False)
            coords=np.r_[[-122.5,0.,122.5],critical[np.isfinite(critical)&(critical>=-122.5)&(critical<=122.5)]]
            i=np.argmax(abs(pp(coords)))
            values.append(dict(leg="horizontal",X_mm=float(coords[i]),Y_mm=fixed,strain=float(L*pp(coords[i]))))
        return values
    return evaluate,steel_bounds

def bound_strains(eval_field,n):
    # Each subpatch lies within one original two-span cubic spline patch.
    # Reconstruct its bicubic tensor in the cubic Bernstein basis by tensor collocation.
    # Symmetric Bernstein coefficient matrices form a convex combination; the
    # minimum of their min eigenvalues is a lower bound on the actual principal strain.
    t=np.linspace(0.,1.,4)
    B=np.stack([math.comb(3,k)*t**k*(1.-t)**(3-k) for k in range(4)],axis=1)
    invB=np.linalg.inv(B)
    ans=[]
    for side in (-1,0,1):
        candidates=[]
        engineering=[]
        for x0,x1 in zip(np.linspace(-152.5,152.5,n+1)[:-1],np.linspace(-152.5,152.5,n+1)[1:]):
            for y0,y1 in zip(np.linspace(-305.,305.,n+1)[:-1],np.linspace(-305.,305.,n+1)[1:]):
                x=x0+(x1-x0)*t[:,None]
                y=y0+(y1-y0)*t[None,:]
                v=eval_field(x,y,side)
                coefficients=np.einsum("ai,ijc,bj->abc",invB,v,invB)
                engineering.append(float(np.max(coefficients[:,:,5])))
                coefficients[:,:,3:]*=.5
                vals=np.linalg.eigvalsh(tensor(coefficients))
                row=np.unravel_index(int(np.argmin(vals[:,:,0])),(4,4))
                candidates.append((float(vals[row][0]),[float(x0),float(x1),float(y0),float(y1)],list(map(int,row))))
        record=min(candidates)
        ans.append(dict(side=side,subdivisions=n,min_principal_lower_bound=record[0],
                        max_shear_gamma_yz_upper_bound=max(engineering),
                        compression_bound_patch=[record[1],record[2]]))
    return ans

def width_control(geom,arr):
    # Integrate by exact overlap of current 12x12 quadrature cells with a strip,
    # retaining their published piecewise constant stress and unchanged bar positions.
    x=geom[:,0]
    dx=305./12.
    center_tau=arr[1,:,11]
    kN=geom[:,2]*center_tau/1000.
    assert len(np.unique(np.round(x[:144],8)))==12
    assert np.max(abs(geom[:144,2]-305.*610./144.))<1e-7
    def resection(width):
        overlap=np.clip(np.minimum(x[:144]+dx/2.,width/2.)-np.maximum(x[:144]-dx/2.,-width/2.),0.,dx)/dx
        steel_inside=abs(x[144:])<=width/2.
        return float(np.sum(overlap*kN[:144])+np.sum(kN[144:][steel_inside]))
    f1={}
    for w in (305.,255.,254.5,245.,236.):
        force=resection(w)
        f1[str(w)]=dict(Qy_kN=force,average_tau_MPa=1000.*force/(w*610.))
    assert abs(f1["305.0"]["Qy_kN"]-np.sum(kN))<1e-10
    factor=np.r_[np.full(8,510./(math.pi*25.**2/4.)),np.full(32,71./(math.pi*10.**2/4.))]
    nominal_bar_area_change=np.sum(kN[144:]*(factor-1.))
    return f1,float(nominal_bar_area_change)

def figure_curves():
    # Fig. 6.45 in printed page 191 and e-page 223. Compare the axis strokes,
    # then read the connected blue/red paths. No OCR or manually sampled ordinates.
    with pin_pdf("Bairan-2005-TINSA-thesis.pdf","5B653FD1CD05DDF257C62F3121E3F537A370495B0E3CA75A3004618DCA8AE142") as doc:
        page=doc[222]
        assert "Figure 6.45:" in page.get_text()
        paths=page.get_drawings()
    axis=[]
    for y in (104.543,229.511):
        axis.append(next(r["rect"] for r in paths if r["type"]=="s" and r["color"]==(0.,0.,0.)
                     and max(abs(a-b) for a,b in zip(r["rect"],(148.067,y,421.237,y)))<.002))
    top,g0=axis
    series={}
    for key,target in (("experiment",(0.,0.,.98)),("TINSA",(1.,.008,.047))):
        path,=[r for r in paths if r["type"]=="s" and r["color"] is not None
                 and len(r["items"])>8 and peak(np.asarray(r["color"])-target)<1e-5]
        assert all(t[0]=="l" for t in path["items"])
        assert all(a[2]==b[1] for a,b in zip(path["items"],path["items"][1:]))
        d=[path["items"][0][1],*(p[2] for p in path["items"])]
        series[key]=[((p.x-g0.x0)*8./(g0.x1-g0.x0), (g0.y0-p.y)*1000./(g0.y0-top.y0)) for p in d]
    return series

def mvt2_check():
    p=pin_pdf("Wang-Huang-2017-MVT-NMVT.pdf","6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E")
    raw=[]
    for number in (12,18):
        page=p[number]
        txt=page.get_text().splitlines()
        j=next(i for i,w in enumerate(txt) if w.strip()=="MVT2")
        raw.append([x.strip() for x in txt[j:j+10]])
    p.close()
    assert raw[0][:9]==["MVT2","-","0","0","6.50","-","48","80","10.51"]
    assert raw[1]==["MVT2","-","48","80","10.51","-","49.40","82.34","10.51","1.03"]
    with archive("MVT2AcceptedStrainOffline.zip") as z:
        u=value(z,"Verification.json")
    winner={}
    for k,v in u["routes"].items():
        most=max(v["matched_native_summaries"], key=lambda m:m["Qy_kN"])
        winner[k]=dict(native=most,
                       Q_fraction_of_crushing=most["Qy_kN"]/80.,
                       sigma_steel_to_fy=(most["long_max_MPa_elastic"]/498,most["hoop_max_MPa_elastic"]/450.))
    return dict(experiment_Mx_kNm=48.,experiment_Qy_kN=80.,experiment_T_kNm=10.51,
                WangHuang_theoretical_Mx_kNm=49.4,WangHuang_theoretical_Qy_kN=82.34,
                WangHuang_theoretical_to_experiment_Q=82.34/80.,
                first_tensile_bar_yield_inference_at_Qy_kN=67.5,first_crack_no_Q_T_kNm=6.50,
                archive_routes=winner)

def main():
    arr,g,field,L,h45=archive_h45()
    evaluate,steel=strain_splines(field,L)
    for side in (-1,0,1):
        assert peak(evaluate(g[:,0],g[:,1],side)-arr[side+1,:,:6])<3e-14
    h45["continuous_hoop_legs"]=legs=steel()
    h45["continuous_stirrup_elastic_utilization"]=max(abs(r["strain"]) for r in legs)/.002
    h45["continuous_bounds"]=bounds=[row for n in (2,4,8) for row in bound_strains(evaluate,n)]
    h45["Qy_kN_fraction_of_reported_published_725"]=h45["Qy_request_N"]/725e3
    h45["experimental_min_marker_minus_upper_H45_kN"]=715.5-(h45["Qy_request_N"]+h45["Qy_adjoint_uncertainty_N"])/1000.
    assert min(b["min_principal_lower_bound"] for b in bounds)>-.0022
    assert max(b["max_shear_gamma_yz_upper_bound"] for b in bounds)<.003033
    curves=figure_curves()
    for curve in curves.values():assert all(b[0]>a[0] for a,b in zip(curve, curve[1:]))
    x,y=np.asarray(curves["experiment"]).T
    f,bars=width_control(g,arr)
    reference_gamma=1.97910116 # H34 accepted work-conjugate gamma, §237.
    past_NDM_force=550.61992
    exc=float(np.interp(reference_gamma,x,y))
    need=305.*exc/past_NDM_force
    stable=1.
    q_stable=378.33 # §229 current 144-point model value at gamma_work=1 per mille.
    q_stable_prev=378.98
    experimental_stable=float(np.interp(stable,x,y))
    kinematic_comparison=dict(
        h45_min_final_experimental_gamma_mm_per_m=3.033,
        h45_min_exp_minus_max_model_gamma=float(3.033-1000.*max(x["max_shear_gamma_yz_upper_bound"] for x in bounds if x["subdivisions"]==8)),
        Bairan_fig6_45_interpolation_near_committed_load_gamma_mm_per_m=float(np.interp(h45["Qy_request_N"]/1000.,y,x)),
        experimental_last_marker=list(curves["experiment"][-1]),
        Bairan_TINSA_last_marker=list(curves["TINSA"][-1]),
        same_indicated_gamma_h34=dict(gamma_work_mm_per_m=reference_gamma,NDM_force_kN=past_NDM_force,experiment_plot_force_kN=exc,
                                    proportional_effective_width_mm=need,
                                    after_linear_outer_hoop_width_254_5_mm_kN=past_NDM_force*254.5/305.),
        same_indicated_gamma_early=dict(gamma_work_mm_per_m=stable,NDM_100_points_kN=q_stable_prev,
                                      NDM_144_points_kN=q_stable,experiment_plot_force_kN=experimental_stable,
                                      proportional_effective_width_mm=305.*experimental_stable/q_stable),
        frozen_H45_force_effective_core_strips=f,
        frozen_H45_change_from_nominal_steel_areas_kN=bars)
    # Strength marker cross-checks from identified publications, not criteria for RC_Section_NDM.
    with pin_pdf("Benyahi-et-al-2021-SK3-Shear.pdf","9404CEE73312CB0C3174FDF9A815960B60DB99A1354707A2940C039D499F3CD4") as p:
        rows=[line.strip() for line in p[17].get_text().splitlines()]
        j=rows.index("SK3")
        assert rows[j:j+3]==["SK3","725","733.75"]
    pin_pdf("Vecchio-Collins-1988-SK3.pdf","D58DBD21B09CA181371F180D331A65957B27298D82362F966C475DB2B27420A8").close()
    return dict(Kani_SK3=dict(benchmark_table2_experiment_kN=725., benchmark_table2_external_model_kN=733.75,
                            h45=h45, strain_and_width_comparisons=kinematic_comparison),
                MVT2=mvt2_check(),input_sha256=receipts)

proof=main()
out.write_text(json.dumps(proof,indent=2,allow_nan=False)+"\n","utf-8")
print(digest(out))


