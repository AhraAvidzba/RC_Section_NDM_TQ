"""Fixed-H53 ASD station-wise replay of the real rejected p7 crossing."""
from pathlib import Path
from time import perf_counter
import gzip
import importlib.util
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('cross',HERE/'Cross-P7.py')
cross=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(cross)
expand=cross.expand
cone=cross.cone
follow=cross.follow
PIN='EC30E478EA840A8741D229E23591401803FA1C68490B482D89267227C29FB889'
ORDER=(0,1,-1)
PARTS=32
REFINEMENTS=22


def exact_fixture():
    old=expand.read_wire('ConeP7Wire.json.gz',PIN)
    assert old['status']=='checked_candidate_rejected' and old['history_final']==53
    probe=cone.load_pinned('station_probe',cone.PRIOR/'station/Probe-Stations.py',cone.STATION_SRC)
    vector,archived=probe.exact_reference()
    np,ops,section,material,identity,load,_=probe.exact_replay(vector,archived)
    assert old['same_material']==material and old['target']==load.tolist()
    return old,probe,vector,archived,np,ops,section,material,identity,load


def principal(np,sigma):
    a,b,c,d,e,f=sigma
    return np.linalg.eigvalsh([[a,d,e],[d,b,f],[e,f,c]]).tolist()


def material_state(section,tag):
    material=section.ops.NDTest
    return {key:list(material('GetResponse',tag,key)) for key in ('equivalentTotalStrain','equivalentPlasticStrain','damage')}


def probe_station(np,section,x,d,side):
    s=ORDER.index(side); point=6
    key=1+s*45+point
    op=section.strain[s,point]
    saved={}

    def full(alpha):
        if alpha not in saved:
            field=x+alpha*d
            eps=op@field
            sig=section.trial(key,eps)
            data=material_state(section,key)
            saved[alpha]={'alpha':alpha,'strain':eps.tolist(),'stress':list(sig),
                          'principal_nominal_MPa':principal(np,sig),**data}
        return saved[alpha]

    first=full(0.)
    table={name:list(section.ops.NDTest('GetResponse',key,name)) for name in ('Te','Ts','Tq','Ce')}
    limits={family:1e-6*min(float(b-a) for a,b in zip(table[family],table[family][1:])) for family in ('Te','Ce')}
    assert min(limits.values())>0.
    functions={}
    for i,family in enumerate(('Te','Ce')):
        for j,knot in enumerate(table[family][1:-1],1):
            threshold=knot+limits[family]
            functions[family,j]=(threshold,lambda sample,i=i,threshold=threshold:sample['equivalentTotalStrain'][i]-threshold)
    functions['principal',2]=(0.,lambda sample:sample['principal_nominal_MPa'][1])
    grid=[i/PARTS for i in range(PARTS+1)]
    for alpha in grid: full(alpha)
    kinks=[]
    for (family,i),(threshold,value) in functions.items():
        for left,right in zip(grid,grid[1:]):
            if value(full(left))*value(full(right))>=0.:
                continue
            left_initial,right_initial=left,right
            for count in range(REFINEMENTS):
                mid=(left+right)/2.
                if value(full(left))*value(full(mid))<=0.:
                    right=mid
                else:
                    left=mid
            gap=right-left
            for a in (left-64*gap,right+64*gap): full(a)
            assert value(full(left))*value(full(right))<=0.
            kinks.append({'family':family,'index':i,'threshold':threshold,'coarse_bracket':[left_initial,right_initial],
                          'actual_alpha_bracket':[left,right],'outer_alpha':[left-64*gap,right+64*gap]})
    assert tuple(first['stress'])==section.trial(key,np.asarray(first['strain']))
    return {'point':7,'side':side,'curves':table,'curve_x_tolerance':limits,'endpoints':[0.,1.],
            'station_kinematic_direction':(op@d).tolist(),'values':[saved[i] for i in sorted(saved)],'events':kinks}


def main():
    started=perf_counter()
    old,probe,vector,archived,np,ops,section,material,identity,load=exact_fixture()
    x=np.array(old['start_field']); d=np.array(old['plan']['field_delta'])
    assert (x+d).tolist()==old['actual']['field']
    report={'previous_attempt_sha256':PIN,'operator_source':identity,'material':material,
            'accepted_history_before':section.committed,'field':x.tolist(),'direction':d.tolist(),'target':load.tolist(),
            'max_measured_shape_step':expand.physical(np,section,d),'stations':[]}
    assert probe.raw_section(section,x,load)==old['start_snapshot'] and probe.raw_section(section,x+d,load)==old['actual']['section']
    for side in ORDER:
        report['stations'].append(probe_station(np,section,x,d,side))
    alphas={float(i)/PARTS for i in range(PARTS+1)}
    alphas.update(a for s in report['stations'] for e in s['events'] for a in e['actual_alpha_bracket'])
    report['section_trace']=[{'alpha':alpha,'section':probe.raw_section(section,x+alpha*d,load)} for alpha in sorted(alphas)]
    assert probe.raw_section(section,x,load)==old['start_snapshot'] and section.committed==53
    report['accepted_history_after']=section.committed
    ops.wipe()
    raw=gzip.compress(vector.raw_json(report),compresslevel=9,mtime=0)
    with (HERE/'P7AllStationsWire.json.gz').open('xb') as sink:sink.write(raw)
    print('MVT2 ASD THREE STATION WIRE',cone.digest(raw),len(raw),'seconds',perf_counter()-started)


if __name__=='__main__':
    main()
