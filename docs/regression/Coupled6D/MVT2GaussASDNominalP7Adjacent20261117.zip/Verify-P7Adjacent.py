"""Independent replay of three p7 station events and one adjacent-cell correction."""
from argparse import ArgumentParser
from bisect import bisect_left
from hashlib import sha256
from math import copysign, fsum
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
STATION='457CD00F212072B93BF43CF4C14A453AB2BED8BC955925D2F1B034C4C5D0E327'
CORRECTION='3D52877A7D642262B49B65C3A1B604DB5FFC42B7B4745CC9CF29D36B4CB1FFD6'
P7=('MVT2GaussASDNominalP7Crossing20261117','EC3FD10733670B75F442AA6326228A62739BF8ABCEC3C58710E31DA647CAB6D3')
SIDES=(0,1,-1)


def sha(b):
    return sha256(b).hexdigest().upper()


def load(path,pin):
    payload=path.read_bytes()
    assert sha(payload)==pin
    return json.loads(gzip.decompress(payload))


def archive(repo,identity):
    name,pin=identity
    path=repo/'docs/regression/Coupled6D'/(name+'.zip')
    assert sha(path.read_bytes())==pin
    return ZipFile(path)


def delta(a,b):
    return [x-y for x,y in zip(a,b,strict=True)]


def error(a,b):
    return max(map(abs,delta(a,b)))


def signature(features):
    return [copysign(1.,v) for v in features]


def norm(v):
    return max(map(abs,v))


def projected(a,b,coef):
    return fsum(x*y for x,y in zip(delta(a,b),coef,strict=True))


def check_trace(wire,original,watch,past,p7,guard,op,geo,area,length):
    x=wire['field']; d=wire['direction']; target=wire['target']; tensor=past['tensor']; eq=watch['check_whole']
    assert wire['accepted_history_before']==wire['accepted_history_after']==53
    assert wire['previous_attempt_sha256']==p7['WIRE'] and x==original['start_field'] and d==original['plan']['field_delta']
    assert target==original['target']
    frames={item['alpha']:item['section'] for item in wire['section_trace']}
    assert frames[0.]==original['start_snapshot'] and frames[1.]==original['actual']['section']
    def field(alpha): return [v+alpha*change for v,change in zip(x,d,strict=True)]
    norms={a:eq(s,field(a),target,op,geo,area,length,guard['signed_forces']) for a,s in frames.items()}
    assert all(n>frames[0.]['tolerance_MPa'] for n in norms.values())
    assert abs(wire['max_measured_shape_step']-max(abs(v) for p in range(45) for side in SIDES for v in tensor(op,d,p,side)))<4e-18
    assert [r['side'] for r in wire['stations']]==list(SIDES)
    out=[]
    for station in wire['stations']:
        side=station['side']
        assert station['point']==7 and error(station['station_kinematic_direction'],tensor(op,d,6,side))<2e-21
        values={v['alpha']:v for v in station['values']}
        limits={key:1e-6*min(b-a for a,b in zip(station['curves'][key],station['curves'][key][1:])) for key in ('Te','Ce')}
        assert limits==station['curve_x_tolerance']
        cells={key:[] for key in ('Te','Ce')}
        for alpha,item in values.items():
            assert error(item['strain'],tensor(op,field(alpha),6,side))<4e-18
            principal=watch['eigen'](item['stress'])
            assert error(principal,item['principal_nominal_MPa'])<3e-13 and principal[1]>.075
            if alpha in frames:
                same=frames[alpha]['net_stresses_MPa'][SIDES.index(side)][6]
                assert error(same,item['stress'])<2e-13
            for i,key in enumerate(cells):
                cells[key].append(bisect_left([q+limits[key] for q in station['curves'][key]],item['equivalentTotalStrain'][i]))
        assert len(set(cells['Ce']))==1
        result={'side':side,'tensile_equivalent_first_and_last':[values[a]['equivalentTotalStrain'][0] for a in (0.,1.)],
                'compression_cell':cells['Ce'][0],'tensile_cells':sorted(set(cells['Te'])),
                'minimum_middle_principal_MPa':min(w['principal_nominal_MPa'][1] for w in values.values())}
        if side!=-1:
            assert not station['events'] and set(cells['Te'])=={3}
        else:
            e,=station['events']
            assert e['family']=='Te' and e['index']==3 and set(cells['Te'])=={3,4}
            threshold=station['curves']['Te'][3]+limits['Te']; assert threshold==e['threshold']
            left,right=e['actual_alpha_bracket']; a,b=e['outer_alpha']
            assert values[left]['equivalentTotalStrain'][0]<threshold<values[right]['equivalentTotalStrain'][0]
            before=[q/(left-a) for q in delta(values[left]['stress'],values[a]['stress'])]
            after=[q/(b-right) for q in delta(values[b]['stress'],values[right]['stress'])]
            stress_jump=delta(values[right]['stress'],values[left]['stress'])
            assert 1.48e-8<norm(stress_jump)<1.50e-8 and norm(before)>2.5*norm(after)
            assert norms[left]<norms[0.]<norms[right]
            do=p7['point_contributions'](frames[left],frames[right],7,53,op)
            assert abs(do[0])+abs(do[1])<abs(do[-1])*1e-3
            result.update({'Te_transition':threshold,'alpha_bracket':[left,right],
                           'local_stress_jump_MPa':stress_jump,'max_stress_slope_before_after_MPa_per_alpha':[norm(before),norm(after)],
                           'signed_weak53_point7_boundary_jump_MPa':do,
                           'full_norm_at_bracket_MPa':[norms[left],norms[right]]})
        out.append(result)
    return {'whole_signed_snapshots':len(frames),'stations':out}


def measured_prediction(cols,base,m,step,op):
    dr=[[] for _ in range(66)]; dm=[[] for _ in range(6)]
    onesided=0
    assert [v['column'] for v in cols]==list(range(1,57))
    for col in cols:
        j=col['column']-1
        h=col['step']; plus=col['plus']; minus=col['minus']
        assert plus or minus
        if plus: assert signature(col['m_plus'])==signature(m)
        if minus: assert signature(col['m_minus'])==signature(m)
        if plus and minus:
            r=delta(col['r_plus'],col['r_minus']); n=delta(col['m_plus'],col['m_minus']); h*=2.
        elif plus:
            r=delta(col['r_plus'],base); n=delta(col['m_plus'],m)
        else:
            r=delta(base,col['r_minus']); n=delta(m,col['m_minus'])
        onesided+=not (plus and minus)
        for result,v in zip(dr,r,strict=True): result.append(v*step[j]/h)
        for result,v in zip(dm,n,strict=True): result.append(v*step[j]/h)
    for k,row in enumerate(dr[:60]):
        row.extend(op['G'][k][j]*(30000. if k>=56 else 1.)*step[j] for j in range(56,60))
    return ([v+fsum(u) for v,u in zip(base,dr,strict=True)],[v+fsum(u) for v,u in zip(m,dm,strict=True)],onesided)


def check_corrected(new,wire,original,old,watch,past,guard,op,geo,area,length):
    assert new['station_wire_sha256']==STATION and new['history_before']==new['history_after']==53
    assert new['status']=='checked_adjacent_descent_uncommitted'
    minus_station=wire['stations'][-1]; event=minus_station['events'][0]; threshold=event['threshold']
    assert new['adjacent_alpha']==event['outer_alpha'][1]
    x0=wire['field']; d=wire['direction']; plan=new['plan']; actual=new['candidate']; y=actual['field']
    x=[a+new['adjacent_alpha']*b for a,b in zip(x0,d,strict=True)]
    assert x==new['adjacent_field'] and y==[a+b for a,b in zip(x,plan['delta'],strict=True)]
    assert x0==new['reference_pre_switch_field']
    eq=watch['check_whole']; goal=new['target']; signed=guard['signed_forces']; tensor=past['tensor']
    def movement(d): return max(abs(v) for p in range(45) for side in SIDES for v in tensor(op,d,p,side))
    adjacent=eq(new['adjacent_section'],x,goal,op,geo,area,length,signed)
    endpoint=eq(actual['section'],y,goal,op,geo,area,length,signed)
    initial=eq(original['start_snapshot'],x0,goal,op,geo,area,length,signed)
    assert abs(initial-new['reference_pre_switch_norm_MPa'])<3e-12
    assert abs(adjacent-new['adjacent_norm_MPa'])<3e-12 and abs(endpoint-actual['independent_norm_MPa'])<3e-12
    assert abs(endpoint-norm(actual['all66']))<3e-12
    pred,marks,one=measured_prediction(new['finite_difference']['columns'],new['adjacent_all66'],new['adjacent_markers'],plan['delta'],op)
    assert one==50 and abs(norm(pred)-plan['predicted_norm_MPa'])<5e-15
    assert error(marks,plan['predicted_markers'])<3e-18
    expected=[-1.,1.,1.,-1.,-1.,1.]
    assert signature(new['adjacent_markers'])==signature(marks)==signature(actual['markers'])==expected
    assert signature(new['reference_pre_switch_markers'])==expected[:-1]+[-1.]
    for q in ((new['adjacent_section'],new['adjacent_markers']),(actual['section'],actual['markers'])):
        section,markers=q
        for (p,side),m in zip(((20,1),(20,-1),(10,-1)),markers[:3],strict=True):
            value=watch['eigen'](section['net_stresses_MPa'][SIDES.index(side)][p-1])[1]
            assert abs(value-m)<2e-13 and copysign(1.,m)==copysign(1.,value)
    assert actual['same_selected_cell_and_steel'] and actual['admissible']
    assert actual['section']['steel_active_flags']==new['adjacent_section']['steel_active_flags']==original['start_snapshot']['steel_active_flags']
    for i,side in enumerate(SIDES):
        state=actual['three_p7_states'][i]
        assert state['side']==side
        assert error(watch['eigen'](actual['section']['net_stresses_MPa'][i][6]),state['principal_nominal_MPa'])<3e-13
        assert state['principal_nominal_MPa'][1]>.075 and state['equivalentTotalStrain'][1]<.00006
        assert abs(state['equivalentTotalStrain'][0]-threshold-actual['markers'][3+i])<2e-18
    cap=new['combined_step_cap']; total=new['total_cap_about_rejected_center']
    assert abs(cap-movement(delta(x,x0))-plan['local_radius'])<4e-18
    first=movement(delta(y,x0)); overall=movement(delta(y,old['first_rejected_trial']))
    assert abs(first-actual['distance_from_pre_switch'])<4e-18 and first<cap
    assert abs(overall-actual['distance_from_rejected_center'])<4e-18 and overall<total
    ratio=(adjacent-endpoint)/(adjacent-norm(pred)); tau=actual['section']['tolerance_MPa']
    assert abs(ratio-actual['reduction_ratio'])<1e-6 and .998<ratio<1.
    assert tau<endpoint<initial<adjacent and 4.13<endpoint/tau<4.14
    return {'accepted_history_count':53,'initial_pre_switch_MPa':initial,'post_switch_anchor_MPa':adjacent,
            'predicted_corrected_MPa':norm(pred),'actual_corrected_MPa':endpoint,'original_tolerance_MPa':tau,
            'actual_tolerance_ratio':endpoint/tau,'adjacent_reduction_ratio':ratio,'one_sided_columns':one,
            'retained_corrected_material_indicators':actual['markers'],'final_signed_6':actual['section']['signed_6'],
            'physical_limit_established':False}


def main(repo):
    wire=load(HERE/'P7AllStationsWire.json.gz',STATION); correction=load(HERE/'P7AdjacentWire.json.gz',CORRECTION)
    with tempfile.TemporaryDirectory(prefix='MVTP7Adjacent_') as directory, archive(repo,P7) as baseline:
        stage=Path(directory)
        def require(z,name):
            f=stage/name; f.write_bytes(z.read(name)); return runpy.run_path(str(f))
        p7=require(baseline,'Verify-P7.py'); initial=baseline.read('ConeP7Wire.json.gz')
        assert sha(initial)==p7['WIRE']
        original=json.loads(gzip.decompress(initial))
        with archive(repo,p7['EXPANDED']) as z:
            expanded=require(z,'Verify-Expanded.py')
        with archive(repo,expanded['PREVIOUS']) as z:
            prior=require(z,'Verify-Cone.py'); old=z.read('ConeWire.json.gz')
            assert sha(old)==prior['WIRE']
        with archive(repo,prior['STATION']) as z:
            watch=require(z,'Verify-Stations.py')
        with archive(repo,watch['BASE']) as z:
            history=require(z,'Verify-VectorEvidence.py')
        accepted,n,_,_,_=history['history'](repo)
        assert accepted['Q_target_N']==55156.25 and n<accepted['tolerance_MPa']
        with archive(repo,history['POST']) as z:
            past=require(z,'Verify-Postyield.py')
        with archive(repo,past['AUTH']) as z:
            for name in ('Verify-Authoritative.py','Operators.py','Reequilibrate.py'):
                (stage/name).write_bytes(z.read(name))
        sys.path.insert(0,str(stage))
        guard=runpy.run_path(str(stage/'Verify-Authoritative.py'))
        operator,source=guard['unpack'](stage,repo)
        model=runpy.run_path(str(stage/'Reequilibrate.py'))
        _,_,geo,dirs,area,length,op,_,_,identity=model['read_inputs'](operator,stage,source)
    assert wire['operator_source']==correction['operator_source']==identity and wire['material']==correction['same_material']
    return {'ray':check_trace(wire,original,watch,past,p7,guard,op,geo,area,length),
            'correction':check_corrected(correction,wire,original,json.loads(gzip.decompress(old)),watch,past,guard,op,geo,area,length)}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--report',type=Path)
    options=parser.parse_args()
    result=main(options.repo)
    payload=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if options.report:
        with options.report.open('xb') as stream: stream.write(payload)
    print('MVT2 ASD ADJACENT P7 OFFLINE PASS',sha(payload),result['ray']['whole_signed_snapshots'],result['correction']['actual_corrected_MPa'])
