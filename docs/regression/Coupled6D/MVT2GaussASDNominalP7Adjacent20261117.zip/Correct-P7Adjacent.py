"""One exact correction using only the newly measured adjacent side of p7."""
from pathlib import Path
from time import perf_counter
import gzip
import importlib.util
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('inspect_p7',HERE/'Inspect-P7.py')
study=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(study)
cone=study.cone
expand=study.expand
PIN='457CD00F212072B93BF43CF4C14A453AB2BED8BC955925D2F1B034C4C5D0E327'
SIDES=(0,1,-1)


def current(np,section,x,load,vector,threshold):
    r=section.equations(x,load,False)
    rows=vector.coordinates(np,section,load,r)
    steel=section.next_steel[2]==0.
    m=[]
    for pt,side in ((20,1),(20,-1),(10,-1)):
        m.append(study.principal(np,r[2][SIDES.index(side),pt-1])[1])
    for s in range(3):
        tag=1+s*45+6
        assert section.trial(tag,section.last_tensor[s,6])==tuple(r[2][s,6])
        response=section.ops.NDTest('GetResponse',tag,'equivalentTotalStrain')
        m.append(response[0]-threshold)
    return r,rows,steel,np.array(m)


def finite(np,section,x,load,start,vector,threshold,grid):
    _,rows,steel,mar=start
    jac=np.empty((66,60)); state=np.zeros((6,60)); wire=[]
    for j,p in enumerate(grid):
        if p==0.:
            jac[:,j]=np.r_[section.G[:,j]*section.scale,np.zeros(6)]
            continue
        perturb=np.zeros(60)
        for factor in (1.,.25,.0625):
            h=factor*cone.NORMAL_STATION_STEP/p
            perturb[j]=h
            _,rp,sp,mp=current(np,section,x+perturb,load,vector,threshold)
            _,rm,sm,mm=current(np,section,x-perturb,load,vector,threshold)
            plus=np.array_equal(sp,steel) and np.array_equal(np.sign(mp),np.sign(mar))
            minus=np.array_equal(sm,steel) and np.array_equal(np.sign(mm),np.sign(mar))
            if plus or minus: break
        if not plus and not minus:
            return None,None,{'columns':wire,'invalid_column':j+1}
        if plus and minus:
            jac[:,j]=(rp-rm)/(2*h); state[:,j]=(mp-mm)/(2*h)
        elif plus:
            jac[:,j]=(rp-rows)/h; state[:,j]=(mp-mar)/h
        else:
            jac[:,j]=(rows-rm)/h; state[:,j]=(mar-mm)/h
        wire.append({'column':j+1,'step':h,'plus':bool(plus),'minus':bool(minus),
                     'r_plus':rp.tolist(),'r_minus':rm.tolist(),'m_plus':mp.tolist(),'m_minus':mm.tolist()})
    return jac,state,{'columns':wire}


def propose(np,section,start,j,k,cap,physical):
    from scipy.optimize import linprog
    _,r,_,m=start
    sigma=float(np.max(np.abs(r)))
    scale=np.divide(cap,physical,out=np.zeros(60),where=physical>0.)
    null=physical==0.
    scale[null]=sigma/np.max(np.abs(j[:,null]),axis=0)
    op=j*scale/sigma
    u=np.reshape(section.strain*scale/cap,(-1,60))
    signs=np.sign(m)
    active=signs[:,None]*k*scale
    margin=np.maximum(np.abs(m),np.max(np.abs(active),axis=1))
    matrix=np.vstack((np.c_[op,-np.ones(66)],np.c_[-op,-np.ones(66)],
                     np.c_[u,np.zeros(len(u))],np.c_[-u,np.zeros(len(u))],np.c_[-active/margin[:,None],np.zeros(6)]))
    rhs=np.r_[-r/sigma,r/sigma,np.ones(2*len(u)),.5*np.abs(m)/margin]
    sol=linprog(np.r_[np.zeros(60),1.],A_ub=matrix,b_ub=rhs,bounds=[(None,None)]*60+[(0.,None)],
                method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    out={'local_radius':cap,'lp_status':int(sol.status)}
    if not sol.success:
        return None,out
    d=sol.x[:60]*scale
    out.update({'delta':d.tolist(),'predicted_norm_MPa':float(np.max(np.abs(r+j@d))),'predicted_markers':(m+k@d).tolist(),
                'binding_material_sign_constraints':(np.flatnonzero(np.abs(sol.ineqlin.residual[-6:])<1e-9)+1).tolist()})
    return d,out


def main():
    started=perf_counter()
    wire=expand.read_wire('P7AllStationsWire.json.gz',PIN)
    old,probe,vector,receipt,np,ops,section,material,identity,load=study.exact_fixture()
    assert wire['operator_source']==identity and wire['accepted_history_after']==53
    threshold=wire['stations'][-1]['events'][0]['threshold']
    event,=wire['stations'][-1]['events']
    assert event['family']=='Te' and not any(s['events'] for s in wire['stations'][:-1])
    alpha=event['outer_alpha'][1]
    x=np.array(wire['field']); d0=np.array(wire['direction']); base=x+alpha*d0
    old_cone=expand.read_wire('ConeWire.json.gz',study.follow.PRIOR)
    origin=np.array(old_cone['first_rejected_trial'])
    total=old['total_cap_same_rejected_center']
    budget=old['local_cap']
    local=budget-expand.physical(np,section,base-x)
    assert local>0. and expand.physical(np,section,base-origin)+local<total
    reference=current(np,section,x,load,vector,threshold)
    b=current(np,section,base,load,vector,threshold)
    assert reference[0][4]==old['start_snapshot']['norm_MPa']
    assert np.sign(reference[3]).tolist()==[-1.,1.,1.,-1.,-1.,-1.]
    assert np.sign(b[3]).tolist()==[-1.,1.,1.,-1.,-1.,1.] and np.array_equal(b[2],reference[2])
    watch=runpy.run_path(str(cone.PRIOR/'station/Verify-Stations.py'))
    anchor=probe.raw_section(section,base,load)
    physical=np.max(np.abs(section.strain),axis=(0,1,2))
    J,K,columns=finite(np,section,base,load,b,vector,threshold,physical)
    report={'station_wire_sha256':PIN,'same_material':material,'operator_source':identity,'target':load.tolist(),
            'reference_pre_switch_field':x.tolist(),'reference_pre_switch_markers':reference[3].tolist(),
            'reference_pre_switch_norm_MPa':reference[0][4],
            'adjacent_alpha':alpha,'adjacent_field':base.tolist(),'adjacent_section':anchor,
            'adjacent_norm_MPa':follow_norm(section,watch,anchor,base,load),'adjacent_all66':b[1].tolist(),
            'adjacent_markers':b[3].tolist(),'finite_difference':columns,'combined_step_cap':budget,
            'total_cap_about_rejected_center':total,'history_before':section.committed,
            'status':'no_admissible_affine_descent'}
    if J is not None:
        change,plan=propose(np,section,b,J,K,local,physical)
        report['plan']=plan
        if change is not None and plan['predicted_norm_MPa']<reference[0][4]:
            y=base+change
            actual,rows,steel,ind=current(np,section,y,load,vector,threshold)
            snap=probe.raw_section(section,y,load)
            norm=follow_norm(section,watch,snap,y,load)
            signed=np.array_equal(np.sign(ind),np.sign(b[3])) and np.array_equal(steel,b[2])
            pre=expand.physical(np,section,y-x)
            dist=expand.physical(np,section,y-origin)
            known=b[0][4]-plan['predicted_norm_MPa']
            ratio=(b[0][4]-norm)/known
            states=[]
            for index,side in enumerate(SIDES):
                tag=1+45*index+6
                sig=section.trial(tag,section.last_tensor[index,6])
                assert sig==tuple(actual[2][index,6])
                states.append({'side':side,'principal_nominal_MPa':study.principal(np,sig),**study.material_state(section,tag)})
            allowed=bool(signed and pre<=budget*(1.+3e-9) and dist<total and
                         norm<reference[0][4] and ratio>=.5 and all(z['principal_nominal_MPa'][1]>0. for z in states))
            report['candidate']={'field':y.tolist(),'section':snap,'all66':rows.tolist(),'markers':ind.tolist(),
                                 'three_p7_states':states,'same_selected_cell_and_steel':bool(signed),
                                 'distance_from_pre_switch':pre,'distance_from_rejected_center':dist,
                                 'independent_norm_MPa':norm,'reduction_ratio':ratio,'admissible':allowed}
            report['status']='checked_adjacent_descent_uncommitted' if allowed else 'checked_adjacent_candidate_rejected'
            if allowed and max(norm,actual[4])<=actual[5]:
                assert probe.raw_section(section,y,load)==snap
                section.accepted_stresses.append(actual[2].tolist()); section.commit()
                report['status']='balanced_original_equilibrium'
    if report['status']!='balanced_original_equilibrium':
        assert probe.raw_section(section,x,load)==old['start_snapshot'] and section.committed==53
    report['history_after']=section.committed
    ops.wipe()
    raw=gzip.compress(vector.raw_json(report),compresslevel=9,mtime=0)
    with (HERE/'P7AdjacentWire.json.gz').open('xb') as sink:sink.write(raw)
    print('MVT2 ASD ADJACENT STATION WIRE',cone.digest(raw),len(raw),'seconds',perf_counter()-started,report['status'])


follow_norm=study.follow.independent
if __name__=='__main__':
    main()
