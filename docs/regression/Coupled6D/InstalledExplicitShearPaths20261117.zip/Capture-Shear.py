"""Снимает ячейки предельной строки и сверяет VBA частной книги."""

from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile


def digest(data):
    return sha256(data).hexdigest().upper()


def column_number(letters):
    index = 0
    for character in letters:
        index = index * 26 + ord(character) - 64
    return index


def capture(saved, parts):
    """Сохраняет XML, нужный для чтения предельной строки вне Excel."""
    with ZipFile(saved) as package:
        used = ['xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/sharedStrings.xml']
        workbook = ET.fromstring(package.read(used[0]))
        sheet, = [item for item in workbook.findall('.//{*}sheet') if item.get('name') == 'Results']
        ref, = [value for key, value in sheet.attrib.items() if key.endswith('}id')]
        relationships = ET.fromstring(package.read(used[1]))
        target, = [item.get('Target') for item in relationships if item.get('Id') == ref]
        used.append('xl/' + target)
        with ZipFile(parts, 'x') as output:
            for name in used:
                output.writestr(name, package.read(name))
    return extract_row(parts) | {'saved_sha256': digest(saved.read_bytes())}


def extract_row(parts):
    """Читает положение строки по имени Excel и разрешает строки из sharedStrings."""
    with ZipFile(parts) as package:
        workbook = ET.fromstring(package.read('xl/workbook.xml'))
        anchor, = [n.text for n in workbook.findall('.//{*}definedName') if n.get('name') == 'rngStrengthSummaryAnchor']
        label, index = re.fullmatch(r"'?Results'?\!\$([A-Z]+)\$(\d+)",anchor).groups()
        base = column_number(label)
        sheet, = [item for item in workbook.findall('.//{*}sheet') if item.get('name') == 'Results']
        ref, = [value for key,value in sheet.attrib.items() if key.endswith('}id')]
        relationships = ET.fromstring(package.read('xl/_rels/workbook.xml.rels'))
        target, = [item.get('Target') for item in relationships if item.get('Id') == ref]
        raw = package.read('xl/' + target)
        worksheet = ET.fromstring(raw)
        strings = [''.join(t.text or '' for t in item.findall('.//{*}t'))
                   for item in ET.fromstring(package.read('xl/sharedStrings.xml'))]
        row, = [item for item in worksheet.findall('.//{*}row') if item.get('r') == index]
        cells = {}
        for item in row:
            name = item.get('r')
            column = column_number(re.match('[A-Z]+',name).group()) - base
            value = item.find('{*}v')
            if value is not None and column in (35,37,38,39,40,41,42,43,58,59,64):
                cells[column] = [name, strings[int(value.text)] if item.get('t') == 's' else float(value.text)]
    return {'cells':cells,'results_xml_sha256':digest(raw),'anchor':anchor}


def contains_only_test_changes(repo, candidate):
    primary = repo / 'workbook/output/RC_Section_NDM.xlsm'
    archives = repo / 'docs/regression/Coupled6D'
    release = (archives / 'HardShearCoarseGrowthWorkbookRelease20261117.zip').read_bytes()
    assert digest(release) == '6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63'
    with ZipFile(BytesIO(release)) as packet:
        source = packet.read('Stage-Release.py')
    stage = {'__name__':'__pinned__','__file__':str(Path(__file__).with_name('Stage-Release.py'))}
    exec(compile(source,stage['__file__'],'exec'),stage)
    observation, read = stage['parse_vba'](repo)
    baseline, final = primary.read_bytes(), candidate.read_bytes()
    _, before = read(BytesIO(baseline))
    _, after = read(BytesIO(final))
    fold, compare = observation['literal_safe_fold'], observation['compiler_body']
    assert len(before) == len(after) == 225 and before.keys() == after.keys()
    changed = [x for x in before if fold(before[x]) != fold(after[x])]
    name, = changed
    assert name == 'modTestCoupledElasticState'
    source_body = (repo/'tests/modTestCoupledElasticState.bas').read_text(encoding='utf-8')
    test_addition = Path(__file__).with_name('EccentricShearEntry.bas.txt').read_text(encoding='utf-8')
    expected = source_body.rstrip() + '\n' + test_addition
    # Уже установленное тело сравнивается с книгой. Оно содержит представление
    # чисел и комментариев, которое сохранил VBE. Новый фрагмент сверяется с исходником.
    before_body, before_attributes = compare(before[name], name)
    after_body, after_attributes = compare(after[name], name)
    expected_body, expected_attributes = compare(expected, name)
    entry = 'public function runtestcoupledeccentricshearworkbook'
    heading = "' -------------------- "
    before_start = after_body.rindex(heading, 0, after_body.index(entry))
    expected_start = expected_body.rindex(heading, 0, expected_body.index(entry))
    assert before_attributes == after_attributes == expected_attributes
    assert after_body[:before_start].rstrip() == before_body.rstrip()
    assert after_body[before_start:] == expected_body[expected_start:]
    return {'base_sha256':digest(baseline),'candidate_sha256':digest(final),'component_count':len(before),
            'changed_vba_modules':changed,'original_test_module_prefix_unchanged':True,
            'appended_test_code_matches_source':True}
