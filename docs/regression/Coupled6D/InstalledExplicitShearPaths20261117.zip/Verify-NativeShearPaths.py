"""Повторяет проверку двух явных поперечных путей по сохранённым данным Excel."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import isclose, ulp
from pathlib import Path
import re
from runpy import run_path


HERE = Path(__file__).resolve().parent
ORIGINAL = run_path(str(HERE / "Verify-NativeSelectedStock.py"))
CAPTURE = run_path(str(HERE / "Capture-Shear.py"))
BOOK_SHA = ORIGINAL["BOOK_SHA"]
CANDIDATE_SHA = "B38FEDCB9C3021A2AD00E343393E970289222163C7DCB57D23AD34E38902BDFB"
COMPONENTS = ("N", "Mx", "My", "T", "Qx", "Qy")


def read_json(name):
    """Читает протокол Python или PowerShell в UTF-8."""
    return json.loads((HERE / name).read_text(encoding="utf-8-sig"))


def verify_sample(axis):
    """Сверяет сохранённую строку и все цели равновесия в центре."""
    name = f"Verified{axis}.txt"
    native = ORIGINAL["native"](name, CANDIDATE_SHA, {"COUPLED_ECCENTRIC_SHEAR": 33}, True)
    transcript = (HERE / name).read_text(encoding="utf-8-sig")
    multiplier_text, = re.findall(
        rf"^ECCENTRIC_SHEAR_STATUS;{axis};FAIL;([^;]+);FAIL;PHYSICAL_LIMIT_EXCEEDED$",
        transcript, re.M,
    )
    captured = read_json(f"Shear{axis}OOXML.json")
    raw = CAPTURE["extract_row"](HERE / f"Shear{axis}Parts.zip")
    assert raw["anchor"] == captured["anchor"]
    assert raw["results_xml_sha256"] == captured["results_xml_sha256"]
    assert {str(key): value for key, value in raw["cells"].items()} == captured["cells"]
    row = {offset: value for offset, (_, value) in raw["cells"].items()}
    assert row[35] == "λ*" + axis
    assert row[58] == row[64] == "FAIL"
    multiplier = row[37]
    assert 0.75 < multiplier < 1. and row[59] == multiplier
    assert isclose(float(multiplier_text), multiplier, rel_tol=0., abs_tol=1e-14)
    user = [-250., -24998200., -20002300., 710080., 50., -60.]
    user[COMPONENTS.index(axis)] *= multiplier
    dx, dy = -80000., -100000.
    axial, _, _, _, qx, qy = user
    transferred = [0., dy * axial, dx * axial, dx * qy - dy * qx, 0., 0.]
    center = [component + addition for component, addition in zip(user, transferred)]
    tf = 9806.65
    scale = (tf, tf * 1000, tf * 1000, tf * 1000, tf, tf)
    for index, component in enumerate(COMPONENTS):
        assert isclose(row[38 + index] * scale[index], user[index], rel_tol=1e-13)
        target, = re.findall(
            rf"^OK: Explicit shear CapacityState saves the correct centered target {component} actual=([^ ]+) ",
            transcript, re.M,
        )
        # До переноса Mx близок по модулю к добавке от N. Сравнение учитывает
        # округление исходных операндов до преобразования к малому остатку.
        transfer_roundoff = 4. * (ulp(user[index]) + ulp(transferred[index]))
        assert isclose(float(target) * scale[index], center[index],
                       rel_tol=1e-13, abs_tol=transfer_roundoff)
    time, = re.findall(r"Время расчёта: ([0-9.]+) с.", transcript)
    return {
        "native": native,
        "lambda": multiplier,
        "load_point_vector_N_Nmm": user,
        "centered_vector_N_Nmm": center,
        "calculation_seconds": float(time),
        "saved_sha256": captured["saved_sha256"],
        "results_xml_sha256": raw["results_xml_sha256"],
        "hoop_direct_status": row[58],
        "hoop_capacity_status": row[64],
    }


def verify(repo):
    """Привязывает отчёты к рабочему пакету и компиляции только тестового модуля."""
    stock = (repo / ORIGINAL["BOOK_PATH"]).read_bytes()
    if sha256(stock).hexdigest().upper() != BOOK_SHA:
        from subprocess import check_output

        stock = check_output(
            ["git", "cat-file", "blob", f"{ORIGINAL['BOOK_REVISION']}:{ORIGINAL['BOOK_PATH']}"], cwd=repo
        )
    assert sha256(stock).hexdigest().upper() == BOOK_SHA
    identity = read_json("VbaIdentity.json")
    assert identity["base_sha256"] == BOOK_SHA and identity["candidate_sha256"] == CANDIDATE_SHA
    assert identity["component_count"] == 225
    assert identity["changed_vba_modules"] == ["modTestCoupledElasticState"]
    assert identity["original_test_module_prefix_unchanged"] and identity["appended_test_code_matches_source"]
    code = read_json("CodeUpdate.json")
    assert code["WorkbookSHA256"] == CANDIDATE_SHA and code["ProductionSHA256"] == BOOK_SHA
    assert code["Compiled"] and not code["ProductionChanged"] and code["Modules"] == ["modTestCoupledElasticState"]
    cases = {axis: verify_sample(axis) for axis in ("Qx", "Qy")}
    assert cases["Qx"]["lambda"] != cases["Qy"]["lambda"]
    return {"book_sha256": BOOK_SHA, "vba_identity": identity, "cases": cases}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.repo.resolve())
    with args.report.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print("EXPLICIT SHEAR WORKBOOK EVIDENCE OFFLINE PASS")
