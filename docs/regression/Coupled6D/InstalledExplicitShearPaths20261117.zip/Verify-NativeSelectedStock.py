"""Проверяет свидетельства направленных штатных тестов точной установленной книги."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_output


BOOK_SHA = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'
BOOK_REVISION = '0081ce2aee08b83f49c74dbe9c7d95a991ebd327'
BOOK_PATH = 'workbook/output/RC_Section_NDM.xlsm'
HERE = Path(__file__).resolve().parent


def native(name, book_sha, suites, needs_reopen):
    """Сверяет исходный SHA, итоги макросов и выход отдельного процесса Excel."""
    primary = HERE / name
    raw = primary.read_bytes()
    text = raw.decode('utf-8-sig').replace('\r\n', '\n')
    assert f'SOURCE_SHA256: {book_sha}\n' in text
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    assert 'SCRIPT ERROR:' not in text and 'RUNTIME ERROR:' not in text
    assertions = {suite: [int(passed),int(failed)] for suite,passed,failed in
                  re.findall(r'^TOTAL_([A-Z0-9_]+): passed=(\d+); failed=(\d+)$',text,re.M)}
    assert assertions == {key:[value,0] for key,value in suites.items()}
    process = json.loads((HERE/f'{name}.ProcessClosure.json').read_text(encoding='utf-8-sig'))
    assert process['Stage']=='AFTER_CHILD_EXIT' and process['ChildExitCode']==0 and process['RunnerCleanupValid']
    assert process['Passed'] and process['Closure']['FinalState']['State']=='Absent'
    assert not process['OrdinaryPathKilledAnything']
    owner = json.loads((HERE/f'{name}.Ownership.json').read_text(encoding='utf-8-sig'))
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256'] == book_sha
    assert owner['PID'] == process['Closure']['Identity']['PID']
    assert int(owner['StartTicksUTC']) == process['Closure']['Identity']['Ticks']
    matches = re.findall(r'^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=([0-9A-F]{64}); equal=True;',text,re.M)
    assert len(matches) == int(needs_reopen)
    assert all(before == after for before,after in matches)
    return {'assertions': assertions, 'reopened_signature': matches[0][0] if matches else None,
            'transcript_sha256': sha256(raw).hexdigest().upper(), 'owned_excel_closed': True}


def main(repo):
    """Проверяет запуск хомута, перенос к центру и общую матрицу LoadPath."""
    book = (repo / BOOK_PATH).read_bytes()
    if sha256(book).hexdigest().upper() != BOOK_SHA:
        book = check_output(['git','cat-file','blob',f'{BOOK_REVISION}:{BOOK_PATH}'],cwd=repo)
    assert sha256(book).hexdigest().upper() == BOOK_SHA
    hoop = native('StockHoopReopen.txt',BOOK_SHA,{'COUPLED_HOOP_CAPACITY':228},True)
    paths = native('StockPaths.txt',BOOK_SHA,{'COUPLED_CENTERED_LOAD_PATHS':323,'AUDIT03_UNIVERSAL_PATH':945},False)
    return {'exact_book_sha256': BOOK_SHA,'hoop':hoop,'paths':paths,'total_assertions':1496}


if __name__ == '__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',default=Path.cwd(),type=Path)
    parser.add_argument('--report',required=True,type=Path)
    arguments=parser.parse_args()
    with arguments.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(main(arguments.repo.resolve()),output,indent=2,sort_keys=True)
        output.write('\n')
    print('INSTALLED SELECTED LOAD PATH STOCK NATIVE PASS')
