"""Rebuild all native force/compatibility rows, detached from the Excel solver."""
from argparse import ArgumentParser
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from hashlib import sha256
import csv,json,runpy
import numpy as np

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare-Mixed.py')
Z=H/'Native'
LABELS=('Base45','Plus18Center','Plus18TargetMinus','Plus18TargetPlus','Plus18Repeat','End45','Restore45')
PROBES=LABELS[1:5]


def read_json(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def peak(v): return float(np.max(abs(v)))
def sha(p): return sha256(p.read_bytes()).hexdigest().upper()

def archived(repo,name):
    return P['frozen_archive'](repo,name)

def sample_rows(path):
    with path.open(encoding='cp1251',newline='') as stream:
        yield from csv.reader(stream,delimiter=';')

def trace(folder):
    q={}; out={}; flags={}; projections={}
    for tag,name,*row in sample_rows(folder/'KaniV4Trace.csv'):
        if tag=='K59C_VECTOR': dest=q; expected=89
        elif tag=='K59C_STATE': dest=out; expected=99
        elif tag=='PROJECTION': dest=projections; expected=87
        elif tag=='TANGENT_FLAGS': dest=flags; expected=3
        else:
            assert tag=='CHECK'; continue
        assert name not in dest and len(row)==expected
        dest[name]=np.array(row,float)
    assert set(out)==set(q)==set(LABELS) and set(flags)=={'Center'} and set(projections)=={'Mean'}
    return q,out,flags['Center'],projections['Mean']

def station_fields(folder,names):
    tensors={label:np.full((3,184,12),np.nan) for label in names}
    for kind,name,pt,side,*row in sample_rows(folder/'KaniV4Stations.csv'):
        i,j=int(side)+1,int(pt)-1
        assert 0<=i<3 and 0<=j<184 and kind=='K59C_STATION' and len(row)==12 and np.isnan(tensors[name][i,j]).all()
        tensors[name][i,j]=list(map(float,row))
    assert all(np.isfinite(x).all() for x in tensors.values())
    return tensors

def material_observations(folder,names,flags):
    branches={label:np.full((3,184,3),-999) for label in names}; F={label:np.full((3,184),np.nan) for label in names}
    energy={label:np.full((3,184,2),np.nan) for label in ('Base45','End45','Restore45')}; jac={}
    for kind,name,pt,*row in sample_rows(folder/'KaniV4Tangents.csv'):
        j=int(pt)-1
        if kind=='MATRIX':
            assert 0<=j<88 and len(row)==88
            m=jac.setdefault(name,np.full((88,88),np.nan)); assert np.isnan(m[j]).all(); m[j]=list(map(float,row)); continue
        i=int(row[0])+1; tail=row[1:]; assert 0<=i<3 and 0<=j<184
        if kind=='BRANCH':
            assert branches[name][i,j,0]==-999 and len(tail)==3
            branches[name][i,j]=list(map(int,tail))
        elif kind=='ENERGY':
            assert np.isnan(energy[name][i,j]).all() and len(tail)==2
            energy[name][i,j]=list(map(float,tail))
        else:
            assert kind=='YIELD' and len(tail)==1 and np.isnan(F[name][i,j])
            F[name][i,j]=float(tail[0])
    assert all(np.isfinite(x).all() for x in [*energy.values(),*F.values(),*jac.values()])
    assert all((x!=-999).all() for x in branches.values())
    assert set(jac)=={k for yes,k in zip(flags,('CenterStock','CenterRefined','CenterOrdinary')) if yes}
    return branches,F,energy,jac


def verify(repo):
    prep=P['check'](repo); plan=read_json(H/'Plus18Plan.json'); r=read_json(Z/'KaniV4.txt.ProcessClosure.json')
    book=read_json(H/'docs/regression/CodeUpdate.json'); own=read_json(Z/'KaniV4.txt.Ownership.json'); closed=read_json(Z/'CompileClosure.json')
    end=r['Closure']['FinalState']; report=(Z/'KaniV4.txt').read_text(encoding='utf-8-sig')
    assert r['Passed'] and r['ChildExitCode']==0 and end['State']==closed['State']=='Absent'
    assert end['PID']==own['PID'] and end['StartTicksUTC']==own['StartTicksUTC'] and own['VerifiedNewOwner']
    assert book['Compiled'] and not book['ProductionChanged'] and book['ProductionSHA256']==prep['bookSHA256']
    assert book['WorkbookSHA256']==sha(H/P['PRIVATE']) and sorted(book['Modules'])==['CCoupledElasticState','CCoupledNewtonSolver','modTestKaniStage38']
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    with archived(repo,'KaniCommitNear48Portable.zip') as history, archived(repo,'KaniPracticalProbe45Portable.zip') as original:
        stage=json.loads(history.read('Commit48Verification.json')); h=dict(np.load(BytesIO(history.read('MeasuredSamples.npz')),allow_pickle=False))
        old=dict(np.load(BytesIO(original.read('MeasuredSamples.npz')),allow_pickle=False)); src=history.read('Verify.py').decode('utf-8')
        # Read only the independently checked spatial basis helper from the identified source.
        stop=src.index('ROOT='); base=src[:stop].replace('\r\n','\n'); ops=H/'BuildOperators.py'; ops.write_text(base,encoding='utf8')
    q,summary,flags,proj=trace(Z); T=station_fields(Z,q); b,F,e,M=material_observations(Z,q,flags)
    ids={key:i for i,key in enumerate(h['names'])}; v=ids['Committed45']; base=q['Base45']
    assert np.array_equal(proj,h['projection']) and np.array_equal(base,h['fields'][v]) and np.array_equal(T['Base45'],h['stations'][h['station_index'][v]])
    assert np.array_equal(e['Base45'],np.array(stage['energiesByStation_minus0plus']['Committed45']))
    for fields in (q,T,b,F,e):
        assert all(np.array_equal(fields['Base45'],fields[n]) for n in ('End45','Restore45'))
    for fields in (q,T,b,F): assert np.array_equal(fields['Plus18Center'],fields['Plus18Repeat'])
    assert np.array_equal(summary['Plus18Center'],summary['Plus18Repeat'])
    assert np.array_equal(old['geometry'],h['geometry'])
    build=runpy.run_path(ops)['operators']; length=float(h['length']); geo=h['geometry']; H0,sh,g,phys,area,scale=build(geo,length)

    def material_force(stress):
        core=stress[1]; gradient=(stress[2]-stress[0])/.002
        weak=np.einsum('nij,ni,n->j',H0,core,area)
        weak[4:]-=np.einsum('nk,na,n->ka',sh,gradient[:,[4,5,2]],area).ravel()
        long=np.einsum('nij,ni,n->j',H0[:,:,:4],gradient,area)
        wrench=np.einsum('nij,nj,n->i',phys,core,geo[:,2]); return np.r_[weak,long],wrench
    def section(tag):
        lam,gamma=q[tag][:2]; d=q[tag][2:]; state=summary[tag]; tensor=T[tag]
        target=np.r_[np.zeros(5),1e5*lam]
        strain=H0@d[:79]; gradient=H0[:,:,:4]@d[79:83]
        expected=np.array([strain+i*.001*gradient for i in (-1,0,1)])
        assert peak(expected-tensor[:,:,:6])<2e-12
        w,c=material_force(tensor[:,:,6:]); w[:79]+=g.T@d[83:]; w[80]-=lam*1e5/scale[0];
        eq=np.r_[25600*g@d[:79],25600*(proj@d-gamma)]
        rows=np.r_[w,(c-target)/scale]; assert len(rows)==89 and len(eq)==5
        errs=[peak(w-state[12:95]),peak((c-state[6:12])/scale),peak(eq[:4]/25600-state[95:99]),abs(eq[-1]-state[4])]
        n=max(peak(rows),abs(eq[-1])); assert max(errs)<2e-10 and abs(n-state[2])<2e-10 and peak(eq)<=state[3]
        return rows,c,n,eq,max(errs)
    points={tag:section(tag) for tag in LABELS}; center=points['Plus18Center'][0]
    assert abs(q['Plus18Center'][0]*1e5-plan['fixedQyN'])<1e-8 and abs(q['Plus18Center'][1]-plan['fixedPositiveGamma'])<2e-16
    for tag in PROBES:
        assert np.array_equal(q[tag][:2],q['Plus18Center'][:2]) and np.array_equal(q[tag][-4:],q['Plus18Center'][-4:])
        expect=np.array(plan['conditionalModel'][tag if tag!='Plus18Repeat' else 'Plus18Center']['field'])
        assert peak(q[tag][2:]-expect[:87])<3e-16 and abs(q[tag][0]-expect[-1])<1e-14
    def source_tensor(z,labels):
        rows={label:np.full((3,184,12),np.nan) for label in labels};
        for kind,tag,ip,side,*pts in csv.reader(z.read('Native/KaniV4Stations.csv').decode('cp1251').splitlines(),delimiter=';'):
            if tag in rows:
                rows[tag][int(side)+1,int(ip)-1]=list(map(float,pts))
        assert all(np.isfinite(x).all() for x in rows.values())
        return rows
    def source_material_branches(z,labels):
        raw={label:np.full((3,184,3),-99) for label in labels}
        for kind,tag,ip,*ppt in csv.reader(z.read('Native/KaniV4Tangents.csv').decode('cp1251').splitlines(),delimiter=';'):
            if kind=='BRANCH' and tag in raw:
                raw[tag][int(ppt[0])+1,int(ip)-1]=list(map(int,ppt[1:]))
        assert all((x!=-99).all() for x in raw.values())
        return raw
    with archived(repo,'KaniH45Plus18NativePortable.zip') as z330, archived(repo,'KaniSecondDirectionNativePortable.zip') as z335:
        first=json.loads(z330.read('Plus18Verification.json')); second=json.loads(z335.read('SecondNativeVerification.json'))
        n1=source_tensor(z330,('Base45','Plus18Center','Plus18TargetPlus')); n2=source_tensor(z335,('Base45','Plus18Center','Plus18TargetPlus'))
        b1=source_material_branches(z330,('Base45','Plus18Center','Plus18TargetPlus')); b2=source_material_branches(z335,('Base45','Plus18Center','Plus18TargetPlus'))
    assert all(np.array_equal(T['Base45'],src['Base45']) for src in (n1,n2)) and all(np.array_equal(b['Base45'],src['Base45']) for src in (b1,b2))
    assert np.array_equal(n1['Plus18TargetPlus'],n2['Plus18Center'])
    assert np.array_equal(T['Plus18TargetMinus'],n1['Plus18Center']) and np.array_equal(T['Plus18TargetPlus'],n2['Plus18TargetPlus'])
    v=n1['Plus18TargetPlus'][:,:,:6]-n1['Plus18Center'][:,:,:6]; w=n2['Plus18TargetPlus'][:,:,:6]-n2['Plus18Center'][:,:,:6]
    mix_shape=T['Plus18Center'][:,:,:6]-T['Plus18TargetMinus'][:,:,:6]
    assert peak(mix_shape-w)<2e-17 and abs(peak(w)-2e-9)<2e-17 and abs(peak(v)-2e-9)<2e-17
    cos=float((v.ravel()@w.ravel())/np.linalg.norm(v)/np.linalg.norm(w)); assert abs(cos)<1e-8
    alladd=np.array(plan['conditionalAll89_MPa']); nv=points['Plus18Center'][0];
    cr=nv-alladd
    r_C=points['Plus18TargetMinus'][0]; r_AW=points['Plus18TargetPlus'][0]; r_A=np.array(first['statuses']['Plus18TargetPlus']['all89Rows_MPa'])
    assert peak(alladd-(r_C+r_AW-r_A))<2e-10
    delta_t=T['Plus18Center'][:,:,6:]-n1['Plus18Center'][:,:,6:]-n2['Plus18TargetPlus'][:,:,6:]+n2['Plus18Center'][:,:,6:]
    qforce,pforce=material_force(delta_t); actual_station_cross=np.r_[qforce,pforce/scale]
    assert peak(cr-actual_station_cross)<2e-10
    edgeA=(b2['Plus18TargetPlus'][:,:,0]!=b2['Plus18Center'][:,:,0]); edgeC=b['Plus18Center'][:,:,0]!=b['Plus18TargetMinus'][:,:,0]
    branch_differ=edgeA ^ edgeC; assert len(cr)==89
    wx=geo[:,2][None,:]*delta_t[:,:,2]; ii,jj=np.unravel_index(int(np.argmax(abs(wx[1]))),wx[1].shape) if wx[1].ndim==2 else (1,int(np.argmax(abs(wx[1]))))
    N_required=float(-alladd[83]*scale[0]-float(summary['Plus18Center'][3])*scale[0]); assert N_required>0
    cross={'nativeInputsSameHistoryFromIndependentArchives':True,'twoExactEarlierCornerTensorsReproduced':True,
           'roles':plan['anchorNames'],'directionCosine':cos,'eachDirectionMaxStationStrain':[peak(v),peak(w)],
           'maxMixedCoordinateChangeFromA':peak(T['Plus18Center'][:,:,:6]-n1['Plus18TargetPlus'][:,:,:6]),
           'maxDeviationFromCombinationAppliedToStrains':peak(mix_shape-w),'lambdaAndGammaExact':True,
           'all89CrossResidualsMPa':cr.tolist(),'crossMaxNormMPa':peak(cr),'all89AdditiveResidualsMPa':alladd.tolist(),
           'stationCrossProjectionErrorMPa':peak(cr-actual_station_cross),'maxAdditiveNormMPa':peak(alladd),'mixedNativeNormMPa':peak(nv),
           'weak80And81CrossMPa':[float(cr[79]),float(cr[80])],'signedSixCross_N_Nmm':pforce.tolist(),
           'estimatedAdditiveSixResiduals_N_Nmm':(alladd[83:]*scale).tolist(),'actualMixedSixResiduals_N_Nmm':(nv[83:]*scale).tolist(),
           'crossNNeededToReachToleranceHere_N':N_required,'normalForceResidualTolerance_N':float(summary['Plus18Center'][3])*scale[0],
           'nativePlasticSwitchCountsEdgeAandC':[int(edgeA.sum()),int(edgeC.sum())],
           'differentPlasticSwitchStationsAcrossEdges':int(branch_differ.sum()),
           'centralNcrossByGeometry_N':{'directConcrete':float(wx[1,:144].sum()),'netReinforced':float(wx[1,144:].sum())},
           'centralNcrossFromDifferentPlasticSwitchStations_N':float(wx[1][branch_differ[1]].sum()),
           'largestCentralNcrossStation':{'point':jj+1,'signedN_N':float(wx[1,jj])}}
    refined=old['resultant_projection']; matrix89={k:np.r_[a[:83],refined@a[:83]] for k,a in M.items()}
    weights=np.array([-1,0,1])[:,None]*((geo[:,2]*geo[:,1])/(305.*610.*length*.002))[None]
    cert={}
    for tag in PROBES:
        rows,wrench,n,five,roundoff=points[tag]; c=T['Plus18Center']; change=T[tag]-c
        w81=weights*change[:,:,8]; delta=rows-center; d=np.r_[q[tag][2:]-q['Plus18Center'][2:],0.]
        assert abs(float(w81.sum())-delta[80])<2e-12
        i,k=np.unravel_index(int(np.argmax(abs(w81))),w81.shape)
        a=plan['conditionalModel'][tag if tag!='Plus18Repeat' else 'Plus18Center']['apexHybrid']['H45Stock']
        cert[tag]={'maxForceRows_MPa':peak(rows),'maxWithControls_MPa':n,'tau_MPa':float(summary[tag][3]),'withinTolerance':bool(n<=summary[tag][3]),
                   'independentNoiseUpper_MPa':roundoff,'dominantRow':int(np.argmax(abs(rows))+1),'all89Rows_MPa':rows.tolist(),
                   'sixWrenches_N_Nmm':wrench.tolist(),'targetQyMiss_N':float(wrench[-1]-q[tag][0]*1e5),'fiveControlsMPa':five.tolist(),
                   'weak81_MPa':float(rows[80]),'weak81Change_MPa':float(delta[80]),'predictedWeak81_MPa':a['row81MPa'],
                   'branchChangesVersusCenter':int(np.count_nonzero(np.any(b[tag]!=b['Plus18Center'],axis=2))),
                   'plasticIncrementSwitchesVersusCenter':int(np.count_nonzero(b[tag][:,:,0]!=b['Plus18Center'][:,:,0])),
                   'FSignChangesVersusCenter':int(np.count_nonzero(np.sign(F[tag])!=np.sign(F['Plus18Center']))),
                   'maxStrainChangeVersusCenter':peak(change[:,:,:6]),
                   'row81Stations':{'directConcrete_MPa':float(w81[:,:144].sum()),'netRebar_MPa':float(w81[:,144:].sum()),
                                      'point8AllSides_MPa':float(w81[:,7].sum()),'largestSidePoint':[int(i)-1,int(k)+1],
                                      'largestContributionMPa':float(w81[i,k])},
                   'measuredDeltaAll89_MPa':delta.tolist(), 'freshTangentErrorAll89_MPa':{k:peak(m@d-delta) for k,m in matrix89.items()},
                   'freshTangentRow81Change_MPa':{k:float((m@d)[80]) for k,m in matrix89.items()}}
    plus=points['Plus18TargetPlus'][0]; minus=points['Plus18TargetMinus'][0]; even=plus+minus-2*center
    result={'workbook':prep['bookSHA256'],'commonQy_N':float(q['Plus18Center'][0]*1e5),'commonGamma':float(q['Plus18Center'][1]),
            'physicalRows':89,'kinematicRows':5,'stationsPerState':552,'recordedStates':len(LABELS),
            'stationProofH45Exact':True,'afterProbesAndReplaySame':True,'statuses':cert,
            'repeatDeterminism':{'repeatRowDifference_MPa':peak(points['Plus18Repeat'][0]-center),
                'repeatTensorDifference':peak(T['Plus18Repeat']-T['Plus18Center']),
                'maxIndependentAssemblyMismatchMPa':max(row[-1] for row in points.values()),
                'crossDifferenceNotNoise_MPa':cross['crossMaxNormMPa']},
            'tangentFlags':dict(zip(('stock','refined','ordinaryFallback'),map(bool,flags))),
            'mixed':cross,'liveInstalledBookSHA256':prep['installedBookSHA256'],'closure':{'compile':closed,'native':end},'nativeSHA256':{file:sha(Z/file) for file in ('KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv')}}
    out=H/'MixedVerification.json'; out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(out,sha(out),[(k,x['weak81_MPa'],x['maxForceRows_MPa']) for k,x in cert.items()],result['tangentFlags'])
    return result

if __name__=='__main__':
    parser=ArgumentParser(); parser.add_argument('--repo-root',type=Path,required=True); a=parser.parse_args()
    verify(a.repo_root.resolve())
