"""Freeze one missing corner of the two measured H45 directions."""
from argparse import ArgumentParser
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from decimal import Decimal,localcontext
import subprocess,csv,json
import numpy as np

H=Path(__file__).resolve().parent; D=H.parent/'kani2'; SRC=Path('docs/regression/Coupled6D')
BOOK=Path('workbook/output/RC_Section_NDM.xlsm'); PRIVATE=Path('docs/regression/Diagnostic.xlsm')
INSTALLED='0B82F8C795B7FE19309FC9AC165BF5016AADBC6E0FE02FA2F3F19DED9A062603'
HISTORICAL='A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A'; GIT='aab6994'
LIVE={Path('src/Solver/CCoupledNewtonSolver.cls'):'9E33A100858D4181123244A0A54F98DF23258B9ABD87CF0E6293C122E371176F',
      Path('src/Solver/CCoupledElasticState.cls'):'A6BF256F42610AE7A353AD4AE1CCC9275DC247B398C3FA429CACD83840C97F94',
      Path('src/Materials/CCoupledConcreteResponse.cls'):'92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C'}
ARCHIVES={'KaniH45Plus18NativePortable.zip':'10FFDC956D9F6D74F6A50A79DF2E50B3C5F7EFE810AEB18A4415D8584E1C5F48',
          'KaniSecondDirectionNativePortable.zip':'66068CCC3E3744B75D8877F635B0FFC1C2D0B6AB65CC1B5819731D8326758DC4',
          'KaniMeasuredSubspacePortable.zip':'E7BB5594610D4DF13C9CF4E9E02E21E719F63AE0A85D27FB9300CB4E4FDEC635',
          'KaniCommitNear48Portable.zip':'EA0A80006AF81D99799B53FDCB75B18CDDE7B7DF730AB16039902F12C6431488',
          'KaniPracticalProbe45Portable.zip':'4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113'}
sha=lambda p:sha256(p.read_bytes() if isinstance(p,Path) else p).hexdigest().upper()
ROLES={'Plus18Center':'MixedCPlusW','Plus18TargetMinus':'OldC','Plus18TargetPlus':'OldAPlusW','Plus18Repeat':'MixedRepeat'}

def frozen_archive(repo,file):
    p=repo/SRC/file; assert sha(p)==ARCHIVES[file],file
    return ZipFile(p)

def live(repo):
    assert H.is_relative_to((repo/'tmp').resolve()) and sha(repo/BOOK)==INSTALLED
    assert all(sha(repo/k)==v for k,v in LIVE.items())
    assert all(sha(repo/SRC/k)==v for k,v in ARCHIVES.items())

def git_blob(repo,element):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',GIT+':'+str(element).replace('\\','/')])

def field_book(z,file):
    return {r[1]:r for r in csv.reader(z.read(file).decode('ascii').splitlines(),delimiter=';')}

def prepare(repo):
    live(repo)
    if (H/'Preparation.json').exists(): return check(repo)
    for path in LIVE:
        checkout=(repo/path).read_bytes().replace(b'\r\n',b'\n')
        historical=git_blob(repo,path).replace(b'\r\n',b'\n')
        assert historical==checkout,path
    old=git_blob(repo,BOOK); assert sha(old)==HISTORICAL
    with frozen_archive(repo,'KaniH45Plus18NativePortable.zip') as a, frozen_archive(repo,'KaniSecondDirectionNativePortable.zip') as b:
        x=field_book(a,'Plus18Fields.csv'); y=field_book(b,'SecondCoordinateDiagnostic.csv')
        C=x['Plus18Center']; A=x['Plus18TargetPlus']; AW=y['SecondImprove']; Y=y['SecondCenter']
        assert A[2:]==Y[2:] and len(A)==len(C)==len(AW)==92 and all(k[3]==C[3] and k[91]==C[91] and k[87:91]==C[87:91] for k in (C,A,AW))
        copy_a=[l for l in a.read('KaniGaugeInput.csv').decode('ascii').splitlines() if l.startswith('KANI_B_FIELD;History')]
        copy_b=[l for l in b.read('KaniGaugeInput.csv').decode('ascii').splitlines() if l.startswith('KANI_B_FIELD;History')]
        assert len(copy_a)==8 and copy_a==copy_b and copy_a[-1].startswith('KANI_B_FIELD;History45;')
        result_a=json.loads(a.read('Plus18Verification.json')); result_b=json.loads(b.read('SecondNativeVerification.json'))
        donor=b.read('docs/regression/CodeUpdate.json'); closure=b.read('Native/CompileClosure.json')
        earlier=b.read('Native/DonorNativeClosure.json'); final=b.read('Native/KaniV4.txt.ProcessClosure.json')
        receipt=json.loads(b.read('Preparation.json'))
    compiled=json.loads(donor); assert compiled['Compiled'] and not compiled['ProductionChanged']
    assert compiled['ProductionSHA256']==HISTORICAL and compiled['WorkbookSHA256']==sha(D/PRIVATE)
    assert all(json.loads(row)['Closure']['FinalState']['State']=='Absent' for row in (earlier,final)) and json.loads(closure)['State']=='Absent'
    with localcontext() as a:
        a.prec=50
        mixture=[format(float(Decimal(c)+Decimal(w)-Decimal(q)),'.17g') for c,q,w in zip(C[4:87],A[4:87],AW[4:87],strict=True)]
    mixed=C[:4]+mixture+C[87:]; assert len(mixed)==92
    def annotate(row,key):
        a=row.copy(); a[1]=key; return a
    frozen=[annotate(mixed,'MixedCPlusW'),annotate(C,'OldC'),annotate(AW,'OldAPlusW')]
    q=[';'.join(annotate(item,name)) for item,name in zip(frozen,list(ROLES)[:3],strict=True)]
    param=lambda z:np.array([*map(float,z[4:-1]),float(z[-1])]); base=param(C); v=param(A)-base; w=param(AW)-param(A)
    assert np.max(abs(param(mixed)-base-w))<5e-17 and np.max(abs(v))<2e-8 and np.max(abs(w))<2e-8
    n0=np.array(result_a['statuses']['Plus18Center']['all89Rows_MPa']); n1=np.array(result_a['statuses']['Plus18TargetPlus']['all89Rows_MPa']); nw=np.array(result_b['statuses']['Plus18TargetPlus']['all89Rows_MPa'])
    expected=n0+nw-n1
    plan={'conditionalModel':{},'anchorNames':ROLES,'fixedQyN':result_a['commonQy_N'],'fixedPositiveGamma':result_a['commonGamma'],
          'independentMixedEvaluatesNonlinearity':True,'storedV':v.tolist(),'storedW':w.tolist(),'conditionalAll89_MPa':expected.tolist(),
          'additiveAxial_N':float(expected[83]*305*610),'originalToleranceMPa':result_a['statuses']['Plus18Center']['tau_MPa'],
          'originalInstalled':INSTALLED,'historicalGitCommit':GIT,'historicalBookSHA256':HISTORICAL}
    for entry,label,r in zip(frozen,list(ROLES),[expected,n0,nw],strict=False):
        plan['conditionalModel'][label]={'field':param(entry).tolist(),'apexHybrid':{'H45Stock':{'row81MPa':float(r[80])}}}
    artifacts={BOOK:old, PRIVATE:(D/PRIVATE).read_bytes(),Path('docs/regression/CodeUpdate.json'):donor,
            Path('Native/CompileClosure.json'):closure,Path('Native/DonorNativeClosure.json'):final,Path('Native/FirstDonorNativeClosure.json'):earlier,
            Path('MixedFields.csv'):('\r\n'.join(';'.join(r) for r in frozen)+'\r\n').encode('ascii'),
            Path('KaniGaugeInput.csv'):('\r\n'.join(copy_a+q)+'\r\n').encode('ascii'),Path('Plus18Plan.json'):(json.dumps(plan,indent=2)+'\n').encode('utf8')}
    for key,value in receipt['frozen'].items():
        if key.startswith('tools/') or key in ('KaniV4Input.csv','KaniChartInput.csv'):
            source=D/key; assert sha(source)==value; artifacts[Path(key)]=source.read_bytes()
    for p,data in artifacts.items():
        destination=H/p; destination.parent.mkdir(parents=True,exist_ok=True); destination.write_bytes(data)
    (H/'Temp').mkdir(exist_ok=True)
    freeze=sorted(set(artifacts)|{Path(k) for k in ('Prepare-Mixed.py','Run-Mixed.ps1','Verify-Mixed.py')})
    p={'bookSHA256':HISTORICAL,'installedBookSHA256':INSTALLED,'donorBookSHA256':compiled['WorkbookSHA256'],
       'sourceGit':GIT,'diagnosticSourceSHA256':{k.as_posix():v for k,v in LIVE.items()},
       'inputZIP_SHA256':ARCHIVES,'frozen':{k.as_posix():sha(H/k) for k in freeze}}
    (H/'Preparation.json').write_text(json.dumps(p,indent=2)+'\n',encoding='utf8')
    return check(repo)

def check(repo):
    live(repo)
    p=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert p['installedBookSHA256']==INSTALLED and p['bookSHA256']==HISTORICAL==sha(H/BOOK)
    assert p['donorBookSHA256']==sha(H/PRIVATE) and all(sha(H/k)==v for k,v in p['frozen'].items())
    return p

if __name__=='__main__':
    ap=ArgumentParser(); ap.add_argument('--repo-root',type=Path,required=True); ap.add_argument('--check',action='store_true'); x=ap.parse_args()
    result=(check if x.check else prepare)(x.repo_root.resolve()); print(result['installedBookSHA256'],sha(H/'Preparation.json'))
