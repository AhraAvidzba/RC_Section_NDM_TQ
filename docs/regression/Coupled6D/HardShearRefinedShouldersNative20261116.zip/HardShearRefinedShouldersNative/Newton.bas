' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считывает уже собранные уравнения для пробной касательной без повторного решения.
Friend Sub CopyHardFoldTrialTest(ByRef load() As Double, ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double, _
        ByRef residual() As Double, ByRef tolerance As Double, ByRef control As Double, _
        ByRef resultantNorm As Double, ByRef projectedSlope As Double, ByRef referenceModulus As Double, _
        ByRef gaugeStart As Long, ByRef isConsistent As Boolean, ByRef hasSides As Boolean)
    RequireCandidate
    residual = mResidual
    tolerance = EquilibriumTolerance(absoluteTolerance, relativeTolerance)
    control = ControlResidual(mCandidate)
    resultantNorm = mSection.ResultantResidualNorm(mTrialResultants, load)
    projectedSlope = mHardFoldSlopeTest
    referenceModulus = mReferenceModulus: gaugeStart = mGaugeStart
    isConsistent = mConsistentControl: hasSides = mUseSpatialHistory
End Sub
