"""Проверяет подлинность плеч, шесть усилий, неопределённость и сохранённый график."""

import argparse
from hashlib import sha256
import json
from math import fsum, isclose, isfinite
from pathlib import Path
import re
from struct import unpack
import subprocess


here = Path(__file__).resolve().parent
repo = here.parents[1]
native = here / "Native"


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def obj(name):
    return json.loads((here / name).read_text(encoding="utf-8-sig"))


def dbl(token):
    assert re.fullmatch(r"[A-F0-9]{16}", token), token
    result, = unpack(">d", bytes.fromhex(token))
    assert isfinite(result)
    return result


def nums(tokens):
    return tuple(map(dbl, tokens))


def near(a, b, abs_tol=2e-14):
    return isclose(a, b, rel_tol=6e-13, abs_tol=abs_tol)


def point(row, projection, previous):
    assert len(row) == 147, len(row)
    order = int(row[1])
    requested, coordinate, factor, uncertainty, steel, tolerance, control, native_force, slope, modulus = nums(row[2:12])
    gauge_start = int(row[12])
    consistent, sides = row[13:15]
    target, actual = nums(row[15:21]), nums(row[21:27])
    field, residual = nums(row[27:87]), nums(row[87:147])
    assert consistent in ("True", "False") and sides == "True"
    assert gauge_start == 57 and modulus == 30000
    assert requested > previous and coordinate > previous
    assert 0 < factor and 0 < uncertainty and 0 <= steel <= 1
    assert near(coordinate, fsum(a*b for a, b in zip(projection[:56], field[:56], strict=True)))
    assert near(control, modulus*(coordinate-requested), 1e-10)
    direction = (28000., 510000., 180000., 1500000., 17000., -7100.)
    scales = (21600., 2219577.365175632, 2219577.365175632, 2219577.365175632, 21600., 21600.)
    assert all(near(t, f*factor) for t, f in zip(target, direction, strict=True))
    force = max(abs(t-a)/scale for t, a, scale in zip(target, actual, scales, strict=True))
    weak = max(map(abs, residual[:gauge_start-1]))
    gauge = modulus*max(map(abs, residual[gauge_start-1:]))
    assert near(native_force, force) and 0 < tolerance
    assert max(abs(control), force, weak, gauge) <= tolerance*(1+1e-10)
    return {"order": order, "requested": requested, "coordinate": coordinate, "lambda": factor,
            "uncertainty": uncertainty, "steel_usage": steel, "weak_residual_MPa": weak,
            "gauge_residual_MPa": gauge, "six_force_residual_MPa": force, "projection_residual_MPa": abs(control),
            "equilibrium_tolerance_MPa": tolerance, "slope": slope, "branch_consistent_mode": consistent == "True",
            "target": target, "resultants": actual, "field_bits": row[27:87]}


def parse(path):
    rows = [line.split(";", 9) if line.startswith("END;") else line.split(";")
            for line in path.read_text(encoding="cp1251").splitlines()]
    assert rows[0] == ["HARDSHEAR-FOLD", "1"]
    records = {}
    restore = None
    active = None
    for row in rows[1:]:
        key = row[0]
        if key == "START":
            assert active is None and len(row) == 10 and row[9] == "7"
            active = {"id": tuple(row[1:3]), "divisions": int(row[3]), "common": row[4:],
                      "guide": None, "prefix_bits": [], "left_bits": None, "points": []}
            assert {"Stock": 2, "Short4": 4, "Short8": 8}[row[1]] == active["divisions"]
        elif key == "END":
            if active is None:
                assert row[3] == "False" and row[8] == "prefix"
                active = {"id": tuple(row[1:3]), "points": []}
            assert active["id"] == tuple(row[1:3])
            if "prefix_bits" in active:
                assert len(active["prefix_bits"]) == 7 and active["left_bits"] == active["prefix_bits"][-1]
            assert row[3] in ("True", "False")
            active.update(signed_maximum=row[3] == "True", native_peak=nums(row[4:8]), stop=row[8], reason=row[9])
            assert active["id"] not in records
            records[active["id"]] = active
            active = None
        elif key == "RESTORE":
            assert active is None and restore is None and row[1] == "11" and len(row) == 62
            restore = row[2:]
        else:
            assert active is not None
            if key == "PROJECTION":
                assert active["guide"] is None and len(row) == 61
                active["guide"] = row[1:]
            elif key == "PREFIX":
                assert int(row[1]) == len(active["prefix_bits"]) + 1 and len(row) == 62
                active["prefix_bits"].append(row[2:])
            elif key == "LEFT":
                assert active["left_bits"] is None and len(row) == 61
                active["left_bits"] = row[1:]
            else:
                assert key == "STEP" and active["left_bits"] is not None
                previous = active["points"][-1]["coordinate"] if active["points"] else dbl(active["common"][0])
                exact = point(row, nums(active["guide"]), previous)
                assert exact["order"] == len(active["points"]) + 1
                active["points"].append(exact)
    assert active is None and restore is not None
    stock, = (arm for (name, _), arm in records.items() if name == "Stock" and arm["signed_maximum"])
    chosen = [stock, records[("Short4", stock["id"][1])], records[("Short8", stock["id"][1])]]
    for arm in chosen:
        assert (arm["common"], arm["guide"], arm["prefix_bits"]) == (stock["common"], stock["guide"], stock["prefix_bits"])
        evaluate(arm)
    assert len(stock["points"]) == 4 and restore == stock["points"][-1]["field_bits"]
    return chosen


def evaluate(arm):
    left, middle, right, factor, uncertainty = nums(arm["common"][:5])
    assert left < middle < right
    n = arm["divisions"]
    assert len(arm["points"]) <= 2*n
    sequence = [{"coordinate": left, "lambda": factor, "uncertainty": uncertainty}] + arm["points"]
    for p in arm["points"]:
        k = p["order"]
        start, finish, index = (left, middle, k) if k <= n else (middle, right, k-n)
        assert near(p["requested"], start + (finish-start)*index/n)
    local_signed = []
    for left_point, center, right_point in zip(sequence, sequence[1:], sequence[2:]):
        lower = center["lambda"]-center["uncertainty"]
        upper_neighbors = max(p["lambda"]+p["uncertainty"] for p in (left_point, right_point))
        if lower <= upper_neighbors:
            continue
        local_signed.append({"coordinate_interval": [left_point["coordinate"], right_point["coordinate"]],
                             "sample_coordinate": center["coordinate"], "sample_lambda_interval":
                                 [lower, center["lambda"]+center["uncertainty"]], "signed_margin": lower-upper_neighbors})
    arm["robust_local_samples"] = local_signed
    arm["completed_shoulder"] = len(arm["points"]) == 2*n
    if arm["signed_maximum"]:
        location, peak, unc, _ = arm["native_peak"]
        assert arm["completed_shoulder"] and arm["stop"] == "complete"
        assert any(x["sample_coordinate"] == location and near(x["sample_lambda_interval"][0], peak-unc) for x in local_signed)


def verify(config):
    from ReadChart import read_series

    log = native / "HardShear.txt"
    trace = native / "HardFold.csv"
    info = obj("docs/regression/CodeUpdate.json")
    compiler = obj("CompileClosure.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    receipt = obj("Native/HardShear.txt.ProcessClosure.json")
    assert info["Compiled"] and not info["ProductionChanged"]
    assert info["ProductionSHA256"] == config["source_workbook_sha256"]
    assert sorted(info["Modules"]) == ["CCoupledDeformationContinuation", "CCoupledNewtonSolver", "modTestCoupledElasticState"]
    assert compiler["State"] == "Absent" and owner["SourceSHA256"] == info["WorkbookSHA256"]
    closure = receipt["Closure"]["FinalState"]
    assert receipt["Passed"] and closure["State"] == "Absent" and receipt["ChildExitCode"] == 0
    assert owner["PID"] == closure["PID"] and owner["StartTicksUTC"] == closure["StartTicksUTC"]
    report = log.read_text(encoding="utf-8-sig")
    assert "TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0" in report
    assert "TOTAL_HARD_SHEAR_FOLD: passed=1; failed=0" in report
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in report
    saved = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", report, re.M)
    timing = re.search(r"^TIMING_SECONDS: ([\d.,]+) \| Both \| Excel$", report, re.M)
    state = re.search(r"^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([^;]+); limit=; code=NUMERICAL_FAILURE", report, re.M)
    assert saved and timing and state
    assert "Диагностическая остановка после сохранения уточнённых плеч." in report
    saved_book = Path(saved[2]).resolve()
    assert saved_book.is_relative_to(here / "Temp")
    chart, series = read_series(saved_book)
    indices, multipliers = series["Поиск предела"]
    arms = parse(trace)
    stock_lambda = [dbl(arms[0]["common"][3])] + [p["lambda"] for p in arms[0]["points"]]
    assert indices == list(range(1, 12)) and len(multipliers) == 11
    assert all(near(a, b, 5e-14) for a, b in zip(stock_lambda, multipliers[6:], strict=True))
    assert near(float(state[1].replace(",", ".")), 1.10290889219566)
    assert near(max(multipliers), arms[0]["native_peak"][1])
    return {"source_workbook_sha256": config["source_workbook_sha256"], "diagnostic_workbook_sha256": owner["SourceSHA256"],
            "native_log_sha256": digest(log), "trace_sha256": digest(trace), "diagnostic_seconds": float(timing[1].replace(",", ".")),
            "verified_results_reopen": saved[1], "saved_workbook_sha256": digest(saved_book), "chart": chart,
            "comparison_prefix_is_bit_identical": True, "stock_H7_through_H11": multipliers[6:], "arms": arms,
            "force_controlled_tangent_rank": "open", "global_or_physical_limit_verified": False}


def check_inputs(config):
    assert all(digest(here / name) == value for name, value in config["inputs"].items())
    assert digest(here / config["workbook"]) == config["source_workbook_sha256"]
    assert digest(repo / config["workbook"]) == config["source_workbook_sha256"]
    for name, expected in config["production"].items():
        raw = subprocess.check_output(["git", "show", f"{config['source_revision']}:{name}"], cwd=repo)
        assert sha256(raw).hexdigest().upper() == expected


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", action="store_true")
    config = obj("Fixture.json")
    check_inputs(config)
    if parser.parse_args().inputs:
        print("INPUTS", digest(here / "Fixture.json"))
    else:
        output = native / "Verification.json"
        output.write_bytes((json.dumps(verify(config), indent=2) + "\n").encode())
        print("HARD SHEAR FOLD", digest(output))
