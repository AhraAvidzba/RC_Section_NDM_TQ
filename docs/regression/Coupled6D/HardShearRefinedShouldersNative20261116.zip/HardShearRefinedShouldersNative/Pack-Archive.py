"""Запечатывает нативную пробу с точными полями и сохранённым графиком."""

from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_output, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import Verify

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ARCHIVE = HERE / "HardShearRefinedShouldersNative20261116.zip"
PREFIX = "HardShearRefinedShouldersNative"
NATIVE = HERE / "Native"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def serialized(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def main():
    fixture = Verify.obj("Fixture.json")
    Verify.check_inputs(fixture)
    raw_log = NATIVE / "HardShear.txt"
    log = raw_log.read_text(encoding="utf-8-sig")
    receipt = Verify.obj("Native/HardShear.txt.ProcessClosure.json")
    owner = Verify.obj("Native/HardShear.txt.Ownership.json")
    final = receipt["Closure"]["FinalState"]
    assert final["State"] == "Absent" and owner["PID"] == final["PID"] and owner["StartTicksUTC"] == final["StartTicksUTC"]
    assert "WATCHDOG_COMPLETED:" in log or receipt["ChildExitCode"] != 0
    audit = {"source_revision": fixture["source_revision"], "owner_pid": owner["PID"],
             "owner_start_ticks_utc": owner["StartTicksUTC"], "native_process_absent": True,
             "native_watchdog_passed": receipt["Passed"], "native_exit_code": receipt["ChildExitCode"],
             "native_report_sha256": digest(raw_log.read_bytes())}
    files = {}
    saved = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", log, re.M)
    saved_path = None
    if saved:
        from ReadChart import read_series

        saved_path = Path(saved[2]).resolve(strict=True)
        assert saved_path.is_relative_to(HERE / "Temp")
        part, _ = read_series(saved_path)
        with ZipFile(saved_path) as workbook:
            info = workbook.getinfo(part)
            chart = workbook.read(info)
        files["Native/SavedChart.xml"] = chart
        audit["saved_chart"] = {"original_workbook_sha256": digest(saved_path.read_bytes()),
                                 "results_reopen_sha256": saved[1], "member": part,
                                 "member_sha256": digest(chart), "zip_crc32": info.CRC}
    run_result = run([sys.executable, "-B", "-X", "utf8", "Verify.py"], cwd=HERE, capture_output=True, check=False)
    files["IndependentVerify.stdout.txt"] = run_result.stdout
    files["IndependentVerify.stderr.txt"] = run_result.stderr
    audit["independent_verifier_exit_code"] = run_result.returncode
    audit["overall"] = "VERIFIED" if receipt["Passed"] and run_result.returncode == 0 else "UNRESOLVED"
    if audit["overall"] == "VERIFIED":
        assert saved_path is not None
        audit["verification_sha256"] = Verify.digest(NATIVE / "Verification.json")
        result = Verify.obj("Native/Verification.json")
        audit["diagnostic_seconds"] = result["diagnostic_seconds"]
        audit["stock_H7_through_H11"] = result["stock_H7_through_H11"]
        audit["arms"] = [
            {"name": arm["id"][0], "accepted_points": len(arm["points"]),
             "completed_shoulder": arm["completed_shoulder"], "stop": arm["stop"],
             "verified_local_samples": arm["robust_local_samples"],
             "rerun_peak": arm["native_peak"][:3] if arm["signed_maximum"] else None,
             "unassigned_native_exit_values_are_excluded": not arm["signed_maximum"]}
            for arm in result["arms"]
        ]
        audit["force_controlled_tangent_rank"] = "open"
        audit["physical_limit_verified"] = False
    for name, expected in fixture["inputs"].items():
        raw = (HERE / name).read_bytes()
        assert digest(raw) == expected, name
        files[name] = raw
    for name, expected in fixture["production"].items():
        raw = check_output(["git", "show", f"{fixture['source_revision']}:{name}"], cwd=REPO)
        assert digest(raw) == expected, name
        files[f"Baseline/{name}"] = raw
    for name in ("Fixture.json", "Run-Compiled.ps1", "Pack-Archive.py", "Verify-Archive.py", "README-Archive.md",
                 "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json"):
        files[name] = (HERE / name).read_bytes()
    for file in sorted(NATIVE.iterdir()):
        if file.is_file() and file.suffix.lower() != ".xlsm":
            files[f"Native/{file.name}"] = file.read_bytes()
    if "Native/HardFold.csv" not in files:
        copies = list((HERE / "Temp").glob("RC_NDM_ModeSuite_*/HardFold.csv"))
        assert len(copies) <= 1
        if copies:
            files["Native/HardFold.csv"] = copies[0].read_bytes()
    files["Audit.json"] = serialized(audit)
    files["SHA256SUMS.json"] = serialized({name: digest(raw) for name, raw in sorted(files.items())})
    with TemporaryDirectory(prefix="fold-proof-", dir=HERE) as directory:
        scratch = Path(directory)
        artifact = scratch / ARCHIVE.name
        with ZipFile(artifact, "w", ZIP_DEFLATED, compresslevel=9) as zip:
            for name, raw in sorted(files.items()):
                entry = ZipInfo(f"{PREFIX}/{name}", date_time=(2026, 11, 16, 0, 0, 0))
                zip.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(artifact) as zip:
            assert zip.testzip() is None and not any(n.lower().endswith(".xlsm") for n in zip.namelist())
            zip.extractall(scratch / "detached")
        cmd = [sys.executable, "-B", "-X", "utf8", "Verify-Archive.py"]
        run(cmd, cwd=scratch / "detached" / PREFIX, check=True)
        if saved_path:
            run([*cmd, "--saved-workbook", str(saved_path)], cwd=scratch / "detached" / PREFIX, check=True)
        ARCHIVE.write_bytes(artifact.read_bytes())
    checksum = Verify.digest(ARCHIVE)
    ARCHIVE.with_suffix(".zip.sha256").write_bytes(f"{checksum}  {ARCHIVE.name}\n".encode("ascii"))
    print("PORTABLE", audit["overall"], checksum, ARCHIVE.stat().st_size)


if __name__ == "__main__":
    main()
