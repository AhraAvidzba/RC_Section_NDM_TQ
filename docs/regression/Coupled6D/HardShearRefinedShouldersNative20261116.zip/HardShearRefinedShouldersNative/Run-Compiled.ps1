# Запускает уже проверенную компилятором копию HardShear.
param(
    [Parameter(Mandatory)]
    [switch]$CompiledOnly,
    [switch]$VerifyInputsOnly
)

$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$report='Native/HardShear.txt'
$compiledSha='A0FFA4CECF38A418E39149053FE1EA738684680CB6137F2A6B8C1F97398FC102'
$compileFiles=[ordered]@{
    'Compile.log'='5949C0D51EFAFDC38E0371AE198A56AF734B2F88D188A949FF3D6A7F5C63FABA'
    'CompileClosure.json'='B5A73743735078D6E80ADED9AB83D8EB3FA987717E403F268BF0AA69760D91CD'
    'docs/regression/CodeUpdate.json'='001AF437B8386E89AA075A408B623C5E40DB3C583826DA1FED08266D67CF5522'
}

Push-Location -LiteralPath $root
try {
    if (!$CompiledOnly) {throw 'Укажите CompiledOnly для запуска из уже скомпилированной книги.'}
    python -B -X utf8 'Verify.py' --inputs
    if ($LASTEXITCODE) {throw 'Входы проверки HardShear не подтверждены.'}
    $fixture=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    foreach ($file in $compileFiles.Keys) {
        if ((Get-FileHash -LiteralPath $file).Hash -cne $compileFiles[$file]) {throw "Изменился протокол компиляции $file."}
    }
    $info=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closed=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$info.Compiled -or $info.ProductionChanged -or $info.ProductionSHA256 -cne $fixture.source_workbook_sha256 -or
        $info.Workbook -ine (Resolve-Path -LiteralPath $draft).Path -or $info.WorkbookSHA256 -cne $compiledSha -or
        (Get-FileHash -LiteralPath $draft).Hash -cne $compiledSha -or $info.RetiredModules.Count -or
        $info.EntryPointNames.Count -or $info.TraceGeometry -or
        ($info.Modules -join ',') -cne 'CCoupledDeformationContinuation,CCoupledNewtonSolver,modTestCoupledElasticState') {
        throw 'Хеш и состав скомпилированной книги должны совпадать с протоколом.'
    }
    $records=@(Get-Content -LiteralPath 'Compile.log' -Encoding utf8)
    $owner=@($records | Where-Object {$_ -ceq "OWNED_EXCEL: id=$($closed.PID); utcStartTicks=$($closed.StartTicksUTC)"})
    if ($closed.State -cne 'Absent' -or $owner.Count -ne 1 -or
        $records[-1] -cne 'PRIVATE_CODE_READY: modules=3; production unchanged=True') {
        throw 'Нет подтверждения закрытия Excel после компиляции.'
    }
    if (Get-Process -Id $closed.PID -ErrorAction SilentlyContinue) {throw "PID $($closed.PID) ещё занят."}
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Превышена длина пути фикстуры Excel.'
    }
    if (@(Get-ChildItem -LiteralPath 'Native' -Force).Count -or
        @(Get-ChildItem -LiteralPath 'Temp' -Force -Filter 'RC_NDM_ModeSuite_*').Count) {
        throw 'Есть данные уже запущенной нативной проверки.'
    }
    Write-Output "COMPILED_INPUTS_OK: sha256=$compiledSha; compilerPID=$($closed.PID); state=Absent"
    if ($VerifyInputsOnly) {return}
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    Assert-IsolatedOfficeReady 'RunHardShearFoldCompiledOnly'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $draft -ReportPath $report -Macro 'modTestCoupledElasticState.RunTestHardShearFold' `
        -Mode No -TimeoutSeconds $fixture.watchdog_seconds -FailFast -VerifyResultsReopen
    $nativeExit=$LASTEXITCODE
    if (Test-Path -LiteralPath $report) {
        $origin=@(Get-Content -LiteralPath $report -Encoding utf8 | Where-Object {$_ -like 'FIXTURE: *'})
        if ($origin.Count -eq 1) {
            $folder=Split-Path -Parent $origin[0].Substring('FIXTURE: '.Length)
            if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Нативная фикстура за рабочим каталогом.'}
            $trace=Join-Path $folder 'HardFold.csv'
            if (Test-Path -LiteralPath $trace) {Copy-Item -LiteralPath $trace -Destination 'Native/HardFold.csv'}
        }
    }
    if ($nativeExit) {throw "Нативная проверка HardShear завершилась с кодом $nativeExit."}
    python -B -X utf8 'Verify.py'
    if ($LASTEXITCODE) {throw 'Независимая сверка плеч не пройдена.'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
