' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет общий префикс полей и одну проекцию деформации для каждого плеча.
Private Sub RecordHardFoldStartTest(ByVal history As Collection, ByRef left As TBranchPoint, _
        ByRef middle As TBranchPoint, ByRef right As TBranchPoint, ByVal divisions As Long)
    Dim index As Long, field() As Double
    WriteHardFoldRowTest "START;" & mHardFoldArmTest & ";" & CStr(mHardFoldAttemptTest) & ";" & CStr(divisions) & ";" & _
        HardFoldBitsTest(left.Coordinate) & ";" & HardFoldBitsTest(middle.Coordinate) & ";" & HardFoldBitsTest(right.Coordinate) & ";" & _
        HardFoldBitsTest(left.Lambda) & ";" & HardFoldBitsTest(left.Uncertainty) & ";" & CStr(left.HistoryIndex)
    WriteHardFoldRowTest "PROJECTION;" & HardFoldVectorTest(mProjection)
    For index = 1 To left.HistoryIndex
        field = history.Item(index)
        WriteHardFoldRowTest "PREFIX;" & CStr(index) & ";" & HardFoldVectorTest(field)
    Next index
    mSolver.CopyAccepted field
    WriteHardFoldRowTest "LEFT;" & HardFoldVectorTest(field)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт невязки и принятые значения в исходных координатах.
Private Sub RecordHardFoldPointTest(ByRef point As TBranchPoint, ByVal localIndex As Long, ByVal requested As Double)
    Dim field() As Double, measured() As Double, force() As Double, residual() As Double
    Dim tolerance As Double, controlResidual As Double, resultantNorm As Double, slope As Double
    Dim referenceModulus As Double, gaugeStart As Long, isConsistent As Boolean, hasSides As Boolean
    mSolver.CopyTrial field, measured
    ReDim force(1 To COMPONENT_COUNT)
    Dim i As Long, steel As Double
    For i = 1 To COMPONENT_COUNT: force(i) = mOffset(i) + point.Lambda * mDirection(i): Next i
    mSolver.CopyHardFoldTrialTest force, mAbsTol, mRelTol, residual, tolerance, controlResidual, resultantNorm, slope, _
        referenceModulus, gaugeStart, isConsistent, hasSides
    If Not mReinforcement Is Nothing Then steel = mReinforcement.TrialSteelUtilization
    WriteHardFoldRowTest "STEP;" & CStr(localIndex) & ";" & HardFoldBitsTest(requested) & ";" & _
        HardFoldBitsTest(point.Coordinate) & ";" & HardFoldBitsTest(point.Lambda) & ";" & HardFoldBitsTest(point.Uncertainty) & ";" & _
        HardFoldBitsTest(steel) & ";" & HardFoldBitsTest(tolerance) & ";" & HardFoldBitsTest(controlResidual) & ";" & _
        HardFoldBitsTest(resultantNorm) & ";" & HardFoldBitsTest(slope) & ";" & HardFoldBitsTest(referenceModulus) & ";" & _
        CStr(gaugeStart) & ";" & CStr(isConsistent) & ";" & CStr(hasSides) & ";" & HardFoldVectorTest(force) & ";" & _
        HardFoldVectorTest(measured) & ";" & HardFoldVectorTest(field) & ";" & HardFoldVectorTest(residual)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Два коротких шага обследуются только после подтверждения штатных плеч.
' Восстанавливает все штатные поля до публикации и не переносит пробные значения в Results.
Private Sub CheckHardFoldShorterTest(ByVal history As Collection, ByVal accepted As Collection, _
        ByRef commonLeft As TBranchPoint, ByRef commonMiddle As TBranchPoint, ByRef commonRight As TBranchPoint)
    Dim i As Long, left As TBranchPoint, middle As TBranchPoint, right As TBranchPoint, peak As TBranchPoint
    Dim probes As Long: probes = mProbeCount
    Dim shoulderProbes As Long: shoulderProbes = mShoulderProbes
    Dim recoveryProbes As Long: recoveryProbes = mYieldRecoveryProbes
    Dim details As String: details = mProbeDetails
    Dim sampling As Double, solved As Boolean, divisions As Long
    For i = 1 To 2
        left = commonLeft: middle = commonMiddle: right = commonRight
        If i = 1 Then divisions = 4 Else divisions = 8
        mHardFoldArmTest = "Short" & CStr(divisions)
        mProbeDetails = vbNullString
        ' Армированная ветвь сохраняет знак lambda и проверяет весь спад.
        solved = ReplayShoulders(history, left, middle, right, divisions, peak, sampling, keepRight:=True)
        EndHardFoldReplayTest solved, peak, sampling
        mHardFoldArmTest = vbNullString
    Next i
    mProbeCount = probes: mShoulderProbes = shoulderProbes: mYieldRecoveryProbes = recoveryProbes
    mProbeDetails = details
    If Not mSolver.ReplayAcceptedFields(accepted, accepted.Count) Then _
        Err.Raise 5, "CheckHardFoldShorterTest", "Не удалось восстановить штатную ветвь после теста."
    Dim field() As Double
    mSolver.CopyAccepted field
    WriteHardFoldRowTest "RESTORE;" & CStr(accepted.Count) & ";" & HardFoldVectorTest(field)
    HardFoldFinishedTest = True
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует результат текущего прохода и первую остановку, если она была.
Private Sub EndHardFoldReplayTest(ByVal solved As Boolean, ByRef peak As TBranchPoint, ByVal sampling As Double)
    Dim reason As String
    reason = Replace(Replace(Replace(mProbeDetails, vbCr, " "), vbLf, " "), ";", "|")
    WriteHardFoldRowTest "END;" & mHardFoldArmTest & ";" & CStr(mHardFoldAttemptTest) & ";" & CStr(solved) & ";" & _
        HardFoldBitsTest(peak.Coordinate) & ";" & HardFoldBitsTest(peak.Lambda) & ";" & HardFoldBitsTest(peak.Uncertainty) & ";" & _
        HardFoldBitsTest(sampling) & ";" & mHardFoldStopTest & ";" & reason
End Sub
