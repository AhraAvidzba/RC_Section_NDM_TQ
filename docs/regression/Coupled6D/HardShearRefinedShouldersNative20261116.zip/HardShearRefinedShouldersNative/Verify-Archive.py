"""Повторяет сверку пробы отдельно от рабочей копии."""

import argparse
import json
from pathlib import Path
import re
from xml.etree import ElementTree
from zipfile import ZipFile
from zlib import crc32

from ReadChart import cached_coordinates, CHART_NS
from Verify import dbl, digest, near, obj, parse

HERE = Path(__file__).resolve().parent
NATIVE = HERE / "Native"


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--saved-workbook", type=Path)
    args = cli.parse_args()
    manifest = obj("SHA256SUMS.json")
    actual = {file.relative_to(HERE).as_posix() for file in HERE.rglob("*")
              if file.is_file() and file.name != "SHA256SUMS.json"}
    assert actual == set(manifest)
    assert all(digest(HERE / name) == expected for name, expected in manifest.items())
    config = obj("Fixture.json")
    assert all(manifest[name] == expected for name, expected in config["inputs"].items())
    assert all(manifest[f"Baseline/{name}"] == expected for name, expected in config["production"].items())
    audit = obj("Audit.json")
    compiler = obj("CompileClosure.json")
    code = obj("docs/regression/CodeUpdate.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    closure = obj("Native/HardShear.txt.ProcessClosure.json")
    final = closure["Closure"]["FinalState"]
    assert audit["source_revision"] == config["source_revision"] and code["Compiled"] and not code["ProductionChanged"]
    assert code["ProductionSHA256"] == config["source_workbook_sha256"]
    assert owner["SourceSHA256"] == code["WorkbookSHA256"]
    assert compiler["State"] == "Absent" and f"OWNED_EXCEL: id={compiler['PID']}; utcStartTicks={compiler['StartTicksUTC']}" in (
        HERE / "Compile.log").read_text(encoding="utf-8-sig")
    assert final["State"] == "Absent" and owner["PID"] == final["PID"] == audit["owner_pid"]
    assert owner["StartTicksUTC"] == final["StartTicksUTC"] == audit["owner_start_ticks_utc"]
    assert closure["Passed"] == audit["native_watchdog_passed"]
    assert closure["ChildExitCode"] == audit["native_exit_code"]
    assert manifest["Native/HardShear.txt"] == audit["native_report_sha256"]
    log = (NATIVE / "HardShear.txt").read_text(encoding="utf-8-sig")
    chart = None
    if "saved_chart" in audit:
        pin = audit["saved_chart"]
        xml = (NATIVE / "SavedChart.xml").read_bytes()
        assert crc32(xml) == pin["zip_crc32"] and manifest["Native/SavedChart.xml"] == pin["member_sha256"]
        assert f"RESULTS_SAVE_REOPEN: before={pin['results_reopen_sha256']}; after={pin['results_reopen_sha256']}; equal=True" in log
        if args.saved_workbook:
            assert digest(args.saved_workbook) == pin["original_workbook_sha256"]
            with ZipFile(args.saved_workbook) as xlsm:
                assert xlsm.read(pin["member"]) == xml
        chart = ElementTree.fromstring(xml)
    if audit["overall"] != "VERIFIED":
        assert not closure["Passed"] or audit["independent_verifier_exit_code"] != 0
        print("HardShear portable evidence: UNRESOLVED")
        print("Native watchdog exit:", closure["ChildExitCode"])
        print("Independent verifier exit:", audit["independent_verifier_exit_code"])
        return
    assert closure["Passed"] and closure["ChildExitCode"] == 0 and audit["independent_verifier_exit_code"] == 0
    assert chart is not None
    report = obj("Native/Verification.json")
    assert manifest["Native/Verification.json"] == audit["verification_sha256"]
    assert report["trace_sha256"] == manifest["Native/HardFold.csv"]
    assert report["native_log_sha256"] == audit["native_report_sha256"]
    assert report["chart"] == audit["saved_chart"]["member"]
    assert report["saved_workbook_sha256"] == audit["saved_chart"]["original_workbook_sha256"]
    assert report["force_controlled_tangent_rank"] == "open" and not report["global_or_physical_limit_verified"]
    arm = parse(NATIVE / "HardFold.csv")
    assert json.loads(json.dumps(arm)) == report["arms"]
    assert audit["force_controlled_tangent_rank"] == "open" and not audit["physical_limit_verified"]
    for summary, recorded in zip(audit["arms"], arm, strict=True):
        assert summary["name"] == recorded["id"][0] and summary["accepted_points"] == len(recorded["points"])
        assert summary["completed_shoulder"] == recorded["completed_shoulder"] and summary["stop"] == recorded["stop"]
        assert summary["verified_local_samples"] == recorded["robust_local_samples"]
        assert summary["unassigned_native_exit_values_are_excluded"] == (not recorded["signed_maximum"])
        assert summary["rerun_peak"] == (list(recorded["native_peak"][:3]) if recorded["signed_maximum"] else None)
    series = {entry.findtext("./c:tx//c:v", namespaces=CHART_NS): entry
              for entry in chart.findall(".//c:ser", CHART_NS)}
    target = series["Заданная точка"]
    last = series["Последняя точка поиска"]
    assert cached_coordinates(target, "yVal") == [1.]
    capacity = series["Поиск предела"]
    indices, multipliers = cached_coordinates(capacity, "xVal"), cached_coordinates(capacity, "yVal")
    assert indices == list(range(1, len(multipliers)+1))
    assert cached_coordinates(last, "xVal") == [indices[-1]] and cached_coordinates(last, "yVal") == [multipliers[-1]]
    stock = [dbl(arm[0]["common"][3])] + [p["lambda"] for p in arm[0]["points"]]
    assert len(multipliers) == 11 and multipliers[6:] == report["stock_H7_through_H11"]
    assert all(near(a, b) for a, b in zip(stock, multipliers[6:], strict=True))
    state = re.search(r"^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([^;]+); limit=; code=NUMERICAL_FAILURE", log, re.M)
    timing = re.search(r"^TIMING_SECONDS: ([\d.,]+) \| Both \| Excel$", log, re.M)
    assert state and timing and near(float(state[1].replace(",", ".")), max(multipliers))
    assert float(timing[1].replace(",", ".")) == report["diagnostic_seconds"]
    assert "TOTAL_COUPLED_WORKBOOK_TIMING: passed=28; failed=0" in log
    print("HardShear portable evidence: VERIFIED")
    for recorded in arm:
        print(recorded["id"][0], len(recorded["points"]), "points", recorded["stop"],
              "signed local samples", len(recorded["robust_local_samples"]))


if __name__ == "__main__":
    main()
