"""Замораживает изолированную проверку точных плеч HardShear."""

from hashlib import sha256
import json
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
repo = here.parents[1]
revision = "c9e7268fe8b7c3c40edca958d137eb0531a53c19"
book = "workbook/output/RC_Section_NDM.xlsm"
continuation = "src/Solver/CCoupledDeformationContinuation.cls"
newton = "src/Solver/CCoupledNewtonSolver.cls"
test = "tests/modTestCoupledElasticState.bas"
workbook = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, content):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == content, path
    else:
        path.write_bytes(content)
    return digest(content)


def once(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)


def vba(source):
    return source.rstrip().replace("\n", "\r\n").encode("utf-8") + b"\r\n"


def unit(name):
    return (here / name).read_text(encoding="utf-8")


def stage():
    installed = (repo / book).read_bytes()
    assert digest(installed) == workbook
    save(book, installed)
    save("docs/regression/Diagnostic.xlsm", installed)
    for folder in ("Temp", "Native"):
        (here / folder).mkdir(exist_ok=True)
    inputs = {}
    source = {}
    production = {}
    for name in (continuation, newton, test):
        git_raw = subprocess.check_output(["git", "show", f"{revision}:{name}"], cwd=repo)
        source[name] = git_raw.decode("utf-8-sig").replace("\r\n", "\n")
        production[name] = digest(git_raw)
        assert (repo / name).read_text(encoding="utf-8-sig") == source[name], name

    src = source[continuation]
    src = once(src, "Private mTrace As CCoupledLoadTrace", """Private mHardFoldArmTest As String, mHardFoldStopTest As String, mHardFoldAttemptTest As Long
Private mTrace As CCoupledLoadTrace""")
    src = once(src, "                ResumeAfterLocalPeak history, current, trial", """                ResumeAfterLocalPeak history, current, trial
                If HardFoldFinishedTest Then
                    StopSearch "Диагностическая остановка после сохранения уточнённых плеч."
                    Exit Sub
                End If""")
    src = once(src, """    If keepRight Then
        If Not ReplayShoulders(history, checkedLeft, middle, checkedRight, 2, second, sampling, refinedFields, actual, True, retainedMaximum, refinedDesignLeft, _
                retainedPreviousMaximum) Then Exit Function""", """    Dim captureTest As Boolean, replayed As Boolean
    Dim leftTest As TBranchPoint, middleTest As TBranchPoint, rightTest As TBranchPoint
    If keepRight Then
        captureTest = HardFoldRequestedTest And (sharedPrefix = 7)
        If captureTest Then
            leftTest = left: middleTest = middle: rightTest = right
            mHardFoldAttemptTest = mHardFoldAttemptTest + 1
            mHardFoldArmTest = "Stock"
        End If
        replayed = ReplayShoulders(history, checkedLeft, middle, checkedRight, 2, second, sampling, refinedFields, actual, True, retainedMaximum, refinedDesignLeft, _
                retainedPreviousMaximum)
        If captureTest Then
            EndHardFoldReplayTest replayed, second, sampling
            mHardFoldArmTest = vbNullString
        End If
        If Not replayed Then Exit Function""")
    src = once(src, "    VerifyPeak = True\nEnd Function", """    If captureTest Then CheckHardFoldShorterTest history, refinedFields, leftTest, middleTest, rightTest
    VerifyPeak = True
End Function""")
    target = src.index("Private Function ReplayShoulders(")
    pre, replay = src[:target], src[target:]
    finish = replay.index("\nEnd Function")
    replay, post = replay[:finish], replay[finish:]
    replay = once(replay, "    If Not mSolver.ReplayAcceptedFields(history, left.HistoryIndex) Then Exit Function", """    mHardFoldStopTest = "prefix"
    If Not mSolver.ReplayAcceptedFields(history, left.HistoryIndex) Then Exit Function
    If Len(mHardFoldArmTest) > 0 Then RecordHardFoldStartTest history, left, middle, right, divisions""")
    replay = once(replay, "    Dim saveFields As Boolean, refined As Collection, integrated As Collection", """    Dim saveFields As Boolean, refined As Collection, integrated As Collection
    Dim requestedTest As Double""")
    replay = once(replay, "            If point.Coordinate <= samples(index).Coordinate Then", """            requestedTest = point.Coordinate
            mHardFoldStopTest = "requested-progress"
            If point.Coordinate <= samples(index).Coordinate Then""")
    replay = once(replay, "            If Not Probe(point, previousLambda) Then Exit Function\n            If Not UpdateTrialCoordinate", """            mHardFoldStopTest = "probe"
            If Not Probe(point, previousLambda) Then Exit Function
            mHardFoldStopTest = "actual-progress"
            If Not UpdateTrialCoordinate""")
    replay = once(replay, "            If BeyondSteelLimit()", '            mHardFoldStopTest = "physical-guard"\n            If BeyondSteelLimit()')
    replay = once(replay, "            If Not mSolver.TrialLambdaUncertainty", '            mHardFoldStopTest = "uncertainty"\n            If Not mSolver.TrialLambdaUncertainty')
    replay = once(replay, "            If keepRight And point.Lambda <= 0# Then", '            mHardFoldStopTest = "positive-ray"\n            If keepRight And point.Lambda <= 0# Then')
    replay = once(replay, "            mSolver.AcceptStep", """            If Len(mHardFoldArmTest) > 0 Then RecordHardFoldPointTest point, index + 1, requestedTest
            mSolver.AcceptStep""")
    replay = once(replay, "    Dim peakIndex As Long, lower As Double", '    mHardFoldStopTest = "signed-neighbors"\n    Dim peakIndex As Long, lower As Double')
    replay = once(replay, "    ReplayShoulders = True", '    mHardFoldStopTest = "complete"\n    ReplayShoulders = True')
    inputs[continuation] = save(continuation, vba(pre + replay + post + "\n" + unit("Trace.bas")))

    src = once(source[newton], "Private mConsistentControl As Boolean", """Private mHardFoldSlopeTest As Double
Private mConsistentControl As Boolean""")
    src = once(src, "    TrialLambdaUncertainty = True", """    mHardFoldSlopeTest = weights(size) * mReferenceModulus
    TrialLambdaUncertainty = True""")
    inputs[newton] = save(newton, vba(src + "\n" + unit("Newton.bas")))
    src = once(source[test], "Option Explicit", """Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Флаги действуют только при вызове пробного сценария рабочей копии.
Public HardFoldRequestedTest As Boolean, HardFoldFinishedTest As Boolean

Private Type THardFoldNumberTest
    Value As Double
End Type

Private Type THardFoldWordsTest
    Low As Long
    High As Long
End Type""")
    inputs[test] = save(test, vba(src + "\n" + unit("Native.bas")))
    template = here.parent / "hs-live-depth"
    source_fixture = json.loads((template / "Fixture.json").read_bytes())
    for name, expected in source_fixture["inputs"].items():
        if not (name.startswith("tools/build_workbook/") or name in ("Guard-IsolatedOffice.ps1", "ReadChart.py")):
            continue
        raw = (template / name).read_bytes()
        assert digest(raw) == expected, name
        inputs[name] = save(name, raw)
    for name in ("Run.ps1", "Verify.py", "Stage.py", "Trace.bas", "Newton.bas", "Native.bas"):
        inputs[name] = digest((here / name).read_bytes())
    manifest = {"source_workbook_sha256": workbook, "source_revision": revision,
                "workbook": book, "production": production, "inputs": inputs,
                "divisions": [2, 4, 8], "shared_prefix": 7, "watchdog_seconds": 150}
    print(save("Fixture.json", (json.dumps(manifest, indent=2) + "\n").encode()))


if __name__ == "__main__":
    stage()
