' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запускает пользовательский путь Both с остановкой после уточнённых плеч.
Public Function RunTestHardShearFold() As String
    HardFoldRequestedTest = True: HardFoldFinishedTest = False
    WriteHardFoldRowTest "HARDSHEAR-FOLD;1"
    RunTestHardShearFold = RunTestCoupledWorkbookTiming("Both", "Excel")
    HardFoldRequestedTest = False
    If HardFoldFinishedTest Then
        RunTestHardShearFold = RunTestHardShearFold & vbCrLf & "TOTAL_HARD_SHEAR_FOLD: passed=1; failed=0"
    Else
        RunTestHardShearFold = RunTestHardShearFold & vbCrLf & "TOTAL_HARD_SHEAR_FOLD: passed=0; failed=1"
    End If
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет данные только рядом с нативной тестовой копией.
Public Sub WriteHardFoldRowTest(ByVal row As String)
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, "WriteHardFoldRowTest", "Запись плеч доступна в изолированной книге."
    Dim channel As Integer: channel = FreeFile
    Open ThisWorkbook.Path & "\HardFold.csv" For Append As #channel
    Print #channel, row
    Close #channel
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сериализует точный Double для сверки исходных полей и направлений.
Public Function HardFoldBitsTest(ByVal value As Double) As String
    Dim number As THardFoldNumberTest, words As THardFoldWordsTest
    number.Value = value: LSet words = number
    HardFoldBitsTest = Right$("00000000" & Hex$(words.High), 8) & Right$("00000000" & Hex$(words.Low), 8)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет одномерный численный массив в порядке индексов.
Public Function HardFoldVectorTest(ByRef values() As Double) As String
    Dim i As Long
    For i = LBound(values) To UBound(values)
        If i > LBound(values) Then HardFoldVectorTest = HardFoldVectorTest & ";"
        HardFoldVectorTest = HardFoldVectorTest & HardFoldBitsTest(values(i))
    Next i
End Function
