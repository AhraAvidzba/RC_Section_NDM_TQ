"""ДЛЯ ТЕСТОВ: проверяет GMRES на штатном HardShear в частной копии книги."""

from argparse import ArgumentParser
import importlib.util
import json
from pathlib import Path


def TestStage(repo, root):
    """Меняет только два численных компонента; листы и исходные материалы сохраняются."""
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location('TestKrylovUnitStage', here/'Stage-TestKrylovUnit.py')
    unit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(unit)
    unit.TestStage(repo, root)
    relative = 'src/Solver/CCoupledNewtonSolver.cls'
    (root/relative).write_bytes((here/relative).read_bytes())
    driver = (here/'Run-TestKrylovUnit.ps1').read_text('utf-8-sig')
    driver = driver.replace("@('CCoupledKrylovSpace','modTestCoupledKrylov')", "@('CCoupledKrylovSpace','CCoupledNewtonSolver')")
    driver = driver.replace('Native/Krylov.txt', 'Native/KrylovStock.txt')
    driver = driver.replace("-Macro 'modTestCoupledKrylov.RunTestCoupledKrylov' -Mode No -TimeoutSeconds 165 -FailFast",
                            "-Macro 'modTestCoupledElasticState.RunTestCoupledWorkbookTiming' -MacroArgument1 Both -MacroArgument2 Excel -Mode No -TimeoutSeconds 170 -FailFast -VerifyResultsReopen")
    (root/'Run-TestKrylovStock.ps1').write_bytes(driver.encode('utf-8-sig'))
    (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    inputs = json.loads((root/'Preparation.json').read_bytes())
    for name in (relative, 'Run-TestKrylovStock.ps1', Path(__file__).name):
        inputs[name] = unit.TestDigest((root/name).read_bytes())
    (root/'Preparation.json').write_text(json.dumps(inputs, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('KRYLOV STOCK INPUTS READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
