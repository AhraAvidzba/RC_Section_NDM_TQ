"""ДЛЯ ТЕСТОВ: собирает протоколы GMRES без подмены установленной книги."""

from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile


def TestCollect():
    """Копирует исходные квитанции и привязки к фактическим закрытым книгам."""
    repo = Path.cwd()
    here = Path(__file__).resolve().parent
    root = here/'KrylovFallbackBundle'
    root.mkdir()
    for path in here.glob('*'):
        if path.suffix in ('.py', '.txt', '.ps1'):
            (root/path.name).write_bytes(path.read_bytes())
    locations = {'Unit': 'KrylovUnit20261117Ready', 'Stock': 'KrylovStock20261117', 'MVT': 'KrylovMVTNdm20261117'}
    for name, folder in locations.items():
        source = Path('D:/CodexScratch/RC_Section_NDM_TQ')/folder
        target = root/name
        target.mkdir()
        for path in source.rglob('*'):
            relative = path.relative_to(source)
            if not path.is_file() or relative.parts[0] in ('Temp', 'workbook', 'docs', 'tools'):
                continue
            if path.suffix.lower() in ('.bin', '.xlsm'):
                continue
            output = target/relative
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(path.read_bytes())
        compiler = source/'docs/regression/CodeUpdate.json'
        if not compiler.exists():
            compiler = source/'CodeUpdate.json'
        (target/'CodeUpdate.json').write_bytes(compiler.read_bytes())
        if name == 'Unit':
            destination = target/'docs/regression/CodeUpdate.json'
            destination.parent.mkdir(parents=True)
            destination.write_bytes(compiler.read_bytes())
        (target/'CaptureSource.json').write_text(json.dumps({'compiled': str(source/'docs/regression/Diagnostic.xlsm')}, indent=2)+'\n', encoding='utf-8')
        if name == 'Stock':
            for path in (target/'Native').glob('KrylovStock.txt*'):
                path.rename(path.with_name(path.name.replace('KrylovStock.txt', 'Both.txt', 1)))
            (target/'KrylovEquilibrium.bas.txt').write_bytes((here/'KrylovEquilibrium.bas.txt').read_bytes())
            fixture, = re.findall(r'^FIXTURE: (.+)$', (target/'Native/Both.txt').read_text('utf-8-sig'), re.M)
            (target/'Native/Both.Execution.txt').write_bytes((Path(fixture).parent/'RC_Section_NDM_execution_report.txt').read_bytes())
    reference = repo/'docs/regression/Coupled6D/HardShearCoarseGrowthWorkbookRelease20261117.zip'
    assert sha256(reference.read_bytes()).hexdigest().upper() == '6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63'
    with ZipFile(reference) as archive:
        for name in ('ReadWorkbookCurve.py', 'Verify-FullAB.py'):
            (root/name).write_bytes(archive.read(name))
    for name, folder in (('CompileAttempt1', 'KrylovUnit20261117'), ('CompileAttempt2', 'KrylovUnit20261117Retry')):
        target = root/name
        target.mkdir()
        source = Path('D:/CodexScratch/RC_Section_NDM_TQ')/folder
        for filename in ('Compile.log', 'CompileClosure.json', 'Run.ndjson', 'tests/modTestCoupledKrylov.bas'):
            path = target/filename
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes((source/filename).read_bytes())
    print(root)


if __name__ == '__main__':
    TestCollect()
