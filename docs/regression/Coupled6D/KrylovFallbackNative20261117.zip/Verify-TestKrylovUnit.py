"""ДЛЯ ТЕСТОВ: сверяет нативные поправки GMRES с независимым least-squares NumPy."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
import numpy as np


def TestClose(actual, expected, scale, message):
    """Сравнивает массивы в общей шкале задачи, не меняя сохранённые исходные числа."""
    error = float(np.max(np.abs(np.asarray(actual)-np.asarray(expected))))
    assert error <= 2e-10 * scale, (message, error, scale)
    return error / scale


def TestVerify(root):
    """Повторяет операторы, все промежуточные проекции и нативный итог."""
    report = (root/'Native/Krylov.txt').read_text('utf-8-sig')
    assert not re.search(r'(^|\n)(FAIL:|RUNTIME ERROR:|TIMEOUT)', report)
    totals = re.findall(r'TOTAL_COUPLED_KRYLOV: passed=(\d+); failed=(\d+)', report)
    assert len(totals) == 1 and int(totals[0][0]) > 100 and totals[0][1] == '0', totals
    cases = {}
    for line in report.splitlines():
        if not line.startswith('GMRES_'):
            continue
        row = line.split(';')
        if row[0] == 'GMRES_CASE':
            cases[row[1]] = {'n': int(row[2]), 'limit': int(row[3]), 'columns': {}, 'vectors': {}, 'residuals': {}}
        elif row[0] == 'GMRES_COLUMN':
            cases[row[1]]['columns'][row[2], int(row[3])] = np.array(row[4:], dtype=float)
        elif row[0] == 'GMRES_VECTOR':
            cases[row[1]]['vectors'][row[2], int(row[3])] = np.array(row[4:], dtype=float)
        elif row[0] == 'GMRES_RESIDUAL':
            cases[row[1]]['residuals'][int(row[2])] = np.array(row[3:], dtype=float)
        else:
            raise AssertionError(line)
    assert set(cases) == {'N1', 'N2', 'N3', 'N6', 'N12', 'N61', 'Partial12'}
    proofs = {}
    for name, case in cases.items():
        n = case['n']
        columns, vectors = case['columns'], case['vectors']
        actual_a = np.column_stack([columns['A', j] for j in range(1, n+1)])
        actual_k = np.column_stack([columns['K', j] for j in range(1, n+1)])
        indices = np.arange(1, n+1, dtype=float)
        u, a, b = np.sin(.37*indices), np.sin(.83*indices), np.cos(.71*indices)
        diagonal = 10**(4*indices/n-2)
        expected_k = np.diag(diagonal) + np.diag(.03*diagonal[:-1], 1)
        expected_p = np.eye(n) - 2*np.outer(u, u)/(u@u) + .2/n*(np.outer(a, b)-np.outer(b, a))
        expected_a = expected_p@expected_k
        right = np.sin(.7*indices)+.4*np.cos(1.1*indices)+.2*indices/n
        matrix_scale = max(float(np.max(np.abs(expected_a))), 1.)
        errors = [TestClose(actual_k, expected_k, matrix_scale, name+' K'),
                  TestClose(actual_a, expected_a, matrix_scale, name+' A'),
                  TestClose(vectors['B', 0], right, max(float(np.linalg.norm(right)), 1.), name+' B')]
        steps = sorted(case['residuals'])
        assert steps == list(range(1, len(steps)+1)) and len(steps) <= case['limit']
        for step in steps:
            z = np.column_stack([vectors['Z', j] for j in range(1, step+1)])
            az = np.column_stack([vectors['AZ', j] for j in range(1, step+1)])
            x = vectors['X', step]
            errors.append(TestClose(actual_a@z, az, max(float(np.linalg.norm(az)), 1.), name+' operator'))
            basis = actual_k@z
            errors.append(TestClose(basis.T@basis, np.eye(step), 1., name+' orthonormal basis'))
            weights, _, rank, _ = np.linalg.lstsq(az, right, rcond=None)
            assert rank == step, (name, step, rank)
            independent_x = z@weights
            errors.append(TestClose(x, independent_x, max(float(np.linalg.norm(independent_x)), 1.), name+' least-squares'))
            residual = right-actual_a@x
            actual_norm = float(np.linalg.norm(residual))
            errors.append(TestClose(case['residuals'][step], [actual_norm, actual_norm],
                                    max(float(np.linalg.norm(right)), 1.), name+' residual'))
            errors.append(TestClose(az.T@residual, np.zeros(step), max(float(np.linalg.norm(right)), 1.), name+' orthogonality'))
        relative = float(np.linalg.norm(right-actual_a@vectors['X', steps[-1]])/np.linalg.norm(right))
        if case['limit'] >= 4 or n < 4:
            assert relative < 2e-10, (name, relative)
        else:
            assert 1e-6 < relative < 1., (name, relative)
        proofs[name] = {'steps': len(steps), 'relative_residual': relative, 'maximum_scaled_error': max(errors)}
    compiler = json.loads((root/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
    assert compiler['Compiled'] and not compiler['ProductionChanged']
    assert set(compiler['Modules']) == {'CCoupledKrylovSpace', 'modTestCoupledKrylov'}
    assert json.loads((root/'CompileClosure.json').read_text('utf-8-sig'))['State'] == 'Absent'
    proof = {'native_assertions': int(totals[0][0]), 'cases': proofs,
             'report_sha256': sha256((root/'Native/Krylov.txt').read_bytes()).hexdigest().upper(),
             'compiled_modules': compiler['Modules']}
    (root/'Independent.json').write_text(json.dumps(proof, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print(json.dumps(proof, indent=2))
    return proof


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    TestVerify(parser.parse_args().root.resolve())
