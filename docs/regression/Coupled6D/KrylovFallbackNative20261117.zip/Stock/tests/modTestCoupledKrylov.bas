﻿Attribute VB_Name = "modTestCoupledKrylov"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет GMRES на несимметричных системах с неверным знаком одной моды.
' Полные операторы и промежуточные поправки сохраняются для проверки NumPy.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выполняет независимые по размеру линейные случаи и проверки сброса состояния.
Public Function RunTestCoupledKrylov() As String
    Dim report As String, passed As Long, failed As Long, size As Variant, count As Long
    On Error GoTo Failure
    For Each size In Array(1, 2, 3, 6, 12, 61)
        count = CLng(size)
        TestLinearCase count, GeomMin(6, count), "N" & CStr(count), report, passed, failed
    Next size
    TestLinearCase 12, 2, "Partial12", report, passed, failed
    TestBoundaryCases report, passed, failed
    RunTestCoupledKrylov = report & "TOTAL_COUPLED_KRYLOV: passed=" & CStr(passed) & "; failed=" & CStr(failed)
    Exit Function
Failure:
    RunTestCoupledKrylov = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит A=P*K, где P содержит отражение и кососимметричное возмущение ранга два.
' K имеет разные масштабы столбцов и используется как правый предобусловливатель.
Private Sub TestLinearCase(ByVal size As Long, ByVal limit As Long, ByVal name As String, _
        ByRef report As String, ByRef passed As Long, ByRef failed As Long)
    Dim matrix() As Double, preconditioner() As Double, right() As Double, original() As Double
    Dim u() As Double, a() As Double, b() As Double, product() As Double, z() As Double, v() As Double, x() As Double
    Dim i As Long, j As Long, k As Long, iteration As Long, columnMagnitude As Double, normU As Double
    ReDim matrix(1 To size, 1 To size), preconditioner(1 To size, 1 To size), right(1 To size)
    ReDim u(1 To size), a(1 To size), b(1 To size), product(1 To size)
    For i = 1 To size
        u(i) = Sin(0.37 * i): a(i) = Sin(0.83 * i): b(i) = Cos(0.71 * i)
        normU = normU + u(i) * u(i)
        right(i) = Sin(0.7 * i) + 0.4 * Cos(1.1 * i) + 0.2 * i / size
        columnMagnitude = 10# ^ (4# * i / size - 2#)
        preconditioner(i, i) = columnMagnitude
        If i < size Then preconditioner(i + 1, i) = 0.03 * columnMagnitude
    Next i
    For j = 1 To size
        For i = 1 To size
            matrix(j, i) = preconditioner(j, i)
            For k = 1 To size
                matrix(j, i) = matrix(j, i) + (-2# * u(i) * u(k) / normU + _
                    0.2 * (a(i) * b(k) - b(i) * a(k)) / size) * preconditioner(j, k)
            Next k
        Next i
    Next j
    original = right
    report = report & "GMRES_CASE;" & name & ";" & CStr(size) & ";" & CStr(limit) & vbCrLf
    For j = 1 To size
        report = report & "GMRES_COLUMN;" & name & ";A;" & CStr(j)
        For i = 1 To size: report = report & ";" & TestNumber(matrix(j, i)): Next i
        report = report & vbCrLf & "GMRES_COLUMN;" & name & ";K;" & CStr(j)
        For i = 1 To size: report = report & ";" & TestNumber(preconditioner(j, i)): Next i
        report = report & vbCrLf
    Next j
    TestVector report, name, "B", 0, right
    Dim space As New CCoupledKrylovSpace, system As New CCoupledLinearSystem
    TestRecord space.Start(right, limit), name & " start", report, passed, failed
    TestRecord system.Factor(preconditioner, size), name & " factorization", report, passed, failed
    Dim previous As Double, actual As Double, value As Double, inputError As Double
    previous = TestNorm(right)
    Do While space.CopyNextResidualDirection(v)
        z = v
        TestRecord system.SolveFactored(z), name & " preconditioner", report, passed, failed
        For i = 1 To size
            product(i) = 0#
            For j = 1 To size: product(i) = product(i) + matrix(j, i) * z(j): Next j
        Next i
        iteration = iteration + 1
        TestVector report, name, "Z", iteration, z
        TestVector report, name, "AZ", iteration, product
        TestRecord space.AddOperatorVector(z, product), name & " Arnoldi", report, passed, failed
        TestRecord space.CopyCorrection(x), name & " correction", report, passed, failed
        TestVector report, name, "X", iteration, x
        actual = 0#
        For i = 1 To size
            value = right(i)
            For j = 1 To size: value = value - matrix(j, i) * x(j): Next j
            actual = actual + value * value
            inputError = GeomMax(inputError, Abs(right(i) - original(i)))
        Next i
        actual = Sqr(actual)
        report = report & "GMRES_RESIDUAL;" & name & ";" & CStr(iteration) & ";" & _
            TestNumber(actual) & ";" & TestNumber(space.EstimatedResidualNorm) & vbCrLf
        TestRecord Abs(actual - space.EstimatedResidualNorm) <= 0.00000001 * TestNorm(right), _
            name & " QR residual", report, passed, failed
        TestRecord actual <= previous + 0.00000001 * TestNorm(right), name & " minimal residual", report, passed, failed
        previous = actual
    Loop
    TestRecord inputError = 0#, name & " input unchanged", report, passed, failed
    If limit >= 4 Or size < 4 Then TestRecord actual <= 0.00000001 * TestNorm(right), _
        name & " recovered exact linear solution", report, passed, failed
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет нулевую правую часть, вырожденное действие оператора и повторный Start.
Private Sub TestBoundaryCases(ByRef report As String, ByRef passed As Long, ByRef failed As Long)
    Dim space As New CCoupledKrylovSpace, right(1 To 2) As Double, v() As Double, x() As Double
    TestRecord space.Start(right, 2), "zero start", report, passed, failed
    TestRecord Not space.CopyNextResidualDirection(v), "zero needs no direction", report, passed, failed
    TestRecord space.CopyCorrection(x), "zero correction available", report, passed, failed
    TestRecord x(1) = 0# And x(2) = 0#, "zero correction", report, passed, failed
    right(1) = 3#: right(2) = 4#
    TestRecord space.Start(right, 2), "restart", report, passed, failed
    TestRecord space.CopyNextResidualDirection(v), "restart direction", report, passed, failed
    Dim z(1 To 2) As Double, product(1 To 2) As Double
    z(1) = v(1): z(2) = v(2)
    TestRecord Not space.AddOperatorVector(z, product), "zero operator rejected", report, passed, failed
    TestRecord space.FailureCode = sfcSingularTangent, "zero operator status", report, passed, failed
    TestRecord Not space.CopyCorrection(x), "no invented correction", report, passed, failed
    TestRecord space.Start(right, 2), "reset after breakdown", report, passed, failed
    space.CopyNextResidualDirection v
    product(1) = v(1): product(2) = v(2)
    TestRecord space.AddOperatorVector(v, product), "identity after reset", report, passed, failed
    TestRecord space.CopyCorrection(x), "identity correction", report, passed, failed
    TestRecord Abs(x(1) - 3#) + Abs(x(2) - 4#) < 0.000000000001, "no state leakage", report, passed, failed
    TestRecord Not space.CopyNextResidualDirection(v), "happy breakdown", report, passed, failed
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет вектор для независимого расчёта без зависимости от локали Excel.
Private Sub TestVector(ByRef report As String, ByVal name As String, ByVal kind As String, _
        ByVal step As Long, ByRef vector() As Double)
    Dim i As Long
    report = report & "GMRES_VECTOR;" & name & ";" & kind & ";" & CStr(step)
    For i = LBound(vector) To UBound(vector): report = report & ";" & TestNumber(vector(i)): Next i
    report = report & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает инвариантную десятичную запись числа.
Private Function TestNumber(ByVal value As Double) As String
    TestNumber = Replace$(Trim$(Str$(value)), ",", ".")
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает норму небольших контрольных векторов.
Private Function TestNorm(ByRef value() As Double) As Double
    Dim i As Long, square As Double
    For i = LBound(value) To UBound(value): square = square + value(i) * value(i): Next i
    TestNorm = Sqr(square)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает каждое фактически выполненное утверждение.
Private Sub TestRecord(ByVal condition As Boolean, ByVal message As String, ByRef report As String, _
        ByRef passed As Long, ByRef failed As Long)
    If condition Then
        passed = passed + 1: report = report & "OK: " & message & vbCrLf
    Else
        failed = failed + 1: report = report & "FAIL: " & message & vbCrLf
    End If
End Sub
