"""Extract one accepted HardShear capacity curve from the saved Results worksheet."""
from hashlib import sha256
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile

CURVE_KEY = re.compile(r"^Coupled\.Trace\.Capacity\.(\d+)\.(Lambda|Offset)$")


def sha(raw):
    return sha256(raw).hexdigest().upper()


def column_number(name):
    number = 0
    for character in name:
        number = 26 * number + ord(character) - ord("A") + 1
    return number


def read_curve(path):
    with ZipFile(path) as book:
        workbook = ET.fromstring(book.read("xl/workbook.xml"))
        refs = [item.text for item in workbook.findall(".//{*}definedName")
                if item.get("name") == "rngNDMSectionProperties"]
        address, row_start = re.fullmatch(r"'?Results'?\!\$([A-Z]+)\$(\d+)", refs[0]).groups()
        assert len(refs) == 1
        result, = (item for item in workbook.findall(".//{*}sheet") if item.get("name") == "Results")
        relationship, = (value for key, value in result.attrib.items() if key.endswith("}id"))
        relations = ET.fromstring(book.read("xl/_rels/workbook.xml.rels"))
        target, = (item.get("Target") for item in relations if item.get("Id") == relationship)
        worksheet = "xl/" + target
        raw = book.read(worksheet)
        data = ET.fromstring(raw)
        strings = ["".join(t.text or "" for t in item.findall(".//{*}t"))
                   for item in ET.fromstring(book.read("xl/sharedStrings.xml"))]
        base = column_number(address)
        entries = []
        for row in data.findall(".//{*}row"):
            if int(row.get("r")) < int(row_start):
                continue
            cells = {}
            for cell in row:
                pos = cell.get("r", "")
                match = re.match(r"[A-Z]+", pos)
                if not match:
                    continue
                col = column_number(match.group()) - base
                value = cell.find("{*}v")
                if col in (1, 2, 3) and value is not None and value.text is not None:
                    text = strings[int(value.text)] if cell.get("t") == "s" else value.text
                    cells[col] = (pos, text)
            if 1 not in cells or 2 not in cells or cells[1][1] != "HardShear":
                continue
            key = CURVE_KEY.fullmatch(cells[2][1])
            if key:
                entries.append([int(key[1]), key[2], *cells[2], *cells[3]])
    return {"worksheet": worksheet, "worksheet_sha256": sha(raw), "saved_workbook_sha256": sha(path.read_bytes()),
            "named_anchor": refs[0], "entries": entries}
