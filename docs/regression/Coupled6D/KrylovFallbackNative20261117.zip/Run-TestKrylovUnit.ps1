# ДЛЯ ТЕСТОВ: компилирует и проверяет два компонента в отдельном экземпляре Excel.
param([ValidateSet('Compile','Native')][string]$Phase='Compile')
$ErrorActionPreference='Stop'
$oldTemp=$env:TEMP;$oldTmp=$env:TMP
Push-Location -LiteralPath $PSScriptRoot
try {
    . './Guard-IsolatedOffice.ps1'
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path;$env:TMP=$env:TEMP
    $inputs=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    foreach ($item in $inputs.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $item.Name).Hash -cne $item.Value) {throw "Изменён вход $($item.Name)."}
    }
    if ($Phase -eq 'Compile') {
        if (Test-Path -LiteralPath 'Compile.log') {throw 'Компиляция уже запускалась.'}
        Assert-IsolatedOfficeReady 'CompileKrylovUnit'
        & './tools/build_workbook/Update-IsolatedOptimizerCode.ps1' -WorkbookPath 'docs/regression/Diagnostic.xlsm' `
            -ModuleNames @('CCoupledKrylovSpace','modTestCoupledKrylov') | Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    } else {
        if (Test-Path -LiteralPath 'Native/Krylov.txt') {throw 'Нативный протокол уже существует.'}
        Assert-IsolatedOfficeReady 'RunKrylovUnit'
        $legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
        & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-FocusedKaniWatchdog.ps1' `
            -SourceWorkbook 'docs/regression/Diagnostic.xlsm' -ReportPath 'Native/Krylov.txt' `
            -Macro 'modTestCoupledKrylov.RunTestCoupledKrylov' -Mode No -TimeoutSeconds 165 -FailFast
        if ($LASTEXITCODE -ne 0) {throw "Ошибка нативной проверки: $LASTEXITCODE."}
    }
} finally {
    $env:TEMP=$oldTemp;$env:TMP=$oldTmp
    Pop-Location
}
