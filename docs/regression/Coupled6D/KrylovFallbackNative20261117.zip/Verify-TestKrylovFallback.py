"""ДЛЯ ТЕСТОВ: проверяет линейный GMRES, фактический VBA и два нелинейных случая."""

from argparse import ArgumentParser
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from subprocess import check_output
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZIP_DEFLATED


BASE = ('HardShearCoarseGrowthWorkbookRelease20261117.zip', '6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63')
STOCK = ('HardShearIntegratedSteelWorkbook20261117.zip', '5E28B5A6CB9F49855708E91249A3370403A93461E325CDAEE41BB0520A63F9E1')
NDM = ('MVT2NdmCurveConsistency20261117.zip', 'CE2DD6CE11F0C30BCAF46F3F14ABF35E25295B38762A4DBEDD90B0075DF85034')
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA = 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
REV = '826221bfde2fef1e690c65745c0169ef4a342161'


def TestDigest(raw):
    """Возвращает хеш исходных байтов."""
    return sha256(raw).hexdigest().upper()


def TestRead(file):
    """Читает нативный JSON с возможным BOM."""
    return json.loads(file.read_text('utf-8-sig'))


def TestArchive(repo, entry):
    """Открывает ровно зафиксированную прежнюю проверку."""
    raw = (repo/'docs/regression/Coupled6D'/entry[0]).read_bytes()
    assert TestDigest(raw) == entry[1]
    return ZipFile(BytesIO(raw))


def TestScript(archive, name):
    """Подключает сохранённый наблюдатель без изменения его текста."""
    scope = {'__name__': '__pinned__', '__file__': name}
    exec(compile(archive.read(name), name, 'exec'), scope)
    return scope


def TestContainer(raw):
    """Оборачивает сохранённый фактический VBA в минимальный носитель декодера."""
    stream = BytesIO()
    with ZipFile(stream, 'w') as archive:
        archive.writestr('xl/vbaProject.bin', raw)
    stream.seek(0)
    return stream


def TestMVTCompilerBody(body, source, module):
    """Учитывает только перечисленные равнозначные литералы и потери старых комментариев VBA."""
    value = body(source, module)[0]
    edits = []
    literals = {
        'CCoupledConcreteResponse': [('1e-12', '0.000000000001')],
        'CCoupledElasticState': [('1e-10', '0.0000000001'), ('1e-13', '0.0000000000001'),
                                ('1e-8', '0.00000001'), ('1e-7', '0.0000001')],
        'CCoupledSectionQuadrature': [('1e-7', '0.0000001'), ('1e-8', '0.00000001')],
        'modTestMVT2GaussSpan': [('72812.5#', '72812.5'), ('75312.5#', '75312.5')],
    }
    for old, new in literals.get(module, []):
        assert Decimal(old.rstrip('#')) == Decimal(new)
        count = value.count(old)
        assert count > 0
        value = value.replace(old, new)
        edits.append({'kind': 'equivalent_literal', 'from': old, 'to': new, 'count': count})
    if module in ('CCoupledConcreteResponse', 'CCoupledElasticState'):
        rows = value.splitlines()
        for index, row in enumerate(rows):
            if not row.lstrip().startswith("'"):
                continue
            converted = row
            for old, new in [('bairán', 'bairan'), ('²', '?'), ('σ', '?'), ('ε', '?'), ('γ', '?'), ('−', '?'), ('ᵀ', '?')]:
                converted = converted.replace(old, new)
            if converted != row:
                edits.append({'kind': 'legacy_comment_encoding_loss', 'from': row, 'to': converted})
                rows[index] = converted
        value = '\n'.join(rows)
    if module == 'CCoupledElasticState':
        old = "' градиент my добавляет заданное qx и компенсирует производную σzz."
        new = old.replace('σ', '?')
        assert value.count(old) == 1
        value = value.replace(old, new)
        edits.append({'kind': 'legacy_comment_encoding_loss', 'from': old, 'to': new})
    return value, edits


def TestProcess(root, stem):
    """Подтверждает собственный процесс, неизменность источника, ресурсы и выход Excel."""
    compiler = TestRead(root/'CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged']
    assert TestRead(root/'CompileClosure.json')['State'] == 'Absent'
    for row in (root/'Run.ndjson').read_text('utf-8-sig').splitlines():
        memory = json.loads(row)
        if memory.get('phase') == 'CompileKrylovUnit' and root.name == 'Unit' and not all(p['ProtectedUser'] for p in memory['excel']):
            continue  # Отклонённая до создания процесса попытка; успешная компиляция проверена отдельной квитанцией.
        assert memory['ramMiB'] >= 6500 and memory['freeCommitGiB'] >= 6
        assert memory['freeC_MiB'] >= 80 and memory['freeD_GiB'] >= 4
        assert all(p['ProtectedUser'] for p in memory['excel'])
    close = TestRead(root/'Native'/(stem+'.ProcessClosure.json'))
    owner = TestRead(root/'Native'/(stem+'.Ownership.json'))
    assert close['Passed'] and close['ChildExitCode'] == 0 and close['RunnerCleanupValid']
    assert close['Closure']['FinalState']['State'] == 'Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == compiler['WorkbookSHA256']
    assert close['Closure']['Identity']['PID'] == owner['PID']
    assert close['Closure']['Identity']['Ticks'] == int(owner['StartTicksUTC'])
    return compiler


def TestCapture(root):
    """Сохраняет только недостающие байтовые свидетельства закрытых частных книг."""
    for name in ('Unit', 'Stock', 'MVT'):
        folder = root/name
        candidate = TestRead(folder/'CaptureSource.json')
        file = Path(candidate['compiled'])
        assert TestDigest(file.read_bytes()) == TestRead(folder/'CodeUpdate.json')['WorkbookSHA256']
        with ZipFile(file) as archive:
            (folder/'CompiledVBA.bin').write_bytes(archive.read('xl/vbaProject.bin'))
    stock = root/'Stock'
    report = (stock/'Native/Both.txt').read_text('utf-8-sig')
    saved, = re.findall(r'^RESULTS_SAVE_REOPEN:[^\n]*; file=(.+)$', report, re.M)
    fixture, = re.findall(r'^FIXTURE: (.+)$', report, re.M)
    assert Path(saved).parent == Path(fixture).parent and Path(saved).name == 'RC_Section_NDM_saved.xlsm'
    read_curve = run_path(str(root/'ReadWorkbookCurve.py'))['read_curve']
    values = read_curve(Path(saved))
    with ZipFile(saved) as source, ZipFile(stock/'Native/SavedResultsParts.zip', 'x', ZIP_DEFLATED, compresslevel=9) as out:
        for name in ('xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/sharedStrings.xml', values['worksheet']):
            out.writestr(name, source.read(name))


def TestVerify(repo, root):
    """Не выдаёт отсутствие улучшения за готовую численную или физическую приёмку."""
    with TestArchive(repo, BASE) as archive:
        stage = TestScript(archive, 'Stage-Release.py')
    observer, sources = stage['parse_vba'](repo)
    for name in ('CompileAttempt1', 'CompileAttempt2'):
        failed = root/name
        close = TestRead(failed/'CompileClosure.json')
        assert close['State'] == 'Absent'
        identity, = re.findall(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',
                               (failed/'Compile.log').read_text('utf-8-sig'), re.M)
        assert int(identity[0]) == close['PID'] and identity[1] == close['StartTicksUTC']
    stock_book = (repo/BOOK).read_bytes()
    if TestDigest(stock_book) != BOOK_SHA:
        stock_book = check_output(['git', 'cat-file', 'blob', f'{REV}:{BOOK}'], cwd=repo)
    assert TestDigest(stock_book) == BOOK_SHA
    _, baseline = sources(BytesIO(stock_book))
    fold, body = observer['literal_safe_fold'], observer['compiler_body']
    unit = root/'Unit'
    unit_compiler = TestProcess(unit, 'Krylov.txt')
    assert set(unit_compiler['Modules']) == {'CCoupledKrylovSpace', 'modTestCoupledKrylov'}
    _, unit_sources = sources(TestContainer((unit/'CompiledVBA.bin').read_bytes()))
    assert set(unit_sources)-set(baseline) == {'CCoupledKrylovSpace', 'modTestCoupledKrylov'}
    assert all(fold(unit_sources[name]) == fold(code) for name, code in baseline.items())
    for name, relative in (('CCoupledKrylovSpace', 'src/Solver/CCoupledKrylovSpace.cls'), ('modTestCoupledKrylov', 'tests/modTestCoupledKrylov.bas')):
        assert body(unit_sources[name], name)[0] == body((unit/relative).read_text('utf-8-sig'), name)[0]
    linear = run_path(str(root/'Verify-TestKrylovUnit.py'))['TestVerify'](unit)
    stock = root/'Stock'
    compiler = TestProcess(stock, 'Both.txt')
    assert compiler['ProductionSHA256'] == BOOK_SHA
    assert set(compiler['Modules']) == {'CCoupledKrylovSpace', 'CCoupledNewtonSolver'}
    _, embedded = sources(TestContainer((stock/'CompiledVBA.bin').read_bytes()))
    assert len(embedded) == 227 and set(embedded)-set(baseline) == {'CCoupledKrylovSpace'}
    assert [name for name in baseline if fold(embedded[name]) != fold(baseline[name])] == ['CCoupledNewtonSolver']
    for name in compiler['Modules']:
        relative = 'src/Solver/'+name+'.cls'
        assert body(embedded[name], name)[0] == body((stock/relative).read_text('utf-8-sig'), name)[0]
    assert fold(embedded['CCoupledKrylovSpace']) == fold(unit_sources['CCoupledKrylovSpace'])
    with TemporaryDirectory(dir=root) as directory:
        temporary = Path(directory)
        baseline_file = temporary/'src/Solver/CCoupledNewtonSolver.cls'
        baseline_file.parent.mkdir(parents=True)
        baseline_file.write_bytes(baseline['CCoupledNewtonSolver'].encode('utf-8'))
        output = temporary/'Expected.cls'
        run_path(str(root/'Build-TestKrylovSolver.py'))['TestBuild'](temporary, output)
        assert body(output.read_text('utf-8-sig'), 'CCoupledNewtonSolver')[0] == body(embedded['CCoupledNewtonSolver'], 'CCoupledNewtonSolver')[0]
    native = run_path(str(root/'Verify-FullAB.py'))['native'](stock/'Native', compiler['WorkbookSHA256'])
    with TestArchive(repo, STOCK) as archive:
        prior = json.loads(archive.read('CleanSteelHardShearProof.json'))
        old_raw = archive.read('Native/SavedResultsParts.zip')
    for key in ('capacity_status', 'result_code', 'limit_lambda', 'ultimate_N_Nmm', 'assertions', 'probes'):
        assert native[key] == prior['native'][key]
    assert abs(native['lower_lambda']-prior['native']['lower_lambda']) < 1e-10
    read_curve = run_path(str(root/'ReadWorkbookCurve.py'))['read_curve']
    curve = read_curve(stock/'Native/SavedResultsParts.zip')
    with TemporaryDirectory(dir=root) as directory:
        old_file = Path(directory)/'Previous.zip'
        old_file.write_bytes(old_raw)
        old = read_curve(old_file)
    assert len(curve['entries']) == len(old['entries']) == 136
    assert all(a[:-1] == b[:-1] for a, b in zip(curve['entries'], old['entries'], strict=True))
    curve_error = max(abs(float(a[-1])-float(b[-1])) for a, b in zip(curve['entries'], old['entries'], strict=True))
    assert curve_error == 0.
    mvt = root/'MVT'
    mvt_compiler = TestProcess(mvt, 'MVTGaussMixed.txt')
    assert len(mvt_compiler['Modules']) == 10 and 'CCoupledKrylovSpace' in mvt_compiler['Modules']
    _, mvt_sources = sources(TestContainer((mvt/'CompiledVBA.bin').read_bytes()))
    mvt_conversions = {}
    for name in mvt_compiler['Modules']:
        matches = [p for folder in ('src', 'tests') for p in (mvt/folder).rglob(name+'.*') if p.suffix in ('.bas', '.cls')]
        assert len(matches) == 1, name
        expected_body, conversions = TestMVTCompilerBody(body, matches[0].read_text('utf-8-sig'), name)
        assert body(mvt_sources[name], name)[0] == expected_body, name
        if conversions:
            mvt_conversions[name] = conversions
    assert fold(mvt_sources['CCoupledNewtonSolver']) == fold(embedded['CCoupledNewtonSolver'])
    log = (mvt/'Native/MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'target_reached=False' in log and '; резервных пространств Крылова: 1; направлений: 6;' in log
    assert 'MVT2_CUT_DIRECT_STOP;S2;' in log
    with TestArchive(repo, NDM) as archive:
        for name in ('Native/MVTGaussMixed.Tensor.csv', 'Native/Operators.csv'):
            assert (mvt/name).read_bytes() == archive.read(name)
    elapsed, = re.findall(r'^CASE_FINISHED;MVTGaussMixed;False;(.+)$', log, re.M)
    assert TestDigest((root/'KrylovEquilibrium.bas.txt').read_bytes()) == TestDigest((stock/'KrylovEquilibrium.bas.txt').read_bytes())
    return {'linear': linear, 'stock': native, 'stock_curve_maximum_difference': curve_error,
            'stock_accepted_states': 68, 'stock_unchanged_modules': 225,
            'mvt_accepted_torque_fields': 8, 'mvt_mixed_target_reached': False, 'mvt_macro_time_s': float(elapsed),
            'stock_previous_results_time_s': prior['native']['timing_s']['results'], 'mvt_compiler_conversions': mvt_conversions,
            'paired_performance_comparison': False, 'candidate_installed': False, 'physical_capacity_certified': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--capture', action='store_true')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.capture:
        TestCapture(args.root.resolve())
    proof = TestVerify(args.repo.resolve(), args.root.resolve())
    args.out.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode('utf-8'))
    print('KRYLOV FALLBACK VERIFIED 141 28 68; TARGET NOT REACHED; NOT INSTALLED')
