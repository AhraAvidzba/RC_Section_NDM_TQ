"""ДЛЯ ТЕСТОВ: закрепляет завершённые доказательства GMRES и новый случай воспроизведения."""

from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED


def TestSeal():
    """Добавляет один проверяемый случай, сохраняя все предыдущие записи манифеста."""
    repo = Path.cwd()
    source = Path(__file__).resolve().parent/'KrylovFallbackBundle'
    proof = source/'KrylovFallbackChecks.json'
    result = json.loads(proof.read_bytes())
    assert result['linear']['native_assertions'] == 141 and result['stock']['assertions'] == 28
    assert not result['candidate_installed'] and not result['physical_capacity_certified']
    name = 'KrylovFallbackNative20261117'
    destination = repo/'docs/regression/Coupled6D'/(name+'.zip')
    with destination.open('xb') as stream, ZipFile(stream, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for file in sorted(source.rglob('*')):
            if not file.is_file():
                continue
            assert '__pycache__' not in file.parts and file.suffix not in ('.pyc', '.xlsm')
            item = ZipInfo(file.relative_to(source).as_posix(), date_time=(2026, 11, 17, 0, 0, 0))
            item.compress_type = ZIP_DEFLATED
            archive.writestr(item, file.read_bytes(), compresslevel=9)
    stamp = sha256(destination.read_bytes()).hexdigest().upper()
    manifest_file = repo/'docs/reports/Coupled6DEvidence.json'
    original = manifest_file.read_text('utf-8')
    manifest = json.loads(original)
    assert name not in manifest['archives']
    last_archive, last_hash = list(manifest['archives'].items())[-1]
    manifest['archives'][name] = stamp
    case = {
        'id': 'bounded-gmres-native-linear-witness-and-two-nonlinear-cases',
        'journal_section': 590, 'archive': name, 'script': 'Verify-TestKrylovFallback.py',
        'arguments': ['--repo', '{repo}', '--root', '.', '--out', 'KrylovFallbackChecks.json'],
        'stdout_contains': 'KRYLOV FALLBACK VERIFIED 141 28 68; TARGET NOT REACHED; NOT INSTALLED',
        'outputs': {'KrylovFallbackChecks.json': sha256(proof.read_bytes()).hexdigest().upper()},
    }
    manifest['cases'].append(case)
    archive_line = '    '+json.dumps(last_archive)+': '+json.dumps(last_hash)
    assert original.count(archive_line) == 1
    updated = original.replace(archive_line, archive_line+',\n    '+json.dumps(name)+': '+json.dumps(stamp))
    marker = '\n  ],\n  "frozen_repositories": {'
    assert updated.count(marker) == 1
    block = '\n'.join('    '+line for line in json.dumps(case, ensure_ascii=False, indent=2).splitlines())
    updated = updated.replace(marker, ',\n'+block+marker)
    assert json.loads(updated) == manifest
    manifest_file.write_bytes(updated.replace('\n', '\r\n').encode('utf-8'))
    print('KRYLOV EVIDENCE SEALED', destination.stat().st_size, stamp)


if __name__ == '__main__':
    TestSeal()
