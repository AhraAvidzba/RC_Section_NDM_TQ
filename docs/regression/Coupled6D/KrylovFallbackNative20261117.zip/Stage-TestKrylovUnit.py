"""ДЛЯ ТЕСТОВ: готовит отдельную книгу для нативной проверки малого GMRES."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestDigest(data):
    """Возвращает отпечаток точных байтов входа."""
    return sha256(data).hexdigest().upper()


def TestStage(repo, root):
    """Копирует согласованную книгу и два новых компонента без изменения рабочих файлов."""
    here = Path(__file__).resolve().parent
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/VBAFlowIntegratedCore')
    book = 'workbook/output/RC_Section_NDM.xlsm'
    installed = (repo/book).read_bytes()
    assert TestDigest(installed) == 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450'
    files = {book: installed, 'docs/regression/Diagnostic.xlsm': installed}
    for name in ('src/Solver/CCoupledKrylovSpace.cls', 'tests/modTestCoupledKrylov.bas'):
        code = (here/name).read_text('utf-8-sig').replace('\r\n', '\n')
        files[name] = code.replace('\n', '\r\n').encode('utf-8-sig')
    for path in (template/'tools/build_workbook').glob('*'):
        if path.is_file():
            files[path.relative_to(template).as_posix()] = path.read_bytes()
    files['Guard-IsolatedOffice.ps1'] = (template/'Guard-IsolatedOffice.ps1').read_bytes()
    files['Run-TestKrylovUnit.ps1'] = (here/'Run-TestKrylovUnit.ps1').read_bytes()
    files[Path(__file__).name] = Path(__file__).read_bytes()
    prep = {name: TestDigest(raw) for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    root.mkdir()
    for name in ('Native', 'Temp'):
        (root/name).mkdir()
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('KRYLOV UNIT INPUTS READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
