"""ДЛЯ ТЕСТОВ: добавляет ограниченный GMRES в частный исходник Ньютона."""

from argparse import ArgumentParser
from pathlib import Path


def TestOnce(code, old, new):
    """Заменяет единственное проверенное место без неявной адаптации к другой версии."""
    assert code.count(old) == 1, old
    return code.replace(old, new)


def TestBuild(repo, output):
    """Расширяет только численный резерв; законы материалов и приёмка прежние."""
    here = Path(__file__).resolve().parent
    code = (repo/'src/Solver/CCoupledNewtonSolver.cls').read_text('utf-8-sig')
    code = TestOnce(code, 'Private mSteelBranchBuilds As Long, mSteelFieldTangents As Long',
                    'Private mSteelBranchBuilds As Long, mSteelFieldTangents As Long\nPrivate mKrylovBuilds As Long, mKrylovDirections As Long')
    code = TestOnce(code, '    mSteelBranchBuilds = 0: mSteelFieldTangents = 0',
                    '    mSteelBranchBuilds = 0: mSteelFieldTangents = 0\n    mKrylovBuilds = 0: mKrylovDirections = 0')
    target = '        If Not accepted Then\n            If useSteelCorrection And mSteelBranchBuilds > 0'
    addition = '''        If Not accepted And mUseSpatialHistory And mKrylovBuilds < 1 Then
            mKrylovBuilds = mKrylovBuilds + 1 ' Один ограниченный резерв на вызов силового или деформационного шага.
            accepted = TryKrylovEquilibrium(current, currentLambda, load, norm, absoluteTolerance, relativeTolerance, _
                candidateLambda, candidateNorm, candidateTolerance)
        End If
'''
    code = TestOnce(code, target, addition+target)
    marker = "' Пересматривает ветви стали без изменения принятой истории и базовой матрицы."
    code = TestOnce(code, marker, (here/'KrylovEquilibrium.bas.txt').read_text('utf-8')+'\n\n'+marker)
    target = '    If mSteelFieldTangents > 0 Then DiagnosticSummary = DiagnosticSummary & _'
    code = TestOnce(code, target, '''    If mKrylovBuilds > 0 Then DiagnosticSummary = DiagnosticSummary & _
        "; резервных пространств Крылова: " & CStr(mKrylovBuilds) & "; направлений: " & CStr(mKrylovDirections)
'''+target)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as stream:
        stream.write(code.replace('\n', '\r\n').encode('utf-8-sig'))
    print('KRYLOV SOLVER PROTOTYPE READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    TestBuild(args.repo.resolve(), args.output.resolve())
