"""ДЛЯ ТЕСТОВ: добавляет малый GMRES к неизменной силовой истории MVT2."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestDigest(data):
    """Возвращает хеш точных входных байтов."""
    return sha256(data).hexdigest().upper()


def TestStage(repo, root, mode):
    """Копирует фиксированный опыт без разгрузки кручения или внешнего прогноза."""
    here = Path(__file__).resolve().parent
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/VBAFlowIntegratedCore')
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, stamp in prep['inputs'].items():
        raw = (template/name).read_bytes()
        assert TestDigest(raw) == stamp, name
        files[name] = raw
    source = 'src/Solver/CCoupledNewtonSolver.cls'
    assert TestDigest((repo/source).read_bytes()) == prep['source_core'][source]
    files[source] = (here/'src/Solver/CCoupledNewtonSolver.cls').read_bytes()
    new = 'src/Solver/CCoupledKrylovSpace.cls'
    files[new] = (here/new).read_text('utf-8-sig').replace('\r\n', '\n').replace('\n', '\r\n').encode('utf-8-sig')
    driver = files['Run-Native.ps1'].decode('utf-8-sig')
    needle = "'CCoupledSteelCorrection','CCoupledReinforcedResponse')"
    assert driver.count(needle) == 1
    driver = driver.replace(needle, "'CCoupledSteelCorrection','CCoupledReinforcedResponse','CCoupledKrylovSpace')")
    assert driver.count("$env:NDM_MVT_FLOW_MODE='default'") == 1
    driver = driver.replace("$env:NDM_MVT_FLOW_MODE='default'", f"$env:NDM_MVT_FLOW_MODE='{mode}'")
    files['Run-Native.ps1'] = driver.encode('utf-8-sig')
    files[Path(__file__).name] = Path(__file__).read_bytes()
    files['Build-TestKrylovSolver.py'] = (here/'Build-TestKrylovSolver.py').read_bytes()
    files['KrylovEquilibrium.bas.txt'] = (here/'KrylovEquilibrium.bas.txt').read_bytes()
    files['docs/regression/Diagnostic.xlsm'] = files['workbook/output/RC_Section_NDM.xlsm']
    prep['inputs'] = {name: TestDigest(raw) for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    prep['krylov_mode'] = mode
    prep['modified_core'] = [source, new]
    root.mkdir()
    for name in ('Native', 'Temp', 'tests', 'src'):
        (root/name).mkdir(exist_ok=True)
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('KRYLOV MVT INPUTS READY', mode)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--mode', choices=('default', 'ndm_uniaxial'), default='ndm_uniaxial')
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.mode)
