"""Independently integrate native stresses and attest input/Office identities."""
from argparse import ArgumentParser
from hashlib import sha256
from math import fsum, isfinite, isclose, pi, sqrt, tanh
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
BOOK = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
MODULES = {"CCoupledSectionQuadrature", "CCoupledElasticState", "modTestMVT2GaussSpan"}
TARGETS = (.26275, .5255, 1.051, 2.102, 4.204, 6.8315, 10.51)
LOADS = ((0.0, 0.0, 0.0, 262750.0, 0.0, 0.0),
         (-3600.0, -95000.0, 73500.0, 262750.0, 830.0, -1020.0))


def digest(data):
    return sha256(data).hexdigest().upper()


def read(name):
    return json.loads((HERE / name).read_bytes())


def ownership(case):
    prep = read("Preparation.json")
    assert prep["source_book_sha256"] == BOOK
    for name, expected in prep["inputs"].items():
        assert digest((HERE / name).read_bytes()) == expected
    compiled = read("docs/regression/CodeUpdate.json")
    compiler = read("CompileClosure.json")
    assert compiled["Compiled"] and not compiled["ProductionChanged"]
    assert set(compiled["Modules"]) == MODULES and compiled["ProductionSHA256"] == BOOK
    assert compiler["State"] == "Absent"
    compile_text = (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    assert f"OWNED_EXCEL: id={compiler['PID']}; utcStartTicks={compiler['StartTicksUTC']}" in compile_text
    name = f"Native/{case}.txt"
    owner, watch = (read(name + s) for s in (".Ownership.json", ".ProcessClosure.json"))
    end = watch["Closure"]["FinalState"]
    assert owner["VerifiedNewOwner"] and owner["SourceSHA256"] == compiled["WorkbookSHA256"]
    assert watch["Passed"] and watch["ChildHasExited"] and watch["ChildExitCode"] == 0
    assert (end["PID"], end["StartTicksUTC"], end["State"]) == (owner["PID"], owner["StartTicksUTC"], "Absent")
    report = (HERE / name).read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_GAUSS_SPAN: passed=1; failed=0;" in report
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in report
    return {"compiler_PID": compiler["PID"], "compiler_start_ticks": compiler["StartTicksUTC"],
            "native_PID": owner["PID"], "native_start_ticks": owner["StartTicksUTC"],
            "native_book_sha256": compiled["WorkbookSHA256"]}


def keyed(rows):
    result = {}
    for key, value in rows:
        assert key not in result, key
        result[key] = value
    return result


def floats(xs):
    result = tuple(float(x) for x in xs)
    assert all(isfinite(x) for x in result), result
    return result


def integrate(points, stress, ox, oy):
    terms = []
    for (x, y, weight), (sxx, syy, szz, sxy, sxz, syz) in zip(points, stress, strict=True):
        xr, yr = x - ox, y - oy
        terms.append((weight*szz, weight*yr*szz, weight*xr*szz, weight*(xr*syz-yr*sxz),
                      weight*sxz, weight*syz))
    return tuple(map(fsum, zip(*terms, strict=True)))


def compare_forces(actual, target, force_limit, moment_limit):
    assert len(actual) == len(target) == 6
    error = max(abs(x-y) / (moment_limit if i in (1, 2, 3) else force_limit)
                for i, (x,y) in enumerate(zip(actual, target, strict=True)))
    assert error <= 1.0, (actual, target, force_limit, moment_limit, error)
    return error


def grid(spans, gauss, hole, stock):
    side = 240.0 / spans
    if gauss:
        b = 2*sqrt(10/7)
        inner, outer = sqrt(5-b)/3, sqrt(5+b)/3
        rule_nodes = [(1-outside)/2 for outside in (outer, inner, 0.0, -inner, -outer)]
        wm, wp = (322-13*sqrt(70))/1800, (322+13*sqrt(70))/1800
        rule_weights = (wm, wp, 64/225, wp, wm)
    else:
        rule_nodes = [0.1 + k/5 for k in range(5)]
        rule_weights = (0.2,)*5
    output = []
    for sy in range(spans):
        for j in range(5):
            for sx in range(spans):
                for i in range(5):
                    if hole and sx == sy == 1 and gauss:
                        output.append(stock[len(output)])
                        continue
                    x = -120.0 + side*(sx + rule_nodes[i])
                    y = -120.0 + side*(sy + rule_nodes[j])
                    area = side**2 * rule_weights[i] * rule_weights[j]
                    if hole and (sx, sy, i, j) == (1, 1, 3, 1):
                        assert area == 256.0 or isclose(area, 256.0, abs_tol=2e-13)
                        x, y, area = (area*x - 16*13)/(area-16), (area*y + 16*20)/(area-16), area-16
                    output.append((x,y,area))
    return output


def verify_geometry(rows, completed):
    assert completed
    setup = keyed((r[1], r[2:]) for r in rows if r[0] == "GEO_SETUP")
    all_points = keyed(((r[1], int(r[2])), floats(r[3:])) for r in rows if r[0] == "GEO_POINT")
    all_loads = keyed(((r[1], int(r[2])), floats(r[3:])) for r in rows if r[0] == "GEO_LOAD")
    all_stress = keyed(((r[1], int(r[2]), int(r[3])), floats(r[4:])) for r in rows if r[0] == "GEO_STRESS")
    output = {}
    stock_hole = None
    for kind in ("SquareStock", "SquareGauss", "HoleStock", "HoleGauss"):
        spans, n, total = map(int, setup[kind][:3])
        ox, oy, area, scale = floats(setup[kind][3:])
        hole, gauss = kind.startswith("Hole"), kind.endswith("Gauss")
        assert (spans, n, total) == ((3,225,225) if hole else (1,25,25)) and scale > 0
        points = [all_points.pop((kind, k)) for k in range(1, n+1)]
        expected = grid(spans, gauss, hole, stock_hole)
        for k, (native, theory) in enumerate(zip(points, expected, strict=True)):
            assert len(native) == 3 and native[2] > 0.0
            assert max(abs(a-b) for a,b in zip(native,theory,strict=True)) < 3e-8, (kind, k, native, theory)
            if hole:
                assert not (11.0 <= native[0] <= 15.0 and -22.0 <= native[1] <= -18.0)
        expected_area = 57584.0 if hole else 57600.0
        assert abs(fsum(p[2] for p in points)-expected_area) < 3e-8
        assert abs(area-expected_area) < 3e-8
        if kind == "HoleStock":
            stock_hole = points
        if kind == "HoleGauss":
            cut = [k for k, (x,y,w) in enumerate(stock_hole) if abs(x) < 40.0 and abs(y) < 40.0]
            assert len(cut) == 25 and all(points[k] == stock_hole[k] for k in cut)
            moved = sum(points[k] != stock_hole[k] for k in range(n) if k not in cut)
            assert moved == 200
        responses = []
        for index, load in enumerate(LOADS, 1):
            twist, *measured = all_loads.pop((kind,index))
            assert tuple(measured[:6]) == load
            actual = measured[6:]
            sigma = [all_stress.pop((kind,index,k)) for k in range(1,n+1)]
            independent = integrate(points,sigma,ox,oy)
            load_scale = fsum(abs(v)/scale if 1 <= i <= 3 else abs(v) for i,v in enumerate(load))
            f_lim = 1e-8*load_scale + 1e-7
            ratio = compare_forces(actual,load,f_lim,f_lim*scale)
            indep_ratio = compare_forces(independent,load,f_lim,f_lim*scale)
            compare_forces(independent,actual,1e-8,2e-6)
            responses.append({"twist_rad_per_m": twist, "signed_resultants_N_Nmm": actual,
                              "independent_resultants_N_Nmm": independent,
                              "max_fraction_of_tolerance": max(ratio, indep_ratio)})
        output[kind] = {"point_count": n, "area_mm2": area, "frame_origin_mm": [ox,oy], "loads": responses}
    assert not all_points and not all_loads and not all_stress
    j = 240.0**4 * (1.0/3.0 - 64/pi**5*fsum(tanh(n*pi/2)/n**5 for n in range(1, 512, 2)))
    sv = 1000 * 262750/(12500*j)
    for name, case in output.items():
        if name.startswith("Square"):
            case["pure_T_twist_error_vs_SV"] = case["loads"][0]["twist_rad_per_m"]/sv-1
    assert abs(output["SquareStock"]["pure_T_twist_error_vs_SV"]-.1015560012) < 1e-8
    assert abs(output["SquareGauss"]["pure_T_twist_error_vs_SV"]+.0011633148) < 1e-8
    return {"cases": output, "hole_cut_points_identical": 25, "hole_full_span_points_reweighted": 200}


def verify_mvt(rows, case, completed):
    setup = [r for r in rows if r[0] == "MVT_GEOM"]
    assert len(setup) == 1 and tuple(map(int,setup[0][1:4])) == (25,45,60)
    ox,oy,area,scale = floats(setup[0][4:])
    assert abs(area-57600.0) < 3e-8 and scale > 0
    budget = [r[1:] for r in rows if r[0] == "MVT_BUDGET"]
    assert budget == [["1","44","26","5e-7","5e-7"]]
    model = [r for r in rows if r[0] == "MVT2_ADAPT_SETUP"]
    assert len(model) == 1 and int(model[0][1]) == 5
    fc,ft,gt,gc = floats(model[0][2:])
    expected_gc = (fc/(.302*fc**(2/3)))**2*gt
    assert isclose(fc,588000/(.3*57600),rel_tol=1e-13) and abs(ft-2.10667357864589) < 1e-13
    assert isclose(gt,.073*fc**.18,rel_tol=1e-13) and isclose(gc,expected_gc,rel_tol=1e-13)
    samples = keyed((int(r[1]),floats(r[2:])) for r in rows if r[0] == "MVT_POINT")
    assert set(samples) == set(range(1,46))
    points = [samples[k][:3] for k in range(1,46)]
    directions = [samples[k][3:] for k in range(1,46)]
    assert all(len(d) == 6 for d in directions)
    assert all(directions[k] == (0.0,)*6 for k in range(25))
    assert all(directions[k] == (0.0,0.0,1.0,0.0,0.0,0.0) for k in range(25,29))
    assert all(abs(d[0]+d[1]-1.0)<1e-13 and d[2]==d[4]==d[5]==0.0 for d in directions[29:])
    expected = grid(1,case=="MVTGauss",False,None)
    for native, theory in zip(points[:25], expected, strict=True):
        assert max(abs(a-b) for a,b in zip(native,theory,strict=True)) < 3e-8
    states = keyed((r[1],floats(r[2:])) for r in rows if r[0] == "MVT2_STATE")
    stress_rows = keyed(((r[1],int(r[2])),floats(r[3:])) for r in rows if r[0] == "MVT_STRESS")
    trials = [r for r in rows if r[0] == "MVT2_ADAPT_TRIAL"]
    history = [(r[1], int(r[2]), float(r[3])) for r in rows if r[0] == "MVT2_ADAPT_HISTORY"]
    rejected = keyed((r[1],int(r[2])) for r in rows if r[0] == "MVT_WORK")
    assert 1 <= len(trials) <= 7
    assert [n for stage,n,torque in history] == list(range(1,len(history)+1))
    assert all(a[2]<b[2] for a,b in zip(history,history[1:]))
    result = []
    last_torque = 0.0
    for i, row in enumerate(trials,1):
        phase = f"R{i}"
        assert row[1] == phase
        requested,reached = floats(row[2:4])
        assert requested == TARGETS[i-1] and last_torque <= reached <= requested
        success = row[4] == "True"
        assert row[4] in ("True","False")
        status, code = map(int,row[5:7])
        rejected_count = rejected.pop(phase)
        assert 0 <= rejected_count <= 44
        if success:
            assert (status,code) == (4,0) and reached == requested
        else:
            assert i == len(trials) and not completed and (status,code) in {(6,10),(6,11),(5,5),(5,6),(5,7)}
        item = {"requested_T_kNm": requested, "accepted_T_kNm": reached, "internal_status": status,
                "result_code": code, "rejected_attempts": rejected_count}
        intermediate = [torque for stage, index, torque in history if stage == phase]
        assert all(last_torque < t <= reached for t in intermediate)
        if reached > last_torque:
            assert intermediate and intermediate[-1] == reached
        last_torque = reached
        if reached:
            req, rea, n,mx,my,t,qx,qy, eps,kx,ky,twist,gamma, sl,sh,nl,nh,dt,dc,pmin,pmax,resid = states.pop(phase)
            assert req == requested and rea == reached
            stress = []
            for point in range(1,46):
                values = stress_rows.pop((phase,point))
                assert len(values)==7
                if point <= 25:
                    assert values[-1] == 0.0
                    stress.append(values[:6])
                else:
                    stress.append(tuple(values[-1]*s-c for s,c in zip(directions[point-1],values[:6],strict=True)))
            independent = integrate(points,stress,ox,oy)
            measured = (n*1e3,mx*1e6,my*1e6,t*1e6,qx*1e3,qy*1e3)
            compare_forces(independent,measured,2e-7,2e-5)
            target = (0.0, 0.0, 0.0, reached*1e6, 0.0, 0.0)
            mtol = 5e-7 + 5e-7*target[3]/(area*scale) + 5e-14
            compare_forces(measured,target,mtol*area,mtol*area*scale)
            compare_forces(independent,target,mtol*area,mtol*area*scale)
            assert 0 <= resid <= mtol and twist > 0.0
            item.update({"twist_rad_per_m": twist, "forces_N_Nmm": measured,
                         "independent_forces_N_Nmm": independent, "native_resultant_norm_MPa": resid,
                         "tolerance_MPa": mtol,"max_tensile_damage":dt,"max_compressive_damage":dc,
                         "max_steel_stress_MPa":{"long":sl,"hoop":sh}})
        result.append(item)
    assert not states and not stress_rows and not rejected
    assert completed == (len(trials)==7 and result[-1]["accepted_T_kNm"]==10.51 and result[-1]["internal_status"]==4)
    return {"target_10_51_reached": completed,"stages": result,"accepted_history_torque_kNm": [r[2] for r in history],
            "physical_limit_established": result[-1]["internal_status"]==5}


def main(case):
    receipts = ownership(case)
    wire = (HERE / f"Native/{case}.csv").read_bytes()
    rows = [r.split(";") for r in wire.decode("cp1251").splitlines()]
    end = rows.pop()
    assert end[:2] == ["CASE_FINISHED",case] and end[2] in ("True","False")
    completed = end[2] == "True"
    elapsed, = floats(end[3:])
    assert elapsed >= 0
    take = verify_geometry(rows,completed) if case=="Geometry" else verify_mvt(rows,case,completed)
    proof = {"status":"PASS","case":case,"macro_elapsed_s":elapsed,"native_csv_SHA256":digest(wire),
             "ownership":receipts,**take}
    output = HERE / f"Verification{case}.json"
    content = (json.dumps(proof,indent=2,sort_keys=True)+"\n").encode()
    if output.is_file():
        assert output.read_bytes()==content
    else:
        output.write_bytes(content)
    print(f"PASS {output.name} SHA256 {digest(content)}")


if __name__ == "__main__":
    cli = ArgumentParser()
    cli.add_argument("--case",choices=("Geometry","MVTStock","MVTGauss"),required=True)
    main(cli.parse_args().case)
