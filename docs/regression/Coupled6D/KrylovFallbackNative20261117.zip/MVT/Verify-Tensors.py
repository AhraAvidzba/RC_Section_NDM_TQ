"""Check the exact accepted central-strain cable before an external material replay."""

from hashlib import sha256
import json
from math import isfinite
from pathlib import Path


ROOT = Path(__file__).resolve().parent
Q = (5000, 6250, 7500, 8750, 10000, 11250, 11562.5, 11875, 12187.5, 12500,
     12812.5, 13125, 13437.5, 13750, 14062.5, 14375, 14687.5, 15000)
T = (0.26275, 0.5255, 1.051, 2.102, 4.204, 6.8315, 8.67075, 10.51)
NPOINTS = 45


def numbers(fields, size):
    values = tuple(map(float, fields))
    assert len(values) == size and all(map(isfinite, values))
    return values


def rows(raw, encoding="ascii"):
    return [line.split(";") for line in raw.decode(encoding).splitlines()]


def unique(entries):
    pairs = list(entries)
    keyed = dict(pairs)
    assert len(keyed) == len(pairs)
    return keyed


def verify(raw, native):
    data = rows(raw)
    model = numbers(data[0][1:], 8)
    assert data[0][0] == "MODEL" and model[:2] == (30000, .2) and model[-1] == 125
    assert 0 < model[3] < model[2] and model[4] > model[2] / model[0] and min(model[5:7]) > 0
    index = 1
    curves = {}
    for branch, sign in (("TENSION", 1), ("COMPRESSION", -1)):
        table = []
        while data[index][:2] == ["CURVE", branch]:
            values = numbers(data[index][2:], 2)
            table.append(tuple(sign * value for value in values))
            index += 1
        assert len(table) >= 9 and table[0] == (0., 0.)
        assert all(a[0] < b[0] and b[1] > 0 for a, b in zip(table, table[1:]))
        curves[branch] = table
    assert abs(max(stress for _, stress in curves["TENSION"]) - model[3]) < 1e-12
    assert abs(max(stress for _, stress in curves["COMPRESSION"]) - model[2]) < 1e-12

    native_rows = rows(native, "cp1251")
    assert all(row[0] not in {"MVT2_CUT_INSERTED", "MVT2_CUT_DIRECT_STOP"} for row in native_rows)
    observed = unique(((row[1], int(row[2])), numbers(row[3:], 7)[:6]) for row in native_rows
                      if row[0] in {"MVT_STRESS", "MVT_SHEAR_STRESS"})
    accepted_t = unique((int(row[2]), (row[1], float(row[3]))) for row in native_rows
                        if row[0] == "MVT2_ADAPT_HISTORY")
    assert tuple(item[1] for item in accepted_t.values()) == T
    main_t = {index: label for index, (label, _) in accepted_t.items()
              if index == len(T) or accepted_t[index + 1][0] != label}
    schedule = [(f"R{i}", t * 1e6, 0, main_t.get(i)) for i, t in enumerate(T, 1)]
    schedule += [(f"S{i}", T[-1] * 1e6, q, f"S{i}") for i, q in enumerate(Q, 1)]
    frames = []
    compared = 0
    max_error = 0.0
    for label, torque, shear, reference in schedule:
        row = data[index]
        assert row[:2] == ["FRAME", label] and numbers(row[2:], 2) == (torque, shear)
        index += 1
        frame = []
        for point in range(1, NPOINTS + 1):
            row = data[index]
            assert row[:2] == ["POINT", str(point)]
            values = numbers(row[2:], 12)
            if reference is not None:
                expected = observed.pop((reference, point))
                max_error = max(max_error, *(abs(a - b) for a, b in zip(values[6:], expected, strict=True)))
                compared += 1
            frame.append(values)
            index += 1
        frames.append({"phase": label, "T_Nmm": torque, "Qy_N": shear, "points": frame})
    assert index == len(data) and not observed and compared == 25 * NPOINTS
    assert max_error < 1e-9
    return {"model": model, "curves_MPa": curves, "frames": frames,
            "accepted_stress_rows_checked": compared, "max_accepted_stress_difference_MPa": max_error,
            "tensor_wire_sha256": sha256(raw).hexdigest().upper()}


if __name__ == "__main__":
    proof = verify((ROOT / "Native/MVTGaussMixed.Tensor.csv").read_bytes(),
                   (ROOT / "Native/MVTGaussMixed.csv").read_bytes())
    encoded = (json.dumps(proof, indent=2, sort_keys=True) + "\n").encode()
    target = ROOT / "VerificationMVTGaussTensors.json"
    if target.exists():
        assert target.read_bytes() == encoded
    else:
        target.write_bytes(encoded)
    print("MVT2 CENTRAL TENSORS VERIFIED", proof["tensor_wire_sha256"],
          proof["max_accepted_stress_difference_MPa"], sha256(encoded).hexdigest().upper())
