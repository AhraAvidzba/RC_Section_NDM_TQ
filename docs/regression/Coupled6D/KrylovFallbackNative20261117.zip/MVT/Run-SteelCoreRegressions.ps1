# Проверяет штатные материалы в частной книге с рабочей поправкой стали.
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$tempBefore=$env:TEMP
$tmpBefore=$env:TMP
$flowBefore=$env:NDM_MVT_FLOW_FOLDER
$modeBefore=$env:NDM_MVT_FLOW_MODE
Push-Location -LiteralPath $root
try {
    . './Guard-IsolatedOffice.ps1'
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    if ($prep.force_schedule -cne 'IntegratedSteelCorrection') {throw 'Книга собрана для другой проверки.'}
    foreach ($file in $prep.inputs.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $file.Name).Hash -cne $file.Value) {throw "Не совпал вход $($file.Name)."}
    }
    $book='docs/regression/Diagnostic.xlsm'
    $report='Native/SteelCoreRegressions.txt'
    if (Test-Path -LiteralPath $report) {throw 'Протокол проверки уже существует.'}
    $compiler=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $compilerExit=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiler.Compiled -or $compiler.ProductionChanged -or $compilerExit.State -cne 'Absent' -or
        $compiler.ProductionSHA256 -cne $prep.source_book_sha256 -or $compiler.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $book).Hash) {
        throw 'Не подтверждена частная компиляция.'
    }
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    $env:NDM_MVT_FLOW_FOLDER=$null
    $env:NDM_MVT_FLOW_MODE=$null
    Assert-IsolatedOfficeReady 'VerifySteadySteelCore'
    $suite=@('RunCoupledNewtonTests','RunTestCoupledSteelLimit','RunTestCoupledSpatialTransactions','RunTestCoupledContinuation',
             'RunTestCoupledDeformationSteelCrossing','RunTestCoupledHoopCapacity','RunTestCoupledSteelClasses','RunTestCoupledSteelAtDesign')
    $suiteWire=($suite|ForEach-Object {'modTestCoupledElasticState.'+$_}) -join ','
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-FocusedKaniWatchdog.ps1',
        '-SourceWorkbook',$book,'-ReportPath',$report,'-Macro',$suiteWire,'-Mode','No','-TimeoutSeconds','165','-FailFast')
    & $legacy @arguments
    if ($LASTEXITCODE -ne 0) {throw 'Одна из направленных проверок рабочего решателя завершилась ошибкой.'}
} finally {
    $env:TEMP=$tempBefore
    $env:TMP=$tmpBefore
    $env:NDM_MVT_FLOW_FOLDER=$flowBefore
    $env:NDM_MVT_FLOW_MODE=$modeBefore
    Pop-Location
}
