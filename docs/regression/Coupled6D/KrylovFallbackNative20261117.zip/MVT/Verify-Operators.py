"""Rebuild the MVT2 strains and two spatial equilibrium anchors from the exported operators."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum, isfinite
from pathlib import Path
from zipfile import ZipFile


TENSOR_ARCHIVE = "D2DBF6FDE48CDB5997FD099056DEC49231EEABE6D018D817E809C3F951D801A1"
TENSOR_WIRE = "8D5BF7E9D9B688A9C18CB6AFF4972142752C232999CAC4AFD2A4821BC86CB33B"
REFERENCE_MODULUS = 30_000.0
LOAD_ORDER = ("N", "Mx", "My", "T", "Qx", "Qy")


def digest(raw):
    return sha256(raw).hexdigest().upper()


def values(row, count):
    nums = tuple(map(float, row))
    assert len(nums) == count and all(map(isfinite, nums))
    return nums


def insert(target, key, datum):
    assert key not in target
    target[key] = datum


def dot(a, b):
    return fsum(x * y for x, y in zip(a, b, strict=True))


def parse(raw):
    head, *tail = raw.decode("ascii").splitlines()
    assert head == "SIZE;60;45;0.001"
    tables = {family: {} for family in "GLBSRFH"}
    for row in tail:
        kind, *args = row.split(";")
        if kind in "GL":
            key, coeff = int(args[0]), values(args[1:], 60)
        elif kind in "BSR":
            key = int(args[0]), int(args[1])
            coeff = values(args[2:], 12 if kind == "B" else 60)
        elif kind == "F":
            key, coeff = args[0], values(args[1:], 60)
        else:
            assert kind == "H"
            key, coeff = (args[0], int(args[1]), int(args[2])), values(args[3:], 6)
        insert(tables[kind], key, coeff)
    phases = [f"R{i}" for i in range(1, 9)] + [f"S{i}" for i in range(1, 19)]
    assert list(tables["F"]) == phases
    assert set(tables["G"]) == set(range(1, 61)) and set(tables["L"]) == set(range(1, 7))
    points = range(1, 46)
    for kind, width in (("B", 60), ("S", 6), ("R", 6)):
        assert set(tables[kind]) == {(p, j) for p in points for j in range(1, width + 1)}
    assert set(tables["H"]) == {(phase, side, p) for phase in ("S1", "S18") for side in (-1, 0, 1) for p in points}
    assert all(tables["G"][j][i - 1] == tables["G"][i][j - 1] for j in range(1, 61) for i in range(1, 61))
    assert all(tables["G"][j][i - 1] == 0 for j in range(1, 57) for i in range(1, 57))
    return tables


def verify(root, frozen_archive):
    native = root / "Native"
    raw = (native / "Operators.csv").read_bytes()
    data = parse(raw)
    tensors_raw = (native / "MVTGaussMixed.Tensor.csv").read_bytes()
    assert digest(tensors_raw) == TENSOR_WIRE
    assert digest(frozen_archive.read_bytes()) == TENSOR_ARCHIVE
    with ZipFile(frozen_archive) as reference:
        for name in ("Native/MVTGaussMixed.Tensor.csv", "VerificationMVTGaussTensors.json"):
            assert (root / name).read_bytes() == reference.read(name)
        trace_name = "Native/MVTGaussMixed.csv"
        assert (root / trace_name).read_bytes().splitlines()[:-1] == reference.read(trace_name).splitlines()[:-1]
    proof = json.loads((root / "VerificationMVTGaussTensors.json").read_bytes())
    raw_main = (native / "MVTGaussMixed.csv").read_bytes().decode("cp1251")
    raw_rows = [row.split(";") for row in raw_main.splitlines()]
    geometry, = [row for row in raw_rows if row[0] == "MVT_GEOM"]
    ox, oy, area, length = values(geometry[4:], 4)
    positions = {int(row[1]): values(row[2:], 9) for row in raw_rows if row[0] == "MVT_POINT"}
    steel = {(row[1], int(row[2])): float(row[-1]) for row in raw_rows if row[0] == "MVT_SHEAR_STRESS"}
    strain_error = 0.0
    anchors = []
    for frame in proof["frames"]:
        phase = frame["phase"]
        field = data["F"][phase]
        for p, saved in enumerate(frame["points"], 1):
            center = [fsum(coefficient * data["B"][p, j][k] for j, coefficient in enumerate(field, 1)) for k in range(6)]
            strain_error = max(strain_error, *(abs(a - b) for a, b in zip(center, saved[:6], strict=True)))
        if phase not in ("S1", "S18"):
            continue
        qy = frame["Qy_N"]
        load = (0., -330. * qy, 0., frame["T_Nmm"], 0., qy)
        external = [fsum(data["L"][i][row] * value for i, value in enumerate(load, 1)) for row in range(60)]
        eq = [dot(field, data["G"][row + 1]) - ext for row, ext in enumerate(external)]
        coefficients = []
        for p, state in enumerate(frame["points"], 1):
            x, y, w, *direction = positions[p]
            center = data["H"][phase, 0, p]
            assert center == tuple(state[6:]) if p <= 25 else max(
                abs(a - (steel[phase, p] * d - c)) for a, d, c in zip(center, direction, state[6:], strict=True)) < 3e-13
            x -= ox
            y -= oy
            zz, xz, yz = center[2], center[4], center[5]
            coefficients.append((w * zz, w * y * zz, w * x * zz, w * (x * yz - y * xz), w * xz, w * yz))
            plus, minus = data["H"][phase, 1, p], data["H"][phase, -1, p]
            for k, (pc, mc, cc) in enumerate(zip(plus, minus, center, strict=True), 1):
                gradient = (pc - mc) / .002
                eq = [old + cc * s + gradient * r for old, s, r in zip(eq, data["S"][p, k], data["R"][p, k], strict=True)]
        resultants = tuple(map(fsum, zip(*coefficients, strict=True)))
        errors = [(a - b) / (area * length if 1 <= index <= 3 else area)
                  for index, (a, b) in enumerate(zip(resultants, load, strict=True))]
        tolerance = 5e-7 + 5e-7 * max(map(abs, external[:56]))
        weak = max(map(abs, eq[:56]))
        gauge = max(map(abs, eq[56:]))
        six = max(map(abs, errors))
        assert max(weak, gauge * REFERENCE_MODULUS, six) <= tolerance
        anchors.append({"phase": phase, "max_weak_residual_MPa": weak, "max_gauge_residual": gauge,
                        "max_resultant_residual_MPa": six, "tolerance_MPa": tolerance,
                        "resultants_N_Nmm": resultants, "weak_residual": eq})
    assert strain_error < 3e-16 and len(anchors) == 2
    return {"status": "PASS", "operators_sha256": digest(raw), "accepted_field_count": len(data["F"]),
            "max_center_strain_difference": strain_error, "physical_equations": 56, "gauges": 4,
            "spatial_anchors": anchors, "resultant_order": LOAD_ORDER}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.root, args.reference)
    raw = (json.dumps(result, indent=2, sort_keys=True) + "\n").encode()
    if args.out.is_file():
        assert args.out.read_bytes() == raw
    else:
        args.out.write_bytes(raw)
    print("MVT2 SPATIAL OPERATORS VERIFIED", result["operators_sha256"], digest(raw))
