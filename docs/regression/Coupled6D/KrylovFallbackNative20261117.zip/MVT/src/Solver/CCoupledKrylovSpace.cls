﻿VERSION 1.0 CLASS
BEGIN
  MultiUse = -1
END
Attribute VB_Name = "CCoupledKrylovSpace"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ==========================================================================
' Малое пространство GMRES для уточнения направления связанного равновесия
' ==========================================================================
' Алгоритм Арнольди и QR по Saad–Schultz (1986), §3.1–3.2.
' Вызывающий вычисляет предобусловленное направление и действие оператора.
' Класс не читает материалы и Excel и не подтверждает нелинейное равновесие.
' Столбец является первым индексом матриц. История между Start не сохраняется.

Private Const BREAKDOWN_RATIO As Double = 0.000000000001
Private mSize As Long, mLimit As Long, mDimension As Long
Private mBasis() As Double, mDirections() As Double, mHessenberg() As Double
Private mCosine() As Double, mSine() As Double, mRight() As Double
Private mInitialNorm As Double, mStopped As Boolean
Private mFailure As ESolverFailureCode

' Начинает решение A*z=b с нулевой поправки. Вектор b уже имеет выбранные
' вызывающим масштабы уравнений; размер пространства ограничен maxVectors.
Friend Function Start(ByRef rightHandSide() As Double, ByVal maxVectors As Long) As Boolean
    mSize = 0: mDimension = 0: mStopped = True: mFailure = sfcNone
    If LBound(rightHandSide) <> 1 Or maxVectors < 1 Then _
        Err.Raise 5, "CCoupledKrylovSpace", "Задайте вектор с индексами от 1 и положительный размер пространства Крылова."
    mSize = UBound(rightHandSide): mLimit = maxVectors
    If mLimit > mSize Then mLimit = mSize
    ReDim mBasis(1 To mLimit + 1, 1 To mSize), mDirections(1 To mLimit, 1 To mSize)
    ReDim mHessenberg(1 To mLimit, 1 To mLimit + 1)
    ReDim mCosine(1 To mLimit), mSine(1 To mLimit), mRight(1 To mLimit + 1)
    On Error GoTo ArithmeticFailure
    mInitialNorm = VectorNorm(rightHandSide)
    mRight(1) = mInitialNorm
    If mInitialNorm > 0# Then
        Dim i As Long
        For i = 1 To mSize: mBasis(1, i) = rightHandSide(i) / mInitialNorm: Next i
        mStopped = False
    End If
    Start = True
    Exit Function
ArithmeticFailure:
    If Err.Number <> 6 And Err.Number <> 11 Then Err.Raise Err.Number, Err.Source, Err.Description
    mFailure = sfcNumericalFailure
End Function

' Копирует следующий единичный вектор в масштабе уравнений. Вызывающий
' применяет к нему свою неизменную предобусловливающую факторизацию.
Friend Function CopyNextResidualDirection(ByRef vector() As Double) As Boolean
    If mStopped Or mDimension >= mLimit Then Exit Function
    ReDim vector(1 To mSize)
    Dim i As Long
    For i = 1 To mSize: vector(i) = mBasis(mDimension + 1, i): Next i
    CopyNextResidualDirection = True
End Function

' Добавляет z=M^(-1)*v и измеренное A*z. Массивы входа не меняются.
' Двойная ортогонализация ограничивает потерю независимости базиса.
Friend Function AddOperatorVector(ByRef direction() As Double, ByRef product() As Double) As Boolean
    If mStopped Or mDimension >= mLimit Then Exit Function
    If LBound(direction) <> 1 Or UBound(direction) <> mSize Or _
            LBound(product) <> 1 Or UBound(product) <> mSize Then _
        Err.Raise 5, "CCoupledKrylovSpace", "Размер направления или действия оператора не совпадает с системой."
    On Error GoTo ArithmeticFailure
    Dim column As Long, i As Long, j As Long, pass As Long
    Dim vector() As Double, projection As Double, originalNorm As Double, remainder As Double
    column = mDimension + 1: vector = product
    originalNorm = VectorNorm(vector)
    For i = 1 To mSize: mDirections(column, i) = direction(i): Next i
    For pass = 1 To 2
        For j = 1 To column
            projection = 0#
            For i = 1 To mSize: projection = projection + mBasis(j, i) * vector(i): Next i
            mHessenberg(column, j) = mHessenberg(column, j) + projection
            For i = 1 To mSize: vector(i) = vector(i) - projection * mBasis(j, i): Next i
        Next j
    Next pass
    remainder = VectorNorm(vector)
    mHessenberg(column, column + 1) = remainder
    mStopped = (remainder <= BREAKDOWN_RATIO * originalNorm)
    If Not mStopped Then
        For i = 1 To mSize: mBasis(column + 1, i) = vector(i) / remainder: Next i
    End If

    Dim upper As Double, lower As Double, radius As Double, pair(1 To 2) As Double
    For j = 1 To column - 1
        upper = mHessenberg(column, j): lower = mHessenberg(column, j + 1)
        mHessenberg(column, j) = mCosine(j) * upper + mSine(j) * lower
        mHessenberg(column, j + 1) = -mSine(j) * upper + mCosine(j) * lower
    Next j
    upper = mHessenberg(column, column): lower = mHessenberg(column, column + 1)
    pair(1) = upper: pair(2) = lower: radius = VectorNorm(pair)
    If radius = 0# Then
        mStopped = True: mFailure = sfcSingularTangent
        Exit Function
    End If
    mCosine(column) = upper / radius: mSine(column) = lower / radius
    mHessenberg(column, column) = radius: mHessenberg(column, column + 1) = 0#
    mRight(column + 1) = -mSine(column) * mRight(column)
    mRight(column) = mCosine(column) * mRight(column)
    mDimension = column
    If mDimension = mLimit Then mStopped = True
    AddOperatorVector = True
    Exit Function
ArithmeticFailure:
    If Err.Number <> 6 And Err.Number <> 11 Then Err.Raise Err.Number, Err.Source, Err.Description
    mStopped = True: mFailure = sfcNumericalFailure
End Function

' Решает малую треугольную систему QR и возвращает сумму z_j*y_j.
' Результат требует отдельной проверки по полной нелинейной невязке.
Friend Function CopyCorrection(ByRef correction() As Double) As Boolean
    If mSize < 1 Then Exit Function
    ReDim correction(1 To mSize)
    If mDimension = 0 Then
        CopyCorrection = (mInitialNorm = 0#)
        Exit Function
    End If
    On Error GoTo ArithmeticFailure
    Dim weights() As Double, i As Long, j As Long, value As Double
    ReDim weights(1 To mDimension)
    For i = mDimension To 1 Step -1
        value = mRight(i)
        For j = i + 1 To mDimension: value = value - mHessenberg(j, i) * weights(j): Next j
        weights(i) = value / mHessenberg(i, i)
    Next i
    For i = 1 To mSize
        For j = 1 To mDimension: correction(i) = correction(i) + mDirections(j, i) * weights(j): Next j
    Next i
    CopyCorrection = True
    Exit Function
ArithmeticFailure:
    If Err.Number <> 6 And Err.Number <> 11 Then Err.Raise Err.Number, Err.Source, Err.Description
    Erase correction
    mFailure = sfcNumericalFailure
End Function

' Считает евклидову норму с предварительным масштабированием компонентов.
' Квадраты исходных больших или малых чисел не вычисляются напрямую.
Private Function VectorNorm(ByRef vector() As Double) As Double
    Dim maximum As Double, square As Double, i As Long
    For i = LBound(vector) To UBound(vector)
        If Abs(vector(i)) > maximum Then maximum = Abs(vector(i))
    Next i
    If maximum = 0# Then Exit Function
    For i = LBound(vector) To UBound(vector): square = square + (vector(i) / maximum) ^ 2: Next i
    VectorNorm = maximum * Sqr(square)
End Function

' Возвращает число включённых направлений.
Friend Property Get Dimension() As Long
    Dimension = mDimension
End Property

' Возвращает оценку нормы линейной невязки из последнего элемента QR.
Friend Property Get EstimatedResidualNorm() As Double
    EstimatedResidualNorm = Abs(mRight(mDimension + 1))
End Property

' Возвращает код отказа последней линейной операции.
Friend Property Get FailureCode() As ESolverFailureCode
    FailureCode = mFailure
End Property
