VERSION 1.0 CLASS
BEGIN
  MultiUse = -1
END
Attribute VB_Name = "CTestTabulatedConcreteFlow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Раздельное спектральное обновление под заданные одноосные таблицы.
' Состояние хранит вызывающий материал. Нулевые вязкость и перекрёстное
' повреждение, изотропная упругость, один набор переменных на каждый знак.
' Формулы соответствуют проверке ASDConcrete3D из журнала §572.

Private Const ALPHA As Double = 4# / 33#
Private Const GAMMA As Double = 3#
Private mTension As CTestConcreteBackbone, mCompression As CTestConcreteBackbone
Private mModulus As Double, mPoisson As Double, mShearModulus As Double, mLame As Double
Private mStrengthRatio As Double, mBeta As Double

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Загружает обе подготовленные ветви и фиксирует согласованные упругие параметры.
Friend Sub TestInitialize(ByVal path As String, ByVal modulus As Double, ByVal poisson As Double)
    Dim handle As Integer, row As String, head() As String
    Dim failure As Long, description As String
    On Error GoTo Failed
    handle = FreeFile
    Open path For Input As #handle
    Line Input #handle, row
    head = Split(row, ";")
    If UBound(head) <> 2 Then Err.Raise 5, , "Не прочитаны параметры табличного бетона."
    If head(0) <> "ASDFlow1" Or Val(head(1)) <> modulus Or Val(head(2)) <> poisson Then _
        Err.Raise 5, , "Упругие параметры материала и таблиц различаются."
    Set mTension = New CTestConcreteBackbone: Set mCompression = New CTestConcreteBackbone
    mTension.TestRead handle, "T"
    mCompression.TestRead handle, "C"
    If Not EOF(handle) Then Err.Raise 5, , "После таблицы обнаружены лишние данные."
    Close #handle
    mModulus = modulus: mPoisson = poisson
    mShearModulus = modulus / (2# * (1# + poisson))
    mLame = 2# * mShearModulus * poisson / (1# - 2# * poisson)
    mStrengthRatio = GeomMax(5#, mCompression.TestPeak / mTension.TestPeak)
    mBeta = (1# - ALPHA) * mStrengthRatio - (1# + ALPHA)
    Exit Sub
Failed:
    failure = Err.Number: description = Err.Description
    On Error Resume Next
    If handle <> 0 Then Close #handle
    On Error GoTo 0
    Err.Raise failure, "CTestTabulatedConcreteFlow.TestInitialize", description & vbCrLf & path
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продолжает один тензор из принятого состояния. Все выходы относятся к одной пробе.
Friend Sub TestStep(ByRef strain() As Double, ByRef oldStrain() As Double, ByRef oldEffective() As Double, _
        ByVal oldT As Double, ByVal oldC As Double, ByRef newT As Double, ByRef newC As Double, _
        ByRef effective() As Double, ByRef nominal() As Double, ByRef plastic() As Double, _
        ByRef damageT As Double, ByRef damageC As Double)
    Dim trial(1 To 6) As Double, dv(1 To 6) As Double, i As Long, volumeTerm As Double
    For i = 1 To 6: dv(i) = strain(i) - oldStrain(i): Next i
    volumeTerm = mLame * (dv(1) + dv(2) + dv(3))
    For i = 1 To 3: trial(i) = oldEffective(i) + 2# * mShearModulus * dv(i) + volumeTerm: Next i
    For i = 4 To 6: trial(i) = oldEffective(i) + mShearModulus * dv(i): Next i
    Dim trace As Double, q As Double, high As Double, middle As Double, low As Double
    CoupledStressInvariants trial, trace, q, high, middle, low
    Dim tensileExcursion As Double, compressiveExcursion As Double
    If high >= mTension.TestFloor Then _
        tensileExcursion = (ALPHA * trace + q + mBeta * high) / ((1# - ALPHA) * mModulus * mStrengthRatio)
    If low < 0# Then
        Dim a As Double, b As Double, c As Double, negativeTrace As Double, negativeQ As Double
        a = GeomMin(0#, high): b = GeomMin(0#, middle): c = low
        negativeTrace = a + b + c
        negativeQ = Sqr(0.5 * ((a - b) ^ 2 + (b - c) ^ 2 + (c - a) ^ 2))
        compressiveExcursion = (ALPHA * negativeTrace + negativeQ + GAMMA * a) / ((1# - ALPHA) * mModulus)
    End If
    Dim scaledT As Double, scaledC As Double, sigmaT As Double, sigmaC As Double
    TestBranchStep mTension, oldT, tensileExcursion, newT, sigmaT, scaledT, damageT
    TestBranchStep mCompression, oldC, compressiveExcursion, newC, sigmaC, scaledC, damageC
    TestScaleSigns trial, high, middle, low, scaledT, scaledC, effective
    TestScaleSigns trial, high, middle, low, sigmaT, sigmaC, nominal
    Dim elasticVolume As Double
    elasticVolume = mPoisson * (effective(1) + effective(2) + effective(3))
    For i = 1 To 3
        plastic(i) = strain(i) - ((1# + mPoisson) * effective(i) - elasticVolume) / mModulus
    Next i
    For i = 4 To 6: plastic(i) = strain(i) - effective(i) / mShearModulus: Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продвигает необратимую координату и вычисляет масштабы двух напряжений ветви.
Private Sub TestBranchStep(ByVal law As CTestConcreteBackbone, ByVal previous As Double, _
        ByVal excursion As Double, ByRef current As Double, ByRef nominalScale As Double, _
        ByRef effectiveScale As Double, ByRef damage As Double)
    Dim y As Double, z As Double, previousPlastic As Double, denominator As Double
    law.TestStresses previous, y, z
    previousPlastic = previous - z / mModulus
    current = GeomMax(previous, excursion + previousPlastic)
    law.TestStresses current, y, z
    denominator = mModulus * (current - previousPlastic)
    nominalScale = y / denominator: effectiveScale = z / denominator
    damage = 1# - y / z
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Масштабирует знаковые части спектра. Проектор одиночного знака устойчив
' к кратности двух остальных главных напряжений.
Private Sub TestScaleSigns(ByRef source() As Double, ByVal high As Double, ByVal middle As Double, _
        ByVal low As Double, ByVal positiveScale As Double, ByVal negativeScale As Double, ByRef result() As Double)
    Dim commonScale As Double, i As Long
    If low >= 0# Or high <= 0# Or positiveScale = negativeScale Then
        If high <= 0# Then commonScale = negativeScale Else commonScale = positiveScale
        For i = 1 To 6: result(i) = commonScale * source(i): Next i
        Exit Sub
    End If
    Dim isolatedValue As Double, pairedValue As Double, projectorScale As Double
    If middle >= 0# Then
        isolatedValue = low: pairedValue = high
        commonScale = positiveScale: projectorScale = negativeScale - positiveScale
    Else
        isolatedValue = high: pairedValue = low
        commonScale = negativeScale: projectorScale = positiveScale - negativeScale
    End If
    projectorScale = projectorScale * (isolatedValue / (isolatedValue - middle)) / (isolatedValue - pairedValue)

    Dim x As Double, y As Double, z As Double, h As Double, g As Double, f As Double, eigenSum As Double
    x = source(1): y = source(2): z = source(3)
    h = source(4): g = source(5): f = source(6)
    eigenSum = middle + pairedValue
    result(1) = commonScale * x + projectorScale * ((x - middle) * (x - pairedValue) + h * h + g * g)
    result(2) = commonScale * y + projectorScale * ((y - middle) * (y - pairedValue) + h * h + f * f)
    result(3) = commonScale * z + projectorScale * ((z - middle) * (z - pairedValue) + g * g + f * f)
    result(4) = commonScale * h + projectorScale * (h * (x + y - eigenSum) + g * f)
    result(5) = commonScale * g + projectorScale * (g * (x + z - eigenSum) + h * f)
    result(6) = commonScale * f + projectorScale * (f * (y + z - eigenSum) + h * g)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает фактические узлы выбранной табличной ветви.
Friend Sub TestCopyCurve(ByVal compression As Boolean, ByRef strain() As Double, ByRef stress() As Double)
    If compression Then
        mCompression.TestCopyCurve -1#, strain, stress
    Else
        mTension.TestCopyCurve 1#, strain, stress
    End If
End Sub
