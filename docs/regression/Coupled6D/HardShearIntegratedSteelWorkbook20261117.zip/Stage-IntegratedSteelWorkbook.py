"""Собирает чистую контрольную книгу с рабочей поправкой ветвей стали."""

from argparse import ArgumentParser
from copy import copy
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
TOOLS = Path('D:/CodexScratch/RC_Section_NDM_TQ/VBAFlowIntegratedCore')
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'
DUMP = 'workbook/output/VBA_All_Code.txt'
DUMP_SHA = '8F48A525BD7983304E7CB83874F4FBCE0F475C63ED4D210E2550353DE0F956EF'
DRAFT = 'docs/regression/Diagnostic.xlsm'
CANDIDATE = 'docs/regression/Audit03/RC_Section_NDM.xlsm'
PART = 'xl/vbaProject.bin'
CLASSES = ('src/Solver/CCoupledNewtonSolver.cls','src/Solver/CCoupledSteelCorrection.cls',
           'src/Materials/CCoupledReinforcedResponse.cls')
CORE_PROOF = ('MVT2IntegratedSteelCorrection20261117.zip','20D400686306651D3605A60FEF7B81D4838BF3A368591264243F74434AFC88DC')
BASELINE = ('HardShearCoarseGrowthWorkbookRelease20261117.zip','6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63')


def digest(data):
    """Возвращает отпечаток полного входа."""
    return sha256(data).hexdigest().upper()


def sealed(repo, entry):
    """Открывает архив после сравнения с контрольной точкой."""
    path=repo/'docs/regression/Coupled6D'/entry[0]
    assert digest(path.read_bytes())==entry[1]
    return ZipFile(path)


def put(path, data):
    """Записывает новый файл в частной сборке, сохраняя старые протоколы."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as writer:
        writer.write(data)


def json_bytes(data):
    """Формирует стабильную UTF-8 квитанцию."""
    return (json.dumps(data,indent=2,sort_keys=True)+'\n').encode('utf-8')


def stage(repo, root, template):
    """Готовит частный подкаталог с чистой книгой и точными исходниками."""
    installed=(repo/BOOK).read_bytes()
    dump=(repo/DUMP).read_bytes()
    assert (digest(installed),digest(dump))==(BOOK_SHA,DUMP_SHA)
    files={BOOK:installed,DRAFT:installed,'Stock.VBA_All_Code.txt':dump}
    prep=json.loads((template/'Preparation.json').read_bytes())
    with sealed(repo,CORE_PROOF) as evidence:
        snapshot=json.loads(evidence.read('Preparation.json'))
        for file in CLASSES:
            raw=(repo/file).read_bytes()
            assert raw.replace(b'\r\n',b'\n')==evidence.read(file).replace(b'\r\n',b'\n')
            files[file]=raw
        assert prep['source_core']==snapshot['source_core']
        for file in ('Guard-IsolatedOffice.ps1','tools/build_workbook/Run-FocusedKaniWatchdog.ps1'):
            assert (template/file).read_bytes()==evidence.read(file)
    for p in (template/'tools/build_workbook').glob('*'):
        if p.is_file(): files[p.relative_to(template).as_posix()]=p.read_bytes()
    for file in ('Guard-IsolatedOffice.ps1',):
        files[file]=(template/file).read_bytes()
    exporter='tools/build_workbook/Export-Audit03VbaSnapshot.ps1'
    files[exporter]=(repo/exporter).read_bytes()
    for name in ('Stage-IntegratedSteelWorkbook.py','Run-IntegratedSteelWorkbook.ps1'):
        files[name]=(HERE/name).read_bytes()
    with sealed(repo,BASELINE) as base:
        for name in ('ReadWorkbookCurve.py','Verify-FullAB.py'):
            files[name]=base.read(name)
    manifest={'baseline_book_sha256':BOOK_SHA,'baseline_dump_sha256':DUMP_SHA,'classes':list(CLASSES),
              'inputs':{name:digest(raw) for name,raw in files.items() if name!=DRAFT}}
    files['Preparation.json']=json_bytes(manifest)
    root.mkdir()
    for d in ('Native','Temp','src','tests'):
        (root/d).mkdir()
    for name, data in files.items(): put(root/name,data)
    print('CLEAN STEEL WORKBOOK INPUTS',root,digest(files['Preparation.json']))


def package(repo, root):
    """Переносит только VBA-контейнер и проверяет фактические модули в нём."""
    installed=(root/BOOK).read_bytes()
    compiled=(root/DRAFT).read_bytes()
    compiler=json.loads((root/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
    exit_note=json.loads((root/'CompileClosure.json').read_text('utf-8-sig'))
    assert (digest(installed),compiler['ProductionSHA256'])==(BOOK_SHA,BOOK_SHA)
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['WorkbookSHA256']==digest(compiled)
    assert exit_note['State']=='Absent' and set(compiler['Modules'])=={Path(p).stem for p in CLASSES}
    with sealed(repo,BASELINE) as base:
        shared={'__name__':'__pinned__','__file__':str(root/'Stage-Release.py')}
        exec(compile(base.read('Stage-Release.py'),shared['__file__'],'exec'),shared)
    output=BytesIO()
    with ZipFile(BytesIO(installed)) as old, ZipFile(BytesIO(compiled)) as draft, ZipFile(output,'w') as result:
        result.comment=old.comment
        project=draft.read(PART)
        for item in old.infolist(): result.writestr(copy(item), project if item.filename==PART else old.read(item))
    packet=output.getvalue()
    with ZipFile(BytesIO(installed)) as old, ZipFile(BytesIO(packet)) as result:
        parts=old.namelist()
        assert parts==result.namelist() and old.comment==result.comment and len(parts)==len(set(parts))==122
        assert [name for name in parts if old.read(name)!=result.read(name)]==[PART]
        part_digests={name:digest(result.read(name)) for name in parts}
    observer,read_sources=shared['parse_vba'](repo)
    _,before=read_sources(BytesIO(installed))
    _,after=read_sources(BytesIO(packet))
    names={Path(file).stem for file in CLASSES}
    new='CCoupledSteelCorrection'
    assert set(after)==set(before)|{new} and len(before)==225
    fold=observer['literal_safe_fold']
    changed={n for n in before if fold(before[n])!=fold(after[n])}
    assert changed==names-{new}
    body=observer['compiler_body']
    normalizations={}
    for file in CLASSES:
        n=Path(file).stem
        source, source_conversions=body((root/file).read_text('utf-8-sig'),n)
        packed, packed_conversions=body(after[n],n)
        assert source==packed, n
        normalizations[n]={'source':source_conversions,'packed':packed_conversions}
    assert normalizations['CCoupledNewtonSolver']=={'source':[['2e-12','0.000000000002'],['1e-12','0.000000000001']],
                                                   'packed':[]}
    assert all(item=={'source':[],'packed':[]} for n,item in normalizations.items() if n!='CCoupledNewtonSolver')
    proof={'source_sha256':BOOK_SHA,'candidate_sha256':digest(packet),'compiled_sha256':digest(compiled),
           'normalized_changed_modules':sorted(changed),'new_module':new,'unchanged_ooxml_parts':121,
           'unchanged_modules':len(before)-len(changed),'parts':part_digests,'numeric_literal_normalizations':normalizations}
    put(root/CANDIDATE,packet)
    put(root/'Package.json',json_bytes(proof))
    print('CLEAN STEEL WORKBOOK PACKAGE',proof['candidate_sha256'])


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--template',type=Path,default=TOOLS)
    parser.add_argument('--package',action='store_true')
    arg=parser.parse_args()
    if arg.package: package(arg.repo.resolve(),arg.root.resolve())
    else: stage(arg.repo.resolve(),arg.root.resolve(),arg.template.resolve())
