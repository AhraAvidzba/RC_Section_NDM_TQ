"""Сверяет штатный расчёт HardShear и сохранённый лист Results в чистой сборке."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from math import isclose
from pathlib import Path
import re
from runpy import run_path
from subprocess import check_output
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
BASE = ('HardShearCoarseGrowthWorkbookRelease20261117.zip','6931A477A1D64FD38EE5134197B54646A68A7E28C475DBA969D7807883336D63')
BASE_REV = '0081ce2aee08b83f49c74dbe9c7d95a991ebd327'
BOOK = 'docs/regression/Audit03/RC_Section_NDM.xlsm'
DUMP = 'docs/regression/Audit03/VBA_All_Code.txt'
SAVED = 'Native/SavedResultsParts.zip'


def digest(data):
    """Формирует SHA-256 для контрольных байтов."""
    return sha256(data).hexdigest().upper()


def read(path):
    """Читает UTF-8 протокол, подготовленный Python или PowerShell."""
    return json.loads(path.read_text('utf-8-sig'))


def baseline(repo, assembly):
    """Подключает закреплённые доказательства предыдущей рабочей книги."""
    path=repo/'docs/regression/Coupled6D'/BASE[0]
    assert digest(path.read_bytes())==BASE[1]
    with ZipFile(path) as z:
        helper={'__name__':'__pinned__','__file__':str(path)}
        exec(compile(z.read('Stage-Release.py'),str(path),'exec'),helper)
        previous=json.loads(z.read('PackagedNativeVerification.json'))
    current=repo/assembly['DUMP']
    original=current.read_bytes()
    if digest(original)!=assembly['DUMP_SHA']:
        original=check_output(['git','cat-file','blob',f'{BASE_REV}:{assembly["DUMP"]}'],cwd=repo)
    assert digest(original)==assembly['DUMP_SHA']
    return helper,previous,original


def export(repo, root, assembly, helper, old_dump, package):
    """Сравнивает фактическую выгрузку VBE с исходниками и 223 прежними модулями."""
    current_wire=(root/DUMP).read_bytes()
    before=helper['components'](old_dump)
    current=helper['components'](current_wire)
    assert len(before)==225 and set(current)==set(before)|{package['new_module']}
    changed={n for n in before if current[n]!=before[n]}
    assert changed==set(package['normalized_changed_modules']) and len(current)==226
    observer,_=helper['parse_vba'](repo)
    body=observer['compiler_body']
    for filename in assembly['CLASSES']:
        name=Path(filename).stem
        code=(root/filename).read_text('utf-8-sig')
        # Разбор VBE уже исключил строки атрибутов. Сопоставляет тело и оставляет литералы строк точными.
        actual='Option Explicit\n'+'\n'.join(current[name][1][1:])
        assert body(code,name)[0]==body(actual,name)[0], name
        assert current[name][0]=='TYPE: 2'
    log=(root/'Export.log').read_text('utf-8-sig')
    owner=read(root/'ExportClosure.json')
    assert owner['State']=='Absent' and f"OWNED_EXCEL: id={owner['PID']}; utcStartTicks={owner['StartTicksUTC']}" in log
    assert f"VBA_READ_ONLY_EXPORT: components=226; sourceSHA256={package['candidate_sha256']}; sourceUnchanged=True;" in log
    return {'sha256':digest(current_wire),'components':len(current),'unchanged':package['unchanged_modules'],
            'updated':sorted(changed),'added':package['new_module']}


def capture(root, curve_reader):
    """Сохраняет только части сохранённой книги, необходимые для автономного чтения Results."""
    transcript=(root/'Native/Both.txt').read_text('utf-8-sig')
    saved_name,=re.findall(r'^RESULTS_SAVE_REOPEN:[^\n]*; file=(.+)$',transcript,re.M)
    stored=Path(saved_name).resolve()
    assert stored.name=='RC_Section_NDM_saved.xlsm' and stored.is_relative_to((root/'Temp').resolve())
    full=curve_reader(stored)
    parts=['xl/workbook.xml','xl/_rels/workbook.xml.rels','xl/sharedStrings.xml',full['worksheet']]
    with ZipFile(stored) as book, ZipFile(root/SAVED,'x',compression=ZIP_DEFLATED,compresslevel=9) as compact:
        for name in parts: compact.writestr(name,book.read(name))
    provenance={key:full[key] for key in ('worksheet','worksheet_sha256','saved_workbook_sha256','named_anchor')}
    (root/'Native/SavedResultsProvenance.json').write_bytes((json.dumps(provenance,indent=2,sort_keys=True)+'\n').encode())


def verify(repo, root, capture_saved=False):
    """Подтверждает упаковку, нативную приёмку и численный статус после открытия Results."""
    assembly=run_path(str(root/'Stage-IntegratedSteelWorkbook.py'))
    prep=read(root/'Preparation.json')
    package=read(root/'Package.json')
    helper,previous,old_dump=baseline(repo,assembly)
    assert package['source_sha256']==assembly['BOOK_SHA'] and prep['baseline_book_sha256']==package['source_sha256']
    assert package['unchanged_ooxml_parts']==121 and len(package['parts'])==122 and package['unchanged_modules']==223
    assert package['normalized_changed_modules']==['CCoupledNewtonSolver','CCoupledReinforcedResponse']
    assert package['new_module']=='CCoupledSteelCorrection'
    if (root/BOOK).is_file():
        raw=(root/BOOK).read_bytes()
        assert digest(raw)==package['candidate_sha256']
        with ZipFile(BytesIO(raw)) as z:
            assert {name:digest(z.read(name)) for name in z.namelist()}==package['parts']
    for filename in (*prep['classes'],'Stage-IntegratedSteelWorkbook.py','Run-IntegratedSteelWorkbook.ps1'):
        assert digest((root/filename).read_bytes())==prep['inputs'][filename]
    compile_proof=read(root/'CodeUpdate.json')
    compile_exit=read(root/'CompileClosure.json')
    assert compile_exit['State']=='Absent' and compile_proof['Compiled'] and not compile_proof['ProductionChanged']
    assert package['compiled_sha256']==compile_proof['WorkbookSHA256'] and compile_proof['ProductionSHA256']==package['source_sha256']
    assert set(compile_proof['Modules'])=={Path(n).stem for n in assembly['CLASSES']}
    steps=[json.loads(line) for line in (root/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert [x['phase'] for x in steps]==['CompileCleanSteelWorkbook','ExportCleanSteelWorkbook','RunCleanSteelHardShear']
    assert all(x['freeCommitGiB']>=6 and x['ramMiB']>=6500 and all(e['ProtectedUser'] for e in x['excel']) for x in steps)
    code=export(repo,root,assembly,helper,old_dump,package)
    check_native=run_path(str(root/'Verify-FullAB.py'))['native']
    new=check_native(root/'Native',package['candidate_sha256'])
    old=previous['native']
    for k in ('capacity_status','result_code','limit_lambda','ultimate_N_Nmm','assertions','probes'):
        assert new[k]==old[k], (k,old[k],new[k])
    assert isclose(old['lower_lambda'],new['lower_lambda'],abs_tol=1e-8,rel_tol=0.)
    assert max(abs(x-y) for x,y in zip(old['direct_N_Nmm'],new['direct_N_Nmm'],strict=True))<.01
    curve_reader=run_path(str(root/'ReadWorkbookCurve.py'))['read_curve']
    if capture_saved: capture(root,curve_reader)
    entries=curve_reader(root/SAVED)
    provenance=read(root/'Native/SavedResultsProvenance.json')
    assert all(entries[k]==provenance[k] for k in ('worksheet','worksheet_sha256','named_anchor'))
    old_entries=previous['curve']['entries']
    assert len(old_entries)==len(entries['entries'])==136
    difference=max(abs(float(a[-1])-float(b[-1])) for a,b in zip(entries['entries'],old_entries,strict=True))
    assert all(a[:-1]==b[:-1] for a,b in zip(entries['entries'],old_entries,strict=True))
    assert difference<1e-8, difference
    return {'code':code,'candidate_sha256':package['candidate_sha256'],'unchanged_ooxml_parts':121,
            'native':new,'saved_results':provenance,'accepted_curve_states':68,
            'maximum_curve_difference':difference,'physical_limit_certified':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,default=HERE)
    p.add_argument('--capture',action='store_true')
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    proof=verify(args.repo,args.root,args.capture)
    args.out.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode('utf-8'))
    print('CLEAN STEEL HARDSHEAR VERIFIED',proof['native']['assertions'],proof['accepted_curve_states'])
