"""Sensitivity of unconfined stress bound to lateral strain from Kagermanov-Ceresa eq. 13."""
import csv
from hashlib import sha256
import json
from pathlib import Path
import sys
import numpy as np
from zipfile import ZipFile

here = Path(__file__).resolve().parent

target = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else here / "TBU3LateralTensionSensitivity.json"
manifest = json.loads((here / "InputManifest.json").read_text("utf-8"))
paths = {}
def open_rows(relative):
    with ZipFile(here / "RawInputs.zip") as raw:
        content = raw.read(relative)
    actual_hash = sha256(content).hexdigest().upper()
    assert actual_hash == manifest["input_sha256"][relative]["sha256"]
    paths[relative] = actual_hash
    yield from csv.reader(content.decode("cp1251").splitlines(),delimiter=";")

ages = sorted({48,77,98,152})
geometry = {int(row[1]): row[2] for row in open_rows(
    "TBU3PublishedFieldCheckpoint/Native2x6/TBU3_Trace.csv") if row[0]=="TBU3_QUADRATURE"}
maxima = []
beam_fc = 34.8
peak_one_axis = .0045

def tensor(components, factor):
    xx, yy, zz, xy, xz, yz = map(float, components)
    return np.array(((xx,xy*factor,xz*factor),
                     (xy*factor,yy,yz*factor),
                     (xz*factor,yz*factor,zz)))

def reduction(e):
    return min(1.,1./(.8+.34*e/peak_one_axis))

for relative in ("TBU3PublishedAfter20/Native/TBU3After20Material.csv",
                 "TBU3PublishedTail/Native/TBU3TailMaterial.csv"):
    by_age = {age: [] for age in ages}
    for raw in open_rows(relative):
        age=int(raw[1])
        if raw[0]!="POINT" or age not in by_age or geometry[int(raw[2])]!="Concrete":
            continue
        i=int(raw[2]); area=float(raw[5])
        eps=tensor(raw[15:21],.5)
        sigma=tensor(raw[9:15],1.)
        sig, orient=np.linalg.eigh(sigma)
        assert sig[0]<=sig[-1]
        lateral=np.linalg.eigvalsh(orient[:,1:].T@eps@orient[:,1:])
        minimum=max(0.,float(np.sum(lateral)))/2.
        maximum=float(np.sum(np.maximum(lateral,0.)))/2.
        no_softening=-float(sig[0])/beam_fc
        compressive_only=max(0.,no_softening)
        by_age[age].append(dict(point=i, area=area, stresses_MPa=sig.tolist(),
             strain_principal=np.linalg.eigvalsh(eps).tolist(),
             orthogonal_strain_bounds=[minimum,maximum],
             beta_sigma_bounds=[reduction(maximum),reduction(minimum)],
             utilization_without_confinement_or_lateral_softening=compressive_only,
             utilization_without_confinement_bounds=[compressive_only/reduction(minimum),
                                                     compressive_only/reduction(maximum)]))
    for age, points in by_age.items():
        if not points:
            continue
        assert len(points)==96
        points_no_confinement = [p for p in points if p["stresses_MPa"][1] >= 0. and
                                                       p["stresses_MPa"][0] < 0.]
        a = sum(p["area"] for p in points)
        consistent_excess=[p for p in points if p["utilization_without_confinement_bounds"][0]>1.]
        maxima.append(dict(field=age,
                           compressive_strain_hotspot=min(points,key=lambda p:p["strain_principal"][0]),
                           matched_most_compressive_point=max(points,key=lambda p:p["utilization_without_confinement_or_lateral_softening"]),
                           highest_unconfined_utilization=max(points,key=lambda p:p["utilization_without_confinement_bounds"][0]),
                           count_unconfined=len(points_no_confinement),
                           highest_actual_unconfined_utilization=max(points_no_confinement,
                                 key=lambda p:p["utilization_without_confinement_bounds"][0],default=None),
                           area_fraction_definitely_exceeds_unconfined_bound=sum(p["area"] for p in consistent_excess)/a,
                           area_fraction_excess_and_no_lateral_compressive_stress=sum(p["area"] for p in consistent_excess
                                                                                      if p in points_no_confinement)/a))
assert [m["field"] for m in maxima] == [48,77,77,98,152]
assert abs(maxima[1]["highest_unconfined_utilization"]["utilization_without_confinement_bounds"][0]
           -maxima[2]["highest_unconfined_utilization"]["utilization_without_confinement_bounds"][0])<1e-9
del maxima[2]
primary = manifest["primaries"]["Kagermanov-Ceresa-2018.pdf"]
result = dict(reference="Kagermanov-Ceresa (2018), Eq. (13), https://doi.org/10.1155/2018/8596970",
  purpose="Explore stress cap sensitivity on unchanged NDM fields, without reproducing fixed crack axes or the source orthotropic constitutive model.",
  method="In compression follow each minimum Cauchy stress eigenvector. The lower and upper mean of the two positive lateral normal strains over all orthogonal directions derive from the projected strain tensor trace and positive eigenvalues. Apply Eq. (13) with epsilon0=.0045 and cap beta_sigma at 1; use no lateral compressive confinement in this sensitivity measure.",
  fields=maxima, inputs_sha256=paths, primary=primary, fc_MPa=beam_fc, epsilon0=peak_one_axis)
target.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n","utf-8")
print(sha256(target.read_bytes()).hexdigest().upper())
for s in maxima:
 print(s["field"], *(s[key] for key in ("count_unconfined","area_fraction_definitely_exceeds_unconfined_bound","area_fraction_excess_and_no_lateral_compressive_stress")),
       s["highest_unconfined_utilization"]["utilization_without_confinement_bounds"], s["highest_unconfined_utilization"]["stresses_MPa"],
       None if s["highest_actual_unconfined_utilization"] is None else s["highest_actual_unconfined_utilization"]["utilization_without_confinement_bounds"])

