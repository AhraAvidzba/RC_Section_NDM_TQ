"""Recompute concrete envelope events from archived NDM point histories."""
from collections import defaultdict
from hashlib import sha256
from math import fsum
from pathlib import Path
import json
import sys
from pathlib import PurePosixPath
import numpy as np
from zipfile import ZipFile

here = Path(__file__).resolve().parent

out = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else here / "ConcreteLimitChecks.json"
archives = PurePosixPath(".")
inputs = {}

def rows(path, coding="cp1251"):
    key = path.as_posix()
    with ZipFile(here / "RawInputs.zip") as raw:
        payload = raw.read(key)
    actual_hash = sha256(payload).hexdigest().upper()
    assert actual_hash == manifest["input_sha256"][key]["sha256"]
    inputs[key] = actual_hash
    return (line.split(";") for line in payload.decode(coding).splitlines())

def calibration(fc, fc0, modulus, peak_total_strain, gc, loc=125.):
    peak_damage = .423 * (1. - fc / (modulus * peak_total_strain))
    peak_plastic = peak_total_strain - fc / ((1. - peak_damage) * modulus)
    energy = gc / loc
    peak_ratio = .5 * (fc + fc0) * peak_plastic / energy
    return dict(fc_MPa=fc, fc0_MPa=fc0, E_MPa=modulus,
                peak_total_compressive_strain=peak_total_strain,
                Gc_N_per_mm=gc, localization_length_mm=loc,
                plastic_peak_strain=peak_plastic, kc_peak=peak_ratio)

def principal(components, shear):
    xx, yy, zz, xy, xz, yz = components
    a = [[xx, shear * xy, shear * xz],
         [shear * xy, yy, shear * yz],
         [shear * xz, shear * yz, zz]]
    return np.linalg.eigvalsh(a).tolist()

def point(i, area, kt, kc, stress, strain=None):
    result = dict(point=i, area=area, kt=kt, kc=kc, sigma=principal(stress, 1.))
    if strain is not None:
        result["epsilon"] = principal(strain, .5)
    return result

def summarize(meta, points, material):
    area = fsum(p["area"] for p in points)
    kc_peak = material["kc_peak"]
    maximum = max(points, key=lambda p: p["kc"])
    worst_stress = min(points, key=lambda p: p["sigma"][0])
    result = dict(**meta, n_concrete=len(points), area=area, max_kc=maximum["kc"],
                  max_kt=max(p["kt"] for p in points), peak_ratio=kc_peak, energy_hotspot=maximum,
                  strongest_compression=worst_stress,
                  max_compressive_to_fc=-worst_stress["sigma"][0] / material["fc_MPa"],
                  postpeak_area_fraction=fsum(p["area"] for p in points if p["kc"] > kc_peak)/area,
                  energy90_area_fraction=fsum(p["area"] for p in points if p["kc"] >= .90)/area)
    if "epsilon" in maximum:
        worst_strain = min(points, key=lambda p: p["epsilon"][0])
        result["worst_compressive_strain"] = worst_strain
        result["max_concurrent_tensile_strain"] = max(p["epsilon"][-1] for p in points)
        result["point_strain_peak_area_fraction"] = fsum(
            p["area"] for p in points if -p["epsilon"][0] >= material["peak_total_compressive_strain"]
        ) / area
    return result

def tbu3():
    material = calibration(34.8, .6*34.8, 30000., .0045, 80.)
    geometry = {}
    meta = {}
    points = defaultdict(dict)
    for row in rows(archives / "TBU3PublishedFieldCheckpoint/Native2x6/TBU3_Trace.csv"):
        if row[0] == "TBU3_QUADRATURE":
            geometry[int(row[1])] = row[2]
    assert len(geometry) == 176 and sum(f == "Concrete" for f in geometry.values()) == 96
    for folder, native_file in (("TBU3PublishedAfter20", "TBU3After20Material.csv"),
                                ("TBU3PublishedTail", "TBU3TailMaterial.csv")):
        for row in rows(archives / folder / "Native" / native_file):
            field_index = int(row[1])
            if row[0] == "STATE":
                lam, twist = map(float, row[2:4])
                previous = meta.get(field_index, (lam, twist))
                assert abs(previous[0]-lam) < 1e-10 and abs(previous[1]-twist) < 1e-10
                meta[field_index] = (lam, twist)
                continue
            if len(row) != 21:
                assert field_index >= 153
                continue
            assert row[0] == "POINT"
            i = int(row[2])
            _, _, a, kt, kc, _, *tensor = map(float, row[3:])
            if field_index <= 152:
                previous = points[field_index].get(i, (a, kt, kc, *tensor))
                assert max(abs(x-y) for x,y in zip(previous,(a, kt, kc, *tensor),strict=True)) < 1e-8
                points[field_index][i] = (a, kt, kc, *tensor)
    assert set(points) == set(range(48, 153))
    states = []
    for f, all_points in sorted(points.items()):
        assert set(all_points) == set(geometry)
        bulk = [point(i, a, kt, kc, tensor[:6], tensor[6:])
                for i, (a, kt, kc, *tensor) in all_points.items() if geometry[i] == "Concrete"]
        lam, twist = meta[f]
        states.append(summarize(dict(field=f, lambda_value=lam, twist_mrad_m=1000.*twist,
                                     T_kNm=10.35*lam, Mx_kNm=-29.6-14.87*lam), bulk, material))
    assert abs(states[0]["area"] - 116432.) < 1e-7
    computed_peak = max(states, key=lambda state: state["lambda_value"])
    assert computed_peak["field"] == 98
    targets = [(key, thresholds) for key, thresholds in (
        ("max_kc", [material["kc_peak"], .2, .3, .35, .5, .8, .9]),
        ("postpeak_area_fraction", [.05, .25, .5, .6, .65, .7, .9]),
        ("point_strain_peak_area_fraction", [.01, .05, .25, .5]))]
    crossing = {}
    for key, thresholds in targets:
        crossing[key] = {}
        for threshold in thresholds:
            first = next((s for s in states if s[key] >= threshold), None)
            crossing[key][str(threshold)] = None if first is None else {
                k:first[k] for k in ("field","lambda_value","twist_mrad_m","T_kNm",key)
            }
    intervals = {}
    for key, _ in targets:
        previous_max = max(state[key] for state in states if state["field"] < computed_peak["field"])
        peak_value = computed_peak[key]
        intervals[key] = dict(max_before=previous_max, at_peak=peak_value,
                              width=max(0.,peak_value-previous_max))
    return dict(material=material, stored_fields=states, first_crossings=crossing,
                thresholds_detecting_first_at_computed_peak=intervals)

def a2():
    fc, ft = 47.3, 3.5
    gt = .073 * fc**.18
    material = calibration(fc, .6*fc, 36100., .002, (fc/ft)**2*gt)
    archive = archives / "A2YieldAnchors20261116"
    points = defaultdict(list)
    steel = defaultdict(list)
    meta = {}
    for row in rows(archive / "Native/A2YieldAnchors.csv"):
        if row[0] == "ANCHOR":
            i = int(row[1])
            target, step, twist, left, right, residual, _, _, _, torque, *_ = map(float, row[2:])
            assert abs(torque / 1e6 - target) < .001
            assert residual < .000005
            meta[i] = dict(anchor=i, T_kNm=torque/1e6, T_target_kNm=target,
                           twist_mrad_m=1000.*twist, error_MPa=residual)
        if row[0] == "POINT":
            i, point_i, family = int(row[1]), int(row[2]), row[3]
            _, _, a, rod_stress, _, kt, kc, *tensor = map(float, row[4:])
            if family == "Concrete":
                points[i].append(point(point_i, a, kt, kc, tensor[:6]))
            else:
                steel[i].append((family, abs(rod_stress)))
    states = []
    for i in sorted(meta):
        s = summarize(meta[i], points[i], material)
        s["max_hoop_stress_MPa"] = max(sig for fam,sig in steel[i] if fam=="Hoop")
        s["max_longitudinal_stress_MPa"] = max(sig for fam,sig in steel[i] if fam!="Hoop")
        states.append(s)
    assert all(s["n_concrete"] == 20 and abs(s["area"]-216004.) < 1e-7 for s in states)
    return dict(material=material, exact_load_states=states, fy_hoop_MPa=696., fy_longitudinal_MPa=672.)

def hardshear():
    material = calibration(30., 16., 30000., .002, 80.)
    snaps = (archives / "ProductionYieldRecovery/PostPeakWideStepRefinement/Native/Native.txt")
    coarse_indexes = {}
    points = {}
    for row in rows(snaps, "utf-8-sig"):
        if row[0] == "GRH":
            coarse_indexes[int(row[1])] = int(row[3])
        if row[0] == "GRS" and row[2] == "1":
            key = (int(row[1]), int(row[3]))
            nums = tuple(map(float, row[4:]))
            assert len(nums) == 1219
            data = np.asarray(nums[:27*43]).reshape(43,27)
            points[key] = [point(i+1, 864., p[25], p[26], p[6:12], p[:6])
                           for i,p in enumerate(data[:25])]
    assert coarse_indexes == {1:18,2:56}
    assert set(points) == {(frame, station) for frame in (1,2) for station in (-1,0,1)}
    field_data = defaultdict(list)
    ab = archives / "HardShearDilationAB20261116"
    for row in rows(ab / "PrescribedStrains.csv"):
        f,i,lam = int(row[0]), int(row[1]), float(row[2])
        assert i == len(field_data[f]) + 1
        field_data[f].append((lam,list(map(float,row[3:9]))))
    stresses = defaultdict(list)
    for row in rows(ab / "Native/DilationAB.csv"):
        if row[0] == "DIL_POINT":
            f,i = map(int,row[1:3])
            assert i == len(stresses[f]) + 1
            stresses[f].append(list(map(float,row[3:9])))
    for slot in (1,2):
        f = coarse_indexes[slot]
        for station,offset in ((0,0),(1,43),(-1,86)):
            for i,p in enumerate(points[slot,station]):
                # Shape/stress pairing also authenticates order and engineering shear.
                sig=principal(stresses[f][offset+i],1.)
                eps=principal(field_data[f][offset+i][1],.5)
                for name, checks in (("sigma",sig),("epsilon",eps)):
                    assert max(abs(a-b) for a,b in zip(p[name],checks,strict=True)) < 2e-11
    diagnostic_summary=[]
    for f in (8,9,10,18,56):
        sigs = [principal(s,1.) for s in stresses[f][:25]]
        eps = [principal(e,.5) for _,e in field_data[f][:25]]
        diagnostic_summary.append(dict(frame=f, lambda_value=field_data[f][0][0],
          max_abs_compressive_MPa=-min(s[0] for s in sigs), max_point_compressive_strain=-min(e[0] for e in eps),
          max_point_tensile_strain=max(e[-1] for e in eps)))
    full_diagnostics = [summarize(dict(frame=coarse_indexes[f], station=station,
                            lambda_value=field_data[coarse_indexes[f]][0][0]), data, material)
                        for (f,station),data in sorted(points.items())]
    assert all(s["max_kc"] < material["kc_peak"] for s in full_diagnostics)
    assert all(s["max_point_compressive_strain"] < material["peak_total_compressive_strain"] for s in diagnostic_summary)
    return dict(material=material, stock_peak_stress_strain=diagnostic_summary,
                native_energies=full_diagnostics)

manifest = json.loads((here / "InputManifest.json").read_text("utf-8"))
proof = dict(TBU3=tbu3(), A2=a2(), HardShear=hardshear())
assert set(inputs) == set(manifest["input_sha256"])
proof["files_SHA256"]=inputs
out.write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False)+"\n", "utf-8")
print(sha256(out.read_bytes()).hexdigest().upper())

