"""Replay the original native continuation verifier and audit each fallback stop."""
import argparse
import csv
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
REPORT = "AD22C868815404D79FCA5D888B46D11F77F923FF3FFA6C5C645F635EEACABFF4"
RAW = "244065BBF02C27B45EBBBE7D0CD7BAAB6CBB2C0F9483607D9F337C07BD6BD5EF"
DEPENDENCIES = {
    "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
    "MVT2StockBranchArcNative20261116.zip": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def local(root, name):
    return root / (root / name).resolve().relative_to(root.resolve())


def diagnostics(raw):
    assert digest(raw) == RAW
    all_attempts = {}
    current = None
    for marker, *row in csv.reader(raw.decode("cp1251").splitlines(), delimiter=";"):
        if marker == "B_EXT_TRY":
            label, *_ = row
            assert current is None and label not in all_attempts
            current = {"nominal": row[4], "label": label}
            all_attempts[label] = current
        elif marker in {"B_FB_START", "B_FB_OPT", "B_FB_TRIAL", "B_FB_RADIUS", "B_FB_STOP"}:
            assert current is not None, marker
            current.setdefault(marker, []).append(row)
        elif marker == "B_EXT_DECISION":
            label, result = row
            assert current is not None and label == current["label"]
            current["decision"] = result
            current = None
    assert current is None and list(all_attempts) == [f"Attempt{i}" for i in range(1,7)]
    output = []
    for index, entry in enumerate(all_attempts.values(),1):
        row = {"attempt": index, "nominal_arc_step": entry["nominal"], "decision": entry["decision"]}
        if index == 5:
            assert len(entry) == 3 and entry["decision"] == "Accepted"
            row["corrector"] = "ordinary Newton"
        else:
            [[raw_weak, raw_norm, raw_tau, _]] = entry["B_FB_START"]
            norm, tau = Decimal(raw_norm), Decimal(raw_tau)
            assert raw_weak == "53" and norm > 0 and tau > 0
            row.update({"fallback_start_row": int(raw_weak), "fallback_start_over_original_tolerance": str(norm/tau)})
            if index == 1:
                assert entry["decision"] == "Accepted" and "B_FB_STOP" not in entry
                trials = [tuple(map(Decimal, trial)) for trial in entry["B_FB_TRIAL"]]
                assert len(trials) == 2 and [t[0] for t in trials] == [1,2]
                assert trials[0][1] == norm and trials[0][2] == trials[1][1] and trials[1][2] < trials[1][4]
                row["true_norm_over_tolerance"] = [str(trial[2]/trial[4]) for trial in trials]
                row["force_norm_over_tolerance"] = [str(trial[3]/trial[4]) for trial in trials]
            elif index in (2,3,4):
                assert entry["decision"] == "Newton" and entry["B_FB_STOP"] == [["1", "Optimizer"]]
                [[first, solved, solves]] = entry["B_FB_OPT"]
                assert first == "1" and solved == "0" and int(solves) in (49,51,53) and "B_FB_RADIUS" not in entry and "B_FB_TRIAL" not in entry
                row.update({"fallback_stop": "optimizer", "linear_solves": int(solves)})
            else:
                assert index == 6 and entry["decision"] == "Newton" and entry["B_FB_STOP"] == [["1", "Radius"]]
                assert entry["B_FB_OPT"] == [["1", "1", "84"]] and "B_FB_TRIAL" not in entry
                [[first, radius, cumulative, cap]] = entry["B_FB_RADIUS"]
                assert first == "1" and Decimal(radius) == Decimal(cumulative) > Decimal(cap) > 0
                row.update({"fallback_stop": "local tensor radius before nonlinear reevaluation", "linear_solves": 84,
                            "physical_tensor_radius": radius, "physical_tensor_radius_cap": cap,
                            "physical_tensor_radius_over_cap": str(Decimal(radius)/Decimal(cap))})
        output.append(row)
    return {"native_trace_sha256": RAW, "fallback_attempts": output, "claimed_physical_limit": False}


def materialize(work, manifest, archive_dir):
    assert manifest["book"] == {"path": BOOK, "sha256": WORKBOOK}
    assert manifest["archives"] == DEPENDENCIES
    for basename, expected in DEPENDENCIES.items():
        assert digest((archive_dir / basename).read_bytes()) == expected
    for name, record in manifest["input_paths"].items():
        filename = record.get("archive")
        member = record.get("member", name)
        if filename:
            with ZipFile(archive_dir / filename) as source:
                raw = source.read(member)
        else:
            raw = local(HERE,member).read_bytes()
        assert digest(raw) == record["sha256"], name
        target = local(work,name)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)


def run(work, archive_dir):
    source_path = work / "Verify-MVT2ShearControlled.py"
    source = source_path.read_text(encoding="utf-8")
    old = '    assert all(v.digest(HERE / name) == sha for name,sha in prep["inputs"].items())'
    assert source.count(old) == 1 and not (work / BOOK).exists()
    new = (f'    assert prep["inputs"]["{BOOK}"] == prep["book_sha256"] == "{WORKBOOK}"\n'
           f'    assert all(v.digest(HERE / name) == sha for name,sha in prep["inputs"].items() if name != "{BOOK}")')
    scope = {"__file__": str(source_path), "__name__": "archived_native"}
    sys.path.insert(0,str(work))
    exec(compile(source.replace(old,new), str(source_path), "exec"), scope)
    report = scope["verify"](*scope["prepare"]())
    proof = (work / "VerificationContinue.json").read_bytes()
    assert digest(proof) == REPORT and (json.dumps(report,indent=2)+"\n").encode() == proof
    assert report["accepted_points"] == 2 and report["terminal"] == "MinimumStep" and report["private_history_restored_H24"]
    assert report["last_accepted_Qy_kN"] == 18.5785550208131
    audit = diagnostics((work / "NativeContinue/MVT2.csv").read_bytes())
    assert [entry["decision"] for entry in audit["fallback_attempts"]] == [row["decision"] for row in report["attempts"]]
    expected_audit = (work / "FallbackStops.json").read_bytes()
    assert (json.dumps(audit, indent=2) + "\n").encode() == expected_audit
    stage = work / "Stage.py"
    stage_scope = {"__file__": str(stage), "__name__": "archived_stage"}
    exec(compile(stage.read_text(encoding="utf-8"), str(stage), "exec"), stage_scope)
    with ZipFile(archive_dir / next(iter(DEPENDENCIES))) as parent:
        predecessor_macro = parent.read(stage_scope["MACRO"])
        assert digest(parent.read("Preparation.json")) == stage_scope["PARENT_PREP"]
        assert stage_scope["overlay_macro"](predecessor_macro) == (work / stage_scope["MACRO"]).read_bytes()
    return report, digest(expected_audit)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives", type=Path, required=True)
    args = parser.parse_args()
    manifests = json.loads((HERE / "PortableManifest.json").read_bytes())
    with TemporaryDirectory() as temp:
        work = Path(temp)
        materialize(work, manifests, args.archives)
        report, fallback_hash = run(work, args.archives)
    print("MVT2 NATIVE CONTINUATION", REPORT, "FALLBACK DIAGNOSTICS", fallback_hash)
    print("ACCEPTED", report["accepted_points"], "LAST Qy kN", report["last_accepted_Qy_kN"], "STOP", report["terminal"], "H24 EXACTLY RESTORED")


if __name__ == "__main__":
    main()
