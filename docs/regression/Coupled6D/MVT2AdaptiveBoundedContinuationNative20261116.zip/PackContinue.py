"""Package native continuation evidence with deduplicated tracked inputs."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import ReplayContinuePortable as replay


HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[1] / "docs/regression/Coupled6D"
RESULT = HERE / "MVT2AdaptiveBoundedContinuationNative20261116.zip"


def build():
    prep = json.loads((HERE / "Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK] == prep["book_sha256"] == replay.WORKBOOK
    existing = {}
    for basename, checksum in replay.DEPENDENCIES.items():
        path = REGRESSION / basename
        assert replay.digest(path.read_bytes()) == checksum
        with ZipFile(path) as prior:
            for member in prior.namelist():
                if not member.casefold().endswith(".xlsm"):
                    existing.setdefault(replay.digest(prior.read(member)),(basename,member))
    audit = replay.diagnostics((HERE / "NativeContinue/MVT2.csv").read_bytes())
    (HERE / "FallbackStops.json").write_bytes((json.dumps(audit, indent=2) + "\n").encode())
    paths, blobs = {}, {}
    additional = ("Preparation.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json",
                  "VerificationContinue.json", "FallbackStops.json", "ReplayContinuePortable.py", "PackContinue.py", "PortableREADME.txt")
    native = tuple(f"NativeContinue/{item.name}" for item in (HERE / "NativeContinue").iterdir() if item.is_file())
    for name in sorted(set(prep["inputs"]) | set(additional) | set(native)):
        if name == replay.BOOK:
            continue
        raw = (HERE / name).read_bytes()
        digest = replay.digest(raw)
        if name in prep["inputs"]:
            assert digest == prep["inputs"][name], name
        anchor = existing.get(digest) if name in prep["inputs"] else None
        if anchor:
            archive, member = anchor
            paths[name] = {"archive": archive, "member": member, "sha256": digest}
        else:
            paths[name] = {"sha256": digest}
            blobs[name] = raw
    manifest = {"book": {"path": replay.BOOK, "sha256": replay.WORKBOOK}, "archives": replay.DEPENDENCIES, "input_paths": paths}
    blobs["PortableManifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    assert all(not name.casefold().endswith(".xlsm") for name in blobs)
    with ZipFile(RESULT,"w",compresslevel=9) as output:
        for name,raw in sorted(blobs.items()):
            member = ZipInfo(name)
            member.compress_type = ZIP_DEFLATED
            output.writestr(member,raw)


def main():
    build()
    with TemporaryDirectory(dir=HERE / "Temp") as temp, ZipFile(RESULT) as archive:
        assert archive.testzip() is None
        archive.extractall(temp)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayContinuePortable.py","--archives",str(REGRESSION)),cwd=temp,check=True)
    print(RESULT.name,RESULT.stat().st_size,replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
