Native adaptive continuation of MVT2 path B after accepted H24.

Extract this archive. Run the offline replay without Excel or any workbook.

    python -B -X utf8 ReplayContinuePortable.py --archives <repository>/docs/regression/Coupled6D

The manifest pins two tracked archives and the compiled and source workbook identities.
The original native verifier is included unchanged. The detached wrapper substitutes only
the reference workbook byte read with its pinned receipt. It verifies the remaining seal,
regenerates the native VBA driver from the pinned predecessor, rebuilds all equilibrium and
history checks, and reproduces VerificationContinue.json byte for byte. FallbackStops.json
independently groups the underlying native optimizer and tensor-radius diagnostics by attempt.

Two steps were accepted at the original tolerance in the private history. The first reproduces
the archived fallback state. The second uses ordinary Newton after reducing the arc step.
The final accepted Qy is 18.5785550208131 kN, with fixed T=10.51 kN m and Mx=.60 Qy.
The next attempt stopped before evaluating the predicted correction because it lay 34.95 times
outside its local tensor radius. The continuation ended when its nominal step fell below the
minimum prescribed for this fixture. All accepted histories are replayed and original H24 is
restored exactly. No private continuation state is installed in the workbook.
