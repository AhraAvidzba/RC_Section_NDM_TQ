"""Seal the adaptive continuation overlay on the exact verified mvgf source."""
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "mvgf"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MACRO = "tests/modTestCoupledExperiment.bas"
RUNNER = "Run-MVT2ShearControlled.ps1"
PARENT_PREP = "A8643B8C9BC88F04EBF9BC80D15DCACC3B4535FF9871D2D206A9EF3CD86CF96A"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def utf8(raw):
    return raw.decode("utf-8-sig").replace("\r\n", "\n")


def overlay_macro(raw):
    source = utf8(raw)
    source = once(source, 'If phase <> "Compare" Then Err.Raise 5, , "Неизвестная фаза сравнения MVT2."',
                  'If phase <> "Continue" Then Err.Raise 5, , "Неизвестная фаза продолжения MVT2."')
    source = once(source, '    ProbeWangArcComparisonTest output, folder, history, solver, operators, materials, responses, base, qBase, qTrial',
                  '    ContinueWangArcTest output, folder, history, solver, operators, materials, responses, base, qBase, factors(23)')
    start = source.index("Private Sub ProbeWangArcComparisonTest(")
    end = source.index("Private Sub CaptureWangArcHistoryTest(")
    marker = "' -------------------- ДЛЯ ТЕСТОВ --------------------\n"
    source = source[:source.rfind(marker, 0, start)] + source[source.rfind(marker, 0, end):]
    source = source.rstrip() + "\n\n" + (HERE / "ContinueTest.txt").read_text(encoding="utf-8")
    assert max(map(len, source.splitlines())) < 1023
    return source.replace("\n", "\r\n").encode("utf-8")


def main():
    prior_prep = (BASE / "Preparation.json").read_bytes()
    assert digest(prior_prep) == PARENT_PREP
    prior = json.loads(prior_prep)
    inputs = {}
    inherited_code = {}
    for name, old_hash in prior["inputs"].items():
        raw = (BASE / name).read_bytes()
        assert digest(raw) == old_hash, name
        if name in ("Stage.py", "README.txt", "Verify-MVT2ShearControlled.py"):
            continue
        if name == MACRO:
            raw = overlay_macro(raw)
        elif name == RUNNER:
            raw = once(utf8(raw), "[ValidateSet('Compare')][string]$Phase='Compare'", "[ValidateSet('Continue')][string]$Phase='Continue'").encode("utf-8")
        elif name.startswith("src/"):
            inherited_code[name] = old_hash
        inputs[name] = put(name, raw)
    assert inputs[BOOK] == prior['book_sha256']
    assert put("docs/regression/Diagnostic.xlsm", (HERE / BOOK).read_bytes()) == prior['book_sha256']
    for folder in ("NativeContinue", "Temp"):
        (HERE / folder).mkdir(exist_ok=True)
    for name in ("Stage.py", "ContinueTest.txt", "README.txt", "Verify-MVT2ShearControlled.py"):
        inputs[name] = digest((HERE / name).read_bytes())
    result = {"inputs": inputs, "book_sha256": prior["book_sha256"], "replay_sha256": prior["replay_sha256"],
              "watchdog_seconds": 245, "parent_preparation_sha256": PARENT_PREP, "unchanged_fallback_source": inherited_code}
    print(put("Preparation.json", (json.dumps(result, indent=2) + "\n").encode("utf-8")))


if __name__ == "__main__":
    main()
