Private adaptive MVT2 B continuation from exact accepted H24.

    python -B -X utf8 tmp/mvext/Stage.py
    python -B -X utf8 tmp/mvext/Verify-MVT2ShearControlled.py --inputs-only

After assigning the isolated Office slot and resource preflight, launch the bounded native harness once.

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mvext/Run-MVT2ShearControlled.ps1

First uses the same physical arc normal and H23->H24 secant predictor at 1/64 as mvgf.
Later normals use the latest two verified histories, all 135 station strains in the same
area-weighted tensor metric, and the fixed original Qy metric. Gauge multipliers are excluded.
The independent checker rebuilds this from station geometry and verifies the complete sequence.
T is fixed at 10.51 kN m; Mx [kN m] = .60 Qy [kN]. N, My and Qx are zero.
Neither a decrease in Qy nor an increase establishes capacity by itself. The augmented
steps use positive signed physical projection, 3x nominal metric radius and original tolerance.
All 56 weak equations, six signed resultants and four gauges are read back independently.
The proven matched-side fallback and original constitutive source overlays are copied byte-for-byte.
No station ID directs recovery. Accepted candidate fields and full stations are written before the
commit from the exact previous history. Every committed field immediately survives full replay;
failed steps are discarded with exact field/stress/energy checks. The sequence ends restored to H24.
Halve if rejected, grow 1.5x after sufficiently small actual step, max 2x first step. Stop on
six accepted points, ten attempted points, nominal size below first/8, or 175 s before a new attempt.
Watchdog is 245 s. If fewer than six points are accepted, read the terminal reason and diagnostics;
this private fixture is never a physical limit claim or production publication.
