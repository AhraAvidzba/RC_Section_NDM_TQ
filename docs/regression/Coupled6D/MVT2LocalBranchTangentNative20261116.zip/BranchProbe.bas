
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет касательные только на трёх проблемных станциях и двух
' контрольных станциях точки 23. Состояние H24 используется только для чтения.
Private Sub ReadWangBranchActionTest(ByVal output As Integer, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef origin() As Double, ByRef ray() As Double)
    Dim item As Variant, point As Long, side As Long
    For Each item In Array(Array(2, -1), Array(2, 1), Array(22, 1), Array(23, -1), Array(23, 1))
        point = CLng(item(0)): side = CLng(item(1))
        ReadWangBranchStationTest output, operators, materials(side), responses(side), origin, ray, point, side
    Next item
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает исходные столбцы и ветви всех возмущений для независимого
' пересчёта направленного действия dσz на архивном луче.
Private Sub ReadWangBranchStationTest(ByVal output As Integer, ByVal operators As CCoupledElasticState, _
        ByVal material As CCoupledConcreteResponse, ByVal response As ICoupledPointResponse, _
        ByRef origin() As Double, ByRef ray() As Double, ByVal point As Long, ByVal side As Long)
    Dim center(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim rayCenter(1 To 6) As Double, raySlope(1 To 6) As Double, direction(1 To 6) As Double
    operators.PointStrain point, origin, center: operators.AxialGradientAtPoint point, origin, slope
    operators.PointStrain point, ray, rayCenter: operators.AxialGradientAtPoint point, ray, raySlope
    Dim i As Long, prefix As String, row As String
    prefix = CStr(point) & ";" & CStr(side)
    For i = 1 To 6
        station(i) = center(i) + side * 0.001 * slope(i)
        direction(i) = rayCenter(i) + side * 0.001 * raySlope(i)
    Next i
    Dim baseStress As Double, baseF As Double, basePlastic As Boolean, basePrincipal As Long, baseSteps As Long
    If Not ReadWangBranchStressTest(material, response, point, station, baseStress, baseF, basePlastic, basePrincipal, baseSteps) Then _
        Err.Raise 5, , "Не восстановлена ветвь опытной станции MVT2."
    row = "B_BC_BASE;" & prefix & ";" & ExperimentNumberTest(baseStress) & ";" & ExperimentNumberTest(baseF) & ";" & _
        CStr(Abs(CLng(basePlastic))) & ";" & CStr(basePrincipal) & ";" & CStr(baseSteps)
    For i = 1 To 6: row = row & ";" & ExperimentNumberTest(direction(i)): Next i
    Print #output, row
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, matched(1 To 6) As Double
    Dim code As ESolverFailureCode, mode As Variant, method As String, value As Double
    For Each mode In Array(ctmFull, ctmFullBranchConsistent)
        method = "Stock": If CLng(mode) = ctmFullBranchConsistent Then method = "Consistent"
        code = response.EvaluatePoint(point, station, stress, tangent, CLng(mode), False)
        row = "B_BC_MODE;" & prefix & ";" & method & ";" & CStr(Abs(CLng(code = sfcNone)))
        If code = sfcNone Then
            value = 0#
            For i = 1 To 6
                row = row & ";" & ExperimentNumberTest(tangent(3, i))
                value = value + tangent(3, i) * direction(i)
            Next i
            row = row & ";" & ExperimentNumberTest(value)
        End If
        Print #output, row
    Next mode
    Dim h As Double, bump As Long, divisor As Variant, leftStress As Double, rightStress As Double, trialStress As Double
    Dim trialF As Double, plastic As Boolean, principal As Long, substeps As Long, ok As Boolean, agrees As Boolean
    Dim leftMatched As Boolean, rightMatched As Boolean, complete As Boolean
    complete = True
    For Each divisor In Array(1&, 4&)
        For i = 1 To 6
            h = 0.000000002 * (1# + Abs(station(i))) / CLng(divisor)
            leftMatched = False: rightMatched = False
            For bump = -1 To 1 Step 2
                trialStress = 0#: trialF = 0#: plastic = False: principal = 0: substeps = 0
                station(i) = center(i) + side * 0.001 * slope(i) + bump * h
                ok = ReadWangBranchStressTest(material, response, point, station, trialStress, trialF, plastic, principal, substeps)
                agrees = (ok And plastic = basePlastic And principal = basePrincipal And substeps = baseSteps And Sgn(trialF) = Sgn(baseF))
                If bump < 0 Then
                    leftStress = trialStress: leftMatched = agrees
                Else
                    rightStress = trialStress: rightMatched = agrees
                End If
                Print #output, "B_BC_AXIS;" & prefix & ";" & CStr(i) & ";" & CStr(divisor) & ";" & CStr(bump) & ";" & _
                    ExperimentNumberTest(h) & ";" & CStr(Abs(CLng(ok))) & ";" & CStr(Abs(CLng(agrees))) & ";" & _
                    ExperimentNumberTest(trialStress) & ";" & ExperimentNumberTest(trialF) & ";" & _
                    CStr(Abs(CLng(plastic))) & ";" & CStr(principal) & ";" & CStr(substeps)
            Next bump
            station(i) = center(i) + side * 0.001 * slope(i)
            If CLng(divisor) = 4 Then
                If leftMatched And rightMatched Then
                    matched(i) = (rightStress - leftStress) / (2# * h)
                ElseIf rightMatched Then
                    matched(i) = (rightStress - baseStress) / h
                ElseIf leftMatched Then
                    matched(i) = (baseStress - leftStress) / h
                Else
                    complete = False
                End If
            End If
        Next i
    Next divisor
    row = "B_BC_MODE;" & prefix & ";MatchedQuarter;" & CStr(Abs(CLng(complete)))
    If complete Then
        value = 0#
        For i = 1 To 6
            row = row & ";" & ExperimentNumberTest(matched(i))
            value = value + matched(i) * direction(i)
        Next i
        row = row & ";" & ExperimentNumberTest(value)
    End If
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает напряжение и признаки ветви от той же принятой истории, не
' записывая материальную пробу. Локальная ошибка оставляет колонку пустой.
Private Function ReadWangBranchStressTest(ByVal material As CCoupledConcreteResponse, ByVal response As ICoupledPointResponse, _
        ByVal point As Long, ByRef station() As Double, ByRef axialStress As Double, ByRef valueF As Double, _
        ByRef plastic As Boolean, ByRef principal As Long, ByRef substeps As Long) As Boolean
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, unused(1 To 6) As Double
    If response.EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then Exit Function
    If Not material.TryReadTrialYield(point, station, valueF, unused, needGradient:=False) Then Exit Function
    If Not material.TryReadConcreteBranch(point, station, plastic, principal, substeps) Then Exit Function
    axialStress = stress(3)
    ReadWangBranchStressTest = True
End Function
