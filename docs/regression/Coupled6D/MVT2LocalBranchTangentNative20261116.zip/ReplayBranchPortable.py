"""Verify native local branch actions with previously archived shared evidence."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import tempfile
from zipfile import ZipFile


here = Path(__file__).resolve().parent
book_sha = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
verification_sha = "7CF0F089F3A9BF97279E43F764BCD84ABC428DA3E4AF4413F18E7FD2D1CE3DBD"
dependencies = {
    "jet": "6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33",
    "shift": "688E1CB09A1FC7E4A4976FEA214BB4E0A9DADA0FE042BBBB6AFA55D1EA9B0979",
    "ray": "E6FCD67D16C2637EF7992AB67CE6DB71AA7E63EE41F15CD33E8CB198A586304D",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for tag in dependencies:
        parser.add_argument(tag, type=Path)
    args = parser.parse_args()
    for tag, sha in dependencies.items():
        assert digest(getattr(args,tag).read_bytes()) == sha, tag
    manifest = json.loads((here / "PortableManifest.json").read_bytes())
    with (tempfile.TemporaryDirectory() as folder, ZipFile(args.jet) as jet,
          ZipFile(args.shift) as shift, ZipFile(args.ray) as ray):
        work = Path(folder)
        archives = {"jet":jet,"shift":shift,"ray":ray}
        for name, row in manifest.items():
            tag = row.get("archive")
            raw = (here/name).read_bytes() if tag is None else archives[tag].read(row["member"])
            assert digest(raw) == row["sha256"], name
            target = work/name
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(raw)
        verifier = work/"Verify-MVT2ShearControlled.py"
        src = verifier.read_text(encoding="utf-8")
        guard = '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]'
        assert src.count(guard) == 1
        src = src.replace(guard,f'    assert prep["book_sha256"] == "{book_sha}"')
        scope = {"__name__":"verified_native_replay","__file__":str(verifier)}
        sys.path.insert(0,str(work))
        try:
            exec(compile(src,str(verifier),"exec"),scope)
            valid = (json.dumps(scope["verify"](*scope["prepare"]()),indent=2)+"\n").encode()
        finally:
            sys.path.pop(0)
        assert digest(valid) == verification_sha and valid == (work/"VerificationBranch.json").read_bytes()
        print("CANONICAL LOCAL MATCHED ACTION",verification_sha)


if __name__ == "__main__":
    main()
