"""Replay current-book stress, axis probes, and signed local tangent actions."""
import argparse
from decimal import Decimal
from math import fsum
import json
from pathlib import Path

import VerifyBase as v


here = Path(__file__).resolve().parent
native = here / "NativeHalf"
selected = ((2,-1),(2,1),(22,1),(23,-1),(23,1))
methods = ("Stock","Consistent","MatchedQuarter")


def half_wire_unit(token):
    val = Decimal(token)
    return float(Decimal("0.5").scaleb(val.copy_abs().adjusted()-14)) if val else 0.


def prepare():
    prep = v.read(here / "Preparation.json")
    assert all(v.digest(here / name) == expected for name, expected in prep["inputs"].items())
    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]
    assert prep["workbook_revision"] == "c9e7268" and prep["control_book_sha256"] != prep["book_sha256"]
    old = v.read(here / "SameRayVerification.json")
    assert old["raw_sha256"] == v.digest(here / "SameRayNative.csv") and old["history_restored"]
    prior, old_stations = v.verified_states(v.read_native(here / "SameRayNative.csv"))
    shift, _ = v.verified_states(v.read_native(here / "ShiftNative.csv"))
    assert prior["RayZero"]["field"] == shift["ShiftStop"]["field"]
    ray = tuple(map(float,(here/"RayDirection.csv").read_text(encoding="ascii").strip().split(";")))
    assert len(ray) == 61
    return prep, old, prior, old_stations, ray


def verify(prep, old, prior, old_stations, ray):
    build = v.read(here / "docs/regression/CodeUpdate.json")
    compiler = v.read(here / "CompileClosure.json")
    owner = v.read(native / "MVT2.txt.Ownership.json")
    watch = v.read(native / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(native / "RunReceipt.json")
    final = watch["Closure"]["FinalState"]
    assert build["Compiled"] and build["Modules"] == ["modTestCoupledExperiment"] and not build["ProductionChanged"]
    assert build["ProductionSHA256"] == prep["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == build["WorkbookSHA256"]
    assert watch["Passed"] and watch["ChildExitCode"] == receipt["native_exit"] == 0 and watch["ChildHasExited"]
    assert final["State"] == "Absent" and final["PID"] == owner["PID"] and final["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    path = native / "MVT2.csv"
    tags = v.read_native(path)
    assert tags["B_FRESH_PHASE"] == [["Half"]]
    states, stations = v.verified_states(tags)
    assert set(states) == {"Base24","Restored24","RayZero","Ray-25","Ray25"}
    history = v.vec(tags,"MVT2_CONTROL_FIELD")
    csv_history = (here/"Replay.csv").read_text(encoding="ascii").splitlines()[1:]
    assert len(csv_history) == len(history) == 24
    for i, line in enumerate(csv_history,1):
        assert v.peak(v.diff(tuple(map(float,line.split(";")[9:])),history[f"Replay{i}"])) < 1e-15
    assert states["Base24"] == states["Restored24"] and stations["Base24"] == stations["Restored24"]
    accepted = {name:tuple(vals) for name,*vals in tags["B_ARC_HISTORY"]}
    assert set(accepted) == {"RayBefore","Ray-25","Ray25","RayFinal"}
    assert all(vals == accepted["RayBefore"] and len(vals) == 1080 for vals in accepted.values())
    # New-book anchors must agree with measured old-book states, in original units.
    drifts = {}
    for name in states:
        a, b = states[name], prior[name]
        assert a["field"] == b["field"] and a["q"] == b["q"] and a["geometry"] == b["geometry"]
        difference_r = v.peak(v.diff(a["r"],b["r"]))
        difference_s = max(v.peak(v.diff(stations[name][key][13:19],old_stations[name][key][13:19]))
                           for key in stations[name])
        assert difference_r < 4e-10 and difference_s < 4e-9
        assert all(stations[name][key][3:6] == old_stations[name][key][3:6] and
                   abs(stations[name][key][6] - old_stations[name][key][6]) < 4e-9 for key in stations[name])
        drifts[name] = {"all62_max_abs_error_MPa":difference_r, "station_stress_max_abs_error_MPa":difference_s}
    z = stations["RayZero"]
    minus, plus = stations["Ray-25"], stations["Ray25"]
    assert all(z[k][3:6] == minus[k][3:6] == plus[k][3:6] and
               z[k][6]*minus[k][6] > 0 and z[k][6]*plus[k][6] > 0 for k in z if k[0] <= 25)
    base_rows = {(int(p),int(s)):tuple(map(float,data)) for p,s,*data in tags["B_BC_BASE"]}
    assert tuple(base_rows) == selected
    axis_data = {}
    for p,s,axis,div,sign,h,ok,matched,stress,val,plastic,principal,substeps in tags["B_BC_AXIS"]:
        key = int(p),int(s)
        sample = int(axis),int(div),int(sign)
        assert key in base_rows and sample not in axis_data.setdefault(key,{})
        axis_data[key][sample] = (float(h),bool(int(ok)),bool(int(matched)),stress,float(val),int(plastic),int(principal),int(substeps))
    mode_data = {}
    for p,s,name,ok,*tail in tags["B_BC_MODE"]:
        key = int(p),int(s)
        assert name in methods and name not in mode_data.setdefault(key,{})
        assert len(tail) == (7 if int(ok) else 0)
        mode_data[key][name] = tuple(map(float,tail)) if tail else None
    assert set(mode_data) == set(axis_data) == set(selected)
    base_raw_sigma = {(int(row[0]),int(row[1])):row[2] for row in tags["B_BC_BASE"]}
    resolved = {}
    for key, base in base_rows.items():
        sigma, f0, plast0, principal0, steps0, *direction = base
        point, side = key
        a = z[key]
        assert abs(sigma-a[15]) < 4e-12 and abs(f0-a[6]) < 4e-10 and (plast0,principal0,steps0) == a[3:6]
        d = v.strain_at(ray[:60],v.operators(*a[:2]),side)
        assert v.peak(v.diff(d,direction)) < 4e-16
        weight = side*a[2]/(v.AREA*.002)
        left = -4*weight*(minus[key][15]-a[15])
        right = 4*weight*(plus[key][15]-a[15])
        actual = .5*(left+right)
        old_exact = old["original_material_directional_measurements"]["0.25"]["all_station_values"][str(point)][str(side)]
        assert abs(actual-old_exact["centered_MPa"]) < 2e-9
        probes = axis_data[key]
        assert len(probes) == 24
        cross = {}
        for divisor in (1,4):
            violations = []
            for i in range(1,7):
                for sign in (-1,1):
                    h,ok,matched,stress,ftrial,plast,principal,steps = probes[i,divisor,sign]
                    assert abs(h-(2e-9*(1+abs(a[6+i]))/divisor)) < 2e-22
                    assert matched == (ok and (plast,principal,steps) == (plast0,principal0,steps0) and ftrial*f0 > 0)
                    if not matched:
                        violations.append({"component":i,"side":sign,"evaluated":ok,"F":ftrial,
                                           "plastic":plast,"principal":principal,"return_substeps":steps})
            cross[divisor] = violations
        candidates = {}
        for name, values in mode_data[key].items():
            if values is None:
                candidates[name] = None
                continue
            action = weight*v.dot(values[:6],d)
            assert abs(action-values[6]*weight) < 4e-12
            if name == "Stock":
                assert abs(action-old_exact["stock_MPa"]) < 2e-9
            if name == "MatchedQuarter":
                accumulated_wire = 0.
                estimates = []
                for i in range(1,7):
                    lp, rp = (probes[i,4,sign] for sign in (-1,1))
                    h = lp[0]
                    assert h == rp[0] and (lp[2] or rp[2])
                    base_token = base_raw_sigma[key]
                    terms = (rp[3],lp[3],2*h) if lp[2] and rp[2] else ((rp[3],base_token,h) if rp[2] else (base_token,lp[3],h))
                    p0,p1,denom = terms
                    estimates.append((float(p0)-float(p1))/denom)
                    accumulated_wire += abs(d[i-1]*weight) * (half_wire_unit(p0)+half_wire_unit(p1))/denom
                assert abs(action-weight*v.dot(estimates,d)) <= accumulated_wire+3e-13
            candidates[name] = {"action_MPa":action,"actual_minus_mode_MPa":actual-action,"stress_row_z":values[:6]}
        resolved[f"{point}/{side}"] = {"base_F":f0,"plastic":bool(plast0),"principal":principal0,"substeps":steps0,
                                        "signed_actual_sides_MPa":[left,right],"centered_action_MPa":actual,
                                        "unmatched_axes_by_divisor":cross,"tangent_actions":candidates}
    base = states["RayZero"]
    original = fsum(old["original_stock_center_slope_MPa"])
    true = (states["Ray25"]["r"][52]-states["Ray-25"]["r"][52])/.5
    assert abs(true-old["original_material_directional_measurements"]["0.25"]["central_row53_action_MPa"])<2e-9
    decision = {}
    for method in ("Consistent","MatchedQuarter"):
        failure_cells = [resolved[id]["tangent_actions"] for id in ("2/-1","2/1","22/1")]
        control_cells = [resolved[id]["tangent_actions"] for id in ("23/-1","23/1")]
        if any(cell[method] is None for cell in (*failure_cells,*control_cells)):
            decision[method] = {"tested_replacement_matches":False,"available_for_all":False}
            continue
        forecast = original+fsum(cell[method]["action_MPa"]-cell["Stock"]["action_MPa"] for cell in failure_cells)
        worst_sum = fsum(abs(cell[method]["actual_minus_mode_MPa"]) for cell in failure_cells)
        control_sum = fsum(abs(cell[method]["actual_minus_mode_MPa"]) for cell in control_cells)
        decision[method] = {"tested_replacement_matches":forecast*true>0 and abs(forecast-true)<=base["tol_MPa"] and
                             worst_sum<=base["tol_MPa"] and control_sum<=base["tol_MPa"],
                            "available_for_all":True,"signed_replacement_forecast_MPa":forecast,
                            "sum_abs_local_errors_MPa":worst_sum,"control_sum_abs_errors_MPa":control_sum}
    return {"source_workbook_sha256":prep["book_sha256"],"old_mechanical_reference_sha256":prep["control_book_sha256"],
            "native_trace_sha256":v.digest(path),"H24_hash":prep["replay_sha256"],"exact_accepted_restore":True,
            "current_vs_old":drifts,"true_centered_row53_action_MPa":true,"stock_row53_action_MPa":original,
            "original_equilibrium_tolerance_MPa":base["tol_MPa"],"local_station_modes":resolved,"same_ray_replacement_screen":decision,
            "history_or_equilibrium_claimed":False,"native_owner_closed":final,"native_wall_s":receipt["wall_seconds"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--phase",choices=["Half"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(here/"Preparation.json"))
    else:
        assert args.phase == "Half"
        report = here/"VerificationBranch.json"
        report.write_bytes((json.dumps(verify(*frozen),indent=2)+"\n").encode())
        print(report,v.digest(report))
