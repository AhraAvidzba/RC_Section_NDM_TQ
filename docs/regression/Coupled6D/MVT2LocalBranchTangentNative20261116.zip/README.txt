Native local tangent branch contrast at the MVT2 B stop

Run after extracting this ZIP, with the three exact tracked archives.

    python -B -X utf8 ReplayBranchPortable.py PATH/MVT2HalfJointJetNative20261116.zip PATH/MVT2SafeguardedTangentShift20261116.zip PATH/MVT2SameRayDerivativeNative20261116.zip

Shared frozen dependencies are resolved by SHA256 through the manifest. This
receipt omits Excel binaries. The verifier checks the compiler and owned native
process records that pin the actual 2ACF source and executable fixture.

By direct native measurement, the current 2ACF workbook (c9e7268) exactly
reproduces the old 8EAD H24 and associated stop and quarter-ray fields, all
62 weak/force residual coordinates, and all station stresses.

The old stock axial action for weak equation 53 was +7.2578389156e-5 MPa;
the original material on the same branch yielded -9.3877607509e-6 MPa.
Replacing only the three diagnosed side actions projects -9.3902115978e-6
for branch-consistent tangents and -9.3877146592e-6 for the h/4 matched stencil.
Stock coordinate perturbations cross yield at five samples of these sides.
The same h/4 branch and point 23 control checks account for the sign difference.
The native stage evaluates derivatives and preserves H24. A full Newton
correction and a physical capacity were outside this scalar comparison.
