"""ДЛЯ ТЕСТОВ. Сверяет фактические компоненты книги с 36 компонентами связанного ядра, включая новый общий адаптер."""

from argparse import ArgumentParser
from pathlib import Path


def TestAudit(repo, root, output):
    """Сохраняет все проверки точных импортов; расширение области требует ровно трёх заданных рабочих компонентов."""
    here = Path(__file__).resolve().parent
    source = here / 'Audit-TestPrivateCoupledBook.py'
    code = source.read_text('utf-8-sig')
    old = '        assert len(coupled) == 33'
    assert code.count(old) == 1
    code = code.replace(old, '''        assert len(coupled) == 36
        assert {'ICoupledScalarConstraint', 'CCoupledConstraintEquations', 'CCoupledMaterialConstraint'} <= set(coupled)''', 1)
    namespace = {'__name__': 'generic_constraint_book_audit', '__file__': str(source)}
    exec(compile(code, str(source), 'exec'), namespace)
    namespace['TestAudit'](repo, root, output)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAudit(args.repo.resolve(), args.root.resolve(), args.out.resolve())
