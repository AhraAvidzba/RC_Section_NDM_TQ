"""ДЛЯ ТЕСТОВ. Проверяет общий адаптер в последовательной истории и два шага исходного решателя без адаптера."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestAnalyze(root, output):
    """Разделяет строгие материальные координаты и штатный допуск обычного продолжения; проверяет общий экспорт всей истории."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Analyze-TestYieldSequence.py'))['TestAnalyze'](root, output)
    result = json.loads(output.read_bytes())
    rows = list(csv.reader((root / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    accepted = [row for row in rows if row[0] == 'BRIDGE_ACCEPTED']
    end, = [row for row in rows if row[0] == 'BRIDGE_END']
    assert len(accepted) == int(end[1]) and [int(row[1]) for row in accepted] == list(range(len(accepted)))
    preparation = json.loads((root / 'Preparation.json').read_bytes())
    limit = preparation['directed_scope']['bridge_step_limit']
    assert int(end[3]) == limit and len(accepted) <= limit
    proof, bridges = None, {}
    if accepted:
        validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
        proof, fields = validate(root, 'NewtonLine.Bridge')
        offset = preparation['directed_scope']['initial_accepted_prefix'] + result['accepted_steps']
        assert len(fields) == offset + len(accepted)
        for index, record in enumerate(accepted):
            observed, = [row for row in rows if row[:2] == ['BRIDGE_RESULT', str(index)]]
            native, = [row for row in rows if row[:2] == ['BRIDGE_NATIVE', str(index)]]
            final, = [row for row in rows if row[:2] == ['BRIDGE_FINAL', str(index)]]
            assert observed[2] == 'True' and native[2:5] == ['True', 'True', 'True']
            assert float(record[2]) == float(observed[4]) == float(final[2])
            np.testing.assert_allclose(fields[offset + index], np.asarray([float(value) for value in final[3:]]),
                                       rtol=1e-14, atol=1e-300)
            bridges[str(index)] = {'lambda': float(record[2]), 'seconds': float(observed[3]),
                'native_original_tolerance_verified': True, 'field_Double_unchanged': True,
                'native_forward_direction': True, 'residual_max_MPa': float(observed[-1]),
                'newton_iterations': int(observed[5]), 'full_evaluations': int(observed[6]),
                'hybrid_steps': int(observed[7]), 'accepted_revision': int(record[3])}
            if preparation['directed_scope'].get('lambda_uncertainty_recorded_for_ordinary_bridge'):
                uncertainty, = [row for row in rows if row[:2] == ['BRIDGE_UNCERTAINTY', str(index)]]
                assert uncertainty[2] == 'True'
                bound, gain = map(float, uncertainty[3:5])
                assert bound >= 0 and gain > 0
                previous_lambda = (list(bridges.values())[-2]['lambda'] if index else
                                   result['cases'][str(result['accepted_steps'] - 1)]['final_lambda'])
                assert abs(float(record[2]) - previous_lambda - gain) <= 3e-14
                bridges[str(index)].update(lambda_uncertainty=bound, lambda_gain=gain,
                    gain_exceeds_adjoint_uncertainty=gain > bound,
                    nds_acceptance_is_not_capacity_or_stock_search_acceptance=True)
                if preparation['directed_scope'].get('resolved_ordinary_steps_required'):
                    gate, = [row for row in rows if row[:2] == ['BRIDGE_RESOLUTION', str(index)]]
                    assert gate[2] == 'True' and gain > bound and gain > float(gate[3])
                    bridges[str(index)]['stock_lambda_resolution'] = float(gate[3])
    assert all(after['accepted_revision'] == before['accepted_revision'] + 1 for before, after in zip(list(bridges.values()), list(bridges.values())[1:]))
    result.update(ordinary_bridge={'accepted_steps': len(accepted), 'requested_steps': limit,
        'full_requested_bridge_completed': len(accepted) == limit, 'steps': bridges,
        'independent_all_sequence_equations': proof, 'uses_original_tolerances_not_strict_1e_10': True},
        generic_projection_equations_used_for_first_four_steps=True,
        ordinary_equation_interface_unchanged=True, physical_capacity_certified=False,
        installed_workbook_changed=False)
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('GENERIC CONSTRAINT SEQUENCE AND ORDINARY CONTINUATION BRIDGE VERIFIED', len(accepted), 'CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
