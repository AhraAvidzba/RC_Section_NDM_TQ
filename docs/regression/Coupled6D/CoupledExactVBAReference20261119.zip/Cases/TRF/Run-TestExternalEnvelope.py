"""ДЛЯ ТЕСТОВ. SciPy решает фактическую систему VBA через отдельный собственный Excel; рабочая книга не изменяется."""

from argparse import ArgumentParser
import ctypes
from ctypes import wintypes
import gc
from hashlib import sha256
import json
import os
from pathlib import Path
from runpy import run_path
import shutil
import site
import struct
import threading
import time
import traceback
from uuid import uuid4

site.addsitedir('D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython')
import numpy as np
import scipy
from scipy.optimize import least_squares
import pythoncom
import win32com.client
import win32com.client.dynamic
import win32process


def TestWrite(path,value):
    """Сохраняет UTF-8 и точные окончания строк независимо от платформенного текстового преобразования."""
    path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+'\n').encode('utf-8'))


def TestProcess(pid,expected=None,terminate=False):
    """Читает точное FILETIME; завершение допустимо только при совпадении времени собственного процесса."""
    api=ctypes.WinDLL('kernel32',use_last_error=True)
    api.OpenProcess.argtypes=(wintypes.DWORD,wintypes.BOOL,wintypes.DWORD);api.OpenProcess.restype=wintypes.HANDLE
    api.GetProcessTimes.argtypes=(wintypes.HANDLE,ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME))
    api.GetProcessTimes.restype=wintypes.BOOL
    api.CloseHandle.argtypes=(wintypes.HANDLE,);api.CloseHandle.restype=wintypes.BOOL
    api.TerminateProcess.argtypes=(wintypes.HANDLE,wintypes.UINT);api.TerminateProcess.restype=wintypes.BOOL
    handle=api.OpenProcess(0x1000 | (1 if terminate else 0),False,pid)
    if not handle:
        error=ctypes.get_last_error()
        return {'state':'Absent' if error==87 else 'Unreadable','error':error}
    try:
        created,exit_time,kernel,user=(wintypes.FILETIME() for _ in range(4))
        if not api.GetProcessTimes(handle,ctypes.byref(created),ctypes.byref(exit_time),ctypes.byref(kernel),ctypes.byref(user)):
            raise ctypes.WinError(ctypes.get_last_error())
        value=(created.dwHighDateTime<<32)|created.dwLowDateTime
        if expected is not None and value!=expected:return {'state':'Replaced','filetime':value}
        if terminate:
            if expected is None:raise ValueError('Explicit owned creation time required')
            if not api.TerminateProcess(handle,124):raise ctypes.WinError(ctypes.get_last_error())
        return {'state':'TerminationRequested' if terminate else 'Alive','filetime':value,'start_ticks_utc':value+504911232000000000}
    finally:api.CloseHandle(handle)


def TestRun(root,method,seed_kind,fraction,step,max_nfev,timeout):
    """Каждый отклик и его аргумент сохраняются как Double; успех оптимизатора отделён от исходного равновесия и приёмки ветви."""
    prep=json.loads((root/'Preparation.json').read_bytes())
    for name,digest in prep['inputs'].items():assert sha256((root/name).read_bytes()).hexdigest().upper()==digest,name
    compilation=json.loads((root/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
    assert compilation['Compiled'] and not compilation['ProductionChanged']
    assert json.loads((root/'CompileClosure.json').read_bytes())['State']=='Absent'
    source=root/'docs/regression/Diagnostic.xlsm'; source_hash=sha256(source.read_bytes()).hexdigest().upper()
    assert source_hash==compilation['WorkbookSHA256']
    output=root/'Native/ExternalResult.json';assert not output.exists()
    fixture=root/'Temp'/('External_'+uuid4().hex)/'Diagnostic.xlsm';fixture.parent.mkdir();shutil.copyfile(source,fixture)
    before=set(win32process.EnumProcesses());owner={}; excel=None;book=None;trace=None;timer=None;done=threading.Event()
    trace_lock=threading.Lock();started=time.perf_counter();result={'method':method,'seed_kind':seed_kind,
        'relative_energy_increment':fraction,'difference_relative_step':step,'maximum_base_evaluations':max_nfev,
        'scipy_version':scipy.__version__,'numpy_version':np.__version__,'source_sha256':source_hash,
        'fixture':str(fixture),'physical_capacity_certified':False,'working_external_dependency_added':False,
        'candidate_diagnostic_replay_not_branch_admission':True}
    def TestTimeout():
        """Watchdog сохраняет доказательства и касается лишь нового Excel с точным временем запуска."""
        if done.is_set():return
        with trace_lock:
            if trace is not None and not trace.closed:trace.flush()
        state=TestProcess(owner['pid'],owner['filetime'],True) if owner.get('exclusive_private_fixture') and not owner.get('protected_workbooks_detected') else {'state':'NoExclusiveOwnedExcel'}
        TestWrite(root/'Native/ExternalTimeout.json',dict(owner=owner,after=state,timeout_seconds=timeout,physical_failure=False))
        os._exit(124)
    pythoncom.CoInitialize()
    try:
        excel=win32com.client.dynamic.Dispatch(pythoncom.CoCreateInstance('Excel.Application',None,pythoncom.CLSCTX_LOCAL_SERVER,pythoncom.IID_IDispatch))
        _,pid=win32process.GetWindowThreadProcessId(int(excel.Hwnd))
        if pid in before:raise RuntimeError('Excel COM did not create a new owned process; existing application protected')
        state=TestProcess(pid);assert state['state']=='Alive'
        owner.update(pid=pid,filetime=state['filetime'],start_ticks_utc=str(state['start_ticks_utc']))
        TestWrite(root/'Native/ExternalOwnership.json',owner)
        timer=threading.Timer(timeout,TestTimeout);timer.daemon=True;timer.start()
        excel.Visible=False;excel.DisplayAlerts=False;excel.EnableEvents=False;excel.ScreenUpdating=False;excel.AutomationSecurity=1
        if excel.Workbooks.Count:raise RuntimeError('Unexpected workbooks in newly created Excel')
        book=excel.Workbooks.Open(str(fixture),0,False)
        if bool(book.ReadOnly):raise RuntimeError('Private fixture opened read-only')
        if Path(str(book.FullName)).resolve()!=fixture.resolve():raise RuntimeError('Opened fixture differs')
        owner['exclusive_private_fixture']=True;TestWrite(root/'Native/ExternalOwnership.json',owner)
        prefix="'"+str(book.Name).replace("'","''")+"'!modTestCoupledElasticState."
        boot=excel.Run(prefix+'TestStartExternalEnvelope',str(root));result['bootstrap']=str(boot)
        if 'RUNTIME ERROR:' in str(boot):raise RuntimeError(str(boot))
        meta=np.asarray(excel.Run(prefix+'TestOpenExternalEnvelope',float(fraction),int(seed_kind)),float).ravel()
        assert meta.shape==(11,);n=int(meta[0]);result['context_metadata']=meta.tolist()
        scales=np.asarray(excel.Run(prefix+'TestExternalEnvelopeScales'),float).ravel();assert scales.shape==(n,)
        result['unknown_scales']=scales.tolist()
        trace=(root/'Native/ExternalFTrace.bin').open('xb');trace.write(b'NDMEXTFTRACE0001'+struct.pack('<i',n));trace.flush()
        calls=0;jacobians=0
        def TestResidual(x):
            """Делегирует вычисление исходному VBA, без штрафных или искусственных значений невязки."""
            nonlocal calls
            x=np.asarray(x,float);assert x.shape==(n,) and np.all(np.isfinite(x))
            argument=win32com.client.VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_R8,tuple(float(z) for z in x))
            value=np.asarray(excel.Run(prefix+'TestEvaluateExternalEnvelope',argument),float).ravel()
            assert value.shape==(n,) and np.all(np.isfinite(value))
            calls+=1
            with trace_lock:
                trace.write(struct.pack('<Qd',calls,time.perf_counter()-started));trace.write(x.astype('<f8').tobytes());trace.write(value.astype('<f8').tobytes());trace.flush()
            if calls%100==0:print('EXACT_VBA_F_CALLS',calls,'MAX_MPa',float(np.max(np.abs(value))),flush=True)
            return value
        def TestJacobian(x):
            """Повторяет центральный шаг нормированных координат VBA; SciPy меняет только алгоритм решения."""
            nonlocal jacobians
            jacobians+=1;matrix=np.empty((n,n))
            for i in range(n):
                delta=step*(1+abs(x[i]));a=x.copy();b=x.copy();a[i]+=delta;b[i]-=delta
                matrix[:,i]=(TestResidual(a)-TestResidual(b))/(2*delta)
            return matrix
        initial=np.zeros(n); first=TestResidual(initial); second=TestResidual(initial)
        assert np.array_equal(first,second),'Repeated immutable VBA evaluation differs'
        solver_started=time.perf_counter()
        answer=least_squares(TestResidual,initial,jac=TestJacobian,method=method,x_scale='jac',
            ftol=1e-13,xtol=1e-13,gtol=1e-13,max_nfev=max_nfev,loss='linear',**({'tr_solver':'exact'} if method=='trf' else {}))
        final=TestResidual(answer.x);matrix=TestJacobian(answer.x)
        result.update(optimizer_success=bool(answer.success),optimizer_message=str(answer.message),base_evaluations=int(answer.nfev),
            optimizer_jacobians=int(answer.njev),actual_jacobians=jacobians,actual_VBA_function_calls=calls,
            solver_seconds=time.perf_counter()-solver_started,coordinates=answer.x.tolist(),residual_MPa=final.tolist(),
            residual_max_MPa=float(np.max(np.abs(final))),jacobian=matrix.tolist(),repeat_immutable_response_bits_equal=True)
        argument=win32com.client.VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_R8,tuple(float(z) for z in answer.x))
        native=np.asarray(excel.Run(prefix+'TestFinishExternalEnvelope',argument),float).ravel()
        assert len(native)==12+n-1
        binary=native.astype('<f8').tobytes();(root/'Native/ExternalNativeResult.bin').write_bytes(binary)
        result['native_result_binary_sha256']=sha256(binary).hexdigest().upper()
        result['native_verification']=native[:12].tolist();result['field']=native[12:].tolist()
        read=run_path(str(root/'Check-TestActualReverseCapture.py'))['TestReadBinary'];data=read(root/'Input/Reverse1.bin')
        operators=run_path(str(root/'Check-TestHardHalfSteps.py'))['TestOperators']
        import csv
        with (root/'Native/EnvelopeEnergy.Accepted.csv').open(encoding='cp1251') as f:
            dims=next(r[1:] for r in csv.reader(f,delimiter=';') if r and r[0]=='DIM')
        dofs,physical,points,concrete=map(int,dims[:4]);half=float(dims[4])
        g,load,w,v,coordinates,axis,b,slope=operators(root/'Native/EnvelopeEnergy.Operators.csv',dofs,points)
        def TestTensor(field):return np.asarray([b@field+s*half*(slope@field) for s in (-1,0,1)])
        def TestSquare(a):return float(np.einsum('spc,spc,p,c->',a,a,coordinates[:,2],np.array((1,1,1,.5,.5,.5)))/(3*sum(coordinates[:,2])))
        old=np.sqrt(TestSquare(TestTensor(data['fields'][-1]-data['fields'][-2])))
        distance=np.sqrt(TestSquare(TestTensor(native[12:]-data['fields'][-1])))
        predicted=abs(meta[7])*old
        result['tensor_distance']=float(distance);result['predicted_tensor_distance']=float(predicted)
        local=bool(distance<=3*predicted and predicted>0)
        result['within_three_predicted_distances']=local
        verified=bool(native[0]==1 and native[1]==1 and native[2]==1 and native[3]<=1 and native[4]>0 and
            np.max(np.abs(final))<=native[10] and native[5]-meta[1]>2*native[10]/meta[4] and local)
        result['nds_verified_on_local_forward_energy_step']=verified
        try:
            weights=np.linalg.solve(matrix.T,np.eye(n)[:,-1]);condition=float(np.linalg.cond(matrix))
            result['jacobian_condition']=condition if np.isfinite(condition) else None
            result['jacobian_condition_nonfinite']=not bool(np.isfinite(condition))
            result['diagnostic_lambda_uncertainty']=float(abs(scales[-1])*max(native[10],np.max(np.abs(final)))*sum(abs(weights))) if condition<1e14 else None
        except np.linalg.LinAlgError:result['diagnostic_lambda_uncertainty']=None
        result['outcome']='VerifiedLocalNDS;NotCapacity' if verified else 'NoVerifiedLocalNDS;NotPhysicalFailure'
    except Exception as error:
        result.update(outcome='ExternalControlError;NotPhysicalFailure',error=str(error),traceback=traceback.format_exc())
    finally:
        result['elapsed_seconds']=time.perf_counter()-started
        if trace is not None:trace.close()
        if owner:
            if book is not None:
                try:
                    if Path(str(book.FullName)).resolve()!=fixture.resolve():raise RuntimeError('Owned fixture identity changed')
                    book.Close(False)
                except Exception as error:result['book_cleanup_error']=str(error)
                book=None
            if excel is not None:
                try:
                    if excel.Workbooks.Count:
                        owner['protected_workbooks_detected']=True
                        result['cleanup_protected_unknown_workbooks']=True
                    else:excel.Quit()
                except Exception as error:result['excel_quit_error']=str(error)
        excel=None;gc.collect();pythoncom.CoUninitialize()
        if owner:
            for _ in range(30):
                state=TestProcess(owner['pid'],owner['filetime'])
                if state['state']!='Alive':break
                time.sleep(.2)
            if state['state']=='Alive' and not owner.get('protected_workbooks_detected'):
                result['owned_empty_excel_cleanup_termination']=TestProcess(owner['pid'],owner['filetime'],True)
                time.sleep(.5);state=TestProcess(owner['pid'],owner['filetime'])
            result['owned_excel_final_state']=state
        result['source_unchanged']=sha256(source.read_bytes()).hexdigest().upper()==source_hash
        TestWrite(output,result);done.set()
        if timer is not None:timer.cancel()
    print('EXTERNAL EXACT VBA CONTROL:',result['outcome'],'calls=',result.get('actual_VBA_function_calls'),flush=True)
    return 1 if result['outcome'].startswith('ExternalControlError') or not result['source_unchanged'] or result.get('owned_excel_final_state',{}).get('state') not in ('Absent','Replaced') else 0


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--method',choices=('trf','lm'),default='trf')
    p.add_argument('--seed-kind',type=int,choices=(0,1),default=1);p.add_argument('--fraction',type=float,default=.000015625)
    p.add_argument('--step',type=float,default=1e-6);p.add_argument('--max-nfev',type=int,default=40);p.add_argument('--timeout',type=int,default=600)
    a=p.parse_args();raise SystemExit(TestRun(a.root.resolve(),a.method,a.seed_kind,a.fraction,a.step,a.max_nfev,a.timeout))
