"""ДЛЯ ТЕСТОВ. Повторяет точную последнюю точку внешнего решателя в новой собственной сессии Excel."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct


def TestStage(root, parent):
    """Сохраняет исходные Double координат и F; холодный повтор обязан дать побитовое совпадение."""
    here = Path(__file__).resolve().parent
    raw = (parent/'Native/ExternalFTrace.bin').read_bytes()
    assert raw[:16] == b'NDMEXTFTRACE0001'
    n, = struct.unpack_from('<i', raw, 16)
    stride = 16 + 16*n
    assert n == 61 and (len(raw)-20) % stride == 0
    count = (len(raw)-20)//stride
    position = 20+(count-2*n-1)*stride  # После конечного F записаны ровно 2*n запросов контрольного Якобиана.
    call, elapsed = struct.unpack_from('<Qd', raw, position)
    x = raw[position+16:position+16+8*n]
    f = raw[position+16+8*n:position+stride]
    base = struct.unpack('<'+str(n)+'d', x)
    for column in range(n):
        for side in range(2):
            offset = position+(1+2*column+side)*stride+16
            probe = struct.unpack_from('<'+str(n)+'d', raw, offset)
            assert [i for i in range(n) if probe[i] != base[i]] == [column]
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    prep = json.loads((root/'Preparation.json').read_bytes())
    for name, content in {
        'Input/InitialCoordinates.bin': struct.pack('<i', n)+x,
        'Input/InitialResidual.bin': f,
        'Run-TestExternalEnvelope.py': (here/'Run-TestExternalEnvelope.py').read_bytes(),
        Path(__file__).name: Path(__file__).read_bytes(),
    }.items():
        (root/name).write_bytes(content)
        prep['inputs'][name] = sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='ExternalExactVBAColdRestart',
        initial_coordinates_origin=str(parent/'Native/ExternalFTrace.bin'),
        initial_coordinates_origin_call=call,
        original_parent_optimizer_status_not_available=True,
        cold_identical_prior_residual_bits_equal_required=True,
        new_algorithm='LM', physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    (root/'ExternalRestartOrigin.json').write_bytes((json.dumps(dict(
        parent=str(parent), trace_sha256=sha256(raw).hexdigest().upper(),
        parent_total_exact_calls=count, initial_call=call,
        initial_elapsed_seconds=elapsed, exact_double_copied=True,
        final_jacobian_stencil_layout_verified=True,
        cold_history_and_context_residual_check_required=True), indent=2)+'\n').encode())
    print('EXACT RESTART READY; prior call', call, 'of', count)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.parent.resolve())
