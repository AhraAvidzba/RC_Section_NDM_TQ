"""ДЛЯ ТЕСТОВ. Независимо проверяет нелинейное исключение координаты и все записанные шаги Newton."""

from argparse import ArgumentParser
import csv
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestAnalyze(root, output):
    """Прочитанная координата проверяется по независимой поверхности; остальные компоненты должны быть исходным аффинным полем."""
    here = Path(__file__).resolve().parent
    base = here / 'Analyze-TestNewtonLine.py'
    scope = run_path(str(base))
    read = scope['TestRead']
    rows = list(csv.reader((root / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    preparation = json.loads((root / 'Preparation.json').read_bytes())
    case_ids = scope['TestCaseIds'](preparation, rows)
    maps, pivots, proofs = {}, {}, {}
    for case in case_ids:
        data = read(root / f'Native/NewtonLine.C{case}I0.bin')
        target = data['target']
        path = root / f'Native/NewtonLine.Projection{case}.bin'
        raw = path.read_bytes()
        assert raw[:16] == b'NDMQPROJECT00001' and (len(raw) - 20) % (63 * 8) == 0
        pivot, = struct.unpack_from('<i', raw, 16)
        assert 1 <= pivot <= 60
        pivots[case] = pivot - 1
        saved = np.frombuffer(raw, '<f8', offset=20).reshape(-1, 63)
        assert np.all(np.isfinite(saved)) and len(saved) > 0
        event = scope['TestYieldEventFunction'](root, rows, case)
        record = {}
        maximum_independent, maximum_native = 0., 0.
        for row in saved:
            coordinate, projected, native_q = row[:61], row[61], row[62]
            field = data['seed'] + data['scales'][:60] * coordinate[:60]
            field[pivot - 1] = projected
            independent_q = event(field)
            assert abs(native_q - target) <= 2e-12 and abs(independent_q - native_q) <= 1e-9
            maximum_independent = max(maximum_independent, abs(independent_q - target))
            maximum_native = max(maximum_native, abs(native_q - target))
            key = coordinate.tobytes()
            if key in record:
                assert record[key] == projected
            record[key] = float(projected)
        maps[case] = record
        proofs[str(case)] = {'pivot_1_based': pivot, 'projection_records': len(saved), 'event_target_MPa': target,
            'unique_raw_coordinates': len(record), 'trace_sha256': sha256(raw).hexdigest().upper(),
            'maximum_native_event_residual_MPa': maximum_native,
            'maximum_independent_event_residual_MPa': maximum_independent,
            'independent_geometry_CSV_arithmetic_bound_MPa': 1e-9}

    def TestProjectedField(folder, case, coordinate, seed, scales):
        """Восстанавливает точное физическое поле только по сохранённому отображению, без повторного VBA-вызова."""
        key = coordinate.tobytes()
        assert key in maps[case], (case, 'missing projected coordinate')
        field = seed + scales[:60] * coordinate[:60]
        field[pivots[case]] = maps[case][key]
        return field

    for case in case_ids:
        for file in (root / 'Native').glob(f'NewtonLine.C{case}I*.bin'):
            data = read(file)
            pivot = pivots[case]
            assert data['residual'][-1] == data['x'][pivot]
            for column in range(61):
                for sign, name in ((1, 'plus'), (-1, 'minus')):
                    x = data['x'].copy()
                    x[column] += sign * data['sizes'][column]
                    TestProjectedField(root, case, x, data['seed'], data['scales'])
                    assert data[name][-1, column] == x[pivot]
            assert np.all(data['jacobian'][:60, pivot] == 0.)
            assert data['jacobian'][-1, pivot] == 1.
            for trial in data['trials']:
                if trial['evaluated']:
                    TestProjectedField(root, case, trial['x'], data['seed'], data['scales'])
                    assert trial['residual'][-1] == trial['x'][pivot]
    code = base.read_text('utf-8-sig')
    old = "            expected_field = previous['seed'] + previous['scales'][:60] * coordinate[:60]"
    assert code.count(old) == 1
    code = code.replace(old, "            expected_field = TestProjectedField(root, case, coordinate, previous['seed'], previous['scales'])", 1)
    namespace = {'__file__': str(base), '__name__': 'yield_projection_analysis', 'TestProjectedField': TestProjectedField}
    exec(compile(code, str(base), 'exec'), namespace)
    namespace['TestAnalyze'](root, output)
    result = json.loads(output.read_bytes())
    result.update(nonlinear_elimination=proofs, dummy_equation_exact=True,
        all_finite_difference_and_line_coordinates_mapped=True,
        full_original_equilibrium_equations_retained=True,
        independent_material_reintegration=False, physical_capacity_certified=False)
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('NONLINEAR YIELD ELIMINATION TRACES DUMMY EQUATION AND COMPLETE NEWTON VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
