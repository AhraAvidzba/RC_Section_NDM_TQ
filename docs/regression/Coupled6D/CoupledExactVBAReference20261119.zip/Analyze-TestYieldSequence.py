"""ДЛЯ ТЕСТОВ. Проверяет последовательное принятие истории и независимое равновесие всех принятых полей."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestAnalyze(root, output):
    """Численная остановка сохраняется явно; только принятые состояния участвуют в подтверждённой последовательности."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Analyze-TestYieldProjection.py'))['TestAnalyze'](root, output)
    result = json.loads(output.read_bytes())
    preparation = json.loads((root / 'Preparation.json').read_bytes())
    rows = list(csv.reader((root / 'Native/NewtonLine.csv').read_text('cp1251').splitlines(), delimiter=';'))
    accepted = [row for row in rows if row[0] == 'SEQUENCE_ACCEPTED']
    revisions = [int(row[3]) for row in accepted]
    assert all(after == before + 1 for before, after in zip(revisions, revisions[1:]))
    proof = None
    if accepted:
        validate = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate']
        proof, fields = validate(root, 'NewtonLine.Sequence')
        prefix = preparation['directed_scope']['initial_accepted_prefix']
        assert len(fields) == prefix + len(accepted)
        for index, record in enumerate(accepted):
            assert int(record[1]) == index
            case = result['cases'][str(index)]
            criterion = case['configured_residual_criterion_met'] if preparation['directed_scope'].get('configured_absolute_equilibrium_contract', False) else case['strict_root_found']
            assert criterion and case['native_original_tolerance_verified']
            assert case['native_field_Double_unchanged'] and case['native_forward_direction']
            assert float(record[2]) == case['final_lambda']
            final, = [row for row in rows if row[:2] == ['FINAL', str(index)]]
            np.testing.assert_allclose(fields[prefix + index], np.asarray([float(value) for value in final[3:]]),
                                       rtol=1e-14, atol=1e-300)
    result.update(accepted_steps=len(accepted), attempted_steps=len(result['cases']),
        full_requested_sequence_completed=len(accepted) == preparation['directed_scope']['step_limit'],
        accepted_revision_increments_verified=True,
        lambda_sequence=[float(row[2]) for row in accepted], independent_sequence_equations=proof,
        physical_capacity_certified=False, working_runtime_changed=False)
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('SEQUENTIAL MATERIAL HISTORY ALL ACCEPTED FIELDS AND EQUATIONS VERIFIED', len(accepted), 'CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
