"""Reconstruct HardShear step 15 locality from the sealed 60-DOF native trace."""
from argparse import ArgumentParser
from base64 import b64decode
from hashlib import sha256
from math import acos, atan2, degrees, fsum, isclose, sqrt
from pathlib import Path
from struct import unpack
from zipfile import ZipFile
import json

TRACE_SHA='6E47987D65E6A02FCA2797979D8E5075B31EAD81C8153741EB18BBBB838CB37E'
ARCHIVES={
    'HardShearG13SerialArcAttempt14DirectionNative20261117.zip':'6CA5C64823399B7385635AA50F31C132A221164C47DE8D8E96B42DBC23037318',
    'HardShearG13Arc31ResumeNative20261117.zip':'819291EB230833351A6A9742D57B8FCC4473146176D5442BEDD7BB5557ED0978',
}
GROUPS={
    'plane_axial_and_bending':tuple(range(0,3)),
    'plane_twist':(3,),
    'cross_section_u_v':tuple(i for i in range(4,52) if (i-4)%3<2),
    'longitudinal_w':tuple(range(6,52,3)),
    'longitudinal_derivatives':tuple(range(52,56)),
    'gauges':tuple(range(56,60)),
}
STRAINS=('epsilon_xx','epsilon_yy','gamma_xy','epsilon_zz','gamma_xz','gamma_yz')


def number(v):
    return unpack('>d',bytes.fromhex(v))[0]


def restore(repo):
    root=repo/'docs/regression/Coupled6D'
    archives=list(ARCHIVES.items())
    data=[]
    for (name,seal),leaf in zip(archives,('HardG14Direction.csv','TraceDeltaResume.json'),strict=True):
        path=root/name
        assert sha256(path.read_bytes()).hexdigest().upper()==seal
        with ZipFile(path) as bundle:
            data.append(bundle.read('Native/Order10/'+leaf))
    old,wire=data
    encoded=json.loads(wire); prefix=encoded['prefix_lines']; suffix=encoded['suffix_lines']
    lines=old.splitlines(keepends=True)
    assert encoded['old_sha256']==sha256(old).hexdigest().upper() and encoded['old_lines']==len(lines)
    assert 10000<prefix and 0<=suffix<=len(lines)-prefix
    raw=b''.join(lines[:prefix])+b64decode(encoded['middle'],validate=True)+b''.join(lines[len(lines)-suffix:])
    assert encoded['new_sha256']==sha256(raw).hexdigest().upper()==TRACE_SHA
    assert encoded['new_lines']==len(raw.splitlines())
    return raw


def read(raw):
    assert sha256(raw).hexdigest().upper()==TRACE_SHA
    weights={}; op={}; steps={}
    live=None; tail=None
    for line in raw.decode('cp1251').splitlines():
        key,*args=line.split(';')
        if key=='TRACE-AREA':
            p=int(args[0]); assert p not in weights
            weights[p]=number(args[1])
        elif key=='TRACE-OP':
            p,row=map(int,args[:2]); assert (p,row) not in op
            pieces=[v.split('=') for v in args[2:]]
            op[p,row]={int(i)-1:number(x) for i,x in pieces}
        elif key=='TRACE-TRY':
            attempt=int(args[0]); assert attempt not in steps
            live={'try':args}; steps[attempt]=live
        elif key=='TRACE-FINISH':
            assert tail is None; tail=args
        elif key.startswith('TRACE-'):
            if live is not None:
                assert key not in live; live[key]=args
    assert tail==['SINGLE_STOCK_PROBE','10','9744']
    assert sorted(weights)==list(range(1,119)) and set(op)=={(p,r) for p in weights for r in range(1,10)}
    assert all(0<=i<56 for terms in op.values() for i in terms)
    assert len(steps)==15 and [i for i,r in steps.items() if r['TRACE-DECISION']==['ACCEPTED']]==[1,2,3,4,5,6,7,8,11,14]
    assert steps[15]['TRACE-DECISION']==['LOCALITY_OR_BALANCE'] and 'TRACE-COMMIT' not in steps[15]
    assert steps[14]['TRACE-COMMIT']==steps[14]['TRACE-FIELD']
    return weights,op,steps


def sub(a,b):
    return tuple(x-y for x,y in zip(a,b,strict=True))


def mul(a,k):
    return tuple(x*k for x in a)


def dot(a,b):
    return fsum(x*y for x,y in zip(a,b,strict=True))


def vector(row,key):
    raw=row[key]
    assert len(raw)==60
    return tuple(map(number,raw))


def physical(weights,op,movement):
    """Flatten the exact native metric as area-weighted orthonormal Cartesian rows."""
    denominator=3.*fsum(weights.values())
    result=[]
    for p,w in sorted(weights.items()):
        e=[fsum(movement[j]*value for j,value in op[p,r].items()) for r in range(1,10)]
        scale=sqrt(w/denominator)
        normal=[sqrt(3.)*e[0],sqrt(3.)*e[1],sqrt(1.5)*e[2]]
        for i,t in ((3,1.),(5,sqrt(.5)),(7,sqrt(.5))):
            low,high=e[i:i+2]; normal.extend((t*low,t*high,t*(low+high)/2.))
        result.append(tuple(scale*x for x in normal))
    return tuple(v for p in result for v in p)


def cosine(a,b):
    return dot(a,b)/sqrt(dot(a,a)*dot(b,b))


def angle(value):
    return degrees(acos(max(-1.,min(1.,value))))


def group_energy(fn,d,x):
    total=dot(x,x)
    result={}
    parts={}
    for key,ids in GROUPS.items():
        q=fn(tuple(v if i in ids else 0. for i,v in enumerate(d)))
        parts[key]=q
        result[key]={'isolated_metric_norm':sqrt(dot(q,q)), 'share_of_true_squared_distance':dot(q,x)/total,
                     'isolated_squared_distance_over_total':dot(q,q)/total,
                     'coefficient_max_abs':max(abs(d[i]) for i in ids)}
    assert abs(fsum(row['share_of_true_squared_distance'] for row in result.values())-1.)<3e-13
    return result,{'twist_w_cross_over_total':2.*dot(parts['plane_twist'],parts['longitudinal_w'])/total,
                   'axial_derivative_cross_over_total':2.*dot(parts['plane_axial_and_bending'],parts['longitudinal_derivatives'])/total}


def components(v):
    def local(point,k):
        a=12*point
        return v[a+k:a+k+1] if k<3 else v[a+(k-2)*3:a+(k-1)*3]
    # Native metric stores three scalar rows then triples for zz, xz and yz.
    totals={key:fsum(q*q for p in range(len(v)//12) for q in local(p,k)) for k,key in enumerate(STRAINS)}
    assert isclose(fsum(totals.values()),dot(v,v),rel_tol=2e-15)
    return {key:{'norm':sqrt(value),'share':value/dot(v,v)} for key,value in totals.items()}


def main(raw):
    weights,op,steps=read(raw)
    physics=lambda d:physical(weights,op,d)
    q11=vector(steps[11],'TRACE-COMMIT'); q14=vector(steps[14],'TRACE-COMMIT'); q15=vector(steps[15],'TRACE-FIELD')
    d11=sub(q11,vector(steps[8],'TRACE-COMMIT')); d14=sub(q14,q11); d15=sub(q15,q14)
    d8=sub(vector(steps[8],'TRACE-COMMIT'),vector(steps[7],'TRACE-COMMIT'))
    dseed=sub(vector(steps[15],'TRACE-SEED'),q14)
    vectors=[physics(x) for x in (d8,d11,d14,d15,dseed)]
    b8,b11,b14,b15,s15=vectors
    n8,n11,n14,n15,nseed=(sqrt(dot(v,v)) for v in vectors)
    travel14,travel15=(number(steps[j]['try'][2]) for j in (14,15))
    balance14=tuple(map(number,steps[14]['TRACE-BALANCE'][:-1])); balance15=tuple(map(number,steps[15]['TRACE-BALANCE'][:-1]))
    assert steps[14]['TRACE-BALANCE'][-1]=='True' and steps[15]['TRACE-BALANCE'][-1]=='False'
    assert all(isclose(n,b[4],rel_tol=3e-11) for n,b in ((n14,balance14),(n15,balance15)))
    assert balance14[1]<=balance14[2] and balance15[1]<=balance15[2] and n15>3*travel15
    projection15=vector(steps[15],'TRACE-PROJECTION')
    tangent=mul(b14,1./n14)
    along=dot(tangent,b15)
    assert isclose(along,dot(projection15,d15),rel_tol=3e-11)
    assert isclose(along,balance15[3],rel_tol=3e-11)
    assert isclose(nseed,travel15,rel_tol=3e-10) and cosine(s15,b14)>1.-2e-13
    turned=sub(b15,mul(tangent,along))
    orth=sqrt(dot(turned,turned)); rt=mul(turned,1./orth)
    v_turn=sub(mul(tangent,cosine(b14,b11)),mul(b11,1./n11))
    trend_cosine=cosine(rt,v_turn)
    raw_turn=angle(along/n15)
    accepted_plane_projection=(along/n15,orth/n15*trend_cosine)
    plane_peak=sqrt(dot(accepted_plane_projection,accepted_plane_projection))
    optimum_angle=degrees(atan2(accepted_plane_projection[1],accepted_plane_projection[0]))
    assert plane_peak>1./3. and optimum_angle<0.
    closest_in_plane_rotation=optimum_angle+angle(1./(3.*plane_peak))
    assert closest_in_plane_rotation<0.
    increment=balance15[0]-balance14[0]
    widths=number(steps[14]['TRACE-BOUND'][1])
    a11=number(steps[11]['TRACE-BALANCE'][0])
    accepted_increment=balance14[0]-a11
    width=widths+number(steps[11]['TRACE-BOUND'][1])
    g14,c14=group_energy(physics,d14,b14);g15,c15=group_energy(physics,d15,b15)
    direction15_along_field=mul(d14,along/n14)
    d15side=sub(d15,direction15_along_field)
    group_orth,c_orth=group_energy(physics,d15side,turned)
    distance_correction=sqrt(dot(sub(b15,s15),sub(b15,s15)))
    summary={
        'native_trace_sha256':TRACE_SHA,'tracked_source_archives':ARCHIVES,
        'attempt14_accepted':{'requested_step':travel14,'physical_length':n14,'ratio':n14/travel14,'norm_MPa':balance14[1],'tolerance_MPa':balance14[2]},
        'attempt15_rejected_not_committed':{'requested_step':travel15,'physical_length':n15,'length_ratio':n15/travel15,
          'parallel_distance_along_accepted14':along,'orthogonal_distance':orth,'orthogonal_over_requested':orth/travel15,
          'orthogonal_squared_share':(orth/n15)**2,'direction_angle_to_accepted14_deg':raw_turn,
          'seed_distance':nseed,'raw_field_correction_from_seed':distance_correction,'norm_MPa':balance15[1],
          'tolerance_MPa':balance15[2],'lambda_nominal_increment_from_attempt14':increment,
          'raw_step15_lambda_uncertainty_available':False},
        'accepted_14_minus_11_lambda':{'nominal':accepted_increment,'interval':[accepted_increment-width,accepted_increment+width]},
        'accepted_direction_evidence':{
            'angle_step8_to_step11_deg':angle(cosine(b8,b11)),
            'angle_step11_to_step14_deg':angle(cosine(b11,b14)),
            'angle_step11_to_rejected15_deg':angle(cosine(b11,b15)),
            'rejected_orthogonal_vs_extrapolated_accepted_turn_cosine':trend_cosine,
            'minimum_tilt_to_put_this_raw_direction_inside_three_radius_cone_deg':raw_turn-angle(1./3.),
            'raw_direction_best_alignment_in_accepted11_14_plane':plane_peak,
            'best_signed_rotation_in_accepted11_14_plane_deg_against_recent_turn':optimum_angle,
            'least_signed_rotation_in_accepted11_14_plane_for_cone_deg_against_recent_turn':closest_in_plane_rotation,
        },
        'half_radius_counterfactual_pure_similarity_only':{
            'new_requested_step':travel15/2.,'three_radius_cap':3.*travel15/2.,
            'scaled_raw_length_without_nonlinear_resolve':n15/2.,'unchanged_length_ratio':(n15/2.)/(travel15/2.),
            'scaled_rejected_point_meets_locality':n15/2.<=3.*travel15/2.,
            'new_half_step_was_executed':False,
            'needed_orthogonal_reduction_fraction_at_correct_projection':1.-sqrt(8.)/(orth/travel15),
        },
        'true_metric_share_by_strain':{'accepted14':components(b14),'rejected15':components(b15),'orthogonal_part15':components(turned)},
        'coefficient_group_metric':{'accepted14':g14,'rejected15':g15,'orthogonal_part15':group_orth},
        'signed_cross_term_over_true_norm_squared':{'accepted14':c14,'rejected15':c15,'orthogonal_part15':c_orth},
        'new_native_trial_executed':False,'physical_limit_certified':False,
    }
    return summary


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    source=cli.add_mutually_exclusive_group()
    source.add_argument('--trace',type=Path)
    source.add_argument('--repo',type=Path)
    cli.add_argument('--report',type=Path)
    cli.add_argument('--details',action='store_true')
    opts=cli.parse_args()
    raw=opts.trace.read_bytes() if opts.trace else restore(opts.repo or Path.cwd())
    report=main(raw)
    payload=(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
    if opts.report:
        with opts.report.open('xb') as stream: stream.write(payload)
    print('HARDSHEAR_14_15_METRIC_OFFLINE_PASS',sha256(payload).hexdigest().upper())
    if opts.details:
        print(json.dumps(report,indent=2,sort_keys=True,allow_nan=False))
