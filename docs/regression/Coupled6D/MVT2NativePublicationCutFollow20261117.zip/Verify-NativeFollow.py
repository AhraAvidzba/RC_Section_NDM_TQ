"""Проверяет продолжение MVT2 в Excel от последнего принятого поля §551."""

from argparse import ArgumentParser
from hashlib import sha256
from itertools import product
import json
from math import copysign, isclose
from pathlib import Path
import re
from zipfile import ZipFile


BASE = "MVT2NativePublicationCutTimed20261117.zip"
BASE_SHA = "EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A"
RECOVERY = "MVT2NativePublicationCutRecovery20261117.zip"
RECOVERY_SHA = "3ADDC2837E6D63A8B31C6CD2314CB47387AC437C1C786DE7A304AC18C9F19309"
SPLIT = "MVT2NativePublicationCutSplit20261117.zip"
SPLIT_SHA = "B90505E21FA5E7735B91374512602B901A4864F4F0C23D7191028F87268B8F46"
HISTORY_SHA = "6C9DB16335E0792C2841A6BCDDF27A59D25A203F001BFB74C70ADB3632933F1C"
LAST = "Split14"
Q_START = 22392.578125
Q_TARGET = 22500.0
TORQUE = 10510000.0
MODULUS = 30000.0
REPORT = "MVTGaussMixed.txt"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def pinned(directory, archive_name, fingerprint):
    path = directory / archive_name
    assert digest(path.read_bytes()) == fingerprint
    return ZipFile(path)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_references(repo):
    """Читает проверенные операторы, геометрию и принятые поля из трёх архивов."""
    directory = repo / "docs/regression/Coupled6D"
    utility, recovery = {"__name__": "__pinned__"}, {"__name__": "__pinned__"}
    with pinned(directory, BASE, BASE_SHA) as base:
        exec(compile(base.read("Verify-NativePublicationCut.py"), BASE, "exec"), utility)
        base_field = utility["read_operators"](base.read("Native/Operators.csv"))["F"]
    with pinned(directory, RECOVERY, RECOVERY_SHA) as prior:
        exec(compile(prior.read("Verify-NativeRecovery.py"), RECOVERY, "exec"), recovery)
    with pinned(directory, SPLIT, SPLIT_SHA) as split:
        operators = utility["read_operators"](split.read("Native/Operators.csv"))
        frames = utility["read_tensor_frames"](split.read("Native/MVTGaussMixed.Tensor.csv"), 45)
        rows = [line.split(";") for line in split.read("Native/MVTGaussMixed.csv").decode("cp1251").splitlines()]
        mesh = recovery["geometry"](rows)
        assert frames[LAST][:2] == (TORQUE, Q_START)
        assert len(base_field) == 22 and len(operators["F"]) == 7
    return utility, recovery, base_field, operators, frames, mesh


def owner_check(root, log, reference):
    """Проверяет завершение именно изолированного процесса Excel."""
    native = root / "Native"
    compiler = read_json(root / "CodeUpdate.json")
    owner = read_json(native / f"{REPORT}.Ownership.json")
    closing = read_json(native / f"{REPORT}.ProcessClosure.json")
    assert compiler["Compiled"] and not compiler["ProductionChanged"]
    assert compiler["ProductionSHA256"] == reference["BOOK_SHA"]
    assert compiler["WorkbookSHA256"] == owner["SourceSHA256"]
    assert set(compiler["Modules"]) == {"CCoupledElasticState", "CCoupledSectionQuadrature", "modTestMVT2GaussSpan"}
    assert read_json(root / "CompileClosure.json")["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["ProcessName"] == "EXCEL"
    assert f"TEST_EXCEL_PROCESS: id={owner['PID']}; startTicks={owner['StartTicksUTC']}" in log
    assert f"SOURCE_SHA256: {compiler['WorkbookSHA256']}" in log
    assert "RUNTIME ERROR:" not in log
    if closing["Stage"] == "AFTER_CHILD_EXIT":
        reference["DIAGNOSTIC_SHA"][False] = compiler["WorkbookSHA256"]
        reference["checks_of_owner"](root, log, False)
        return "completed", owner["PID"], owner["StartTicksUTC"]
    assert closing["Stage"] == "TIMEOUT" and not closing["Passed"]
    assert closing["Identity"]["Valid"] and closing["Identity"]["PID"] == owner["PID"]
    assert closing["Identity"]["Ticks"] == int(owner["StartTicksUTC"])
    assert closing["After"]["State"] == "Absent" and closing["After"]["PID"] == owner["PID"]
    assert int(closing["After"]["StartTicksUTC"]) == int(owner["StartTicksUTC"])
    assert closing["ExactOwnExcelStopRequestedOnlyByExplicitTimeout"]
    assert "WATCHDOG_FAILURE: timeout=165 sec;" in log and "ownExcelState=Absent" in log
    return "watchdog_timeout", owner["PID"], owner["StartTicksUTC"]


def trial_work(details, success, internal, code):
    """Проверяет нативный статус и количество выполненных итераций."""
    assert success in ("True", "False")
    assert (internal, code) == (("4", "0") if success == "True" else ("6", "10"))
    work = re.match(r"Итерации: (\d+); пробы: (\d+); невязка, МПа: ([0-9.Ee+-]+)", ";".join(details))
    assert work and 0 <= int(work[1]) <= 26
    return {"accepted": success == "True", "iterations": int(work[1]),
            "evaluations": int(work[2]), "reported_norm_MPa": float(work[3])}


def force_trials(rows):
    """Восстанавливает дискретный алгоритм роста и деления шагов."""
    attempts, q, step = [], Q_START, 2.44140625
    for index, row in enumerate(rows, 1):
        _, ordinal, previous, raw_goal, success, internal, code, *details = row
        assert int(ordinal) == index and 0.0762939453125 <= step <= 9.765625 and q < Q_TARGET
        goal = min(Q_TARGET, q + step)
        assert isclose(float(previous), q, abs_tol=1e-9, rel_tol=0)
        assert isclose(float(raw_goal), goal, abs_tol=1e-9, rel_tol=0)
        work = trial_work(details, success, internal, code)
        attempts.append(work | {"phase": f"Follow{index}", "Qy_N": goal, "increment_N": step})
        if work["accepted"]:
            q, step = goal, min(step * 2, 9.765625)
        else:
            step /= 2
    assert len(attempts) <= 32
    return attempts, q == Q_TARGET, q == Q_TARGET or len(attempts) == 32 or step < 0.0762939453125


def control_trials(rows, reference):
    """Сверяет знак и размер проекции, прогноз и возвращённый множитель Qy."""
    attempts = []
    settings = list(product(("Twist", "CurvatureX"), (0.5, 1.0)))
    for index, row in enumerate(rows, 1):
        _, phase, name, part, coordinate, prediction, factor, success, internal, code, *details = row
        assert phase == f"Control{index}"
        assert (name, float(part)) == settings[index - 1]
        axis = 3 if name == "Twist" else 1
        past, current = reference["F"]["Split10"][axis], reference["F"][LAST][axis]
        assert current != past
        sign = copysign(1, current - past)
        goal = sign * current + float(part) * abs(current - past)
        assert isclose(float(coordinate), goal, abs_tol=3e-17, rel_tol=0)
        assert float(prediction) == Q_START / 1000 + float(part) * 0.009765625
        work = trial_work(details, success, internal, code)
        assert float(factor) > 0 if work["accepted"] else float(factor) == 0
        attempts.append(work | {"phase": phase, "control": name, "coordinate_index": axis,
                                "coordinate_sign": sign, "coordinate_target": float(coordinate),
                                "Qy_N": float(factor) * 1000})
    return attempts, any(row["accepted"] for row in attempts), len(attempts) == len(settings)


def complete_frames(utility, raw, partial):
    """Отделяет недописанный хвост при остановке watchdog."""
    if not partial:
        return utility["read_tensor_frames"](raw, 45)
    lines = raw.splitlines()
    counts = [index for index, value in enumerate(lines) if value.startswith(b"FRAME;")]
    last = counts[-1]
    if len(lines) - last < 46 or not raw.endswith(b"\n"):
        raw = b"\n".join(lines[:last]) + b"\n"
    return utility["read_tensor_frames"](raw, 45)


def verify_run(root, mode, references):
    """Повторяет численную проверку и выделяет незавершённые записи."""
    utility, recovery, base, reference, reference_frames, mesh = references
    prep = read_json(root / "Preparation.json")
    assert prep["follow_mode"] == mode and prep["follow_history_archive"] == SPLIT_SHA
    assert prep["source_book_sha256"] == recovery["BOOK_SHA"]
    for leaf in ("Replay.Fields.csv", "tests/modTestMVT2GaussSpan.bas"):
        assert digest((root / leaf).read_bytes()) == prep["inputs"][leaf]
    history = (root / "Replay.Fields.csv").read_bytes()
    assert digest(history) == HISTORY_SHA
    rows = [line.split(";") for line in history.decode("ascii").splitlines()]
    assert len(rows) == 28 and [row[0] for row in rows] == [*base, *list(reference["F"])[1:]]
    assert all(tuple(map(float, values)) == (base[phase] if phase in base else reference["F"][phase])
               for phase, q, torque, *values in rows)

    native = root / "Native"
    log = (native / REPORT).read_text(encoding="utf-8-sig")
    termination, pid, ticks = owner_check(root, log, recovery)
    partial = termination == "watchdog_timeout"
    raw_ops = (native / "Operators.csv").read_bytes()
    if partial and not raw_ops.endswith(b"\n"):
        raw_ops = raw_ops.rsplit(b"\n", 1)[0] + b"\n"
    operators = utility["read_operators"](raw_ops)
    assert all(operators[group] == reference[group] for group in "GLBSR")
    frames = complete_frames(utility, (native / "MVTGaussMixed.Tensor.csv").read_bytes(), partial)
    trace = [line.split(";") for line in (native / "MVTGaussMixed.csv").read_text(encoding="cp1251").splitlines()]
    assert recovery["geometry"](trace) == mesh
    assert [row for row in trace if row[0] == "MVT2_FOLLOW_REPLAY"] == [["MVT2_FOLLOW_REPLAY", "28", str(Q_START)]]
    assert operators["F"]["Replay"] == reference["F"][LAST]
    assert frames["Replay"][:2] == reference_frames[LAST][:2] == (TORQUE, Q_START)
    replay_delta = max(abs(a - b) for side, p in product((-1, 0, 1), mesh[1])
                       for a, b in zip(operators["H"]["Replay", side, p], reference["H"][LAST, side, p], strict=True))
    assert replay_delta < 5e-12
    tag = f"MVT2_FOLLOW_{mode.upper()}"
    other = "MVT2_FOLLOW_CONTROL" if mode == "Force" else "MVT2_FOLLOW_FORCE"
    assert not any(row[0] == other for row in trace)
    trials = [row for row in trace if row[0] == tag]
    finish = [row for row in trace if row[0] == "CASE_FINISHED"]
    attempts, reached, complete = (force_trials(trials) if mode == "Force" else control_trials(trials, reference))
    if partial:
        assert not finish and "TOTAL_MVT2_GAUSS_SPAN:" not in log
        elapsed = None
    else:
        assert complete and len(finish) == 1 and finish[0][2] == str(reached)
        assert f"TOTAL_MVT2_GAUSS_SPAN: passed=1; failed=0; target_reached={reached}" in log
        assert all(";".join(row) in log for row in trials)
        elapsed = float(finish[0][3])
        assert 0 < elapsed < 165
    expected = {item["phase"]: item for item in attempts if item["accepted"]}
    assert set(operators["F"]) | set(frames) | {key[0] for key in operators["H"]} <= {"Replay", *expected}
    station_keys = set(product((-1, 0, 1), mesh[1]))
    fields, incomplete = [], []
    for phase in ("Replay", *expected):
        available = {(side, point) for name, side, point in operators["H"] if name == phase}
        if phase not in operators["F"] or phase not in frames or available != station_keys:
            assert partial and phase != "Replay"
            incomplete.append(phase)
            continue
        tol = recovery["equations"](phase, frames[phase], operators, mesh)
        q = frames[phase][1]
        assert frames[phase][0] == TORQUE
        coordinates = operators["F"][phase]
        output = {"phase": phase, "Qy_N": q, "normalized_twist": coordinates[3],
                  "twist_rad_per_m": 1000 * coordinates[3] / mesh[0][3], **tol}
        if phase in expected:
            row = expected[phase]
            assert isclose(q, row["Qy_N"], abs_tol=1e-8, rel_tol=0)
            if mode == "Control":
                residual = abs(row["coordinate_sign"] * coordinates[row["coordinate_index"]]
                               - row["coordinate_target"]) * MODULUS
                assert residual <= tol["tolerance_MPa"]
                output["control_residual_MPa"] = residual
        fields.append(output)
    return {"termination": termination, "excel_pid": pid, "excel_start_ticks": ticks,
            "replay_810_component_max_delta_MPa": replay_delta, "attempts": attempts,
            "fields": fields, "logged_acceptance_without_complete_archive": incomplete,
            "macro_seconds": elapsed, "maximum_verified_Qy_N": max(row["Qy_N"] for row in fields),
            "exact_force_goal_verified": any(row["Qy_N"] == Q_TARGET for row in fields),
            "physical_limit_established": False}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    references = read_references(args.repo.resolve())
    modes = [mode for mode in ("Force", "Control") if (args.root / mode).is_dir()]
    assert modes
    result = {mode: verify_run(args.root / mode, mode, references) for mode in modes}
    with args.report.open("x", encoding="utf-8", newline="\n") as out:
        json.dump(result, out, indent=2, sort_keys=True, allow_nan=False)
        out.write("\n")
    print("MVT2 NATIVE FOLLOW OFFLINE PASS", len(modes),
          sum(len(record["fields"]) - 1 for record in result.values()))


if __name__ == "__main__":
    main()
