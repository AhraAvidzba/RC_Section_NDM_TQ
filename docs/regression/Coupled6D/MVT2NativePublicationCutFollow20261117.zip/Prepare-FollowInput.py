"""Объединяет подтверждённые истории MVT2 из §547 и §551."""

from argparse import ArgumentParser
from decimal import Decimal
from hashlib import sha256
import json
from math import fsum, isclose
from pathlib import Path
from zipfile import ZipFile


BASE = "MVT2NativePublicationCutTimed20261117.zip"
BASE_SHA = "EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A"
SPLIT = "MVT2NativePublicationCutSplit20261117.zip"
SPLIT_SHA = "B90505E21FA5E7735B91374512602B901A4864F4F0C23D7191028F87268B8F46"
PROOF_SHA = "6A812FC56DFE40F0B879EC75F5C328EC060625D70B55F5D10198DBF8FEFAFC74"


def digest(data):
    return sha256(data).hexdigest().upper()


def open_verified(directory, name, expected):
    path = directory / name
    assert digest(path.read_bytes()) == expected, name
    return ZipFile(path)


def records(data, encoding="ascii"):
    return [line.split(";") for line in data.decode(encoding).splitlines()]


def fields(archive):
    """Читает коэффициенты и заданные силы из одного нативного прогона."""
    operator_rows = records(archive.read("Native/Operators.csv"))
    tensor_rows = records(archive.read("Native/MVTGaussMixed.Tensor.csv"))
    targets = {row[1]: (row[3], row[2]) for row in tensor_rows if row[0] == "FRAME"}
    accepted = [row for row in operator_rows if row[0] == "F"]
    assert [row[1] for row in accepted] == list(targets)
    assert all(len(row) == 62 for row in accepted)
    return [[row[1], *targets[row[1]], *row[2:]] for row in accepted], operator_rows, tensor_rows


def prepared_bytes(rows):
    return ("\r\n".join(";".join(row) for row in rows) + "\r\n").encode("ascii")


def write_new(path, data):
    with path.open("xb") as output:
        output.write(data)


def prepare(repo, out):
    """Сохраняет исходные десятичные строки VBA и конечные тензоры трёх станций."""
    directory = repo / "docs/regression/Coupled6D"
    with open_verified(directory, BASE, BASE_SHA) as base, open_verified(directory, SPLIT, SPLIT_SHA) as split:
        prefix, base_ops, _ = fields(base)
        extra, split_ops, split_tensors = fields(split)
        assert len(prefix) == 22 and len(extra) == 7
        assert [row[1:] for row in prefix] == [row[1:] for row in records(split.read("Replay.Fields.csv"))]
        assert extra[0][0] == "Replay" and extra[0][1:] == prefix[-1][1:]
        assert [row for row in base_ops if row[0] in ("SIZE", "G", "L", "B", "S", "R")] == [
            row for row in split_ops if row[0] in ("SIZE", "G", "L", "B", "S", "R")]
        raw_proof = split.read("NativeSplitProof.json")
        assert digest(raw_proof) == PROOF_SHA
        proof = json.loads(raw_proof, parse_float=Decimal)
        assert proof["new_fields"] == 6 and proof["target_N"] == 22500 and not proof["exact_target_reached"]
        assert not proof["physical_limit_established"]
        assert [Decimal(row[1]) for row in extra] == [field["Qy_N"] for field in proof["fields"]]
        attempts = [(index, trial["q_N"]) for index, trial in enumerate(proof["attempts"], 1) if trial["accepted"]]
        assert [(row[0], Decimal(row[1])) for row in extra[1:]] == [
            (f"Split{index}", q) for index, q in attempts]
        last, q, torque, *_ = extra[-1]
        assert Decimal(q) == proof["last_Qy_N"] == Decimal("22392.578125")
        assert Decimal(torque) == 10510000
        for row in prefix + extra[1:]:
            assert len(row) == 63
        phases = [row[0] for row in extra]
        triplets = [row for row in split_ops if row[0] == "H"]
        assert all(len(row) == 10 for row in triplets)
        assert {(row[1], int(row[2]), int(row[3])) for row in triplets} == {
            (phase, station, point) for phase in phases for station in (-1, 0, 1) for point in range(1, 46)}
        assert len(triplets) == len(phases) * 135
        terminal_h = [row for row in triplets if row[1] == last]
        terminal_start = next(i for i, row in enumerate(split_tensors) if row[:2] == ["FRAME", last])
        terminal_center = split_tensors[terminal_start:terminal_start + 46]
        assert [int(row[1]) for row in terminal_center[1:]] == list(range(1, 46))

        mesh_base = [row for row in records(base.read("Native/MVTGaussMixed.csv"), "cp1251")
                     if row[0] in ("MVT_GEOM", "MVT_POINT")]
        mesh_split = [row for row in records(split.read("Native/MVTGaussMixed.csv"), "cp1251")
                      if row[0] in ("MVT_GEOM", "MVT_POINT")]
        assert mesh_base == mesh_split
        assert mesh_split[0][1:4] == ["25", "45", "60"]
        assert [int(row[1]) for row in mesh_split[1:]] == list(range(1, 46))
        weights = [float(row[4]) for row in mesh_split[1:]]
        assert all(w > 0 for w in weights)
        area = float(mesh_split[0][6])
        concrete = fsum(weights[:25])
        assert isclose(concrete, area, abs_tol=1e-8, rel_tol=0)

    replay = prepared_bytes(prefix + extra[1:])
    metadata = {
        "history_sha256": digest(replay),
        "archived_prefix_fields": len(prefix),
        "archived_appended_fields": len(extra) - 1,
        "target_Qy_N": 22500,
        "last_phase": last,
        "last_Qy_N": q,
        "last_T_Nmm": torque,
        "last_Mx_Nmm": str(-Decimal("396") * Decimal(q)),
        "section_reference_length_mm": float(mesh_split[0][7]),
        "coefficient_count": 60,
        "station_point_count": len(terminal_h),
        "tensor_component_count": len(terminal_h) * 6,
        "station_offsets_mm": [-0.001, 0, 0.001],
        "concrete_weight_sum_mm2": concrete,
        "longitudinal_weight_sum_mm2": fsum(weights[25:29]),
        "stirrup_weight_sum_mm2": fsum(weights[29:]),
        "physical_limit_established": False,
    }
    out.mkdir(parents=True, exist_ok=True)
    write_new(out / "Replay.Fields.csv", replay)
    write_new(out / "Replay.Terminal.H.csv", prepared_bytes(terminal_h))
    write_new(out / "Replay.Terminal.Tensor.csv", prepared_bytes(terminal_center))
    write_new(out / "FollowInputProof.json", (json.dumps(metadata, indent=2) + "\n").encode("ascii"))
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    prepare(args.repo.resolve(), args.out.resolve())
