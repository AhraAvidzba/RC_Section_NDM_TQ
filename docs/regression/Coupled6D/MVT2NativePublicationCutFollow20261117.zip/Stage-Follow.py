"""Готовит пробу продолжения MVT2 от 28 подтверждённых полей."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import json


HERE = Path(__file__).resolve().parent
EVIDENCE = 'MVT2NativePublicationCutSplit20261117.zip'
EVIDENCE_SHA = 'B90505E21FA5E7735B91374512602B901A4864F4F0C23D7191028F87268B8F46'
HISTORY_SHA = '6C9DB16335E0792C2841A6BCDDF27A59D25A203F001BFB74C70ADB3632933F1C'


def digest(wire):
    return sha256(wire).hexdigest().upper()


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


def stage(repo, target, history, mode):
    wire = history.read_bytes()
    assert digest(wire) == HISTORY_SHA and wire.count(b'\r\n') == 28
    evidence = repo / 'docs/regression/Coupled6D' / EVIDENCE
    assert digest(evidence.read_bytes()) == EVIDENCE_SHA
    with TemporaryDirectory(dir=repo / 'tmp', prefix='stage-follow-') as folder:
        work = Path(folder)
        with ZipFile(evidence) as archive:
            for leaf in ('Stage-Recovery.py', 'PublicationRecovery.bas.txt'):
                (work / leaf).write_bytes(archive.read(leaf))
        base = run_path(str(work / 'Stage-Recovery.py'))
        base['stage'](repo, target, False, False)
    replay, test = target / 'Replay.Fields.csv', target / 'tests/modTestMVT2GaussSpan.bas'
    preparation = target / 'Preparation.json'
    records = json.loads(preparation.read_bytes())
    replay.write_bytes(wire)
    source = test.read_text(encoding='utf-8-sig')
    source = replace_once(source, 'Q_ACCEPTED As Double = 21875#', 'Q_ACCEPTED As Double = 22392.578125')
    source = replace_once(source, 'If history.Count <> 22 Or', 'If history.Count <> 28 Or')
    source = replace_once(source, 'MVT2_RECOVERY_REPLAY;22;21875', 'MVT2_FOLLOW_REPLAY;28;22392.578125')
    source = replace_once(source, 'leftField = history.Item(21): rightField = history.Item(22)',
                         'leftField = history.Item(27): rightField = history.Item(28)')
    anchor = '    ReDim seedValues(1 To 60)'
    call = ('TestPublicationFollowForce(solver, operators, stations, report, tracePath)' if mode == 'Force'
            else 'TestPublicationFollowControl(solver, operators, stations, history, report, tracePath)')
    source = replace_once(source, anchor, '    TestPublicationRecovery = ' + call + '\n    Exit Function\n' + anchor)
    source += (HERE / 'FollowPublication.bas.txt').read_text(encoding='utf-8-sig')
    source.encode('cp1251')
    test.write_bytes(source.replace('\n', '\r\n').encode('utf-8-sig'))
    records['follow_mode'] = mode
    records['follow_history_archive'] = EVIDENCE_SHA
    for leaf in (replay, test):
        records['inputs'][leaf.relative_to(target).as_posix()] = digest(leaf.read_bytes())
    preparation.write_bytes((json.dumps(records, indent=2) + '\n').encode())
    print('FOLLOW PREPARED', mode, records['inputs'][test.relative_to(target).as_posix()], flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--stage', required=True, type=Path)
    parser.add_argument('--history', required=True, type=Path)
    parser.add_argument('--mode', required=True, choices=('Force', 'Control'))
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve(), args.history.resolve(), args.mode)
