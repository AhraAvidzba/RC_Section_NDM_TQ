"""Независимо восстанавливает явное обновление ASD при повторе тензора деформаций."""

from argparse import ArgumentParser
from dataclasses import dataclass
from hashlib import sha256
import gzip
import json
from pathlib import Path
import sys
from zipfile import ZipFile

import numpy as np


DESIGN = ('HardShearSameSectionASDDesignPaths20261117.zip',
          '3197E52A738FC93C69488146D0C5A5DCCD84094366D7733717E2471645E2D5B0')
YOUNG = 30000.
POISSON = .2
ALPHA = .16 / 1.32
GAMMA = 3. * (1. - 2. / 3.) / (2. * (2. / 3.) - 1.)


def matrix(stress):
    """Преобразует порядок НДМ xx,yy,zz,xy,xz,yz в симметричный тензор."""
    xx, yy, zz, xy, xz, yz = np.moveaxis(stress, -1, 0)
    return np.moveaxis(np.array(((xx, xy, xz), (xy, yy, yz), (xz, yz, zz))), (0, 1), (-2, -1))


def voigt(stress):
    """Собирает компоненты напряжения без коэффициента сдвига."""
    return stress[..., (0, 1, 2, 0, 0, 1), (0, 1, 2, 1, 2, 2)]


@dataclass
class Branch:
    """Фактические узлы одноосной таблицы, считанные из библиотеки."""

    strain: np.ndarray
    nominal: np.ndarray
    effective: np.ndarray
    strain_tolerance: float
    stress_tolerance: float

    def response(self, strain):
        """Интерполирует обе ординаты и восстанавливает повреждение из их отношения."""
        assert np.min(strain) >= 0. and np.max(strain) <= self.strain[-1]
        segment = np.maximum(1, np.searchsorted(self.strain + self.strain_tolerance, strain))
        lower = segment - 1
        fraction = (strain - self.strain[lower]) / (self.strain[segment] - self.strain[lower])
        def curve(values):
            return np.maximum(self.stress_tolerance, values[lower] + (values[segment] - values[lower]) * fraction)
        return curve(self.nominal), curve(self.effective)


def make_branch(command, tables, side):
    """Определяет документированные численные допуски из входных узлов до их корректировки ASD."""
    first, middle, last = (command.index('-' + side + suffix) for suffix in ('e', 's', 'd'))
    strain = np.abs(command[first + 1:middle])
    stress = np.abs(command[middle + 1:last])
    assert strain[0] == stress[0] == 0.
    stress[1] = YOUNG * strain[1]
    def tolerance(values):
        delta = np.abs(np.diff(values))
        return float(1e-6 * np.min(delta[delta > 0.]))
    return Branch(*(np.asarray(row) for row in tables[side]), tolerance(strain), tolerance(stress))


def law_tables(ops, command):
    """Читает таблицы после внутренней подготовки аргументов в OpenSees."""
    ops.wipe()
    ops.model('basic', '-ndm', 3, '-ndf', 3)
    ops.nDMaterial(command[0], 1, *command[1:])
    return {prefix: [list(ops.NDTest('GetResponse', 1, prefix + suffix)) for suffix in ('e', 's', 'q')]
            for prefix in ('T', 'C')}


def equivalent(principal, ratio, include_tension, tension_floor=0.):
    """Эквивалентная мера из инвариантов поверхности Лублинера."""
    eigen = principal if include_tension else np.minimum(principal, 0.)
    trace = np.sum(eigen, axis=-1)
    dev = eigen - trace[..., None] / 3.
    norm = np.sqrt(1.5 * np.sum(dev * dev, axis=-1))
    largest = eigen[..., -1]
    beta = ratio * (1. - ALPHA) - (1. + ALPHA)
    branch = (ALPHA * trace + norm + beta * np.maximum(largest, 0.) - GAMMA * np.maximum(-largest, 0.))
    value = branch / (YOUNG * (1. - ALPHA))
    return np.where(largest >= tension_floor, value / ratio, 0.) if include_tension else value


def elastic_increment(delta):
    """Строит упругий прогноз из инженерных деформаций, заданных в порядке НДМ."""
    shear = YOUNG / (2. * (1. + POISSON))
    lame = 2. * shear * POISSON / (1. - 2. * POISSON)
    stress = delta * shear
    stress[..., :3] = 2. * shear * delta[..., :3] + lame * np.sum(delta[..., :3], axis=-1)[..., None]
    return matrix(stress)


def scale_response(branch, old, measure):
    """Возвращает новые историю, пластический множитель и долю номинального напряжения."""
    _, old_effective = branch.response(old)
    plastic = old - old_effective / YOUNG
    updated = np.maximum(old, measure + plastic)
    nominal, effective = branch.response(updated)
    divisor = YOUNG * (updated - plastic)
    return updated, effective / divisor, nominal / divisor


def evaluate(state, strain, tension, compression, ratio):
    """Рассчитывает очередное состояние без вызова OpenSees."""
    previous_strain, effective, t_state, c_state = state
    predictor = effective + elastic_increment(strain - previous_strain)
    principal, vectors = np.linalg.eigh(predictor)
    positive = (vectors * np.maximum(principal, 0.)[..., None, :]) @ np.swapaxes(vectors, -1, -2)
    negative = predictor - positive
    t, t_effective, t_nominal = scale_response(tension, t_state, equivalent(principal, ratio, True, tension.stress_tolerance))
    c, c_effective, c_nominal = scale_response(compression, c_state, equivalent(principal, ratio, False))
    updated = positive * t_effective[..., None, None] + negative * c_effective[..., None, None]
    nominal = positive * t_nominal[..., None, None] + negative * c_nominal[..., None, None]
    return (strain, updated, t, c), voigt(nominal), (positive, negative, t_effective, c_effective)


def load_history(repo):
    """Читает только запечатанные данные происхождения конечной точки HardShear."""
    path = repo / 'docs/regression/Coupled6D' / DESIGN[0]
    assert sha256(path.read_bytes()).hexdigest().upper() == DESIGN[1]
    with ZipFile(path) as archive:
        implementation = archive.read('Continue-ASDToDesign.py')
        first = json.loads(gzip.decompress(archive.read('ASDToDesignWire.json.gz')))
        refinement = json.loads(gzip.decompress(archive.read('ASDRefineToDesignWire.json.gz')))
    runner = {'__name__': '__pinned__', '__file__': str(Path(__file__).with_name('Continue-ASDToDesign.py'))}
    exec(compile(implementation, runner['__file__'], 'exec'), runner)
    source, _, prior, cases, _ = runner['inputs'](repo)
    frames = cases['split'] + first['arms']['split']['accepted'] + refinement['arms']['refined']['accepted']
    assert len(frames) == 14 and frames[-1]['lambda'] == .9765625
    geometry, directions, area, length, _, _ = source.fixture(repo)
    operators = source.operators(geometry, area, length)
    return source, prior, frames, geometry, directions, area, length, operators


def initial_state(shape):
    """Создаёт чистую историю для всех бетонных точек и замещённых объёмов."""
    return (np.zeros(shape + (6,)), np.zeros(shape + (3, 3)), np.zeros(shape), np.zeros(shape))


def nominal_with_old_cracking(split, state, tension, compression):
    """Применяет повторный пластический множитель и удерживает принятое повреждение."""
    positive, negative, t_effective, c_effective = split
    t_nominal, t_before = tension.response(state[2])
    c_nominal, c_before = compression.response(state[3])
    t_scale = t_effective * t_nominal / t_before
    c_scale = c_effective * c_nominal / c_before
    return voigt(positive * t_scale[..., None, None] + negative * c_scale[..., None, None])


def exercise(repo, tables):
    """Сверяет независимые вызовы с принятыми и повторными напряжениями архива."""
    source, prior, frames, geometry, directions, area, length, op = load_history(repo)
    positive, negative = (make_branch(prior['material_command'], tables, side) for side in ('T', 'C'))
    ratio = max(5., max(negative.nominal) / max(positive.nominal))
    b, z = (np.asarray(op[name]) for name in ('B', 'Z'))
    strain_op = np.stack((b, b + .001 * z, b - .001 * z))
    state = initial_state((3, 43))
    max_accepted, probes = [], []
    for frame in frames:
        strain = strain_op @ np.asarray(frame['field'])
        state, stress, _ = evaluate(state, strain, positive, negative, ratio)
        net = stress.copy()
        steel = np.asarray(frame['steel_stress_MPa'])
        net[:, 25:] = -net[:, 25:] + steel[..., None] * np.asarray(directions)[25:]
        max_accepted.append(float(np.max(np.abs(net - np.asarray(frame['net_stress_MPa'])))))

        repeated = frame.get('zero_increment_trial') or frame.get('post_commit_new_zero_increment')
        if repeated is None:
            continue
        updated, stored, split = evaluate(state, strain, positive, negative, ratio)
        new_net = stored.copy()
        new_net[:, 25:] = -new_net[:, 25:] + steel[..., None] * np.asarray(directions)[25:]
        expected = np.asarray(repeated['net_stress_MPa'])
        index = np.unravel_index(np.argmax(np.abs(expected - np.asarray(frame['net_stress_MPa']))), new_net.shape)
        plastic_only = nominal_with_old_cracking(split, state, positive, negative)
        sign = 1. if index[1] < 25 else -1.
        plastic_delta = sign * (plastic_only - stress)[index]
        damage_delta = sign * (stored - plastic_only)[index]
        assert abs(plastic_delta + damage_delta - (new_net - net)[index]) < 3e-14
        metrics = source.verify_rows(geometry, directions, area, length, op, frame['field'], new_net.tolist(),
                                     frame['lambda'], steel.tolist(), False)
        probes.append({'lambda': frame['lambda'], 'station_point_component_zero_based': list(map(int, index)),
                       'native_difference_MPa': float(expected[index] - frame['net_stress_MPa'][index[0]][index[1]][index[2]]),
                       'predicted_difference_MPa': float((new_net - net)[index]),
                       'increment_from_plastic_multiplier_MPa': float(plastic_delta),
                       'increment_from_changed_cracking_damage_MPa': float(damage_delta),
                       'point_max_error_MPa': float(np.max(np.abs(new_net - expected))),
                       'recovered_residual_MPa': metrics['combined_norm_MPa'],
                       'native_residual_MPa': repeated['independent']['combined_norm_MPa'],
                       'largest_tensile_history_growth': float(np.max(updated[2] - state[2])),
                       'largest_compressive_history_growth': float(np.max(updated[3] - state[3]))})
    assert len(probes) == 8 and len(max_accepted) == 14
    assert max(max_accepted) < 1e-10
    assert max(r['point_max_error_MPa'] for r in probes) < 1e-10
    assert max(abs(r['recovered_residual_MPa'] - r['native_residual_MPa']) for r in probes) < 1e-11
    assert abs(probes[-1]['native_difference_MPa'] + .033062948297567174) < 1e-12
    return {'material_command_sha256': source.sha(source.packed(prior['material_command'])),
            'accepted_state_max_errors_MPa': max_accepted, 'unchanged_strain_probes': probes,
            'physical_limit_established': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--tables', type=Path, required=True)
    parser.add_argument('--read-native-tables', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    sys.dont_write_bytecode = True
    if args.read_native_tables:
        import openseespy.opensees as ops

        assert ops.version() == '3.8.0'
        _, prior, *_ = load_history(args.repo.resolve())
        tables = law_tables(ops, prior['material_command'])
        with args.tables.open('x', encoding='utf-8', newline='\n') as out:
            json.dump(tables, out, separators=(',', ':'), allow_nan=False)
    else:
        tables = json.loads(args.tables.read_bytes())
    result = exercise(args.repo.resolve(), tables)
    payload = json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n'
    if args.report:
        with args.report.open('x', encoding='utf-8', newline='\n') as out:
            out.write(payload)
        print('HARDSHEAR ASD DRIFT RECONSTRUCTION PASS')
    else:
        print(payload)
