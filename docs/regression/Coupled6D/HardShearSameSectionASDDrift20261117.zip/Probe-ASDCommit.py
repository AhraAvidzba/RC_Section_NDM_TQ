"""Сравнивает три повторные пробы одного тензора с принятием состояния и без него."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import sys

import numpy as np
import openseespy.opensees as ops


def main(repo, tables):
    """Повторяет один и тот же путь в двух независимых экземплярах материала ASD."""
    assert ops.version() == '3.8.0'
    engine = run_path(str(Path(__file__).with_name('Explain-ASDRepeat.py')))
    _, prior, frames, _, _, _, _, op = engine['load_history'](repo)
    point, side = 2, -.001
    tensor = np.asarray(op['B'][point]) + side * np.asarray(op['Z'][point])
    history = [tensor @ np.asarray(frame['field']) for frame in frames]
    permutation = [0, 1, 2, 3, 5, 4]
    ops.model('basic', '-ndm', 3, '-ndf', 3)
    command = prior['material_command']
    tension, compression = (engine['make_branch'](command, tables, branch) for branch in ('T', 'C'))
    ratio = max(5., max(compression.nominal) / max(tension.nominal))
    evaluate, clean = engine['evaluate'], engine['initial_state'](())
    for strain in history:
        clean, predicted, _ = evaluate(clean, strain, tension, compression, ratio)
    candidates = {}
    for accept in (False, True):
        tag = 1 + int(accept)
        ops.nDMaterial(command[0], tag, *command[1:])

        def tension_trial(strain):
            order = strain[permutation].tolist()
            ops.NDTest('SetStrain', tag, *order)
            assert list(ops.NDTest('GetStrain', tag)) == order
            return np.array(ops.NDTest('GetStress', tag))[permutation]

        for strain in history:
            accepted = tension_trial(strain)
            ops.NDTest('CommitState', tag)
        assert np.max(np.abs(accepted - predicted)) < 1e-10
        result, model = [], clean
        for _ in range(3):
            stress = tension_trial(history[-1])
            next_model, recomputed, _ = evaluate(model, history[-1], tension, compression, ratio)
            error = float(np.max(np.abs(stress - recomputed)))
            assert error < 1e-10
            result.append({'stress_MPa': stress.tolist(), 'reconstruction_error_MPa': error})
            if accept:
                ops.NDTest('CommitState', tag)
                model = next_model
        candidates['commit' if accept else 'discard'] = result
    ops.wipe()
    discard, commit = (candidates[name] for name in ('discard', 'commit'))
    assert [step['stress_MPa'] for step in discard] == [discard[0]['stress_MPa']] * 3
    assert discard[0]['stress_MPa'] == commit[0]['stress_MPa']
    assert commit[2]['stress_MPa'] != commit[0]['stress_MPa']
    return {'anchor_lambda': frames[-1]['lambda'], 'tensor': history[-1].tolist(),
            'accepted_stress_MPa': accepted.tolist(), 'arms': candidates, 'physical_limit_established': False}


if __name__ == '__main__':
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--repo', type=Path, default=Path.cwd())
    cli.add_argument('--tables', type=Path, required=True)
    cli.add_argument('--report', type=Path, required=True)
    options = cli.parse_args()
    sys.dont_write_bytecode = True
    proof = main(options.repo.resolve(), json.loads(options.tables.read_bytes()))
    with options.report.open('x', encoding='utf-8', newline='\n') as out:
        json.dump(proof, out, indent=2, sort_keys=True, allow_nan=False)
        out.write('\n')
    print('HARDSHEAR ASD COMMIT AB NATIVE PASS', [row['stress_MPa'][0] for row in proof['arms']['commit']])
