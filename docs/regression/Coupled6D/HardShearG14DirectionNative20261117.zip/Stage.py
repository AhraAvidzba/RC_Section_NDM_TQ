"""Готовит нативную запись первой отклонённой поправки G14 без изменения модели."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = REPO/'docs/regression/Coupled6D/HardShearG13PrecisionNative20261117.zip'
BASE_SHA = '1B7C0461264D41BE516B206B2AD05931F1B2695256CE8A85BCAE2C92533391C7'
REPORT_SHA = 'EC1A826D4F10FAA79C5A82C4B15B7CC50EF930A0935434D7D868C0FAB1DAEB0D'
BOOK_SHA = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
SOLVER = 'src/Solver/CCoupledNewtonSolver.cls'
TEST = 'tests/modTestCoupledElasticState.bas'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def encode(source):
    assert max(map(len,source.splitlines())) < 1024
    return (source.rstrip().replace('\n','\r\n')+'\r\n').encode('utf-8')


def once(source,old,new):
    assert source.count(old) == 1, old
    return source.replace(old,new)


def seal(root,path,raw):
    target = root/path
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, path
    else:
        target.write_bytes(raw)
    return sha(raw)


def solver(raw):
    source = text(raw)
    marker = 'Private mWrongControlDirection As Boolean\n'
    source = once(source,marker,marker+'Private mHardG14ArmedTest As Boolean, mHardG14CapturedTest As Boolean\n'
                                      'Private mHardG14RowTest As Long, mHardG14PartsTest() As Double, mHardG14InitialRowTest As Double\n')
    marker = '                mWrongControlDirection = True\n                If recoverYieldControl Then\n'
    source = once(source,marker,'''                mWrongControlDirection = True
                If mHardG14ArmedTest Then
                    CaptureHardG14DirectionTest current, currentLambda, correction, governingRow, baseEquation, _
                        trialEquation, trialFraction, norm, tolerance
                    Exit Function
                End If
                If recoverYieldControl Then
''')
    marker = '    Dim differenceScale As Double, plusOk As Boolean, minusOk As Boolean, failedSide As Long\n'
    source = once(source,marker,marker+'    Dim hardG14BeforeTest As Double\n')
    marker = '    mSection.StartEquations field, mExternal, mResidual, mMatrix, withMatrix\n'
    source = once(source,marker,marker+'    If mHardG14RowTest > 0 Then mHardG14InitialRowTest = mResidual(mHardG14RowTest)\n')
    marker = '''            mSection.AddSpatialPointEquilibrium point, mStress, mTangent, mSpatialGradient, mGradientTangent, _
                mSlopeTangent, mResidual, mMatrix, withMatrix, mTrialResultants
'''
    source = once(source,marker,'''            If mHardG14RowTest > 0 Then hardG14BeforeTest = mResidual(mHardG14RowTest)
'''+marker+'''            If mHardG14RowTest > 0 Then
                mHardG14PartsTest(point, 1) = mResidual(mHardG14RowTest) - hardG14BeforeTest
                mHardG14PartsTest(point, 2) = mMinusStress(3): mHardG14PartsTest(point, 3) = mStress(3)
                mHardG14PartsTest(point, 4) = mPlusStress(3)
            End If
''')
    source = once(source,'status = RunHardG13PairsTest(history, saved, controls, factors, projection, firstTarget, offset, direction, started, probes)',
                  'status = RunHardG14DirectionTest(history, saved, controls, factors, projection, firstTarget, offset, direction, started, probes)')
    start = source.index('Private Function RunHardG13PairsTest(')
    start = source.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,start)
    end = source.index('\nEnd Function',start)+len('\nEnd Function\n\n')
    addition = text((HERE/'Direction.bas').read_bytes())
    addition.encode('cp1251')
    return encode(source[:start]+source[end:]+'\n'+addition)


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready')
    cli.add_argument('--with-workbook',action='store_true')
    args = cli.parse_args()
    stage = args.destination.resolve()
    assert stage.is_relative_to(HERE) or stage.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(BASE.read_bytes()) == BASE_SHA
    inputs = {}
    with ZipFile(BASE) as archive:
        prior = json.loads(archive.read('Fixture.json'))
        stock = (REPO/prior['workbook']).read_bytes()
        assert sha(stock) == prior['source_workbook_sha256'] == BOOK_SHA
        receipt = archive.read('Native/Order10/Verification.json')
        trace = archive.read('Native/Order10/HardG13.csv')
        assert sha(receipt) == REPORT_SHA and json.loads(receipt)['native_trace_sha256'] == sha(trace)
        for name,raw in (('Prior/Verification.json',receipt),('Prior/HardG13.csv',trace),('G13Verify.py',archive.read('Verify.py'))):
            inputs[name] = seal(stage,name,raw)
        for path,expected in prior['inputs'].items():
            raw = archive.read(path)
            assert sha(raw) == expected, path
            if path in ('Expected.json','PriorVerify.py','FineVerify.py','F19Verify.py','Guard-IsolatedOffice.ps1','Run.ps1') or path.startswith(('src/','tools/')) or path == TEST:
                if path == SOLVER:
                    raw = solver(raw)
                elif path == TEST:
                    raw = encode(text(raw).replace('HardG13.csv','HardG14Direction.csv').replace('HARDSHEAR-G13;1','HARDSHEAR-G14-DIRECTION;1'))
                elif path == 'Run.ps1':
                    raw = text(raw).replace('HardG13','HardG14Direction').encode('utf-8')
                inputs[path] = seal(stage,path,raw)
    for path in ('Stage.py','Verify.py','Direction.bas'):
        inputs[path] = seal(stage,path,(HERE/path).read_bytes())
    if args.with_workbook:
        seal(stage,prior['workbook'],stock)
        seal(stage,'docs/regression/Diagnostic.xlsm',stock)
        for path in ('Temp','Native/Order10'):
            (stage/path).mkdir(parents=True,exist_ok=True)
    plan = {**prior,'inputs':inputs,'watchdog_seconds':150,'prior_report_sha256':REPORT_SHA,'prior_archive_sha256':BASE_SHA,
            'prior_compiled_workbook_sha256':json.loads(receipt)['proof']['compiled_workbook_sha256'],
            'scope':'one exact prior R2S baseline capture; no accepted state beyond G13; unchanged constitutive evaluation'}
    print(stage,seal(stage,'Fixture.json',(json.dumps(plan,indent=2)+'\n').encode('utf-8')))


if __name__ == '__main__':
    main()
