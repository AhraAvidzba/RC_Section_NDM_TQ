"""Reconstructs the exact late-steel native report and all inherited stage inputs."""

from base64 import b64decode,b64encode
from hashlib import sha256
import json
from zipfile import ZipFile

EVENT='ED564C3A1874FF25243EE7E4C64C1472146CC36D042D8EF17B79598C02493CAF'
SPLIT='F1D28250BD87A9F81445F8D650FF0F9E816433857B96DE0756FC0AECAA052461'
GROWTH='40B29680E2E73033519883545091BD201DC109430D405151D8EC5EBF97B99302'
STOCK='C452D2A59077C5DA5F6667DDD5ADF33778A0681F1B955A0E091FB08D8D2EE24F'
BASE='245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
BOOK='workbook/output/RC_Section_NDM.xlsm'
REPORT='Native/B/Both.txt'
PLAN='ABManifest.json'
DELTA='Native/B/Both.TraceDelta.json'
RECEIPT='ABVerification.json'
SUMS='SHA256SUMS.json'
CODE='docs/regression/CodeUpdate.json'
CHANGED={'src/Solver/CCoupledDeformationContinuation.cls','src/Solver/CCoupledNewtonSolver.cls',
         'src/Materials/CCoupledReinforcedResponse.cls'}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def json_bytes(value):
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()


def members(path,expected):
    assert digest(path.read_bytes())==expected,path
    with ZipFile(path) as z:
        return {n:z.read(n) for n in z.namelist()}


def baselines(split_path,growth_path,stock_path):
    split=members(split_path,SPLIT)
    growth=members(growth_path,GROWTH)
    stock=members(stock_path,STOCK)
    assert digest(split[REPORT])=='5CEBFB10C557E49304520FBCE6DFB3C466DE560AAF0F07FCB5892FF2D8FD5B49'
    return split,growth,stock


def spec(raw):
    assert digest(raw)==EVENT
    result=json.loads(raw)
    assert result['wide_split_archive_sha256']==SPLIT and result['inputs'][BOOK]==result['book_sha256']==BASE
    return result


def inherited(plan,previous):
    split,growth,stock=previous
    for name,d in plan['inputs'].items():
        if name==BOOK:
            continue
        if name=='PreviousB.json':
            options=(growth['ABVerification.json'],)
        elif name.startswith('StockPrior/'):
            options=(stock.get(name.removeprefix('StockPrior/')),)
        else:
            options=(split.get(name),growth.get(name),stock.get(name),split.get('SplitProofReplay.py') if name=='SplitProof.py' else None)
        for raw in options:
            if raw is not None and digest(raw)==d:
                yield name,raw
                break


def encode(old,new):
    reference={line:i for i,line in enumerate(old.splitlines(keepends=True))}
    records=[]
    reused=0
    for row in new.splitlines(keepends=True):
        found=reference.get(row)
        if found is not None:
            records.append(found)
            reused+=len(row)
        else:
            records.append(b64encode(row).decode('ascii'))
    assert reused>300000
    return {'baseline_sha256':digest(old),'new_sha256':digest(new),'reused_bytes':reused,'ordered_rows':records}


def decode(old,delta):
    assert digest(old)==delta['baseline_sha256']
    ref=old.splitlines(keepends=True)
    rows=[]
    for entry in delta['ordered_rows']:
        if isinstance(entry,int):
            assert 0<=entry<len(ref)
            rows.append(ref[entry])
        else:
            rows.append(b64decode(entry,validate=True))
    actual=b''.join(rows)
    assert digest(actual)==delta['new_sha256'] and encode(old,actual)==delta
    return actual


def restore(delta_pack,baseline):
    cfg=spec(delta_pack[PLAN])
    shared=dict(inherited(cfg,baseline))
    assert delta_pack.keys().isdisjoint(shared) and REPORT not in delta_pack
    result={**shared,**delta_pack}
    for name,expected in cfg['inputs'].items():
        if name!=BOOK:
            assert digest(result[name])==expected,name
    result[REPORT]=decode(baseline[0][REPORT],json.loads(result[DELTA]))
    return result
