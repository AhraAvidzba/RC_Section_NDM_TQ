' -------------------- ДЛЯ ТЕСТОВ --------------------
' Даёт для проверки только точную деформацию и невязки активного поля.
Friend Sub RecordLateSteelFieldTest(ByVal route As Long, ByVal ordinal As Long, ByVal point As Long, ByRef field() As Double)
    Dim response As CCoupledReinforcedResponse: Set response = mResponse
    Call TestRechartLog("EVS;" & CStr(route) & ";" & CStr(ordinal) & ";" & _
        TestRechartNumber(response.ReadLateSteelStrainTest(mSection, point, field)))
    Call TestRechartLog("EVW;" & CStr(route) & ";" & CStr(ordinal) & TestRechartVector(mResidual))
    Call TestRechartLog("EVE;" & CStr(route) & ";" & CStr(ordinal) & TestRechartVector(mExternal))
End Sub
