"""Проверяет диагностический первый переход и исходную позднюю классификацию."""
from collections import defaultdict
from math import isclose
from pathlib import Path
import re

from SplitProof import TARGET, grouped, maximum, nums


def verify(root,native):
    text=(root/'Native/B/Both.txt').read_text(encoding='utf-8-sig')
    lines=defaultdict(list)
    for raw in text.splitlines():
        key,*row=raw.split(';')
        if key.startswith('EV'):
            lines[key].append(row)
    setup,=lines['EVP']
    point,limit,index,probe_count,prior_max,start,finish=nums(setup)
    assert point==30 and limit==.0000792583568961 and (index,probe_count)==(22,51)
    assert start<finish and isclose(prior_max,native['lower_lambda'],rel_tol=1e-13)
    starts=grouped(lines,'EVA',1)
    restorations=grouped(lines,'EVR',1)
    bases=grouped(lines,'EVB',1)
    assert bases=={(r,):['1223','EXACT_EXCEPT_CENTER_GATE'] for r in (1,2)}
    assert starts.keys()==restorations.keys()=={(1,),(2,)}
    assert starts[1,]==starts[2,] and 0.<float(starts[1,][0])<1.
    assert starts[1,][1:]==['30','50']
    assert all(row==['23','1223','51','EXACT'] for row in restorations.values())
    results=grouped(lines,'EVT',2)
    strains=grouped(lines,'EVS',2)
    weak=grouped(lines,'EVW',2)
    load=grouped(lines,'EVE',2)
    fields=grouped(lines,'EVF',2)
    assert strains.keys()==results.keys()==weak.keys()==load.keys()==fields.keys()
    assert set(results)<={(1,1),(2,1),(2,2)}
    baseline=grouped(lines,'EVX',1)
    report={'point':int(point),'test_strain_limit':limit,'highest_admissible_prior_lambda':prior_max,
            'same_anchor_and_restored_B':True,'routes':{},'physical_limit_certified':False}
    for route in (1,2):
        path={}
        report['routes'][str(route)]=path
        probes=[]
        for key,row in sorted(results.items()):
            if key[0]!=route:
                continue
            _,k=key
            assert len(row)==21 and row[12]=='True'
            factor,target,actual,u,governing=nums(row[:5])
            above=row[5]=='True'
            n,g,tau,E,A,L=nums(row[6:12])
            abs_tol,rel_tol=nums(row[13:15])
            actual_force=nums(row[15:])
            strain,=nums(strains[key])
            w=nums(weak[key]); ext=nums(load[key])
            assert len(fields[key])==len(w)==len(ext)==60
            signed=[(a-factor*f)/s for a,f,s in zip(actual_force,TARGET,(A,A*L,A*L,A*L,A,A),strict=True)]
            assert isclose(target,start+(finish-start)*k/route,abs_tol=2e-17)
            assert isclose(tau,abs_tol+rel_tol*maximum(ext[:56]),abs_tol=2e-19)
            assert max(maximum(w[:56]),maximum(w[56:])*E,abs(actual-target)*E,maximum(signed))<=tau+2e-15
            assert n<=tau and g<=tau and 0<factor<prior_max
            assert strain>0. and governing==point and isclose(u,strain/limit,rel_tol=5e-13)
            assert above==(u>1.)
            probes.append(dict(step=k,lambda_value=factor,coordinate=actual,point=int(governing),
                               governing_strain=strain,utilization=u,above=above,
                               signed_force_residuals_MPa=signed,norm_MPa=n,tolerance_MPa=tau))
        path['probes']=probes
        refusals=[row for row in lines['EVQ'] if int(row[0])==route]
        if refusals:
            assert len(refusals)==1 and (route,) not in baseline
            path['findings']=['SOLVE_REFUSED',*refusals[0][1:]]
            continue
        ordinal,finished,critical,status,code,published,num_status,num_code,best,final_probes,*detail=baseline[route,]
        assert probes and int(ordinal)==probes[-1]['step']==route
        assert all(not p['above'] for p in probes[:-1]) and probes[-1]['above']
        assert published=='False' and isclose(float(best),prior_max,rel_tol=2e-13) and int(final_probes)<=96
        if finished=='True':
            assert critical=='30' and num_status==num_code=='True'
            assert detail and 'Арматурное событие:' in detail[0]
            hits=re.search(r'Координата деформации: \[([\-\d.Ee+]+), ([\-\d.Ee+]+)\]',detail[0])
            assert hits
            low,high=map(float,hits.groups())
            assert start<=low<high<=finish+2e-17
            path.update(findings=['LATE_NUMFAIL_NO_CAPACITY',*detail],control_bracket=[low,high])
        else:
            assert critical=='0' and not ''.join(detail)
            path['findings']=['REFINEMENT_REFUSED_WITH_NO_CAPACITY']
    return report
