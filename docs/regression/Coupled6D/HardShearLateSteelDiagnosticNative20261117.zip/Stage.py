"""Ставит диагностический порог только для двух проб позднего события HardShear."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SPLIT=ROOT/'tmp/hs-growth-split/ready'
REPLAY=ROOT/'tmp/hs-growth-split/SplitProofReplay.py'
BOOK='workbook/output/RC_Section_NDM.xlsm'
CONT='src/Solver/CCoupledDeformationContinuation.cls'
NEWTON='src/Solver/CCoupledNewtonSolver.cls'
STEEL='src/Materials/CCoupledReinforcedResponse.cls'
ARCH='F1D28250BD87A9F81445F8D650FF0F9E816433857B96DE0756FC0AECAA052461'
SPLIT_PLAN='0A2228943D99E6359C589C4443BE83FBB5534AE211C196FFC836FC3717899439'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def once(src,a,b):
    assert src.count(a)==1,a
    return src.replace(a,b)


def vba(src,helper):
    append=text((HERE/helper).read_bytes()).rstrip()
    append.encode('cp1251')
    output=src.rstrip()+'\n\n'+append+'\n'
    assert max(map(len,output.splitlines()))<1024
    return output.replace('\n','\r\n').encode('utf-8')


def overlay(name,raw):
    src=text(raw)
    if name==CONT:
        marker='    mYieldRecoveryProbes = priorYieldProbes: mFixedYieldRecoveryProbes = priorFixedProbes\n'
        # The original single/two-half case must restore B before the two isolated late checks.
        src=once(src,marker,marker+'    TestRunLateSteelPair history, anchor, coarse, acceptedCenter, acceptedPlus, acceptedMinus, _\n        seedCenter, seedPlus, seedMinus\n')
        return vba(src,'Event.bas')
    if name==STEEL:
        marker='Private mTrialSteelUtilization As Double\n'
        src=once(src,marker,marker+'Private mLateSteelTestPoint As Long, mLateSteelTestLimit As Double\n')
        marker='        utilization = mSteel(point).StrainUtilization(axialStrain)\n'
        src=once(src,marker,marker+'''
        If point = mLateSteelTestPoint And axialStrain > 0# Then
            utilization = axialStrain / mLateSteelTestLimit
        End If
''')
        return vba(src,'Reinforcement.bas')
    if name==NEWTON:
        return vba(src,'Newton.bas')
    return raw


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready2')
    cli.add_argument('--with-workbook',action='store_true')
    args=cli.parse_args()
    dst=args.destination.resolve()
    assert dst.is_relative_to(HERE) or dst==Path('D:/CodexScratch/RC_Section_NDM_TQ/HardGrowthEvent').resolve()
    archive=ROOT/'tmp/hs-growth-split/proof/HardShearCoarseGrowthSplitNative20261117.zip'
    assert sha(archive.read_bytes())==ARCH
    manifest=(SPLIT/'ABManifest.json').read_bytes()
    assert sha(manifest)==SPLIT_PLAN
    base=json.loads(manifest)
    files={}
    changes={CONT,NEWTON,STEEL}
    for name,digest in base['inputs'].items():
        if name in (BOOK,'Stage.py'):
            continue
        raw=(SPLIT/name).read_bytes()
        assert sha(raw)==digest,name
        files[name]=overlay(name,raw) if name in changes else raw
    files['SplitProof.py']=REPLAY.read_bytes()
    verifier=text(files['Verify-FullAB.py'])
    verifier=once(verifier,base['inputs'][CONT],sha(files[CONT]))
    verifier=once(verifier,'    out = HERE / "ABVerification.json"',
                  '    import EventProof\n    comparison["late_steel_test"] = EventProof.verify(HERE,b)\n'
                  '    out = HERE / "ABVerification.json"')
    files['Verify-FullAB.py']=verifier.encode()
    files['Run-FullAB.ps1']=text(files['Run-FullAB.ps1']).replace('HardGrowthSplit','HardGrowthEvent').encode()
    for name in ('Stage.py','EventProof.py','Event.bas','Newton.bas','Reinforcement.bas'):
        files[name]=(HERE/name).read_bytes()
    plan={**base,'inputs':{name:sha(data) for name,data in files.items()}|{BOOK:base['book_sha256']},
          'wide_split_archive_sha256':ARCH,'scope':'late isolated proof threshold at center transverse p30, original mechanics'}
    files['ABManifest.json']=(json.dumps(plan,indent=2)+'\n').encode()
    if args.with_workbook:
        book=(ROOT/BOOK).read_bytes()
        assert sha(book)==base['book_sha256']
        files[BOOK]=book
        files[base['draft']]=book
        for name in ('Temp','Native/B'):
            (dst/name).mkdir(parents=True,exist_ok=True)
    for name,data in files.items():
        output=dst/name
        output.parent.mkdir(parents=True,exist_ok=True)
        if output.exists():
            assert output.read_bytes()==data,name
        else:
            output.write_bytes(data)
    print('HARDSHEAR LATE STEEL INPUTS: PASS',dst,sha(files['ABManifest.json']),sha(files[CONT]))


if __name__=='__main__':
    main()
