' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет позднее событие при исходном законе в отдельном объекте
' продолжения. Принятая история основной ветви восстанавливается побитово.
Private Sub TestRunLateSteelPair(ByVal history As Collection, ByRef anchor As TBranchPoint, ByRef coarse As TBranchPoint, _
        ByRef center() As Double, ByRef plus() As Double, ByRef minus() As Double, _
        ByRef anchorCenter() As Double, ByRef anchorPlus() As Double, ByRef anchorMinus() As Double)
    Const POINT As Long = 30, LIMIT As Double = 0.0000792583568961
    Dim experiment As CCoupledDeformationContinuation, route As Long, i As Long
    Dim prefix As Collection, entry As Variant
    Call TestRechartLog("EVP;" & CStr(POINT) & ";" & TestRechartNumber(LIMIT) & ";" & _
        CStr(anchor.HistoryIndex) & ";" & CStr(mProbeCount) & ";" & TestRechartNumber(mBestLambda) & ";" & _
        TestRechartNumber(anchor.Coordinate) & ";" & TestRechartNumber(coarse.Coordinate))
    For route = 1 To 2
        Set prefix = New Collection
        For i = 1 To anchor.HistoryIndex: entry = history.Item(i): prefix.Add entry: Next i
        Set experiment = New CCoupledDeformationContinuation
        mReinforcement.SetLateSteelScreenTest POINT, LIMIT
        experiment.TestRunLateSteelArm mSolver, mReinforcement, prefix, route, POINT, anchor.Coordinate, anchor.Lambda, _
            coarse.Coordinate, mProjection, mOffset, mDirection, mMaxIterations, mAbsTol, mRelTol, mLambdaTolerance, _
            mMaximumLambda, mBestLambda, mLocalPeak, mProbeCount - 1, mDesignHistoryIndex, mUsesYieldControl, _
            anchorCenter, anchorPlus, anchorMinus
        mReinforcement.SetLateSteelScreenTest 0, 0#
        If Not mSolver.ReplayAcceptedFields(history, history.Count) Then _
            Err.Raise 5, "TestRunLateSteelPair", "Не восстановлена основная ветвь."
        Dim field() As Double, expected() As Double
        Dim actualCenter() As Double, actualPlus() As Double, actualMinus() As Double
        mSolver.CopyAccepted field: expected = history.Item(history.Count)
        mSolver.TestCopyRefinementHistory actualCenter, actualPlus, actualMinus
        If Not TestSameGrowthArray(field, expected) Or Not TestSameGrowthArray(actualCenter, center) Or _
                Not TestSameGrowthArray(actualPlus, plus) Or Not TestSameGrowthArray(actualMinus, minus) Then _
            Err.Raise 5, "TestRunLateSteelPair", "Диагностический порог изменил основное принятое состояние."
        Call TestRechartLog("EVR;" & CStr(route) & ";" & CStr(history.Count) & ";" & CStr(UBound(center)) & _
            ";" & CStr(mProbeCount) & ";EXACT")
    Next route
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прослеживает широкую пробу либо два равных полушага и вызывает штатное
' уточнение только на первом наблюдённом превышении тестового порога.
Friend Sub TestRunLateSteelArm(ByVal solver As CCoupledNewtonSolver, ByVal reinforcement As CCoupledReinforcedResponse, _
        ByVal history As Collection, ByVal route As Long, ByVal steelPoint As Long, ByVal anchorCoordinate As Double, _
        ByVal anchorLambda As Double, ByVal rightCoordinate As Double, ByRef projection() As Double, _
        ByRef offset() As Double, ByRef direction() As Double, ByVal maxIterations As Long, ByVal absoluteTolerance As Double, _
        ByVal relativeTolerance As Double, ByVal lambdaTolerance As Double, ByVal maximumLambda As Double, _
        ByVal previousMaximum As Double, ByVal localPeak As Double, ByVal probes As Long, ByVal designIndex As Long, _
        ByVal consistentControl As Boolean, ByRef anchorCenter() As Double, ByRef anchorPlus() As Double, _
        ByRef anchorMinus() As Double)
    Set mSolver = solver: Set mReinforcement = reinforcement: Set mMeta = New CResultMeta
    mProjection = projection: mOffset = offset: mDirection = direction
    mProbeCount = probes: mDesignHistoryIndex = designIndex
    mMaxIterations = maxIterations: mMaximumLambda = maximumLambda: mLambdaTolerance = lambdaTolerance
    mAbsTol = absoluteTolerance: mRelTol = relativeTolerance: mBestLambda = previousMaximum: mLocalPeak = localPeak
    mFollowingLocalPeak = True: mUsesYieldControl = consistentControl
    If Not mSolver.ReplayAcceptedFields(history, history.Count) Then _
        Err.Raise 5, "TestRunLateSteelArm", "Исходная ветвь пробы не воспроизведена."
    Dim actualCenter() As Double, actualPlus() As Double, actualMinus() As Double, word As Long
    mSolver.TestCopyRefinementHistory actualCenter, actualPlus, actualMinus
    If UBound(actualCenter) <> 1223 Then _
        Err.Raise 5, "TestRunLateSteelArm", "Не подтверждён формат истории якоря."
    For word = 1 To UBound(actualCenter)
        Select Case word
            Case 1164, 1165, 1168, 1169
                actualCenter(word) = anchorCenter(word) ' Служебные максимум и точка диагностики, по центру и группе хомутов.
        End Select
    Next word
    If Not TestSameGrowthArray(actualCenter, anchorCenter) Or Not TestSameGrowthArray(actualPlus, anchorPlus) Or _
            Not TestSameGrowthArray(actualMinus, anchorMinus) Then _
        Err.Raise 5, "TestRunLateSteelArm", "Механическая история якоря изменилась при включении тестовой метки."
    Call TestRechartLog("EVB;" & CStr(route) & ";1223;EXACT_EXCEPT_CENTER_GATE")
    Dim prior As TBranchPoint, trial As TBranchPoint, stepNo As Long, coordinate As Double
    Dim field() As Double, actual() As Double, solved As Boolean, exceeded As Boolean
    Dim finished As Boolean, established As Boolean
    prior.Coordinate = anchorCoordinate: prior.Lambda = anchorLambda: prior.HistoryIndex = history.Count
    Call TestRechartLog("EVA;" & CStr(route) & ";" & TestRechartNumber(mReinforcement.AcceptedSteelUtilization) & _
        ";" & CStr(mReinforcement.AcceptedSteelCriticalPoint) & ";" & CStr(mProbeCount))
    For stepNo = 1 To route
        coordinate = anchorCoordinate + (rightCoordinate - anchorCoordinate) * stepNo / route
        trial.Coordinate = coordinate
        solved = Probe(trial, prior.Lambda)
        If solved Then solved = UpdateTrialCoordinate(trial, prior.Coordinate)
        If Not solved Then
            Call TestRechartLog("EVQ;" & CStr(route) & ";" & CStr(stepNo) & ";SOLVE_REFUSED;" & _
                Replace(mProbeDetails, ";", "|"))
            Exit For
        End If
        mSolver.CopyTrial field, actual
        exceeded = BeyondSteelLimit()
        Call TestRechartLog("EVT;" & CStr(route) & ";" & CStr(stepNo) & ";" & TestRechartNumber(trial.Lambda) & ";" & _
            TestRechartNumber(coordinate) & ";" & TestRechartNumber(trial.Coordinate) & ";" & _
            TestRechartNumber(mReinforcement.TrialSteelUtilization) & ";" & CStr(mReinforcement.TrialSteelCriticalPoint) & ";" & _
            CStr(exceeded) & ";" & mSolver.TestReadRechartCriteria(prior.Lambda, mAbsTol, mRelTol) & TestRechartVector(actual))
        Call TestRechartLog("EVF;" & CStr(route) & ";" & CStr(stepNo) & TestRechartVector(field))
        mSolver.RecordLateSteelFieldTest route, stepNo, steelPoint, field
        If exceeded Then
            finished = ResolveSteelCrossing(history, prior, trial)
            established = Not mLimitFields Is Nothing
            Call TestRechartLog("EVX;" & CStr(route) & ";" & CStr(stepNo) & ";" & CStr(finished) & ";" & _
                CStr(mSteelEventPoint) & ";" & CStr(mMeta.InternalStatus) & ";" & CStr(mMeta.ResultCode) & ";" & _
                CStr(established) & ";" & CStr(mMeta.InternalStatus = rsNumericalFailure) & ";" & _
                CStr(mMeta.ResultCode = rcNumericalFailure) & ";" & TestRechartNumber(mBestLambda) & ";" & CStr(mProbeCount) & ";" & _
                Replace(mSteelEventDetails, ";", "|"))
            Exit For
        End If
        AcceptPoint history, trial: prior = trial
    Next stepNo
    mSolver.DiscardStep
End Sub
