"""Запечатывает нативный опыт позднего события без книги и повторов исходных логов."""
from argparse import ArgumentParser
from pathlib import Path
from runpy import run_path
from subprocess import PIPE,run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED,ZipFile,ZipInfo

import PortableSupport as p

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ARCH=ROOT/'docs/regression/Coupled6D'
DEFAULT_SPLIT=ROOT/'tmp/hs-growth-split/proof/HardShearCoarseGrowthSplitNative20261117.zip'
DEFAULT_GROWTH=ARCH/'HardShearCoarseGrowthWorkbookNative20261117.zip'
DEFAULT_STOCK=ARCH/'HardShearInstalledStockTiming20261117.zip'
NAME='HardShearLateSteelDiagnosticNative20261117'


def collect(source,baseline,receipt_sha):
    plan=p.spec((source/p.PLAN).read_bytes())
    shared=dict(p.inherited(plan,baseline))
    files=[p.PLAN,p.RECEIPT,p.CODE,'Compile.log','CompileClosure.json','Run.ndjson']
    files.extend(n for n in plan['inputs'] if n!=p.BOOK and n not in shared)
    files.extend(path.relative_to(source).as_posix() for path in sorted((source/'Native/B').iterdir()) if path.is_file())
    assert len(set(files))==len(files)
    data={name:(source/name).read_bytes() for name in files}
    for name,digest in plan['inputs'].items():
        if name!=p.BOOK:
            raw=shared[name] if name in shared else data[name]
            assert p.digest(raw)==digest and raw==(source/name).read_bytes()
    assert p.digest(data[p.RECEIPT])==receipt_sha.upper()
    report=data.pop(p.REPORT)
    fixture=next(line.rsplit('; file=',1)[1] for line in report.decode('utf-8-sig').splitlines()
                 if line.startswith('RESULTS_SAVE_REOPEN: '))
    book=Path(fixture).resolve()
    assert book.is_relative_to(source.resolve()/'Temp') and book.name=='RC_Section_NDM_saved.xlsm'
    curve=run_path(str(ROOT/'tmp/hs-growth-probe/ReadWorkbookCurve.py'))['read_curve']
    data['EventWorkbookCurve.json']=p.json_bytes(curve(book))
    data[p.DELTA]=p.json_bytes(p.encode(baseline[0][p.REPORT],report))
    for name in ('Pack.py','Verify-Portable.py','PortableSupport.py','README-Portable.md'):
        data[name]=(HERE/name).read_bytes()
    data[p.SUMS]=p.json_bytes(dict(sorted((name,p.digest(raw)) for name,raw in data.items())))
    return data


def write_once(file,content):
    if file.exists():
        assert file.read_bytes()==content
    else:
        file.write_bytes(content)


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('source',type=Path)
    cli.add_argument('receipt_sha')
    cli.add_argument('--split',type=Path,default=DEFAULT_SPLIT)
    cli.add_argument('--growth',type=Path,default=DEFAULT_GROWTH)
    cli.add_argument('--stock',type=Path,default=DEFAULT_STOCK)
    args=cli.parse_args()
    paths=[path.resolve() for path in (args.split,args.growth,args.stock)]
    data=collect(args.source,p.baselines(*paths),args.receipt_sha)
    out=HERE/'proof'
    out.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix='portable-',dir=out) as name:
        scratch=Path(name)
        path=scratch/'candidate.zip'
        with ZipFile(path,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
            for key,raw in sorted(data.items()):
                entry=ZipInfo(key,date_time=(2026,11,17,0,0,0))
                entry.create_system=3
                entry.external_attr=0o100644<<16
                z.writestr(entry,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
        extracted=scratch/'extracted'
        with ZipFile(path) as z:
            z.extractall(extracted)
        replay=run([sys.executable,'-B','-X','utf8','Verify-Portable.py',*map(str,paths)],
                   cwd=extracted,stdout=PIPE,check=True).stdout
        payload=path.read_bytes()
        sha=p.digest(payload)
        write_once(out/(NAME+'.zip'),payload)
        write_once(out/(NAME+'.zip.sha256'),f'{sha} *{NAME}.zip\n'.encode())
        write_once(out/(NAME+'.replay.txt'),replay)
    print(out/(NAME+'.zip'),sha,len(payload))
    print(replay.decode('utf-8').splitlines()[-1])


if __name__=='__main__':
    main()
