' -------------------- ДЛЯ ТЕСТОВ --------------------
' Переоценивает только положительное удлинение выбранной арматурной точки.
' Закон напряжений, жёсткость и параметры материала читаются штатно.
Friend Sub SetLateSteelScreenTest(ByVal point As Long, ByVal limit As Double)
    mLateSteelTestPoint = point: mLateSteelTestLimit = limit
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает фактическую деформацию также через штатную ось стержня.
Friend Function ReadLateSteelStrainTest(ByVal operators As CCoupledElasticState, ByVal point As Long, _
        ByRef field() As Double) As Double
    Dim strain As Double, limit As Double
    ReadSteelStrain operators, point, field, strain, limit
    ReadLateSteelStrainTest = strain
End Function
