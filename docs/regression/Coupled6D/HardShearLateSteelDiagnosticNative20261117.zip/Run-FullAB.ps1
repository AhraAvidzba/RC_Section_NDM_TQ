# Run the fixed HardShear comparison with one isolated Office process per phase.
param(
    [ValidateSet('Inputs','Compile','Native','Verify')][string]$Phase='Inputs',
    [switch]$FreshA
)

$ErrorActionPreference='Stop'
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$abOriginalTemp=$env:TEMP
$abOriginalTmp=$env:TMP
$stage='D:\CodexScratch\RC_Section_NDM_TQ\HardGrowthEvent'
if ((Resolve-Path -LiteralPath $PSScriptRoot).Path -ine $stage) {throw 'Unexpected HardShear stage.'}
if ($FreshA -and $Phase -ne 'Native') {throw 'FreshA applies only to Native.'}
Push-Location -LiteralPath $stage
try {
    $verification = switch ($Phase) {
        'Inputs' { '--inputs' }
        'Compile' { '--inputs' }
        'Native' { '--compiled' }
        'Verify' { '--native' }
    }
    python -B -X utf8 './Verify-FullAB.py' $verification
    if ($LASTEXITCODE) {throw "AB preflight failed for $Phase."}
    if ($Phase -in 'Inputs','Verify') {return}

    . './Guard-IsolatedOffice.ps1'
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    $plan=Get-Content -LiteralPath 'ABManifest.json' -Raw | ConvertFrom-Json
    if ($Phase -eq 'Compile') {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Get-FileHash -LiteralPath $plan.draft).Hash -cne $plan.book_sha256) {
            throw 'Compile requires a clean private copy.'
        }
        Assert-IsolatedOfficeReady 'CompileHardGrowthEvent'
        & './tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $plan.draft -ModuleNames CCoupledDeformationContinuation,CCoupledNewtonSolver,CCoupledConcreteResponse,CCoupledReinforcedResponse,modTestCoupledElasticState |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
        python -B -X utf8 './Verify-FullAB.py' --compiled
        if ($LASTEXITCODE) {throw 'Compile receipt could not be verified.'}
        return
    }

    $report='Native/B/Both.txt'
    if (Test-Path -LiteralPath $report) {throw 'Candidate report already exists.'}
    if ($FreshA -and !(Test-Path -LiteralPath 'Native/Both.txt')) {& './Run-Stock.ps1'}
    if ($FreshA) {
        python -B -X utf8 './Verify-FullAB.py' --fresh-stock
        if ($LASTEXITCODE) {throw 'Fresh installed-workbook run could not be verified.'}
    }
    Assert-IsolatedOfficeReady 'RunHardGrowthEvent'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $plan.draft -ReportPath $report `
        -Macro 'modTestCoupledElasticState.RunTestWideSplit' -MacroArgument1 Both -MacroArgument2 Excel `
        -Mode No -TimeoutSeconds 170 -FailFast -VerifyResultsReopen
    if ($LASTEXITCODE) {throw "Candidate watchdog exited with code $LASTEXITCODE."}
    $fixture=@(Get-Content -LiteralPath $report -Encoding utf8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixture.Count -ne 1) {throw 'An owned fixture was not reported.'}
    $directory=Split-Path -Parent $fixture[0].Substring('FIXTURE: '.Length)
    if (!$directory.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Fixture is outside Temp.'}
    Copy-Item -LiteralPath (Join-Path $directory 'RC_Section_NDM_execution_report.txt') -Destination 'Native/B/Both.Execution.txt'
    python -B -X utf8 './Verify-FullAB.py' --native
    if ($LASTEXITCODE) {throw 'AB native checks failed.'}
} finally {
    $env:TEMP=$abOriginalTemp
    $env:TMP=$abOriginalTmp
    Pop-Location
}
