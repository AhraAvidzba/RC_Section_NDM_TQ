"""Сверяет архив позднего события, нативную квитанцию и сохранённый путь."""
from argparse import ArgumentParser
import json
from pathlib import Path,PureWindowsPath
import re
from runpy import run_path
import sys
from tempfile import TemporaryDirectory

import PortableSupport as p

HERE=Path(__file__).resolve().parent


def safe(name):
    path=Path(name)
    assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
    assert path.suffix.lower()!='.xlsm'
    return path


def replay(folder,baseline):
    plan=p.spec((folder/p.PLAN).read_bytes())
    code=json.loads((folder/p.CODE).read_bytes())
    close=json.loads((folder/'CompileClosure.json').read_bytes())
    logs=(folder/'Compile.log').read_text(encoding='utf-8-sig').splitlines()
    assert code['Compiled'] and not code['ProductionChanged'] and code['ProductionSHA256']==p.BASE
    assert sorted(code['Modules'])==sorted(plan['modules'])
    assert close['State']=='Absent' and logs.count(f"OWNED_EXCEL: id={close['PID']}; utcStartTicks={close['StartTicksUTC']}")==1
    assert PureWindowsPath(code['Workbook'])==PureWindowsPath(
        r'D:\CodexScratch\RC_Section_NDM_TQ\HardGrowthEvent\docs\regression\Diagnostic.xlsm'
    )
    phases=[json.loads(line) for line in (folder/'Run.ndjson').read_text(encoding='utf-8-sig').splitlines()]
    assert [m['phase'] for m in phases]==['CompileHardGrowthEvent','RunHardGrowthEvent']
    own=json.loads((folder/'Native/B/Both.txt.Ownership.json').read_bytes())
    assert all(proc['ProtectedUser'] and proc['Id'] not in [close['PID'],own['PID']] for phase in phases for proc in phase['excel'])
    original_split,growth,stock=baseline
    stage=run_path(str(folder/'Stage.py'))
    for name in p.CHANGED:
        assert stage['overlay'](name,original_split[name])==(folder/name).read_bytes(),name
    check=run_path(str(folder/'Verify-FullAB.py'))
    a=check['stock'](folder,False)
    b=check['native'](folder/'Native/B',code['WorkbookSHA256'])
    trace=(folder/'Native/B/Both.Execution.txt').read_text(encoding='utf-16')
    pair,=set(re.findall(r'GrowthTestAcceptedBeyondDouble=(\d+); GrowthTestFinalLambda=([\d.,Ee+-]+)',trace))
    measures={'accepted_beyond_double':int(pair[0]),'last_positive_lambda':check['number'](pair[1])}
    folder_key=str(folder)
    sys.path.insert(0,folder_key)
    try:
        split=run_path(str(folder/'SplitProof.py'))['verify'](folder,b,measures)
        late=run_path(str(folder/'EventProof.py'))['verify'](folder,b)
    finally:
        assert sys.path.pop(0)==folder_key
    checked={'stock_source':'archive §490','A':a,'B':b,'matched_runtime_delta_s':None,
             'continuation':measures,'wide_split':split,'late_steel_test':late}
    native=json.loads((folder/p.RECEIPT).read_bytes())
    assert checked==native
    old=json.loads(growth['CandidateWorkbookCurve.json'])
    ref=json.loads(original_split['InstrumentedWorkbookCurve.json'])
    saved=json.loads((folder/'EventWorkbookCurve.json').read_bytes())
    assert saved['entries']==old['entries']==ref['entries'] and len(saved['entries'])==136
    assert saved['named_anchor']==ref['named_anchor'] and saved['worksheet']==ref['worksheet']
    assert late['same_anchor_and_restored_B'] and not late['physical_limit_certified']
    return dict(verified_saved_B_curve_rows=136,saved_event_workbook_sha256=saved['saved_workbook_sha256'],
                compiled_workbook_sha256=code['WorkbookSHA256'],native_late_steel=late)


def verify(root,baseline):
    checks=json.loads((root/p.SUMS).read_bytes())
    archive={path.relative_to(root).as_posix():path.read_bytes() for path in root.rglob('*') if path.is_file()}
    assert archive.keys()==checks.keys()|{p.SUMS}
    for n,d in checks.items():
        safe(n)
        assert p.digest(archive[n])==d,n
    files=p.restore(archive,baseline)
    with TemporaryDirectory(prefix='late-steel-expanded-',dir=root.parent) as name:
        work=Path(name)
        for key,data in files.items():
            out=work/safe(key)
            out.parent.mkdir(parents=True,exist_ok=True)
            out.write_bytes(data)
        result=replay(work,baseline)
    print(p.json_bytes(result).decode().strip())
    cases=[result['native_late_steel']['routes'][key]['findings'][0] for key in ('1','2')]
    print(f'HARDSHEAR_LATE_STEEL_PORTABLE: VERIFIED_EVIDENCE; FULL={cases[0]}; HALF={cases[1]}; physical_limit_certified=False')


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('split',type=Path)
    cli.add_argument('growth',type=Path)
    cli.add_argument('stock',type=Path)
    args=cli.parse_args()
    verify(HERE,p.baselines(args.split,args.growth,args.stock))
