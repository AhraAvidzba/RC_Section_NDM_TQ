"""ДЛЯ ТЕСТОВ: независимо повторяет ветвь общего продолжения и проверяет её подтверждённую границу."""
from argparse import ArgumentParser
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestValidate(repo,root,phase,output,start_count=74):
    """Использует полный нативный путь, включая уточнённые плечи; никакой чужой истории не подставляет."""
    here=Path(__file__).resolve().parent
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        for target,source in (('Operators.csv',phase+'.Operators.csv'),('MVTGaussMixed.csv',phase+'.csv'),
                              ('MVTGaussMixed.Tensor.csv',phase+'.Tensor.csv')):
            (scratch/target).write_bytes((root/'Native'/source).read_bytes())
        section,history,fields=run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo,scratch,scratch/'Mechanics.json')
        proof=json.loads((scratch/'Mechanics.json').read_bytes())
    log=(root/'Native'/(phase+'.txt')).read_text('utf-8-sig')
    counts=re.findall(r'^PRODUCTION_PATH_COUNT;(\d+)$',log,re.M)
    assert len(counts)==1 and len(fields)==int(counts[0])
    reported=re.findall(r'наибольший допустимый lambda: ([\d.,E+-]+)',log)
    assert len(reported)==1
    best=float(reported[0].replace(',','.'))*75000.
    maximum=max(row['target_N_Nmm'][5] for row in proof['states'])
    assert abs(best-maximum)<1e-6,(best,maximum)
    for row in proof['states']:
        n,mx,my,torque,qx,qy=row['target_N_Nmm']
        assert n==my==qx==0.
        assert 0.<=torque<=10510000.
        assert abs(mx+396.*qy)<1e-5
    assert 'равновесие при lambda = 1 подтверждено: True' in log
    assert any(abs(row['target_N_Nmm'][5]-75000.)<1e-7 and row['target_N_Nmm'][3]==10510000. for row in proof['states'])
    name='средний инженерный сдвиг по направлению изменяемой поперечной силы'
    steady=('Мера деформации: '+name+';') in log and 'мера после локального максимума' not in log
    control_increments=[]
    if len(fields)>start_count and steady:
        projection=np.einsum('p,pd->d',section.weight[:section.TestConcreteCount],section.b[0,:section.TestConcreteCount,5,:])/57600.
        coordinates=np.asarray([projection@field for _,field in fields[start_count-1:]])
        control_increments=np.diff(coordinates).tolist()
        assert all(value>0. for value in control_increments),control_increments
    last=fields[-1][1]; strain=(section.b@last)[:,:section.TestConcreteCount]
    tensor=np.zeros((*strain.shape[:-1],3,3))
    for i in range(3): tensor[...,i,i]=strain[...,i]
    for index,(a,b) in enumerate(((0,1),(0,2),(1,2)),3): tensor[...,a,b]=tensor[...,b,a]=.5*strain[...,index]
    eigen=np.linalg.eigvalsh(tensor); steel=(section.a@last).reshape(3,section.TestSteelCount)
    compression=section.curves[1]
    proof.update({'native_phase':phase,'new_states_after_given_prefix':len(fields)-start_count,
        'reported_best_Qy_N':best,'maximum_Qy_N':maximum,'steady_shear_measure':steady,
        'minimum_positive_control_increment':min(control_increments) if control_increments else None,
        'individual_control_targets_recorded':False,'physical_capacity_certified':False,
        'final_material_measures':{'compression_coordinate':float(np.max(history[2][1,:,:section.TestConcreteCount])),
            'compression_backbone_peak_coordinate':float(compression.x[int(np.argmax(compression.nominal))]),
            'minimum_principal_concrete_strain':float(np.min(eigen)),'maximum_principal_concrete_strain':float(np.max(eigen)),
            'maximum_longitudinal_bar_strain':float(np.max(np.abs(steel[:,:4]))),'maximum_hoop_strain':float(np.max(np.abs(steel[:,4:])))}})
    output.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('GENERAL CONTINUATION ALL SIX EQUILIBRIA AND RETAINED LOAD BOUND VERIFIED',len(fields),maximum,flush=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--phase',choices=('Trace74','Trace44','Trace44Extended'),default='Trace74'); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); TestValidate(args.repo.resolve(),args.root.resolve(),args.phase,args.out.resolve(),74 if args.phase=='Trace74' else 44)
