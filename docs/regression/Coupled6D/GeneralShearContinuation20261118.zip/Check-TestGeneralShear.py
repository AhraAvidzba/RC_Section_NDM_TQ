"""ДЛЯ ТЕСТОВ: проверяет общий сдвиговый поиск, фактическую книгу и независимые уравнения."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


def TestRead(file):
    """Читает точные значения JSON и отрицательные статусы."""
    return json.loads(file.read_text('utf-8-sig'))


def TestFiles(root):
    """Проверяет закрепление каждого файла до работы проверяющего сценария."""
    for name,expected in TestRead(root/'Files.json').items(): assert sha256((root/name).read_bytes()).hexdigest().upper()==expected,name


def TestNative(repo,root,output):
    """Декодирует все компоненты, проверяет статусы, память, закрытие Excel и чистое восстановление."""
    TestFiles(root)
    shared=run_path(str(root/'Check-TestMaterialRoundoff.py'))
    source,_=run_path(str(root/'Verify-TestReducedEvidence.py'))['TestSource'](repo,root)
    helper,body,reader=run_path(str(root/'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _,original=reader(BytesIO(source)); records={}
    for key in TestRead(root/'Cases.json'):
        folder=root/'Cases'/key
        record=shared['TestSourceComparison'](repo,root,folder,source,original,helper,body,reader)
        compiler=TestRead(folder/'docs/regression/CodeUpdate.json'); reports={}
        for log in sorted((folder/'Native').glob('*.txt')):
            text=log.read_text('utf-8-sig'); phase=log.stem
            closure=TestRead(log.with_name(log.name+'.ProcessClosure.json')); owner=TestRead(log.with_name(log.name+'.Ownership.json'))
            if phase=='Trace44':
                assert key in ('BeforeObserver','Final') and closure['Stage']=='TIMEOUT' and not closure['Passed']
                assert closure['After']['State']=='Absent' and closure['ExactOwnExcelStopRequestedOnlyByExplicitTimeout']
                identity=closure['Identity']
                assert owner['PID']==identity['PID'] and int(owner['StartTicksUTC'])==identity['Ticks']
                assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==compiler['WorkbookSHA256']
                reports[phase]={'scope_execution_completed':False,'watchdog_timeout':True,'physical_capacity_certified':False}
                continue
            assert closure['Passed'] and closure['ChildExitCode']==0 and closure['RunnerCleanupValid']
            assert closure['Closure']['FinalState']['State']=='Absent'
            identity=closure['Closure']['Identity']; assert owner['PID']==identity['PID'] and int(owner['StartTicksUTC'])==identity['Ticks']
            assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==compiler['WorkbookSHA256']
            assert 'RUNTIME ERROR:' not in text and 'SOURCE_UNCHANGED: True' in text
            totals=[tuple(map(int,row)) for row in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)',text,re.M)]
            assert totals and all(failed==0 for passed,failed in totals)
            if phase=='Core': assert sum(passed for passed,failed in totals)==365
            if phase=='Material': assert totals==[({'Initial':348,'RecentSeed':349,'BeforeObserver':349,'Final':353}[key],0)]
            if phase=='Trace74':
                counts=re.findall(r'^PRODUCTION_PATH_COUNT;(\d+)$',text,re.M)
                assert counts==[str({'Initial':74,'RecentSeed':102,'BeforeObserver':108}[key])]
                assert 'до подтверждения физического предела' in text
            if phase=='Trace44Extended':
                assert key=='Final' and re.findall(r'^PRODUCTION_PATH_COUNT;(\d+)$',text,re.M)==['73']
                scope=TestRead(folder/'Native/Trace44Extended.Scope.json')
                assert scope['Original240SecondScopePassed'] is False and scope['SpeedAcceptancePassed'] is False
                assert scope['MaximumProbes']==96 and scope['ObservationSeconds']==480
            if phase=='Stock':
                assert totals==[(28,0)]
                assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10460833943358; limit=;' in text
                assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;',text,re.M)
                reports['stock_seconds']=float(re.search(r'^TIMING_SECONDS: ([\d.]+)',text,re.M)[1])
            reports[phase]={'assertions':sum(passed for passed,failed in totals),'scope_execution_completed':True}
        safety=[json.loads(line) for line in (folder/'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB']>=6500 and row['freeCommitGiB']>=6 for row in safety)
        blocked=[]
        for row in safety:
            unknown=[item for item in row['excel'] if not item['ProtectedUser']]
            if unknown:
                assert key=='Final' and row['phase']=='CompileWorkingASD' and len(unknown)==1 and unknown[0]['Id']==17632
                observed=TestRead(folder/'TransientExcelObservation.json')
                assert observed['PID']==17632 and observed['State']=='Absent' and observed['ClosedByAgent'] is False
                assert row['utc']<observed['ObservedUTC']<safety[1]['utc']
                blocked.append({'phase':row['phase'],'unknown_process':17632,'started_before_retry':False})
        record['preserved_preflight_blocks']=blocked
        record['reports']=reports; records[key]=record
    for folder in sorted((root/'FailedCompile').iterdir()):
        assert TestRead(folder/'CompileFailureClosure.json')['State']=='Absent'
        assert 'COMPILE_LOCATION:' in (folder/'Compile.log').read_text('utf-8-sig')
    final=root/'Cases/Final'; scope=TestRead(final/'Preparation.json')['directed_scope']
    assert scope=={'trace':'Trace74','maximum_probe_count':96,'observation_seconds':480,'full_acceptance':False}
    restored={}
    with TemporaryDirectory() as scratch:
        target=Path(scratch)/'Restored'; target.mkdir(); prep=TestRead(final/'Preparation.json')
        for name,expected in prep['inputs'].items():
            raw=source if name=='workbook/output/RC_Section_NDM.xlsm' else (final/name).read_bytes()
            file=target/name; file.parent.mkdir(parents=True,exist_ok=True); file.write_bytes(raw)
            assert sha256(file.read_bytes()).hexdigest().upper()==expected,name
        (target/'Preparation.json').write_bytes((final/'Preparation.json').read_bytes())
        for name in ('Native','Temp','docs/regression'): (target/name).mkdir(parents=True,exist_ok=True)
        (target/'docs/regression/Diagnostic.xlsm').write_bytes(source)
        restored={'inputs':len(prep['inputs']),'source_book_sha256':sha256(source).hexdigest().upper(),
                  'excel_started':False,'compiled_or_calculated_state_reused':False}
    result={'cases':records,'clean_input_restoration':restored,'full_acceptance_completed':False,
            'physical_capacity_certified':False,'installed_workbook_changed':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('GENERAL SHEAR EXACT VBA AND DIRECTED NATIVE REGRESSIONS VERIFIED; PHYSICAL LIMIT OPEN')


def TestMechanics(repo,root,output):
    """Повторяет каждую собственную историю и проверяет заявленную границу только по её сохранённым полям."""
    TestFiles(root); records={}
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        for key in TestRead(root/'Cases.json'):
            folder=root/'Cases'/key
            for phase in ('Trace74','Trace44Extended'):
                if not (folder/'Native'/(phase+'.txt')).is_file(): continue
                name=key+'-'+phase; file=scratch/(name+'.json')
                run_path(str(root/'Validate-TestGeneralContinuation.py'))['TestValidate'](repo,folder,phase,file,74 if phase=='Trace74' else 44)
                proof=TestRead(file)
                if phase=='Trace74': assert len(proof['states'])=={'Initial':74,'RecentSeed':102,'BeforeObserver':108}[key]
                if key=='BeforeObserver' and phase=='Trace74': assert proof['maximum_Qy_N']==80725.5089571909
                if key=='Final' and phase=='Trace44Extended':
                    assert len(proof['states'])==73 and proof['maximum_Qy_N']==81199.7972637311
                records[name]=proof
        final=root/'Cases/Final'; checkpoint=scratch/'Checkpoint.json'
        snapshot=run_path(str(root/'Read-TestContinuationCheckpoint.py'))['TestRead'](final/'Native/Trace44.Checkpoint.csv')
        assert snapshot['count']==73 and snapshot['sequence']==53
        checkpoint.write_text(json.dumps(snapshot),encoding='utf-8')
        proof=scratch/'CheckpointProof.json'
        run_path(str(root/'Validate-TestContinuationCheckpoint.py'))['TestValidate'](repo,final,checkpoint,root/'Cases/BeforeObserver',proof)
        records['Final-CheckpointAfterTimeout']=TestRead(proof)
    result={'cases':records,'physical_capacity_certified':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('GENERAL SHEAR ALL SIX EQUATIONS, MATERIAL HISTORIES AND RETAINED LOAD BOUNDS VERIFIED; CAPACITY OPEN')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--scope',choices=('native','mechanics'),required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); (TestNative if args.scope=='native' else TestMechanics)(args.repo.resolve(),args.root.resolve(),args.out.resolve())
