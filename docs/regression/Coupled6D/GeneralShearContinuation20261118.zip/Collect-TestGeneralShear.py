"""ДЛЯ ТЕСТОВ: сохраняет общий поиск, его направленные регрессии и фактический VBA."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile,ZIP_DEFLATED

TestCases={'Initial':'GeneralShearContinuation0420261118','RecentSeed':'GeneralShearContinuation0520261118',
           'BeforeObserver':'GeneralShearContinuation0720261118','Final':'GeneralShearContinuation0820261118'}


def TestCopy(source,target):
    """Сохраняет точные байты без перезаписи другой попытки."""
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream: stream.write(source.read_bytes())


def TestCollect(repo,root):
    """Копирует все входы и завершённые области, отделяя VBA и XML от временных книг."""
    scratch=Path('D:/CodexScratch/RC_Section_NDM_TQ'); root.mkdir()
    for key,directory in TestCases.items():
        source=scratch/directory; target=root/'Cases'/key
        prep=json.loads((source/'Preparation.json').read_bytes())
        for name,expected in prep['inputs'].items(): assert sha256((source/name).read_bytes()).hexdigest().upper()==expected,(key,name)
        for file in source.rglob('*'):
            if not file.is_file(): continue
            name=file.relative_to(source)
            if name.parts[0] in ('Temp','workbook') or file.suffix.lower()=='.xlsm': continue
            TestCopy(file,target/name)
        for log in (target/'Native').glob('*.txt'): assert log.with_name(log.name+'.ProcessClosure.json').is_file(),log
        with ZipFile(source/'docs/regression/Diagnostic.xlsm') as book: binary=book.read('xl/vbaProject.bin')
        (target/'CompiledVBA.bin').write_bytes(binary)
        (target/'CompiledVBA.json').write_bytes((json.dumps({'bytes':len(binary),'sha256':sha256(binary).hexdigest().upper()},indent=2)+'\n').encode())
        if key in ('BeforeObserver','Final'):
            log=(source/'Native/Stock.txt').read_text('utf-8-sig')
            saved,=re.findall(r'^RESULTS_SAVE_REOPEN: .*; file=([^\r\n]+)$',log,re.M)
            assert Path(saved).resolve().is_relative_to((source/'Temp').resolve())
            with ZipFile(saved) as book,ZipFile(target/'SavedWorkbookXML.zip','x',ZIP_DEFLATED,compresslevel=9) as output:
                for name in sorted(book.namelist()):
                    if name!='xl/vbaProject.bin': output.writestr(name,book.read(name))
    for number,directory in enumerate(('GeneralShearContinuation20261118','GeneralShearContinuation0220261118','GeneralShearContinuation0320261118'),1):
        source=scratch/directory; target=root/'FailedCompile'/str(number)
        for file in source.rglob('*'):
            if not file.is_file(): continue
            name=file.relative_to(source)
            if name.parts[0] in ('Temp','workbook') or file.suffix.lower()=='.xlsm': continue
            TestCopy(file,target/name)
    here=Path(__file__).resolve().parent
    for name in ('Collect-TestGeneralShear.py','Check-TestGeneralShear.py','Validate-TestGeneralContinuation.py',
                 'Inspect-TestInitialShearSeed.py','Read-TestContinuationCheckpoint.py','Validate-TestContinuationCheckpoint.py',
                 'Run-TestExtendedTrace.ps1','TestResolutionSection.py','Probe-TestASDMaterialSteps.py','Probe-TestASDClosure.py',
                 'Check-TestMaterialRoundoff.py','Inspect-TestResolutionVBA.py','Verify-TestReducedEvidence.py','Verify-TestASDResolution.py'):
        TestCopy(here/name,root/name)
    TestCopy(scratch/'WorkingForceSubspaceEvidence20261118/SourceBook.json',root/'SourceBook.json')
    (root/'Cases.json').write_bytes((json.dumps(TestCases,indent=2,sort_keys=True)+'\n').encode())
    files={file.relative_to(root).as_posix():sha256(file.read_bytes()).hexdigest().upper() for file in root.rglob('*') if file.is_file()}
    (root/'Files.json').write_bytes((json.dumps(files,indent=2,sort_keys=True)+'\n').encode())
    print('GENERAL SHEAR EVIDENCE COLLECTED',len(files))


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args(); TestCollect(args.repo.resolve(),args.root.resolve())
