# ДЛЯ ТЕСТОВ: диагностическое наблюдение прежних 96 проб после незавершённого 240-секундного запуска.
param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference='Stop'
$tempBefore=$env:TEMP;$tmpBefore=$env:TMP;$flowBefore=$env:NDM_MVT_FLOW_FOLDER
Push-Location -LiteralPath $Root
try {
    . './Guard-IsolatedOffice.ps1'
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    foreach($file in $prep.inputs.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $file.Name).Hash -cne $file.Value) {throw "Изменён вход $($file.Name)."}
    }
    $compile=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    $book='docs/regression/Diagnostic.xlsm'
    if (!$compile.Compiled -or $compile.ProductionChanged -or $closure.State -cne 'Absent' -or
        $compile.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $book).Hash) {throw 'Нет подтверждённой частной компиляции.'}
    $negative=Get-Content -LiteralPath 'Native/Trace44.txt.ProcessClosure.json' -Raw | ConvertFrom-Json
    if ($negative.Stage -cne 'TIMEOUT' -or $negative.After.State -cne 'Absent') {throw 'Исходный тайм-аут не подтверждён.'}
    $report='Native/Trace44Extended.txt'
    if (Test-Path -LiteralPath $report) {throw 'Диагностический протокол уже существует.'}
    [ordered]@{Kind='DiagnosticOnly';SourceSHA256=$compile.WorkbookSHA256;Case='Trace44';MaximumProbes=96;
        ObservationSeconds=480;Original240SecondScopePassed=$false;SpeedAcceptancePassed=$false} |
        ConvertTo-Json | Set-Content -LiteralPath 'Native/Trace44Extended.Scope.json' -Encoding utf8
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path;$env:TMP=$env:TEMP;$env:NDM_MVT_FLOW_FOLDER=(Get-Location).Path
    Assert-IsolatedOfficeReady 'DiagnosticTrace44Extended'
    $legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-FocusedKaniWatchdog.ps1' `
        -SourceWorkbook $book -ReportPath $report -Mode No -FailFast `
        -Macro 'modTestMVT2ProductionASDTest.RunTestMVT2ProductionASDTest' -MacroArgument1 Trace44 -TimeoutSeconds 480
    $exitCode=$LASTEXITCODE
    $fixtures=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixtures.Count -ne 1) {throw 'Нет однозначной частной книги диагностического запуска.'}
    $folder=Split-Path -Parent $fixtures[0].Substring('FIXTURE: '.Length)
    if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Диагностика вне частного каталога.'}
    foreach($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv')) {
        $source=Join-Path $folder ('MVT2GaussSpan.csv'+$suffix)
        if(Test-Path -LiteralPath $source) {
            $destination=if($suffix){'Native/Trace44Extended'+$suffix}else{'Native/Trace44Extended.csv'}
            Copy-Item -LiteralPath $source -Destination $destination
        }
    }
    if ($exitCode -ne 0) {throw "Диагностический запуск завершился с кодом $exitCode."}
} finally {
    $env:TEMP=$tempBefore;$env:TMP=$tmpBefore;$env:NDM_MVT_FLOW_FOLDER=$flowBefore
    Pop-Location
}
