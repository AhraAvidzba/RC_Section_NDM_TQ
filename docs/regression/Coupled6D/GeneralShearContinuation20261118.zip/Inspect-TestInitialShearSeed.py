"""ДЛЯ ТЕСТОВ: сопоставляет автоматически выбранную секущую с проверенным сдвиговым приращением."""
from pathlib import Path
import json

root=Path('D:/CodexScratch/RC_Section_NDM_TQ/GeneralShearContinuation0420261118')
rows=[line.split(';') for line in (root/'AcceptedHistory.csv').read_text().splitlines()]
old,current=rows[-2:]; current_lambda=float(current[2])/75000.
resolution=8.*5e-7*(1.+abs(current_lambda)); anchor=old
for row in reversed(rows[:-1]):
    if float(row[1])!=10510000.: break
    if current_lambda-float(row[2])/75000.>8.*resolution:
        anchor=row; break
source=Path('D:/CodexScratch/RC_Section_NDM_TQ/RoundoffControlContinuation20261118/Native/ControlProbe.csv')
projection,=[list(map(float,line.split(';')[2:])) for line in source.read_text('cp1251').splitlines() if line.startswith('CONTROL_PROJECTION;ShearY32;')]
coordinate=lambda row:sum(a*float(b) for a,b in zip(projection,row[3:],strict=True))
nominal=coordinate(current)-coordinate(anchor); last_delta=coordinate(current)-coordinate(old)
print(json.dumps({'current_Qy_N':float(current[2]),'last_Qy_increment_N':float(current[2])-float(old[2]),
                  'anchor_label':anchor[0],'anchor_Qy_N':float(anchor[2]),'current_control':coordinate(current),
                  'initial_control_target':coordinate(current)+.5*nominal,
                  'initial_increment_in_last_shear_steps':.5*nominal/last_delta},indent=2))
