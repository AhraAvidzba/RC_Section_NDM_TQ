"""ДЛЯ ТЕСТОВ: проверяет законченный диагностический снимок без объявления его завершённым расчётом."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestValidate(repo,root,checkpoint,reference,output):
    """Повторяет материалы и все уравнения на копии полей; источник операторов проверяется по подготовленным файлам."""
    here=Path(__file__).resolve().parent
    for relative in ('src/Solver/CCoupledElasticState.cls','src/Solver/CCoupledSectionQuadrature.cls',
                     'src/Materials/CCoupledASDFlow.cls','src/Materials/CCoupledConcreteResponse.cls',
                     'src/Materials/CCoupledConcreteBackbone.cls','src/Common/modCoupledConcreteTensor.bas',
                     'Data/default.csv'):
        if not (root/relative).is_file():
            matches=list((root/'src').rglob(Path(relative).name)); assert len(matches)==1
            relative=matches[0].relative_to(root).as_posix()
        assert (root/relative).read_bytes()==(reference/relative).read_bytes(),relative
    material=run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    with TemporaryDirectory() as scratch:
        scratch=Path(scratch)
        for a,b in (('Operators.csv','Trace74.Operators.csv'),('MVTGaussMixed.csv','Trace74.csv')):
            (scratch/a).write_bytes((reference/'Native'/b).read_bytes())
        section=run_path(str(here/'TestResolutionSection.py'))['TestResolutionSection'](scratch,material,True)
    closure=run_path(str(here/'Probe-TestASDClosure.py'))['TestClosure']
    section.nominal=lambda field,history:closure(section,field,history,maximum_iterations=1024)
    state=json.loads(checkpoint.read_bytes()); history=section.TestInitial(); records=[]
    for index,point in enumerate(state['points'],1):
        field=np.asarray(point['field']); q=75000.*point['lambda']; torque=10510000.*point['fraction']
        target=np.array([0.,-396.*q,0.,torque,0.,q])
        result=section.TestEvaluate(field,history,target)
        tolerance=float(5e-7+5e-7*np.max(np.abs((target@section.l)[:-4])))
        assert result[1]<=tolerance,(index,result[1],tolerance)
        records.append({'index':index,'target_N_Nmm':target.tolist(),'norm_MPa':float(result[1]),'tolerance_MPa':tolerance})
        history=result[4]
    assert len(records)==state['count']
    result={'states':records,'sequence':state['sequence'],'checkpoint_details':state['details'],
            'maximum_Qy_N_on_full_path':max(75000.*p['lambda'] for p in state['points'] if p['fraction']==1.),
            'maximum_closure_iterations':1024,'native_stress_tensors_recorded':False,
            'original_scope_completed':False,'physical_capacity_certified':False}
    output.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('DIAGNOSTIC CHECKPOINT SIX EQUATIONS VERIFIED',len(records),result['maximum_Qy_N_on_full_path'],'ORIGINAL SCOPE REMAINS INCOMPLETE')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__); parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--checkpoint',type=Path,required=True); parser.add_argument('--reference',type=Path,required=True); parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args(); TestValidate(args.repo.resolve(),args.root.resolve(),args.checkpoint.resolve(),args.reference.resolve(),args.out.resolve())
