"""Готовит парную нативную проверку допусков возле принятого HardShear G13."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = REPO/'docs/regression/Coupled6D/HardShearF19ContinuationNative20261117.zip'
BASE_SHA = 'E6E987A86DE0191A649B123F3F1B629CD5821C24E71AF946FC1B010CFB25F131'
OLD_REPORT = '48E5B874F9BDC62B87EC9AC3240C295674FE23C6C81D7F9E45FA36F9E1D7838D'
BOOK = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
SOLVER = 'src/Solver/CCoupledNewtonSolver.cls'
TEST = 'tests/modTestCoupledElasticState.bas'
NATIVE = ('FIELD','ACTUAL','TARGET','RESIDUAL','CONTROL','BALANCE','SEED','SOLVER')


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def encode(source):
    assert max(map(len,source.splitlines())) < 1024
    return (source.rstrip().replace('\n','\r\n')+'\r\n').encode('utf-8')


def once(source,old,new):
    assert source.count(old) == 1, old
    return source.replace(old,new)


def seal(root,path,raw):
    target = root/path
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, path
    else:
        target.write_bytes(raw)
    return sha(raw)


def replay_fields(raw):
    tags, excellent, old = {}, [], None
    active = None
    data = raw.decode('cp1251').splitlines()
    assert data.pop(0) == 'HARDSHEAR-F19;1'
    for row in data:
        key,*tokens = row.split(';')
        if key in ('OFFSET','DIRECTION','PROJECTION'):
            tags[key] = tokens
        elif key == 'BEGIN':
            assert active is None and tokens[3] == 'True'
            active = {'label':tokens[0],'control':tokens[1],'estimate':tokens[2]}
        elif key == 'END':
            assert active is not None and active['label'] == tokens[0]
            if tokens[1] == 'True':
                assert set(NATIVE) <= set(active)
                excellent.append(active)
            elif tokens[0] == 'G14':
                old = active
            active = None
        elif active is not None and key in NATIVE:
            assert key not in active
            active[key] = tokens
    assert len(excellent) == 25 and [r['label'] for r in excellent[-3:]] == ['G9','G12','G13']
    assert old is not None and old['SOLVER'][0] == 'False'
    return {'fields':excellent,'geometry':tags,'old_G14':old,'stock_tolerance':5e-7,'tight_tolerance':5e-10,'soft_seconds':190.}


def packed(tokens,name):
    encoded = ''.join(tokens)
    assert len(encoded) == 960 and all(c in '0123456789ABCDEF' for c in encoded)
    parts = [encoded[i:i+192] for i in range(0,960,192)]
    return '\n'.join([f'    packed = "{parts[0]}"',*(f'    packed = packed & "{p}"' for p in parts[1:]),
                      f'    HardRankUnpackTest packed, {name}'])+'\n'


def test_source(raw,plan):
    code = text(raw)
    code = once(code,'HARDSHEAR-F19;1','HARDSHEAR-G13;1')
    code = once(code,'HardF19.csv','HardG13.csv')
    signature = code.index('Public Function ReplayHardYieldGateTest(')
    start = code.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,signature)
    end = code.index('\nEnd Function',signature)+len('\nEnd Function')
    source = '''' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт принятые поля на той же квадратуре через G13.
Public Function ReplayHardYieldGateTest(ByVal solver As CCoupledNewtonSolver, ByRef offset() As Double, _
        ByRef direction() As Double) As Boolean
    Dim history As New Collection, field() As Double, projection() As Double, packed As String
    Dim controls(1 To 25) As Double, factors(1 To 25) As Double, labels(1 To 25) As String
'''
    for i,row in enumerate(plan['fields'],1):
        source += packed(row['FIELD'],'field')+'    history.Add field\n'
        source += f'    controls({i}) = HardRankValueTest("{row["control"]}")\n'
        source += f'    factors({i}) = HardRankValueTest("{row["BALANCE"][0]}")\n'
        source += f'    labels({i}) = "{row["label"]}"\n'
    source += packed(plan['geometry']['PROJECTION'],'projection')
    source += '    ReplayHardYieldGateTest = solver.TraceHardG13Test(history, controls, factors, labels, projection, _\n'
    source += f'        HardRankValueTest("{plan["old_G14"]["control"]}"), offset, direction)\nEnd Function'
    source.encode('cp1251')
    return encode(code[:start]+source+code[end:])


def solver_source(raw):
    code = text(raw)
    code = code.replace('TraceHardFineResumeTest','TraceHardG13Test')
    code = once(code,'        ByVal maxControl As Double, ByVal firstTarget As Double, _\n','        ByVal firstTarget As Double, _\n')
    code = once(code,'    Const MAX_PROBES As Long = 36, SOFT_SECONDS As Double = 205#\n','')
    code = once(code,'history.Count <> 19 Then Exit Function','history.Count <> 25 Then Exit Function')
    code = once(code,'    Dim current() As Double, prior() As Double, expected() As Double\n','    Dim current() As Double, expected() As Double\n')
    code = once(code,'    Dim index As Long, lambda As Double, acceptedControl As Double, priorControl As Double\n'
                     '    Dim acceptedLambda As Double, priorLambda As Double, label As String, seed As Variant, verified As Boolean\n',
                '    Dim index As Long, lambda As Double, acceptedControl As Double\n'
                '    Dim label As String, seed As Variant, verified As Boolean\n')
    code = once(code,'seed, acceptedControl, lambda, True, index = history.Count)',
                'seed, acceptedControl, lambda, True, False)')
    code = once(code,'        If index = 5 Or index = 6 Or index = history.Count Then\n',
                '        If index >= history.Count - 1 Then\n')
    code = once(code,'        If index = history.Count - 1 Then\n            CopyAccepted prior\n'
                     '            priorControl = acceptedControl: priorLambda = lambda\n        End If\n','')
    code = once(code,'        WriteHardRankRowTest "FINISH;HISTORY_REFUSED;19;0;0"',
                '        WriteHardRankRowTest "FINISH;HISTORY_REFUSED;25;0;0"')
    first = code.index('    CopyAccepted current\n    acceptedLambda = lambda\n')
    end = code.index('    TraceHardG13Test = True\nEnd Function',first)
    code = code[:first]+'''    Dim status As String, probes As Long
    status = RunHardG13PairsTest(history, saved, controls, factors, projection, firstTarget, offset, direction, started, probes)
    WriteHardRankRowTest "FINISH;" & status & ";25;" & CStr(probes)
'''+code[end:]
    code = once(code,'    For Each mark In Array(5, 6, 19)\n','    For Each mark In Array(24, 25)\n')
    code = once(code,'        ByRef control As Double, ByRef trialFactor As Double, ByVal replay As Boolean, ByVal wantBound As Boolean) As Boolean\n'
                     '    Const ABS_TOLERANCE As Double = 0.0000005, REL_TOLERANCE As Double = 0.0000005, ITERATIONS As Long = 12\n',
                '        ByRef control As Double, ByRef trialFactor As Double, ByVal replay As Boolean, ByVal wantBound As Boolean, _\n'
                '        Optional ByVal toleranceSpec As Double = 0.0000005, Optional ByVal commitTrial As Boolean = True) As Boolean\n'
                '    Const ITERATIONS As Long = 12\n')
    # В диагностической пристройке меняется только управление допуском. Рабочий код расположен выше.
    boundary = code.index('Private Function TryHardFinePointTest(')
    code = code[:boundary]+code[boundary:].replace('ABS_TOLERANCE, REL_TOLERANCE','toleranceSpec, toleranceSpec')
    code = once(code,'HardRankBitsTest(estimate) & ";True"','HardRankBitsTest(estimate) & ";" & CStr(commitTrial)')
    code = once(code,'            If wantBound Then\n','            If wantBound Then\n                If Not commitTrial Then RecordHardG13StationsTest current\n')
    code = once(code,'                If Not mCandidateReady Then\n                    If Not RestoreHardFineCandidateTest',
                '                If commitTrial And Not mCandidateReady Then\n                    If Not RestoreHardFineCandidateTest')
    code = once(code,'    If TryHardFinePointTest Then AcceptStep Else DiscardStep\n',
                '    If TryHardFinePointTest And commitTrial Then AcceptStep Else DiscardStep\n'
                '    If TryHardFinePointTest And Not commitTrial Then result = "VERIFIED_PROBE"\n')
    addition = text((HERE/'Probe.bas').read_bytes())
    addition.encode('cp1251')
    return encode(code+'\n'+addition)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready')
    cli.add_argument('--with-workbook',action='store_true')
    args = cli.parse_args()
    dest = args.destination.resolve()
    assert dest.is_relative_to(HERE) or dest.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(BASE.read_bytes()) == BASE_SHA
    inputs = {}
    with ZipFile(BASE) as base:
        inherited = json.loads(base.read('Fixture.json'))
        stock = (REPO/inherited['workbook']).read_bytes()
        assert sha(stock) == inherited['source_workbook_sha256'] == BOOK
        report = base.read('Native/Order10/Verification.json')
        native = base.read('Native/Order10/HardF19.csv')
        assert sha(report) == OLD_REPORT and json.loads(report)['native_trace_sha256'] == sha(native)
        expected = replay_fields(native)
        for name,raw in (('Expected.json',(json.dumps(expected,indent=2)+'\n').encode('utf-8')),
                         ('Prior/HardF19.csv',native),('Prior/Verification.json',report),
                         ('F19Verify.py',base.read('Verify.py')),('PriorVerify.py',base.read('PriorVerify.py')),
                         ('FineVerify.py',base.read('FineVerify.py'))):
            inputs[name] = seal(dest,name,raw)
        for path,digest in inherited['inputs'].items():
            raw = base.read(path)
            assert sha(raw) == digest, path
            if path.startswith('tools/') or path.startswith('src/') or path in (TEST,'Guard-IsolatedOffice.ps1','Run.ps1'):
                if path == SOLVER:
                    raw = solver_source(raw)
                elif path == TEST:
                    raw = test_source(raw,expected)
                elif path == 'Run.ps1':
                    raw = text(raw).replace('HardF19','HardG13').encode('utf-8')
                inputs[path] = seal(dest,path,raw)
    for path in ('Stage.py','Verify.py','Probe.bas'):
        inputs[path] = seal(dest,path,(HERE/path).read_bytes())
    if args.with_workbook:
        seal(dest,inherited['workbook'],stock)
        seal(dest,'docs/regression/Diagnostic.xlsm',stock)
        for directory in ('Temp','Native/Order10'):
            (dest/directory).mkdir(parents=True,exist_ok=True)
    plan = {**inherited,'inputs':inputs,'watchdog_seconds':240,'prior_archive_sha256':BASE_SHA,'prior_report_sha256':OLD_REPORT,
            'prior_compiled_workbook_sha256':json.loads(report)['proof']['compiled_workbook_sha256'],
            'scope':'transactional G12/G13 neighboring equilibria at identical controls and alternative numerical tolerances'}
    print(dest,seal(dest,'Fixture.json',(json.dumps(plan,indent=2)+'\n').encode('utf-8')))


if __name__ == '__main__':
    main()
