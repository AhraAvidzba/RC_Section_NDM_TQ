' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сопоставляет один набор координат при двух допусках от каждого фиксированного буфера.
' Ни одна из новых проб не становится принятым полем.
Private Function RunHardG13PairsTest(ByVal history As Collection, ByVal snapshots As Collection, ByRef controls() As Double, _
        ByRef factors() As Double, ByRef projection() As Double, ByVal g14 As Double, ByRef offset() As Double, _
        ByRef direction() As Double, ByVal started As Double, ByRef probes As Long) As String
    Const SOFT_SECONDS As Double = 190#
    Dim anchor As Long, i As Long, current() As Double, previous() As Double, prediction() As Double
    Dim leftCoordinate As Double, rightCoordinate As Double, goal As Variant, target As Double, estimate As Double, stride As Double
    Dim measure As Double, lambda As Double, suffix As Variant, identifier As String, seed As Variant
    Dim fixedHistory() As Double, tolerance As Double, keep As Boolean, weights As Collection
    Dim reason As String: reason = "COMPLETE"
    For anchor = 24 To 25
        previous = history(anchor - 1): current = history(anchor)
        leftCoordinate = HardFineControlTest(projection, previous): rightCoordinate = HardFineControlTest(projection, current)
        If rightCoordinate <= leftCoordinate Or g14 <= rightCoordinate Then
            RunHardG13PairsTest = "INVALID_WINDOW": Exit Function
        End If
        If anchor = 24 Then
            Set weights = New Collection
            weights.Add 0.5 * (rightCoordinate + controls(25))
            weights.Add controls(25)
        Else
            Set weights = New Collection
            weights.Add 0.5 * (rightCoordinate + g14)
        End If
        weights.Add g14
        fixedHistory = snapshots(anchor - 23)
        Dim j As Long: j = 0
        For Each goal In weights
            j = j + 1: target = CDbl(goal)
            stride = (target - rightCoordinate) / (rightCoordinate - leftCoordinate)
            estimate = factors(anchor) + stride * (factors(anchor) - factors(anchor - 1))
            prediction = current
            For i = 1 To UBound(prediction): prediction(i) = current(i) + stride * (current(i) - previous(i)): Next i
            For Each suffix In Array("S", "T")
                If HardF19ElapsedTest(started) >= SOFT_SECONDS Then
                    RunHardG13PairsTest = "TIME_BOUND": Exit Function
                End If
                identifier = "L" & CStr(j) & CStr(suffix)
                If anchor = 25 Then identifier = "R" & CStr(j) & CStr(suffix)
                tolerance = 0.0000005
                If suffix = "T" Then tolerance = 0.0000000005
                If Not ReplayAcceptedFields(history, anchor) Then
                    RunHardG13PairsTest = "ROLLBACK_REFUSED": Exit Function
                End If
                If Not HardG13HistoryAgreesTest(fixedHistory) Then
                    RunHardG13PairsTest = "ROLLBACK_REFUSED": Exit Function
                End If
                WriteHardRankRowTest "PAIR;" & identifier & ";" & CStr(anchor) & ";" & HardRankBitsTest(tolerance)
                seed = prediction: probes = probes + 1
                keep = TryHardFinePointTest(identifier, target, estimate, offset, direction, projection, _
                    seed, measure, lambda, False, True, tolerance, False)
                If Not HardG13HistoryAgreesTest(fixedHistory) Then
                    RunHardG13PairsTest = "ROLLBACK_REFUSED": Exit Function
                End If
                WriteHardRankRowTest "ROLLBACK;" & identifier & ";" & CStr(anchor) & ";" & CStr(UBound(fixedHistory))
            Next suffix
        Next goal
    Next anchor
    RunHardG13PairsTest = reason
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет принятые переменные материала после каждой отклонённой пробы.
Private Function HardG13HistoryAgreesTest(ByRef saved() As Double) As Boolean
    Dim current() As Double, i As Long
    ReadHardF19HistoryTest current
    If UBound(current) <> UBound(saved) Then Exit Function
    For i = 1 To UBound(current)
        If HardRankBitsTest(current(i)) <> HardRankBitsTest(saved(i)) Then Exit Function
    Next i
    HardG13HistoryAgreesTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает признаки перехода на бетонных точках трёх продольных станций.
Private Sub RecordHardG13StationsTest(ByRef field() As Double)
    Dim lines() As String, point As Long, side As Long, idx As Long, strain(1 To COMPONENT_COUNT) As Double
    ReDim lines(1 To 3 * mSection.ConcretePointCount)
    Dim position As CCoupledReinforcedResponse, yieldValue As Double, unused(1 To COMPONENT_COUNT) As Double
    Dim isPlastic As Boolean, principal As Long, substeps As Long
    For point = 1 To mSection.ConcretePointCount
        For side = -1 To 1
            idx = idx + 1: Set position = YieldResponse(side)
            YieldStrain point, side, field, strain
            lines(idx) = "STATION;" & CStr(point) & ";" & CStr(side) & ";"
            If position.TryReadTrialYield(point, strain, yieldValue, unused, False) And _
                    position.TryReadConcreteBranch(point, strain, isPlastic, principal, substeps) Then
                lines(idx) = lines(idx) & "ok;" & HardRankBitsTest(yieldValue) & ";" & CStr(isPlastic) & ";" & _
                    CStr(principal) & ";" & CStr(substeps)
            Else
                lines(idx) = lines(idx) & "failed"
            End If
        Next side
    Next point
    WriteHardRankRowTest Join(lines, vbCrLf)
End Sub
