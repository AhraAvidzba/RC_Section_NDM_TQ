"""Check the no-factor mixed-softened steel witness from saved native output."""

from decimal import Decimal as D, getcontext
from hashlib import sha256
import json
from pathlib import Path
import sys


getcontext().prec=45
report=Path(sys.argv[1])
raw=report.read_text(encoding='utf-8-sig')
assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in raw
assert 'TOTAL_STEEL_WITHOUT_FACTOR: passed=26; failed=0' in raw
rows=[line.split(';') for line in raw.splitlines()]
_, n, torque, reference, hoop_area=next(row for row in rows if row[0]=='FALLBACK_REFERENCE')
lim=D('.00099'); area=D(21600); hoop=D(hoop_area); net=area-D(100)-hoop
expected=net*(D(30000)*lim-D(10**10)*lim**3)+D(10000)
assert abs(D(n)-expected)<D('1e-8') and D(torque)==D(300000) and abs(D(reference)-1)<D('1e-10')
nominal_tolerance=D('5e-7')*(1+abs(D(n))/area)
fallback_strain=nominal_tolerance/D(30000)
case_rows=[row[1:] for row in rows if row[0]=='FALLBACK_CASE']
balance_rows=[row[1:] for row in rows if row[0]=='FALLBACK_BALANCE']
field_rows=[row[1:] for row in rows if row[0]=='FALLBACK_FIELD']
assert len(case_rows)==len(balance_rows)==len(field_rows)==4
_, dof, physical, observed_tangent, analytical_tangent=next(row for row in rows if row[0]=='FALLBACK_MATRIX')
natural_tangent=net/area*(D(30000)-D(3)*D(10**10)*lim**2)
assert int(dof)>int(physical)>6 and abs(D(observed_tangent)-natural_tangent)<D('1e-7')
assert abs(D(analytical_tangent)-natural_tangent)<D('1e-7')
expected_groups=[1,1,3,3]
expected_routes=['FreshUnfactored']*2+['TangentUnavailableAfterBalance']*2
records=[]
for i,(tangent,shift,raw_u,uncertain,certified_residual) in enumerate(case_rows):
    assert abs(D(shift))>fallback_strain and (D(raw_u)>1)==(D(shift)>0)
    assert int(uncertain)==expected_groups[i]
    assert D(certified_residual)<D('5e-6')
    route, shift_again, area_txt, length_txt, weak, *values=balance_rows[i]
    assert route==expected_routes[i] and shift_again==shift and D(area_txt)==area and D(weak)<D('5e-6')
    terms=[(D(values[j]),D(values[j+1])) for j in range(0,12,2)]
    assert [pair[0] for pair in terms]==[D(n),D(0),D(0),D(torque),D(0),D(0)]
    factors=[area,area*D(length_txt),area*D(length_txt),area*D(length_txt),area,area]
    normalized_norm=max(abs(want-got)/weight for (want,got),weight in zip(terms,factors,strict=True))
    assert abs(normalized_norm-D(certified_residual))<D('1e-11')
    field_route, field_shift, original, retained, difference=field_rows[i]
    assert (field_route,field_shift)==(route,shift)
    assert abs(D(original)-lim-D(shift))<D('2e-16')
    if i<2:
        assert abs(D(retained)-lim)<D('1e-15') and D(certified_residual)<D('1e-9')
    else:
        assert D(original)==D(retained) and D(difference)==0
    records.append({'tangent':tangent,'provisional_strain_shift':shift,'provisional_U':raw_u,
                    'route':route,'unresolved_groups':uncertain,'final_force_norm_MPa':certified_residual,
                    'weak_residual_MPa':weak,'retained_epsilon0':retained,'max_field_change':difference})
data={'report_sha256':sha256(report.read_bytes()).hexdigest().upper(),'reference_N':n,'reference_T_Nmm':torque,
      'old_strain_proxy':str(fallback_strain),'measured_axial_tangent_MPa':observed_tangent,'cases':records}
report.with_suffix('.Verification.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2))
