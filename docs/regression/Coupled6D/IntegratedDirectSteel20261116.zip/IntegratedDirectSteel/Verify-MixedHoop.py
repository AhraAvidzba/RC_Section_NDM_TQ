"""Verify the native mixed hoop comparison and independent six-force residuals."""

from decimal import Decimal as D, getcontext
from hashlib import sha256
import json
from pathlib import Path
import sys


getcontext().prec=48
report=Path(sys.argv[1])
raw=report.read_text(encoding='utf-8-sig')
assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in raw
assert 'TOTAL_DIRECT_HOOP_CONTACT: passed=16; failed=0' in raw
rows=[line.split(';') for line in raw.splitlines()]
references=[row[1:] for row in rows if row[0]=='HOOP_REFERENCE']
assert [row[0] for row in references]==['0','1','2'] and all(int(row[1])>0 for row in references)
loose, strict, tighter=[D(row[2]) for row in references]
assert all(D(row[3])<D('1e-9') for row in references[1:])
assert loose*strict>0 and strict*tighter>0
_, center, delta=next(row for row in rows if row[0]=='HOOP_INTERVAL')
margin=D(delta); contact=D(center)
assert abs(strict)==contact and margin>=32*abs(strict-tighter)-D('1e-18')
cases=[row[1:] for row in rows if row[0]=='HOOP_CASE']
forces=[row[1:] for row in rows if row[0]=='HOOP_FORCE']
assert [row[0] for row in cases]==[row[0] for row in forces]==['-1','0','1']
check_cases=[]
expected_loads=None
for case, record, status, code in zip(cases,forces,('FAIL','NumFail','OK'),
        ('TRANSVERSE_STRAIN_EXCEEDED','COUPLED_STEEL_LIMIT_UNRESOLVED','NONE'),strict=True):
    case_side, direct, hoop, direct_code, hoop_code, strain, signed_limit, raw_u=case
    assert direct==hoop==status and direct_code==hoop_code==code
    assert abs(D(raw_u)-D(strain)/D(signed_limit))<D('5e-13')
    assert D(strain)*strict>0 and D(signed_limit)*strict>0
    assert abs(abs(D(signed_limit))-(contact+D(case_side)*margin))<D('1e-18')
    if status=='FAIL': assert D(raw_u)>1
    if status=='OK': assert D(raw_u)<1
    _, area, length, *values=record
    terms=[(D(values[i]),D(values[i+1])) for i in range(0,12,2)]
    load=[target for target,_ in terms]
    assert expected_loads is None or load==expected_loads
    expected_loads=load
    norm=max(abs(achieved-target)/(D(area)*D(length) if i in (1,2,3) else D(area))
             for i,(target,achieved) in enumerate(terms))
    assert norm<D('5e-6')
    check_cases.append({'case':case,'force_pairs':record,'normalized_equilibrium_error_MPa':str(norm)})
assert all(value != 0 for value in expected_loads)
proof={'native_sha256':sha256(report.read_bytes()).hexdigest().upper(),'references':references,
       'center_magnitude':center,'margin':delta,'cases':check_cases}
report.with_suffix('.Verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,indent=2))
