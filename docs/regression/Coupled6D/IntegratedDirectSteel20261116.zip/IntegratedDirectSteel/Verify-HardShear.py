"""Verify actual direct HardShear output, reopen identity, and elapsed time."""

from decimal import Decimal as D
from hashlib import sha256
import json
from pathlib import Path
import re
import sys


report=Path(sys.argv[1])
raw=report.read_text(encoding='utf-8-sig')
assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in raw
assert 'TOTAL_COUPLED_WORKBOOK_TIMING: passed=19; failed=0' in raw
assert 'TIMING_STATES: direct=OK; capacity=N/A;' in raw
timing=re.search(r'^TIMING_SECONDS: ([0-9.]+) \| Direct \| Excel$',raw,re.M)
reopen=re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=([A-F0-9]+); equal=True;',raw,re.M)
assert timing and D(timing[1])>0 and reopen and reopen[1]==reopen[2]
components=re.findall(r'^OK: direct (\S+) actual=(\S+) expected=(\S+)$',raw,re.M)
assert [name for name,_,_ in components]==['N','Mx','My','T','Qx','Qy']
assert all(abs(D(actual)-D(expected))<D('1e-8') for _,actual,expected in components)
proof={'report_sha256':sha256(report.read_bytes()).hexdigest().upper(),'direct_seconds':timing[1],
       'met_time_goal':D(timing[1])<=10,'reopen_sha256':reopen[1],'resultant_pairs':components}
report.with_suffix('.Verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,indent=2))
