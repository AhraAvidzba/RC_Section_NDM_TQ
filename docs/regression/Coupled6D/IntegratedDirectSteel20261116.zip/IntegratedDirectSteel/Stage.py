"""Merge the two natively tested runtime branches and freeze the combined probe."""

from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
TMP=HERE.parent
BOOK='workbook/output/RC_Section_NDM.xlsm'
TEST='tests/modTestCoupledElasticState.bas'
SECTION='src/Solver/CCoupledSectionAnalysis.cls'
SOLVER_UPDATES={'src/Solver/CCoupledNewtonSolver.cls','src/Materials/CCoupledReinforcedResponse.cls'}
COMPAT_UPDATES={'src/Excel/CSectionPlotDataReader.cls','src/Excel/modAutoCADStressExport.bas','src/Excel/modSectionSnapshot.bas'}


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def freeze(source,target):
    target.parent.mkdir(exist_ok=True,parents=True)
    copyfile(source,target)


def manifest(path):
    return json.loads((path/'Fixture.json').read_text(encoding='utf-8'))


def runtime(fixture):
    return {name:sha for name,sha in fixture['frozen'].items() if name.startswith('src/')}


def differences(name,first,second):
    actual={key for key in first.keys()|second.keys() if first.get(key)!=second.get(key)}
    assert actual==name,(actual,name)


assert not (HERE/'Fixture.json').exists()
compat_dir=TMP/'dsr/Compat'; common_dir=TMP/'dsr/Snapshot'
successful_feedback=TMP/'dsf2'; initial_feedback=TMP/'dsf'; hoop_dir=TMP/'dsh'
compat=manifest(compat_dir); common=manifest(common_dir)
fallback=manifest(successful_feedback); initial=manifest(initial_feedback); mixed=manifest(hoop_dir)
common_sha=digest(common_dir/'Fixture.json')
assert common_sha=='511490464CBC79EBD0BB9F1D0382982E0F362650E2A6D610DBE2ED9D7A468376'
assert initial['base_fixture_sha256']==common_sha==mixed['base_fixture_sha256']
assert fallback['base_fixture_sha256']==digest(initial_feedback/'Fixture.json')
assert digest(REPO/BOOK)==compat['workbook_sha256']==fallback['workbook_sha256']==mixed['workbook_sha256']
differences(COMPAT_UPDATES,runtime(compat),runtime(common))
differences(SOLVER_UPDATES,runtime(fallback),runtime(common))
differences({SECTION},runtime(mixed),runtime(common))
assert COMPAT_UPDATES.isdisjoint(SOLVER_UPDATES)
for key in SOLVER_UPDATES:
    assert compat['frozen'][key]==common['frozen'][key]==initial['base_module_sha256'][key]

sources={}
for name,sha in sorted(runtime(compat).items()):
    selected=successful_feedback if name in SOLVER_UPDATES else compat_dir
    expected=fallback['frozen'][name] if name in SOLVER_UPDATES else sha
    assert digest(selected/name)==expected
    freeze(selected/name,HERE/'Production'/name)
    freeze(selected/name,HERE/name)
    sources[name]={'sha256':expected,'from':selected.relative_to(TMP).as_posix(),'common_sha256':common['frozen'].get(name)}
production={'production_files':sources,'retained_state_compat_fixture_sha256':digest(compat_dir/'Fixture.json'),
            'fallback_fixture_sha256':digest(successful_feedback/'Fixture.json'),'common_snapshot_fixture_sha256':common_sha}
(HERE/'Production/ProductionManifest.json').write_text(json.dumps(production,indent=2)+'\n',encoding='utf-8')

reference=(hoop_dir/'Reference.txt').read_text(encoding='utf-8')
original=(HERE/SECTION).read_text(encoding='utf-8').rstrip()
(HERE/SECTION).write_text(original+'\n\n'+reference,encoding='utf-8',newline='\r\n')
assert digest(HERE/SECTION)==mixed['frozen'][SECTION]
assert digest(compat_dir/TEST)==compat['frozen'][TEST]
combined=(compat_dir/TEST).read_text(encoding='utf-8').rstrip()
for folder,fragment,expected in ((hoop_dir,'MixedTest.txt',mixed),(successful_feedback,'FallbackTest.txt',fallback)):
    assert digest(folder/fragment)==expected['frozen'][fragment]
    combined+='\n\n'+(folder/fragment).read_text(encoding='utf-8').rstrip()
(HERE/TEST).parent.mkdir(exist_ok=True)
(HERE/TEST).write_text(combined+'\n',encoding='utf-8',newline='\r\n')

files=[name for name in compat['frozen'] if name.startswith('tools/') or name in (BOOK,'Guard-IsolatedOffice.ps1')]
for name in files:
    assert digest(compat_dir/name)==compat['frozen'][name]
    freeze(compat_dir/name,HERE/name)
for directory in ('docs/regression','Native','Temp'):
    (HERE/directory).mkdir(exist_ok=True,parents=True)
freeze(HERE/BOOK,HERE/'docs/regression/Diagnostic.xlsm')
freeze(compat_dir/'Verify.py',HERE/'Verify-Compat.py')
freeze(successful_feedback/'Verify.py',HERE/'Verify-Fallback.py')
freeze(hoop_dir/'Verify.py',HERE/'Verify-MixedHoop.py')
files+=list(sources)+[TEST,'Production/ProductionManifest.json','Stage.py','Run.ps1',
                      'Verify-Compat.py','Verify-Fallback.py','Verify-MixedHoop.py','Verify-HardShear.py']
fixture={'workbook_sha256':compat['workbook_sha256'],'frozen':{name:digest(HERE/name) for name in files},
         'modules':sorted(Path(name).stem for name in (*sources,TEST)),'production_manifest_sha256':digest(HERE/'Production/ProductionManifest.json'),
         'test_appended_to_production_only_for_probe':[SECTION]}
(HERE/'Fixture.json').write_text(json.dumps(fixture,indent=2)+'\n',encoding='utf-8')
print('INTEGRATED_FIXTURE',digest(HERE/'Fixture.json'))
print('PRODUCTION_MANIFEST',fixture['production_manifest_sha256'])
for name,info in sources.items():
    print(info['sha256'], name)
