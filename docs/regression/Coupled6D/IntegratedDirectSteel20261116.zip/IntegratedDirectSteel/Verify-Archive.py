"""Check the frozen DSI candidate and reproduce its six native validations offline."""

import argparse
from difflib import SequenceMatcher
from hashlib import sha256
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory


HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
TEST = "tests/modTestCoupledElasticState.bas"
SECTION = "src/Solver/CCoupledSectionAnalysis.cls"
COMMIT = "f4741ae638f3c17bc19b39e02d177698c247bd86"
FIXTURE_SHA = "988715E00C30D2306F01E11B9149244D903C7CE75721114F134DA0CECA2F933F"
BOOK_SHA = "8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF"
DIAGNOSTIC_SHA = "D5DD7A956A69DE8B504DA7DC08394787A51D6C86CE4AD9BE9812F1DE71040A3C"
MACROS = {
    "Equilibrium": "RunTestCoupledDirectSteelVerification",
    "Fallback": "RunTestCoupledSteelWithoutSavedFactor",
    "Mixed": "RunTestCoupledDirectHoopContact",
    "Excel": "RunTestCoupledRetainedSnapshot",
    "File": "RunTestCoupledRetainedSnapshot",
    "HardShear": "RunTestCoupledWorkbookTiming",
}
VALIDATORS = {
    "Fallback": "Verify-Fallback.py",
    "Mixed": "Verify-MixedHoop.py",
    "HardShear": "Verify-HardShear.py",
}


def digest(value):
    return sha256(value).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_bytes())


def runtime(fixture):
    return {name: checksum for name, checksum in fixture["frozen"].items() if name.startswith("src/")}


def changes(before, after):
    return {key for key in before.keys() | after.keys() if before.get(key) != after.get(key)}


def verify_provenance(fixture, entries, repository):
    provenance = HERE / "Provenance"
    source = {key: read_json(provenance / key / "Fixture.json") for key in ("Compat", "Snapshot", "Initial", "Fallback", "Mixed")}
    for name, ref in (
        ("Compat", "retained_state_compat_fixture_sha256"),
        ("Snapshot", "common_snapshot_fixture_sha256"),
        ("Fallback", "fallback_fixture_sha256"),
    ):
        assert digest((provenance / name / "Fixture.json").read_bytes()) == entries[ref]
    common_sha = entries["common_snapshot_fixture_sha256"]
    assert source["Initial"]["base_fixture_sha256"] == common_sha == source["Mixed"]["base_fixture_sha256"]
    assert source["Fallback"]["base_fixture_sha256"] == digest((provenance / "Initial/Fixture.json").read_bytes())
    common = runtime(source["Snapshot"])
    compatibility = runtime(source["Compat"])
    fallback = runtime(source["Fallback"])
    assert changes(common, compatibility) == {
        "src/Excel/CSectionPlotDataReader.cls", "src/Excel/modAutoCADStressExport.bas", "src/Excel/modSectionSnapshot.bas"
    }
    solver_updates = {"src/Solver/CCoupledNewtonSolver.cls", "src/Materials/CCoupledReinforcedResponse.cls"}
    assert changes(common, fallback) == solver_updates
    assert changes(common, runtime(source["Mixed"])) == {SECTION}
    for name in solver_updates:
        assert compatibility[name] == common[name] == source["Initial"]["base_module_sha256"][name]
    for name in ("Compat", "Fallback", "Mixed"):
        assert source[name]["workbook_sha256"] == BOOK_SHA

    deltas = {}
    files = entries["production_files"]
    assert len(files) == 12 and set(files) == set(compatibility) == set(runtime(fixture))
    for name, record in files.items():
        production = (HERE / "Production" / name).read_bytes()
        imported = (HERE / name).read_bytes()
        chosen = fallback if name in solver_updates else compatibility
        assert digest(production) == record["sha256"] == chosen[name]
        assert digest(imported) == fixture["frozen"][name]
        assert record["from"] == ("dsf2" if name in solver_updates else "dsr/Compat")
        assert record["common_sha256"] == common.get(name)
        if name == SECTION:
            section_reference = provenance / "Mixed/Reference.txt"
            assert digest(section_reference.read_bytes()) == source["Mixed"]["frozen"]["Reference.txt"]
            probe = production.decode("utf-8").replace("\r\n", "\n").rstrip() + "\n\n"
            probe += section_reference.read_text(encoding="utf-8")
            assert probe.replace("\n", "\r\n").encode("utf-8") == imported
            assert digest(imported) == source["Mixed"]["frozen"][SECTION]
        else:
            assert imported == production
        historical = (HERE / "Baseline" / name).read_bytes()
        if repository is not None:
            assert check_output(["git", "show", f"{COMMIT}:{name}"], cwd=repository) == historical
        original = historical.decode("utf-8-sig").splitlines()
        candidate = production.decode("utf-8-sig").splitlines()
        sequence = SequenceMatcher(None, original, candidate, autojunk=False).get_opcodes()
        removed = sum(end - start for op, start, end, _, _ in sequence if op != "equal")
        added = sum(end - start for op, _, _, start, end in sequence if op != "equal")
        assert removed or added
        deltas[name] = {
            "history_sha256": digest(historical),
            "production_sha256": digest(production),
            "probe_import_sha256": digest(imported),
            "production_lines_removed": removed,
            "production_lines_added": added,
            "probe_changes_vs_production_lines_added": len(imported.splitlines()) - len(production.splitlines()),
        }
    if repository is not None:
        assert digest(check_output(["git", "show", f"{COMMIT}:{BOOK}"], cwd=repository)) == BOOK_SHA
    parts = (("Compat", TEST), ("Mixed", "MixedTest.txt"), ("Fallback", "FallbackTest.txt"))
    text = []
    for origin, name in parts:
        path = provenance / origin / name
        assert digest(path.read_bytes()) == source[origin]["frozen"][name]
        text.append(path.read_text(encoding="utf-8").rstrip())
    combined = ("\n\n".join(text) + "\n").replace("\n", "\r\n").encode("utf-8")
    assert combined == (HERE / TEST).read_bytes()
    return deltas


def verify_identity(raw, report_path, label):
    assert re.search(r"^SOURCE_SHA256: " + DIAGNOSTIC_SHA + "$", raw, re.M)
    assert re.search(r"^===== modTestCoupledElasticState\." + MACROS[label] + " =====$", raw, re.M)
    assert "SOURCE_UNCHANGED: True" in raw
    owner = read_json(report_path.with_suffix(".txt.Ownership.json"))
    closure = read_json(report_path.with_suffix(".txt.ProcessClosure.json"))
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"]
    assert owner["SourceSHA256"] == DIAGNOSTIC_SHA
    assert closure["ChildHasExited"] and closure["Passed"] and closure["ChildExitCode"] == 0
    assert closure["RunnerCleanupValid"] and not closure["OrdinaryPathKilledAnything"]
    expected = int(owner["PID"]), str(owner["StartTicksUTC"])
    pid, ticks = re.search(r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$", raw, re.M).groups()
    assert (int(pid), ticks) == expected
    final = closure["Closure"]["FinalState"]
    assert final["State"] == "Absent" and (int(final["PID"]), final["StartTicksUTC"]) == expected
    return expected


def verify_reports(fixture):
    update = read_json(HERE / "docs/regression/CodeUpdate.json")
    assert update["ProductionSHA256"] == BOOK_SHA and update["WorkbookSHA256"] == DIAGNOSTIC_SHA
    assert update["Compiled"] and not update["ProductionChanged"] and not update["RetiredModules"]
    assert sorted(update["Modules"]) == fixture["modules"] and len(update["Modules"]) == 13
    compile_close = read_json(HERE / "CompileClosure.json")
    compile_log = (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    pid, ticks = re.search(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", compile_log, re.M).groups()
    compiler = int(pid), ticks
    assert compile_close["State"] == "Absent" and (compile_close["PID"], compile_close["StartTicksUTC"]) == compiler
    assert "PRIVATE_CODE_READY: modules=13; production unchanged=True" in compile_log
    owners = {compiler}
    proof = {}
    with TemporaryDirectory(prefix="dsi-offline-") as directory:
        for label in MACROS:
            original = HERE / "Native" / f"{label}.txt"
            raw = original.read_text(encoding="utf-8-sig")
            owner = verify_identity(raw, original, label)
            assert owner not in owners
            owners.add(owner)
            staged = Path(directory) / original.name
            copyfile(original, staged)
            validator = HERE / VALIDATORS.get(label, "Verify-Compat.py")
            args = [sys.executable, "-B", "-X", "utf8", str(validator)]
            if label not in VALIDATORS:
                args.append(label)
            check_output([*args, str(staged)])
            validated = read_json(staged.with_suffix(".Verification.json"))
            assert validated == read_json(original.with_suffix(".Verification.json"))
            expected_sha = validated.get("report_sha256", validated.get("native_sha256"))
            assert digest(original.read_bytes()) == expected_sha
            proof[label] = {
                "report_sha256": expected_sha,
                "verified_json_sha256": digest(original.with_suffix(".Verification.json").read_bytes()),
                "native_pid": owner[0],
                "native_start_ticks": owner[1],
                "details": validated,
            }
    return proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--git", type=Path, help="also verify the baseline against this local Git repository")
    parser.add_argument("--write-summary", type=Path, help="export reconstructed source and native verification summary")
    args = parser.parse_args()
    manifest = read_json(HERE / "SHA256SUMS.json")
    for name, expected in manifest.items():
        assert digest((HERE / name).read_bytes()) == expected, name
    fixture_path = HERE / "Fixture.json"
    fixture = read_json(fixture_path)
    assert digest(fixture_path.read_bytes()) == FIXTURE_SHA
    assert fixture["workbook_sha256"] == fixture["frozen"][BOOK] == BOOK_SHA
    assert fixture["test_appended_to_production_only_for_probe"] == [SECTION]
    for name, expected in fixture["frozen"].items():
        if name != BOOK:
            assert digest((HERE / name).read_bytes()) == expected, name
    path = HERE / "Production/ProductionManifest.json"
    assert digest(path.read_bytes()) == fixture["production_manifest_sha256"]
    sources = verify_provenance(fixture, read_json(path), args.git)
    reports = verify_reports(fixture)
    summary = {
        "historical_commit": COMMIT,
        "historical_workbook_sha256": BOOK_SHA,
        "diagnostic_workbook_sha256": DIAGNOSTIC_SHA,
        "fixture_sha256": FIXTURE_SHA,
        "production_manifest_sha256": fixture["production_manifest_sha256"],
        "production_file_count": len(sources),
        "production_and_probe_source_deltas": sources,
        "native": reports,
    }
    if args.write_summary is not None:
        args.write_summary.write_bytes((json.dumps(summary, indent=2) + "\n").encode("utf-8"))
    else:
        assert summary == read_json(HERE / "Verification.json")
    print("PASS DSI OFFLINE", FIXTURE_SHA, DIAGNOSTIC_SHA, ",".join(MACROS))


if __name__ == "__main__":
    assert not sys.flags.optimize
    main()
