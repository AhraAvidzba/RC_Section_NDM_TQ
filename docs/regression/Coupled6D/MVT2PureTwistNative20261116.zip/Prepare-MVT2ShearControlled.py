"""Freeze the current workbook, archived B fields, and diagnostic-only module."""
import argparse
import hashlib
import json
from pathlib import Path
from shutil import copyfile

HERE=Path(__file__).resolve().parent
PRIOR=Path("D:/CodexScratch/RC_Section_NDM_TQ/MVT2MinimumFields")
BOOK=Path("workbook/output/RC_Section_NDM.xlsm")
DRAFT=Path("docs/regression/Diagnostic.xlsm")
MODULE=Path("tests/modTestCoupledExperiment.bas")
BOOK_SHA="9A99BF072D67536CBCCA525A75E049F510C5242D46CB4EA3ADA7BC4C726088F8"
PREFIX_SHA="504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def main(repo, stage):
    assert digest(repo/BOOK)==BOOK_SHA
    archived=PRIOR/"MVT2ShearBReplay.csv"
    assert digest(archived)==PREFIX_SHA
    former=json.loads((PRIOR/"Preparation.json").read_text(encoding="utf-8"))
    assert digest(PRIOR/MODULE)==former["export_macro_sha256"]
    composed=((PRIOR/MODULE).read_text(encoding="utf-8-sig")+"\n"+
              (HERE/"Control.bas").read_text(encoding="utf-8")).replace("\n","\r\n").encode("utf-8")
    tools={path.relative_to(PRIOR):path for path in (PRIOR/"tools/build_workbook").iterdir() if path.is_file()}
    sources={**tools,BOOK:repo/BOOK,Path("Guard-IsolatedOffice.ps1"):PRIOR/"Guard-IsolatedOffice.ps1",Path("Replay.csv"):archived}
    for key,path in tools.items():
        assert digest(path)==former["frozen"][key.as_posix()]
    assert digest(sources[Path("Guard-IsolatedOffice.ps1")])==former["frozen"]["Guard-IsolatedOffice.ps1"]
    additional={'AnchorField.csv': '8529433F832D50B367E5CBFF20F3AD707EC2410AE84DF9AD381F31647D8826FE', 'Fields.csv': '442E550ABDDC39A1CDE29D0391420A5DD506581DCB7894244A57CBE0B061C869', 'WorkItem.json': '96ADDE0E5C8B1CDEDE2D886B9AC91578BBC06A4299DC8400C66A6BEF36A79342', 'PreviousNative.csv': '16DD7D97534AF4E9C23CA4D5E04D70099563821E5AD339FBCE7214BC312FB436'}
    assert all(digest(HERE/name)==identity for name,identity in additional.items())
    data={"prior_input_sha256":additional,"book_sha256":BOOK_SHA,"replay_sha256":PREFIX_SHA,"watchdog_seconds":200,
          "only_updated_module":"modTestCoupledExperiment",
          "sources":{key.as_posix():digest(path) for key,path in sources.items()},
          "module_sha256":hashlib.sha256(composed).hexdigest().upper(),
          "native_harness":digest(HERE/"Run-MVT2ShearControlled.ps1")}
    receipt=HERE/"Preparation.json"
    if stage:
        assert not receipt.exists() and not (HERE/DRAFT).exists()
        for key,src in sources.items():
            dest=HERE/key
            dest.parent.mkdir(parents=True,exist_ok=True)
            assert not dest.exists()
            copyfile(src,dest)
        for directory in ("tests","Temp","Native","docs/regression"):
            (HERE/directory).mkdir(parents=True,exist_ok=True)
        (HERE/MODULE).write_bytes(composed)
        copyfile(HERE/BOOK,HERE/DRAFT)
        receipt.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
    assert json.loads(receipt.read_text(encoding="utf-8"))==data
    assert (HERE/MODULE).read_bytes()==composed
    assert all(digest(HERE/name)==expected for name,expected in data["sources"].items())
    print(data["book_sha256"],digest(receipt))

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo",type=Path)
    parser.add_argument("--stage",action="store_true")
    opts=parser.parse_args()
    main(opts.repo.resolve(strict=True),opts.stage)