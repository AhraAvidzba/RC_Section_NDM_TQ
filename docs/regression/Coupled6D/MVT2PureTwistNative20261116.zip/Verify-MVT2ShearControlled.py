"""Independent native verification of the measured MVT2 secant predictions and rollback."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import sys
import csv
import json
import math

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def read_native(path,encoding="cp1251"):
    tables=defaultdict(list)
    for marker,*row in csv.reader(path.read_text(encoding=encoding).splitlines(),delimiter=";"):
        tables[marker].append(row)
    return tables


def verified_states(tags):
    fields, stations = {}, defaultdict(dict)
    for name, history, q, *x in tags["B_TANGENT_FIELD"]:
        assert name not in fields and len(x) == 60
        fields[name] = (int(history), float(q), tuple(map(float, x)))
    for name, point, side, *row in tags["B_TANGENT_STATION"]:
        key = int(point), int(side)
        assert key not in stations[name] and len(row) == 19
        stations[name][key] = tuple(map(float, row))
    raw_r = vec(tags, "B_TANGENT_RESIDUAL")
    raw_force = {name: tuple(map(float, row)) for name, *row in tags["B_BOUND_ACTUAL"]}
    raw_norm = {name: float(value) for name, value in tags["B_BOUND_NORM"]}
    output = {}
    assert set(fields) == set(stations) == set(raw_r) == set(raw_force) == set(raw_norm)
    for name, (history, q, x) in fields.items():
        assert history == 24 and len(stations[name]) == 135
        rows, actual, strain_error = reconstruct(x, q, stations[name])
        error = peak(diff(rows, raw_r[name]))
        assert strain_error < 4e-15 and error < 3e-10
        assert max(abs(a-b)/s for a,b,s in zip(actual, raw_force[name], SCALES, strict=True)) < 4e-12
        signed = diff(actual, force(q))
        efforts = tuple(r/s for r, s in zip(signed, SCALES, strict=True))
        residual = (*rows[:56], *efforts)
        gauge_norm = MODULUS*peak(rows[56:])
        tol = 5e-7*(1.+peak(loading(q)))
        near(max(peak(residual), gauge_norm),raw_norm[name], 4e-10)
        assert gauge_norm <= tol
        output[name] = {"q": q, "field": x, "r": residual, "gauge_MPa": gauge_norm, "tol_MPa": tol,
            "signed_force_N_Nmm": signed, "norm_MPa": peak(residual), "reconstruction_error_MPa": error,
            "geometry": {key: row[:3] for key, row in stations[name].items()}}
    return output, stations


def tensor_radius(field, geometry):
    maximum = 0.
    for (_, side), (x, y, _) in geometry.items():
        strain = strain_at(field, operators(x, y), side)
        maximum = max(maximum, peak(s/(1. if i < 3 else math.sqrt(2.)) for i, s in enumerate(strain)))
    return maximum


HERE=Path(__file__).resolve().parent
NATIVE=HERE/'Native'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def verify_run(prep):
    build=read(HERE/'docs/regression/CodeUpdate.json')
    compiler=read(HERE/'CompileClosure.json')
    owner=read(NATIVE/'MVT2.txt.Ownership.json')
    watch=read(NATIVE/'MVT2.txt.ProcessClosure.json')
    receipt=read(NATIVE/'RunReceipt.json')
    final=watch['Closure']['FinalState']
    assert build['Compiled'] and build['Modules']==['modTestCoupledExperiment'] and not build['ProductionChanged']
    assert build['ProductionSHA256']==prep['book_sha256'] and compiler['State']=='Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==build['WorkbookSHA256']
    assert watch['Passed'] and watch['ChildExitCode']==receipt['native_exit']==0 and watch['ChildHasExited']
    assert final['State']=='Absent' and final['PID']==owner['PID'] and final['StartTicksUTC']==owner['StartTicksUTC']
    assert 'TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0' in (NATIVE/'MVT2.txt').read_text(encoding='utf-8-sig')
    if '--offline' not in sys.argv:
        assert digest(HERE/'docs/regression/Diagnostic.xlsm')==build['WorkbookSHA256']
    return compiler,final,receipt['wall_seconds']


def verify_steel(tags, native, stations, accepted):
    steel=defaultdict(dict)
    for name,point,side,ax,e,concrete,sigma in tags['B_BOUND_STEEL']:
        key=int(point),int(side)
        assert key not in steel[name]
        steel[name][key]=int(ax)-1,float(e),float(concrete),float(sigma)
    assert set(steel)==set(native)
    peaks={}
    for name,stress in steel.items():
        assert len(stress)==60
        for (point,side),(ax,e,concrete,sigma) in stress.items():
            row=stations[name][point,side]
            x,y,area=row[:3]
            assert ax==(2 if point<=29 else 1 if abs(x)>abs(y) else 0)
            near(e,row[7+ax],4e-16)
            near(sigma,row[13+ax]+concrete,4e-10)
            near(sigma,200000.*e,4e-8)
            limit=498. if point<=29 else 450.
            assert abs(sigma)<limit
            block=operators(x,y)
            assert max(abs(strain_at(q,block,side)[ax])*200000. for q in accepted.values())<limit
        peaks[name]=max(abs(row[3]) for row in stress.values())
    return peaks


def main():
    prep=read(HERE/'Preparation.json')
    compiler,owner,wall=verify_run(prep)
    assert digest(HERE/'Replay.csv')==prep['replay_sha256']
    assert digest(HERE/'tests/modTestCoupledExperiment.bas')==prep['module_sha256']
    assert all(digest(HERE/name)==value for name,value in prep['prior_input_sha256'].items())
    tags=read_native(NATIVE/'MVT2.csv')
    native,stations=verified_states(tags)
    earlier,early_stations=verified_states(read_native(HERE/'PreviousNative.csv','ascii'))
    old_anchor=earlier['Anchor']
    archived=list(csv.reader((HERE/'Replay.csv').read_text().splitlines(),delimiter=';'))[1:]
    accepted=vec(tags,'MVT2_CONTROL_FIELD')
    assert len(accepted)==len(archived)==24
    for i,r in enumerate(archived,1):
        assert int(r[0])==i and peak(diff(tuple(map(float,r[9:])),accepted[f'Replay{i}']))<1e-15
    [[qbase,qtrial]]=tags['B_TANGENT_LOAD']
    qbase,qtrial=map(float,(qbase,qtrial))
    near(qbase,float(archived[-1][2]),2e-13)
    near(qtrial,qbase+(qbase-float(archived[-2][2]))/64.,2e-13)
    anchors=['Base24','Restored24','TwistPlus/Rollback','TwistMinus/Rollback']
    for name in anchors:
        assert native[name]==native['Base24'] and native[name]['q']==qbase
        assert native[name]['field']==accepted['Replay24'] and stations[name]==stations['Base24']
    assert tags['B_TANGENT_END']==[['24',f'{qbase:g}']] or (len(tags['B_TANGENT_END'])==1 and tags['B_TANGENT_END'][0][0]=='24' and float(tags['B_TANGENT_END'][0][1])==qbase)
    anchor=native['Anchor']
    assert anchor['q']==old_anchor['q']==qtrial and anchor['geometry']==old_anchor['geometry']
    assert peak(diff(anchor['field'],old_anchor['field']))<3e-15
    assert peak(diff(anchor['r'],old_anchor['r']))<4e-10
    assert max(peak(diff(x,early_stations['Anchor'][key])) for key,x in stations['Anchor'].items())<3e-9
    tol=anchor['tol_MPa']; caps=tuple(max(tol,abs(v)) for v in anchor['r'][56:])
    [[r0_log,tol_log]]=tags['B_MEASURE_ORIGIN']
    near(float(r0_log),anchor['norm_MPa'],4e-10); near(float(tol_log),tol,5e-15)
    [[name,*native_caps]]=tags['B_MEASURE_CAPS']
    assert name=='Anchor' and peak(diff(tuple(map(float,native_caps)),caps))<4e-10
    work=read(HERE/'WorkItem.json')
    data=check_prepared_fields(work,anchor)
    assert set(native)==set(anchors+['Anchor','TwistPlus','TwistMinus'])
    inputs={name:float(radius) for name,radius in tags['B_MEASURE_INPUT']}
    assert set(inputs)=={'TwistPlus','TwistMinus'}
    native_status={name:tuple(map(int,v)) for name,*v in tags['B_MEASURE_STATUS']}
    native_effort={name:tuple(map(float,v)) for name,*v in tags['B_MEASURE_RELATIVE_EFFORTS']}
    assert set(native_effort)==set(native_status)==set(inputs)
    steel=verify_steel(tags,native,stations,accepted)
    reports={}
    for name,sign in (('TwistPlus',1.),('TwistMinus',-1.)):
        payload=data[name]
        state=native[name]
        assert state['q']==qtrial
        assert peak(diff(state['field'],payload['coordinates']))<3e-15
        actual_delta=diff(state['field'],native['Anchor']['field'])
        assert all(v==0. for i,v in enumerate(actual_delta) if i!=3)
        near(actual_delta[3],sign*work['q4_increment'],4e-16)
        radius=tensor_radius(actual_delta,anchor['geometry'])
        near(radius,inputs[name],5e-15)
        near(radius,work['physical_tensor_radius'],5e-15)
        assert radius<=1e-8+4e-16
        output_effort=state['r'][56:]
        assert peak(diff(output_effort,native_effort[name]))<4e-10
        violations=[key for key,v,limit in zip(EFFORT_NAMES,output_effort,caps,strict=True) if abs(v)>limit+4e-10]
        if not any(abs(abs(v)-c)<4e-10 for v,c in zip(output_effort,caps,strict=True)):
            assert native_status[name][1]==int(not violations)
        abs_error=max(state['norm_MPa'],state['gauge_MPa'])
        progress=abs_error<anchor['norm_MPa']
        full=abs_error<=tol
        assert native_status[name][0]==int(full) and native_status[name][2]==int(progress)
        responses=diff(state['r'],anchor['r'])
        d_force=diff(state['signed_force_N_Nmm'],anchor['signed_force_N_Nmm'])
        parts=[]
        max_other_kinematic=0.
        max_kinematic_discrepancy=0.
        changed_branches=0
        for key,station in stations[name].items():
            base_station=stations['Anchor'][key]
            x,y,a=station[:3]
            expected=(0.,0.,0.,0.,-y*actual_delta[3]/LENGTH,x*actual_delta[3]/LENGTH)
            new=diff(station[7:13],base_station[7:13])
            max_kinematic_discrepancy=max(max_kinematic_discrepancy,peak(diff(new,expected)))
            max_other_kinematic=max(max_other_kinematic,peak(new[:4]))
            if key[0]<=25 and station[3:6]!=base_station[3:6]:
                changed_branches+=1
            if key[1]==0:
                dz,dxz,dyz=(station[k]-base_station[k] for k in (15,17,18))
                force_parts=(a*dz,a*y*dz,a*x*dz,a*(x*dyz-y*dxz),a*dxz,a*dyz)
                parts.append((key[0],x,y,force_parts))
        assert len(parts)==45 and max_kinematic_discrepancy<=4e-16
        summed=tuple(math.fsum(v) for v in zip(*(item[3] for item in parts),strict=True))
        roundoff=work['comparison_roundoff_guard_difference_of_two_states_MPa']
        discrepancy=peak(a/s for a,s in zip(diff(summed,d_force),SCALES,strict=True))
        assert discrepancy<=roundoff and peak(d/s for d,s in zip(diff(d_force,tuple(v*s for v,s in zip(responses[56:],SCALES,strict=True))),SCALES,strict=True))<roundoff
        gain=d_force[3]
        reports[name]={'tensor_radius':radius,'measured_QDOF4_increment':actual_delta[3],
            'max_off_axis_strain_change':max_other_kinematic,'max_pure_twist_kinematics_error':max_kinematic_discrepancy,
            'signed_effort_delta_N_Nmm':d_force,'independent_station_difference_efforts_N_Nmm':summed,
            'direct_difference_reassembly_error_MPa':discrepancy,'torque_change_Nmm':gain,
            'torque_signal_expected_sign_above_original_tol':sign*gain>work['torque_signal_threshold_Nmm'],
            'direct_concrete_torque_change_Nmm':math.fsum(s[3] for j,x,y,s in parts if j<=25),
            'replacement_concrete_torque_change_Nmm':math.fsum(s[3] for j,x,y,s in parts if j>25),
            'station_force_increments_N_Nmm':parts,'changed_concrete_branch_flags':changed_branches,
            'gauge_MPa':state['gauge_MPa'],'true_max_MPa':abs_error,'full_equilibrium_at_original_tol':full,
            'worst_weak_row':max(range(56),key=lambda i:abs(state['r'][i]))+1,
            'gradient_rows_53_56_changes_MPa':responses[52:56],
            'six_resultant_residual_N_Nmm':state['signed_force_N_Nmm'],'worsened_efforts':violations,
            'genuine_reduction_at_all_six_caps':progress and not violations,
            'maximum_steel_stress_MPa':steel[name],'full_residual_MPa':state['r'],'full_action_MPa':responses}
    plus,minus=(reports[n] for n in ('TwistPlus','TwistMinus'))
    even=[a+b for a,b in zip(plus['full_action_MPa'],minus['full_action_MPa'],strict=True)]
    final={'source_workbook_sha256':prep['book_sha256'],'replay_sha256':prep['replay_sha256'],
        'native_trace_sha256':digest(NATIVE/'MVT2.csv'),'compiler':compiler,'owner':owner,'native_wall_s':wall,
        'target_Qy_kN':qtrial,'qLastAccepted_kN':qbase,'anchor_norm_MPa':anchor['norm_MPa'],'equilibrium_tolerance_MPa':tol,
        'effort_cap_MPa':caps,'anchor_signed_force_error_N_Nmm':anchor['signed_force_N_Nmm'],
        'anchor_r_vector_MPa':anchor['r'],'both_exact_rollbacks':True,'native_results':reports,
        'pure_twist_torque_signal_measured':all(x['torque_signal_expected_sign_above_original_tol'] for x in reports.values()),
        'conservative_two_state_arithmetic_guard_MPa':work['comparison_roundoff_guard_difference_of_two_states_MPa'],
        'nominal_T_signal_threshold_Nmm':work['torque_signal_threshold_Nmm'],
        'signed_even_part_peak_MPa':peak(even),'signed_even_part_peak_row':max(range(62),key=lambda k:abs(even[k]))+1,
        'material_history_advanced':False,'physical_limit_confirmed':False}
    path=HERE/'Verification.json'
    path.write_text(json.dumps(final,indent=2)+'\n',encoding='utf8')
    print(path,digest(path))


def check_prepared_fields(work,anchor):
    flux=work['q4_increment']
    assert anchor['q']==work['fixed_Qy_kN'] and 0.<flux<1e-8
    near(anchor['tol_MPa'],work['original_tolerance_MPa'],5e-15)
    near(work['comparison_roundoff_guard_difference_of_two_states_MPa'],2.*work['force_comparison_guard_each_state_MPa'],1e-18)
    near(work['archived_T_loss_for_axial_plus_Nmm'],flux*work['archived_normalized_J44_at_another_field_MPa']*SCALES[3],2e-7)
    near(work['torque_signal_threshold_Nmm'],max(anchor['tol_MPa'],work['comparison_roundoff_guard_difference_of_two_states_MPa'])*SCALES[3],1e-10)
    rows=list(csv.reader((HERE/'Fields.csv').read_text().splitlines(),delimiter=';'))[1:]
    assert len(rows)==3
    planned={}
    for (expected,sign),(name,loaded,*row) in zip((('Centre',0),('TwistPlus',1),('TwistMinus',-1)),rows,strict=True):
        field=tuple(map(float,row))
        assert name==expected and float(loaded)==anchor['q']
        assert peak(diff(tuple(a+(sign*flux if j==3 else 0.) for j,a in enumerate(anchor['field'])),field))<3e-15
        actual=diff(field,anchor['field'])
        radius=tensor_radius(actual,anchor['geometry'])
        near(radius,abs(sign)*work['physical_tensor_radius'],5e-15)
        assert radius<=1e-8 and max(abs(actual[j]) for j in range(60) if j!=3)<3e-15
        planned[name]={'coordinates':field,'tensor_radius':radius}
    return planned


def prevalidate():
    prep=read(HERE/'Preparation.json')
    assert all(digest(HERE/name)==value for name,value in prep['prior_input_sha256'].items())
    data,_=verified_states(read_native(HERE/'PreviousNative.csv','ascii'))
    anchor=data['Anchor']
    work=read(HERE/'WorkItem.json')
    check=check_prepared_fields(work,anchor)
    message={'workbook_sha256':prep['book_sha256'],'input_hashes':prep['prior_input_sha256'],'H24_sha256':prep['replay_sha256'],
        'fixed_Qy_kN':anchor['q'],'calibrated_original_tol_MPa':anchor['tol_MPa'],
        'original_C_norm_MPa':anchor['norm_MPa'],'original_C_signed_effort_N_Nmm':anchor['signed_force_N_Nmm'],
        'all_six_individual_caps_N_Nmm':[max(abs(v),anchor['tol_MPa']*s) for v,s in zip(anchor['signed_force_N_Nmm'],SCALES,strict=True)],
        'q4_increment_signed':work['q4_increment'],'witness_radius':check['TwistPlus']['tensor_radius'],
        'torque_signal_Nmm':work['torque_signal_threshold_Nmm'],'roundoff_guard_torque_difference_Nmm':work['comparison_roundoff_guard_difference_of_two_states_MPa']*SCALES[3]}
    out=HERE/'InputCheck.json'
    out.write_text(json.dumps(message,indent=2)+'\n',encoding='utf8')
    print(out,digest(out))


if __name__=='__main__':
    if '--inputs-only' in sys.argv:
        prevalidate()
    else:
        main()
