"""Compare MVT2 twist-control increments in station strain and solver coordinates."""
import argparse
from csv import reader
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np

RAW_SHA = "6E51126D79B633FBD61D1C7A2CB3EE3FD8A5E31413695E17B3F28CED6329772D"
L = float(np.hypot(110., 110.))
STATIONS = [(x, y, z) for z in (-.001, 0., .001)
            for y in (-96., -48., 0., 48., 96.)
            for x in (-96., -48., 0., 48., 96.)]
TENSOR_SCALE = np.array([1., 1., 1., 2.**-.5, 2.**-.5, 2.**-.5])


def basis(x):
    t = (x + 120.) / 240.
    u = 1. - t
    return (np.array([u**3, 3*u*u*t, 3*u*t*t, t**3]),
            np.array([-u*u, u*u-2*u*t, 2*u*t-t*t, t*t]) * (3. / 240.))


def stations(q):
    u, v, w = q[4:52].reshape(16, 3).T
    values = []
    for x, y, z in STATIONS:
        bx, dx = basis(x)
        by, dy = basis(y)
        dx = np.outer(by, dx).ravel() * L
        dy = np.outer(dy, bx).ravel() * L
        xx, yy = x / L, y / L
        twist = q[3] + z*q[55]
        values.append([
            dx@u, dy@v, q[0]+q[1]*yy+q[2]*xx+z*(q[52]+q[53]*yy+q[54]*xx),
            dy@u+dx@v, dx@w-twist*yy, dy@w+twist*xx])
    return np.array(values)


def geometry(old, new, predicted_ratio):
    old = old.ravel()
    new = new.ravel()
    a, b = np.linalg.norm(old), np.linalg.norm(new)
    dot = old @ new
    return dict(previous_norm=float(a), trial_norm=float(b),
                ratio_to_nominal=float(b / (predicted_ratio*a)),
                cosine=float(dot / (a*b)),
                projected_fraction=float(dot / (a*a)),
                orthogonal_fraction=float(np.linalg.norm(new - old*(dot/(a*a))) / b))


def main(archive_path):
    with ZipFile(archive_path) as archive:
        data = archive.read("Native/MVT2.csv")
    identity = sha256(data).hexdigest().upper()
    assert identity == RAW_SHA, identity
    rows = list(reader(StringIO(data.decode("cp1251")), delimiter=";"))
    fields = {r[1]: np.array(r[2:], float) for r in rows
              if r[0] == "MVT2_CONTROL_FIELD"}
    base = fields["Replay24"]
    assert np.array_equal(base, fields["Base"])
    history = base - fields["Replay23"]
    y0 = stations(base)
    dy0 = stations(history)
    out = dict(native_trace_sha256=identity, previous={})
    for index in (23, 24):
        a, b = (fields[f"Replay{i}"] for i in (index-2, index-1))
        c = fields[f"Replay{index}"]
        out["previous"][index] = geometry(stations(b-a)*TENSOR_SCALE,
                                          stations(c-b)*TENSOR_SCALE, 1.)
    out["raw"] = {}
    for label in ("TwistNative", "TwistConsistent"):
        raw = fields[label + "/Raw"]
        assert np.array_equal(fields[label + "/Rollback"], base)
        d = raw - base
        ratio = d[3]/history[3]
        ds = stations(d)
        assert abs(ratio - 1/64) < 1e-12
        assert np.max(np.abs(y0 + ds - stations(raw))) < 1e-17
        delta = np.linalg.norm(ds*TENSOR_SCALE, axis=1)
        loc = int(np.argmax(delta))
        previous_local = np.linalg.norm(dy0*TENSOR_SCALE, axis=1)
        out["raw"][label] = dict(twist_ratio=float(ratio),
            solver=geometry(history[:56], d[:56], ratio),
            frobenius=geometry(dy0*TENSOR_SCALE, ds*TENSOR_SCALE, ratio),
            max_abs_local_strain=float(delta[loc]), location_mm=list(STATIONS[loc]),
            max_abs_at_predicted_local_d=float(ratio*np.max(previous_local)),
            component_rms=np.sqrt((ds**2).mean(axis=0)).tolist())
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = main(args.archive)
    args.output.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(sha256(args.output.read_bytes()).hexdigest().upper())
