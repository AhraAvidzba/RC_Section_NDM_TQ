"""ДЛЯ ТЕСТОВ. Готовит штатный контроллер с новой рабочей координатой от точных 147 исходных состояний."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestStage(root, parent):
    """Меняет только тестовый вызов и входную историю; рабочие классы берёт из проверенной компиляции родителя."""
    here = Path(__file__).resolve().parent
    read = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original = read(parent / 'Input/Original147.bin')
    prefix = read(parent / 'Input/Reverse1.bin')
    assert len(original['fields']) == 147 and len(prefix['fields']) == 184
    for key in ('fields', 'fractions', 'lambdas'):
        assert np.array_equal(original[key], prefix[key][:147]), key
    for key in ('calibration', 'options', 'offset', 'direction'):
        assert np.array_equal(original[key], prefix[key]), key
    run_path(str(here / 'Stage-TestWorkingControllerResume.py'))['TestStage'](root, parent)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'Input/Reverse1.bin'
    (root / name).write_bytes((parent / 'Input/Original147.bin').read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = Path(__file__).name
    (root / name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='WorkingEnvelopeController147', initial_history_states=147,
        input_fields_exact_original_Double=True, later_fields_decimal_reconstructed=False,
        component_count_expected=254, actual_import_this_pass=['modTestCoupledElasticState'],
        working_class_sources_current=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('WORKING ENVELOPE CONTROLLER READY; EXACT 147-STATE HISTORY; ONLY TEST CALLBACK TO IMPORT')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    a = p.parse_args()
    TestStage(a.root.resolve(), a.parent.resolve())
