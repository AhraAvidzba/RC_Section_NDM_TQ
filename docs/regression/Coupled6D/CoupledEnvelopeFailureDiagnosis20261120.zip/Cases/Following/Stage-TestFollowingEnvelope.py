"""ДЛЯ ТЕСТОВ. Готовит сопровождение H после успешного штатного переключения без раннего резерва при первом отказе."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo,root,parent):
    """Заменяет только рабочий контроллер; тестовый вызов Trace и точные входные поля сохраняет из родительской сборки."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestStockYieldEvent.py'))['TestStage'](repo,root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='FollowHAfterVerifiedLateSwitch',
        actual_import_this_pass=['CCoupledDeformationContinuation'],fresh_compilation_claimed=True,
        source_classes_unchanged=False,early_on_failure_policy_enabled=False,
        follow_only_after_verified_H_candidate=True,H_step_growth=1.25,
        original_force_and_material_tolerances=True,physical_parameters_unchanged=True,
        steel_and_design_checks_in_common_acceptance_loop=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('FOLLOW H AFTER VERIFIED SWITCH READY; ONE CONTROLLER IMPORT; ORIGINAL CRITERIA')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,required=True);p.add_argument('--parent',type=Path,required=True)
    a=p.parse_args();TestStage(a.repo.resolve(),a.root.resolve(),a.parent.resolve())
