"""ДЛЯ ТЕСТОВ. Проверяет промежуточные H-цели без принятия материальной истории и сохраняет полную разностную матрицу."""
from argparse import ArgumentParser
from hashlib import sha256
import json,re
from pathlib import Path
from runpy import run_path


def TestStage(root,parent):
    """Меняет один тестовый модуль; промежуточные поля служат только начальными приближениями следующего уровня."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingControllerResume.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    name='tests/modTestCoupledElasticState.bas'
    source=(parent/name).read_text('utf-8-sig')
    body=re.search(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',source)[0]
    body=body.replace('    Dim candidates As New Collection, factors As New Collection, identifiers As New Collection',
        '''    Dim fullTargetTest As Double: fullTargetTest = target
    Dim levelsTest As Variant: levelsTest = Array(0.125, 0.25, 0.5, 0.75, 1#)
    Dim seedFactorTest As Double: seedFactorTest = factor
    Dim warmTargetTest As Double: warmTargetTest = baseline
    Dim warmFieldTest() As Double: warmFieldTest = accepted
    Dim warmFactorTest As Double: warmFactorTest = factor
    Dim candidates As New Collection, factors As New Collection, identifiers As New Collection''',1)
    body=body.replace('        lambda = 0#: maximum = 0#',
        '''        target = baseline + levelsTest(caseIndex - 1) * (fullTargetTest - baseline)
        Dim warmRatioTest As Double: warmRatioTest = (target - baseline) / increment
        seed = accepted: seedFactorTest = factor + warmRatioTest * (factor - previousFactor)
        For degree = 1 To mReverseSolverTest.PhysicalDegreeCount
            seed(degree) = accepted(degree) + warmRatioTest * (accepted(degree) - previous(degree))
        Next degree
        If warmTargetTest > baseline Then
            warmRatioTest = (target - baseline) / (warmTargetTest - baseline)
            For degree = 1 To mReverseSolverTest.PhysicalDegreeCount
                seed(degree) = accepted(degree) + warmRatioTest * (warmFieldTest(degree) - accepted(degree))
            Next degree
            seedFactorTest = factor + warmRatioTest * (warmFactorTest - factor)
        End If
        Print #report, "LEVEL" & TestHardPreparedVector(Array(caseIndex, target, warmTargetTest, seedFactorTest))
        lambda = 0#: maximum = 0#''',1)
    body=body.replace('projection, coordinate, seed, factor + predictorRatioTest * (factor - previousFactor))',
        'projection, coordinate, seed, seedFactorTest)',1)
    body=body.replace('CLng(mReverseOptionsTest(2)), tolerance,','15, tolerance,',1)
    body=body.replace('            Print #report, "BEST" & TestHardPreparedVector(Array(caseIndex, lambda, maximum))',
        '''            Print #report, "BEST" & TestHardPreparedVector(Array(caseIndex, lambda, maximum))
            Print #report, "FIELD;" & CStr(caseIndex) & TestHardPreparedVector(field)
            TestEnvelopeHomotopyMatrix equations, solution, caseIndex''',1)
    body=body.replace('                    candidates.Add field: factors.Add lambda: identifiers.Add caseIndex',
        '''                    warmFieldTest = field: warmFactorTest = lambda: warmTargetTest = target
                    candidates.Add field: factors.Add lambda: identifiers.Add caseIndex''',1)
    body=body.replace('WorkingEnvelopeDifferenceBatch;SameAcceptedHistory','WorkingEnvelopeHomotopy;SameAcceptedHistory',1)
    code=(root/name).read_text('utf-8-sig')
    code,n=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert n==1
    code+='''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет центральную разностную матрицу в нормированных координатах; каждая проба читает ту же принятую историю.
Private Sub TestEnvelopeHomotopyMatrix(ByVal equations As ICoupledEquationSystem, ByRef point() As Double, ByVal identifier As Long)
    Dim report As Integer: report = FreeFile
    Open mPolishRootTest & "\\Native\\HomotopyMatrix" & CStr(identifier) & ".csv" For Output As #report
    Print #report, "X" & TestHardPreparedVector(point)
    Dim size As Long: size = UBound(point)
    Dim column As Long, row As Long, delta As Double, plus() As Double, minus() As Double, positive() As Double, negative() As Double, unused() As Double
    Dim values() As Double: ReDim values(1 To size)
    For column = 1 To size
        delta = 0.000001 * (1# + Abs(point(column)))
        plus = point: minus = point
        plus(column) = point(column) + delta: minus(column) = point(column) - delta
        If Not equations.TryEvaluate(plus, False, positive, unused) Then Err.Raise 5, , "Нет положительной разностной пробы H."
        If Not equations.TryEvaluate(minus, False, negative, unused) Then Err.Raise 5, , "Нет отрицательной разностной пробы H."
        For row = 1 To size: values(row) = (positive(row) - negative(row)) / (2# * delta): Next row
        Print #report, "COLUMN;" & CStr(column) & TestHardPreparedVector(values)
    Next column
    Close #report
End Sub
'''
    assert max(map(len,code.splitlines()))<1024
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name='Input/EnvelopeDifferenceOptions.bin'
    (root/name).write_bytes(run_path(str(here/'Stage-TestMaterialBranchEnergy.py'))['TestVector']([v for _ in range(5) for v in (1e-6,1.,1.)]))
    prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ActualFailedEnvelopeHomotopy',
        levels=[.125,.25,.5,.75,1.],maximum_iterations_per_level=15,
        accepted_material_history_unchanged=True,source_classes_unchanged=True,
        physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('H HOMOTOPY READY; FIVE TARGETS; SAME ACCEPTED HISTORY; MATRIX EXPORT')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True);p.add_argument('--parent',type=Path,required=True);a=p.parse_args()
    TestStage(a.root.resolve(),a.parent.resolve())
