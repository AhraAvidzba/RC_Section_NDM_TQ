
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает два значения ft при неизменных энергиях, сечении и протоколе нагружения MVT2.
' Обе истории кручения начинаются с нуля. Продолжение по Qy запускается отдельно.
Public Function RunTestWangCrackSensitivity(ByVal routeMode As String) As String
    Dim report As String, path As String, passed As Long, failed As Long
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для сравнения MVT2 нужна изолированная книга."
    path = ThisWorkbook.Path & "\WangCrackSensitivity.csv"
    Select Case routeMode
        Case "Marker"
            If RunWangCrackRouteTest("A", False, report, path) Then passed = passed + 1 Else failed = failed + 1
            If RunWangCrackRouteTest("B", False, report, path) Then passed = passed + 1 Else failed = failed + 1
        Case "ShearA", "ShearB"
            If RunWangCrackRouteTest(Right$(routeMode, 1), True, report, path) Then passed = passed + 1 Else failed = failed + 1
        Case Else
            Err.Raise 5, , "Укажите режим Marker, ShearA или ShearB."
    End Select
    RunTestWangCrackSensitivity = report & "TOTAL_COUPLED_WANG_CRACK_SENSITIVITY: passed=" & CStr(passed) & "; failed=" & CStr(failed)
    Exit Function
Failed:
    RunTestWangCrackSensitivity = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет интегральное равновесие принятых состояний и сохраняет состояние до численной остановки.
Private Function RunWangCrackRouteTest(ByVal lawTag As String, ByVal combined As Boolean, _
        ByRef report As String, ByVal tracePath As String) As Boolean
    Const EC As Double = 30000#, NU As Double = 0.2, PEAK As Double = 0.0022, PRELOAD As Double = 10.51
    Const TORQUE_UNITS As Double = 1000000#, FORCE_UNITS As Double = 1000#, MOMENT_PER_SHEAR As Double = 600000#
    Const FT_B As Double = __FT_B__
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005, MAX_NATIVE_RESIDUAL As Double = 0.000005
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim fc As Double, ft As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#)
    nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt ' В обоих маршрутах сохраняется одна энергия сжатия.
    ft = nominalFt
    If lawTag = "B" Then ft = FT_B ' Эквивалент начала чистого сдвига в 25 точках при 6,50 кН·м.
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver, branch As New CCoupledLoadContinuation
    Dim path As New CLoadPathVector, shearX() As Double, shearY() As Double
    operators.PrepareModel section, EC, NU, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура MVT2 не совпала с архивом."
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, ft, PEAK, gt, gc, True
    operators.MeanShearProjections shearX, shearY
    Dim goals As Variant, kind As String, route As String
    If combined Then
        kind = "Shear"
        goals = Array(0#, 15#, 22.11622, 25#, 30#) ' Точный силовой маршрут исходной проверки, без деформационного обхода.
        path.Initialize 0#, 0#, 0#, MOMENT_PER_SHEAR, 0#, 0#, PRELOAD * TORQUE_UNITS, 0#, 0#, 0#, 0#, FORCE_UNITS
    Else
        kind = "Torque"
        goals = Array(5.2, 6.45, 6.49, 6.5, 6.51, 6.55, 7.8, 9.1, 9.45, 9.46, 9.47, 9.5, 10.4, PRELOAD)
        path.Initialize 0#, 0#, 0#, 0#, 0#, 0#, 0#, TORQUE_UNITS, 0#, 0#, 0#, 0#
    End If
    route = lawTag & "/" & kind
    branch.Initialize solver, path, 8, 44, 26, ABS_TOL, REL_TOL, True
    AddExperimentTraceTest report, tracePath, "WANG_CRACK_CASE;" & route & ";" & ExperimentNumberTest(ft) & ";" & _
        ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc) & ";" & CStr(operators.ConcretePointCount)
    Dim start As Double: start = Timer
    Dim target As Variant, solved As Boolean, reached As Double, field() As Double, actual() As Double, expected() As Double
    Dim residual As Double, valid As Boolean: valid = True
    Dim seen As Long
    For Each target In goals
        solved = branch.Advance(CDbl(target))
        reached = branch.AcceptedLambda
        RecordWangPairStatusTest branch, lawTag, kind, CDbl(target), reached, solved, report, tracePath
        If branch.SavedFieldCount > 0 Then
            branch.CopyAccepted field, actual
            path.TargetSix reached, expected
            If combined Then expected(4) = PRELOAD * TORQUE_UNITS * branch.AcceptedOffsetFraction
            residual = operators.ResultantResidualNorm(actual, expected)
            RecordWangMVT2StateTest operators, concrete, response, field, actual, shearY, _
                route, CDbl(target), reached, actual(4), residual, report, tracePath
            valid = valid And residual <= MAX_NATIVE_RESIDUAL
            seen = seen + 1
        End If
        If Not solved Then Exit For
        If reached <> CDbl(target) Then Err.Raise 5, , "Целевая ступень MVT2 не совпала с принятой."
    Next target
    Dim elapsed As Double: elapsed = Timer - start
    If elapsed < 0# Then elapsed = elapsed + 86400#
    AddExperimentTraceTest report, tracePath, "WANG_CRACK_END;" & route & ";" & ExperimentNumberTest(elapsed) & ";" & _
        CStr(seen) & ";" & CStr(branch.SavedFieldCount) & ";" & ExperimentNumberTest(branch.AcceptedOffsetFraction) & ";" & CStr(solved)
    RunWangCrackRouteTest = valid And seen > 0
End Function