"""Check archived physical inputs, separated native routes, and the exact marker proof."""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent

def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest().upper()

def source_table(repo: Path, physics: dict) -> None:
    # Rendering is unnecessary. Only the selected labels and numerals are read.
    import fitz
    path = repo / "literature/Coupled6D/Wang-Huang-2017-MVT-NMVT.pdf"
    assert digest(path) == physics["input_hashes"]["pdf"]
    with fitz.open(path) as pdf:
        table = pdf[12].get_text().split("Table 1. Summary of the experimental results.", 1)[1]
        labels = [line.strip() for line in table.splitlines() if line.strip()]
        for specimen, measurement in physics["observation"].items():
            row = labels.index(specimen)
            numbers = labels[row + 1:row + 9]
            assert len(numbers) == 8 and float(numbers[3]) == measurement["first_visible_kNm"]
            if specimen == "MVT2":
                assert list(map(float, numbers[1:4])) == [0., 0., 6.5]
                assert list(map(float, numbers[5:8])) == [48., 80., 10.51]
        mvt1 = labels.index("MVT1")
        assert float(labels[mvt1 + 4]) == physics["MVT1_no_visible_crack_through_kNm"]
        assert "MVT1 did not crack under torsion of 0.35Tu" in pdf[6].get_text()
        assert "load increment of each load step was 60 kN for compres-\nsive axial force and 1.3 kN" in pdf[4].get_text()

def verify(repo: Path) -> None:
    package_root = HERE.parent
    manifest = json.loads((package_root / "Manifest.json").read_text(encoding="utf-8"))
    assert manifest and all(digest(package_root / name) == expected for name, expected in manifest.items())
    native = HERE / "Native"
    traces = [(native / f"Marker-{label}.csv").read_bytes() for label in ("A", "B")]
    for label, trace in zip(("A", "B"), traces, strict=True):
        records = trace.decode("cp1251").splitlines()
        assert records
        allowed = (f"WANG_CRACK_CASE;{label}/", f"WANG_CRACK_END;{label}/", f"WANG_PAIR_STATUS;{label};", f"MVT2_STATE;{label}/")
        assert all(record.startswith(allowed) for record in records)
    assert b"".join(traces) == (native / "Marker.csv").read_bytes()
    physics = json.loads((HERE / "IndependentCrackControl.json").read_text(encoding="utf-8"))
    source_table(repo, physics)
    owner = json.loads((native / "Marker.txt.Ownership.json").read_text(encoding="utf-8-sig"))
    closure = json.loads((native / "Marker.txt.ProcessClosure.json").read_text(encoding="utf-8-sig"))
    final = closure["Closure"]["FinalState"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and closure["Passed"]
    assert final["State"] == "Absent" and owner["PID"] == final["PID"] and owner["StartTicksUTC"] == final["StartTicksUTC"]
    compilation = json.loads((HERE / "CodeUpdate.json").read_text(encoding="utf-8-sig"))
    assert compilation["Compiled"] and not compilation["ProductionChanged"]
    assert compilation["ProductionSHA256"] == "462546E8EE57451AC32F95128972E36E245517A3CADDB5D51B888DCBF0392FA2"
    assert compilation["Modules"] == ["modTestCoupledExperiment"] and owner["SourceSHA256"] == compilation["WorkbookSHA256"]
    for script, args in (("PureShearCrack.py", [str(repo)]), ("Verify-MVT2CrackSensitivity.py", ["Marker"])):
        subprocess.run([sys.executable, "-B", "-X", "utf8", str(HERE / script), *args], check=True)
    outcome = HERE / "Marker.Verification.json"
    expected = HERE / "Marker.ExpectedVerification.json"
    assert outcome.read_bytes() == expected.read_bytes()
    print("MARKER_OFFLINE_PASS", digest(outcome))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path, help="Project folder with the primary paper.")
    verify(parser.parse_args().repo.resolve(strict=True))