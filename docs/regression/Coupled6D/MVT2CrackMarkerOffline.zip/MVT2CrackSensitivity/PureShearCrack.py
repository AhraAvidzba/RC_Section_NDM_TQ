"""Invert the archived elastic MVT2 yield surface against the published inspection loads."""
from __future__ import annotations

import argparse
import csv
from hashlib import sha256
import json
from math import sqrt
from pathlib import Path

HERE = Path(__file__).resolve().parent
TRACE = HERE.parent / "MVT2TurnV4/Native/MVT2.csv"
INTEGRALS = HERE.parent / (
    "ArchivedEvidence/LocalGradientDerivative20261115/H45PanelNative20261116/"
    "MVT2Native/MVT2EquilibriumChecks.json"
)
PRIMARY = "literature/Coupled6D/Wang-Huang-2017-MVT-NMVT.pdf"
EXPECTED = {
    "trace": "2E362A0EDC31616253D79A15F9B81AC93197A02C6673246028B2F20CE07D3AA5",
    "integrals": "3FB50769E16B16A431031A3AAF820B46773981D831E2F5766BC5ACDE3FDA0ECD",
    "pdf": "6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E",
}

def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest().upper()

def build(repo: Path) -> dict:
    observed = {"T1": 10.4, "T2": 5.2, "MVT2": 6.5, "MVT3": 9.1, "MVT4": 7.8}
    resolution, lower_censored = 1.3, 6.69
    source_paths = {"trace": TRACE, "integrals": INTEGRALS, "pdf": repo / PRIMARY}
    assert {key: digest(path) for key, path in source_paths.items()} == EXPECTED
    archive = json.loads(INTEGRALS.read_text(encoding="utf-8-sig"))
    rows = list(csv.reader(TRACE.read_text(encoding="cp1251").splitlines(), delimiter=";"))
    material = next(row for row in rows if row[0] == "MVT2_MATERIAL")
    ec, nu, fc, nominal, peak, gt, gc, lc = map(float, material[1:9])
    alpha, cc = .12, .6 * fc
    a, b = (1. - alpha) * cc, sqrt(3.) - 1. - alpha
    elastic_rows = [row for row in rows if row[:2] == ["MVT2_STATE", "TorsionReplayTarget"]
                    and float(row[19]) == float(row[20]) == 0.]
    measured = [[float(row[3]), float(row[22])] for row in elastic_rows]
    assert len(measured) == 7
    vertex_slopes = [force_stress / force for force, force_stress in measured]
    section_slope = sum(vertex_slopes) / len(vertex_slopes)
    continuum_slope = archive["ContinuousElasticShearMPaPerKNm"]
    assert max(abs(k - section_slope) for k in vertex_slopes) < 1.e-13
    assert abs(section_slope - archive["NativeElasticPointShearMPaPerKNm"]) < 1.e-13

    def invert(torque: float, slope: float) -> float:
        shear = torque * slope
        return a * shear / (a - b * shear)

    def threshold(ct: float, slope: float) -> float:
        return a / (a / ct + b) / slope

    target = observed["MVT2"]
    calibrate = invert(target, section_slope)
    assert abs(threshold(calibrate, section_slope) - target) < 1.e-13
    assert abs(threshold(nominal, continuum_slope) - archive["ElasticContinuumYieldTorque_kNm"]) < 1.e-12
    control = {}
    for specimen, torque in observed.items():
        before = torque - resolution  # Nominal protocol resolution, not a timestamped negative observation.
        control[specimen] = {
            "first_visible_kNm": torque,
            "nominal_inspection_window_kNm": [before, torque],
            "equivalent_ct_MPa_continuous": [invert(t, continuum_slope) for t in (before, torque)],
            "equivalent_ct_MPa_25_points": [invert(t, section_slope) for t in (before, torque)],
        }
    assert control["T1"]["equivalent_ct_MPa_continuous"][0] > invert(observed["T2"] + resolution, continuum_slope)
    return {
        "input_hashes": EXPECTED,
        "primary_reference": "Wang and Huang 2017, doi:10.1371/journal.pone.0175834, pp. 3-7 and table 1",
        "inspection_increment_kNm": resolution,
        "elastic_fields_torque_kNm_and_sigma1_MPa": measured,
        "continuous_tau_slope_MPa_per_kNm": continuum_slope,
        "native_25_point_tau_slope_MPa_per_kNm": section_slope,
        "parameters": {"Ec_MPa": ec, "nu": nu, "fc_MPa": fc, "fc0_MPa": cc, "alpha": alpha,
                       "peak_strain": peak, "Gt_N_per_mm": gt, "Gc_N_per_mm": gc, "Lc_mm": lc},
        "A_ft_MPa": nominal,
        "B_ft_MPa": calibrate,
        "equivalent_ct_for_6_5_MPa_continuous": invert(target, continuum_slope),
        "A_yield_kNm_continuous": threshold(nominal, continuum_slope),
        "A_yield_kNm_25_points": threshold(nominal, section_slope),
        "B_yield_kNm_continuous": threshold(calibrate, continuum_slope),
        "B_yield_kNm_25_points": threshold(calibrate, section_slope),
        "observation": control,
        "MVT1_no_visible_crack_through_kNm": lower_censored,
        "MVT1_equivalent_ct_lower_bound_MPa_continuous": invert(lower_censored, continuum_slope),
        "limitations": [
            "Damage onset in a point and the observed visible crack are different markers.",
            "The nominal inspection increment is used for sensitivity, not as a precisely logged interval.",
            "No independent tensile coupon results for the individual beams are given.",
            "The adjustment is a diagnostic sensitivity for the frozen 25-point quadrature."
        ],
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    parser.add_argument("--stage", action="store_true")
    opts = parser.parse_args()
    outcome = build(opts.repo.resolve(strict=True))
    path = HERE / "IndependentCrackControl.json"
    if opts.stage:
        assert not path.exists()
        path.write_text(json.dumps(outcome, indent=2) + "\n", encoding="utf-8")
    else:
        assert json.loads(path.read_text()) == outcome
    print(digest(path))