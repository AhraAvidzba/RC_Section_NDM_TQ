"""Package native own-direction H26 evidence and perform a detached replay."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import ReplayOwnPortable as replay

HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[1]/"docs/regression/Coupled6D"
RESULT = HERE/"MVT2H26OwnFixedRecoveryNative20261117.zip"


def main():
    prep = json.loads((HERE/"Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK] == prep["book_sha256"] == replay.WORKBOOK
    indexed = {}
    for name,expected in replay.DEPENDENCIES.items():
        path = REGRESSION/name
        assert replay.digest(path.read_bytes()) == expected
        with ZipFile(path) as z:
            for member in z.namelist():
                if not member.casefold().endswith(".xlsm"):
                    indexed.setdefault(replay.digest(z.read(member)),(name,member))
    extra = ("Preparation.json","Compile.log","CompileClosure.json","Run.ndjson","docs/regression/CodeUpdate.json",
             "VerificationOwnRecovery.json","PackOwn.py","ReplayOwnPortable.py","PortableREADME.txt")
    native = tuple(f"NativeResume/{item.name}" for item in (HERE/"NativeResume").iterdir() if item.is_file())
    items, entries = {}, {}
    for name in sorted(set(prep["inputs"]) | set(extra) | set(native)):
        if name == replay.BOOK:
            continue
        raw = (HERE/name).read_bytes()
        digest = replay.digest(raw)
        if name in prep["inputs"]:
            assert digest == prep["inputs"][name]
        inherited = indexed.get(digest) if name in prep["inputs"] else None
        if inherited:
            archive,member = inherited
            entries[name] = {"archive":archive,"member":member,"sha256":digest}
        else:
            entries[name] = {"sha256":digest}
            items[name] = raw
    manifest = {"workbook":{"path":replay.BOOK,"sha256":replay.WORKBOOK},"archives":replay.DEPENDENCIES,"inputs":entries,
                "verification_sha256":entries["VerificationOwnRecovery.json"]["sha256"]}
    items["PortableManifest.json"] = (json.dumps(manifest,indent=2)+"\n").encode()
    assert all(not p.casefold().endswith(".xlsm") for p in items)
    with ZipFile(RESULT,"w",compresslevel=9) as z:
        for name,raw in sorted(items.items()):
            info = ZipInfo(name)
            info.compress_type = ZIP_DEFLATED
            z.writestr(info,raw)
    with TemporaryDirectory(dir=HERE/"Temp") as temp, ZipFile(RESULT) as z:
        assert z.testzip() is None
        z.extractall(temp)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayOwnPortable.py","--archives",str(REGRESSION)),cwd=temp,check=True)
    print(RESULT.name,RESULT.stat().st_size,replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
