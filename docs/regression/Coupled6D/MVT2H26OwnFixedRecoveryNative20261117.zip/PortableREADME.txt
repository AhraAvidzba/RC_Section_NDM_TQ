H26 legacy recovery on the ordinary fixed target's own rejected Newton ray.

    python -B -X utf8 ReplayOwnPortable.py --archives <repository>/docs/regression/Coupled6D

The original external guide is omitted from the native procedure. Reconstruct accepted histories,
solve the same fixed target with legacy recovery enabled, and compare the exact pre-recovery
diagnostic with the original stock failure. The last damped ray and its material crossing are
recorded. A full-ray crossing, when requested after an empty damped crossing, is diagnostic-only.
Any recovered field is verified separately, then eligible only as a seed for the same original
target under the remaining cap. The native trial is never committed; H24 is restored in full.
The detached proof reproduces the exact VBA overlays and original numerical checks without Excel.
