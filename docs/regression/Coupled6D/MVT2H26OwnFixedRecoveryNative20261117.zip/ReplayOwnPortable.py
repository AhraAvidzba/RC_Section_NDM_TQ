"""Replay the isolated fixed-control solver's own rejected Newton direction."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import ModuleType
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
PARENT = "MVT2H26FixedControlGuideComparisonNative20261117.zip"
DEPENDENCIES = {
    PARENT: "D9A524928E9189711CA835181691899B1CDAA7D38507F260817DC7BC3CEFD7DB",
    "MVT2H26YieldGuideOriginalPlaneNative20261117.zip": "8B5402E9D61B2C058DF2FA3033E81767C8AFF70CB82810B5807AAFFADBA2883F",
    "MVT2H26RadiusRejectionNative20261117.zip": "72D5A584147EB019F811EAA92E439F81504E88218FF499899A1BE17152FD1788",
    "MVT2ExactH26SmallerArcNative20261116.zip": "B775E3D70EED7CC8239F905AC4E3779AA65CE8994BA1F045BED899B6235B4F07",
    "MVT2AdaptiveBoundedContinuationNative20261116.zip": "A5F4EABFE14F46544D6BA36934B050AED5C5F3655DC91D32D6E8C6408562E699",
    "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
    "MVT2StockBranchArcNative20261116.zip": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def local(root, name):
    return root / (root/name).resolve().relative_to(root.resolve())


def materialize(work, manifest, archives):
    assert manifest["archives"] == DEPENDENCIES
    assert manifest["workbook"] == {"path":BOOK,"sha256":WORKBOOK}
    for name, expected in DEPENDENCIES.items():
        assert digest((archives/name).read_bytes()) == expected
    for name, record in manifest["inputs"].items():
        parent = record.get("archive")
        member = record.get("member",name)
        if parent:
            with ZipFile(archives/parent) as z:
                raw = z.read(member)
        else:
            raw = local(HERE,member).read_bytes()
        assert digest(raw) == record["sha256"], name
        dst = local(work,name)
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(raw)


def loaded(path, name):
    scope = {"__name__":name,"__file__":str(path)}
    exec(compile(path.read_text(encoding="utf-8"),str(path),"exec"),scope)
    return scope


def generation(work, archives):
    stage = loaded(work/"Stage.py","staged_fixture")
    with ZipFile(archives/PARENT) as baseline:
        assert digest(baseline.read("Preparation.json")) == stage["PREP"]
        assert digest(baseline.read("VerificationFixedControl.json")) == stage["REPORT"]
        assert baseline.read("VerificationFixedControl.json") == (work/"FixedTargetWitness.json").read_bytes()
        records = json.loads(baseline.read("PortableManifest.json"))["inputs"]
        for name, change in ((stage["SOLVER"],"overlay_solver"),(stage["MACRO"],"overlay_macro")):
            record = records[name]
            if "archive" in record:
                with ZipFile(archives/record["archive"]) as parent:
                    source = parent.read(record["member"])
            else:
                source = baseline.read(name)
            assert digest(source) == record["sha256"]
            assert stage[change](source) == (work/name).read_bytes()


def replay(work, expected):
    sys.path.insert(0,str(work))
    path = work/"ResumeBase.py"
    content = path.read_text(encoding="utf-8")
    old = '    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items())'
    assert content.count(old) == 1 and not (work/BOOK).exists()
    pin = (f'    assert prep["inputs"]["{BOOK}"] == prep["book_sha256"] == "{WORKBOOK}"\n'
           f'    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items() if path != "{BOOK}")')
    patched = ModuleType("ResumeBase")
    patched.__file__ = str(path)
    sys.modules["ResumeBase"] = patched
    exec(compile(content.replace(old,pin),str(path),"exec"),patched.__dict__)
    scope = loaded(work/"Verify-MVT2ShearControlled.py","native_proof")
    result = scope["verify"](*scope["prepare"]())
    saved = (work/"VerificationOwnRecovery.json").read_bytes()
    assert digest(saved) == expected and (json.dumps(result,indent=2)+"\n").encode() == saved
    assert result["no_external_arc_guide"] and result["H26_restored_exactly"] and result["H24_restored_exactly"]
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives",type=Path,required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE/"PortableManifest.json").read_bytes())
    with TemporaryDirectory() as root:
        work = Path(root)
        materialize(work,manifest,args.archives)
        generation(work,args.archives)
        proof = replay(work,manifest["verification_sha256"])
    print("OWN NEWTON RAY",manifest["verification_sha256"],"ROW",proof["same_stock_stall_row"],"CROSSINGS",proof["first_yield_crossings"])
    print("MODES",[(item["mode"],item["returned_trial"]) for item in proof["trials"]])


if __name__ == "__main__":
    main()
