"""Seal an H26 fixed-control probe with only its own rejected Newton ray."""
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mv26f"
PREP="C69C2B6342D38111199E5B19A0C9424B1C92EB304F341BA88C09EF73253784AF"
REPORT="4DB67D74AE025BAD266EAC590F718B8B8955A24B1198319EA60185FB099F5F36"
BOOK="workbook/output/RC_Section_NDM.xlsm"
SOLVER="src/Solver/CCoupledNewtonSolver.cls"
MACRO="tests/modTestCoupledExperiment.bas"
VERIFY="Verify-MVT2ShearControlled.py"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name,raw):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==raw, name
    else:
        path.write_bytes(raw)
    return digest(raw)


def change(source,before,after):
    assert source.count(before)==1, before
    return source.replace(before,after)


def text(raw):
    return raw.decode("utf-8-sig").replace("\r\n","\n")


def native(source):
    assert max(map(len,source.splitlines()))<1023
    return source.replace("\n","\r\n").encode()


def overlay_solver(raw):
    source=text(raw)
    anchor="Private mBoundedTraceTest As Integer ' Ненулевой канал только в изолированной пробе.\n"
    source=change(source,anchor,anchor+"Private mOwnYieldTraceTest As Integer ' Протокол штатной отклонённой поправки.\n")
    anchor="            If recoverYieldControl And Len(mismatch) > 0 And mUseSpatialHistory Then\n"
    source=change(source,anchor,anchor+'''                If mOwnYieldTraceTest > 0 Then
                    Print #mOwnYieldTraceTest, "B_OWN_STALL;" & CStr(governingRow) & ";" & Trim$(Str$(norm)) & ";" & _
                        Trim$(Str$(tolerance)) & ";" & Trim$(Str$(currentLambda)) & ";" & Trim$(Str$(baseEquation)) & ";" & _
                        Trim$(Str$(trialEquation)) & ";" & Trim$(Str$(trialFraction))
                    Print #mOwnYieldTraceTest, "B_OWN_STALL_META;" & details
                End If
''')
    anchor="    If Not FirstYieldCrossing(field, ends, station) Then Exit Function\n"
    source=change(source,anchor,'''    Dim crossed As Boolean: crossed = FirstYieldCrossing(field, ends, station)
    If mOwnYieldTraceTest > 0 Then
        PrintOwnYieldVectorTest "B_OWN_VECTOR;Stall", field
        PrintOwnYieldVectorTest "B_OWN_VECTOR;Direction", correction
        PrintOwnYieldVectorTest "B_OWN_VECTOR;Last", ends
        PrintOwnYieldCrossingTest "Last", crossed, station
        If Not crossed Then
            Dim fullTrial() As Double, fullStation As TYieldStation, fullCrossed As Boolean
            ReDim fullTrial(1 To mDegreeCount)
            For i = 1 To mDegreeCount: fullTrial(i) = field(i) + correction(i): Next i
            PrintOwnYieldVectorTest "B_OWN_VECTOR;Full", fullTrial
            fullCrossed = FirstYieldCrossing(field, fullTrial, fullStation)
            PrintOwnYieldCrossingTest "Full", fullCrossed, fullStation
        End If
    End If
    If Not crossed Then Exit Function
''')
    return native(source.rstrip()+"\n\n"+(HERE/"OwnSolver.txt").read_text(encoding="utf-8"))


def overlay_macro(raw):
    source=text(raw)
    source=change(source,"    For attempt = 1 To 3\n","    For attempt = 1 To 2\n")
    start=source.index("            If attempt = 3 Then\n                If solved Then Err.Raise")
    end=source.index("        End If\n    Next attempt\n",start)
    source=source[:start]+source[end:]
    anchor='    Next attempt\n    Print #output, "B_RESUME_END;"'
    source=change(source,anchor,'''    Next attempt
    RunWangOwnFixedTest output, solver, operators, materials, responses, workingHistory, baseField, baseFactor, committed
    Print #output, "B_RESUME_END;"''')
    start=source.index("Private Sub RunWangFixedGuideTest(")
    marker="' -------------------- ДЛЯ ТЕСТОВ --------------------\n"
    source=source[:source.rfind(marker,0,start)].rstrip()+"\n\n"+(HERE/"OwnTest.txt").read_text(encoding="utf-8")
    return native(source)


def main():
    raw=(PARENT/"Preparation.json").read_bytes()
    proof=(PARENT/"VerificationFixedControl.json").read_bytes()
    assert (digest(raw),digest(proof))==(PREP,REPORT)
    data=json.loads(raw)
    inputs={"FixedTargetWitness.json":put("FixedTargetWitness.json",proof)}
    for name,expected in data["inputs"].items():
        source=(PARENT/name).read_bytes()
        assert digest(source)==expected
        if name==VERIFY:
            inputs["FixedBase.py"]=put("FixedBase.py",source)
            continue
        if name in ("Stage.py","README.txt","FixedTest.txt"):
            continue
        if name==SOLVER:
            source=overlay_solver(source)
        if name==MACRO:
            source=overlay_macro(source)
        inputs[name]=put(name,source)
    for path in ("Stage.py","README.txt",VERIFY,"OwnTest.txt","OwnSolver.txt"):
        inputs[path]=digest((HERE/path).read_bytes())
    assert put("docs/regression/Diagnostic.xlsm",(HERE/BOOK).read_bytes())==data["book_sha256"]
    for folder in ("NativeResume","Temp"):
        (HERE/folder).mkdir(exist_ok=True)
    metadata={**data,"inputs":inputs,"stock_fixed_reference_preparation_sha256":PREP,"stock_fixed_reference_report_sha256":REPORT}
    print(put("Preparation.json",(json.dumps(metadata,indent=2)+"\n").encode()))


if __name__=="__main__":
    main()
