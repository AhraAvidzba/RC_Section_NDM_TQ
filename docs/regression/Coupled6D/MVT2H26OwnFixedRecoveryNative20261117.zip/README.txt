H26 fixed-coordinate legacy recovery from its own rejected Newton direction.

    python -B -X utf8 tmp/mv26o/Stage.py
    python -B -X utf8 tmp/mv26o/Verify-MVT2ShearControlled.py --inputs-only

After allocating the exclusive Office slot and passing the resource guard:

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mv26o/Run-MVT2ShearControlled.ps1

Rebuild accepted H25 and H26 from the frozen witnesses. Derive the same ordinary curvature
target as in mv26f. Begin the ordinary TryDeformationStep with recovery enabled, no affine
load coefficient, and no external field. Verify it reaches the identical stock stall before
recovery. The private diagnostics record the actual last damped Newton direction and governing
row, and test its earliest qualified material event. When the last fraction has no event,
a read-only diagnostic scans the full correction on the same ray without following it.
If legacy recovery produces a checked trial, use its CopyTrial field only as a seed for one
remaining-budget attempt at the original fixed target. Preserve original 56 weak equations,
six resultants, four gauges and control checks. No trial is committed and H24 is restored.
