# Компилирует и проверяет выбранную границу прямого НДС в изолированной книге.
param([ValidateSet('Equilibrium','Excel','File')][string]$Check='Equilibrium',[switch]$Preflight)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../../..')).Path
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$book='workbook/output/RC_Section_NDM.xlsm'
$draft='docs/regression/Diagnostic.xlsm'
$report="Native/$Check.txt"
$oldTemp=$env:TEMP
$oldTmp=$env:TMP
Push-Location -LiteralPath $root
try {
    $data=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    if ($Check -ne 'Equilibrium' -and $data.layer -cne 'Snapshot') {throw 'Нужна дорожка сохранения снимка.'}
    foreach ($item in $data.frozen.PSObject.Properties) {
        if ((Get-FileHash -LiteralPath $item.Name).Hash -cne $item.Value) {throw ('Изменён файл '+$item.Name)}
    }
    if ((Get-FileHash -LiteralPath (Join-Path $repo $book)).Hash -cne $data.workbook_sha256) {throw 'Изменилась установленная книга.'}
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {throw 'Путь пробной книги слишком длинный.'}
    Assert-IsolatedOfficeReady "DirectSteel$Check"
    if ($Preflight) {return}
    if (Test-Path -LiteralPath $report) {throw 'Предыдущая проверка сохранена.'}
    if (!(Test-Path -LiteralPath 'docs/regression/CodeUpdate.json')) {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Get-FileHash -LiteralPath $draft).Hash -cne $data.workbook_sha256) {throw 'Найдена непроверенная компиляция.'}
        $moduleNames=@($data.modules | ForEach-Object { [string]$_ })
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft -ModuleNames $moduleNames |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $closure.State -cne 'Absent' -or
        (($compiled.Modules | Sort-Object) -join ',') -cne ($data.modules -join ',') -or
        $compiled.ProductionSHA256 -cne $data.workbook_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash) {throw 'Компиляция не подтверждена.'}
    Assert-IsolatedOfficeReady "BeforeDirectSteel$Check"
    $macro='modTestCoupledElasticState.RunTestCoupledDirectSteelVerification'
    if ($Check -ne 'Equilibrium') {$macro='modTestCoupledElasticState.RunTestCoupledRetainedSnapshot'}
    $commandArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-Audit03Watchdog.ps1',
                   '-SourceWorkbook',$draft,'-ReportPath',$report,'-Macro',$macro,'-Mode','No','-TimeoutSeconds',185,'-FailFast')
    if ($Check -ne 'Equilibrium') {$commandArgs+=@('-MacroArgument1',$Check)}
    & $legacy @commandArgs
    if ($LASTEXITCODE -ne 0) {throw ('Нативная проверка завершилась ошибкой '+$Check)}
    $ended=Get-Content -LiteralPath ($report+'.ProcessClosure.json') -Raw | ConvertFrom-Json
    if (!$ended.Passed -or $ended.Closure.FinalState.State -cne 'Absent') {throw 'Закрытие дочернего Excel не подтверждено.'}
    & python -B -X utf8 'Verify.py' $Check $report
    if ($LASTEXITCODE -ne 0) {throw 'Независимая проверка завершилась ошибкой.'}
} finally {
    $env:TEMP=$oldTemp
    $env:TMP=$oldTmp
    Pop-Location
}
