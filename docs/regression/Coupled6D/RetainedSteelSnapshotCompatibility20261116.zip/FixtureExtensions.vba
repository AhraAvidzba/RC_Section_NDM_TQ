' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет каждую несовместимость на штатный носитель, заново открывает книгу
' и проверяет общий код чтения схемы и подготовки экспорта до получения изображения.
Private Sub TestSavedSteelOutcomeCompatibility(ByVal book As Object, ByVal snapshot As CCalculationSnapshot, _
        ByVal storage As String, ByRef passed As Long, ByRef failed As Long, ByRef report As String)
    Dim settingsArea As Object: Set settingsArea = book.Names.Item("rngSystemSettings").RefersToRange
    Dim fixture As Variant, changed As CCalculationSnapshot, store As New CCalculationSnapshotStore
    Dim writer As New CNDMResultsWriter
    For Each fixture In Array("UnknownCode", "BlankCode", "ContradictOK", "ContradictFail", "RetainedMissing", "OldWithField")
        TestInputCell(settingsArea, "Results.SnapshotName").Value2 = CStr(fixture) & storage
        Set changed = TestCopySteelOutcomeSnapshot(snapshot, CStr(fixture))
        If storage = "Excel" Then
            writer.RestoreSnapshotBase book, changed, False
        Else
            store.SaveFile book, changed
        End If
        TestReadReopenedSteelOutcome book, storage, CStr(fixture), passed, failed, report
    Next fixture

    ' Формирует Full с одним LC штатным writer-ом после настоящего численного отказа.
    TestInputCell(settingsArea, "Results.SnapshotName").Value2 = "LegacySole" & storage
    Dim loadsArea As Object: Set loadsArea = book.Names.Item("rngLoadCombinations").RefersToRange
    loadsArea.Cells(3, 1).Resize(1, loadsArea.Columns.Count).ClearContents
    Dim section As CSectionModel, units As CUnitSystem, provider As CMaterialModelProvider, batch As CBatchSectionCalculator
    Set batch = TestCreateContactPresentationBatch(book, section, units, provider, True)
    Dim result As CCombinationResult, state As CSectionStateResult
    Set result = batch.ResultAt(1): Set state = result.StateRepository.FindState(sstStrengthState)
    Dim actual() As Double, code As String: code = ResultCodeToText(result.DirectStateMeta.ResultCode)
    Dim noField As Boolean
    noField = (result.DirectStateMeta.InternalStatus = rsNumericalFailure And state Is Nothing And _
        code <> ResultCodeToText(rcCoupledSteelLimitUnresolved) And Not result.CopyCoupledResultants(actual))
    TestRecord noField, storage & " genuine numerical exit without an accepted field (" & code & ")", passed, failed, report
    If Not noField Then Exit Sub

    Dim legacy As New CCalculationSnapshot, summary As New CBatchResultWriter
    Set summary.CaptureSnapshot = legacy
    summary.WriteSummary book, batch, units, section, False
    Set writer.CaptureSnapshot = legacy
    writer.WriteResults book, section, PrepareSectionSnapshot(section, provider), batch, units, False, False
    legacy.AddTable "Calculation.Profiles", book.Names.Item("rngCalculationProfiles").RefersToRange.Value2
    Dim plotWarning As String: plotWarning = SaveAndDisplayCalculationSnapshot(book, legacy)
    TestReadReopenedSteelOutcome book, storage, "LegacySole", passed, failed, report
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет заданную строку свойств ровно одного LC. При удалении поля
' оставляет общий снимок и независимые сохранённые строки второго LC.
Private Function TestCopySteelOutcomeSnapshot(ByVal source As CCalculationSnapshot, ByVal fixture As String) As CCalculationSnapshot
    Dim changed As New CCalculationSnapshot: changed.RunID = source.RunID
    Dim key As Variant, data As Variant
    For Each key In source.Keys
        data = source.Table(CStr(key))
        If CStr(key) = "LoadCase.Properties" Or (CStr(key) = "rngNDMElementResults" And fixture = "RetainedMissing") Then
            data = TestChangeSteelOutcomeRows(data, fixture, CStr(key) = "LoadCase.Properties")
        End If
        changed.AddTable CStr(key), data
    Next key
    Set TestCopySteelOutcomeSnapshot = changed
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает матрицу запрашиваемой высоты с исходными заголовками и RunID.
' OldWithField моделирует сохранённое НДС без необязательного машинного кода.
Private Function TestChangeSteelOutcomeRows(ByRef data As Variant, ByVal fixture As String, ByVal properties As Boolean) As Variant
    Dim lcCol As Long: lcCol = ResultColumn(data, "LoadCase")
    Dim keyCol As Long, valueCol As Long
    If properties Then
        keyCol = ResultColumn(data, "Parameter"): valueCol = ResultColumn(data, "Value")
    Else
        keyCol = ResultColumn(data, "StateType")
    End If
    Dim row As Long, col As Long, key As String, removing() As Boolean, keep As Long, affected As Long
    ReDim removing(1 To UBound(data, 1)): keep = UBound(data, 1)
    For row = 2 To UBound(data, 1)
        If CStr(data(row, lcCol)) = "ContactLong" Then
            key = CStr(data(row, keyCol))
            If properties Then
                If key = "State.StrengthState.ResultCode" Then
                    Select Case fixture
                        Case "UnknownCode": data(row, valueCol) = "UNSUPPORTED_STEEL_OUTCOME": affected = affected + 1
                        Case "BlankCode": data(row, valueCol) = Empty: affected = affected + 1
                        Case "OldWithField": removing(row) = True
                    End Select
                ElseIf key = "State.StrengthState.Status" Then
                    Select Case fixture
                        Case "ContradictOK": data(row, valueCol) = "OK": affected = affected + 1
                        Case "ContradictFail": data(row, valueCol) = "FAIL": affected = affected + 1
                    End Select
                End If
            Else
                removing(row) = (key = "StrengthState")
            End If
            If removing(row) Then keep = keep - 1: affected = affected + 1
        End If
    Next row
    If affected = 0 And Not (properties And fixture = "RetainedMissing") Then Err.Raise 5, , "Проба снимка не внесла изменение: " & fixture
    If keep = UBound(data, 1) Then TestChangeSteelOutcomeRows = data: Exit Function
    Dim changed() As Variant, target As Long
    ReDim changed(1 To keep, 1 To UBound(data, 2))
    For row = 1 To UBound(data, 1)
        If Not removing(row) Then
            target = target + 1
            For col = 1 To UBound(data, 2): changed(target, col) = data(row, col): Next col
        End If
    Next row
    TestChangeSteelOutcomeRows = changed
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет различные исходы схемы и экспорта на прочитанном экземпляре.
' У численного отказа без поля допустима геометрия схемы без раскраски.
Private Sub TestReadReopenedSteelOutcome(ByVal book As Object, ByVal storage As String, ByVal fixture As String, _
        ByRef passed As Long, ByRef failed As Long, ByRef report As String)
    On Error GoTo Failed
    Dim savedPath As String: savedPath = book.Path & Application.PathSeparator & fixture & ".xlsm"
    Dim reopened As Object
    book.SaveCopyAs savedPath
    Set reopened = book.Application.Workbooks.Open(savedPath, 0, True)
    Dim settings As New CSystemSettingsReader: settings.LoadFromWorkbook reopened
    Dim reader As New CSectionPlotDataReader, pictureError As Long, exportError As Long
    Dim pictureText As String, exportText As String, exportResult As String
    On Error Resume Next
    reader.LoadFromWorkbook reopened, settings
    pictureError = Err.Number: pictureText = Err.Description: Err.Clear
    exportResult = Audit02ReadExportSnapshotForTests(reopened)
    exportError = Err.Number: exportText = Err.Description: Err.Clear
    On Error GoTo Failed

    Dim valid As Boolean, geometryOnly As Boolean, storageProof As Boolean
    Dim codeKey As String: codeKey = "State.StrengthState.ResultCode"
    Select Case fixture
        Case "OldWithField"
            valid = (pictureError = 0 And exportError = 0 And reader.Count > 0 And Not reader.GeometryOnly And _
                Len(exportResult) > 0 And Len(ReadLoadCasePropertyText(reopened, "ContactLong", codeKey)) = 0 And _
                InStr(exportResult, "ПРЕДЕЛ АРМАТУРЫ НЕ УТОЧНЁН") = 0)
        Case "RetainedMissing"
            valid = (pictureError = vbObjectError + 4703 And InStr(pictureText, "не имеет требуемых строк элементов") > 0 And _
                exportError = vbObjectError + 4354)
        Case "LegacySole"
            valid = (pictureError = vbObjectError + 4706 And exportError = vbObjectError + 4354 And _
                ReadLoadCasePropertyText(reopened, "ContactLong", "DirectStateStatus") = "NumFail" And _
                Len(ReadLoadCasePropertyText(reopened, "ContactLong", codeKey)) = 0)
            If valid Then
                Dim zeroField As Variant: zeroField = ReadElementResultTable(reopened, , , True)
                reader.LoadGeometryOnlyForMissingState reopened, settings
                geometryOnly = (reader.GeometryOnly And reader.Count > 0 And reader.LoadCase = "ContactLong")
                valid = geometryOnly And UBound(zeroField, 1) = 1
            End If
        Case Else
            valid = (pictureError = vbObjectError + 4720 And InStr(pictureText, codeKey) > 0 And _
                exportError = vbObjectError + 4361 And InStr(exportText, codeKey) > 0)
    End Select

    Dim medium As String: medium = storage
    If storage = "File" Then
        Dim store As New CCalculationSnapshotStore, loaded As CCalculationSnapshot
        Set loaded = store.LoadFile(reopened)
        Dim fileID As Integer: fileID = FreeFile
        Dim magic As String * 8, filename As String: filename = store.SnapshotPath(reopened)
        Open filename For Binary Access Read As #fileID
        Get #fileID, 1, magic
        Close #fileID
        storageProof = (magic = "NDMSNP06" And Not loaded.IsGeometryPreview)
        medium = magic
    Else
        storageProof = (reopened.ReadOnly And reopened.FullName <> book.FullName)
    End If
    report = report & "SNAPSHOT_OUTCOME|" & storage & "|" & fixture & "|" & CStr(TestSnapshotOutcomeError(pictureError)) & _
        "|" & CStr(TestSnapshotOutcomeError(exportError)) & "|" & CStr(Abs(CLng(geometryOnly))) & "|" & medium & vbCrLf
    If Not valid Then report = report & "SNAPSHOT_OUTCOME_DETAILS|" & fixture & "|" & pictureText & "|" & exportText & vbCrLf
    TestRecord valid And storageProof, storage & " reopens and validates " & fixture, passed, failed, report
    reopened.Close False
    Exit Sub
Failed:
    Dim problem As String: problem = Err.Description
    If Not reopened Is Nothing Then reopened.Close False
    Err.Raise 5, "TestReadReopenedSteelOutcome", fixture & ": " & problem
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пишет короткий модульный код ошибки для независимой сверки протокола.
Private Function TestSnapshotOutcomeError(ByVal errorNumber As Long) As Long
    If errorNumber <> 0 Then TestSnapshotOutcomeError = errorNumber - vbObjectError
End Function
