"""Apply the directed compatibility overlay to verified copies, without starting Office."""

import json
from hashlib import sha256
from pathlib import Path


root = Path(__file__).resolve().parent
base = root.parent / "Snapshot"
repo = root.parents[2]
frozen = json.loads((base / "Fixture.json").read_text(encoding="utf-8"))


def update(path, changes, extra=""):
    target = root / path
    raw = target.read_bytes()
    crlf = b"\r\n" in raw
    enc = "utf-8"
    code = raw.decode(enc).replace("\r\n", "\n")
    for old, new in changes:
        assert code.count(old) == 1, (path, old)
        code = code.replace(old, new)
    code += extra
    target.write_bytes((code.replace("\n", "\r\n") if crlf else code).encode(enc))


common = "src/Excel/modSectionSnapshot.bas"
plot = "src/Excel/CSectionPlotDataReader.cls"
export = "src/Excel/modAutoCADStressExport.bas"
test = "tests/modTestCoupledElasticState.bas"
for rel in (plot, export, test, "Run.ps1"):
    raw = (base / rel).read_bytes()
    assert sha256(raw).hexdigest().upper() == frozen["frozen"][rel]
    (root / rel).write_bytes(raw)
raw = (repo / common).read_bytes()
assert sha256(raw).hexdigest().upper() == "7C1C23CC421BD4B5A11EBCDAA39F6FA0E4371452D8590F979A891C4610D399EA"
(root / common).write_bytes(raw)
parser = """' Читает присутствующий машинный код из сохранённого НДС. Отсутствующий
' ключ обрабатывает адаптер по формату снимка. Неуточнённый предел стали
' допустим только при статусе NumFail, даже если равновесие подтверждено.
Public Function TryReadSnapshotStateResultCode(ByVal value As Variant, ByVal stateStatus As String, _
        ByRef retainedSteel As Boolean) As Boolean
    retainedSteel = False
    If IsObject(value) Or IsArray(value) Then Exit Function
    If VarType(value) <> vbString Then Exit Function
    Dim codeText As String: codeText = UCase$(Trim$(CStr(value)))
    Dim code As EResultCode
    For code = rcNone To rcCoupledSteelLimitUnresolved
        If codeText = ResultCodeToText(code) Then
            If code = rcCoupledSteelLimitUnresolved Then
                If stateStatus <> "NumFail" Then Exit Function
                retainedSteel = True
            End If
            TryReadSnapshotStateResultCode = True
            Exit Function
        End If
    Next code
End Function

"""
update(common, [("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Показывает число блочных чтений", parser +
                 "' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Показывает число блочных чтений")])

update(plot, [
    ("    Dim parameter As String, loadCase As String\n    Dim stateFields",
     "    Dim parameter As String, loadCase As String, propertyKey As String\n    Dim stateFields"),
    ("""                    stateFields(LCase$(parameter)) = Array(data(rowIndex, colValue), data(rowIndex, colUnit), rowIndex, colValue, colUnit)
""",
     """                    propertyKey = LCase$(parameter)
                    If propertyKey = "directstatestatus" Or (Left$(propertyKey, 6) = "state." And _
                            (Right$(propertyKey, 7) = ".status" Or Right$(propertyKey, 11) = ".resultcode")) Then
                        If stateFields.Exists(propertyKey) Then Err.Raise vbObjectError + 4720, "CSectionPlotDataReader", _
                            SnapshotMetadataInputMessage(anchor, rowIndex, colValue, parameter)
                    End If
                    stateFields(propertyKey) = Array(data(rowIndex, colValue), data(rowIndex, colUnit), rowIndex, colValue, colUnit)
"""),
    ("""            If Not HasRows(availableStates) Then Err.Raise vbObjectError + 4705, "CSectionPlotDataReader", _
""",
     """            If Not HasRows(availableStates) And Not HasSavedNoFieldDirectFailure(workbook, stateFields) Then Err.Raise vbObjectError + 4705, "CSectionPlotDataReader", _
"""),
    ("""    Dim field As Variant, key As String, saved As Variant, number As Double, flag As Boolean, status As String, unit As String
""",
     """    Dim field As Variant, key As String, saved As Variant, number As Double, flag As Boolean, unit As String
"""),
    ("""                Case "Status": status = ReadSnapshotStatus(saved(0), anchor, CLng(saved(2)), CLng(saved(3)), key)
""", ""),
    ("""    Next field
End Sub

' Отсутствующее выбранное НДС разрешает только геометрию проверенного Full:""",
     """    Next field
    Dim status As String, retainedSteel As Boolean
    key = "State." & stateType & ".Status"
    saved = stateFields.Item(LCase$(key))
    status = ReadSnapshotStatus(saved(0), anchor, CLng(saved(2)), CLng(saved(3)), key)
    retainedSteel = SavedStateRetainsUnresolvedSteel(anchor, stateFields, stateType, status)
End Sub

' Допускает отсутствие ключа в совместимых снимках. Присутствующий код
' проверяется даже при полностью сохранённых строках элементов.
Private Function SavedStateRetainsUnresolvedSteel(ByVal anchor As Object, ByVal stateFields As Object, _
        ByVal stateType As String, ByVal status As String) As Boolean
    Dim key As String: key = "State." & stateType & ".ResultCode"
    If Not stateFields.Exists(LCase$(key)) Then Exit Function
    Dim saved As Variant, retainedSteel As Boolean: saved = stateFields.Item(LCase$(key))
    If Not TryReadSnapshotStateResultCode(saved(0), status, retainedSteel) Then Err.Raise vbObjectError + 4720, _
        "CSectionPlotDataReader", SnapshotMetadataInputMessage(anchor, CLng(saved(2)), CLng(saved(3)), key)
    SavedStateRetainsUnresolvedSteel = retainedSteel
End Function

' В расчётном снимке прямой численный отказ без НДС сохраняет статус LC,
' профиль и геометрию. Частичное именованное НДС или остатки подтверждённых
' усилий означают повреждение и не разрешают этот режим. Одного LC достаточно.
Private Function HasSavedNoFieldDirectFailure(ByVal workbook As Object, ByVal stateFields As Object) As Boolean
    If StrComp(mStateType, "StrengthState", vbTextCompare) <> 0 Then Exit Function
    If Not stateFields.Exists("directstatestatus") Or Not stateFields.Exists("profileid") Then Exit Function
    Dim key As Variant
    For Each key In stateFields.Keys
        If Left$(CStr(key), Len("state.strengthstate.")) = "state.strengthstate." Or _
                Left$(CStr(key), Len("coupled.internal.")) = "coupled.internal." Or CStr(key) = "coupled.statesolver" Then Exit Function
    Next key
    Dim anchor As Object: Set anchor = workbook.Names.Item("rngNDMSectionProperties").RefersToRange
    Dim saved As Variant: saved = stateFields.Item("directstatestatus")
    HasSavedNoFieldDirectFailure = (ReadSnapshotStatus(saved(0), anchor, CLng(saved(2)), CLng(saved(3)), "DirectStateStatus") = "NumFail")
End Function

' Отсутствующее выбранное НДС разрешает только геометрию проверенного Full:"""),
    ('"В сохраненном снимке Results успешное состояние " & CStr(key) & " не имеет строк элементов для "',
     '"В сохраненном снимке Results состояние " & CStr(key) & " не имеет требуемых строк элементов для "'),
    ("""    If caseStates.Count = 0 And Not metadataStates.Exists(LCase$(mStateType)) Then Err.Raise vbObjectError + 4703, "CSectionPlotDataReader", _
""",
     """    If caseStates.Count = 0 And Not metadataStates.Exists(LCase$(mStateType)) And _
            Not HasSavedNoFieldDirectFailure(workbook, stateFields) Then Err.Raise vbObjectError + 4703, "CSectionPlotDataReader", _
"""),
    ("""        Case "NumFail"
            key = "state." & LCase$(stateType) & ".resultcode"
            If stateFields.Exists(key) Then
                saved = stateFields.Item(key)
                Dim reason As String: reason = ReadSnapshotText(saved(0), anchor, CLng(saved(2)), CLng(saved(3)), key)
                SavedStateNeedsElementRows = (reason = ResultCodeToText(rcCoupledSteelLimitUnresolved))
            End If
""",
     """        Case "NumFail": SavedStateNeedsElementRows = SavedStateRetainsUnresolvedSteel(anchor, stateFields, stateType, status)
"""),
])

update(export, [
    ("    Dim stateStatus As String, stateCode As String",
     "    Dim stateStatus As String, stateCodeValue As Variant, stateCodeRow As Long, retainedSteel As Boolean"),
    ("""            If Left$(key, Len(prefix)) = prefix Then
                stateFields(key) = True
                Select Case Mid$(key, Len(prefix) + 1)
""",
     """            If Left$(key, Len(prefix)) = prefix Then
                If key = prefix & "resultcode" Or key = prefix & "status" Then
                    If stateFields.Exists(key) Then RejectExportSnapshotMetadata workbook, rowIndex, colValue, SafeText(data(rowIndex, colParameter))
                End If
                stateFields(key) = True
                Select Case Mid$(key, Len(prefix) + 1)
"""),
    ("                    stateCode = SafeText(data(rowIndex, colValue))",
     "                    stateCodeValue = data(rowIndex, colValue): stateCodeRow = rowIndex"),
    ("""    If extensionUsed Or stateStatus = policy.Fail Then
        stateWarningText = EXTENSION_WARNING_TEXT
    ElseIf stateStatus = policy.NumFail Then
        If stateCode = ResultCodeToText(rcCoupledSteelLimitUnresolved) Then
            stateWarningText = STEEL_CHECK_WARNING_TEXT
        Else
            stateWarningText = NUMERICAL_STATE_WARNING_TEXT
        End If
    End If
""",
     """    If stateCodeRow > 0 Then
        If Not TryReadSnapshotStateResultCode(stateCodeValue, stateStatus, retainedSteel) Then _
            RejectExportSnapshotMetadata workbook, stateCodeRow, colValue, "State." & stateType & ".ResultCode"
    End If
    If retainedSteel Then
        stateWarningText = STEEL_CHECK_WARNING_TEXT
    ElseIf extensionUsed Or stateStatus = policy.Fail Then
        stateWarningText = EXTENSION_WARNING_TEXT
    ElseIf stateStatus = policy.NumFail Then
        stateWarningText = NUMERICAL_STATE_WARNING_TEXT
    End If
"""),
])

updates = (root / "FixtureExtensions.vba").read_text(encoding="utf-8")
update(test, [
    ("""    reopened.Close False: Set reopened = Nothing
    RunTestCoupledRetainedSnapshot""",
     """    reopened.Close False: Set reopened = Nothing
    TestSavedSteelOutcomeCompatibility book, snapshot, storage, passed, failed, report
    RunTestCoupledRetainedSnapshot"""),
    ("""Private Function TestCreateContactPresentationBatch(ByVal book As Object, ByRef section As CSectionModel, _
        ByRef units As CUnitSystem, ByRef provider As CMaterialModelProvider) As CBatchSectionCalculator""",
     """Private Function TestCreateContactPresentationBatch(ByVal book As Object, ByRef section As CSectionModel, _
        ByRef units As CUnitSystem, ByRef provider As CMaterialModelProvider, _
        Optional ByVal noField As Boolean = False) As CBatchSectionCalculator"""),
    ("""    analysis.Initialize section, layout, provider, 0.2, 0.12, 80#, 125#, 16# / 30#, 0.002, "A400", 30
    profiles.LoadFromWorkbook book, False
    spec.Initialize "ULS(I)", "ThreeLine", "UseDiagram", "TwoLine"
    Set profile = profiles.ProfileById("PR4")
    profile.Initialize "PR4", "Снимок критерия арматуры", "", True, False, False, False""",
     """    Dim iterationLimit As Long: iterationLimit = 30
    If noField Then iterationLimit = 1 ' Воспроизводим исчерпание итераций на реальном пространственном материале.
    analysis.Initialize section, layout, provider, 0.2, 0.12, 80#, 125#, 16# / 30#, 0.002, "A400", iterationLimit
    profiles.LoadFromWorkbook book, False
    spec.Initialize "ULS(I)", "ThreeLine", "UseDiagram", "TwoLine"
    Set profile = profiles.ProfileById("PR4")
    profile.Initialize "PR4", "Снимок критерия арматуры", "", True, False, False, False"""),
    ("""    batch.AddCombination "ContactLong", -1000#, 0#, 0#, "PR4", "", sourceDataOffset:=1, torque:=100000#
    batch.AddCombination "ContactHoop", -1000#, 0#, 0#, "PR4", "", sourceDataOffset:=2, torque:=100000#""",
     """    If noField Then
        batch.AddCombination "ContactLong", 1000000000#, 12000000#, -9000000#, "PR4", "", _
            sourceDataOffset:=1, torque:=40000000#, qx:=80000#, qy:=-60000#
    Else
        batch.AddCombination "ContactLong", -1000#, 0#, 0#, "PR4", "", sourceDataOffset:=1, torque:=100000#
        batch.AddCombination "ContactHoop", -1000#, 0#, 0#, "PR4", "", sourceDataOffset:=2, torque:=100000#
    End If"""),
    ("""    batch.Execute
    Dim i As Long
    For i = 1 To 2
        Dim solved As CCombinationResult, base As CSectionStateResult, state As CSectionStateResult""",
     """    batch.Execute
    If noField Then Set TestCreateContactPresentationBatch = batch: Exit Function
    Dim i As Long
    For i = 1 To 2
        Dim solved As CCombinationResult, base As CSectionStateResult, state As CSectionStateResult"""),
], extra="\n" + updates)

update("Run.ps1", [
    ("'-TimeoutSeconds',130", "'-TimeoutSeconds',185"),
])

sources = json.loads((base / "SourceManifest.json").read_text(encoding="utf-8"))
source_changes = sources["changes"]
source_changes[common] = {"base_sha256": sha256((repo / common).read_bytes()).hexdigest().upper()}
for rel in (common, plot, export, test):
    source_changes[rel]["candidate_sha256"] = sha256((root / rel).read_bytes()).hexdigest().upper()
    frozen["frozen"][rel] = source_changes[rel]["candidate_sha256"]
frozen["modules"] = sorted(frozen["modules"] + ["modSectionSnapshot"], key=str.casefold)
(root / "SourceManifest.json").write_text(json.dumps(sources, indent=2) + "\n", encoding="utf-8")
for path in ("Verify.py", "Run.ps1", "SourceManifest.json", "FixtureExtensions.vba", "StageCompatibility.py"):
    frozen["frozen"][path] = sha256((root / path).read_bytes()).hexdigest().upper()
(root / "Fixture.json").write_text(json.dumps(frozen, indent=2) + "\n", encoding="utf-8")
