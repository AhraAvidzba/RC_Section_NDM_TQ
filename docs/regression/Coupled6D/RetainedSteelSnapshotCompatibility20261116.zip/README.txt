Compatibility of direct steel outcomes in Results.

The source overlays come from the sealed Snapshot stage. SourceManifest.json
lists baseline and final digests. Fixture.json enumerates frozen native inputs.
No workbook is included. The installed input XLSM SHA256 is
8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF.

Native reproduced both actual Excel worksheet storage and indexed NDMSNP06
storage after reopening a saved workbook. Each medium checks unknown and blank
code, contradictory OK and FAIL, missing retained field, prior field without a
stored code, and one genuine solver numerical exit without any accepted field or
any other LC. The last path shows the confirmed Full section geometry in Excel
and declines preparation of a field export. AutoCAD itself is not opened.
Legacy NDMSNP04/05 binary fixture round-trips were outside this directed scope.

Replay the saved native report checks with Python 3:
    python -B -X utf8 Verify.py Excel Native/Excel.txt
    python -B -X utf8 Verify.py File Native/File.txt

The watchdog receipts in Native record owned process closure and source
identity. CompileClosure.json and CodeUpdate.json pin the executable private
build and attest that the installed workbook was unchanged.
