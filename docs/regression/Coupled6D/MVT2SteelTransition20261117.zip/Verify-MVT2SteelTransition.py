"""Проверяет текучесть продольных стержней на принятых станциях MVT2."""

from argparse import ArgumentParser
from gzip import decompress
from hashlib import sha256
import json
from math import fsum, isclose
from pathlib import Path
import re
from zipfile import ZipFile


ARCHIVES = {
    'MVT2TabulatedFlowNative20261117.zip': '0DDB248B0B2F61AF814F1E70EAE55CABE46CC07C261E8E8043A8D8A960850F49',
    'MVT2PublicationCut20261117.zip': '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD',
}
STATIONS = (0, 1, -1)
LONGITUDINAL = range(26, 30)
ELASTIC_MODULUS = 200000.
YIELD = 498.


def rows(raw):
    """Разделяет зафиксированные в VBA записи без преобразования чисел."""
    return [line.split(';') for line in raw.decode('cp1251').splitlines()]


def native(z):
    """Проецирует поля на сталь и повторяет возврат с принятой историей каждой станции."""
    prefix = 'Matched/Native/'
    operators = rows(z.read(prefix + 'Operators.csv'))
    trial_log = z.read(prefix + 'MVTGaussMixed.csv')
    size = operators[0]
    assert size == ['SIZE', '60', '45', '0.001']
    dx = float(size[-1])
    columns = {(int(p), int(j)): tuple(map(float, coef)) for _, p, j, *coef in
               (line for line in operators if line[0] == 'B')}
    fields = {label: tuple(map(float, coords)) for _, label, *coords in
              (line for line in operators if line[0] == 'F')}
    points = (line for line in rows(trial_log) if line[0] == 'MVT_POINT')
    directions = {int(p): tuple(map(float, d)) for _, p, _, _, _, *d in points if int(p) in LONGITUDINAL}
    assert set(directions.values()) == {(0., 0., 1., 0., 0., 0.)}
    loads = {label: float(q) for key, label, t, q in
             (line for line in rows(z.read(prefix + 'MVTGaussMixed.Tensor.csv')) if line[0] == 'FRAME')}
    assert list(loads) == list(fields)
    point_columns = {(p, s): [fsum(d * (coef[k] + s * dx * coef[k + 6]) for k, d in enumerate(directions[p]))
                             for coef in (columns[p, j] for j in range(1, 61))]
                     for p in LONGITUDINAL for s in STATIONS}
    plastic = dict.fromkeys(point_columns, 0.)
    replay = {}
    for label, field in fields.items():
        state = {}
        for point, column in point_columns.items():
            eps = fsum(a * b for a, b in zip(column, field, strict=True))
            trial = ELASTIC_MODULUS * (eps - plastic[point])
            stress = min(YIELD, max(-YIELD, trial))
            if abs(trial) > YIELD:
                plastic[point] = eps - stress / ELASTIC_MODULUS
            state[point] = (eps, trial, stress, plastic[point])
        replay[loads[label]] = state
    previous, final = replay[72500.], replay[72812.5]
    assert all(value[-1] == 0. for q, state in replay.items() if q <= 72500. for value in state.values())
    assert [point for point, value in final.items() if value[-1]] == [(28, -1)]
    assert isclose(final[28, -1][1], 498.010602, abs_tol=1e-6)
    failure, = re.findall(r'^MVT2_CUT_TRIAL;S32;10510000;73750;-29205000;False;6;10;([^\r\n]+)',
                          trial_log.decode('cp1251'), re.M)
    return {
        'longitudinal_states': len(fields) * len(point_columns),
        'point28_station_0_plus_minus': {str(q): [state[28, s] for s in STATIONS]
                                          for q, state in ((72500, previous), (72812.5, final))},
        'rejected_73750': failure,
    }


def external(z):
    """Читает принятую историю OpenSees для того же плеча и тех же станций."""
    route = json.loads(z.read('Cut396.json'))
    assert route['arm_mm'] == 396 and not route['physical_limit_established']
    wire = z.read('Cut396.stress.json.gz')
    assert sha256(wire).hexdigest().lower() == route['stress_sha256'].lower()
    trace = json.loads(decompress(wire))['steel']
    data = {}
    for step, state in zip(route['result']['accepted'], trace, strict=True):
        q = step['Q_target_N']
        if q in (72500., 73750., 75312.5):
            centre, plus, minus = state['columns_strain_stress_tangent_plastic_backstress_increment']
            data[q] = [values[2] for values in (centre, plus, minus)]
    assert set(data) == {72500., 73750., 75312.5}
    assert all(row[1] < YIELD and row[3] == 0. for row in data[72500.])
    assert all(row[1] == YIELD and row[3] > 0. for q in (73750., 75312.5) for row in data[q])
    return data


def verify(repo):
    """Сверяет неизменность архивов и сравнивает пространственную последовательность текучести."""
    paths = [repo / 'docs/regression/Coupled6D' / name for name in ARCHIVES]
    for path, digest in zip(paths, ARCHIVES.values(), strict=True):
        assert sha256(path.read_bytes()).hexdigest().upper() == digest
    with ZipFile(paths[0]) as vba, ZipFile(paths[1]) as opensees:
        first, second = native(vba), external(opensees)
    vba_elastic = first['point28_station_0_plus_minus']['72500']
    discrepancy = max(abs(a[2] - b[1]) for a, b in zip(vba_elastic, second[72500.], strict=True))
    assert discrepancy < .00004
    return {'VBA': first, 'OpenSees_0_plus_minus': second, 'elastic_check_MPa': discrepancy,
            'physical_limit_established': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = verify(args.repo)
    proof = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if args.out:
        args.out.write_bytes(proof.encode('utf-8'))
        print('MVT2 STEEL TRANSITION PASS', result['VBA']['longitudinal_states'])
    else:
        print(proof, end='')
