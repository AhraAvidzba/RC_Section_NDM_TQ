' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает два начальных поля при одной точной силовой цели и истории.
Private Sub ProbeWangSameRayTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef base() As Double)
    Const TARGET_Q As Double = 18.5720088671875
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005, MAX_ITERATIONS As Long = 26
    Dim arcField() As Double, arcQ As Double, secant() As Double, previous() As Double
    Dim field() As Double, forces() As Double, actual() As Double, weak() As Double
    Dim historyBefore() As Double, historyProbe() As Double
    Dim i As Long, label As Variant, seed As Variant, solved As Boolean, began As Double, elapsed As Double
    Dim result As CResultMeta
    ReadWangRayVectorTest folder & "ArcSeed.csv", arcField, arcQ
    previous = history(23): secant = base
    For i = 1 To solver.PhysicalDegreeCount: secant(i) = secant(i) + (base(i) - previous(i)) / 64#: Next i
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "Before", operators, materials, historyBefore
    For Each label In Array("Secant", "Arc")
        RestoreWangShearBaselineTest solver, history, base
        If CStr(label) = "Secant" Then seed = secant Else seed = arcField
        Dim recordedSeed() As Double: recordedSeed = seed
        EmitWangTangentVectorTest output, "B_FORCE_SEED;" & CStr(label), recordedSeed
        began = Timer
        solved = solver.TryStep(0#, 600000# * TARGET_Q, 0#, 10510000#, 0#, 1000# * TARGET_Q, _
            ABS_TOL, REL_TOL, MAX_ITERATIONS, initialField:=seed)
        elapsed = Timer - began: If elapsed < 0# Then elapsed = elapsed + 86400#
        Set result = solver.ResultMeta
        Print #output, "B_FORCE_SEEDED;" & CStr(label) & ";" & CStr(Abs(CLng(solved))) & ";" & _
            CStr(result.InternalStatus) & ";" & CStr(result.ResultCode) & ";" & ExperimentNumberTest(elapsed)
        Print #output, "B_FORCE_DETAILS;" & CStr(label) & ";" & Replace(Replace(result.DiagnosticDetails, vbLf, " "), vbCr, " ")
        If solved Then
            solver.CopyTrial field, forces
            solver.DiscardStep
            Dim norm As Double
            norm = RecordWangTangentStateTest(output, CStr(label), 24, TARGET_Q, solver, operators, materials, responses, field, actual, weak)
        Else
            solver.DiscardStep
        End If
        RequireWangAcceptedFieldTest solver, base
        CaptureWangArcHistoryTest output, CStr(label), operators, materials, historyProbe
        RequireWangArcHistoryTest historyBefore, historyProbe
    Next label
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "Final", operators, materials, historyProbe
    RequireWangArcHistoryTest historyBefore, historyProbe
End Sub
