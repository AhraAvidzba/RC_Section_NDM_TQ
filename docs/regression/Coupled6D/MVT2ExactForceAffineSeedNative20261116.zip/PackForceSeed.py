"""Package the exact-force negative MVT2 comparison and replay the archive."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import ReplayPortable as replay


HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[1] / "docs/regression/Coupled6D"
ARCHIVES = {"automatic": REGRESSION / "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip",
            "jet": REGRESSION / "MVT2HalfJointJetNative20261116.zip"}
RESULT = HERE / "MVT2ExactForceAffineSeedNative20261116.zip"


def pack(local, dependency):
    manifest = {"files": {name: replay.digest(value) for name, value in sorted(local.items())},
                "dependencies": dependency, "source_archives": replay.SOURCES, "omitted_workbook_sha256": replay.WORKBOOK}
    parts = {**local, "PortableManifest.json": (json.dumps(manifest, indent=2) + "\n").encode()}
    assert all(not name.casefold().endswith(".xlsm") for name in (*parts, *dependency))
    with ZipFile(RESULT, "w", compression=ZIP_DEFLATED, compresslevel=9) as output:
        for name, data in sorted(parts.items()):
            member = ZipInfo(name)
            member.compress_type = ZIP_DEFLATED
            output.writestr(member, data)


def detached(*args):
    with TemporaryDirectory(dir=HERE / "Temp") as folder, ZipFile(RESULT) as archive:
        assert archive.testzip() is None
        archive.extractall(folder)
        subprocess.run([sys.executable, "-B", "-X", "utf8", "ReplayPortable.py", *map(str, ARCHIVES.values()), *args],
                       cwd=folder, check=True)


def main():
    prep = json.loads((HERE / "Preparation.json").read_bytes())
    assert prep["book_sha256"] == replay.WORKBOOK
    assert replay.digest((HERE / "VerificationForceSeed.json").read_bytes()) == replay.CANONICAL
    index = {}
    for label, path in ARCHIVES.items():
        assert replay.digest(path.read_bytes()) == replay.SOURCES[label]
        with ZipFile(path) as source:
            for name in source.namelist():
                index.setdefault(replay.digest(source.read(name)), (label, name))
    local, dependency = {}, {}
    for name, expected in prep["inputs"].items():
        raw = (HERE / name).read_bytes()
        assert replay.digest(raw) == expected, name
        if expected in index:
            dependency[name] = (*index[expected], expected)
        else:
            local[name] = raw
    records = ("Preparation.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "VerificationForceSeed.json",
               "docs/regression/CodeUpdate.json", "ReplayPortable.py", "PackForceSeed.py", "PortableREADME.txt")
    native = tuple(f"NativeHalf/{item.name}" for item in (HERE / "NativeHalf").iterdir()
                   if item.is_file() and not item.name.endswith((".stdout.log", ".stderr.log")))
    for name in (*records, *native):
        local[name] = (HERE / name).read_bytes()
    pack(local, dependency)
    audit = HERE / "NumericalAudit.json"
    detached("--audit-output", str(audit))
    local[audit.name] = audit.read_bytes()
    pack(local, dependency)
    detached()
    print(RESULT, RESULT.stat().st_size, replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
