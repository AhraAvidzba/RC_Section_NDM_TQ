MVT2 at a fixed six-force target from two separately frozen initial fields

From the extracted directory with Python 3.10 or later run
    python -B -X utf8 ReplayPortable.py PATH/MVT2AutomaticBoundedBranchRecoveryNative20261116.zip PATH/MVT2HalfJointJetNative20261116.zip

Both dependencies exist under docs/regression/Coupled6D. The replay requires
neither workbook bytes nor Excel. It validates native ownership/closure,
compile receipts, input identities, the exact previous H24 material response,
and the canonical negative outcome. The marker is MVT2_EXACT_FORCE_BOTH_NUMFAIL.

The same force target Qy=18.5720088671875 kN is solved from H24 separately
with the H23-H24 1/64 secant and with the archived affine equilibrium at
18.5708039839326 kN used only as a field seed. None of those seed or trial
fields is committed to the force-test history. Both force solves give NumFail.
The recorded final diagnostic norms are 8.64138481e-4 and 1.85383125e-5 MPa.
The affine-seed norm is 46.61 times lower but still 16.53 times the target
tolerance. The seed's extra cost incurred in the separate affine solve is
outside these exact-force walltimes. H24 is restored exactly at every station.

The direct `TryStep` numerical witness does not exercise steel-limit polishing
or an integrated extra retry budget. This result establishes neither supported
exact-force continuation nor a physical limit.
