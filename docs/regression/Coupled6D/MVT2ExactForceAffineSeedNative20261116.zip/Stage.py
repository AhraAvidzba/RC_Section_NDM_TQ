"""Готовит проверку точной силовой цели с прогнозом от псевдодуги."""

from hashlib import sha256
import json
from pathlib import Path

here = Path(__file__).resolve().parent
repo = here.parents[1]
base = here.parent / "mvbc"
recovery = here.parent / "mvgf"
book = "workbook/output/RC_Section_NDM.xlsm"
test = "tests/modTestCoupledExperiment.bas"
runner = "Run-MVT2ShearControlled.ps1"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name, raw):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


raw = (base / "Preparation.json").read_bytes()
assert digest(raw) == "5B7321D7D780840199F52F36450FC1986559AE0D3417D8E08E2525C9B91FE73D"
old = json.loads(raw)
raw = (repo / book).read_bytes()
assert digest(raw) == old["book_sha256"]
put(book, raw)
put("docs/regression/Diagnostic.xlsm", raw)
for name in ("src", "Temp", "NativeHalf"):
    (here / name).mkdir(exist_ok=True)
inputs = {}
for name in ("Replay.csv", "VerifyBase.py", "Guard-IsolatedOffice.ps1", runner,
             *(k for k in old["inputs"] if k.startswith("tools/"))):
    data = (base / name).read_bytes()
    assert digest(data) == old["inputs"][name]
    inputs[name] = put(name, data)
case = (recovery / "VerificationCompare.json").read_bytes()
assert digest(case) == "CC64D1BB52C21D5B3A247D12E771D6945BAF66CC135FACAD02098D79A3DDD7CD"
verified = json.loads(case)
inputs["ReferenceArc.json"] = put("ReferenceArc.json", case)
raw = (recovery / "NativeCompare/MVT2.csv").read_bytes()
assert digest(raw) == verified["trace_sha256"]
inputs["ReferenceTrace.csv"] = put("ReferenceTrace.csv", raw)
[seed] = [row.decode("ascii").split(";") for row in raw.splitlines() if row.startswith(b"B_TANGENT_FIELD;Fallback;")]
assert len(seed) == 64 and float(seed[3]) == verified["outcomes"]["Fallback"]["returned_Qy_parameter_kN"]
inputs["ArcSeed.csv"] = put("ArcSeed.csv", (";".join(seed[4:] + [seed[3]]) + "\n").encode("ascii"))

source = (base / test).read_bytes()
assert digest(source) == old["inputs"][test]
module = source.decode("utf-8-sig").replace("\r\n", "\n")
marker = "' -------------------- ДЛЯ ТЕСТОВ --------------------"
start = module.rindex(marker, 0, module.index("Private Sub ProbeWangSameRayTest("))
end = module.rindex(marker, 0, module.index("Private Sub ReadWangRayVectorTest("))
module = module[:start] + (here / "ForceProbe.bas").read_text(encoding="utf-8") + "\n" + module[end:]
start = module.rindex(marker, 0, module.index("Private Sub ReadWangBranchActionTest"))
end = module.rindex(marker, 0, module.index("Private Sub CaptureWangArcHistoryTest"))
module = module[:start] + module[end:]
inputs[test] = put(test, module.replace("\n", "\r\n").encode("utf-8"))
for name in ("Stage.py", "ForceProbe.bas", "Verify-MVT2ShearControlled.py"):
    inputs[name] = digest((here / name).read_bytes())
config = {"inputs": inputs, "book_sha256": old["book_sha256"], "replay_sha256": old["replay_sha256"], "watchdog_seconds": 100}
print(put("Preparation.json", (json.dumps(config, indent=2) + "\n").encode()))
