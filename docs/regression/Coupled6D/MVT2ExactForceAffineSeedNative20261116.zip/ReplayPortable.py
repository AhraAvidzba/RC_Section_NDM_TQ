"""Verify the recorded exact-force comparisons without a workbook or Excel."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
CANONICAL = "058E8635C1B4FB562C3F643601563A87240887D59006188776393178B882F0D4"
RAW = "9E7C644A9F7B70F8F2EB812DA51FEFAD355A45D08ABCC1DAD01653CABFAEE21D"
SOURCES = {"automatic": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
           "jet": "6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33"}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def relative(root, path):
    return (root / path).resolve().relative_to(root.resolve())


def reproduce(work):
    native_verifier = work / "Verify-MVT2ShearControlled.py"
    source = native_verifier.read_text(encoding="utf-8")
    book = '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == config["book_sha256"]'
    assert source.count(book) == 1 and not (work / "workbook/output/RC_Section_NDM.xlsm").exists()
    source = source.replace(book, f'    assert config["book_sha256"] == "{WORKBOOK}"')
    scope = {"__file__": str(native_verifier), "__name__": "force_seed_archive_replay"}
    sys.path.insert(0, str(work))
    exec(compile(source, str(native_verifier), "exec"), scope)
    result = scope["verify"](*scope["inputs"]())
    assert digest((json.dumps(result, indent=2) + "\n").encode()) == CANONICAL
    assert digest((work / "VerificationForceSeed.json").read_bytes()) == CANONICAL
    assert result["trace_sha256"] == RAW and result["exact_H24_restored"]
    assert result["native_closure"]["State"] == "Absent"
    expected = {"Secant": 8.6413848066818e-4, "Arc": 1.85383124514848e-5}
    tolerance = 5e-7 * (1. + scope["v"].peak(scope["v"].loading(result["target_Qy_kN"])))
    for arm, final_norm in expected.items():
        reported = result["results"][arm]
        assert (reported["returned_equilibrium"], reported["status"], reported["code"]) == (False, 6, 10)
        norms = re.findall(r"невязка, МПа: ([0-9.E+\-]+)", reported["diagnostic"])
        assert len(norms) == 1 and float(norms[0]) == final_norm and final_norm > tolerance
    states, _ = scope["v"].verified_states(scope["v"].read_native(work / "NativeHalf/MVT2.csv"))
    assert set(states) == {"Base24", "Restored24"}
    return {"reference_report_sha256": CANONICAL, "native_source_trace_sha256": RAW, "exact_target_tolerance_MPa": tolerance,
            "last_trial_diagnostic_MPa": expected, "improvement_secant_over_arc": expected["Secant"] / expected["Arc"],
            "arc_last_trial_over_original_tolerance": expected["Arc"] / tolerance,
            "force_increment_from_source_arc_to_target_N": 1000. * (result["target_Qy_kN"] - result["source_arc_Qy_kN"]),
            "exact_force_equilibrium_returned": False, "exact_H24_rollback": True, "physical_limit_established": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("automatic", type=Path)
    parser.add_argument("jet", type=Path)
    parser.add_argument("--audit-output", type=Path)
    args = parser.parse_args()
    manifest = json.loads((HERE / "PortableManifest.json").read_bytes())
    assert manifest["source_archives"] == SOURCES and manifest["omitted_workbook_sha256"] == WORKBOOK
    for name, expected in SOURCES.items():
        assert digest(getattr(args, name).read_bytes()) == expected
    with TemporaryDirectory() as folder, ZipFile(args.automatic) as auto, ZipFile(args.jet) as jet:
        work = Path(folder)
        archives = {"automatic": auto, "jet": jet}
        for name, expected in manifest["files"].items():
            data = (HERE / relative(HERE, name)).read_bytes()
            assert digest(data) == expected, name
            target = work / relative(work, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        for name, (archive, member, expected) in manifest["dependencies"].items():
            data = archives[archive].read(member)
            assert digest(data) == expected, name
            target = work / relative(work, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        report = (json.dumps(reproduce(work), indent=2) + "\n").encode()
    if args.audit_output is not None:
        args.audit_output.write_bytes(report)
    if "NumericalAudit.json" in manifest["files"]:
        assert digest(report) == manifest["files"]["NumericalAudit.json"]
    print("MVT2_EXACT_FORCE_BOTH_NUMFAIL", CANONICAL, "NUMERICAL_AUDIT", digest(report))


if __name__ == "__main__":
    main()
