"""Независимо проверяет силовой результат от двух начальных полей."""

import argparse
import json
from pathlib import Path

import VerifyBase as v

here = Path(__file__).resolve().parent
native = here / "NativeHalf"


def inputs():
    config = v.read(here / "Preparation.json")
    assert all(v.digest(here / name) == expected for name, expected in config["inputs"].items())
    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == config["book_sha256"]
    assert v.digest(here / "Replay.csv") == config["replay_sha256"]
    reference = v.read(here / "ReferenceArc.json")
    assert reference["book_sha256"] == config["book_sha256"]
    raw = here / "ReferenceTrace.csv"
    assert v.digest(raw) == reference["trace_sha256"]
    old, old_stations = v.verified_states(v.read_native(raw))
    seed = tuple(map(float, (here / "ArcSeed.csv").read_text(encoding="ascii").strip().split(";")))
    assert seed == (*old["Fallback"]["field"], old["Fallback"]["q"])
    return config, reference, old, old_stations, seed


def verify(config, reference, old, old_stations, seed):
    compile_info = v.read(here / "docs/regression/CodeUpdate.json")
    compiler = v.read(here / "CompileClosure.json")
    owner = v.read(native / "MVT2.txt.Ownership.json")
    watchdog = v.read(native / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(native / "RunReceipt.json")
    close = watchdog["Closure"]["FinalState"]
    assert compile_info["Compiled"] and not compile_info["ProductionChanged"]
    assert compile_info["Modules"] == ["modTestCoupledExperiment"]
    assert compile_info["ProductionSHA256"] == config["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == compile_info["WorkbookSHA256"]
    assert watchdog["Passed"] and watchdog["ChildHasExited"] and watchdog["ChildExitCode"] == receipt["native_exit"] == 0
    assert close["State"] == "Absent" and close["PID"] == owner["PID"] and close["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    raw = native / "MVT2.csv"
    tags = v.read_native(raw)
    states, stations = v.verified_states(tags)
    assert states["Base24"] == states["Restored24"] == old["Base24"]
    assert stations["Base24"] == stations["Restored24"] == old_stations["Base24"]
    history = v.vec(tags, "MVT2_CONTROL_FIELD")
    q23, q24 = history["Replay23"], history["Replay24"]
    secant = tuple(b + (b-a)/64 if i < 56 else b for i, (a, b) in enumerate(zip(q23, q24, strict=True)))
    starts = v.vec(tags, "B_FORCE_SEED")
    assert set(starts) == {"Arc", "Secant"} and starts["Arc"] == seed[:60]
    assert v.peak(v.diff(starts["Secant"], secant)) < 4e-15
    snapshots = {name: tuple(vals) for name, *vals in tags["B_ARC_HISTORY"]}
    assert set(snapshots) == {"Before", "Arc", "Secant", "Final"}
    assert all(vals == snapshots["Before"] and len(vals) == 1080 for vals in snapshots.values())
    steel = v.verify_steel(tags, states, stations, history)
    details = {label: ";".join(values) for label, *values in tags["B_FORCE_DETAILS"]}
    results = {}
    for name, solved, status, code, seconds in tags["B_FORCE_SEEDED"]:
        assert name in starts and name not in results and solved in ("0", "1")
        answer = {"returned_equilibrium": solved == "1", "status": int(status), "code": int(code), "seconds": float(seconds),
                  "diagnostic": details[name]}
        if solved == "1":
            state = states[name]
            requested = reference["arc_predictor_Qy_kN"]
            assert abs(state["q"] - requested) < 5e-14
            assert max(state["norm_MPa"], state["gauge_MPa"]) <= state["tol_MPa"]
            answer.update({"q_parameter_kN": state["q"], "norm_MPa": state["norm_MPa"], "tolerance_MPa": state["tol_MPa"],
                           "signed_force_errors_N_Nmm": state["signed_force_N_Nmm"], "gauge_norm_MPa": state["gauge_MPa"],
                           "steel_max_MPa": steel[name], "actual_resultants": v.reconstruct(state["field"], state["q"], stations[name])[1]})
        else:
            assert name not in states
        results[name] = answer
    assert set(results) == set(starts)
    return {"workbook_sha256": config["book_sha256"], "trace_sha256": v.digest(raw), "source_arc_Qy_kN": seed[-1],
            "target_Qy_kN": reference["arc_predictor_Qy_kN"], "exact_H24_restored": True, "native_closure": close,
            "results": results}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Half"])
    args = parser.parse_args()
    data = inputs()
    if args.inputs_only:
        print("FROZEN INPUTS", v.digest(here / "Preparation.json"))
    else:
        output = here / "VerificationForceSeed.json"
        output.write_bytes((json.dumps(verify(*data), indent=2) + "\n").encode())
        print("MVT2 FORCE SEED NATIVE", v.digest(output))
