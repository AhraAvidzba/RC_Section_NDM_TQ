"""Cold MVT2 comparisons of tensile onset, nominal postpeak stress and degradation."""
from argparse import ArgumentParser
from bisect import bisect_right
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from types import SimpleNamespace
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
from Reequilibrate import HERE,NUMPY,read_inputs,simulate

OPS_FILE=Path("D:/CodexScratch/RC_Section_NDM_TQ/MVTGauss25Operators/Native/Operators.csv")
FACTORS_SHA="2EFB8356ADC6EB57D77CBEE2FF609DCD8F7CE4C0A2E9D3C63B393591111E3BC5"
OPS_SHA="3E8C00B7AC650B9FF6BBF55C412AED9A18A258BCEE3083D58ECEA9B7A07B653A"
ARMS=("onset_and_peak_strain","nominal_postpeak","degradation_at_fixed_nominal")


def digest(data):
    return sha256(data).hexdigest().upper()


def split(table):
    index=max(range(len(table)),key=lambda i:table[i][1])
    peak=table[index][0]
    return table[:index+1],[(x-peak,s,d) for x,s,d in table[index:]]


def interpolate(table,x,k):
    nodes=[r[0] for r in table]
    i=bisect_right(nodes,x)
    if i==len(table):
        return table[-1][k]
    a,b=table[i-1],table[i]
    return a[k]+(b[k]-a[k])*(x-a[0])/(b[0]-a[0])


def construct(source,modulus,validate):
    stock_raw=source["tables"]["stock"]["TENSION"]
    ndm_raw=source["tables"]["NDM"]["TENSION"]
    stock_pre,stock_post=split(stock_raw)
    ndm_pre,ndm_post=split(ndm_raw)
    peak=stock_pre[-1][0]
    first=list(map(tuple,ndm_pre))
    first.extend((ndm_pre[-1][0]+offset,s,d) for offset,s,d in stock_post[1:])
    coords=sorted(set(row[0] for row in stock_post+ndm_post))[1:]
    nominal=list(map(tuple,stock_pre))
    degradation=list(map(tuple,stock_pre))
    caps=[]
    p_previous=peak-stock_pre[-1][1]/modulus
    epsilon_previous=peak
    for offset in coords:
        strain=peak+offset
        nominal.append((strain,interpolate(ndm_post,offset,1),interpolate(stock_post,offset,2)))
        stress=interpolate(stock_post,offset,1)
        requested=interpolate(ndm_post,offset,2)
        # Positive plastic increment avoids re-clipping the analytically capped row in Double.
        guard=min(1e-12,1e-6*(strain-epsilon_previous))
        available=1.-stress/(modulus*(strain-p_previous-guard))
        actual=min(requested,available)
        if requested-actual>1e-12:
            caps.append((offset,requested,actual))
        assert actual>=degradation[-1][2]-1e-14
        p_previous=strain-stress/(modulus*(1.-actual))
        epsilon_previous=strain
        degradation.append((strain,stress,actual))
    cases=dict(zip(ARMS,(first,nominal,degradation),strict=True))
    for name,table in cases.items():
        validate(table,modulus,name)
    return cases,caps


def material(report,tension,compression):
    wire=["ASDConcrete3D",*report["model"][:2]]
    for label,table in (("T",tension),("C",compression)):
        for col,var in enumerate("esd"):
            wire.extend(["-"+label+var,*(row[col] for row in table)])
    return wire+["-tangent"]


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument("--operators",type=Path,default=OPS_FILE)
    p.add_argument("--numpy",type=Path,default=NUMPY)
    p.add_argument("--out",type=Path,default=HERE/"TensileHybrid.json")
    p.add_argument("--inspect-only",action="store_true")
    p.add_argument("--curves-only",action="store_true")
    a=p.parse_args()
    assert digest(a.operators.read_bytes())==OPS_SHA
    sys.path.insert(0,str(a.numpy))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0" and np.__version__=="2.3.5"
    raw=(HERE/"CurveFactor.json").read_bytes()
    assert digest(raw)==FACTORS_SHA
    reference=json.loads(raw)
    shared,data,geo,dirs,area,length,operators,seeds,observed,proof=read_inputs(a.operators)
    helpers=runpy.run_path(str(shared["D"]/shared["ENVELOPE"]))
    cases,caps=construct(reference,data["model"][0],helpers["validate_branch"])
    compression=reference["tables"]["stock"]["COMPRESSION"]
    if a.curves_only:
        print("ADMISSIBLE",{"knots":{k:len(v) for k,v in cases.items()},"cap_rows":len(caps),
                            "first_cap":caps[0] if caps else None})
        return
    if a.inspect_only:
        brick=runpy.run_path(str(shared["D"]/shared["BRICK"]))["brick"]
        quality={}
        for name,tension in cases.items():
            command=material(data,tension,compression)
            brick(lambda tag:ops.nDMaterial(command[0],tag,*command[1:]),
                  [tuple(data["frames"][0]["points"][2][:6])],
                  SimpleNamespace(components=shared["voigt"]),125.)
            differences={}
            for branch,table in (("tension",tension),("compression",compression)):
                observed_table=helpers["read_installed_branch"](1,1,branch)
                difference=max(abs(v-w) for o,t in zip(observed_table,table,strict=True) for v,w in zip(o,t,strict=True))
                assert difference<1e-8
                differences[branch]=difference
            quality[name]=differences
        print("INSTALLED TABULAR ASD",json.dumps(quality,sort_keys=True))
        return
    deadline=perf_counter()+110.
    outcomes={};stresses={}
    for name,tension in cases.items():
        print("START",name,flush=True)
        try:
            outcomes[name],stresses[name]=simulate(np,ops,shared,data,geo,dirs,area,length,operators,
                seeds,name,material(data,tension,compression),deadline,26)
        finally:
            ops.wipe()
        print("FINISH",name,outcomes[name]["last_confirmed"],flush=True)
    anchors={}
    for name,case in outcomes.items():
        saved={r["phase"]:r["twist_rad_per_m"] for r in case["accepted"]}
        anchors[name]={key:saved.get(key) for key in ("R8","S1","S18")}
    wire=gzip.compress(json.dumps(stresses,sort_keys=True,separators=(",",":"),allow_nan=False).encode(),
                       compresslevel=9,mtime=0)
    with a.out.with_suffix(".stress.json.gz").open("xb") as o:
        o.write(wire)
    final={"status":"PASS","engine":"3.8.0","numpy":np.__version__,"native_operators":proof,
           "previous_branch_experiment_SHA256":FACTORS_SHA,"ASD_accepted_stresses_SHA256":digest(wire),
           "assumption":"fixed original compression, exact shifted tensile onset or postpeak nominal, admissibly clipped degradation",
           "hybrid_tension_tables":cases,"compression_table":compression,"degradation_caps":caps,
           "twist_anchors_rad_per_m":anchors,"runs":outcomes,"physical_limit_established":False}
    content=(json.dumps(final,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with a.out.open("xb") as f:
        f.write(content)
    print("HYBRIDS PASS",digest(content),digest(wire))


if __name__=="__main__":
    main()
