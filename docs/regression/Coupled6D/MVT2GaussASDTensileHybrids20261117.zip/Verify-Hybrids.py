"""Verify the three tensile hybrids and their accepted 60-row equilibria offline."""
from argparse import ArgumentParser
from bisect import bisect_right
from hashlib import sha256
from math import isclose
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
AUTH=("MVT2GaussReequilibratedASD20261117","FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E")
FACT=("MVT2GaussASDBranchFactorial20261117","C608C6BA4BCD3ED21B950F903815D8A8E67446724B78F25962201430E6836246")
FACTOR_SHA="2EFB8356ADC6EB57D77CBEE2FF609DCD8F7CE4C0A2E9D3C63B393591111E3BC5"
REPORT_SHA="362EF0B11EBD24B75B967E90F5FA5A8E377AE4ADFCB6D91A14CC7BF5BA8F4B85"
STRESS_SHA="A111BE2B791525D6E3B826D7DC0302AEA5612938F71946380131622A45620ED8"


def digest(data):
    return sha256(data).hexdigest().upper()


def archive(repo,ref):
    path=repo/"docs/regression/Coupled6D"/(ref[0]+".zip")
    assert digest(path.read_bytes())==ref[1]
    return ZipFile(path)


def verify_files():
    names=set()
    for line in (HERE/"SHA256SUMS").read_text(encoding="ascii").splitlines():
        sha,name=line.split("  ",1)
        p=PurePosixPath(name)
        assert not p.is_absolute() and ".." not in p.parts and name not in names
        assert digest((HERE/name).read_bytes())==sha
        names.add(name)
    assert names=={p.relative_to(HERE).as_posix() for p in HERE.rglob("*")
                   if p.is_file() and p.name!="SHA256SUMS"}


def branch(table):
    peak=max(table,key=lambda r:r[1])
    return peak[0],peak[1],{r[0]-peak[0]:r[1:] for r in table if r[0]>=peak[0]}


def interp(values,x,index):
    axis=list(values)
    hi=bisect_right(axis,x+2e-18)
    if hi==len(values):
        return values[axis[-1]][index]
    lower,upper=axis[hi-1],axis[hi]
    f=max(0.,(x-lower)/(upper-lower))
    return values[lower][index]*(1-f)+values[upper][index]*f


def curves(proof,source,model):
    report=proof["hybrid_tension_tables"]
    assert proof["compression_table"]==source["tables"]["stock"]["COMPRESSION"]
    s,_,st=branch(source["tables"]["stock"]["TENSION"])
    n,_,nt=branch(source["tables"]["NDM"]["TENSION"])
    pm,_,pp=branch(report["nominal_postpeak"])
    dm,_,dp=branch(report["degradation_at_fixed_nominal"])
    om,_,op=branch(report["onset_and_peak_strain"])
    assert pm==dm==s and om==n
    assert list(op.values())==list(st.values())
    assert all(abs(a-b)<2e-17 for a,b in zip(op,st,strict=True))
    for x,(stress,damage) in pp.items():
        assert isclose(stress,interp(nt,x,0),abs_tol=5e-12,rel_tol=1e-10)
        assert abs(damage-interp(st,x,1))<2e-14
    caps=[]
    previous=0.
    total=0.
    for x,(stress,damage) in dp.items():
        expected=interp(nt,x,1)
        assert isclose(stress,interp(st,x,0),abs_tol=5e-12,rel_tol=1e-10)
        plastic=s+x-stress/(model[0]*(1-damage))
        assert plastic>=previous-2e-12 and damage<=expected+2e-14
        if expected-damage>1e-12:
            caps.append(x)
        total=max(total,expected-damage)
        previous=plastic
    recorded=proof["degradation_caps"]
    assert len(caps)==len(recorded)==226 and max(abs(x-r[0]) for x,r in zip(caps,recorded,strict=True))<2e-18
    return {"first_degradation_cap_strain_offset":caps[0],"max_degradation_cap_reduction":total}


def main(repo):
    verify_files()
    raw=(HERE/"TensileHybrid.json").read_bytes()
    stresses=(HERE/"TensileHybrid.stress.json.gz").read_bytes()
    assert digest(raw)==REPORT_SHA and digest(stresses)==STRESS_SHA
    proof=json.loads(raw)
    assert proof["ASD_accepted_stresses_SHA256"]==STRESS_SHA and proof["previous_branch_experiment_SHA256"]==FACTOR_SHA
    assert proof["physical_limit_established"] is False
    stresses=json.loads(gzip.decompress(stresses))
    with archive(repo,FACT) as z:
        source=z.read("CurveFactor.json")
        assert digest(source)==FACTOR_SHA
        source=json.loads(source)
    with tempfile.TemporaryDirectory(prefix="MVTASDTensionHybrids_") as name:
        work=Path(name)
        with archive(repo,AUTH) as z:
            for leaf in ("Verify-Authoritative.py","Operators.py","Reequilibrate.py"):
                (work/leaf).write_bytes(z.read(leaf))
        sys.path.insert(0,str(work))
        guard=runpy.run_path(str(work/"Verify-Authoritative.py"))
        operators,helper=guard["unpack"](work,repo)
        replay=runpy.run_path(str(work/"Reequilibrate.py"))
        sh,native,geom,dirs,area,length,op,seeds,h,identity=replay["read_inputs"](operators,work,helper)
        assert identity==proof["native_operators"]
        verified=curves(proof,source,native["model"])
        paths={}
        expected={"onset_and_peak_strain":(26,15000.),"nominal_postpeak":(10,5312.5),"degradation_at_fixed_nominal":(26,15000.)}
        assert set(proof["runs"])==set(stresses)==set(expected)
        for key,(n,qn) in expected.items():
            series=proof["runs"][key]
            full=series["accepted"]
            assert len(full)==n and full[-1]["Q_target_N"]==qn
            assert series["rejected_trial_interleaving_max_MPa"]==0. and not series["physical_limit_established"]
            agreement=[guard["check"](sigma,row,geom,dirs,area,length,op)
                       for sigma,row in zip(stresses[key],full,strict=True)]
            assert [r["T_target_Nmm"] for r in full[:8]]==[f["T_Nmm"] for f in native["frames"][:8]]
            assert all(row["T_target_Nmm"]==10510000. for row in full[8:])
            phases={row["phase"]:row["twist_rad_per_m"] for row in full}
            assert proof["twist_anchors_rad_per_m"][key]=={tag:phases.get(tag) for tag in ("R8","S1","S18")}
            paths[key]={"fields":n,"last_confirmed_Qy_N":qn,"max_independent_norm_MPa":max(a[0] for a in agreement)}
        stopped=proof["runs"]["nominal_postpeak"]["terminal"]
        assert stopped["last_reached_Q_N"]==5312.5 and stopped["reason"]=="bounded_numerical_stop"
        assert stopped["Q_requested_N"]==6250 and stopped["T_requested_Nmm"]==10510000.
        assert all(proof["runs"][k]["complete_nominal_targets"] for k in expected if k!="nominal_postpeak")
    print("MVT2 ASD TENSILE HYBRID OFFLINE PASS",REPORT_SHA,STRESS_SHA,verified,paths)


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--repo",type=Path,default=Path.cwd())
    main(parser.parse_args().repo)
