H26 fixed-control proof. Compare baseline and guide seed at the first ordinary half-span target.

    python -B -X utf8 tmp/mv26f/Stage.py
    python -B -X utf8 tmp/mv26f/Verify-MVT2ShearControlled.py --inputs-only

After the exclusive Office slot has been assigned and resource preflight passes:

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mv26f/Run-MVT2ShearControlled.ps1

Reconstruct H25 and H26 exactly, reproduce the original attempt-6 rejection, and obtain the same
legacy material-yield guide as the previously verified affine case. Discard that guide. Compute
the ordinary control via SelectDeformationControl from accepted H25 and H26. Recreate the first
ordinary half-span target using c(H26) + 0.5*(c(H26)-c(H25)). Arm Stock starts from exact accepted
H26. Arm Seed uses the archive-confirmed guide as initial field and load. Both use the same fixed
target, tolerance and iteration budget, with unchanged recovery defaults and no load coefficient
in the control. Check all 56 weak rows, six actual resultants, four gauges and the fixed control
against exact restored H26 history. Neither arm commits its trial. End restoring H24.
The result applies to this fixed target. The fixture does not exercise shoulder ordering.
