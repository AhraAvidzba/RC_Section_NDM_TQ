"""Seal a fixed-deformation H26 baseline and same-target yield-guide probe."""
import csv
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent/"mv26y"
PREP = "8F6D2FF08B715F83EDD39DA9D00921A3647926F0EE883E9370740A517F1CB0F2"
RAW = "1024CC65B110A6B48FE1D8C92B154295612DD6408234EF9128B3EC4130622A0E"
REPORT = "0B9E9033401684AEF852C7A49292FB36B81C5265D8BF27376709375BD1F06949"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MACRO = "tests/modTestCoupledExperiment.bas"
VERIFY = "Verify-MVT2ShearControlled.py"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name,data):
    target = HERE/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_bytes() == data, name
    else:
        target.write_bytes(data)
    return digest(data)


def locked_guide(raw):
    assert digest(raw) == RAW
    selected = {}
    for tag,*row in csv.reader(raw.decode("cp1251").splitlines(),delimiter=";"):
        if (tag == "B_Y_SEED_EVENT" or (tag == "B_TANGENT_FIELD" and row[0] == "YieldGuide") or
                (tag == "B_Y_SEED_GATES" and row[0] == "Guide")):
            assert tag not in selected
            selected[tag] = row
    assert selected["B_Y_SEED_EVENT"][:2] == ["22","-1"]
    assert selected["B_TANGENT_FIELD"][:3] == ["YieldGuide","26","18.5813383708966"]
    assert len(selected["B_TANGENT_FIELD"]) == 63
    return selected


def overlay_macro(raw):
    source = raw.decode("utf-8-sig").replace("\r\n","\n")
    old = '''                RunWangYieldSeedTest output, solver, operators, materials, responses, baseField, baseFactor, _
                    projection, normalLoad, metric, loadMetric, nominal, target, committed
                RunWangYieldAnchorTest output, solver, operators, materials, responses, baseField, baseFactor, _
                    projection, normalLoad, metric, loadMetric, target, committed
'''
    new = '''                RunWangFixedGuideTest output, solver, operators, materials, responses, workingHistory, baseField, baseFactor, committed
'''
    assert source.count(old) == 1
    source = source.replace(old,new)
    start = source.index("Private Sub RunWangYieldSeedTest(")
    split = source.rfind("' -------------------- ДЛЯ ТЕСТОВ --------------------\n",0,start)
    source = source[:split].rstrip()+"\n\n"+(HERE/"FixedTest.txt").read_text(encoding="utf-8")
    assert max(map(len,source.splitlines())) < 1023
    return source.replace("\n","\r\n").encode()


def main():
    prep = (BASE/"Preparation.json").read_bytes()
    report = (BASE/"VerificationYieldSeed.json").read_bytes()
    assert digest(prep) == PREP and digest(report) == REPORT
    metadata = json.loads(prep)
    proof = locked_guide((BASE/"NativeResume/MVT2.csv").read_bytes())
    files = {"GuideWitness.json":put("GuideWitness.json",(json.dumps(proof,indent=2)+"\n").encode())}
    for path,expected in metadata["inputs"].items():
        raw = (BASE/path).read_bytes()
        assert digest(raw) == expected
        if path in ("Stage.py","GuideTest.txt",VERIFY):
            continue
        if path == MACRO:
            raw = overlay_macro(raw)
        files[path] = put(path,raw)
    for name in ("Stage.py","FixedTest.txt","README.txt",VERIFY):
        files[name] = digest((HERE/name).read_bytes())
    assert put("docs/regression/Diagnostic.xlsm",(HERE/BOOK).read_bytes()) == metadata["book_sha256"]
    for folder in ("NativeResume","Temp"):
        (HERE/folder).mkdir(exist_ok=True)
    metadata = {**metadata,"inputs":files,"previous_guide_preparation_sha256":PREP,"previous_guide_trace_sha256":RAW}
    print(put("Preparation.json",(json.dumps(metadata,indent=2)+"\n").encode()))


if __name__ == "__main__":
    main()
