"""Compare real fixed-control proof candidates and charge the guide preparation cost."""
from math import hypot
import re

import PriorReplay as prior
import VerifyBase as v


def summarize(report, raw_file, legacy):
    raw = v.read_native(raw_file)
    fields = prior.by_name(raw,"B_TANGENT_FIELD")
    station = {}
    observed_labels = {"Base24","Attempt1","Attempt2","FixedGuide","FixedStock","FixedSeed"}
    for key,point,side,*row in raw["B_TANGENT_STATION"]:
        if key in observed_labels:
            station.setdefault(key,{})[int(point),int(side)] = prior.numbers(row)
    geometry = {key:row[:3] for key,row in station["Base24"].items()}
    assert len(geometry)==135
    assert all(geometry=={key:row[:3] for key,row in sample.items()} for sample in station.values())
    rows = v.vec(raw,"B_TANGENT_RESIDUAL")
    actual_forces = prior.by_name(raw,"B_BOUND_ACTUAL")
    count,factor,*qwire = fields["FixedGuide"]
    q = prior.numbers(qwire)
    assert count=="26" and float(factor)==report["guide_Qy_kN"]
    forces = prior.numbers(actual_forces["FixedGuide"])
    assert len(forces) == 6
    weak,actual,defect = v.reconstruct(q,float(factor),station["FixedGuide"])
    assert defect<4e-15 and v.peak(v.diff(weak,rows["FixedGuide"]))<3e-10
    assert v.peak(e/s for e,s in zip(v.diff(actual,forces),v.SCALES,strict=True))<4e-12
    force_error = v.peak(e/s for e,s in zip(v.diff(actual,v.force(float(factor))),v.SCALES,strict=True))
    tol = 5e-7*(1+v.peak(v.loading(float(factor))))
    all_norm = max(v.peak(weak[:56]),v.peak(e*v.MODULUS for e in weak[56:]),force_error)
    assert all_norm<tol
    saved_guide = next(item for item in legacy["trials"] if item["mode"]=="Guide")
    v.near(all_norm/tol,saved_guide["full_residual_over_original_tau"],3e-4)
    coord = v.dot(report["selected_projection"],q)
    guide_control_error = v.MODULUS*(coord-report["target_coordinate"])
    numeric = []
    for trial in report["trials"]:
        counts = re.search(r"Итерации: (\d+); пробы: (\d+);",trial["diagnostic"])
        assert counts is not None
        startup = report["guide_construction_seconds"] if trial["mode"]=="FixedSeed" else 0.
        numeric.append({"mode":trial["mode"],"iterations":int(counts[1]),"residual_evaluations":int(counts[2]),
                        "solver_wall_seconds":trial["solver_seconds"],"additional_guide_wall_seconds":startup,
                        "target_and_guide_wall_seconds":trial["solver_seconds"]+startup})
    answer = {"native_trace_sha256":v.digest(raw_file),"guide_original_equilibrium_norm_MPa":all_norm,
              "guide_mismatch_to_fixed_control_MPa":guide_control_error,"candidates":numeric}
    if all(t["met_original_target"] for t in report["trials"]):
        warm,cold = (report["trials"][i] for i in (1,0))
        delta_field = v.diff(prior.numbers(fields["FixedSeed"][2:]),prior.numbers(fields["FixedStock"][2:]))
        answer.update({"delta_Qy_seed_minus_stock_N":1000*(warm["Qy_kN"]-cold["Qy_kN"]),
                       "delta_six_seed_minus_stock_N_Nmm":v.diff(warm["actual_six_N_Nmm"],cold["actual_six_N_Nmm"]),
                       "mechanical_strain_RMS_between_candidates":hypot(*prior.station_metric(delta_field,geometry)),
                       "maximum_point_strain_difference":v.strain_extent(delta_field,geometry)})
    return answer
