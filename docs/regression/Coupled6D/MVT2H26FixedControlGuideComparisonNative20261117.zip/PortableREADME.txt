H26 fixed-measure comparison against the baseline for one native half-span target.

    python -B -X utf8 ReplayFixedPortable.py --archives <repository>/docs/regression/Coupled6D

The detached verifier reconstructs the guide witness, exact VBA overlay, native receipt, and the
fixed coordinate chosen by the original algorithm. It reproduces the two reports byte for byte.
Both arms use the same fixed target and iteration allowance; only the initial field and load
change. FixedComparison verifies common geometry and the auxiliary guide's actual equilibrium.
It separately charges guide construction time and reports differences between successful fields.
Each arm restores H26 exactly; neither trial is committed. The fixture finishes at original H24.
This evidence pertains to the tested coordinate and does not exercise peak shoulders or warrant
a change to the production search. No capacity value, workbook copy, or installation is included.
