"""Reproduce the H26 fixed-measure baseline and guide comparison without Excel."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import ModuleType
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
PARENT = "MVT2H26YieldGuideOriginalPlaneNative20261117.zip"
DEPENDENCIES = {
    PARENT: "8B5402E9D61B2C058DF2FA3033E81767C8AFF70CB82810B5807AAFFADBA2883F",
    "MVT2H26RadiusRejectionNative20261117.zip": "72D5A584147EB019F811EAA92E439F81504E88218FF499899A1BE17152FD1788",
    "MVT2ExactH26SmallerArcNative20261116.zip": "B775E3D70EED7CC8239F905AC4E3779AA65CE8994BA1F045BED899B6235B4F07",
    "MVT2AdaptiveBoundedContinuationNative20261116.zip": "A5F4EABFE14F46544D6BA36934B050AED5C5F3655DC91D32D6E8C6408562E699",
    "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
    "MVT2StockBranchArcNative20261116.zip": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def local(root,name):
    return root/(root/name).resolve().relative_to(root.resolve())


def materialize(work,manifest,archives):
    assert manifest["archives"]==DEPENDENCIES and manifest["workbook"]=={"path":BOOK,"sha256":WORKBOOK}
    for name, expected in DEPENDENCIES.items():
        assert digest((archives/name).read_bytes())==expected
    for name,rec in manifest["inputs"].items():
        source = rec.get("archive")
        member = rec.get("member",name)
        if source:
            with ZipFile(archives/source) as archive:
                raw=archive.read(member)
        else:
            raw=local(HERE,member).read_bytes()
        assert digest(raw)==rec["sha256"],name
        target=local(work,name)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)


def scope_of(path, name):
    scope={"__name__":name,"__file__":str(path)}
    exec(compile(path.read_text(encoding="utf-8"),str(path),"exec"),scope)
    return scope


def replay(work,archives,defn):
    stage=scope_of(work/"Stage.py","archived_stage")
    with ZipFile(archives/PARENT) as parent:
        assert digest(parent.read("Preparation.json"))==stage["PREP"]
        proof=stage["locked_guide"](parent.read("NativeResume/MVT2.csv"))
        assert (json.dumps(proof,indent=2)+"\n").encode()==(work/"GuideWitness.json").read_bytes()
        actual_macro=work/stage["MACRO"]
        assert stage["overlay_macro"](parent.read(stage["MACRO"]))==actual_macro.read_bytes()
        guide=parent.read("VerificationYieldSeed.json")
        assert digest(guide)==stage["REPORT"]
    sys.path.insert(0,str(work))
    path=work/"ResumeBase.py"
    content=path.read_text(encoding="utf-8")
    anchor='    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items())'
    assert not (work/BOOK).exists() and content.count(anchor)==1
    pinned=(f'    assert prep["inputs"]["{BOOK}"] == prep["book_sha256"] == "{WORKBOOK}"\n'
            f'    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items() if path != "{BOOK}")')
    base=ModuleType("ResumeBase")
    base.__file__=str(path)
    sys.modules["ResumeBase"]=base
    exec(compile(content.replace(anchor,pinned),str(path),"exec"),base.__dict__)
    verifier=scope_of(work/"Verify-MVT2ShearControlled.py","archived_proof")
    report=verifier["verify"](*verifier["prepare"]())
    pinned_report=(work/"VerificationFixedControl.json").read_bytes()
    assert digest(pinned_report)==defn["verification_sha256"] and (json.dumps(report,indent=2)+"\n").encode()==pinned_report
    from AnalyzeFixed import summarize
    native=work/"NativeResume/MVT2.csv"
    summary=summarize(report,native,json.loads(guide))
    pinned_analysis=(work/"FixedComparison.json").read_bytes()
    assert digest(pinned_analysis)==defn["analysis_sha256"] and (json.dumps(summary,indent=2)+"\n").encode()==pinned_analysis
    return report,summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives",type=Path,required=True)
    args=parser.parse_args()
    definition=json.loads((HERE/"PortableManifest.json").read_bytes())
    with TemporaryDirectory() as tmp:
        work=Path(tmp)
        materialize(work,definition,args.archives)
        report,summary=replay(work,args.archives,definition)
    print("FIXED CONTROL",definition["verification_sha256"],"INDEPENDENT ANALYSIS",definition["analysis_sha256"])
    print("ORIGINAL TARGET",report["target_coordinate"],"SOLVED",[r["met_original_target"] for r in report["trials"]])
    print("WORK",[(r["iterations"],r["residual_evaluations"],r["target_and_guide_wall_seconds"]) for r in summary["candidates"]])


if __name__=="__main__":
    main()
