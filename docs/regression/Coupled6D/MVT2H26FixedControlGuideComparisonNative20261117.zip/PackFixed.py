"""Pack the native fixed-control H26 fixture and replay it after extraction."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import AnalyzeFixed
import ReplayFixedPortable as replay

HERE=Path(__file__).resolve().parent
REGRESSION=HERE.parents[1]/"docs/regression/Coupled6D"
RESULT=HERE/"MVT2H26FixedControlGuideComparisonNative20261117.zip"


def main():
    prep=json.loads((HERE/"Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK]==prep["book_sha256"]==replay.WORKBOOK
    lookup={}
    for name,expected in replay.DEPENDENCIES.items():
        path=REGRESSION/name
        assert replay.digest(path.read_bytes())==expected
        with ZipFile(path) as z:
            for member in z.namelist():
                if not member.casefold().endswith(".xlsm"):
                    lookup.setdefault(replay.digest(z.read(member)),(name,member))
    with ZipFile(REGRESSION/replay.PARENT) as source:
        guide=json.loads(source.read("VerificationYieldSeed.json"))
    verification=(HERE/"VerificationFixedControl.json").read_bytes()
    summary=AnalyzeFixed.summarize(json.loads(verification),HERE/"NativeResume/MVT2.csv",guide)
    analysis=(json.dumps(summary,indent=2)+"\n").encode()
    (HERE/"FixedComparison.json").write_bytes(analysis)
    extra=("Preparation.json","Compile.log","CompileClosure.json","Run.ndjson","docs/regression/CodeUpdate.json",
           "VerificationFixedControl.json","AnalyzeFixed.py","FixedComparison.json","PackFixed.py","ReplayFixedPortable.py","PortableREADME.txt")
    native=tuple(f"NativeResume/{p.name}" for p in (HERE/"NativeResume").iterdir() if p.is_file())
    entries,content={},{}
    for name in sorted(set(prep["inputs"])|set(extra)|set(native)):
        if name==replay.BOOK:
            continue
        raw=(HERE/name).read_bytes()
        digest=replay.digest(raw)
        if name in prep["inputs"]:
            assert digest==prep["inputs"][name]
        older=lookup.get(digest) if name in prep["inputs"] else None
        if older:
            archive,member=older
            entries[name]={"archive":archive,"member":member,"sha256":digest}
        else:
            entries[name]={"sha256":digest}
            content[name]=raw
    manifest={"workbook":{"path":replay.BOOK,"sha256":replay.WORKBOOK},"archives":replay.DEPENDENCIES,"inputs":entries,
              "verification_sha256":replay.digest(verification),"analysis_sha256":replay.digest(analysis)}
    content["PortableManifest.json"]=(json.dumps(manifest,indent=2)+"\n").encode()
    assert all(not path.casefold().endswith(".xlsm") for path in content)
    with ZipFile(RESULT,"w",compresslevel=9) as z:
        for member, raw in sorted(content.items()):
            info=ZipInfo(member)
            info.compress_type=ZIP_DEFLATED
            z.writestr(info,raw)
    with TemporaryDirectory(dir=HERE/"Temp") as tmp, ZipFile(RESULT) as z:
        assert z.testzip() is None
        z.extractall(tmp)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayFixedPortable.py","--archives",str(REGRESSION)),cwd=tmp,check=True)
    print(RESULT.name,RESULT.stat().st_size,replay.digest(RESULT.read_bytes()))


if __name__=="__main__":
    main()
