"""ДЛЯ ТЕСТОВ. Проверяет знак и размер материальной координаты вдоль фактической последней пространственной секущей."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestAnalyze(root,target_override=None):
    """Вычисляет только управляющую координату, не заменяя напряжения рабочего материала."""
    here=Path(__file__).resolve().parent
    data=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](root/'Input/Reverse1.bin')
    control=json.loads((root/'Input/MaterialControl.json').read_bytes())
    if target_override is not None:control['target_MPa']=float(target_override)
    raw=(root/'Native/ExternalPoints.000001.bin').read_bytes();n,rows,cols=struct.unpack_from('<iii',raw)
    values=np.frombuffer(raw,dtype='<f8',count=rows*cols,offset=12+8*n).reshape(rows,cols)
    state=values[(values[:,0]==control['point'])&(values[:,1]==control['side'])][0]
    _,_,_,_,_,_,b,slope=run_path(str(here/'Check-TestHardHalfSteps.py'))['TestOperators'](root/'Native/EnvelopeEnergy.Operators.csv',60,43)
    operator=b[control['point']-1]+control['side']*.001*slope[control['point']-1]
    E,nu=data['calibration'][:2];lame=E*nu/((1+nu)*(1-2*nu));G=E/(2*(1+nu))
    D=np.zeros((6,6));D[:3,:3]=lame
    for i in range(3):D[i,i]+=2*G;D[i+3,i+3]=G
    def TestPhi(field):
        """Использует закреплённые пластические координаты и сцепления принятого 147-го состояния."""
        stress=D@(operator@field-state[22:28])
        tensor=np.array([[stress[0],stress[3],stress[4]],[stress[3],stress[1],stress[5]],[stress[4],stress[5],stress[2]]])
        high=np.linalg.eigvalsh(tensor)[-1];trace=sum(stress[:3]);dev=stress.copy();dev[:3]-=trace/3
        q=np.sqrt(1.5*(dev[:3]@dev[:3]+2*(dev[3:]@dev[3:])))
        alpha,gamma=state[20:22];cc,ct=state[28:30]
        term=(cc/ct*(1-alpha)-(1+alpha))*high if high>0 else gamma*high
        return float((alpha*trace+q+term)/(1-alpha)-cc)
    current,previous=data['fields'][-1],data['fields'][-2];increment=current-previous
    baseline=TestPhi(current);old=TestPhi(previous);predicted=TestPhi(current+increment)
    target=control['target_MPa'];low=0.;high=1.
    found=False
    for _ in range(11):
        if (TestPhi(current+high*increment)-target)*(baseline-target)<=0:found=True;break
        high*=2
    if found:
        for _ in range(64):
            mid=low+(high-low)/2
            if (TestPhi(current+mid*increment)-target)*(baseline-target)<=0:high=mid
            else:low=mid
        ratio=(low+high)/2
    else:ratio=None
    return dict(point=control['point'],side=control['side'],previous_phi_on_current_history_MPa=old,
        current_phi_MPa=baseline,one_forward_secant_phi_MPa=predicted,
        forward_secant_phi_change_MPa=predicted-baseline,requested_target_MPa=target,
        requested_change_from_current_MPa=target-baseline,
        target_change_exceeds_two_original_tolerances=abs(target-baseline)>2*control['original_force_tolerance_MPa'],
        positive_secant_ray_target_ratio=ratio,physical_capacity_certified=False)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    report=TestAnalyze(args.root.resolve());args.out.write_bytes((json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps(report,indent=2))
