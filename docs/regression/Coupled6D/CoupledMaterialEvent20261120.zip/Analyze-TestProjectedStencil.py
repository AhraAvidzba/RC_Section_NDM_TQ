"""ДЛЯ ТЕСТОВ. Локализует новые пересечения поверхности по фактически отображённым разностным пробам."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestAnalyze(root):
    """Пробную поверхность пересчитывает по закреплённой истории; материальные напряжения не заменяет."""
    here=Path(__file__).resolve().parent
    n,trace=run_path(str(here/'Analyze-TestExternalLine.py'))['TestRead'](root/'Native/ExternalFTrace.bin')
    raw=(root/'Native/ExternalMappedCoordinates.bin').read_bytes();stride=8+8*n
    assert len(raw)==stride*len(trace)
    mapped=[]
    for i in range(len(trace)):
        call,=struct.unpack_from('<Q',raw,i*stride);assert call==i+1
        mapped.append(np.frombuffer(raw,dtype='<f8',count=n,offset=i*stride+8).copy())
    raw=(root/'Native/ExternalPoints.000001.bin').read_bytes();size,rows,cols=struct.unpack_from('<iii',raw)
    packet=np.frombuffer(raw,dtype='<f8',count=rows*cols,offset=12+8*size).reshape(43,3,30)
    assert np.array_equal(np.frombuffer(raw,dtype='<f8',count=n,offset=12),mapped[-2*n-1])
    data=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](root/'Input/Reverse1.bin')
    E,nu=data['calibration'][:2];lame=E*nu/((1+nu)*(1-2*nu));G=E/(2*(1+nu))
    D=np.zeros((6,6));D[:3,:3]=lame
    for i in range(3):D[i,i]+=2*G;D[i+3,i+3]=G
    _,_,_,_,_,_,b,slope=run_path(str(here/'Check-TestHardHalfSteps.py'))['TestOperators'](root/'Native/EnvelopeEnergy.Operators.csv',60,43)
    raw=(root/'Input/ExternalSeed.bin').read_bytes();seed=np.frombuffer(raw,dtype='<f8',offset=4,count=n)
    result=json.loads((root/'Native/ExternalResult.json').read_bytes());scales=np.asarray(result['unknown_scales'])
    def TestPhi(coordinates):
        """Использует собственные значения NumPy вместо тригонометрического алгоритма VBA."""
        field=seed[:60]+scales[:60]*coordinates[:60]
        strain=np.asarray([b@field+s*.001*(slope@field) for s in (-1,0,1)]).transpose(1,0,2)
        stress=(strain-packet[:,:,22:28])@D.T
        tensor=np.zeros((43,3,3,3))
        for i in range(3):tensor[:,:,i,i]=stress[:,:,i]
        for k,(i,j) in enumerate(((0,1),(0,2),(1,2))):tensor[:,:,i,j]=tensor[:,:,j,i]=stress[:,:,k+3]
        high=np.linalg.eigvalsh(tensor)[:,:,-1];tr=np.sum(stress[:,:,:3],axis=-1)
        dev=stress.copy();dev[:,:,:3]-=tr[:,:,None]/3
        q=np.sqrt(1.5*(np.sum(dev[:,:,:3]**2,axis=-1)+2*np.sum(dev[:,:,3:]**2,axis=-1)))
        alpha=packet[:,:,20];gamma=packet[:,:,21];cc=packet[:,:,28];ct=packet[:,:,29]
        term=np.where(high>0,(cc/ct*(1-alpha)-(1+alpha))*high,gamma*high)
        return (alpha*tr+q+term)/(1-alpha)-cc
    base=TestPhi(mapped[-2*n-1]);error=float(np.max(abs(base-packet[:,:,17])))
    assert error<1e-10
    cases=[]
    for column in range(n):
        first=len(trace)-2*n+2*column
        plus=TestPhi(mapped[first]);minus=TestPhi(mapped[first+1])
        mask=(np.minimum(plus,minus)<-1e-10)&(np.maximum(plus,minus)>1e-10)
        asymmetry=trace[first][1]+trace[first+1][1]-2*trace[-2*n-1][1]
        for p,s in np.argwhere(mask):
            cases.append(dict(point=int(p)+1,side=int(s)-1,column=column+1,
                base_phi_MPa=float(base[p,s]),plus_phi_MPa=float(plus[p,s]),minus_phi_MPa=float(minus[p,s]),
                F_stencil_asymmetry_max_MPa=float(max(abs(asymmetry[:-1])))))
    return dict(final_native_trial_yield_reconstruction_error_MPa=error,
        candidates=sorted(cases,key=lambda row:row['F_stencil_asymmetry_max_MPa'],reverse=True),
        physical_failure=False,coordinate_mapped_for_every_original_F_call=True)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    report=TestAnalyze(args.root.resolve());args.out.write_bytes((json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps(report,indent=2))
