"""ДЛЯ ТЕСТОВ. Выявляет порядок упругопластических событий на положительной принятой пространственной секущей."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestAnalyze(root):
    """Отличает старые активные поверхности от новых пересечений; упругий прогноз не объявляется реальным путём равновесий."""
    here=Path(__file__).resolve().parent
    data=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](root/'Input/Reverse1.bin')
    raw=(root/'Native/ExternalPoints.000001.bin').read_bytes();n,rows,cols=struct.unpack_from('<iii',raw)
    state=np.frombuffer(raw,dtype='<f8',count=rows*cols,offset=12+8*n).reshape(43,3,30)
    _,_,_,_,_,_,b,slope=run_path(str(here/'Check-TestHardHalfSteps.py'))['TestOperators'](root/'Native/EnvelopeEnergy.Operators.csv',60,43)
    E,nu=data['calibration'][:2];lame=E*nu/((1+nu)*(1-2*nu));G=E/(2*(1+nu))
    D=np.zeros((6,6));D[:3,:3]=lame
    for i in range(3):D[i,i]+=2*G;D[i+3,i+3]=G
    def TestPhi(field):
        """Считает пробный критерий от одной фиксированной принятой истории для всех трёх станций."""
        strain=np.asarray([b@field+s*.001*(slope@field) for s in (-1,0,1)]).transpose(1,0,2)
        stress=(strain-state[:,:,22:28])@D.T
        tensor=np.zeros((43,3,3,3))
        for i in range(3):tensor[:,:,i,i]=stress[:,:,i]
        for k,(i,j) in enumerate(((0,1),(0,2),(1,2))):tensor[:,:,i,j]=tensor[:,:,j,i]=stress[:,:,k+3]
        high=np.linalg.eigvalsh(tensor)[:,:,-1];tr=np.sum(stress[:,:,:3],axis=-1)
        dev=stress.copy();dev[:,:,:3]-=tr[:,:,None]/3
        q=np.sqrt(1.5*(np.sum(dev[:,:,:3]**2,axis=-1)+2*np.sum(dev[:,:,3:]**2,axis=-1)))
        alpha=state[:,:,20];gamma=state[:,:,21];cc=state[:,:,28];ct=state[:,:,29]
        term=np.where(high>0,(cc/ct*(1-alpha)-(1+alpha))*high,gamma*high)
        return (alpha*tr+q+term)/(1-alpha)-cc
    current=data['fields'][-1];increment=current-data['fields'][-2]
    before=TestPhi(current);after=TestPhi(current+increment);cc=state[:,:,28]
    count=len(data['fields']);energy={}
    with (root/'Native/EnvelopeEnergy.Accepted.csv').open(encoding='cp1251') as stream:
        for row in csv.reader(stream,delimiter=';'):
            if row and row[0]=='S' and int(row[1]) in (count-1,count):
                energy[int(row[1]),int(row[3])-1,int(row[2])+1]=np.asarray(row[10:12],float)
    events=[]
    for p in range(25):
        for side in range(3):
            delta=energy[count,p,side]-energy[count-1,p,side]
            row=dict(point=p+1,side=side-1,current_phi_MPa=float(before[p,side]),
                forward_secant_phi_MPa=float(after[p,side]),
                accepted_tension_envelope_energy_ratio_change=float(delta[0]),
                accepted_compression_envelope_energy_ratio_change=float(delta[1]),
                within_current_material_yield_tolerance=bool(abs(before[p,side])<=1e-8*cc[p,side]))
            if before[p,side]<-1e-10 and after[p,side]>1e-10:
                low=0.;high=1.
                for _ in range(40):
                    mid=low+(high-low)/2
                    if TestPhi(current+mid*increment)[p,side]>0:high=mid
                    else:low=mid
                row['ray_crossing_ratio']=(low+high)/2
            if abs(before[p,side])<1e-5 or 'ray_crossing_ratio' in row:events.append(row)
    return dict(states=count,events=sorted(events,key=lambda r:r.get('ray_crossing_ratio',2.)),
        secant_is_predictor_not_new_equilibrium=True,physical_capacity_certified=False)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    report=TestAnalyze(args.root.resolve());args.out.write_bytes((json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps(report,indent=2))
