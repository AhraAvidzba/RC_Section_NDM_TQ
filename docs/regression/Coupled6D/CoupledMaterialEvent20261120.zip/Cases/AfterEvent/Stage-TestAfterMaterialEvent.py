"""ДЛЯ ТЕСТОВ. Продолжает расчёт после точного события, восстанавливая его как принятое нативное состояние."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestVector(values):
    """Пишет ограниченный вектор Double без десятичного преобразования."""
    array=np.asarray(values,dtype='<f8').ravel();assert 0<len(array)<=10000 and np.all(np.isfinite(array))
    return struct.pack('<i',len(array))+array.tobytes()


def TestStage(root,parent):
    """Добавляет только событие, прошедшее силу, неизменность поля, сталь и направление; остальные найденные корни не включаются."""
    here=Path(__file__).resolve().parent
    read=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary']
    data=read(parent/'Input/Reverse1.bin')
    result=json.loads((parent/'Native/ExternalResult.json').read_bytes())
    native=np.fromfile(parent/'Native/ExternalNativeResult.bin',dtype='<f8')
    assert np.array_equal(native[:12],result['native_verification'])
    assert tuple(native[:3])==(1.,1.,1.) and native[3]<=1 and native[4]>0
    assert abs(result['final_native_material_constraint_MPa'])<=2e-12
    control=json.loads((parent/'Input/MaterialControl.json').read_bytes());assert control['target_MPa']==0
    report,fields=run_path(str(here/'Validate-TestHardPrepared.py'))['TestValidate'](parent,'ExternalEnvelope.Sequence')
    assert len(fields)==len(data['fields'])+1 and not report['reversed_fields']
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,1e-6,0)
    previous=data['fields'][-1];accepted=native[12:]
    snapshot=b'NDMREVTEST000001'+struct.pack('<i',len(accepted))
    for name in ('calibration','options','offset','direction'):snapshot+=TestVector(data[name])
    snapshot+=struct.pack('<i',len(data['fields'])+1)
    for fraction,factor,field in zip(data['fractions'],data['lambdas'],data['fields']):
        snapshot+=struct.pack('<dd',fraction,factor)+TestVector(field)
    snapshot+=struct.pack('<dd',1.,native[4])+TestVector(accepted)
    actual=data['offset']+native[4]*data['direction'];coordinate=float(data['projection']@accepted)
    for values in (previous,accepted,accepted,actual,data['projection'],
            np.array((native[4],coordinate,native[4],0.)),np.array((native[8],native[9],native[11],1.))):
        snapshot+=TestVector(values)
    name='Input/Reverse1.bin';(root/name).write_bytes(snapshot)
    after=read(root/name)
    assert np.array_equal(after['fields'][:-1],data['fields']) and np.array_equal(after['fields'][-1],accepted)
    assert np.array_equal(after['lambdas'][:-1],data['lambdas']) and after['lambdas'][-1]==native[4]
    prediction=accepted+(accepted-previous)
    predicted_factor=native[4]+(native[4]-data['lambdas'][-1])
    contents={'Input/ExternalSeed.bin':TestVector(np.r_[prediction,predicted_factor]),
        'Input/InitialCoordinates.bin':TestVector(np.zeros(len(accepted)+1)),
        'Input/ProjectionOrigin.bin':TestVector(np.zeros(len(accepted)+1)),
        'Input/ChangedInitialCondition.json':(json.dumps(dict(kind='NaturalSecantAfterVerifiedExactMaterialEvent',
            accepted_input_states=len(after['fields']),previous_prefix_bits_equal=True,
            new_event_native_Double_exact=True,history_replay_must_accept_event_before_new_trial=True,
            external_failed_energy_field_used=False),indent=2,sort_keys=True)+'\n').encode(),
        'Run-TestExternalEnvelope.py':(here/'Run-TestExternalEnvelope.py').read_bytes(),
        Path(__file__).name:Path(__file__).read_bytes()}
    control.update(target_MPa=3*float(native[10]),numerical_increment_MPa=3*float(native[10]),
        observed_accepted_trial_yield_MPa=0.,target_is_exact_yield_event_not_strength_limit=False,
        event_state_committed_by_exact_history_replay=True)
    contents['Input/MaterialControl.json']=(json.dumps(control,indent=2,sort_keys=True)+'\n').encode()
    prep=json.loads((root/'Preparation.json').read_bytes())
    prep['inputs']['Input/Reverse1.bin']=sha256(snapshot).hexdigest().upper()
    for name,content in contents.items():
        (root/name).write_bytes(content);prep['inputs'][name]=sha256(content).hexdigest().upper()
    prep['directed_scope'].update(case='AfterVerifiedExactMaterialEvent',
        current_input_states=len(after['fields']),first_147_exact_input_prefix_preserved=True,
        accepted_event_field_native_Double_exact=True,material_history_replayed_including_event=True,
        new_material_trial_from_updated_accepted_event_history=True,
        original_material_precision_and_force_tolerance=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('VERIFIED EVENT APPENDED AS EXACT STATE',len(after['fields']),'NEW HISTORY REQUIRED')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--parent',type=Path,required=True);args=parser.parse_args()
    TestStage(args.root.resolve(),args.parent.resolve())
