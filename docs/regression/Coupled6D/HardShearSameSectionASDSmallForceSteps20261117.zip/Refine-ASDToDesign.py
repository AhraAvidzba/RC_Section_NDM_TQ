"""Проверяет шаг к расчётной нагрузке HardShear и маршрут с узлами НДМ."""

from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
from runpy import run_path
import sys
from time import perf_counter


PREVIOUS = 'E3EC4DB2505468B587D334C347F640C4130D95EF927E1E167441A15EC93F324F'
NEAR_DESIGN = (.9765625, .984375, .9921875, .99609375, 1.)
NDM_STEPS = (.25, .5, .75, 1.)


def refine(repo, prior_wire, output):
    """Повторяет принятые поля из архива и решает две новые силовые траектории."""
    import numpy as np
    import openseespy.opensees as ops

    start = perf_counter()
    assert not output.exists()
    assert ops.version() == '3.8.0' and np.__version__ == '2.3.5'
    runner = run_path(str(Path(__file__).with_name('Continue-ASDToDesign.py')))
    source, compare, prior, histories, _ = runner['inputs'](repo)
    raw = prior_wire.read_bytes()
    assert source.sha(raw) == PREVIOUS
    preceding = json.loads(gzip.decompress(raw))
    split_history = histories['split'] + preceding['arms']['split']['accepted']
    assert split_history[-1]['lambda'] == .96875 and len(split_history) == 13
    geo, dirs, area, length, _, _ = source.fixture(repo)
    operators = source.operators(geo, area, length)
    operator_sha = source.sha(source.packed(operators))
    assert operator_sha == prior['identity']['exact_built_operator_sha256'] == preceding['operator_sha256']
    solver, solver_sha = source.source_model(repo)
    assert solver_sha == prior['identity']['solver_source_sha256'] == preceding['solver_sha256']
    command, _ = source.material_command(repo)
    assert list(command) == prior['material_command']
    solver.P = 43
    load = np.array(source.RAY)
    solver.loads = lambda arrays, t, q: q * load
    make_section = compare.kernel(np, ops, solver, geo, dirs, area, length, operators, command,
                                  start + 55., source.ES)
    arms = {}
    for key, history, schedule, max_iterations in (
            ('refined', split_history, NEAR_DESIGN, 30),
            ('ndm_schedule', [], NDM_STEPS, 14)):
        solver.MAX_ITER = max_iterations
        arm = runner['continue_path'](np, ops, source, compare, solver, make_section, load, geo, dirs,
                                      area, length, operators, command, history, schedule)
        arm['max_iterations'] = max_iterations
        arms[key] = arm
    ops.wipe()
    report = {'operator_sha256': operator_sha, 'previous_wire_sha256': PREVIOUS,
              'solver_sha256': solver_sha, 'material_command_sha256': source.sha(source.packed(command)),
              'runtime': ops.version(), 'numpy': np.__version__, 'arms': arms,
              'physical_limit_established': False}
    packed = gzip.compress(source.packed(report), compresslevel=9, mtime=0)
    with output.open('xb') as sink:
        sink.write(packed)
    print('HARDSHEAR ASD DESIGN REFINEMENT WIRE', source.sha(packed), f'{perf_counter()-start:.3f}s',
          [(key, [s['lambda'] for s in arm['accepted']], arm['first_failure']) for key, arm in arms.items()])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--prior', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    arguments = parser.parse_args()
    sys.dont_write_bytecode = True
    refine(arguments.repo.resolve(), arguments.prior.resolve(), arguments.out.resolve())
