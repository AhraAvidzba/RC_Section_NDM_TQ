"""Продолжает два проверенных маршрута ASD к расчётному сочетанию HardShear."""

from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys
from time import perf_counter
from types import ModuleType
from zipfile import ZipFile


SPLIT_ARCHIVE = ('HardShearSameSectionASDStepSplit20261117.zip',
                 '11365D5BA1F390ACD3F92445DB4B98FCBB4EFB940506940637406DF6294076BB')
FOLLOW_ARCHIVE = ('HardShearSameSectionASDCoarseFollow20261117.zip',
                  'F89FFBD0F47E05CBAC62CDF07F3318BC4AFB4DEDB86366FFEA9E70B93FCFFA50')
SCHEDULES = {'single': (.9375, 1.), 'split': (.90625, .9375, .96875, 1.)}


def pinned_module(repo, archive, member):
    """Получает исполняемый исходник только из проверенного архива проекта."""
    from hashlib import sha256

    name, digest = archive
    path = repo / 'docs/regression/Coupled6D' / name
    assert sha256(path.read_bytes()).hexdigest().upper() == digest
    with ZipFile(path) as bundle:
        source = bundle.read(member)
    module = ModuleType(Path(member).stem)
    module.__file__ = str(Path(__file__).with_name(member))
    exec(compile(source, module.__file__, 'exec'), module.__dict__)
    return module


def inputs(repo):
    """Восстанавливает общую историю до 0,75 и разные принятые переходы до 0,875."""
    source = pinned_module(repo, FOLLOW_ARCHIVE, 'HardShearSameSection.py')
    compare = pinned_module(repo, SPLIT_ARCHIVE, 'Compare-ASDStepSplit.py')
    common, prior, _ = compare.old_input(repo, vars(source))
    with source.archived(repo, SPLIT_ARCHIVE) as bundle:
        wire = bundle.read('ASDStepSplitWire.json.gz')
    data = json.loads(gzip.decompress(wire))
    histories = {key: common + data['arms'][key]['qualified_steps'] for key in SCHEDULES}
    assert all(history[-1]['lambda'] == .875 for history in histories.values())
    assert [len(history) for history in histories.values()] == [9, 10]
    return source, compare, prior, histories, source.sha(wire)


def continue_path(np, ops, source, compare, solver, make_section, load, geo, dirs,
                  area, length, operators, command, history, schedule):
    """Решает заданные множители и проверяет воспроизводимость принятых состояний."""
    section = make_section()
    field = compare.replay(np, section, history, load) if history else np.zeros(60)
    initial = section.eval_count
    accepted = []
    failure = None
    for factor in schedule:
        selected, step = solver.try_correct(section, field, float(load[3]), factor)
        if selected is None:
            failure = {'lambda': factor, 'numerical': step}
            break
        field = selected
        stress = section.accepted_stresses[-1]
        steel = section.steel_stress.tolist()
        check = source.verify_rows(geo, dirs, area, length, operators, field.tolist(), stress, factor, steel)
        assert abs(check['combined_norm_MPa'] - step['all_weak_and_force_max_MPa']) < 3e-12
        frame = {'lambda': factor, 'field': field.tolist(), 'net_stress_MPa': stress,
                 'steel_stress_MPa': steel, 'independent': check, 'iterations': step['newton_iterations']}
        frame.update(compare.material_readback(np, ops, vars(source), section, command, field, factor,
                                               load, stress, steel, geo, dirs, area, length, operators))
        accepted.append(frame)
    calls = section.eval_count - initial
    assert section.committed == len(history) + len(accepted)
    cold = make_section()
    compare.replay(np, cold, history + accepted, load, excursions=True)
    return {'schedule': schedule, 'prefix_count': len(history), 'accepted': accepted, 'first_failure': failure,
            'evaluations_after_prefix': calls, 'exact_cold_steps_with_discarded_trials': cold.committed}


def main(repo, output):
    """Сохраняет полные поля принятых шагов и отдельно отброшенных проб материала."""
    import numpy as np
    import openseespy.opensees as ops

    start = perf_counter()
    assert not output.exists()
    assert ops.version() == '3.8.0' and np.__version__ == '2.3.5'
    source, compare, prior, histories, input_wire = inputs(repo)
    geo, dirs, area, length, _, _ = source.fixture(repo)
    operators = source.operators(geo, area, length)
    operator_sha = source.sha(source.packed(operators))
    assert operator_sha == prior['identity']['exact_built_operator_sha256']
    solver, solver_sha = source.source_model(repo)
    assert solver_sha == prior['identity']['solver_source_sha256']
    command, _ = source.material_command(repo)
    assert list(command) == prior['material_command']
    solver.P = 43
    load = np.array(source.RAY)
    solver.loads = lambda arrays, t, q: q * load
    make_section = compare.kernel(np, ops, solver, geo, dirs, area, length, operators, command,
                                  start + 55., source.ES)
    arms = {key: continue_path(np, ops, source, compare, solver, make_section, load, geo, dirs, area,
                               length, operators, command, histories[key], schedule)
            for key, schedule in SCHEDULES.items()}
    ops.wipe()
    report = {'operator_sha256': operator_sha, 'input_wire_sha256': input_wire,
              'solver_sha256': solver_sha, 'material_command_sha256': source.sha(source.packed(command)),
              'runtime': ops.version(), 'numpy': np.__version__, 'arms': arms,
              'physical_limit_established': False}
    raw = gzip.compress(source.packed(report), compresslevel=9, mtime=0)
    with output.open('xb') as sink:
        sink.write(raw)
    print('HARDSHEAR ASD DESIGN WIRE', source.sha(raw), f'{perf_counter()-start:.3f}s',
          [(key, [s['lambda'] for s in arm['accepted']], arm['first_failure']) for key, arm in arms.items()])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--out', required=True, type=Path)
    arguments = parser.parse_args()
    sys.dont_write_bytecode = True
    main(arguments.repo.resolve(), arguments.out.resolve())
