"""Сверяет контрольные усилия и деление шагов HardShear по сохранённым тензорам."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from runpy import run_path
import gzip
import json


HERE = Path(__file__).resolve().parent
WIRE_SHA = '5B61217ED8545E7DC25807E5BF88D5466C2C644CC6D5B1CA5C6F47C327F5DAA5'
DESIGN_ARCHIVE_SHA = '3197E52A738FC93C69488146D0C5A5DCCD84094366D7733717E2471645E2D5B0'


def verify_arm(arm, history, limits, source, geometry):
    """Проверяет принятие и отклонение каждого силового приращения."""
    width, minimum, attempts_limit, max_iterations = limits
    geo, dirs, area, length, operators = geometry
    factor = history[-1]['lambda']
    anchor = factor
    accepted_fields = iter(arm['accepted'])
    checkpoints = []
    all_attempts = arm['attempts']
    assert arm['prefix_count'] == len(history)
    assert arm['cold_replay_count'] == len(history) + len(arm['accepted'])
    assert 0 < len(all_attempts) <= attempts_limit
    for attempt in all_attempts:
        assert attempt['from_lambda'] == factor and attempt['target_lambda'] == min(1., factor + width)
        assert 0 <= attempt['iterations'] <= max_iterations and width >= minimum
        if not attempt['accepted']:
            assert attempt['status'] == 'line_search_no_decrease' and attempt['residual_MPa'] > 2e-4
            width /= 2
            continue
        frame = next(accepted_fields)
        factor = attempt['target_lambda']
        assert factor == frame['lambda'] and attempt['status'] == 'balanced'
        field, steel = frame['field'], frame['steel_stress_MPa']
        integrated = source.verify_rows(geo, dirs, area, length, operators, field, frame['net_stress_MPa'],
                                        factor, steel)
        assert integrated == frame['independent']
        assert abs(integrated['combined_norm_MPa'] - attempt['residual_MPa']) < 3e-12
        assert frame['immediate_committed_stress_identical']
        discarded = frame['zero_increment_trial']
        repeat = source.verify_rows(geo, dirs, area, length, operators, field, discarded['net_stress_MPa'],
                                    factor, steel, False)
        assert repeat == discarded['independent'] and not discarded['committed']
        state = frame['concrete_measures']
        responses = state['raw_indicators']
        assert len(responses) == 75 and all(len(row) == 6 for row in responses)
        peaks = state['table_peak_T_C_ordinates']
        above = [sum(row[index] > peak for row in responses) for index, peak in enumerate(peaks)]
        assert above == state['number_above_tension_compression_table_peak']
        assert above[1] == 0 and all(row[5] == 0 for row in responses)
        checkpoints.append({'lambda': factor, 'norm_MPa': integrated['combined_norm_MPa'],
                            'tolerance_MPa': integrated['original_tolerance_MPa'],
                            'twist_rad_per_m': 1000. * field[3] / length,
                            'signed_six': integrated['signed_six'],
                            'stations_beyond_tension_compression_peak': above,
                            'zero_increment_norm_MPa': repeat['combined_norm_MPa']})
    assert list(accepted_fields) == []
    assert not arm['design_solved'] and factor < 1. and width < minimum
    return {'anchor_lambda': anchor, 'attempts': len(all_attempts), 'cold_count': arm['cold_replay_count'],
            'accepted': checkpoints, 'last_trial': all_attempts[-1]}


def verify(repo):
    """Восстанавливает две истории и сравнивает поля при равном множителе."""
    archive = repo / 'docs/regression/Coupled6D/HardShearSameSectionASDDesignPaths20261117.zip'
    assert sha256(archive.read_bytes()).hexdigest().upper() == DESIGN_ARCHIVE_SHA
    runner = run_path(str(HERE / 'Refine-ASDForceSteps.py'))
    source, _, reference, histories, geometry = runner['base_inputs'](repo)
    raw = (HERE / 'ASDSmallForceStepsWire.json.gz').read_bytes()
    assert source.sha(raw) == WIRE_SHA
    data = json.loads(gzip.decompress(raw))
    identity = reference['identity']
    assert data['solver_sha256'] == identity['solver_source_sha256']
    assert data['operator_sha256'] == identity['exact_built_operator_sha256']
    assert data['material_command_sha256'] == source.sha(source.packed(reference['material_command']))
    assert data['opensees'] == '3.8.0' and data['numpy'] == '2.3.5' and not data['physical_limit_established']
    assert data['controls'] == [1/256, 1/65536, 20, 30]
    recorded = {name: verify_arm(arm, histories[name], data['controls'], source, geometry)
                for name, arm in data['arms'].items()}
    assert [f['lambda'] for f in recorded['after']['accepted']] == [.9775390625]
    assert [f['lambda'] for f in recorded['before']['accepted']] == [.97265625, .9765625, .9765777587890625]
    assert [recorded[name]['attempts'] for name in ('after', 'before')] == [10, 12]
    old = histories['after'][-1]
    split = data['arms']['before']['accepted'][1]
    assert old['lambda'] == split['lambda'] == .9765625
    difference = max(abs(a - b) for s, t in zip(old['net_stress_MPa'], split['net_stress_MPa'], strict=True)
                     for u, v in zip(s, t, strict=True) for a, b in zip(u, v, strict=True))
    twist = 1000. * (split['field'][3] - old['field'][3]) / geometry[3]
    assert 1.22 < difference < 1.23 and twist > 0.
    return {'wire_sha256': WIRE_SHA, 'arms': recorded,
            'same_lambda': old['lambda'], 'max_abs_net_stress_delta_MPa': difference,
            'twist_delta_rad_per_m': twist, 'physical_limit_established': False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    result = verify(args.repo.resolve())
    with args.report.open('xb') as output:
        output.write((json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n').encode())
    print('HARDSHEAR ASD SMALL FORCE STEPS OFFLINE PASS', WIRE_SHA)
