"""Делит силовые шаги HardShear вокруг последнего принятого поля OpenSees."""

from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
from runpy import run_path
from time import perf_counter


HERE = Path(__file__).resolve().parent
REFINEMENT_SHA = '5D844C9E76D7456E39C12F7B2ED3645A7F1F50727A6C841ADDB4DDD44D212E61'
WIDTH = 1 / 256
MINIMUM = 1 / 65536
MAX_ATTEMPTS = 20
MAX_ITERATIONS = 30


def base_inputs(repo):
    """Читает два подтверждённых префикса и их точный оператор."""
    runner = run_path(str(HERE / 'Continue-ASDToDesign.py'))
    reference = run_path(str(HERE / 'Refine-ASDToDesign.py'))
    source, compare, prior, histories, _ = runner['inputs'](repo)
    payloads = []
    for name, sha in (('ASDToDesignWire.json.gz', reference['PREVIOUS']),
                      ('ASDRefineToDesignWire.json.gz', REFINEMENT_SHA)):
        raw = (HERE / name).read_bytes()
        assert source.sha(raw) == sha
        payloads.append(json.loads(gzip.decompress(raw)))
    design, refined = payloads
    prefix = histories['split'] + design['arms']['split']['accepted']
    complete = prefix + refined['arms']['refined']['accepted']
    assert len(prefix) == 13 and prefix[-1]['lambda'] == .96875
    assert len(complete) == 14 and complete[-1]['lambda'] == .9765625
    geo, dirs, area, length, _, _ = source.fixture(repo)
    operators = source.operators(geo, area, length)
    operator_sha = source.sha(source.packed(operators))
    assert operator_sha == prior['identity']['exact_built_operator_sha256'] == refined['operator_sha256']
    return source, compare, prior, {'after': complete, 'before': prefix}, (geo, dirs, area, length, operators)


def advance(np, ops, source, compare, solver, section, load, geometry, command, history):
    """Повторяет префикс и делит только отклонённые приращения множителя."""
    geo, dirs, area, length, operators = geometry
    field = compare.replay(np, section, history, load)
    initial_count = section.eval_count
    factor = history[-1]['lambda']
    width = WIDTH
    accepted, attempts = [], []
    for _ in range(MAX_ATTEMPTS):
        target = min(1., factor + width)
        committed = section.committed
        selected, solve = solver.try_correct(section, field, float(load[3]), target)
        attempts.append({'from_lambda': factor, 'target_lambda': target,
                         'status': solve.get('status', solve.get('kind')), 'accepted': selected is not None,
                         'residual_MPa': solve.get('weak_or_forces_norm_MPa',
                                                   solve.get('all_weak_and_force_max_MPa')),
                         'iterations': solve.get('newton_iterations')})
        # При отказе новый шаг стартует от того же поля и принятой истории.
        if selected is None:
            assert section.committed == committed
            width /= 2
            if width < MINIMUM:
                break
            continue
        assert section.committed == committed + 1
        field, factor = selected, target
        stress = section.accepted_stresses[-1]
        steel = section.steel_stress.tolist()
        independent = source.verify_rows(geo, dirs, area, length, operators, field.tolist(), stress, factor, steel)
        assert abs(independent['combined_norm_MPa'] - solve['all_weak_and_force_max_MPa']) < 3e-12
        frame = {'lambda': factor, 'field': field.tolist(), 'net_stress_MPa': stress,
                 'steel_stress_MPa': steel, 'independent': independent}
        frame.update(compare.material_readback(np, ops, vars(source), section, command, field, factor,
                                               load, stress, steel, geo, dirs, area, length, operators))
        accepted.append(frame)
        if factor == 1.:
            break
    return {'prefix_count': len(history), 'evaluations_after_prefix': section.eval_count - initial_count,
            'accepted': accepted, 'attempts': attempts, 'design_solved': factor == 1.}


def main(repo, output):
    """Сохраняет точные тензоры, статусы проб и идентичность холодного повтора."""
    import numpy as np
    import openseespy.opensees as ops

    started = perf_counter()
    assert not output.exists() and ops.version() == '3.8.0' and np.__version__ == '2.3.5'
    source, compare, prior, histories, geometry = base_inputs(repo)
    solver, solver_sha = source.source_model(repo)
    assert prior['identity']['solver_source_sha256'] == solver_sha
    command, _ = source.material_command(repo)
    assert list(command) == prior['material_command']
    solver.P = 43
    solver.MAX_ITER = MAX_ITERATIONS
    load = np.array(source.RAY)
    solver.loads = lambda arrays, t, q: q * load
    make_section = compare.kernel(np, ops, solver, *geometry, command, started + 100., source.ES)
    arms = {}
    for name, history in histories.items():
        arm = advance(np, ops, source, compare, solver, make_section(), load, geometry, command, history)
        cold = make_section()
        compare.replay(np, cold, history + arm['accepted'], load, excursions=True)
        arm['cold_replay_count'] = cold.committed
        arms[name] = arm
        print(name, 'accepted', [x['lambda'] for x in arm['accepted']],
              'last probe', arm['attempts'][-1], flush=True)
    ops.wipe()
    report = {'operator_sha256': prior['identity']['exact_built_operator_sha256'], 'solver_sha256': solver_sha,
              'material_command_sha256': source.sha(source.packed(command)), 'numpy': np.__version__,
              'opensees': ops.version(), 'controls': [WIDTH, MINIMUM, MAX_ATTEMPTS, MAX_ITERATIONS],
              'prior_refinement_sha256': REFINEMENT_SHA, 'arms': arms, 'physical_limit_established': False}
    wire = gzip.compress(source.packed(report), compresslevel=9, mtime=0)
    with output.open('xb') as sink:
        sink.write(wire)
    print('HARDSHEAR ASD SMALL FORCE STEPS WIRE', source.sha(wire), f'{perf_counter() - started:.3f}s')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    main(args.repo.resolve(), args.out.resolve())
