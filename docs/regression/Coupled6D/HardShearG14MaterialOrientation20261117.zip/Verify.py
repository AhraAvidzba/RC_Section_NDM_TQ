"""Воспроизводит направление четырёх материальных равновесий G14 в метрике деформаций."""

from hashlib import sha256
import json
from math import fsum, isclose, pi, sqrt
from pathlib import Path
from statistics import median
from struct import unpack


HERE = Path(__file__).resolve().parent
MATERIAL_ARCHIVE = 'D9AA3D7A7A01DA49F7FE23C7EF7D3304BF8C407510DD978FA4449D8E7C5B8A8F'
ANCHOR_ARCHIVE = 'E6E987A86DE0191A649B123F3F1B629CD5821C24E71AF946FC1B010CFB25F131'
MATERIAL_REPORT = 'A98C9A39B68D603FA51A82F0A91942C1791C0A927767E06A3FE4936B374098D0'
ANCHOR_REPORT = '48E5B874F9BDC62B87EC9AC3240C295674FE23C6C81D7F9E45FA36F9E1D7838D'
RAY = (28000., 510000., 180000., 1500000., 17000., -7100.)


def digest(path):
    return sha256((HERE / path).read_bytes()).hexdigest().upper()


def read(path):
    return json.loads((HERE / path).read_text(encoding='utf-8-sig'))


def doubles(tokens):
    return [unpack('>d', bytes.fromhex(bit_string))[0] for bit_string in tokens]


def difference(a, b):
    return [x-y for x,y in zip(a,b,strict=True)]


def raw_material():
    path = HERE / 'Input/Material/HardG14Direction.csv'
    rows = path.read_text(encoding='cp1251').splitlines()
    data, events, concrete = {}, [], []
    active = None
    for line in rows:
        kind, *items = line.split(';')
        if kind in ('MESH', 'OFFSET', 'DIRECTION', 'PROJECTION'):
            assert kind not in data
            data[kind] = items
        elif kind == 'QUAD':
            assert int(items[0]) == len(concrete)+1
            concrete.append(doubles(items[1:]))
        elif kind == 'EVENT':
            assert active is None and items[3] == 'True'
            active = {'target':doubles(items[:1])[0]}
        elif kind == 'EVENT-ROLLBACK':
            assert active is not None and items == ['9744']
            events.append(active)
            active = None
        elif kind in ('EVENT-BALANCE','EVENT-FIELD','EVENT-RESIDUAL','EVENT-LOAD','EVENT-WRENCH'):
            assert active is not None and kind not in active
            if kind == 'EVENT-BALANCE':
                assert items[-1] == 'True'
                items = items[:-1]
            active[kind] = doubles(items)
    assert active is None and len(concrete) == 100 and len(events) == 4
    return data, concrete, events


def material_points(concrete):
    """Две продольные точки и 16 точек Гаусса оси прямоугольного хомута."""
    points = [tuple(v) for v in concrete]
    for sign in (-1, 1):
        points.append((0., 30.*sign, 36.*pi))
    nodes = (-.861136311594053,-.339981043584856,.339981043584856,.861136311594053)
    weights = (.347854845137454,.652145154862546,.652145154862546,.347854845137454)
    # Защитный слой 10 мм до поверхности стержня d=8 мм. Шаг хомута 100 мм.
    for node,weight in zip(nodes,weights,strict=True):
        for sign in (-1,1):
            points.append((76.*node,46.*sign,16.*pi*76.*weight/100.))
            points.append((76.*sign,46.*node,16.*pi*46.*weight/100.))
    assert len(points) == 118
    return points


def cubic(t):
    """Значения и производные базиса Бернштейна одного кубического пролёта."""
    v = 1.-t
    return (v**3,3.*t*v**2,3.*t*t*v,t**3),(-3.*v*v,3.*v*v-6.*t*v,6.*t*v-3.*t*t,3.*t*t)


def strains(field, x, y, length):
    """Эквивалент PointStrain и AxialGradientAtPoint в трёх выбранных станциях."""
    bx, dx = cubic((x+90.)/180.)
    by, dy = cubic((y+60.)/120.)
    nx,ny = x/length,y/length
    center = [0.,0.,field[0]+ny*field[1]+nx*field[2],0.,-ny*field[3],nx*field[3]]
    for basis in range(16):
        i,j = basis%4,basis//4
        gx = dx[i]*by[j]*length/180.
        gy = bx[i]*dy[j]*length/120.
        u,v,w = field[4+3*basis:7+3*basis]
        center[0] += gx*u
        center[1] += gy*v
        center[3] += gy*u+gx*v
        center[4] += gx*w
        center[5] += gy*w
    gradient = (0.,0.,field[52]+ny*field[53]+nx*field[54],0.,-ny*field[55],nx*field[55])
    return [[e+s*.001*g for e,g in zip(center,gradient,strict=True)] for s in (-1,0,1)]


def inner(f, g, points, length):
    """Скалярное произведение тензоров с весом 1/2 инженерных сдвигов."""
    products = []
    for x,y,area in points:
        a,b = strains(f,x,y,length),strains(g,x,y,length)
        for first,second in zip(a,b,strict=True):
            products.append(area*fsum(v*w*(1. if i<3 else .5) for i,(v,w) in enumerate(zip(first,second,strict=True))))
    return fsum(products)/(3.*fsum(a for _,_,a in points))


def balance(event, projection, length, area, modulus):
    factor,norm,tolerance,actual_event,old_coordinate,*_ = event['EVENT-BALANCE']
    field = event['EVENT-FIELD']
    assert len(field)==60
    assert isclose(fsum(a*b for a,b in zip(field,projection,strict=True)),old_coordinate,abs_tol=5e-18)
    assert abs(actual_event-event['target']) < 4e-14
    requested,verified = event['EVENT-LOAD'],event['EVENT-WRENCH']
    units=(area,area*length,area*length,area*length,area,area)
    assert all(isclose(a,factor*b,rel_tol=3e-15) for a,b in zip(requested,RAY,strict=True))
    six=max(abs(a-b)/s for a,b,s in zip(requested,verified,units,strict=True))
    residual=event['EVENT-RESIDUAL']
    assert len(residual)==60
    assert max(map(abs,residual[56:])) <= tolerance/modulus
    assert isclose(norm,max(six,max(map(abs,residual[:56]))),rel_tol=3e-11,abs_tol=1e-15)
    assert norm<=tolerance
    return factor


def orientation(archive, points, length, event, lam, lambda_radius):
    recent=[(row['label'],doubles(row['FIELD']),doubles(row['BALANCE'][:1])[0]) for row in archive[-4:]]
    assert recent[-2][0]=='G12' and recent[-1][0]=='G13'
    prior_steps=[(difference(b[1],a[1]),b[2]-a[2]) for a,b in zip(recent[:-1],recent[1:],strict=True)]
    metrics=[sqrt(inner(step,step,points,length))/delta_lam for step,delta_lam in prior_steps]
    gamma=median(metrics)
    secant,load_step=prior_steps[-1]
    e2=inner(secant,secant,points,length)
    movement=difference(event['EVENT-FIELD'],recent[-1][1]); delta_lambda=lam-recent[-1][2]
    dot=inner(secant,movement,points,length)
    s=dot/e2
    relative_distance=sqrt(inner(movement,movement,points,length)/e2)
    perpendicular=sqrt(relative_distance**2-s**2)
    load_weight=gamma**2
    combined_norm=e2+load_weight*load_step**2
    sensitivity=load_weight*load_step/combined_norm
    return {'strain_secant_norm':sqrt(e2),'projection_in_previous_step':s,'distance_in_previous_step':relative_distance,
            'cosine':s/relative_distance,'orthogonal_in_previous_step':perpendicular,'strain_per_lambda_median':gamma,
            'nominal_augmented_projection':(dot+load_weight*load_step*delta_lambda)/combined_norm,
            'augmented_projection_radius_from_G13_alone':sensitivity*lambda_radius,
            'nominal_signed_lambda_change':delta_lambda,'lambda_radius_from_G13_alone':lambda_radius,
            'signed_lambda_change_certified':False}


def main():
    hashes=read('SHA256SUMS.json')
    actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}
    assert actual==set(hashes)|{'SHA256SUMS.json'}
    for path,expected in hashes.items():
        assert not path.endswith('.xlsm') and digest(path)==expected, path
    manifest=read('InputManifest.json')
    assert manifest['material_archive_sha256']==MATERIAL_ARCHIVE and manifest['anchor_archive_sha256']==ANCHOR_ARCHIVE
    assert digest('Input/Material/Verification.json')==MATERIAL_REPORT and digest('Input/Anchor/Verification.json')==ANCHOR_REPORT
    proof=read('Input/Material/Verification.json'); anchor=read('Input/Anchor/Verification.json')['max_confirmed']
    assert digest('Input/Material/HardG14Direction.csv')==proof['native_trace_sha256']
    assert anchor['label']=='G13' and proof['new_equilibrium_probes']==4
    old=read('Input/Material/Expected.json')['fields']
    assert old[-1]['label']=='G13' and doubles(old[-1]['BALANCE'][:1])[0]==anchor['factor']
    meta,concrete,events=raw_material()
    assert [int(x) for x in meta['MESH'][:3]]==[10,100,118]
    area,length,modulus=doubles(meta['MESH'][3:])
    assert area==21600. and fsum(r[2] for r in concrete)==area
    assert tuple(doubles(meta['DIRECTION']))==RAY and doubles(meta['OFFSET'])==[0.]*6
    projection=doubles(meta['PROJECTION']); all_points=material_points(concrete)
    results=[]
    for event,declared in zip(events,proof['events'],strict=True):
        lam=balance(event,projection,length,area,modulus)
        assert lam==declared['lambda'] and declared['norm_MPa']==event['EVENT-BALANCE'][1]
        full=orientation(old,all_points,length,event,lam,anchor['uncertainty'])
        concrete_only=orientation(old,concrete,length,event,lam,anchor['uncertainty'])
        assert full['projection_in_previous_step']<-.49 and concrete_only['projection_in_previous_step']<-.49
        assert abs(full['nominal_signed_lambda_change'])<anchor['uncertainty']
        results.append({'material_coordinate_MPa':event['target'],'concrete_only':concrete_only,'all_118_points':full})
    print(json.dumps({'recorded_material_event_count':4,'events':results,'physical_limit_certified':False},indent=2,ensure_ascii=False))
    print('HARDSHEAR_G14_EVENT_ORIENTATION: VERIFIED_EVIDENCE; backward_strain_projection=True; signed_lambda_unresolved=True')


if __name__=='__main__':
    main()
