"""Готовит компактный воспроизводимый архив независимой ориентации G14."""

from hashlib import sha256
import json
from pathlib import Path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
REGRESSION=REPO/'docs/regression/Coupled6D'
MATERIAL='HardShearG14MaterialCoordinateNative20261117.zip'
ANCHOR='HardShearF19ContinuationNative20261117.zip'
MATERIAL_SHA='D9AA3D7A7A01DA49F7FE23C7EF7D3304BF8C407510DD978FA4449D8E7C5B8A8F'
ANCHOR_SHA='E6E987A86DE0191A649B123F3F1B629CD5821C24E71AF946FC1B010CFB25F131'
REVISION='709e7dfa16c192748fc2c6d999925bdbf9948a4c'
NAME='HardShearG14MaterialOrientation20261117'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def inputs():
    assert sha((REGRESSION/MATERIAL).read_bytes())==MATERIAL_SHA
    assert sha((REGRESSION/ANCHOR).read_bytes())==ANCHOR_SHA
    materials={'HardG14Direction.csv':'Native/Order10/HardG14Direction.csv','Verification.json':'Native/Order10/Verification.json',
               'Expected.json':'Expected.json','Fixture.json':'Fixture.json'}
    with ZipFile(REGRESSION/MATERIAL) as arc:
        data={'Input/Material/'+name:arc.read(path) for name,path in materials.items()}
        for name in ('src/Solver/CCoupledNewtonSolver.cls','tests/modTestCoupledElasticState.bas'):
            data['Operators/'+name]=arc.read('Production/'+name)
    with ZipFile(REGRESSION/ANCHOR) as arc:
        data['Input/Anchor/Verification.json']=arc.read('Native/Order10/Verification.json')
    operators=('src/Solver/CCoupledElasticState.cls','src/Solver/CCoupledSectionQuadrature.cls',
               'src/Solver/CTransverseRebarQuadrature.cls','src/Section/CTransverseRebarLayout.cls')
    for file in operators:
        data['Operators/'+file]=run(['git','show',f'{REVISION}:{file}'],cwd=REPO,stdout=PIPE,check=True).stdout
    for name in ('Verify.py','Pack.py','README.md'):
        data[name]=(HERE/name).read_bytes()
    plan={'material_source_archive':'docs/regression/Coupled6D/'+MATERIAL,'material_archive_sha256':MATERIAL_SHA,
          'anchor_source_archive':'docs/regression/Coupled6D/'+ANCHOR,'anchor_archive_sha256':ANCHOR_SHA,
          'source_revision_for_operator_classes':REVISION,'material_members':materials,'anchor_member':'Native/Order10/Verification.json'}
    data['InputManifest.json']=(json.dumps(plan,indent=2)+'\n').encode('utf-8')
    data['SHA256SUMS.json']=(json.dumps({name:sha(raw) for name,raw in data.items()},sort_keys=True,indent=2)+'\n').encode('utf-8')
    return data


def seal(path,raw):
    if path.exists():
        assert path.read_bytes()==raw,path
    else:
        path.write_bytes(raw)


def main():
    folder=HERE/'proof'; folder.mkdir(exist_ok=True)
    data=inputs()
    with TemporaryDirectory(prefix='replay-',dir=folder) as directory:
        detached=Path(directory)
        temp=detached/'candidate.zip'
        with ZipFile(temp,'w',compression=ZIP_DEFLATED,compresslevel=9) as archive:
            for name,raw in sorted(data.items()):
                entry=ZipInfo(name,date_time=(2026,11,17,0,0,0));entry.create_system=3
                entry.external_attr=0o100644<<16
                archive.writestr(entry,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
        extract=detached/'unpacked'
        with ZipFile(temp) as archive:
            archive.extractall(extract)
        replay=run([sys.executable,'-B','-X','utf8','Verify.py'],cwd=extract,stdout=PIPE,check=True).stdout
        digest=sha(temp.read_bytes())
        seal(folder/(NAME+'.zip'),temp.read_bytes())
        seal(folder/(NAME+'.zip.sha256'),f'{digest} *{NAME}.zip\n'.encode('ascii'))
        seal(folder/(NAME+'.replay.txt'),replay)
    print(folder/(NAME+'.zip'),digest)
    print(replay.decode('utf-8').splitlines()[-1])


if __name__=='__main__':
    main()
