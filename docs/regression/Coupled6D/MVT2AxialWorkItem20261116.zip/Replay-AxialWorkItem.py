"""Replay the frozen compensated axial measurement triplet for MVT2 B."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import argparse
import csv
import json
import math

import numpy as np

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.

def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def trace_tables(data):
    tables = defaultdict(list)
    for marker, *row in csv.reader(data.decode("cp1251").splitlines(), delimiter=";"):
        tables[marker].append(row)
    return tables


def verified_states(tags):
    fields, stations = {}, defaultdict(dict)
    for name, history, q, *x in tags["B_TANGENT_FIELD"]:
        assert name not in fields and len(x) == 60
        fields[name] = (int(history), float(q), tuple(map(float, x)))
    for name, point, side, *row in tags["B_TANGENT_STATION"]:
        key = int(point), int(side)
        assert key not in stations[name] and len(row) == 19
        stations[name][key] = tuple(map(float, row))
    raw_r = vec(tags, "B_TANGENT_RESIDUAL")
    raw_force = {name: tuple(map(float, row)) for name, *row in tags["B_BOUND_ACTUAL"]}
    raw_norm = {name: float(value) for name, value in tags["B_BOUND_NORM"]}
    output = {}
    assert set(fields) == set(stations) == set(raw_r) == set(raw_force) == set(raw_norm)
    for name, (history, q, x) in fields.items():
        assert history == 24 and len(stations[name]) == 135
        rows, actual, strain_error = reconstruct(x, q, stations[name])
        error = peak(diff(rows, raw_r[name]))
        assert strain_error < 4e-15 and error < 3e-10
        assert max(abs(a-b)/s for a,b,s in zip(actual, raw_force[name], SCALES, strict=True)) < 4e-12
        signed = diff(actual, force(q))
        efforts = tuple(r/s for r, s in zip(signed, SCALES, strict=True))
        residual = (*rows[:56], *efforts)
        gauge_norm = MODULUS*peak(rows[56:])
        tol = 5e-7*(1.+peak(loading(q)))
        near(max(peak(residual), gauge_norm),raw_norm[name], 4e-10)
        assert gauge_norm <= tol
        output[name] = {"q": q, "field": x, "r": residual, "gauge_MPa": gauge_norm, "tol_MPa": tol,
            "signed_force_N_Nmm": signed, "norm_MPa": peak(residual), "reconstruction_error_MPa": error,
            "geometry": {key: row[:3] for key, row in stations[name].items()}}
    return output, stations


def tensor_radius(field, geometry):
    maximum = 0.
    for (_, side), (x, y, _) in geometry.items():
        strain = strain_at(field, operators(x, y), side)
        maximum = max(maximum, peak(s/(1. if i < 3 else math.sqrt(2.)) for i, s in enumerate(strain)))
    return maximum


NATIVE_ARCHIVE = "MVT2MeasuredNative20261116.zip"
GRADIENT_ARCHIVE = "MVT2GradientCorrection20261116.zip"
NATIVE_HASH = "0D19814EB74BA458E56B40BF7E5D2E58CE057FDC724CB79A610DC6D56A77BA5E"
GRADIENT_HASH = "FA407B0A7625E2CC09C240470D205A5C70CE86BDC67AE04443C3B5306B323CA9"


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def load_matrix_rows(rows):
    matrices = {}
    for name in ("Stock", "Consistent"):
        output = {int(row): vals for label, row, *vals in rows if label == name}
        assert set(output) == set(range(1, 61)) and all(len(vals) == 60 for vals in output.values())
        matrices[name] = np.array([output[row] for row in range(1, 61)], float)
    return matrices


def tensor(field, geometry):
    return np.array([value/(1. if k<3 else math.sqrt(2.))
        for (_,side),(x,y,_) in geometry.items()
        for k,value in enumerate(strain_at(field,operators(x,y),side))])


def replay(evidence, output):
    native_path = evidence / NATIVE_ARCHIVE
    gradient_path = evidence / GRADIENT_ARCHIVE
    assert digest(native_path) == NATIVE_HASH
    assert digest(gradient_path) == GRADIENT_HASH
    with ZipFile(native_path) as native_zip:
        native, _ = verified_states(trace_tables(native_zip.read("Native/MVT2.csv")))
    with ZipFile(gradient_path) as gradient_zip:
        matrix_rows = trace_tables(gradient_zip.read("NativeA/MVT2.csv"))["B_FRESH_MATRIX"]
        comparison = trace_tables(gradient_zip.read("NativeB/MVT2.csv"))["B_TANGENT_FIELD"]
    centre = native["MeasuredCombination"]
    q = np.array(centre["field"])
    r = np.array(centre["r"])
    large = np.array(next(vals for name, history, factor, *vals in comparison if name == "BothBest"), float)
    matrices = load_matrix_rows(matrix_rows)
    stock = matrices["Stock"]
    delta = np.zeros(60)
    delta[0] = -r[0] / stock[0, 0]
    delta[52:56] = np.linalg.solve(stock[52:56, 52:56], -stock[52:56, 0] * delta[0])
    assert all(max(abs((matrix@delta)[52:60])) < 1e-17 for matrix in matrices.values())
    strain_cap = tensor_radius(delta, centre["geometry"])
    assert strain_cap < 1e-8
    forward = tensor(large-q, centre["geometry"])
    proposed = tensor(delta, centre["geometry"])
    cosine = float(forward@proposed/np.linalg.norm(forward)/np.linalg.norm(proposed))
    action = stock@delta
    report = {
        "source_native_archive_sha256": NATIVE_HASH,
        "prior_matrix_archive_sha256": GRADIENT_HASH,
        "field_label": "MeasuredCombination",
        "accepted_history": 24,
        "target_Qy_kN": centre["q"],
        "tolerance_MPa": centre["tol_MPa"],
        "native_numerical_force_scale_at_tolerance_N": centre["tol_MPa"]*AREA,
        "N_anchor_N": centre["signed_force_N_Nmm"][0],
        "anchor_max_MPa": centre["norm_MPa"],
        "anchor_gradient_rows_53_56_MPa": r[52:56].tolist(),
        "N_derivative_at_prior_anchor_MPa": stock[0,0],
        "increment_nonzero_1_based": {str(i+1): float(x) for i,x in enumerate(delta) if x},
        "physical_tensor_component_cap": strain_cap,
        "new_direction_cosine_to_existing_center_axis": cosine,
        "expected_first_order_N_increment_N": float(action[0]*AREA),
        "old_tangent_full_linear_residual_MPa": float(np.max(abs(r[:56]+action[:56]))),
        "certification_measurements": [
            "centre and each signed displacement from same H24 with unchanged six loads",
            "native full signed combination and gauge rows for all three fields",
            "opposite changes N with magnitudes larger than original tolerance in N",
            "compare rows 53–56 to centre with original tolerance as compensation check",
            "compare both signed full actions and retain actual vectors before searching an admissible candidate",
        ],
        "scope": "Directions are frozen for measurement. The prior tangent is used for sizing and compensation only.",
    }
    output.mkdir(parents=True, exist_ok=True)
    report_path = output / "WorkItem.json"
    fields_path = output / "Fields.csv"
    report_path.write_text(json.dumps(report,indent=2)+"\n", encoding="utf8")
    with fields_path.open("w", encoding="ascii", newline="") as stream:
        writer = csv.writer(stream, delimiter=";", lineterminator="\r\n")
        writer.writerow(["field_label", "Qy_kN", *[f"q{i}" for i in range(1,61)]])
        for label,sign in (("Centre",0),("AxialCompPlus",1),("AxialCompMinus",-1)):
            writer.writerow([label,centre["q"],*(q+sign*delta)])
    print(report_path.name, digest(report_path))
    print(fields_path.name, digest(fields_path))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence_directory", type=Path)
    parser.add_argument("output_directory", type=Path)
    args = parser.parse_args()
    replay(args.evidence_directory, args.output_directory)
