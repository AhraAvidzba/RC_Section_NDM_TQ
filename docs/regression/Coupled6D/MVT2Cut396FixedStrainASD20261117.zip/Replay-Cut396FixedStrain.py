"""Сравнивает два закона ASD с НДМ при одних и тех же деформациях MVT2."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha256
from io import BytesIO
from math import fsum, isclose, isfinite
from os import devnull
from pathlib import Path
from zipfile import ZipFile
import json


HERE = Path(__file__).resolve().parent
DIRECTORY = Path('docs/regression/Coupled6D')
NATIVE = ('MVT2NativePublicationCutTimed20261117.zip',
          'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A')
CONSTITUTIVE = ('MVT2GaussFixedHistoryASD20261117.zip',
                '56F7D14B51F60071DD6FD936663CEBEB3850045C842EDF1A947A54DB7FE7B4FB')
EXTERNAL = ('MVT2PublicationCut20261117.zip',
            '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD')
ARM = 396.
T = 10510000.
STATIONS = (0, 1, -1)
H = .001
STEEL_E = 200000.
MODES = ('default', 'ndm_uniaxial')
DOCUMENTATION = 'https://opensees.github.io/OpenSeesDocumentation/user/manual/material/ndMaterials/ASDConcrete3D.html'


def digest(data):
    return sha256(data).hexdigest().upper()


def archive(repo, ref):
    """Открывает известный архив результатов и методов только по совпавшему отпечатку."""
    name, expected = ref
    data = (repo / DIRECTORY / name).read_bytes()
    assert digest(data) == expected, name
    return ZipFile(BytesIO(data))


def functions(source, code):
    """Загружает чистые функции разбора из закреплённого архива."""
    target = {'__name__': '__pinned__', '__file__': str(HERE / source)}
    exec(compile(code, target['__file__'], 'exec'), target)
    return target


def read_data(repo):
    """Воспроизводит геометрию, операторы, 22 принятых состояния и команды материала."""
    with archive(repo, NATIVE) as data:
        reader = functions('Verify-NativePublicationCut.py', data.read('Verify-NativePublicationCut.py'))
        trace = data.read('Native/MVTGaussMixed.csv')
        raw_ops = data.read('Native/Operators.csv')
        raw_tensors = data.read('Native/MVTGaussMixed.Tensor.csv')
        proof = json.loads(data.read('NativePublicationCutProof.json'))
        assert proof['wire_sha256'] == dict(trace=digest(trace), operators=digest(raw_ops), tensors=digest(raw_tensors))
    with archive(repo, CONSTITUTIVE) as source:
        history = functions('Replay-History.py', source.read('Replay-History.py'))
    with archive(repo, EXTERNAL) as source:
        external = json.loads(source.read('Cut396.json'))
    tables = reader['read_operators'](raw_ops)
    frames = reader['read_tensor_frames'](raw_tensors, 45)
    rows = [row.split(';') for row in trace.decode('cp1251').splitlines()]
    header, = [row for row in rows if row[0] == 'MVT_GEOM']
    assert header[1:4] == ['25', '45', '60']
    ox, oy, area, length = map(float, header[4:])
    points = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == 'MVT_POINT'}
    assert tuple(points) == tuple(range(1, 46)) and area == 57600.
    points = {j: (row[0] - ox, row[1] - oy, *row[2:]) for j, row in points.items()}
    lines = [row.split(';') for row in raw_tensors.decode('ascii').splitlines()]
    model, = [tuple(map(float, row[1:])) for row in lines if row[0] == 'MODEL']
    curves = {name: [(abs(float(row[2])), abs(float(row[3]))) for row in lines
                     if row[0] == 'CURVE' and row[1] == name]
              for name in ('TENSION', 'COMPRESSION')}
    explicit, knot_error = history['exact_tables']({'model': model, 'curves_MPa': curves})
    e, nu, fc, ft, *_ = model
    command = {'default': ['ASDConcrete3D', e, nu, '-fc', fc, '-ft', ft, '-tangent']}
    op = ['ASDConcrete3D', e, nu]
    for name, character in (('TENSION', 'T'), ('COMPRESSION', 'C')):
        for tag, col in zip(('e', 's', 'd'), zip(*explicit[name], strict=True), strict=True):
            op.extend((f'-{character}{tag}', *col))
    command['ndm_uniaxial'] = op + ['-tangent']
    path = [(phase, torque, shear, tensors) for phase, (torque, shear, tensors) in frames.items()]
    assert len(path) == 22 and [p[0] for p in path[:8]] == [f'R{i}' for i in range(1, 9)]
    assert list(tables['F']) == list(frames)
    assert [(phase, q) for phase, _, q, _ in path[8:]] == [(p['phase'], p['Qy_N']) for p in proof['accepted']]
    assert path[-1][2] == 21875. and all(t == T for _, t, _, _ in path[8:])
    assert external['arm_mm'] == ARM
    return tables, path, points, area, length, command, model, knot_error, proof, external


def prescribed(tables, phase, side, point, state):
    """Берёт прямой экспорт в центре и восстанавливает боковые деформации тем же оператором."""
    k = tables['F'][phase]
    b = [tables['B'][point, i] for i in range(1, len(k) + 1)]
    base = tuple(fsum(v[j] * x for v, x in zip(b, k, strict=True)) for j in range(6))
    assert max(abs(a - b) for a, b in zip(base, state[:6], strict=True)) < 3e-16
    if side == 0:
        return state[:6]
    return tuple(fsum((v[j] + side * H * v[j+6]) * x for v, x in zip(b, k, strict=True)) for j in range(6))


def capture(repo, output):
    """Закрепляет каждый отклик OpenSees в той же хронологии, что принял НДМ."""
    import openseespy.opensees as ops

    assert ops.version() == '3.8.0'
    tables, path, _, _, _, command, _, _, _, _ = read_data(repo)
    stress = {}
    for name, args in command.items():
        ops.wipe()
        ops.logFile(devnull, '-noEcho')
        ops.model('basic', '-ndm', 3, '-ndf', 3)
        try:
            for tag in range(1, 136):
                ops.nDMaterial(args[0], tag, *args[1:])
            states = []
            for phase, _, _, tensors in path:
                layers = []
                for s, side in enumerate(STATIONS):
                    concrete = []
                    for point in range(1, 46):
                        strain = prescribed(tables, phase, side, point, tensors[point])
                        target = (*strain[:4], strain[5], strain[4])
                        tag = 45 * s + point
                        ops.NDTest('SetStrain', tag, *target)
                        assert tuple(ops.NDTest('GetStrain', tag)) == target
                        xx, yy, zz, xy, yz, xz = ops.NDTest('GetStress', tag)
                        row = [xx, yy, zz, xy, xz, yz]
                        assert all(map(isfinite, row))
                        concrete.append(row)
                    layers.append(concrete)
                for tag in range(1, 136):
                    ops.NDTest('CommitState', tag)
                states.append(layers)
            stress[name] = states
        finally:
            ops.wipe()
    serialized = json.dumps({'engine': '3.8.0', 'stress': stress}, allow_nan=False, separators=(',', ':')).encode()
    with output.open('xb') as fp:
        fp.write(compress(serialized, mtime=0))


def resultant(positions, stresses):
    """Интегрирует вектор N, Mx, My, T, Qx, Qy в Н и Н·мм."""
    products = [(w*zz, w*y*zz, w*x*zz, w*(x*yz-y*xz), w*xz, w*yz)
                for (x, y, w, *_), (_, _, zz, _, xz, yz) in zip(positions.values(), stresses, strict=True)]
    return tuple(map(fsum, zip(*products, strict=True)))


def assemble_net(stresses, steel, points):
    """Включает стали по НДМ и вычитает замещённый ею бетон."""
    return [row if j <= 25 else tuple(d * steel[j] - s for d, s in zip(points[j][3:], row, strict=True))
            for j, row in enumerate(stresses, 1)]


def weak_action(tables, layers):
    """Собирает материал в 60 уравнений. Для градиента применяет тот же шаг ±0,001 мм."""
    center, plus, minus = layers
    parts = [tuple(fsum(tables['S'][p, k][i] * center[p-1][k-1]
                        + tables['R'][p, k][i] * (plus[p-1][k-1] - minus[p-1][k-1]) / (2 * H)
                        for p in selected for k in range(1, 7)) for i in range(60))
             for selected in (range(1, 26), range(26, 46))]
    return tuple(a+b for a, b in zip(*parts, strict=True)), parts


def strip_resultants(points, center, steel):
    """Разделяет работу основного бетона, замещённого бетона и арматуры."""
    empty = (0.,)*6
    gross = [row if j <= 25 else empty for j, row in enumerate(center, 1)]
    removed = [empty if j <= 25 else tuple(-s for s in row) for j, row in enumerate(center, 1)]
    bars = [empty if j <= 25 else tuple(d * steel[j] for d in points[j][3:]) for j in points]
    sections = dict(gross_concrete=resultant(points, gross), replaced_concrete=resultant(points, removed),
                    steel=resultant(points, bars))
    return sections, tuple(map(fsum, zip(*sections.values(), strict=True)))


def verify(repo, wire_path):
    """Сверяет заданные деформации, упругость арматуры, усилия и слабые строки."""
    tables, path, points, area, length, _, model, knot_error, proof, _ = read_data(repo)
    data = wire_path.read_bytes()
    wire = json.loads(decompress(data))
    assert wire['engine'] == '3.8.0' and tuple(wire['stress']) == MODES
    assert all(len(traces) == len(path) for traces in wire['stress'].values())
    trace = []
    maximum_steel = [0., 0.]
    central_steel_error = 0.
    maximum_ndm_action_norm = 0.
    maximum_ndm_residual = 0.
    small_strain_elastic_error = dict.fromkeys(MODES, 0.)
    e, nu, fc, ft, *_ = model
    lam = nu*e/((1.+nu)*(1.-2.*nu))
    mu = e/(2.*(1.+nu))
    for index, (phase, torque, shear, tensors) in enumerate(path):
        wanted = (0., -ARM*shear, 0., torque, 0., shear)
        external = [fsum(tables['L'][j][i] * value for j, value in enumerate(wanted, 1)) for i in range(60)]
        gauge = [fsum(a * b for a, b in zip(tables['G'][i], tables['F'][phase], strict=True)) for i in range(1, 61)]
        scale = [area, area*length, area*length, area*length, area, area]
        tolerance = 5e-7 + 5e-7*max(map(abs, external[:56]))
        bars = []
        for side in STATIONS:
            steel = {}
            for j in range(26, 46):
                strain = prescribed(tables, phase, side, j, tensors[j])
                steel[j] = STEEL_E*fsum(a*b for a, b in zip(points[j][3:], strain, strict=True))
                family = int(j >= 30)
                maximum_steel[family] = max(maximum_steel[family], abs(steel[j]))
                assert abs(steel[j]) < (450. if family else 498.)
                if index >= 8 and side == 0:
                    center = tables['H'][phase, 0, j]
                    error = max(abs(a+b - steel[j]*d)
                                for a,b,d in zip(center, tensors[j][6:], points[j][3:], strict=True))
                    central_steel_error = max(central_steel_error, error)
                    assert error < 2e-11
            bars.append(steel)
        native_center = [tensors[j][6:] for j in points]
        ndm_parts, ndm_six = strip_resultants(points, native_center, bars[0])
        ndm_force = max(abs(a-b)/s for a,b,s in zip(ndm_six, wanted, scale, strict=True))
        assert ndm_force <= tolerance
        maximum_ndm_action_norm = max(maximum_ndm_action_norm, ndm_force)
        value = dict(phase=phase, torque_Nmm=torque, Qy_N=shear, applied_N_Nmm=wanted,
                     native_N_Nmm=ndm_six, native_parts_N_Nmm=ndm_parts, native_force_residual_MPa=ndm_force,
                     tolerance_MPa=tolerance, models={})
        if index >= 8:
            native_net = [[tables['H'][phase, side, j] for j in points] for side in STATIONS]
            net_ct = resultant(points, native_net[0])
            assert all(abs(a-b) < 1e-6 for a,b in zip(ndm_six, net_ct, strict=True))
            weak_ndm, ndm_bands = weak_action(tables, native_net)
            ndm_errors = [a+b-c for a,b,c in zip(weak_ndm, gauge, external, strict=True)]
            ndm_measure = max(ndm_force, max(map(abs, ndm_errors[:56])), 30000.*max(map(abs, ndm_errors[56:])))
            assert ndm_measure <= tolerance
            maximum_ndm_residual = max(maximum_ndm_residual, ndm_measure)
            value['native_weak_and_force_residual_MPa'] = ndm_measure
        for name, sequence in wire['stress'].items():
            layer = sequence[index]
            assert len(layer) == 3 and all(len(s) == 45 for s in layer)
            assert all(len(v) == 6 and all(map(isfinite, v)) for s in layer for v in s)
            if index == 0:
                for sid, side in enumerate(STATIONS):
                    for j, calculated in enumerate(layer[sid], 1):
                        strain = prescribed(tables, phase, side, j, tensors[j])
                        independent = (*[2*mu*x+lam*fsum(strain[:3]) for x in strain[:3]],
                                       *[mu*x for x in strain[3:]])
                        err = max(abs(a-b) for a,b in zip(calculated, independent, strict=True))
                        small_strain_elastic_error[name] = max(small_strain_elastic_error[name], err)
                        assert err < (2e-7 if name == 'default' else 5e-12)
            sigma = [assemble_net(s, rebar, points) for s, rebar in zip(layer, bars, strict=True)]
            breakdown, six = strip_resultants(points, layer[0], bars[0])
            assert all(abs(a-b) < 1e-6 for a,b in zip(six, resultant(points, sigma[0]), strict=True))
            force = max(abs(a-b)/s for a,b,s in zip(six, wanted, scale, strict=True))
            weak, bands = weak_action(tables, sigma)
            residual = [a+b-c for a,b,c in zip(weak, gauge, external, strict=True)]
            weak_max = max(range(56), key=lambda k:abs(residual[k]))
            weak_norm = max(force, abs(residual[weak_max]), 30000.*max(map(abs, residual[56:])))
            ds = [a-b for a,b in zip(six, ndm_six, strict=True)]
            assert all(abs(d - ((c-g)+(a-b))) < 1e-6 for d,c,g,a,b in zip(
                ds, breakdown['gross_concrete'], ndm_parts['gross_concrete'],
                breakdown['replaced_concrete'], ndm_parts['replaced_concrete'], strict=True))
            variation = max((abs(a-b), j, k, a-b) for j in range(1,46)
                            for k,(a,b) in enumerate(zip(layer[0][j-1], native_center[j-1], strict=True), 1))
            entry = dict(N_Nmm=six, parts_N_Nmm=breakdown, difference_vs_native_N_Nmm=ds,
                         force_residual_MPa=force, section_residual_MPa=weak_norm,
                         max_weak_row_one_based=weak_max+1,
                         stress_change_max_center_MPa=variation)
            if index >= 8:
                asymmetry = max(range(56), key=lambda k:abs(weak[k]-weak_ndm[k]))
                first, second = (a[asymmetry]-b[asymmetry] for a,b in zip(bands,ndm_bands,strict=True))
                assert isclose(first+second, weak[asymmetry]-weak_ndm[asymmetry], abs_tol=1e-12)
                entry['max_native_to_asd_weak_difference'] = {
                    'row_one_based': asymmetry + 1, 'gross_MPa': first, 'replacement_MPa': second,
                    'total_MPa': weak[asymmetry]-weak_ndm[asymmetry]}
            value['models'][name] = entry
        trace.append(value)
    assert trace[7]['torque_Nmm'] == T and abs(trace[0]['models']['default']['difference_vs_native_N_Nmm'][3]) < 1.
    assert trace[-1]['models']['default']['section_residual_MPa'] > trace[-1]['tolerance_MPa']
    return dict(
        fixed_strain_section_equilibrium_test_only=True, physical_capacity_established=False,
        input_sha256={spec[0]:spec[1] for spec in (NATIVE, CONSTITUTIVE, EXTERNAL)},
        wire_sha256=digest(data), engine=wire['engine'], field_count=len(path), station_count=3,
        points_per_station=45, asd_modes=MODES, model_source=DOCUMENTATION,
        max_steel_stress_MPa={'longitudinal': maximum_steel[0], 'transverse': maximum_steel[1]},
        max_center_steel_export_difference_MPa=central_steel_error,
        max_first_field_elastic_stress_error_MPa=small_strain_elastic_error,
        max_explicit_ndm_uniaxial_anchor_difference=knot_error,
        max_native_force_residual_MPa=maximum_ndm_action_norm,
        max_native_section_residual_on_mixed_steps_MPa=maximum_ndm_residual,
        pure_torsion_has_native_center_stress_only=True,
        states=trace,
    )


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--capture', type=Path)
    parser.add_argument('--wire', type=Path, default=HERE / 'Cut396FixedStrain.json.gz')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.capture:
        capture(args.repo, args.capture)
    if args.report:
        checked = verify(args.repo, args.capture or args.wire)
        with args.report.open('x', encoding='utf-8', newline='\n') as fp:
            json.dump(checked, fp, indent=2, sort_keys=True, allow_nan=False)
            fp.write('\n')
        print('MVT2 CUT396 FIXED STRAIN OFFLINE PASS', checked['field_count'])
    assert args.capture or args.report


if __name__ == '__main__':
    main()
