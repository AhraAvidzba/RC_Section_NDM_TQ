"""Independently rebuild all stored rows, six resultants, and update strain radii."""
from collections import defaultdict
from pathlib import Path
import csv, json
import runpy
globals().update({k:v for k,v in runpy.run_path(str(Path(__file__).with_name("Verify-MVT2ShearControlled.py"))).items() if not k.startswith("__")})

folder=Path(__file__).resolve().parent
tags=defaultdict(list)
for tag,*row in csv.reader((folder/"NativeA/MVT2.csv").read_text().splitlines(),delimiter=";"):
    tags[tag].append(row)
assert tags["B_TANGENT_END"] and tags["BOUNDED_CURRENT"] and tags["BOUNDED_READY"]
fields={name:(int(h),float(f),tuple(map(float,row))) for name,h,f,*row in tags["B_TANGENT_FIELD"]}
stations=defaultdict(dict)
for name,i,s,*row in tags["B_TANGENT_STATION"]:
    stations[name][int(i),int(s)]=tuple(map(float,row))
native={name:tuple(map(float,row)) for name,*row in tags["B_TANGENT_RESIDUAL"]}
actuals={name:tuple(map(float,row)) for name,*row in tags["B_BOUND_ACTUAL"]}
native_norm={name:float(n) for name,n in tags["B_BOUND_NORM"]}
assert fields["Base24"]==fields["Restored24"]
assert stations["Base24"]==stations["Restored24"]
assert native["Base24"]==native["Restored24"]
assert fields["Anchor"][:2]==fields["FinalProvisional"][:2]
metrics={}
for name,(h,f,field) in fields.items():
    internal, efforts, strain_difference=reconstruct(field,f,stations[name])
    residual_replay=peak(diff(internal,native[name]))
    assert strain_difference<4e-15 and residual_replay<3e-10
    assert peak(diff(efforts,actuals[name]))<1e-7
    force_signed=diff(efforts,force(f))
    scales=(AREA,AREA*LENGTH,AREA*LENGTH,AREA*LENGTH,AREA,AREA)
    full=max(peak(internal[:56]),MODULUS*peak(internal[56:]),peak(r/w for r,w in zip(force_signed,scales)))
    near(full,native_norm[name],4e-10)
    metrics[name]={"norm_MPa":full,"target_tolerance_MPa":5e-7*(1.+peak(loading(f))),"signed_effort_error_N_Nmm":force_signed,
                   "reconstruction_error_MPa":residual_replay,"strain_difference":strain_difference}
steps={}
prior=fields["Anchor"][2]
for count,*values in tags["BOUNDED_FIELD"]:
    next_field=tuple(map(float,values))
    delta=diff(next_field,prior)
    strains=(strain_at(delta,operators(*record[:2]),side) for (point,side),record in stations["Anchor"].items())
    radius=max(peak(e if i<3 else e/math.sqrt(2.) for i,e in enumerate(values)) for values in strains)
    assert radius<=1e-8+1e-14
    steps[int(count)]=radius
    prior=next_field
near(peak(diff(prior,fields["FinalProvisional"][2])),0.,5e-15)
assert len(steps)==len(tags["BOUNDED_UPDATE"])
assert tags["BOUNDED_READY"] in [[["0"]],[["1"]]]
ready=tags["BOUNDED_READY"]==[["1"]]
start=metrics["Anchor"]["norm_MPa"]
end=metrics["FinalProvisional"]["norm_MPa"]
near(float(tags["BOUNDED_CURRENT"][0][1]),start,4e-10)
if steps: near(float(tags["BOUNDED_UPDATE"][-1][1]),end,4e-10)
if ready: assert end<=metrics["FinalProvisional"]["target_tolerance_MPa"]+4e-10
result={"metrics":metrics,"ready":ready,"update_radius":steps,"trial_rows":{name:rows for name,rows in tags.items() if name.startswith("BOUNDED_") and name!="BOUNDED_FIELD"}}
path=folder/"Verification.json"
path.write_text(json.dumps(result,indent=2)+"\n")
print(digest(path),start,end,len(steps),ready)

