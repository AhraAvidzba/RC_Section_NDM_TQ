"""Prepare and hash the scoped MVT2 repeated-correction experiment."""
from pathlib import Path
import hashlib, json, shutil

root=Path(__file__).resolve().parent
previous=root.parent/"mvt-next"
book=Path("workbook/output/RC_Section_NDM.xlsm")
draft=Path("docs/regression/Diagnostic.xlsm")
module=Path("tests/modTestCoupledExperiment.bas")
solver=Path("src/CCoupledNewtonSolver.cls")
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def vba(p,out):
    out.write_bytes(p.replace("\n","\r\n").encode("utf-8"))
receipt=root/"Preparation.json"
if not receipt.exists():
    meta=json.loads((previous/"Preparation.json").read_text(encoding="utf-8"))
    assert sha(previous/book)==meta["book_sha256"]==sha(Path.cwd()/book)
    assert sha(previous/module)==meta["module_sha256"]
    assert sha(previous/"AnchorField.csv")==meta["previous_input_sha256"]["AnchorField.csv"]
    assert sha(previous/"Replay.csv")==meta["replay_sha256"]
    for rel in ("tools","Guard-IsolatedOffice.ps1","Replay.csv","AnchorField.csv","Verify-MVT2ShearControlled.py"):
        origin=previous/rel
        if origin.is_dir(): shutil.copytree(origin,root/rel)
        else: shutil.copyfile(origin,root/rel)
    for path in (root/book,root/draft,root/module,root/solver,root/"Temp/probe",root/"NativeA/probe"):
        path.parent.mkdir(parents=True,exist_ok=True)
    for path in (book,draft): shutil.copyfile(previous/book,root/path)
    text=(previous/module).read_text(encoding="utf-8-sig")
    begin=text.index('    If phase = "A" Then',text.index("Public Function RunTestWangShearControlled"))
    end=text.index('    RequireWangAcceptedFieldTest solver, base',begin)
    branch=(root/"RepeatedBranch.txt").read_text(encoding="utf-8")
    vba(text[:begin]+branch+text[end:],root/module)
    fixed=(root/"CCoupledNewtonSolver.cls").read_text(encoding="utf-8-sig")
    fixed=fixed.replace("ByVal log As Collection","ByVal traceRows As Collection").replace("log.Add ","traceRows.Add ").replace("nextNorm, log)","nextNorm, traceRows)")
    marker='        traceRows.Add "BOUNDED_UPDATE;" & CStr(attempt + 1) & ";" & Str$(nextNorm)'
    assert fixed.count(marker)==1
    fixed=fixed.replace(marker,marker+'''
        Dim row As String, i As Long
        row = "BOUNDED_FIELD;" & CStr(attempt + 1)
        For i = 1 To mDegreeCount: row = row & ";" & Str$(provisional(i)): Next i
        traceRows.Add row''')
    vba(fixed+"\n"+(previous/"SolverReader.txt").read_text(encoding="utf-8"),root/solver)
    old=(previous/"Run-MVT2ShearControlled.ps1").read_text(encoding="utf-8")
    old=old.replace("Prepare-MVT2ShearControlled.py","Prepare-Repeated.py").replace('Verify-MVT2ShearControlled.py\') --phase $Phase','Verify-Repeated.py\')')
    (root/"Run-Repeated.ps1").write_text(old,encoding="utf-8")
    files=[book,module,solver,Path("Guard-IsolatedOffice.ps1"),Path("Replay.csv"),Path("AnchorField.csv"),Path("Verify-Repeated.py"),Path("Verify-MVT2ShearControlled.py"),Path("Run-Repeated.ps1"),*[p.relative_to(root) for p in (root/"tools").rglob("*") if p.is_file()]]
    receipt.write_text(json.dumps({"book_sha256":meta["book_sha256"],"watchdog_seconds":220,"frozen":{str(f):sha(root/f) for f in files}},indent=2),encoding="utf-8")
meta=json.loads(receipt.read_text(encoding="utf-8"))
assert all(sha(root/f)==expected for f,expected in meta["frozen"].items())
print(sha(receipt))

