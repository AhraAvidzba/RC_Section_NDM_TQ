Attribute VB_Name = "modTestCoupledExperiment"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сопоставление связанного НДС с опытами Onsongo TBU3, Kani и Lopes A2.
' Геометрия и стали восстановлены по первичным публикациям в literature/Coupled6D.
' Параметры, отсутствующие в источниках, фиксируются как допущения расчёта.

Private Const TBU3_HALF_WIDTH As Double = 254#
Private Const TBU3_HALF_HEIGHT As Double = 205# ' Полувысота номинального прямоугольника, мм.
Private Const TBU3_MEASUREMENT_HALF_HEIGHT As Double = 76# ' Две соседние базы измерения по 76 мм.
Private Const TBU3_REFERENCE_HOOP_SPACING As Double = 150# ' Контрольный вариант исторического ряда.
Private Const TBU3_MEASURED_HOOP_SPACING As Double = 76# ' Схема TBU по Rahal и Collins.
Private Const TBU3_REFERENCE_BOTTOM_Y As Double = -154# ' Оценка положения нижнего ряда, мм.
Private Const TBU3_PUBLISHED_HOOP_COVER As Double = 6.35 ' Слой до поверхности по Kuan и соавторам, рис. 9, мм.
Private Const TBU3_PUBLISHED_BOTTOM_Y As Double = -173# ' Приведённая глубина оси 378 мм от верхней грани.
Private Const TBU3_REFERENCE_PEAK_COMPRESSION As Double = 0.0045 ' Калибровка Yamamoto с учётом остановок нагружения.
Private Const TBU3_PUBLISHED_PEAK_COMPRESSION As Double = 0.0031 ' Значение Kagermanov и Ceresa, табл. 2.

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прослеживает чистый Qy с заданием среднего инженерного сдвига yz.
' Опытная кривая сравнивается с принятыми точками без экстраполяции.
Public Function RunTestCoupledKaniShear(ByVal spansText As String, ByVal shearText As String) As String
    RunTestCoupledKaniShear = TraceKaniShearTest(spansText, shearText, False)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет траекторию с оценками энергий из формул (16.3–16.4)
' Poliotti и Bairán (2019). Характеристическую длину сохраняет.
Public Function RunTestCoupledKaniPublishedEnergy(ByVal spansText As String, ByVal shearText As String) As String
    RunTestCoupledKaniPublishedEnergy = TraceKaniShearTest(spansText, shearText, True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет траекторию Kani с тремя историями и теми же оценками энергий.
Public Function RunTestCoupledKaniSpatial(ByVal spansText As String, ByVal shearText As String) As String
    RunTestCoupledKaniSpatial = TraceKaniShearTest(spansText, shearText, True, spatialHistory:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет точки равновесия и причины уменьшения шага при заданном сдвиге.
Private Function TraceKaniShearTest(ByVal spansText As String, ByVal shearText As String, ByVal publishedEnergies As Boolean, _
        Optional ByVal spatialHistory As Boolean = False) As String
    On Error GoTo Failed
    Const EC As Double = 25600#
    Const FC As Double = 28.2
    Const FT As Double = 1.75
    Const NOMINAL_INCREMENT As Double = 0.0002
    Const MAX_ATTEMPTS As Long = 120
    Const FORCE_SCALE As Double = 100000# ' Множитель равновесия отсчитывается в долях 100 кН.
    Const AREA As Double = 305# * 610#
    Dim report As String, tracePath As String, passed As Long, failed As Long
    Dim spans As Long: spans = CLng(spansText)
    Dim maximumShear As Double: maximumShear = Val(shearText)
    If spans < 1 Or spans > 3 Or maximumShear <= 0# Or maximumShear > 0.008 Then _
        Err.Raise 5, , "Тестовые границы: базис 1–3, инженерный сдвиг от 0 до 0,008."
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) > 0 Then tracePath = ThisWorkbook.Path & "\Kani_Trace.csv"
    AddExperimentTraceTest report, tracePath, "attempt;gamma_yz;Qy_kN;hoop_stress_MPa;hoop_utilization;stress_residual_MPa;seconds"
    Dim gt As Double, gc As Double
    gt = 0.12: gc = 80#
    If publishedEnergies Then
        gt = 0.073 * FC ^ 0.18
        gc = (FC / FT) ^ 2 * gt
    End If
    AddExperimentTraceTest report, tracePath, "KANI_ENERGIES_N_PER_MM: " & ExperimentNumberTest(gt) & " | " & ExperimentNumberTest(gc)
    Dim section As CSectionModel, layout As CTransverseRebarLayout, steel As Object
    Set section = BuildKaniSectionTest(layout, steel)
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse, response As New CCoupledReinforcedResponse
    operators.PrepareModel section, EC, 0.2, spans, spans, 5, layout, steelModels:=steel
    Dim solver As New CCoupledNewtonSolver, shearX() As Double, shearY() As Double
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, 0.2, FC, FT, 0.0022, gt, gc, spatialHistory
    operators.MeanShearProjections shearX, shearY
    Dim baseLoad(1 To 6) As Double, direction(1 To 6) As Double
    direction(6) = FORCE_SCALE
    AddExperimentTraceTest report, tracePath, "KANI_POINTS: " & CStr(operators.PointCount) & " | DOF: " & CStr(operators.DegreeCount)

    Dim coordinate As Double, increment As Double, candidate As Double, trialLambda As Double, reached As Double
    Dim field() As Double, actual() As Double, attempt As Long, i As Long, errorNorm As Double, difference As Double
    Dim gamma As Double, expected As Double, hoopPoint As Long, started As Double, stopReason As String
    increment = NOMINAL_INCREMENT: stopReason = "AttemptLimit"
    For attempt = 1 To MAX_ATTEMPTS
        candidate = coordinate + increment
        If candidate > maximumShear Then candidate = maximumShear
        started = Timer
        If solver.TryDeformationStep(baseLoad, direction, shearY, candidate, reached, trialLambda, 0.0000005, 0.00000002, 24) Then
            solver.CopyTrial field, actual: solver.AcceptStep
            reached = trialLambda: coordinate = candidate: errorNorm = 0#: gamma = 0#
            For i = 1 To operators.DegreeCount: gamma = gamma + shearY(i) * field(i): Next i
            For i = 1 To 6
                expected = reached * direction(i)
                difference = Abs(actual(i) - expected) / AREA
                If i >= 2 And i <= 4 Then difference = difference / 610#
                If difference > errorNorm Then errorNorm = difference
            Next i
            hoopPoint = response.AcceptedTransverseCriticalPoint
            AddExperimentTraceTest report, tracePath, "Kani" & CStr(attempt) & ";" & ExperimentNumberTest(gamma) & ";" & _
                ExperimentNumberTest(actual(6) / 1000#) & ";" & ExperimentNumberTest(response.AcceptedSteelStress(hoopPoint)) & ";" & _
                ExperimentNumberTest(response.AcceptedTransverseSteelUtilization) & ";" & ExperimentNumberTest(errorNorm) & ";" & ExperimentNumberTest(Timer - started)
            If errorNorm < 0.000005 And Abs(gamma - candidate) < 0.000000001 Then passed = passed + 1 Else failed = failed + 1
            If coordinate = maximumShear Then
                stopReason = "TargetReached"
                Exit For
            End If
            increment = increment * 1.25
            If increment > NOMINAL_INCREMENT Then increment = NOMINAL_INCREMENT
        Else
            AddExperimentTraceTest report, tracePath, "KANI_REJECTED: " & CStr(attempt) & " | gamma: " & ExperimentNumberTest(candidate) & _
                " | " & solver.ResultMeta.ResultComment & " | " & solver.ResultMeta.DiagnosticDetails
            increment = increment * 0.5
            If increment < NOMINAL_INCREMENT / 32# Then
                stopReason = "MinimumShearIncrement"
                Exit For
            End If
        End If
    Next attempt
    AddExperimentTraceTest report, tracePath, "KANI_STOP: " & stopReason
    If passed = 0 Then failed = failed + 1
    TraceKaniShearTest = report & "TOTAL_KANI_SHEAR_EQUILIBRIUM: passed=" & passed & "; failed=" & failed
    Exit Function
Failed:
    TraceKaniShearTest = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит номинальное сечение Kani. Положение осей масштабировано по рис. 4a
' Poliotti и Bairán. Фактические радиусы загибов и диаграммы после текучести неизвестны.
Private Function BuildKaniSectionTest(ByRef layout As CTransverseRebarLayout, ByRef steel As Object) As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("Kani_Outer", Array(Array(-152.5, -305#, 305#, 610#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours

    Dim i As Long, x As Double
    For i = 0 To 3
        x = -105# + 70# * i
        section.AddRebarElement x, -254#, 25#, GEOM_PI * 156.25, "KANI_LONG"
        section.AddRebarElement x, 254#, 25#, GEOM_PI * 156.25, "KANI_LONG"
    Next i
    Set layout = New CTransverseRebarLayout
    layout.AddContourGroup section, "KANI_HOOP", vbNullString, 10#, 100#, 25#, "KANI_HOOP"
    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "KANI_LONG", ExperimentBilinearSteelTest(200000#, 442#, 0#)
    steel.Add "KANI_HOOP", ExperimentBilinearSteelTest(200000#, 400#, 0#)
    Set BuildKaniSectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Нагружает полую балку A2 заданным закручиванием. Независимо записывает
' первое повреждение бетона, текучесть хомута и продольной стали.
Public Function RunTestCoupledLopesA2(ByVal spansText As String, ByVal twistText As String) As String
    RunTestCoupledLopesA2 = TraceLopesA2Test(spansText, twistText, False)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет чистое кручение с уточнённой стенкой и отдельными параметрами
' бетона и двух видов стали по таблицам 4.1–4.2 Martins.
Public Function RunTestCoupledLopesA2RefinedInputs(ByVal spansText As String, ByVal twistText As String) As String
    RunTestCoupledLopesA2RefinedInputs = TraceLopesA2Test(spansText, twistText, True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прослеживает ту же траекторию чистого кручения A2 с тремя историями.
Public Function RunTestCoupledLopesA2Spatial(ByVal spansText As String, ByVal twistText As String) As String
    RunTestCoupledLopesA2Spatial = TraceLopesA2Test(spansText, twistText, True, spatialHistory:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит сжатие 1279,1 кН из таблицы 3 Bernardo и Taborda
' до увеличения кручения. Продольная сила затем остаётся постоянной.
Public Function RunTestCoupledLopesA2Compression(ByVal spansText As String, ByVal twistText As String) As String
    RunTestCoupledLopesA2Compression = TraceLopesA2Test(spansText, twistText, True, -1279100#)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет диагностический пик и итог прочности A2 с восстановленной ветвью.
Public Function RunTestCoupledLopesA2LocalPeak(ByVal spansText As String, ByVal maximumLambdaText As String) As String
    RunTestCoupledLopesA2LocalPeak = TraceLopesA2Test(spansText, ".029", True, strengthMaximum:=Val(maximumLambdaText))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает упругое сечение и последующую нелинейную ветвь с армированием.
Private Function TraceLopesA2Test(ByVal spansText As String, ByVal twistText As String, ByVal refinedInputs As Boolean, _
        Optional ByVal normalForce As Double = 0#, Optional ByVal strengthMaximum As Double = 0#, _
        Optional ByVal spatialHistory As Boolean = False) As String
    On Error GoTo Failed
    Const NU As Double = 0.2
    Const FC As Double = 47.3
    Const START_INCREMENT As Double = 0.00025 ' рад/м
    Const MAX_INCREMENT As Double = 0.001 ' рад/м
    Dim spans As Long: spans = CLng(spansText)
    Dim limitTwist As Double: limitTwist = Val(twistText)
    If spans < 1 Or spans > 3 Or limitTwist <= 0# Or limitTwist > 0.035 Then _
        Err.Raise 5, , "Тестовые границы A2: базис 1–3, закручивание до 0,035 рад/м."
    Dim report As String, tracePath As String, passed As Long, failed As Long
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) > 0 Then tracePath = ThisWorkbook.Path & "\A2_Trace.csv"

    Dim ec As Double, ft As Double, gt As Double, gc As Double, peakStrain As Double, wall As Double
    Dim hoopYield As Double, longitudinalYield As Double
    ec = 35000#: ft = 0.302 * FC ^ (2# / 3#): peakStrain = 0.0024: wall = 100#
    hoopYield = 686#: longitudinalYield = 686#
    If refinedInputs Then
        ec = 36100#: ft = 3.5: peakStrain = 0.002: wall = 107#
        hoopYield = 696#: longitudinalYield = 672#
    End If
    gt = 0.073 * FC ^ 0.18: gc = (FC / ft) ^ 2 * gt
    Dim section As CSectionModel: Set section = BuildLopesA2SectionTest(wall)
    Dim operators As New CCoupledElasticState
    operators.PrepareModel section, ec, NU, spans, spans, 5
    Dim field() As Double, actual() As Double, deformation() As Double, stress() As Double
    If Not operators.Solve(0#, 0#, 0#, 10000000#, 0#, 0#, deformation, actual, stress) Then _
        Err.Raise 5, , operators.ResultMeta.ResultComment
    Dim rigidity As Double: rigidity = actual(4) / deformation(4)
    AddExperimentTraceTest report, tracePath, "A2_ELASTIC_J_MM4: " & ExperimentNumberTest(rigidity * 2# * (1# + NU) / ec)
    AddExperimentTraceTest report, tracePath, "A2_ELASTIC_RIGIDITY_KNM2: " & ExperimentNumberTest(rigidity / 1E+9)

    Dim layout As New CTransverseRebarLayout, steel As Object
    AddLopesA2ReinforcementTest section, layout
    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "A2_LONG", ExperimentBilinearSteelTest(200000#, longitudinalYield, 0#)
    steel.Add "A2_HOOP", ExperimentBilinearSteelTest(200000#, hoopYield, 0#)
    operators.PrepareModel section, ec, NU, spans, spans, 5, layout, steelModels:=steel
    AddExperimentTraceTest report, tracePath, "A2_PARAMETERS: Ec " & ExperimentNumberTest(ec) & " | Ft " & _
        ExperimentNumberTest(ft) & " | Gt " & ExperimentNumberTest(gt) & " | Gc " & ExperimentNumberTest(gc) & _
        " | wall " & ExperimentNumberTest(wall) & " | fy hoop " & ExperimentNumberTest(hoopYield) & _
        " | fy longitudinal " & ExperimentNumberTest(longitudinalYield)
    AddExperimentTraceTest report, tracePath, "A2_POINTS: " & CStr(operators.PointCount) & " | DOF: " & CStr(operators.DegreeCount)
    Dim concrete As New CCoupledConcreteResponse, response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, ec, NU, FC, ft, peakStrain, gt, gc, spatialHistory
    If strengthMaximum > 0# Then
        TraceLopesA2Test = SearchLopesA2StrengthTest(operators, solver, response, strengthMaximum, report, tracePath)
        Exit Function
    End If
    If normalForce <> 0# Then
        Dim path As New CLoadPathVector, preload As New CCoupledLoadContinuation
        path.Initialize normalForce, 0#, 0#, 0#, 0#, 0#
        preload.Initialize solver, path, 4, 12, 24, 0.0000005, 0.00000002
        If Not preload.Advance(0#) Then Err.Raise 5, , preload.ResultMeta.ResultComment & " " & preload.ResultMeta.DiagnosticDetails
        preload.CopyAccepted field, actual
        AddExperimentTraceTest report, tracePath, "A2_PRELOAD_N_KN: " & ExperimentNumberTest(actual(1) / 1000#)
    End If
    Dim projection() As Double, baseLoad(1 To 6) As Double, direction(1 To 6) As Double, target(1 To 6) As Double
    ReDim projection(1 To operators.DegreeCount): projection(4) = 1#
    baseLoad(1) = normalForce: target(1) = normalForce
    direction(4) = 100000000# ' Множитель в долях 100 кН·м.
    Dim eps0 As Double, kx As Double, ky As Double, twist As Double, coordinatePerRadPerM As Double
    operators.GeneralizedDeformation projection, eps0, kx, ky, twist
    coordinatePerRadPerM = 1# / (1000# * twist)
    AddExperimentTraceTest report, tracePath, "attempt;twist_rad_per_m;T_kNm;hoop_stress_MPa;longitudinal_stress_MPa;tension_energy_ratio;residual_MPa;seconds"

    Dim coordinate As Double, increment As Double, requested As Double, lambda As Double, trialLambda As Double
    Dim attempt As Long, i As Long, tension As Double, compression As Double, damage As Double, longStress As Double
    Dim moment As Double, previousMoment As Double, hoopStress As Double, errorNorm As Double, started As Double
    Dim sawDamage As Boolean, sawHoop As Boolean, sawLongitudinal As Boolean, stopReason As String
    increment = START_INCREMENT: stopReason = "AttemptLimit"
    For attempt = 1 To 100
        requested = coordinate + increment
        If requested > limitTwist Then requested = limitTwist
        started = Timer
        If solver.TryDeformationStep(baseLoad, direction, projection, requested * coordinatePerRadPerM, lambda, _
                trialLambda, 0.0000005, 0.00000002, 24) Then
            solver.CopyTrial field, actual: solver.AcceptStep
            lambda = trialLambda: target(4) = lambda * direction(4)
            moment = actual(4) / 1E+6
            operators.GeneralizedDeformation field, eps0, kx, ky, twist
            errorNorm = operators.ResultantResidualNorm(actual, target)
            damage = 0#: longStress = 0#
            For i = 1 To operators.ConcretePointCount
                concrete.AcceptedPointDamage i, tension, compression
                If tension > damage Then damage = tension
            Next i
            For i = operators.ConcretePointCount + 1 To operators.ConcretePointCount + section.RebarCount
                If Abs(response.AcceptedSteelStress(i)) > longStress Then longStress = Abs(response.AcceptedSteelStress(i))
            Next i
            hoopStress = Abs(response.AcceptedSteelStress(response.AcceptedTransverseCriticalPoint))
            AddExperimentTraceTest report, tracePath, "A2Step" & CStr(attempt) & ";" & ExperimentNumberTest(twist * 1000#) & _
                ";" & ExperimentNumberTest(moment) & ";" & ExperimentNumberTest(hoopStress) & ";" & ExperimentNumberTest(longStress) & _
                ";" & ExperimentNumberTest(damage) & ";" & ExperimentNumberTest(errorNorm) & ";" & ExperimentNumberTest(Timer - started)
            If errorNorm < 0.000005 And Abs(twist * 1000# - requested) < 0.00000001 Then passed = passed + 1 Else failed = failed + 1
            RecordLopesA2EventTest "TENSION_DAMAGE", (damage > 0.000001), sawDamage, coordinate, previousMoment, requested, moment, report, tracePath
            RecordLopesA2EventTest "HOOP_YIELD", (hoopStress >= hoopYield - 0.000001), sawHoop, coordinate, previousMoment, requested, moment, report, tracePath
            RecordLopesA2EventTest "LONGITUDINAL_YIELD", (longStress >= longitudinalYield - 0.000001), sawLongitudinal, coordinate, previousMoment, requested, moment, report, tracePath
            coordinate = requested: previousMoment = moment
            If coordinate = limitTwist Then
                stopReason = "TargetReached"
                Exit For
            End If
            increment = increment * 1.25
            If increment > MAX_INCREMENT Then increment = MAX_INCREMENT
        Else
            Dim meta As CResultMeta: Set meta = solver.ResultMeta
            AddExperimentTraceTest report, tracePath, "A2_REJECTED: " & CStr(attempt) & " | " & ExperimentNumberTest(requested) & _
                " | " & meta.ResultComment & " | " & meta.DiagnosticDetails
            increment = increment * 0.5
            If increment < START_INCREMENT / 32# Then
                stopReason = "MinimumTwistIncrement"
                Exit For
            End If
        End If
    Next attempt
    AddExperimentTraceTest report, tracePath, "A2_STOP: " & stopReason
    If passed = 0 Then failed = failed + 1
    TraceLopesA2Test = report & "TOTAL_A2_TORSION_EQUILIBRIUM: passed=" & passed & "; failed=" & failed
    Exit Function
Failed:
    TraceLopesA2Test = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Запускает тот же силовой и деформационный поиск, что использует проверка прочности.
Private Function SearchLopesA2StrengthTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByVal response As CCoupledReinforcedResponse, ByVal maximum As Double, ByRef report As String, ByVal tracePath As String) As String
    Const UNIT_MOMENT As Double = 100000000#
    Dim path As New CLoadPathVector, branch As New CCoupledLoadContinuation
    path.Initialize 0#, 0#, 0#, 0#, 0#, 0#, 0#, UNIT_MOMENT
    branch.Initialize solver, path, 4, 64, 24, 0.0000005, 0.0000005, True
    branch.TraceSteelLimit response, 0.25, maximum, 0.005, True
    Dim forceMeta As CResultMeta: Set forceMeta = branch.ResultMeta
    AddExperimentTraceTest report, tracePath, "A2_STRENGTH_FORCE: " & ExperimentNumberTest(branch.AcceptedLambda) & " | " & _
        forceMeta.ResultComment & " | " & forceMeta.DiagnosticDetails
    Dim controlled As CCoupledDeformationContinuation, best As Double, peak As Double, accuracy As Double, verified As Boolean
    Dim limitFields As Collection, actual() As Double, force() As Double, field() As Double
    Dim low As Double, high As Double, onOffset As Boolean, point As Long, failure As Long, passed As Long
    Dim eps0 As Double, kx As Double, ky As Double, twist As Double
    If branch.CopySteelLimit(low, high, onOffset, point) Then
        branch.CopyLimitState limitFields, actual
    Else
        Set controlled = branch.ContinueByDeformation(maximum)
        If Not controlled Is Nothing Then
            Dim meta As CResultMeta: Set meta = controlled.ResultMeta
            best = controlled.BestAdmissibleLambda
            AddExperimentTraceTest report, tracePath, "A2_STRENGTH_CONTROL: " & meta.ResultComment & " | " & meta.DiagnosticDetails
            If controlled.CopyPeak(peak, accuracy, verified) Or controlled.CopySteelLimit(low, high, point) Then _
                controlled.CopyLimitState limitFields, actual
        End If
    End If
    AddExperimentTraceTest report, tracePath, "A2_STRENGTH_LIMIT;" & ExperimentNumberTest(best) & ";" & _
        ExperimentNumberTest(peak) & ";" & ExperimentNumberTest(accuracy) & ";" & CStr(verified) & ";" & _
        ExperimentNumberTest(low) & ";" & ExperimentNumberTest(high) & ";" & CStr(point)
    CheckLopesA2LocalPeakTest controlled, best, peak, point, limitFields, report, tracePath, passed, failure
    If limitFields Is Nothing Then
        If peak = 0# And point = 0 Then passed = passed + 1 Else failure = failure + 1
    Else
        If peak > 0# Then path.TargetSix peak, force Else path.TargetSix low, force
        field = limitFields.Item(limitFields.Count)
        operators.GeneralizedDeformation field, eps0, kx, ky, twist
        Dim errorNorm As Double: errorNorm = operators.ResultantResidualNorm(actual, force)
        AddExperimentTraceTest report, tracePath, "A2_STRENGTH_RESULTANT;" & ExperimentNumberTest(actual(4) / 1E+6) & ";" & _
            ExperimentNumberTest(twist * 1000#) & ";" & ExperimentNumberTest(errorNorm)
        If errorNorm < 0.000005 Then passed = passed + 1 Else failure = failure + 1
    End If
    SearchLopesA2StrengthTest = report & "TOTAL_A2_STRENGTH_SEARCH: passed=" & passed & "; failed=" & failure
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подтверждает, что ранний пик не записан как предельный максимум.
Private Sub CheckLopesA2LocalPeakTest(ByVal controlled As CCoupledDeformationContinuation, ByVal best As Double, _
        ByVal peak As Double, ByVal steelPoint As Long, ByVal fields As Collection, ByRef report As String, _
        ByVal tracePath As String, ByRef passed As Long, ByRef failures As Long)
    Dim passedLocal As Boolean, details As String, capacity As New CCapacityResult
    If Not controlled Is Nothing Then
        Const RECOVERY_MARKER As String = "максимумов превзойдено после спада: "
        Dim meta As CResultMeta: Set meta = controlled.ResultMeta
        details = meta.DiagnosticDetails
        Dim recoveryAt As Long: recoveryAt = InStr(details, RECOVERY_MARKER)
        If recoveryAt > 0 Then
            passedLocal = (Val(Mid$(details, recoveryAt + Len(RECOVERY_MARKER))) > 0 And _
                InStr(details, "локальный максимум lambda:") > 0 And peak = 0# And best > 1.54)
        End If
        If steelPoint = 0 Then
            capacity.InitializeCoupledUnresolved meta, "Auto", best
            passedLocal = passedLocal And (fields Is Nothing) And capacity.Status = "NumFail" And _
                capacity.HasConfirmedLowerBound And Not capacity.HasUltimatePoint
        End If
    End If
    AddExperimentTraceTest report, tracePath, "A2_LOCAL_PEAK_NOT_ULTIMATE: " & CStr(passedLocal)
    If passedLocal Then passed = passed + 1 Else failures = failures + 1
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Фиксирует первое обнаружение события интервалом двух принятых точек.
Private Sub RecordLopesA2EventTest(ByVal eventName As String, ByVal detected As Boolean, ByRef reported As Boolean, _
        ByVal leftTwist As Double, ByVal leftMoment As Double, ByVal rightTwist As Double, ByVal rightMoment As Double, _
        ByRef report As String, ByVal tracePath As String)
    If Not detected Or reported Then Exit Sub
    reported = True
    AddExperimentTraceTest report, tracePath, "A2_EVENT;" & eventName & ";" & ExperimentNumberTest(leftTwist) & ";" & _
        ExperimentNumberTest(leftMoment) & ";" & ExperimentNumberTest(rightTwist) & ";" & ExperimentNumberTest(rightMoment)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит тот же наружный квадрат и восьмиугольный проём, что и КЭ-эталон.
Private Function BuildLopesA2SectionTest(ByVal wall As Double) As CSectionModel
    Dim query As New CSectionGeometryQuery, outer As CConcreteRegion, inner As CConcreteRegion, geometry As New CGeometryRegion
    Set outer = query.RectangleRegion(0#, 0#, 600#, 600#)
    Dim coordinates(1 To 8, 1 To 2) As Double, vertex As Variant, index As Long
    Dim halfOpening As Double, chamferStart As Double
    halfOpening = 300# - wall: chamferStart = halfOpening - 50#
    For Each vertex In Array(Array(-chamferStart, -halfOpening), Array(chamferStart, -halfOpening), _
            Array(halfOpening, -chamferStart), Array(halfOpening, chamferStart), Array(chamferStart, halfOpening), _
            Array(-chamferStart, halfOpening), Array(-halfOpening, chamferStart), Array(-halfOpening, -chamferStart))
        index = index + 1
        coordinates(index, 1) = vertex(0): coordinates(index, 2) = vertex(1)
    Next vertex
    Set inner = query.PolygonRegion(coordinates)
    geometry.Initialize query.SubtractContainedRegion(outer, inner)
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh geometry, 24#, 24#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    geometry.BuildContours section.Contours
    Set BuildLopesA2SectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Задаёт опубликованные размеры осей хомута и размещает стержни внутри него.
Private Sub AddLopesA2ReinforcementTest(ByVal section As CSectionModel, ByVal layout As CTransverseRebarLayout)
    Dim query As New CSectionGeometryQuery, path As CGeometryPath
    Set path = query.AdjacentRectangles("A2_HOOP", Array(Array(-269#, -265.5, 538#, 531#)))
    layout.AddGroup path, 8#, 80#, "A2_HOOP"
    Dim sx As Long, sy As Long, i As Long
    For sx = -1 To 1 Step 2
        For sy = -1 To 1 Step 2
            section.AddRebarElement sx * 259#, sy * 255.5, 12#, GEOM_PI * 36#, "A2_LONG"
        Next sy
        For i = -1 To 1
            section.AddRebarElement sx * 260#, i * 127.75, 10#, GEOM_PI * 25#, "A2_LONG"
            section.AddRebarElement i * 129.5, sx * 256.5, 10#, GEOM_PI * 25#, "A2_LONG"
        Next i
    Next sx
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит предварительный момент и натурные приращения Mx/T.
' Протокол хранит даже последнюю допустимую точку перед численным отказом.
Public Function RunTestCoupledTBU3(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3 = TraceTBU3Test(spansText, maximumStageText, False)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' До пятой стадии задаёт усилия, затем управляет закручиванием до
' запрошенной стадии либо до явно зафиксированной остановки.
Public Function RunTestCoupledTBU3Twist(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3Twist = TraceTBU3Test(spansText, maximumStageText, True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт начальную траекторию TBU3 рабочему алгоритму подтверждения
' первого максимума с повторным прохождением обоих плеч.
Public Function RunTestCoupledTBU3Peak(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3Peak = TraceTBU3Test(spansText, maximumStageText, True, True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет силовое и деформационное продолжение TBU3 с тремя историями.
Public Function RunTestCoupledTBU3SpatialPeak(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3SpatialPeak = TraceTBU3Test(spansText, maximumStageText, True, True, spatialHistory:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает деформацию обеих вертикальных ветвей в середине стенки
' на принятых полях с тремя пространственными историями.
' Первый аргумент принимает число интервалов или «интервалы x деления».
Public Function RunTestCoupledTBU3HoopGauge(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3HoopGauge = TraceTBU3HoopGaugeTest(spansText, maximumStageText, TBU3_REFERENCE_HOOP_SPACING)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет измерение обеих ветвей с шагом хомутов из схемы образца TBU.
' Дополнительно сохраняет точечное значение для сопоставления полей.
Public Function RunTestCoupledTBU3MeasuredHoop(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3MeasuredHoop = TraceTBU3HoopGaugeTest(spansText, maximumStageText, TBU3_MEASURED_HOOP_SPACING)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Меняет базис при общей бетонной и арматурной квадратуре TBU3.
' Использует шаг хомутов 76 мм и исходные оси номинального сечения.
Public Function RunTestCoupledTBU3CommonHoopGauge(ByVal spansText As String, ByVal maximumStageText As String) As String
    RunTestCoupledTBU3CommonHoopGauge = TraceTBU3HoopGaugeTest(spansText, maximumStageText, _
        TBU3_MEASURED_HOOP_SPACING, commonHoopQuadrature:=True)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Оценивает чувствительность TBU3 к положению осей по рис. 9 Kuan и соавторов.
' В обоих случаях сохраняет бетонную сетку, материалы и общую квадратуру хомута.
Public Function RunTestCoupledTBU3PublishedAxes(ByVal caseText As String, ByVal maximumStageText As String) As String
    On Error GoTo Failed
    Dim bottomY As Double
    Select Case LCase$(Trim$(caseText))
        Case "cover": bottomY = TBU3_REFERENCE_BOTTOM_Y
        Case "coverandbottom": bottomY = TBU3_PUBLISHED_BOTTOM_Y
        Case Else: Err.Raise 5, , "Задайте вариант Cover или CoverAndBottom."
    End Select
    RunTestCoupledTBU3PublishedAxes = TraceTBU3PublishedAxesTest(maximumStageText, bottomY, TBU3_REFERENCE_PEAK_COMPRESSION)
    Exit Function
Failed:
    RunTestCoupledTBU3PublishedAxes = "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает две деформации пика на одной модели бетона и одной геометрии TBU3.
' Значение из табл. 2 меняет калибровку НДМ, остальные законы опыта сохраняются.
Public Function RunTestCoupledTBU3CompressionPeak(ByVal caseText As String, ByVal maximumStageText As String) As String
    On Error GoTo Failed
    Dim peakCompression As Double
    Select Case LCase$(Trim$(caseText))
        Case "reference": peakCompression = TBU3_REFERENCE_PEAK_COMPRESSION
        Case "published": peakCompression = TBU3_PUBLISHED_PEAK_COMPRESSION
        Case Else: Err.Raise 5, , "Задайте вариант Reference или Published."
    End Select
    RunTestCoupledTBU3CompressionPeak = TraceTBU3PublishedAxesTest(maximumStageText, TBU3_PUBLISHED_BOTTOM_Y, peakCompression)
    Exit Function
Failed:
    RunTestCoupledTBU3CompressionPeak = "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проводит сравнение TBU3 при слое хомута 6,35 мм и заданной оси нижнего ряда.
' Бетонная сетка, базис 2x6, шаг хомута 76 мм и порядок нагружения одинаковы.
Private Function TraceTBU3PublishedAxesTest(ByVal maximumStageText As String, ByVal bottomY As Double, _
        ByVal peakCompression As Double) As String
    TraceTBU3PublishedAxesTest = TraceTBU3Test("2", maximumStageText, True, spatialHistory:=True, _
        measureHoop:=True, cellsPerSpan:=6, hoopSpacing:=TBU3_MEASURED_HOOP_SPACING, _
        commonHoopQuadrature:=True, bottomY:=bottomY, publishedCover:=True, peakCompression:=peakCompression)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает разрешение базиса и запускает опыт с заданным шагом хомутов.
Private Function TraceTBU3HoopGaugeTest(ByVal spansText As String, ByVal maximumStageText As String, _
        ByVal hoopSpacing As Double, Optional ByVal commonHoopQuadrature As Boolean = False) As String
    On Error GoTo Failed
    Dim resolution() As String: resolution = Split(spansText, "x")
    Dim cellsPerSpan As Long: cellsPerSpan = 5
    If UBound(resolution) > 1 Then Err.Raise 5, , "Задайте число интервалов или «интервалы x деления»."
    If UBound(resolution) = 1 Then cellsPerSpan = CLng(Trim$(resolution(1)))
    TraceTBU3HoopGaugeTest = TraceTBU3Test(Trim$(resolution(0)), maximumStageText, True, _
        spatialHistory:=True, measureHoop:=True, cellsPerSpan:=cellsPerSpan, hoopSpacing:=hoopSpacing, _
        commonHoopQuadrature:=commonHoopQuadrature)
    Exit Function
Failed:
    TraceTBU3HoopGaugeTest = "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает принятые точки силового и деформационного контроля отдельно.
Private Function TraceTBU3Test(ByVal spansText As String, ByVal maximumStageText As String, ByVal followTwist As Boolean, _
        Optional ByVal confirmPeak As Boolean = False, Optional ByVal spatialHistory As Boolean = False, _
        Optional ByVal measureHoop As Boolean = False, Optional ByVal cellsPerSpan As Long = 5, _
        Optional ByVal hoopSpacing As Double = TBU3_REFERENCE_HOOP_SPACING, _
        Optional ByVal commonHoopQuadrature As Boolean = False, _
        Optional ByVal bottomY As Double = TBU3_REFERENCE_BOTTOM_Y, Optional ByVal publishedCover As Boolean = False, _
        Optional ByVal peakCompression As Double = TBU3_REFERENCE_PEAK_COMPRESSION) As String
    On Error GoTo Failed
    Const EC As Double = 30000#
    Const NU As Double = 0.2
    Const FC As Double = 34.8
    Const FT As Double = 1.95
    Const MX_OFFSET As Double = -29600000#
    Const DELTA_MX As Double = -14870000#
    Const DELTA_T As Double = 10350000#
    Dim report As String, passed As Long, failures As Long, tracePath As String
    Dim spans As Long: spans = CLng(spansText)
    Dim maximumStage As Long: maximumStage = CLng(maximumStageText)
    If spans < 1 Or spans > 3 Or maximumStage < 1 Or maximumStage > 21 Then Err.Raise 5, , "Тестовые границы: базис 1–3, стадия 1–21."
    If cellsPerSpan < 4 Or cellsPerSpan > 16 Then Err.Raise 5, , "Задайте от 4 до 16 делений на интервал базиса."
    Dim forceStage As Long: forceStage = maximumStage
    If followTwist And forceStage > 5 Then forceStage = 5
    If InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) > 0 Then tracePath = ThisWorkbook.Path & "\TBU3_Trace.csv"
    AddExperimentTraceTest report, tracePath, "stage;actual_stage;Mx_kNm;T_kNm;kappa_per_m;twist_rad_per_m;hoop_utilization;steel_utilization;stress_residual_MPa;elapsed_s;status"

    Dim layout As CTransverseRebarLayout, steel As Object, section As CSectionModel
    Set section = BuildTBU3SectionTest(layout, steel, hoopSpacing, bottomY, publishedCover)
    If commonHoopQuadrature Then Set layout = CommonTBU3HoopLayoutTest(section, layout)
    Dim gaugeLeftX As Double, gaugeRightX As Double
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse, response As New CCoupledReinforcedResponse
    operators.PrepareModel section, EC, NU, spans, spans, cellsPerSpan, layout, steelModels:=steel
    If measureHoop Then
       Dim hoopPath As CGeometryPath: Set hoopPath = layout.Path(1)
        hoopPath.ProjectionBounds 1#, 0#, gaugeLeftX, gaugeRightX
        AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_X_MM;" & ExperimentNumberTest(gaugeLeftX) & ";" & _
            ExperimentNumberTest(gaugeRightX)
        AddExperimentTraceTest report, tracePath, "TBU3_HOOP_SPACING_MM;" & ExperimentNumberTest(hoopSpacing)
        If publishedCover Then
            AddExperimentTraceTest report, tracePath, "TBU3_LONG_BOTTOM_Y_MM;" & ExperimentNumberTest(bottomY)
            AddExperimentTraceTest report, tracePath, "TBU3_HOOP_CLEAR_COVER_MM;" & _
                ExperimentNumberTest(TBU3_HALF_WIDTH - gaugeRightX - layout.Diameter(1) / 2#)
            AddExperimentTraceTest report, tracePath, "TBU3_COMPRESSION_PEAK_STRAIN;" & ExperimentNumberTest(peakCompression)
        End If
        AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_BASE_MM;" & ExperimentNumberTest(-TBU3_MEASUREMENT_HALF_HEIGHT) & _
            ";" & ExperimentNumberTest(TBU3_MEASUREMENT_HALF_HEIGHT)
        AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_RESOLUTION;" & CStr(spans) & ";" & CStr(cellsPerSpan) & ";" & _
            CStr(operators.ConcretePointCount) & ";" & CStr(operators.PointCount) & ";" & CStr(operators.DegreeCount)
        AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_COLUMNS;stage;Mx_kNm;T_kNm;strain_left;strain_right"
    End If
    If commonHoopQuadrature Then RecordTBU3QuadratureTest operators, report, tracePath
    Dim solver As New CCoupledNewtonSolver, path As New CLoadPathVector, branch As New CCoupledLoadContinuation
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, FC, FT, peakCompression, 0.12, 80#, spatialHistory
    path.Initialize 0#, 0#, MX_OFFSET, DELTA_MX, 0#, 0#, 0#, DELTA_T
    branch.Initialize solver, path, 1, 12, 24, 0.0000005, 0.00000002, saveAcceptedFields:=confirmPeak

    Dim stage As Long, solved As Boolean, started As Double, reached As Double, meta As CResultMeta
    Dim field() As Double, achieved() As Double, target() As Double, errorNorm As Double
    Dim eps0 As Double, kx As Double, ky As Double, twist As Double, row As String
    For stage = 0 To forceStage
        started = Timer
        solved = branch.Advance(CDbl(stage))
        Set meta = branch.ResultMeta
        reached = branch.AcceptedLambda
        row = CStr(stage) & ";" & ExperimentNumberTest(reached)
        If branch.HasAcceptedVariableState Or branch.AcceptedOffsetFraction = 1# And solved Then
            branch.CopyAccepted field, achieved
            path.TargetSix reached, target
            operators.GeneralizedDeformation field, eps0, kx, ky, twist
            errorNorm = TBU3ForceErrorTest(achieved, target)
            If measureHoop And solved And errorNorm < 0.000005 Then _
                RecordTBU3HoopGaugeTest operators, field, reached, achieved, gaugeLeftX, gaugeRightX, spans, report, tracePath
            row = row & ";" & ExperimentNumberTest(-achieved(2) / 1E+6) & ";" & ExperimentNumberTest(achieved(4) / 1E+6) & _
                ";" & ExperimentNumberTest(-kx * 1000#) & ";" & ExperimentNumberTest(twist * 1000#) & _
                ";" & ExperimentNumberTest(response.AcceptedTransverseSteelUtilization) & ";" & ExperimentNumberTest(response.AcceptedSteelUtilization) & _
                ";" & ExperimentNumberTest(errorNorm)
            If errorNorm < 0.000005 Then passed = passed + 1 Else failures = failures + 1
        Else
            row = row & ";;;;;;;"
        End If
        row = row & ";" & ExperimentNumberTest(Timer - started)
        If solved Then
            AddExperimentTraceTest report, tracePath, row & ";Accepted"
        Else
            AddExperimentTraceTest report, tracePath, row & ";Unresolved"
            AddExperimentTraceTest report, tracePath, "DIAGNOSTICS: " & meta.ResultComment & " | " & meta.DiagnosticDetails
            Exit For
        End If
    Next stage
    AddExperimentTraceTest report, tracePath, "LAST_REQUESTED_STAGE_ACCEPTED: " & CStr(solved)
    If followTwist And branch.HasAcceptedVariableState And reached < maximumStage Then
        If confirmPeak Then
            ConfirmTBU3PeakTest operators, solver, path, branch, response, maximumStage, report, tracePath, passed, failures
        Else
            ContinueTBU3ByTwistTest operators, solver, path, branch, response, maximumStage, report, tracePath, passed, failures, _
                measureHoop, gaugeLeftX, gaugeRightX, spans
        End If
    End If
    If passed = 0 Then failures = failures + 1
    TraceTBU3Test = report & "TOTAL_TBU3_FORCE_EQUILIBRIUM: passed=" & passed & "; failed=" & failures
    Exit Function
Failed:
    TraceTBU3Test = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Делит одну замкнутую ось TBU3 по объединению узлов базисов 2 и 3.
' Штатная квадратура использует эти границы и для базиса 1.
Private Function CommonTBU3HoopLayoutTest(ByVal section As CSectionModel, _
        ByVal layout As CTransverseRebarLayout) As CTransverseRebarLayout
    Dim original As CGeometryPath: Set original = layout.Path(1)
    Dim axis As New CGeometryPath: axis.Initialize original.ID
    Dim basisTwo As New CCoupledSectionQuadrature, basisThree As New CCoupledSectionQuadrature
    basisTwo.Initialize section, 2, 2
    basisThree.Initialize section, 3, 3
    Dim edge As TRegionEdge, part As TRegionEdge, cuts() As Double, extraCuts() As Double
    Dim i As Long, j As Long, count As Long, extraCount As Long
    For i = 1 To original.SegmentCount
        original.CopySegment i, edge
        basisTwo.PathCuts edge, cuts, count
        basisThree.PathCuts edge, extraCuts, extraCount
        For j = 1 To extraCount: modGeometryPrimitives.AddScalar cuts, count, extraCuts(j): Next j
        modGeometryPrimitives.SortScalars cuts, count
        For j = 2 To count
            modGeometryPrimitives.SubEdge edge, cuts(j - 1), cuts(j), part
            axis.Append original.SegmentID(i) & "_" & CStr(j - 1), part
        Next j
    Next i
    axis.Seal True
    Dim result As New CTransverseRebarLayout
    result.AddGroup axis, layout.Diameter(1), layout.Spacing(1), layout.SteelClass(1), layout.SourceReference(1)
    Set CommonTBU3HoopLayoutTest = result
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает фактические координаты, веса и направления материальных
' точек в том порядке, в котором их получает решатель.
Private Sub RecordTBU3QuadratureTest(ByVal operators As CCoupledElasticState, ByRef report As String, ByVal tracePath As String)
    Dim index As Long, x As Double, y As Double, weight As Double, row As String, group As Long
    Dim direction(1 To 6) As Double, material As String
    For index = 1 To operators.PointCount
        operators.Point index, x, y, weight
        group = 0: material = "Concrete"
        If index > operators.ConcretePointCount Then
            group = operators.TransverseGroupAt(index)
            material = operators.SteelClassAt(index)
            operators.SteelProjection index, direction
        End If
        row = "TBU3_QUADRATURE;" & CStr(index) & ";" & material & ";" & CStr(group) & ";" & _
            ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(weight) & ";" & _
            ExperimentNumberTest(direction(1)) & ";" & ExperimentNumberTest(direction(2)) & ";" & _
            ExperimentNumberTest(direction(3)) & ";" & ExperimentNumberTest(direction(4))
        AddExperimentTraceTest report, tracePath, row
    Next index
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает продольные деформации обеих вертикальных ветвей в центре
' и на базе измерения. Читает кинематику из принятого поля.
Private Sub RecordTBU3HoopGaugeTest(ByVal operators As CCoupledElasticState, ByRef field() As Double, _
        ByVal stage As Double, ByRef achieved() As Double, ByVal gaugeLeftX As Double, ByVal gaugeRightX As Double, _
        ByVal verticalSpans As Long, ByRef report As String, ByVal tracePath As String)
    Dim strain(1 To 6) As Double, unusedWarping As Double, leftGauge As Double
    operators.KinematicsAt gaugeLeftX, 0#, field, strain, unusedWarping
    leftGauge = strain(2) ' Вертикальная прямая ветвь, направление ±y даёт одну и ту же проекцию.
    operators.KinematicsAt gaugeRightX, 0#, field, strain, unusedWarping
    AddExperimentTraceTest report, tracePath, "TBU3_GAUGE;" & ExperimentNumberTest(stage) & ";" & _
        ExperimentNumberTest(-achieved(2) / 1E+6) & ";" & ExperimentNumberTest(achieved(4) / 1E+6) & ";" & _
        ExperimentNumberTest(leftGauge) & ";" & ExperimentNumberTest(strain(2))
    AddExperimentTraceTest report, tracePath, "TBU3_GAUGE_AVERAGE;" & ExperimentNumberTest(stage) & ";" & _
        ExperimentNumberTest(-achieved(2) / 1E+6) & ";" & ExperimentNumberTest(achieved(4) / 1E+6) & ";" & _
        ExperimentNumberTest(MeanTBU3GaugeStrainTest(operators, field, gaugeLeftX, verticalSpans)) & ";" & _
        ExperimentNumberTest(MeanTBU3GaugeStrainTest(operators, field, gaugeRightX, verticalSpans))
    Dim row As String, component As Long
    row = "TBU3_INTEGRALS;" & ExperimentNumberTest(stage)
    For component = 1 To 6: row = row & ";" & ExperimentNumberTest(achieved(component)): Next component
    AddExperimentTraceTest report, tracePath, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Осредняет εyy по двум соседним базам 76 мм в середине стенки.
' На каждом интервале кубического сплайна производная квадратична.
Private Function MeanTBU3GaugeStrainTest(ByVal operators As CCoupledElasticState, ByRef field() As Double, _
        ByVal x As Double, ByVal verticalSpans As Long) As Double
    Const GAUSS_ABSCISSA As Double = 0.577350269189626 ' Узел двухточечной квадратуры [-1, 1], вес 1.
    Dim lower As Double: lower = -TBU3_MEASUREMENT_HALF_HEIGHT
    Dim upper As Double, center As Double, halfWidth As Double, integral As Double
    Dim strain(1 To 6) As Double, unusedWarping As Double, span As Long
    For span = 1 To verticalSpans
        upper = GeomMin(TBU3_MEASUREMENT_HALF_HEIGHT, TBU3_HALF_HEIGHT * (2# * span / verticalSpans - 1#))
        If upper > lower Then
            center = 0.5 * (lower + upper): halfWidth = 0.5 * (upper - lower)
            operators.KinematicsAt x, center - GAUSS_ABSCISSA * halfWidth, field, strain, unusedWarping
            integral = integral + halfWidth * strain(2)
            operators.KinematicsAt x, center + GAUSS_ABSCISSA * halfWidth, field, strain, unusedWarping
            integral = integral + halfWidth * strain(2)
            lower = upper
        End If
        If lower >= TBU3_MEASUREMENT_HALF_HEIGHT Then Exit For
    Next span
    MeanTBU3GaugeStrainTest = integral / (2# * TBU3_MEASUREMENT_HALF_HEIGHT)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подключает одну или три истории к одним операторам и параметрам опыта.
' Центральная история используется для наблюдений в протоколах.
Private Sub InitializeExperimentSolverTest(ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByVal concrete As CCoupledConcreteResponse, ByVal center As CCoupledReinforcedResponse, ByVal steel As Object, _
        ByVal ec As Double, ByVal nu As Double, ByVal fc As Double, ByVal ft As Double, ByVal peakStrain As Double, _
        ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean)
    Const LOCALIZATION_LENGTH As Double = 125# ' мм, принятое значение во всех трёх сопоставлениях.
    Dim pointCount As Long: pointCount = operators.PointCount
    Dim fc0 As Double: fc0 = 0.6 * fc ' Начальная прочность сжатия в материальной модели.
    concrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    center.Initialize operators, concrete, steel
    If Not spatialHistory Then
        solver.Initialize operators, center, ec
        Exit Sub
    End If
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    plusConcrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize pointCount, ec, nu, fc0, fc, ft, peakStrain, gt, gc, LOCALIZATION_LENGTH
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, center, ec, plusSide, minusSide
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет рабочий критерий максимума отдельно от наблюдаемого падения
' в диагностических точках. Сохраняет статус, точность и интегралы пика.
Private Sub ConfirmTBU3PeakTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByVal path As CLoadPathVector, ByVal branch As CCoupledLoadContinuation, ByVal response As CCoupledReinforcedResponse, _
        ByVal requestedStage As Long, ByRef report As String, ByVal tracePath As String, ByRef passed As Long, ByRef failures As Long)
    Const STAGE_TOLERANCE As Double = 0.005 ' 0,052 кН·м на траектории кручения TBU3.
    Dim baseLoad() As Double, direction() As Double, accepted() As Double, resultants() As Double
    path.Components baseLoad, direction
    branch.CopyAccepted accepted, resultants
    Dim controlled As New CCoupledDeformationContinuation
    AddExperimentTraceTest report, tracePath, "PEAK_SEARCH_STARTED: " & ExperimentNumberTest(branch.AcceptedLambda)
    controlled.Trace solver, response, baseLoad, direction, branch.AcceptedFields, branch.PreviousAcceptedLambda, _
        branch.AcceptedLambda, resultants, CDbl(requestedStage), STAGE_TOLERANCE, 24, 0.0000005, 0.00000002

    Dim meta As CResultMeta: Set meta = controlled.ResultMeta
    AddExperimentTraceTest report, tracePath, "PEAK_DIAGNOSTICS: " & meta.ResultComment & " | " & meta.DiagnosticDetails
    AddExperimentTraceTest report, tracePath, "PEAK_BEST_ADMISSIBLE_STAGE: " & ExperimentNumberTest(controlled.BestAdmissibleLambda)
    Dim peak As Double, accuracy As Double, designVerified As Boolean
    If Not controlled.CopyPeak(peak, accuracy, designVerified) Then
        AddExperimentTraceTest report, tracePath, "PEAK_CONFIRMED: False"
        Exit Sub
    End If
    AddExperimentTraceTest report, tracePath, "PEAK_CONFIRMED: True"
    Dim fields As Collection
    If Not controlled.CopyLimitState(fields, resultants) Then
        failures = failures + 1
        Exit Sub
    End If
    Dim target() As Double, eps0 As Double, kx As Double, ky As Double, twist As Double, errorNorm As Double
    path.TargetSix peak, target
    accepted = fields(fields.Count)
    operators.GeneralizedDeformation accepted, eps0, kx, ky, twist
    errorNorm = TBU3ForceErrorTest(resultants, target)
    AddExperimentTraceTest report, tracePath, "PEAK_STAGE_M_T_TWIST_ERROR_ACCURACY;" & ExperimentNumberTest(peak) & ";" & _
        ExperimentNumberTest(-resultants(2) / 1E+6) & ";" & ExperimentNumberTest(resultants(4) / 1E+6) & ";" & _
        ExperimentNumberTest(twist * 1000#) & ";" & ExperimentNumberTest(errorNorm) & ";" & ExperimentNumberTest(accuracy)
    If errorNorm < 0.000005 And accuracy <= STAGE_TOLERANCE Then passed = passed + 1 Else failures = failures + 1
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет переход через отказ силового шага по управляемому углу,
' сохраняя постоянный момент, отношение приращений и принятую историю.
Private Sub ContinueTBU3ByTwistTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByVal path As CLoadPathVector, ByVal branch As CCoupledLoadContinuation, ByVal response As CCoupledReinforcedResponse, _
        ByVal requestedStage As Long, ByRef report As String, ByVal tracePath As String, ByRef passed As Long, ByRef failures As Long, _
        ByVal measureHoop As Boolean, ByVal gaugeLeftX As Double, ByVal gaugeRightX As Double, ByVal verticalSpans As Long)
    Const MAX_ATTEMPTS As Long = 200 ' Лимит опытного прогона, включая уменьшения шага.
    Dim baseLoad() As Double, direction() As Double, projection() As Double
    path.Components baseLoad, direction
    ReDim projection(1 To operators.DegreeCount): projection(4) = 1#
    Dim field() As Double, achieved() As Double, target() As Double, eps0 As Double, kx As Double, ky As Double, twist As Double
    branch.CopyAccepted field, achieved
    operators.GeneralizedDeformation field, eps0, kx, ky, twist
    If twist <= 0# Then
        AddExperimentTraceTest report, tracePath, "TWIST_STOP: NonpositiveInitialTwist"
        Exit Sub
    End If
    Dim increment As Double, initialIncrement As Double, length As Double, reached As Double, coordinate As Double
    length = field(4) / twist ' Обобщённая координата равна относительному углу, умноженному на длину масштаба.
    initialIncrement = 0.0002 * length / 1000#
    increment = initialIncrement: reached = branch.AcceptedLambda: coordinate = field(4)
    Dim attempt As Long, trialLambda As Double, errorNorm As Double, row As String, started As Double, stopReason As String
    stopReason = "AttemptLimit"
    AddExperimentTraceTest report, tracePath, "TWIST_REQUESTED_STAGE: " & CStr(requestedStage)
    For attempt = 1 To MAX_ATTEMPTS
        started = Timer
        If solver.TryDeformationStep(baseLoad, direction, projection, coordinate + increment, reached, trialLambda, _
                0.0000005, 0.00000002, 24) Then
            solver.CopyTrial field, achieved: solver.AcceptStep
            coordinate = field(4): reached = trialLambda
            path.TargetSix reached, target
            operators.GeneralizedDeformation field, eps0, kx, ky, twist
            errorNorm = TBU3ForceErrorTest(achieved, target)
            If measureHoop And errorNorm < 0.000005 Then _
                RecordTBU3HoopGaugeTest operators, field, reached, achieved, gaugeLeftX, gaugeRightX, verticalSpans, report, tracePath
            row = "Twist" & CStr(attempt) & ";" & ExperimentNumberTest(reached) & ";" & ExperimentNumberTest(-achieved(2) / 1E+6) & _
                ";" & ExperimentNumberTest(achieved(4) / 1E+6) & ";" & ExperimentNumberTest(-kx * 1000#) & ";" & ExperimentNumberTest(twist * 1000#) & _
                ";" & ExperimentNumberTest(response.AcceptedTransverseSteelUtilization) & ";" & ExperimentNumberTest(response.AcceptedSteelUtilization) & _
                ";" & ExperimentNumberTest(errorNorm) & ";" & ExperimentNumberTest(Timer - started) & ";Accepted"
            AddExperimentTraceTest report, tracePath, row
            If errorNorm < 0.000005 Then passed = passed + 1 Else failures = failures + 1
            If reached >= requestedStage Then
                stopReason = "TargetReached"
                Exit For
            End If
            If increment < initialIncrement Then increment = increment * 1.25
            If increment > initialIncrement Then increment = initialIncrement
        Else
            AddExperimentTraceTest report, tracePath, "TWIST_REJECTED: " & CStr(attempt) & " | " & ExperimentNumberTest(Timer - started) & _
                " | " & solver.ResultMeta.ResultComment & " | " & solver.ResultMeta.DiagnosticDetails
            increment = increment * 0.5
            If increment < initialIncrement / 32# Then
                stopReason = "MinimumTwistIncrement"
                Exit For
            End If
        End If
    Next attempt
    AddExperimentTraceTest report, tracePath, "TWIST_CONTROL_REACHED_STAGE: " & ExperimentNumberTest(reached)
    AddExperimentTraceTest report, tracePath, "TWIST_STOP: " & stopReason
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выдаёт напряжения однородной коробки при шести ненулевых усилиях для
' сравнения с независимым треугольным КЭ-расчётом sectionproperties.
Public Function RunTestCoupledTBU3Elastic() As String
    On Error GoTo Failed
    Const E As Double = 30000#
    Const G As Double = E / 2# ' В обеих программах контроль проводится при нулевом коэффициенте Пуассона.
    Const FORCE As Double = 100000#
    Const MX As Double = 15000000#
    Const MY As Double = -11000000#
    Const TORQUE As Double = 10000000#
    Const QX As Double = 28000#
    Const QY As Double = -19000#
    Dim section As CSectionModel: Set section = BuildTBU3BoxTest()
    Dim points As Variant: points = Array(Array(0#, 167#), Array(0#, -167#), Array(216#, 0#), Array(-216#, 0#), _
        Array(210#, 170#), Array(-210#, -170#))
    Dim spans As Long, point As Variant, passed As Long, failed As Long, report As String
    Dim solver As CCoupledElasticState, deformation() As Double, resultants() As Double, stress() As Double
    Dim field() As Double, raw As Variant, strain(1 To 6) As Double, warping As Double
    Dim path As New CLoadPathVector, target() As Double
    path.Initialize 0#, FORCE, 0#, MX, 0#, MY, 0#, TORQUE, 0#, QX, 0#, QY
    path.TargetSix 1#, target
    For spans = 1 To 3
        Set solver = New CCoupledElasticState
        solver.PrepareModel section, E, 0#, spans, spans, 7
        If solver.Solve(FORCE, MX, MY, TORQUE, QX, QY, deformation, resultants, stress, raw) Then
            field = raw
            report = report & "ELASTIC_RIGIDITY;" & CStr(spans) & ";" & ExperimentNumberTest(TORQUE / (G * deformation(4))) & vbCrLf
            If TBU3ForceErrorTest(resultants, target) < 0.0000001 Then passed = passed + 1 Else failed = failed + 1
            For Each point In points
                solver.KinematicsAt CDbl(point(0)), CDbl(point(1)), field, strain, warping
                report = report & "ELASTIC_STRESS;" & CStr(spans) & ";" & ExperimentNumberTest(CDbl(point(0))) & ";" & ExperimentNumberTest(CDbl(point(1))) & _
                    ";" & ExperimentNumberTest(E * strain(3)) & ";" & ExperimentNumberTest(G * strain(5)) & ";" & ExperimentNumberTest(G * strain(6)) & vbCrLf
            Next point
        Else
            failed = failed + 1
            report = report & "FAIL: spans=" & CStr(spans) & " " & solver.ResultMeta.ResultComment & vbCrLf
        End If
    Next spans
    RunTestCoupledTBU3Elastic = report & "TOTAL_TBU3_ELASTIC_EQUILIBRIUM: passed=" & passed & "; failed=" & failed
    Exit Function
Failed:
    RunTestCoupledTBU3Elastic = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит номинальную коробку и измеренные площади стали. Для контроля
' чувствительности принимает положение нижнего ряда и слой хомута по публикации.
' Малая длина стыка хомута отдельно не моделируется.
Private Function BuildTBU3SectionTest(ByRef layout As CTransverseRebarLayout, ByRef steel As Object, _
        ByVal hoopSpacing As Double, ByVal bottomY As Double, ByVal publishedCover As Boolean) As CSectionModel
    Dim section As CSectionModel: Set section = BuildTBU3BoxTest()

    Dim i As Long, dx As Double
    For i = -3 To 3
        dx = 206# * CDbl(i) / 3#
        section.AddRebarElement dx, bottomY, Sqr(4# * 510# / GEOM_PI), 510#, "TBU3_8"
    Next i
    For i = -1 To 1
        section.AddRebarElement 216# * i, 167#, Sqr(4# * 129# / GEOM_PI), 129#, "TBU3_4"
        section.AddRebarElement -218#, 78# * i, Sqr(4# * 71# / GEOM_PI), 71#, "TBU3_3"
        section.AddRebarElement 218#, 78# * i, Sqr(4# * 71# / GEOM_PI), 71#, "TBU3_3"
    Next i
    Set layout = New CTransverseRebarLayout
    Dim diameter As Double: diameter = Sqr(4# * 129# / GEOM_PI)
    Dim cover As Double: cover = 32# - diameter / 2# ' Исходная ось отстоит от контура бетона на 32 мм.
    If publishedCover Then cover = TBU3_PUBLISHED_HOOP_COVER
    layout.AddContourGroup section, "TBU3_HOOP", vbNullString, diameter, hoopSpacing, cover, "TBU3_HOOP"

    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "TBU3_8", ExperimentBilinearSteelTest(194200#, 436#, 9000#)
    steel.Add "TBU3_4", ExperimentBilinearSteelTest(201900#, 393#, 4900#)
    steel.Add "TBU3_3", ExperimentBilinearSteelTest(205100#, 552#, 9000#)
    steel.Add "TBU3_HOOP", ExperimentBilinearSteelTest(198500#, 379#, 5200#)
    Set BuildTBU3SectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Использует одинаковые контуры для упругой и нелинейной постановок.
Private Function BuildTBU3BoxTest() As CSectionModel
    Dim query As New CSectionGeometryQuery, outer As CConcreteRegion, inner As CConcreteRegion, geometry As New CGeometryRegion
    Set outer = query.RegionFromPath(query.AdjacentRectangles("TBU3_Outer", Array(Array(-TBU3_HALF_WIDTH, -TBU3_HALF_HEIGHT, 2# * TBU3_HALF_WIDTH, 2# * TBU3_HALF_HEIGHT))))
    Set inner = query.RegionFromPath(query.AdjacentRectangles("TBU3_Opening", Array(Array(-178#, -129#, 356#, 258#))))
    geometry.Initialize query.SubtractContainedRegion(outer, inner)
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh geometry, 20#, 18#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    geometry.BuildContours section.Contours
    Set BuildTBU3BoxTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Двухлинейная аппроксимация измеренной стали. После текучести модуль
' упрочнения включается сразу. Предел 0,05 принят только для диагностики.
Private Function ExperimentBilinearSteelTest(ByVal modulus As Double, ByVal strength As Double, ByVal hardening As Double) As CCoupledSteelModel
    Dim steel As New CCoupledSteelModel
    steel.Initialize modulus, strength, strength, hardening, hardening, 0.05, 0.05
    Set ExperimentBilinearSteelTest = steel
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Приводит остатки шести усилий к МПа по номинальной площади коробки.
Private Function TBU3ForceErrorTest(ByRef achieved() As Double, ByRef target() As Double) As Double
    Const AREA As Double = 508# * 410# - 356# * 258#
    Dim i As Long, difference As Double
    For i = 1 To 6
        difference = Abs(achieved(i) - target(i)) / AREA
        If i >= 2 And i <= 4 Then difference = difference / 508#
        If difference > TBU3ForceErrorTest Then TBU3ForceErrorTest = difference
    Next i
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Русская локаль Excel не меняет десятичную точку в машинном протоколе.
Private Function ExperimentNumberTest(ByVal value As Double) As String
    ExperimentNumberTest = Trim$(Str$(value))
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Отмечает завершённую стадию также на диске, чтобы длительный контроль
' можно было наблюдать без обращения к пользовательскому экземпляру Excel.
Private Sub AddExperimentTraceTest(ByRef report As String, ByVal path As String, ByVal row As String)
    report = report & row & vbCrLf
    If Len(path) = 0 Then Exit Sub
    Dim file As Integer: file = FreeFile
    Open path For Append As #file
    Print #file, row
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Прослеживает испытание MVT2. Сначала наращивается чистое кручение,
' затем при неизменном кручении растут поперечная сила и изгиб.
' Предельные деформации материала не интерпретируются как механизм опыта.
Public Function RunTestCoupledWangMVT2Follow(ByVal specimen As String, ByVal maximumShearText As String) As String
    On Error GoTo Failed
    Const NU As Double = 0.2
    Const EC As Double = 30000# ' Допущение. Измеренного модуля бетона нет в исходных данных контрольного прогона.
    Const PEAK_STRAIN As Double = 0.0022
    Dim Torque As Double ' Н·мм, заданное постоянное кручение после предварительного участка.
    Const LEVER As Double = 600# ' мм, расстояние до середины от опоры в критическом полупролёте.
    Const REFERENCE_SHEAR As Double = 1000# ' Н на единицу множителя, который численно равен Qy в кН.
    Const NOMINAL_STEPS As Long = 8 ' Один и тот же план относительных приращений для двух ветвей.
    Dim report As String, tracePath As String, passed As Long, failed As Long, prefixSaved As Long
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для испытания MVT2 нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangPairedCold.csv"
    Const spans As Long = 1
    Dim maximumShear As Double: maximumShear = Val(maximumShearText)
    Select Case specimen
        Case "MVT2": Torque = 10510000#
        Case Else: Err.Raise 5, , "Укажите контрольный образец MVT2."
    End Select
    If maximumShear <> 40# Then _
        Err.Raise 5, , "Цель продолжения — 40 кН."
    AddExperimentTraceTest report, tracePath, "WANG_PAIR_CASE;" & specimen & ";" & _
        ExperimentNumberTest(Torque / 1000000#) & ";" & ExperimentNumberTest(maximumShear)

    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    Dim fc As Double, ft As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#) ' Восстановление из Nm/Ag=0,3fc серии NMVT с тем же бетоном.
    ft = 0.302 * fc ^ (2# / 3#): gt = 0.073 * fc ^ 0.18: gc = (fc / ft) ^ 2 * gt
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse, response As New CCoupledReinforcedResponse
    Dim solver As New CCoupledNewtonSolver, shearX() As Double, shearY() As Double
    operators.PrepareModel section, EC, NU, spans, spans, 5, transverse, steelModels:=steel
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, ft, PEAK_STRAIN, gt, gc, True
    operators.MeanShearProjections shearX, shearY

    AddExperimentTraceTest report, tracePath, "MVT2_GEOMETRY;240;240;4;16;84;8;60;20;96;" & CStr(spans) & ";" & _
        CStr(operators.ConcretePointCount) & ";" & CStr(operators.PointCount) & ";" & CStr(operators.DegreeCount)
    AddExperimentTraceTest report, tracePath, "MVT2_MATERIAL;" & ExperimentNumberTest(EC) & ";" & ExperimentNumberTest(NU) & ";" & _
        ExperimentNumberTest(fc) & ";" & ExperimentNumberTest(ft) & ";" & ExperimentNumberTest(PEAK_STRAIN) & ";" & _
        ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc) & ";125;200000;498;450;0"
    AddExperimentTraceTest report, tracePath, "WANG_PAIR_REFERENCE;MVT1_Vmax_kN;92;MVT2_Vmax_kN;80;lever_mm;600"
    AddExperimentTraceTest report, tracePath, "MVT2_STATE_COLUMNS;stage;target;reached;N_kN;Mx_kNm;My_kNm;T_kNm;Qx_kN;Qy_kN;" & _
        "eps0;kx_rad_m;ky_rad_m;twist_rad_m;gamma_yz;long_abs_MPa;hoop_abs_MPa;long_at_yield;hoop_at_yield;" & _
        "tension_energy;compression_energy;min_principal_MPa;max_principal_MPa;residual_MPa"

    Dim path As New CLoadPathVector, branch As New CCoupledLoadContinuation
    path.Initialize 0#, 0#, 0#, LEVER * REFERENCE_SHEAR, 0#, 0#, TORQUE, 0#, 0#, 0#, 0#, REFERENCE_SHEAR
    branch.Initialize solver, path, NOMINAL_STEPS, 44, 26, 0.0000005, 0.0000005, True
    Dim started As Double: started = Timer
    Dim field() As Double, resultants() As Double, expected() As Double
    Dim shear As Variant, requested As Double, reached As Double, elapsed As Double, ok As Boolean, errorNorm As Double
    ok = branch.Advance(0#)
    RecordWangPairStatusTest branch, specimen, "Offset", Torque / 1000000#, _
        branch.AcceptedOffsetFraction * Torque / 1000000#, ok, report, tracePath
    If Not ok Then
        prefixSaved = branch.SavedFieldCount
        If prefixSaved > 0 Then
            branch.CopyAccepted field, resultants
            ReDim expected(1 To 6): expected(4) = branch.AcceptedOffsetFraction * Torque
            errorNorm = operators.ResultantResidualNorm(resultants, expected)
            RecordWangMVT2StateTest operators, concrete, response, field, resultants, shearY, _
                "OffsetPartial", Torque / 1000000#, resultants(4) / 1000000#, resultants(4), errorNorm, report, tracePath
        End If
        AddExperimentTraceTest report, tracePath, "MVT2_STOP;Torsion;" & ExperimentNumberTest(branch.AcceptedOffsetFraction) & ";" & _
            branch.ResultMeta.ResultComment & " | " & branch.ResultMeta.DiagnosticDetails
        If prefixSaved > 0 And errorNorm < 0.000005 Then passed = passed + 1 Else failed = failed + 1
    Else
        prefixSaved = branch.SavedFieldCount
        branch.CopyAccepted field, resultants
        path.TargetSix 0#, expected
        RecordWangMVT2StateTest operators, concrete, response, field, resultants, shearY, _
            "Offset", TORQUE / 1000000#, resultants(4) / 1000000#, resultants(4), _
            operators.ResultantResidualNorm(resultants, expected), report, tracePath
        For Each shear In Array(15#, 22.11622, 25#, 30#, 40#)
            requested = GeomMin(CDbl(shear), maximumShear)
            ok = branch.Advance(requested)
            reached = branch.AcceptedLambda
            RecordWangPairStatusTest branch, specimen, "Combined", requested, reached, ok, report, tracePath
            branch.CopyAccepted field, resultants
            path.TargetSix reached, expected
            errorNorm = operators.ResultantResidualNorm(resultants, expected)
            RecordWangMVT2StateTest operators, concrete, response, field, resultants, shearY, _
                "Combined", requested, reached, resultants(4), errorNorm, report, tracePath
            AddExperimentTraceTest report, tracePath, "MVT2_STAGE;" & ExperimentNumberTest(requested) & ";" & _
                ExperimentNumberTest(reached) & ";" & CStr(branch.RejectedAttempts) & ";" & CStr(branch.SavedFieldCount)
            If Not ok Then
                AddExperimentTraceTest report, tracePath, "MVT2_STOP;Combined;" & ExperimentNumberTest(reached) & ";" & _
                    branch.ResultMeta.ResultComment & " | " & branch.ResultMeta.DiagnosticDetails
                If errorNorm < 0.000005 Then passed = passed + 1 Else failed = failed + 1
                If requested = 30# Then FollowWangControlledTest branch, solver, operators, path, response, Torque, report, tracePath
                Exit For
            End If
            If reached = requested And errorNorm < 0.000005 Then passed = passed + 1 Else failed = failed + 1
            If requested = maximumShear Then
                AddExperimentTraceTest report, tracePath, "MVT2_STOP;TargetReached;" & ExperimentNumberTest(reached)
                Exit For
            End If
        Next shear
    End If
    elapsed = Timer - started: If elapsed < 0# Then elapsed = elapsed + 86400#
    AddExperimentTraceTest report, tracePath, "MVT2_LOAD_SECONDS;" & ExperimentNumberTest(elapsed)

    ' После законченной ветви повторяем её фактические поля кручения с исходной историей.
    If prefixSaved > 0 Then
        If ReplayWangMVT2TorsionTest(solver, branch, operators, concrete, response, shearY, prefixSaved, TORQUE, report, tracePath) Then
            passed = passed + 1
        Else
            failed = failed + 1
        End If
    Else
        AddExperimentTraceTest report, tracePath, "MVT2_CRACK;NoAcceptedTorsionStates"
    End If
    RunTestCoupledWangMVT2Follow = report & "TOTAL_COUPLED_WANG_MVT2_FOLLOW: passed=" & CStr(passed) & "; failed=" & CStr(failed)
    Exit Function
Failed:
    AddExperimentTraceTest report, tracePath, "RUNTIME ERROR: " & Err.Source & " " & Err.Description
    RunTestCoupledWangMVT2Follow = report
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Собирает сечение 240×240 мм. Положение осей стержней номинальное,
' радиус загиба хомута и фактическая форма углов не опубликованы.
Private Function BuildWangMVT2SectionTest(ByRef transverse As CTransverseRebarLayout, ByRef steel As Object) As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("MVT2_Outer", Array(Array(-120#, -120#, 240#, 240#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Dim xSign As Long, ySign As Long
    For xSign = -1 To 1 Step 2
        For ySign = -1 To 1 Step 2
            section.AddRebarElement 84# * xSign, 84# * ySign, 16#, GEOM_PI * 64#, "MVT2_LONG"
        Next ySign
    Next xSign
    Set transverse = New CTransverseRebarLayout
    transverse.AddContourGroup section, "MVT2_HOOP", vbNullString, 8#, 60#, 20#, "MVT2_HOOP"
    Set steel = CreateObject("Scripting.Dictionary")
    steel.Add "MVT2_LONG", ExperimentBilinearSteelTest(200000#, 498#, 0#)
    steel.Add "MVT2_HOOP", ExperimentBilinearSteelTest(200000#, 450#, 0#)
    Set BuildWangMVT2SectionTest = section
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' На точно принятом силовом префиксе определяет скобку по положительной
' энергии растяжения. Это показатель модели, сравнимый со стадией первой трещины.
Private Function ReplayWangMVT2TorsionTest(ByVal solver As CCoupledNewtonSolver, ByVal branch As CCoupledLoadContinuation, _
        ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, ByVal response As CCoupledReinforcedResponse, _
        ByRef shearY() As Double, ByVal count As Long, ByVal maximumTorque As Double, ByRef report As String, ByVal tracePath As String) As Boolean
    Const TENSION_MARKER As Double = 0.000001
    Dim index As Long, point As Long, offsetFraction As Double, scaleValue As Double
    Dim previousTorque As Double, maximumTension As Double, tension As Double, compression As Double, found As Boolean
    Dim trace As CCoupledLoadTrace, accepted As Collection, field() As Double, expected(1 To 6) As Double
    Set trace = branch.SavedTrace: Set accepted = branch.AcceptedFields
    If trace Is Nothing Or accepted Is Nothing Then Exit Function
    If trace.Count < count Or accepted.Count < count Then Exit Function
    For index = 1 To count
        trace.ReadPoint index, offsetFraction, scaleValue
        If scaleValue <> 0# Then Exit Function
        If Not solver.ReplayAcceptedFields(accepted, index) Then
            AddExperimentTraceTest report, tracePath, "MVT2_REPLAY_STOP;" & CStr(index) & ";" & solver.ResultMeta.DiagnosticDetails
            Exit Function
        End If
        branch.CopySavedField index, field
        maximumTension = 0#
        For point = 1 To operators.ConcretePointCount
            concrete.AcceptedPointDamage point, tension, compression
            maximumTension = GeomMax(maximumTension, tension)
        Next point
        expected(4) = maximumTorque * offsetFraction ' Принятая целевая нагрузка при повторе поля, не заново интегрированный результат.
        RecordWangMVT2StateTest operators, concrete, response, field, expected, shearY, _
            "TorsionReplayTarget", expected(4) / 1000000#, expected(4) / 1000000#, expected(4), -1#, report, tracePath
        If Not found And maximumTension > TENSION_MARKER Then
            AddExperimentTraceTest report, tracePath, "MVT2_CRACK;TensileEnergyBracket;" & ExperimentNumberTest(previousTorque) & ";" & _
                ExperimentNumberTest(expected(4) / 1000000#) & ";" & ExperimentNumberTest(TENSION_MARKER)
            found = True
        End If
        previousTorque = expected(4) / 1000000#
    Next index
    If Not found Then AddExperimentTraceTest report, tracePath, "MVT2_CRACK;MarkerNotReached;" & ExperimentNumberTest(previousTorque)
    ReplayWangMVT2TorsionTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает подтверждённые нагрузки, деформации и материалы центральной
' квадратуры. Отрицательная невязка обозначает целевую нагрузку при повторе.
Private Sub RecordWangMVT2StateTest(ByVal operators As CCoupledElasticState, ByVal concrete As CCoupledConcreteResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef field() As Double, ByRef resultants() As Double, ByRef shearY() As Double, _
        ByVal stage As String, ByVal requested As Double, ByVal reached As Double, ByVal torque As Double, ByVal residual As Double, _
        ByRef report As String, ByVal tracePath As String)
    Const LONG_YIELD As Double = 498#
    Const HOOP_YIELD As Double = 450#
    Dim point As Long, i As Long, gamma As Double, eps0 As Double, kappaX As Double, kappaY As Double, twist As Double
    Dim maxLong As Double, maxHoop As Double, atLong As Long, atHoop As Long, steelStress As Double
    Dim maximumTension As Double, maximumCompression As Double, tension As Double, compression As Double
    Dim minPrincipal As Double, maxPrincipal As Double, trace As Double, q As Double, high As Double, mid As Double, low As Double
    Dim stress(1 To 6) As Double
    operators.GeneralizedDeformation field, eps0, kappaX, kappaY, twist
    For i = 1 To UBound(shearY): gamma = gamma + shearY(i) * field(i): Next i
    For point = 1 To operators.PointCount
        If point <= operators.ConcretePointCount Then
            concrete.AcceptedPointDamage point, tension, compression
            maximumTension = GeomMax(maximumTension, tension): maximumCompression = GeomMax(maximumCompression, compression)
            concrete.CopyAcceptedStress point, stress
            CoupledStressInvariants stress, trace, q, high, mid, low
            If point = 1 Or low < minPrincipal Then minPrincipal = low
            If point = 1 Or high > maxPrincipal Then maxPrincipal = high
        Else
            steelStress = Abs(response.AcceptedSteelStress(point))
            If operators.TransverseGroupAt(point) > 0 Then
                maxHoop = GeomMax(maxHoop, steelStress)
                If steelStress >= HOOP_YIELD * (1# - 0.00000001) Then atHoop = atHoop + 1
            Else
                maxLong = GeomMax(maxLong, steelStress)
                If steelStress >= LONG_YIELD * (1# - 0.00000001) Then atLong = atLong + 1
            End If
        End If
    Next point
    AddExperimentTraceTest report, tracePath, "MVT2_STATE;" & stage & ";" & ExperimentNumberTest(requested) & ";" & _
        ExperimentNumberTest(reached) & ";" & ExperimentNumberTest(resultants(1) / 1000#) & ";" & ExperimentNumberTest(resultants(2) / 1000000#) & ";" & _
        ExperimentNumberTest(resultants(3) / 1000000#) & ";" & ExperimentNumberTest(torque / 1000000#) & ";" & _
        ExperimentNumberTest(resultants(5) / 1000#) & ";" & ExperimentNumberTest(resultants(6) / 1000#) & ";" & _
        ExperimentNumberTest(eps0) & ";" & ExperimentNumberTest(1000# * kappaX) & ";" & ExperimentNumberTest(1000# * kappaY) & ";" & _
        ExperimentNumberTest(1000# * twist) & ";" & ExperimentNumberTest(gamma) & ";" & ExperimentNumberTest(maxLong) & ";" & _
        ExperimentNumberTest(maxHoop) & ";" & CStr(atLong) & ";" & CStr(atHoop) & ";" & ExperimentNumberTest(maximumTension) & ";" & _
        ExperimentNumberTest(maximumCompression) & ";" & ExperimentNumberTest(minPrincipal) & ";" & _
        ExperimentNumberTest(maxPrincipal) & ";" & ExperimentNumberTest(residual)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет фактический статус, причину и последнюю подтверждённую ступень текущего отрезка.
Private Sub RecordWangPairStatusTest(ByVal branch As CCoupledLoadContinuation, ByVal specimen As String, _
        ByVal phase As String, ByVal target As Double, ByVal reached As Double, ByVal succeeded As Boolean, _
        ByRef report As String, ByVal tracePath As String)
    Dim meta As CResultMeta, policy As New CResultStatusPolicy: Set meta = branch.ResultMeta
    AddExperimentTraceTest report, tracePath, "WANG_PAIR_STATUS;" & specimen & ";" & phase & ";" & _
        ExperimentNumberTest(target) & ";" & ExperimentNumberTest(reached) & ";" & CStr(succeeded) & ";" & _
        policy.ExternalStatus(meta) & ";" & CStr(meta.InternalStatus) & ";" & CStr(meta.ResultCode) & ";" & _
        CStr(branch.RejectedAttempts) & ";" & CStr(branch.SavedFieldCount) & ";" & meta.ResultComment & " | " & meta.DiagnosticDetails
End Sub


' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет близкое деформационное продолжение MVT2 по штатной мере.
' Деление шага сохраняет принятую историю. Отрицательное приращение нагрузки
' допустимо на нисходящей ветви, но направление поля проверяется отдельно.
Private Sub FollowWangControlledTest(ByVal branch As CCoupledLoadContinuation, ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByVal path As CLoadPathVector, ByVal response As CCoupledReinforcedResponse, _
        ByVal torque As Double, _
        ByRef report As String, ByVal tracePath As String)
    Const ABS_TOL As Double = 0.0000005
    Const REL_TOL As Double = 0.0000005
    Const MAX_ATTEMPTS As Long = 14
    Const MAX_ACCEPTED As Long = 5
    Const MAX_TARGET As Double = 30#
    Const REFERENCE_MODULUS As Double = 30000#
    Dim previous() As Double, current() As Double, trial() As Double, verified() As Double, actual() As Double
    Dim offset(1 To 6) As Double, direction(1 To 6) As Double, projection() As Double, expected() As Double
    Dim leftLambda As Double, currentLambda As Double, trialLambda As Double, stepLambda As Double, initialLambda As Double
    Dim coordinate As Double, lastIncrement As Double, increment As Double, minimum As Double, ratio As Double, target As Double
    Dim controlName As String, visited As Long, accepted As Long, i As Long, solved As Boolean, forward As Boolean
    Dim forceHistory As Collection, coarseTargets(1 To 5) As Double
    Dim coldLeft As Double, coldRight As Double, coldCoordinate As Double, coldIncrement As Double
    Dim weakNorm As Double, gaugeNorm As Double, integralNorm As Double, controlNorm As Double, tolerance As Double
    Dim detail As String, initialLoad() As Double, applied() As Double, row As String, steelUtil As Double
    offset(4) = torque: direction(2) = 600000#: direction(6) = 1000#
    If branch.SavedFieldCount < 2 Then Err.Raise 5, , "Нет двух принятых состояний перед переходом MVT2."
    branch.CopySavedField branch.SavedFieldCount - 1, previous
    branch.CopyAccepted current, actual
    currentLambda = branch.AcceptedLambda: leftLambda = branch.PreviousAcceptedLambda
    If leftLambda <= 0# Or leftLambda >= currentLambda Then Err.Raise 5, , "Нет возрастающей пары перед переходом MVT2."
    If Not solver.SelectDeformationControl(previous, current, projection, coordinate, lastIncrement, controlName) Then _
        Err.Raise 5, , "Не определена мера продолжения MVT2."
    increment = lastIncrement * 0.5
    minimum = lastIncrement / 64#
    Set forceHistory = SaveWangTurnHistoryTest(branch, report, tracePath)
    coldLeft = leftLambda: coldRight = currentLambda
    coldCoordinate = coordinate: coldIncrement = lastIncrement
    AddExperimentTraceTest report, tracePath, "MVT2_CONTROL_START;" & ExperimentNumberTest(leftLambda) & ";" & _
        ExperimentNumberTest(currentLambda) & ";" & ExperimentNumberTest(coordinate) & ";" & _
        ExperimentNumberTest(lastIncrement) & ";" & controlName
    AppendWangFieldTest report, tracePath, "Prior", previous
    AppendWangFieldTest report, tracePath, "Base", current
    AppendWangFieldTest report, tracePath, "Projection", projection
    For visited = 1 To MAX_ATTEMPTS
        If increment < minimum Or accepted >= MAX_ACCEPTED Or currentLambda >= MAX_TARGET Then Exit For
        target = coordinate + increment
        ratio = increment / lastIncrement
        stepLambda = currentLambda - leftLambda
        trialLambda = currentLambda
        initialLambda = currentLambda + ratio * stepLambda
        solved = solver.TryDeformationStep(offset, direction, projection, target, _
            initialLambda, trialLambda, ABS_TOL, REL_TOL, 26, consistentControl:=True)
        detail = solver.ResultMeta.DiagnosticDetails
        forward = False
        If solved Then
            solver.CopyTrial trial, actual
            steelUtil = response.TrialSteelUtilization
            forward = trialLambda > 0# And steelUtil <= 1# And _
                Abs(trialLambda - currentLambda) <= 3# * ratio * GeomMax(Abs(stepLambda), 0.01) And _
                ForwardWangFieldTest(previous, current, trial, ratio)
        End If
        AddExperimentTraceTest report, tracePath, "MVT2_CONTROL_PROBE;" & CStr(visited) & ";" & _
            ExperimentNumberTest(target) & ";" & ExperimentNumberTest(increment) & ";" & _
            ExperimentNumberTest(trialLambda) & ";" & CStr(Abs(CLng(solved))) & ";" & CStr(Abs(CLng(forward))) & ";" & _
            CStr(solver.ResultMeta.ResultCode) & ";" & detail
        solver.CopyAccepted verified
        For i = 1 To UBound(current)
            If verified(i) <> current(i) Then Err.Raise 5, , "Проба изменила принятое поле MVT2."
        Next i
        If solved And forward Then
            path.TargetSix trialLambda, expected
            WangControlledNormTest operators, solver, trial, actual, expected, projection, target, REFERENCE_MODULUS, _
                weakNorm, gaugeNorm, integralNorm, controlNorm
            path.TargetSix initialLambda, initialLoad
            operators.LoadEquations initialLoad(1), initialLoad(2), initialLoad(3), initialLoad(4), initialLoad(5), initialLoad(6), applied
            tolerance = 0#
            For i = 1 To UBound(applied) - 4: tolerance = GeomMax(tolerance, Abs(applied(i))): Next i
            tolerance = ABS_TOL + REL_TOL * tolerance
            If GeomMax(GeomMax(weakNorm, gaugeNorm), GeomMax(integralNorm, controlNorm)) > tolerance Then _
                Err.Raise 5, , "Повторная проверка равновесия контролируемой пробы MVT2 не прошла."
            solver.AcceptStep
            previous = current: current = trial
            leftLambda = currentLambda: currentLambda = trialLambda
            coordinate = target: lastIncrement = increment
            accepted = accepted + 1
            coarseTargets(accepted) = coordinate
            row = "MVT2_CONTROL_ACCEPT;" & CStr(visited) & ";" & ExperimentNumberTest(currentLambda) & ";" & _
                ExperimentNumberTest(coordinate) & ";" & ExperimentNumberTest(weakNorm) & ";" & ExperimentNumberTest(gaugeNorm) & ";" & _
                ExperimentNumberTest(integralNorm) & ";" & ExperimentNumberTest(controlNorm) & ";" & ExperimentNumberTest(tolerance) & ";" & ExperimentNumberTest(steelUtil)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(actual(i)): Next i
            AddExperimentTraceTest report, tracePath, row
            AppendWangFieldTest report, tracePath, CStr(visited), current
            increment = lastIncrement * 1.25
        Else
            solver.DiscardStep
            increment = increment * 0.5
        End If
    Next visited
    AddExperimentTraceTest report, tracePath, "MVT2_CONTROL_STOP;" & CStr(accepted) & ";" & _
        ExperimentNumberTest(currentLambda) & ";" & CStr(visited - 1)
    If accepted = MAX_ACCEPTED Then
        FollowWangTurnTest forceHistory, solver, operators, path, response, offset, direction, projection, _
            coldLeft, coldRight, coldCoordinate, coldIncrement, coarseTargets, report, tracePath
    Else
        AddExperimentTraceTest report, tracePath, "MVT2_TURN_STOP;BaselineNotReproduced;0;0;0;0"
    End If
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет направление и длину физической части приращения по предыдущей паре.
Private Function ForwardWangFieldTest(ByRef previous() As Double, ByRef current() As Double, _
        ByRef trial() As Double, ByVal ratio As Double) As Boolean
    Dim i As Long, leftDelta As Double, rightDelta As Double, product As Double, left2 As Double, right2 As Double
    For i = 1 To UBound(current) - 4 ' Последние четыре координаты — реакции связей.
        leftDelta = current(i) - previous(i): rightDelta = trial(i) - current(i)
        product = product + leftDelta * rightDelta
        left2 = left2 + leftDelta * leftDelta
        right2 = right2 + rightDelta * rightDelta
    Next i
    ForwardWangFieldTest = product > 0# And right2 <= 9# * ratio * ratio * left2
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторно вычисляет слабые строки, связи и управляющую координату в МПа.
Private Sub WangControlledNormTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByRef field() As Double, ByRef actual() As Double, ByRef expected() As Double, ByRef projection() As Double, _
        ByVal target As Double, ByVal modulus As Double, ByRef weakNorm As Double, ByRef gaugeNorm As Double, _
        ByRef integralNorm As Double, ByRef controlNorm As Double)
    Dim residual() As Double, matrix() As Double, applied() As Double, i As Long, coordinate As Double
    If Not solver.TestEquilibriumLinearization(field, False, False, residual, matrix) Then _
        Err.Raise 5, , "Недоступна повторная невязка MVT2."
    operators.LoadEquations expected(1), expected(2), expected(3), expected(4), expected(5), expected(6), applied
    weakNorm = 0#: gaugeNorm = 0#: coordinate = 0#
    For i = 1 To UBound(field) - 4
        weakNorm = GeomMax(weakNorm, Abs(residual(i) - applied(i)))
        coordinate = coordinate + projection(i) * field(i)
    Next i
    For i = UBound(field) - 3 To UBound(field)
        gaugeNorm = GeomMax(gaugeNorm, modulus * Abs(residual(i)))
    Next i
    integralNorm = operators.ResultantResidualNorm(actual, expected)
    controlNorm = modulus * Abs(coordinate - target)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Экспортирует поле для независимой проверки направления и наклона ветви.
Private Sub AppendWangFieldTest(ByRef report As String, ByVal tracePath As String, ByVal label As String, ByRef values() As Double)
    Dim i As Long, row As String
    row = "MVT2_CONTROL_FIELD;" & label
    For i = 1 To UBound(values): row = row & ";" & ExperimentNumberTest(values(i)): Next i
    AddExperimentTraceTest report, tracePath, row
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает каждое принятое поле холодной силовой части в порядке обновления материала.
Private Function SaveWangTurnHistoryTest(ByVal branch As CCoupledLoadContinuation, _
        ByRef report As String, ByVal tracePath As String) As Collection
    Dim history As New Collection, i As Long, field() As Double
    For i = 1 To branch.SavedFieldCount
        branch.CopySavedField i, field
        history.Add field
        AppendWangFieldTest report, tracePath, "Force" & CStr(i), field
    Next i
    AddExperimentTraceTest report, tracePath, "MVT2_TURN_HISTORY;" & CStr(history.Count)
    Set SaveWangTurnHistoryTest = history
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет левое плечо из силовой истории и уточняет закручивание между соседними полями.
Private Sub FollowWangTurnTest(ByVal history As Collection, ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByVal path As CLoadPathVector, ByVal response As CCoupledReinforcedResponse, _
        ByRef offset() As Double, ByRef direction() As Double, ByRef projection() As Double, _
        ByVal leftLambda As Double, ByVal currentLambda As Double, ByVal coordinate As Double, _
        ByVal lastIncrement As Double, ByRef oldTargets() As Double, ByRef report As String, ByVal tracePath As String)
    Const ABS_TOL As Double = 0.0000005
    Const REL_TOL As Double = 0.0000005
    Const REFERENCE_MODULUS As Double = 30000#
    Const MAX_ATTEMPTS As Long = 24
    If history.Count < 2 Then Err.Raise 5, , "Недостаточно силовых полей для повтора MVT2."
    If Not solver.ReplayAcceptedFields(history, history.Count) Then _
        Err.Raise 5, , "Не восстановлена холодная история материала MVT2."
    Dim previous() As Double, current() As Double, trial() As Double, actual() As Double, expected() As Double, verified() As Double
    previous = history(history.Count - 1): current = history(history.Count)
    solver.CopyAccepted verified
    Dim i As Long
    For i = 1 To UBound(current)
        If current(i) <> verified(i) Then Err.Raise 5, , "Силовое поле изменилось при восстановлении."
    Next i
    Dim goals(1 To 10) As Double, extension As Double
    goals(1) = oldTargets(1)
    goals(2) = (oldTargets(1) + oldTargets(2)) / 2#: goals(3) = oldTargets(2)
    goals(4) = (oldTargets(2) + oldTargets(3)) / 2#: goals(5) = oldTargets(3)
    goals(6) = oldTargets(4)
    goals(7) = (oldTargets(4) + oldTargets(5)) / 2#: goals(8) = oldTargets(5)
    extension = oldTargets(5) - oldTargets(4)
    goals(9) = oldTargets(5) + extension / 2#: goals(10) = oldTargets(5) + extension
    Dim minimum As Double: minimum = lastIncrement / 64#
    For i = 1 To UBound(goals)
        AddExperimentTraceTest report, tracePath, "MVT2_TURN_GOAL;" & CStr(i) & ";" & ExperimentNumberTest(goals(i))
    Next i
    Dim target As Double, increment As Double, ratio As Double, initialLambda As Double, trialLambda As Double
    Dim weakNorm As Double, gaugeNorm As Double, integralNorm As Double, controlNorm As Double, tolerance As Double, uncertainty As Double
    Dim accepted As Long, attempt As Long, probes As Long, goal As Long, status As String, stage As String, row As String, details As String
    Dim ok As Boolean, forward As Boolean, steel As Double, reached As Boolean
    goal = 1: target = goals(goal): stage = "AttemptLimit"
    For attempt = 1 To MAX_ATTEMPTS
        increment = target - coordinate
        If increment < minimum Then
            stage = "MinimumIncrement"
            Exit For
        End If
        ratio = increment / lastIncrement
        initialLambda = currentLambda + ratio * (currentLambda - leftLambda)
        trialLambda = currentLambda: steel = 0#: uncertainty = 0#
        ok = solver.TryDeformationStep(offset, direction, projection, target, initialLambda, trialLambda, _
            ABS_TOL, REL_TOL, 26, consistentControl:=True)
        details = solver.ResultMeta.DiagnosticDetails
        forward = False: status = "SolverRejected"
        If ok Then
            solver.CopyTrial trial, actual
            steel = response.TrialSteelUtilization
            forward = trialLambda > 0# And steel <= 1# And _
                Abs(trialLambda - currentLambda) <= 3# * ratio * GeomMax(Abs(currentLambda - leftLambda), 0.01) And _
                ForwardWangFieldTest(previous, current, trial, ratio)
            status = "ForwardRejected"
        End If
        If forward Then
            path.TargetSix trialLambda, expected
            WangControlledNormTest operators, solver, trial, actual, expected, projection, target, REFERENCE_MODULUS, _
                weakNorm, gaugeNorm, integralNorm, controlNorm
            tolerance = WangTurnToleranceTest(operators, path, initialLambda, ABS_TOL, REL_TOL)
            If GeomMax(GeomMax(weakNorm, gaugeNorm), GeomMax(integralNorm, controlNorm)) > tolerance Then _
                Err.Raise 5, , "Независимая силовая проверка уточнения MVT2 не прошла."
            status = "AdjointUnavailable"
            If solver.TrialLambdaUncertainty(ABS_TOL, REL_TOL, uncertainty) Then status = "Accepted"
        End If
        solver.CopyAccepted verified
        For i = 1 To UBound(current)
            If verified(i) <> current(i) Then Err.Raise 5, , "Проба поворота изменила принятое поле MVT2."
        Next i
        row = "MVT2_TURN_PROBE;" & CStr(attempt) & ";" & CStr(goal) & ";" & ExperimentNumberTest(target) & ";" & _
            ExperimentNumberTest(increment) & ";" & ExperimentNumberTest(initialLambda) & ";" & ExperimentNumberTest(trialLambda) & ";" & _
            status & ";" & CStr(solver.ResultMeta.ResultCode) & ";" & details
        AddExperimentTraceTest report, tracePath, row
        probes = probes + 1
        If status = "Accepted" Then
            solver.AcceptStep
            accepted = accepted + 1
            reached = (target = goals(goal))
            row = "MVT2_TURN_ACCEPT;" & CStr(attempt) & ";" & CStr(goal) & ";" & CStr(Abs(CLng(reached))) & ";" & _
                ExperimentNumberTest(target) & ";" & ExperimentNumberTest(trialLambda) & ";" & ExperimentNumberTest(uncertainty) & ";" & _
                ExperimentNumberTest(tolerance) & ";" & ExperimentNumberTest(weakNorm) & ";" & ExperimentNumberTest(gaugeNorm) & ";" & _
                ExperimentNumberTest(integralNorm) & ";" & ExperimentNumberTest(controlNorm) & ";" & ExperimentNumberTest(steel)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(actual(i)): Next i
            AddExperimentTraceTest report, tracePath, row
            AppendWangFieldTest report, tracePath, "Turn" & CStr(attempt), trial
            previous = current: current = trial
            leftLambda = currentLambda: currentLambda = trialLambda
            coordinate = target: lastIncrement = increment
            If reached Then goal = goal + 1
            If goal > UBound(goals) Then
                stage = "WindowComplete"
                Exit For
            End If
            target = goals(goal)
        Else
            solver.DiscardStep
            target = coordinate + increment / 2#
        End If
    Next attempt
    AddExperimentTraceTest report, tracePath, "MVT2_TURN_STOP;" & stage & ";" & CStr(accepted) & ";" & _
        CStr(probes) & ";" & ExperimentNumberTest(coordinate) & ";" & ExperimentNumberTest(currentLambda)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит исходный допуск из нормы заданных слабых силовых строк.
Private Function WangTurnToleranceTest(ByVal operators As CCoupledElasticState, ByVal path As CLoadPathVector, _
        ByVal lambda As Double, ByVal absTol As Double, ByVal relTol As Double) As Double
    Dim target() As Double, equations() As Double, i As Long, norm As Double
    path.TargetSix lambda, target
    operators.LoadEquations target(1), target(2), target(3), target(4), target(5), target(6), equations
    For i = 1 To UBound(equations) - 4: norm = GeomMax(norm, Abs(equations(i))): Next i
    WangTurnToleranceTest = absTol + relTol * norm
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает два значения ft при неизменных энергиях, сечении и протоколе нагружения MVT2.
' Обе истории кручения начинаются с нуля. Продолжение по Qy запускается отдельно.
Public Function RunTestWangCrackSensitivity(ByVal routeMode As String) As String
    Dim report As String, path As String, passed As Long, failed As Long
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для сравнения MVT2 нужна изолированная книга."
    path = ThisWorkbook.Path & "\WangCrackSensitivity.csv"
    Select Case routeMode
        Case "Marker"
            If RunWangCrackRouteTest("A", False, report, path) Then passed = passed + 1 Else failed = failed + 1
            If RunWangCrackRouteTest("B", False, report, path) Then passed = passed + 1 Else failed = failed + 1
        Case "ShearA", "ShearB"
            If RunWangCrackRouteTest(Right$(routeMode, 1), True, report, path) Then passed = passed + 1 Else failed = failed + 1
        Case Else
            Err.Raise 5, , "Укажите режим Marker, ShearA или ShearB."
    End Select
    RunTestWangCrackSensitivity = report & "TOTAL_COUPLED_WANG_CRACK_SENSITIVITY: passed=" & CStr(passed) & "; failed=" & CStr(failed)
    Exit Function
Failed:
    RunTestWangCrackSensitivity = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет интегральное равновесие принятых состояний и сохраняет состояние до численной остановки.
Private Function RunWangCrackRouteTest(ByVal lawTag As String, ByVal combined As Boolean, _
        ByRef report As String, ByVal tracePath As String) As Boolean
    Const EC As Double = 30000#, NU As Double = 0.2, PEAK As Double = 0.0022, PRELOAD As Double = 10.51
    Const TORQUE_UNITS As Double = 1000000#, FORCE_UNITS As Double = 1000#, MOMENT_PER_SHEAR As Double = 600000#
    Const FT_B As Double = 2.10667357864589
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005, MAX_NATIVE_RESIDUAL As Double = 0.000005
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim fc As Double, ft As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#)
    nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt ' В обоих маршрутах сохраняется одна энергия сжатия.
    ft = nominalFt
    If lawTag = "B" Then ft = FT_B ' Эквивалент начала чистого сдвига в 25 точках при 6,50 кН·м.
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver, branch As New CCoupledLoadContinuation
    Dim path As New CLoadPathVector, shearX() As Double, shearY() As Double
    operators.PrepareModel section, EC, NU, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура MVT2 не совпала с архивом."
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, EC, NU, fc, ft, PEAK, gt, gc, True
    operators.MeanShearProjections shearX, shearY
    Dim goals As Variant, kind As String, route As String
    If combined Then
        kind = "Shear"
        goals = Array(0#, 15#, 22.11622, 25#, 30#) ' Точный силовой маршрут исходной проверки, без деформационного обхода.
        path.Initialize 0#, 0#, 0#, MOMENT_PER_SHEAR, 0#, 0#, PRELOAD * TORQUE_UNITS, 0#, 0#, 0#, 0#, FORCE_UNITS
    Else
        kind = "Torque"
        goals = Array(5.2, 6.45, 6.49, 6.5, 6.51, 6.55, 7.8, 9.1, 9.45, 9.46, 9.47, 9.5, 10.4, PRELOAD)
        path.Initialize 0#, 0#, 0#, 0#, 0#, 0#, 0#, TORQUE_UNITS, 0#, 0#, 0#, 0#
    End If
    route = lawTag & "/" & kind
    branch.Initialize solver, path, 8, 44, 26, ABS_TOL, REL_TOL, True
    AddExperimentTraceTest report, tracePath, "WANG_CRACK_CASE;" & route & ";" & ExperimentNumberTest(ft) & ";" & _
        ExperimentNumberTest(gt) & ";" & ExperimentNumberTest(gc) & ";" & CStr(operators.ConcretePointCount)
    Dim start As Double: start = Timer
    Dim target As Variant, solved As Boolean, reached As Double, field() As Double, actual() As Double, expected() As Double
    Dim residual As Double, valid As Boolean: valid = True
    Dim seen As Long
    For Each target In goals
        solved = branch.Advance(CDbl(target))
        reached = branch.AcceptedLambda
        RecordWangPairStatusTest branch, lawTag, kind, CDbl(target), reached, solved, report, tracePath
        If branch.SavedFieldCount > 0 Then
            branch.CopyAccepted field, actual
            path.TargetSix reached, expected
            If combined Then expected(4) = PRELOAD * TORQUE_UNITS * branch.AcceptedOffsetFraction
            residual = operators.ResultantResidualNorm(actual, expected)
            RecordWangMVT2StateTest operators, concrete, response, field, actual, shearY, _
                route, CDbl(target), reached, actual(4), residual, report, tracePath
            valid = valid And residual <= MAX_NATIVE_RESIDUAL
            seen = seen + 1
        End If
        If Not solved Then Exit For
        If reached <> CDbl(target) Then Err.Raise 5, , "Целевая ступень MVT2 не совпала с принятой."
    Next target
    Dim elapsed As Double: elapsed = Timer - start
    If elapsed < 0# Then elapsed = elapsed + 86400#
    AddExperimentTraceTest report, tracePath, "WANG_CRACK_END;" & route & ";" & ExperimentNumberTest(elapsed) & ";" & _
        CStr(seen) & ";" & CStr(branch.SavedFieldCount) & ";" & ExperimentNumberTest(branch.AcceptedOffsetFraction) & ";" & CStr(solved)
    If combined And lawTag = "B" Then ExportWangShearFieldsTest branch, path, report, tracePath
    RunWangCrackRouteTest = valid And seen > 0
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает сохранённые поля и заданные усилия после завершения опытной ветви.
Private Sub ExportWangShearFieldsTest(ByVal branch As CCoupledLoadContinuation, ByVal path As CLoadPathVector, _
        ByRef report As String, ByVal tracePath As String)
    Dim trace As CCoupledLoadTrace: Set trace = branch.SavedTrace
    If trace Is Nothing Then Err.Raise 5, , "История нагрузок ShearB не записана."
    If trace.Count <> branch.SavedFieldCount Then Err.Raise 5, , "Истории ShearB имеют разную длину."
    Dim j As Long, k As Long, offsetFraction As Double, loadFactor As Double
    Dim constantValues() As Double, variableValues() As Double, values() As Double, row As String
    path.Components constantValues, variableValues
    For j = 1 To trace.Count
        trace.ReadPoint j, offsetFraction, loadFactor
        branch.CopySavedField j, values
        If UBound(values) <> 60 Then Err.Raise 5, , "Поле ShearB не содержит 60 координат."
        row = "MVT2_SHEAR_FORCE_TARGET;" & CStr(j) & ";" & ExperimentNumberTest(offsetFraction) & ";" & ExperimentNumberTest(loadFactor)
        For k = 1 To 6
            row = row & ";" & ExperimentNumberTest(constantValues(k) * offsetFraction + variableValues(k) * loadFactor)
        Next k
        AddExperimentTraceTest report, tracePath, row
        AppendWangFieldTest report, tracePath, "ShearB/Force" & CStr(j), values
    Next j
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает касательную в подтверждённой пробе BothSmall и отдельно проверяет ограниченные поправки.
Public Function RunTestWangShearControlled(ByVal replayPath As String, ByVal phase As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Const EC As Double = 30000#, NU As Double = 0.2, FT As Double = 2.10667357864589
    Const PEAK_STRAIN As Double = 0.0022, LOCALIZATION_LENGTH As Double = 125#
    concrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    plusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    response.Initialize operators, concrete, steel
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, response, EC, plusSide, minusSide
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim materials(-1 To 1) As CCoupledConcreteResponse, responses(-1 To 1) As ICoupledPointResponse
    Set materials(0) = concrete: Set materials(1) = plusConcrete: Set materials(-1) = minusConcrete
    Set responses(0) = response: Set responses(1) = plusSide: Set responses(-1) = minusSide
    Dim base() As Double, anchor() As Double, qBase As Double, qTrial As Double, norm As Double, folder As String
    folder = Left$(replayPath, InStrRev(replayPath, "\"))
    ReadWangFreshAnchorTest folder & "AnchorField.csv", anchor
    base = history(24): qBase = factors(24): qTrial = qBase + (qBase - factors(23)) / 64#
    Dim output As Integer: output = FreeFile
    Open tracePath For Append As #output
    Print #output, "B_TANGENT_LOAD;" & ExperimentNumberTest(qBase) & ";" & ExperimentNumberTest(qTrial)
    Print #output, "B_FRESH_PHASE;" & phase
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Base24", 24, qBase, solver, operators, materials, responses, base)
    norm = RecordWangTangentStateTest(output, "Anchor", 24, qTrial, solver, operators, materials, responses, anchor)
    If norm <= 0# Then Err.Raise 5, , "Не воспроизведена проба BothSmall."
    ' -------------------- ДЛЯ ТЕСТОВ --------------------
    Dim fixedLoad(1 To 6) As Double, provisional() As Double, traceRows As New Collection
    Dim traceRow As Variant, passed As Boolean
    fixedLoad(2) = 600000# * qTrial: fixedLoad(4) = 10510000#: fixedLoad(6) = 1000# * qTrial
    passed = solver.TryTestBoundedFixedForce(fixedLoad, anchor, 0.00000001, 4, 0.0000005, 0.0000005, provisional, traceRows)
    For Each traceRow In traceRows: Print #output, CStr(traceRow): Next traceRow
    Print #output, "BOUNDED_READY;" & CStr(Abs(CLng(passed)))
    solver.DiscardStep
    norm = RecordWangTangentStateTest(output, "FinalProvisional", 24, qTrial, solver, operators, materials, responses, provisional)
    If norm < 0# Then Err.Raise 5, , "Не воспроизведено пробное поле после поправок MVT2."

    RequireWangAcceptedFieldTest solver, base
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Restored24", 24, qBase, solver, operators, materials, responses, base)
    Print #output, "B_TANGENT_END;24;" & ExperimentNumberTest(qBase)
    Close #output
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    Dim problem As String: problem = Err.Source & " " & Err.Description
    On Error Resume Next
    If output > 0 Then Close #output
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Масштабирует одно и то же направление без изменения принятого поля решателя.
Private Sub AddWangTangentDirectionTest(ByRef base() As Double, ByRef direction() As Double, _
        ByVal amount As Double, ByRef target() As Double)
    Dim j As Long
    ReDim target(1 To UBound(base))
    For j = 1 To UBound(base): target(j) = base(j) + amount * direction(j): Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает вектор в инвариантной форме для независимой проверки.
Private Sub EmitWangTangentVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef values() As Double)
    Dim row As String, j As Long
    row = prefix
    For j = 1 To UBound(values): row = row & ";" & ExperimentNumberTest(values(j)): Next j
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет независимые центральные и боковые напряжения, признаки ветви и слабые строки.
Private Function RecordWangTangentStateTest(ByVal output As Integer, ByVal label As String, ByVal historyCount As Long, _
        ByVal factor As Double, ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef field() As Double) As Double
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, grad(1 To 6) As Double
    Dim residual() As Double, matrix() As Double, external() As Double, row As String, flag As Long
    Dim yielding As Boolean, principal As Long, substeps As Long, yieldValue As Double
    Dim concretePoint As ICoupledPointResponse, concreteStress(1 To 6) As Double, component As Long
    EmitWangTangentVectorTest output, "B_TANGENT_FIELD;" & label & ";" & CStr(historyCount) & ";" & _
        ExperimentNumberTest(factor), field
    RecordWangTangentStateTest = -1#
    If Not solver.TestEquilibriumLinearization(field, False, False, residual, matrix) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";Residual"
        Exit Function
    End If
    operators.LoadEquations 0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, external
    For i = 1 To UBound(residual): residual(i) = residual(i) - external(i): Next i
    EmitWangTangentVectorTest output, "B_TANGENT_RESIDUAL;" & label, residual
    Dim norm As Double, value As Double, actual(1 To 6) As Double, demand(1 To 6) As Double
    For i = 1 To UBound(residual)
        value = Abs(residual(i))
        If i > solver.PhysicalDegreeCount Then value = value * 30000#
        norm = GeomMax(norm, value)
    Next i
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For point = 1 To operators.PointCount
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, slope
        For side = -1 To 1
            For i = 1 To 6: station(i) = strain(i) + side * 0.001 * slope(i): Next i
            If responses(side).EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Не подтвержден станционный отклик MVT2 B. " & label
            If side = 0 Then
                actual(1) = actual(1) + area * stress(3)
                actual(2) = actual(2) + area * stress(3) * y
                actual(3) = actual(3) + area * stress(3) * x
                actual(4) = actual(4) + area * (x * stress(6) - y * stress(5))
                actual(5) = actual(5) + area * stress(5)
                actual(6) = actual(6) + area * stress(6)
            End If
            If point > operators.ConcretePointCount Then
                Set concretePoint = materials(side)
                If concretePoint.EvaluatePoint(point, station, concreteStress, tangent, ctmStressOnly, False) <> sfcNone Then _
                    Err.Raise 5, , "Не подтверждён бетон в поправке замещения арматуры MVT2 B. " & label
                component = 3 ' Продольные стержни имеют ось z.
                If point > operators.ConcretePointCount + 4 Then
                    If Abs(x) > Abs(y) Then component = 2 Else component = 1 ' Ось ветви параллельна стенке квадрата.
                End If
                Print #output, "B_BOUND_STEEL;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & CStr(component) & ";" & _
                    ExperimentNumberTest(station(component)) & ";" & ExperimentNumberTest(concreteStress(component)) & ";" & _
                    ExperimentNumberTest(stress(component) + concreteStress(component))
            End If
            flag = -1: principal = 0: substeps = -1: yieldValue = 0#
            If point <= operators.ConcretePointCount Then
                If Not materials(side).TryReadConcreteBranch(point, station, yielding, principal, substeps) Then _
                    Err.Raise 5, , "Недоступна ветвь бетона MVT2 B. " & label
                If Not materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=False) Then _
                    Err.Raise 5, , "Недоступна пробная поверхность бетона MVT2 B. " & label
                flag = Abs(CLng(yielding))
            End If
            row = "B_TANGENT_STATION;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area) & ";" & _
                CStr(flag) & ";" & CStr(principal) & ";" & CStr(substeps) & ";" & ExperimentNumberTest(yieldValue)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(station(i)): Next i
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(i)): Next i
            Print #output, row
        Next side
    Next point
    EmitWangTangentVectorTest output, "B_BOUND_ACTUAL;" & label, actual
    RecordWangTangentStateTest = GeomMax(norm, operators.ResultantResidualNorm(actual, demand))
    Print #output, "B_BOUND_NORM;" & label & ";" & ExperimentNumberTest(RecordWangTangentStateTest)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает наибольшую взвешенную компоненту тензора на всех 135 станциях.
Private Function WangBoundedTensorPeakTest(ByVal operators As CCoupledElasticState, ByRef direction() As Double) As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double
    Dim point As Long, side As Long, j As Long, s As Double, peak As Double
    For point = 1 To operators.PointCount
        operators.PointStrain point, direction, strain
        operators.AxialGradientAtPoint point, direction, slope
        For side = -1 To 1
            For j = 1 To 6
                s = Abs(strain(j) + side * 0.001 * slope(j))
                If j > 3 Then s = s / Sqr(2#)
                peak = GeomMax(peak, s)
            Next j
        Next side
    Next point
    WangBoundedTensorPeakTest = peak
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает 60 архивных координат BothSmall без добавления поля в историю.
Private Sub ReadWangFreshAnchorTest(ByVal path As String, ByRef field() As Double)
    Dim file As Integer, row As String, values As Variant, k As Long
    file = FreeFile: Open path For Input As #file
    Line Input #file, row
    Close #file
    values = Split(row, ";")
    If UBound(values) <> 59 Then Err.Raise 5, , "Неверный архив поля BothSmall."
    ReDim field(1 To 60)
    For k = 1 To 60: field(k) = Val(values(k - 1)): Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает свежие матрицы и проекцию слабых строк в шесть подписанных усилий.
Private Sub RecordWangFreshMatricesTest(ByVal output As Integer, ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByRef anchor() As Double)
    Dim matrix() As Double, residual() As Double, projection() As Double, choice As Long, i As Long, j As Long
    Dim label As String, row As String
    For choice = 1 To 2
        label = "Stock": If choice = 2 Then label = "Consistent"
        If solver.CopyTestWangTangent(anchor, choice, residual, matrix) Then
            EmitWangTangentVectorTest output, "B_FRESH_INTERNAL;" & label, residual
            For i = 1 To UBound(anchor)
                row = "B_FRESH_MATRIX;" & label & ";" & CStr(i)
                For j = 1 To UBound(anchor): row = row & ";" & ExperimentNumberTest(matrix(j, i)): Next j
                Print #output, row
            Next i
        Else
            Print #output, "B_FRESH_MATRIX_UNAVAILABLE;" & label
        End If
    Next choice
    operators.CopyResultantResidualProjection projection
    For i = 1 To 6
        row = "B_FRESH_PROJECTION;" & CStr(i)
        For j = 1 To solver.PhysicalDegreeCount: row = row & ";" & ExperimentNumberTest(projection(j, i)): Next j
        Print #output, row
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет только заранее вычисленные ограниченные поправки, сохраняя принятую H24.
Private Sub CheckWangFreshCandidatesTest(ByVal output As Integer, ByVal path As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByRef anchor() As Double, ByVal factor As Double)
    Dim file As Integer, row As String, values As Variant, field() As Double, correction(1 To 60) As Double
    Dim count As Long, label As String, radius As Double, prediction As Double, extent As Double, k As Long, norm As Double
    file = FreeFile: Open path For Input As #file
    Do Until EOF(file)
        Line Input #file, row
        values = Split(row, ";")
        If UBound(values) <> 62 Or count >= 6 Then Err.Raise 5, , "Неверный перечень ограниченных проб MVT2 B."
        label = values(0): radius = Val(values(1)): prediction = Val(values(2))
        For k = 1 To 60: correction(k) = Val(values(k + 2)): Next k
        extent = WangBoundedTensorPeakTest(operators, correction)
        If radius <= 0# Or radius > 0.00000001 Or extent > radius + 0.0000000000000004 Then _
            Err.Raise 5, , "Нарушено ограничение приращения деформаций MVT2 B."
        RestoreWangShearBaselineTest solver, history, base
        AddWangTangentDirectionTest anchor, correction, 1#, field
        Print #output, "B_FRESH_INPUT;" & label & ";" & ExperimentNumberTest(radius) & ";" & _
            ExperimentNumberTest(prediction) & ";" & ExperimentNumberTest(extent)
        norm = RecordWangTangentStateTest(output, label, 24, factor, solver, operators, materials, responses, field)
        RequireWangAcceptedFieldTest solver, base
        count = count + 1
    Loop
    Close #file
    If count < 1 Then Err.Raise 5, , "Проверенных ограниченных поправок нет."
    Print #output, "B_FRESH_PROBES;" & CStr(count)
End Sub
