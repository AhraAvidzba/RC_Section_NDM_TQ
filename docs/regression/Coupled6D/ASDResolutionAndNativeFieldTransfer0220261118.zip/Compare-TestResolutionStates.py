"""ДЛЯ ТЕСТОВ: сравнивает фактически принятые состояния разных пространственных дискретизаций."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestCompare(repo, folders, output):
    """Сопоставляет одинаковые усилия и физические единицы; несходимость за предел не принимает."""
    here = Path(__file__).resolve().parent
    reference = run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    section_class = run_path(str(here/'TestResolutionSection.py'))['TestResolutionSection']
    table = {}
    for name, folder in folders.items():
        section = section_class(folder, reference, True)
        fields = {row[1]: np.asarray(row[2:], dtype=float) for row in
                  (line.split(';') for line in (folder/'Operators.csv').read_text('cp1251').splitlines()) if row[0] == 'F'}
        states = {}
        for line in (folder/'MVTGaussMixed.Tensor.csv').read_text('cp1251').splitlines():
            row = line.split(';')
            if row[0] != 'FRAME':
                continue
            phase, torque, q = row[1], float(row[2]), float(row[3])
            if torque != 10510000. or q not in (0., 30000., 50000., 60000.):
                continue
            field = fields[phase]
            states[str(q)] = {'label': phase, 'Qy_N': q, 'T_Nmm': torque, 'Mx_Nmm': -396.*q,
                              'epsilon0': float(field[0]), 'curvature_X_per_m': float(1000.*field[1]/section.radius),
                              'curvature_Y_per_m': float(1000.*field[2]/section.radius),
                              'twist_rad_per_m': float(1000.*field[3]/section.radius),
                              'center_longitudinal_bar_strains': (section.a@field).reshape(3, -1)[0, :4].tolist()}
        assert len(states) == 4, (name, states.keys())
        table[name] = {'concrete_points': section.TestConcreteCount, 'degrees': section.TestDof, 'states': states}
    comparison = []
    for q, first in table['G7S1']['states'].items():
        other = table['G9S1']['states'][q]
        record = {'Qy_N': float(q), 'twist_relative_difference': abs(first['twist_rad_per_m']/other['twist_rad_per_m']-1.)}
        if float(q) > 0.:
            record['curvature_X_relative_difference'] = abs(first['curvature_X_per_m']/other['curvature_X_per_m']-1.)
        comparison.append(record)
    output.write_bytes((json.dumps({'variants': table, 'G7_G9_comparison': comparison,
                                   'physical_capacity_certified': False}, indent=2, sort_keys=True)+'\n').encode())
    print('SAME LOAD STATES COMPARED', json.dumps(comparison), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native-root', type=Path, default=Path('D:/CodexScratch/RC_Section_NDM_TQ'))
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    folders = {key: args.native_root/name/'Native' for key, name in
               (('G5S1', 'ClosedASDForcePath20261117'), ('G7S1', 'ClosedASDG7S120261118'),
                ('G9S1', 'ClosedASDG9S120261118'), ('G5S2', 'ClosedASDG5S220261118'))}
    TestCompare(args.repo.resolve(), folders, args.out.resolve())
