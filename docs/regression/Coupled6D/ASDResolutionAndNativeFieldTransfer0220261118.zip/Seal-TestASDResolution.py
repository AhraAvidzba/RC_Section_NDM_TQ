"""ДЛЯ ТЕСТОВ: закрепляет пространственную проверку и двоичные части отдельными архивами."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED


TestMain = 'ASDResolutionAndNativeFieldTransfer0220261118'


def TestZip(root, path, selection):
    """Записывает новый воспроизводимый архив, не заменяя уже сохранённые свидетельства."""
    with path.open('xb') as stream, ZipFile(stream, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for file in sorted(root.rglob('*')):
            if not file.is_file() or not selection(file.relative_to(root)):
                continue
            assert '__pycache__' not in file.parts and file.suffix != '.pyc'
            info = ZipInfo(file.relative_to(root).as_posix(), date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, file.read_bytes(), compresslevel=9)
    assert path.stat().st_size < 100*2**20, path.stat().st_size
    return sha256(path.read_bytes()).hexdigest().upper()


def TestPayloads(repo, root):
    """Разделяет большие двоичные материалы, сохраняя возможность точного восстановления книг и CFB."""
    metadata = {}
    for key, directory, name in (('books', 'SourceBooks', 'ASDResolutionSourceBooks20261118'),
                                  ('vba', 'VBAChunks', 'ASDResolutionVBAContainers20261118')):
        path = repo/'docs/regression/Coupled6D'/(name+'.zip')
        digest = TestZip(root, path, lambda relative: relative.parts[0] == directory)
        metadata[key] = {'archive': name, 'sha256': digest, 'directory': directory}
        print('RESOLUTION PAYLOAD SEALED', name, path.stat().st_size, digest, flush=True)
    (root/'ResolutionPayloads.json').write_bytes((json.dumps(metadata, indent=2, sort_keys=True)+'\n').encode())


def TestSeal(repo, root):
    """Добавляет один проверяющий случай и три точных архива, сохраняя прежний манифест."""
    proof_file = root/'ResolutionMechanicsChecks.json'
    proof = json.loads(proof_file.read_bytes())
    assert proof['states']['Control']['states'] == 72 and proof['opensees']['material_updates'] == 484380
    assert proof['identical_native_control_targets']['completed'] and not proof['physical_capacity_certified']
    payloads = json.loads((root/'ResolutionPayloads.json').read_bytes())
    archives = {entry['archive']: entry['sha256'] for entry in payloads.values()}
    path = repo/'docs/regression/Coupled6D'/(TestMain+'.zip')
    digest = TestZip(root, path, lambda relative: relative.parts[0] not in ('SourceBooks', 'VBAChunks'))
    archives[TestMain] = digest
    manifest_file = repo/'docs/reports/Coupled6DEvidence.json'
    pending = json.loads(manifest_file.read_bytes())
    original = check_output(['git', 'cat-file', 'blob', 'HEAD:docs/reports/Coupled6DEvidence.json']).decode('utf-8').replace('\r\n', '\n')
    manifest = json.loads(original)
    assert len(pending['cases']) == len(manifest['cases'])+1
    assert pending['cases'][:-1] == manifest['cases']
    assert pending['cases'][-1]['id'] == 'asd-resolution-native-field-transfer-and-identical-control-targets'
    assert {key: pending[key] for key in ('source_checkpoint', 'installed_inputs', 'frozen_repositories')} == {key: manifest[key] for key in ('source_checkpoint', 'installed_inputs', 'frozen_repositories')}
    assert all(pending['archives'][name] == digest for name, digest in manifest['archives'].items())
    old_name, old_digest = list(manifest['archives'].items())[-1]
    for name, value in archives.items():
        assert name not in manifest['archives']
        manifest['archives'][name] = value
    cases = []
    for scope, filename, message in (
        ('native', 'ResolutionNativeChecks.json', 'RESOLUTION NATIVE VBA AND CLOSED EXCEL PROCESSES VERIFIED; CAPACITY OPEN'),
        ('mechanics', 'ResolutionMechanicsChecks.json', 'RESOLUTION STUDY AND NATIVE FIELD TRANSFER VERIFIED; PHYSICAL CAPACITY OPEN')):
        case = {'id': 'asd-resolution-field-transfer-'+scope, 'journal_section': 593,
                'archive': TestMain, 'script': 'Verify-TestASDResolution.py',
                'arguments': ['--repo', '{repo}', '--root', '.', '--scope', scope, '--out', filename],
                'stdout_contains': message,
                'outputs': {filename: sha256((root/filename).read_bytes()).hexdigest().upper()}}
        cases.append(case)
    manifest['cases'].extend(cases)
    old = '    '+json.dumps(old_name)+': '+json.dumps(old_digest)
    assert original.count(old) == 1
    additions = ',\n'.join('    '+json.dumps(name)+': '+json.dumps(value) for name, value in archives.items())
    updated = original.replace(old, old+',\n'+additions)
    marker = '\n  ],\n  "frozen_repositories": {'
    assert updated.count(marker) == 1
    block = ',\n'.join('\n'.join('    '+row for row in json.dumps(case, ensure_ascii=False, indent=2).splitlines()) for case in cases)
    updated = updated.replace(marker, ',\n'+block+marker)
    assert json.loads(updated) == manifest
    manifest_file.write_bytes(updated.replace('\n', '\r\n').encode())
    print('RESOLUTION STUDY SEALED', path.stat().st_size, digest, len(manifest['archives']), len(manifest['cases']), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--payloads', action='store_true')
    args = parser.parse_args()
    repo = Path.cwd()
    root = Path(__file__).resolve().parent/'ResolutionEvidenceBundle'
    if args.payloads:
        TestPayloads(repo, root)
    else:
        TestSeal(repo, root)
