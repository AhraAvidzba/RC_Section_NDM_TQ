"""ДЛЯ ТЕСТОВ: продолжает связанное равновесие из нативной истории по деформационной координате."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestRestore(repo, native):
    """Повторяет все принятые поля и возвращает два последних собственных состояния силы."""
    here = Path(__file__).resolve().parent
    inputs = run_path(str(here/'Probe-TestASDMaterialSteps.py'))
    closure = run_path(str(here/'Probe-TestASDClosure.py'))['TestClosure']
    sections, _, _ = inputs['TestInputs'](repo)
    section = sections['default']
    section.TestOriginalNominal = section.nominal
    section.TestClosureIterations = 0
    section.nominal = lambda field, history: closure(section, field, history)
    loads = {}
    for line in (native/'MVTGaussMixed.Tensor.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME':
            torque, q = float(row[2]), float(row[3])
            loads[row[1]] = np.array([0., -396.*q, 0., torque, 0., q])
    history, records, points = section.initial(), [], []
    for line in (native/'Operators.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] != 'F':
            continue
        phase, field = row[1], np.asarray(row[2:], dtype=float)
        target = loads[phase]
        result = section.evaluate(field, history, target)
        tolerance = 5e-7+5e-7*np.max(np.abs((target@section.l)[:56]))
        assert result[1] <= tolerance, (phase, result[1], tolerance)
        history = result[4]
        records.append({'phase': phase, 'norm_MPa': float(result[1]), 'tolerance_MPa': float(tolerance)})
        if target[5] > 0.:
            points.append((target[5]/1000., field))
    assert len(records) == 35 and points[-1][0] == 61.71875
    return section, history, points, records


def TestControlledStep(section, history, projection, target_control, field, multiplier, difference_step=2e-9, load_projection=0., tangent_function=None):
    """Решает слабые уравнения поля и точную меру деформации; lambda=Qy в кН."""
    degree = len(field)
    base = np.array([0., 0., 0., 10510000., 0., 0.])
    direction = np.array([0., -396000., 0., 0., 0., 1000.])

    def TestEvaluate(current, value):
        """Собирает все шесть усилий и ограничения исходного нелинейного материала."""
        target = base+value*direction
        result = section.evaluate(current, history, target)
        control_error = 30000.*(projection@current+load_projection*value-target_control)
        residual = np.r_[result[0]*section.gauge_scale, control_error]
        norm = max(float(result[1]), abs(float(control_error)))
        tolerance = 5e-7+5e-7*np.max(np.abs((target@section.l)[:degree-4]))
        return result, residual, norm, float(tolerance)

    result, residual, norm, tolerance = TestEvaluate(field, multiplier)
    norms, failure = [norm], ''
    load_column = -(direction@section.l)*section.gauge_scale
    for iteration in range(32):
        if norm <= tolerance:
            break
        matrix = np.zeros((degree+1, degree+1))
        if tangent_function is not None:
            matrix[:degree, :degree] = tangent_function(section, field, history)[0]*section.gauge_scale[:, None]
        else:
            for j, unit in enumerate(np.eye(degree)):
                plus = section.evaluate(field+difference_step*unit, history, base+multiplier*direction)
                minus = section.evaluate(field-difference_step*unit, history, base+multiplier*direction)
                matrix[:degree, j] = (plus[0]-minus[0])*section.gauge_scale/(2*difference_step)
        matrix[:degree, degree] = load_column
        matrix[degree, :degree] = 30000.*projection
        matrix[degree, degree] = 30000.*load_projection
        scales = np.max(np.abs(matrix), axis=0)
        if np.min(scales) == 0.:
            failure = 'Вырожденный столбец контролируемой системы.'
            break
        try:
            correction = np.linalg.solve(matrix/scales, -residual)/scales
        except np.linalg.LinAlgError as error:
            failure = str(error)
            break
        for fraction in 2.**-np.arange(13):
            trial = field+fraction*correction[:degree]
            value = multiplier+fraction*correction[degree]
            try:
                proposed, other_residual, other_norm, other_tolerance = TestEvaluate(trial, value)
            except ArithmeticError:
                continue
            if other_norm < norm:
                field, multiplier = trial, value
                result, residual, norm, tolerance = proposed, other_residual, other_norm, other_tolerance
                norms.append(norm)
                break
        else:
            failure = 'Уменьшение поправки не снизило полную невязку.'
            break
    return field, multiplier, result[4], {
        'accepted': bool(norm <= tolerance), 'control_target': float(target_control),
        'Qy_N': float(multiplier*1000.), 'forces_N_Nmm': result[2].tolist(), 'norms_MPa': norms,
        'tolerance_MPa': tolerance, 'control_error_MPa': float(30000.*(projection@field+load_projection*multiplier-target_control)),
        'field': field.tolist(), 'failure': failure,
        'longitudinal_bar_strains': (section.a@field).reshape(3, -1)[:, :4].tolist(),
        'hoop_max_abs_strain': float(np.max(np.abs((section.a@field).reshape(3, -1)[:, 4:]))),
    }


def TestTrace(repo, native, output, steps, difference_step=2e-9, selected=('bar26', 'twist', 'secant'), tangent='finite'):
    """Сравнивает заранее выбранные меры от одного принятого поля без внешнего прогноза."""
    section, history, points, replay = TestRestore(repo, native)
    tangent_function = None if tangent == 'finite' else run_path(str(Path(__file__).with_name('TestClosedASDTangent.py')))['TestGlobalMatrix']
    earlier_q, earlier_field = points[-2]
    current_q, current_field = points[-1]
    delta = current_field-earlier_field
    secant = delta.copy()
    secant[56:] = 0.
    secant /= np.linalg.norm(secant)
    twist = np.zeros(60)
    twist[3] = 1.
    variants = {}
    for name, projection in (('bar26', section.a[0].copy()), ('twist', twist), ('secant', secant), ('arc', secant)):
        if name not in selected:
            continue
        previous, current = earlier_field.copy(), current_field.copy()
        prior_q, q = earlier_q, current_q
        load_projection = 0.
        load_weight = np.linalg.norm(delta[:56])/(current_q-earlier_q)
        if name == 'arc':
            projection = secant/np.sqrt(2.)
            load_projection = load_weight/np.sqrt(2.)
        old, control = float(projection@previous+load_projection*prior_q), float(projection@current+load_projection*q)
        increment = .5*(control-old)
        assert abs(increment) > 1e-15, (name, increment)
        accepted_history = tuple(part.copy() for part in history)
        rows = []
        for index in range(steps):
            if name == 'arc':
                tangent = current-previous
                tangent[56:] = 0.
                distance = np.sqrt(tangent@tangent+(load_weight*(q-prior_q))**2)
                projection = tangent/distance
                load_projection = load_weight**2*(q-prior_q)/distance
                old = float(projection@previous+load_projection*prior_q)
                control = float(projection@current+load_projection*q)
            step = increment
            for attempt in range(6):
                target = control+step
                ratio = step/(control-old)
                seed = current+ratio*(current-previous)
                guessed = q+ratio*(q-prior_q)
                field, value, proposed, row = TestControlledStep(section, accepted_history, projection, target, seed, guessed, difference_step, load_projection, tangent_function)
                row['step_index'], row['attempt'] = index, attempt
                row['projection'], row['load_projection'] = projection.tolist(), float(load_projection)
                rows.append(row)
                print(name, index, attempt, row['accepted'], row['Qy_N'], row['norms_MPa'][-1], flush=True)
                if row['accepted']:
                    previous, prior_q, old = current, q, control
                    current, q, control, accepted_history = field, value, target, proposed
                    break
                step *= .5
            else:
                break
        variants[name] = {'projection': projection.tolist(), 'initial_increment': increment, 'trials': rows}
    output.write_bytes((json.dumps({'native_replay': replay, 'variants': variants, 'difference_step': difference_step, 'tangent': tangent,
                                  'integration_modified': True, 'physical_capacity_certified': False},
                                 indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--steps', type=int, default=4)
    parser.add_argument('--difference-step', type=float, default=2e-9)
    parser.add_argument('--tangent', choices=('finite', 'closed-ad'), default='finite')
    parser.add_argument('--projections', nargs='+', choices=('bar26', 'twist', 'secant', 'arc'), default=['bar26', 'twist', 'secant'])
    args = parser.parse_args()
    TestTrace(args.repo.resolve(), args.native.resolve(), args.out.resolve(), args.steps, args.difference_step, args.projections, args.tangent)
