"""ДЛЯ ТЕСТОВ: независимо решает те же нативные контрольные цели из одной принятой истории."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestRun(repo, folder, fine_prefix, force_prefix, native_control, output):
    """Не использует нативные управляемые поля и силы как прогнозы; заимствует только заданные цели деформации."""
    section, history, fields = run_path(str(folder/'TestResolutionSection.py'))['TestReplay'](
        repo, force_prefix, output.with_suffix('.Prefix.json'), prefix_native=fine_prefix)
    prefix = json.loads(output.with_suffix('.Prefix.json').read_bytes())['states']
    assert len(prefix) == 42
    previous_q, previous = prefix[-2]['target_N_Nmm'][5]/1000., fields[-2][1]
    q, field = prefix[-1]['target_N_Nmm'][5]/1000., fields[-1][1]
    same = {row[1]: np.asarray(row[2:], dtype=float) for row in
            (line.split(';') for line in (native_control/'Operators.csv').read_text('cp1251').splitlines())
            if row[0] == 'F' and not row[1].startswith('TransferredControl')}
    for label, accepted in fields[-4:]:
        assert np.array_equal(accepted, same[label]), label
    prescribed = [row.split(';') for row in (native_control/'MVTGaussMixed.txt').read_text('utf-8-sig').splitlines()
                  if row.startswith('TRANSFER_CONTROL_ACCEPTED;')]
    assert len(prescribed) == 30
    projection = section.a[0]
    trace = run_path(str(folder/'Trace-TestClosedASDControl.py'))['TestControlledStep']
    tangent = run_path(str(folder/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    records = []
    for label, current in zip(prefix[-2:], (previous, field), strict=True):
        assert current.shape == (section.TestDof,)
    old, control = float(projection@previous), float(projection@field)
    for record in prescribed:
        target = float(record[2])
        ratio = (target-control)/(control-old)
        seed = field+ratio*(field-previous)
        guessed = q+ratio*(q-previous_q)
        candidate, value, proposed, row = trace(section, history, projection, target, seed, guessed, tangent_function=tangent)
        row['native_comparison_Qy_N'] = float(record[3])
        if row['accepted']:
            assert abs(row['Qy_N']-float(record[3])) <= row['tolerance_MPa']*section.force_scale[5]
        records.append(row)
        print('same control', record[1], row['accepted'], row['Qy_N'], abs(row['Qy_N']-float(record[3])), flush=True)
        if not row['accepted']:
            break
        previous, previous_q, old = field, q, control
        field, q, control, history = candidate, value, target, proposed
    proof = {'shared_prefix_states': len(prefix), 'trials': records,
             'native_fields_used_as_seeds': False, 'native_forces_used_as_seeds': False,
             'targets_completed': len(records) == 30 and all(row['accepted'] for row in records),
             'maximum_Qy_difference_N': max(abs(row['Qy_N']-row['native_comparison_Qy_N']) for row in records),
             'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    assert proof['targets_completed']


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--folder', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--fine-prefix', type=Path, required=True)
    parser.add_argument('--force-prefix', type=Path, required=True)
    parser.add_argument('--native-control', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.folder.resolve(), args.fine_prefix.resolve(), args.force_prefix.resolve(),
            args.native_control.resolve(), args.out.resolve())
