"""ДЛЯ ТЕСТОВ: сохраняет нативные дискретизации, перенос и продолжение с точными VBA-контейнерами."""

from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile


TestCases = {
    'G7S1': 'ClosedASDG7S120261118', 'G9S1': 'ClosedASDG9S120261118',
    'G5S2': 'ClosedASDG5S220261118', 'G7Fine': 'ClosedASDG7Fine20261118',
    'Transfer': 'ClosedASDNativeTransfer20261118',
    'ControlFailed': 'ClosedASDNativeTransferControl20261118',
    'Control': 'ClosedASDNativeTransferControl0220261118',
}


def TestCopy(source, target):
    """Копирует точные байты в новый архивный комплект, сохраняя вложенные каталоги."""
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = source.read_bytes()
    if target.exists():
        assert target.read_bytes() == raw
    else:
        target.write_bytes(raw)


def TestChunks(raw, root):
    """Сохраняет общие фрагменты CFB один раз; восстановление проверяется по полному SHA-256."""
    chunk_size = 262144
    keys = []
    folder = root/'VBAChunks'
    folder.mkdir(exist_ok=True)
    for first in range(0, len(raw), chunk_size):
        chunk = raw[first:first+chunk_size]
        key = sha256(chunk).hexdigest().upper()
        path = folder/(key+'.bin')
        if path.exists():
            assert path.read_bytes() == chunk
        else:
            path.write_bytes(chunk)
        keys.append(key)
    return {'bytes': len(raw), 'sha256': sha256(raw).hexdigest().upper(), 'chunk_size': chunk_size, 'chunks': keys}


def TestRecoverFailureFiles(source, target):
    """Сохраняет уже записанные поля после терминального сбоя теста, когда драйвер не дошёл до копирования тензоров."""
    closure = json.loads((source/'Native/MVTGaussMixed.txt.ProcessClosure.json').read_text('utf-8-sig'))
    assert closure['ChildExitCode'] == 1 and closure['Passed'] and closure['Closure']['FinalState']['State'] == 'Absent'
    log = (source/'Native/MVTGaussMixed.txt').read_text('utf-8-sig')
    fixture, = re.findall(r'^FIXTURE: ([^\r\n]+)$', log, re.M)
    folder = Path(fixture).parent.resolve()
    assert folder.is_relative_to((source/'Temp').resolve()) and folder.name.startswith('RC_NDM_ModeSuite_')
    receipt = {}
    for suffix, name in (('.Operators.csv', 'Operators.csv'), ('.Tensor.csv', 'MVTGaussMixed.Tensor.csv')):
        file = folder/('MVT2GaussSpan.csv'+suffix)
        TestCopy(file, target/'Native'/name)
        receipt[name] = {'source': str(file), 'sha256': sha256(file.read_bytes()).hexdigest().upper()}
    (target/'FailedRunnerTensorCapture.json').write_bytes((json.dumps(receipt, indent=2, sort_keys=True)+'\n').encode())


def TestCollect():
    """Собирает только завершённые собственные запуски; не включает пользовательские Excel и временные книги."""
    repo = Path.cwd()
    here = Path(__file__).resolve().parent
    root = here/'ResolutionEvidenceBundle'
    root.mkdir()
    sources = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    for name, source_name in TestCases.items():
        source, target = sources/source_name, root/name
        target.mkdir()
        prep = json.loads((source/'Preparation.json').read_bytes())
        compiler = json.loads((source/'docs/regression/CodeUpdate.json').read_text('utf-8-sig'))
        closure = json.loads((source/'Native/MVTGaussMixed.txt.ProcessClosure.json').read_text('utf-8-sig'))
        assert closure['Passed'] and closure['Closure']['FinalState']['State'] == 'Absent'
        assert closure['ChildExitCode'] == (1 if name == 'ControlFailed' else 0)
        for relative, expected in prep['inputs'].items():
            assert '..' not in Path(relative).parts and not Path(relative).is_absolute()
            file = source/relative
            assert sha256(file.read_bytes()).hexdigest().upper() == expected, (name, relative)
            if file.suffix == '.xlsm':
                TestCopy(file, root/'SourceBooks'/(expected+'.xlsm'))
            else:
                TestCopy(file, target/relative)
        for relative in ('Preparation.json', 'Compile.log', 'CompileClosure.json', 'Run.ndjson', 'docs/regression/CodeUpdate.json'):
            TestCopy(source/relative, target/Path(relative).name)
        for file in (source/'Native').rglob('*'):
            if file.is_file():
                TestCopy(file, target/'Native'/file.relative_to(source/'Native'))
        if name == 'ControlFailed':
            TestRecoverFailureFiles(source, target)
        book = source/'docs/regression/Diagnostic.xlsm'
        assert sha256(book.read_bytes()).hexdigest().upper() == compiler['WorkbookSHA256']
        with ZipFile(book) as archive:
            container = TestChunks(archive.read('xl/vbaProject.bin'), root)
        (target/'CompiledVBA.json').write_bytes((json.dumps(container, indent=2, sort_keys=True)+'\n').encode())
    scripts = ('Probe-TestASDMaterialSteps.py', 'Probe-TestASDClosure.py', 'Solve-TestASDClosure.py',
               'Solve-TestSingleASDTangent.py', 'TestClosedASDTangent.py', 'Trace-TestClosedASDControl.py',
               'TestResolutionSection.py', 'Stage-TestASDResolution.py', 'Continue-TestResolution.py',
               'Control-TestResolution.py', 'Compare-TestResolutionStates.py', 'Prolong-TestResolution.py',
               'Stage-TestTransferredNative.py', 'TestTransferContinuation.bas.txt',
               'Stage-TestNativeTransferredControl.py', 'TestNativeTransferredControl.bas.txt',
               'Replay-TestResolutionOpenSees.py', 'Check-TestASDSourceBehavior.py', 'Replay-TestASDIntegration.py',
               'Collect-TestASDResolution.py')
    for name in scripts:
        TestCopy(here/name, root/name)
    for file in here.glob('Resolution*.json*'):
        TestCopy(file, root/file.name)
    old = sources/'ClosedASDForcePath20261117/Native'
    for name in ('Operators.csv', 'MVTGaussMixed.csv', 'MVTGaussMixed.Tensor.csv', 'MVTGaussMixed.txt'):
        TestCopy(old/name, root/'G5S1/Native'/name)
    (root/'Cases.json').write_bytes((json.dumps(TestCases, indent=2, sort_keys=True)+'\n').encode())
    expected = {
        'workbook/output/RC_Section_NDM.xlsm': 'E47ACB7083D92310F9915FD5EB59DA6A7B6C52F352D5EE274A2DCDC6BA567450',
        'workbook/output/VBA_All_Code.txt': 'DB8023F9384B0059E1D1C51D59FE0E62F9B8CD94AC4D9B329DD0EE810AF676CC',
        'src/Solver/CCoupledNewtonSolver.cls': 'E960D4DDFB01B4FECA54472901A3A9A4E5BD9B7765CEA780E621E15BFC9600A7'}
    for name, digest in expected.items():
        assert sha256((repo/name).read_bytes()).hexdigest().upper() == digest
    (root/'ProductionUnchanged.json').write_bytes((json.dumps(expected, indent=2, sort_keys=True)+'\n').encode())
    print('RESOLUTION NATIVE EVIDENCE COLLECTED', len(TestCases), len(list((root/'VBAChunks').glob('*'))))


if __name__ == '__main__':
    TestCollect()
