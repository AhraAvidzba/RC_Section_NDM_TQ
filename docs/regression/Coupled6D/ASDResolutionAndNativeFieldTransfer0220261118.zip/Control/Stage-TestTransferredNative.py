"""ДЛЯ ТЕСТОВ: готовит нативную проверку переноса собственного грубого прогноза в уточнённую секцию."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path


def TestStage(root):
    """Сохраняет уточнённую историю и рабочий Ньютон; новые поля грубой секции не передаются в историю материалов."""
    here = Path(__file__).resolve().parent
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/ClosedASDG5S220261118')
    coarse = Path('D:/CodexScratch/RC_Section_NDM_TQ/ClosedASDG7S120261118/Native')
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, expected in prep['inputs'].items():
        raw = (template/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, name
        files[name] = raw
    old_name, new_name = 'modTestMVT2ResolutionTest', 'modTestMVT2TransferTest'
    code = files.pop('tests/'+old_name+'.bas').decode('utf-8-sig').replace('\r\n', '\n')
    code = code.replace(old_name, new_name).replace('RunTestMVT2ResolutionTest', 'RunTestMVT2TransferTest')
    code = code.replace('TOTAL_MVT2_RESOLUTION_TEST', 'TOTAL_MVT2_TRANSFER_TEST')
    old = 'completed = RunMVT2TorqueContinuationTest(5, report, tracePath, True, True)'
    assert code.count(old) == 1
    code = code.replace(old, 'completed = RunTransferredMVT2Test(report, tracePath)')
    code += '\n'+(here/'TestTransferContinuation.bas.txt').read_text('utf-8')
    files['tests/'+new_name+'.bas'] = code.replace('\n', '\r\n').encode('utf-8-sig')
    driver = files['Run-Native.ps1'].decode('utf-8-sig').replace(old_name, new_name)
    driver = driver.replace('RunTestMVT2ResolutionTest', 'RunTestMVT2TransferTest')
    files['Run-Native.ps1'] = driver.encode('utf-8-sig')
    prefix = [line for line in (template/'Native/Operators.csv').read_text('cp1251').splitlines() if line.startswith('F;')]
    assert len(prefix) == 38 and len(prefix[-1].split(';')) == 89
    files['FinePrefix.csv'] = ('\r\n'.join(prefix)+'\r\n').encode('cp1251')
    fields = {row[1]: row[2:] for row in (line.split(';') for line in (coarse/'Operators.csv').read_text('cp1251').splitlines()) if row[0] == 'F'}
    seeds = []
    requested = {65000., 67500., 70000., 72500., 72812.5}
    for line in (coarse/'MVTGaussMixed.Tensor.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME' and float(row[3]) in requested:
            seeds.append('SEED;'+row[3]+';'+';'.join(fields[row[1]]))
    assert len(seeds) == 5
    files['CoarseSeeds.csv'] = ('\r\n'.join(seeds)+'\r\n').encode('cp1251')
    files[Path(__file__).name] = Path(__file__).read_bytes()
    files['TestTransferContinuation.bas.txt'] = (here/'TestTransferContinuation.bas.txt').read_bytes()
    files['docs/regression/Diagnostic.xlsm'] = files['workbook/output/RC_Section_NDM.xlsm']
    prep['inputs'] = {name: sha256(raw).hexdigest().upper() for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    prep['test_scope'] = 'replay own 38 fine accepted states; try force targets 65000,67500,70000,72500,72812.5 N with own coarse prolongation only on direct failure'
    prep['history_source'] = 'ClosedASDG5S220261118/Native/Operators.csv, all 38 F records'
    prep['seed_source'] = 'ClosedASDG7S120261118/Native/Operators.csv, exact own native fields at requested forces'
    root.mkdir()
    for directory in ('Native', 'Temp', 'src', 'tests'):
        (root/directory).mkdir(exist_ok=True)
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE COARSE FIELD TRANSFER INPUTS READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve())
