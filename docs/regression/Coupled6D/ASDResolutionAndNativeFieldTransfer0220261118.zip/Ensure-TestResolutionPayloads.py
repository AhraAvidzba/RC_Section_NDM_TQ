"""ДЛЯ ТЕСТОВ: восстанавливает отдельные двоичные части проверенного комплекта по SHA-256."""

from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


def TestEnsure(root, repo):
    """Распаковывает только явно закреплённые книги и CFB-фрагменты внутрь каталога проверки."""
    metadata = json.loads((root/'ResolutionPayloads.json').read_bytes())
    for entry in metadata.values():
        archive = repo/'docs/regression/Coupled6D'/(entry['archive']+'.zip')
        assert sha256(archive.read_bytes()).hexdigest().upper() == entry['sha256']
        directory = root/entry['directory']
        if directory.exists():
            continue
        with ZipFile(archive) as source:
            for member in source.infolist():
                relative = Path(member.filename)
                assert not relative.is_absolute() and '..' not in relative.parts
                assert relative.parts[0] == entry['directory'] and not member.is_dir()
                target = (root/relative).resolve()
                assert target.is_relative_to(root.resolve()) and not target.exists()
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.read(member))
        assert directory.exists()
