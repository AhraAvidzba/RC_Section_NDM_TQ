"""ДЛЯ ТЕСТОВ: готовит нативное продолжение после собственного перенесённого прогноза."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root):
    """Использует тот же восстановленный префикс и добавляет штатный деформационный решатель VBA."""
    here = Path(__file__).resolve().parent
    if not root.exists():
        run_path(str(here/'Stage-TestTransferredNative.py'))['TestStage'](root)
    else:
        assert not (root/'Compile.log').exists() and not (root/'Native/MVTGaussMixed.txt').exists()
        frozen = json.loads((root/'Preparation.json').read_bytes())
        for name, expected in frozen['inputs'].items():
            assert sha256((root/name).read_bytes()).hexdigest().upper() == expected, name
    old_name, new_name = 'modTestMVT2TransferTest', 'modTestMVT2TransferControlTest'
    old_path, new_path = root/'tests'/(old_name+'.bas'), root/'tests'/(new_name+'.bas')
    code = old_path.read_text('utf-8-sig').replace('\r\n', '\n')
    code = code.replace(old_name, new_name).replace('RunTestMVT2TransferTest', 'RunTestMVT2TransferControlTest')
    code = code.replace('TOTAL_MVT2_TRANSFER_TEST', 'TOTAL_MVT2_TRANSFER_CONTROL_TEST')
    start = code.index('Private Function RunTransferredMVT2Test(')
    before, code = code[:start], code[start:]
    needle = '    Dim field() As Double, actual() As Double, expected(1 To 6) As Double, residual As Double, i As Long'
    assert code.count(needle) == 1
    code = code.replace(needle, needle+'\n    Dim previousField() As Double, previousQ As Double, currentQ As Double\n    previousField = history(history.Count - 1): previousQ = 64375#: currentQ = 64687.5')
    needle = '''        If Not solved Then
            solver.DiscardStep
            Exit Function
        End If
        solver.CopyTrial field, actual'''
    assert code.count(needle) == 1
    code = code.replace(needle, '''        If Not solved Then
            solver.DiscardStep
            RunTransferredMVT2Test = RunTransferredControlTest(solver, operators, previousField, previousQ, currentQ, report, tracePath, stations)
            Exit Function
        End If
        solver.CopyTrial field, actual''')
    needle = '''        solver.AcceptStep
        row = "MVT_TRANSFER_ACCEPTED;"'''
    assert code.count(needle) == 1
    code = code.replace(needle, '''        solver.CopyAccepted previousField
        previousQ = currentQ: currentQ = CDbl(load)
        solver.AcceptStep
        row = "MVT_TRANSFER_ACCEPTED;"''')
    code = before+code+'\n'+(here/'TestNativeTransferredControl.bas.txt').read_text('utf-8')
    new_path.write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    old_path.unlink()
    driver = (root/'Run-Native.ps1').read_text('utf-8-sig').replace(old_name, new_name)
    driver = driver.replace('RunTestMVT2TransferTest', 'RunTestMVT2TransferControlTest')
    (root/'Run-Native.ps1').write_bytes(driver.encode('utf-8-sig'))
    for name in (Path(__file__).name, 'TestNativeTransferredControl.bas.txt'):
        (root/name).write_bytes((here/name).read_bytes())
    prep = json.loads((root/'Preparation.json').read_bytes())
    del prep['inputs']['tests/'+old_name+'.bas']
    for name in ('tests/'+new_name+'.bas', 'Run-Native.ps1', Path(__file__).name, 'TestNativeTransferredControl.bas.txt'):
        prep['inputs'][name] = sha256((root/name).read_bytes()).hexdigest().upper()
    prep['test_scope'] += '; on final force failure switch to 30 native first-longitudinal-bar control steps with 32 Newton iterations and unchanged residual tolerances'
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE TRANSFERRED CONTROL INPUTS READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.root.resolve())
