"""ДЛЯ ТЕСТОВ: готовит направленный нативный контроль дискретизации MVT2."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


def TestReplace(code, old, new):
    """Меняет только однозначно найденный фрагмент закреплённого тестового источника."""
    assert code.count(old) == 1, old
    return code.replace(old, new)


def TestRule(order):
    """Готовит положительное правило Гаусса и независимо проверяет все полиномиальные моменты."""
    node, weight = np.polynomial.legendre.leggauss(order)
    node, weight = (node+1.)/2., weight/2.
    errors = [abs(float(weight@(node**degree))-1./(degree+1.)) for degree in range(2*order)]
    assert np.min(weight) > 0. and np.max(errors) < 3e-15
    assert np.max(np.abs(node+node[::-1]-1.)) < 1e-15
    body = ["' -------------------- ДЛЯ ТЕСТОВ --------------------",
            "' Узлы и веса Гаусса-Лежандра на [0, 1]; моменты проверены независимо до степени 2n-1.",
            'Private Sub GaussUnitRuleTest(ByRef node() As Double, ByRef weight() As Double)']
    for i, (x, w) in enumerate(zip(node, weight, strict=True), 1):
        body.append(f'    node({i}) = {float(x):.17g}#: weight({i}) = {float(w):.17g}#')
    body.append('End Sub')
    return '\n'.join(body), {'order': order, 'nodes': node.tolist(), 'weights': weight.tolist(), 'moment_errors': errors}


def TestStage(root, order, spans, point_perturbation=2e-9):
    """Переиспользует материал §591 и рабочий Ньютон; меняет только правило и число интервалов базиса."""
    template = Path('D:/CodexScratch/RC_Section_NDM_TQ/ClosedASDForcePath20261117')
    prep = json.loads((template/'Preparation.json').read_bytes())
    files = {}
    for name, expected in prep['inputs'].items():
        raw = (template/name).read_bytes()
        assert sha256(raw).hexdigest().upper() == expected, name
        files[name] = raw
    quad = 'src/Solver/CCoupledSectionQuadrature.cls'
    code = files[quad].decode('utf-8-sig').replace('\r\n', '\n')
    code = code.replace('GAUSS5_ORDER', 'TEST_GAUSS_ORDER')
    code = TestReplace(code, 'Private Const TEST_GAUSS_ORDER As Long = 5', f'Private Const TEST_GAUSS_ORDER As Long = {order}')
    code = code.replace('PrepareFullSpanGauss', 'PrepareFullSpanGaussTest')
    code = code.replace('Gauss5UnitRule', 'GaussUnitRuleTest')
    rule, moments = TestRule(order)
    if order != 5:
        first = code.index('Private Sub GaussUnitRuleTest(')
        last = code.index('End Sub', first)+len('End Sub')
        code = code[:first]+rule+code[last:]
    code = code.replace("' При включенной пробе полные интервалы получают по 25 узлов Гаусса.",
                        "' ДЛЯ ТЕСТОВ: полные интервалы получают TEST_GAUSS_ORDER ^ 2 узлов Гаусса.")
    code = code.replace("' Полный интервал меняется целиком после сверки 25 исходных ячеек и новых точек.",
                        "' ДЛЯ ТЕСТОВ: интервал меняется целиком после проверки всех исходных ячеек и новых узлов.")
    code = code.replace("' Узлы и положительные веса пяти точек Гаусса–Лежандра на [0, 1].\n' Правило точно интегрирует одномерные полиномы степени не выше девяти.\n", '')
    files[quad] = code.replace('\n', '\r\n').encode('utf-8-sig')
    old_module = 'modTestMVT2ClosureForcePath'
    new_module = 'modTestMVT2ResolutionTest'
    module_path = 'tests/'+old_module+'.bas'
    code = files.pop(module_path).decode('utf-8-sig').replace('\r\n', '\n')
    code = code.replace(old_module, new_module).replace('RunTestMVT2ClosureForcePath', 'RunTestMVT2ResolutionTest')
    code = code.replace('TOTAL_MVT2_CLOSURE_FORCE_PATH', 'TOTAL_MVT2_RESOLUTION_TEST')
    code = TestReplace(code, 'RunMVT2TorqueContinuationTest(5, report, tracePath, True, True)',
                        f'RunMVT2TorqueContinuationTest({order}, report, tracePath, True, True)')
    code = TestReplace(code, 'operators.PrepareModel section, EC, NU, 1, 1, quadraturePoints,',
                        f'operators.PrepareModel section, EC, NU, {spans}, {spans}, quadraturePoints,')
    code = TestReplace(code, 'operators.ConcretePointCount <> quadraturePoints ^ 2',
                        f'operators.ConcretePointCount <> ({spans} * quadraturePoints) ^ 2')
    expected_dof = 12+3*(spans+3)**2
    code = TestReplace(code, 'operators.DegreeCount <> 60', f'operators.DegreeCount <> {expected_dof}')
    code = TestReplace(code, 'operators.PointCount <> operators.ConcretePointCount + 20',
                        f'operators.PointCount <> operators.ConcretePointCount + {4+16*spans}')
    files['tests/'+new_module+'.bas'] = code.replace('\n', '\r\n').encode('utf-8-sig')
    material = 'src/Materials/CCoupledConcreteResponse.cls'
    if point_perturbation != 2e-9:
        code = files[material].decode('utf-8-sig').replace('\r\n', '\n')
        code = TestReplace(code, 'Private Const STRAIN_PERTURBATION As Double = 0.000000002',
                           f'Private Const STRAIN_PERTURBATION As Double = {point_perturbation:.15f}')
        files[material] = code.replace('\n', '\r\n').encode('utf-8-sig')
    driver = files['Run-Native.ps1'].decode('utf-8-sig').replace(old_module, new_module)
    driver = driver.replace('RunTestMVT2ClosureForcePath', 'RunTestMVT2ResolutionTest')
    driver = TestReplace(driver, "$timeout='165'", "$timeout='240'")
    files['Run-Native.ps1'] = driver.encode('utf-8-sig')
    files[Path(__file__).name] = Path(__file__).read_bytes()
    files['GaussRuleTest.json'] = (json.dumps(moments, indent=2, sort_keys=True)+'\n').encode()
    files['docs/regression/Diagnostic.xlsm'] = files['workbook/output/RC_Section_NDM.xlsm']
    prep['inputs'] = {name: sha256(raw).hexdigest().upper() for name, raw in files.items() if name != 'docs/regression/Diagnostic.xlsm'}
    prep['test_scope'] = 'eight original torque goals and all 37 original mixed force goals with original bisection budget'
    prep['gauss_order_per_span_axis'] = order
    prep['spline_spans_per_axis'] = spans
    prep['expected_concrete_points'] = (order*spans)**2
    prep['expected_degrees'] = expected_dof
    prep['material_tangent_strain_step'] = point_perturbation
    prep['base_stage_commit'] = 'c397dfe'
    root.mkdir()
    for directory in ('Native', 'Temp', 'tests', 'src'):
        (root/directory).mkdir(exist_ok=True)
    for name, raw in files.items():
        path = root/name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('ASD RESOLUTION INPUTS READY', order, spans, prep['expected_concrete_points'], expected_dof)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--order', type=int, choices=(5, 7, 9), required=True)
    parser.add_argument('--spans', type=int, choices=(1, 2, 3), required=True)
    parser.add_argument('--point-perturbation', type=float, choices=(2e-9, 2e-11), default=2e-9)
    args = parser.parse_args()
    TestStage(args.root.resolve(), args.order, args.spans, args.point_perturbation)
