"""ДЛЯ ТЕСТОВ: продолжает уточнённую нативную историю по деформации продольного стержня."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestRun(repo, native, continuation, output, steps, prior_control=None):
    """Свободная сила Qy сохраняет T и соотношение Mx/Qy; новые состояния принимаются только по полной невязке."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Replay-TestASDIntegration.py'))['TestMemory']()
    section, history, fields = run_path(str(here/'TestResolutionSection.py'))['TestReplay'](repo, native, output.with_suffix('.Prefix.json'))
    prefix = json.loads(output.with_suffix('.Prefix.json').read_bytes())['states']
    points = [(record['target_N_Nmm'][5]/1000., field) for record, (_, field) in zip(prefix, fields, strict=True)]
    for row in json.loads(continuation.read_bytes())['trials']:
        if not row['accepted']:
            continue
        field, target = np.asarray(row['field']), np.asarray(row['target'])
        result = section.evaluate(field, history, target)
        assert result[1] <= row['tolerance_MPa']
        points.append((target[5]/1000., field))
        history = result[4]
    projection = section.a[0]
    previous_q, previous = points[-2]
    q, field = points[-1]
    old, control = float(projection@previous), float(projection@field)
    maximum_step = min(abs(.5*(control-old)), 1e-5)
    increment = np.sign(control-old)*maximum_step
    assert abs(increment) > 2e-9
    records = []
    first_index = 0
    if prior_control is not None:
        prior = json.loads(prior_control.read_bytes())
        assert np.array_equal(projection, prior['projection'])
        records = prior['trials'].copy()
        for row in records:
            if not row['accepted']:
                continue
            candidate = np.asarray(row['field'])
            value = row['Qy_N']/1000.
            target = np.array([0., -396000.*value, 0., 10510000., 0., 1000.*value])
            result = section.evaluate(candidate, history, target)
            assert result[1] <= row['tolerance_MPa']
            previous, previous_q, old = field, q, control
            field, q, control, history = candidate, value, row['control_target'], result[4]
        first_index = 1+max(row['step_index'] for row in records)
        increment = np.sign(increment)*min(maximum_step, 2.*abs(control-old))
    trace = run_path(str(here/'Trace-TestClosedASDControl.py'))['TestControlledStep']
    tangent = run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    stop_reason = 'RequestedStepsCompleted'
    for index in range(first_index, first_index+steps):
        step = increment
        accepted_step = False
        for attempt in range(8):
            load = np.array([0., -396000.*q, 0., 10510000., 0., 1000.*q])
            control_resolution = (5e-7+5e-7*np.max(np.abs((load@section.l)[:len(field)-4])))/30000.
            if abs(step) < 10.*control_resolution:
                stop_reason = 'ControlIncrementBelowTenResidualResolutions'
                break
            target = control+step
            ratio = step/(control-old)
            seed = field+ratio*(field-previous)
            guessed = q+ratio*(q-previous_q)
            candidate, value, proposed, row = trace(section, history, projection, target, seed, guessed, tangent_function=tangent)
            row['step_index'], row['attempt'] = index, attempt
            records.append(row)
            print(index, attempt, row['accepted'], row['Qy_N'], row['norms_MPa'][-1], flush=True)
            if row['accepted']:
                accepted_step = True
                previous, previous_q, old = field, q, control
                field, q, control, history = candidate, value, target, proposed
                increment = np.sign(increment)*min(maximum_step, 2.*abs(step))
                break
            step *= .5
        if not accepted_step:
            if stop_reason == 'RequestedStepsCompleted':
                stop_reason = 'NoAcceptedControlStep'
            break
    proof = {'native_prefix_states': len(prefix), 'controlled_point_ID': section.TestConcreteCount+1,
             'projection': projection.tolist(), 'trials': records, 'requested_steps': first_index+steps,
             'maximum_control_step': maximum_step,
             'stop_reason': stop_reason,
             'physical_capacity_certified': False, 'closed_integration': True}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--continuation', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--steps', type=int, default=30)
    parser.add_argument('--prior-control', type=Path)
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.native.resolve(), args.continuation.resolve(), args.out.resolve(), args.steps,
            args.prior_control.resolve() if args.prior_control is not None else None)
