"""ДЛЯ ТЕСТОВ: продолжает подтверждённую нативную историю на уточнённой квадратуре."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestRun(repo, native, output, schedule='diagnostic'):
    """Использует собственный секущий прогноз и согласованную касательную; не меняет нагрузки и допуски."""
    here = Path(__file__).resolve().parent
    replay = run_path(str(here/'TestResolutionSection.py'))['TestReplay']
    section, history, fields = replay(repo, native, output.with_suffix('.Prefix.json'))
    tangent = run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    correct = run_path(str(here/'Solve-TestSingleASDTangent.py'))['TestCorrection']
    solve = run_path(str(here/'Solve-TestASDClosure.py'))['TestSolve']
    section.correction = lambda f, h, r, method, delta: correct(section, f, h, r, tangent, single_update=False)
    prefix = json.loads(output.with_suffix('.Prefix.json').read_bytes())['states']
    prior_q, previous = prefix[-2]['target_N_Nmm'][5], fields[-2][1]
    q, field = prefix[-1]['target_N_Nmm'][5], fields[-1][1]
    trials = []
    requested_loads = (73750., 75000., 76000., 77500., 80000.)
    if schedule == 'original':
        requested_loads = (*np.arange(2500., 60001., 2500.), 61250., 62500., 65000., 67500., 70000.,
                           72500., 72812.5, 73750., 75000., 75312.5, 76000., 77500., 77625., 80000.)
    for requested in requested_loads:
        if requested <= q:
            continue
        ratio = (requested-q)/(q-prior_q)
        seed = field+ratio*(field-previous)
        load = np.array([0., -396.*requested, 0., 10510000., 0., requested])
        candidate, proposed, record = solve(section, load, seed, history)
        trials.append(record)
        print('continued force', requested, record['accepted'], record['norms_MPa'][-1], flush=True)
        if not record['accepted']:
            break
        previous, prior_q, field, q, history = field, q, candidate, requested, proposed
    proof = {'prefix_states': len(prefix), 'concrete_points': section.TestConcreteCount,
             'degrees': section.TestDof, 'trials': trials, 'schedule': schedule,
             'physical_capacity_certified': False, 'full_force_schedule_completed': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--schedule', choices=('diagnostic', 'original'), default='diagnostic')
    args = parser.parse_args()
    TestRun(args.repo.resolve(), args.native.resolve(), args.out.resolve(), args.schedule)
