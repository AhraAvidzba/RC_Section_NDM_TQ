"""ДЛЯ ТЕСТОВ: повторяет в реальном OpenSees всю материальную историю уточнённой ветви MVT2."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from subprocess import run, PIPE
from tempfile import TemporaryDirectory
import sys

import numpy as np


TestBinary = '25BA42E1672526137D765D9C3631D1403E091F54F5AFCDB9242F9243C63C3A96'


def TestInputs(repo, folder, native, continuation, controls):
    """Передаёт внешнему материалу деформации, сохраняя все внутренние фиксации исследовательского замыкания."""
    reference = run_path(str(folder/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    section = run_path(str(folder/'TestResolutionSection.py'))['TestResolutionSection'](native, reference, True)
    target = {}
    for line in (native/'MVTGaussMixed.Tensor.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME':
            target[row[1]] = np.array([0., -396.*float(row[3]), 0., float(row[2]), 0., float(row[3])])
    path = [(row[1], np.asarray(row[2:], dtype=float), target[row[1]], None) for row in
            (line.split(';') for line in (native/'Operators.csv').read_text('cp1251').splitlines()) if row[0] == 'F']
    for index, row in enumerate(json.loads(continuation.read_bytes())['trials']):
        if row['accepted']:
            path.append(('OwnForce'+str(index), np.asarray(row['field']), np.asarray(row['target']), None))
    controlled = json.loads(controls.read_bytes())
    projection = np.asarray(controlled['projection'])
    for row in controlled['trials']:
        if row['accepted']:
            q = row['Qy_N']
            path.append(('OwnControl'+str(row['step_index']), np.asarray(row['field']),
                         np.array([0., -396.*q, 0., 10510000., 0., q]), row['control_target']))
    frames, expected, endpoints = [], [], []
    original = section.TestOriginalNominal

    def TestRecord(field, history):
        """Сохраняет один материальный вызов до его внешней фиксации; отклонённых глобальных проб здесь нет."""
        response = original(field, history)
        concrete = response[0].copy()
        concrete[:, section.TestConcreteCount:] *= -1.
        frames.append(response[3][0].reshape(-1, 6).tolist())
        expected.append(concrete.reshape(-1, 6).tolist())
        return response

    section.TestOriginalNominal = TestRecord
    history = section.initial()
    for label, field, load, control in path:
        result = section.evaluate(field, history, load)
        tolerance = float(5e-7+5e-7*np.max(np.abs((load@section.l)[:section.TestDof-4])))
        norm = float(result[1])
        if control is not None:
            norm = max(norm, abs(float(30000.*(projection@field-control))))
        assert norm <= tolerance, (label, norm, tolerance)
        history = result[4]
        endpoints.append({'label': label, 'frame': len(frames)-1, 'field': field.tolist(), 'target': load.tolist(),
                          'steel': result[5].tolist(), 'tolerance_MPa': tolerance, 'control': control})
    return section, frames, expected, endpoints, projection


def TestCapture(repo, folder, native, continuation, controls, interpreter, output):
    """Сохраняет полный ответ загруженного нативного модуля; историю каждой точки не разрывает."""
    section, frames, _, endpoints, _ = TestInputs(repo, folder, native, continuation, controls)
    helper = run_path(str(folder/'Probe-TestASDMaterialSteps.py'))
    source = run_path(str(folder/'Check-TestASDSourceBehavior.py'))['REPLAY']
    memory = run_path(str(folder/'Replay-TestASDIntegration.py'))['TestMemory']
    with helper['TestArchive'](repo, source) as archive:
        worker = archive.read('Replay-NativeBarOpenSees.py').decode('utf-8-sig').replace('\r\n', '\n')
    needle = '    import openseespy.opensees as ops\n'
    assert worker.count(needle) == 1
    worker = worker.replace(needle, needle+'''    import openseespywin.opensees as native
    from hashlib import sha256
    assert ops.NDTest is native.NDTest
    assert sha256(Path(native.__file__).read_bytes()).hexdigest().upper() == "'''+TestBinary+'"\n')
    command = ['ASDConcrete3D', 30000., .2, '-fc', 34.0277777777778, '-ft', 2.10667357864589, '-tangent']
    count = 3*section.TestPointCount
    batch = min(3, 3000//len(frames))
    assert batch > 0, len(frames)
    result, resources = [[] for _ in frames], []
    with TemporaryDirectory(dir=output.parent) as directory:
        temp = Path(directory)
        (temp/'Worker.py').write_bytes(worker.encode())
        for first in range(0, count, batch):
            resources.append(memory())
            chunk = [frame[first:first+batch] for frame in frames]
            target = temp/'Output.json'
            process = run([str(interpreter), '-B', '-X', 'utf8', str(temp/'Worker.py'), '--worker', str(target)],
                          input=json.dumps([command, chunk], separators=(',', ':')).encode(), stdout=PIPE, stderr=PIPE,
                          timeout=45, check=True, creationflags=0x08000000 if sys.platform == 'win32' else 0)
            assert process.returncode == 0
            for row, values in zip(result, json.loads(target.read_bytes()), strict=True):
                row.extend(values)
            if first % (10*batch) == 0:
                print('OPENSEES RESOLUTION', first, count, 'frames', len(frames), flush=True)
    proof = {'binary_sha256': TestBinary, 'command': command, 'stress': result, 'frames': len(frames),
             'positions': count, 'endpoints': len(endpoints), 'resources': resources,
             'strain_sha256': sha256(json.dumps(frames, separators=(',', ':')).encode()).hexdigest().upper(),
             'worker_sha256': sha256(worker.encode()).hexdigest().upper()}
    output.write_bytes(compress(json.dumps(proof, separators=(',', ':')).encode(), mtime=0))
    print('OPENSEES RESOLUTION CAPTURED', len(frames)*count, flush=True)


def TestVerify(repo, folder, native, continuation, controls, wire, output):
    """Заново собирает шесть усилий, слабые строки, связи и контрольную деформацию по внешним напряжениям."""
    section, frames, expected, endpoints, projection = TestInputs(repo, folder, native, continuation, controls)
    data = json.loads(decompress(wire.read_bytes()))
    assert data['binary_sha256'] == TestBinary and data['endpoints'] == len(endpoints)
    assert data['frames'] == len(frames) and data['positions'] == 3*section.TestPointCount
    assert data['strain_sha256'] == sha256(json.dumps(frames, separators=(',', ':')).encode()).hexdigest().upper()
    observed = np.asarray(data['stress'])
    error = float(np.max(np.abs(observed-expected)))
    assert error < 8e-7, error
    ratio, maximum, margin = 0., 0., float('inf')
    for endpoint in endpoints:
        field, load = np.asarray(endpoint['field']), np.asarray(endpoint['target'])
        stress = observed[endpoint['frame']].reshape(3, section.TestPointCount, 6).copy()
        stress[:, section.TestConcreteCount:] *= -1.
        stress[:, section.TestConcreteCount:] += np.asarray(endpoint['steel'])[..., None]*section.directions
        residual = section.projected(field, stress)-load@section.l
        norm = max(float(np.max(np.abs(residual*section.gauge_scale))),
                   float(np.max(np.abs(section.loads(stress[0])-load)/section.force_scale)))
        if endpoint['control'] is not None:
            norm = max(norm, abs(float(30000.*(projection@field-endpoint['control']))))
        tolerance = endpoint['tolerance_MPa']
        assert norm <= tolerance, (endpoint['label'], norm, tolerance)
        ratio, maximum, margin = max(ratio, norm/tolerance), max(maximum, norm), min(margin, tolerance-norm)
    assert all(r['ramMiB'] >= 6500 and r['freeCommitGiB'] >= 6 for r in data['resources'])
    proof = {'material_updates': len(frames)*3*section.TestPointCount, 'equilibrium_fields': len(endpoints),
             'maximum_stress_error_MPa': error, 'maximum_external_norm_MPa': maximum,
             'maximum_norm_ratio': ratio, 'minimum_tolerance_margin_MPa': margin,
             'physical_capacity_certified': False, 'independent_external_capacity_search': False,
             'binary_sha256': TestBinary}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('RESOLUTION OPENSEES HISTORIES AND ALL SIX RESULTANTS VERIFIED', json.dumps(proof), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--folder', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--continuation', type=Path, required=True)
    parser.add_argument('--controls', type=Path, required=True)
    parser.add_argument('--capture', type=Path)
    parser.add_argument('--python', type=Path)
    parser.add_argument('--wire', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    common = (args.repo.resolve(), args.folder.resolve(), args.native.resolve(), args.continuation.resolve(), args.controls.resolve())
    if args.capture:
        TestCapture(*common, args.python.resolve(), args.capture.resolve())
    else:
        TestVerify(*common, args.wire.resolve(), args.out.resolve())
