"""ДЛЯ ТЕСТОВ: повторяет экспортированные уравнения MVT2 при произвольном числе точек и степеней свободы."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path

import numpy as np


TestTensor = ((0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2))


class TestResolutionSection:
    """Использует фактические операторы VBA и закреплённые одноосные таблицы, сохраняя раздельную историю станций."""

    def __init__(self, folder, reference, closed):
        """Готовит числовую проекцию одного экспорта; алиасы реализуют протокол архивных проверяющих сценариев."""
        self.TestFolder = folder
        rows = [line.split(';') for line in (folder/'Operators.csv').read_text('cp1251').splitlines()]
        points = [line.split(';') for line in (folder/'MVTGaussMixed.csv').read_text('cp1251').splitlines()]
        geometry, = [row for row in points if row[0] == 'MVT_GEOM']
        self.TestConcreteCount, self.TestPointCount, self.TestDof = map(int, geometry[1:4])
        self.TestSteelCount = self.TestPointCount-self.TestConcreteCount
        vector = lambda key: np.asarray([[float(x) for x in row[2:]] for row in rows if row[0] == key])
        block = lambda key: np.asarray([[float(x) for x in row[3:]] for row in rows if row[0] == key])
        size, = [row for row in rows if row[0] == 'SIZE']
        assert int(size[1]) == self.TestDof and int(size[2]) == self.TestPointCount
        dx = float(size[-1])
        operators = block('B').reshape(self.TestPointCount, self.TestDof, 12).transpose(0, 2, 1)
        self.b = np.stack((operators[:, :6], operators[:, :6]+dx*operators[:, 6:], operators[:, :6]-dx*operators[:, 6:]))
        self.g, self.l = vector('G'), vector('L')
        self.s = block('S').reshape(self.TestPointCount, 6, self.TestDof)
        self.r = block('R').reshape(self.TestPointCount, 6, self.TestDof)
        self.double_dx = 2.*dx
        data = np.asarray([[float(x) for x in row[2:]] for row in points if row[0] == 'MVT_POINT'])
        self.xy, self.weight, self.directions = data[:, :2], data[:, 2], data[self.TestConcreteCount:, 3:]
        assert np.array_equal(self.directions[:4], np.tile([0., 0., 1., 0., 0., 0.], (4, 1)))
        assert np.all(self.directions[4:, 2] == 0.) and np.all(self.weight > 0.)
        self.radius = float(geometry[-1])
        self.force_scale = float(geometry[-2])*np.array([1., self.radius, self.radius, self.radius, 1., 1.])
        self.gauge_scale = np.array([1.]*(self.TestDof-4)+[30000.]*4)
        assert self.TestSteelCount >= 4
        self.bounds = np.array([498.]*4+[450.]*(self.TestSteelCount-4))
        self.a = np.einsum('pi,spij->spj', self.directions, self.b[:, self.TestConcreteCount:]).reshape(3*self.TestSteelCount, self.TestDof)
        self.scatter = np.concatenate([np.einsum('pi,pij->jp', self.directions, matrix[self.TestConcreteCount:])
                                       for matrix in (self.s, self.r/self.double_dx, -self.r/self.double_dx)], axis=1)
        self.curves, self.ratio = reference.curves, reference.ratio
        self.calls, self.TestClosureIterations = 0, 0
        self.TestOriginalNominal = self.TestNominal
        self.initial, self.projected, self.loads, self.evaluate = self.TestInitial, self.TestProjected, self.TestLoads, self.TestEvaluate
        self.nominal = self.TestNominal
        if closed:
            close = run_path(str(Path(__file__).with_name('Probe-TestASDClosure.py')))['TestClosure']
            self.nominal = lambda field, history: close(self, field, history)

    def TestInitial(self):
        """Создаёт отдельные нулевые бетонные и стальные буферы трёх станций."""
        return np.zeros((3, self.TestPointCount, 6)), np.zeros((3, self.TestPointCount, 6)), np.zeros((2, 3, self.TestPointCount)), np.zeros((3, self.TestSteelCount))

    def TestNominal(self, field, history):
        """Повторяет одно ASD-обновление по тем же таблицам без изменения принятого буфера."""
        self.calls += 1
        prior_strain, prior_effective, old, prior_steel = history
        strain = self.b@field
        increment = strain-prior_strain
        trial = prior_effective+increment*np.array([25000.]*3+[12500.]*3)
        trial[..., :3] += (25000./3.)*increment[..., :3].sum(axis=-1, keepdims=True)
        tensor = np.empty((*trial.shape[:-1], 3, 3))
        for k, (i, j) in enumerate(TestTensor):
            tensor[..., i, j] = tensor[..., j, i] = trial[..., k]
        values, axes = np.linalg.eigh(tensor)
        nominal_scales, effective_scales, proposed = [], [], []
        alpha, gamma = 4./33., 3.
        beta = (1.-alpha)*self.ratio-(1.+alpha)
        for k, curve in enumerate(self.curves):
            v = values if k == 0 else np.minimum(values, 0.)
            mean = v.mean(axis=-1)
            q = np.sqrt(1.5*((v-mean[..., None])**2).sum(axis=-1))
            high = v[..., -1]
            equiv = (3.*alpha*mean+q+beta*np.maximum(high, 0.)-gamma*np.maximum(-high, 0.))/((1.-alpha)*30000.*(self.ratio if k == 0 else 1.))
            if k == 0:
                equiv = np.where(high < curve.floor, 0., equiv)
            current, nominal, effective = curve.update(old[k], equiv)
            proposed.append(current)
            nominal_scales.append(nominal)
            effective_scales.append(effective)

        def TestSpectral(scales):
            """Собирает знаковые проекторы обратно в исходные физические оси."""
            matrix = np.einsum('...ik,...k,...jk->...ij', axes, values*np.where(values < 0., scales[1][..., None], scales[0][..., None]), axes)
            return np.stack([matrix[..., i, j] for i, j in TestTensor], axis=-1)

        concrete = TestSpectral(nominal_scales)
        concrete[:, self.TestConcreteCount:] *= -1.
        steel_strain = (self.a@field).reshape(3, self.TestSteelCount)
        steel_trial = 200000.*(steel_strain-prior_steel)
        steel = np.clip(steel_trial, -self.bounds, self.bounds)
        return concrete, steel, steel_trial, (strain, TestSpectral(effective_scales), np.asarray(proposed), steel_strain-steel/200000.)

    def TestProjected(self, field, stress):
        """Собирает все слабые уравнения и четыре связи с исходной центральной производной."""
        return self.g@field+np.einsum('pij,pi->j', self.s, stress[0])+np.einsum('pij,pi->j', self.r, (stress[1]-stress[2])/self.double_dx)

    def TestLoads(self, stress):
        """Интегрирует все шесть знаковых усилий по центральной станции."""
        x, y = self.xy.T
        zz, xz, yz = stress[:, 2], stress[:, 4], stress[:, 5]
        return np.asarray([self.weight@v for v in (zz, y*zz, x*zz, x*yz-y*xz, xz, yz)])

    def TestEvaluate(self, field, history, target):
        """Проверяет равновесие до фиксации пробного состояния; NumFail не превращается в разрушение."""
        concrete, steel, trial, proposed = self.nominal(field, history)
        stress = concrete.copy()
        stress[:, self.TestConcreteCount:] += steel[..., None]*self.directions
        residual = self.TestProjected(field, stress)-target@self.l
        loads = self.TestLoads(stress[0])
        norm = max(np.max(np.abs(residual*self.gauge_scale)), np.max(np.abs(loads-target)/self.force_scale))
        return residual, norm, loads, stress, proposed, steel, trial


def TestReplay(repo, native, output, closed=True, prefix_native=None):
    """Повторяет нативные поля и квадратурные моменты без подстановки результатов внешнего решателя."""
    here = Path(__file__).resolve().parent
    reference = run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    section = TestResolutionSection(native, reference, closed)
    if prefix_native is not None:
        prior = TestResolutionSection(prefix_native, reference, closed)
        for name in ('b', 's', 'r', 'g', 'l', 'xy', 'weight', 'directions'):
            assert np.array_equal(getattr(section, name), getattr(prior, name)), name
    loads = {}
    center, net = {}, {}
    fields = []
    controls = {}
    log = native/'MVTGaussMixed.txt'
    if log.exists():
        for line in log.read_text('utf-8-sig').splitlines():
            row = line.split(';')
            if row[0] == 'TRANSFER_CONTROL_ACCEPTED':
                controls[row[1]] = (float(row[2]), float(row[3]))
    sources = ([prefix_native] if prefix_native is not None else [])+[native]
    for source in sources:
        for line in (source/'MVTGaussMixed.Tensor.csv').read_text('cp1251').splitlines():
            row = line.split(';')
            if row[0] == 'FRAME':
                assert row[1] not in loads
                torque, q = float(row[2]), float(row[3])
                loads[row[1]] = np.array([0., -396.*q, 0., torque, 0., q])
                center[row[1]] = np.empty((section.TestPointCount, 6))
                phase = row[1]
            elif row[0] == 'POINT':
                center[phase][int(row[1])-1] = np.asarray(row[8:], dtype=float)
        for line in (source/'Operators.csv').read_text('cp1251').splitlines():
            row = line.split(';')
            if row[0] == 'F':
                fields.append((row[1], np.asarray(row[2:], dtype=float)))
            elif row[0] == 'H':
                net.setdefault(row[1], np.empty((3, section.TestPointCount, 6)))[(0, 1, -1).index(int(row[2])), int(row[3])-1] = np.asarray(row[4:], dtype=float)
    history, records, maximum = section.TestInitial(), [], 0.
    for label, field in fields:
        target = loads[label]
        result = section.TestEvaluate(field, history, target)
        tolerance = float(5e-7+5e-7*np.max(np.abs((target@section.l)[:section.TestDof-4])))
        norm = float(result[1])
        if label in controls:
            control, q = controls[label]
            assert abs(q-target[5]) < 1e-5
            norm = max(norm, abs(float(30000.*(section.a[0]@field-control))))
        assert norm <= tolerance, (label, norm, tolerance)
        concrete = result[3][0].copy()
        concrete[section.TestConcreteCount:] = result[5][0, :, None]*section.directions-concrete[section.TestConcreteCount:]
        if label in net:
            maximum = max(maximum, float(np.max(np.abs(result[3]-net[label]))))
        maximum = max(maximum, float(np.max(np.abs(concrete-center[label]))))
        assert maximum < 8e-7, (label, maximum)
        records.append({'label': label, 'target_N_Nmm': target.tolist(), 'norm_MPa': norm,
                        'tolerance_MPa': tolerance, 'twist_rad_per_m': float(1000.*field[3]/section.radius)})
        history = result[4]
    xy, weights = section.xy[:section.TestConcreteCount]/120., section.weight[:section.TestConcreteCount]/57600.
    moments = []
    for degree in range(10):
        exact = 0. if degree % 2 else 1./(degree+1.)
        for axis in range(2):
            moments.append(abs(float(weights@(xy[:, axis]**degree))-exact))
    assert max(moments) < 3e-12
    proof = {'degrees': section.TestDof, 'concrete_points': section.TestConcreteCount, 'steel_points': section.TestSteelCount,
             'closed_integration': closed, 'states': records, 'native_stress_error_MPa': maximum,
             'maximum_quadrature_moment_error': max(moments), 'physical_capacity_certified': False}
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('RESOLUTION STATES REPLAYED', len(records), section.TestConcreteCount, section.TestDof, maximum, flush=True)
    return section, history, fields


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--prefix-native', type=Path)
    args = parser.parse_args()
    TestReplay(args.repo.resolve(), args.native.resolve(), args.out.resolve(),
               prefix_native=args.prefix_native.resolve() if args.prefix_native is not None else None)
