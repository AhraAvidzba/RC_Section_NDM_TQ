"""ДЛЯ ТЕСТОВ: восстанавливает чистую нативную копию только из закреплённых входов архива."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestRestore(root, case, destination, repo=None):
    """Создаёт новый каталог без протоколов предыдущих запусков и без изменения существующих книг."""
    assert case in json.loads((root/'Cases.json').read_bytes())
    if not (root/'SourceBooks').exists():
        assert repo is not None, 'Укажите --repo для получения закреплённых двоичных частей комплекта.'
        run_path(str(root/'Ensure-TestResolutionPayloads.py'))['TestEnsure'](root, repo)
    source = root/case
    prep = json.loads((source/'Preparation.json').read_bytes())
    assert not destination.exists()
    destination.mkdir(parents=True)
    for name, expected in prep['inputs'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        original = root/'SourceBooks'/(expected+'.xlsm') if relative.suffix == '.xlsm' else source/relative
        raw = original.read_bytes()
        assert sha256(raw).hexdigest().upper() == expected
        target = destination/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    (destination/'Preparation.json').write_bytes((source/'Preparation.json').read_bytes())
    (destination/'docs/regression').mkdir(parents=True, exist_ok=True)
    (destination/'docs/regression/Diagnostic.xlsm').write_bytes((destination/'workbook/output/RC_Section_NDM.xlsm').read_bytes())
    (destination/'Temp').mkdir()
    assert not (destination/'Compile.log').exists() and not (destination/'Native/MVTGaussMixed.txt').exists()
    print('CLEAN NATIVE RESOLUTION INPUTS RESTORED', case, destination)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--case', required=True)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--repo', type=Path)
    args = parser.parse_args()
    TestRestore(args.root.resolve(), args.case, args.destination.resolve(), args.repo.resolve() if args.repo is not None else None)
