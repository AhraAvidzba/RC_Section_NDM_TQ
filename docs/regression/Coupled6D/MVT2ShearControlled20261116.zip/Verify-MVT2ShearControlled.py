"""Independently reconstruct B resultants and verify exact directed controls and ownership."""
from collections import defaultdict
from hashlib import sha256
import json
import math
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
NATIVE=HERE/"Native"
MODULUS=30000.
BASE_FORCE_ARCHIVED=(-.0000439129602785443,11134865.9994933,-.00127382198084014,10509999.9997492,.0000042615867257784,18558.1099948724)

def reading(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()

def near(a,b,tol):
    assert abs(a-b)<=tol,(a,b,tol)

def maxdiff(x,y):
    return max(abs(a-b) for a,b in zip(x,y,strict=True))

def demand(q):
    return (0.,600000*q,0.,10510000.,0.,1000*q)

def reconstruct(stations):
    assert len(stations)==45
    parts=[]
    for n,x,y,area,*stuff in stations:
        assert int(n)==len(parts)+1 and len(stuff)==12 and all(map(math.isfinite,stuff))
        z,xz,yz=stuff[8],stuff[10],stuff[11]
        parts.append((area*z,area*z*y,area*z*x,area*(x*yz-y*xz),area*xz,area*yz))
    return tuple(map(math.fsum,zip(*parts,strict=True)))

def main():
    offline="--offline" in sys.argv
    prep=reading(HERE/"Preparation.json")
    build=reading(HERE/"docs/regression/CodeUpdate.json")
    compile_close=reading(HERE/"CompileClosure.json")
    receipt=reading(NATIVE/"RunReceipt.json")
    close=reading(NATIVE/"MVT2.txt.ProcessClosure.json")
    owner=reading(NATIVE/"MVT2.txt.Ownership.json")
    logs=(NATIVE/"MVT2.txt").read_text(encoding="utf-8-sig")
    assert build["Compiled"] and not build["ProductionChanged"] and build["Modules"]==["modTestCoupledExperiment"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and compile_close["State"]=="Absent"
    if not offline:
        assert digest(HERE/"docs/regression/Diagnostic.xlsm")==build["WorkbookSHA256"]
    assert digest(HERE/"Replay.csv")==prep["replay_sha256"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    final=close["Closure"]["FinalState"]
    assert close["Passed"] and close["ChildHasExited"] and close["RunnerCleanupValid"] and close["ChildExitCode"]==receipt["native_exit"]==0
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in logs and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in logs
    source=(NATIVE/"MVT2.csv").read_text(encoding="cp1251")
    tags=defaultdict(list)
    for line in source.splitlines():
        kind,*row=line.split(";")
        tags[kind].append(row)
    field={label:tuple(map(float,row)) for label,*row in tags["MVT2_CONTROL_FIELD"]}
    assert len(field)==len(tags["MVT2_CONTROL_FIELD"]) and all(len(values)==60 for values in field.values())
    archive=[tuple(map(float,line.split(";"))) for line in (HERE/"Replay.csv").read_text(encoding="ascii").splitlines()[1:]]
    assert len(archive)==24
    for i,(index,offset,factor,*load_field) in enumerate(archive,1):
        demand_row=list(demand(factor))
        demand_row[3]*=offset
        assert index==i and len(load_field)==66 and maxdiff(load_field[:6],demand_row)<1e-6
        assert maxdiff(field[f"Replay{i}"],load_field[6:])<1e-15
    stations=defaultdict(list)
    for label,*values in tags["B_CONTROL_STATION"]:
        stations[label].append(tuple(map(float,values)))
    assert len(tags["B_CONTROL_SETUP"])==1
    n,area,length=map(float,tags["B_CONTROL_SETUP"][0])
    assert n==24
    near(area,240.**2,1e-6);near(length,155.56349186104046,1e-7)
    scale=(area,area*length,area*length,area*length,area,area)
    def tolerance(factor):
        return 5e-7*(1+max(abs(force/s) for force,s in zip(demand(factor),scale,strict=True)))
    def normalized(a,b):
        return max(abs(x-y)/den for x,y,den in zip(a,b,scale,strict=True))
    equilibria={}
    for label,*values in tags["B_CONTROL_EQUILIBRIUM"]:
        axis,target,q,tol,weak,gauge,integral,control,*forces=map(float,values)
        assert label not in equilibria and len(forces)==6
        direct=reconstruct(stations[label])
        assert normalized(direct,forces)<=2e-12
        near(tol,tolerance(q),5e-15)
        near(integral,normalized(direct,demand(q)),2e-12)
        near(control,MODULUS*abs(field[label][int(axis)-1]-target),2e-12)
        assert max(weak,gauge,integral,control)<=tol+2e-12
        equilibria[label]={"q_kN":q,"coordinate":target,"resultants_N_Nmm":direct,"norms_MPa":[weak,gauge,integral,control],"tolerance_MPa":tol}
    assert field["Base"]==field["Replay24"] and set(stations)==set(equilibria)
    assert normalized(equilibria["Base"]["resultants_N_Nmm"],BASE_FORCE_ARCHIVED)<2e-8
    assert set(equilibria).issuperset({f"{name}/Rollback" for name in ("TwistNative","TwistConsistent","CurvatureConsistent")})
    for label in equilibria:
        if label.endswith("/Rollback"):
            assert field[label]==field["Base"] and stations[label]==stations["Base"]
            assert equilibria[label]["norms_MPa"][:3]==equilibria["Base"]["norms_MPa"][:3]
    trial_rows={label:tuple(map(float,values)) for label,*values in tags["B_CONTROL_TRIAL"]}
    mode_spec={"TwistNative":(4,0),"TwistConsistent":(4,1),"CurvatureConsistent":(2,1)}
    outputs={}
    for label,axis,consistent,target,initial,ratio,qold,qprev,q,status,code,*diag in tags["B_CONTROL_PROBE"]:
        axis,consistent,code=int(axis),int(consistent),int(code)
        target,initial,ratio,qold,qprev,q=map(float,(target,initial,ratio,qold,qprev,q))
        if label in mode_spec:
            assert (axis,consistent)==mode_spec[label]
            near(ratio,1./64,1e-16)
            near(qold,archive[23][2],3e-14);near(qprev,archive[22][2],3e-14)
            left,right=field["Replay23"],field["Replay24"]
        else:
            assert label.startswith("Extend") and "extension_prior" in locals()
            left,right=extension_prior,extension_current
        near(target,right[axis-1]+ratio*(right[axis-1]-left[axis-1]),3e-16)
        near(initial,qold+ratio*(qold-qprev),2e-13)
        item={"axis":axis,"consistent":bool(consistent),"target":target,"starting_q_kN":initial,
              "trial_q_kN":q,"status":status,"code":code,"diagnostics":";".join(diag)}
        outputs[label]=item
        if status=="Accepted":
            tol,weak,gauge,integral,control,steel,adjoint,*forces=trial_rows[label]
            near(tol,tolerance(initial),5e-15)
            near(integral,normalized(forces,demand(q)),2e-12)
            trial=field[label+"/Trial"]
            near(control,MODULUS*abs(trial[axis-1]-target),2e-12)
            assert max(weak,gauge,integral,control)<=tol+2e-12 and .0<=steel<=1. and adjoint>0.
            delta=[b-a for a,b in zip(left[:56],right[:56],strict=True)]
            move=[b-a for a,b in zip(right[:56],trial[:56],strict=True)]
            assert math.fsum(a*b for a,b in zip(delta,move,strict=True))>0.
            assert math.hypot(*move)<=3*ratio*math.hypot(*delta)*(1+1e-8)
            assert abs(q-qold)<=3*ratio*max(abs(qold-qprev),.01)*(1+1e-8)
            assert field[label+"/Commit"]==trial and normalized(equilibria[label+"/Commit"]["resultants_N_Nmm"],forces)<2e-9
            item.update({"uncertainty_kN":adjoint,"steel_utilization":steel,"commit":equilibria[label+"/Commit"]})
            if label.startswith("Extend"):
                extension_prior,extension_current=right,trial
        else:
            assert label not in trial_rows and label+"/Commit" not in equilibria
        if label=="CurvatureConsistent" and tags["B_CONTROL_BRANCH"]:
            [[strategy]]=tags["B_CONTROL_BRANCH"]
            assert outputs[strategy]["status"]=="Accepted"
            extension_prior,extension_current=field["Replay24"],field[strategy+"/Trial"]
    assert list(outputs)[:3]==list(mode_spec)
    [[outcome,added,terminal]]=tags["B_CONTROL_END"]
    accepted_extensions=[item for key,item in outputs.items() if key.startswith("Extend") and item["status"]=="Accepted"]
    assert len(accepted_extensions)==int(added)<=3
    if not tags["B_CONTROL_BRANCH"]:
        assert outcome=="PairedInconclusive" and all(outputs[name]["status"]!="Accepted" for name in mode_spec)
        near(float(terminal),archive[-1][2],2e-13)
    else:
        [[strategy]]=tags["B_CONTROL_BRANCH"]
        last=accepted_extensions[-1] if accepted_extensions else outputs[strategy]
        near(float(terminal),last["trial_q_kN"],2e-13)
    record={"source_workbook_sha256":prep["book_sha256"],"replay_sha256":prep["replay_sha256"],"native_trace_sha256":digest(NATIVE/"MVT2.csv"),
            "native_wall_s":receipt["wall_seconds"],"owner_pid":owner["PID"],"owner_ticks":str(owner["StartTicksUTC"]),
            "regular_closure":final["State"],"prefix_fields":len(archive),"exact_base_rollbacks":3,
            "base":equilibria["Base"],"probes":outputs,"new_branch":tags["B_CONTROL_BRANCH"],"additional_fields":int(added),
            "outcome":outcome,"last_q_kN":float(terminal),"physical_limit_confirmed":False}
    result=HERE/"Verification.json"
    result.write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(result,digest(result))

if __name__=="__main__":
    main()