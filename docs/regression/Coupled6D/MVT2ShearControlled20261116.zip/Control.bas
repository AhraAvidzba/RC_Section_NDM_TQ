' -------------------- ДЛЯ ТЕСТОВ --------------------
' Продолжает архивную историю B при неизменном кручении и пропорциональных Qy и Mx.
Public Function RunTestWangShearControlled(ByVal replayPath As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    InitializeExperimentSolverTest solver, operators, concrete, response, steel, 30000#, 0.2, _
        fc, 2.10667357864589, 0.0022, gt, gc, True
    Dim path As New CLoadPathVector, offset() As Double, direction() As Double
    path.Initialize 0#, 0#, 0#, 600000#, 0#, 0#, 10510000#, 0#, 0#, 0#, 0#, 1000#
    path.Components offset, direction
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim previous() As Double, current() As Double, baseline() As Double, trial() As Double, actual() As Double
    Dim bestField() As Double, bestFactor As Double, bestMode As String, bestAxis As Long, bestConsistent As Boolean
    Dim span As Double, target As Double, trialFactor As Double, startingFactor As Double, mode As Variant, axis As Long
    Dim ratio As Double, accepted As Boolean, consistent As Boolean, currentFactor As Double, previousFactor As Double
    Dim targetIncrement As Double, attempts As Long, stage As String, acceptedCount As Long
    previous = history(history.Count - 1): baseline = history(history.Count)
    previousFactor = factors(history.Count - 1): currentFactor = factors(history.Count)
    span = currentFactor - previousFactor: ratio = 1# / 64#
    startingFactor = currentFactor + ratio * span
    RestoreWangShearBaselineTest solver, history, baseline
    RecordWangShearEquilibriumTest operators, solver, response, path, baseline, currentFactor, 4, baseline(4), _
        "Base", report, tracePath
    For Each mode In Array("TwistNative", "TwistConsistent", "CurvatureConsistent")
        RestoreWangShearBaselineTest solver, history, baseline
        axis = 4: If mode = "CurvatureConsistent" Then axis = 2
        consistent = (mode <> "TwistNative")
        target = baseline(axis) + ratio * (baseline(axis) - previous(axis))
        accepted = TryWangShearControlProbeTest(CStr(mode), axis, consistent, solver, operators, response, path, _
            offset, direction, previous, baseline, currentFactor, previousFactor, target, startingFactor, ratio, _
            trial, trialFactor, report, tracePath)
        If accepted Then
            solver.AcceptStep
            RecordWangShearEquilibriumTest operators, solver, response, path, trial, trialFactor, axis, target, _
                CStr(mode) & "/Commit", report, tracePath
            If Len(bestMode) = 0 Or mode = "TwistConsistent" Then
                bestMode = CStr(mode): bestAxis = axis: bestConsistent = consistent
                bestField = trial: bestFactor = trialFactor
            End If
        Else
            solver.DiscardStep
        End If
        RestoreWangShearBaselineTest solver, history, baseline
        RecordWangShearEquilibriumTest operators, solver, response, path, baseline, currentFactor, axis, baseline(axis), _
            CStr(mode) & "/Rollback", report, tracePath
    Next mode
    If Len(bestMode) > 0 Then
        stage = "Budget"
        AddExperimentTraceTest report, tracePath, "B_CONTROL_BRANCH;" & bestMode
        previous = baseline: current = bestField: previousFactor = currentFactor: currentFactor = bestFactor
        history.Add current
        RestoreWangShearBaselineTest solver, history, current
        targetIncrement = 1.25 * (current(bestAxis) - previous(bestAxis))
        For attempts = 1 To 6
            ratio = targetIncrement / (current(bestAxis) - previous(bestAxis))
            If targetIncrement < Abs(baseline(bestAxis) - CDblWangPriorAxisTest(history, bestAxis)) / 512# Then
                stage = "Minimum": Exit For
            End If
            target = current(bestAxis) + targetIncrement
            startingFactor = currentFactor + ratio * (currentFactor - previousFactor)
            accepted = TryWangShearControlProbeTest("Extend" & CStr(attempts), bestAxis, bestConsistent, solver, _
                operators, response, path, offset, direction, previous, current, currentFactor, previousFactor, target, _
                startingFactor, ratio, trial, trialFactor, report, tracePath)
            If accepted Then
                solver.AcceptStep
                RecordWangShearEquilibriumTest operators, solver, response, path, trial, trialFactor, bestAxis, target, _
                    "Extend" & CStr(attempts) & "/Commit", report, tracePath
                history.Add trial
                previous = current: current = trial
                previousFactor = currentFactor: currentFactor = trialFactor
                targetIncrement = targetIncrement * 1.25
                acceptedCount = acceptedCount + 1
                If acceptedCount = 3 Then stage = "ThreeStates": Exit For
            Else
                solver.DiscardStep
                targetIncrement = targetIncrement / 2#
            End If
        Next attempts
    Else
        stage = "PairedInconclusive"
    End If
    AddExperimentTraceTest report, tracePath, "B_CONTROL_END;" & stage & ";" & CStr(acceptedCount) & ";" & ExperimentNumberTest(currentFactor)
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Исходная физическая координата предпоследнего поля силовой части.
Private Function CDblWangPriorAxisTest(ByVal history As Collection, ByVal axis As Long) As Double
    Dim prior() As Double: prior = history(23)
    CDblWangPriorAxisTest = prior(axis)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает одну точную пробу, проверяет продолжение физического направления, сталь и сопряжённую оценку.
Private Function TryWangShearControlProbeTest(ByVal label As String, ByVal axis As Long, ByVal consistent As Boolean, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, ByVal response As CCoupledReinforcedResponse, _
        ByVal path As CLoadPathVector, ByRef offset() As Double, ByRef direction() As Double, ByRef previous() As Double, _
        ByRef current() As Double, ByVal currentFactor As Double, ByVal previousFactor As Double, ByVal target As Double, _
        ByVal initialFactor As Double, ByVal ratio As Double, ByRef trial() As Double, ByRef trialFactor As Double, _
        ByRef report As String, ByVal tracePath As String) As Boolean
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005
    Dim projection(1 To 60) As Double, expected() As Double, actual() As Double
    Dim weak As Double, gauge As Double, integral As Double, control As Double, tolerance As Double
    Dim status As String, details As String, steel As Double, adjoint As Double, code As Long, k As Long
    projection(axis) = 1#
    trialFactor = currentFactor
    status = "SolverRejected"
    If solver.TryDeformationStep(offset, direction, projection, target, initialFactor, trialFactor, _
            ABS_TOL, REL_TOL, 26, consistentControl:=consistent) Then
        solver.CopyTrial trial, actual
        steel = response.TrialSteelUtilization
        status = "ForwardRejected"
        If trialFactor > 0# And steel <= 1# And ForwardWangFieldTest(previous, current, trial, ratio) And _
            Abs(trialFactor - currentFactor) <= 3# * ratio * GeomMax(Abs(currentFactor - previousFactor), 0.01) Then
            path.TargetSix trialFactor, expected
            WangControlledNormTest operators, solver, trial, actual, expected, projection, target, 30000#, weak, gauge, integral, control
            tolerance = WangTurnToleranceTest(operators, path, initialFactor, ABS_TOL, REL_TOL)
            status = "BalanceRejected"
            If GeomMax(GeomMax(weak, gauge), GeomMax(integral, control)) <= tolerance Then
                status = "AdjointUnavailable"
                If solver.TrialLambdaUncertainty(ABS_TOL, REL_TOL, adjoint) Then status = "Accepted"
            End If
        End If
    End If
    code = solver.ResultMeta.ResultCode: details = solver.ResultMeta.DiagnosticDetails
    RequireWangAcceptedFieldTest solver, current
    AddExperimentTraceTest report, tracePath, "B_CONTROL_PROBE;" & label & ";" & CStr(axis) & ";" & _
        CStr(Abs(CLng(consistent))) & ";" & ExperimentNumberTest(target) & ";" & ExperimentNumberTest(initialFactor) & ";" & _
        ExperimentNumberTest(ratio) & ";" & ExperimentNumberTest(currentFactor) & ";" & ExperimentNumberTest(previousFactor) & ";" & _
        ExperimentNumberTest(trialFactor) & ";" & status & ";" & CStr(code) & ";" & Replace(details, vbCrLf, " ")
    If status <> "Accepted" Then Exit Function
    Dim row As String
    row = "B_CONTROL_TRIAL;" & label & ";" & ExperimentNumberTest(tolerance) & ";" & ExperimentNumberTest(weak) & ";" & _
        ExperimentNumberTest(gauge) & ";" & ExperimentNumberTest(integral) & ";" & ExperimentNumberTest(control) & ";" & _
        ExperimentNumberTest(steel) & ";" & ExperimentNumberTest(adjoint)
    For k = 1 To 6: row = row & ";" & ExperimentNumberTest(actual(k)): Next k
    AddExperimentTraceTest report, tracePath, row
    AppendWangFieldTest report, tracePath, label & "/Trial", trial
    TryWangShearControlProbeTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает фактический центральный отклик, отдельно собирает шесть усилий и проверяет слабые строки.
Private Sub RecordWangShearEquilibriumTest(ByVal operators As CCoupledElasticState, ByVal solver As CCoupledNewtonSolver, _
        ByVal response As CCoupledReinforcedResponse, ByVal path As CLoadPathVector, ByRef field() As Double, _
        ByVal factor As Double, ByVal axis As Long, ByVal target As Double, ByVal label As String, _
        ByRef report As String, ByVal tracePath As String)
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005
    RequireWangAcceptedFieldTest solver, field
    Dim material As ICoupledPointResponse: Set material = response
    Dim strain(1 To 6) As Double, stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim actual(1 To 6) As Double, expected() As Double, projection(1 To 60) As Double, residual() As Double
    Dim i As Long, k As Long, x As Double, y As Double, area As Double, row As String
    Dim weak As Double, gauge As Double, integral As Double, control As Double, tolerance As Double
    For i = 1 To operators.PointCount
        operators.Point i, x, y, area
        operators.PointStrain i, field, strain
        If material.EvaluatePoint(i, strain, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
            Err.Raise 5, , "Невозможно пересчитать станционный отклик B."
        row = "B_CONTROL_STATION;" & label & ";" & CStr(i) & ";" & ExperimentNumberTest(x) & ";" & _
            ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area)
        For k = 1 To 6: row = row & ";" & ExperimentNumberTest(strain(k)): Next k
        For k = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(k)): Next k
        AddExperimentTraceTest report, tracePath, row
        actual(1) = actual(1) + area * stress(3)
        actual(2) = actual(2) + area * stress(3) * y
        actual(3) = actual(3) + area * stress(3) * x
        actual(4) = actual(4) + area * (x * stress(6) - y * stress(5))
        actual(5) = actual(5) + area * stress(5)
        actual(6) = actual(6) + area * stress(6)
    Next i
    projection(axis) = 1#
    path.TargetSix factor, expected
    WangControlledNormTest operators, solver, field, actual, expected, projection, target, 30000#, weak, gauge, integral, control
    tolerance = WangTurnToleranceTest(operators, path, factor, ABS_TOL, REL_TOL)
    If GeomMax(GeomMax(weak, gauge), GeomMax(integral, control)) > tolerance Then _
        Err.Raise 5, , "Подтверждённая история B не воспроизвела исходный допуск равновесия. " & label & " " & _
            ExperimentNumberTest(weak) & " " & ExperimentNumberTest(gauge) & " " & ExperimentNumberTest(integral)
    row = "B_CONTROL_EQUILIBRIUM;" & label & ";" & CStr(axis) & ";" & ExperimentNumberTest(target) & ";" & _
        ExperimentNumberTest(factor) & ";" & ExperimentNumberTest(tolerance) & ";" & ExperimentNumberTest(weak) & ";" & _
        ExperimentNumberTest(gauge) & ";" & ExperimentNumberTest(integral) & ";" & ExperimentNumberTest(control)
    For k = 1 To 6: row = row & ";" & ExperimentNumberTest(actual(k)): Next k
    AddExperimentTraceTest report, tracePath, row
    AppendWangFieldTest report, tracePath, label, field
End Sub