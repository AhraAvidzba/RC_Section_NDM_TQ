"""Independently reconstruct 56 weak equations, four constraints and six signed efforts."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import csv
import json
import math
import sys

HERE = Path(__file__).resolve().parent
NATIVE = HERE / "Native"
DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result


def verify():
    prep = read(HERE/"Preparation.json")
    build = read(HERE/"docs/regression/CodeUpdate.json")
    closure = read(HERE/"CompileClosure.json")
    owner = read(NATIVE/"MVT2.txt.Ownership.json")
    watcher = read(NATIVE/"MVT2.txt.ProcessClosure.json")
    receipt = read(NATIVE/"RunReceipt.json")
    final = watcher["Closure"]["FinalState"]
    assert build["Compiled"] and not build["ProductionChanged"]
    assert sorted(build["Modules"])==prep["only_updated_modules"]==["CCoupledNewtonSolver","modTestCoupledExperiment"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and closure["State"]=="Absent"
    assert digest(HERE/"src/CCoupledNewtonSolver.cls")==prep["solver_module_sha256"]
    assert digest(HERE/"tests/modTestCoupledExperiment.bas")==prep["module_sha256"]
    if "--offline" not in sys.argv:
        assert digest(HERE/"docs/regression/Diagnostic.xlsm")==build["WorkbookSHA256"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert watcher["Passed"] and watcher["ChildExitCode"]==receipt["native_exit"]==0
    assert final["State"]=="Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (NATIVE/"MVT2.txt").read_text(encoding="utf-8-sig")
    assert digest(HERE/"Replay.csv")==prep["replay_sha256"]
    archived = list(csv.reader((HERE/"Replay.csv").read_text(encoding="ascii").splitlines(),delimiter=";"))[1:]
    assert len(archived)==24
    tags=defaultdict(list)
    trace = NATIVE/"MVT2.csv"
    for tag,*row in csv.reader(trace.read_text(encoding="cp1251").splitlines(),delimiter=";"):
        tags[tag].append(row)
    fields = vec(tags,"MVT2_CONTROL_FIELD")
    assert len(fields)==len(archived)
    for i,row in enumerate(archived,1):
        expected = [float(x) for x in row[9:]]
        assert int(row[0])==i and peak(diff(expected,fields[f"Replay{i}"]))<1e-15
    [[fb,ft]]=tags["B_TANGENT_LOAD"]
    base_factor, target_factor = float(fb),float(ft)
    near(base_factor,float(archived[-1][2]),1e-13)
    near(target_factor,base_factor+(base_factor-float(archived[-2][2]))/64.,1e-13)
    [[last,factor]]=tags["B_TANGENT_END"]
    assert int(last)==24 and float(factor)==base_factor
    directions=vec(tags,"B_TANGENT_DIRECTION")
    assert set(directions)=={"Secant","Newton"}
    state_fields, flags = {}, {}
    for label,h,f,*values in tags["B_TANGENT_FIELD"]:
        assert label not in state_fields and len(values)==DIM
        state_fields[label]=tuple(map(float,values))
        flags[label]=(int(h),float(f))
    residuals=vec(tags,"B_TANGENT_RESIDUAL")
    stations=defaultdict(dict)
    for label,point,side,*values in tags["B_TANGENT_STATION"]:
        identity=(int(point),int(side))
        assert label in residuals and identity not in stations[label] and len(values)==19
        stations[label][identity]=tuple(map(float,values))
    unavailable=defaultdict(list)
    for label,reason,*info in tags["B_TANGENT_UNAVAILABLE"]:
        unavailable[label].append((reason,*info))
    for name in state_fields.keys()-residuals.keys():
        assert name in unavailable and unavailable[name]==[("Residual",)]
    assert all(name in stations and name in state_fields for name in residuals)
    for label in ("Base24","Unpublished24","Restored24"):
        assert state_fields[label]==fields["Replay24"] and stations[label]==stations["Base24"]
        assert flags[label]==(24,base_factor) and residuals[label]==residuals["Base24"]
    assert state_fields["Base23"]==fields["Replay24"] and flags["Base23"]==(23,base_factor)
    assert all(row[3]==row[5]==0 for (point,_),row in stations["Base24"].items() if point<=25)
    assert max(abs(row[5]) for (point,_),row in stations["Base23"].items() if point<=25)>=1.
    geometric_scale=(AREA,AREA*LENGTH,AREA*LENGTH,AREA*LENGTH,AREA,AREA)
    responses, diagnostics = {}, {}
    for name in residuals:
        h,f = flags[name]
        assert set(stations[name])=={(point,side) for point in range(1,46) for side in (-1,0,1)}
        computed, actual, error = reconstruct(state_fields[name],f,stations[name])
        discrepancy=peak(diff(computed,residuals[name]))
        assert error<4e-15 and discrepancy<3e-10,(name,error,discrepancy)
        integral=peak(delta/s for delta,s in zip(diff(actual,force(f)),geometric_scale,strict=True))
        weak=peak(computed[:56]); gauge=MODULUS*peak(computed[56:]); tol=5e-7*(1.+peak(loading(f)))
        diagnostics[name]={"history":h,"Qy_kN":f,"max_weak_MPa":weak,"gauge_MPa":gauge,"force_MPa":integral,
            "max_full_MPa":max(weak,gauge,integral),"worst_weak_row":max(range(56),key=lambda idx:abs(computed[idx]))+1,
            "equilibrium_tolerance_MPa":tol,"six_N_Nmm":actual,
            "independent_weak_difference_MPa":discrepancy,"station_strain_discrepancy":error}
        responses[name]=computed
    matrix_family={name:(int(m),int(h)) for name,m,h in tags["B_TANGENT_MATRIX_FAMILY"]}
    matrices=defaultdict(dict)
    for label,row,*values in tags["B_TANGENT_MATRIX"]:
        idx=int(row)
        assert idx not in matrices[label] and len(values)==DIM
        matrices[label][idx]=tuple(map(float,values))
    assert set(matrix_family)==set(matrices)
    original_rhs=tuple(-x for x in responses["Base24"])
    original_rhs=tuple(a+b for a,b in zip(original_rhs,diff(loading(target_factor),loading(base_factor)),strict=True))
    anchors=vec(tags,"B_TANGENT_ANCHOR")
    corrections=vec(tags,"B_TANGENT_CORRECTION")
    base=state_fields["Base24"]
    assert set(anchors)==set(matrices) and set(corrections).issubset(matrices)
    assert "Stock24" in corrections
    first_updates={}
    for label,rows in matrices.items():
        assert set(rows)==set(range(1,61))
        mode,count=matrix_family[label]
        assert (mode,count)==((1,24) if label=="Stock24" else (2,23) if label=="Consistent23" else (2,24))
        if label.startswith("Biased24/"):
            amplitude=float(label.partition("/")[2])
            assert abs(amplitude)==1e-8
            predicted=tuple(a+amplitude*b for a,b in zip(base,directions["Secant"],strict=True))
            assert peak(diff(predicted,anchors[label]))<2e-15
        else:
            assert anchors[label]==base
        if label not in corrections:
            assert label in unavailable
            continue
        vector=corrections[label]
        applied=tuple(dot(rows[i],vector) for i in range(1,61))
        linear_error=peak(diff(applied,original_rhs))
        assert linear_error<5e-10,(label,linear_error)
        first_updates[label]={"linear_error_MPa":linear_error,"max_station_strain":strain_extent(vector,stations["Base24"]),"damped":{}}
    for label,matrix,fraction in tags["B_TANGENT_DAMP"]:
        weight=float(fraction)
        assert weight in (1.,.25,.0625) and flags[label]==(24,target_factor)
        expected=tuple(a+weight*b for a,b in zip(base,corrections[matrix],strict=True))
        assert peak(diff(expected,state_fields[label]))<2e-15
        first_updates[matrix]["damped"][str(weight)]=diagnostics.get(label)
    assert all(len(row["damped"])==3 for row in first_updates.values())
    for label,vector in directions.items():
        source=diff(fields["Replay24"],fields["Replay23"]) if label=="Secant" else corrections["Stock24"]
        near(strain_extent(vector,stations["Base24"]),1.,2e-13)
        expected=tuple(v/strain_extent(source,stations["Base24"]) for v in source)
        assert peak(diff(vector,expected)) < 1e-8
    signed={}
    for family,vector in directions.items():
        projected={mode:tuple(dot(rows[i],vector) for i in range(1,61)) for mode,rows in matrices.items()}
        pairs={}
        for amplitude in (1e-10,1e-9,1e-8):
            selected={}
            for name,field in state_fields.items():
                if not name.startswith(family+"/") or abs(float(name.split("/")[1]))!=amplitude:
                    continue
                value=float(name.split("/")[1]); selected[math.copysign(1.,value)]=name
                predicted=tuple(a+value*b for a,b in zip(base,vector,strict=True))
                assert peak(diff(predicted,field))<2e-15 and flags[name]==(24,base_factor)
            assert set(selected)=={-1.,1.}
            plus,minus=selected[1.],selected[-1.]
            pair={"positive":plus,"negative":minus}
            if plus in responses and minus in responses:
                delta_plus=diff(responses[plus],responses["Base24"])
                delta_minus=diff(responses[minus],responses["Base24"])
                even=tuple(p+m for p,m in zip(delta_plus,delta_minus,strict=True))
                for sign,name,delta in ((1.,plus,delta_plus),(-1.,minus,delta_minus)):
                    pair[name]= {mode:peak(diff(delta,tuple(sign*amplitude*v for v in projection))) for mode,projection in projected.items()}
                active=[]; substeps=[]; nonlinear_inst=[]
                for key in stations["Base24"]:
                    branch_plus,branch_minus=stations[plus][key],stations[minus][key]
                    if key[0]<=25:
                        if branch_plus[3:5]!=branch_minus[3:5]: active.append(key)
                        if branch_plus[5]!=branch_minus[5]: substeps.append(key)
                    at_base=stations["Base24"][key]
                    nonlinear_inst.append((key,math.hypot(*(a+b-2*c for a,b,c in zip(branch_plus[13:19],branch_minus[13:19],at_base[13:19],strict=True)))))
                norm=math.fsum(v*v for _,v in nonlinear_inst)
                pos,mag=max(nonlinear_inst,key=lambda row:row[1])
                pair.update({"weak_even_MPa":peak(even[:56]),"single_tangent_error_lower_bound_MPa":.5*peak(even[:56]),
                    "changed_material_flags":len(active),"changed_substeps":len(substeps),"peak_station":pos,
                    "peak_even_station_MPa":mag,"even_station_sq_fraction_at_flagged":math.fsum(v*v for key,v in nonlinear_inst if key in active)/norm if norm else 0.})
            pairs[str(amplitude)]=pair
        signed[family]=pairs
    history_difference={"max_weak_MPa":peak(diff(responses["Base23"][:56],responses["Base24"][:56])),
        "max_station_stress_MPa":max(peak(diff(row[13:19],stations["Base24"][key][13:19])) for key,row in stations["Base23"].items()),
        "plastic_updates_before_q24_commit":sum(row[3]>0 for (point,_),row in stations["Base23"].items() if point<=25)}
    summary={"workbook_sha256":prep["book_sha256"],"prefix_sha256":prep["replay_sha256"],"trace_sha256":digest(trace),
        "solver_owned_closure":final,"compile_closure":closure,"wall_s":receipt["wall_seconds"],
        "origin_factor_kN":base_factor,"missed_factor_kN":target_factor,
        "origin_norm_with_trial_load_MPa":max(peak(original_rhs[:56]),
            peak(v/s for v,s in zip(diff(diagnostics["Base24"]["six_N_Nmm"],force(target_factor)),geometric_scale,strict=True))),
        "exact_rollback":True,"base":diagnostics["Base24"],"identical_field_history_comparison":history_difference,
        "measured_states":len(responses),"unavailable":dict(unavailable),"first_updates":first_updates,"signed_tests":signed,
        "scope":"First corrections and signed material tests from the same history. No updated field was accepted."}
    result = HERE/"Verification.json"
    result.write_text(json.dumps(summary,indent=2)+"\n",encoding="utf8")
    print(result,digest(result))


if __name__=="__main__":
    verify()
