' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сопоставляет касательные и первый шаг решателя при одном состоянии MVT2 B.
Public Function RunTestWangShearControlled(ByVal replayPath As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Const EC As Double = 30000#, NU As Double = 0.2, FT As Double = 2.10667357864589
    Const PEAK_STRAIN As Double = 0.0022, LOCALIZATION_LENGTH As Double = 125#
    concrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    plusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    response.Initialize operators, concrete, steel
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, response, EC, plusSide, minusSide
    Dim path As New CLoadPathVector, offset() As Double, direction() As Double
    path.Initialize 0#, 0#, 0#, 600000#, 0#, 0#, 10510000#, 0#, 0#, 0#, 0#, 1000#
    path.Components offset, direction
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim materials(-1 To 1) As CCoupledConcreteResponse, responses(-1 To 1) As ICoupledPointResponse
    Set materials(0) = concrete: Set materials(1) = plusConcrete: Set materials(-1) = minusConcrete
    Set responses(0) = response: Set responses(1) = plusSide: Set responses(-1) = minusSide
    Dim previous() As Double, base() As Double, secant() As Double, directionNewton() As Double
    Dim applied() As Double, internal() As Double, scratch() As Double, corrected() As Double, matrix() As Double
    Dim qBase As Double, qTrial As Double, k As Long, family As Variant, amount As Variant, label As String
    previous = history(23): base = history(24)
    qBase = factors(24): qTrial = qBase + (qBase - factors(23)) / 64#
    operators.LoadEquations 0#, 600000# * qTrial, 0#, 10510000#, 0#, 1000# * qTrial, applied
    Dim output As Integer: output = FreeFile
    Open tracePath For Append As #output
    Print #output, "B_TANGENT_LOAD;" & ExperimentNumberTest(qBase) & ";" & ExperimentNumberTest(qTrial)
    RestoreWangShearBaselineTest solver, history, base
    If Not solver.CopyTestWangTangent(base, 0, internal, matrix) Then Err.Raise 5, , "Недоступна невязка исходного поля B."
    RecordWangTangentStateTest output, "Base24", 24, qBase, solver, operators, materials, responses, base
    ReDim secant(1 To 60)
    For k = 1 To 60: secant(k) = base(k) - previous(k): Next k
    ScaleWangTangentDirectionTest operators, secant
    EmitWangTangentVectorTest output, "B_TANGENT_DIRECTION;Secant", secant
    If Not WangTangentCandidateTest(output, "Stock24", 1, 24, base, base, internal, applied, _
            qTrial, solver, operators, materials, responses, directionNewton) Then _
        Err.Raise 5, , "Недоступна штатная первая поправка MVT2 B."
    ScaleWangTangentDirectionTest operators, directionNewton
    EmitWangTangentVectorTest output, "B_TANGENT_DIRECTION;Newton", directionNewton
    For Each family In Array("Secant", "Newton")
        scratch = secant: If family = "Newton" Then scratch = directionNewton
        For Each amount In Array(0.0000000001, -0.0000000001, 0.000000001, -0.000000001, 0.00000001, -0.00000001)
            label = CStr(family) & "/" & ExperimentNumberTest(CDbl(amount))
            AddWangTangentDirectionTest base, scratch, CDbl(amount), corrected
            RecordWangTangentStateTest output, label, 24, qBase, solver, operators, materials, responses, corrected
        Next amount
    Next family
    If Not solver.ReplayAcceptedFields(history, 23) Then Err.Raise 5, , "Не восстановлена история B до поля 24."
    RecordWangTangentStateTest output, "Base23", 23, qBase, solver, operators, materials, responses, base
    ' Касательная до записи q24 формируется с H23. Невязка и проверка поправки используют H24.
    Dim matrix23() As Double, eligible As Boolean
    eligible = solver.CopyTestWangTangent(base, 2, scratch, matrix23)
    RestoreWangShearBaselineTest solver, history, base
    If eligible Then
        ScreenWangTangentCandidateTest output, "Consistent23", 2, 23, base, matrix23, base, internal, applied, _
            qTrial, solver, operators, materials, responses, corrected
    Else
        Print #output, "B_TANGENT_UNAVAILABLE;Consistent23;Matrix"
    End If
    WangTangentCandidateTest output, "Consistent24", 2, 24, base, base, internal, applied, _
        qTrial, solver, operators, materials, responses, corrected
    For Each amount In Array(0.00000001, -0.00000001)
        label = "Biased24/" & ExperimentNumberTest(CDbl(amount))
        AddWangTangentDirectionTest base, secant, CDbl(amount), scratch
        WangTangentCandidateTest output, label, 2, 24, scratch, base, internal, applied, _
            qTrial, solver, operators, materials, responses, corrected
    Next amount
    RequireWangAcceptedFieldTest solver, base
    RecordWangTangentStateTest output, "Unpublished24", 24, qBase, solver, operators, materials, responses, base
    RestoreWangShearBaselineTest solver, history, base
    RecordWangTangentStateTest output, "Restored24", 24, qBase, solver, operators, materials, responses, base
    Print #output, "B_TANGENT_END;24;" & ExperimentNumberTest(qBase)
    Close #output
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    Dim problem As String: problem = Err.Source & " " & Err.Description
    On Error Resume Next
    If output > 0 Then Close #output
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Строит направление с максимальной нормой Фробениуса по станциям, равной единице.
Private Sub ScaleWangTangentDirectionTest(ByVal operators As CCoupledElasticState, ByRef direction() As Double)
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double
    Dim point As Long, side As Long, j As Long, s As Double, n2 As Double, maxNorm As Double
    For point = 1 To operators.PointCount
        operators.PointStrain point, direction, strain
        operators.AxialGradientAtPoint point, direction, slope
        For side = -1 To 1
            n2 = 0#
            For j = 1 To 6
                s = strain(j) + side * 0.001 * slope(j)
                If j > 3 Then n2 = n2 + 0.5 * s * s Else n2 = n2 + s * s
            Next j
            maxNorm = GeomMax(maxNorm, Sqr(n2))
        Next side
    Next point
    If maxNorm <= 0# Then Err.Raise 5, , "Нулевое физическое направление пробы MVT2 B."
    For j = 1 To UBound(direction): direction(j) = direction(j) / maxNorm: Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Масштабирует одно и то же направление без изменения принятого поля решателя.
Private Sub AddWangTangentDirectionTest(ByRef base() As Double, ByRef direction() As Double, _
        ByVal amount As Double, ByRef target() As Double)
    Dim j As Long
    ReDim target(1 To UBound(base))
    For j = 1 To UBound(base): target(j) = base(j) + amount * direction(j): Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает вектор в инвариантной форме для независимой проверки.
Private Sub EmitWangTangentVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef values() As Double)
    Dim row As String, j As Long
    row = prefix
    For j = 1 To UBound(values): row = row & ";" & ExperimentNumberTest(values(j)): Next j
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает матрицу в выбранной точке, затем применяет её к одной исходной правой части.
Private Function WangTangentCandidateTest(ByVal output As Integer, ByVal label As String, ByVal choice As Long, _
        ByVal historyCount As Long, ByRef anchor() As Double, ByRef base() As Double, ByRef internal() As Double, _
        ByRef applied() As Double, ByVal qTrial As Double, ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByRef materials() As CCoupledConcreteResponse, _
        ByRef responses() As ICoupledPointResponse, ByRef correction() As Double) As Boolean
    Dim residual() As Double, matrix() As Double
    If Not solver.CopyTestWangTangent(anchor, choice, residual, matrix) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";Matrix"
        Exit Function
    End If
    WangTangentCandidateTest = ScreenWangTangentCandidateTest(output, label, choice, historyCount, anchor, matrix, _
        base, internal, applied, qTrial, solver, operators, materials, responses, correction)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает первую поправку и три её доли при неизменной исходной материальной истории H24.
Private Function ScreenWangTangentCandidateTest(ByVal output As Integer, ByVal label As String, ByVal choice As Long, _
        ByVal historyCount As Long, ByRef anchor() As Double, ByRef matrix() As Double, ByRef base() As Double, _
        ByRef internal() As Double, ByRef applied() As Double, ByVal qTrial As Double, ByVal solver As CCoupledNewtonSolver, _
        ByVal operators As CCoupledElasticState, ByRef materials() As CCoupledConcreteResponse, _
        ByRef responses() As ICoupledPointResponse, ByRef correction() As Double) As Boolean
    Dim row As String, i As Long, j As Long, fraction As Variant, target() As Double, state As String
    Print #output, "B_TANGENT_MATRIX_FAMILY;" & label & ";" & CStr(choice) & ";" & CStr(historyCount)
    EmitWangTangentVectorTest output, "B_TANGENT_ANCHOR;" & label, anchor
    For i = 1 To UBound(base)
        row = "B_TANGENT_MATRIX;" & label & ";" & CStr(i)
        For j = 1 To UBound(base): row = row & ";" & ExperimentNumberTest(matrix(j, i)): Next j
        Print #output, row
    Next i
    ReDim correction(1 To UBound(base))
    For j = 1 To UBound(base): correction(j) = applied(j) - internal(j): Next j
    Dim system As New CCoupledLinearSystem
    If Not system.Solve(matrix, correction, UBound(base)) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";LinearSystem;" & CStr(system.FailureCode)
        Exit Function
    End If
    Print #output, "B_TANGENT_LINEAR;" & label & ";" & ExperimentNumberTest(system.MinimumPivot)
    EmitWangTangentVectorTest output, "B_TANGENT_CORRECTION;" & label, correction
    For Each fraction In Array(1#, 0.25, 0.0625)
        state = label & "/Newton/" & ExperimentNumberTest(CDbl(fraction))
        AddWangTangentDirectionTest base, correction, CDbl(fraction), target
        Print #output, "B_TANGENT_DAMP;" & state & ";" & label & ";" & ExperimentNumberTest(CDbl(fraction))
        RecordWangTangentStateTest output, state, 24, qTrial, solver, operators, materials, responses, target
    Next fraction
    ScreenWangTangentCandidateTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет независимые центральные и боковые напряжения, признаки ветви и слабые строки.
Private Sub RecordWangTangentStateTest(ByVal output As Integer, ByVal label As String, ByVal historyCount As Long, _
        ByVal factor As Double, ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef field() As Double)
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, grad(1 To 6) As Double
    Dim residual() As Double, matrix() As Double, external() As Double, row As String, flag As Long
    Dim yielding As Boolean, principal As Long, substeps As Long, yieldValue As Double
    EmitWangTangentVectorTest output, "B_TANGENT_FIELD;" & label & ";" & CStr(historyCount) & ";" & _
        ExperimentNumberTest(factor), field
    If Not solver.CopyTestWangTangent(field, 0, residual, matrix) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";Residual"
        Exit Sub
    End If
    operators.LoadEquations 0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, external
    For i = 1 To UBound(residual): residual(i) = residual(i) - external(i): Next i
    EmitWangTangentVectorTest output, "B_TANGENT_RESIDUAL;" & label, residual
    For point = 1 To operators.PointCount
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, slope
        For side = -1 To 1
            For i = 1 To 6: station(i) = strain(i) + side * 0.001 * slope(i): Next i
            If responses(side).EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Не подтвержден станционный отклик MVT2 B. " & label
            flag = -1: principal = 0: substeps = -1: yieldValue = 0#
            If point <= operators.ConcretePointCount Then
                If Not materials(side).TryReadConcreteBranch(point, station, yielding, principal, substeps) Then _
                    Err.Raise 5, , "Недоступна ветвь бетона MVT2 B. " & label
                If Not materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=False) Then _
                    Err.Raise 5, , "Недоступна пробная поверхность бетона MVT2 B. " & label
                flag = Abs(CLng(yielding))
            End If
            row = "B_TANGENT_STATION;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area) & ";" & _
                CStr(flag) & ";" & CStr(principal) & ";" & CStr(substeps) & ";" & ExperimentNumberTest(yieldValue)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(station(i)): Next i
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(i)): Next i
            Print #output, row
        Next side
    Next point
End Sub
