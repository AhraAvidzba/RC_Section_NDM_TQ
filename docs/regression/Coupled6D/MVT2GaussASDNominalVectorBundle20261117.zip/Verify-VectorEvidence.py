"""Offline audit of the H53 path and fixed-history Q55.234375 MPa residuals."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import math
import runpy
import sys
import tempfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
POST = ('MVT2GaussASDNominalPostyield20261117', '06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED')
FOLLOW = ('MVT2GaussASDNominalDirectionalFollow20261117', '53E7D62932498F6EEC71BAA39120920B814E3F34410A245F818B4EB982501E69')
REPORTS = {
    'VectorNominal.json': 'C926B144CC34ED1AB42889F090773A1FED8DE0B833D34E2F7555969CC9EC1AC2',
    'bundle-output/VectorNominal.json': '8791C8E328AD33BEB301B46E2E1A6244011375736B1A6E4D62E80BEA51089C1C',
    'bundle24-output/VectorNominal.json': 'D3A5081B05ABAB4C1B744922BA5EB3CE992B233B1671BA96A14F07111B350602',
}
EMPTY = 'DF12204691CACA14EFF753D137116CADFBE4FD4F491EEA3A917A5159712FF6DE'


def digest(payload):
    return sha256(payload).hexdigest().upper()


def archive(repo, identity):
    name, expected = identity
    payload = repo / 'docs/regression/Coupled6D' / (name + '.zip')
    assert digest(payload.read_bytes()) == expected
    return ZipFile(payload)


def history(repo):
    with (tempfile.TemporaryDirectory(prefix='MVTVectorOffline_') as folder,
          archive(repo, POST) as original,
          archive(repo, FOLLOW) as extension):
        root = Path(folder)
        (root / 'Verify-Postyield.py').write_bytes(original.read('Verify-Postyield.py'))
        past = runpy.run_path(str(root / 'Verify-Postyield.py'))
        with past['archive'](repo, past['AUTH']) as authority:
            for leaf in ('Verify-Authoritative.py', 'Operators.py', 'Reequilibrate.py'):
                (root / leaf).write_bytes(authority.read(leaf))
        sys.path.insert(0, str(root))
        guard = runpy.run_path(str(root / 'Verify-Authoritative.py'))
        operator, source = guard['unpack'](root, repo)
        model = runpy.run_path(str(root / 'Reequilibrate.py'))
        _, _, geometry, directions, area, length, op, _, _, identification = model['read_inputs'](operator, root, source)
        first = json.loads(original.read('Postyield.json'))['result']['accepted']
        old = json.loads(extension.read('FollowCorrected.json'))
        tail = old['all_accepted']
        assert identification == old['source_operator_identity']
        first_wire = json.loads(gzip.decompress(original.read('Postyield.stress.json.gz')))
        tail_wire = json.loads(gzip.decompress(extension.read('FollowCorrected.stress.json.gz')))
        fields = first + tail
        stresses = first_wire['net_three_station_stress_MPa'] + tail_wire['three_station_net_stresses']
        steel = first_wire['steel'] + tail_wire['three_station_steel']
        assert len(fields) == len(stresses) == len(steel) == 53
        checked = [past['check_equilibrium'](sig, field, op, geometry, area, length, guard['signed_forces'])
                   for sig, field in zip(stresses, fields, strict=True)]
        steel_check = past['verify_history'](fields, steel, stresses, op, directions)
    return fields[-1], checked[-1], steel[-1], steel_check, old['all_attempts'][-1]['stock']


def evidence():
    proofs = []
    for leaf, pin in REPORTS.items():
        path = HERE / leaf
        data = path.read_bytes()
        assert digest(data) == pin
        proof = json.loads(data)
        proof_wire = path.with_suffix('.stress.json.gz').read_bytes()
        assert digest(proof_wire) == proof['derived_stresses_sha256'] == EMPTY
        assert json.loads(gzip.decompress(proof_wire)) == {'three_station_net_stresses': [], 'three_station_steel': []}
        assert proof['first_frozen_H53_sha256'] == dict((POST, FOLLOW))
        assert proof['true_53_prefix_stress_and_steel_exact'] and proof['same_nominal_material']
        assert proof['accepted'] == [] and not proof['physical_limit_established']
        assert proof['terminal'] == {'last_accepted_Qy_N': 55156.25, 'status': 'bounded_numerical_stop', 'target_Qy_N': 55234.375}
        proofs.append(proof)
    vector, eight, final = proofs
    steps = [p['all_attempts'][0]['same_model_vector'] for p in proofs]
    assert all(len(p['all_attempts']) == 1 for p in proofs)
    assert steps[0] == steps[1][:6] == steps[2][:6] and steps[1] == steps[2][:14]
    for p in proofs:
        assert p['first_rejection_two_distinct_fields'] == final['first_rejection_two_distinct_fields']
    for before, after in zip(steps[2][6:-1], steps[2][7:], strict=True):
        assert before['row_norm_before_MPa'] > before['actual_iteration_norm_MPa'] == after['row_norm_before_MPa']
        assert 0. < before['physical_move_from_first_trial'] <= before['original_trust']
    assert steps[2][-1]['result'] == 'no_true_full66_decrease_inside_signed_local_bundle'
    initial = steps[0][0]['row_norm_before_MPa']
    best = steps[2][-1]['row_norm_before_MPa']
    screen = final['first_rejection_two_distinct_fields']['stock_iterate']
    tau = screen['tolerance_MPa']
    assert best > tau and tuple(steps[2][-1]['active_rows']) == (54, 53, 55, 56)
    assert 113. < best / tau < 114. and .80 < 1. - best / initial < .81
    sites = [item for item in screen['largest_material_side_gaps_at_governing_row'][:4]]
    assert [(item['point'], item['side']) for item in sites] == [(20, 1), (20, -1), (7, -1), (10, -1)]
    assert all(math.isclose(item['plus_contribution_MPa'] - item['minus_contribution_MPa'],
                            item['plus_minus_signed_contribution_gap_MPa'], rel_tol=0., abs_tol=2e-18)
               for item in sites)
    assert screen['steel_tangent_branch_agrees_between_signs'] and screen['dominant_row_1_based'] == 56
    return initial, best, tau, final['all_attempts'][0]['stock']


if __name__ == '__main__':
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--repo', type=Path, default=Path.cwd())
    options = cli.parse_args()
    start, best, tau, stock = evidence()
    accepted, independent, steel, check, original_stop = history(options.repo)
    assert stock == original_stop and accepted['Q_target_N'] == 55156.25
    out = {'accepted_Qy_N': accepted['Q_target_N'], 'accepted_independent_norm_MPa': independent,
           'net_steel_independent_max_point_error_MPa': check['max_point_stress_error_MPa'],
           'accepted_minimum_concrete_principal_strain': steel['minimum_concrete_principal_strain'],
           'initial_uncommitted_norm_MPa': start, 'best_uncommitted_norm_MPa': best,
           'best_uncommitted_to_tolerance': best / tau, 'original_tolerance_MPa': tau,
           'physical_limit_established': False}
    print('MVT2 ASD VECTOR BUNDLE OFFLINE PASS', json.dumps(out, sort_keys=True, allow_nan=False))
