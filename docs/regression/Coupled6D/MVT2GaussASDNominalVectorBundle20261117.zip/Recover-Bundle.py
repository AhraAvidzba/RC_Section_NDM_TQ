"""Fixed-history measured directional bundle after the nominal vector stall."""
from hashlib import sha256
from pathlib import Path
from argparse import ArgumentParser
import json
import shutil
import sys

sys.dont_write_bytecode = True
import importlib.util

BASE = Path(__file__).resolve().with_name('Recover-Vector.py')
SPEC = importlib.util.spec_from_file_location('recover_vector', BASE)
vector = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(vector)
HERE = BASE.parent
REFERENCE = 'C926B144CC34ED1AB42889F090773A1FED8DE0B833D34E2F7555969CC9EC1AC2'
NEW = HERE / 'bundle-output'
MAX_CYCLES = 8


def finish(np, section, program, x, load, base, trace):
    confirmed = section.equations(x, load, False)
    assert np.array_equal(confirmed[2], base[2]) and np.array_equal(confirmed[0], base[0])
    section.accepted_stresses.append(confirmed[2].tolist())
    section.commit()
    return x, program['q_record'](section, x, float(load[3]), float(load[5]),
                                  confirmed, 'verified_measured_bundle_accepted', len(trace),
                                  [row['row_norm_before_MPa'] for row in trace])


def bundle(np, section, program, x, field, load, last, predictor):
    from scipy.optimize import linprog

    trust = float(np.max(np.abs(section.strain @ (predictor - last))))
    x = x.copy()
    trace = []
    for iteration in range(MAX_CYCLES):
        base = section.equations(x, load, False)
        residual = vector.coordinates(np, section, load, base)
        if base[4] <= base[5]:
            return finish(np, section, program, x, load, base, trace), trace
        branch = section.next_steel[2].copy()
        matrix, check = vector.verified_vector_columns(np, section, x, load, base, trust)
        if matrix is None:
            trace.append(check)
            break
        norms = np.linalg.norm(matrix, axis=0)
        active = np.argsort(np.abs(residual))[-4:][::-1]
        # Obtain one full Newton direction and three directions that target only
        # a currently governing row. Measure the complete response of each one.
        rhs = np.column_stack((residual, np.eye(66)[:, active[:3]] * residual[active[:3]]))
        directions = -np.linalg.lstsq(matrix / norms, rhs, rcond=1e-12)[0] / norms[:, None]
        range_ = float(np.max(np.abs(section.strain @ directions[:, 0])))
        assert range_ > 0.
        movements = np.max(np.abs(section.strain @ directions), axis=(0, 1, 2))
        item = {'iteration': iteration, 'row_norm_before_MPa': base[4],
                'active_rows': (active + 1).tolist(), 'original_trust': trust, **check}
        trace.append(item)
        best = None
        for factor in (.5, .125, .03125, .0078125, .001953125):
            radius = min(range_ * factor, trust / 4.)
            measured = []
            proposals = []
            for column in range(directions.shape[1]):
                if movements[column] == 0.:
                    continue
                for sign in (1., -1.):
                    delta = (sign * radius / movements[column]) * directions[:, column]
                    at = x + delta
                    if np.max(np.abs(section.strain @ (at - field))) > trust:
                        continue
                    value = section.equations(at, load, False)
                    if not np.array_equal(branch, section.next_steel[2]):
                        continue
                    measured.append((delta, vector.coordinates(np, section, load, value) - residual))
                    proposals.append((value, at, f'direction_{column}_{sign:g}'))
            if measured:
                action = np.asarray([v[1] for v in measured]).T
                scale = base[4]
                rows = np.vstack((np.column_stack((action / scale, -np.ones(66))),
                                  np.column_stack((-action / scale, -np.ones(66))),
                                  np.r_[np.ones(len(measured)), 0.]))
                values = np.r_[-residual / scale, residual / scale, 1.]
                optimum = linprog(np.r_[np.zeros(len(measured)), 1.], A_ub=rows, b_ub=values,
                                  bounds=[(0., None)] * (len(measured) + 1), method='highs')
                if optimum.success:
                    delta = np.asarray([v[0] for v in measured]).T @ optimum.x[:-1]
                    at = x + delta
                    if np.max(np.abs(section.strain @ (at - field))) <= trust:
                        result = section.equations(at, load, False)
                        if np.array_equal(branch, section.next_steel[2]):
                            proposals.append((result, at, 'measured_convex_bundle'))
                    item.setdefault('predicted_at_radii', []).append([radius, float(optimum.fun * scale)])
            for value, at, method in proposals:
                if value[4] < base[4] and (best is None or value[4] < best[0][4]):
                    best = value, at, method, radius
        if best is None:
            item['result'] = 'no_true_full66_decrease_inside_signed_local_bundle'
            break
        value, x, method, radius = best
        item.update({'method': method, 'sampling_max_engineering_strain': radius,
                     'actual_iteration_norm_MPa': value[4],
                     'physical_move_from_first_trial': float(np.max(np.abs(section.strain @ (x - field))))})
    base = section.equations(x, load, False)
    return (finish(np, section, program, x, load, base, trace), trace) if base[4] <= base[5] else (None, trace)


def staged_recovery(np, section, program, field, load, last, predictor):
    # Preserve the previously verified trajectory before enabling its separate
    # diagnostic extension. Capture only fields of strictly accepted iterations.
    equations = section.equations
    before = section.committed
    seen = []
    def capture(x, demand, matrix=False):
        result = equations(x, demand, matrix)
        seen.append((result[4], x.copy()))
        return result
    section.equations = capture
    try:
        recovered, earlier = ORIGINAL(np, section, program, field, load, last, predictor)
    finally:
        section.equations = equations
    if recovered is not None:
        return recovered, earlier
    assert section.committed == before
    anchor = earlier[-1]['row_norm_before_MPa']
    x = next(x for error, x in seen if error == anchor)
    recovered, later = bundle(np, section, program, x, field, load, last, predictor)
    return recovered, earlier + later


ORIGINAL = vector.recover
if __name__ == '__main__':
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--cycles', choices=(8, 24), type=int, default=8)
    options = cli.parse_args()
    MAX_CYCLES = options.cycles
    if MAX_CYCLES != 8:
        NEW = HERE / f'bundle{MAX_CYCLES}-output'
    assert sha256((HERE / 'VectorNominal.json').read_bytes()).hexdigest().upper() == REFERENCE
    # Keep previous exact failed observation sealed. Redirect only new outputs.
    NEW.mkdir(exist_ok=False)
    fixture = HERE / 'Postyield.py'
    shutil.copyfile(fixture, NEW / fixture.name)
    vector.HERE = NEW
    original_run_path = vector.runpy.run_path
    def fixture_location(path, *args, **kwargs):
        if Path(path) == NEW / fixture.name:
            path = str(fixture)
        return original_run_path(path, *args, **kwargs)
    vector.runpy.run_path = fixture_location
    vector.recover = staged_recovery
    vector.main()
