"""Same-model vector-residual recovery at the nominal Q55.234375 stop."""
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
ARCH=REPO/"docs/regression/Coupled6D"
ARTIFACTS={
 "MVT2GaussASDNominalPostyield20261117":"06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED",
 "MVT2GaussASDNominalDirectionalFollow20261117":"53E7D62932498F6EEC71BAA39120920B814E3F34410A245F818B4EB982501E69",
}
FIRST=55234.375
TARGETS=(FIRST,55312.5,55625.,56250.,57500.)
MAX_VECTOR=6
COL_STEP=5e-11
MAX_SEARCH=12


def digest(raw):
    return sha256(raw).hexdigest().upper()


def raw_json(data):
    return json.dumps(data,sort_keys=True,separators=(",",":"),allow_nan=False).encode()


def read_seed():
    saved=[]
    for name,pin in ARTIFACTS.items():
        path=ARCH/(name+".zip")
        assert digest(path.read_bytes())==pin
        with ZipFile(path) as pack:
            summary="Postyield" if len(saved)==0 else "FollowCorrected"
            p=json.loads(pack.read(summary+".json"))
            wire=json.loads(gzip.decompress(pack.read(summary+".stress.json.gz")))
            saved.append((p,wire))
    (post,r0),(follow,r1)=saved
    fields=post["result"]["accepted"]+follow["all_accepted"]
    tensors=r0["net_three_station_stress_MPa"]+r1["three_station_net_stresses"]
    steel=r0["steel"]+r1["three_station_steel"]
    assert len(fields)==len(tensors)==len(steel)==53 and fields[-1]["Q_target_N"]==55156.25
    return fields,tensors,steel,follow


def coordinates(np,section,demand,result):
    return np.r_[result[0]*section.scale,(result[3]-demand)/section.exact_force_scale]


def ranks(np,res,n=10):
    return [[int(j)+1,float(res[j])] for j in np.argsort(np.abs(res))[-n:][::-1]]


def material_side_rank(np,section,r0,plus,minus,row):
    qplus=np.einsum("spi,spi->sp",section.project[...,row],plus[2]-r0[2])
    qminus=np.einsum("spi,spi->sp",section.project[...,row],r0[2]-minus[2])
    gap=qplus-qminus
    return [{"side":(0,1,-1)[int(k)//45],"point":int(k)%45+1,
             "plus_minus_signed_contribution_gap_MPa":float(gap.flat[k]),
             "plus_contribution_MPa":float(qplus.flat[k]),
             "minus_contribution_MPa":float(qminus.flat[k])}
            for k in np.argsort(np.abs(gap),axis=None)[-8:][::-1]]


def screen(np,section,result,field,demand,old,tau):
    base_r=coordinates(np,section,demand,result)
    j=result[1]*section.scale[:,None]
    delta=np.linalg.solve(j,-result[0]*section.scale)
    plus=old(field+.25*delta,demand,False)
    sign_plus=section.next_steel[2].copy()
    minus=old(field-.25*delta,demand,False)
    sign_minus=section.next_steel[2].copy()
    row=int(np.argmax(np.abs(base_r[:56])))
    scale=float(np.max(np.abs(section.strain@delta)))
    return {"dominant_weak":ranks(np,result[0][:56]),"norm_MPa":result[4],"tolerance_MPa":tau,
            "largest_physical_direction_strain":scale,
            "dominant_row_1_based":row+1,"predicted_stock_action_MPa":float((j@delta)[row]),
            "measured_plus_action_MPa":float((plus[0][row]-result[0][row])/.25),
            "measured_minus_action_MPa":float((result[0][row]-minus[0][row])/.25),
            "steel_tangent_branch_agrees_between_signs":bool(np.array_equal(sign_plus,sign_minus)),
            "largest_material_side_gaps_at_governing_row":material_side_rank(np,section,result,plus,minus,row),
            "six_signed_resultants_N_Nmm":result[3].tolist()}


def verified_vector_columns(np,section,x,load,base,trust):
    eb=coordinates(np,section,load,base)
    branch=section.next_steel[2].copy()
    physical=np.max(np.abs(section.strain),axis=(0,1,2))
    scale=np.ones(60)
    scale=np.divide(COL_STEP,physical,out=scale,where=physical>0.)
    frame=np.eye(60)*scale
    matrix=np.empty((66,60))
    sided=[]
    max_asym=0.
    for j in range(60):
        if physical[j]==0.:
            matrix[:,j]=np.r_[section.G[:,j]*section.scale,np.zeros(6)]
            continue
        perturb=frame[j]
        plus=section.equations(x+perturb,load,False)
        same_plus=np.array_equal(branch,section.next_steel[2])
        minus=section.equations(x-perturb,load,False)
        same_minus=np.array_equal(branch,section.next_steel[2])
        ap=(coordinates(np,section,load,plus)-eb)/scale[j]
        am=(eb-coordinates(np,section,load,minus))/scale[j]
        max_asym=max(max_asym,float(np.max(np.abs(ap-am))*scale[j]))
        if same_plus and same_minus:
            matrix[:,j]=.5*(ap+am)
        elif same_plus or same_minus:
            matrix[:,j]=ap if same_plus else am
            sided.append((j+1,1 if same_plus else -1))
        else:
            return None,{"result":"both_numerical_sides_change_steel_branch","column":j+1}
    return matrix,{"one_sided_to_preserve_steel_columns":sided,"max_coordinate_side_action_gap_MPa":max_asym}


def recover(np,section,program,field,load,last,predictor):
    trust=float(np.max(np.abs(section.strain@(predictor-last))))
    if trust<=2*COL_STEP:
        return None,[{"result":"no_original_predictor_strain_radius","trust":trust}]
    x=field.copy();trace=[]
    for k in range(MAX_VECTOR+1):
        base=section.equations(x,load,False)
        row=coordinates(np,section,load,base)
        summary={"iteration":k,"row_norm_before_MPa":base[4],"tolerance_MPa":base[5],
                 "dominant_all_rows":ranks(np,row,4),"trust_extra_max_engineering_strain":trust,
                 "relative_to_rejected_base_max_engineering_strain":float(np.max(np.abs(section.strain@(x-field))))}
        trace.append(summary)
        if base[4]<=base[5]:
            confirm=section.equations(x,load,False)
            assert np.array_equal(confirm[2],base[2]) and np.array_equal(confirm[0],base[0])
            section.accepted_stresses.append(confirm[2].tolist()); section.commit()
            summary["result"]="accepted_original_equations"
            return (x,program["q_record"](section,x,float(load[3]),float(load[5]),confirm,
                                           "verified_vector_accepted",k,[item["row_norm_before_MPa"] for item in trace])),trace
        if k==MAX_VECTOR:
            break
        matrix,check=verified_vector_columns(np,section,x,load,base,trust)
        summary.update(check)
        if matrix is None:
            break
        # Solve the measured full residual equations together. Column scaling
        # prevents arbitrary coordinate amplitudes from biasing the least-squares solve.
        norms=np.linalg.norm(matrix,axis=0); assert np.all(norms>0.)
        delta=np.linalg.lstsq(matrix/norms,-row,rcond=1e-12)[0]/norms
        step_prediction=float(np.max(np.abs(row+matrix@delta)))
        summary["predicted_full_norm_MPa"]=step_prediction
        before=float(row@row)
        for i in range(MAX_SEARCH):
            ratio=.5**i
            candidate=x+ratio*delta
            movement=float(np.max(np.abs(section.strain@(candidate-field))))
            if movement>trust:
                continue
            true=section.equations(candidate,load,False)
            actual=coordinates(np,section,load,true)
            if true[4]<=true[5] or (actual@actual<before and true[4]<base[4]):
                summary.update({"accepted_iteration_step_fraction":ratio,"actual_iteration_norm_MPa":true[4],
                                "actual_iteration_max_engineering_strain":movement})
                x=candidate
                break
        else:
            summary["result"]="measured_vector_no_true_trust_reduction"
            break
    return None,trace


def main():
    started=perf_counter()
    fixture=runpy.run_path(str(HERE/"Postyield.py"))
    refs,tensors,steel_ref,old=read_seed()
    SRC=fixture["SRC"]
    sys.path.insert(0,str(fixture["NUMPY"]));sys.path.insert(0,str(SRC))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0" and np.__version__=="2.3.5"
    program=runpy.run_path(str(SRC/"Reequilibrate.py"))
    sh,native,geo,dirs,area,length,op,seeds,obs,identity=program["read_inputs"](fixture["OPS"],fixture["NATIVE_ROOT"])
    assert identity==old["source_operator_identity"]
    stock=program["try_correct"]
    program_scope=stock.__globals__
    load=lambda q:np.array((0.,-600.*q,0.,10510000.,0.,q))
    program_scope["loads"]=lambda arrays,t,q:arrays.array((0.,-600.*q,0.,t,0.,q))
    steel=[]
    model=fixture["steel_section"](program["Section"],np,steel)
    material=program["commands"](sh,native,("default",))["default"]
    section=model(np,ops,material,geo,dirs,area,length,op,perf_counter()+110.)
    fields=refs.copy()
    for n,step in enumerate(fields):
        q=step["Q_target_N"]; t=step["T_target_Nmm"]
        result=section.equations(np.array(step["field"]),program_scope["loads"](np,t,q),False)
        assert result[4]<=result[5] and np.array_equal(result[2],tensors[n])
        section.accepted_stresses.append(result[2].tolist()); section.commit()
    assert section.committed==53 and raw_json(steel)==raw_json(steel_ref)
    screens=None
    attempts=[]
    stop=None
    print("START exact H53 vector control",flush=True)
    for target in TARGETS:
        q_last=fields[-1]["Q_target_N"];q_prior=fields[-2]["Q_target_N"]
        last=np.array(fields[-1]["field"]);prior=np.array(fields[-2]["field"])
        factor=(target-q_last)/(q_last-q_prior)
        predictor=last+factor*(last-prior) if factor<4. else last.copy()
        old_eval=section.equations
        calls=[]
        def watching(x,d,matrix=False):
            values=old_eval(x,d,matrix)
            calls.append((x.copy(),matrix,values[4]))
            return values
        section.equations=watching
        try:
            field,diag=stock(section,predictor,10510000.,target)
        finally:
            section.equations=old_eval
        entry={"target_Qy_N":target,"stock":{k:v for k,v in diag.items() if k!="field"}}
        if target==FIRST:
            assert field is None and diag==old["all_attempts"][-1]["stock"]
            last_matrix=next(x for x,mode,value in reversed(calls) if mode)
            rejected=calls[-1][0]
            stock_state=old_eval(last_matrix,load(target),True)
            last_trial=old_eval(rejected,load(target),True)
            assert stock_state[4]==diag["weak_or_forces_norm_MPa"]
            assert last_trial[4]==old["all_attempts"][-1]["bounded_probe"]["starting_norm_MPa"]
            screens={"stock_iterate":screen(np,section,stock_state,last_matrix,load(target),old_eval,stock_state[5]),
                     "rejected_line_trial":screen(np,section,last_trial,rejected,load(target),old_eval,last_trial[5])}
            after=old_eval(rejected,load(target),False)
            assert np.array_equal(after[2],last_trial[2]) and np.array_equal(after[0],last_trial[0])
            assert section.committed==53
        if field is None:
            eligible=diag["kind"] in ("line_search_no_decrease","maximum_iterations")
            if eligible:
                selected=min((c for c in calls if not c[1]),key=lambda c:c[2])[0]
                candidate,record=recover(np,section,program,selected,load(target),last,predictor)
                entry["same_model_vector"]=record
                if candidate is not None: field,diag=candidate
        attempts.append(entry)
        if field is None:
            stop={"status":"bounded_numerical_stop","target_Qy_N":target,"last_accepted_Qy_N":fields[-1]["Q_target_N"]}
            break
        fields.append({**diag,"phase":f"VectorQ{target:g}","subdivision":0})
        print("ACCEPTED",target,diag["all_weak_and_force_max_MPa"],flush=True)
    ops.wipe()
    raw=gzip.compress(raw_json({"three_station_net_stresses":section.accepted_stresses[53:],
                                 "three_station_steel":steel[53:]}),compresslevel=9,mtime=0)
    proof={"status":"PASS","same_nominal_material":True,"physical_limit_established":False,
           "true_53_prefix_stress_and_steel_exact":True,"first_rejection_two_distinct_fields":screens,
           "first_frozen_H53_sha256":ARTIFACTS,"all_attempts":attempts,"accepted":fields[53:],
           "numerical_control":{"vector_correction_cap":MAX_VECTOR,"probe_engineering_strain":COL_STEP,"backtracks":MAX_SEARCH},
           "terminal":stop,"derived_stresses_sha256":digest(raw)}
    payload=(json.dumps(proof,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with (HERE/"VectorNominal.json").open("xb") as f:f.write(payload)
    with (HERE/"VectorNominal.stress.json.gz").open("xb") as f:f.write(raw)
    print("PASS",digest(payload),digest(raw),"last",fields[-1]["Q_target_N"],stop,"seconds",round(perf_counter()-started,6))


if __name__=="__main__":
    main()
