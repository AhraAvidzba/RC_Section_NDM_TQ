"""Offline robust force and compatibility check for Kani's measured 19/512 field."""
from pathlib import Path
import json
import runpy
import hashlib
import numpy as np
from scipy.optimize import linprog

here=Path(__file__).resolve().parent
root=here.parent
old=runpy.run_path(root/'KaniWarpBeyond43/Check-KaniBeyond43.py')
data=old['trs'](root/'KaniWarpBeyond43')
def peak(x): return np.max(abs(x)).item()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
paths=[root/name for name in ('KaniV4Rebase3/RebasedLinearSystems.npz','KaniV4Rebase38/RebasedLinearSystems.npz','KaniV4Jv38/KaniBHalfLinearSystems.npz')]
blocks=[dict(np.load(p,allow_pickle=False)) for p in paths]
B=blocks[0]['strain_matrix'].reshape(-1,88)
geometry=blocks[0]['stock_equality_matrix_MPa']
assert all(np.array_equal(a['strain_matrix'], blocks[0]['strain_matrix']) for a in blocks)
assert all(np.array_equal(a['stock_equality_matrix_MPa'], geometry) for a in blocks)
assert peak(B[:,83:])==0
back=blocks[0]['resultant_projection']
families={}
dataJv=[]
for name,a in zip(('Rebase3','Rebase38','Jv38'),blocks):
    directions=np.column_stack([a[k+'_newton_direction'] for k in ('stock','refined')])
    assert peak(geometry @ directions) < 3e-8
    w=B@directions
    dual=np.linalg.solve(w.T@w,w.T@B)
    assert peak(dual @ directions - np.eye(2))<3e-10
    counts=(a['sample_denominator']==4096)
    assert counts.sum()==2
    Y=np.array([np.c_[a[k+'_actual_weak_directional_MPa'][counts,:83],a[k+'_actual_six_directional_MPa'][counts]] for k in ('stock','refined')]).transpose(1,2,0)
    measured=np.mean(Y,axis=0)
    for k in ('stock','refined'):
        op=a[k+'_force_matrix_MPa']
        assert peak(back@op[:83]-op[83:])<3e-8
        families[f'{name}/{k}']=op
        families[f'{name}/{k}/central']=op+(measured-op@directions)@dual
        if k=='refined':
            for j,k2 in enumerate(a['sample_sign'][counts]):
                families[f'{name}/{k}/oneSide{k2}']=op+(Y[j]-op@directions)@dual
    dataJv.append((name,directions,dual,measured,Y))
cols=np.maximum.reduce([np.max(abs(f),axis=0) for f in families.values()])
base={}
target='Bracket19of512'
for h in (42,43):
    tag=f'History{h}/{target}/Probe'
    native, field, projection, _, _=data
    q=field[tag]; raw=native[tag]
    r=old['independent'](data,tag)
    # Geometry residuals are independently reconstructed.
    np.testing.assert_allclose(geometry[-1,:87],25600*projection,rtol=0,atol=5e-10)
    e=np.r_[25600*old['section'].gauges@q[2:81],25600*(projection@q[2:]-q[1])]
    assert peak(e)<3e-12
    warp=old['warp'](r)
    assert not warp['feasibility']
    x0=np.r_[q[2:],q[0]]
    center=np.zeros(88)
    center[85]=-6.79114354245e-7 # one absolute gauge shift for both measured histories
    shifted=r+old['D']*center[85]
    assert peak(shifted)>raw[3]
    base[h]=(r,e,x0,center,shifted,float(raw[3]),q[1])
families['Rebase3/refined']=families['Rebase3/refined']
models={
    'refined':('Rebase3/refined','Rebase38/refined','Jv38/refined'),
    'refined_w_calibration':tuple(k for k in families if '/refined' in k),
    'all':tuple(families),
}
r,e,x,center,shifted,tau,gamma=base[43]
F0=tau/cols
F0[83:87]=1e-6
F0[87]=1e-7
F0[:83]*=.1
# Engineering shapes can have nearly-null kinematics; cap each station explicitly and
# also limit gross coordinates so a minimax iterate cannot take a hidden large step.
Aeq=np.c_[geometry*F0,np.zeros(5)]
gscale=np.max(abs(Aeq),axis=1)
Aeq/=gscale[:,None]
rhs=-e/gscale
lo=[(-100,100)]*83+[(-2,2)]*4
rhs0=np.vstack([base[h][4] for h in base])

def solve(keys, cap, fixed_lambda, target=0., h=(42,43)):
    # All force rows for all charts and histories. If target > 0, minimize required strain.
    A=np.vstack([families[k]*F0 for k in keys])
    U=[]
    D=[]
    for hist in h:
        b=np.tile(base[hist][4],len(keys))
        if target:
            U += [np.c_[A/tau,np.zeros(len(A))],np.c_[-A/tau,np.zeros(len(A))]]
            D += [(target-b)/tau,(target+b)/tau]
        else:
            U += [np.c_[A/tau,-np.ones(len(A))],np.c_[-A/tau,-np.ones(len(A))]]
            D += [-b/tau,b/tau]
    S=B*F0/cap
    if target:
        U += [np.c_[S,-np.ones(len(S))],np.c_[-S,-np.ones(len(S))]]
        D += [np.zeros(len(S)),np.zeros(len(S))]
    else:
        U += [np.c_[S,np.zeros(len(S))],np.c_[-S,np.zeros(len(S))]]
        D += [np.ones(len(S)),np.ones(len(S))]
    U=np.vstack(U); D=np.concatenate(D)
    bounds=lo+[(0,0) if fixed_lambda else (-1,1),(0,1) if target else (0,None)]
    fun=np.r_[np.zeros(88),1.]
    p=linprog(fun,U,D,Aeq,rhs,bounds=bounds,method="highs")
    if not p.success:
        return {'ok':False,'message':p.message,'cap':cap,'target':target}
    dual=(p.ineqlin.marginals@D+p.eqlin.marginals@rhs+
          sum((0 if l is None else l*p.lower.marginals[i])+(0 if u is None else u*p.upper.marginals[i]) for i,(l,u) in enumerate(bounds)))
    stat=peak(fun-U.T@p.ineqlin.marginals-Aeq.T@p.eqlin.marginals-p.lower.marginals-p.upper.marginals)
    assert abs(dual-p.fun)<2e-6 and stat<2e-6,(dual,p.fun,stat)
    d=p.x[:88]*F0
    impacts={name:op@d for name,op in families.items()}
    norms={str(j):{name:peak(dt+base[j][4]) for name,dt in impacts.items()} for j in base}
    return {'ok':True,'objective':float(p.fun),'objective_dual':float(dual),'dual_stationarity':stat,
            'norms':norms,'d':d.tolist(),'cap':cap,'target':target,'material_step':peak(B@d),
            'noncollinear_coordinate_change_norm':float(np.linalg.norm(d[:83])),'balance':peak(geometry@d+e),'mechanics_only':fixed_lambda}

if __name__=='__main__':
    results={}
    for name,keys in models.items():
        for cap in (1e-13,3e-13,1e-12,3e-12,1e-11):
            tag=f'{name}/{cap}'
            result=solve(keys,cap,True)
            results[tag]=result
            if result['ok']:
                print(tag,f"{result['objective']*tau:.8e}",f"mechanics {result['material_step']:.3g}",f"allmax {max(max(v.values()) for v in result['norms'].values()):.8e}",flush=True)
        for margin in (1e-9,2e-9,5e-9):
            tag=f'{name}/margin/{margin}'
            result=solve(keys,1e-11,True,target=tau-margin)
            results[tag]=result
            print(tag,result.get('material_step'),result.get('message'),flush=True)
    record={'input_sha':{p.name+str(i):sha(p) for i,p in enumerate(paths)},
            'native_trace_sha':sha(root/'KaniWarpBeyond43/Native/KaniV4Trace.csv'),
            'native_stations_sha':sha(root/'KaniWarpBeyond43/Native/KaniV4Stations.csv'),
            'tolerance_MPa':tau,'results':results}
    (here/'LPResults.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')