from pathlib import Path
import json, runpy
import numpy as np
from fractions import Fraction

here=Path(__file__).resolve().parent
root=here.parent
src=runpy.run_path(here/'Solve.py')
old=src['old']; peak=src['peak']; sha=src['sha']; B=src['B']; E=src['geometry']
r=src['base']; tau=src['tau']; force=1e5
chosen=json.loads((here/'LPResults.json').read_text(encoding='utf8'))['results']['all/1e-13']
assert chosen['ok'] and chosen['mechanics_only'] and chosen['balance']<3e-12
v=np.array(chosen['d']); c=r[43][3]; q=np.array(r[43][2]); gamma=r[43][-1]
assert np.array_equal(q,r[42][2]); assert gamma==r[42][-1]
nominal=next(line.split(';') for line in (root/'KaniWarpBeyond43/Continuation43.csv').read_text(encoding='ascii').splitlines() if line.startswith('KANI_B_FIELD;Bracket19of512;'))
co=np.array([*map(float,nominal[4:-1]),float(nominal[-1])]); assert peak(co-q)<1e-14
assert gamma==float(nominal[3]) or abs(gamma-float(nominal[3]))<1e-16
q=co; nominal[1]='Nominal19of512'
def line(name,x):
    assert x[-1]==q[-1]
    return ';'.join([*nominal[:1],name,*nominal[2:4],*(format(n,'.17g') for n in x[:-1]),nominal[-1]])
w=v.copy(); w[:83]=0
fields={'Nominal19of512':q,'GaugeOnly19of512':q+c+w,'Opposite19of512':q+c-v,'OffAxis19of512':q+c+v}
fixture=here/'Mechanics44.csv'
fixture.write_bytes(('\r\n'.join([';'.join(nominal),*(line(name,x) for name,x in fields.items() if name!=nominal[1])])+'\r\n').encode('ascii'))
# Compare with actual measured older secants and the nominal continuation direction.
previous=src['data'][1]['History43/Next35of1024/Probe']
path=np.r_[r[43][2][:87]-previous[2:],r[43][2][-1]-previous[0]]
bv=B@v; bp=B@path
cos=float((bv@bp)/(np.linalg.norm(bv)*np.linalg.norm(bp)))
assert abs(cos)<.75
comparisons={}
for name,directions,dual,measured,independent in src['dataJv']:
    projection=dual@v
    captured=(B@directions)@projection
    disagreement=peak((independent[0]-independent[1])@projection)
    assert peak(captured)<5e-13
    comparisons[name]={'capturedProjectionCoefficients':projection.tolist(),
            'physicalFractionInMeasuredSubspace':float(np.linalg.norm(captured)/np.linalg.norm(bv)),
            'calibratedEvenOddMismatch_MPa':disagreement}
expected={}
for name,x in fields.items():
    d=x-q
    ke=E@d+r[43][1]
    assert peak(ke)<4e-12 and x[-1]==q[-1]
    hist={}
    for h in r:
        # Cover the known trace serialization roundoff without replacing the native baseline.
        predictions=np.array([r[h][0]+op@d for op in src['families'].values()]); norms=np.max(abs(predictions),axis=1)
        exact_gauge=(r[h][0]+src['families']['Rebase3/refined']@d).tolist() if name=='GaugeOnly19of512' else None
        hist[h]={'norm_MPa':[float(np.min(norms)),float(np.max(norms))],
                 'rowEnvelope_MPa':np.c_[np.min(predictions,axis=0),np.max(predictions,axis=0)].tolist(),
                 'gaugeOnlyRows_MPa':exact_gauge,'row46And70Envelope_MPa':predictions[:,[45,69]].tolist()}
    expected[name]={'q':x[:87].tolist(),'lambda':float(x[-1]),'maxStationStrainDelta':peak(B@d),'compatibilityNorm_MPa':peak(ke),'histories':hist}
assert expected['OffAxis19of512']['histories'][43]['norm_MPa'][1]<tau-1.5e-8
assert expected['GaugeOnly19of512']['histories'][43]['norm_MPa'][0]>tau
out={'fixtureSHA256':sha(fixture),'qSignConvention':'qCandidate=qNominal+commonGaugeCenter+d, qOpposite=qNominal+commonGaugeCenter-d',
     'lambda':float(q[-1]),'Qy_N':float(q[-1]*force),'gamma':float(nominal[3]),'tolerance_MPa':tau,
     'signedVectorIncrement':v.tolist(),'absoluteGaugeCenterDelta':c.tolist(),
     'absoluteCosineWithPreviousContinuation':abs(cos),'localArchiveProjection':comparisons,
     'mechanics':expected,'linearProgramsSHA256':sha(here/'LPResults.json')}
receipt=here/'Prediction.json'
receipt.write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(sha(fixture),sha(receipt),out['lambda'],out['Qy_N'],out['gamma'],cos)
for k,e in expected.items(): print(k,e['maxStationStrainDelta'],e['compatibilityNorm_MPa'],e['histories'][43]['norm_MPa'])
print(comparisons)
