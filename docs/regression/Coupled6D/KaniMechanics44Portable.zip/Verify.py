from pathlib import Path
from hashlib import sha256
import json, numpy as np
from scipy.interpolate import BSpline

def operators(geometry, L):
    x,y,area=geometry.T
    normalized=area/(305.*610.)
    gx_knots=np.array([-152.5]*4+[0.]+[152.5]*4)
    gy_knots=np.array([-305.]*4+[0.]+[305.]*4)
    basis=np.eye(5)
    spline_x=BSpline(gx_knots,basis,3,extrapolate=False)
    spline_y=BSpline(gy_knots,basis,3,extrapolate=False)
    nx,ny=spline_x(x),spline_y(y)
    dx,dy=spline_x.derivative()(x),spline_y.derivative()(y)
    def pair(a,b):
        return (a[:,:,None]*b[:,None,:]).reshape((len(x),25))
    shape=pair(ny,nx)
    slope_x=L*pair(ny,dx)
    slope_y=L*pair(dy,nx)
    h=np.zeros((184,6,79))
    u=slice(4,79,3)
    v=slice(5,79,3)
    w=slice(6,79,3)
    h[:,2,0]=1.
    h[:,2,1]=y/L
    h[:,2,2]=x/L
    h[:,4,3]=-y/L
    h[:,5,3]=x/L
    h[:,0,u]=slope_x
    h[:,1,v]=slope_y
    h[:,3,u]=slope_y
    h[:,3,v]=slope_x
    h[:,4,w]=slope_x
    h[:,5,w]=slope_y
    c=np.zeros((4,79))
    concrete=slice(144)
    shape_weight=shape[concrete]*normalized[concrete,None]
    c[0,u]=c[1,v]=c[2,w]=shape_weight.sum(axis=0)
    c[3,u]=(-y[concrete,None]/L*shape_weight).sum(axis=0)
    c[3,v]=(x[concrete,None]/L*shape_weight).sum(axis=0)
    resultants=np.zeros((184,6,6))
    resultants[:,0,2]=1.
    resultants[:,1,2]=y
    resultants[:,2,2]=x
    resultants[:,3,4]=-y
    resultants[:,3,5]=x
    resultants[:,4,4]=1.
    resultants[:,5,5]=1.
    scales=305.*610.*np.array([1.,L,L,L,1.,1.])
    return h, shape, c, resultants, normalized, scales

ROOT=Path(__file__).resolve().parent
def read(name): return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def digest(name): return sha256((ROOT/name).read_bytes()).hexdigest().upper()
def peak(a): return float(np.max(np.abs(a)))
def near(a,b,tol): assert abs(a-b)<=tol,(a,b,tol)

def control_certificate(residual,weights,tau):
    coeff=weights[2]
    pos=coeff>0.
    lo=float(np.max((-tau-residual[:79][pos])/coeff[pos]))
    hi=float(np.min((tau-residual[:79][pos])/coeff[pos]))
    involved=np.r_[pos,np.zeros(10,dtype=bool)]
    feasible=lo<=hi and peak(residual[~involved])<=tau
    return lo,hi,bool(feasible)

def computed(d, original):
    g,L=d["geometry"],float(d["length"])
    h,shape,c,qmat,weights,scales=operators(g,L)
    states={}
    for name,field,native,index in zip(d["names"],d["fields"],d["states"],d["station_index"],strict=True):
        tag=str(name)
        stations=d["stations"][int(index)]
        lam,target=field[:2]
        q=field[2:]
        coord=q[:79]
        depth=q[79:83]
        mu=q[83:]
        assert lam==native[1] and target==native[0]
        strains=h@coord
        slope=h[:,:,:4]@depth
        eps3=np.array([strains+i*.001*slope for i in (-1,0,1)])
        assert peak(eps3-stations[:,:,:6])<2e-12
        stresses=stations[1,:,6:]
        gradient=(stations[2,:,6:]-stations[0,:,6:])/.002
        eq=np.einsum("nij,ni,n->j",h,stresses,weights)
        eq[4:]-=np.einsum("nk,na,n->ka",shape,gradient[:,[4,5,2]],weights).ravel()
        eq+=c.T@mu
        long_eq=np.einsum("nij,ni,n->j",h[:,:,:4],gradient,weights)
        long_eq[1]-=1e5*lam/scales[0]
        gauge=c@coord
        force=np.einsum("nij,nj,n->i",qmat,stresses,g[:,2])
        assert peak(np.r_[eq,long_eq,gauge]-native[12:])<2e-10
        assert peak((force-native[6:12])/scales)<2e-10
        r=np.r_[eq,long_eq,(force-np.r_[np.zeros(5),1e5*lam])/scales]
        gamma=float(weights[:144]@strains[:144,5])
        tau=float(native[3])
        assert abs(gamma-target)*25600. <=tau and peak(gauge)*25600.<=tau
        norm=max(peak(r),abs(gamma-target)*25600.)
        near(norm,native[2],2e-10)
        states[tag]={"r":r,"tau":tau,"norm":norm,"field":field,"idx":int(index),"resultants":native[6:12]}
    return states,c

def verify():
    manifest=read('Manifest.json')
    for name,value in manifest['files'].items(): assert digest(name)==value,name
    preparation=read('Preparation.json'); prediction=read('Prediction.json'); witness=read('Verification.json')
    compile=read('CodeUpdate.json'); compile_close=read('CompileClosure.json'); closure=read('KaniV4.txt.ProcessClosure.json'); owner=read('KaniV4.txt.Ownership.json')
    raw=(ROOT/'KaniV4.txt').read_text(encoding='utf-8-sig')
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in raw and 'SOURCE_UNCHANGED: True' in raw
    fingerprint='A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A'
    assert preparation['workbook_sha256']==witness['workbook']==compile['ProductionSHA256']==fingerprint
    assert compile['Compiled'] and not compile['ProductionChanged'] and closure['Passed'] and int(closure['ChildExitCode'])==0
    stopped=closure['Closure']['FinalState']
    assert stopped['State']==compile_close['State']=='Absent' and owner['VerifiedNewOwner']
    assert int(stopped['PID'])==int(owner['PID']) and stopped['StartTicksUTC']==owner['StartTicksUTC']
    assert int(stopped['PID'])!=int(compile_close['PID']) or stopped['StartTicksUTC']!=compile_close['StartTicksUTC']
    for name in ('Mechanics44.csv','KaniGaugeInput.csv','Prediction.json','LPResults.json'):
        assert digest(name)==preparation['frozen'][name],name
    assert prediction['fixtureSHA256']==digest('Mechanics44.csv')
    with np.load(ROOT/'MeasuredSamples.npz',allow_pickle=False) as d:
        st,c=computed(d,witness)
    assert len(st)==manifest['recordedStates'] and len({m['idx'] for m in st.values()})==manifest['uniqueMaterialStates']
    a,b=c[2,[45,69]]
    assert a>0 and b>0 and np.count_nonzero(c[[0,1,3]][:,[45,69]])==0
    def pair(row): return float((b*row[45]-a*row[69])/(a+b))
    report={}
    for history,control in witness['tests'].items():
        root='History'+history; before=st[root+'/Base']; end=st[root+'/End']
        assert before['idx']==end['idx'] and np.array_equal(before['field'],end['field'])
        nominal=st[root+'/Nominal19of512/Probe']; chart=st[root+'/GaugeOnly19of512/Probe']; minus=st[root+'/Opposite19of512/Probe']; plus=st[root+'/OffAxis19of512/Probe']
        assert nominal['idx']==chart['idx'] and len({nominal['idx'],minus['idx'],plus['idx']})==3
        assert all(np.array_equal(m['field'][:2],nominal['field'][:2]) for m in (chart,minus,plus))
        assert nominal['norm']>nominal['tau'] and abs(pair(nominal['r']))>nominal['tau'] and abs(pair(chart['r']))>chart['tau']
        near(pair(nominal['r']),pair(chart['r']),2e-13)
        for tag,m in zip(control,(nominal,chart,minus,plus)):
            rows=np.array(control[tag]['rows_MPa']); assert len(rows)==89 and peak(m['r']-rows)<2e-10
            near(m['norm'],control[tag]['complete_norm_MPa'],2e-10)
        if control['OffAxis19of512']['exact']:
            solved=st[root+'/OffAxis19of512/Solved']
            assert np.array_equal(solved['field'],plus['field']) and solved['idx']==plus['idx']
            assert peak(solved['r'])<=solved['tau']
        report[history]={'nominalPairFloorMPa':abs(pair(nominal['r'])),'gaugeOnlyPairFloorMPa':abs(pair(chart['r'])),
            'offAxisNormMPa':plus['norm'],'oppositeNormMPa':minus['norm'],'toleranceMPa':plus['tau']}
    base,restore=st['History43/Base'],st['History43/Restore']
    assert base['idx']==restore['idx'] and np.array_equal(base['field'],restore['field'])
    if witness['commit']:
        comp=st['History43/Committed']; trial=st['History43/OffAxis19of512/Solved']
        assert comp['idx']==trial['idx'] and np.array_equal(comp['field'],trial['field'])
        near(comp['norm'],witness['commit']['complete_norm_MPa'],2e-10)
        assert comp['norm']<=comp['tau'] and witness['commit']['lambda_uncertainty']>0.
    assert (witness['outcome']=='EXACT_ACCEPTED')==bool(witness['commit'])
    print(json.dumps({'workbook':fingerprint,'outcome':witness['outcome'],'stationTensorsPerState':552,'forceRows':89,
        'compatibilityRows':5,'states':len(st),'details':report,'ownedExcelFinalState':stopped},indent=2))

if __name__=='__main__': verify()
