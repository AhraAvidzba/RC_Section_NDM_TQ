"""Check the native evidence for one frozen mechanical direction, without trusting solver norms."""
from pathlib import Path
import csv, json, runpy

HERE=Path(__file__).resolve().parent
PRE=HERE.parent/'KaniWarpBeyond43'
P=runpy.run_path(HERE/'Prepare-Mechanics44.py')
N=runpy.run_path(PRE/'Verify-Beyond43.py')
O=runpy.run_path(PRE/'Check-KaniBeyond43.py')
np=N['np']; R=N['R']; peak=O['peak']; sha=P['digest']; snapshot=N['CHART']['snapshot']
NAMES=('Nominal19of512','GaugeOnly19of512','Opposite19of512','OffAxis19of512')

def verify():
    frozen=P['check']()
    src=HERE/'Native'; report=src/'KaniV4.txt'
    base_native=O['trs'](PRE); native=O['trs'](HERE)
    A,Q,proj,T,hashes=native
    expected=json.loads((HERE/'Prediction.json').read_text(encoding='utf8'))
    R(np.array_equal(proj,base_native[2]),'Changed control projection')
    closure=json.loads((src/'KaniV4.txt.ProcessClosure.json').read_text(encoding='utf-8-sig'))
    R(closure['Passed'] and closure['ChildExitCode']==0 and closure['Closure']['FinalState']['State']=='Absent','No closed private Excel proof')
    compiler=json.loads((HERE/'docs/regression/CodeUpdate.json').read_text(encoding='utf-8-sig'))
    R(compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256']==frozen['workbook_sha256']
       and compiler['WorkbookSHA256']==sha(HERE/P['SHADOW'])
       and sorted(compiler['Modules'])==['CCoupledElasticState','CCoupledNewtonSolver','modTestKaniStage38'],'Wrong compiled build')
    R('TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in report.read_text(encoding='utf-8-sig'),'Native fixture failure')
    outcomes={}; diagnostics={}; adjoints={}; choice=None
    for kind,*payload in csv.reader((src/'KaniV4Trace.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        if kind=='WITNESS_CHOICE': choice=int(payload[0]); continue
        if kind in ('OUTCOME','DIAGNOSTIC','ADJOINT'):
            tab={'OUTCOME':outcomes,'DIAGNOSTIC':diagnostics,'ADJOINT':adjoints}[kind]
            tag,*values=payload; R(tag not in tab,'Duplicate summary'); tab[tag]=values
    R(set(outcomes)=={f'History{h}/{n}' for h in (42,43) for n in NAMES},'Missing diagnostic probe')
    result={}; margin=[]
    for h in (42,43):
        stem=f'History{h}'; baseline=stem+'/Base'; end=stem+'/End'
        R(np.array_equal(Q[baseline],base_native[1][baseline]),'Native history field changed')
        R(peak(T[baseline]-base_native[3][baseline])<2e-10,'Native history constitutive state changed')
        R(np.array_equal(Q[baseline],Q[end]) and np.array_equal(T[baseline],T[end]),'Trials changed accepted history')
        nominal=stem+'/'+NAMES[0]+'/Probe'; gauge=stem+'/'+NAMES[1]+'/Probe'; opposite=stem+'/'+NAMES[2]+'/Probe'; off=stem+'/'+NAMES[3]+'/Probe'
        R(all(np.array_equal(Q[k][:2],Q[nominal][:2]) for k in (gauge,opposite,off)), 'The four probes do not share exact lambda and mean shear')
        R(np.array_equal(T[nominal],T[gauge]),'Gauge-only probe changed material state')
        step=peak(T[off][:,:,:6]-T[nominal][:,:,:6]); opposite_step=peak(T[opposite][:,:,:6]-T[nominal][:,:,:6]);
        R(0.97e-13<step<1.03e-13 and 0.97e-13<opposite_step<1.03e-13,'Native field is not the intended mechanical step')
        R(peak(T[off][:,:,:6]+T[opposite][:,:,:6]-2*T[nominal][:,:,:6])<3e-17,'Directions are not exact opposites within serialization')
        result[str(h)]={}
        for name in NAMES:
            tag=stem+'/'+name; probe=tag+'/Probe'; trial=tag+'/Solved'; state=A[probe]; tau=float(state[3]);
            q=Q[probe]; solved,exact=map(int,outcomes[tag]); e=expected['mechanics'][name]
            R(peak(q[2:]-np.array(e['q']))<3e-16 and abs(q[0]-e['lambda'])<1e-14 and abs(q[1]-expected['gamma'])<1e-16,'Native q/λ/γ not signed fixture')
            details=snapshot(probe,state,q,T[probe],proj)
            rows=O['independent'](native,probe)
            equality=np.r_[25600*O['section'].gauges@q[2:81],25600*(proj@q[2:]-q[1])]
            R(len(rows)==89 and len(equality)==5 and peak(equality)<4e-12,'Missing 89 residuals or 5 compatibility equations')
            pe=np.asarray(e['histories'][str(h)]['rowEnvelope_MPa']);
            err=max(0.,float(np.max(pe[:,0]-rows)),float(np.max(rows-pe[:,1])))
            details.update(rows_MPa=rows.tolist(),controls_MPa=equality.tolist(),tau_MPa=tau,
                   reserve_MPa=tau-peak(rows),actual_outside_derivative_family_envelope_by_MPa=err,
                   peakMaterialStrainChange=peak(T[probe][:,:,:6]-T[nominal][:,:,:6]),solved=bool(solved),exact=bool(exact))
            if name in NAMES[:2]:
                residual=O['warp'](rows)
                floor=residual['best_MPa']
                R(floor>tau+5e-10 and not solved and not exact,'Gauge-only comparator not excluded by fixed-physics pair')
                details.update(exactWarpOnlyMinimax_MPa=floor,activeRows46and70_MPa=rows[[45,69]].tolist())
            if name==NAMES[-1]:
                # A failed or changed-field trial is a measured outcome, never a claim of collapse.
                margin.append(tau-peak(rows))
                if solved:
                    R(trial in Q and tag in diagnostics,'Missing resulting field')
                    after=snapshot(trial,A[trial],Q[trial],T[trial],proj)
                    if exact:
                        R(np.array_equal(Q[probe],Q[trial]) and np.array_equal(T[probe],T[trial])
                            and after['complete_norm_MPa']<=tau and diagnostics[tag][0].startswith('Итерации: 0|'),
                            'Solver admitted a changed or out-of-tolerance field')
                    details.update(after=after,diagnostic=diagnostics[tag][0])
            result[str(h)][name]=details
    commit=None
    off=result['43'][NAMES[-1]]
    R(choice==(4 if off['exact'] and off['reserve_MPa']>0 else 0),'Incorrect native witness selection')
    if choice:
        tag='History43/Committed'; prior='History43/'+NAMES[-1]+'/Solved';
        R(np.array_equal(Q[tag],Q[prior]) and np.array_equal(T[tag],T[prior]),'Commit differs from exact trial')
        R(len(adjoints[tag])==2 and adjoints[tag][0]=='1' and float(adjoints[tag][1])>0.,'Missing multiplier uncertainty')
        commit={'lambda_uncertainty':float(adjoints[tag][1]),**snapshot(tag,A[tag],Q[tag],T[tag],proj)}
    R(np.array_equal(Q['History43/Base'],Q['History43/Restore']) and np.array_equal(T['History43/Base'],T['History43/Restore']), 'Final rollback changed history')
    answer={'outcome':'EXACT_ACCEPTED' if commit else 'MEASURED_NO_ACCEPTANCE','tests':result,'commit':commit,
        'note':'Local witness at fixed Qy and controlled strain. Neither limiting strength nor global convergence is established.',
        'workbook':frozen['workbook_sha256'],'trace_sha256s':{x.name:h for x,h in hashes},'reportSHA256':sha(report)}
    dest=HERE/'Verification.json'; dest.write_text(json.dumps(answer,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf8')
    print(dest,sha(dest),answer['outcome'],margin)

if __name__=='__main__': verify()
