"""Freeze the current production sources and a private two-history witness."""
from argparse import ArgumentParser
import json
from pathlib import Path
import runpy

HERE=Path(__file__).resolve().parent
PRE=HERE.parent/'KaniWarpBeyond43'
P=runpy.run_path(PRE/'Prepare-Beyond43.py')
BOOK,SHADOW,SOLVER,ELASTIC,MODULE,CAPTURED=(P[key] for key in ('BOOK','SHADOW','SOLVER','ELASTIC','MODULE','CAPTURED'))
digest,one=P['digest'],P['one']
BOOK_SHA='A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A'
FROZEN_SOURCES={SOLVER:'9E33A100858D4181123244A0A54F98DF23258B9ABD87CF0E6293C122E371176F',
    ELASTIC:'A6BF256F42610AE7A353AD4AE1CCC9275DC247B398C3FA429CACD83840C97F94'}
CANDIDATE_SHA='1B2822E24E6A504D9D227132B40EEDD052DFF6DDB282F573B677DDDD1FCBFEDB'
PREDICTION_SHA='0AE780C70563B619A9C69DF4FE9A1849E4069A288248297010B6B9B02B66521E'

def prep(repo):
    assert not (HERE/'Preparation.json').exists(), 'Prepare in a fresh directory once'
    assert digest(repo/BOOK)==BOOK_SHA
    assert all(digest(repo/p)==h for p,h in FROZEN_SOURCES.items())
    past=P['check']()
    assert all(past['production_source_sha256'][k.as_posix()]==v for k,v in FROZEN_SOURCES.items())
    assert digest(HERE/'Mechanics44.csv')==CANDIDATE_SHA and digest(HERE/'Prediction.json')==PREDICTION_SHA
    fixture=(PRE/MODULE).read_text(encoding='utf8')
    begin=fixture.index('    Dim rootPath As String')
    end=fixture.index('    Close #tangents:',begin)
    fixture=fixture[:begin]+(HERE/'MechanicsMain.bas.txt').read_text(encoding='utf8').rstrip()+'\n'+fixture[end:]
    fixture=fixture[:fixture.index("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Ограничивает допуск к фиксации полем")]
    fixture+=(HERE/'MechanicsHelper.bas.txt').read_text(encoding='utf8').rstrip()+'\n'
    runner=(PRE/'Run-Beyond43.ps1').read_text(encoding='utf-8-sig')
    for old,new in (('Prepare-Beyond43.py','Prepare-Mechanics44.py'),('Verify-Beyond43.py','Verify-Mechanics44.py'),
                    ('# Отдельная проверка Kani 37→38 в замороженной книге V4.','# Изолированная проверка механического поля Kani на отметке 19/512.'),
                    ('Независимая сверка Kani 37→38 не пройдена.','Независимая сверка механического поля Kani не пройдена.')):
        runner=one(runner,old,new)
    history=[line for line in (PRE/'KaniGaugeInput.csv').read_text(encoding='ascii').splitlines() if line.startswith('KANI_B_FIELD;History')]
    assert len(history)==6 and history[-1].startswith('KANI_B_FIELD;History43;')
    trial=(HERE/'Mechanics44.csv').read_text(encoding='ascii').splitlines()
    assert len(trial)==4 and len({x.split(';')[91] for x in trial})==len({x.split(';')[3] for x in trial})==1
    assert all(len(line.split(';'))==92 for line in history+trial)
    (HERE/'Native').mkdir(exist_ok=True); (HERE/'Temp').mkdir(exist_ok=True)
    files={MODULE:fixture.encode('utf8'),Path('Run-Mechanics44.ps1'):runner.encode('utf-8-sig'),
           Path('KaniGaugeInput.csv'):('\r\n'.join(history+trial)+'\r\n').encode('ascii')}
    copies={Path(k):PRE/k for k in past['frozen'] if k.startswith('tools/') or k in
            ('KaniV4Input.csv','KaniChartInput.csv',SOLVER.as_posix(),ELASTIC.as_posix(),CAPTURED.as_posix())}
    copies[BOOK]=repo/BOOK; copies[SHADOW]=repo/BOOK
    for path,source in copies.items(): files[path]=source.read_bytes()
    for relative,payload in files.items():
        path=HERE/relative
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(payload)
    # The shadow will be compiled, while its identical source remains sealed.
    frozen_names=(set(files)-{SHADOW})|{Path(k) for k in ('MechanicsMain.bas.txt','MechanicsHelper.bas.txt','Mechanics44.csv',
                    'Prediction.json','LPResults.json','Solve.py','FreezeCandidate.py','Prepare-Mechanics44.py','Verify-Mechanics44.py')}
    info={'workbook_sha256':BOOK_SHA,'production_source_sha256':{k.as_posix():v for k,v in FROZEN_SOURCES.items()},
          'frozen':{k.as_posix():digest(HERE/k) for k in sorted(frozen_names)}}
    (HERE/'Preparation.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf8')
    return check()

def check():
    info=json.loads((HERE/'Preparation.json').read_text(encoding='utf8'))
    assert info['workbook_sha256']==BOOK_SHA and digest(HERE/BOOK)==BOOK_SHA
    assert all(digest(HERE/k)==v for k,v in info['frozen'].items())
    assert all(info['production_source_sha256'][k.as_posix()]==v for k,v in FROZEN_SOURCES.items())
    assert digest(HERE/CAPTURED)==FROZEN_SOURCES[SOLVER] and digest(HERE/ELASTIC)==FROZEN_SOURCES[ELASTIC]
    production=(HERE/CAPTURED).read_text(encoding='utf8'); warp=P['P']
    assert (HERE/SOLVER).read_text(encoding='utf8')==production+warp['MARK']+warp['wrapper'](production)+'\n'
    assert info['frozen']['Mechanics44.csv']==CANDIDATE_SHA and info['frozen']['Prediction.json']==PREDICTION_SHA
    return info

if __name__=='__main__':
    ap=ArgumentParser(); ap.add_argument('--repo',type=Path); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    print((check() if a.check else prep(a.repo))['workbook_sha256'],digest(HERE/'Preparation.json'))
