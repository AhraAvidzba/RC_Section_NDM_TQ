"""Проверяет сохранённую диагностику двух рабочих модулей без Excel."""

import argparse
from decimal import Decimal
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import re
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from Verify import CASES, decimal, hash_bytes, hash_file, read


HERE = Path(__file__).resolve().parent
MODULE = "xl/vbaProject.bin"
SPECIAL = re.compile(r"(?:^_xmlsignatures/|vbaprojectsignature)", re.I)
NS = {"c": "http://schemas.openxmlformats.org/drawingml/2006/chart"}


def parts(path):
    with ZipFile(path) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(set(names))
        assert not any(SPECIAL.search(name) for name in names)
        return [
            {"member": p.filename, "sha256": hash_bytes(z.read(p)), "length": p.file_size, "crc32": p.CRC}
            for p in z.infolist()
        ]


def export_source(fixture, package):
    spec = spec_from_file_location("vbe", HERE / "Verify-ExportDifference.py")
    vbe = module_from_spec(spec)
    spec.loader.exec_module(vbe)
    baseline = vbe.modules(HERE / "Baseline/VBA_All_Code.txt")
    actual = vbe.modules(HERE / "Exported/VBA_All_Code.txt")
    canon = lambda lines: [vbe.code_case(line) for line in "\n".join(lines).rstrip().splitlines()]
    assert baseline.keys() == actual.keys()
    assert all(baseline[name][0] == actual[name][0] for name in actual)
    changed = {name for name in actual if canon(baseline[name][1]) != canon(actual[name][1])}
    assert changed == set(fixture["import_modules"])
    proof = read("SourceAgreement.json")
    assert proof["status"] == "PASS"
    assert proof["actual_components"] == len(actual) == 225 and proof["unchanged_components"] == 223
    assert set(proof["changed_components"]) == changed
    production = read("Production.json")
    decimal_tokens = re.compile(r'''"(?:""|[^"])*"|'[^\n]*|(?<![\w.])(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?[#%!&@^]?(?![\w.])''')

    def numbers(line):
        def convert(token):
            value = token[0]
            if value.startswith(('"', "'")):
                return value
            suffix = value[-1] if value[-1] in "#%!&@^" else ""
            integral = value[:-1] if suffix else value
            return str(Decimal(integral).normalize()) + suffix
        return decimal_tokens.sub(convert, line)

    def runtime(path):
        text = path.read_text(encoding="utf-8-sig")
        return canon(re.search(r"^Option Explicit.*", text, re.M | re.S)[0].splitlines())

    for name, pin in production["production"].items():
        key = Path(name).stem
        source = HERE / name
        assert hash_file(source) == pin == proof["changed_components"][key]["source_sha256"]
        old_src = runtime(HERE / "Baseline" / name)
        old_vbe = canon(baseline[key][1])
        common = set(zip(old_src, old_vbe, strict=True))
        same_lines = []
        equivalent_decimals = []
        new_src = runtime(source)
        for i, (a, b) in enumerate(zip(new_src, canon(actual[key][1]), strict=True), start=1):
            if a == b:
                continue
            if (a, b) in common:
                same_lines.append(i)
            else:
                assert numbers(a) == numbers(b), (key, i, a, b)
                equivalent_decimals.append(i)
        assert proof["changed_components"][key] == {"lines": len(new_src), "matches_existing_vbe_line": same_lines,
                    "equal_decimal_spelling": equivalent_decimals, "source_sha256": pin}
    export_log = (HERE / "Export.log").read_text(encoding="utf-8-sig")
    assert f"components=225; sourceSHA256={package['candidate_sha256']}; sourceUnchanged=True;" in export_log


def series(chart):
    root = ET.fromstring(chart)
    result = {}
    for entry in root.findall(".//c:ser", NS):
        title = entry.findtext("./c:tx//c:v", namespaces=NS)
        result[title] = tuple([float(point.findtext("./c:v", namespaces=NS)) for point in entry.findall(f"./c:{axis}//c:pt", NS)]
                              for axis in ("xVal", "yVal"))
    return result


def native(case, package, chart, optional_book):
    tag, passed = CASES[case]
    log_path = HERE / f"Native/{case}.txt"
    owner = read(f"Native/{case}.txt.Ownership.json")
    receipt = read(f"Native/{case}.txt.ProcessClosure.json")
    ending = receipt["Closure"]["FinalState"]
    proof = read(f"Native/{case}.Verification.json")
    assert receipt["Passed"] and receipt["ChildExitCode"] == 0 and ending["State"] == "Absent"
    assert (owner["PID"], owner["StartTicksUTC"]) == (ending["PID"], ending["StartTicksUTC"])
    assert owner["SourceSHA256"] == proof["workbook_sha256"] == package["candidate_sha256"]
    assert proof["native_report_sha256"] == hash_file(log_path) and proof["assertions"] == passed
    log = log_path.read_text(encoding="utf-8-sig")
    assert f"TOTAL_COUPLED_{tag}: passed={passed}; failed=0" in log
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    if case in ("Both","Direct"):
        exact = chart[case]
        assert proof["reopened_workbook_sha256"] == exact["workbook_sha256"]
        reopened = proof["results_reopened_sha256"]
        assert f"RESULTS_SAVE_REOPEN: before={reopened}; after={reopened}; equal=True" in log
        xml = (HERE/exact["xml"]).read_bytes()
        assert hash_bytes(xml) == exact["xml_sha256"]
        if optional_book:
            assert hash_file(optional_book) == exact["workbook_sha256"]
            with ZipFile(optional_book) as zz:
                assert zz.read(exact["member"]) == xml
        results = series(xml)
        assert results["Заданная точка"][1] == [1.]
        matches = re.findall(r"^OK: direct (\S+) actual=(\S+) expected=(\S+)$",log,re.M)
        assert [n for n, _, _ in matches] == ["N","Mx","My","T","Qx","Qy"]
        assert all(abs(decimal(a)-decimal(b)) < Decimal("1e-8") for _,a,b in matches)
        if case == "Both":
            x, y = results["Поиск предела"]
            assert x == list(range(1, len(y)+1))
            assert results["Последняя точка поиска"] == ([x[-1]], [y[-1]])
            assert abs(max(y) - float(proof["confirmed_lower_lambda"])) < 1e-12
            assert "TIMING_STATES: direct=OK; capacity=NumFail;" in log
            assert all(f"OK: no unconfirmed limit component {name}\n" in log for name,_,_ in matches)
        else:
            assert "Поиск предела" not in results and proof["seconds"] <= 10.
    if case == "HoopCapacity":
        for store in ("Excel","File"):
            assert f"OK: {store} documents the same governing point and FAIL in the structured properties" in log
            assert proof[f"{store}_governing_hoop_lambda"] == "1.20004272460938"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-workbook", type=Path)
    parser.add_argument("--candidate-workbook", type=Path)
    parser.add_argument("--both-reopened", type=Path)
    parser.add_argument("--direct-reopened", type=Path)
    args = parser.parse_args()
    hashes = read("SHA256SUMS.json")
    files = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file() and p.name != "SHA256SUMS.json"}
    assert files == set(hashes) and all(hash_file(HERE/name) == value for name,value in hashes.items())
    config, package, zip_parts = [read(name) for name in ("Fixture.json","PackageChecks.json","ZipParts.json")]
    for name, expected in config["inputs"].items():
        assert hashes[name] == expected
    proof = read("Production.json")
    assert all(hashes[f"Baseline/{name}"] == pin for name,pin in proof["base"].items())
    assert hashes["Production.json"] == config["production_definition_sha256"]
    for label, path in (("base", args.base_workbook), ("candidate", args.candidate_workbook)):
        if path:
            assert hash_file(path) == package[f"{label}_sha256"] and parts(path) == zip_parts[label]
    assert len(zip_parts["base"]) == len(zip_parts["candidate"]) == 122
    assert all(a["member"]==b["member"] for a,b in zip(zip_parts["base"],zip_parts["candidate"],strict=True))
    assert [a["member"] for a,b in zip(zip_parts["base"],zip_parts["candidate"],strict=True) if a != b] == [MODULE]
    assert package["unchanged_package_parts"] == 121
    assert package["vba_sha256"] == next(item["sha256"] for item in zip_parts["candidate"] if item["member"]==MODULE)
    assert not any(SPECIAL.search(member["member"]) for member in zip_parts["candidate"])
    update = read("docs/regression/CodeUpdate.json")
    assert update["Compiled"] and not update["ProductionChanged"] and update["ProductionSHA256"] == package["base_sha256"]
    assert sorted(update["Modules"]) == config["import_modules"] and update["WorkbookSHA256"] == package["compiled_sha256"]
    for label in ("Compile","Export"):
        receipt = read(f"{label}Closure.json")
        assert receipt["State"] == "Absent"
        assert f"OWNED_EXCEL: id={receipt['PID']}; utcStartTicks={receipt['StartTicksUTC']}" in (HERE/f"{label}.log").read_text(encoding="utf-8-sig")
    export_source(config, package)
    chart = read("SavedCharts.json")
    for case in CASES:
        optional = {"Both": args.both_reopened, "Direct": args.direct_reopened}.get(case)
        native(case, package, chart, optional)
    print("HARDSHEAR V1 WORKBOOK SMOKE PORTABLE VERIFIED")


if __name__ == "__main__":
    main()
