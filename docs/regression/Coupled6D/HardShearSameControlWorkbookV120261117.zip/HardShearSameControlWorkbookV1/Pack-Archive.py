"""Упаковывает штатную проверку первой версии двух рабочих модулей."""

import json
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import re
from subprocess import check_call, check_output
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from Verify import hash_file, hash_bytes, inputs, read

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
PREFIX = "HardShearSameControlWorkbookV1"
TARGET = HERE / f"{PREFIX}20261117.zip"
REVISION = "c9e7268fe8b7c3c40edca958d137eb0531a53c19"
BASE_BOOK = "workbook/output/RC_Section_NDM.xlsm"
BASE_EXPORT = "workbook/output/VBA_All_Code.txt"
PACKAGED = "docs/regression/Audit03/RC_Section_NDM.xlsm"


def serialize(data):
    return (json.dumps(data, ensure_ascii=False, indent=2)+"\n").encode()


def main():
    spec = spec_from_file_location("archived_validation", HERE/"Verify-Archive.py")
    checker = module_from_spec(spec)
    spec.loader.exec_module(checker)
    fixture, package, production = [read(name) for name in ("Fixture.json","PackageChecks.json","Production.json")]
    inputs(fixture)
    source = check_output(["git", "show", f"{REVISION}:{BASE_BOOK}"], cwd=REPO)
    assert hash_bytes(source) == package["base_sha256"] == hash_file(HERE/BASE_BOOK)
    assert hash_file(HERE/PACKAGED) == package["candidate_sha256"]
    paths = {*fixture["inputs"], "Fixture.json","Compile.log","CompileClosure.json","Export.log","ExportClosure.json",
             "Run.ndjson","Run-Packaged.ps1","VerifyPackaged.py","Package.py","PackageChecks.json","SourceAgreement.json",
             "Verify-ExportDifference.py","Verify-SourceAgreement.py","Verify-Archive.py","Pack-Archive.py","README-Archive.md",
             "docs/regression/CodeUpdate.json"}
    paths.update(p.relative_to(HERE).as_posix() for p in (HERE/"Native").iterdir() if p.is_file() and p.suffix.lower() != ".xlsm")
    data = {path: (HERE/path).read_bytes() for path in paths}
    for name, expected in production["base"].items():
        raw = check_output(["git", "show", f"{REVISION}:{name}"], cwd=REPO)
        assert hash_bytes(raw) == expected
        data[f"Baseline/{name}"] = raw
    before_export = check_output(["git", "show", f"{REVISION}:{BASE_EXPORT}"], cwd=REPO)
    assert hash_bytes(before_export) == hash_file(REPO/BASE_EXPORT)
    data["Baseline/VBA_All_Code.txt"] = before_export
    data["Exported/VBA_All_Code.txt"] = (HERE/"docs/regression/Audit03/VBA_All_Code.txt").read_bytes()
    data["ZipParts.json"] = serialize({"base": checker.parts(HERE/BASE_BOOK), "candidate": checker.parts(HERE/PACKAGED)})
    saved = {}
    optional = {}
    for label in ("Both","Direct"):
        report = HERE/f"Native/{label}.txt"
        log = report.read_text(encoding="utf-8-sig")
        match = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", log, re.M)
        assert match
        workbook = Path(match[2]).resolve(strict=True)
        assert workbook.is_relative_to(HERE/"Temp")
        optional[label] = workbook
        with ZipFile(workbook) as package_file:
            pairs = [(name, package_file.read(name)) for name in package_file.namelist() if re.fullmatch(r"xl/charts/chart\d+\.xml", name)]
        choices = [(name, xml) for name, xml in pairs if "Заданная точка" in checker.series(xml)]
        name, xml = choices[0]
        assert len(choices) == 1
        local = f"Native/{label}.SavedChart.xml"
        data[local] = xml
        saved[label] = {"workbook_sha256": hash_file(workbook), "member": name,
                        "xml_sha256": hash_bytes(xml), "xml": local, "reopen_sha256": match[1]}
    data["SavedCharts.json"] = serialize(saved)
    data["Audit.json"] = serialize({"baseline_git_revision": REVISION, "baseline_workbook_sha256": package["base_sha256"],
                                    "baseline_export_sha256": hash_bytes(before_export), "export_sha256": hash_bytes(data["Exported/VBA_All_Code.txt"])})
    data["SHA256SUMS.json"] = serialize({name: hash_bytes(value) for name,value in sorted(data.items())})
    with TemporaryDirectory(prefix="hsr-smoke-proof-", dir=HERE) as directory:
        scratch = Path(directory)
        archive = scratch/TARGET.name
        with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=9) as bundle:
            for name, raw in sorted(data.items()):
                entry = ZipInfo(f"{PREFIX}/{name}", date_time=(2026, 11, 17, 0, 0, 0))
                bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(archive) as bundle:
            assert bundle.testzip() is None and not any(name.lower().endswith(".xlsm") for name in bundle.namelist())
            bundle.extractall(scratch/"detached")
        command = [sys.executable, "-B", "-X", "utf8", "Verify-Archive.py"]
        cwd = scratch/"detached"/PREFIX
        check_call(command, cwd=cwd)
        check_call([*command, "--base-workbook", str(HERE/BASE_BOOK), "--candidate-workbook", str(HERE/PACKAGED),
                    "--both-reopened", str(optional["Both"]), "--direct-reopened", str(optional["Direct"])], cwd=cwd)
        TARGET.write_bytes(archive.read_bytes())
    sha = hash_file(TARGET)
    TARGET.with_suffix(".zip.sha256").write_bytes(f"{sha}  {TARGET.name}\n".encode("ascii"))
    print("PORTABLE HARDSHEAR V1 WORKBOOK", sha, TARGET.stat().st_size)


if __name__ == "__main__":
    main()
