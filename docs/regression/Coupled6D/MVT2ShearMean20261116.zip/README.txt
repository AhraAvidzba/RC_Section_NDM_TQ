MVT2 B native deformation control along the mean engineering shear gamma_yz from the fixed 24-field history of section 299. The stock workbook A0563 is the calculation base. The workbook derivative imports only the test module. The loads hold T=10.51 kN m and Mx=0.6 Qy kN m, with N, My and Qx all zero. The diagnostic compares standard and consistent linearization at positive target increments of 1/64 and 1/128 of the accepted secant. It repeats the current target as a zero anchor. A reverse 1/128 target is optional if the paired run has already exceeded the 50 s in-macro window. Tests preserve the material history, field and all original guard thresholds. A candidate may pass the probe gate while remaining uncommitted.

Offline independent reconstruction and audit of the native trace:

    python Verify-MVT2ShearControlled.py --offline

This requires Python 3.10+ and no Office. It verifies all native projection coefficients against the Bernstein formula, reconstructs actual signed six effort components and steel utilization from central point stress and strain, checks the original acceptance guards, and proves exact field and central-tensor rollbacks. The build attestation, process ownership and closure receipts link the derivative to workbook A0563; the private derivative XLSM is omitted.

The auxiliary projection explanation and verification are in projection/. Replay the earlier archives' independent projection reconstruction from the archive extraction directory:

    python projection/Verify-MVT2MeanShear.py PATH_TO_EVIDENCE_ZIP_DIRECTORY projection/Verification.json

Sibling evidence used by this optional replay (both in docs/regression/Coupled6D): MVT2ShearRaw20261116.zip and MVT2ShearBracket20261116.zip. The native mean-shear audit above is self-contained.
