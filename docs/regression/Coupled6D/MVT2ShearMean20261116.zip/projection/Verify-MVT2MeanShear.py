"""Reconstruct the stock mean engineering shear axis for MVT2 B from 25 Gauss-cell midpoints."""
from collections import defaultdict
from hashlib import sha256
import json
import math
from pathlib import Path
import sys
from zipfile import ZipFile

INPUTS = {
    "exact_pair": (
        "MVT2ShearRaw20261116.zip",
        "6E51126D79B633FBD61D1C7A2CB3EE3FD8A5E31413695E17B3F28CED6329772D",
    ),
    "local_bracket": (
        "MVT2ShearBracket20261116.zip",
        "505C3BD1C45F9C1989B965224177594388063CC47B9DAC5EA934DC9B2AB4D1FA",
    ),
}


def average_projection():
    length = math.hypot(110., 110.)
    basis, derivatives = [], []
    for coordinate in (-96., -48., 0., 48., 96.):
        t = (coordinate + 120.) / 240.
        s = 1. - t
        basis.append((s**3, 3*s*s*t, 3*s*t*t, t**3))
        derivative = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
        derivatives.append(tuple(3*value*length/240 for value in derivative))
    shape = tuple(math.fsum(column)/5 for column in zip(*basis, strict=True))
    gradient = tuple(math.fsum(column)/5 for column in zip(*derivatives, strict=True))
    # q4*x/L vanishes on the symmetric grid. q7 is the first w degree.
    return {7 + 3*(4*j + i): gradient[j]*shape[i] for j in range(4) for i in range(4)}


def mean_shear(field, projection):
    return math.fsum(coefficient*field[degree-1] for degree, coefficient in projection.items())


def load_states(folder, projection):
    traces = {}
    for name, (archive, expected_sha) in INPUTS.items():
        with ZipFile(folder / archive) as evidence:
            stream = evidence.read("Native/MVT2.csv")
        identity = sha256(stream).hexdigest().upper()
        assert identity == expected_sha
        fields, central = {}, defaultdict(list)
        for line in stream.decode("cp1251").splitlines():
            tag, label, *values = line.split(";")
            if tag == "MVT2_CONTROL_FIELD":
                assert label not in fields and len(values) == 60
                fields[label] = tuple(map(float, values))
            elif tag == "B_CONTROL_STATION" and int(values[0]) <= 25:
                central[label].append((float(values[3]), float(values[9])))
        errors = []
        for label, values in central.items():
            assert len(values) == 25
            native = math.fsum(area*value for area, value in values) / math.fsum(area for area, _ in values)
            errors.append(abs(native - mean_shear(fields[label], projection)))
        assert max(errors) < 1e-15
        traces[name] = (identity, len(errors), max(errors), fields)
    return traces


def evaluate(folder):
    projection = average_projection()
    traces = load_states(folder, projection)
    fields = traces["exact_pair"][3]
    preceding, base = (mean_shear(fields[f"Replay{i}"], projection) for i in (23, 24))
    increment = base - preceding
    q_prev, q_base = 17.6685825, 18.55811
    step = increment / 64
    levels = [0, -1, -.5, .25, .5, 1]
    probes = {str(level): {"mean_gamma_yz": base + level*step,
                          "initial_Qy_kN": q_base + level*(q_base-q_prev)/64} for level in levels}
    states = {label: fields[label] for label in ("Replay22", "Replay23", "Replay24", "TwistNative/Raw", "TwistConsistent/Raw")}
    states["BracketWarmHalfRaw"] = traces["local_bracket"][3]["Warm/.5/Raw"]
    comparisons = {}
    for label, field in states.items():
        gamma = mean_shear(field, projection)
        comparisons[label] = {"mean_gamma_yz": gamma, "delta_gamma_yz": gamma-base, "q4": field[3]}
    positive_raw = comparisons["TwistConsistent/Raw"]["delta_gamma_yz"]
    wrong_sign = comparisons["BracketWarmHalfRaw"]["delta_gamma_yz"]
    assert 2*step < positive_raw < 3*step and wrong_sign < 0.
    return {"projection_index_1_based": projection, "mean_gamma_yz_base": base,
            "latest_accepted_mean_gamma_increment": increment, "states":comparisons, "control_targets": probes,
            "native_checks": {name: {"sha256": identity, "states_compared": n, "max_difference": error}
                              for name, (identity, n, error, _) in traces.items()}}


if __name__ == "__main__":
    assert len(sys.argv) == 3, "Usage: python Verify-MVT2MeanShear.py <directory with both evidence ZIPs> <output json>"
    path = Path(sys.argv[2])
    path.write_text(json.dumps(evaluate(Path(sys.argv[1])), indent=2)+"\n", encoding="utf-8")
    print(path, sha256(path.read_bytes()).hexdigest().upper())
