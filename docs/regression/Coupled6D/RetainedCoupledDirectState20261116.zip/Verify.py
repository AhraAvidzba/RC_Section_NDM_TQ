"""Verify the independent receipts for the retained equilibrium and storage checks."""

from decimal import Decimal as D
from hashlib import sha256
import json
from pathlib import Path
import sys


check, report=sys.argv[1:]
path=Path(report)
raw=path.read_text(encoding='utf-8-sig')
assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in raw
if check=='Equilibrium':
    assert 'TOTAL_DIRECT_STEEL_VERIFICATION: passed=36; failed=0' in raw
    lines=[line.split(';') for line in raw.splitlines()]
    contacts=[row for row in lines if row[0]=='DIRECT_CONTACT']
    resolved=[row for row in lines if row[0]=='DIRECT_RESOLVED']
    assert len(contacts)==3 and all(row[3]=='1' for row in contacts)
    assert D(contacts[0][1])<0==D(contacts[1][1])<D(contacts[2][1])
    assert all(abs(D(row[2])-D(415920))<D('.00001') for row in contacts)
    assert len(resolved)==2 and D(resolved[0][2])<1<D(resolved[1][2])
    assert abs(D(resolved[1][3]))<D('1e-9')
    proof={'contacts':contacts,'resolved':resolved}
else:
    assert 'TOTAL_COUPLED_RETAINED_SNAPSHOT: passed=34; failed=0' in raw
    assert f'OK: {check} saves actual element stresses and strains' in raw
    assert f'OK: {check} export reads the saved field and reports the steel uncertainty' in raw
    proof={'storage':check,'exact_fields':True,'reopened':True}
proof['report_sha256']=sha256(path.read_bytes()).hexdigest().upper()
path.with_suffix('.Verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,indent=2))
