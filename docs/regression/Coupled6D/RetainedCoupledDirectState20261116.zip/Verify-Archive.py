"""Reproduce retained-equilibrium/Results evidence without an Excel workbook."""

import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory


HERE=Path(__file__).resolve().parent
TEST='tests/modTestCoupledElasticState.bas'
NATIVE={'Equilibrium':'96AF251D46F11CC43672B769D705E904BAEFC84EB00A26284D1855FAB313B0D2',
        'Excel':'C8B46211994E78B6CE1F13A3BACC7DAFCAAAEB9538F57BA6836196D2AFD71506',
        'File':'B3ABE6688CD1C896A16A87831DB4B64511A3D54015FEAAAEB0EE2CBDCCAAA6B5'}
FIXTURES={'Equilibrium':'E1C87014AA5A7056033AAC70F068D6A53173507FEE387AF7C1ACEA6E89955202',
          'Snapshot':'511490464CBC79EBD0BB9F1D0382982E0F362650E2A6D610DBE2ED9D7A468376'}


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def file_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def load_composer(path,name):
    spec=spec_from_file_location(name,path)
    module=module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def from_repo(repo,name):
    return check_output(['git','show',f'abcfa53:{name}'],cwd=repo)


def source_text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def native_text(text):
    return text.replace('\n','\r\n').encode('utf-8')


def previous_sources(repo):
    if repo is None:
        return {}
    c=load_composer(HERE/'Base/Compose.py','base_steel')
    changes={'CCoupledLoadContinuation.cls':c.continuation,'CCoupledSectionAnalysis.cls':c.section,
             'CCoupledNewtonSolver.cls':c.newton,'CCoupledElasticState.cls':lambda s:c.append(s,'Projection.txt'),
             'CCoupledReinforcedResponse.cls':lambda s:c.append(s,'Steel.txt'),
             'modTestCoupledElasticState.bas':lambda s:c.append(s,'Test.txt')}
    results={}
    baseline=file_json(HERE/'Base/SourceManifest.json')
    assert baseline['base']=='abcfa53'
    for name, expected in baseline['changes'].items():
        raw=from_repo(repo,name)
        assert sha256(raw).hexdigest().upper()==expected['base_sha256']
        results[name]=native_text(changes[Path(name).name](source_text(raw)))
        assert sha256(results[name]).hexdigest().upper()==expected['private_sha256']
    return results


def verify_sources(layer,fixture,repo,previous):
    c=load_composer(HERE/'Compose.py','retained_steel')
    changes={'CBatchSectionCalculator.cls':c.batch,'CSectionStateResult.cls':c.state,'modResultStatus.bas':c.status,
             'CCoupledReinforcedResponse.cls':c.reinforcement,'CCoupledElasticState.cls':lambda s:s,
             'CCoupledLoadContinuation.cls':c.continuation,'CCoupledNewtonSolver.cls':c.newton,
             'CCoupledSectionAnalysis.cls':c.section,'modTestCoupledElasticState.bas':c.tests}
    if layer=='Snapshot':
        changes.update((Path(name).name,modify) for name,modify in c.snapshot_changes().items())
    base_manifest=file_json(HERE/'Base/SourceManifest.json')['changes']
    manifest=file_json(HERE/layer/'SourceManifest.json')
    assert manifest['layer']==layer
    for name,expected in manifest['changes'].items():
        assert expected['candidate_sha256']==fixture['frozen'][name]
        if name in base_manifest:
            assert expected['base_sha256']==base_manifest[name]['private_sha256']
        if repo is None:
            continue
        original=previous[name] if name in previous else from_repo(repo,name)
        assert sha256(original).hexdigest().upper()==expected['base_sha256']
        text=changes[Path(name).name](source_text(original))
        if layer=='Snapshot' and name==TEST:
            text=text.rstrip()+'\n\n'+(HERE/'SnapshotTest.txt').read_text(encoding='utf-8')
        assert sha256(native_text(text)).hexdigest().upper()==expected['candidate_sha256']


def verify_compiler(lane,fixture):
    code=file_json(lane/'docs/regression/CodeUpdate.json')
    closure=file_json(lane/'CompileClosure.json')
    log=(lane/'Compile.log').read_text(encoding='utf-8-sig')
    owned=re.search(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',log,re.M)
    assert closure['State']=='Absent' and owned
    assert (closure['PID'],closure['StartTicksUTC'])==(int(owned[1]),owned[2])
    assert code['Compiled'] and not code['ProductionChanged'] and code['ProductionSHA256']==fixture['workbook_sha256']
    assert sorted(code['Modules'])==fixture['modules'] and code['RetiredModules']==[]
    return code['WorkbookSHA256'],closure['PID']


def verify_report(lane,check,compiled_hash):
    report=lane/f'Native/{check}.txt'
    assert digest(report)==NATIVE[check]
    native=report.read_text(encoding='utf-8-sig')
    assert f'SOURCE_SHA256: {compiled_hash}' in native
    owner=file_json(report.with_suffix('.txt.Ownership.json'))
    closure=file_json(report.with_suffix('.txt.ProcessClosure.json'))
    state=closure['Closure']['FinalState']
    assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode']==0
    assert closure['RunnerCleanupValid'] and not closure['OrdinaryPathKilledAnything']
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256']==compiled_hash
    assert state['State']=='Absent' and (state['PID'],state['StartTicksUTC'])==(owner['PID'],owner['StartTicksUTC'])
    with TemporaryDirectory() as folder:
        output=Path(folder)/report.name
        copyfile(report,output)
        check_output([sys.executable,'-B','-X','utf8',str(HERE/'Verify.py'),check,str(output)])
        assert output.with_suffix('.Verification.json').read_bytes()==report.with_suffix('.Verification.json').read_bytes()
    print(check,NATIVE[check])
    return owner['PID']


def main(repo):
    all_hashes=file_json(HERE/'SHA256SUMS.json')
    assert all(digest(HERE/name)==value for name,value in all_hashes.items())
    baseline=previous_sources(repo)
    process_ids=[]
    for layer,checks in (('Equilibrium',('Equilibrium',)),('Snapshot',('Excel','File'))):
        lane=HERE/layer
        assert digest(lane/'Fixture.json')==FIXTURES[layer]
        fixture=file_json(lane/'Fixture.json')
        verify_sources(layer,fixture,repo,baseline)
        compiled_hash,owner=verify_compiler(lane,fixture)
        process_ids.append(owner)
        for check in checks:
            process_ids.append(verify_report(lane,check,compiled_hash))
    assert len(set(process_ids))==len(process_ids)
    print('RETAINED DIRECT EQUILIBRIUM AND SNAPSHOT EVIDENCE PASS')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path)
    main(parser.parse_args().repo)
