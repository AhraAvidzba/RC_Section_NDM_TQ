"""Compose the accepted-equilibrium and separate-steel-status layers."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
PREVIOUS=HERE.parent/'dsc2'
BASE='abcfa53'


def replace(text,old,new):
    if text.count(old)!=1:
        raise ValueError(f'Unexpected VBA anchor {old!r}')
    return text.replace(old,new)


def between(text,start,stop,body):
    begin=text.index(start)
    end=text.index(stop,begin)
    return text[:begin]+body+text[end:]


def status(text):
    marker='    rcTransverseStrainExceeded = 21'
    at=text.index('\n',text.index(marker))
    text=text[:at]+"\n    rcCoupledSteelLimitUnresolved = 22 ' Равновесие подтверждено, сторона предела стали не различима."+text[at:]
    text=replace(text,'Public Enum EResultKind',
        '''' Отдельные группы стали с неразрешённым знаком по предельной деформации.
Public Enum ECoupledSteelUncertainty
    csuNone = 0
    csuLongitudinal = 1
    csuTransverse = 2
End Enum

Public Enum EResultKind''')
    return replace(text,'        Case rcTransverseStrainExceeded: ResultCodeToText = "TRANSVERSE_STRAIN_EXCEEDED"',
        '        Case rcTransverseStrainExceeded: ResultCodeToText = "TRANSVERSE_STRAIN_EXCEEDED"\n'
        '        Case rcCoupledSteelLimitUnresolved: ResultCodeToText = "COUPLED_STEEL_LIMIT_UNRESOLVED"')


def reinforcement(text):
    text=replace(text,'Private mTrialTransverseUtilization As Double, mAcceptedTransverseUtilization As Double',
        '''Private mTrialTransverseUtilization As Double, mAcceptedTransverseUtilization As Double
Private mTrialLongitudinalUtilization As Double, mAcceptedLongitudinalUtilization As Double
Private mTrialLongitudinalPoint As Long, mAcceptedLongitudinalPoint As Long''')
    point=text.index("' Считывает принятое напряжение стержня")
    text=text[:point]+''' ' Возвращает максимальное использование отдельно по продольным стержням.
Friend Property Get AcceptedLongitudinalUtilization() As Double
    AcceptedLongitudinalUtilization = mAcceptedLongitudinalUtilization
End Property

' Возвращает продольную контрольную точку отдельно от хомутов.
Friend Property Get AcceptedLongitudinalPoint() As Long
    AcceptedLongitudinalPoint = mAcceptedLongitudinalPoint
End Property

'''.lstrip()+text[point:]
    text=replace(text,'        mTrialTransverseUtilization = 0#: mTrialTransversePoint = 0',
        '        mTrialTransverseUtilization = 0#: mTrialTransversePoint = 0\n'
        '        mTrialLongitudinalUtilization = 0#: mTrialLongitudinalPoint = 0')
    text=replace(text,'                mTrialTransverseUtilization = utilization: mTrialTransversePoint = point\n            End If\n        End If',
        '                mTrialTransverseUtilization = utilization: mTrialTransversePoint = point\n            End If\n'
        '        ElseIf utilization > mTrialLongitudinalUtilization Or mTrialLongitudinalPoint = 0 Then\n'
        '            mTrialLongitudinalUtilization = utilization: mTrialLongitudinalPoint = point\n        End If')
    text=replace(text,'    mAcceptedSteelUtilization = mTrialSteelUtilization',
        '    mAcceptedSteelUtilization = mTrialSteelUtilization\n'
        '    mAcceptedLongitudinalUtilization = mTrialLongitudinalUtilization: mAcceptedLongitudinalPoint = mTrialLongitudinalPoint')
    text=replace(text,'    mTrialSteelUtilization = 0#: mAcceptedSteelUtilization = 0#',
        '    mTrialSteelUtilization = 0#: mAcceptedSteelUtilization = 0#\n'
        '    mTrialLongitudinalUtilization = 0#: mAcceptedLongitudinalUtilization = 0#\n'
        '    mTrialLongitudinalPoint = 0: mAcceptedLongitudinalPoint = 0')
    text=replace(text,'ByRef correction() As Double, ByRef governingPoint As Long) As Boolean',
        'ByRef correction() As Double, ByRef governingPoint As Long, ByRef unresolved As ECoupledSteelUncertainty) As Boolean')
    text=replace(text,'    For family = 0 To 1\n        If Not exceeded(family) And candidates(family) <> 0 Then\n            governingPoint = candidates(family)\n            Exit For\n        End If\n    Next family',
        '    unresolved = csuNone\n'
        '    If Not exceeded(0) And candidates(0) <> 0 Then\n'
        '        unresolved = csuLongitudinal: governingPoint = candidates(0)\n    End If\n'
        '    If Not exceeded(1) And candidates(1) <> 0 Then\n'
        '        unresolved = unresolved Or csuTransverse\n'
        '        If governingPoint = 0 Then governingPoint = candidates(1)\n    End If')
    return text


def newton(text):
    return between(text,"' Уточняет знак малой погрешности у предела стали", "' Использует факторизацию принятой поправки",
                   (HERE/'FinalForce.txt').read_text(encoding='utf-8')+'\n')


def continuation(text):
    text=replace(text,'Private mDirectSteelUnconfirmed As Boolean','Private mDirectSteelUncertainty As ECoupledSteelUncertainty')
    text=text.replace(' Or mDirectSteelUnconfirmed','')
    text='\n'.join(line for line in text.split('\n') if 'If mDirectSteelUnconfirmed Then Exit Function' not in line)
    text=replace(text,'    mDirectSteelUnconfirmed = False','    mDirectSteelUncertainty = csuNone')
    text=replace(text,'                mMaxIterations, mDirectSteelDetails) Then\n            mDirectSteelUnconfirmed = True',
        '                mMaxIterations, mDirectSteelDetails, mDirectSteelUncertainty) Then')
    key="' Возвращает копию результата последнего принятого шага"
    i=text.index(key)
    return text[:i]+''' ' Сообщает, какая проверка стали осталась открытой при подтверждённом НДС.
Friend Property Get DirectSteelUncertainty() As ECoupledSteelUncertainty
    DirectSteelUncertainty = mDirectSteelUncertainty
End Property

'''.lstrip()+text[i:]


def section(text):
    start='        If response.AcceptedTransverseSteelUtilization > 1# Then'
    end='        If captureFields Then'
    text=between(text,start,end,(HERE/'StateMeta.txt').read_text(encoding='utf-8')+'\n')
    text=replace(text,'                concrete, response, models, target, resultants, fc, ft, meta, warning)',
        '                concrete, response, models, target, resultants, fc, ft, meta, warning, transverseMeta:=hoopMeta)')
    text=replace(text,'Optional ByVal governingTransversePoint As Long = 0) As CSectionStateResult',
        'Optional ByVal governingTransversePoint As Long = 0, _\n'
        '        Optional ByVal transverseMeta As CResultMeta = Nothing) As CSectionStateResult')
    text=replace(text,'        (reinforcement.AcceptedSteelUtilization <= 1#), residualArea, residualLength',
        '        (reinforcement.AcceptedSteelUtilization <= 1# And meta.ResultCode <> rcCoupledSteelLimitUnresolved), residualArea, residualLength')
    text=replace(text,'    SetTransverseControl state, reinforcement, models, field, governingTransversePoint',
        '    SetTransverseControl state, reinforcement, models, field, governingTransversePoint, transverseMeta')
    text=replace(text,'ByVal models As Object, ByRef field() As Double, ByVal point As Long)\n    If point = 0 Then point = reinforcement.AcceptedTransverseCriticalPoint',
        'ByVal models As Object, ByRef field() As Double, ByVal point As Long, ByVal criterion As CResultMeta)\n'
        '    If point = 0 Then point = reinforcement.AcceptedTransverseCriticalPoint')
    text=replace(text,'        steel.StrainUtilization(strain), reinforcement.AcceptedSteelStress(point), strain, strainLimit',
        '        steel.StrainUtilization(strain), reinforcement.AcceptedSteelStress(point), strain, strainLimit, criterion')
    key="' Добавляет предупреждение о поле"
    i=text.index(key)
    return text[:i]+(HERE/'Criterion.txt').read_text(encoding='utf-8')+'\n'+text[i:]


def state(text):
    key='Private mCoupledTransverseControl As String'
    i=text.index(key)
    text=text[:i]+'Private mCoupledTransverseMeta As CResultMeta\n'+text[i:]
    text=replace(text,'        ByVal strain As Double, ByVal strainLimit As Double)\n    AssertWritable',
        '        ByVal strain As Double, ByVal strainLimit As Double, Optional ByVal criterion As CResultMeta = Nothing)\n'
        '    AssertWritable\n    Set mCoupledTransverseMeta = Nothing\n'
        '    If Not criterion Is Nothing Then Set mCoupledTransverseMeta = criterion.Clone')
    text=replace(text,'    mCoupledTransverseControl = vbNullString: mCoupledTransverseUtilization = 0#: mCoupledTransverseStress = 0#',
        '    Set mCoupledTransverseMeta = Nothing\n'
        '    mCoupledTransverseControl = vbNullString: mCoupledTransverseUtilization = 0#: mCoupledTransverseStress = 0#')
    return between(text,"' Возвращает статус только критерия деформации поперечной арматуры", "' Возвращает закручивание",
                   (HERE/'TransverseStatus.txt').read_text(encoding='utf-8')+'\n')


def batch(text):
    return replace(text,'''        combined.SetDirectStateMeta meta
        If Not acceptedState Is Nothing Then combined.AddState acceptedState
        If meta.InternalStatus = rsSuccess Or meta.InternalStatus = rsSuccessWithWarning Or meta.InternalStatus = rsCheckFailed Then _
            combined.StoreCoupledResultants resultants''',
        '''        If Not acceptedState Is Nothing Then
            combined.AddState acceptedState
            combined.StoreSectionStateResult acceptedState
            combined.StoreCoupledResultants resultants
        End If
        combined.SetDirectStateMeta meta''')


def for_layer(output,layer):
    before=json.loads((PREVIOUS/'SourceManifest.json').read_text(encoding='utf-8'))['changes']
    reused={'src/Solver/CCoupledElasticState.cls'}
    changes={
        'src/Common/modResultStatus.bas':status,
        'src/Materials/CCoupledReinforcedResponse.cls':reinforcement,
        'src/Solver/CCoupledNewtonSolver.cls':newton,
        'src/Solver/CCoupledLoadContinuation.cls':continuation,
        'src/Solver/CCoupledSectionAnalysis.cls':section,
        'src/Batch/CSectionStateResult.cls':state,
        'src/Batch/CBatchSectionCalculator.cls':batch,
        'tests/modTestCoupledElasticState.bas':tests,
    }
    if layer=='Snapshot':
        changes.update(snapshot_changes())
    tracked={}
    for name in sorted(set(changes)|reused):
        if name in before:
            raw=(PREVIOUS/name).read_bytes()
            assert sha256(raw).hexdigest().upper()==before[name]['private_sha256']
        else:
            raw=check_output(['git','show',f'{BASE}:{name}'],cwd=REPO)
        source=raw.decode('utf-8-sig').replace('\r\n','\n')
        edited=changes[name](source) if name in changes else source
        if layer=='Snapshot' and name.startswith('tests/'):
            edited=edited.rstrip()+'\n\n'+(HERE/'SnapshotTest.txt').read_text(encoding='utf-8')
        revised=edited.replace('\n','\r\n').encode('utf-8')
        target=output/name
        target.parent.mkdir(exist_ok=True,parents=True)
        target.write_bytes(revised)
        tracked[name]={'base_sha256':sha256(raw).hexdigest().upper(),'candidate_sha256':sha256(revised).hexdigest().upper()}
    (output/'SourceManifest.json').write_text(json.dumps({'layer':layer,'changes':tracked},indent=2)+'\n',encoding='utf-8')


def tests(text):
    text=replace(text,'    RunTestCoupledDirectSteelVerification = report & "TOTAL_DIRECT_STEEL_VERIFICATION',
        '    TestSavedTransverseCriterion passed, failed, report\n'
        '    RunTestCoupledDirectSteelVerification = report & "TOTAL_DIRECT_STEEL_VERIFICATION')
    text=between(text,'    If contact Then\n','    Else\n        TestRecord confirmed And concrete.TestAcceptedSteps = 4',
        '''    If contact Then
        TestRecord confirmed And branch.ResultMeta.InternalStatus = rsSuccess And branch.AcceptedLambda = 1#, _
            "force equilibrium converged at the exact design load", passed, failed, report
        TestRecord branch.DirectSteelUncertainty = csuLongitudinal, _
            "unresolved steel is separate from confirmed equilibrium", passed, failed, report
        TestRecord concrete.TestAcceptedSteps = 4 And branch.SavedFieldCount = 4, _
            "the confirmed target added exactly one final history field", passed, failed, report
        branch.CopyAccepted field, resultants
        TestRecord Abs(resultants(1) - force) / AREA < 1E-9, _
            "retained field verifies requested force at contact", passed, failed, report
        report = report & "DIRECT_CONTACT;" & TestOnsetNumber(shift) & ";" & _
            TestOnsetNumber(resultants(1)) & ";" & CStr(branch.DirectSteelUncertainty) & vbCrLf
''')
    text=replace(text,'    TestDirectSteelSignSeeds solver, response, concrete, STEEL_LIMIT, TOLERANCE, passed, failed, report',
        '    Dim acceptedFields As Collection: Set acceptedFields = branch.AcceptedFields\n'
        '    If Not solver.ReplayAcceptedFields(acceptedFields, 3) Then Err.Raise 5, , "Не восстановлено левое плечо."\n'
        '    TestDirectSteelSignSeeds solver, response, concrete, STEEL_LIMIT, TOLERANCE, passed, failed, report')
    text=replace(text,'    Dim signedGuess As Variant, tangentFailure As Variant, seed As Variant, confirmed As Boolean, preservesSeedSide As Boolean',
        '    Dim signedGuess As Variant, tangentFailure As Variant, seed As Variant, confirmed As Boolean, preservesSeedSide As Boolean\n'
        '    Dim uncertain As ECoupledSteelUncertainty, resultants() As Double')
    text=replace(text,'''            confirmed = solver.VerifyDirectSteelTrial(force, response, tolerance, tolerance, 30, verification)
            TestRecord Not confirmed And solver.ResultMeta.InternalStatus = rsNumericalFailure, _
                "provisional roundoff-scale side never becomes a physical result", passed, failed, report''',
        '''            confirmed = solver.VerifyDirectSteelTrial(force, response, tolerance, tolerance, 30, verification, uncertain)
            TestRecord confirmed And uncertain = csuLongitudinal And solver.ResultMeta.InternalStatus = rsSuccess, _
                "same force state restored without deciding the steel side", passed, failed, report
            solver.CopyTrial field, resultants
            TestRecord Abs(resultants(1) - force(1)) / 21600# < 1E-8, _
                "restored force field did not publish the diagnostic projection", passed, failed, report''')
    return text.rstrip()+'\n\n'+(HERE/'GroupTest.txt').read_text(encoding='utf-8')


def snapshot_changes():
    return {'src/Excel/CNDMResultsWriter.cls':writer,
            'src/Excel/CSectionPlotDataReader.cls':plot_reader,
            'src/Excel/modAutoCADStressExport.bas':autocad_export}


def writer(text):
    text=replace(text,'Private Const COUPLED_SECTION_PROPERTY_ROWS As Long = 37','Private Const COUPLED_SECTION_PROPERTY_ROWS As Long = 38')
    text=replace(text,'Private Const STATE_SECTION_PROPERTY_ROWS As Long = 14','Private Const STATE_SECTION_PROPERTY_ROWS As Long = 15')
    text=replace(text,'            PutProperty data, row, runID, id, "Coupled.Transverse.Status", state.CoupledTransverseStatus, "-", "Статус по достижению предельной деформации при заданных нагрузках."',
        '            PutProperty data, row, runID, id, "Coupled.Transverse.Status", state.CoupledTransverseStatus, "-", "Статус по достижению предельной деформации при заданных нагрузках."\n'
        '            Dim hoopMeta As CResultMeta: Set hoopMeta = state.CoupledTransverseMeta\n'
        '            PutProperty data, row, runID, id, "Coupled.Transverse.ResultCode", ResultCodeToText(hoopMeta.ResultCode), "-", _\n'
        '                "Машинная причина результата по предельной деформации хомута."')
    return replace(text,'                stateResult.Status, "-", "Короткий статус НДС, сохранённый при расчёте сочетания."',
        '                stateResult.Status, "-", "Короткий статус НДС, сохранённый при расчёте сочетания."\n'
        '            PutProperty data, rowIndex, runID, batch.CombinationID(combinationIndex), prefix & "ResultCode", _\n'
        '                ResultCodeToText(stateResult.ResultMeta.ResultCode), "-", "Машинная причина результата именованного НДС."')


def plot_reader(text):
    return replace(text,'        Case "NumFail", "InputErr", "CalcErr", "N/A": SavedStateNeedsElementRows = False',
        '        Case "NumFail"\n'
        '            key = "state." & LCase$(stateType) & ".resultcode"\n'
        '            If stateFields.Exists(key) Then\n'
        '                saved = stateFields.Item(key)\n'
        '                Dim reason As String: reason = ReadSnapshotText(saved(0), anchor, CLng(saved(2)), CLng(saved(3)), key)\n'
        '                SavedStateNeedsElementRows = (reason = ResultCodeToText(rcCoupledSteelLimitUnresolved))\n'
        '            End If\n'
        '        Case "InputErr", "CalcErr", "N/A": SavedStateNeedsElementRows = False')


def autocad_export(text):
    point=text.index('Private Const NUMERICAL_STATE_WARNING_TEXT As String')
    text=text[:point]+'Private Const STEEL_CHECK_WARNING_TEXT As String = "РАВНОВЕСИЕ ПОДТВЕРЖДЕНО. ПРЕДЕЛ АРМАТУРЫ НЕ УТОЧНЁН"\n'+text[point:]
    text=replace(text,'                Case "status"\n                    If Not TryReadSnapshotStatus(data(rowIndex, colValue), stateStatus) Then',
        '                Case "resultcode"\n'
        '                    stateCode = SafeText(data(rowIndex, colValue))\n'
        '                Case "status"\n'
        '                    If Not TryReadSnapshotStatus(data(rowIndex, colValue), stateStatus) Then')
    text=replace(text,'    Dim stateStatus As String\n','    Dim stateStatus As String, stateCode As String\n')
    return replace(text,'    ElseIf stateStatus = policy.NumFail Then\n        stateWarningText = NUMERICAL_STATE_WARNING_TEXT',
        '    ElseIf stateStatus = policy.NumFail Then\n'
        '        If stateCode = ResultCodeToText(rcCoupledSteelLimitUnresolved) Then\n'
        '            stateWarningText = STEEL_CHECK_WARNING_TEXT\n'
        '        Else\n            stateWarningText = NUMERICAL_STATE_WARNING_TEXT\n        End If')


if __name__=='__main__':
    dry=argparse.ArgumentParser(description=__doc__)
    dry.add_argument('--layer',choices=('Equilibrium','Snapshot'),default='Equilibrium')
    args=dry.parse_args()
    for_layer(HERE/args.layer,args.layer)
