"""Freeze native verification lanes for equilibrium and persistence."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile

from Compose import for_layer, HERE, PREVIOUS, REPO


BOOK='workbook/output/RC_Section_NDM.xlsm'


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def stage(layer):
    target=HERE/layer
    assert not (target/'Fixture.json').exists()
    for_layer(target,layer)
    old=json.loads((PREVIOUS/'Fixture.json').read_text(encoding='utf-8'))
    assert digest(REPO/BOOK)==old['workbook_sha256']==digest(PREVIOUS/BOOK)
    source=[name for name in old['frozen'] if name.startswith('tools/') or name in (BOOK,'Guard-IsolatedOffice.ps1')]
    for name in source:
        assert digest(PREVIOUS/name)==old['frozen'][name]
        (target/name).parent.mkdir(exist_ok=True,parents=True)
        copyfile(PREVIOUS/name,target/name)
    for name in ('docs/regression','Temp','Native'):
        (target/name).mkdir(exist_ok=True,parents=True)
    copyfile(target/BOOK,target/'docs/regression/Diagnostic.xlsm')
    changes=json.loads((target/'SourceManifest.json').read_text(encoding='utf-8'))['changes']
    for name in ('Run.ps1','Verify.py'):
        copyfile(HERE/name,target/name)
    source+=list(changes)+['Run.ps1','Verify.py','SourceManifest.json']
    manifest={'layer':layer,'workbook_sha256':old['workbook_sha256'],'frozen':{name:digest(target/name) for name in source},
              'modules':sorted(Path(name).stem for name in changes)}
    (target/'Fixture.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(layer,digest(target/'Fixture.json'))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('layer',choices=('Equilibrium','Snapshot'))
    stage(parser.parse_args().layer)
