"""Compose a private source and test overlay for final direct steel verification."""

from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
BASE='abcfa53'


def replace(text, old, new):
    if text.count(old)!=1:
        raise ValueError(f'Unexpected VBA anchor {old!r}')
    return text.replace(old,new)


def compose(name, change):
    raw=check_output(['git','show',f'{BASE}:{name}'],cwd=REPO)
    source=raw.decode('utf-8-sig').replace('\r\n','\n')
    revised=change(source).replace('\n','\r\n').encode('utf-8')
    target=HERE/name
    target.parent.mkdir(exist_ok=True,parents=True)
    target.write_bytes(revised)
    return {'base_sha256':sha256(raw).hexdigest().upper(),'private_sha256':sha256(revised).hexdigest().upper()}


def continuation(source):
    token='Private mReinforcement As CCoupledReinforcedResponse '
    pointer=source.index(token)
    source=source[:pointer]+'''Private mDirectSteel As CCoupledReinforcedResponse ' Чтение границы стали на точной силовой цели.
Private mDirectTarget As Double
Private mDirectSteelDetails As String
Private mDirectSteelUnconfirmed As Boolean
'''+source[pointer:]
    source=replace(source,'Friend Function Advance(ByVal targetLambda As Double) As Boolean',
        'Friend Function Advance(ByVal targetLambda As Double, Optional ByVal verifyDirectSteel As CCoupledReinforcedResponse = Nothing) As Boolean')
    source=replace(source,'    mMeta.Clear\n    mRejected = 0: mAccepted = 0: mAttempts = 0',
        '    mMeta.Clear\n    Set mDirectSteel = verifyDirectSteel: mDirectTarget = targetLambda: mDirectSteelDetails = vbNullString\n'
        '    mDirectSteelUnconfirmed = False\n'
        '    mRejected = 0: mAccepted = 0: mAttempts = 0')
    source=replace(source,'    Set mReinforcement = Nothing\n    mHasSteelLimit',
        '    Set mReinforcement = Nothing: Set mDirectSteel = Nothing\n    mHasSteelLimit')
    source=replace(source,'    mAttempts = mAttempts + 1\n    If Not mSolver.TryStep(load(1), load(2), load(3), load(4), load(5), load(6), _\n'
        '            mAbsoluteTolerance, mRelativeTolerance, mMaxIterations, initialField) Then',
        '    Dim checkSteel As Boolean\n'
        '    If Not mDirectSteel Is Nothing Then\n'
        '        checkSteel = (Not offsetStage And parameter = mDirectTarget) Or _\n'
        '            (offsetStage And parameter = 1# And mDirectTarget = 0#)\n'
        '        checkSteel = checkSteel And mDirectSteel.HasSteel\n'
        '    End If\n'
        '    mAttempts = mAttempts + 1\n    If Not mSolver.TryStep(load(1), load(2), load(3), load(4), load(5), load(6), _\n'
        '            mAbsoluteTolerance, mRelativeTolerance, mMaxIterations, initialField, retainDirectProof:=checkSteel) Then')
    source=replace(source,'    TryEquilibrium = True\nEnd Function',
        '    If checkSteel Then\n'
        '        If Not mSolver.VerifyDirectSteelTrial(load, mDirectSteel, mAbsoluteTolerance, mRelativeTolerance, _\n'
        '                mMaxIterations, mDirectSteelDetails) Then\n'
        '            mDirectSteelUnconfirmed = True\n'
        '            Set mMeta = mSolver.ResultMeta\n'
        '            Exit Function\n'
        '        End If\n'
        '    End If\n'
        '    TryEquilibrium = True\nEnd Function')
    source=replace(source,'            If mHasSteelLimit Or mMeta.InternalStatus <> rsNumericalFailure Then Exit Function',
        '            If mHasSteelLimit Or mDirectSteelUnconfirmed Or mMeta.InternalStatus <> rsNumericalFailure Then Exit Function')
    source=replace(source,'                    FollowSegment = True\n                    Exit Function\n                End If\n            End If\n            If mPreferDeformationOnStall',
        '                    FollowSegment = True\n                    Exit Function\n                End If\n'
        '                If mDirectSteelUnconfirmed Then Exit Function\n            End If\n            If mPreferDeformationOnStall')
    source=replace(source,'        Dim canPredict As Boolean: canPredict = (mMeta.InternalStatus = rsNumericalFailure)',
        '        If mDirectSteelUnconfirmed Then Exit Function\n'
        '        Dim canPredict As Boolean: canPredict = (mMeta.InternalStatus = rsNumericalFailure)')
    source=replace(source,'        mSecantFailure = mMeta.ResultComment\n        Dim canGuide',
        '        If mDirectSteelUnconfirmed Then Exit Function\n        mSecantFailure = mMeta.ResultComment\n        Dim canGuide')
    source=replace(source,'        mTwistGuideDetails = mTwistGuideDetails & " Точная силовая проба: " & mMeta.ResultComment\n        Set mMeta = failure',
        '        If mDirectSteelUnconfirmed Then Exit Function\n'
        '        mTwistGuideDetails = mTwistGuideDetails & " Точная силовая проба: " & mMeta.ResultComment\n        Set mMeta = failure')
    token='    If Len(mExactTargetRecovery) > 0 Then ProgressDetails'
    pointer=source.index(token)
    return source[:pointer]+'    If Len(mDirectSteelDetails) > 0 Then ProgressDetails = ProgressDetails & " | " & mDirectSteelDetails\n'+source[pointer:]


def section(source):
    return replace(source,'    If continuation.Advance(1#) Then','    If continuation.Advance(1#, response) Then')


def newton(source):
    source=replace(source,'Private mMatrix() As Double, mExternal() As Double, mResidual() As Double',
        'Private mMatrix() As Double, mExternal() As Double, mResidual() As Double\n'
        'Private mDirectProofMatrix As Boolean, mDirectProofFactor As Boolean\n'
        'Private mDirectProofMove() As Double')
    source=replace(source,'        Optional ByRef initialField As Variant) As Boolean\n    Dim load(1 To COMPONENT_COUNT)',
        '        Optional ByRef initialField As Variant, Optional ByVal retainDirectProof As Boolean = False) As Boolean\n'
        '    Dim load(1 To COMPONENT_COUNT)')
    source=replace(source,'TryStep = SolveStep(load, 0#, absoluteTolerance, relativeTolerance, maxIterations, initialField:=initialField)',
        'TryStep = SolveStep(load, 0#, absoluteTolerance, relativeTolerance, maxIterations, _\n'
        '        initialField:=initialField, retainDirectProof:=retainDirectProof)')
    source=replace(source,'        Optional ByVal recoverYieldControl As Boolean = False, Optional ByRef initialField As Variant) As Boolean\n    mMeta.Clear',
        '        Optional ByVal recoverYieldControl As Boolean = False, Optional ByRef initialField As Variant, _\n'
        '        Optional ByVal retainDirectProof As Boolean = False) As Boolean\n'
        '    mDirectProofMatrix = False: mDirectProofFactor = False\n'
        '    If retainDirectProof Then Erase mDirectProofMove\n'
        '    mMeta.Clear')
    source=replace(source,'            mCandidate = current\n            PublishCandidate currentLambda\n            SolveStep = True',
        '            mCandidate = current\n'
        '            mDirectProofMatrix = retainDirectProof And Not mControlActive\n'
        '            PublishCandidate currentLambda\n            SolveStep = True')
    source=replace(source,'        If candidateNorm <= candidateTolerance And GaugesVerified(candidateTolerance) Then\n            PublishCandidate candidateLambda',
        '        If candidateNorm <= candidateTolerance And GaugesVerified(candidateTolerance) Then\n'
        '            If retainDirectProof And Not mControlActive Then\n'
        '                mDirectProofFactor = True\n'
        '                ReDim mDirectProofMove(1 To mDegreeCount)\n'
        '                For i = 1 To mGaugeStart - 1\n'
        '                    mDirectProofMove(i) = mCandidate(i) - current(i)\n'
        '                Next i\n'
        '            End If\n'
        '            PublishCandidate candidateLambda')
    point=source.index("' Возвращает максимум по всем силовым уравнениям")
    return source[:point]+(HERE/'Newton.txt').read_text(encoding='utf-8')+'\n'+source[point:]


def append(source,name):
    return source.rstrip()+'\n\n'+(HERE/name).read_text(encoding='utf-8')


if __name__=='__main__':
    changes={
        'src/Solver/CCoupledLoadContinuation.cls':continuation,
        'src/Solver/CCoupledSectionAnalysis.cls':section,
        'src/Solver/CCoupledNewtonSolver.cls':newton,
        'src/Solver/CCoupledElasticState.cls':lambda s:append(s,'Projection.txt'),
        'src/Materials/CCoupledReinforcedResponse.cls':lambda s:append(s,'Steel.txt'),
        'tests/modTestCoupledElasticState.bas':lambda s:append(s,'Test.txt')}
    receipt={'base':BASE,'changes':{name:compose(name,change) for name,change in changes.items()}}
    (HERE/'SourceManifest.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,indent=2))
