"""Повторяет состояние трёх точек ASD и восстанавливает эффективный прогноз."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha256
from io import BytesIO
from math import fsum
from os import devnull
from pathlib import Path
from zipfile import ZipFile
import json


PIN = ('MVT2Cut396PrincipalSigns20261117.zip',
       '1588EF69B15D6398613C4F96C526792BE31AAF1D46C857ECD116109C9AE51269')
POINTS = (11, 14, 15)
MEASURES = ('equivalentTotalStrain', 'equivalentPlasticStrain', 'damage')
COMPONENTS = ((0,0),(1,1),(2,2),(0,1),(0,2),(1,2))
ZERO = (0.,)*6


def load(repo):
    """Подтверждает архив собственных напряжений и его исходные входы."""
    source = (repo/'docs/regression/Coupled6D'/PIN[0]).read_bytes()
    assert sha256(source).hexdigest().upper() == PIN[1]
    module = {'__name__':'__pinned__', '__file__':'Split-Cut396Principal.py'}
    with ZipFile(BytesIO(source)) as archive:
        exec(compile(archive.read(module['__file__']), module['__file__'], 'exec'), module)
    replay, wire = module['read_replay'](repo)
    _, path, positions, _, _, command, model, *_ = replay['read_data'](repo)
    return module, wire, path, positions, command, model


def capture(repo, target):
    """Снимает ведомые переменные у трёх отдельных материальных историй."""
    import openseespy.opensees as ops

    assert ops.version() == '3.8.0'
    _, reference, path, _, command, _ = load(repo)
    data = {}
    for mode, arguments in command.items():
        ops.wipe()
        ops.logFile(devnull, '-noEcho')
        ops.model('basic','-ndm',3,'-ndf',3)
        for tag in range(1,7):
            ops.nDMaterial(arguments[0],tag,*arguments[1:])

        def response(tag, row):
            strain = (*row[:4],row[5],row[4])
            ops.NDTest('SetStrain',tag,*strain)
            assert tuple(ops.NDTest('GetStrain',tag)) == strain
            a,b,c,d,f,e = ops.NDTest('GetStress',tag)
            measured = [list(ops.NDTest('GetResponse',tag,key)) for key in MEASURES]
            return {'stress_MPa':[a,b,c,d,e,f], 'measures':measured}

        states = []
        for index,(phase,_,q,tensors) in enumerate(path):
            result = {}
            for tag,j in enumerate(POINTS,1):
                row = response(tag,tensors[j])
                assert row['stress_MPa'] == reference['stress'][mode][index][0][j-1]
                ops.NDTest('CommitState',tag)
                if q == 20000.:
                    row['cold'] = response(tag+3,tensors[j])
                result[str(j)] = row
            states.append({'phase':phase,'points':result})
        data[mode] = states
    ops.wipe()
    with target.open('xb') as output:
        output.write(compress(json.dumps(data,separators=(',',':'),allow_nan=False).encode(),mtime=0))


def eigensystem(row, rotate):
    """Возвращает собственные значения и оси принятого напряжения."""
    xx,yy,zz,xy,xz,yz = row
    axes = [[float(i==j) for j in range(3)] for i in range(3)]
    principal = rotate([[xx,xy,xz],[xy,yy,yz],[xz,yz,zz]],axes)
    return principal,axes


def compose(principal, axes):
    """Восстанавливает тензор из спектральной записи."""
    return tuple(fsum(axes[i][k]*axes[j][k]*s for k,s in enumerate(principal)) for i,j in COMPONENTS)


def elastic(strain, e, nu):
    """Применяет изотропную упругую матрицу к инженерным деформациям."""
    mu = e/(2.*(1.+nu))
    lam = nu*e/((1.+nu)*(1.-2.*nu))
    vol = fsum(strain[:3])
    return (*[2.*mu*x+lam*vol for x in strain[:3]],*[mu*x for x in strain[3:]])


def response(row, strain, prior, e, nu, rotate):
    """Сверяет прогноз, эффективный и номинальный тензоры с ответом ASD."""
    sig = row['stress_MPa']
    abscissa, plastic, damage = row['measures']
    old_eff, old_strain, old_abscissa, old_plastic = prior
    assert all(0. <= x < 1. for x in damage)
    assert all(b >= a - 1e-15 for a,b in zip(old_abscissa,abscissa,strict=True))
    base = elastic(strain,e,nu)
    increment = elastic(tuple(a-b for a,b in zip(strain,old_strain,strict=True)),e,nu)
    predictor = tuple(a+b for a,b in zip(old_eff,increment,strict=True))
    trial, axes = eigensystem(predictor,rotate)
    factors = [(x-p)/(x-p_old) if x-p_old>1e-14 else 1.
               for x,p,p_old in zip(abscissa,plastic,old_plastic,strict=True)]
    effective = [s*factors[int(s<0.)] for s in trial]
    nominal = [s*(1.-damage[int(s<0.)]) for s in effective]
    error = max(abs(a-b) for a,b in zip(compose(nominal,axes),sig,strict=True))
    native_values,native_axes = eigensystem(sig,rotate)
    inverse_eff = compose([s/(1.-damage[int(s<0.)]) for s in native_values],native_axes)
    inverse_error = max(abs(a-b) for a,b in zip(compose(effective,axes),inverse_eff,strict=True))
    bulk = fsum(effective)
    effective_strain = [(1.+nu)/e*s-nu/e*bulk for s in effective]
    current = inverse_eff,strain,abscissa,plastic
    details = dict(total_strain=strain, elastic_principal_MPa=sorted(eigensystem(base,rotate)[0]),
                   effective_predictor_principal_MPa=sorted(trial), effective_principal_MPa=sorted(effective),
                   effective_elastic_principal_strains=sorted(effective_strain), nominal_principal_MPa=sorted(native_values),
                   total_measures_T_C=abscissa, cracking_damage_T_C=damage, plastic_measures_T_C=plastic,
                   prior_total_measures_T_C=old_abscissa, current_plastic_factors_T_C=factors)
    return current,details,error,inverse_error


def verify(repo, captured):
    """Сравнивает каждую точку с сохранённым путём и отдельной холодной пробой."""
    functions, reference, path, positions, command, model = load(repo)
    raw = captured.read_bytes()
    data = json.loads(decompress(raw))
    assert list(data) == list(command)
    e,nu,*_ = model
    zero = (ZERO,ZERO,(0.,0.),(0.,0.))
    rotate = functions['rotate']
    results = {}
    errors = {'initial_step':[0.,0.], 'later_accepted':[0.,0.], 'cold_20_kN':[0.,0.]}

    def check(key,err,inv):
        previous = errors[key]
        errors[key] = [max(previous[0],err),max(previous[1],inv)]

    for mode, states in data.items():
        selected = {}
        prior = dict.fromkeys(POINTS,zero)
        assert len(states) == 22
        for i, ((phase,_,q,tensors),step) in enumerate(zip(path,states,strict=True)):
            assert phase == step['phase']
            for j in POINTS:
                row = step['points'][str(j)]
                assert row['stress_MPa'] == reference['stress'][mode][i][0][j-1]
                now,markers,err,inv = response(row,tensors[j][:6],prior[j],e,nu,rotate)
                prior[j] = now
                check('initial_step' if i == 0 else 'later_accepted',err,inv)
                if q == 20000.:
                    _,cold,cold_err,cold_inv = response(row['cold'],tensors[j][:6],zero,e,nu,rotate)
                    check('cold_20_kN',cold_err,cold_inv)
                    selected[str(j)] = {'coordinates_mm':positions[j][:2], 'history':markers, 'cold':cold}
        assert len(selected) == len(POINTS)
        for j, pair in selected.items():
            warm,cold = pair['history'],pair['cold']
            if j in ('14','15'):
                assert all(min(route[key]) > 0. for route in (warm,cold)
                           for key in ('effective_predictor_principal_MPa','nominal_principal_MPa'))
                assert cold['total_measures_T_C'][1] == 0.
                assert warm['total_measures_T_C'][1] == warm['prior_total_measures_T_C'][1] > 0.
            else:
                assert min(warm['effective_predictor_principal_MPa']) < 0.
                assert abs(min(warm['nominal_principal_MPa']) - min(warm['effective_predictor_principal_MPa'])) < 2e-7
            assert warm['cracking_damage_T_C'][1] == 0. and abs(warm['plastic_measures_T_C'][1]) < 1e-14
        results[mode] = selected
    # Для упругой пробы первого шага сохранён допуск 2e-7
    # из автономной проверки исходного повтора.
    assert max(errors['initial_step']) < 2e-7
    assert errors['later_accepted'][0] < 3e-9 and errors['later_accepted'][1] < 2e-8
    assert max(errors['cold_20_kN']) < 8e-8
    return dict(history_states=22,points=POINTS,source_pin=PIN[1],wire_sha256=sha256(raw).hexdigest().upper(),
                reconstruction_errors_MPa=errors, comparisons_at_Qy_20_kN=results)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--capture',type=Path)
    parser.add_argument('--report',type=Path)
    args = parser.parse_args()
    if args.capture:
        capture(args.repo.resolve(),args.capture)
    if args.report:
        proof = verify(args.repo.resolve(),args.capture or Path(__file__).with_name('Cut396MaterialWire.json.gz'))
        with args.report.open('x',encoding='utf-8',newline='\n') as file:
            json.dump(proof,file,sort_keys=True,indent=2,allow_nan=False)
            file.write('\n')
        print('MVT2 CUT396 MATERIAL HISTORY OFFLINE PASS 22')
