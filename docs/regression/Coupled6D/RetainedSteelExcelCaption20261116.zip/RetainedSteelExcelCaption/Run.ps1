# Проверяет все выбранные сценарии на одном наборе рабочих исходников.
param([ValidateSet('Excel','File','All','Compile')]
    [string]$Check='All',[switch]$Preflight)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../..')).Path
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$book='workbook/output/RC_Section_NDM.xlsm'
$draft='docs/regression/Diagnostic.xlsm'
$oldTemp=$env:TEMP
$oldTmp=$env:TMP
Push-Location -LiteralPath $root
try {
    $data=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    foreach ($item in $data.frozen.PSObject.Properties) {
        if ((Get-FileHash -LiteralPath $item.Name).Hash -cne $item.Value) {throw ('Изменён файл '+$item.Name)}
    }
    if ((Get-FileHash -LiteralPath (Join-Path $repo $book)).Hash -cne $data.workbook_sha256) {throw 'Изменилась установленная книга.'}
    $production=Get-Content -LiteralPath 'Production/PlotOverlay.json' -Raw | ConvertFrom-Json
    foreach ($item in $production.production_overlay.PSObject.Properties) {
        if ((Get-FileHash -LiteralPath ('Production/'+$item.Name)).Hash -cne $item.Value.sha256) {
            throw ('Изменён рабочий исходник '+$item.Name)
        }
    }
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {throw 'Путь пробной книги слишком длинный.'}
    Assert-IsolatedOfficeReady "IntegratedDirect$Check"
    if ($Preflight) {return}
    if (!(Test-Path -LiteralPath 'docs/regression/CodeUpdate.json')) {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Get-FileHash -LiteralPath $draft).Hash -cne $data.workbook_sha256) {throw 'Найдена непроверенная компиляция.'}
        $moduleNames=@($data.modules | ForEach-Object { [string]$_ })
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft -ModuleNames $moduleNames |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $closure.State -cne 'Absent' -or
        (($compiled.Modules | Sort-Object) -join ',') -cne ($data.modules -join ',') -or
        $compiled.ProductionSHA256 -cne $data.workbook_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash) {throw 'Компиляция не подтверждена.'}
    if ($Check -eq 'Compile') {return}

    $macros=@{Fallback='RunTestCoupledSteelWithoutSavedFactor';Mixed='RunTestCoupledDirectHoopContact';
        Excel='RunTestCoupledRetainedSnapshot';File='RunTestCoupledRetainedSnapshot';
        HardShear='RunTestCoupledWorkbookTiming';Equilibrium='RunTestCoupledDirectSteelVerification'}
    $checks=@($Check)
    if ($Check -eq 'All') {$checks=@('Excel','File')}
    foreach ($label in $checks) {
        $report="Native/$label.txt"
        if (Test-Path -LiteralPath $report) {throw ('Сохраняется предыдущая проверка '+$label)}
        if ((Get-FileHash -LiteralPath $draft).Hash -cne $compiled.WorkbookSHA256) {throw 'Смена исходной диагностической книги.'}
        Assert-IsolatedOfficeReady "BeforeIntegrated$label"
        $macro='modTestCoupledElasticState.'+$macros[$label]
        $commandArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-Audit03Watchdog.ps1',
                       '-SourceWorkbook',$draft,'-ReportPath',$report,'-Macro',$macro,'-Mode','No','-TimeoutSeconds',210,'-FailFast')
        if ($label -in 'Excel','File') {$commandArgs+=@('-MacroArgument1',$label)}
        if ($label -eq 'HardShear') {$commandArgs+=@('-MacroArgument1','Direct','-MacroArgument2','Excel','-VerifyResultsReopen')}
        & $legacy @commandArgs
        if ($LASTEXITCODE -ne 0) {throw ('Нативная проверка завершилась ошибкой '+$label)}
        $ended=Get-Content -LiteralPath ($report+'.ProcessClosure.json') -Raw | ConvertFrom-Json
        if (!$ended.Passed -or $ended.Closure.FinalState.State -cne 'Absent') {throw 'Закрытие дочернего Excel не подтверждено.'}
        switch ($label) {
            'Fallback' { & python -B -X utf8 'Verify-Fallback.py' $report }
            'Mixed' { & python -B -X utf8 'Verify-MixedHoop.py' $report }
            'HardShear' { & python -B -X utf8 'Verify-HardShear.py' $report }
            default { & python -B -X utf8 'Verify-Compat.py' $label $report }
        }
        if ($LASTEXITCODE -ne 0) {throw ('Независимая проверка завершилась ошибкой '+$label)}
    }
} finally {
    $env:TEMP=$oldTemp
    $env:TMP=$oldTmp
    Pop-Location
}
