"""Replay the two native Excel caption checks without launching Excel."""

from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory


HERE = Path(__file__).resolve().parent
MEDIUMS = ("Excel", "File")
FIXTURE_SHA = "58AB96E76A14D9E74890D3C3B3FD0F9BACB3FC49A9F2C81C973DC5E6A76B87A0"
PROBE_SHA = "443B0A7F3ACBCF26A71DF0784E0C632F551922583AB8A5CC26472E219B98F1BE"


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def code_bytes(text):
    return text.replace("\n", "\r\n").encode("utf-8")


def check_sources():
    assert digest(HERE / "Fixture.json") == FIXTURE_SHA
    fixture = read(HERE / "Fixture.json")
    base = HERE / "BaselineDsi"
    assert digest(base / "Fixture.json") == fixture["base_dsi_fixture_sha256"]
    previous = read(base / "Fixture.json")
    spec = spec_from_file_location("captions", HERE / "Stage.py")
    stage = module_from_spec(spec)
    spec.loader.exec_module(stage)
    stage.DSI = base
    for name, value in fixture["frozen"].items():
        if name == stage.BOOK:
            assert value == fixture["workbook_sha256"] == previous["workbook_sha256"]
        else:
            assert digest(HERE / name) == value
    assert sorted((*previous["modules"], Path(stage.PLOTTER).stem)) == fixture["modules"]
    overlay = read(HERE / "Production/PlotOverlay.json")
    assert overlay["base_fixture_sha256"] == fixture["base_dsi_fixture_sha256"]
    assert set(overlay["production_overlay"]) == {stage.READER, stage.PLOTTER}
    assert digest(base / "Production" / stage.READER) == previous["frozen"][stage.READER]
    assert digest(base / stage.TEST) == previous["frozen"][stage.TEST]
    for name, expected in previous["frozen"].items():
        if name.startswith("src/") and name != stage.READER:
            assert fixture["frozen"][name] == expected
    old_plotter = HERE / "BaselinePlotter.cls"
    assert digest(old_plotter) == overlay["production_overlay"][stage.PLOTTER]["base_sha256"]
    assert code_bytes(stage.reader_code()) == (HERE / stage.READER).read_bytes()
    assert code_bytes(stage.plotter_code(old_plotter.read_bytes())) == (HERE / stage.PLOTTER).read_bytes()
    assert code_bytes(stage.test_code()) == (HERE / stage.TEST).read_bytes()
    for name, hashes in overlay["production_overlay"].items():
        assert digest(HERE / "Production" / name) == digest(HERE / name) == hashes["sha256"]
    assert digest(HERE / stage.TEST) == overlay["test_probe"][stage.TEST]
    return fixture


def check_runs(fixture):
    document = read(HERE / "docs/regression/CodeUpdate.json")
    assert document["Compiled"] and not document["ProductionChanged"]
    assert document["ProductionSHA256"] == fixture["workbook_sha256"]
    assert document["WorkbookSHA256"] == PROBE_SHA and sorted(document["Modules"]) == fixture["modules"]
    log = (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    pid, ticks = re.search(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", log, re.M).groups()
    compiler = read(HERE / "CompileClosure.json")
    assert (str(compiler["PID"]), compiler["StartTicksUTC"], compiler["State"]) == (pid, ticks, "Absent")
    with TemporaryDirectory(prefix="captions-") as temporary:
        for medium in MEDIUMS:
            report = HERE / "Native" / f"{medium}.txt"
            body = report.read_text(encoding="utf-8-sig")
            assert re.search(r"^SOURCE_SHA256: " + PROBE_SHA + "$", body, re.M)
            assert "SOURCE_UNCHANGED: True" in body
            owner = read(report.with_suffix(".txt.Ownership.json"))
            assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == PROBE_SHA
            pid, ticks = re.search(r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$", body, re.M).groups()
            assert (str(owner["PID"]), owner["StartTicksUTC"]) == (pid, ticks)
            closure = read(report.with_suffix(".txt.ProcessClosure.json"))
            assert closure["Passed"] and closure["ChildExitCode"] == 0 and closure["ChildHasExited"]
            final = closure["Closure"]["FinalState"]
            assert (str(final["PID"]), final["StartTicksUTC"], final["State"]) == (pid, ticks, "Absent")
            local = Path(temporary) / report.name
            copyfile(report, local)
            check_output([sys.executable, "-B", "-X", "utf8", str(HERE / "Verify-Compat.py"), medium, str(local)])
            expected = report.with_suffix(".Verification.json")
            assert read(local.with_suffix(".Verification.json")) == read(expected)
            assert read(expected)["report_sha256"] == digest(report)
            print("PASS RENDERED CAPTION", medium, digest(report), digest(expected))


def main():
    assert not sys.flags.optimize
    for name, claimed in read(HERE / "SHA256SUMS.json").items():
        assert digest(HERE / name) == claimed
    check_runs(check_sources())


if __name__ == "__main__":
    main()
