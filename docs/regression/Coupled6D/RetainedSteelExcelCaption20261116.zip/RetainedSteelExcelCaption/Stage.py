"""Freeze the Excel chart warning overlay on the verified integrated DSI candidate."""

from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from subprocess import check_output


HERE = Path(__file__).resolve().parent
DSI = HERE.parent / "dsi"
REPO = HERE.parents[1]
COMMIT = "f4741ae638f3c17bc19b39e02d177698c247bd86"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
READER = "src/Excel/CSectionPlotDataReader.cls"
PLOTTER = "src/Excel/CSectionPlotter.cls"
TEST = "tests/modTestCoupledElasticState.bas"
DSI_SHA = "988715E00C30D2306F01E11B9149244D903C7CE75721114F134DA0CECA2F933F"
WARNING = "РАВНОВЕСИЕ ПОДТВЕРЖДЕНО. ПРЕДЕЛ АРМАТУРЫ НЕ УТОЧНЁН"


def digest(data):
    return sha256(data).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_bytes())


def freeze(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    copyfile(source, target)


def write_code(path, code):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(code.replace("\n", "\r\n").encode("utf-8"))


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def reader_code():
    text = (DSI / "Production" / READER).read_text(encoding="utf-8")
    marker = 'Private mStateStatus As String \' Статус выбранного сохранённого расчётного состояния.'
    text = once(text, marker, marker + "\nPrivate mRetainedSteelLimitUnresolved As Boolean")
    text = once(
        text,
        "    retainedSteel = SavedStateRetainsUnresolvedSteel(anchor, stateFields, stateType, status)",
        "    retainedSteel = SavedStateRetainsUnresolvedSteel(anchor, stateFields, stateType, status)\n"
        "    If StrComp(stateType, mStateType, vbTextCompare) = 0 Then mRetainedSteelLimitUnresolved = retainedSteel",
    )
    marker = "    mStateStatus = vbNullString"
    text = once(text, marker, marker + "\n    mRetainedSteelLimitUnresolved = False")
    marker = "Public Property Get DirectStateStatus() As String: DirectStateStatus = mStateStatus: End Property"
    return once(text, marker, marker +
                "\n' Выбранное сохранённое НДС уравновешено, сторона предела стали открыта.\n"
                "Friend Property Get RetainedSteelLimitUnresolved() As Boolean\n"
                "    RetainedSteelLimitUnresolved = mRetainedSteelLimitUnresolved\n"
                "End Property")


def plotter_code(original):
    text = original.decode("utf-8").replace("\r\n", "\n")
    marker = 'Private Const NUMERICAL_STATE_WARNING_TEXT As String = "ПРЯМОЕ НДС НЕ СОШЛОСЬ"'
    lines = text.splitlines()
    insert = next(line for line in lines if line.startswith(marker))
    text = once(text, insert, insert + '\nPrivate Const STEEL_CHECK_WARNING_TEXT As String = "' + WARNING + '"')
    text = once(
        text,
        "' Показывает под схемой короткое красное предупреждение по сохраненному\n"
        "' DirectStateStatus. Для FAIL состояние найдено\n"
        "' вне физической диаграммы. Для NumFail отдельно предупреждаем, что на схеме\n"
        "' может быть последняя итерация, а не корректное равновесное состояние.",
        "' Показывает предупреждение по выбранному сохранённому НДС. Отдельная\n"
        "' подпись сообщает о неопределённости предела стали при подтверждённом равновесии.",
    )
    return once(
        text,
        "    If data.PhysicalDiagramWarningRequired Then\n        warningText = EXTENSION_WARNING_TEXT",
        "    If data.RetainedSteelLimitUnresolved Then\n        warningText = STEEL_CHECK_WARNING_TEXT\n"
        "    ElseIf data.PhysicalDiagramWarningRequired Then\n        warningText = EXTENSION_WARNING_TEXT",
    )


def test_code():
    text = (DSI / TEST).read_text(encoding="utf-8")
    marker = '    TestInputCell(settingsArea, "Results.SnapshotName").Value2 = "TestDirectSteelContact" & storage'
    text = once(text, marker, marker + '\n    TestInputCell(settingsArea, "Plot.Enabled").Value2 = "Yes"')
    marker = '    reopened.Close False: Set reopened = Nothing\n    TestSavedSteelOutcomeCompatibility book, snapshot, storage, passed, failed, report'
    text = once(
        text, marker,
        "    UpdateSectionPlotForWorkbook reopened\n"
        '    Dim warningCorrect As Boolean: warningCorrect = TestSteelChartHasText(reopened, "' + WARNING + '")\n'
        '    warningCorrect = warningCorrect And Not TestSteelChartHasText(reopened, "ПРЯМОЕ НДС НЕ СОШЛОСЬ")\n'
        '    TestRecord warningCorrect, storage & " Excel chart distinguishes retained equilibrium and steel uncertainty", passed, failed, report\n'
        + marker,
    )
    marker = '                valid = geometryOnly And UBound(zeroField, 1) = 1'
    text = once(
        text, marker,
        marker + "\n"
        "                UpdateSectionPlotForWorkbook reopened\n"
        "                Dim warningCorrect As Boolean\n"
        "                warningCorrect = Len(reader.GeometryOnlyNote) > 0 And TestSteelChartHasText(reopened, reader.GeometryOnlyNote)\n"
        '                warningCorrect = warningCorrect And Not TestSteelChartHasText(reopened, "' + WARNING + '")\n'
        '                TestRecord warningCorrect, storage & " Excel chart keeps the genuine no-field geometry note", passed, failed, report',
    )
    return text.rstrip() + "\n\n" + (HERE / "ChartTest.txt").read_text(encoding="utf-8").strip() + "\n"


def stage():
    assert not (HERE / "Fixture.json").exists()
    dsi_fixture = DSI / "Fixture.json"
    assert digest(dsi_fixture.read_bytes()) == DSI_SHA
    fixture = read_json(dsi_fixture)
    source_manifest = read_json(DSI / "Production/ProductionManifest.json")["production_files"]
    original_plotter = check_output(["git", "show", f"{COMMIT}:{PLOTTER}"], cwd=REPO)
    assert (REPO / PLOTTER).read_bytes() == original_plotter

    for name, expected in fixture["frozen"].items():
        assert digest((DSI / name).read_bytes()) == expected
        if name != "Stage.py":
            freeze(DSI / name, HERE / name)
    for name, info in source_manifest.items():
        assert digest((DSI / "Production" / name).read_bytes()) == info["sha256"]

    write_code(HERE / READER, reader_code())
    write_code(HERE / PLOTTER, plotter_code(original_plotter))
    write_code(HERE / TEST, test_code())
    assert "If data.RetainedSteelLimitUnresolved Then" in (HERE / PLOTTER).read_text(encoding="utf-8")
    for name in (READER, PLOTTER):
        freeze(HERE / name, HERE / "Production" / name)
    overlay = {
        "base_fixture_sha256": DSI_SHA,
        "production_overlay": {
            READER: {
                "base_sha256": source_manifest[READER]["sha256"],
                "sha256": digest((HERE / READER).read_bytes()),
            },
            PLOTTER: {
                "base_sha256": digest(original_plotter),
                "sha256": digest((HERE / PLOTTER).read_bytes()),
            },
        },
        "test_probe": {TEST: digest((HERE / TEST).read_bytes())},
    }
    (HERE / "Production/PlotOverlay.json").write_text(json.dumps(overlay, indent=2)+"\n", encoding="utf-8")
    runner = (HERE / "Run.ps1").read_text(encoding="utf-8")
    runner = once(runner, "'Fallback','Mixed','Excel','File','HardShear','Equilibrium','All','Compile'", "'Excel','File','All','Compile'")
    runner = once(runner, "@('Equilibrium','Fallback','Mixed','Excel','File','HardShear')", "@('Excel','File')")
    runner = once(runner, "Get-Content -LiteralPath 'Production/ProductionManifest.json' -Raw | ConvertFrom-Json",
                  "Get-Content -LiteralPath 'Production/PlotOverlay.json' -Raw | ConvertFrom-Json")
    runner = once(runner, "$production.production_files.PSObject.Properties", "$production.production_overlay.PSObject.Properties")
    runner = once(runner, "'-TimeoutSeconds',185", "'-TimeoutSeconds',210")
    (HERE / "Run.ps1").write_text(runner, encoding="utf-8", newline="\n")
    validator = (HERE / "Verify-Compat.py").read_text(encoding="utf-8")
    validator = once(
        validator,
        "    assert 'TOTAL_COUPLED_RETAINED_SNAPSHOT: passed=42; failed=0' in raw",
        "    assert 'TOTAL_COUPLED_RETAINED_SNAPSHOT: passed=44; failed=0' in raw\n"
        "    assert f'OK: {check} Excel chart distinguishes retained equilibrium and steel uncertainty' in raw\n"
        "    assert f'OK: {check} Excel chart keeps the genuine no-field geometry note' in raw",
    )
    (HERE / "Verify-Compat.py").write_text(validator, encoding="utf-8", newline="\n")
    for name in ("Native", "Temp", "docs/regression"):
        (HERE / name).mkdir(parents=True, exist_ok=True)
    freeze(HERE / BOOK, HERE / "docs/regression/Diagnostic.xlsm")
    fixture["modules"].append(Path(PLOTTER).stem)
    fixture["modules"].sort()
    fixture["base_dsi_fixture_sha256"] = DSI_SHA
    names = (*fixture["frozen"], "Production/PlotOverlay.json", PLOTTER, "ChartTest.txt")
    fixture["frozen"] = {name: digest((HERE / name).read_bytes()) for name in names}
    (HERE / "Fixture.json").write_text(json.dumps(fixture, indent=2)+"\n", encoding="utf-8")
    print("PLOT_FIXTURE", digest((HERE / "Fixture.json").read_bytes()))
    print("PLOT_OVERLAY", digest((HERE / "Production/PlotOverlay.json").read_bytes()))
    print(json.dumps(overlay, indent=2))


if __name__ == "__main__":
    stage()
