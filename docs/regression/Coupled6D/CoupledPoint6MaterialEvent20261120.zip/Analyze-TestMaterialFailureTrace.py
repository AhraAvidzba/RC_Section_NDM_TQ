"""ДЛЯ ТЕСТОВ. Локализует нелинейный дефект точечного материала по точным двоичным откликам и исходным операторам."""
from argparse import ArgumentParser
from hashlib import sha256
import json,struct
from pathlib import Path
from runpy import run_path
import numpy as np


def TestAnalyze(root,output=None):
    """Различает материальное переключение, изменение подшагов и физический предел; исходную историю проверяет отдельно."""
    here=Path(__file__).resolve().parent
    result=json.loads((root/'Native/ExternalResult.json').read_bytes())
    owner=json.loads((root/'Native/ExternalOwnership.json').read_bytes())
    assert result['outcome']=='ReadOnlyMaterialTrace;NotCapacity'
    assert result['source_unchanged'] and result['owned_excel_final_state']['state']=='Exited'
    assert result['owned_excel_final_state']['filetime']==owner['filetime']
    assert result['accepted_revision_unchanged_during_all_reads'] and result['all_available_before_after_responses_bits_equal']
    raw=(root/'Input/PointTraceFields.bin').read_bytes();count,size=struct.unpack_from('<ii',raw)
    assert size==61 and len(raw)==8+8*count*size
    fields=np.frombuffer(raw,dtype='<f8',offset=8).reshape(count,size)
    names=json.loads((root/'Input/PointTraceNames.json').read_bytes());assert len(names)==count==12
    seed_raw=(root/'Input/ExternalSeed.bin').read_bytes();assert struct.unpack_from('<i',seed_raw)[0]==61
    seed=np.frombuffer(seed_raw,dtype='<f8',offset=4);scales=np.asarray(result['unknown_scales'],float)
    frames={};residuals={};mapped_fields={}
    for i,frame in enumerate(result['frames']):
        assert frame['name']==names[i] and not frame['errors']
        arrays={}
        for kind,pin in frame['files'].items():
            data=(root/pin['file']).read_bytes();assert sha256(data).hexdigest().upper()==pin['sha256']
            arrays[kind]=np.frombuffer(data,dtype='<f8').reshape(pin['shape'])
        p=arrays['Points'];assert p.shape==(129,30)
        assert np.array_equal(p[:,0],np.repeat(np.arange(1,44),3)) and np.array_equal(p[:,1],np.tile([-1,0,1],43))
        mapped=seed+scales*arrays['Coordinates']
        np.testing.assert_allclose(mapped,fields[i],rtol=1e-14,atol=1e-300)
        frames[names[i]]=p;residuals[names[i]]=arrays['Residual'];mapped_fields[names[i]]=mapped
    base=frames['TRF100'];mask=base[:,0]<=25
    assert all(np.array_equal(p[:,20:30],base[:,20:30]) for p in frames.values())
    assert all(np.all(p[mask,16]==(0 if name=='Accepted200' else 1)) for name,p in frames.items())
    operators=run_path(str(here/'Check-TestHardHalfSteps.py'))['TestOperators']
    geometry,load,w,v,coords,axis,b,slope=operators(root/'Native/EnvelopeEnergy.Operators.csv',60,43)
    strain_error=0.;strain_bound=0.
    for name,p in frames.items():
        physical=mapped_fields[name][:60]
        tensor=np.einsum('pcd,d->pc',b,physical);gradient=np.einsum('pcd,d->pc',slope,physical)
        expected=np.transpose(np.asarray([tensor+s*.001*gradient for s in (-1,0,1)]),(1,0,2)).reshape(129,6)
        # Операторы CSV имеют 15 значащих цифр CStr; оценка учитывает округление коэффициентов и сумму до 60 слагаемых.
        absolute=np.einsum('pcd,d->pc',abs(b),abs(physical));absolute_gradient=np.einsum('pcd,d->pc',abs(slope),abs(physical))
        absolute=np.transpose(np.asarray([absolute+abs(s)*.001*absolute_gradient for s in (-1,0,1)]),(1,0,2)).reshape(129,6)
        bound=(1e-14+128*np.finfo(float).eps)*absolute
        error=abs(p[:,2:8]-expected)
        assert np.all(error<=bound), (name,float(np.max(error-bound)))
        strain_error=max(strain_error,float(np.max(error)));strain_bound=max(strain_bound,float(np.max(bound)))
    helpers=run_path(str(here/'Validate-TestHardPrepared.py'))
    accepted_proof,accepted_fields=helpers['TestValidate'](root,'EnvelopeEnergy.Accepted')
    assert len(accepted_fields)==200
    original=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary'](root/'Input/Reverse1.bin')
    modulus,poisson=original['calibration'][:2];lame=modulus*poisson/((1+poisson)*(1-2*poisson));shear=modulus/(2*(1+poisson))
    elastic=np.zeros((6,6));elastic[:3,:3]=lame
    for i in range(3):elastic[i,i]+=2*shear;elastic[i+3,i+3]=shear
    yield_error=0.
    for p in frames.values():
        effective=(p[:,2:8]-p[:,22:28])@elastic.T
        tensor=np.zeros((129,3,3))
        for i in range(3):tensor[:,i,i]=effective[:,i]
        for k,(i,j) in enumerate(((0,1),(0,2),(1,2))):tensor[:,i,j]=tensor[:,j,i]=effective[:,k+3]
        high=np.linalg.eigvalsh(tensor)[:,-1];trace=np.sum(effective[:,:3],axis=1)
        dev=effective.copy();dev[:,:3]-=trace[:,None]/3
        q=np.sqrt(1.5*(np.sum(dev[:,:3]**2,axis=1)+2*np.sum(dev[:,3:]**2,axis=1)))
        alpha,gamma,cc,ct=p[:,20],p[:,21],p[:,28],p[:,29]
        principal=np.where(high>0,(cc/ct*(1-alpha)-(1+alpha))*high,gamma*high)
        independent=(alpha*trace+q+principal)/(1-alpha)-cc
        yield_error=max(yield_error,float(max(abs(independent-p[:,17]))))
    assert yield_error<1e-10,yield_error
    concrete=25;signs=np.r_[np.ones(concrete),-np.ones(43-concrete)]
    minus,plus=frames['TRF100Column1Minus'],frames['TRF100Column1Plus']
    defect=(plus[:,8:14]+minus[:,8:14]-2*base[:,8:14]).reshape(43,3,6).transpose(1,0,2)
    contributions=np.zeros((3,43,60))
    contributions[1]=np.einsum('pcd,pc,p->pd',w,defect[1],signs)
    contributions[2]=np.einsum('pcd,pc,p->pd',v,defect[2],signs)/.002
    contributions[0]=-np.einsum('pcd,pc,p->pd',v,defect[0],signs)/.002
    reconstructed=contributions.sum(axis=(0,1));reconstructed[56:]*=30000
    actual=residuals['TRF100Column1Plus']+residuals['TRF100Column1Minus']-2*residuals['TRF100']
    error=float(max(abs(reconstructed-actual[:60])))
    assert error<1e-9,error
    ranking=[]
    for side in range(3):
        for point in range(43):
            value=contributions[side,point].copy();value[56:]*=30000
            ranking.append(dict(point=point+1,side=side-1,maximum_residual_defect_MPa=float(max(abs(value))),
                dominant_row=int(np.argmax(abs(value)))+1))
    ranking.sort(key=lambda x:x['maximum_residual_defect_MPa'],reverse=True)
    assert ranking[0]['point']==6 and ranking[0]['side']==-1
    switches={}
    for name,p in frames.items():
        changed=np.flatnonzero(np.any(p[:,14:17]!=base[:,14:17],axis=1)&mask)
        switches[name]=[dict(point=int(p[j,0]),side=int(p[j,1]),before=base[j,14:17].tolist(),after=p[j,14:17].tolist()) for j in changed]
    assert switches['TRF100Column1Minus']==[]
    assert switches['TRF100Column1Plus']==[dict(point=6,side=-1,before=[0.,1.,1.],after=[1.,1.,1.])]
    tolerance=result['context_metadata'][3]
    assert max(abs(residuals['Accepted200'][:60]))<=tolerance and max(abs(residuals['HalfH'][:60]))<=tolerance
    result_proof=dict(accepted_history_independent_equilibrium=accepted_proof,
        all_12_frames_available=True,all_readonly_material_histories_identical=True,
        concrete_substeps_near_failure_always_one=True,substep_change_hypothesis_rejected=True,
        stencil_defect_reconstruction_error_MPa=error,maximum_actual_stencil_defect_MPa=float(max(abs(actual[:60]))),
        strain_reconstruction_error=strain_error,CSV_and_sum_strain_bound=strain_bound,
        maximum_independent_trial_yield_error_MPa=yield_error,
        strongest_point_station_contributions=ranking[:6],branch_switches=switches,
        selected_point6_trial_yield_MPa={name:float(p[(p[:,0]==6)&(p[:,1]==-1),17][0]) for name,p in frames.items()},
        own_excel_closed=True,physical_capacity_certified=False,material_switch_not_proof_of_failure=True,
        independent_material_reintegration=False)
    if output is not None:output.write_bytes((json.dumps(result_proof,sort_keys=True,indent=2)+'\n').encode())
    return result_proof


if __name__=='__main__':
    p=ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();r=TestAnalyze(a.root.resolve(),a.out.resolve())
    print('MATERIAL FAILURE TRACE VERIFIED; SUBSTEPS UNCHANGED; DOMINANT POINT',r['strongest_point_station_contributions'][0])
