"""ДЛЯ ТЕСТОВ. Проверяет штатные численные методы от точного лучшего поля TRF при неизменной принятой истории."""
from argparse import ArgumentParser
from hashlib import sha256
import json,re,struct
from pathlib import Path
from runpy import run_path


def TestStage(root,parent,seed_source):
    """Внешнее поле служит только начальным приближением; все пробы решает VBA и отдельно проверяет исходными критериями."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingControllerResume.py'))['TestStage'](root,parent)
    prep=json.loads((root/'Preparation.json').read_bytes())
    result=json.loads((seed_source/'Native/ExternalResult.json').read_bytes())
    assert result['owned_excel_final_state']['state']=='Exited' and not result['native_verification'][0]
    raw=(seed_source/'Native/ExternalNativeResult.bin').read_bytes();values=struct.unpack('<72d',raw)
    assert list(values)==result['native_verification']+result['field']
    for name,data in {'Input/EnvelopeInitialSeed.bin':struct.pack('<i61d',61,*values[12:],values[4]),
        'Input/EnvelopeFailureLevel.bin':(seed_source/'Input/EnvelopeFailureLevel.bin').read_bytes(),
        'Input/EnvelopeDifferenceOptions.bin':struct.pack('<i12d',12,1e-6,1.,1.,1e-5,1.,1.,1e-4,1.,1.,1e-5,0.,1.)}.items():
        (root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
    name='tests/modTestCoupledElasticState.bas'
    original=(parent/name).read_text('utf-8-sig')
    body=re.search(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',original)[0]
    anchor='    Dim caseIndex As Long, offset As Long';pos=body.index(anchor)
    body=body[:pos]+'''    Dim seedHandleTest As Integer: seedHandleTest = FreeFile
    Open mPolishRootTest & "\\Input\\EnvelopeInitialSeed.bin" For Binary Access Read As #seedHandleTest
    Dim seedInputTest As Variant: seedInputTest = TestReadPolishVector(seedHandleTest)
    If Seek(seedHandleTest) <> LOF(seedHandleTest) + 1 Or UBound(seedInputTest) <> 61 Then Err.Raise 5, , "Неверный размер начального поля численного повтора."
    Close #seedHandleTest
    For degree = 1 To mReverseOperatorsTest.DegreeCount: seed(degree) = seedInputTest(degree): Next degree
'''+body[pos:]
    anchor='projection, coordinate, seed, factor + predictorRatioTest * (factor - previousFactor))';assert body.count(anchor)==1
    body=body.replace(anchor,'projection, coordinate, seed, CDbl(seedInputTest(61)))',1)
    code=(root/name).read_text('utf-8-sig')
    code,n=re.subn(r'(?ms)^Private Sub TestIntegratedYieldEvent\(\).*?^End Sub',lambda _:body,code);assert n==1
    methods=re.findall(r'(?im)^(?:Public|Private|Friend) (?:Function|Sub) (\w+)',code)
    assert len(methods)==len(set(v.lower() for v in methods)) and max(map(len,code.splitlines()))<1024
    (root/name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'));prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    origin=dict(source=seed_source.name,source_native_result_sha256=sha256(raw).hexdigest().upper(),
        seed_exact_Double=True,accepted_history_unchanged=True,physical_failure=False)
    name='Input/ExactSeedOrigin.json';(root/name).write_bytes((json.dumps(origin,sort_keys=True,indent=2)+'\n').encode());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='NativeEnvelopeFromExactTRFSeed',actual_import_this_pass=['modTestCoupledElasticState'],
        source_classes_unchanged=True,target_from_TRF_diagnostic=True,requested_H_from_actual_failure=None,
        target_H_MPa=struct.unpack('<id',(root/'Input/EnvelopeFailureLevel.bin').read_bytes())[1],
        native_seed_from_external_solver_not_material_history=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,sort_keys=True,indent=2)+'\n').encode())
    print('NATIVE H FROM EXACT TRF SEED READY; FOUR VARIANTS; MATERIAL HISTORY UNCHANGED')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent','seed-source'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve(),a.seed_source.resolve())
