"""ДЛЯ ТЕСТОВ. Снимает бетонные пробные отклики около реальной остановки H без изменения принятой истории."""
from argparse import ArgumentParser
from hashlib import sha256
import csv,json,struct
from pathlib import Path
from runpy import run_path
import numpy as np


def TestStage(root,parent,homotopy,restart):
    """Переиспользует неизменную компиляцию с читающим интерфейсом; каждое заданное поле остаётся диагностической пробой."""
    here=Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestEnergyNumerics.py'))['TestClone'](root,parent,1e-6,1,.001,0)
    prep=json.loads((root/'Preparation.json').read_bytes())
    read=run_path(str(here/'Check-TestActualReverseCapture.py'))['TestReadBinary']
    original=read(root/'Input/Reverse1.bin')
    rows=list(csv.reader((homotopy/'Native/IntegratedEvent.csv').read_text('cp1251').splitlines(),delimiter=';'))
    names=['Accepted200','HalfH','FailedThreeQuarterH']
    fields=[np.r_[original['fields'][-1],original['lambdas'][-1]]]
    for index in (3,4):
        field=next(np.asarray(r[2:],float) for r in rows if r[0]=='FIELD' and int(r[1])==index)
        factor=next(float(r[2]) for r in rows if r[0]=='BEST' and int(r[1])==index)
        fields.append(np.r_[field,factor])
    result=json.loads((restart/'Native/ExternalResult.json').read_bytes())
    raw=(restart/'Native/ExternalNativeResult.bin').read_bytes();native=np.frombuffer(raw,dtype='<f8')
    assert native.shape==(72,) and native.tolist()==result['native_verification']+result['field']
    current=np.r_[native[12:],native[4]];scales=np.asarray(result['unknown_scales'],float)
    x=np.asarray(result['coordinates'],float);delta=1e-6*(1+abs(x[0]))
    for label,sign in (('TRF100Column1Minus',-1),('TRF100Column1Plus',1)):
        point=current.copy();point[0]+=sign*scales[0]*delta;names.append(label);fields.append(point)
    matrix=np.asarray(result['jacobian'],float);residual=np.asarray(result['residual_MPa'],float)
    direction=np.linalg.lstsq(matrix,-residual,rcond=None)[0]
    for exponent in (0,4,8,12,16,20):
        names.append('TRF100NewtonHalf'+str(exponent))
        fields.append(current+(2.**(-exponent))*scales*direction)
    names.append('TRF100');fields.append(current)
    fields=np.asarray(fields,float);assert fields.shape==(len(names),61) and np.all(np.isfinite(fields))
    contents={'Input/PointTraceFields.bin':struct.pack('<ii',len(names),61)+fields.astype('<f8').tobytes(),
        'Input/PointTraceNames.json':(json.dumps(names,indent=2)+'\n').encode(),
        'Input/PointTraceOrigins.json':(json.dumps(dict(accepted200_exact_Double=True,half_and_failed_fields_decimal_reconstructed=True,
            final_TRF_field_exact_Double=True,TRF_native_result_sha256=sha256(raw).hexdigest().upper(),
            Newton_direction_is_not_equilibrium=True,material_history_unchanged=True),sort_keys=True,indent=2)+'\n').encode()}
    for name,data in contents.items():(root/name).write_bytes(data);prep['inputs'][name]=sha256(data).hexdigest().upper()
    runner=(here/'Run-TestExternalEnvelope.py').read_text('utf-8-sig')
    begin=runner.index("        result['context_open_attempts']=[]")
    end=runner.index('    except Exception as error:',begin)
    body='''        meta=np.asarray(excel.Run(prefix+'TestOpenExternalEnvelope',float(fraction),int(seed_kind)),float).ravel()
        assert meta.shape==(11,) and int(meta[0])==61
        scales=np.asarray(excel.Run(prefix+'TestExternalEnvelopeScales'),float).ravel()
        raw=(root/'Input/ExternalSeed.bin').read_bytes()
        assert struct.unpack_from('<i',raw)[0]==61
        origin=np.frombuffer(raw,dtype='<f8',offset=4)
        raw=(root/'Input/PointTraceFields.bin').read_bytes();count,n=struct.unpack_from('<ii',raw)
        assert n==61 and len(raw)==8+8*count*n
        fields=np.frombuffer(raw,dtype='<f8',offset=8).reshape(count,n)
        names=json.loads((root/'Input/PointTraceNames.json').read_bytes());assert len(names)==count
        result['context_metadata']=meta.tolist();result['unknown_scales']=scales.tolist();result['frames']=[]
        for index,(name,field) in enumerate(zip(names,fields),1):
            x=(field-origin)/scales
            argument=win32com.client.VARIANT(pythoncom.VT_ARRAY|pythoncom.VT_R8,tuple(float(v) for v in x))
            errors={};before=points=after=None
            try:before=np.asarray(excel.Run(prefix+'TestEvaluateExternalEnvelope',argument),float).ravel()
            except pywintypes.com_error as error:errors['before']=str(error)
            try:points=np.asarray(excel.Run(prefix+'TestReadExternalPointTrace',argument),float)
            except pywintypes.com_error as error:errors['points']=str(error)
            try:after=np.asarray(excel.Run(prefix+'TestEvaluateExternalEnvelope',argument),float).ravel()
            except pywintypes.com_error as error:errors['after']=str(error)
            if before is not None and after is not None:
                assert before.shape==after.shape==(61,) and np.all(np.isfinite(before))
                assert np.array_equal(before,after),'Point diagnostics changed the native response'
            if points is not None:assert points.shape==(129,30) and np.all(np.isfinite(points))
            stem='MaterialFrame%02d'%index
            paths={}
            for suffix,values in (('Coordinates',x),('Residual',before),('Points',points)):
                if values is None:continue
                file='Native/'+stem+'.'+suffix+'.bin';data=np.asarray(values,dtype='<f8').tobytes()
                (root/file).write_bytes(data);paths[suffix]=dict(file=file,shape=list(values.shape),sha256=sha256(data).hexdigest().upper())
            maximum=float(max(abs(before))) if before is not None else None
            result['frames'].append(dict(name=name,files=paths,max_residual_MPa=maximum,errors=errors))
            TestWrite(root/'Native/MaterialTraceProgress.json',dict(frames=result['frames'],accepted_revision=meta[10],physical_failure=False))
            print('MATERIAL_FRAME',index,name,'MAX_MPa',maximum,'ERRORS',list(errors),flush=True)
        assert names[-1]=='TRF100'
        native=np.asarray(excel.Run(prefix+'TestFinishExternalEnvelope',argument),float).ravel()
        assert native.shape==(72,) and native[0]==0 and native[11]==meta[10]
        (root/'Native/MaterialTraceFinal.bin').write_bytes(native.astype('<f8').tobytes())
        result['native_final_check']=native[:12].tolist()
        result['accepted_revision_unchanged_during_all_reads']=True
        result['all_available_before_after_responses_bits_equal']=True
        result['outcome']='ReadOnlyMaterialTrace;NotCapacity'
'''
    runner=runner[:begin]+body+runner[end:]
    name='Run-TestMaterialFailureTrace.py';(root/name).write_bytes(runner.encode());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    name=Path(__file__).name;(root/name).write_bytes(Path(__file__).read_bytes());prep['inputs'][name]=sha256((root/name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='ReadOnlyMaterialFailureTrace200',fresh_compilation_claimed=False,actual_import_this_pass=[],
        source_classes_unchanged=True,frames=names,accepted_material_history_unchanged=True,physical_capacity_certified=False)
    (root/'Preparation.json').write_bytes((json.dumps(prep,indent=2,sort_keys=True)+'\n').encode())
    print('MATERIAL FAILURE TRACE READY;',len(names),'FRAMES; SAME COMPILED WORKING H')


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    for name in ('root','parent','homotopy','restart'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();TestStage(a.root.resolve(),a.parent.resolve(),a.homotopy.resolve(),a.restart.resolve())
