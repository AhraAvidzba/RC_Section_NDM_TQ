"""Branch-selected correction from measured one-sided actions and a fresh base matrix."""
from pathlib import Path
from hashlib import sha256
import itertools,json,runpy
import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
NATIVE=HERE.parent/'KaniPracticalProbe45/PortableReplayed'
data=runpy.run_path(NATIVE/'Verify.py')
y=json.loads((NATIVE/'Verification.json').read_text(encoding='utf8')); plan=json.loads((NATIVE/'ProbePlan.json').read_text(encoding='utf8'))
with np.load(NATIVE/'MeasuredSamples.npz',allow_pickle=False) as d:
    stations,_=data['computed'](d,y); E=d['Refined_rows'][83:]; bproj=d['resultant_projection']; target=d['projection']
    fresh={k:np.vstack((d[k+'_rows'][:83],bproj@d[k+'_rows'][:83])) for k in ('Stock','Refined')}
B=np.load(HERE.parent/'KaniV4Rebase3/RebasedLinearSystems.npz',allow_pickle=False)['strain_matrix'].reshape(-1,88)
anchor=stations['BaseAccepted']; r=anchor['r']; tau=anchor['tau']; fields=np.r_[anchor['field'][2:],anchor['field'][0]]
names=list(plan['dirs']); directions=np.array([plan['dirs'][k] for k in names]).T
physical=B@directions
metric=np.linalg.solve(physical.T@physical,physical.T@B)
perp=B-physical@metric; assert np.max(abs(metric@directions-np.eye(3)))<1e-12

def measured(branch,level):
    actions=[]
    for axis,sign in zip(names,branch):
        col=axis+level+sign
        rec=plan['probes'][col]; h=rec['radius']*rec['sign']
        actions.append(np.array(y['probeDiagnostics'][col]['signedActualDeltaAll89_MPa'])/h)
    return np.column_stack(actions)

# Guard every candidate on both stock/refined bases with both earlier calibration radii.
# Use independent material tests at other sizes for the signed matching inputs.
def solve(force_N,cap,off,correct=True):
    best=None
    x_scale=np.r_[np.full(83,cap),np.full(4,1.e-5),1.e-5]
    ph=B*x_scale/cap; complement=perp*x_scale/off
    st=np.r_[x_scale[-1]*1e5]; desired=force_N
    condition=np.vstack((E[:4]*x_scale,np.eye(88)[-1]*x_scale[-1]*1e5)); condition/=np.max(abs(condition),axis=1)[:,None]
    rhs0=np.r_[np.zeros(4),desired/st[0]]
    Aeq=np.c_[condition,np.zeros(5)]
    for sign in itertools.product(('Minus','Plus'),repeat=3):
        orient=np.array([1 if s=='Plus' else -1 for s in sign]); side=-(orient[:,None]*metric*x_scale/cap)
        ops={}
        for mode,m in fresh.items():
            for level in ('01','25'):
                ops[(mode,level)]=m+(measured(sign,level)-m@directions)@metric if correct else m
        U=[np.c_[v,np.zeros(len(v))] for v in (ph,-ph,complement,-complement,side)]
        constants=[np.ones(len(v)) for v in (ph,-ph,complement,-complement)]+[np.zeros(3)]
        for j in ops.values():
            op=j*x_scale/tau
            U+=[np.c_[op,-np.ones(len(op))],np.c_[-op,-np.ones(len(op))]]
            constants.extend([-r/tau,r/tau])
        res=linprog(np.r_[np.zeros(88),1.],np.vstack(U),np.concatenate(constants),Aeq,rhs0,bounds=[(-20,20)]*87+[(-200,200),(0,None)],method='highs')
        if not res.success: continue
        d=res.x[:88]*x_scale; predict=lambda J:float(np.max(abs(r+J@d)))
        if best is None or res.fun*tau<best['bestNorm_MPa']:
            best={'bestNorm_MPa':res.fun*tau,'sign':dict(zip(names,sign)),'deltaQy_N':float(d[-1]*1e5),
                  'deltaGamma':float(target@d[:87]),'maxStrain':float(np.max(abs(B@d))),
                  'complementMaxStrain':float(np.max(abs(perp@d))), 'signProjections':dict(zip(names,metric@d)),
                  'withheldLargerRadiusNorm_MPa':{mode:predict(m+(measured(sign,'50')-m@directions)@metric) for mode,m in fresh.items()},
                  'calibratedNorm_MPa':{'/'.join(mode):predict(J) for mode,J in ops.items()},
                  'rawIncrement':d.tolist(),'newField':(fields+d).tolist()}
    return best

cases={}
for target_n in (.02,.04,.1,1.,18.):
    c=2e-9 if target_n<=.1 else 5e-8; e=2e-12 if target_n<=.1 else 3e-11
    cases[str(target_n)]={'measured':solve(target_n,c,e),'freshRaw':solve(target_n,c,e,False),'cap':c,'complementCap':e}
    print(target_n,[(k,None if not v else [v['bestNorm_MPa'], list(v['withheldLargerRadiusNorm_MPa'].values())]) for k,v in cases[str(target_n)].items() if k in ('measured','freshRaw')],flush=True)
cert={'purpose':'Calibrate selected one-sided actions in measured strain span. Constrain unfitted strain complement and projected signs. No material or acceptance change.',
      'tolerance_MPa':tau,'onModelOnly':True,'cases':cases}
path=HERE/'OneSidedCorrectionPlan.json'; path.write_text(json.dumps(cert,indent=2)+'\n',encoding='utf8')
print(path,sha256(path.read_bytes()).hexdigest().upper())
