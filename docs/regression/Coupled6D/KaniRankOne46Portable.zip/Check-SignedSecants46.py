"""Check same-sign one-sided force secants on measured, withheld radii."""
from pathlib import Path
import json
from hashlib import sha256
import numpy as np

H=Path(__file__).resolve().parent
S=H.parent/'KaniPracticalProbe45'
w=json.loads((S/'Verification.json').read_text(encoding='utf8')); p=json.loads((S/'ProbePlan.json').read_text(encoding='utf8'))
d=w['probeDiagnostics']; pairs=w['signedPairs']; pk=lambda x:float(np.max(abs(x)))
checks={}; models=('Stock','Refined')

def delta(case): return np.array(d[case]['signedActualDeltaAll89_MPa'])

def triangle(train,test):
    k=pairs[test]['radius']/pairs[train]['radius']; result={}
    for sign in ('Plus','Minus'):
        opposite='Minus' if sign=='Plus' else 'Plus'
        true=delta(test+sign); matched=k*delta(train+sign); opposite_predict=-k*delta(train+opposite)
        centered=.5*(matched+opposite_predict)
        target=d[test+sign]['freshMatrixErrors_MPa']; old_errors=d[test+sign]['archivedMatrixErrors_MPa']
        result[sign]={'maxSameSignError_MPa':pk(true-matched),'maxOppositeSignError_MPa':pk(true-opposite_predict),
            'maxCenteredAtSameRadiusError_MPa':pk(true-centered),'freshErrors_MPa':target,
            'bestArchivedError_MPa':min(old_errors.values()),'weak81SameSignError_MPa':float(true[80]-matched[80]),
            'weak81OppositeSignError_MPa':float(true[80]-opposite_predict[80]),
            'weak81Actual_MPa':float(true[80]),'sameSignRatio_vsFreshRefined':pk(true-matched)/target['Refined']}
    return result

for direction in p['dirs']:
    t=(('01','25'),('01','50'),('25','50'))
    if direction=='LoadShape': t+=(('00','01'),('01','18'),('25','18'),('50','18'))
    checks[direction]={f'{x}to{y}':triangle(direction+x,direction+y) for x,y in t}
ans={'purpose':'Measured signed derivative actions at frozen accepted H43→19/512, no changes to material, strokes, force tolerance or Excel history.',
    'checks':checks,'allHeldOutRadii':True}
out=H/'SignedSecantValidation.json'; out.write_text(json.dumps(ans,indent=2)+'\n',encoding='utf8')
print(out,sha256(out.read_bytes()).hexdigest().upper())
for k,v in checks.items():
    print(k)
    for pair,axes in v.items(): print(pair,[(a,e['maxSameSignError_MPa'],e['maxCenteredAtSameRadiusError_MPa'],e['freshErrors_MPa']['Refined'],e['weak81SameSignError_MPa'],e['sameSignRatio_vsFreshRefined']) for a,e in axes.items()])
