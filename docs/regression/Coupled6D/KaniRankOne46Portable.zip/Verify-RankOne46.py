"""Independently check both native A/B one-step probes and frozen energy history."""
from pathlib import Path
import csv,json,runpy

H=Path(__file__).resolve().parent; root=H.parent
P=runpy.run_path(H/'Prepare-RankOne46.py'); O=runpy.run_path(root/'KaniWarpBeyond43/Check-KaniBeyond43.py')
np=O['np']; pk=O['peak']; sha=P['sha']; section=O['section']


def verify():
    prep=P['check'](); native=H/'Native'; a,f,projection,tensors,hashes=O['trs'](H)
    archive=O['trs'](root/'KaniPracticalProbe45')
    plan=json.loads((H/'RankOneComparisonPlan.json').read_text(encoding='utf8'))
    closure=json.loads((native/'KaniV4.txt.ProcessClosure.json').read_text(encoding='utf-8-sig'))
    owner=json.loads((native/'KaniV4.txt.Ownership.json').read_text(encoding='utf-8-sig'))
    stop=closure['Closure']['FinalState']; compile_stop=json.loads((native/'CompileClosure.json').read_text(encoding='utf-8-sig'))
    compile_program=json.loads((H/'docs/regression/CodeUpdate.json').read_text(encoding='utf-8-sig'))
    assert projection.shape==(87,) and np.array_equal(projection,archive[2]); assert closure['Passed'] and closure['ChildExitCode']==0
    assert stop['State']==compile_stop['State']=='Absent' and owner['VerifiedNewOwner']
    assert stop['PID']==owner['PID'] and stop['StartTicksUTC']==owner['StartTicksUTC']
    assert compile_program['Compiled'] and not compile_program['ProductionChanged'] and compile_program['ProductionSHA256']==prep['workbook_sha256']
    assert compile_program['WorkbookSHA256']==sha(H/P['SHADOW']) and sorted(compile_program['Modules'])==['CCoupledElasticState','CCoupledNewtonSolver','modTestKaniStage38']
    report=(native/'KaniV4.txt').read_text(encoding='utf-8-sig')
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    history=('Original43','BaseAccepted','EndAccepted','Restore43')
    energy={label:np.full((3,184,2),np.nan) for label in history}
    yield_tags={'BaseAccepted','EndAccepted','LoadShape00Plus','LoadShape00Minus',*(a for a in a if a.startswith(('SignedRankOne','FreshUncorrected')) and not a.endswith('/Admitted'))}
    criterion={label:np.full((3,184),np.nan) for label in yield_tags}
    sig={tag:np.full((3,184,3),-10,dtype=int) for tag in a}
    for kind,label,pt,side,*parts in csv.reader((native/'KaniV4Tangents.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        i=int(side)+1; j=int(pt)-1; assert 0<=i<3 and 0<=j<184
        if kind=='ENERGY':
            assert np.isnan(energy[label][i,j]).all() and len(parts)==2
            energy[label][i,j]=list(map(float,parts))
        elif kind=='YIELD':
            assert np.isnan(criterion[label][i,j]) and len(parts)==1
            criterion[label][i,j]=float(parts[0])
        else:
            assert kind=='BRANCH' and sig[label][i,j,0]==-10 and len(parts)==3
            sig[label][i,j]=list(map(int,parts))
    assert all(np.isfinite(g).all() and g.min()>=0 for g in energy.values())
    assert all((g[:,:,0]>=0).all() for g in sig.values())
    assert all(np.isfinite(v).all() for v in criterion.values()) and np.array_equal(criterion['BaseAccepted'],criterion['EndAccepted'])
    tiny_both=(sig['LoadShape00Minus'][:,:,0]==1)&(sig['LoadShape00Plus'][:,:,0]==1)
    assert int(tiny_both.sum())==59
    for label in ('LoadShape00Minus','LoadShape00Plus'):
        assert np.array_equal(f[label],archive[1][label])
        assert pk(tensors[label]-archive[3][label])<2e-10
    f0=criterion['BaseAccepted']
    tiny_details={'bothPlasticCount':int(tiny_both.sum()),'F0_at_bothPlastic_range_MPa':[float(f0[tiny_both].min()),float(f0[tiny_both].max())],
                  'F0_at_bothPlastic_positiveCount':int(np.count_nonzero(f0[tiny_both]>0)),
                  'F_both_signs_positive_on_bothPlastic':int(np.count_nonzero(tiny_both&(criterion['LoadShape00Minus']>0)&(criterion['LoadShape00Plus']>0)))}
    for before,after in (('Original43','Restore43'),('BaseAccepted','EndAccepted')):
        assert np.array_equal(energy[before],energy[after]) and np.array_equal(sig[before],sig[after])
        assert np.array_equal(f[before],f[after]) and np.array_equal(tensors[before],tensors[after])
        assert np.array_equal(f[before],archive[1][before]) and pk(tensors[before]-archive[3][before])<2e-10
    entries={}
    for item in csv.reader((native/'KaniV4Trace.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        if item[0]=='OUTCOME':
            _,l,ok,exact=item; assert l not in entries; entries[l]=(bool(int(ok)),bool(int(exact)))
    assert set(entries)=={m+l for m in ('FreshUncorrected','SignedRankOne') for l in ('Signal','Near')}
    base_gamma=f['BaseAccepted'][1]; base_lambda=f['BaseAccepted'][0]; base_tensor=tensors['BaseAccepted']
    independent=O['independent']((a,f,projection,tensors,hashes),'BaseAccepted')
    gbase=energy['BaseAccepted']; gOrig=energy['Original43']; diff=gbase-gOrig
    # Energy changes are for committed states. They are not trial plastic branch flags.
    assert diff.min()>-1e-10
    result={}
    for label,record in plan['frozenPairs'].items():
        A='FreshUncorrected'+label; B='SignedRankOne'+label
        assert np.array_equal(f[A][:2],f[B][:2])
        assert abs((f[A][0]-base_lambda)*1e5-record['load_increment_N'])<1e-8
        assert abs(f[A][1]-base_gamma-record['gammaIncrement'])<1e-16
        result[label]={'prescribedLoad_N':float(f[A][0]*1e5),'commonGamma':float(f[A][1])}
        for method in ('FreshUncorrected','SignedRankOne'):
            tag=method+label; q=f[tag]; accepted,exact=entries[tag]; tol=float(a[tag][3]);
            rows=O['independent']((a,f,projection,tensors,hashes),tag); assert len(rows)==89
            gauges=np.r_[25600*section.gauges@q[2:81],25600*(projection@q[2:]-q[1])];
            assert len(gauges)==5 and pk(gauges)<5e-11
            expect=record[method]['literalField']; assert pk(q[2:]-np.array(expect[:-1]))<3e-16 and abs(q[0]-expect[-1])<1e-14
            peak=pk(rows); assert (peak<=tol+1e-12)==accepted
            if accepted:
                post=tag+'/Admitted'; assert exact and np.array_equal(f[tag],f[post]) and np.array_equal(tensors[tag],tensors[post]);
            strain=pk(tensors[tag][:,:,:6]-base_tensor[:,:,:6]); assert 0<strain<1.01e-9
            result[label][method]={'norm_MPa':peak,'deltaAll89_MPa':(rows-independent).tolist(),'fiveGauges_MPa':gauges.tolist(),
                'dominantRow':int(np.argmax(abs(rows))+1),'tau_MPa':tol,'matchedAcceptedField':exact,'solverAdmitted':accepted,
                'maxStationStrainChange':strain,'physicalPlasticCount':int(sig[tag][:,:,0].sum()),
                'row81_MPa':float(rows[80]),'prescribedQy_N':float(q[0]*1e5),'oneStepPredictedNorm_MPa':record[method]['ownPredictedNormMPa']}
        result[label]['actualReduction']=1-result[label]['SignedRankOne']['norm_MPa']/result[label]['FreshUncorrected']['norm_MPa']
    answer={'workbook':prep['workbook_sha256'],'cases':result,'stamina':{'compilationClosed':compile_stop,'nativeClosed':stop},
         'unchangedBaselineNorm_MPa':pk(independent),'energyNormDefinitions':['TensionEnergy','CompressionEnergy'],
         'maxOriginal43toBaseAcceptedEnergyChange':np.max(diff.reshape(-1,2),axis=0).tolist(),
         'acceptedEnergies_byStation_SidesMinusCenterPlus':{k:v.tolist() for k,v in energy.items()},
         'trialYield_MPa_byStation_SidesMinusCenterPlus':{k:v.tolist() for k,v in criterion.items()},'tinyYield':tiny_details,
         'hashes':{**{p.name:s for p,s in hashes},'KaniV4Tangents.csv':sha(native/'KaniV4Tangents.csv')}}
    dest=H/'RankOneNativeVerification.json'; dest.write_text(json.dumps(answer,indent=2)+'\n',encoding='utf8')
    print(dest,sha(dest),{k:v['actualReduction'] for k,v in result.items()})

if __name__=='__main__': verify()
