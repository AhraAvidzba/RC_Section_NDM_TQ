"""Freeze a stock versus single-action one-step pair with identical load and mean shear."""
from pathlib import Path
from hashlib import sha256
import itertools,json,runpy
import numpy as np
from scipy.optimize import linprog

H=Path(__file__).resolve().parent; N=H.parent/'KaniPracticalProbe45/PortableReplayed'
reader=runpy.run_path(N/'Verify.py'); measured=json.loads((N/'Verification.json').read_text(encoding='utf8')); plan=json.loads((N/'ProbePlan.json').read_text(encoding='utf8'))
with np.load(N/'MeasuredSamples.npz',allow_pickle=False) as f:
    checks,_=reader['computed'](f,measured); pr=f['projection']; eq=f['Refined_rows'][83:]
    stock=np.vstack((f['Stock_rows'][:83],f['resultant_projection']@f['Stock_rows'][:83]))
    refined=np.vstack((f['Refined_rows'][:83],f['resultant_projection']@f['Refined_rows'][:83]))
strain=np.load(H.parent/'KaniV4Rebase3/RebasedLinearSystems.npz',allow_pickle=False)['strain_matrix'].reshape(-1,88)
origin=checks['BaseAccepted']; rr=origin['r']; tau=origin['tau']; old=origin['field']; q=np.r_[old[2:],old[0]]
size=1e-8; max_probe=1e-9
axes=list(plan['dirs']); dirs=np.array([plan['dirs'][name] for name in axes]).T*size
physical=strain@dirs; w=np.linalg.solve(physical.T@physical,physical.T@strain)
assert np.max(abs(w@dirs-np.eye(3)))<1e-11
Gc=np.zeros((88,4)); Gc[83:87]=np.eye(4)*1e-5
coordinates=np.c_[dirs,Gc]; Jraw=refined@coordinates; Jstock=stock@coordinates

# The first-axis action was measured at the earlier positive radius, before any candidate evaluation.
# w0 annihilates both measured complementary axes and all four pure gauge coordinates.
axis='PriorSecant'; gain=np.array(measured['probeDiagnostics'][axis+'01Plus']['signedActualDeltaAll89_MPa'])-refined@dirs[:,0]
rank_one=refined+gain[:,None]@w[:1]; Jnew=rank_one@coordinates
assert np.max(abs((rank_one-refined)@dirs[:,1:]))<1e-10
q_cols=1e5*coordinates[-1]; gamma_cols=pr@coordinates[:87]
projection_scale=1e-8

def fd(sign,small=False):
    cols=[]
    for i,n in enumerate(axes):
        code='00' if small and n=='LoadShape' else '01'
        tag=n+code+sign[i]; c=plan['probes'][tag]
        cols.append(np.array(measured['probeDiagnostics'][tag]['signedActualDeltaAll89_MPa'])*size/(c['radius']*c['sign']))
    return np.column_stack(cols)

def minimize(op,requested,gamma,rule):
    E=np.r_[q_cols,0.][None]; er=np.array([requested]);
    if gamma is not None:
        E=np.vstack((E,np.r_[gamma_cols,0.]/projection_scale)); er=np.r_[er,gamma/projection_scale]
    p=physical/max_probe
    U=np.vstack((np.c_[op/tau,-np.ones(89)],np.c_[-op/tau,-np.ones(89)],np.c_[p,np.zeros((len(p),5))],np.c_[-p,np.zeros((len(p),5))]))
    sol=linprog(np.r_[np.zeros(7),1.],U,np.r_[-rr/tau,rr/tau,np.ones(2*len(p))],E,er,
         bounds=rule+[(-.5,.5)]*4+[(0,None)],method='highs')
    if not sol.success: return None
    x=sol.x[:7]; dq=coordinates@x
    signs=['Plus' if t>=0 else 'Minus' for t in x[:3]]
    assert np.max(abs(eq[:4]@dq))<5e-12
    if gamma is not None: assert abs((pr@dq[:87])-gamma)<5e-17
    v0=rr+fd(signs)@x[:3]+refined@Gc@x[3:]; v1=rr+fd(signs,True)@x[:3]+refined@Gc@x[3:]
    return {'coefficients':x.tolist(),'delta':dq.tolist(),'gamma':float(pr@dq[:87]),'maxStationStrain':float(np.max(abs(strain@dq))),
          'ownPredictedNormMPa':float(sol.fun*tau),'retrospectiveSignedOnlyActionAt01NormMPa':float(np.max(abs(v0))),
          'retrospectiveSignedOnlyActionAt00Plus01NormMPa':float(np.max(abs(v1))), 'rawNormPredictionMPa':float(np.max(abs(rr+Jraw@x))),
          'rankOneNormPredictionMPa':float(np.max(abs(rr+Jnew@x)))}

basic=[(-.1,.1)]*3; rank=[(0.,.1),(-.1,.1),(-.1,.1)]
rows={}
for load in (.02,.04,.07,.1):
    for gamma_mult in (.05,.16,.32,.6,.78,1.,1.5,2.,3.):
        assert gamma_cols[0]>0
        gg=load*(gamma_cols[0]/q_cols[0])*gamma_mult
        A=minimize(Jraw,load,gg,basic); B=minimize(Jnew,load,gg,rank)
        if A and B:
            key=f'{load}/{gamma_mult}'
            rows[key]={'load_increment_N':load,'gammaIncrement':gg,'FreshUncorrected':A,'SignedRankOne':B}

# Favor separation under the two independent retrospective models and the measured low-radius scale.
def grade(rec):
    a,b=[rec[label] for label in ('FreshUncorrected','SignedRankOne')]
    keys=['retrospectiveSignedOnlyActionAt01NormMPa','retrospectiveSignedOnlyActionAt00Plus01NormMPa']
    return (min(a[i]-b[i] for i in keys), -max(b[i] for i in keys))
shortlist=sorted(rows.items(),key=lambda kv:grade(kv[1]),reverse=True)
for k,v in shortlist[:8]:
    a,b=[v[x] for x in ('FreshUncorrected','SignedRankOne')]
    print(k,'control γ',v['gammaIncrement'],'A',a['ownPredictedNormMPa'],a['retrospectiveSignedOnlyActionAt00Plus01NormMPa'],'B',b['ownPredictedNormMPa'],b['retrospectiveSignedOnlyActionAt00Plus01NormMPa'],flush=True)
selections=[('Signal', shortlist[0][0],shortlist[0][1]),('Near', '0.1/1.0', rows['0.1/1.0'])]
inputs=H.parent/'KaniPracticalProbe45/ProbeFields.csv'
seed=next(l.split(';') for l in inputs.read_text(encoding='ascii').splitlines() if l.startswith('KANI_B_FIELD;Accepted19of512;'))
base_q=np.r_[list(map(float,seed[4:-1])),float(seed[-1])]; assert np.max(abs(base_q-q))<1e-14
exact_gamma=float(seed[3]); ordered=[';'.join(seed)]; frozen={}
for label,k,pair in selections:
    for method in ('FreshUncorrected','SignedRankOne'):
        step=np.array(pair[method]['delta']); v=base_q+step
        l=base_q[-1]+pair['load_increment_N']/1e5
        g=exact_gamma+pair['gammaIncrement']
        assert abs(v[-1]-l)<1e-14 and abs(pr@v[:87]-g)<4e-17
        ordered.append(';'.join(['KANI_B_FIELD',method+label,'1',format(g,'.17g'),*[format(a,'.17g') for a in v[:87]],format(l,'.17g')]))
        pair[method]['literalField']=v.tolist()
    frozen[label]={'key':k,'targetQy_N':float(l*1e5),'gamma':g,**pair}
out=H/'RankOneComparison.csv'; out.write_bytes(('\r\n'.join(ordered)+'\r\n').encode('ascii'))
result=H/'RankOneComparisonPlan.json'; result.write_text(json.dumps({'frozenPairs':frozen,'allCandidates':rows,'gaugeAndControlSource':'fixed load and fixed gamma for each pair','tolerance_MPa':tau,
    'update':'J + (observed action - Jv) w^T. PriorSecant01Plus action selected by planned positive projection; w^Tv=1 in strain metric.',
    'fixtureSHA256':sha256(out.read_bytes()).hexdigest().upper()},indent=2)+'\n',encoding='utf8')
print(out,sha256(out.read_bytes()).hexdigest().upper(),result,sha256(result.read_bytes()).hexdigest().upper())