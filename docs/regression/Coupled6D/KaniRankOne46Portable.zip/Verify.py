from pathlib import Path
from hashlib import sha256
import json, numpy as np
from scipy.interpolate import BSpline

def operators(geometry, L):
    x,y,area=geometry.T
    normalized=area/(305.*610.)
    gx_knots=np.array([-152.5]*4+[0.]+[152.5]*4)
    gy_knots=np.array([-305.]*4+[0.]+[305.]*4)
    basis=np.eye(5)
    spline_x=BSpline(gx_knots,basis,3,extrapolate=False)
    spline_y=BSpline(gy_knots,basis,3,extrapolate=False)
    nx,ny=spline_x(x),spline_y(y)
    dx,dy=spline_x.derivative()(x),spline_y.derivative()(y)
    def pair(a,b):
        return (a[:,:,None]*b[:,None,:]).reshape((len(x),25))
    shape=pair(ny,nx)
    slope_x=L*pair(ny,dx)
    slope_y=L*pair(dy,nx)
    h=np.zeros((184,6,79))
    u=slice(4,79,3)
    v=slice(5,79,3)
    w=slice(6,79,3)
    h[:,2,0]=1.
    h[:,2,1]=y/L
    h[:,2,2]=x/L
    h[:,4,3]=-y/L
    h[:,5,3]=x/L
    h[:,0,u]=slope_x
    h[:,1,v]=slope_y
    h[:,3,u]=slope_y
    h[:,3,v]=slope_x
    h[:,4,w]=slope_x
    h[:,5,w]=slope_y
    c=np.zeros((4,79))
    concrete=slice(144)
    shape_weight=shape[concrete]*normalized[concrete,None]
    c[0,u]=c[1,v]=c[2,w]=shape_weight.sum(axis=0)
    c[3,u]=(-y[concrete,None]/L*shape_weight).sum(axis=0)
    c[3,v]=(x[concrete,None]/L*shape_weight).sum(axis=0)
    resultants=np.zeros((184,6,6))
    resultants[:,0,2]=1.
    resultants[:,1,2]=y
    resultants[:,2,2]=x
    resultants[:,3,4]=-y
    resultants[:,3,5]=x
    resultants[:,4,4]=1.
    resultants[:,5,5]=1.
    scales=305.*610.*np.array([1.,L,L,L,1.,1.])
    return h, shape, c, resultants, normalized, scales

ROOT=Path(__file__).resolve().parent
def read(name): return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def digest(name): return sha256((ROOT/name).read_bytes()).hexdigest().upper()
def peak(a): return float(np.max(np.abs(a)))
def near(a,b,tol): assert abs(a-b)<=tol,(a,b,tol)

def control_certificate(residual,weights,tau):
    coeff=weights[2]
    pos=coeff>0.
    lo=float(np.max((-tau-residual[:79][pos])/coeff[pos]))
    hi=float(np.min((tau-residual[:79][pos])/coeff[pos]))
    involved=np.r_[pos,np.zeros(10,dtype=bool)]
    feasible=lo<=hi and peak(residual[~involved])<=tau
    return lo,hi,bool(feasible)

def computed(d, original):
    g,L=d["geometry"],float(d["length"])
    h,shape,c,qmat,weights,scales=operators(g,L)
    states={}
    for name,field,native,index in zip(d["names"],d["fields"],d["states"],d["station_index"],strict=True):
        tag=str(name)
        stations=d["stations"][int(index)]
        lam,target=field[:2]
        q=field[2:]
        coord=q[:79]
        depth=q[79:83]
        mu=q[83:]
        assert lam==native[1] and target==native[0]
        strains=h@coord
        slope=h[:,:,:4]@depth
        eps3=np.array([strains+i*.001*slope for i in (-1,0,1)])
        assert peak(eps3-stations[:,:,:6])<2e-12
        stresses=stations[1,:,6:]
        gradient=(stations[2,:,6:]-stations[0,:,6:])/.002
        eq=np.einsum("nij,ni,n->j",h,stresses,weights)
        eq[4:]-=np.einsum("nk,na,n->ka",shape,gradient[:,[4,5,2]],weights).ravel()
        eq+=c.T@mu
        long_eq=np.einsum("nij,ni,n->j",h[:,:,:4],gradient,weights)
        long_eq[1]-=1e5*lam/scales[0]
        gauge=c@coord
        force=np.einsum("nij,nj,n->i",qmat,stresses,g[:,2])
        assert peak(np.r_[eq,long_eq,gauge]-native[12:])<2e-10
        assert peak((force-native[6:12])/scales)<2e-10
        r=np.r_[eq,long_eq,(force-np.r_[np.zeros(5),1e5*lam])/scales]
        gamma=float(weights[:144]@strains[:144,5])
        tau=float(native[3])
        assert abs(gamma-target)*25600. <=tau and peak(gauge)*25600.<=tau
        norm=max(peak(r),abs(gamma-target)*25600.)
        near(norm,native[2],2e-10)
        states[tag]={"r":r,"tau":tau,"norm":norm,"field":field,"idx":int(index),"resultants":native[6:12]}
    return states,c

import csv

def verify():
    manifest=read('Manifest.json'); v=read('RankOneNativeVerification.json'); plan=read('RankOneComparisonPlan.json'); prep=read('Preparation.json')
    for key,want in manifest['files'].items(): assert digest(key)==want,key
    assert v['workbook']==prep['workbook_sha256']==read('CodeUpdate.json')['ProductionSHA256']
    assert digest('RankOneComparison.csv')==plan['fixtureSHA256']==prep['frozen']['RankOneComparison.csv']
    assert digest('RankOneComparisonPlan.json')==prep['frozen']['RankOneComparisonPlan.json']
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in (ROOT/'KaniV4.txt').read_text(encoding='utf-8-sig')
    closure=read('KaniV4.txt.ProcessClosure.json'); owner=read('KaniV4.txt.Ownership.json'); ended=closure['Closure']['FinalState']
    assert closure['Passed'] and closure['ChildExitCode']==0 and ended==v['stamina']['nativeClosed']
    assert ended['PID']==owner['PID'] and ended['StartTicksUTC']==owner['StartTicksUTC'] and ended['State']=='Absent'
    assert read('CompileClosure.json')['State']=='Absent'
    with np.load(ROOT/'MeasuredSamples.npz',allow_pickle=False) as d:
        st,c=computed(d,v); proj=d['projection']; samples=d['names']
    assert all(np.array_equal(st[a]['field'],st[b]['field']) and st[a]['idx']==st[b]['idx'] for a,b in (('Original43','Restore43'),('BaseAccepted','EndAccepted')))
    energy={l:np.full((3,184,2),np.nan) for l in v['acceptedEnergies_byStation_SidesMinusCenterPlus']}
    trial={l:np.full((3,184),np.nan) for l in v['trialYield_MPa_byStation_SidesMinusCenterPlus']}
    branch={l:np.full((3,184,3),-99,dtype=np.int16) for l in samples}
    for kind,tag,ip,side,*data in csv.reader((ROOT/'KaniV4Tangents.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        j,i=int(ip)-1,int(side)+1
        if kind=='ENERGY': energy[tag][i,j]=list(map(float,data))
        elif kind=='YIELD': trial[tag][i,j]=float(data[0])
        else:
            assert kind=='BRANCH'; branch[tag][i,j]=list(map(int,data))
    for p,q in ((energy,'acceptedEnergies_byStation_SidesMinusCenterPlus'),(trial,'trialYield_MPa_byStation_SidesMinusCenterPlus')):
        assert all(np.array_equal(a,np.array(v[q][tag])) for tag,a in p.items())
    assert np.array_equal(energy['BaseAccepted'],energy['EndAccepted']) and np.array_equal(energy['Original43'],energy['Restore43'])
    both=(branch['LoadShape00Minus'][:,:,0]==1)&(branch['LoadShape00Plus'][:,:,0]==1)
    assert v['tinyYield']['bothPlasticCount']==int(both.sum())
    assert v['tinyYield']['F0_at_bothPlastic_positiveCount']==int((both&(trial['BaseAccepted']>0.)).sum())
    origin=st['BaseAccepted']['r']; details={}
    for label,entry in v['cases'].items():
        ca=st['FreshUncorrected'+label]; cb=st['SignedRankOne'+label]
        assert np.array_equal(ca['field'][:2],cb['field'][:2])
        for m in ('FreshUncorrected','SignedRankOne'):
            tag=m+label; k=st[tag]; a=entry[m]
            near(a['norm_MPa'],k['norm'],2e-10); assert peak(np.array(a['deltaAll89_MPa'])-(k['r']-origin))<2e-10
            assert peak(np.r_[c@k['field'][2:81],proj@k['field'][2:]-k['field'][1]])<1e-15
            if a['solverAdmitted']:
                after=st[tag+'/Admitted']; assert after['idx']==k['idx'] and np.array_equal(after['field'],k['field']) and k['norm']<=k['tau']
        details[label]={'unchangedTangentMPa':ca['norm'],'signedActionMPa':cb['norm'],'toleranceMPa':cb['tau'],'reduction':1-cb['norm']/ca['norm']}
    print(json.dumps({'book':v['workbook'],'nativeCases':details,'W':v['tinyYield'],'closed':v['stamina']},indent=2))

if __name__=='__main__': verify()
