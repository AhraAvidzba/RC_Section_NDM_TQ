"""Decompose the even residual in the exact §308 signed station witnesses."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import json, runpy
import numpy as np

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'KaniPracticalProbe45/PortableReplayed'
TRACE=SOURCE/'MeasuredSamples.npz'; w=json.loads((SOURCE/'Verification.json').read_text(encoding='utf8'))
D=dict(np.load(TRACE,allow_pickle=False)); ids={n:i for i,n in enumerate(D['names'])}
ops=runpy.run_path(SOURCE/'Verify.py')['operators']
geometry=D['geometry']; h,shape,_,resultants,weight,scale=ops(geometry,D['length']); pk=lambda v:float(np.max(abs(v)))

def stress(label): return D['stations'][D['station_index'][ids[label]],:,:,6:]
def branch(label): return D['branches'][ids[label]]
def histogram(value): return {str(k):v for k,v in sorted(Counter(map(int,value.ravel())).items())}
def assemble(st):
    traction=st[1]; gradient=(st[2]-st[0])/.002
    eq=np.einsum('nij,ni,n->j',h,traction,weight)
    eq[4:]-=np.einsum('nk,na,n->ka',shape,gradient[:,[4,5,2]],weight).ravel()
    longitudinal=np.einsum('nij,ni,n->j',h[:,:,:4],gradient,weight)
    wrench=np.einsum('nij,nj,n->i',resultants,traction,geometry[:,2])/scale
    return np.r_[eq,longitudinal,wrench]

def eigen(st):
    xx,yy,zz,xy,xz,yz=np.moveaxis(st,-1,0)
    m=np.stack([xx,xy,xz,xy,yy,yz,xz,yz,zz],axis=-1).reshape(st.shape[:-1]+(3,3))
    return np.linalg.eigvalsh(m)

for label in ids:
    st=stress(label)[:,:144]; eig=eigen(st)[:,:,2]
    flags=branch(label)[:,:144,1]
    assert np.all(np.sign(eig)==flags),(label,pk(eig[np.sign(eig)!=flags]))

origin='BaseAccepted'; B=branch(origin); st0=stress(origin); summary={}
for pair,existing in w['signedPairs'].items():
    plus=pair+'Plus'; minus=pair+'Minus'; Splus=stress(plus); Sminus=stress(minus); p,m=branch(plus),branch(minus)
    even=Splus+Sminus-2*st0
    flags={'plasticOnly':(p[:,:,0]!=m[:,:,0])&(p[:,:,1]==m[:,:,1]), 'principalOnly':(p[:,:,0]==m[:,:,0])&(p[:,:,1]!=m[:,:,1]),
           'both':(p[:,:,0]!=m[:,:,0])&(p[:,:,1]!=m[:,:,1]),'unflagged':(p[:,:,:2]==m[:,:,:2]).all(axis=2)}
    detail={}; signed={}; frac_sum=float(np.sum(even**2)); row=assemble(even)
    dp=w['probeDiagnostics'][plus]['signedActualDeltaAll89_MPa']; dm=w['probeDiagnostics'][minus]['signedActualDeltaAll89_MPa']
    assert pk(row-(np.array(dp)+dm))<3e-11
    plus_eig=eigen(Splus)[:,:144]; minus_eig=eigen(Sminus)[:,:144]; base_eigen=eigen(st0)[:,:144]
    for name,mask in flags.items():
        sec0=mask[:,:144]; sec1=mask[:,144:]; rows=assemble(even*mask[:,:,None]); strict=np.isin(p[:,:,1],[1,-1])
        by_sign={'positiveMajorInBoth':int(np.count_nonzero(mask&(p[:,:,1]>0)&(m[:,:,1]>0))),
                 'compressiveInBoth':int(np.count_nonzero(mask&(p[:,:,1]<0)&(m[:,:,1]<0))),
                 'plasticOnPlusOnly':int(np.count_nonzero(mask&(p[:,:,0]>m[:,:,0]))),
                 'plasticOnMinusOnly':int(np.count_nonzero(mask&(p[:,:,0]<m[:,:,0]))),
                 'mixedPrincipalBothInConcrete':int(np.count_nonzero(sec0&(plus_eig[:,:,0]<0)&(plus_eig[:,:,2]>0)&(minus_eig[:,:,0]<0)&(minus_eig[:,:,2]>0)))}
        detail[name]={'count':int(mask.sum()),'concrete':int(sec0.sum()),'netReinforced':int(sec1.sum()),
            'evenStressSquaredFraction':float(np.sum(even[mask]**2)/frac_sum),'row81_MPa':float(rows[80]),'outOfAxisPair_MPa':rows[[45,69]].tolist(),
            'maxForceRowsContribution_MPa':pk(rows),'bySign':by_sign}
    up=p[:,:,0].astype(bool); down=m[:,:,0].astype(bool)
    for label,sig in [(plus,p),(minus,m)]:
        cc=sig[:,:144]; steel=sig[:,144:];
        signed[label]={'plastic':int(sig[:,:,0].sum()),'concretePlastic':int(cc[:,:,0].sum()),'displacedConcretePlastic':int(steel[:,:,0].sum()),
          'plasticWithPositivePrincipal':int(np.count_nonzero((sig[:,:,0]==1)&(sig[:,:,1]>0))),
          'plasticWithNegativePrincipal':int(np.count_nonzero((sig[:,:,0]==1)&(sig[:,:,1]<0))),
          'principal':histogram(sig[:,:,1]),'substeps':histogram(sig[:,:,2]),'maxEigenShiftConcrete_MPa':pk((plus_eig if label==plus else minus_eig)-base_eigen)}
    assert (p[:,:,2]==m[:,:,2]).all()
    assert float(sum(x['row81_MPa'] for x in detail.values()))-row[80]<2e-13
    cactive=flags['plasticOnly']|flags['both']; hotspot=tuple(existing['evenStressPeakStation']); ip=(hotspot[0]+1,hotspot[1]-1)
    record={'allEvenRow81_MPa':float(row[80]),'weakPeakRow':int(np.argmax(abs(row))+1),'peak_MPa':pk(row),
        'switchClasses':detail,'signedClasses':signed,'hotspotLabel':hotspot,'hotspotBranchPlus':p[ip].tolist(),'hotspotBranchMinus':m[ip].tolist(),
        'signedScale':existing['radius']}
    if hotspot[1]<=144:
        record.update(hotspotPrincipalBase_MPa=base_eigen[ip].tolist(), hotspotPrincipalPlus_MPa=plus_eig[ip].tolist(),
                      hotspotPrincipalMinus_MPa=minus_eig[ip].tolist())
    summary[pair]=record
out={'sourceSHA256':sha256(TRACE.read_bytes()).hexdigest().upper(),'verifiedPrincipalSignsInDirectConcrete':27*3*144,
     'basePrincipal':histogram(B[:,:,1]),'baseSubsteps':histogram(B[:,:,2]),'basePlastic':int(B[:,:,0].sum()),
     'groups':summary,'limit':'Station records expose plastic change and largest principal sign. They do not expose the separate positive hardening quantities. For reinforced stations stresses are steel less displaced concrete while the flags describe displaced concrete.'}
dest=HERE/'ActiveSetDecomposition.json'; dest.write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(dest,sha256(dest.read_bytes()).hexdigest().upper(),out['basePrincipal'],out['baseSubsteps'],out['basePlastic'])
for pair,v in summary.items():
    print(pair,v['allEvenRow81_MPa'],[(k,x['count'],round(x['evenStressSquaredFraction'],9),x['row81_MPa'],x['bySign']) for k,x in v['switchClasses'].items() if x['count']],v['signedClasses'][pair+'Plus']['substeps'])
