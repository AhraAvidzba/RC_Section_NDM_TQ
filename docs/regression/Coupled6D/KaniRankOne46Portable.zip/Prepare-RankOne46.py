from argparse import ArgumentParser
import json
from pathlib import Path
import runpy

H=Path(__file__).resolve().parent
P45=H.parent/'KaniPracticalProbe45'
P=runpy.run_path(P45/'Prepare-Probe45.py')
BOOK,SHADOW,SOLVER,ELASTIC,MODULE,CAPTURED=(P[k] for k in ('BOOK','SHADOW','SOLVER','ELASTIC','MODULE','CAPTURED'))
sha, one=P['digest'],P['one']
FIX='DE89885774F8F67DC6D0491F7C27F5B53B4AEC925EA58835A2601FEDF279D895'
PLAN='177B7216C6F57EACE9AE635115675364A532F6A17312CECE72520BD5980643E5'

def prepare(repo):
    assert not (H/'Preparation.json').exists()
    past=P['check']()
    assert sha(repo/BOOK)==past['workbook_sha256']
    assert all(sha(repo/k)==v for k,v in past['production_source_sha256'].items())
    assert sha(H/'RankOneComparison.csv')==FIX and sha(H/'RankOneComparisonPlan.json')==PLAN
    src=(P45/MODULE).read_text(encoding='utf8'); a=src.index('    Dim rootPath As String'); b=src.index('    Close #tangents:',a)
    src=src[:a]+(H/'ComparativeMain.bas.txt').read_text(encoding='utf8').rstrip()+'\n'+src[b:]
    src=one(src,'If entries.Count <> 23 Or history.Count <> 43','If entries.Count <> 7 Or history.Count <> 43')
    src+='\n'+(H/'EnergyHelper.bas.txt').read_text(encoding='utf8').rstrip()+'\n'
    solver=(P['W']/SOLVER).read_bytes()
    runner=(P45/'Run-Probe45.ps1').read_text(encoding='utf-8-sig')
    for x,y in (('Prepare-Probe45.py','Prepare-RankOne46.py'),('Verify-Probe45.py','Verify-RankOne46.py'),
                ("'-TimeoutSeconds',125","'-TimeoutSeconds',95"),
                ('# Изолированные знаковые пробы Kani вокруг принятого поля 19/512.','# Изолированная сверка двух поправок для Kani около 19/512.'),
                ('Независимая сверка знаковых проб Kani не пройдена.','Сверка двух поправок Kani не пройдена.')): runner=one(runner,x,y)
    hist=[x for x in (P45/'KaniGaugeInput.csv').read_text(encoding='ascii').splitlines() if x.startswith('KANI_B_FIELD;History')]
    trials=(H/'RankOneComparison.csv').read_text(encoding='ascii').splitlines()
    assert len(hist)==6 and len(trials)==5
    tiny=[l for l in (P45/'ProbeFields.csv').read_text(encoding='ascii').splitlines() if l.split(';')[1] in ('LoadShape00Minus','LoadShape00Plus')]
    assert len(tiny)==2
    trials+=tiny
    assert all(len(s.split(';'))==92 for s in hist+trials)
    (H/'Native').mkdir(exist_ok=True); (H/'Temp').mkdir(exist_ok=True)
    c={Path(k):P45/k for k in past['frozen'] if k.startswith('tools/') or k in ('KaniV4Input.csv','KaniChartInput.csv',CAPTURED.as_posix(),ELASTIC.as_posix())}
    c[BOOK]=repo/BOOK; c[SHADOW]=repo/BOOK
    files={k:v.read_bytes() for k,v in c.items()}
    files.update({MODULE:src.encode('utf8'),SOLVER:solver,Path('Run-RankOne46.ps1'):runner.encode('utf-8-sig'),
        Path('KaniGaugeInput.csv'):('\r\n'.join(hist+trials)+'\r\n').encode('ascii')})
    for k,value in files.items():
        d=H/k; d.parent.mkdir(exist_ok=True,parents=True); d.write_bytes(value)
    frozen=set(files)-{SHADOW}; frozen.update(Path(k) for k in ('RankOneComparison.csv','RankOneComparisonPlan.json','ComparativeMain.bas.txt',
                   'EnergyHelper.bas.txt','Plan-RankOne46.py','Prepare-RankOne46.py','Verify-RankOne46.py'))
    receipt={'workbook_sha256':past['workbook_sha256'],'production_source_sha256':past['production_source_sha256'],
             'frozen':{k.as_posix():sha(H/k) for k in sorted(frozen)}}
    (H/'Preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
    return check()

def check():
    v=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert P['check']()['workbook_sha256']==v['workbook_sha256']==sha(H/BOOK)
    assert all(sha(H/k)==a for k,a in v['frozen'].items())
    assert sha(H/CAPTURED)==v['production_source_sha256'][SOLVER.as_posix()]
    assert sha(H/ELASTIC)==v['production_source_sha256'][ELASTIC.as_posix()]
    assert (H/SOLVER).read_bytes()==(P['W']/SOLVER).read_bytes()
    assert v['frozen']['RankOneComparison.csv']==FIX and v['frozen']['RankOneComparisonPlan.json']==PLAN
    return v

if __name__=='__main__':
    parser=ArgumentParser(); parser.add_argument('--repo',type=Path); parser.add_argument('--check',action='store_true'); a=parser.parse_args()
    print((check() if a.check else prepare(a.repo))['workbook_sha256'],sha(H/'Preparation.json'))
