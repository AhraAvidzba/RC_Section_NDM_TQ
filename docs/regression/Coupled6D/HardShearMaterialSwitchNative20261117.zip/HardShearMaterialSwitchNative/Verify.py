"""Сопоставляет знаковую невязку и действительные признаки материала."""

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from RankVerify import digest, inputs, matvec, norm, null_basis, obj, parse, val

HERE = Path(__file__).resolve().parent
STEPS = (2.5e-11, 8e-12, 5e-12, 1.5e-12)


def extract(raw):
    clean = ["HARDSHEAR-RANK;1"]
    points = {}
    active = station_data = None
    seen = None
    lines = raw.splitlines()
    assert lines[0] == "HARDSHEAR-SWITCH;1"
    for line in lines[1:]:
        kind, *value = line.split(";")
        if kind == "BEGIN":
            assert active is None and value[0] not in points
            active = value[0]
            points[active] = {}
        elif kind == "END":
            assert active == value[0]
            active = station_data = None
        if kind == "STATIONS":
            station_data = points[active]
            step, count = val(value[0]), int(value[1])
            assert step not in station_data and count > 0
            seen = {}
            station_data[step] = (count, seen)
        elif kind == "STATION":
            i, side = int(value[0]), int(value[1])
            assert (i, side) not in seen and side in (-1, 0, 1) and i > 0
            if value[2] == "ok":
                assert value[4] in ("True", "False") and int(value[5]) in (-1, 0, 1)
                seen[i, side] = {"yield_MPa": val(value[3]), "plastic": value[4] == "True",
                                 "principal_sign": int(value[5]), "substeps": int(value[6])}
            else:
                assert value[2:] == ["failed"]
                seen[i, side] = None
        else:
            clean.append(line)
    assert active is None
    assert all(set(records) == {0., *STEPS, *(-h for h in STEPS)} for records in points.values())
    for records in points.values():
        for count, station in records.values():
            assert set(station) == {(point, side) for point in range(1, count+1) for side in (-1, 0, 1)}
    return "\n".join(clean), points


def material_changes(left, right):
    changes = []
    failed = []
    for key, a in left.items():
        b = right[key]
        if a is None or b is None:
            failed.append(key)
            continue
        if any(a[tag] != b[tag] for tag in ("plastic", "principal_sign", "substeps")) or (
                (a["yield_MPa"] > 0) != (b["yield_MPa"] > 0)):
            changes.append({"point": key[0], "axial_side": key[1], "left": a, "right": b,
                            "yield_strictly_bracketed": a["yield_MPa"] * b["yield_MPa"] < 0.})
    return changes, failed


def analyze(case, prior, station):
    for name in ("name", "history", "gauge", "target", "factor", "modulus", "FIELD", "FORCE",
                 "BASE", "MEASURED", "DIRECTION", "PROJECTION", "TANGENT", "matrix"):
        assert case[name] == prior[name], name
    matrix = case["matrix"]
    n = case["gauge"] - 1
    assert n == 56
    z = null_basis([row[:n] for row in matrix[n:]])
    t = case["TANGENT"][:-1]
    amplitude = max(map(abs, t[:n]))
    action = matvec(z, matvec(matrix, [x/amplitude for x in t])[:n])
    reference = norm(action)
    assert 500 < reference < 1000
    before, after = [], []
    observed = []
    for step, residual in case["fd"]:
        difference = matvec(z, [(b-a)/step for a, b in zip(case["BASE"][:n], residual[:n], strict=True)])
        error = norm([a-b for a, b in zip(difference, action, strict=True)])/reference
        if step > 0 and error <= 0.02:
            before.append(step)
        if step > 0 and error >= 20:
            after.append(step)
        changes, failures = material_changes(station[0.][1], station[step][1])
        observed.append({"signed_step": step, "relative_projected_action_difference": error,
                         "relative_projected_action_norm": norm(difference)/reference,
                         "changed_relative_to_archived_peak": changes, "unread_stations": failures})
    bracket = None
    if before and after and max(before) < min(after):
        low, high = max(before), min(after)
        changes, failures = material_changes(station[low][1], station[high][1])
        bracket = {"same_history_test_increment_interval": [low, high],
                   "changed_stations": changes, "unread_stations": failures}
    return {"case": case["name"], "same_archived_equilibrium_and_tangent": True,
            "finite_action_bracket": bracket, "one_sided": observed,
            "failed_residual_probes": case["failed"]}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--inputs", action="store_true")
    args = cli.parse_args()
    fixture = obj("Fixture.json")
    inputs(fixture)
    if args.inputs:
        print("INPUTS OK", digest(HERE / "Fixture.json"))
        return
    code = obj("docs/regression/CodeUpdate.json")
    compiler = obj("CompileClosure.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    closure = obj("Native/HardShear.txt.ProcessClosure.json")
    ending = closure["Closure"]["FinalState"]
    assert code["Compiled"] and not code["ProductionChanged"] and code["ProductionSHA256"] == fixture["source_workbook_sha256"]
    assert compiler["State"] == "Absent" and owner["SourceSHA256"] == code["WorkbookSHA256"]
    assert closure["Passed"] and closure["ChildExitCode"] == 0 and ending["State"] == "Absent"
    assert (owner["PID"], owner["StartTicksUTC"]) == (ending["PID"], ending["StartTicksUTC"])
    log = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_SWITCH: passed=1; failed=0" in log
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    trace = HERE / "Native/HardSwitch.csv"
    stripped, station = extract(trace.read_text(encoding="ascii"))
    with TemporaryDirectory(dir=HERE / "Temp") as directory:
        stripped_trace = Path(directory) / "Trace.csv"
        stripped_trace.write_text(stripped, encoding="ascii")
        cases = parse(stripped_trace)
    prior = parse(HERE / "OriginalPeakTrace.csv")
    assert set(prior) == set(cases) == set(station) == {"Stock-2", "Short4-4"}
    result = {"native_trace_sha256": digest(trace), "assembled_cases": [
        analyze(case, prior[name], station[name]) for name, case in cases.items()
    ], "perturbed_fields_are_equilibria": False,
              "tangent_rank_between_equilibria": "open", "physical_limit_certified": False}
    result_file = HERE / "Native/Verification.json"
    result_file.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print("HARDSHEAR MATERIAL SWITCH", digest(result_file))


if __name__ == "__main__":
    main()
