' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет знаковые возмущения поля на неизменённой материальной истории.
' Регистрирует только невязки и состояния материала. Новые равновесия не ищутся.
Private Sub RecordHardRankDifferencesTest(ByRef field() As Double, ByRef tangent() As Double)
    Dim i As Long, normalization As Double
    For i = 1 To mGaugeStart - 1: normalization = GeomMax(normalization, Abs(tangent(i))): Next i
    If normalization = 0# Then
        WriteHardRankRowTest "FD-FAIL;zero"
        Exit Sub
    End If
    RecordHardSwitchStationsTest field, 0#
    Dim probe() As Double: ReDim probe(1 To mDegreeCount)
    Dim stepValues As Variant: stepValues = Array(0.000000000025, 0.000000000008, 0.000000000005, 0.0000000000015)
    Dim kind As Variant, side As Long, signedStep As Double
    For Each kind In stepValues
        For side = -1 To 1 Step 2
            signedStep = side * CDbl(kind)
            For i = 1 To mDegreeCount: probe(i) = field(i) + signedStep * tangent(i) / normalization: Next i
            If Evaluate(probe, False, recordTrial:=False) Then
                WriteHardRankRowTest "FD;" & HardRankBitsTest(signedStep) & ";" & HardRankVectorTest(mResidual)
            Else
                WriteHardRankRowTest "FD-FAIL;" & HardRankBitsTest(signedStep) & ";" & CStr(mMaterialPoint) & ";" & CStr(mLastFailedSide)
            End If
            RecordHardSwitchStationsTest probe, signedStep
        Next side
    Next kind
End Sub
