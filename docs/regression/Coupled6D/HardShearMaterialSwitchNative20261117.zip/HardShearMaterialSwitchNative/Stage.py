"""Замораживает узкую пробу переключения двух ранее сверенных полей."""

from hashlib import sha256
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parent / "hs-rank"
REPO = HERE.parents[1]
CONT = "src/Solver/CCoupledDeformationContinuation.cls"
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
TEST = "tests/modTestCoupledElasticState.bas"
PEAKS = ("Stock-2", "Short4-4")
RAW_RANK = "2DD4042A5A6AA4A7ACF595039707D77676B9FDD9BE8D2D145C7F07865676F4B7"
RANK_FIXTURE = "BA9BA407471A022E00DAF14F0FF56928405F4174C2A955822460BB149A40459A"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def unit(name):
    return (HERE / name).read_text(encoding="utf-8")


def previous(name):
    return (PREVIOUS / name).read_text(encoding="utf-8")


def vba(source):
    assert max(map(len, source.splitlines())) <= 1023
    return source.rstrip().replace("\n", "\r\n").encode("utf-8") + b"\r\n"


def main():
    raw = (PREVIOUS / "Fixture.json").read_bytes()
    assert digest(raw) == RANK_FIXTURE
    rank = json.loads(raw)
    installed = (REPO / rank["workbook"]).read_bytes()
    assert digest(installed) == rank["source_workbook_sha256"]
    save(rank["workbook"], installed)
    save("docs/regression/Diagnostic.xlsm", installed)
    for directory in ("Native", "Temp"):
        (HERE / directory).mkdir(exist_ok=True)
    names = (CONT, NEWTON, TEST, "Expected.json", "Verify.py", "Guard-IsolatedOffice.ps1")
    original = {name: (PREVIOUS / name).read_bytes() for name in names}
    for name, raw in original.items():
        assert digest(raw) == rank["inputs"][name], name
    base_trace = (PREVIOUS / "Native/HardRank.csv").read_bytes()
    assert digest(base_trace) == RAW_RANK
    filtered = ["HARDSHEAR-RANK;1"]
    capture = False
    for line in base_trace.decode("ascii").splitlines()[1:]:
        if line.startswith("BEGIN;"):
            capture = line.split(";")[1] in PEAKS
        if capture:
            filtered.append(line)
    alpha = previous(NEWTON)
    start = alpha.index("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Обе стороны")
    alpha = alpha[:start] + unit("Differences.bas") + "\n" + unit("Stations.bas")
    beta = previous(TEST)
    for name in ("Stock-1", "Stock-3", "Short4-3", "Short4-5"):
        beta, count = re.subn(rf'(?m)^(    rows.Add "){name};', r'\1;', beta)
        assert count == 1, name
    beta = beta.replace("RunTestHardShearRank", "RunTestHardShearSwitch").replace("TOTAL_HARD_SHEAR_RANK", "TOTAL_HARD_SHEAR_SWITCH")
    beta = beta.replace("HardRank.csv", "HardSwitch.csv").replace("HARDSHEAR-RANK;1", "HARDSHEAR-SWITCH;1")
    expected = json.loads(original["Expected.json"])
    expected["fields"] = {name: expected["fields"][name] for name in PEAKS}
    inputs = {
        CONT: save(CONT, original[CONT]),
        NEWTON: save(NEWTON, vba(alpha)),
        TEST: save(TEST, vba(beta)),
        "Expected.json": save("Expected.json", (json.dumps(expected, indent=2)+"\n").encode()),
        "OriginalPeakTrace.csv": save("OriginalPeakTrace.csv", ("\n".join(filtered)+"\n").encode("ascii")),
        "RankVerify.py": save("RankVerify.py", original["Verify.py"]),
        "Guard-IsolatedOffice.ps1": save("Guard-IsolatedOffice.ps1", original["Guard-IsolatedOffice.ps1"]),
    }
    for name, checksum in rank["inputs"].items():
        if name.startswith("tools/build_workbook/"):
            raw = (PREVIOUS / name).read_bytes()
            assert digest(raw) == checksum
            inputs[name] = save(name, raw)
    for name in ("Stage.py", "Run.ps1", "Verify.py", "Stations.bas", "Differences.bas"):
        inputs[name] = digest((HERE / name).read_bytes())
    fixture = {"source_workbook_sha256": rank["source_workbook_sha256"], "source_revision": rank["source_revision"],
               "workbook": rank["workbook"], "production": rank["production"], "assembled_from_rank_fixture_sha256": RANK_FIXTURE,
               "original_native_rank_trace_sha256": RAW_RANK,
               "source_shoulder_report_sha256": rank["source_shoulder_report_sha256"],
               "watchdog_seconds": 90, "inputs": inputs}
    print(save("Fixture.json", (json.dumps(fixture, indent=2)+"\n").encode()))


if __name__ == "__main__":
    main()
