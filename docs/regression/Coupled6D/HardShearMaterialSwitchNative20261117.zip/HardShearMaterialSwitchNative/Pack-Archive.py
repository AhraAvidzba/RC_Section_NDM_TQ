"""Запечатывает нативные данные переключения и два исходных прогона."""

from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_call, check_output
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from RankVerify import inputs, obj


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
PREFIX = "HardShearMaterialSwitchNative"
ARCHIVE = HERE / f"{PREFIX}20261117.zip"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def serialize(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main():
    fixture = obj("Fixture.json")
    inputs(fixture)
    paths = {*fixture["inputs"], "Fixture.json", "Compile.log", "CompileClosure.json", "Run.ndjson",
             "docs/regression/CodeUpdate.json", "Verify-Archive.py", "Pack-Archive.py", "README-Archive.md"}
    paths.update(p.relative_to(HERE).as_posix() for p in (HERE / "Native").iterdir() if p.is_file() and p.suffix.lower() != ".xlsm")
    content = {name: (HERE / name).read_bytes() for name in paths}
    for name, sha in fixture["production"].items():
        raw = check_output(["git", "show", f"{fixture['source_revision']}:{name}"], cwd=REPO)
        assert digest(raw) == sha
        content[f"Baseline/{name}"] = raw
    for name, previous, key in (("Fixture.json", "hs-rank/Fixture.json", "assembled_from_rank_fixture_sha256"),
                                ("HardRank.csv", "hs-rank/Native/HardRank.csv", "original_native_rank_trace_sha256"),
                                ("ShoulderVerification.json", "hs-fold/Native/Verification.json", "source_shoulder_report_sha256")):
        raw = (HERE.parent / previous).read_bytes()
        assert digest(raw) == fixture[key]
        content[f"Parent/{name}"] = raw
    log = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    elapsed = re.search(r"^RANK_TIME: ([0-9.,]+)$", log, re.M)
    saved = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", log, re.M)
    assert elapsed and saved
    saved_path = Path(saved[2]).resolve(strict=True)
    assert saved_path.is_relative_to(HERE / "Temp")
    audit = {"native_elapsed_seconds": float(elapsed[1].replace(",", ".")), "results_reopen_sha256": saved[1],
             "saved_workbook_sha256": digest(saved_path.read_bytes()), "report_sha256": digest(content["Native/Verification.json"])}
    content["Audit.json"] = serialize(audit)
    content["SHA256SUMS.json"] = serialize({name: digest(raw) for name, raw in sorted(content.items())})
    with TemporaryDirectory(prefix="switch-proof-", dir=HERE) as directory:
        scratch = Path(directory)
        archive = scratch / ARCHIVE.name
        with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=9) as bundle:
            for name, raw in sorted(content.items()):
                entry = ZipInfo(f"{PREFIX}/{name}", date_time=(2026, 11, 17, 0, 0, 0))
                bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(archive) as bundle:
            assert bundle.testzip() is None and not any(n.lower().endswith(".xlsm") for n in bundle.namelist())
            bundle.extractall(scratch / "detached")
        cmd = [sys.executable, "-B", "-X", "utf8", "Verify-Archive.py"]
        cwd = scratch / "detached" / PREFIX
        check_call(cmd, cwd=cwd)
        check_call([*cmd, "--saved-workbook", str(saved_path)], cwd=cwd)
        ARCHIVE.write_bytes(archive.read_bytes())
    checksum = digest(ARCHIVE.read_bytes())
    ARCHIVE.with_suffix(".zip.sha256").write_bytes(f"{checksum}  {ARCHIVE.name}\n".encode("ascii"))
    print("PORTABLE HARD SHEAR MATERIAL SWITCH VERIFIED", checksum, ARCHIVE.stat().st_size)


if __name__ == "__main__":
    main()
