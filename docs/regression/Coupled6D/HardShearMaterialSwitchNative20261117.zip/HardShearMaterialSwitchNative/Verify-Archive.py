"""Повторно проверяет переход материала по точным данным станций и невязок."""

import argparse
from pathlib import Path
from tempfile import TemporaryDirectory

from RankVerify import digest, obj, parse
from Verify import analyze, extract


HERE = Path(__file__).resolve().parent


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--saved-workbook", type=Path)
    args = cli.parse_args()
    manifest = obj("SHA256SUMS.json")
    paths = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file() and p.name != "SHA256SUMS.json"}
    assert paths == set(manifest) and all(digest(HERE / name) == sha for name, sha in manifest.items())
    fixture = obj("Fixture.json")
    rank = obj("Parent/Fixture.json")
    audit = obj("Audit.json")
    for name, expected in fixture["inputs"].items():
        assert manifest[name] == expected
    for name, expected in fixture["production"].items():
        assert manifest[f"Baseline/{name}"] == expected
    assert manifest["Parent/Fixture.json"] == fixture["assembled_from_rank_fixture_sha256"]
    assert manifest["Parent/HardRank.csv"] == fixture["original_native_rank_trace_sha256"]
    assert manifest["Parent/ShoulderVerification.json"] == fixture["source_shoulder_report_sha256"]
    assert rank["source_workbook_sha256"] == fixture["source_workbook_sha256"]
    code = obj("docs/regression/CodeUpdate.json")
    compiler = obj("CompileClosure.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    receipt = obj("Native/HardShear.txt.ProcessClosure.json")
    closure = receipt["Closure"]["FinalState"]
    assert code["Compiled"] and not code["ProductionChanged"] and code["ProductionSHA256"] == fixture["source_workbook_sha256"]
    assert code["Modules"] == ["CCoupledDeformationContinuation", "CCoupledNewtonSolver", "modTestCoupledElasticState"]
    assert compiler["State"] == "Absent" and f"OWNED_EXCEL: id={compiler['PID']}; utcStartTicks={compiler['StartTicksUTC']}" in (
        HERE / "Compile.log").read_text(encoding="utf-8-sig")
    assert owner["SourceSHA256"] == code["WorkbookSHA256"]
    assert receipt["Passed"] and receipt["ChildExitCode"] == 0 and closure["State"] == "Absent"
    assert (owner["PID"], owner["StartTicksUTC"]) == (closure["PID"], closure["StartTicksUTC"])
    native = obj("Native/Verification.json")
    assert manifest["Native/HardSwitch.csv"] == native["native_trace_sha256"]
    assert not native["perturbed_fields_are_equilibria"] and not native["physical_limit_certified"]
    assert native["tangent_rank_between_equilibria"] == "open"
    raw = (HERE / "Native/HardSwitch.csv").read_text(encoding="ascii")
    clean, stations = extract(raw)
    with TemporaryDirectory() as directory:
        path = Path(directory) / "switch.csv"
        path.write_text(clean, encoding="ascii")
        cases = parse(path)
    prior = parse(HERE / "OriginalPeakTrace.csv")
    archived = parse(HERE / "Parent/HardRank.csv")
    assert set(cases) == set(prior) == set(stations) == {"Stock-2", "Short4-4"}
    assert prior == {key: archived[key] for key in prior}
    results = [analyze(case, prior[name], stations[name]) for name, case in cases.items()]
    for result, expected in zip(results, native["assembled_cases"], strict=True):
        assert result["case"] == expected["case"]
        assert result["finite_action_bracket"] == expected["finite_action_bracket"]
        assert result["same_archived_equilibrium_and_tangent"] and not result["failed_residual_probes"]
        for first, second in zip(result["one_sided"], expected["one_sided"], strict=True):
            assert all(first[key] == second[key] for key in ("signed_step", "changed_relative_to_archived_peak", "unread_stations"))
            for key in ("relative_projected_action_difference", "relative_projected_action_norm"):
                assert abs(first[key]-second[key]) <= 1e-11*(1+abs(second[key]))
        bracket = result["finite_action_bracket"]
        assert bracket["same_history_test_increment_interval"] == [5e-12, 8e-12] and not bracket["unread_stations"]
        station, = bracket["changed_stations"]
        assert (station["point"], station["axial_side"]) == (22, -1) and station["yield_strictly_bracketed"]
        assert not station["left"]["plastic"] and station["right"]["plastic"]
        assert all(station[side]["principal_sign"] == 1 and station[side]["substeps"] == 1 for side in ("left", "right"))
    log = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_SWITCH: passed=1; failed=0" in log
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    assert f"RESULTS_SAVE_REOPEN: before={audit['results_reopen_sha256']}; after={audit['results_reopen_sha256']}; equal=True" in log
    assert manifest["Native/Verification.json"] == audit["report_sha256"]
    if args.saved_workbook:
        assert digest(args.saved_workbook) == audit["saved_workbook_sha256"]
    print("HARDSHEAR MATERIAL SWITCH PORTABLE VERIFIED")
    print("Two exact base fields, brackets [5e-12, 8e-12], only station 22 at side -1 changed in each bracket")


if __name__ == "__main__":
    main()
