' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает каждую станцию материала от того же принятого буфера, что и невязку.
' Читающие методы не меняют историю, напряжения и признаки последней принятой пробы.
Private Sub RecordHardSwitchStationsTest(ByRef field() As Double, ByVal signedStep As Double)
    Dim lines() As String: ReDim lines(0 To 3 * mPointCount)
    Dim point As Long, side As Long, index As Long, offset As String
    Dim strain(1 To COMPONENT_COUNT) As Double, unused(1 To COMPONENT_COUNT) As Double
    Dim response As CCoupledReinforcedResponse, yieldValue As Double
    Dim isPlastic As Boolean, principal As Long, substeps As Long
    offset = HardRankBitsTest(signedStep)
    lines(0) = "STATIONS;" & offset & ";" & CStr(mPointCount)
    For point = 1 To mPointCount
        For side = -1 To 1
            Set response = YieldResponse(side)
            YieldStrain point, side, field, strain
            index = index + 1
            lines(index) = "STATION;" & CStr(point) & ";" & CStr(side) & ";"
            If response.TryReadTrialYield(point, strain, yieldValue, unused, False) And _
                    response.TryReadConcreteBranch(point, strain, isPlastic, principal, substeps) Then
                lines(index) = lines(index) & "ok;" & HardRankBitsTest(yieldValue) & ";" & _
                    CStr(isPlastic) & ";" & CStr(principal) & ";" & CStr(substeps)
            Else
                lines(index) = lines(index) & "failed"
            End If
        Next side
    Next point
    WriteHardRankRowTest Join(lines, vbCrLf)
End Sub
