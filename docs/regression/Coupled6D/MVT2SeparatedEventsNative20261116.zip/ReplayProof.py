"""Reproduce native event isolation and quantify physically integrated paired effects."""
import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from io import BytesIO
import json
from math import fsum
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

import VerifyBase as v

HERE=Path(__file__).resolve().parent
TRACE="CE82F4DED6CADFAE3641CA1C58991F0049A0F9F563000359FABED96CD7A31F96"


def load_test():
    spec=spec_from_file_location("event_test",HERE/"Verify-MVT2ShearControlled.py")
    test=module_from_spec(spec)
    spec.loader.exec_module(test)
    return test


def independent(proof,known):
    tags=v.read_native(HERE/"NativeHalf/MVT2.csv")
    states,stations=v.verified_states(tags)
    origin=states["NormalsHalf"]
    cases=proof["cases"]
    paired={}
    for cell,side in ((15,-1),(3,1)):
        a,b=stations[f"P{cell}Minus"],stations[f"P{cell}Plus"]
        contrib=[]
        for point in range(1,46):
            x,y,area=a[point,0][:3]
            gradients=tuple((b[point,1][i]-b[point,-1][i]-a[point,1][i]+a[point,-1][i])/.002 for i in (15,17,18))
            dz,dxz,dyz=gradients
            contrib.append((point,area/v.AREA*x/v.LENGTH*dz,area/(v.AREA*v.LENGTH)*(x*dyz-y*dxz)))
        total=tuple(fsum(row[i] for row in contrib) for i in (1,2))
        official=proof["isolated_event_pairs"][str(cell)]["delta_weak55_56_MPa"]
        assert v.peak(v.diff(official,total))<4e-10
        own=contrib[cell-1][1:]
        paired[str(cell)]={"event":(cell,side),"measured_pair_delta_rows55_56_MPa":total,
            "actual_target_point_contribution_MPa":own,
            "sum_of_other_points_MPa":v.diff(total,own),
            "largest_terms_for_row55":[row for row in sorted(contrib,key=lambda k:abs(k[1]),reverse=True)[:6]],
            "largest_terms_for_row56":[row for row in sorted(contrib,key=lambda k:abs(k[2]),reverse=True)[:6]]}
    init=origin["r"]
    z0=origin["norm_MPa"]
    r55=init[54]
    T=-init[59]
    assert z0>r55>0. and T>r55
    rows=[item["all66_MPa"] for item in cases.values()]
    a=min(row[54]-r55 for row in rows)
    b=max(T+row[59] for row in rows)
    assert a>0. and b>0.
    w=(T-r55)/(a+b)
    assert 0.<w<1.
    lower=max(r55+a*w,T-b*w)
    best_N=min(abs(row[56]) for row in rows)
    assert best_N>z0
    tau=origin["tol_MPa"]
    needed_N=(best_N-z0)*v.AREA
    needed_grad=min(row[54] for row in rows)-z0
    measurable={"affine_hull_plus_exact_gauge_reactions_lower_bound_MPa":lower,
        "maximum_possible_gain_over_tau_from_two_rows":(z0-lower)/tau,
        "potential_total_weight_at_bound":w,"minimum_positive_weak55_increase_when_using_probes_MPa":a,
        "largest_possible_T_relief_using_probes_MPa":b,
        "probe_centers_best_abs_N_normalized_MPa":best_N,"best_event_center_requires_additional_N_improvement_N":needed_N,
        "every_event_state_requires_r55_reduction_MPa":needed_grad,
        "five_tau_target_minimum_N_restore_N":(best_N-z0+5*tau)*v.AREA,
        "five_tau_target_minimum_r55_restore_MPa":needed_grad+5*tau,
        "bounds_apply_to_affine_reuse_only":True}
    assert measured_caps(proof,known)
    return {"actual_pair_actions":paired,"measured_action_reuse":measurable}


def measured_caps(proof,known):
    return all(all(abs(a)<=bound for a,bound in zip(c["all66_MPa"][56:62],known["force_caps_MPa"],strict=True))
               for c in proof["cases"].values())


def redo_plan(nested):
    target=HERE/"PlanReplay"
    target.mkdir(exist_ok=True)
    with ZipFile(nested) as outer:
        force=outer.read("Decision/MVT2Force15Native20261116.zip")
    assert sha256(force).hexdigest().upper()=="AAF97ABED8510F390488F2A5C515E57431BED7ED56694181D2CD763F35A8900F"
    with ZipFile(BytesIO(force)) as inner:
        lock=inner.read("Decision/MVT2BranchLockedNative20261116.zip")
    assert sha256(lock).hexdigest().upper()=="42648C93E2A03D55A09F8E9688357D062D3E4210F98FA4B7507CF3FB5820FFF5"
    with ZipFile(BytesIO(lock)) as early:
        fresh=early.read("Decision/MVT2ReactedFreshNative20261116.zip")
    assert sha256(fresh).hexdigest().upper()=="5DCAB88E25FD13C1DB6C43A8898243D2AF03E906ADA2F87C31A17638E84ABA3E"
    with ZipFile(BytesIO(fresh)) as last:
        for filename in ("PlanFresh.py","NativeA/MVT2.csv"):
            output=target/filename
            output.parent.mkdir(parents=True,exist_ok=True)
            output.write_bytes(last.read(filename))
    temp=target/"Plan"
    subprocess.run([sys.executable,"-B","-X","utf8",str(HERE/"Plan.py"),str(nested),str(target),str(temp)],check=True)
    assert (temp/"EventPlan.json").read_bytes().replace(b"\r\n",b"\n")==(
        HERE/"EventPlan.json").read_bytes().replace(b"\r\n",b"\n")


def replay(options):
    prep=v.read(HERE/"Preparation.json")
    plan=v.read(HERE/"EventPlan.json")
    assert all(v.digest(HERE/name)==expected for name,expected in prep["inputs"].items())
    if options.workbook is not None:
        assert v.digest(options.workbook)==prep["book_sha256"]
    prior=HERE/"Decision/MVT2MeasuredNormalsNative20261116.zip"
    assert v.digest(prior)==prep["source_trace_bundle_sha256"]
    with ZipFile(prior) as package:
        assert (HERE/"PreviousNative.csv").read_bytes()==package.read("NativeHalf/MVT2.csv")
    if options.decision:
        redo_plan(prior)
    test=load_test()
    old,stations=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    anchor=old["NormalsHalf"]
    assert tuple(plan["base_field"])==anchor["field"]==tuple(map(float,test.grid("AnchorField.csv")[0]))
    assert v.peak(v.diff(test.full(anchor,stations["NormalsHalf"]),plan["base_all66_MPa"]))<4e-15
    inputs={}
    for row,spec in zip(test.grid("Half/Candidate.csv"),plan["witnesses"],strict=True):
        label,radius,filler,*values=row
        assert label==spec["label"] and tuple(map(float,values))==tuple(spec["dq"])
        assert float(filler)==0. and v.tensor_radius(spec["dq"],anchor["geometry"])<=float(radius)+4e-16
        inputs[label]=spec
    result=test.attest(prep,plan,anchor,stations["NormalsHalf"],inputs)
    assert result["trace_sha256"]==TRACE
    assert all(row["isolated_material_switch"] for row in result["isolated_event_pairs"].values())
    verified=HERE/"VerificationHalf.json"
    assert (json.dumps(result,indent=2)+"\n").replace("\n","\r\n").encode("utf8")==verified.read_bytes()
    report={"input_workbook_sha256":prep["book_sha256"],"H24_sha256":prep["replay_sha256"],
            "overlay_sha256":prep["inputs"]["tests/modTestCoupledExperiment.bas"],"plan_sha256":prep["inputs"]["EventPlan.json"],
            "verification_sha256":v.digest(verified),"native_trace_sha256":TRACE,
            "exact_H24_rollback":result["exact_H24_rollback"],"history_published":False,
            "compiler":result["compiler"],"solver":result["solver"],"native_wall_s":result["native_wall_s"],
            "archive_anchor_vector_error_MPa":result["source_vector_error_MPa"],"q_trial_kN":result["q_trial_kN"],
            "last_accepted_Qy_kN":result["last_accepted_Qy_kN"],"actual_event_pairs":result["isolated_event_pairs"],
            "independent_station_and_force_findings":independent(result,plan)}
    output=HERE/"PortableReport.json"
    output.write_bytes((json.dumps(report,indent=2)+"\n").encode("utf8"))
    print(output,v.digest(output))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--decision",action="store_true")
    p.add_argument("--workbook",type=Path)
    replay(p.parse_args())
