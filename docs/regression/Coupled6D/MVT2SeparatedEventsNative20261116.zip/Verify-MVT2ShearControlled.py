"""Check four separated signed event probes from the exact NormalsHalf history."""
import argparse
import csv
import json
from pathlib import Path

import VerifyBase as v

HERE=Path(__file__).resolve().parent
RUN=HERE/"NativeHalf"


def full(state,station):
    weak,_,_=v.reconstruct(state["field"],state["q"],station)
    return (*state["r"],*(a*v.MODULUS for a in weak[-4:]))


def grid(name):
    raw=(HERE/name).read_bytes()
    assert raw.count(b"\r\n")==raw.count(b"\n")
    return list(csv.reader(raw.decode("ascii").splitlines(),delimiter=";"))


def preflight():
    prep=v.read(HERE/"Preparation.json")
    assert all(v.digest(HERE/name)==digest for name,digest in prep["inputs"].items())
    assert v.digest(HERE/"workbook/output/RC_Section_NDM.xlsm")==prep["book_sha256"]
    plan=v.read(HERE/"EventPlan.json")
    assert plan["archive_base_trace_sha256"]==v.digest(HERE/"PreviousNative.csv")
    old,station=v.verified_states(v.read_native(HERE/"PreviousNative.csv"))
    base=old["NormalsHalf"]
    assert base["q"]==plan["Qy_kN"]==18.5720088671875
    assert grid("AnchorField.csv")==[[str(i) for i in base["field"]]]
    assert tuple(plan["base_field"])==base["field"]
    archived=full(base,station["NormalsHalf"])
    assert tuple(map(float,grid("ArchiveOrigin.csv")[0]))==tuple(plan["base_all66_MPa"])
    assert v.peak(v.diff(archived,plan["base_all66_MPa"]))<4e-15
    assert plan["target_half_width_MPa"]>=64*plan["verified_signed_surface_error_MPa"]
    rows=grid("Half/Candidate.csv")
    keyed={}
    for row,spec in zip(rows,plan["witnesses"],strict=True):
        label,radius,filler,*values=row
        assert label==spec["label"]
        dq=tuple(map(float,values))
        assert tuple(spec["dq"])==dq and len(dq)==60
        signed=spec["signed_surfaces_MPa"][str((spec["target_point"],spec["target_side"]))]
        v.near(signed,spec["sign"]*plan["target_half_width_MPa"],5e-13)
        assert float(radius)==spec["max_strain"] and float(filler)==0.
        assert v.tensor_radius(dq,base["geometry"])<=float(radius)+4e-16<=1e-8+4e-16
        keyed[label]=spec
    assert list(keyed)==["P15Minus","P15Plus","P3Minus","P3Plus"]
    return prep,plan,base,station["NormalsHalf"],keyed


def attest(prep,plan,old,old_station,keyed):
    build=v.read(HERE/"docs/regression/CodeUpdate.json")
    compiler=v.read(HERE/"CompileClosure.json")
    owner=v.read(RUN/"MVT2.txt.Ownership.json")
    watchdog=v.read(RUN/"MVT2.txt.ProcessClosure.json")
    runtime=v.read(RUN/"RunReceipt.json")
    closed=watchdog["Closure"]["FinalState"]
    assert build["Compiled"] and not build["ProductionChanged"] and build["Modules"]==["modTestCoupledExperiment"]
    assert build["ProductionSHA256"]==prep["book_sha256"] and compiler["State"]=="Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==build["WorkbookSHA256"]
    assert watchdog["Passed"] and watchdog["ChildHasExited"] and watchdog["ChildExitCode"]==runtime["native_exit"]==0
    assert closed["State"]=="Absent" and closed["PID"]==owner["PID"] and closed["StartTicksUTC"]==owner["StartTicksUTC"]
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in (RUN/"MVT2.txt").read_text(encoding="utf-8-sig")
    path=RUN/"MVT2.csv"
    tags=v.read_native(path)
    states,stations=v.verified_states(tags)
    [[qbase,q]]=tags["B_TANGENT_LOAD"]
    assert (float(qbase),float(q))==(plan["accepted_Qy_kN"],plan["Qy_kN"])
    assert tags["B_FRESH_PHASE"]==[["Half"]] and tags["B_FRESH_PROBES"]==[["4"]]
    history=v.vec(tags,"MVT2_CONTROL_FIELD")
    replay=list(csv.reader((HERE/"Replay.csv").read_text().splitlines(),delimiter=";"))[1:]
    assert len(replay)==len(history)==24
    for i,row in enumerate(replay,1):
        assert int(row[0])==i and v.peak(v.diff(tuple(map(float,row[9:])),history[f"Replay{i}"]))<1e-15
    assert states["Restored24"]==states["Base24"] and stations["Restored24"]==stations["Base24"]
    assert states["Base24"]["field"]==history["Replay24"] and states["Base24"]["q"]==float(qbase)
    base=states["NormalsHalf"]
    vec0=full(base,stations["NormalsHalf"])
    error=v.peak(v.diff(vec0,full(old,old_station)))
    assert error<=plan["archive_raw_vector_gate_MPa"]
    assert abs(error-float(tags["B_EVENT_ORIGIN"][0][0]))<=4e-10
    assert v.peak(v.diff(base["field"],old["field"]))<3e-15
    steel=v.verify_steel(tags,states,stations,history)
    surface={}
    for label,point,side,ok,F,*grad in tags["B_FORCE_SURFACE"]:
        key=int(point),int(side)
        assert (label,key) not in surface
        raw=stations[label][key]
        assert abs(raw[6]-float(F))<4e-10
        surface[label,key]={"F":float(F),"gradient":list(map(float,grad)) if int(ok) else None,"flags":raw[3:6]}
    inspected=tuple((i,j) for i in (3,15,19) for j in (-1,0,1))
    cases={}
    for name,spec in keyed.items():
        if name not in states:
            assert [name,"Residual"] in tags["B_TANGENT_UNAVAILABLE"]
            cases[name]={"available":False}
            continue
        s=states[name]
        assert s["q"]==base["q"] and s["geometry"]==base["geometry"]
        dq=v.diff(s["field"],base["field"])
        assert v.peak(v.diff(dq,spec["dq"]))<3e-15
        shape=v.tensor_radius(dq,s["geometry"])
        assert shape<=spec["max_strain"]+4e-16
        vector=full(s,stations[name])
        signed={str(key):surface[name,key] for key in inspected}
        violations=[key for key,a,c in zip(v.EFFORT_NAMES,vector[56:62],plan["force_caps_MPa"],strict=True) if abs(a)>c]
        a=signed[str((spec["target_point"],spec["target_side"]))]
        cases[name]={"available":True,"norm_MPa":v.peak(vector),"all66_MPa":vector,
           "actual_six_N_Nmm":[f+r for f,r in zip(v.force(float(q)),s["signed_force_N_Nmm"],strict=True)],
           "six_signed_residuals_N_Nmm":s["signed_force_N_Nmm"],"cap_violations":violations,
           "weak55_56_MPa":list(vector[54:56]),"gauge_MPa":list(vector[-4:]),"peak_steel_MPa":steel[name],
           "inspected_surfaces":signed,"observed_target_sign_at_least_half_width":spec["sign"]*a["F"]>=.5*plan["target_half_width_MPa"]}
    pairs={}
    for point,side in ((15,-1),(3,1)):
        a,b=f"P{point}Minus",f"P{point}Plus"
        if not cases[a]["available"] or not cases[b]["available"]:
            pairs[str(point)]={"both_available":False}
            continue
        key=point,side
        aa,bb=surface[a,key],surface[b,key]
        all_flags=[k for k in stations[a] if stations[a][k][3:6]!=stations[b][k][3:6]]
        protected=all(surface[a,k]["F"]*surface["NormalsHalf",k]["F"]>0. and surface[b,k]["F"]*surface["NormalsHalf",k]["F"]>0. and
                      min(abs(surface[a,k]["F"]),abs(surface[b,k]["F"]))>=.5*plan["non_target_signed_guard_MPa"]
                      for k in inspected if k!=key)
        signed_bracket=aa["F"]<0.<bb["F"] and cases[a]["observed_target_sign_at_least_half_width"] and cases[b]["observed_target_sign_at_least_half_width"]
        delta=v.diff(cases[b]["all66_MPa"],cases[a]["all66_MPa"])
        f_width=bb["F"]-aa["F"]
        pairs[str(point)]={"both_available":True,"target":key,"target_minus_F_MPa":aa["F"],"target_plus_F_MPa":bb["F"],
            "other_inspected_signs_protected":protected,"branches_changed_all_stations":all_flags,
            "isolated_material_switch":signed_bracket and protected and all_flags==[key],
            "signed_bracket_confirmed":signed_bracket,"delta_weak55_56_MPa":list(delta[54:56]),
            "signed_six_effort_delta_N_Nmm":[z*f for z,f in zip(delta[56:62],v.SCALES,strict=True)],
            "delta_weak55_56_per_delta_F":[k/f_width for k in delta[54:56]] if f_width else None}
    return {"trace_sha256":v.digest(path),"book_sha256":prep["book_sha256"],"source_vector_error_MPa":error,
            "q_trial_kN":float(q),"last_accepted_Qy_kN":float(qbase),"exact_H24_rollback":True,
            "history_published":False,"physical_limit_claimed":False,"cases":cases,"isolated_event_pairs":pairs,
            "native_wall_s":runtime["wall_seconds"],"compiler":compiler,"solver":closed}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--inputs-only",action="store_true")
    p.add_argument("--phase",choices=("Half",))
    args=p.parse_args()
    evidence=preflight()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert args.phase=="Half"
        result=attest(*evidence)
        dest=HERE/"VerificationHalf.json"
        dest.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
        print(dest,v.digest(dest))
