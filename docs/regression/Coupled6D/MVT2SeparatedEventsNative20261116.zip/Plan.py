"""Separate two near-simultaneous measured yield surfaces using mirrored physical pairs."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
PIN="84DAF40599AD0FE9A0AE1C2EBA2CF2F72DED306F0F47B222F1A0528216D50A86"
NATIVE="11BC995BCE708919D632A441162AED37A6896A79F6083836191F0E44806EF4C7"
EVENTS=((15,-1),(3,1))


def sha(data):
    return sha256(data).hexdigest().upper()


def physical_problem(v,model,report,prior,base,accepted,old_tangent,trace,out):
    geometry=base["geometry"]
    q=np.array(base["field"])
    d=np.array(v.diff(q,accepted["field"]))
    r=np.asarray(report["native_force_half_all66_MPa"])
    old=np.array(report["governing_weak_rows_55_56_MPa"])
    anchor_weak,_,_=v.reconstruct(old_tangent[1]["field"],old_tangent[1]["q"],old_tangent[2])
    actual=np.r_[old_tangent[1]["r"],np.array(anchor_weak[-4:])*v.MODULUS]
    models,G,_=model.assembled(old_tangent[0],actual,old_tangent[1],geometry,base["q"])
    J={name:models[name] for name in ("Consistent","Refined")}
    assert np.max(abs(np.array(r[54:56])-old[:,1]))<4e-10
    S=model.strain_matrix(geometry)
    index={key:i for i,key in enumerate(geometry)}
    surfaces={}
    for row in report["station_branch_gradients"]:
        key=row["point"],row["side"]
        i=index[key]
        s=S[6*i:6*(i+1)].copy()
        s[3:]*=np.sqrt(2.)
        normal=np.asarray(row["gradient_after"])@s
        surfaces[key]=float(row["F_after_MPa"]),normal
    surface_error=max(abs(a["tangent_estimate_delta_F_MPa"]-a["actual_delta_F_MPa"])
                      for a in report["station_branch_gradients"])
    halfwidth=1.5e-6
    assert halfwidth>=64*surface_error and len(surfaces)==9
    guard=3*halfwidth
    caps=np.array(prior["original_caps_MPa"])
    nominal=np.max([abs(np.asarray(report["native_force_half_all66_MPa"])-np.asarray(z))
                    for z in prior["predicted_half_all66_MPa"].values()],axis=0)
    # Both probes stay within the historical 10^-8 trust range. The six predictions reserve
    # the actual preceding error and independent archive rounding. The post-event measured
    # forces still decide status because the extrapolated tangent is one-sided.
    reserve=np.maximum(nominal,8e-10)
    m=60
    field_scale=np.r_[np.full(56,1e-9),np.full(4,1e-3)]
    shape=S*field_scale/1e-9
    limits=np.r_[G*field_scale/1e-9]
    entries=[]
    for target in EVENTS:
        other=next(key for key in EVENTS if key!=target)
        F,n=surfaces[target]
        # x is a center offset from the old direction d and y is the signed half separation.
        zeros=np.zeros(m)
        E=[]
        rhs=[]
        for g,gv,d_gauge in zip(limits,r[-4:]/v.MODULUS,G@d,strict=True):
            E.extend([np.r_[g,zeros,0.],np.r_[zeros,g,0.]])
            rhs.extend([(-gv-d_gauge)/1e-9,0.])
        n=surfaces[target][1]
        E.extend([np.r_[n*field_scale/.001,zeros,0.],np.r_[zeros,n*field_scale/.001,0.],
                  np.r_[zeros,surfaces[other][1]*field_scale/.001,0.]])
        rhs.extend([(-F-n@d)/.001,halfwidth/.001,0.])
        C=[]
        bounds=[]
        for sign in (-1.,1.):
            for j,a in enumerate(shape):
                original=(S@d)[j]/1e-9
                C.extend([np.r_[a,sign*a,-1],np.r_[-a,-sign*a,-1],
                          np.r_[a,sign*a,0],np.r_[-a,-sign*a,0]])
                bounds.extend([0.,0.,10.-original,10.+original])
            for key,(F,n) in surfaces.items():
                if key==target:
                    continue
                w=-np.sign(F)*n*field_scale/.001
                C.append(np.r_[w,sign*w,0.])
                bounds.append((np.sign(F)*(F+n@d)-guard)/.001)
            for L in J.values():
                for i,a in enumerate(L[56:62]):
                    residual=r[56+i]+a@d
                    coeff=a*field_scale/1e-4
                    C.extend([np.r_[coeff,sign*coeff,0.],np.r_[-coeff,-sign*coeff,0.]])
                    bounds.extend([(caps[i]-reserve[56+i]-residual)/1e-4,(caps[i]-reserve[56+i]+residual)/1e-4])
        cost=np.r_[np.zeros(2*m),1.]
        pair=linprog(cost,A_ub=np.asarray(C),b_ub=np.asarray(bounds),A_eq=np.asarray(E),b_eq=np.asarray(rhs),
                     bounds=[(None,None)]*(2*m)+[(0.,None)],method="highs",
                     options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
        assert pair.success,(target,pair.message)
        center=d+pair.x[:m]*field_scale
        amplitude=pair.x[m:2*m]*field_scale
        for sign,name in ((-1,"Minus"),(1,"Plus")):
            dq=center+sign*amplitude
            estimated={str(k):float(ff+nn@dq) for k,(ff,nn) in surfaces.items()}
            max_strain=float(max(abs(S@dq)))
            assert max_strain<=1e-8+4e-16
            assert abs(estimated[str(target)]-sign*halfwidth)<5e-13
            assert all(value*surfaces[k][0]>0. and abs(value)>=guard-5e-13 for k in surfaces
                       if k!=target for value in (estimated[str(k)],))
            assert max(abs(G@dq+r[-4:]/v.MODULUS))<2e-17
            entries.append({"label":f"P{target[0]}{name}","target_point":target[0],"target_side":target[1],"sign":sign,
                "dq":list(dq),"max_strain":max_strain,"signed_surfaces_MPa":estimated,
                "signed_forces_MPa":{k:list((r+L@dq)[56:62]) for k,L in J.items()},
                "physical_pair_half_separation":float(max(abs(S@amplitude))),
                "max_physical_offset_from_old_direction":float(pair.fun*1e-9)})
    q_trial=base["q"]
    plan={"archive_base_trace_sha256":trace,"Qy_kN":q_trial,"accepted_Qy_kN":18.55811,"tau_MPa":base["tol_MPa"],
          "base_field":list(q),"base_all66_MPa":list(r),"verified_signed_surface_error_MPa":surface_error,
          "target_half_width_MPa":halfwidth,"non_target_signed_guard_MPa":guard,
          "force_caps_MPa":list(caps),"archive_raw_vector_gate_MPa":8e-10,
          "old_direction_cannot_resolve_two_events_guaranteed":True,"witnesses":entries}
    path=out/"EventPlan.json"
    path.write_text(json.dumps(plan,indent=2)+"\n",encoding="utf8")
    print("EventPlan.json",sha(path.read_bytes()),"error",surface_error)
    for row in entries:
        print(row["label"],row["max_strain"],row["max_physical_offset_from_old_direction"],
              [row["signed_surfaces_MPa"][str(x)] for x in EVENTS])


def main(artifact,old_source,out):
    assert sha(artifact.read_bytes())==PIN
    out.mkdir(parents=True,exist_ok=True)
    with ZipFile(artifact) as z:
        for member in ("VerifyBase.py","NativeHalf/MVT2.csv","VerificationHalf.json","ForceProbe.json"):
            p=out/member
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(z.read(member))
    sys.path.insert(0,str(out))
    sys.path.insert(0,str(old_source))
    import VerifyBase as v
    import PlanFresh as model
    trace=out/"NativeHalf/MVT2.csv"
    assert v.digest(trace)==NATIVE
    measured,stations=v.verified_states(v.read_native(trace))
    old=v.read_native(old_source/"NativeA/MVT2.csv")
    states,old_stations=v.verified_states(old)
    physical_problem(v,model,v.read(out/"VerificationHalf.json"),v.read(out/"ForceProbe.json"),
                     measured["NormalsHalf"],measured["ForceHalf"],(old,states["Reacted"],old_stations["Reacted"]),NATIVE,out)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("archive",type=Path)
    p.add_argument("earlier_extracted_sources",type=Path)
    p.add_argument("out",type=Path)
    a=p.parse_args()
    main(a.archive,a.earlier_extracted_sources.resolve(),a.out.resolve())
