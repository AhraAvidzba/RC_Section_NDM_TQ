"""Prepare a single current-workbook invocation for two separated branch events."""
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"forceN"
BOOK="8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF"
PRIOR="84DAF40599AD0FE9A0AE1C2EBA2CF2F72DED306F0F47B222F1A0528216D50A86"
PROBE="6BA987AB39FF25DECA90523738E3C7C9EA1FCE5F8C14F0B194463AE1345B80C3"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name,raw):
    loc=HERE/name
    loc.parent.mkdir(parents=True,exist_ok=True)
    if loc.exists():
        assert loc.read_bytes()==raw,loc
    else:
        loc.write_bytes(raw)
    return digest(raw)


def change(text,initial,final):
    assert text.count(initial)==1,initial
    return text.replace(initial,final)


def csv(rows):
    return ("\r\n".join(";".join(str(value) for value in row) for row in rows)+"\r\n").encode("ascii")


def main(repo):
    previous=BASE/"MVT2MeasuredNormalsNative20261116.zip"
    assert digest(previous.read_bytes())==PRIOR
    plan_native=(HERE/"Plan/EventPlan.json").read_bytes()
    assert digest(plan_native)==PROBE
    inputs={"EventPlan.json":save("EventPlan.json",plan_native)}
    plan=json.loads(plan_native)
    with ZipFile(previous) as evidence:
        prep=json.loads(evidence.read("Preparation.json"))
        for name in ("VerifyBase.py","Replay.csv","Guard-IsolatedOffice.ps1","Run-MVT2ShearControlled.ps1",
                   *(k for k in prep["inputs"] if k.startswith("tools/"))):
            inputs[name]=save(name,evidence.read(name))
            assert inputs[name]==prep["inputs"][name]
        prior_raw=evidence.read("NativeHalf/MVT2.csv")
        assert digest(prior_raw)==plan["archive_base_trace_sha256"]
        inputs["PreviousNative.csv"]=save("PreviousNative.csv",prior_raw)
        old=evidence.read("Control.bas").decode("utf8")
        tests=evidence.read("tests/modTestCoupledExperiment.bas").decode("utf8").replace("\r\n","\n")
    vba=change(old,'    norm = RecordWangTangentStateTest(output, "ForceHalf",','    norm = RecordWangTangentStateTest(output, "NormalsHalf",')
    vba=change(vba,'Не воспроизведено измеренное исходное поле ForceHalf.','Не воспроизведено измеренное исходное поле NormalsHalf.')
    vba=change(vba,'    If phase <> "Half" Then','''    CheckWangEventOriginTest output, folder & "ArchiveOrigin.csv", operators, residual, referenceForces, qTrial
    If phase <> "Half" Then''')
    vba=change(vba,'(label = "ForceHalf" Or label = "NormalsHalf")','(label = "NormalsHalf" Or Left$(label, 1) = "P")')
    vba+= (HERE/"AnchorGate.bas").read_text(encoding="utf8")
    entry="Public Function RunTestWangShearControlled("
    pos=tests.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,tests.index(entry))
    module=(tests[:pos]+vba).replace("\n","\r\n").encode("utf8")
    assert module.count(entry.encode())==1
    inputs["Control.bas"]=save("Control.bas",vba.encode("utf8"))
    inputs["AnchorGate.bas"]=digest((HERE/"AnchorGate.bas").read_bytes())
    inputs["tests/modTestCoupledExperiment.bas"]=save("tests/modTestCoupledExperiment.bas",module)
    inputs["AnchorField.csv"]=save("AnchorField.csv",csv([plan["base_field"]]))
    inputs["ArchiveOrigin.csv"]=save("ArchiveOrigin.csv",csv([plan["base_all66_MPa"]]))
    # The third column is a no-op predictor for the diagnostic, never a norm acceptance gate.
    inputs["Half/Candidate.csv"]=save("Half/Candidate.csv",csv(
        [(trial["label"],trial["max_strain"],0.,*trial["dq"]) for trial in plan["witnesses"]]))
    original=repo/"workbook/output/RC_Section_NDM.xlsm"
    book=original.read_bytes()
    assert digest(book)==BOOK
    save("workbook/output/RC_Section_NDM.xlsm",book)
    if not (HERE/"docs/regression/Diagnostic.xlsm").exists():
        save("docs/regression/Diagnostic.xlsm",book)
    for directory in ("src","NativeHalf","Temp"):
        (HERE/directory).mkdir(exist_ok=True)
    loc=repo/"src/Solver/CCoupledNewtonSolver.cls"
    material=repo/"src/Materials/CCoupledConcreteResponse.cls"
    h=digest(loc.read_bytes())
    c=digest(material.read_bytes())
    assert h=="CAC79E891D4222D116EBC91AC3767C2345AD8EEC852B910CA166B9B2C4FF799C"
    assert c=="92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C"
    inputs["Verify-MVT2ShearControlled.py"]=digest((HERE/"Verify-MVT2ShearControlled.py").read_bytes())
    result={"inputs":inputs,"book_sha256":BOOK,"source_trace_bundle_sha256":PRIOR,"source_solver_sha256":h,
            "source_concrete_sha256":c,"replay_sha256":inputs["Replay.csv"],"watchdog_seconds":200}
    print("Preparation.json",save("Preparation.json",(json.dumps(result,indent=2)+"\n").encode("utf8")))


if __name__=="__main__":
    main(Path(sys.argv[1]).resolve(strict=True))
