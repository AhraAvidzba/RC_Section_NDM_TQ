
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Останавливает направленные пробы при расхождении отклика установленной книги с точным NormalsHalf.
Private Sub CheckWangEventOriginTest(ByVal output As Integer, ByVal path As String, ByVal operators As CCoupledElasticState, _
        ByRef residual() As Double, ByRef efforts() As Double, ByVal factor As Double)
    Dim file As Integer, row As String, values As Variant, i As Long, area As Double, sectionLength As Double
    Dim scales(1 To 6) As Double, demand(1 To 6) As Double, discrepancy As Double
    file = FreeFile: Open path For Input As #file
    Line Input #file, row
    If Not EOF(file) Then Err.Raise 5, , "Неверное число строк архивного отклика."
    Close #file
    values = Split(row, ";")
    If UBound(values) <> 65 Then Err.Raise 5, , "Неполный архив отклика NormalsHalf."
    operators.CopyResultantResidualScales area, sectionLength
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For i = 1 To 56
        discrepancy = GeomMax(discrepancy, Abs(residual(i) - Val(values(i - 1))))
    Next i
    For i = 1 To 6
        scales(i) = area
        If i >= 2 And i <= 4 Then scales(i) = area * sectionLength
        discrepancy = GeomMax(discrepancy, Abs((efforts(i) - demand(i)) / scales(i) - Val(values(55 + i))))
    Next i
    For i = 1 To 4
        discrepancy = GeomMax(discrepancy, Abs(30000# * residual(56 + i) - Val(values(61 + i))))
    Next i
    Print #output, "B_EVENT_ORIGIN;" & ExperimentNumberTest(discrepancy)
    If discrepancy > 0.0000000008 Then Err.Raise 5, , "Отклик установленной книги не совпал с точным NormalsHalf."
End Sub
