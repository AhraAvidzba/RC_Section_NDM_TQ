"""Verify scoped direct-timing samples, force readback and native work counts."""
import argparse
from hashlib import sha256
import json
from math import hypot
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
FORCE=(9806.65,9806650.,9806650.,9806650.,9806.65,9806.65)
CASES={"Mixed":(28000.,510000.,180000.,1500000.,17000.,-7100.),"PureT":(0.,0.,0.,1500000.,0.,0.)}


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    data=path.read_bytes()
    return data.decode("utf-16" if data.startswith((b"\xff\xfe",b"\xfe\xff")) else "utf-8-sig").replace("\r\n","\n")


def info(path):
    return json.loads(read(path))


def one(pattern, text):
    [match]=re.findall(pattern,text,re.MULTILINE)
    return match


def number(text):
    return float(text.replace(",","."))


def prepare():
    prep=info(HERE/"Preparation.json")
    assert all(digest(HERE/name)==sha for name,sha in prep["frozen"].items())
    assert prep["frozen"]["workbook/output/RC_Section_NDM.xlsm"]==prep["book_sha256"]
    assert prep["order"]==list(CASES)
    return prep


def verify(prep):
    builder=info(HERE/"docs/regression/CodeUpdate.json")
    compile_owner=info(HERE/"CompileClosure.json")
    assert builder["Compiled"] and not builder["ProductionChanged"] and compile_owner["State"]=="Absent"
    assert builder["ProductionSHA256"]==prep["book_sha256"] and builder["Modules"]==["modTestCoupledElasticState"]
    assert builder["EntryPointNames"]==[prep["macro"]]
    results=[]
    for name,want in CASES.items():
        path=HERE/"Native"/f"{name}.txt"
        text=read(path)
        execution=read(HERE/"Native"/f"{name}.Execution.txt")
        wall=info(HERE/"Native"/f"{name}.Receipt.json")
        owner=info(path.with_name(path.name+".Ownership.json"))
        stopper=info(path.with_name(path.name+".ProcessClosure.json"))
        final=stopper["Closure"]["FinalState"]
        assert owner["SourceSHA256"]==builder["WorkbookSHA256"] and owner["BeforeWorkbookOpen"] and owner["VerifiedNewOwner"]
        assert stopper["Passed"] and stopper["ChildHasExited"] and stopper["ChildExitCode"]==wall["native_exit"]==0
        assert final["State"]=="Absent" and (final["PID"],final["StartTicksUTC"])==(owner["PID"],owner["StartTicksUTC"])
        assert "TIMING_STATES: direct=OK; capacity=N/A" in text
        assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in text
        assert "OK: direct-only chart has no capacity branch" in text
        saved, reopened=one(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]+); after=([0-9A-F]+); equal=True;",text)
        assert len(saved)==64 and reopened==saved
        checks=int(one(r"^TOTAL_COUPLED_TORQUE_TIMING: passed=(\d+); failed=0$",text))
        assert checks>=12
        direct_seconds=number(one(rf"^TIMING_SECONDS: (\S+) \| Direct \| Excel \| {name}$",text))
        assert direct_seconds>0. and wall["wall_seconds"]>=direct_seconds
        requested=tuple(map(number,one(r"^TIMING_INPUT_N_NMM: (.+)$",text).split(";")))
        assert requested==want
        entries=re.findall(r"^TIMING_RESULT: ([^;]+);([^;]+);([^\n]+)$",text,re.MULTILINE)
        assert [label for label,*_ in entries]==["N","Mx","My","T","Qx","Qy"]
        columns=[(number(actual)*scale,number(target)*scale) for (_,actual,target),scale in zip(entries,FORCE,strict=True)]
        resultants,demand=zip(*columns,strict=True)
        assert max(abs(a-b) for a,b in zip(demand,requested,strict=True))<1e-7
        if name=="PureT":
            area,length,tol=map(number,one(r"^TIMING_ZERO_SCALE: (.+)$",text).split(";"))
            assert abs(area-180*120)<1e-8 and 0.<length<=hypot(90.,60.)+1e-8 and tol==5e-7
        else:
            assert "TIMING_ZERO_SCALE" not in text
        for index,(a,b) in enumerate(zip(resultants,demand,strict=True)):
            if b:
                assert abs(a/b-1.)<5e-5
            else:
                assert name=="PureT" and abs(a)<=tol*area*(length if 1<=index<=3 else 1.)
        unit=one(r"^\[[^\]]+\] OUTPUT Length/Area/Force/Moment/Stress/Curvature: (.+)$",execution)
        assert unit.split("; ")[2:4]==["tf","tf*m"]
        assert "Знаки OUTPUT N/Mx/My: Tension; +Y tension; +X tension" in execution
        assert "Связанное равновесие подтверждено по шести усилиям." in execution
        assert "Статус несущей способности: N/A" in execution and "Прочитано сочетаний: 1" in execution
        mesh=int(one(r"Бетонных элементов: (\d+)$",execution))
        bars=int(one(r"Стержней арматуры: (\d+)$",execution))
        assert (mesh,bars)==(400,2)
        offset,q,accepted,rejected,work=one(r"Доля постоянной части: ([^;]+); lambda: ([^;]+); принято: (\d+); отклонено: (\d+); проб: (\d+)",execution)
        assert number(offset)==number(q)==1 and int(accepted)>0 and int(work)>=int(accepted)+int(rejected)
        batch=number(one(r"Время batch-расчета: (\S+) с$",execution))
        assert 0.<batch<=direct_seconds
        results.append({"load_case":name,"requested_N_Nmm":requested,"actual_N_Nmm":resultants,
                        "signed_errors_N_Nmm":tuple(a-b for a,b in zip(resultants,requested,strict=True)),
                        "physical_section_mesh_bars":[mesh,bars],"whole_excel_calculation_seconds":direct_seconds,
                        "batch_calculation_seconds":batch,"watchdog_with_reopen_seconds":wall["wall_seconds"],
                        "accepted_continuation_points":int(accepted),"rejected_continuation_probes":int(rejected),"equilibrium_probes":int(work),
                        "assertions":checks,"results_save_reopen_digest":saved,"native_report_sha256":digest(path),"owner_closed":final})
    mixed,pure=results
    return {"installed_source_sha256":prep["book_sha256"],"scope":"single sequential pair on one section, direct only",
            "whole_excel_difference_pure_minus_mixed_s":pure["whole_excel_calculation_seconds"]-mixed["whole_excel_calculation_seconds"],
            "runs":results,"compiler_closed":compile_owner}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    args=parser.parse_args()
    prep=prepare()
    if args.inputs_only:
        print("DIRECT_TORQUE_FROZEN",digest(HERE/"Preparation.json"))
    else:
        path=HERE/"Verification.json"
        path.write_bytes((json.dumps(verify(prep),indent=2)+"\n").encode())
        print(path,digest(path))
