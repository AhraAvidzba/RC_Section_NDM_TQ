"""Stage only a private benchmark entry point on the installed calculation workbook."""
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BOOK = "workbook/output/RC_Section_NDM.xlsm"
CODE = "workbook/output/VBA_All_Code.txt"
BOOK_SHA = "C603E41639484DB313C5390930BC52F1AC3CC42ED4CE01BC1946BC01ED84FA95"
CODE_SHA = "7C5D85EF5D7500E95541EDF1AAF1BEC9AF2177A3B65491356A6DFE16335E365E"
MODULE_FILE = "tests/modTestCoupledElasticState.bas"
TOOLS = ("Run-Audit03Watchdog.ps1","Run-Audit02ModeTests.ps1","Update-PrivateWorkbookCode.ps1",
         "GeometryExampleSupport.ps1","SettingsCatalog.ps1","WorkbookLayout.ps1","WorkbookLayout.json",
         "HelpSettingsDescriptions.json","HelpFormulaExplanations.json","NormativeFormulaImages.ps1",
         "NormativeFormulaImages.json","NormativeHelpReferences.json","NormativeHelpSources.json",
         "GeometryTables.ps1","GeometryTables.json")


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name,raw):
    path = HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, name
    else:
        path.write_bytes(raw)
    return digest(raw)


def main():
    original = (ROOT/BOOK).read_bytes()
    assert digest(original) == BOOK_SHA
    export = (ROOT/CODE).read_bytes()
    assert digest(export) == CODE_SHA
    actual = export.decode("utf-8-sig")
    for item in ("TestHardShearLoads", "TestPrepareCoupledTimingBook", "TestCoupledTimingNumber", "TestLoadTraceChart"):
        assert f"Private Function {item}(" in actual or f"Private Sub {item}(" in actual
    assert "TestHardShearLoads = Array(28000#, 510000#, 180000#, 1500000#, 17000#, -7100#)" in actual
    identity = {BOOK:put(BOOK,original)}
    assert put("docs/regression/Diagnostic.xlsm",original) == BOOK_SHA
    for folder in ("Temp","Native","src"):
        (HERE/folder).mkdir(exist_ok=True)
    for tool in TOOLS:
        path = "tools/build_workbook/"+tool
        identity[path] = put(path,(ROOT/path).read_bytes())
    identity["Guard-IsolatedOffice.ps1"] = put("Guard-IsolatedOffice.ps1",(HERE.parent/"mv26p/Guard-IsolatedOffice.ps1").read_bytes())
    contents = 'Attribute VB_Name = "modTestCoupledElasticState"\nOption Explicit\n\n'+(HERE/"TimingTest.txt").read_text(encoding="utf-8")
    identity[MODULE_FILE] = put(MODULE_FILE,contents.replace("\n","\r\n").encode())
    for name in ("Stage.py","TimingTest.txt","Run.ps1","Verify.py", "README.txt"):
        identity[name] = digest((HERE/name).read_bytes())
    payload = {"book_sha256":BOOK_SHA,"code_export_sha256":CODE_SHA,"frozen":identity,
               "macro":"RunTestCoupledDirectTorqueTiming","order":["Mixed","PureT"]}
    print(put("Preparation.json",(json.dumps(payload,indent=2)+"\n").encode()))


if __name__ == "__main__":
    main()
