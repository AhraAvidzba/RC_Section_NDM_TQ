Current workbook C603. One matched direct-only native pair using the existing HardShear section.

    python -B -X utf8 ReplayTorquePortable.py

The detached replay verifies the native source identity and all original data, owner closures,
saved/reopened results, six signed efforts and same production route. The workbook itself is
omitted. The compiled setup adds only a test entry point. Both torques are 1.5 kN m; the second
run changes other efforts to exactly zero. Whole-Excel and solver batch runtime are measured
separately. This is a single paired timing, with no capacity search.

The nested initial archive preserves the previous workbook observation. The first test helper
divided by zero in its relative comparison after the production solve. The corrected native
replay checks zero residuals absolutely, using the established stress tolerance and actual
section scales. Its nonzero-force comparator keeps the original relative tolerance.
