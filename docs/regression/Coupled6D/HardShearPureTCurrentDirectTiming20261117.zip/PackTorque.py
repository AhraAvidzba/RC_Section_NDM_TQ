"""Package exact corrected timing and independently replay after extraction."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

import ReplayTorquePortable as replay

HERE = Path(__file__).resolve().parent
RESULT = HERE/"HardShearPureTCurrentDirectTiming20261117.zip"


def main():
    prep = json.loads((HERE/"Preparation.json").read_bytes())
    assert prep["book_sha256"]==prep["frozen"][replay.BOOK]==replay.WORKBOOK
    supplement = ("Preparation.json","Verification.json","Compile.log","CompileClosure.json","Run.ndjson",
                  "docs/regression/CodeUpdate.json","ReplayTorquePortable.py","PackTorque.py","PortableREADME.txt")
    native = tuple(f"Native/{path.name}" for path in (HERE/"Native").iterdir() if path.is_file())
    files = {}
    for name in sorted(set(prep["frozen"])|set(supplement)|set(native)):
        if name != replay.BOOK:
            files[name] = (HERE/name).read_bytes()
            if name in prep["frozen"]:
                assert replay.digest(files[name]) == prep["frozen"][name]
    name = "HardShearPureTInitialObservation20261117.zip"
    previous = (HERE.parent/"ptabr"/name).read_bytes()
    assert replay.digest(previous)==replay.INITIAL
    files["Initial/"+name] = previous
    manifest = {"book":{"path":replay.BOOK,"sha256":replay.WORKBOOK},"files":{name:replay.digest(src) for name,src in sorted(files.items())}}
    files["PortableManifest.json"] = (json.dumps(manifest,indent=2)+"\n").encode()
    assert all(not name.casefold().endswith(".xlsm") for name in files)
    with ZipFile(RESULT,"w",compresslevel=9) as z:
        for member,raw in sorted(files.items()):
            entry = ZipInfo(member); entry.compress_type = ZIP_DEFLATED
            z.writestr(entry,raw)
    with TemporaryDirectory(dir=HERE) as temp, ZipFile(RESULT) as z:
        assert z.testzip() is None
        z.extractall(temp)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayTorquePortable.py"),cwd=temp,check=True)
    print(RESULT.name,RESULT.stat().st_size,replay.digest(RESULT.read_bytes()))


if __name__=="__main__":
    main()
