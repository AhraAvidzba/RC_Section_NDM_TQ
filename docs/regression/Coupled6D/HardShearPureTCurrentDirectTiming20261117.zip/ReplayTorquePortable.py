"""Replay the corrected C603 mixed and pure torsion confirmation offline."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "C603E41639484DB313C5390930BC52F1AC3CC42ED4CE01BC1946BC01ED84FA95"
REPORT = "DB92B4224EC6A5F192B3174DE5587FF5487D737B7CA4F6EEB7FD0C8D05AA2888"
INITIAL = "B329140C33FB2E34F1EE234FBB451DAF424FB0930431CC48ACA201F338B4B08F"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def replay():
    manifest = json.loads((HERE/"PortableManifest.json").read_bytes())
    assert manifest["book"] == {"path":BOOK,"sha256":WORKBOOK}
    for name,expected in manifest["files"].items():
        path = HERE/(HERE/name).resolve().relative_to(HERE)
        assert digest(path.read_bytes()) == expected, name
    assert not (HERE/BOOK).exists()
    module = HERE/"Verify.py"
    source = module.read_text(encoding="utf-8")
    old = '    assert all(digest(HERE/name)==sha for name,sha in prep["frozen"].items())'
    assert source.count(old)==1
    pin = (f'    assert prep["frozen"]["{BOOK}"] == prep["book_sha256"] == "{WORKBOOK}"\n'
           f'    assert all(digest(HERE/name)==sha for name,sha in prep["frozen"].items() if name != "{BOOK}")')
    verify = {"__file__":str(module),"__name__":"archived_verifier"}
    exec(compile(source.replace(old,pin),str(module),"exec"),verify)
    report = verify["verify"](verify["prepare"]())
    report_raw = (HERE/"Verification.json").read_bytes()
    assert digest(report_raw)==REPORT and (json.dumps(report,indent=2)+"\n").encode()==report_raw
    mixed,pure = report["runs"]
    assert (mixed["whole_excel_calculation_seconds"],pure["whole_excel_calculation_seconds"])==(6.35888671875,4.90966796875)
    prior = HERE/"Initial/HardShearPureTInitialObservation20261117.zip"
    assert digest(prior.read_bytes())==INITIAL
    with ZipFile(prior) as earlier:
        observation = json.loads(earlier.read("Observation.json"))
        assert observation["PureT"]["native_exit"]==1 and b"VBAProject Overflow" in earlier.read("Native/PureT.txt")
        assert observation["PureT"]["workbook_save_and_reopen_exact"] and observation["PureT"]["normal_macro_seconds"]==5.0029296875
    assert all(r["equilibrium_probes"]==4 and r["rejected_continuation_probes"]==0 for r in (mixed,pure))
    print("CORRECTED NATIVE PAIR",REPORT)
    print("MIXED",mixed["whole_excel_calculation_seconds"],"PURE T",pure["whole_excel_calculation_seconds"])


if __name__=="__main__":
    replay()
