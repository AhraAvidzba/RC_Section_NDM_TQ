One timed pair on the same HardShear section using the installed production calculation.

    python -B -X utf8 tmp/ptab2/Stage.py
    python -B -X utf8 tmp/ptab2/Verify.py --inputs-only

After allocating the exclusive Office slot:

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/ptab2/Run.ps1

The compiled private workbook imports one test entry point. It does not update calculation,
material, geometry or solver source. It uses the actual HardShear section/material fixture and
the ordinary direct-only Excel profile, with the current limit search and all other checks off.
The first arm uses the six original HardShear forces. The second arm retains only T=1.5 kN m.
The timer covers the normal workbook calculation from dispatch through complete Results and
schematic output. Exactly-zero requested efforts are checked by the absolute 5e-7 MPa part of
the production equilibrium tolerance, scaled by the actual prepared geometry. Nonzero
components retain the existing relative comparator. The verifier records continuation counts and batch elapsed time
from the real execution report, and verifies the six signed efforts and saved/reopened Results.
The pair characterizes these two runs. It neither establishes speed for other load levels, nor
asserts linear response or measures ultimate-capacity search.
