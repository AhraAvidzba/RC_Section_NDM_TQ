﻿# Сравнивает два штатных прямых расчёта, изолируя процессы и исходную книгу.
param([switch]$Preflight)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../..')).Path
$draft='docs/regression/Diagnostic.xlsm'
$book='workbook/output/RC_Section_NDM.xlsm'
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
Push-Location -LiteralPath $root
try {
    & python -B -X utf8 'Verify.py' --inputs-only
    if ($LASTEXITCODE -ne 0) {throw 'Входы замера не подтверждены.'}
    if ($Preflight) {return}
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw -Encoding UTF8 | ConvertFrom-Json
    if ((Get-FileHash -LiteralPath (Join-Path $repo $book)).Hash -cne $prep.book_sha256) {throw 'Изменилась установленная книга.'}
    if ((Get-FileHash -LiteralPath $draft).Hash -cne $prep.book_sha256 -or (Test-Path -LiteralPath 'Compile.log')) {
        throw 'Предыдущая компиляция требует отдельной сверки.'
    }
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Путь к временной книге превышает допустимый для Excel.'
    }
    Assert-IsolatedOfficeReady 'PreCompileDirectTorque'
    & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft -ModuleNames @('modTestCoupledElasticState') -EntryPointNames @($prep.macro) |
        Tee-Object -FilePath 'Compile.log'
    Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw -Encoding UTF8 | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $compiled.ProductionSHA256 -cne $prep.book_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or
        ($compiled.Modules -join ',') -cne 'modTestCoupledElasticState' -or ($compiled.EntryPointNames -join ',') -cne $prep.macro) {
        throw 'Импорт только тестового входа не подтверждён.'
    }
    foreach ($mode in $prep.order) {
        $report='Native/'+$mode+'.txt'
        if (Test-Path -LiteralPath $report) {throw 'Сохраняется предыдущий протокол.'}
        Assert-IsolatedOfficeReady ('BeforeDirectTorque'+$mode)
        $clock=[Diagnostics.Stopwatch]::StartNew()
        $macro='modTestCoupledElasticState.'+$prep.macro
        & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' -SourceWorkbook $draft `
            -ReportPath $report -Macro $macro -MacroArgument1 $mode -Mode No -TimeoutSeconds 85 -VerifyResultsReopen -FailFast
        $exit=$LASTEXITCODE
        $clock.Stop()
        [ordered]@{native_exit=$exit;wall_seconds=$clock.Elapsed.TotalSeconds} | ConvertTo-Json |
            Set-Content -LiteralPath ('Native/'+$mode+'.Receipt.json') -Encoding UTF8
        if ($exit -ne 0) {throw "Нативный замер $mode завершился ошибкой."}
        $where=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
        if ($where.Count -ne 1) {throw 'Приватная копия не подтверждена.'}
        $folder=Split-Path -Parent $where[0].Substring('FIXTURE: '.Length)
        if (!(Split-Path -Leaf $folder).StartsWith('RC_NDM_ModeSuite_',[StringComparison]::Ordinal) -or
            !$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Отчёт вне приватной копии.'}
        Copy-Item -LiteralPath (Join-Path $folder 'RC_Section_NDM_execution_report.txt') -Destination ('Native/'+$mode+'.Execution.txt')
    }
    if ((Get-FileHash -LiteralPath (Join-Path $repo $book)).Hash -cne $prep.book_sha256) {throw 'Изменилась исходная книга.'}
    & python -B -X utf8 'Verify.py'
    if ($LASTEXITCODE -ne 0) {throw 'Независимая проверка прямого расчёта завершилась ошибкой.'}
}
finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
