Attribute VB_Name = "modTestCoupledElasticState"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Измеряет штатный прямой расчёт одного сечения при двух заданных сочетаниях.
Public Function RunTestCoupledDirectTorqueTiming(ByVal loadCase As String) As String
    Dim passed As Long, failed As Long, report As String
    On Error GoTo FailedRun
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, "RunTestCoupledDirectTorqueTiming", "Нужна изолированная копия книги."
    Dim loads As Variant: loads = TestHardShearLoads()
    If CDbl(loads(3)) <> 1500000# Then Err.Raise 5, , "Исходное кручение должно равняться 1,5 кН·м."
    Select Case loadCase
        Case "Mixed"
        Case "PureT": loads = Array(0#, 0#, 0#, loads(3), 0#, 0#)
        Case Else: Err.Raise 5, , "Поддерживаются сочетания Mixed и PureT."
    End Select
    Dim book As Object: Set book = ThisWorkbook
    Dim units As CUnitSystem: Set units = TestPrepareCoupledTimingBook(book, "Direct", "Excel", loads)
    Dim started As Double, elapsed As Double, message As String
    started = Timer
    message = RunSectionCalculationForWorkbook(book)
    elapsed = Timer - started
    If elapsed < 0# Then elapsed = elapsed + 86400#
    report = "TIMING_SECONDS: " & Trim$(Str$(elapsed)) & " | Direct | Excel | " & loadCase & vbCrLf
    report = report & "TIMING_MESSAGE: " & Replace(message, vbCrLf, " | ") & vbCrLf
    Dim i As Long, requested As String
    For i = 0 To 5: requested = requested & ";" & Trim$(Str$(loads(i))): Next i
    report = report & "TIMING_INPUT_N_NMM: " & Mid$(requested, 2) & vbCrLf

    Const CASE_ID As String = "HardShear"
    Dim directStatus As String, capacityStatus As String
    directStatus = ReadLoadCasePropertyText(book, CASE_ID, "DirectStateStatus")
    capacityStatus = ReadLoadCasePropertyText(book, CASE_ID, "CapacityStatus")
    report = report & "TIMING_STATES: direct=" & directStatus & "; capacity=" & capacityStatus & vbCrLf
    TestRecord directStatus = "OK", "workbook balances the requested six-component case", passed, failed, report
    TestRecord capacityStatus = "N/A", "direct-only profile does not run the capacity search", passed, failed, report
    Dim components As Variant, values As Variant, actual As String
    components = Array("N", "Mx", "My", "T", "Qx", "Qy")
    values = Array(units.InternalForceToOutput(loads(0)), units.InternalMomentMxToOutput(loads(1)), _
        units.InternalMomentMyToOutput(loads(2)), units.InternalTorqueToOutput(loads(3)), _
        units.InternalShearToOutput(loads(4)), units.InternalShearToOutput(loads(5)))
    Const ZERO_STRESS_TOL As Double = 0.0000005 ' Абсолютная часть допуска штатного связанного равновесия, МПа.
    Dim section As CSectionModel, area As Double, radius As Double, centerX As Double, centerY As Double, zeroCap As Double
    If loadCase = "PureT" Then
        Set section = TestHardShearSection()
        section.ConcreteMeshCentroid centerX, centerY, area
        radius = section.MaximumElementRadiusFromConcreteCenter
        If area <= 0# Or radius <= 0# Then Err.Raise 5, , "Не определены масштабы невязки сечения."
        report = report & "TIMING_ZERO_SCALE: " & Trim$(Str$(area)) & ";" & Trim$(Str$(radius)) & _
            ";" & Trim$(Str$(ZERO_STRESS_TOL)) & vbCrLf
    End If
    For i = 0 To 5
        actual = ReadLoadCasePropertyText(book, CASE_ID, "Coupled.Internal." & components(i))
        If CDbl(values(i)) <> 0# Then
            TestCoupledTimingNumber actual, CDbl(values(i)), "direct " & components(i), passed, failed, report
        ElseIf IsNumeric(actual) Then
            If i >= 1 And i <= 3 Then
                zeroCap = units.InternalMomentMagnitudeToOutput(ZERO_STRESS_TOL * area * radius)
            Else
                zeroCap = units.InternalShearToOutput(ZERO_STRESS_TOL * area)
            End If
            TestRecord Abs(CDbl(actual)) <= zeroCap, "direct " & components(i) & " absolute zero remainder", passed, failed, report
        Else
            TestRecord False, "direct " & components(i) & " was not published", passed, failed, report
        End If
        If IsNumeric(actual) Then report = report & "TIMING_RESULT: " & components(i) & ";" & Trim$(Str$(CDbl(actual))) & _
            ";" & Trim$(Str$(CDbl(values(i)))) & vbCrLf
    Next i
    Dim chart As Object, shape As Object, hoopCount As Long
    Set chart = book.Worksheets("Расчет").ChartObjects("chtNDMSectionPlot").Chart
    For Each shape In chart.Shapes
        If Left$(shape.Name, Len("NDMPlot_TransversePath")) = "NDMPlot_TransversePath" Then hoopCount = hoopCount + 1
    Next shape
    TestRecord hoopCount = 1 And InStr(message, "Схема не обновлена") = 0, _
        "chart plots the same closed hoop", passed, failed, report
    TestLoadTraceChart book, CASE_ID, True, False, False, passed, failed, report, directStatus = "OK"
    RunTestCoupledDirectTorqueTiming = report & "TOTAL_COUPLED_TORQUE_TIMING: passed=" & CStr(passed) & "; failed=" & CStr(failed)
    Exit Function
FailedRun:
    RunTestCoupledDirectTorqueTiming = report & "RUNTIME ERROR: " & Err.Source & " " & Err.Description
End Function
