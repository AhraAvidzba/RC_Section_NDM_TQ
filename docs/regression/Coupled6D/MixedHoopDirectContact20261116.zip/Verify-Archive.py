"""Reproduce the measured mixed hoop decision without Excel."""

from decimal import Decimal as D
from hashlib import sha256
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory


HERE=Path(__file__).resolve().parent
NATIVE='50D5A9437E7AB5086AC441AA16E15138D7DADE315EB335D49DAAA5B5F0864A3C'
FIXTURE='6722CAFE99FB804078A94E0849E136CCAB05A645C5ED467682680218749831F2'
BASE='511490464CBC79EBD0BB9F1D0382982E0F362650E2A6D610DBE2ED9D7A468376'
APPENDED={'src/Solver/CCoupledSectionAnalysis.cls':'Reference.txt','tests/modTestCoupledElasticState.bas':'MixedTest.txt'}


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read_json(name):
    return json.loads((HERE/name).read_text(encoding='utf-8-sig'))


def verify_imports(fixture,base):
    assert fixture['base_fixture_sha256']==BASE
    assert fixture['workbook_sha256']==base['workbook_sha256']
    assert fixture['modules']==base['modules']
    for name, expected in fixture['base_module_sha256'].items():
        assert base['frozen'][name]==expected
        if name not in APPENDED:
            assert fixture['frozen'][name]==expected
            continue
        imported=HERE/'Imported'/name
        assert fixture['frozen'][name]==digest(imported)
        updated=imported.read_text(encoding='utf-8')
        appended=(HERE/APPENDED[name]).read_text(encoding='utf-8')
        suffix='\n\n'+appended
        assert updated.endswith(suffix)
        original=updated.removesuffix(suffix).replace('\n','\r\n').encode('utf-8')
        assert any(sha256(original+b'\r\n'*end).hexdigest().upper()==expected for end in range(4))


def verify_receipts(fixture,report):
    compiled=read_json('docs/regression/CodeUpdate.json')
    assert compiled['Compiled'] and not compiled['ProductionChanged']
    assert compiled['ProductionSHA256']==fixture['workbook_sha256']
    assert sorted(compiled['Modules'])==fixture['modules']
    closure=read_json('CompileClosure.json')
    compile_log=(HERE/'Compile.log').read_text(encoding='utf-8-sig')
    candidate=re.search(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',compile_log,re.M)
    assert closure['State']=='Absent' and candidate
    assert (closure['PID'],closure['StartTicksUTC'])==(int(candidate[1]),candidate[2])
    owner=read_json('Native/Direct.txt.Ownership.json')
    native_end=read_json('Native/Direct.txt.ProcessClosure.json')
    state=native_end['Closure']['FinalState']
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256']==compiled['WorkbookSHA256']
    assert f"SOURCE_SHA256: {compiled['WorkbookSHA256']}" in report.read_text(encoding='utf-8-sig')
    assert native_end['Passed'] and native_end['ChildExitCode']==0 and native_end['RunnerCleanupValid']
    assert state['State']=='Absent' and not native_end['OrdinaryPathKilledAnything']
    assert (state['PID'],state['StartTicksUTC'])==(owner['PID'],owner['StartTicksUTC'])
    assert closure['PID']!=owner['PID']


def main():
    checksums=read_json('SHA256SUMS.json')
    assert all(digest(HERE/name)==expected for name,expected in checksums.items())
    assert digest(HERE/'Fixture.json')==FIXTURE
    assert digest(HERE/'Base/Fixture.json')==BASE
    report=HERE/'Native/Direct.txt'
    assert digest(report)==NATIVE
    fixture=read_json('Fixture.json'); base=read_json('Base/Fixture.json')
    verify_imports(fixture,base)
    verify_receipts(fixture,report)
    with TemporaryDirectory() as folder:
        sample=Path(folder)/report.name
        copyfile(report,sample)
        check_output([sys.executable,'-B','-X','utf8',str(HERE/'Verify.py'),str(sample)])
        assert sample.with_suffix('.Verification.json').read_bytes()==report.with_suffix('.Verification.json').read_bytes()
    saved=read_json('Native/Direct.Verification.json')
    assert [tuple(row['case'][1:3]) for row in saved['cases']]==[('FAIL','FAIL'),('NumFail','NumFail'),('OK','OK')]
    largest=max(D(case['normalized_equilibrium_error_MPa']) for case in saved['cases'])
    print(f'MIXED HOOP EVIDENCE PASS {NATIVE}; maximum signed norm={largest:.3E} MPa')


if __name__=='__main__':
    main()
