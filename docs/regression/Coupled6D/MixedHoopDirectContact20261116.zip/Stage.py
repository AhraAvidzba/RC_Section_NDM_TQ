"""Stage the real weak-hoop directed regression against the retained-field build."""

from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile


HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
BASE=HERE.parent/'dsr/Snapshot'
BOOK='workbook/output/RC_Section_NDM.xlsm'
REF='src/Solver/CCoupledSectionAnalysis.cls'
TEST='tests/modTestCoupledElasticState.bas'


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


assert not (HERE/'Fixture.json').exists()
source=json.loads((BASE/'Fixture.json').read_text(encoding='utf-8'))
assert digest(REPO/BOOK)==source['workbook_sha256']==digest(BASE/BOOK)
names=[name for name in source['frozen'] if name.startswith(('src/','tests/','tools/')) or name in (BOOK,'Guard-IsolatedOffice.ps1')]
for name in names:
    original=BASE/name
    assert digest(original)==source['frozen'][name]
    (HERE/name).parent.mkdir(exist_ok=True,parents=True)
    copyfile(original,HERE/name)
for name,extra in ((REF,'Reference.txt'),(TEST,'MixedTest.txt')):
    original=(HERE/name).read_text(encoding='utf-8-sig').rstrip()
    body=(HERE/extra).read_text(encoding='utf-8')
    (HERE/name).write_text(original+'\n\n'+body,encoding='utf-8',newline='\r\n')
for name in ('docs/regression','Temp','Native'):
    (HERE/name).mkdir(exist_ok=True,parents=True)
copyfile(HERE/BOOK,HERE/'docs/regression/Diagnostic.xlsm')
script=(HERE.parent/'dsc2/Run-Candidate.ps1').read_text(encoding='utf-8-sig')
start=script.index("-ModuleNames @(")
end=script.index(') |',start)
modules=source['modules']
script=script[:start]+"-ModuleNames @("+','.join(repr(name) for name in modules)+script[end:]
start=script.index("($compiled.Modules | Sort-Object) -join ',') -cne '")+len("($compiled.Modules | Sort-Object) -join ',') -cne '")
end=script.index("'",start)
script=script[:start]+','.join(modules)+script[end:]
script=script.replace('RunTestCoupledDirectSteelVerification','RunTestCoupledDirectHoopContact')
script=script.replace("'Verify-Candidate.py'", "'Verify.py'")
script=script.replace('-TimeoutSeconds 110','-TimeoutSeconds 140')
(HERE/'Run.ps1').write_text(script,encoding='utf-8-sig',newline='\r\n')
names+=['Reference.txt','MixedTest.txt','Stage.py','Verify.py','Run.ps1']
manifest={'workbook_sha256':source['workbook_sha256'],'base_fixture_sha256':digest(BASE/'Fixture.json'),
          'base_module_sha256':{name:source['frozen'][name] for name in names if name.startswith(('src/','tests/'))},
          'frozen':{name:digest(HERE/name) for name in names},'modules':modules}
(HERE/'Fixture.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(digest(HERE/'Fixture.json'))
