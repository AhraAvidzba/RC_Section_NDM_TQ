from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import json,os,runpy

H=Path(__file__).resolve().parent
p=ArgumentParser(); p.add_argument('--repo-root',type=Path,required=True); a=p.parse_args()
os.environ['OPENBLAS_NUM_THREADS']='1'; repo=a.repo_root.resolve()
read=lambda name:json.loads((H/name).read_text(encoding='utf8'))
receipt=read('Manifest.json')
assert all(sha256((H/k).read_bytes()).hexdigest().upper()==v for k,v in receipt['files'].items())
calc=runpy.run_path(H/'Decompose-Stations.py'); first,_=calc['decompose'](repo)
main=runpy.run_path(H/'Check-Combination.py'); second=main['main'](repo)
assert first==read('AxialGradientDecomposition.json')
assert second==read('MeasuredSubspaceCombination.json')
print('Station attribution and measured span: native records, controls and model bounds replayed.')
print(json.dumps({'weak80Change':first['decomposition']['pair2']['Plus18TargetPlus']['change80_MPa'],
    'maximumN_N':second['quadraticMaximumN_N'],'full89QuadraticFloorMPa':second['conditionalCombiningBothMeasuredStencils']['full89']['separableQuadratic']['rigorousBoxLowerForModelMPa']},indent=2))
