"""Test only combinations of the two measured directions, with explicit model limits."""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
import itertools,json,heapq,runpy
import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent; d=runpy.run_path(HERE/'Decompose-Stations.py')


def quadratic_range(a,b,l,h):
    z0=a*l+b*l*l; z1=a*h+b*h*h; left=np.minimum(z0,z1); right=np.maximum(z0,z1)
    v=np.divide(-a,2*b,out=np.zeros_like(a),where=b!=0)
    ok=(b!=0)&(v>l)&(v<h); z=a*v+b*v*v
    left[ok]=np.minimum(left[ok],z[ok]); right[ok]=np.maximum(right[ok],z[ok]);
    return left,right


def normal(v): return float(np.max(abs(v)))

def main(root):
    decomposition,st=d['decompose'](root); first,second=(st[k] for k in ('pair1','pair2')); A,AA,branchA,_,_,qA=first; B,BB,branchB,_,_,qB=second
    c,n,p='Plus18Center','Plus18TargetMinus','Plus18TargetPlus'
    rr=lambda payload,tag:np.array(payload['statuses'][tag]['all89Rows_MPa'])
    zero=rr(A,c); v={-1:rr(A,n)-zero,1:rr(A,p)-zero}; second0=rr(B,c)
    w={-1:rr(B,n)-second0,1:rr(B,p)-second0}; assert np.array_equal(second0,rr(A,p))
    C=.5*(v[1]-v[-1]); D=.5*(v[1]+v[-1]); E=.5*(w[1]-w[-1]); F=.5*(w[1]+w[-1]); tau=float(A['statuses'][c]['tau_MPa'])
    load_scale=np.r_[305.*610.,np.full(3,305.*610.*335.410196624968),np.full(2,305.*610.)]
    alpha=AA[p][:,:,:6]-AA[n][:,:,:6]; beta=BB[p][:,:,:6]-BB[n][:,:,:6]
    cos=float((alpha.ravel()@beta.ravel())/np.linalg.norm(alpha)/np.linalg.norm(beta)); assert abs(cos)<1e-9
    linearChecks={}
    # All saved input coordinates start at the same six prescribed loads and have the same
    # gauge/mid-shear readings. This affine identity is separate from nonlinear force balance.
    for key,Q,archive in [('v',qA,A),('w',qB,B)]:
        qa=Q[p]-Q[n]
        assert normal(qa[:2])==0 and normal(qa[-4:])==0
        full=np.r_[qa[2:],qa[0]]
        projector=first[4]['CenterStock'][83:]; g=projector@full
        assert normal(g)<1e-10
        linearChecks[key]={'targetLambdaAndGammaExactZero':True,'gaugeMultipliersExactZero':True,
                           'fourGaugeAndGammaCheckMPa':g.tolist()}
    scope={'full89':np.arange(89),'sixResultants':np.arange(83,89),'axialAndBendingGradients':np.array([79,80]),
           'gradients_N_T_Qy':np.array([79,80,83,86,88])}

    def piecewise(idx):
        data=[]
        for i,j in itertools.product((-1,1),repeat=2):
            # s,t in [0,1] along their respective signed normalization. Last variable is max norm in τ.
            X=np.c_[v[i][idx],w[j][idx]]/tau; r=zero[idx]/tau
            mat=np.r_[np.c_[X,-np.ones(len(X))],np.c_[-X,-np.ones(len(X))]]; b=np.r_[-r,r]
            sol=linprog([0,0,1],mat,b,bounds=[(0,1),(0,1),(0,None)],method='highs'); assert sol.success
            dual=sol.ineqlin.marginals@b+sol.upper.marginals[:2].sum(); assert abs(dual-sol.fun)<1e-6
            x,y=sol.x[:2]; res=zero+x*v[i]+y*w[j]; assert abs(normal(res[idx])-sol.fun*tau)<5e-12
            data.append({'directionSigns':[i,j],'parameters':[float(i*x),float(j*y)],'normMPa':float(sol.fun*tau),
                         'dualLowerMPa':float(dual*tau),'sixPhysicalResiduals_N_Nmm':(res[83:]*load_scale).tolist(),
                         'row80_81_MPa':res[[79,80]].tolist()})
        return {'best':min(data,key=lambda x:x['normMPa']),'sectors':data}

    def quadratic(idx):
        # Each row's range on the rectangle is computed exactly because this surrogate is separable.
        # Independent ranges provide a conservative lower bound on any point's maximum absolute row.
        c,d,e,f,r0=[x[idx] for x in (C,D,E,F,zero)]
        def lower(box):
            lo,hi,bot,top=box
            a,b=quadratic_range(c,d,lo,hi); u,v=quadratic_range(e,f,bot,top)
            return float(np.max(np.maximum(np.maximum(r0+a+u,-(r0+b+v)),0.)))
        def calc(s,t): return zero+s*C+s*s*D+t*E+t*t*F
        def eval_point(s,t): return normal(calc(s,t)[idx])
        upper,point=min((eval_point(s,t),(s,t)) for s,t in itertools.product((-1.,0.,1.),repeat=2));
        box=(-1.,1.,-1.,1.); heap=[(lower(box),box)]; count=0; objective_gap=2e-10
        while heap and upper-heap[0][0]>objective_gap and count<70000:
            val,x=heapq.heappop(heap); a,b,c0,d0=x
            if val>upper: continue
            if b-a>=d0-c0:
                mid=.5*(a+b); split=[(a,mid,c0,d0),(mid,b,c0,d0)]
            else:
                mid=.5*(c0+d0); split=[(a,b,c0,mid),(a,b,mid,d0)]
            for box in split:
                lo=lower(box)
                if lo>upper: continue
                key=(.5*(box[0]+box[1]),.5*(box[2]+box[3])); candidate=eval_point(*key)
                if candidate<upper: upper,point=candidate,key
                heapq.heappush(heap,(lo,box))
            count+=1
        bound=float(min(heap[0][0],upper) if heap else upper)
        assert 0<=bound<=upper and upper-bound<1e-8
        win=calc(*point)
        return {'bestSampleUpperMPa':upper,'rigorousBoxLowerForModelMPa':bound,'s,t':list(point),'rectanglesSplit':count,
                'sixPhysicalResidualsAtBestSample_N_Nmm':(win[83:]*load_scale).tolist(),'row80_81_MPa':win[[79,80]].tolist()}

    results={lab:{'linearChord':piecewise(idx),'separableQuadratic':quadratic(idx)} for lab,idx in scope.items()}
    N=83; vl,vr=quadratic_range(C,D,-1,1); wl,wr=quadratic_range(E,F,-1,1)
    boundN=float((zero[N]+vr[N]+wr[N])*load_scale[0]); boundNChord=float((zero[N]+max(v[-1][N],0,v[1][N])+max(w[-1][N],0,w[1][N]))*load_scale[0]); assert boundN<-.1 and boundNChord<-.1
    Q=88; z0=zero+v[-1]; tq=float(-z0[Q]/w[1][Q]); assert 0<tq<1
    r_q=z0+tq*w[1]
    switch_first=(branchA[c][:,:,0]!=branchA[p][:,:,0]); switch_second=(branchB[c][:,:,0]!=branchB[p][:,:,0]); crossOverlap=int((switch_first&switch_second).sum())
    answer={'conditionalCombiningBothMeasuredStencils':results,'sixPrescribedTargetsCanBeHeldTogether':linearChecks,
            'basisCosineFromNativeStrains':cos,'quadraticMaximumN_N':boundN,'chordMaximumN_N':boundNChord,
            'requiredPositiveNCrossEffectToReachOriginalTolerance_N':min(abs(boundN),abs(boundNChord))-tau*load_scale[0],
            'oneInterpolatedQyOnlyTargetExample':{'parameters':[-1,tq],'sixResiduals_N_Nmm':(r_q[83:]*load_scale).tolist(),'weak80_81_MPa':r_q[[79,80]].tolist()},
            'amplitudeOneNativePlasticSwitchesInEachDirection':[int(switch_first.sum()),int(switch_second.sum())],
            'amplitudeOneNativePlasticSwitchesCommon':crossOverlap,
            'rack':'Native anchors enter exactly; interpolants combine separate increments and cannot verify cross response or equilibrium of unmeasured fields.'}
    return answer

if __name__=='__main__':
    p=ArgumentParser(); p.add_argument('--repo-root',type=Path,required=True); a=p.parse_args(); result=main(a.repo_root.resolve())
    out=HERE/'MeasuredSubspaceCombination.json'; out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8'); print(out,sha256(out.read_bytes()).hexdigest().upper())
    for k,v in result['conditionalCombiningBothMeasuredStencils'].items(): print(k,v['linearChord']['best'],v['separableQuadratic'])
    print('maximum N',result['chordMaximumN_N'],result['quadraticMaximumN_N'],result['oneInterpolatedQyOnlyTargetExample'])
