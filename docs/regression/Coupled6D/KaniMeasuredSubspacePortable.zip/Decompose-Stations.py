"""Replay the two native H45 pairs; attribute axial-gradient residual row 80 by station."""
from pathlib import Path
from argparse import ArgumentParser
from hashlib import sha256
from zipfile import ZipFile
from io import BytesIO
from collections import Counter
import csv,json
import numpy as np

HERE=Path(__file__).resolve().parent
PARAMS={'pair1':('KaniH45Plus18NativePortable.zip','10FFDC956D9F6D74F6A50A79DF2E50B3C5F7EFE810AEB18A4415D8584E1C5F48'),
        'pair2':('KaniSecondDirectionNativePortable.zip','66068CCC3E3744B75D8877F635B0FFC1C2D0B6AB65CC1B5819731D8326758DC4'),
        'geometry':('KaniHydrostaticApex46Portable.zip','B920F591EA6436DB65914CEF8582EA8EB42301679A15311A924253942FEAAEA5'),
        'anchor':('KaniCommitNear48Portable.zip','EA0A80006AF81D99799B53FDCB75B18CDDE7B7DF730AB16039902F12C6431488'),
        'projection':('KaniPracticalProbe45Portable.zip','4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113')}
names=('Base45','Plus18Center','Plus18TargetMinus','Plus18TargetPlus','Plus18Repeat','End45','Restore45')
pk=lambda x:float(np.max(abs(x))); sha=lambda data:sha256(data).hexdigest().upper()

def unpack(root,key):
    filename,expected=PARAMS[key]; path=root/'docs/regression/Coupled6D'/filename; assert sha(path.read_bytes())==expected,filename
    return ZipFile(path)


def parse(z,reportname):
    result=json.loads(z.read(reportname)); native={k:z.read('Native/'+k) for k in ('KaniV4Stations.csv','KaniV4Tangents.csv','KaniV4Trace.csv')}
    assert result['nativeSHA256']=={k:sha(v) for k,v in native.items()}
    rows=lambda key:csv.reader(native[key].decode('cp1251').splitlines(),delimiter=';')
    t={key:np.full((3,184,12),np.nan) for key in names}
    X={key:np.full((3,184,3),-99) for key in names}; F={key:np.full((3,184),np.nan) for key in names}; A={}; V={}
    for k,n,p,side,*v in rows('KaniV4Stations.csv'):
        assert k=='K59C_STATION'; t[n][int(side)+1,int(p)-1]=list(map(float,v))
    for k,n,p,*v in rows('KaniV4Tangents.csv'):
        if k=='MATRIX': A.setdefault(n,np.full((88,88),np.nan))[int(p)-1]=list(map(float,v)); continue
        i,j=int(v[0])+1,int(p)-1
        if k=='BRANCH': X[n][i,j]=list(map(int,v[1:]))
        elif k=='YIELD': F[n][i,j]=float(v[1])
    for tag,name,*v in rows('KaniV4Trace.csv'):
        if tag=='K59C_VECTOR': V[name]=np.array(v,float)
    assert set(V)==set(t) and all(np.isfinite(a).all() for a in [*t.values(),*F.values(),*A.values()])
    assert all((a!=-99).all() for a in X.values())
    return result,t,X,F,A,V


def decompose(root):
    with unpack(root,'pair1') as z: first=parse(z,'Plus18Verification.json')
    with unpack(root,'pair2') as z: second=parse(z,'SecondNativeVerification.json')
    with unpack(root,'geometry') as z:
        geom=np.loadtxt(BytesIO(z.read('GeometryAndDirections.csv')),delimiter=';'); previous=json.loads(z.read('HydrostaticApexDecomposition.json'))
    with unpack(root,'anchor') as z:
        arc=dict(np.load(BytesIO(z.read('MeasuredSamples.npz')),allow_pickle=False)); assert sha(z.read('History45Verified.csv'))=='97FF3089BA40A3B7349B1A0588B21FAFB3689E33DB7BA95892163C80B83CA9EE'
        assert tuple(arc['geometry'].shape)==(184,3) and np.array_equal(geom[:,:3],arc['geometry'])
    with unpack(root,'projection') as z:
        proj0=dict(np.load(BytesIO(z.read('MeasuredSamples.npz')),allow_pickle=False))
        assert np.array_equal(proj0['geometry'],arc['geometry'])
    projection=proj0['resultant_projection']
    a,A,ba,Fa,Ma,qa=first; b,B,bb,Fb,Mb,qb=second
    keys=('Plus18Center','Plus18TargetMinus','Plus18TargetPlus'); center,minus,plus=keys
    assert np.array_equal(A[plus],B[center]) and np.array_equal(ba[plus],bb[center]) and np.array_equal(Fa[plus],Fb[center])
    assert np.array_equal(A['Base45'],B['Base45']) and a['commonQy_N']==b['commonQy_N'] and a['commonGamma']==b['commonGamma']
    for q in (qa,qb):
        assert all(np.array_equal(q[key][:2],q[center][:2]) and np.array_equal(q[key][-4:],q[center][-4:]) for key in keys)
        for key in (minus,plus):
            d=np.r_[q[key][2:]-q[center][2:],q[key][0]-q[center][0]]
            assert pk(Ma['CenterStock'][83:]@d)<5e-12
    physical_area=305.*610.; strain_h=.002; distance=float(arc['length']); dx=geom[:,2]
    weights=np.array([-1,0,1])[:,None]*dx[None,:]/(strain_h*physical_area)
    weights81=weights*(geom[:,1]/distance)[None,:]
    dirs=np.zeros((40,6)); dirs[:,:4]=geom[144:,3:]; assert np.allclose(dirs[:,0]+dirs[:,1]+dirs[:,2],1.)
    assert previous['maximumReplayedSteelStress_MPa']<181.
    def split(t):
        sig=t[:,:,8].copy(); steel=np.zeros_like(sig)
        steel_axial=2e5*np.einsum('sij,ij->si',t[:,144:,:6],dirs)
        assert pk(steel_axial)<200.
        steel[:,144:]=steel_axial*dirs[None,:,2]
        return {'directConcrete':np.c_[sig[:,:144],np.zeros((3,40))],
                'displacedConcreteSigned':np.c_[np.zeros((3,144)),sig[:,144:]-steel[:,144:]],'steel':steel}
    out={}; normErr=0.; projectionError=0.; rtol=float(a['statuses'][center]['tau_MPa']); loaded=float(a['commonQy_N'])
    stage={'pair1':first,'pair2':second}
    for role,(native,t,branch,F,M,q) in stage.items():
        layer={}
        for label in keys:
            members=split(t[label]); axial=t[label][:,:,8]@dx; after=native['statuses'][label]; rr=np.array(after['all89Rows_MPa'])
            projectionError=max(projectionError,pk(projection@rr[:83]-rr[83:]))
            row80=float(weights.ravel()@t[label][:,:,8].ravel()); row81=float(weights81.ravel()@t[label][:,:,8].ravel()-loaded/physical_area)
            normErr=max(normErr,abs(row80-rr[79]),abs(row81-rr[80]),abs(axial[1]-after['sixWrenches_N_Nmm'][0])/physical_area)
            e={'weak80MPa':row80,'weak81MPa':row81,'axialAtSides_N':axial.tolist(),'axialSideJump_N':float(axial[2]-axial[0]),
                'partsAbsolute80_MPa':{k:float(np.sum(weights*v)) for k,v in members.items()}}
            if label!=center:
                b0=branch[center]; b1=branch[label]; dq=np.r_[q[label][2:]-q[center][2:],0.]; fd=t[label][:,:,8]-t[center][:,:,8]
                wing=weights*fd; wing81=weights81*fd; active=(b0[:,:,0]!=b1[:,:,0]); principal=(b0[:,:,1]!=b1[:,:,1]); sub=(b0[:,:,2]!=b1[:,:,2]);
                term={key:float(wing[mask].sum()) for key,mask in {
                        'plasticChanged':active,'plasticSameActive':~active&(b1[:,:,0]==1),
                        'plasticSameInactive':~active&(b1[:,:,0]==0),'principalSignChanged':principal,'substepsChanged':sub}.items()}
                stable=~(active|principal|sub); assert int(stable.sum())+int((~stable).sum())==552
                old_parts=split(t[center]); by_source={k:float((weights*(v-old_parts[k])).sum()) for k,v in members.items()}
                assert abs(sum(by_source.values())-float(wing.sum()))<5e-12 and abs(sum(list(term.values())[:3])-float(wing.sum()))<5e-12
                part_note={k:v-old_parts[k] for k,v in members.items()}
                residual81=float(wing81.sum()); expected=after['weak81Change_MPa']; assert abs(residual81-expected)<2e-12
                ix=np.argsort(abs(wing).ravel())[-10:][::-1]; hot=[]
                for i0 in ix:
                    i,j=np.unravel_index(int(i0),wing.shape); hot.append({'sidePoint':[int(i)-1,int(j)+1],
                        'r80_MPa':float(wing[i,j]),'r81_MPa':float(wing81[i,j]),'netStressChange_MPa':float(fd[i,j]),
                        'steelAndConcreteStressChanges_MPa':{k:float(v[i,j]) for k,v in part_note.items()},
                        'beforeBranch':[int(v) for v in b0[i,j]],'afterBranch':[int(v) for v in b1[i,j]],
                        'yieldBeforeAfterMPa':[float(F[center][i,j]),float(F[label][i,j])],
                        'stationAsDisturbanceOfNetAxial_N':float(fd[i,j]*dx[j])})
                e.update(change80_MPa=float(wing.sum()),change81_MPa=residual81,changeN_Sides_N=(axial-t[center][:,:,8]@dx).tolist(),
                   row80ChangeByMaterial_MPa=by_source,row80ChangeByBranch_MPa=term,
                   changedBranchCounts={'all':int((~stable).sum()),'plastic':int(active.sum()),'principal':int(principal.sum()),'substeps':int(sub.sum())},
                   tangent80_MPa={key:float((matrix@dq)[79]) for key,matrix in M.items()}, hotspots=hot)
            layer[label]=e
        out[role]=layer
    assert normErr<2e-10 and projectionError<2e-10
    out={'decomposition':out,'comparisonWithRecordedMaxMPa':normErr,'independentSixForceProjectionErrorMPa':projectionError,'originalToleranceMPa':rtol,
         'notes':['The axial gradient residual is (N⁺−N⁻)/(0.002·A_c). Centre axial force is a separate equation.',
                 'Stress on the reinforcement points is net steel minus displaced concrete. Subtraction assumes elastic steel on the validated history.',
                 'Finite differences are across independently stored axial stations. If no row or force discrepancy appears, this checks assembly and indexing only.']}
    return out,stage

if __name__=='__main__':
    ap=ArgumentParser(); ap.add_argument('--repo-root',type=Path,required=True); p=ap.parse_args(); out,stage=decompose(p.repo_root.resolve())
    o=HERE/'AxialGradientDecomposition.json'; o.write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
    print(o,sha(o.read_bytes()),out['comparisonWithRecordedMaxMPa'])
    for name in ('pair1','pair2'):
        x=out['decomposition'][name]['Plus18TargetPlus']; print(name,x['axialAtSides_N'],x['changeN_Sides_N'],x['change80_MPa'],x['row80ChangeByMaterial_MPa'],x['row80ChangeByBranch_MPa'],x['tangent80_MPa']); print(x['hotspots'][:2])
