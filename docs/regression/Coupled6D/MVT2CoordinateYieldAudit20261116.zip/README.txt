MVT2 H24 coordinate-wise Barcelona yield audit

From the extracted directory run
    python -B -X utf8 AuditCoordinateYield.py PATH/MVT2SafeguardedTangentShift20261116.zip Replay.json

The only dependency is the tracked shift archive in docs/regression/Coupled6D.
Workbook bytes, Excel and external Python packages are unnecessary. Input
archive, raw record and native verification hashes are pinned. This audit
reconstructs the original static material criterion. It does not replay the
entire plastic return, calculate a replacement tangent or prove equilibrium.

The procedure inverts the archived H24 tension and compression energy ratios
through the original one-dimensional envelopes. It divides each accepted
nominal tensor by its scalar retained stiffness, then transports the effective
elastic predictor to each measured strain. The computed yield values at the
two exact native fields match all 150 recorded direct-concrete values within
1.12e-12 MPa. The geometry, retained-history snapshots and native status also
match the frozen source. The reference VBA source hashes are in the JSON.

With stock coordinate steps 2e-9*(1+abs(strain_component)), five stations
have at least one positive/negative pair straddling the material yield band.
Three are side stations contributing to weak axial-force gradient row 53.

                       F at minus h        F at plus h  [MPa]
    p2, z/L=-.001 exx  -1.50359577e-5      +8.26250584e-4
    p2, z/L=+.001 exx  -2.33656607e-4      +6.07686145e-4
    p2, z/L=+.001 eyy  -1.30220284e-4      +5.04250932e-4
    p2, z/L=+.001 ezz  -3.04181729e-5      +4.04445583e-4
    p22,z/L=+.001 ezz  -9.32021029e-4      +7.04319163e-5

All ten coordinate crossings, including the central stations, stop crossing
at h/4 in this reconstruction. By contrast, the two actual ray endpoints
have the same yield side and the direct native flags match at those fields.
Seventeen reconstructed points along that ray also retain that sign. This is
a sampled check of the elastic predictor, not a material substep trace.

On the 16 included smooth damaged-elastic side stations, the reconstructed
coordinate derivative minus the actual finite-ray change contributes only
3.00e-11 MPa signed to row 53 (5.24e-9 MPa absolute sum). At p23 the signed
error is -1.03e-11 MPa, although p23 gives the largest observed physical row
change. The package identifies where columns can mix regimes. It does not
measure how much of the full row-53 tangent mismatch the crossings explain.
