"""Reconstruct MVT2 H24 concrete yield probes from the sealed native trace."""
import csv
from collections import defaultdict
from hashlib import sha256
import json
from math import acos, cos, exp, fsum, log, pi, sqrt
from pathlib import Path
import sys
from zipfile import ZipFile


SOURCE_ARCHIVE = "688E1CB09A1FC7E4A4976FEA214BB4E0A9DADA0FE042BBBB6AFA55D1EA9B0979"
SOURCE_NATIVE = "7F36511004C965E75D2076076ADE36DC4F9E3079671AE226423B23F12810794D"
SOURCE_RESULT = "A6BE7C71F36D66C21E12BACB3F66D041B86C4DE2AE16DFED109642A7BFBEB47E"
SOURCE_CODE = {"CCoupledConcreteResponse.cls": "92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C",
               "CCoupledConcreteEnvelope.cls": "C82EE69DF1582CA307FCBD30A42335FF6CFA3250B09481833B9033CFC3FEE8E8",
               "modCoupledConcreteTensor.bas": "E7739A8C9200C6F5F56AF5AEA5E226101AF48DE6FDA00ADD29AFB7799F29C30B"}
MATERIAL_TAGS = ("exx", "eyy", "ezz", "gxy", "gxz", "gyz")
H = 2e-9
YIELD_TOLERANCE = 1e-8
E = 30000.
G = E / 2.4
LAME = 2 * G * .2 / .6
AREA = 57600.
SPATIAL_HALF_STEP = .001


def digest(raw):
    return sha256(raw).hexdigest().upper()


def diff(a, b):
    return tuple(x - y for x, y in zip(a, b, strict=True))


def plus(a, b):
    return tuple(x + y for x, y in zip(a, b, strict=True))


def read_trace(archive):
    assert digest(archive.read_bytes()) == SOURCE_ARCHIVE
    with ZipFile(archive) as source:
        raw = source.read("NativeCompare/MVT2.csv")
        verified = source.read("VerificationShift.json")
    assert digest(raw) == SOURCE_NATIVE and digest(verified) == SOURCE_RESULT
    tags = defaultdict(list)
    for marker, *row in csv.reader(raw.decode("cp1251").splitlines(), delimiter=";"):
        tags[marker].append(row)
    states = defaultdict(dict)
    for label, point, side, *row in tags["B_TANGENT_STATION"]:
        assert len(row) == 19 and (int(point), int(side)) not in states[label]
        states[label][int(point), int(side)] = tuple(map(float, row))
    expected_points = {(point, side) for point in range(1, 46) for side in (-1, 0, 1)}
    for label in ("Base24", "ShiftStop", "ShiftTrial"):
        assert states[label].keys() == expected_points
    snapshots = {label: tuple(map(float, row)) for label, *row in tags["B_ARC_HISTORY"]}
    assert len(snapshots) == 9 and len(snapshots["Before"]) == 3 * 45 * 8
    assert all(row == snapshots["Before"] for row in snapshots.values())
    assert states["Base24"] == states["Restored24"]
    return tags, states, snapshots["Before"], json.loads(verified)


def inverse_envelope(ratio, initial, peak, plastic_peak, fracture, damage, damage_at, length=125.):
    energy = ratio * fracture / length
    ascending = (initial + peak) * plastic_peak / 2
    softening = peak / (fracture / length - ascending)
    degradation = -log(1. - damage) / damage_at
    if energy < ascending:
        hardening = (peak - initial) / plastic_peak
        plastic = 2 * energy / (initial + sqrt(initial * initial + 2 * hardening * energy))
        nominal = initial + hardening * plastic
    else:
        ratio_at_plastic = 1. - (energy - ascending) * softening / peak
        assert ratio_at_plastic > 0.
        plastic = plastic_peak - log(ratio_at_plastic) / softening
        nominal = peak * ratio_at_plastic
    retain = exp(-degradation * plastic)
    return nominal / retain, 1. - retain


def materials(kt, kc):
    fc = 588000. / (.3 * 240. ** 2)
    ft = 2.10667357864589
    nominal_ft = .302 * fc ** (2 / 3)
    gt = .073 * fc ** .18
    gc = (fc / nominal_ft) ** 2 * gt
    half_tension = log(2.) * gt / (ft * 125.)
    compression_damage = .423 * (1. - fc / (.0022 * E))
    plastic_peak = .0022 - fc / ((1. - compression_damage) * E)
    ct, dt = inverse_envelope(kt, ft, ft, 0., gt, .5, half_tension)
    cc, dc = inverse_envelope(kc, .6 * fc, fc, plastic_peak, gc, compression_damage, plastic_peak)
    return cc, ct, dt, dc


def invariants(stress):
    trace = sum(stress[:3])
    mean = trace / 3
    a, b, c = (x - mean for x in stress[:3])
    d, e, f = stress[3:]
    scale = sqrt((a*a + b*b + c*c + 2 * (d*d + e*e + f*f)) / 6)
    if scale == 0.:
        return trace, 0., (mean, mean, mean)
    a, b, c, d, e, f = (x / scale for x in (a, b, c, d, e, f))
    half_det = (a * (b*c - f*f) - d * (d*c - e*f) + e * (d*f - e*b)) / 2
    angle = acos(min(1., max(-1., half_det))) / 3
    high = mean + 2 * scale * cos(angle)
    low = mean + 2 * scale * cos(angle + 2*pi/3)
    return trace, 3*scale, (high, trace - high - low, low)


def retention(stress, dt, dc):
    *_, principal = invariants(stress)
    if principal[0] <= 0.:
        positive = 0.
    elif principal[2] >= 0.:
        positive = 1.
    else:
        positive = sum(max(x, 0.) for x in principal) / sum(map(abs, principal))
    return (1. - positive * dt) * (1. - dc)


def elastic(strain):
    hydrostatic = LAME * sum(strain[:3])
    return tuple(2 * G * x + hydrostatic if i < 3 else G * x for i, x in enumerate(strain))


def criterion(stress, cc, ct):
    trace, deviator, (high, _, _) = invariants(stress)
    principal_slope = cc / ct * .88 - 1.12 if high > 0. else 3.
    return (.12 * trace + deviator + principal_slope * high) / .88 - cc


def coordinate_pair(stress, column, increment):
    perturbation = elastic(tuple(increment if i == column else 0. for i in range(6)))
    return diff(stress, perturbation), plus(stress, perturbation)


def crosses(y, epsilon):
    return min(y) < -epsilon and max(y) > epsilon


def audit(archive):
    tags, stations, committed, native = read_trace(archive)
    base, trial = stations["ShiftStop"], stations["ShiftTrial"]
    errors, changes = [], []
    all_crossings, smooth_checks = [], []
    steel_axes = {(int(p), int(side)): int(axis) for label, p, side, axis, *_ in tags["B_BOUND_STEEL"] if label == "ShiftStop"}
    assert fsum(base[p, 0][2] for p in range(1, 26)) == AREA
    for point, side in sorted(base):
        row, candidate, old = base[point, side], trial[point, side], stations["Base24"][point, side]
        ix = 8 * ((side + 1) * 45 + point - 1)
        nominal, kt, kc = committed[ix:ix+6], committed[ix+6], committed[ix+7]
        cc, ct, dt, dc = materials(kt, kc)
        nominal_retention = retention(nominal, dt, dc)
        effective = tuple(x / nominal_retention for x in nominal)
        eps, moved, accepted = row[7:13], candidate[7:13], old[7:13]
        change = diff(moved, eps)
        state = plus(effective, elastic(diff(eps, accepted)))
        ray = plus(effective, elastic(diff(moved, accepted)))
        f0, f1 = criterion(state, cc, ct), criterion(ray, cc, ct)
        threshold = YIELD_TOLERANCE * cc
        if point <= 25:
            errors.extend((abs(f0 - row[6]), abs(f1 - candidate[6])))
            if row[3:6] != candidate[3:6] or row[6] * candidate[6] < 0.:
                changes.append((point, side))
        crossings, directional = [], []
        for column, name in enumerate(MATERIAL_TAGS):
            step = H * (1. + abs(eps[column]))
            sm, sp = coordinate_pair(state, column, step)
            y = criterion(sm, cc, ct), criterion(sp, cc, ct)
            if crosses(y, threshold):
                refined = tuple(criterion(x, cc, ct) for x in coordinate_pair(state, column, step / 4))
                crossings.append({"component": name, "step": step, "minus_plus_F_MPa": y,
                                  "quarter_step_minus_plus_F_MPa": refined, "quarter_step_crosses": crosses(refined, threshold)})
            tangent = (retention(sp, dt, dc) * sp[2] - retention(sm, dt, dc) * sm[2]) / (2 * step)
            directional.append(tangent * change[column])
        if crossings:
            assert f0 * f1 > 0. and abs(f0) > threshold and abs(f1) > threshold
            elastic_action = diff(ray, state)
            sampled = [criterion(plus(state, tuple(value * part / 16 for value in elastic_action)), cc, ct)
                       for part in range(17)]
            assert all(value * f0 > 0. and abs(value) > threshold for value in sampled)
            all_crossings.append({"point": point, "side": side, "x_mm": row[0], "y_mm": row[1],
                                  "stop_F_MPa": f0, "actual_ray_F_MPa": f1, "yield_tolerance_MPa": threshold,
                                  "sampled_ray_F_range_MPa": [min(sampled), max(sampled)], "sampled_ray_count": len(sampled),
                                  "observed_native_flags_stop_and_ray": [row[3:6], candidate[3:6]], "columns": crossings})
        if side != 0 and f0 < -.001 and f1 < -.001 and not crossings:
            actual_concrete = retention(ray, dt, dc) * ray[2] - retention(state, dt, dc) * state[2]
            replacement_sign = 1 if point <= 25 else -1
            steel = 200000. * change[2] if steel_axes.get((point, side)) == 3 else 0.
            material_error = abs((steel + replacement_sign * actual_concrete) - (candidate[15] - row[15]))
            assert material_error < 2e-11
            weight = side * row[2] / (2 * SPATIAL_HALF_STEP * AREA)
            component_error = replacement_sign * (sum(directional) - actual_concrete) * weight
            smooth_checks.append({"point": point, "side": side, "endpoint_stress_replay_error_MPa": material_error,
                                  "stock_coordinate_minus_ray_row53_MPa": component_error})
    sides = [item for item in all_crossings if item["side"]]
    assert [(item["point"], item["side"]) for item in all_crossings] == [(2,-1), (2,0), (2,1), (22,0), (22,1)]
    assert sum(len(item["columns"]) for item in all_crossings) == 10
    assert sum(len(item["columns"]) for item in sides) == 5
    assert all(not col["quarter_step_crosses"] for item in all_crossings for col in item["columns"])
    assert len(smooth_checks) == 16 and max(errors) < 2e-12 and not changes
    sign_error = lambda item: item["stock_coordinate_minus_ray_row53_MPa"]
    native_shift = native["shift_probe"]
    assert not native_shift["accepted_original_equilibrium"] and native_shift["concrete_branch_changes"] == []
    return {"source_archive_sha256": SOURCE_ARCHIVE, "source_native_sha256": SOURCE_NATIVE,
            "source_verification_shift_sha256": SOURCE_RESULT, "audited_source_sha256": SOURCE_CODE,
            "coordinate_h_multiplier": H, "section_area_mm2": AREA, "spatial_half_step_z_over_L": SPATIAL_HALF_STEP,
            "native_ray_stop_to_trial_Qy_N": (native_shift["candidate"]["Qy_parameter_kN"] - native_shift["stop"]["Qy_parameter_kN"]) * 1000,
            "native_full_linear_row53_action_MPa": native_shift["linear_stop_row53_change_MPa"],
            "native_finite_ray_row53_action_MPa": native_shift["actual_stop_row53_change_MPa"],
            "reconstructed_criteria_compared": len(errors), "max_F_replay_error_MPa": max(errors),
            "native_direct_concrete_branch_flags_changed": changes, "side_stations_crossing_columns": len(sides),
            "coordinate_crossings": all_crossings, "smooth_damaged_elastic_station_checks": smooth_checks,
            "smooth_row53_error_signed_sum_MPa": fsum(map(sign_error, smooth_checks)),
            "smooth_row53_error_abs_sum_MPa": fsum(abs(sign_error(item)) for item in smooth_checks),
            "smooth_p23_row53_error_sum_MPa": fsum(sign_error(item) for item in smooth_checks if item["point"] == 23)}


if __name__ == "__main__":
    result = audit(Path(sys.argv[1]))
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("CoordinateYieldAudit.json")
    output.write_bytes((json.dumps(result, indent=2) + "\n").encode("utf-8"))
    print(output, digest(output.read_bytes()))
