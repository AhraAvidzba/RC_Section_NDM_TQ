"""Сверяет рабочую поправку по нативной книге и полному равновесию MVT2."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from tempfile import TemporaryDirectory
from zipfile import ZipFile


EARLIER = ('MVT2TabulatedActiveSteel20261117.zip', '12AC8259874E45568C5B04BB110F4C17D18FDEBD617532A30DE34C262B999792')
BRANCHES = ('MVT2NativeSteelBranches20261117.zip', '6A77DEB08E746CF08833C747F39A4D837DC4C6C470C5CD24B89936DF6AF78D9C')
STOCK = ('src/Solver/CCoupledNewtonSolver.cls','src/Solver/CCoupledSteelCorrection.cls',
         'src/Materials/CCoupledReinforcedResponse.cls')
SUITES = ('RunCoupledNewtonTests','RunTestCoupledSteelLimit','RunTestCoupledSpatialTransactions','RunTestCoupledContinuation',
          'RunTestCoupledDeformationSteelCrossing','RunTestCoupledHoopCapacity','RunTestCoupledSteelClasses','RunTestCoupledSteelAtDesign')


def load_script(repo, entry, file):
    """Подключает только закреплённые функции повторения материала и процесса."""
    path=repo/'docs/regression/Coupled6D'/entry[0]
    assert sha256(path.read_bytes()).hexdigest().upper()==entry[1]
    env={'__name__':'__pinned__','__file__':file}
    with ZipFile(path) as z:
        exec(compile(z.read(file),file,'exec'),env)
    return env


def integrated_path(root, ops, trial_reference):
    """Восстанавливает фактический силовой путь без файла начальных координат."""
    tables, frames, mesh, support, equations, material = ops
    text=(root/'Native/MVTGaussMixed.csv').read_text('cp1251')
    assert 'MVT2_ACTIVE_STEEL_SEED' not in text and not (root/'ActiveSteel.Seeds.csv').is_file()
    test=(root/'tests/modTestMVT2GaussSpan.bas').read_text('utf-8-sig')
    assert 'initialField:=' not in test and not any(x in test for x in ('TestEnableSteelBranchCorrection','ReadActiveSteelSeedTest'))
    meta=json.loads((root/'Preparation.json').read_bytes())
    assert meta['force_schedule']=='IntegratedSteelCorrection' and meta['last_seed_Qy_N'] is None
    assert set(meta['source_core'])==set(STOCK)
    for file, expected in meta['source_core'].items():
        code=(root/file).read_bytes()
        assert sha256(code).hexdigest().upper()==expected==meta['inputs'][file]
        assert b'TestConcreteOnly' not in code and b'TestEnableSteelBranchCorrection' not in code
    seconds,=re.findall(r'^CASE_FINISHED;MVTGaussMixed;True;([^\n]+)',text,re.M)
    rows=[line.split(';',8) for line in text.splitlines() if line.startswith('MVT2_CUT_TRIAL;')]
    assert [float(row[3]) for row in rows]==meta['requested_Qy_N']
    assert all(row[5:8]==['True','4','0'] and float(row[2])==10510000. and float(row[4])==-396.*float(row[3]) for row in rows)
    late=[row for row in rows if float(row[3])>72812.5]
    assert [float(row[3]) for row in late if 'разностных бетонных касательных по полю:' in row[8]]==[76000.]
    probes=sum(int(re.search(r'пробы: (\d+)',row[8])[1]) for row in late)
    assert probes==244
    assert len(frames)==46 and len(tables['H'])==5130
    zero=(0.,)*6
    history={(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in mesh[1]}
    error=0.
    for phase,frame in frames.items():
        field=tables['F'][phase]
        history,net,_=material(field,tables,mesh[1],support,history)
        if phase.startswith('R'): continue
        error=max(error,*(abs(a-b) for (s,p),t in net.items() for a,b in zip(t,tables['H'][phase,s,p],strict=True)))
        result=equations(phase,frame,tables,mesh)
    assert frame[1]==77625. and error<8e-7
    twist=1e6*field[3]/mesh[0][3]
    assert abs(twist-trial_reference['last_balance'][-1]*1000.)<.00001
    norm=max(result[k] for k in ('weak_MPa','gauge_MPa','resultant_MPa'))
    return {'macro_seconds':float(seconds),'probes_after_72_8125':probes,'mixed_fields':38,'stress_error_MPa':error,
            'last_Qy_N':frame[1],'last_norm_MPa':norm,'last_tol_MPa':result['tolerance_MPa'],'last_twist_mrad_per_m':twist}


def check_regressions(root, book):
    """Проверяет штатные макросы, чистую среду материала и выход собственного Excel."""
    base=root/'Native/SteelCoreRegressions.txt'
    driver=(root/'Run-SteelCoreRegressions.ps1').read_text('utf-8')
    assert '$env:NDM_MVT_FLOW_FOLDER=$null' in driver and '$env:NDM_MVT_FLOW_MODE=$null' in driver
    transcript=base.read_text('utf-8-sig')
    assert 'RUNTIME ERROR:' not in transcript and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in transcript
    owners,closure=(json.loads(base.with_name(base.name+suffix).read_text('utf-8-sig'))
                    for suffix in ('.Ownership.json','.ProcessClosure.json'))
    assert owners['VerifiedNewOwner'] and owners['BeforeWorkbookOpen'] and owners['SourceSHA256']==book
    assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['Stage']=='AFTER_CHILD_EXIT'
    pid=closure['Closure']['Identity']
    assert pid['Valid'] and pid['PID']==owners['PID'] and str(pid['Ticks'])==str(owners['StartTicksUTC'])
    assert closure['Closure']['FinalState']['State']=='Absent'
    blocks=re.findall(r'^(TOTAL_[^:\n]+): passed=(\d+); failed=(\d+)',transcript,re.M)
    finished=re.findall(r'^SUITE_FINISHED: modTestCoupledElasticState\.(\w+);',transcript,re.M)
    assert tuple(finished)==SUITES and len(blocks)==len(SUITES) and all(int(ok)>0 and fail=='0' for _,ok,fail in blocks)
    return {name:int(count) for name,count,_ in blocks}


def verify(repo, root, temp):
    """Подтверждает сборку с рабочими исходниками на согласованных данных."""
    branch=load_script(repo, BRANCHES,'Verify-NativeSteelBranches.py')
    material=load_script(repo,EARLIER,'Verify-MVT2TabulatedContinuation.py')
    old,frames0,mesh,support,eq=material['load'](repo,temp)
    with material['archive'](repo,material['OPERATORS']) as source:
        tools=branch['bundled'](source,'Verify-NativeFollow.py')['read_references'](repo)[0]
    stages=[json.loads(line) for line in (root/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert len(stages)==3 and all(x['freeCommitGiB']>=6 and x['ramMiB']>=6500 for x in stages)
    compiler=branch['read'](root/'CodeUpdate.json')
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256']==branch['BOOK']
    assert branch['read'](root/'CompileClosure.json')['State']=='Absent'
    hashes=json.loads((root/'Preparation.json').read_bytes())['inputs']
    for name in (*STOCK,'Run-SteelCoreRegressions.ps1','Run-Native.ps1','tests/modTestMVT2GaussSpan.bas'):
        assert sha256((root/name).read_bytes()).hexdigest().upper()==hashes[name]
    native=root/'Native'
    own=branch['read'](native/'MVTGaussMixed.txt.Ownership.json')
    closure=branch['read'](native/'MVTGaussMixed.txt.ProcessClosure.json')
    assert own['VerifiedNewOwner'] and own['BeforeWorkbookOpen'] and own['SourceSHA256']==compiler['WorkbookSHA256']
    assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['Closure']['FinalState']['State']=='Absent'
    assert closure['Closure']['Identity']['PID']==own['PID']
    report=(native/'MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in report and 'RUNTIME ERROR:' not in report
    tables=tools['read_operators']((native/'Operators.csv').read_bytes())
    frames=tools['read_tensor_frames']((native/'MVTGaussMixed.Tensor.csv').read_bytes(),45)
    assert all(tables[k]==old[k] for k in 'GLBSR')
    early=[phase for phase,(_,q,_) in frames0.items() if q<=72500.]
    assert all(frames[k]==frames0[k] and tables['F'][k]==old['F'][k] for k in early)
    with ZipFile(repo/'docs/regression/Coupled6D'/BRANCHES[0]) as z:
        trial=json.loads(z.read('NativeSteelBranchesProof.json'))['ColdHybrid']
    mvt=integrated_path(root,(tables,frames,mesh,support,eq,material['material']),trial)
    return {'mvt2':mvt,'stock_regressions':check_regressions(root,compiler['WorkbookSHA256']),'physical_limit_established':False}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    with TemporaryDirectory(dir=args.out.resolve().parent) as folder:
        proof=verify(args.repo,args.root,Path(folder))
    args.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode('utf-8'))
    print('MVT2 INTEGRATED STEEL CORRECTION PASS',proof['mvt2']['last_Qy_N'],sum(proof['stock_regressions'].values()))
