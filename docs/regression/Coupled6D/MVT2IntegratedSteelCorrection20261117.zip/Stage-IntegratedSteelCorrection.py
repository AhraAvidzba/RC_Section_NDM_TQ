"""Комплектует частную книгу точными рабочими исходниками поправки стали."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent
STOCK = ('src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledSteelCorrection.cls',
         'src/Materials/CCoupledReinforcedResponse.cls')
MVT_MACRO = 'tests/modTestMVT2GaussSpan.bas'


def stage(repo, root, pid, ticks):
    """Копирует рабочие модули в черновик маршрута без начальных полей."""
    previous = run_path(str(HERE/'Stage-NewtonSteelBranches.py'))
    previous['stage'](repo,root,pid,ticks,False,False,False,True,False)
    base = run_path(str(HERE/'Stage-TabulatedFlowNative.py'))
    assert 'initialField:=' not in (root/MVT_MACRO).read_text('utf-8-sig')
    driver = root/'Run-Native.ps1'
    code = driver.read_text('utf-8')
    tag = "'CTestTabulatedConcreteFlow')"
    modules = ','.join("'"+Path(name).stem+"'" for name in STOCK)
    driver.write_bytes(base['once'](code,tag,tag[:-1]+','+modules+')').encode('utf-8'))
    for name in STOCK:
        path=root/name
        path.parent.mkdir(exist_ok=True)
        path.write_bytes((repo/name).read_bytes())
    regressions = root/'Run-SteelCoreRegressions.ps1'
    regressions.write_bytes((HERE/regressions.name).read_bytes())
    manifest=root/'Preparation.json'
    prep=json.loads(manifest.read_bytes())
    prep['force_schedule']='IntegratedSteelCorrection'
    prep['source_core']={file:base['digest']((root/file).read_bytes()) for file in STOCK}
    for name in ('active_branch_correction','concrete_field_difference','deep_damping','hybrid_tangent'):
        prep.pop(name)
    prep['inputs'].update(prep['source_core'])
    for name in (driver.name,regressions.name):
        prep['inputs'][name]=base['digest']((root/name).read_bytes())
    manifest.write_bytes((json.dumps(prep,indent=2)+'\n').encode())


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--stage',type=Path,required=True)
    p.add_argument('--guard-pid',type=int,required=True)
    p.add_argument('--guard-ticks',type=int,required=True)
    args=p.parse_args()
    stage(args.repo.resolve(),args.stage.resolve(),args.guard_pid,args.guard_ticks)
