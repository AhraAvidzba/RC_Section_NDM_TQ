"""Восстанавливает плоскость поворота, меру и знаковые равновесия дорожки."""
from math import acos, atan2, cos, degrees, fsum, isclose, pi, sin, sqrt
from pathlib import Path

import ArcVerify as arc
import PriorVerify as prior

HERE=Path(__file__).resolve().parent
REPORT='8F255FA77B6EE1753173C5C37633B5EB0248DCC673DDFBC82C5E3908A73C5A9B'
ARCHIVE='CBC7CB1E5D33FF2DC18FAC4A37BB109FFC7B18804D3BD4000A89173BEA8F77BC'
ANGLE=5*pi/180


def inputs(fixture,extract):
    baseline=HERE/'FullTravel/HardG14Direction.csv'
    receipt=HERE/'FullTravel/Verification.json'
    assert fixture['full_travel_archive_sha256']==ARCHIVE
    assert fixture['full_travel_report_sha256']==prior.file_hash(receipt)==REPORT
    full=prior.read(receipt)
    assert full['native_trace_sha256']==prior.file_hash(baseline)
    assert full['automatic_branch_retry']['attempt14']=='ACCEPTED'
    assert full['automatic_branch_retry']['attempt15']=='LOCALITY_OR_BALANCE'
    _,_,_,steps,_,final=extract(baseline)
    assert len(steps)==15 and final==['SINGLE_STOCK_PROBE','10','9744']


def dot(a,b):
    return fsum(x*y for x,y in zip(a,b,strict=True))


def plane(extract,physical_dual,weights,op,change,norm,current,primary):
    _,_,_,reference,_,_=extract(HERE/'FullTravel/HardG14Direction.csv')
    proof=reference[14]
    assert current==prior.numbers(reference[13]['TRACE-COMMIT'])
    field=prior.numbers(proof['TRACE-FIELD'])
    chord=[b-a if i<56 else 0. for i,(a,b) in enumerate(zip(current,field,strict=True))]
    unit=[d/norm if i<56 else 0. for i,d in enumerate(change)]
    forward=dot(primary,chord)
    cross=[d-forward*v for d,v in zip(chord,unit,strict=True)]
    cross_norm=sqrt(arc.metric_value(weights,op,cross))
    assert cross_norm>0 and abs(dot(primary,cross))<5e-21
    second=physical_dual(weights,op,cross,cross_norm)
    rotated=[cos(ANGLE)*a+sin(ANGLE)*b for a,b in zip(primary,second,strict=True)]
    original_distance=sqrt(arc.metric_value(weights,op,chord))
    new_projected=dot(rotated,chord)
    chord_angle=atan2(cross_norm,forward)
    minimum=max(0.,chord_angle-acos(1/3))
    rotated_unit=[cos(ANGLE)*a+sin(ANGLE)*b/cross_norm for a,b in zip(unit,cross,strict=True)]
    assert isclose(dot(primary,rotated_unit),cos(ANGLE),rel_tol=5e-13)
    assert isclose(arc.metric_value(weights,op,rotated_unit),1.,rel_tol=5e-13)
    assert isclose(new_projected,forward*cos(ANGLE)+cross_norm*sin(ANGLE),rel_tol=5e-13)
    return rotated,dict(cosine_to_accepted_secant=cos(ANGLE),angle_deg=degrees(ANGLE),
                        rejected_chord_to_secant_deg=degrees(chord_angle),
                        minimum_deg_if_chord_direction_unchanged=degrees(minimum),
                        archived_chord_forward=forward,archived_chord_orthogonal=cross_norm,
                        archived_chord_distance=original_distance,
                        archived_chord_projection_onto_rotated_control=new_projected,
                        estimated_ratio_if_chord_direction_unchanged=original_distance/new_projected)


def verify(path,extract,physical_dual,steps,final,rows,weights,op,geometry):
    raw=path.read_text(encoding='cp1251').splitlines()
    old=HERE/'FullTravel/HardG14Direction.csv'
    prior_rows=old.read_text(encoding='cp1251').splitlines()
    assert [r for r in raw if r.startswith('AUTO-')]==[r for r in prior_rows if r.startswith('AUTO-')]
    _,witness_weights,witness_op,reference,_,_=extract(old)
    assert len(steps)==15 and steps[:14]==reference[:14] and weights==witness_weights and op==witness_op
    assert final[0]=='SINGLE_STOCK_PROBE' and final[-1]=='9744'
    assert steps[14]['args'][2:3]==reference[14]['args'][2:3]
    assert steps[14]['args'][4:7]==reference[14]['args'][4:7]
    assert steps[14]['TRACE-SEED']==reference[14]['TRACE-SEED']
    assert steps[14]['TRACE-PROJECTION']!=reference[14]['TRACE-PROJECTION']
    current,previous=[prior.numbers(steps[i]['TRACE-COMMIT']) for i in (13,10)]
    change=[a-b for a,b in zip(current,previous,strict=True)]
    norm=sqrt(arc.metric_value(weights,op,change))
    primary=physical_dual(weights,op,change,norm)
    projection,prediction=plane(extract,physical_dual,weights,op,change,norm,current,primary)
    record,=[r.split(';')[1:] for r in raw if r.startswith('STEER-PLANE;')]
    rad,forward,perp=prior.numbers(record)
    assert isclose(rad,ANGLE,rel_tol=2e-15)
    assert isclose(forward,prediction['archived_chord_forward'],rel_tol=2e-11)
    assert isclose(perp,prediction['archived_chord_orthogonal'],rel_tol=2e-11)
    result=dict(exact_first_14_attempts=True,same_predictor_bits=True,restored_history_values=9744,
                predicted_geometry_only=prediction,stock_attempt15=rows[14],physical_limit_certified=False)
    if 'TRACE-FIELD' in steps[14]:
        step=steps[14]
        field,load,wrench=(prior.numbers(step[k]) for k in ('TRACE-FIELD','TRACE-LOAD','TRACE-WRENCH'))
        area,length,modulus=prior.numbers(geometry['MESH'][-3:])
        result['actual_signed_normalized_force_error_MPa']=[(a-b)/s for a,b,s in zip(
            wrench,load,(area,area*length,area*length,area*length,area,area),strict=True)]
        move=[b-a for a,b in zip(current,field,strict=True)]
        result['actual_advance_in_original_and_steered_measures']=[dot(primary,move),dot(projection,move)]
        take=rows[14]
        result['actual_distance_to_requested']=take['actual_distance']/take['requested_distance']
        if take['decision']=='ACCEPTED':
            old_row=rows[13]
            delta=take['lambda']-old_row['lambda']
            error=take['lambda_uncertainty']+old_row['lambda_uncertainty']
            result['accepted_delta_lambda_interval']=[delta-error,delta+error]
    return result
