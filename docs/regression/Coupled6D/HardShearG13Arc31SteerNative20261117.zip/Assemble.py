"""Steers the control on a single stock probe after the exact accepted automatic correction."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import sys


HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
AUTO=ROOT/'tmp/hs-p31-auto/proof/HardShearG13Arc31AutoNative20261117.zip'
AUTO_SHA='CBC7CB1E5D33FF2DC18FAC4A37BB109FFC7B18804D3BD4000A89173BEA8F77BC'
REPORT='8F255FA77B6EE1753173C5C37633B5EB0248DCC673DDFBC82C5E3908A73C5A9B'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'
MACROS='tests/modTestCoupledElasticState.bas'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def once(src,old,new):
    assert src.count(old)==1,old
    return src.replace(old,new)


def seal(dest,name,data):
    target=dest/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_bytes()==data,name
    else:
        target.write_bytes(data)
    return sha(data)


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready')
    cli.add_argument('--with-workbook',action='store_true')
    args=cli.parse_args()
    dest=args.destination.resolve()
    assert dest.is_relative_to(HERE) or dest.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    sys.path.insert(0,str(ROOT/'tmp/hs-p31-auto'))
    import PortableSupport as source
    import Pack
    portable=source.read_zip(AUTO,AUTO_SHA)
    assert (ROOT/'tmp/hs-p31-auto/PortableSupport.py').read_bytes()==portable['PortableSupport.py']
    frozen=source.restore_files(portable,source.read_baselines(Pack.DEFAULT56,Pack.DEFAULT_RESUME))
    assert sha(frozen[source.REPORT])==REPORT
    verified=json.loads(frozen[source.REPORT])
    assert verified['automatic_branch_retry']['attempt14']=='ACCEPTED'
    assert verified['automatic_branch_retry']['attempt15']=='LOCALITY_OR_BALANCE'
    assert sha(frozen[source.TRACE])==verified['native_trace_sha256']
    plan=json.loads(frozen['Fixture.json'])
    book=(ROOT/plan['workbook']).read_bytes()
    assert sha(book)==plan['source_workbook_sha256']
    trace=frozen[source.TRACE].decode('cp1251').splitlines()
    last=next(i for i,line in enumerate(trace) if line.startswith('TRACE-TRY;15;'))
    chord=next(line.split(';')[1:] for line in trace[last:] if line.startswith('TRACE-FIELD;'))
    assert len(chord)==60 and all(len(value)==16 for value in chord)
    packed=''.join(chord)
    assignment='\n'.join('    packed = '+('packed & ' if i else '')+'"'+packed[i:i+160]+'"'
                         for i in range(0,len(packed),160))
    helper=text((HERE/'Steer.bas').read_bytes()).replace('@CHORD@',assignment)
    assert max(map(len,helper.splitlines()))<220
    files={}
    for name,digest in plan['inputs'].items():
        raw=frozen[name]
        assert sha(raw)==digest,name
        if name=='Assemble.py':
            continue
        if name==SOLVER:
            v=text(raw)
            marker='        seedScale = requested / length\n        probes = probes + 1\n'
            v=once(v,marker,'''        If attempt = 15 Then
            If Not SetHardArcSteeringTest(coefficients, current, movement, length, projection) Then
                outcome = "STEER_FORMATION_REFUSED": Exit For
            End If
        End If
'''+marker)
            v=v.rstrip()+'\n\n'+helper.rstrip()+'\n'
            assert '    mHardAutoEnabledTest = (attempt = 14)' in v and 'If attempt = 15 Then outcome' in v
            v.encode('cp1251')
            raw=v.replace('\n','\r\n').encode('utf-8')
        elif name==MACROS:
            macros=once(text(raw),'Private Sub HardRankUnpackTest','Public Sub HardRankUnpackTest')
            raw=macros.replace('\n','\r\n').encode('utf-8')
        elif name=='Verify.py':
            v=text(raw)
            v=once(v,'import AutoProof as auto','import AutoProof as auto\nimport SteerProof as steer')
            v=once(v,'    auto.inputs(fixture, extract)','    auto.inputs(fixture, extract)\n    steer.inputs(fixture, extract)')
            v=once(v,"('ARC56-','AUTO-')","('ARC56-','AUTO-','STEER-')")
            v=once(v,'        primary=physical_dual(weights,op,change,norm)',
                   '        primary=physical_dual(weights,op,change,norm)\n'
                   '        if attempt==15:\n'
                   '            primary,_=steer.plane(extract,physical_dual,weights,op,change,norm,current,primary)')
            v=once(v,"    output=folder/'Verification.json'",
                   "    result['steered_travel_comparison']=steer.verify(path,extract,physical_dual,steps,final,rows,weights,op,geometry)\n"
                   "    output=folder/'Verification.json'")
            raw=v.encode('utf-8')
        elif name=='Run.ps1':
            raw=text(raw).replace('HardArc31Auto','HardArc31Steer').encode()
        files[name]=seal(dest,name,raw)
    for name,raw in [('FullTravel/Verification.json',frozen[source.REPORT]),
                     ('FullTravel/HardG14Direction.csv',frozen[source.TRACE]),
                     ('SteerProof.py',(HERE/'SteerProof.py').read_bytes()),('Steer.bas',(HERE/'Steer.bas').read_bytes()),('Assemble.py',(HERE/'Assemble.py').read_bytes())]:
        files[name]=seal(dest,name,raw)
    if args.with_workbook:
        seal(dest,plan['workbook'],book)
        seal(dest,'docs/regression/Diagnostic.xlsm',book)
        for name in ('Native/Order10','Temp'):
            (dest/name).mkdir(parents=True,exist_ok=True)
    result={**plan,'inputs':files,'full_travel_archive_sha256':AUTO_SHA,'full_travel_report_sha256':REPORT,
            'scope':'Exact auto prefix through accepted attempt14; one stock attempt15 rotated 5deg within archived chord plane; same predictor, travel, locality and tolerances'}
    print(dest,seal(dest,'Fixture.json',(json.dumps(result,indent=2)+'\n').encode()))


if __name__=='__main__':
    main()
