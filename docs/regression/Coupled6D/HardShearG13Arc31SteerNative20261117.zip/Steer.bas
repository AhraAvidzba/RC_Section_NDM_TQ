' -------------------- ДЛЯ ТЕСТОВ --------------------
' Поворачивает только меру управления. Начальное поле остаётся
' продолжением принятой секущей. Архивная хорда задаёт плоскость.
Private Function SetHardArcSteeringTest(ByRef coefficients() As Double, ByRef current() As Double, _
        ByRef movement() As Double, ByVal length As Double, ByRef projection() As Double) As Boolean
    Const ANGLE_RADIANS As Double = 0.0872664625997165 ' Пять градусов.
    Dim archived() As Double, orthogonal() As Double, dual() As Double, packed As String
    Dim longitudinal As Double, normalLength As Double, i As Long
@CHORD@
    HardRankUnpackTest packed, archived
    ReDim orthogonal(1 To mDegreeCount)
    For i = 1 To mGaugeStart - 1
        orthogonal(i) = archived(i) - current(i)
        longitudinal = longitudinal + projection(i) * orthogonal(i)
    Next i
    For i = 1 To mGaugeStart - 1
        orthogonal(i) = orthogonal(i) - longitudinal * movement(i) / length
    Next i
    normalLength = Sqr(ArcPhysicalSquare(coefficients, orthogonal, dual, True))
    If normalLength <= 0# Then Exit Function
    WriteHardRankRowTest "STEER-PLANE;" & HardRankBitsTest(ANGLE_RADIANS) & ";" & _
        HardRankBitsTest(longitudinal) & ";" & HardRankBitsTest(normalLength)
    For i = 1 To mGaugeStart - 1
        projection(i) = Cos(ANGLE_RADIANS) * projection(i) + Sin(ANGLE_RADIANS) * dual(i) / normalLength
    Next i
    SetHardArcSteeringTest = True
End Function
