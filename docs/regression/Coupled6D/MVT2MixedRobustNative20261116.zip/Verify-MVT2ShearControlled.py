"""Independent native verification of the measured MVT2 secant predictions and rollback."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import sys
import csv
import json
import math

DIM = 60
AREA = 240.**2
LENGTH = math.hypot(110., 110.)
MODULUS = 30000.


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def near(a, b, tol):
    assert abs(a-b) <= tol, (a, b, tol)


def peak(values):
    return max(map(abs, values))


def diff(a, b):
    return tuple(x-y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return math.fsum(x*y for x, y in zip(a, b, strict=True))


def b3(coordinate):
    t = (coordinate+120.)/240.
    s = 1.-t
    basis = (s**3, 3*s*s*t, 3*s*t*t, t**3)
    raw = (-s*s, s*s-2*s*t, 2*s*t-t*t, t*t)
    return basis, tuple(3*factor*LENGTH/240. for factor in raw)


def operators(x, y):
    bx, dx = b3(x)
    by, dy = b3(y)
    xn, yn = x/LENGTH, y/LENGTH
    contracted = [((2,1.),), ((2,yn),), ((2,xn),), ((4,-yn),(5,xn))]
    shape = []
    for j in range(4):
        for i in range(4):
            ex, ey = dx[i]*by[j], bx[i]*dy[j]
            contracted.extend((((0,ex),(3,ey)), ((1,ey),(3,ex)), ((4,ex),(5,ey))))
            shape.append(bx[i]*by[j])
    return contracted, shape, xn, yn


def strain_at(field, block, side):
    bx, _, _, _ = block
    components = [0.]*6
    for index, row in enumerate(bx):
        for j, scale in row:
            components[j] += scale * field[index]
    for index, row in enumerate(bx[:4]):
        for j, scale in row:
            components[j] += side * .001 * scale * field[52+index]
    return components


def force(q):
    return (0., 600000.*q, 0., 10510000., 0., 1000.*q)


def loading(q):
    load = [0.]*DIM
    load[1] = 600000.*q/AREA/LENGTH
    load[3] = 10510000./AREA/LENGTH
    load[53] = 1000.*q/AREA
    return load


def reconstruct(field, factor, stations):
    sums = [[] for _ in range(DIM)]
    for slot, load in zip(sums, loading(factor), strict=True):
        slot.append(-load)
    force_parts = []
    strain_error = 0.
    for point in range(1,46):
        minus, center, plus = (stations[point,side] for side in (-1,0,1))
        x,y,area = center[:3]
        block = operators(x,y)
        cols, shape, xn, yn = block
        assert minus[:3] == center[:3] == plus[:3]
        for station, side in ((minus,-1),(center,0),(plus,1)):
            strain_error = max(strain_error, peak(diff(strain_at(field,block,side), station[7:13])))
        s = center[13:19]
        sp = tuple((p-m)/.002 for p,m in zip(plus[13:19],minus[13:19],strict=True))
        az, axz, ayz = s[2]*area, s[4]*area, s[5]*area
        force_parts.append((az, az*y, az*x, x*ayz-y*axz, axz, ayz))
        w = area/AREA
        for idx, terms in enumerate(cols):
            value = math.fsum(s[k]*coef for k,coef in terms)
            if idx < 4:
                sums[52+idx].append(w*math.fsum(sp[k]*coef for k,coef in terms))
            else:
                axis, node = (idx-4)%3,(idx-4)//3
                value -= shape[node]*sp[(4,5,2)[axis]]
                if point <= 25:
                    g = shape[node]*w
                    sums[idx].append(g*field[56+axis])
                    sums[56+axis].append(g*field[idx])
                    if axis < 2:
                        rotation = g*(-yn if axis==0 else xn)
                        sums[idx].append(rotation*field[59])
                        sums[59].append(rotation*field[idx])
            sums[idx].append(w*value)
    efforts = tuple(math.fsum(parts) for parts in zip(*force_parts,strict=True))
    return tuple(map(math.fsum,sums)), efforts, strain_error


def frobenius(strain):
    return math.sqrt(math.fsum(value*value*(1. if i<3 else .5) for i,value in enumerate(strain)))


def strain_extent(field, stations):
    return max(frobenius(strain_at(field,operators(*row[:2]),side)) for (_,side),row in stations.items())


def vec(tags, key):
    result = {label:tuple(map(float,values)) for label,*values in tags[key]}
    assert len(result)==len(tags[key]) and all(len(values)==DIM for values in result.values())
    return result



SCALES = (AREA, AREA*LENGTH, AREA*LENGTH, AREA*LENGTH, AREA, AREA)
EFFORT_NAMES = ("N", "Mx", "My", "T", "Qx", "Qy")


def read_native(path,encoding="cp1251"):
    tables=defaultdict(list)
    for marker,*row in csv.reader(path.read_text(encoding=encoding).splitlines(),delimiter=";"):
        tables[marker].append(row)
    return tables


def verified_states(tags):
    fields, stations = {}, defaultdict(dict)
    for name, history, q, *x in tags["B_TANGENT_FIELD"]:
        assert name not in fields and len(x) == 60
        fields[name] = (int(history), float(q), tuple(map(float, x)))
    for name, point, side, *row in tags["B_TANGENT_STATION"]:
        key = int(point), int(side)
        assert key not in stations[name] and len(row) == 19
        stations[name][key] = tuple(map(float, row))
    raw_r = vec(tags, "B_TANGENT_RESIDUAL")
    raw_force = {name: tuple(map(float, row)) for name, *row in tags["B_BOUND_ACTUAL"]}
    raw_norm = {name: float(value) for name, value in tags["B_BOUND_NORM"]}
    output = {}
    assert set(stations) == set(raw_r) == set(raw_force) == set(raw_norm)
    unavailable={name for name,reason,*_ in tags['B_TANGENT_UNAVAILABLE'] if reason=='Residual'}
    assert set(fields)-set(raw_r)==unavailable
    for name, (history, q, x) in fields.items():
        if name in unavailable:
            continue
        assert history == 24 and len(stations[name]) == 135
        rows, actual, strain_error = reconstruct(x, q, stations[name])
        error = peak(diff(rows, raw_r[name]))
        assert strain_error < 4e-15 and error < 3e-10
        assert max(abs(a-b)/s for a,b,s in zip(actual, raw_force[name], SCALES, strict=True)) < 4e-12
        signed = diff(actual, force(q))
        efforts = tuple(r/s for r, s in zip(signed, SCALES, strict=True))
        residual = (*rows[:56], *efforts)
        gauge_norm = MODULUS*peak(rows[56:])
        tol = 5e-7*(1.+peak(loading(q)))
        near(max(peak(residual), gauge_norm),raw_norm[name], 4e-10)
        assert gauge_norm <= tol
        output[name] = {"q": q, "field": x, "r": residual, "gauge_MPa": gauge_norm, "tol_MPa": tol,
            "signed_force_N_Nmm": signed, "norm_MPa": peak(residual), "reconstruction_error_MPa": error,
            "geometry": {key: row[:3] for key, row in stations[name].items()}}
    return output, stations


def tensor_radius(field, geometry):
    maximum = 0.
    for (_, side), (x, y, _) in geometry.items():
        strain = strain_at(field, operators(x, y), side)
        maximum = max(maximum, peak(s/(1. if i < 3 else math.sqrt(2.)) for i, s in enumerate(strain)))
    return maximum


HERE=Path(__file__).resolve().parent
NATIVE=HERE/'Native'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def verify_run(prep):
    build=read(HERE/'docs/regression/CodeUpdate.json')
    compiler=read(HERE/'CompileClosure.json')
    owner=read(NATIVE/'MVT2.txt.Ownership.json')
    watch=read(NATIVE/'MVT2.txt.ProcessClosure.json')
    receipt=read(NATIVE/'RunReceipt.json')
    final=watch['Closure']['FinalState']
    assert build['Compiled'] and build['Modules']==['modTestCoupledExperiment'] and not build['ProductionChanged']
    assert build['ProductionSHA256']==prep['book_sha256'] and compiler['State']=='Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256']==build['WorkbookSHA256']
    assert watch['Passed'] and watch['ChildExitCode']==receipt['native_exit']==0 and watch['ChildHasExited']
    assert final['State']=='Absent' and final['PID']==owner['PID'] and final['StartTicksUTC']==owner['StartTicksUTC']
    assert 'TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0' in (NATIVE/'MVT2.txt').read_text(encoding='utf-8-sig')
    if '--offline' not in sys.argv:
        assert digest(HERE/'docs/regression/Diagnostic.xlsm')==build['WorkbookSHA256']
    return compiler,final,receipt['wall_seconds']


def verify_steel(tags, native, stations, accepted):
    steel=defaultdict(dict)
    for name,point,side,ax,e,concrete,sigma in tags['B_BOUND_STEEL']:
        key=int(point),int(side)
        assert key not in steel[name]
        steel[name][key]=int(ax)-1,float(e),float(concrete),float(sigma)
    assert set(steel)==set(native)
    peaks={}
    for name,stress in steel.items():
        assert len(stress)==60
        for (point,side),(ax,e,concrete,sigma) in stress.items():
            row=stations[name][point,side]
            x,y,area=row[:3]
            assert ax==(2 if point<=29 else 1 if abs(x)>abs(y) else 0)
            near(e,row[7+ax],4e-16)
            near(sigma,row[13+ax]+concrete,4e-10)
            near(sigma,200000.*e,4e-8)
            limit=498. if point<=29 else 450.
            assert abs(sigma)<limit
            block=operators(x,y)
            assert max(abs(strain_at(q,block,side)[ax])*200000. for q in accepted.values())<limit
        peaks[name]=max(abs(row[3]) for row in stress.values())
    return peaks


LABELS=('Anchor','Large','AxialPlus','TwistPlus')


def input_checks(prep):
    assert all(digest(HERE/name)==value for name,value in prep['prior_input_sha256'].items())
    old_tags=read_native(HERE/'PreviousNative.csv','ascii')
    older,old_stations=verified_states(old_tags)
    actual_old=vec(old_tags,'B_TANGENT_RESIDUAL')
    evidence=read(HERE/'MixEvidence.json')
    model=read(HERE/'TwistFeasibility.json')['reflected_sign_minimum']
    anchor=older['Anchor']
    q=anchor['q'];tol=anchor['tol_MPa']; near(tol,evidence['target_original_tolerance_MPa'],5e-15)
    assert q==evidence['fixed_Qy_kN']
    rows=list(csv.reader((HERE/'Anchors.csv').read_text().splitlines(),delimiter=';'))[1:]
    assert [row[0] for row in rows]==list(LABELS) and all(len(row)==128 for row in rows)
    expected={}
    for row in rows:
        name, load,*values=row
        assert float(load)==q
        numbers=tuple(map(float,values))
        assert numbers[:60]==older[name]['field']
        assert numbers[60:116]==actual_old[name][:56]
        assert numbers[116:120]==tuple(x*MODULUS for x in actual_old[name][56:])
        near(peak(diff(numbers[120:],older[name]['r'][56:])),0.,3e-15)
        expected[name]=numbers[60:]
    fields=list(csv.reader((HERE/'CandidateFields.csv').read_text().splitlines(),delimiter=';'))[1:]
    assert len(fields)==2
    name,load,objective,*field=fields[0]
    assert name=='MeasuredRobust' and float(load)==q
    coordinates=tuple(map(float,field));assert len(coordinates)==60
    near(peak(diff(coordinates,model['coordinates'])),0.,3e-15)
    near(float(objective),model['linear_worst_case_MPa'],3e-15)
    assert model['axes']==['Large','AxialPlus','TwistPlus']
    weights=model['coefficients'];assert all(x>0. for x in weights) and sum(weights)<=1.+3e-15
    recomposed=tuple(a+math.fsum(w*(older[k]['field'][i]-a) for w,k in zip(weights,model['axes'],strict=True))
        for i,a in enumerate(anchor['field']))
    assert peak(diff(recomposed,coordinates))<3e-15
    radius=tensor_radius(diff(coordinates,anchor['field']),anchor['geometry'])
    near(radius,model['shape_component_peak'],3e-15)
    assert radius<=1e-8+4e-16
    threshold=evidence['source_dual_state_anchor_roundoff_guard_MPa']
    assert threshold==8e-10 and threshold<tol
    return older,old_stations,expected,coordinates,radius,model,threshold


def prepare_only():
    prep=read(HERE/'Preparation.json')
    older,_,_,field,radius,model,guard=input_checks(prep)
    anchor=older['Anchor']
    info={'source_book_sha256':prep['book_sha256'],'source_H24_sha256':prep['replay_sha256'],
        'input_sha256':prep['prior_input_sha256'],'candidate_label':'MeasuredRobust','source_anchors':list(LABELS),
        'original_tol_MPa':anchor['tol_MPa'],'anchor_norm_MPa':anchor['norm_MPa'],
        'old_vector_roundoff_guard_MPa':guard,'tensor_radius':radius,'fixed_Qy_kN':anchor['q'],
        'six_caps_N_Nmm':[max(abs(v),anchor['tol_MPa']*s) for v,s in zip(anchor['signed_force_N_Nmm'],SCALES,strict=True)],
        'frozen_linear_prediction_MPa':model['linear_worst_case_MPa'],'native_result_pending':True}
    path=HERE/'InputCheck.json'
    path.write_text(json.dumps(info,indent=2)+'\n',encoding='utf8')
    print(path,digest(path))


def main():
    prep=read(HERE/'Preparation.json')
    old,old_stations,expected,field,radius,model,guard=input_checks(prep)
    compiler,owner,wall=verify_run(prep)
    assert digest(HERE/'Replay.csv')==prep['replay_sha256']
    assert digest(HERE/'tests/modTestCoupledExperiment.bas')==prep['module_sha256']
    tags=read_native(NATIVE/'MVT2.csv')
    native,stations=verified_states(tags)
    residual_native=vec(tags,'B_TANGENT_RESIDUAL')
    actual_native={n:tuple(map(float,values)) for n,*values in tags['B_BOUND_ACTUAL']}
    archived=list(csv.reader((HERE/'Replay.csv').read_text().splitlines(),delimiter=';'))[1:]
    history=vec(tags,'MVT2_CONTROL_FIELD')
    assert len(history)==len(archived)==24
    for i,row in enumerate(archived,1):
        assert int(row[0])==i and peak(diff(tuple(map(float,row[9:])),history[f'Replay{i}']))<1e-15
    [[qbase,qtrial]]=tags['B_TANGENT_LOAD']
    qbase,qtrial=map(float,(qbase,qtrial))
    near(qbase,float(archived[-1][2]),2e-13)
    near(qtrial,qbase+(qbase-float(archived[-2][2]))/64.,2e-13)
    for label in ('Base24','Restored24'):
        assert native[label]==native['Base24'] and native[label]['field']==history['Replay24']
        assert stations[label]==stations['Base24']
    anchor=native['Anchor']
    assert anchor['q']==old['Anchor']['q']==qtrial
    tol=anchor['tol_MPa']; caps=tuple(max(tol,abs(v)) for v in anchor['r'][56:])
    [[log_ref,log_tol]]=tags['B_MEASURE_ORIGIN']
    near(float(log_ref),anchor['norm_MPa'],4e-10);near(float(log_tol),tol,5e-15)
    [[key,*logged_caps]]=tags['B_MEASURE_CAPS']
    assert key=='Anchor'
    near(peak(diff(tuple(map(float,logged_caps)),caps)),0.,4e-10)
    log_anchors={name:(float(v),int(flag)) for name,v,flag in tags['B_MIXED_ANCHOR']}
    unavailable=[el[0] for el in tags['B_MIXED_ANCHOR_UNAVAILABLE']]
    assert set(log_anchors).union(unavailable)==set(LABELS)
    anchor_report={}
    for label in LABELS:
        if label in unavailable:
            assert label not in native
            anchor_report[label]={'material_response_available':False,'matches_archived_response':False}
            continue
        state=native[label]
        assert state['q']==qtrial and state['geometry']==old[label]['geometry']
        assert peak(diff(state['field'],old[label]['field']))<3e-15
        s=residual_native[label]
        actual=tuple((a-b)/den for a,b,den in zip(actual_native[label],force(qtrial),SCALES,strict=True))
        measure=peak(diff((*s[:56],*(v*MODULUS for v in s[56:]),*actual),expected[label]))
        discrepancy=peak(diff(state['r'],old[label]['r']))
        recorded,yes=log_anchors[label]
        near(measure,recorded,4e-10)
        if abs(measure-guard)>4e-10:
            assert yes==int(measure<=guard)
        anchor_report[label]={'material_response_available':True,'matches_archived_response':bool(yes),
            'native_guard_vector_error_MPa':recorded,'independent_62_vector_max_difference_MPa':discrepancy,
            'archive_exact_tensor_max_error':max(peak(diff(v,old_stations[label][key])) for key,v in stations[label].items())}
    defer=not all(item['matches_archived_response'] for item in anchor_report.values())
    assert bool(tags['B_MIXED_DEFER'])==defer
    steel=verify_steel(tags,native,stations,history)
    result=None
    if defer:
        assert tags['B_MIXED_DEFER']==[['ArchivedResponseChanged']]
        assert 'MeasuredRobust' not in native and 'MeasuredRobust/Rollback' not in native
    else:
        assert native['MeasuredRobust/Rollback']==native['Base24'] and stations['MeasuredRobust/Rollback']==stations['Base24']
        [[label,planned,radius_native]]=tags['B_MEASURE_INPUT']
        assert label=='MeasuredRobust'
        near(float(planned),model['linear_worst_case_MPa'],3e-15)
        near(float(radius_native),radius,5e-15)
        if 'MeasuredRobust' not in native:
            assert any(row[:2]==['MeasuredRobust','Residual'] for row in tags['B_TANGENT_UNAVAILABLE'])
            result={'material_response_available':False}
        else:
            state=native['MeasuredRobust']; r=state['r'];g=state['gauge_MPa']
            assert state['q']==qtrial and peak(diff(state['field'],field))<3e-15
            [[_,*native_flags]]=tags['B_MEASURE_STATUS']
            [[_,*relative_efforts]]=tags['B_MEASURE_RELATIVE_EFFORTS']
            near(peak(diff(r[56:],tuple(map(float,relative_efforts)))),0.,4e-10)
            overall=max(state['norm_MPa'],g)
            found=overall<=tol
            improved=overall<anchor['norm_MPa']
            violations=[n for n,v,cap in zip(EFFORT_NAMES,r[56:],caps,strict=True) if abs(v)>cap+4e-10]
            flags=tuple(map(int,native_flags))
            assert flags[0]==int(found) and flags[2]==int(improved)
            if not any(abs(abs(v)-cap)<4e-10 for v,cap in zip(r[56:],caps,strict=True)):
                assert flags[1]==int(not violations)
            action_nominal=tuple(math.fsum(w*(native[key]['r'][i]-anchor['r'][i])
                 for w,key in zip(model['coefficients'],model['axes'],strict=True)) for i in range(62))
            predicted=tuple(a+b for a,b in zip(anchor['r'],action_nominal,strict=True))
            error=diff(r,predicted)
            result={'material_response_available':True,'measured_norm_MPa':overall,
                'change_in_max_norm_MPa':overall-anchor['norm_MPa'],'predicted_affine_norm_MPa':model['linear_worst_case_MPa'],
                'exact_nominal_mix_vector_discrepancy_MPa':peak(error),
                'exact_nominal_mix_discrepancy_row':max(range(62),key=lambda i:abs(error[i]))+1,
                'six_signed_effort_error_N_Nmm':state['signed_force_N_Nmm'],'violation_efforts':violations,
                'worst_weak_row':max(range(56),key=lambda i:abs(r[i]))+1,'gauge_MPa':g,
                'full_resultant_and_weak_vector_MPa':r,'frozen_nominal_prediction_MPa':predicted,
                'physically_bounded_tensor_component':radius,'max_steel_stress_MPa':steel['MeasuredRobust'],
                'progress_all_original_caps':improved and not violations,'original_equilibrium_tol_satisfied':found}
    final={'source_workbook_sha256':prep['book_sha256'],'replay_sha256':prep['replay_sha256'],
        'native_trace_sha256':digest(NATIVE/'MVT2.csv'),'compiler':compiler,'owner':owner,'native_wall_s':wall,
        'target_Qy_kN':qtrial,'qLastAccepted_kN':qbase,'anchor_norm_MPa':anchor['norm_MPa'],'equilibrium_tolerance_MPa':tol,
        'source_anchors':anchor_report,'mixed_deferred_due_to_changed_source':defer,
        'original_effort_caps_MPa':caps,'exact_H24_rollback':True,'candidate':result,'history_published':False}
    path=HERE/'Verification.json'
    path.write_text(json.dumps(final,indent=2)+'\n',encoding='utf8')
    print(path,digest(path))


if __name__=='__main__':
    if '--inputs-only' in sys.argv:
        prepare_only()
    else:
        main()
