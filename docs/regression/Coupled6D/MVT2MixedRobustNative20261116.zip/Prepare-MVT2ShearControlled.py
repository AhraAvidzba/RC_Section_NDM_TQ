"""Freeze the current workbook, archived B fields, and diagnostic-only module."""
import argparse
import hashlib
import json
from pathlib import Path
from shutil import copyfile

HERE=Path(__file__).resolve().parent
PRIOR=Path("D:/CodexScratch/RC_Section_NDM_TQ/MVT2MinimumFields")
BOOK=Path("workbook/output/RC_Section_NDM.xlsm")
DRAFT=Path("docs/regression/Diagnostic.xlsm")
MODULE=Path("tests/modTestCoupledExperiment.bas")
BOOK_SHA="A90C7A5E610C19D2C3CF0D7DB12831651DB12EEFD052E5DBED1378EE3C2C04FA"
PREFIX_SHA="504CFF8453E317382E006F682BB3CDC5E7F61467924AE6DA394692427D20F8B8"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def main(repo, stage):
    assert digest(repo/BOOK)==BOOK_SHA
    archived=PRIOR/"MVT2ShearBReplay.csv"
    assert digest(archived)==PREFIX_SHA
    former=json.loads((PRIOR/"Preparation.json").read_text(encoding="utf-8"))
    assert digest(PRIOR/MODULE)==former["export_macro_sha256"]
    composed=((PRIOR/MODULE).read_text(encoding="utf-8-sig")+"\n"+
              (HERE/"Control.bas").read_text(encoding="utf-8")).replace("\n","\r\n").encode("utf-8")
    tools={path.relative_to(PRIOR):path for path in (PRIOR/"tools/build_workbook").iterdir() if path.is_file()}
    sources={**tools,BOOK:repo/BOOK,Path("Guard-IsolatedOffice.ps1"):PRIOR/"Guard-IsolatedOffice.ps1",Path("Replay.csv"):archived}
    for key,path in tools.items():
        assert digest(path)==former["frozen"][key.as_posix()]
    assert digest(sources[Path("Guard-IsolatedOffice.ps1")])==former["frozen"]["Guard-IsolatedOffice.ps1"]
    additional={'AnchorField.csv': '4CE78954096C3CBE96386C7509CD1F7DF2028C69B5A7DC98E162E90B446A6171', 'CandidateFields.csv': 'C61469CEAFE4BB966DDC638328D27DB70678E9E5967DBBFC76DF998DD2D95302', 'TwistFeasibility.json': '5A32D055F10B6E7B272C3D1274EE335E331BD34F7204BBD6C56F4C6745CCE380', 'PreviousNative.csv': '90C5E72021646EAB0C3E9C2A5149AFB7ED18BB66C6D25B006AA429B4BB4FCD79', 'Anchors.csv': '7A3ED1EBCCA657E538372A78BF781873AA599D30C60DF0D8DCABB3F62D3C78E2', 'MixEvidence.json': '2F7ABAA0349191A57455536713F5C752AEDC958EE2CE993F62573F4F5F466C6B'}
    assert all(digest(HERE/name)==identity for name,identity in additional.items())
    data={"prior_input_sha256":additional,"book_sha256":BOOK_SHA,"replay_sha256":PREFIX_SHA,"watchdog_seconds":200,
          "only_updated_module":"modTestCoupledExperiment",
          "sources":{key.as_posix():digest(path) for key,path in sources.items()},
          "module_sha256":hashlib.sha256(composed).hexdigest().upper(),
          "native_harness":digest(HERE/"Run-MVT2ShearControlled.ps1")}
    receipt=HERE/"Preparation.json"
    if stage:
        assert not receipt.exists() and not (HERE/DRAFT).exists()
        for key,src in sources.items():
            dest=HERE/key
            dest.parent.mkdir(parents=True,exist_ok=True)
            assert not dest.exists()
            copyfile(src,dest)
        for directory in ("tests","Temp","Native","docs/regression"):
            (HERE/directory).mkdir(parents=True,exist_ok=True)
        (HERE/MODULE).write_bytes(composed)
        copyfile(HERE/BOOK,HERE/DRAFT)
        receipt.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
    assert json.loads(receipt.read_text(encoding="utf-8"))==data
    assert (HERE/MODULE).read_bytes()==composed
    assert all(digest(HERE/name)==expected for name,expected in data["sources"].items())
    print(data["book_sha256"],digest(receipt))

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo",type=Path)
    parser.add_argument("--stage",action="store_true")
    opts=parser.parse_args()
    main(opts.repo.resolve(strict=True),opts.stage)