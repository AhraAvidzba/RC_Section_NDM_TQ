"""ДЛЯ ТЕСТОВ: фиксирует два проверенных комплекта, сохраняя байты исторической части манифеста."""
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile, ZIP_DEFLATED


def TestSeal():
    """Добавляет шесть воспроизводимых случаев, не меняя установленную книгу и результаты прошлых этапов."""
    repo = Path.cwd(); scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ'); additions = []; entries = {}; results = []
    for label, selected in (('DiagnosticsA', ('SelectorFailure', 'Centered', 'SmallProbe')),
                            ('DiagnosticsB', ('VerifiedProbe', 'Final'))):
        source = scratch/'PrincipalTransitionDiagnosticsBundle20261118'
        target = scratch/('PrincipalTransition'+label+'Bundle20261118')
        if target.exists():
            assert set(json.loads((target/'Cases.json').read_bytes())) == set(selected)
            continue
        target.mkdir()
        for file in source.rglob('*'):
            if not file.is_file(): continue
            relative = file.relative_to(source)
            if relative.parts[0] == 'Cases' and relative.parts[1] not in selected: continue
            if relative.as_posix() in ('Files.json', 'Cases.json', 'NativeProof.json', 'MechanicsProof.json'): continue
            dest = target/relative; dest.parent.mkdir(parents=True, exist_ok=True); copyfile(file, dest)
        cases = json.loads((source/'Cases.json').read_bytes())
        (target/'Cases.json').write_text(json.dumps({key: cases[key] for key in selected}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
        for name in ('NativeProof.json', 'MechanicsProof.json'):
            proof = json.loads((source/name).read_bytes()); proof['cases'] = {key: proof['cases'][key] for key in selected}
            (target/name).write_text(json.dumps(proof, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    for label in ('DiagnosticsA', 'DiagnosticsB', 'Integration'):
        root = scratch/('PrincipalTransition'+label+'Bundle20261118')
        (root/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
        files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
                 for file in root.rglob('*') if file.is_file() and
                 file.relative_to(root).as_posix() not in ('Files.json', 'NativeProof.json', 'MechanicsProof.json')}
        (root/'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
        name = 'ASDPrincipalTransition'+label+'20261118'; archive = scratch/(name+'.zip')
        with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as output:
            for file in sorted(root.rglob('*')):
                if file.is_file(): output.write(file, file.relative_to(root).as_posix())
        assert archive.stat().st_size < 100000000, (name, archive.stat().st_size)
        digest = sha256(archive.read_bytes()).hexdigest().upper()
        destination = repo/'docs/regression/Coupled6D'/(name+'.zip'); copyfile(archive, destination)
        entries[name] = digest; pins = {}
        for scope, title, marker in (
                ('native', 'NativeProof.json', 'PRINCIPAL TRANSITION NATIVE SOURCES AND NEGATIVE OUTCOMES VERIFIED'),
                ('mechanics', 'MechanicsProof.json', 'PRINCIPAL TRANSITION EQUILIBRIA HISTORY AND ONE SIDED DERIVATIVE VERIFIED; CAPACITY OPEN')):
            pins[title] = sha256((root/title).read_bytes()).hexdigest().upper()
            additions.append({'id': 'asd-principal-transition-'+label.lower()+'-'+scope, 'journal_section': 607,
                              'archive': name, 'script': 'Check-TestPrincipalTransition.py',
                              'arguments': ['--repo', '{repo}', '--root', '.', '--scope', scope, '--out', title],
                              'stdout_contains': marker, 'outputs': {title: pins[title]}, 'timeout_seconds': 300})
        results.append({'archive': name, 'bytes': archive.stat().st_size, 'sha256': digest, 'proofs': pins})
    path = repo/'docs/reports/Coupled6DEvidence.json'; raw = path.read_bytes(); text = raw.decode('utf-8').replace('\r\n', '\n')
    previous = json.loads(text); assert len(previous['archives']) == 295 and len(previous['cases']) == 317
    pos = text.index('\n  },\n  "cases": [')
    text = text[:pos]+',\n'+',\n'.join('    '+json.dumps(name)+': '+json.dumps(value) for name, value in entries.items())+text[pos:]
    pos = text.index('\n  ],\n  "frozen_repositories": {')
    text = text[:pos]+',\n'+',\n'.join('\n'.join('    '+line for line in json.dumps(case, ensure_ascii=False, indent=2).splitlines()) for case in additions)+text[pos:]
    current = json.loads(text)
    assert current['cases'][:317] == previous['cases'] and len(current['cases']) == 323
    assert all(current['archives'][key] == value for key, value in previous['archives'].items())
    path.write_bytes(text.replace('\n', '\r\n').encode())
    (repo/'tmp/PrincipalTransitionSeal.json').write_text(json.dumps(results, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(results, indent=2), flush=True)


if __name__ == '__main__': TestSeal()
