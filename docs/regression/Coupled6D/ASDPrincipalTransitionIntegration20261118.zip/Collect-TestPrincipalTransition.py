"""ДЛЯ ТЕСТОВ: сохраняет рабочий контракт материального перехода и отрицательные численные попытки."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from subprocess import check_output


def TestCollect(repo, root, scope):
    """Разделяет диагностические версии и итоговый контракт; пользовательская книга не изменяется."""
    here = Path(__file__).resolve().parent
    cases = ({'SelectorFailure': 'GeneralPrincipalTransition20261118',
              'Centered': 'GeneralPrincipalDeparture0320261118',
              'SmallProbe': 'GeneralPrincipalDeparture0520261118',
              'VerifiedProbe': 'GeneralPrincipalDeparture0720261118',
              'Final': 'GeneralPrincipalDeparture0820261118'} if scope == 'diagnostics' else
             {'Unbounded': 'GeneralPrincipalFinal20261118', 'Bounded': 'GeneralPrincipalBounded0220261118'})
    collect = run_path(str(here/'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    extra = ('Collect-TestPrincipalTransition.py', 'Check-TestPrincipalTransition.py',
             'Validate-TestNativeCorner.py', 'TestOriented148Corner.py', 'TestRefineBeforeSign.py',
             'Analyze-TestPrincipalCandidates.py', 'Stage-TestGeneralPrincipalTransition.py',
             'Stage-TestOriented148Probes.py', 'Stage-TestWorkingASD.py', 'Check-TestSignMetric.py')
    for name in extra:
        (root/name).write_bytes((here/name).read_bytes())
    if scope == 'integration':
        source = Path('D:/CodexScratch/RC_Section_NDM_TQ/GeneralPrincipalBounded20261118')
        target = root/'CompileFailure'; target.mkdir()
        for file in source.rglob('*'):
            if not file.is_file(): continue
            relative = file.relative_to(source)
            if relative.parts[0] in ('Temp', 'workbook') or file.suffix.lower() == '.xlsm': continue
            dest = target/relative; dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(file.read_bytes())
        (root/'PrincipalCandidates.json').write_bytes((here/'GeneralPrincipalCandidates.json').read_bytes())
    checkpoint = {'base': check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
                  'scope': scope, 'installed_workbook_changed': False,
                  'physical_capacity_certified': False, 'full_acceptance_completed': False}
    (root/'SourceCheckpoint.json').write_text(json.dumps(checkpoint, indent=2)+'\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root/'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('PRINCIPAL TRANSITION EVIDENCE COLLECTED', scope, len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('diagnostics', 'integration'), required=True); args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve(), args.scope)
