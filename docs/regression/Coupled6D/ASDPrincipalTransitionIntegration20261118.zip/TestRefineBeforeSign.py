"""ДЛЯ ТЕСТОВ: проверяет влияние точности последнего принятого равновесия на прохождение спектральной границы."""
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestMetric(section, a, b):
    """Вычисляет среднее тензорное скалярное произведение трёх станций с исключением служебных множителей."""
    return float(np.einsum('spi,spi,p,i->', section.b@a, section.b@b, section.weight,
                           np.array([1., 1., 1., .5, .5, .5]))/(3.*section.weight.sum()))


def TestRefine(section, history, field, load, tolerance):
    """Уточняет ту же фиксированную нагрузку от предшествующей истории; не меняет материал и не принимает пробу автоматически."""
    tangent = run_path(str(Path(__file__).with_name('TestClosedASDTangent.py')))['TestGlobalMatrix']
    field = field.copy(); log = []
    for iteration in range(32):
        data = section.TestEvaluate(field, history, load)
        log.append({'iteration': iteration, 'norm_MPa': float(data[1])})
        if data[1] <= tolerance: break
        matrix = tangent(section, field, history)[0]
        row = np.maximum(1e-30, np.max(np.abs(matrix), axis=1)); scaled = matrix/row[:, None]
        col = np.maximum(1e-30, np.max(np.abs(scaled), axis=0)); scaled /= col
        correction = np.linalg.solve(scaled, -data[0]/row)/col
        accepted = False
        for fraction in 2.**-np.arange(13):
            trial = section.TestEvaluate(field+fraction*correction, history, load)
            if trial[1] <= tolerance or trial[1] < data[1]*(1.-1e-4*fraction):
                field += fraction*correction; accepted = True; log[-1]['fraction'] = float(fraction); break
        if not accepted: break
    data = section.TestEvaluate(field, history, load)
    return field, data, {'solved': bool(data[1] <= tolerance), 'norm_MPa': float(data[1]), 'tolerance_MPa': tolerance,
                         'field': field.tolist(), 'steps': log}


def TestRestore(repo, root):
    """Восстанавливает 142 исходных состояния из переданного комплекта без зависимости от каталога первичного запуска."""
    here = Path(__file__).resolve().parent
    helper = run_path(str(here/'TestResolutionSection.py'))
    reference = run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch)
        for target, source in (('Operators.csv', 'Trace74.Operators.csv'), ('MVTGaussMixed.csv', 'Trace74.csv')):
            (scratch/target).write_bytes((root/'Reference'/source).read_bytes())
        section = helper['TestResolutionSection'](scratch, reference, True)
    lines = [line.split(';') for line in (root/'AcceptedHistory.csv').read_text().splitlines()]
    assert len(lines) == 143
    history = section.TestInitial(); fields = [np.asarray(r[3:], float) for r in lines]
    for row, field in zip(lines[:-1], fields[:-1]):
        torque, q = map(float, row[1:3]); result = section.TestEvaluate(field, history, np.array([0., -396.*q, 0., torque, 0., q]))
        history = result[4]
    torque, q = map(float, lines[-1][1:3]); load = np.array([0., -396.*q, 0., torque, 0., q])
    return section, history, fields, lines, load


def TestRun():
    """Сохраняет четыре прямых шага после отдельного уточнения 143-го поля; этот офлайн-поиск не заменяет нативный расчёт."""
    repo = Path.cwd(); here = Path(__file__).resolve().parent
    root = Path('D:/CodexScratch/RC_Section_NDM_TQ/ASDSignFinalEvidence20261118/Cases/Final')
    section, history, fields, lines, load = TestRestore(repo, root)
    q = float(lines[-1][2])
    field, refined, proof = TestRefine(section, history, fields[-1], load, 1e-9)
    proof['refinement_distance_over_original_increment'] = float(np.sqrt(TestMetric(section, field-fields[-1], field-fields[-1]) /
        TestMetric(section, fields[-1]-fields[-2], fields[-1]-fields[-2])))
    result = {'refinement': proof, 'prefix_states': 142, 'native_implementation_verified': False,
              'material_parameters_changed': False, 'physical_capacity_certified': False, 'trials': {}}
    target = here/'RefineBeforeSign20261118.json'
    if proof['solved']:
        movement = field-fields[-2]
        projection = np.einsum('spid,spi,p,i->d', section.b, section.b@movement, section.weight,
            np.array([1., 1., 1., .5, .5, .5]))/(3.*section.weight.sum())
        spacing = float(projection@movement); projection /= np.sqrt(spacing); spacing = np.sqrt(spacing)
        solve = run_path(str(here/'Solve-TestRejectedDirection.py'))['TestSolve']
        for factor in (.25, .5, 1., 2.):
            candidate = field+factor*movement; lam = (q+factor*(q-float(lines[-2][2])))/75000.
            trial = solve(section, refined[4], candidate, lam, projection, float(projection@field+factor*spacing), 'local',
                          absolute_tol=1e-9, relative_tol=0.)
            delta = np.asarray(trial['field'])-field
            trial['signed_spatial_advance'] = TestMetric(section, movement, delta)/spacing
            result['trials'][str(factor)] = trial
            target.write_bytes((json.dumps(result, indent=2, sort_keys=True)+'\n').encode())
            print('REFINED FORWARD TRIAL', factor, trial['solved'], trial['norm_MPa'], flush=True)
    target.write_bytes((json.dumps(result, indent=2, sort_keys=True)+'\n').encode())
    print('FIXED LOAD REFINEMENT', proof['solved'], proof['norm_MPa'], proof['refinement_distance_over_original_increment'], flush=True)


if __name__ == '__main__': TestRun()
