"""ДЛЯ ТЕСТОВ: сопоставляет близость простых спектральных границ с допуском равновесия."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestAnalyze(repo, root, output):
    """Не меняет материал; читает эффективные напряжения каждой последовательно принятой истории."""
    here = Path(__file__).resolve().parent
    reference = run_path(str(here/'Probe-TestASDMaterialSteps.py'))['TestInputs'](repo)[0]['default']
    cls = run_path(str(here/'TestResolutionSection.py'))['TestResolutionSection']
    metric = run_path(str(here/'TestRefineBeforeSign.py'))['TestMetric']
    read = run_path(str(here/'Validate-TestNativeCorner.py'))['TestRead']
    fields, _, loads, _ = read(root/'Reference', '', 'Trace74')
    with TemporaryDirectory() as temporary:
        temporary = Path(temporary)
        (temporary/'Operators.csv').write_bytes((root/'Reference/Trace74.Operators.csv').read_bytes())
        (temporary/'MVTGaussMixed.csv').write_bytes((root/'Reference/Trace74.csv').read_bytes())
        (temporary/'MVTGaussMixed.Tensor.csv').write_bytes((root/'Reference/Trace74.Tensor.csv').read_bytes())
        section = cls(temporary, reference, True)
    history = section.TestInitial(); records = []
    for index, (label, field) in enumerate(fields, 1):
        history = section.TestEvaluate(field, history, loads[label])[4]
        if index not in (78, 79, 110, 119, 147, 148):
            continue
        candidates = []
        for side in range(3):
            for point in range(section.TestConcreteCount):
                stress = history[1][side, point]; tensor = np.diag(stress[:3])
                for value, (i, j) in zip(stress[3:], ((0, 1), (0, 2), (1, 2))):
                    tensor[i, j] = tensor[j, i] = value
                eigen = np.linalg.eigvalsh(tensor)
                for principal in range(3):
                    if min(abs(eigen[principal]-other) for k, other in enumerate(eigen) if k != principal) < 1e-9:
                        continue
                    candidates.append((abs(float(eigen[principal])), point+1, (0, 1, -1)[side], 3-principal))
        candidates.sort()
        tolerance = float(5e-7+5e-7*np.max(np.abs((loads[label]@section.l)[:section.TestDof-4])))
        record = dict(index=index, closest=candidates[:3], equilibrium_tolerance_MPa=tolerance,
                      closest_to_tolerance=candidates[0][0]/tolerance,
                      previous_increment_RMS=float(np.sqrt(metric(section, field-fields[index-2][1], field-fields[index-2][1]))))
        records.append(record)
        print(json.dumps(record), flush=True)
    output.write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.repo.resolve(), args.root.resolve(), args.out.resolve())
