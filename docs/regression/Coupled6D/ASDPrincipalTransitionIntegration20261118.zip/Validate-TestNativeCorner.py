"""ДЛЯ ТЕСТОВ: независимо повторяет нативный спектральный угол и непрерывную последовательность после него."""
from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory

import numpy as np


def TestRead(folder, suffix, phase='ControlProbe'):
    """Читает фактические поля, шесть внешних усилий и все три станции одного нативного экспорта."""
    rows = [r.split(';') for r in (folder/(phase+suffix+'.Operators.csv')).read_text('cp1251').splitlines()]
    fields = [(r[1], np.asarray(r[2:], float)) for r in rows if r[0] == 'F']
    net = {}
    for row in rows:
        if row[0] == 'H':
            key = ((0, 1, -1).index(int(row[2])), int(row[3])-1)
            assert key not in net.setdefault(row[1], {})
            net[row[1]][key] = np.asarray(row[4:], float)
    loads, center, label = {}, {}, None
    for line in (folder/(phase+suffix+'.Tensor.csv')).read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME':
            label = row[1]; assert label not in loads
            torque, q = map(float, row[2:4])
            loads[label] = np.array([0., -396.*q, 0., torque, 0., q]); center[label] = {}
        elif row[0] == 'POINT':
            point = int(row[1])-1; assert point not in center[label]
            center[label][point] = np.asarray(row[8:], float)
    assert {r[0] for r in fields} == set(net) == set(loads) == set(center)
    return fields, net, loads, center


def TestState(section, history, field, load, net, center, strict=False):
    """Проверяет равновесие, каждое напряжение и возвращает новую историю без изменения исходной."""
    result = section.TestEvaluate(field, history, load)
    tolerance = 1e-9 if strict else float(5e-7+5e-7*np.max(np.abs((load@section.l)[:section.TestDof-4])))
    assert result[1] <= tolerance, (result[1], tolerance)
    assert len(net) == 3*section.TestPointCount and len(center) == section.TestPointCount
    net_error = max(float(np.max(np.abs(result[3][s, p]-stress))) for (s, p), stress in net.items())
    concrete = result[3][0].copy()
    concrete[section.TestConcreteCount:] = result[5][0, :, None]*section.directions-concrete[section.TestConcreteCount:]
    error = max(net_error, max(float(np.max(np.abs(concrete[p]-stress))) for p, stress in center.items()))
    assert error < 8e-7, error
    return result[4], {'norm_MPa': float(result[1]), 'tolerance_MPa': tolerance, 'native_stress_error_MPa': error}


def TestValidate(repo, root, output, phase='ControlProbe', verify_departure=True):
    """Не отождествляет законченный диагностический макрос с достижением физического предела или всех 32 шагов."""
    here = Path(__file__).resolve().parent
    replay = run_path(str(here/'TestResolutionSection.py'))['TestReplay']
    metric = run_path(str(here/'TestRefineBeforeSign.py'))['TestMetric']
    boundary = run_path(str(here/'TestOriented148Corner.py'))['TestBoundary']
    with TemporaryDirectory() as scratch:
        scratch = Path(scratch); prefix = scratch/'Prefix'; prefix.mkdir()
        for target, source in (('Operators.csv', 'Trace74.Operators.csv'), ('MVTGaussMixed.csv', 'Trace74.csv'),
                               ('MVTGaussMixed.Tensor.csv', 'Trace74.Tensor.csv')):
            (prefix/target).write_bytes((root/'Reference'/source).read_bytes())
        section, history, original = replay(repo, prefix, scratch/'Prefix.json')
        prefix_proof = json.loads((scratch/'Prefix.json').read_bytes())
    assert len(original) == 148
    log = [r.split(';') for r in (root/'Native'/(phase+'.txt')).read_text('utf-8-sig').splitlines()]
    events = {r[1]: r for r in log if r[0] == 'CORNER_STEP'}
    coordinates = {r[1]: float(r[2]) for r in log if r[0] == 'CORNER_COORDINATE'}
    departure_rows = [r for r in log if r[0] == 'CORNER_DEPARTURE']
    departure = np.asarray(departure_rows[0][2:], float) if departure_rows else None
    load_scales = [float(r[1]) for r in log if r[0] == 'CORNER_LOAD_SCALE']
    force_scale = load_scales[0] if load_scales else 75000.
    orientation = {r[1]: r for r in log if r[0] == 'CORNER_ORIENTATION'}
    assert set(events) == set(coordinates) == {'FaceReadOnly', 'Incoming', 'Outgoing'}
    assert all(r[2] == 'True' for r in events.values())
    proof = {'prefix': prefix_proof, 'states': [], 'physical_capacity_certified': False,
             'external_equilibrium_seed_used': False, 'native_phase': phase,
             'departure_verification_requested': verify_departure}
    face, net, loads, centers = TestRead(root/'Native', '.Face', phase)
    assert len(face) == 1 and face[0][0] == 'FaceReadOnly'
    label, field = face[0]
    _, record = TestState(section, history, field, loads[label], net[label], centers[label], strict=True)
    h = boundary(section, history, field)[0]
    assert abs(h) < 1e-9 and abs(h-coordinates[label]) < 2e-10
    proof['readonly_face'] = dict(record, label=label, Qy_N=float(loads[label][5]), principal_MPa=h)
    fields, net, loads, centers = TestRead(root/'Native', '', phase)
    assert [r[0] for r in fields[:2]] == ['Incoming', 'Outgoing']
    data = [r.split(';') for r in (root/'Native'/(phase+'.csv')).read_text('cp1251').splitlines()]
    projections = {r[1]: np.asarray(r[2:], float) for r in data if r[0] == 'CONTROL_PROJECTION'}
    targets = {r[1]: float(r[2]) for r in data if r[0] == 'CORNER_TARGET'}
    previous, current = original[-2][1], original[-1][1]
    original_reference = np.sqrt(metric(section, current-previous, current-previous))
    original_h = boundary(section, history, current)[0]
    origins = [float(r[1]) for r in log if r[0] == 'CORNER_ORIGIN_COORDINATE']
    if origins:
        assert len(origins) == 1 and abs(origins[0]-original_h) < 2e-10
        proof['principal_at_origin_MPa'] = original_h
    proof['design_states'] = []
    for label, field in fields:
        proposed, record = TestState(section, history, field, loads[label], net[label], centers[label], strict=(label in events))
        if label in events:
            h = boundary(section, history, field)[0]; target = float(events[label][3])
            assert abs(h-target) < 1e-9 and abs(h-coordinates[label]) < 2e-10 and h*target > 0.
            record.update(principal_MPa=h, principal_target_MPa=target)
            if origins:
                assert h*original_h > 0. if label == 'Incoming' else h*original_h < 0.
        else:
            control = abs(float(30000.*(projections[label]@field-targets[label])))
            assert control <= record['tolerance_MPa']
            record['control_error_MPa'] = control
        oriented_previous = previous
        if departure is not None and label == 'Post1': oriented_previous = current-original_reference*departure
        reference = np.sqrt(metric(section, current-oriented_previous, current-oriented_previous))
        advance = metric(section, current-oriented_previous, field-current)/reference
        assert abs(advance-float(orientation[label][3])) < 2e-12
        assert (advance > 0.) == (orientation[label][2] == 'True')
        if label.startswith('Post'): assert advance > 0.
        record.update(label=label, Qy_N=float(loads[label][5]), signed_spatial_advance=advance,
                      twist_rad_per_m=float(1000.*field[3]/section.radius))
        proof['states'].append(record)
        if (root/'Native'/(phase+'.Design'+label+'.Operators.csv')).exists():
            design, design_net, design_loads, design_centers = TestRead(root/'Native', '.Design'+label, phase)
            assert len(design) == 1 and design[0][0] == label+'Design'
            design_label, design_field = design[0]
            _, design_proof = TestState(section, history, design_field, design_loads[design_label], design_net[design_label], design_centers[design_label])
            assert abs(design_loads[design_label][5]-force_scale) < 1e-7
            first_h = boundary(section, history, current)[0]; last_h = boundary(section, history, field)[0]
            design_h = boundary(section, history, design_field)[0]
            assert min(first_h, last_h)-2e-12 <= design_h <= max(first_h, last_h)+2e-12
            design_proof.update(label=design_label, Qy_N=float(design_loads[design_label][5]), principal_MPa=design_h)
            proof['design_states'].append(design_proof)
        if label == 'Outgoing' and departure is not None:
            assert len(departure) == section.TestDof and abs(metric(section, departure, departure)-1.) < 2e-10
            tangent_field = field
            if (root/'Native'/(phase+'.Departure.Operators.csv')).exists():
                selected, selected_net, selected_loads, selected_centers = TestRead(root/'Native', '.Departure', phase)
                assert len(selected) == 1 and selected[0][0] == 'DepartureReadOnly'
                selected_label, tangent_field = selected[0]
                _, selected_proof = TestState(section, proposed, tangent_field, selected_loads[selected_label], selected_net[selected_label], selected_centers[selected_label], strict=True)
                selected_proof.update(label=selected_label, Qy_N=float(selected_loads[selected_label][5]), not_committed=True)
                proof['departure_readonly_equilibrium'] = selected_proof
            tangent_builder = run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
            native_steel = [r for r in log if r[0] == 'CORNER_STEEL_TANGENT']
            ambiguity = 0
            if native_steel:
                matrix = tangent_builder(section, tangent_field, proposed, include_steel=False)[0]
                slopes = np.empty((3, section.TestSteelCount)); seen = set()
                strains = (section.a@tangent_field).reshape(3, section.TestSteelCount)
                trial = 200000.*(strains-proposed[3])
                for row in native_steel:
                    s = (0, 1, -1).index(int(row[1])); p = int(row[2])-1-section.TestConcreteCount
                    assert (s, p) not in seen; seen.add((s, p))
                    axial, stress, slope = map(float, row[3:6]); assert slope in (0., 200000.)
                    assert abs(axial-strains[s, p]) < 1e-11
                    assert abs(stress-np.clip(trial[s, p], -section.bounds[p], section.bounds[p])) < 8e-7
                    if abs(abs(trial[s, p])-section.bounds[p]) <= 1e-8:
                        ambiguity += 1
                    else: assert slope == (200000. if abs(trial[s, p]) <= section.bounds[p] else 0.)
                    slopes[s, p] = slope
                assert len(seen) == 3*section.TestSteelCount
                matrix += (section.scatter*slopes.ravel())@section.a
            else: matrix = tangent_builder(section, tangent_field, proposed)[0]
            direction = np.array([0., -396.*force_scale, 0., 0., 0., force_scale])
            action = matrix@departure; exact = (direction@section.l)*float(departure_rows[0][1])
            error = float(np.max(np.abs(action-exact))/max(1., np.max(np.abs(action)), np.max(np.abs(exact))))
            if verify_departure: assert error < 2e-7, error
            principal_rate = float(boundary(section, proposed, tangent_field)[1]@departure)
            assert principal_rate*original_h < 0.
            proof['departure'] = {'native_matrix_direction_relative_error': error, 'principal_rate': principal_rate,
                                  'lambda_direction': float(departure_rows[0][1]), 'unit_tensor_norm': float(metric(section, departure, departure)),
                                  'steel_derivatives_at_yield_explicitly_recorded': len(native_steel),
                                  'steel_derivative_ambiguous_at_text_roundoff': ambiguity,
                                  'matrix_direction_verified': bool(error < 2e-7)}
        history = proposed; previous, current = current, field
    count, = [r for r in log if r[0] == 'CORNER_POST_COUNT']
    posts = [r for r in log if r[0] == 'CORNER_POST']
    accepted = len(fields)-2
    assert int(count[1]) == accepted and int(count[3]) == 32
    assert [r[1] for r in posts[:accepted]] == [r[0] for r in fields[2:]]
    assert all(r[2] == 'True' for r in posts[:accepted])
    design_logged = {r[1]+'Design' for r in log if r[0] == 'CORNER_DESIGN' and r[2] == 'True'}
    assert design_logged == {r['label'] for r in proof['design_states']}
    if phase in ('DesignIncoming', 'DesignOutgoing'): assert phase[6:]+'Design' in design_logged
    proof.update(accepted_post_steps=accepted, requested_post_steps=32, completed_all_requested_steps=(accepted == 32),
                 rejected_post_steps=[r[1] for r in posts if r[2] != 'True'],
                 readonly_face_not_committed=True, incoming_history_committed_before_outgoing=True)
    output.write_bytes((json.dumps(proof, indent=2, sort_keys=True)+'\n').encode())
    print('NATIVE CORNER STATES VERIFIED', len(fields), 'post_steps', accepted,
          'departure', proof.get('departure', {}).get('matrix_direction_verified'), 'capacity', False, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--phase', choices=('ControlProbe', 'DesignIncoming', 'DesignOutgoing'), default='ControlProbe')
    parser.add_argument('--states-only', action='store_true'); args = parser.parse_args()
    TestValidate(args.repo.resolve(), args.root.resolve(), args.out.resolve(), args.phase, not args.states_only)
