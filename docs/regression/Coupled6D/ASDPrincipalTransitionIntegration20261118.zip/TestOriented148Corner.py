"""ДЛЯ ТЕСТОВ: решает равновесие на спектральном событии и исследует обе односторонние касательные."""
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path

import numpy as np


def TestSolveMatrix(matrix, rhs):
    """Решает без регуляризации после положительного масштабирования строк и столбцов."""
    row = np.maximum(1e-30, np.max(np.abs(matrix), axis=1)); scaled = matrix/row[:, None]
    col = np.maximum(1e-30, np.max(np.abs(scaled), axis=0)); scaled /= col
    return np.linalg.solve(scaled, rhs/row)/col


def TestBoundary(section, history, field):
    """Читает младшее главное напряжение прогноза точки 36 на станции −1 и его точный градиент."""
    strain = section.b[2, 35]@field
    elastic = np.full((6, 6), 0.); elastic[:3, :3] = 25000./3.
    elastic[np.arange(3), np.arange(3)] += 25000.; elastic[3:, 3:] = np.eye(3)*12500.
    trial = history[1][2, 35]+elastic@(strain-history[0][2, 35])
    tensor = np.diag(trial[:3])
    for value, (i, j) in zip(trial[3:], ((0, 1), (0, 2), (1, 2))): tensor[i, j] = tensor[j, i] = value
    values, vectors = np.linalg.eigh(tensor); v = vectors[:, 0]
    projector = np.array([v[0]**2, v[1]**2, v[2]**2, 2*v[0]*v[1], 2*v[0]*v[2], 2*v[1]*v[2]])
    return float(values[0]), projector@elastic@section.b[2, 35]


def TestAugmented(section, matrix, projection):
    """Добавляет точный столбец заданной силовой траектории и одну управляющую строку."""
    n = len(matrix); augmented = np.zeros((n+1, n+1)); augmented[:n, :n] = matrix
    direction = np.array([0., -396.*75000., 0., 0., 0., 75000.])
    augmented[:n, n] = -direction@section.l; augmented[n, :n] = projection
    return augmented


def TestRun(repo, root, output):
    """Не принимает физического предела: проверяет, является ли остановка локальной односторонней особенностью выбранного управления."""
    here = Path(__file__).resolve().parent
    section, history, field, lam, projection, target = run_path(str(here/'Solve-TestRejectedDirection.py'))['TestRestore'](repo, root)
    tangent = run_path(str(here/'TestClosedASDTangent.py'))['TestGlobalMatrix']
    metric = run_path(str(here/'TestRefineBeforeSign.py'))['TestMetric']
    rows = [r.split(';') for r in (root/'Native/ControlProbe.csv').read_text('cp1251').splitlines()]
    correction, = [r for r in rows if r[0] == 'REJECTED_CORRECTION']; correction = np.asarray(correction[2:], float)
    prior_fields = [np.asarray(r.split(';')[3:], float) for r in (root/'AcceptedHistory.csv').read_text().splitlines()]
    previous_move = prior_fields[-1]-prior_fields[-2]
    low, high = 0., 1./128.
    base_h = TestBoundary(section, history, field)[0]
    assert base_h < 0. and TestBoundary(section, history, field+high*correction[:-1])[0] > 0.
    for _ in range(50):
        middle = .5*(low+high)
        if TestBoundary(section, history, field+middle*correction[:-1])[0] < 0.: low = middle
        else: high = middle
    fraction = .5*(low+high); value = field+fraction*correction[:-1]; factor = lam+fraction*correction[-1]
    constant = np.array([0., 0., 0., 10510000., 0., 0.]); direction = np.array([0., -396.*75000., 0., 0., 0., 75000.])
    logs = []; solved = False
    for iteration in range(24):
        data = section.TestEvaluate(value, history, constant+factor*direction)
        h, gradient = TestBoundary(section, history, value)
        norm = max(float(data[1]), abs(h)); logs.append({'iteration': iteration, 'norm_MPa': norm, 'principal_MPa': h})
        if norm <= 1e-9: solved = True; break
        residual = np.r_[data[0], h]
        matrix = TestAugmented(section, tangent(section, value, history)[0], gradient)
        step = TestSolveMatrix(matrix, -residual); accepted = False
        for alpha in 2.**-np.arange(17):
            candidate = value+alpha*step[:-1]; candidate_lambda = factor+alpha*step[-1]
            trial = section.TestEvaluate(candidate, history, constant+candidate_lambda*direction)
            candidate_h = TestBoundary(section, history, candidate)[0]
            trial_norm = max(float(trial[1]), abs(candidate_h))
            if trial_norm <= 1e-9 or trial_norm < norm*(1.-1e-4*alpha):
                value = candidate; factor = candidate_lambda; logs[-1]['fraction'] = float(alpha); accepted = True; break
        if not accepted: break
    data = section.TestEvaluate(value, history, constant+factor*direction); h, gradient = TestBoundary(section, history, value)
    normal = np.einsum('spid,spi,p,i->d', section.b, section.b@previous_move, section.weight,
        np.array([1., 1., 1., .5, .5, .5]))/(3.*section.weight.sum())
    length = np.sqrt(normal@previous_move); normal /= length
    result = {'base_principal_MPa': base_h, 'crossing_fraction': fraction, 'event_solved': solved,
              'event_field': value.tolist(), 'event_lambda': factor, 'event_Qy_N': 75000.*factor,
              'event_norm_MPa': float(data[1]), 'event_principal_MPa': h,
              'event_signed_advance_from_accepted': float(normal@(value-prior_fields[-1])), 'iterations': logs,
              'sides': [], 'native_implementation_verified': False, 'physical_capacity_certified': False}
    if solved:
        for gap in (1e-7, 1e-8, 1e-9):
            matrices = []
            for side in (-1, 1):
                nearby = value.copy()
                for _ in range(4):
                    z, g = TestBoundary(section, history, nearby)
                    nearby += (side*gap-z)*g/(g@g)
                matrix = TestAugmented(section, tangent(section, nearby, history)[0], normal)
                rhs = np.zeros(len(matrix)); rhs[-1] = 1.
                vector = TestSolveMatrix(matrix, rhs); h_rate = float(gradient@vector[:-1])
                row = np.maximum(1e-30, np.max(np.abs(matrix), axis=1)); scaled = matrix/row[:, None]
                col = np.maximum(1e-30, np.max(np.abs(scaled), axis=0)); scaled /= col
                sign, logdet = np.linalg.slogdet(scaled)
                matrices.append(matrix)
                result['sides'].append({'gap_MPa': gap, 'side': side, 'actual_principal_MPa': TestBoundary(section, history, nearby)[0],
                    'principal_rate_for_mechanical_forward': h_rate, 'lambda_rate_for_mechanical_forward': float(vector[-1]),
                    'determinant_sign': float(sign), 'scaled_condition': float(np.linalg.cond(scaled)),
                    'tangent': vector.tolist()})
            singular = np.linalg.svd(matrices[1]-matrices[0], compute_uv=False)
            result.setdefault('jump_singular_values', []).append({'gap_MPa': gap, 'first': float(singular[0]),
                'second_over_first': float(singular[1]/singular[0])})
    output.write_bytes((json.dumps(result, indent=2, sort_keys=True)+'\n').encode())
    print('EVENT', solved, result['event_norm_MPa'], h, result['event_Qy_N'], result['event_signed_advance_from_accepted'], flush=True)
    print('SIDES', [(r['side'], r['gap_MPa'], r['principal_rate_for_mechanical_forward'], r['determinant_sign']) for r in result['sides']], flush=True)


if __name__ == '__main__':
    from argparse import ArgumentParser
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(); TestRun(args.repo.resolve(), args.root.resolve(), args.out.resolve())
