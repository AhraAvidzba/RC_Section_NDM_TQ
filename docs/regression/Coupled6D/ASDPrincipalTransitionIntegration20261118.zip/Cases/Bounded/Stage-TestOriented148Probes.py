"""ДЛЯ ТЕСТОВ: сравнивает четыре меры на конце непрерывного ориентированного пути из 148 состояний."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestStage(repo, root):
    """Меняет только диагностическую задачу; диаграммы, равновесие, история и лимит 32 итерации сохраняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestWorkingASD.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    raw = (repo/'docs/regression/Coupled6D/ASDOrientedContinuation20261118.zip').read_bytes()
    digest = '34CA8B9813E825B9F707F8D8B17199F3C565A6D013BF4F07B1AA56FD3900FB93'
    assert sha256(raw).hexdigest().upper() == digest
    with ZipFile(BytesIO(raw)) as archive:
        for name in ('Trace74.csv', 'Trace74.Operators.csv', 'Trace74.Tensor.csv'):
            value = archive.read('Cases/Final/Native/'+name)
            (root/'Reference').mkdir(exist_ok=True)
            (root/'Reference'/name).write_bytes(value)
            prep['inputs']['Reference/'+name] = sha256(value).hexdigest().upper()
    loads, fields = {}, []
    for line in (root/'Reference/Trace74.Tensor.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'FRAME': loads[row[1]] = row[2:4]
    for line in (root/'Reference/Trace74.Operators.csv').read_text('cp1251').splitlines():
        row = line.split(';')
        if row[0] == 'F': fields.append(';'.join([row[1], *loads[row[1]], *row[2:]]))
    assert len(fields) == 148
    (root/'AcceptedHistory.csv').write_bytes(('\r\n'.join(fields)+'\r\n').encode())
    name = 'tests/modTestMVT2ProductionASDTest.bas'; full = (root/name).read_text('utf-8-sig')
    begin = full.index('Private Function RunControlProbesTest('); end = full.index('\nEnd Function', begin)+len('\nEnd Function')
    code = full[begin:end]
    old = '''            Case 1, 2
                mode = "FirstBar": consistent = True
                operators.CopySteelStrainProjection operators.ConcretePointCount + 1, projection
                ReDim Preserve projection(1 To operators.DegreeCount)
'''
    assert code.count(old) == 1; code = code.replace(old, '')
    replacements = {
        'If history.Count <> 74 Then': 'If history.Count <> 148 Then',
        'Для сравнительных проб нужны 74 принятых состояния.': 'Для сравнительных проб нужны 148 принятых состояний.',
        'For index = 1 To 6': 'For index = 1 To 16',
        'Case 3, 4\n                mode = "Automatic"': 'Case 1 To 4\n                mode = "Automatic"',
        'Case 5\n                mode = "Twist"': 'Case 5 To 8\n                mode = "Twist"',
        'Case 6\n                Dim unused()': 'Case 9 To 12\n                Dim unused()',
        'factor = 32#: If index = 1 Or index = 3 Then factor = 4#': 'factor = (1# / 64#) * 4# ^ ((index - 1) Mod 4)',
    }
    for old, new in replacements.items():
        assert code.count(old) == 1, old
        code = code.replace(old, new)
    marker = '        End Select\n        control = 0#'
    assert code.count(marker) == 1
    code = code.replace(marker, '''            Case 13 To 16
                mode = "TensorSecant"
                Dim movement() As Double: movement = current
                For i = 1 To solver.PhysicalDegreeCount: movement(i) = current(i) - previous(i): Next i
                If Not solver.SelectSpatialDirectionControl(previous, current, movement, projection, control, spacing) Then _
                    Err.Raise 5, , "Не выбрана пространственная секущая."
'''+marker)
    marker = '            solver.CopyTrial trial, actual: solver.AcceptStep'
    assert code.count(marker) == 1
    code = code.replace(marker, '''            solver.CopyTrial trial, actual
            Dim forward As Boolean, advance As Double, referenceIncrement As Double
            forward = solver.SpatialIncrementAdvances(previous, current, trial, advance, referenceIncrement)
            AddExperimentTraceTest report, tracePath, "CONTROL_ORIENTATION;" & phase & ";" & CStr(forward) & ";" & _
                ExperimentNumberTest(advance) & ";" & ExperimentNumberTest(referenceIncrement)
            solver.AcceptStep''')
    (root/name).write_bytes((full[:begin]+code+full[end:]).replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'; code = (root/runner).read_text('utf-8-sig')
    old = "'-MacroArgument1',$caseName,'-TimeoutSeconds','240'"; assert code.count(old) == 1
    code = code.replace(old, "'-MacroArgument1',$caseName,'-TimeoutSeconds','480'")
    (root/runner).write_bytes(code.encode('utf-8-sig'))
    for relative in (name, runner, 'AcceptedHistory.csv'):
        prep['inputs'][relative] = sha256((root/relative).read_bytes()).hexdigest().upper()
    script = Path(__file__); (root/script.name).write_bytes(script.read_bytes()); prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['probe_scope'] = {'prefix_states': 148, 'independent_trials': 16,
        'measures': ['Automatic', 'Twist', 'ShearY', 'TensorSecant'], 'multiples': [1./64., 1./16., .25, 1.],
        'newton_iterations_per_trial': 32, 'observation_seconds': 480, 'parent_archive_sha256': digest,
        'working_algorithm_changed': False, 'physical_capacity_certified': False}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('ORIENTED 148 PROBES READY; 16 INDEPENDENT TARGETS; ORIGINAL MATERIAL AND EQUILIBRIUM TOLERANCES')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd()); parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve())
