"""ДЛЯ ТЕСТОВ: проверяет общий рабочий API спектрального перехода без добавления методов в решатель."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, design_q=None):
    """Вызывает автоматический выбор точки по фактическому численному отказу; номера контрольного примера не задаются решателю."""
    here = Path(__file__).resolve().parent
    run_path(str(here/'Stage-TestOriented148Probes.py'))['TestStage'](repo, root)
    prep = json.loads((root/'Preparation.json').read_bytes())
    code = (here/'TestNativeCornerTrace.bas.txt').read_text('utf-8')
    if design_q is not None:
        old = 'FORCE_SCALE As Double = 75000#'; assert code.count(old) == 1 and design_q > 0.
        code = code.replace(old, 'FORCE_SCALE As Double = '+format(design_q, '.17g')+'#')
    else:
        old = ', FORCE_SCALE As Double = 75000#'; assert code.count(old) == 1
        code = code.replace(old, '''
    Dim FORCE_SCALE As Double: FORCE_SCALE = 75000#
    If Val(Environ$("NDM_MVT_FLOW_MODE")) > 0# Then FORCE_SCALE = Val(Environ$("NDM_MVT_FLOW_MODE"))''')
    begin = code.index('    Dim incomingSpacing As Double:')
    end = code.index('    movement = current\n', begin)
    replacement = '''    Dim incomingSpacing As Double: incomingSpacing = spacing
    AddExperimentTraceTest report, tracePath, "CORNER_LOAD_SCALE;" & ExperimentNumberTest(FORCE_SCALE)
    Dim testProjection() As Double, testCoordinate As Double, testSpacing As Double, controlName As String
    If Not solver.SelectTransverseDeformationControl(previous, current, direction, testProjection, testCoordinate, testSpacing, controlName) Then Err.Raise 5, , "Нет исходной автоматической меры."
    Dim solved As Boolean, target As Double, phase As String, forward As Boolean, advance As Double, referenceIncrement As Double
    solved = solver.TryDeformationStep(base, direction, testProjection, testCoordinate + testSpacing / 64#, lambda, nextLambda, ATOL, RTOL, 32)
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;initial_raw_failure;" & CStr(Not solved)
    If solved Then Err.Raise 5, , "Не воспроизведён исходный численный отказ."
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;transition_segment_available;" & CStr(solver.HasPrincipalTransitionSegment)
    Dim transition As CCoupledPrincipalTransition
    solved = solver.TryPreparePrincipalTransition(base, direction, previous, lambda, ATOL, RTOL, 3, transition, nextLambda, projection)
    If solved Then Err.Raise 5, , "Две ненулевые материальные доводки неожиданно завершены за три итерации."
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;failed_preparation_keeps_segment;" & CStr(solver.HasPrincipalTransitionSegment)
    If Not solver.HasPrincipalTransitionSegment Then Err.Raise 5, , "Неудачная доводка потеряла исходный отклонённый отрезок."
    solved = solver.TryPreparePrincipalTransition(base, direction, previous, lambda, ATOL, RTOL, 32, transition, nextLambda, projection)
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;automatic_preparation;" & CStr(solved) & ";" & solver.ResultMeta.DiagnosticDetails
    If Not solved Then Err.Raise 5, , "Не подготовлен общий материальный переход."
    AddExperimentTraceTest report, tracePath, "CORNER_STATION;" & transition.Point & ";" & transition.Side & ";" & transition.PrincipalIndex
    AddExperimentTraceTest report, tracePath, "CORNER_ORIGIN_COORDINATE;" & ExperimentNumberTest(ReadPrincipalCoordinateTest(operators, transition, current, stations))
    Dim rejected As Boolean, unusedLambda As Double, unusedProjection() As Double
    rejected = Not solver.TryCompletePrincipalTransition(transition, base, direction, lambda, 32, unusedLambda, unusedProjection)
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;outgoing_before_acceptance_rejected;" & CStr(rejected)
    If Not rejected Then Err.Raise 5, , "Исходящая сторона разрешена до принятия входящей."
    Dim facePath As String, unusedReport As String
    transition.CopyFace field, nextLambda
    phase = "FaceReadOnly": facePath = tracePath & ".Face"
    AddExperimentTraceTest report, tracePath, "CORNER_STEP;" & phase & ";True;0;" & ExperimentNumberTest(nextLambda)
    AddExperimentTraceTest report, tracePath, "CORNER_COORDINATE;" & phase & ";" & ExperimentNumberTest(ReadPrincipalCoordinateTest(operators, transition, field, stations))
    RecordGaussPointsTest section, operators, unusedReport, facePath: WriteMVT2OperatorsTest operators, facePath
    handle = FreeFile: Open facePath & ".Tensor.csv" For Output As #handle: Close #handle
    WriteMVT2ReadOnlyFrameTest operators, field, phase, TORQUE, FORCE_SCALE * nextLambda, facePath, stations
    transition.CopyIncoming field, nextLambda
    solver.CopyTrial field, actual
    For Each phaseValue In Array("Incoming", "Outgoing")
        phase = CStr(phaseValue)
        target = transition.IncomingSign * transition.PrincipalGap
        If phase = "Outgoing" Then
            target = -target
            Dim changedDirection() As Double: changedDirection = direction
            changedDirection(4) = changedDirection(4) + 1#
            rejected = Not solver.TryCompletePrincipalTransition(transition, base, changedDirection, lambda, 32, unusedLambda, unusedProjection)
            AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;changed_load_path_rejected;" & CStr(rejected)
            If Not rejected Then Err.Raise 5, , "Контекст использован при другой нагрузочной траектории."
            solved = solver.TryCompletePrincipalTransition(transition, base, direction, lambda, 32, nextLambda, projection)
            If Not solved Then Err.Raise 5, , "Не решена общая исходящая сторона."
            solver.CopyTrial field, actual
        End If
        AddExperimentTraceTest report, tracePath, "CORNER_STEP;" & phase & ";True;" & ExperimentNumberTest(target) & ";" & ExperimentNumberTest(nextLambda)
        AddExperimentTraceTest report, tracePath, "CORNER_COORDINATE;" & phase & ";" & ExperimentNumberTest(ReadPrincipalCoordinateTest(operators, transition, field, stations))
        If solver.PrincipalDesignLoadVerified Then
            Dim designField() As Double, designActual() As Double, designPath As String
            If Not solver.CopyPrincipalDesignState(designField, designActual) Then Err.Raise 5, , "Не передано проверенное заданное сочетание."
            designPath = tracePath & ".Design" & phase
            RecordGaussPointsTest section, operators, unusedReport, designPath: WriteMVT2OperatorsTest operators, designPath
            handle = FreeFile: Open designPath & ".Tensor.csv" For Output As #handle: Close #handle
            WriteMVT2ReadOnlyFrameTest operators, designField, phase & "Design", TORQUE, FORCE_SCALE, designPath, stations
            AddExperimentTraceTest report, tracePath, "CORNER_DESIGN;" & phase & ";True"
        End If
        forward = solver.SpatialIncrementAdvances(previous, current, field, advance, referenceIncrement)
        AddExperimentTraceTest report, tracePath, "CORNER_ORIENTATION;" & phase & ";" & CStr(forward) & ";" & ExperimentNumberTest(advance)
        solver.AcceptStep
        WriteMVT2FullFrameTest operators, field, phase, TORQUE, FORCE_SCALE * nextLambda, tracePath, stations
        previous = current: current = field: lambda = nextLambda
    Next phaseValue
    rejected = Not solver.TryCompletePrincipalTransition(transition, base, direction, lambda, 32, unusedLambda, unusedProjection)
    AddExperimentTraceTest report, tracePath, "CORNER_CONTRACT;consumed_context_rejected;" & CStr(rejected)
    If Not rejected Then Err.Raise 5, , "Повторно использован завершённый материальный переход."
'''
    replacement = replacement.replace('    Dim solved As Boolean,', '    Dim phaseValue As Variant\n    Dim solved As Boolean,')
    code = code[:begin]+replacement+code[end:]
    begin = code.index('    movement = current\n', code.index('CORNER_CONTRACT;consumed_context_rejected;'))
    end = code.index('    Dim increment As Double', begin)
    code = code[:begin]+'''    Dim departureLambda As Double, departureField As Variant, departurePoint() As Double, departurePointLambda As Double
    If Not solver.TryPrincipalDepartureControl(transition, lambda, movement, departureLambda, projection, coordinate, departureField, departurePointLambda) Then Err.Raise 5, , "Не подтверждена рабочая исходящая касательная."
    departurePoint = departureField
    Dim departurePath As String: departurePath = tracePath & ".Departure"
    RecordGaussPointsTest section, operators, unusedReport, departurePath: WriteMVT2OperatorsTest operators, departurePath
    handle = FreeFile: Open departurePath & ".Tensor.csv" For Output As #handle: Close #handle
    WriteMVT2ReadOnlyFrameTest operators, departurePoint, "DepartureReadOnly", TORQUE, FORCE_SCALE * departurePointLambda, departurePath, stations
    Dim departureRow As String: departureRow = "CORNER_DEPARTURE;" & ExperimentNumberTest(departureLambda)
    For i = 1 To operators.DegreeCount: departureRow = departureRow & ";" & ExperimentNumberTest(movement(i)): Next i
    AddExperimentTraceTest report, tracePath, departureRow
    Dim side As Long, point As Long, axial As Double, stressValue As Double, tangentValue As Double
    Dim stationStrain(1 To 6) As Double, stationSlope(1 To 6) As Double, steelResponse As CCoupledReinforcedResponse
    For side = -1 To 1
        Set steelResponse = stations.Item(2 * side + 4)
        For point = operators.ConcretePointCount + 1 To operators.PointCount
            operators.PointStrain point, departurePoint, stationStrain: operators.AxialGradientAtPoint point, departurePoint, stationSlope
            For i = 1 To 6: stationStrain(i) = stationStrain(i) + side * 0.001 * stationSlope(i): Next i
            steelResponse.ReadSteelBranch point, stationStrain, axial, stressValue, tangentValue
            AddExperimentTraceTest report, tracePath, "CORNER_STEEL_TANGENT;" & side & ";" & point & ";" & ExperimentNumberTest(axial) & ";" & ExperimentNumberTest(stressValue) & ";" & ExperimentNumberTest(tangentValue)
        Next point
    Next side
'''+code[end:]
    code = code.replace('If spacing <= 0# Then Err.Raise', 'If accepted = 0 Then spacing = increment\n        If spacing <= 0# Then Err.Raise')
    old = '        initial = trial\n        solved = solver.TryDeformationStep(base, direction, projection, target, lambda, nextLambda, ATOL, RTOL, 32, initialField:=initial)'
    assert code.count(old) == 1
    code = code.replace(old, '''        Dim initialLambda As Double: initialLambda = lambda
        If accepted = 0 Then
            For i = 1 To operators.DegreeCount: trial(i) = current(i) + increment * movement(i): Next i
            initialLambda = lambda + increment * departureLambda
        End If
        initial = trial
        solved = solver.TryDeformationStep(base, direction, projection, target, initialLambda, nextLambda, ATOL, RTOL, 32, initialField:=initial)''')
    old = '        forward = solver.SpatialIncrementAdvances(previous, current, field, advance, referenceIncrement)'
    assert code.count(old) == 2
    at = code.index(old, code.index('    For postStep = 1 To 32'))
    code = code[:at]+code[at:].replace(old, '''        Dim orientationPrevious() As Double: orientationPrevious = previous
        If accepted = 0 Then
            orientationPrevious = current
            For i = 1 To solver.PhysicalDegreeCount: orientationPrevious(i) = current(i) - incomingSpacing * movement(i): Next i
        End If
        forward = solver.SpatialIncrementAdvances(orientationPrevious, current, field, advance, referenceIncrement)''', 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает выбранную рабочим алгоритмом спектральную координату от текущей принятой истории без изменения пробных буферов.
Private Function ReadPrincipalCoordinateTest(ByVal operators As CCoupledElasticState, ByVal transition As CCoupledPrincipalTransition, _
        ByRef field() As Double, ByVal stations As Collection) As Double
    Dim response As CCoupledReinforcedResponse: Set response = stations.Item(2 * transition.Side + 4)
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, unused(1 To 6) As Double, value As Double, i As Long
    operators.PointStrain transition.Point, field, strain: operators.AxialGradientAtPoint transition.Point, field, slope
    For i = 1 To 6: strain(i) = strain(i) + transition.Side * 0.001 * slope(i): Next i
    If Not response.TryReadPrincipalBoundary(transition.Point, strain, transition.PrincipalIndex, value, unused, False) Then Err.Raise 5, , "Не читается выбранная спектральная координата."
    ReadPrincipalCoordinateTest = value
End Function
'''
    name = 'tests/modTestMVT2ProductionASDTest.bas'; module = (root/name).read_text('utf-8-sig')
    begin = module.index('Private Function RunControlProbesTest('); end = module.index('\nEnd Function', begin)+len('\nEnd Function')
    (root/name).write_bytes((module[:begin]+code+module[end:]).replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'; text = (root/runner).read_text('utf-8-sig')
    old = "foreach ($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv'))"; assert text.count(old) == 1
    text = text.replace(old, "foreach ($suffix in @('','.Tensor.csv','.Operators.csv','.Checkpoint.csv','.Face','.Face.Tensor.csv','.Face.Operators.csv','.Departure','.Departure.Tensor.csv','.Departure.Operators.csv','.DesignIncoming','.DesignIncoming.Tensor.csv','.DesignIncoming.Operators.csv','.DesignOutgoing','.DesignOutgoing.Tensor.csv','.DesignOutgoing.Operators.csv'))")
    text = text.replace("'ControlProbe'", "'ControlProbe','DesignIncoming','DesignOutgoing'")
    marker = '            $env:NDM_MVT_FLOW_FOLDER=$PSScriptRoot'; assert text.count(marker) == 1
    text = text.replace(marker, marker+'''
            if ($Phase -eq 'DesignIncoming') {$env:NDM_MVT_FLOW_MODE='80679.8842822088'}
            if ($Phase -eq 'DesignOutgoing') {$env:NDM_MVT_FLOW_MODE='80679.8842427794'}''')
    marker = "$caseName=if ($Phase -eq 'MVT')"; assert text.count(marker) == 1
    text = text.replace(marker, "$caseName=if ($Phase -in @('DesignIncoming','DesignOutgoing')) {'ControlProbe'} elseif ($Phase -eq 'MVT')")
    (root/runner).write_bytes(text.encode('utf-8-sig'))
    for filename in (Path(__file__).name, 'TestNativeCornerTrace.bas.txt'):
        (root/filename).write_bytes((here/filename).read_bytes())
        prep['inputs'][filename] = sha256((root/filename).read_bytes()).hexdigest().upper()
    for filename in (name, runner): prep['inputs'][filename] = sha256((root/filename).read_bytes()).hexdigest().upper()
    prep['probe_scope'] = {'working_transition_api': True, 'automatic_point_selection': True,
        'prefix_states': 148, 'external_equilibrium_seed_used': False, 'physical_capacity_certified': False,
        'design_Qy_N': design_q, 'departure_from_accepted_outgoing_tangent': True}
    (root/'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True)+'\n').encode())
    print('GENERAL WORKING PRINCIPAL TRANSITION READY; AUTOMATIC STATION; NO SOLVER INSTRUMENTATION')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__); parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True); parser.add_argument('--design-q', type=float)
    args = parser.parse_args(); TestStage(args.repo.resolve(), args.root.resolve(), args.design_q)
