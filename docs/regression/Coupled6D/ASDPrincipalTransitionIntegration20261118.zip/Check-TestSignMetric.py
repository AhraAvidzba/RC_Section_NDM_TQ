"""ДЛЯ ТЕСТОВ: независимо проверяет нативную ориентацию в метрике фактических трёх станций."""
from pathlib import Path
import numpy as np


def TestRead(operators, points, fields=None):
    """Читает числовые операторы, веса всех точек и принятую последовательность полей."""
    rows = [r.split(';') for r in operators.read_text('cp1251').splitlines()]
    data = [r.split(';') for r in points.read_text('cp1251').splitlines()]
    size, = [r for r in rows if r[0] == 'SIZE']; n, count, dx = int(size[1]), int(size[2]), float(size[-1])
    weights = np.asarray([float(r[4]) for r in data if r[0] == 'MVT_POINT'])
    values = np.asarray([[float(x) for x in r[3:]] for r in rows if r[0] == 'B']).reshape(count, n, 12).transpose(0, 2, 1)
    b = np.stack((values[:, :6], values[:, :6]+dx*values[:, 6:], values[:, :6]-dx*values[:, 6:]))
    if fields is None: fields = np.asarray([[float(x) for x in r[2:]] for r in rows if r[0] == 'F'])
    strain = np.einsum('spid,fd->fspi', b, np.diff(fields, axis=0))
    scale = np.array([1., 1., 1., .5, .5, .5])*weights[:, None]/(3.*weights.sum())
    square = np.einsum('fspi,fspi,pi->f', strain, strain, scale)
    dot = np.einsum('fspi,fspi,pi->f', strain[1:], strain[:-1], scale)
    return [{'ending_state': i+3, 'signed_advance': float(d/np.sqrt(square[i])),
             'reference_increment': float(np.sqrt(square[i])),
             'cosine': float(d/np.sqrt(square[i]*square[i+1]))} for i, d in enumerate(dot)]


def TestNative(root):
    """Повторяет все 147 нативных проверок старого пути, включая установленный обратный шаг 144."""
    rows = [r.split(';') for r in (root/'Data/DirectionSequence.csv').read_text().splitlines()]
    fields = np.asarray([r[3:] for r in rows], float)
    expected = TestRead(root/'Reference/Trace74.Operators.csv', root/'Reference/Trace74.csv', fields)
    native = [r.split(';') for r in (root/'Native/Orientation.txt').read_text('utf-8-sig').splitlines() if r.startswith('ORIENTATION;')]
    assert len(native) == len(expected) == 147
    maximum = 0.
    for row, value in zip(native, expected):
        assert int(row[1]) == value['ending_state'] and (row[2] == 'True') == (value['signed_advance'] > 0.)
        maximum = max(maximum, abs(float(row[3])-value['signed_advance']), abs(float(row[4])-value['reference_increment']))
    assert maximum < 2e-12
    assert expected[141]['ending_state'] == 144 and expected[141]['cosine'] < -.8
    return {'checks': len(expected), 'maximum_metric_error': maximum, 'records': expected,
            'physical_capacity_certified': False}
