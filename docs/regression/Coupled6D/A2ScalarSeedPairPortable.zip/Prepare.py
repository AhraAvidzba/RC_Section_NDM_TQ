"""Seal the private A2 scalar-seed fixture without launching Excel."""
from argparse import ArgumentParser
import csv
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
BOOK = Path('workbook/output/RC_Section_NDM.xlsm')
DRAFT = Path('docs/regression/Diagnostic.xlsm')
MODULE = Path('tests/modTestCoupledExperiment.bas')
HISTORICAL = 'f4741ae'
PINNED_SHA = '8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF'
SOURCE_PATHS = ('src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledElasticState.cls',
                'src/Materials/CCoupledReinforcedResponse.cls', 'src/Materials/CCoupledConcreteResponse.cls')
ARCHIVE_FILES = {
    'Native/A-1-Prefix.csv':'163205F8FD6A140FCD1E6617909100C59ED53C72F54D1920FD4935D3C19CAC6D',
    'Native/A-1-Resume.csv':'2538E9DE0FA9038F5AC8BFD1AA1AAB184837A9F57F58D32EF275E2E33BC1A231',
    'tests/modTestCoupledExperiment.bas':'256E0BC75F2F8C71ABBAAE63D152E94CA26406CFE4BEC17E62F7EC3CC211D42F',
}


def digest(value):
    data = value.read_bytes() if isinstance(value, Path) else value
    return sha256(data).hexdigest().upper()


def blob(repo, revision, name):
    return subprocess.check_output(['git', '-C', str(repo), 'cat-file', 'blob', f'{revision}:{Path(name).as_posix()}'])


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(name, content):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    return digest(path)


def replace_one(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def addon(donor, entry):
    old = 'ByVal gt As Double, ByVal gc As Double, ByVal spatialHistory As Boolean)'
    start = donor.index('Private Sub InitializeExperimentSolverTest(')
    stop = donor.index('End Sub', start)
    helper = replace_one(donor[start:stop], old, old[:-1] + ', _\n        Optional ByVal spatialMaterials As Collection = Nothing)')
    statement = '    solver.Initialize operators, center, ec, plusSide, minusSide\n'
    helper = replace_one(helper, statement, statement + '''    If Not spatialMaterials Is Nothing Then
        spatialMaterials.Add minusConcrete: spatialMaterials.Add minusSide
        spatialMaterials.Add plusConcrete: spatialMaterials.Add plusSide
    End If
''')
    combined = donor[:start] + helper + donor[stop:]
    combined = combined.rstrip() + '\n\n' + entry.rstrip() + '\n'
    assert max(map(len, combined.splitlines())) < 1024
    declarations = re.findall(r'(?im)^(?:Public|Private) (?:Function|Sub) (\w+)', combined)
    assert len(declarations) == len(set(x.casefold() for x in declarations))
    return combined.replace('\n','\r\n').encode('utf-8-sig')


def stage(repo):
    assert HERE.is_relative_to(repo / 'tmp') and not (HERE / 'Fixture.json').exists()
    donor = HERE.parent / 'a2-resume'
    for name, expected in ARCHIVE_FILES.items():
        assert digest(donor / name) == expected, name
    archived = read(donor / 'Fixture.json')
    assert digest(repo / BOOK) == digest(blob(repo, HISTORICAL, BOOK)) == archived['workbook_sha256'] == PINNED_SHA
    sources = {name: digest(blob(repo, HISTORICAL, name)) for name in SOURCE_PATHS}
    assert all(digest(blob(repo, 'HEAD', name)) == expected for name, expected in sources.items())
    frozen = {}
    for name, expected in archived['frozen'].items():
        if name.startswith('tools/') or name == 'Guard-IsolatedOffice.ps1':
            assert digest(donor / name) == expected, name
            frozen[name] = write(name, (donor / name).read_bytes())
    frozen[BOOK.as_posix()] = write(BOOK, blob(repo, HISTORICAL, BOOK))
    assert write(DRAFT, (HERE / BOOK).read_bytes()) == PINNED_SHA
    old = (donor / MODULE).read_text(encoding='utf-8-sig')
    frozen[MODULE.as_posix()] = write(MODULE, addon(old, (HERE / 'A2SeedEntry.bas.txt').read_text(encoding='utf-8-sig')))
    frozen['A2Own27.csv'] = write('A2Own27.csv', (donor / 'Native/A-1-Prefix.csv').read_bytes())
    with (donor/'Native/A-1-Resume.csv').open(encoding='cp1251', newline='') as stream:
        witness, = [r for r in csv.reader(stream, delimiter=';') if r[:2] == ['FIELD','28']]
    assert witness[3]=='LoadSecant' and witness[4]=='1.34879453312023E-02' and len(witness)==76
    frozen['Reference28.csv'] = write('Reference28.csv', (';'.join(witness)+'\n').encode('ascii'))
    for name in ('Prepare.py', 'Run-Seed.ps1', 'Verify-Seed.py', 'A2SeedEntry.bas.txt', 'README.md'):
        frozen[name] = digest(HERE / name)
    for name in ('src', 'Native', 'Temp'):
        (HERE / name).mkdir(exist_ok=True)
    fixture = {'historicalGit':HISTORICAL,'workbookSHA256':PINNED_SHA,'sectionSources':sources,
               'donorSourceFilesSHA256':ARCHIVE_FILES,'trialTwistRadM':'0.0134879453312023',
               'macroTimeoutSeconds':160,'frozen':frozen}
    write('Fixture.json', (json.dumps(fixture, indent=2)+'\n').encode('ascii'))


def check(repo):
    fixture = read(HERE / 'Fixture.json')
    assert fixture['historicalGit'] == HISTORICAL
    assert digest(blob(repo, HISTORICAL, BOOK)) == digest(HERE / BOOK) == fixture['workbookSHA256'] == PINNED_SHA
    assert digest(repo / BOOK) == PINNED_SHA
    assert all(digest(blob(repo, 'HEAD', name)) == expected for name, expected in fixture['sectionSources'].items())
    assert all(digest(HERE / name) == expected for name, expected in fixture['frozen'].items())
    assert fixture['frozen']['A2Own27.csv'] == ARCHIVE_FILES['Native/A-1-Prefix.csv']
    print('A2_SEED_FIXTURE_PASS', digest(HERE / 'Fixture.json'), fixture['frozen'][MODULE.as_posix()])


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--repo-root', type=Path, required=True)
    operation = parser.add_mutually_exclusive_group(required=True)
    operation.add_argument('--stage', action='store_true')
    operation.add_argument('--check', action='store_true')
    args = parser.parse_args()
    root = args.repo_root.resolve()
    if args.stage:
        stage(root)
    check(root)
