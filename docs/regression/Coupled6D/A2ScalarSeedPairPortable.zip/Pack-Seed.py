"""Archive the paired A2 experiment without embedding any workbook bytes."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import json

HERE = Path(__file__).resolve().parent
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
MEASURED = ('A2SeedPair.csv', 'A2SeedPair.txt', 'A2SeedPair.txt.memory.json', 'A2SeedPair.txt.Ownership.json',
            'A2SeedPair.txt.ProcessClosure.json', 'A2SeedPair.txt.RunnerCleanup.json',
            'A2SeedPair.txt.stdout.log', 'A2SeedPair.txt.stderr.log', 'Compile.log', 'CompileClosure.json', 'Timing.json')


def digest(content):
    return sha256(content).hexdigest().upper()


fixture = json.loads((HERE/'Fixture.json').read_bytes())
paths = set(fixture['frozen']) - {BOOK}
paths.update('Native/'+path for path in MEASURED)
paths.update(('Fixture.json','A2SeedVerification.json','docs/regression/CodeUpdate.json','Run.ndjson',
              'Replay-Seed.py','Pack-Seed.py','Portable-README.md'))
contents = {name:(HERE/name).read_bytes() for name in sorted(paths)}
assert all(digest(contents[name])==expected for name,expected in fixture['frozen'].items() if name!=BOOK)
assert digest(contents['A2SeedVerification.json'])=='5657630AABEF0AC4FF1EEB00C1EFC128A091583AAA0D6E340276DED500CA73C8'
assert not any(name.endswith(('.xlsm','.xlsx')) for name in paths)
manifest = {'schema':'A2ScalarSeedPair/v1','sourceWorkbookOmitted':True,
            'historicalGit':fixture['historicalGit'],'sourceWorkbookSHA256':fixture['workbookSHA256'],
            'files':{name:digest(data) for name,data in contents.items()}}
contents['Manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode('utf8')
dest=HERE/'Portable'
dest.mkdir(exist_ok=True)
archive=dest/'A2ScalarSeedPairPortable.zip'
with ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=9) as result:
    for name,data in contents.items():
        result.writestr(ZipInfo(name,(2026,11,16,0,0,0)),data,compress_type=ZIP_DEFLATED,compresslevel=9)
with ZipFile(archive) as check:
    assert check.testzip() is None and set(check.namelist())==set(contents)
print(archive,digest(archive.read_bytes()),archive.stat().st_size)
