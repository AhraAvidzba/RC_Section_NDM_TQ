"""Read and independently integrate the single isolated A2 native comparison."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import csv
import json
import math
import re

HERE = Path(__file__).resolve().parent
NATIVE = HERE / 'Native'
DEFAULT = ('DefaultCurrent', 'DefaultSecant')
RECOVERY = ('DefaultRepeat', 'ConsistentCurrent', 'ConsistentSecant')
EC = 36100.


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def csv_rows(path):
    with path.open(encoding='cp1251', newline='') as stream:
        return list(csv.reader(stream, delimiter=';'))


def peak(values):
    return max(map(abs, values))


def close(actual, expected, tolerance):
    assert abs(actual - expected) <= tolerance, (actual, expected)


def vector(row, count):
    answer = tuple(map(float, row))
    assert len(answer) == count and all(math.isfinite(x) for x in answer)
    return answer


def closure():
    fixture = read(HERE/'Fixture.json')
    metadata = read(HERE/'docs/regression/CodeUpdate.json')
    first = read(NATIVE/'CompileClosure.json')
    own = read(NATIVE/'A2SeedPair.txt.Ownership.json')
    process = read(NATIVE/'A2SeedPair.txt.ProcessClosure.json')
    timing = read(NATIVE/'Timing.json')
    report = (NATIVE/'A2SeedPair.txt').read_text(encoding='utf-8-sig')
    log = (NATIVE/'Compile.log').read_text(encoding='utf-8-sig')
    assert metadata['Compiled'] and not metadata['ProductionChanged']
    assert metadata['ProductionSHA256'] == fixture['workbookSHA256']
    assert metadata['Modules'] == ['modTestCoupledExperiment']
    assert re.findall(r'^SOURCE_SHA256: ([0-9A-F]{64})$',report,re.M) == [metadata['WorkbookSHA256']]
    assert own['VerifiedNewOwner'] and own['BeforeWorkbookOpen'] and own['SourceSHA256']==metadata['WorkbookSHA256']
    assert process['Passed'] and process['ChildHasExited'] and process['ChildExitCode']==timing['exit']==0
    assert process['Closure']['Passed'] and not process['Closure']['OrdinaryPathKilledAnything']
    last = process['Closure']['FinalState']
    assert first['State']==last['State']=='Absent' and last['PID']==own['PID']
    assert last['StartTicksUTC']==own['StartTicksUTC'] and first['PID']!=last['PID']
    assert re.findall(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$',log,re.M) == [(str(first['PID']),first['StartTicksUTC'])]
    assert 'TOTAL_A2_SEED_PAIR: passed=1; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    pre = [json.loads(line) for line in (HERE/'Run.ndjson').read_text(encoding='utf-8-sig').splitlines()]
    assert [item['phase'] for item in pre]==['PreCompileA2Seed','PreNativeA2Seed']
    for item in pre:
        assert item['ramMiB']>=6500 and item['freeCommitGiB']>=8 and item['freeC_MiB']>=80
        assert all(e['ProtectedUser'] and e['Id'] not in (first['PID'],last['PID']) for e in item['excel'])
    return {'compiledProcess':first,'nativeProcess':last,'wallSeconds':timing['wallSeconds']}


def integrated(geometry, stations):
    forces=[[] for _ in range(6)]
    for point in range(1,89):
        x,y,area,*axis = geometry[point]
        *components,_,_,rod = stations[0,point]
        if point>56:
            components = [rod*weight-value for value,weight in zip(components,axis)]
        _,_,sigma_z,_,tau_xz,tau_yz=components
        for items,value in zip(forces,(sigma_z,y*sigma_z,x*sigma_z,x*tau_yz-y*tau_xz,tau_xz,tau_yz)):
            items.append(value*area)
    return tuple(math.fsum(items) for items in forces)


def verify():
    owned = closure()
    rows = csv_rows(NATIVE/'A2SeedPair.csv')
    setup, = [row[1:] for row in rows if row[0]=='SETUP']
    tw26,tw27,target,ratio,measure,area,length,gt,gc = vector(setup,9)
    assert target==0.0134879453312023
    close(ratio,(target-tw27)/(tw27-tw26),5e-13)
    close(measure,target*length/1000.,5e-16)
    close(area,216004.,2e-7)
    close(length,407.293505963451,5e-12)
    close(gt,0.14614967887676,5e-14)
    close(gc,26.69218082075,5e-12)
    scales=(area,area*length,area*length,area*length,area,area)
    geometry={int(row[1]):vector(row[2:],9) for row in rows if row[0]=='GEOMETRY'}
    assert set(geometry)==set(range(1,89))
    prefix=csv_rows(HERE/'A2Own27.csv')
    ref, = csv_rows(HERE/'Reference28.csv')
    source_left=vector(prefix[-1][8:],60)
    source_left_forces=vector(prefix[-1][2:8],6)
    source_right=vector(ref[16:],60)
    source_right_t=float(ref[13])
    current=float(prefix[-1][5])/1e8
    secant=current+ratio*(current-float(prefix[-2][5])/1e8)
    groups=defaultdict(dict)
    stations=defaultdict(dict)
    phases=defaultdict(dict)
    for tag,*row in rows:
        if tag in ('SETUP','GEOMETRY'):
            continue
        name,*items=row
        if tag=='STATION':
            phase,side,point,*pieces=items
            key=(int(side),int(point))
            assert key not in stations[name,phase]
            stations[name,phase][key] = vector(pieces,9)
        elif tag=='COMMITTED':
            phase,*pieces=items
            assert phase not in phases[name]
            phases[name][phase]=vector(pieces,60)
        else:
            assert name not in groups[tag],(tag,name)
            groups[tag][name]=items
    cases=list(groups['STATUS'])
    assert tuple(cases) in (DEFAULT,DEFAULT+RECOVERY)
    assert set(groups['STATUS'])==set(groups['DIAGNOSTIC'])==set(groups['REPLAY'])==set(phases)
    base=stations['DefaultCurrent','Before']
    assert set(base)=={(side,point) for side in (-1,0,1) for point in range(1,89)}
    forces_left=integrated(geometry,base)
    assert peak((a-b)/s for a,b,s in zip(forces_left,source_left_forces,scales))<=5e-10
    result={}
    for name in cases:
        consistent,seed,solved,internal_status,code,lam,solve,arm=vector(groups['STATUS'][name],8)
        close(seed,secant if name.endswith('Secant') else current,8e-14)
        assert consistent==int(name.startswith('Consistent')) and solved in (0,1) and 0<=solve<=arm
        assert phases[name]['Before']==phases[name]['AfterSolve']==source_left
        assert stations[name,'Before']==stations[name,'AfterSolve']==base
        diagnostic=';'.join(groups['DIAGNOSTIC'][name])
        counters=re.match(r'^Итерации: (\d+); пробы: (\d+); невязка, МПа: ([^;]+);',diagnostic)
        assert counters,diagnostic
        iterations,evaluations=map(int,counters.groups()[:2]); native_norm=float(counters.group(3).replace(',','.'))
        assert 0<=iterations<=24 and evaluations>=1
        replay,*details=groups['REPLAY'][name]
        assert replay=='REPLAY' and all(0<=x<=5e-6 for x in vector(details,8)[:2])
        state={'consistentControl':bool(consistent),'initialTorque_kNm':seed*100.,'solved':bool(solved),
               'status':int(internal_status),'code':int(code),'iterations':iterations,'equilibriumEvaluations':evaluations,
               'solverReportedNormMPa':native_norm,'solverSeconds':solve,'armSeconds':arm,
               'exactLeftFieldAndThreeAcceptedStationHistories':True}
        if not solved:
            assert set(phases[name])=={'Before','AfterSolve'} and lam==0.
        else:
            assert lam>0
            tau,force,control,weak,gauge,steel=vector(groups['BALANCE'][name],6)
            field=vector(groups['RIGHT'][name],60)
            wrenches=vector(groups['WRENCH'][name],6)
            equations=vector(groups['WEAK'][name],60)
            expected=(0.,0.,0.,lam*1e8,0.,0.)
            close(tau,5e-7+2e-8*abs(expected[3])/scales[3],2e-19)
            close(weak,peak(equations[:56]),5e-15)
            close(gauge,EC*peak(equations[56:]),5e-15)
            close(control,(field[3]-measure)*EC,6e-12)
            close(force,peak((a-b)/s for a,b,s in zip(wrenches,expected,scales)),5e-12)
            assert abs(field[3]-measure)<=1e-11 and field[3]>source_left[3]
            assert max(force,abs(control),weak,gauge)<=tau and native_norm<=tau
            below_steel=steel<=1.
            assert ('Accepted' in phases[name])==below_steel and (name in groups['STEEL_LIMIT'])!=below_steel
            state.update({'lambda':lam,'accepted':below_steel,'trialTauMPa':tau,'steelUtilization':steel,
                          'wrenchesN_Nmm':wrenches,'maximumIndependentBalanceMPa':max(force,abs(control),weak,gauge),
                          'referenceTorqueDifference_kNm':(wrenches[3]-source_right_t)/1e6,
                          'referenceMaximumPhysicalFieldDifference':peak(a-b for a,b in zip(field[:56],source_right[:56]))})
            if below_steel:
                assert phases[name]['Accepted']==field and set(stations[name,'Accepted'])==set(base)
                wrought=integrated(geometry,stations[name,'Accepted'])
                assert peak((a-b)/s for a,b,s in zip(wrenches,wrought,scales))<=5e-10
                state['independentIntegratedWrenchesN_Nmm']=wrought
        result[name]=state
    assert (tuple(cases)==DEFAULT+RECOVERY)==all(not result[name].get('accepted',False) for name in DEFAULT)
    if 'DefaultRepeat' in result:
        ignore={'solverSeconds','armSeconds'}
        control={k:v for k,v in result['DefaultRepeat'].items() if k not in ignore}
        assert control=={k:v for k,v in result['DefaultCurrent'].items() if k not in ignore}
    pair={}
    for label,(a,b) in (('ProductionDefault',DEFAULT),('ConsistentDiagnostic',RECOVERY[1:])):
        if a in result and result[a].get('accepted') and result[b].get('accepted'):
            left,right=phases[a]['Accepted'],phases[b]['Accepted']
            first,second=stations[a,'Accepted'],stations[b,'Accepted']
            pair[label]={'exactRightField':left==right,'exactRightStationStressesAndEnergies':first==second,
                         'maxPhysicalFieldDifference':peak(x-y for x,y in zip(left[:56],right[:56])),
                         'maxAcceptedStressDifferenceMPa':max(peak(x-y for x,y in zip(first[k][:6],second[k][:6])) for k in base),
                         'maxAcceptedEnergyDifference':max(peak(x-y for x,y in zip(first[k][6:8],second[k][6:8])) for k in base)}
    path=NATIVE/'A2SeedPair.csv'
    saved={'rawSHA256':sha256(path.read_bytes()).hexdigest().upper(),'targetTwist_rad_m':target,
           'closure':owned,'arms':result,'rightStates':pair}
    target_path=HERE/'A2SeedVerification.json'
    target_path.write_text(json.dumps(saved,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print('A2_SEED_PROTOCOL_PASS',sha256(target_path.read_bytes()).hexdigest().upper(),
          {name:(data['solved'],data['iterations'],data['equilibriumEvaluations'],data['solverSeconds']) for name,data in result.items()})


if __name__=='__main__':
    verify()
