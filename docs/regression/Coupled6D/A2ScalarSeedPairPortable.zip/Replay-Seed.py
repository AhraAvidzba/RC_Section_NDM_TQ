"""Verify exact native A2 evidence and replay its independent integration."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import math
import subprocess

HERE = Path(__file__).resolve().parent
BOOK = 'workbook/output/RC_Section_NDM.xlsm'


def digest(content):
    return sha256(content).hexdigest().upper()


def compare(saved, computed):
    if isinstance(saved, dict):
        assert set(saved)==set(computed)
        for key in saved:
            compare(saved[key],computed[key])
    elif isinstance(saved, list):
        assert len(saved)==len(computed)
        for left,right in zip(saved,computed):
            compare(left,right)
    elif isinstance(saved,float):
        assert math.isclose(saved,computed,rel_tol=1e-12,abs_tol=1e-13),(saved,computed)
    else:
        assert saved==computed,(saved,computed)


def replay(repo):
    receipt=json.loads((HERE/'Manifest.json').read_bytes())
    fixture=json.loads((HERE/'Fixture.json').read_bytes())
    assert receipt['schema']=='A2ScalarSeedPair/v1' and receipt['sourceWorkbookOmitted']
    assert all(digest((HERE/name).read_bytes())==expected for name,expected in receipt['files'].items())
    assert all(receipt['files'][name]==expected for name,expected in fixture['frozen'].items() if name!=BOOK)
    reference=fixture['historicalGit']
    assert reference==receipt['historicalGit']
    expected={BOOK:fixture['workbookSHA256'],**fixture['sectionSources']}
    assert expected[BOOK]==receipt['sourceWorkbookSHA256']==fixture['frozen'][BOOK]
    for name,checksum in expected.items():
        data=subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{reference}:{name}'])
        assert digest(data)==checksum,name
    original=json.loads((HERE/'A2SeedVerification.json').read_bytes())
    source=HERE/'Verify-Seed.py'
    code=source.read_text(encoding='utf-8')
    assert code.count("HERE/'A2SeedVerification.json'")==1
    code=code.replace("HERE/'A2SeedVerification.json'","HERE/'Replay-A2SeedVerification.json'")
    namespace={'__file__':str(source),'__name__':'a2seed_replay'}
    exec(compile(code,str(source),'exec'),namespace)
    namespace['verify']()
    compare(original,json.loads((HERE/'Replay-A2SeedVerification.json').read_bytes()))
    print('A2_SCALAR_PAIR_PORTABLE_PASS')


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    replay(p.parse_args().repo_root.resolve())
