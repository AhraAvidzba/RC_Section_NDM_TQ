# Запускает один тест двух начальных множителей после выделения слота Excel.
param([string]$RepoRoot=(Join-Path $PSScriptRoot '../..'))
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath $RepoRoot).Path
$ordinaryTemp=$env:TEMP
$ordinaryTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'

Push-Location -LiteralPath $root
try {
    & python -B -X utf8 'Prepare.py' --repo-root $repo --check
    if ($LASTEXITCODE) {throw 'Контроль входов A2 не пройден.'}
    $fixture=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $protected[9552]=[long]639304334673501852
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Путь пробной книги слишком длинный.'
    }
    $private='docs/regression/Diagnostic.xlsm'
    $compileLog='Native/Compile.log'
    $report='Native/A2SeedPair.txt'
    if ((Test-Path -LiteralPath $compileLog) -or (Test-Path -LiteralPath $report) -or
        (Get-FileHash -LiteralPath $private).Hash -cne $fixture.workbookSHA256) {throw 'Нужны исходная копия и свободный каталог протоколов.'}
    Assert-IsolatedOfficeReady 'PreCompileA2Seed'
    & './tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $private -ModuleNames @('modTestCoupledExperiment') |
        Tee-Object -FilePath $compileLog
    Save-OfficeClosure $compileLog 'Native/CompileClosure.json'
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $compiled.ProductionSHA256 -cne $fixture.workbookSHA256 -or
        ($compiled.Modules -join ',') -cne 'modTestCoupledExperiment' -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $private).Hash) {throw 'Частная сборка A2 не подтверждена.'}

    Assert-IsolatedOfficeReady 'PreNativeA2Seed'
    $inputPath=Join-Path $root 'A2Own27.csv'
    $start=[DateTime]::UtcNow
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $private -ReportPath $report -Macro 'modTestCoupledExperiment.RunTestA2SeedPair' `
        -MacroArgument1 $inputPath -MacroArgument2 $fixture.trialTwistRadM -Mode No -TimeoutSeconds $fixture.macroTimeoutSeconds -FailFast
    $exit=$LASTEXITCODE
    $elapsed=([DateTime]::UtcNow-$start).TotalSeconds
    $entry=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($entry.Count -ne 1) {throw 'Нет пути к пробному протоколу A2.'}
    $parent=[IO.Path]::GetFullPath((Split-Path -Parent $entry[0].Substring('FIXTURE: '.Length)))
    if (!$parent.StartsWith($env:TEMP+'\RC_NDM_ModeSuite_',[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь следа вне частной копии.'}
    $raw=Join-Path $parent 'A2SeedPair.csv'
    if (Test-Path -LiteralPath $raw) {Copy-Item -LiteralPath $raw -Destination 'Native/A2SeedPair.csv'}
    [ordered]@{wallSeconds=$elapsed;exit=$exit}|ConvertTo-Json|Set-Content -LiteralPath 'Native/Timing.json' -Encoding utf8
    if ($exit) {throw "Нативная проба A2 завершилась с кодом $exit."}
    & python -B -X utf8 'Verify-Seed.py'
    if ($LASTEXITCODE) {throw 'Независимая проверка сравнения A2 не пройдена.'}
}
finally {
    $env:TEMP=$ordinaryTemp
    $env:TMP=$ordinaryTmp
    Pop-Location
}
