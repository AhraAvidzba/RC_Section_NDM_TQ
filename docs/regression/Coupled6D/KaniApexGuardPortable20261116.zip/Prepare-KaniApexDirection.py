"""Assemble immutable replay fixtures and overlay only the private apex class."""
from pathlib import Path
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
from shutil import copyfile
import json,math,runpy,sys
import numpy as np

here=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve(strict=True)
check="--check" in sys.argv[2:]
source="src/Materials/CCoupledConcreteResponse.cls"
app="workbook/output/RC_Section_NDM.xlsm"
draft="docs/regression/Diagnostic.xlsm"
book_sha="A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A"
source_sha="92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C"
releases=Path("D:/CodexScratch/RC_Section_NDM_TQ/ConcreteAxisReplayCRLF20261116/tools/build_workbook")
arch=repo/"docs/regression/Coupled6D"
names=("KaniPracticalProbe45Portable.zip","KaniRankOne46Portable.zip","KaniHydrostaticApex46Portable.zip")
m=runpy.run_path(str(here/"Verify-KaniApexReturn.py"))

def digest(p):
    return sha256(p.read_bytes()).hexdigest().upper()

assert digest(repo/app)==book_sha and digest(repo/source)==source_sha
overlay=(repo/source).read_text("utf-8-sig")
new_type=(here/"ApexDirectionType.bas.txt").read_text("utf-8-sig").rstrip()+"\n\n"
old=overlay
assert old.count("Private Type TConcreteHistory")==1 and old.count("    mFt = ft: mFc = fc")==1
overlay=overlay.replace("Private Type TConcreteHistory",new_type+"Private Type TConcreteHistory")
overlay=overlay.replace("Private mFt As Double,","Private mApexTensionRate As Double\nPrivate mFt As Double,")
overlay=overlay.replace("    mFt = ft: mFc = fc","    mFt = ft: mFc = fc\n    mApexTensionRate = ft * localizationLength / gt")
overlay=overlay.rstrip()+"\n\n"+(here/"ApexDirectionMethods.bas.txt").read_text("utf-8-sig").lstrip()
files={app:repo/app}
for tool in sorted(releases.iterdir()):
    if tool.is_file():
        files["tools/build_workbook/"+tool.name]=tool
for name in names:
    files["inputs/"+name]=arch/name
if '--refresh' in sys.argv[2:]:
    assert digest(here/draft)==book_sha
elif not check:
    assert not (here/draft).exists()
    for rel,src in files.items():
        dest=here/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        copyfile(src,dest)
    (here/draft).parent.mkdir(parents=True,exist_ok=True)
    copyfile(here/app,here/draft)

assert all(digest(here/k)==digest(src) for k,src in files.items())
def write(rel,bytes_):
    path=here/rel
    if check:assert path.read_bytes()==bytes_,rel
    else:path.write_bytes(bytes_)
write(source,overlay.encode("utf-8"))

a,b,meta,geom,length=m["data"](arch/names[1])
p,pflags,_,pgeom,pl=m["data"](arch/names[0])
assert np.array_equal(geom,pgeom) and length==pl
with ZipFile(arch/names[2]) as zipped:
    geometry=np.loadtxt(BytesIO(zipped.read("GeometryAndDirections.csv")),delimiter=";")
steel=np.zeros((40,6))
steel[:,:4]=geometry[144:,3:]
def concrete(a):
    result=a.copy()
    force=2e5*np.einsum("spi,pi->sp",result[:,144:,:6],steel)
    assert np.all(abs(force)<np.r_[np.full(8,442.),np.full(32,400.)])
    result[:,144:,6:]=force[:,:,None]*steel[None,:,:]-result[:,144:,6:]
    return result
fields={f"308/{k}":concrete(v) for k,v in p.items()}
fields.update({f"313/{k}":concrete(v) for k,v in a.items()})
base=fields["313/BaseAccepted"]
ktkc=np.array(meta["acceptedEnergies_byStation_SidesMinusCenterPlus"]["BaseAccepted"])
case_data=json.loads((here/"KaniApexReturnChecks.json").read_text("utf-8"))
subjects=[(side+1,point-1) for side,point in case_data["target_stations"]]
branch_map={"DeviatoricReturnOutsideBand":1,"ApexTransition":2,"Elastic":3}
cases=[]
rows=[]
def add(stage,loc,delta,expected,is_directional=False,direction=None,override_tension=None):
    baseline=base[loc]
    kt,kc=ktkc[loc]
    if override_tension is not None:
        kt=override_tension
    tension=-math.log1p(-kt)/m["tension_rate"]
    W=kc*m["fc_energy"]
    if W<=m["ascending"]:
        comp=2.*W/(m["fc0"]+math.sqrt(m["fc0"]**2+2.*m["hardening"]*W))
    else:
        comp=m["p_at_peak"]-math.log((m["fc_energy"]-W)/(m["fc_energy"]-m["ascending"]))*(m["fc_energy"]-m["ascending"])/m["FC"]
    effect=np.asarray(delta)
    target=baseline[:6]+effect
    direction=np.zeros(6) if direction is None else direction
    length=max(abs(effect))
    ref=[0.]*6
    differential=[0.]*6
    if expected:
        nom=m["matrix"](baseline[6:])
        response,ret=m["return_apex"](nom,kt,kc,target-baseline[:6])
        assert branch_map[ret["kind"]]==expected
        ref=m["vector"](response)
        if is_directional:
            dr,k=m["apex_jvp"](nom,kt,kc,target-baseline[:6],direction)
            assert branch_map[k]==expected and expected in (1,2)
            differential=m["vector"](dr)
    out_id=f"P{len(rows)+1}"
    rows.append(";".join(("R",out_id,str(expected),str(int(is_directional)),
                          *(format(x,".17g") for x in (tension,comp,*baseline,*target,*direction)))))
    cases.append(dict(key=out_id, origin=stage, side=int(loc[0])-1, point=int(loc[1])+1,
                branch=expected, derivative=is_directional, stress=list(ref), action=list(differential),
                energies=[kt,kc], delta_max=float(length)))

for section,section_data in case_data["station_probes"].items():
    archive="308" if section.startswith("KaniPractical") else "313"
    for label, values in section_data.items():
        field=fields[f"{archive}/{label}"]
        for row in values:
            side,point=row["sidePoint"]
            loc=(side+1,point-1)
            add(f"{archive}/{label}",loc,field[loc][:6]-base[loc][:6],branch_map[row["kind"]])

loc=(2,7)
for pair in case_data["smooth_tangent_actions_at_point8_side1"]:
    target=pair["target"]
    prefix="313" if not target.startswith(("Prior","TangentContrast")) else "308"
    effect=fields[f"{prefix}/{target}"][loc][:6]-base[loc][:6]
    add("ArchivedDerivative/"+target,loc,effect,branch_map[pair["kind"]],True,np.array(pair["normalized_direction"]))

# Independent tensor directions withheld from the archived mechanical direction verification.
for label in ("LoadShape00Plus","LoadShape00Minus"):
    effect=fields["313/"+label][loc][:6]-base[loc][:6]
    expect=1 if label.endswith("Plus") else 2
    for component in (0,2,3,5):
        is_axis=np.zeros(6); is_axis[component]=1.
        add(f"HeldOutAxis/{label}/{component}",loc,effect,expect,True,is_axis)

add("Fallback/Unsaturated",loc,fields["313/LoadShape00Plus"][loc][:6]-base[loc][:6],0,override_tension=0.)
add("Fallback/MixedTrial",loc,np.array([-.0003,0.,0.,0.,0.,0.]),0)
limit=(fields["313/LoadShape00Plus"][loc][:6]-base[loc][:6])*.3
nom=m["matrix"](base[loc][6:])
kt,kc=ktkc[loc]
_,info=m["return_apex"](nom,kt,kc,limit)
assert 0.<info["Ftrial"]<1.e-8*m["compression_history"](kc)[0]
add("Fallback/PositiveYieldBand",loc,limit,0)
write("PrescribedApex.csv",("\r\n".join(rows)+"\r\n").encode("ascii"))
write("ReferenceApex.json",(json.dumps(cases,separators=(",",":"),allow_nan=False)+"\n").encode("ascii"))
ids=["modTestKaniApexDirection","modTestCoupledApexActions","CCoupledConcreteResponse"]
other=["ApexDirectionType.bas.txt","ApexDirectionMethods.bas.txt","Verify-KaniApexReturn.py",
       "KaniApexReturnChecks.json","PrescribedApex.csv","ReferenceApex.json",source]
other += [f"tests/{n}.bas" for n in ids[:2]]
proof=dict(workbook_sha256=book_sha,only_updated_modules=ids,rows=len(rows),
           inputs_sha256={k:digest(here/k) for k in (*files,*other)})
write("Preparation.json",(json.dumps(proof,indent=2)+"\n").encode("ascii"))
print(digest(here/"Preparation.json"),len(rows))


