"""Verify the native private Kani apex candidate against stock and earlier data."""
from pathlib import Path
from hashlib import sha256
import argparse,collections,json,math,re,sys

here=Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_text("utf-8-sig"))
def hashfile(path):
    return sha256(path.read_bytes()).hexdigest().upper()
def gap(a,b):
    return max(abs(x-y) for x,y in zip(a,b,strict=True))
def num(values):
    data=list(map(float,values))
    assert all(map(math.isfinite,data))
    return data

def verify(repo=None, private_workbook=None):
    p=read(here/"Preparation.json")
    for key,sha in p["inputs_sha256"].items():
        if key.startswith(("tools/","workbook/","inputs/")):
            if repo is None or key.startswith("tools/"):
                continue
            root_path=(repo/"docs/regression/Coupled6D"/Path(key).name
                       if key.startswith("inputs/") else repo/key)
            assert hashfile(root_path)==sha,key
            continue
        assert hashfile(here/key)==sha,key
    book=here/"docs/regression/Diagnostic.xlsm"
    command=read(book.with_name("CodeUpdate.json"))
    assert command["Compiled"] and not command["ProductionChanged"]
    assert set(command["Modules"])==set(p["only_updated_modules"])
    assert command["ProductionSHA256"]==p["workbook_sha256"]
    private_sha=command["WorkbookSHA256"]
    assert re.fullmatch("[0-9A-F]{64}",private_sha)
    if private_workbook is not None:
        assert hashfile(private_workbook)==private_sha
    compiler=read(here/"CompileClosure.json")
    assert compiler["State"]=="Absent"
    report=here/"Native/KaniApexDirection.txt"
    raw=report.with_suffix(".csv")
    owner=read(report.with_suffix(".txt.Ownership.json"))
    exit_report=read(report.with_suffix(".txt.ProcessClosure.json"))
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"]==private_sha
    assert exit_report["Passed"] and exit_report["ChildHasExited"] and exit_report["RunnerCleanupValid"]
    assert exit_report["Closure"]["FinalState"]["State"]=="Absent"
    own=exit_report["Closure"]["FinalState"]
    assert [owner[k] for k in ("PID","StartTicksUTC")]==[own[k] for k in ("PID","StartTicksUTC")]
    duration=read(here/"Native/RunReceipt.json")
    expected=read(here/"ReferenceApex.json")
    old=read(here/"KaniApexReturnChecks.json")
    source={}
    for filename,tags in old["station_probes"].items():
        prefix="308" if filename.startswith("KaniPractical") else "313"
        for label,stations in tags.items():
            for row in stations:
                source[(prefix+"/"+label,*row["sidePoint"])]=row

    current=[]
    for i,(line,ref,fixture) in enumerate(zip(raw.read_text("cp1251").splitlines(),expected,
            (here/"PrescribedApex.csv").read_text("ascii").splitlines(),strict=True),1):
        t,key,branch,supported,stock,plastic,steps,derivative,kt,kc,trialF,*tensors=line.split(";")
        assert t=="APEX" and key==ref["key"]==f"P{i}"
        got_branch,supported,stock,plastic,steps,derivative=map(int,(branch,supported,stock,plastic,steps,derivative))
        stress_stock,stress_new,analytic,finite,finite_half=(num(tensors[j:j+6]) for j in (0,6,12,18,24))
        assert len(tensors)==30
        assert gap(num((kt,kc)),ref["energies"])<1e-14
        row={k:ref[k] for k in ("key","origin","side","point")}
        row.update(branch=got_branch,expected_branch=ref["branch"],supported=supported,
                   native_stock_success=stock,native_plastic=plastic,substeps=steps,jvp_supported=derivative,
                   trial_yield_value_MPa=float(trialF))
        if ref["branch"]:
            row["max_candidate_vs_stock_MPa"]=gap(stress_new,stress_stock)
            row["max_candidate_vs_independent_MPa"]=gap(stress_new,ref["stress"])
            row["max_stock_vs_independent_MPa"]=gap(stress_stock,ref["stress"])
            if ref["origin"].startswith(("308/","313/")):
                archived=source[(ref["origin"],ref["side"],ref["point"])]
                base=num(fixture.split(";")[12:18])
                original=[x+y for x,y in zip(base,archived["native_increment_MPa"],strict=True)]
                row["max_candidate_vs_archived_native_MPa"]=gap(stress_new,original)
            if ref["derivative"]:
                row.update(action=analytic,central_stock=finite,central_stock_half=finite_half,
                           max_JVP_vs_independent_MPa_per_strain=gap(analytic,ref["action"]),
                           max_JVP_vs_native_central_MPa_per_strain=gap(analytic,finite),
                           max_JVP_vs_native_central_half_MPa_per_strain=gap(analytic,finite_half))
        row["contract_match"]=(got_branch==ref["branch"] and supported==bool(ref["branch"]) and
            stock==1 and derivative==ref["derivative"] and (not ref["branch"] or plastic==(ref["branch"] in (1,2))))
        current.append(row)

    assert len(current)==p["rows"]==2761
    boundary=next(r for r in current if r["origin"]=="Fallback/PositiveYieldBand")
    assert 0.<boundary["trial_yield_value_MPa"]<1.7e-7 and boundary["branch"]==0
    summary=collections.Counter(str(r["branch"]) for r in current)
    maxima={}
    keys=(
        "max_candidate_vs_stock_MPa","max_candidate_vs_independent_MPa","max_stock_vs_independent_MPa",
        "max_candidate_vs_archived_native_MPa",
        "max_JVP_vs_independent_MPa_per_strain","max_JVP_vs_native_central_MPa_per_strain","max_JVP_vs_native_central_half_MPa_per_strain",
    )
    for k in keys:
        full=[r for r in current if k in r]
        maxima[k]=None if not full else max(full,key=lambda r:r[k])[k]
    macro=report.read_text("utf-8-sig")
    match=re.search(r"^TOTAL_KANI_APEX_DIRECTION: passed=(\d+); failed=(\d+)$",macro,re.M)
    assert match and sum(map(int,match.groups()))==p["rows"]
    fail=[r for r in current if not r["contract_match"]]
    checked=not fail
    if checked:
        assert maxima["max_candidate_vs_independent_MPa"]<1e-10
        assert maxima["max_candidate_vs_archived_native_MPa"]<1e-10
        assert maxima["max_JVP_vs_independent_MPa_per_strain"]<.025
        assert maxima["max_JVP_vs_native_central_half_MPa_per_strain"]<.05
        for row in current:
            key="max_JVP_vs_native_central_MPa_per_strain"
            if row.get(key,0.)>.05:
                assert row["max_JVP_vs_native_central_half_MPa_per_strain"]<.5*row[key]
    return dict(verified_contract=checked,total=len(current),branches=dict(summary),maxima=maxima,failures=fail,
        source_book_sha256=p["workbook_sha256"],private_book_sha256=private_sha,raw_sha256=hashfile(raw),
        compiler_closure=compiler,runner_closure=own,runtime_s=duration["wall_seconds"],native_exit=duration["exit"],
        modified_modules=command["Modules"],checks=current)

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output",type=Path,nargs="?",default=here/"NativeApexDirectionChecks.json")
    parser.add_argument("--repo-root",type=Path)
    parser.add_argument("--private-workbook",type=Path)
    args=parser.parse_args()
    out=args.output
    evidence=verify(args.repo_root,args.private_workbook)
    out.write_text(json.dumps(evidence,indent=2,allow_nan=False)+"\n","utf-8")
    print(hashfile(out))
    print(json.dumps({k:v for k,v in evidence.items() if k!="checks"},ensure_ascii=False))

