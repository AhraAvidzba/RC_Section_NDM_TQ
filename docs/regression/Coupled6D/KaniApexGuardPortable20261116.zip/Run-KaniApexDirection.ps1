# Запускает одну ограниченную материальную проверку на отдельном Excel.
param([switch]$CompiledOnly)
$ErrorActionPreference='Stop'
$repo=(Get-Location).Path
$root=$PSScriptRoot
$oldTemp=$env:TEMP;$oldTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$report='Native/KaniApexDirection.txt'

& python -B -X utf8 (Join-Path $root 'Prepare-KaniApexDirection.py') $repo --check
if ($LASTEXITCODE) {throw 'Изменились исходные входы проверки.'}
Push-Location -LiteralPath $root
try {
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw|ConvertFrom-Json
    [void][IO.Directory]::CreateDirectory((Join-Path $root 'Native'))
    if (Test-Path -LiteralPath $report) {throw 'Сохранён предшествующий нативный протокол.'}
    $temp=Join-Path $root 'Temp'
    [void][IO.Directory]::CreateDirectory($temp)
    $temp=(Resolve-Path -LiteralPath $temp).Path
    if ((Join-Path $temp 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {throw 'Длинный путь Excel.'}
    $env:TEMP=$temp;$env:TMP=$temp
    if (!$CompiledOnly) {
        if (Test-Path -LiteralPath 'Compile.log') {throw 'Сохранён предшествующий протокол компиляции.'}
        if ((Get-FileHash -LiteralPath $draft).Hash -cne $prep.workbook_sha256) {throw 'Исходная копия изменилась.'}
        Assert-IsolatedOfficeReady 'PreAxisReplayCompile'
        & (Join-Path $root 'tools/build_workbook/Update-IsolatedOptimizerCode.ps1') -WorkbookPath $draft `
            -ModuleNames @($prep.only_updated_modules) | Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $receipt=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw|ConvertFrom-Json
    $closed=Get-Content -LiteralPath 'CompileClosure.json' -Raw|ConvertFrom-Json
    if (!$receipt.Compiled -or $receipt.ProductionChanged -or $receipt.ProductionSHA256 -cne $prep.workbook_sha256 -or
        $receipt.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or (($receipt.Modules|Sort-Object) -join ',') -cne
        (($prep.only_updated_modules|Sort-Object) -join ',') -or $closed.State -cne 'Absent') {throw 'Квитанция компиляции не соответствует подготовке.'}
    Assert-IsolatedOfficeReady 'BeforeKaniApexDirection'
    $clock=[Diagnostics.Stopwatch]::StartNew()
    & $legacy -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools/build_workbook/Run-Audit03Watchdog.ps1') `
        -SourceWorkbook $draft -ReportPath $report -Macro 'modTestKaniApexDirection.RunTestKaniApexDirection' `
        -MacroArgument1 (Join-Path $root 'PrescribedApex.csv') -MacroArgument2 ([string]$prep.rows) -TimeoutSeconds 240 -FailFast
    $nativeCode=$LASTEXITCODE
    $clock.Stop()
    $log=@(Get-Content -LiteralPath $report -Encoding utf8|Where-Object {$_ -like 'FIXTURE: *'})
    if ($log.Count -eq 1) {
        $folder=Split-Path -Parent $log[0].Substring('FIXTURE: '.Length)
        if (!$folder.StartsWith($temp+'\',[StringComparison]::OrdinalIgnoreCase) -or
            !(Split-Path -Leaf $folder).StartsWith('RC_NDM_ModeSuite_',[StringComparison]::Ordinal)) {throw 'Файл испытания вне частного каталога.'}
        $trace=Join-Path $folder 'KaniApexDirection.csv'
        if (Test-Path -LiteralPath $trace) { Copy-Item -LiteralPath $trace -Destination 'Native/KaniApexDirection.csv' }
    }
    $closure=Get-Content -LiteralPath "$report.ProcessClosure.json" -Raw|ConvertFrom-Json
    [ordered]@{exit=$nativeCode;wall_seconds=$clock.Elapsed.TotalSeconds;closure_stage=$closure.Stage}|
        ConvertTo-Json|Set-Content -LiteralPath 'Native/RunReceipt.json' -Encoding utf8
    if ($nativeCode -ne 0) { throw 'Материальная проверка оставила зафиксированный отказ. См. Native/KaniApexDirection.txt и CSV.' }
    if (!$closure.Passed -or $closure.Closure.FinalState.State -cne 'Absent') {throw 'Закрытие Excel не подтверждено.'}
}
finally {
    $env:TEMP=$oldTemp;$env:TMP=$oldTmp
    Pop-Location
}


