Attribute VB_Name = "modTestKaniApexDirection"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет частный возврат и его касательную на восстановленных архивных историях.
Public Function RunTestKaniApexDirection(ByVal source As String, ByVal rowsText As String) As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется частная книга проверки."
    Dim output As String: output = ThisWorkbook.Path & "\KaniApexDirection.csv"
    If Len(Dir$(output)) > 0 Then Err.Raise 5, , "Протокол уже существует."
    Dim inputFile As Integer, outputFile As Integer
    inputFile = FreeFile: Open source For Input Access Read As #inputFile
    outputFile = FreeFile: Open output For Output Access Write As #outputFile
    Dim concrete As New CCoupledConcreteResponse, gt As Double
    gt = 0.073 * 28.2 ^ 0.18
    concrete.Initialize 1, 25600#, 0.2, 0.6 * 28.2, 28.2, 1.75, 0.0022, gt, (28.2 / 1.75) ^ 2 * gt, 125#
    Dim stepText As String, fields() As String, row As String, label As String
    Dim passed As Long, failedCount As Long, i As Long, actualBranch As Long, expectedBranch As Long, substeps As Long
    Dim nativeOK As Boolean, trialOK As Boolean, derivativeOK As Boolean, plastic As Boolean, needDirection As Boolean
    Dim tension As Double, compression As Double, tensionEnd As Double, compressionEnd As Double
    Dim yieldTest As Double, yieldGradient() As Double
    Dim strain0(1 To 6) As Double, stress0(1 To 6) As Double, trial(1 To 6) As Double, direction(1 To 6) As Double
    Dim stock(1 To 6) As Double, candidate(1 To 6) As Double, analytic(1 To 6) As Double
    Dim finite(1 To 6) As Double, finiteHalf(1 To 6) As Double
    Do Until EOF(inputFile)
        Line Input #inputFile, stepText
        fields = Split(stepText, ";")
        If UBound(fields) <> 29 Then Err.Raise 5, , "Неверная длина входной строки."
        label = fields(1): expectedBranch = CLng(Val(fields(2))): needDirection = (Val(fields(3)) = 1#)
        actualBranch = 0: substeps = 0: plastic = False: derivativeOK = False
        For i = 1 To 6
            strain0(i) = Val(fields(5 + i)): stress0(i) = Val(fields(11 + i))
            trial(i) = Val(fields(17 + i)): direction(i) = Val(fields(23 + i))
            stock(i) = 0#: candidate(i) = 0#: analytic(i) = 0#: finite(i) = 0#: finiteHalf(i) = 0#
        Next i
        concrete.TestSeedApexHistory 1, strain0, stress0, Val(fields(4)), Val(fields(5))
        concrete.AcceptedPointDamage 1, tension, compression
        If Not concrete.TryReadTrialYield(1, trial, yieldTest, yieldGradient, False) Then _
            Err.Raise 5, , "Невозможно прочитать поверхность текучести контрольной пробы."
        nativeOK = concrete.TestReadStockApex(1, trial, stock, plastic, substeps)
        trialOK = concrete.TryEvaluateApexStress(1, trial, candidate, actualBranch)
        If needDirection Then
            derivativeOK = concrete.TryEvaluateApexDirection(1, trial, direction, analytic)
            If Not TestStockApexFinite(concrete, trial, direction, 0.00000000000025, finite) Then derivativeOK = False
            If Not TestStockApexFinite(concrete, trial, direction, 0.000000000000125, finiteHalf) Then derivativeOK = False
        End If
        concrete.AcceptedPointDamage 1, tensionEnd, compressionEnd
        If tension <> tensionEnd Or compression <> compressionEnd Then Err.Raise 5, , "Проба изменила принятую историю."
        row = "APEX;" & label & ";" & CStr(actualBranch) & ";" & CStr(Abs(CLng(trialOK))) & ";" & _
            CStr(Abs(CLng(nativeOK))) & ";" & CStr(Abs(CLng(plastic))) & ";" & CStr(substeps) & ";" & _
            CStr(Abs(CLng(derivativeOK))) & ";" & Trim$(Str$(tension)) & ";" & Trim$(Str$(compression)) & ";" & Trim$(Str$(yieldTest))
        For i = 1 To 6: row = row & ";" & Trim$(Str$(stock(i))): Next i
        For i = 1 To 6: row = row & ";" & Trim$(Str$(candidate(i))): Next i
        For i = 1 To 6: row = row & ";" & Trim$(Str$(analytic(i))): Next i
        For i = 1 To 6: row = row & ";" & Trim$(Str$(finite(i))): Next i
        For i = 1 To 6: row = row & ";" & Trim$(Str$(finiteHalf(i))): Next i
        Print #outputFile, row
        If actualBranch = expectedBranch And trialOK = (expectedBranch <> 0) And nativeOK And _
                derivativeOK = needDirection Then
            passed = passed + 1
        Else
            failedCount = failedCount + 1
        End If
    Loop
    If passed + failedCount <> CLng(Val(rowsText)) Then Err.Raise 5, , "Прочитан неполный архив проб."
    Close #inputFile, #outputFile
    RunTestKaniApexDirection = "TOTAL_KANI_APEX_DIRECTION: passed=" & CStr(passed) & "; failed=" & CStr(failedCount)
    Exit Function
Failed:
    Dim detail As String: detail = Err.Source & " " & Err.Description
    On Error Resume Next
    If inputFile > 0 Then Close #inputFile
    If outputFile > 0 Then Close #outputFile
    RunTestKaniApexDirection = "RUNTIME ERROR: " & detail
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает центральное действие штатного материала внутри выбранной ветви.
Private Function TestStockApexFinite(ByVal concrete As CCoupledConcreteResponse, ByRef trial() As Double, _
        ByRef direction() As Double, ByVal h As Double, ByRef finite() As Double) As Boolean
    Dim probe(1 To 6) As Double, minus(1 To 6) As Double, plus(1 To 6) As Double
    Dim i As Long, flagMinus As Boolean, flagPlus As Boolean, countMinus As Long, countPlus As Long
    For i = 1 To 6: probe(i) = trial(i) - H * direction(i): Next i
    If Not concrete.TestReadStockApex(1, probe, minus, flagMinus, countMinus) Then Exit Function
    For i = 1 To 6: probe(i) = trial(i) + H * direction(i): Next i
    If Not concrete.TestReadStockApex(1, probe, plus, flagPlus, countPlus) Then Exit Function
    If flagMinus <> flagPlus Or countMinus <> countPlus Then Exit Function
    For i = 1 To 6: finite(i) = (plus(i) - minus(i)) / (2# * H): Next i
    TestStockApexFinite = True
End Function

