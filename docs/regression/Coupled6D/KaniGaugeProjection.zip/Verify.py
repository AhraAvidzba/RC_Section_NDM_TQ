"""Independent point-tensor replay for the fixed-displacement Kani gauge correction."""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from scipy.interpolate import BSpline
from scipy.optimize import linprog

ROOT=Path(__file__).resolve().parent
META=json.loads((ROOT/"Sources.json").read_text(encoding="utf-8"))
DATA=ROOT/"Samples.npz"
assert sha256(DATA.read_bytes()).hexdigest().upper()==META["samples_SHA256"]

def peak(a):
    return float(np.max(np.abs(a)))

def operators(geometry, L):
    x,y,area=geometry.T
    normalized=area/(305.*610.)
    gx_knots=np.array([-152.5]*4+[0.]+[152.5]*4)
    gy_knots=np.array([-305.]*4+[0.]+[305.]*4)
    basis=np.eye(5)
    spline_x=BSpline(gx_knots,basis,3,extrapolate=False)
    spline_y=BSpline(gy_knots,basis,3,extrapolate=False)
    nx,ny=spline_x(x),spline_y(y)
    dx,dy=spline_x.derivative()(x),spline_y.derivative()(y)
    def pair(a,b):
        return (a[:,:,None]*b[:,None,:]).reshape((len(x),25))
    shape=pair(ny,nx)
    slope_x=L*pair(ny,dx)
    slope_y=L*pair(dy,nx)
    h=np.zeros((184,6,79))
    u=slice(4,79,3)
    v=slice(5,79,3)
    w=slice(6,79,3)
    h[:,2,0]=1.
    h[:,2,1]=y/L
    h[:,2,2]=x/L
    h[:,4,3]=-y/L
    h[:,5,3]=x/L
    h[:,0,u]=slope_x
    h[:,1,v]=slope_y
    h[:,3,u]=slope_y
    h[:,3,v]=slope_x
    h[:,4,w]=slope_x
    h[:,5,w]=slope_y
    c=np.zeros((4,79))
    concrete=slice(144)
    shape_weight=shape[concrete]*normalized[concrete,None]
    c[0,u]=c[1,v]=c[2,w]=shape_weight.sum(axis=0)
    c[3,u]=(-y[concrete,None]/L*shape_weight).sum(axis=0)
    c[3,v]=(x[concrete,None]/L*shape_weight).sum(axis=0)
    resultants=np.zeros((184,6,6))
    resultants[:,0,2]=1.
    resultants[:,1,2]=y
    resultants[:,2,2]=x
    resultants[:,3,4]=-y
    resultants[:,3,5]=x
    resultants[:,4,4]=1.
    resultants[:,5,5]=1.
    scales=305.*610.*np.array([1.,L,L,L,1.,1.])
    return h, shape, c, resultants, normalized, scales

def minimax(a,b):
    active=b>0.
    weights=b[active]
    r=a[active]
    assert len(weights)==25
    pair=r[:,None]*weights[None,:]-weights[:,None]*r[None,:]
    bound=float(np.max(np.abs(pair)/(weights[:,None]+weights[None,:])))
    lo=float(np.max((-bound-r)/weights))
    hi=float(np.min((bound-r)/weights))
    assert lo<=hi+2e-18
    delta=.5*(lo+hi)
    observed=peak(a+b*delta)
    assert abs(observed-max(bound,peak(a[~active])))<3e-19
    return delta,observed

def verify():
    with np.load(DATA,allow_pickle=False) as d:
        geometry,L=d["section"],float(d["reference_length"])
        h, shape, c, qmat, weights, scales=operators(geometry,L)
        weak_scale=np.zeros((89,4))
        weak_scale[:79]=c.T
        row_scale=np.max(np.abs(weak_scale),axis=0)
        normalized=weak_scale/row_scale
        inequalities=np.c_[np.r_[normalized,-normalized],-np.ones(178)]
        objective=np.r_[np.zeros(4),1.]
        tau=META["OriginalToleranceMPa"]
        out={}
        for name, field, stations, native, native_w in zip(d["cases"],d["field"],d["station"],d["native_meta"],d["native_weak"],strict=True):
            lam, target,*q=field
            q=np.array(q)
            coord=q[:79]
            depth_var=q[79:83]
            mu=q[83:]
            assert abs(native[0]-target)<1e-17 and lam==native[1]
            strain=h@coord
            slope=h[:,:,:4]@depth_var
            strain3=np.array([strain+i*.001*slope for i in (-1,0,1)])
            assert peak(strain3-stations[:,:,:6])<2e-12
            center=stations[1,:,6:]
            gradient=(stations[2,:,6:]-stations[0,:,6:])/.002
            eq=np.einsum("nij,ni,n->j",h,center,weights)
            eq[4:]-=np.einsum("nk,na,n->ka",shape,gradient[:,[4,5,2]],weights).ravel()
            eq+=c.T@mu
            long_eq=np.einsum("nij,ni,n->j",h[:,:,:4],gradient,weights)
            long_eq[1]-=1e5*lam/scales[0]
            gauge=c@coord
            assert peak(np.r_[eq,long_eq,gauge]-native_w)<2e-10
            force=np.einsum("nij,nj,n->i",qmat,center,geometry[:,2])
            assert peak((force-native[6:])/scales)<2e-10
            relative=(force-np.r_[np.zeros(5),1e5*lam])/scales
            r=np.r_[eq,long_eq,relative]
            gamma=float(weights[:144]@strain[:144,5])
            assert abs(gamma-target)*25600.<tau and peak(gauge)*25600.<tau
            assert abs(peak(r)-native[2])<2e-10
            scalar,norm=minimax(r,weak_scale[:,2])
            b=np.r_[-r,r]/tau
            lp=linprog(objective,inequalities,b,bounds=[(None,None)]*4+[(0,None)],method="highs",
                       options={"primal_feasibility_tolerance":1e-10,"dual_feasibility_tolerance":1e-10})
            assert lp.success
            assert abs(b@lp.ineqlin.marginals-lp.fun)<2e-9
            assert peak(objective-inequalities.T@lp.ineqlin.marginals-lp.lower.marginals)<2e-9
            assert abs(norm-lp.fun*tau)<2e-13
            out[str(name)]={"BeforeMPa":peak(r),"WarpOnlyMPa":norm,"FullLinearProjectionMPa":float(lp.fun*tau),
                     "DeltaWarpMultiplierMPa":float(scalar),"AdmissibleOnRecordedTensors":bool(norm<=tau)}
    print(json.dumps({"OriginalToleranceMPa":tau,"Results":out},indent=2))
if __name__=="__main__":
    verify()
