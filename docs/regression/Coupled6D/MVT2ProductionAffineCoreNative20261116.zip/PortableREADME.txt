Native production-core shape for explicit affine MVT2 recovery

From the extracted directory with Python 3.10 or later run
    python -B -X utf8 ReplayPortable.py PATH/MVT2AutomaticBoundedBranchRecoveryNative20261116.zip PATH/MVT2StockBranchArcNative20261116.zip

Both source archives are tracked under docs/regression/Coupled6D. The detached
replay requires neither workbook bytes nor Excel. It verifies pinned source
compilation, process identity, closure and original exact H24 station history.
It reproduces the original failed comparison before applying the detached
correction. The original source, input seal and original failure are preserved.

The comparison that failed at line 179 was a tuple versus JSON list check.
The detached script converts only the reference container to a tuple. Exact
equality remains required for all 56 values, with no tolerance change. The
independent byte comparison also confirms all 60 field coordinates and Qy,
all 135 station rows, 60 steel rows, native residual/force records, and actual
solver-reported force integrals match the prior successful fallback exactly.

FixedBefore and FixedAfter return identical confirmed original fixed-measure
states at H24. BoundedOne is intentionally NumFail with one recovery iteration
remaining. The Affine arm returns the original equilibrium Qy=18.5708039839326
kN, max residual 8.41043674e-7 MPa against the original 1.12175859e-6 MPa.
All four arms preserve the exact material history. This is a private validated
solver demonstration. No main workbook or capacity trajectory was modified.
