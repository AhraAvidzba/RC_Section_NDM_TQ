"""Pack the detached production-core proof while preserving both original traces."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import ReplayPortable as replay


HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[2] / "docs/regression/Coupled6D"
SOURCES = {"automatic": REGRESSION / "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip",
           "stock": REGRESSION / "MVT2StockBranchArcNative20261116.zip"}
RESULT = HERE / "MVT2ProductionAffineCoreNative20261116.zip"


def write(files, dependencies):
    manifest = {"files": {name: replay.digest(raw) for name, raw in sorted(files.items())}, "dependencies": dependencies,
                "source_archives": replay.SOURCES, "omitted_workbook_sha256": replay.WORKBOOK}
    items = {**files, "PortableManifest.json": (json.dumps(manifest, indent=2) + "\n").encode()}
    assert all(not name.casefold().endswith(".xlsm") for name in (*items, *dependencies))
    with ZipFile(RESULT, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(items.items()):
            member = ZipInfo(name)
            member.compress_type = ZIP_DEFLATED
            archive.writestr(member, raw)


def detached(*extra):
    with TemporaryDirectory(dir=HERE / "Temp") as folder, ZipFile(RESULT) as archive:
        assert archive.testzip() is None
        archive.extractall(folder)
        subprocess.run([sys.executable, "-B", "-X", "utf8", "ReplayPortable.py", *map(str, SOURCES.values()), *extra],
                       cwd=folder, check=True)


def main():
    prep = json.loads((HERE / "Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK] == prep["book_sha256"] == replay.WORKBOOK
    assert replay.digest((HERE / "NativeCompare/MVT2.csv").read_bytes()) == replay.RAW
    failure = subprocess.run([sys.executable, "-B", "-X", "utf8", "Verify-MVT2ShearControlled.py", "--phase", "Compare"],
                             cwd=HERE, capture_output=True)
    assert failure.returncode and replay.BAD.strip().encode() in failure.stderr
    by_hash = {}
    for key, path in SOURCES.items():
        assert replay.digest(path.read_bytes()) == replay.SOURCES[key]
        with ZipFile(path) as archive:
            for name in archive.namelist():
                by_hash.setdefault(replay.digest(archive.read(name)), (key, name))
    files, deps = {"OriginalVerifierFailure.txt": failure.stdout + failure.stderr}, {}
    for name, expected in prep["inputs"].items():
        if name == replay.BOOK:
            continue
        raw = (HERE / name).read_bytes()
        assert replay.digest(raw) == expected, name
        if expected in by_hash:
            deps[name] = (*by_hash[expected], expected)
        else:
            files[name] = raw
    receipts = ("Preparation.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json",
                "ReplayPortable.py", "PackProof.py", "PortableREADME.txt")
    native = tuple(f"NativeCompare/{item.name}" for item in (HERE / "NativeCompare").iterdir()
                   if item.is_file() and not item.name.endswith((".stdout.log", ".stderr.log")))
    for name in (*receipts, *native):
        files[name] = (HERE / name).read_bytes()
    write(files, deps)
    report = HERE / "VerificationProofDetached.json"
    detached("--audit-output", str(report))
    files[report.name] = report.read_bytes()
    write(files, deps)
    detached()
    print(RESULT, RESULT.stat().st_size, replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
