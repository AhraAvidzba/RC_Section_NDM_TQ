"""Replay the exact original/native affine proof and its typed JSON comparison."""
import argparse
import csv
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
RAW = "C0857EC87936445F7FA49E5556B12A68F48F75EE750E06296B413B7078060818"
PRIOR_RAW = "515A3821B7E159372678BDB6D7C6455A85C2D2C83314FA92D9B1BB754DEE231F"
PRIOR_REPORT = "CC64D1BB52C21D5B3A247D12E771D6945BAF66CC135FACAD02098D79A3DDD7CD"
SOURCES = {"automatic": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
           "stock": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422"}
BAD = '    assert results["Affine"]["weak56_MPa"] == prior["outcomes"]["Fallback"]["weak56_MPa"]'
GOOD = '    assert results["Affine"]["weak56_MPa"] == tuple(prior["outcomes"]["Fallback"]["weak56_MPa"])'


def digest(raw):
    return sha256(raw).hexdigest().upper()


def under(root, name):
    return root / (root / name).resolve().relative_to(root.resolve())


def tags(raw):
    result = defaultdict(list)
    for label, *row in csv.reader(raw.decode("cp1251").splitlines(), delimiter=";"):
        result[label].append(row)
    return result


def scope_for(src, origin):
    scope = {"__file__": str(origin), "__name__": "native_affine_detached"}
    exec(compile(src, str(origin), "exec"), scope)
    return scope


def run(work, auto):
    file = work / "Verify-MVT2ShearControlled.py"
    script = file.read_text(encoding="utf-8")
    substitutions = {
        'for name, expected in prep["inputs"].items())':
            f'for name, expected in prep["inputs"].items() if name != "{BOOK}")',
        f'    assert v.digest(here / "{BOOK}") == prep["book_sha256"]':
            f'    assert prep["book_sha256"] == "{WORKBOOK}" and prep["inputs"]["{BOOK}"] == "{WORKBOOK}"',
    }
    assert not (work / BOOK).exists()
    for before, after in substitutions.items():
        assert script.count(before) == 1, before
        script = script.replace(before, after)
    sys.path.insert(0, str(work))
    old = scope_for(script, file)
    try:
        old["verify"](*old["prepare"]())
    except AssertionError as failure:
        stack = failure.__traceback__
        while stack.tb_next is not None:
            stack = stack.tb_next
        assert script.splitlines()[stack.tb_lineno - 1] == BAD
    else:
        raise AssertionError("Original tuple/list defect did not reproduce")
    assert script.count(BAD) == 1
    fixed = scope_for(script.replace(BAD, GOOD), file)
    canonical = fixed["verify"](*fixed["prepare"]())

    raw = (work / "NativeCompare/MVT2.csv").read_bytes()
    original = auto.read("NativeCompare/MVT2.csv")
    original_json = auto.read("VerificationCompare.json")
    assert digest(raw) == RAW and digest(original) == PRIOR_RAW and digest(original_json) == PRIOR_REPORT
    assert (work / "ProvenRecovery.json").read_bytes() == original_json
    old_rows, new_rows = tags(original), tags(raw)
    wire_rows = ("B_TANGENT_FIELD", "B_TANGENT_RESIDUAL", "B_TANGENT_STATION",
                 "B_BOUND_STEEL", "B_BOUND_ACTUAL", "B_BOUND_NORM", "B_ARC_SOLVER_ACTUAL")
    counts = {}
    for key in wire_rows:
        sub_old = [row[1:] for row in old_rows[key] if row[0] == "Fallback"]
        sub_new = [row[1:] for row in new_rows[key] if row[0] == "Affine"]
        assert sub_old and sub_new == sub_old, key
        counts[key] = len(sub_new)
    affine = canonical["outcomes"]["Affine"]
    reference = json.loads(original_json)["outcomes"]["Fallback"]
    assert affine["weak56_MPa"] == tuple(reference["weak56_MPa"])
    assert canonical["accepted_field_exact"] and canonical["accepted_stresses_and_damage_energy_snapshot_exact"]
    assert not canonical["history_published"] and canonical["owner_closed"]["State"] == "Absent"
    assert len(new_rows["B_ARC_HISTORY"]) == 10
    for name, verdict in (("FixedBefore", (True, 4, 0)), ("BoundedOne", (False, 6, 10)),
                          ("Affine", (True, 4, 0)), ("FixedAfter", (True, 4, 0))):
        outcome = canonical["outcomes"][name]
        assert (outcome["newton_equilibrium_returned"], outcome["internal_status"], outcome["result_code"]) == verdict
    explanation = {"original_assertion_failed_as_expected": True, "native_weak_container": "tuple",
                   "deserialized_reference_container": "list", "numerical_comparison_tolerance_changed": False,
                   "maximum_difference_weak56_MPa": 0., "exact_native_wire_counts": counts,
                   "native_diagnostic_norm_MPa": affine["original_force_weak_norm_MPa"],
                   "original_tolerance_MPa": affine["tolerance_MPa"], "affine_Qy_kN": affine["returned_Qy_parameter_kN"],
                   "unchanged_fixed_before_after": True, "bounded_one_numfail": True,
                   "exact_H24_snapshots_checked": len(new_rows["B_ARC_HISTORY"]), "proof_trace_sha256": RAW,
                   "prior_trace_sha256": PRIOR_RAW}
    return {"verified_result": canonical, "exact_wire_audit": explanation}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("automatic", type=Path)
    parser.add_argument("stock", type=Path)
    parser.add_argument("--audit-output", type=Path)
    args = parser.parse_args()
    manifest = json.loads((HERE / "PortableManifest.json").read_bytes())
    assert manifest["source_archives"] == SOURCES and manifest["omitted_workbook_sha256"] == WORKBOOK
    for key, expected in SOURCES.items():
        assert digest(getattr(args, key).read_bytes()) == expected
    with TemporaryDirectory() as folder, ZipFile(args.automatic) as auto, ZipFile(args.stock) as stock:
        work = Path(folder)
        archives = {"automatic": auto, "stock": stock}
        for name, expected in manifest["files"].items():
            raw = under(HERE, name).read_bytes()
            assert digest(raw) == expected, name
            target = under(work, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        for name, (key, member, expected) in manifest["dependencies"].items():
            raw = archives[key].read(member)
            assert digest(raw) == expected, name
            target = under(work, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        report = (json.dumps(run(work, auto), indent=2) + "\n").encode()
    if args.audit_output is not None:
        args.audit_output.write_bytes(report)
    if "VerificationProofDetached.json" in manifest["files"]:
        assert digest(report) == manifest["files"]["VerificationProofDetached.json"]
    print("MVT2_PRODUCTION_AFFINE_CORE_EXACT_WIRES", digest(report))


if __name__ == "__main__":
    main()
