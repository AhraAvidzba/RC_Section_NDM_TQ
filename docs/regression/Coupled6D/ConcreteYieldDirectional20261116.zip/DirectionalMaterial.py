"""Directional first-order Barcelona return at a regular accepted yield state."""
import argparse
from hashlib import sha256
import json
from math import log, hypot, sqrt
from pathlib import Path
import runpy

import numpy as np
from scipy.optimize import root

STEP_SIZES = (1e-7, 1e-8, 1e-9)


def build_state(data, state):
    E, nu = data["E"], data["NU"]
    lam, G = E*nu/((1+nu)*(1-2*nu)), E/(2*(1+nu))
    C = np.diag([2*G]*3 + [G]*3)
    C[:3, :3] += lam
    return dict(data=data, state=state, C=C,
                sigma=np.r_[state["effective_stress"], 0., 0., 0.],
                nominal=np.r_[state["nominal_stress"], 0., 0., 0.],
                positions=np.array([state["tension_coordinate"], state["compression_coordinate"]]))


def tensor(s):
    xx, yy, zz, xy, xz, yz = s
    return np.array([[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]])


def spectrum(s):
    values, vectors = np.linalg.eigh(tensor(s))
    trace = sum(values)
    dev = values-trace/3
    q = sqrt(1.5*(dev@dev))
    return values, vectors, trace, q


def envelopes(st, positions):
    d = st["data"]
    kt, kc = positions
    T = d["envelope"](kt, d["FT"], d["FT"], 0., d["GT"])
    C = d["envelope"](kc, d["FC0"], d["FC"], d["KC_PEAK"], d["GC"])
    return T, C


def flow(st, sigma, angle):
    d = st["data"]
    eig, _, tr, q = spectrum(sigma)
    radius = hypot(d["ECCENTRICITY"]*angle*d["FT"], sqrt(2/3)*q)
    m = (sigma-np.r_[[tr/3]*3, [0.]*3])/radius
    m[:3] += angle
    m[3:] *= 2
    r = sum(np.maximum(eig, 0))/sum(abs(eig))
    principal_flow = angle+(eig-tr/3)/radius
    coords = np.array([r*max(0., principal_flow[-1]), (1-r)*max(0., -principal_flow[0])])
    return m, coords, r


def model_state(st, sigma, positions):
    d = st["data"]
    T, C = envelopes(st, positions)
    eig, _, tr, q = spectrum(sigma)
    r = sum(np.maximum(eig, 0))/sum(abs(eig))
    y = d["yield_value"](eig, C[0], T[0])
    angle = d["pressure_dilation"](T[2], C[2], r, tr, q)
    apparent = (1-r*T[1])*(1-C[1])*sigma
    return y, angle, apparent


def cohesion_and_damage_derivatives(st, pos, T, C):
    d = st["data"]
    E_c, E_t = d["GC"]/d["LENGTH"], d["GT"]/d["LENGTH"]
    peak, fc, fc0 = d["KC_PEAK"], d["FC"], d["FC0"]
    dT = log(2)*d["FT"]/(log(2)*E_t)
    dC = -log(1-d["DC_PEAK"])/peak
    relativeT = dT-d["FT"]/E_t
    if pos[1] < peak:
        relativeC = dC+(fc-fc0)/(peak*(1-C[1])*C[0])
    else:
        relativeC = dC-fc/(E_c-.5*(fc0+fc)*peak)
    return np.array([T[0]*relativeT, C[0]*relativeC]), np.array([(1-T[1])*dT, (1-C[1])*dC])


def tangent(st, deps):
    d, sigma, C = st["data"], st["sigma"], st["C"]
    pos = st["positions"]
    T, S = envelopes(st, pos)
    eig, vectors, tr, q = spectrum(sigma)
    assert q > 0 and eig[-1] > 0 and min(np.diff(eig)) > 0
    m, coeff, r = flow(st, sigma, st["state"]["dilation"])
    # Gradient of F is paired with a stress tensor. Engineering shear only enters C and m.
    alpha = d["ALPHA"]
    beta = (1-alpha)*S[0]/T[0]-(1+alpha)
    normal = (alpha*np.eye(3) + 1.5*(tensor(sigma)-tr/3*np.eye(3))/q
              + beta*np.outer(vectors[:, -1], vectors[:, -1]))/(1-alpha)
    dcohesion, ddamage = cohesion_and_damage_derivatives(st, pos, T, S)
    Ft = -S[0]*eig[-1]/T[0]**2
    Fc = eig[-1]/T[0]-1
    denominator = np.sum(normal*tensor(C@m)) - (Ft*dcohesion[0]*coeff[0]+Fc*dcohesion[1]*coeff[1])
    loading = np.sum(normal*tensor(C@deps))
    assert denominator > 0, denominator
    multiplier = max(0., loading)/denominator
    effective = C@(deps-multiplier*m)
    d_eig = np.diag(vectors.T@tensor(effective)@vectors)
    zero = abs(eig) <= 1e-13
    positive_sum = sum(np.maximum(eig, 0))
    absolute_sum = sum(abs(eig))
    d_positive = sum(d_eig[eig>1e-13])+sum(np.maximum(d_eig[zero], 0))
    d_absolute = np.sign(eig[~zero])@d_eig[~zero]+sum(abs(d_eig[zero]))
    dr = (d_positive-r*d_absolute)/absolute_sum
    damaged = (1-r*T[1])*(1-S[1])
    rateT, rateC = multiplier*coeff*ddamage
    da = -(dr*T[1] + r*rateT)*(1-S[1])-(1-r*T[1])*rateC
    nominal_slope = damaged*effective+sigma*da
    return dict(predicted=nominal_slope, effective=effective,
                loading=float(loading), multiplier=float(multiplier),
                denominator=float(denominator), pressure_dilation=st["state"]["dilation"])


def numerical(st, deps, directional, h):
    d = st["data"]
    E, C = d["E"], st["C"]
    old = st["sigma"]
    pos0 = st["positions"]
    trial = old+h*(C@deps)
    y, _, stress = model_state(st, trial, pos0)
    if y <= 0:
        return (stress-st["nominal"])/h
    # Solve the same backward-Euler constitutive equations in stress increments.
    def residual(x):
        ds = x[:6]*E
        sigma = old+h*ds
        multiplier, angle = x[6:]
        m, coords, _ = flow(st, sigma, angle)
        pos = pos0+h*multiplier*coords
        value, actual_angle, _ = model_state(st, sigma, pos)
        return np.r_[ (ds-C@deps+multiplier*(C@m))/E,
                      value/(E*h), angle-actual_angle ]
    expected = np.r_[directional["effective"]/E,
                    directional["multiplier"], directional["pressure_dilation"]]
    sol = root(residual, expected, options={"eps": 1e-10})
    assert np.linalg.norm(residual(sol.x), np.inf) < 2e-8, (sol.message, residual(sol.x))
    sigma = old + h*E*sol.x[:6]
    _, coords, _ = flow(st, sigma, sol.x[7])
    pos = pos0 + h*sol.x[6]*coords
    _, _, stress = model_state(st, sigma, pos)
    return (stress-st["nominal"])/h


def main(reference):
    identity = sha256(reference.read_bytes()).hexdigest().upper()
    assert identity == '73DDF4F51F1ED856B049B0DA4ACDDF5809B65B33152376B0E6B37ABFFA6889F6', identity
    data = runpy.run_path(str(reference))
    cases = {}
    for ray, direction in (("PlaneMixed", (-1., .2, 0.)), ("ThreeD", (-1., .05, -.15))):
        states = data["path"](direction, 400)
        for idx in (75, 175, 225, 400):
            st = build_state(data, states[idx])
            d0 = np.r_[np.asarray(states[idx]["total_strain"])-states[idx-1]["total_strain"], 0., 0., 0.]
            d0 /= np.max(np.abs(d0))
            for label, change in (("Secant", d0), ("MixedShear", d0+np.array([0., 0., 0., .4, -.25, .35]))):
                report = {}
                paths = []
                for sign in (1, -1):
                    deps = sign*change
                    A = tangent(st, deps)
                    errors = [float(np.max(np.abs(numerical(st, deps, A, h)-A["predicted"]))) for h in STEP_SIZES]
                    assert errors[-1] < .15, (ray, idx, sign, errors)
                    assert errors[0] > errors[-1], (ray, idx, sign, errors)
                    paths.append(A["predicted"])
                    report[str(sign)] = dict(tangent_MPa=A["predicted"].tolist(), loading_MPa=A["loading"],
                                             multiplier=A["multiplier"], denominator_MPa=A["denominator"],
                                             FD_error_MPa=errors)
                report["nonodd_MPa"] = float(np.max(np.abs(paths[0]+paths[1])))
                cases[f"{ray}/{idx}/{label}"] = report
    return dict(reference_sha256=sha256(reference.read_bytes()).hexdigest().upper(),
                step_sizes=STEP_SIZES, cases=cases)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("reference", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = main(args.reference)
    args.output.write_text(json.dumps(result, indent=2)+"\n",encoding="utf8")
    print(sha256(args.output.read_bytes()).hexdigest().upper())
