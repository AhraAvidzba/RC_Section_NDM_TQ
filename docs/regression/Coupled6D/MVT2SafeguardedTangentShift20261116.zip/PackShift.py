"""Seal the MVT2 native shift experiment with only tracked archive dependencies."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import ReplayPortable as replay


HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[1] / "docs/regression/Coupled6D"
ARCHIVES = {"pseudo_arc": REGRESSION / "MVT2PseudoArclengthNativeComparison20261116.zip",
            "jet": REGRESSION / "MVT2HalfJointJetNative20261116.zip"}
NAME = "MVT2SafeguardedTangentShift20261116.zip"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def archive_index():
    existing = {}
    for key, file in ARCHIVES.items():
        assert digest(file.read_bytes()) == replay.ARCHIVES[key]
        with ZipFile(file) as source:
            for archived in source.namelist():
                if not archived.endswith("/"):
                    existing.setdefault(digest(source.read(archived)), (key, archived))
    return existing


def main():
    report = HERE / "VerificationShift.json"
    assert digest(report.read_bytes()) == replay.REPORT_SHA
    subprocess.run((sys.executable, "-B", "-X", "utf8", "VerifyStationAttribution.py"), cwd=HERE, check=True)
    prep = json.loads((HERE / "Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK_PATH] == prep["book_sha256"] == replay.BOOK_SHA
    index, dependencies, content = archive_index(), {}, {}
    for name, digest_expected in prep["inputs"].items():
        if name == replay.BOOK_PATH:
            continue
        raw = (HERE / name).read_bytes()
        assert digest(raw) == digest_expected, name
        if digest_expected in index:
            dependencies[name] = (*index[digest_expected], digest_expected)
        else:
            content[name] = raw
    evidence = ("Preparation.json", "VerificationShift.json", "Compile.log", "CompileClosure.json",
                "Run.ndjson", "docs/regression/CodeUpdate.json", "PortableREADME.txt", "ReplayPortable.py", "PackShift.py",
                "VerifyStationAttribution.py", "StationAttribution.json")
    native = tuple(f"NativeCompare/{item.name}" for item in (HERE / "NativeCompare").iterdir()
                   if item.is_file() and not item.name.endswith((".stderr.log", ".stdout.log")))
    for name in (*evidence, *native):
        content[name] = (HERE / name).read_bytes()
    manifest = {"local": {name: digest(raw) for name, raw in sorted(content.items())},
                "dependencies": dependencies, "omitted_workbook": {"path": replay.BOOK_PATH, "sha256": replay.BOOK_SHA}}
    assert all(not name.lower().endswith(".xlsm") for name in (*content, *dependencies))
    content["PortableManifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode("utf-8")
    path = HERE / NAME
    with ZipFile(path, "w", compression=ZIP_DEFLATED, compresslevel=9) as output:
        for name, data in sorted(content.items()):
            entry = ZipInfo(name)
            entry.compress_type = ZIP_DEFLATED
            output.writestr(entry, data)
    with tempfile.TemporaryDirectory(dir=HERE / "Temp") as work:
        with ZipFile(path) as archive:
            archive.extractall(work)
        subprocess.run((sys.executable, "-B", "-X", "utf8", "ReplayPortable.py", *map(str, ARCHIVES.values())),
                       cwd=work, check=True)
    print(path, path.stat().st_size, digest(path.read_bytes()))


if __name__ == "__main__":
    main()
