"""Verify a single private MVT2 correction with the original force/energy evaluator."""
import argparse
from decimal import Decimal, localcontext
import json
from math import fsum, isfinite
from pathlib import Path
import re

import VerifyBase as v


HERE = Path(__file__).resolve().parent
NATIVE = HERE / "NativeCompare"
OLD_VERIFIER = "B545EECC04E1515038A396E2BA32A4020B41A39954BF8F8B2146295EC2C78D6E"
ARCHIVE_STOP_NORM = 7.22225739794488e-5
ARCHIVE_BEST_ORDINARY_NORM = 7.23107128695863e-5
STATE_RESOLUTION = 4e-10


def wire_projection(tags, normal):
    [[label, *tokens]] = tags["B_ARC_PROJECTION"]
    assert label == "Normal" and len(tokens) == len(normal) == 60
    with localcontext() as ctx:
        ctx.prec = 100
        for coefficient, token in zip(normal, tokens, strict=True):
            pinned = Decimal.from_float(coefficient)
            quantum = Decimal(1).scaleb(pinned.adjusted() - 14)
            assert pinned.quantize(quantum) == Decimal(token)


def baseline_functions():
    path = HERE / "Verify-MVT2ShearControlled.py"
    assert v.digest(path) == OLD_VERIFIER
    script = path.read_text(encoding="utf-8")
    substitutions = {
        'labels = ("Force", "PseudoArc")': 'labels = ("Force", "PseudoArc", "Shifted")',
        '== prep["inputs"]["src/Solver/CCoupledNewtonSolver.cls"]': '== prep["original_solver_sha256"]',
        '    assert v.peak(v.diff(v.vec(tags, "B_ARC_PROJECTION")["Normal"], p)) < 3e-17':
            '    wire_projection(tags, p)',
        '{"Before", "ReplayForce", "ReplayPseudoArc", "AfterForce", "AfterPseudoArc", "Final"}':
            '{"Before", "ReplayForce", "ReplayPseudoArc", "ReplayShifted", "AfterForce", "AfterPseudoArc", '
            '"AfterShifted", "AfterShiftReadback", "Final"}',
        'if name == "PseudoArc":': 'if name in ("PseudoArc", "Shifted"):'
    }
    for before, after in substitutions.items():
        assert script.count(before) == 1, before
        script = script.replace(before, after)
    scope = {"__file__": str(path), "__name__": "frozen_baseline", "wire_projection": wire_projection}
    exec(compile(script, str(path), "exec"), scope)
    return scope


def vector(tags, key, label, size):
    [[found, *values]] = tags[key]
    assert found == label and len(values) == size
    result = tuple(map(float, values))
    assert all(map(isfinite, result))
    return result


def metric_from_geometry(geometry):
    metric = []
    for index in range(56):
        field = tuple(float(i == index) for i in range(60))
        # ±1000 maps the actual .001·∂z shape to unit lever for the diagonal.
        contribution = [area * v.frobenius(v.strain_at(field, v.operators(x, y), 1000 * side)) ** 2 / 2
                        for (_, side), (x, y, area) in geometry.items() if side != 0]
        metric.append(fsum(contribution) * v.MODULUS / v.AREA)
    return tuple(metric) + (0.,) * 5


def sections_sample(state, station, p, k, target):
    lam, q = state["q"], state["field"]
    weak, forces, _ = v.reconstruct(q, lam, station)
    plane = (v.dot(p, q) + k * lam - target) * v.MODULUS
    return {"Qy_parameter_kN": lam, "weak56_MPa": weak[:56], "gauges4_MPa": [x * v.MODULUS for x in weak[56:]],
            "actual_six_N_Nmm": forces, "signed_six_errors_N_Nmm": v.diff(forces, v.force(lam)),
            "arc_plane_MPa": plane, "tolerance_MPa": state["tol_MPa"],
            "norm_MPa": max(state["norm_MPa"], abs(plane)), "field": q}


def check_probe(result, frozen, tags):
    states, stations = v.verified_states(tags)
    *_, p, k, ds, _, _ = frozen
    target = v.dot(p, states["Base24"]["field"]) + k * states["Base24"]["q"] + ds
    trace = vector(tags, "B_SHIFT_TRACE", "Single", 16)
    eta, radius, max_effect, old_norm, old_tolerance, ordinary_best, solved, fraction, raw_radius, raw_effect, closure, valid, raw_norm, tolerance, raw_plane, accepted = trace
    assert (eta, radius, max_effect) == (.01, 1e-8, .1)
    for flag in (solved, valid, accepted):
        assert flag in (0, 1)
    assert accepted <= valid <= solved
    assert bool(accepted) == result["outcomes"]["Shifted"]["newton_equilibrium_returned"]
    assert ("ShiftTrial" in states) == bool(valid)
    assert result["outcomes"]["PseudoArc"]["internal_status"] == 6
    assert result["outcomes"]["PseudoArc"]["result_code"] == 10
    diag = result["outcomes"]["PseudoArc"]["diagnostic"]
    assert re.search(r"уравнение\s+53\b", diag), diag
    v.near(old_norm, ARCHIVE_STOP_NORM, STATE_RESOLUTION)
    v.near(ordinary_best, ARCHIVE_BEST_ORDINARY_NORM, STATE_RESOLUTION)
    stop = sections_sample(states["ShiftStop"], stations["ShiftStop"], p, k, target)
    assert max(range(56), key=lambda i: abs(stop["weak56_MPa"][i])) == 52
    assert abs(stop["arc_plane_MPa"]) <= old_tolerance and v.peak(stop["gauges4_MPa"]) <= old_tolerance
    v.near(stop["norm_MPa"], old_norm, STATE_RESOLUTION)
    v.near(stop["tolerance_MPa"], old_tolerance, 4e-14)
    residual = vector(tags, "B_SHIFT_RESIDUAL", "Stop", 61)
    expected_residual = (*stop["weak56_MPa"], *(x / v.MODULUS for x in stop["gauges4_MPa"]), stop["arc_plane_MPa"])
    assert v.peak(v.diff(residual, expected_residual)) < STATE_RESOLUTION
    metric = vector(tags, "B_SHIFT_METRIC", "Diagonal", 61)
    independent_metric = metric_from_geometry(states["ShiftStop"]["geometry"])
    assert all(value > 0 for value in metric[:56]) and metric[56:] == (0.,) * 5
    assert max(abs(a-b) / a for a,b in zip(metric[:56], independent_metric[:56], strict=True)) < 4e-13
    matrix = []
    for index, (label, *values) in enumerate(tags["B_SHIFT_MATRIX"], 1):
        assert int(label) == index and len(values) == 61
        row = tuple(map(float, values))
        assert all(map(isfinite, row))
        matrix.append(row)
    assert len(matrix) == 61
    assert v.peak(v.diff(matrix[-1], tuple(x * v.MODULUS for x in (*p, k)))) < 4e-10
    physical_load_column = v.diff(v.loading(0.), v.loading(1.))
    assert v.peak(v.diff([row[-1] for row in matrix[:60]], physical_load_column)) < 2e-13
    out = {"stop": stop, "shift_solve": bool(solved), "original_material_sample": bool(valid),
           "accepted_original_equilibrium": bool(accepted), "eta": eta, "max_tensor_strain": radius,
           "max_shift_share_of_stop_norm": max_effect, "trace_sha256": v.digest(NATIVE / "MVT2.csv")}
    if not solved:
        assert not tags["B_SHIFT_RAY"]
        return out
    ray = vector(tags, "B_SHIFT_RAY", "Full", 61)
    expected_closure = max(abs(v.dot(row, ray) + eta * metric[i] * ray[i] + residual[i]) for i, row in enumerate(matrix))
    v.near(expected_closure, closure, 4e-10)
    assert expected_closure < old_norm * 1e-5
    expected_effect = v.peak(eta * a * b for a,b in zip(metric, ray, strict=True))
    expected_radius = v.strain_extent(ray[:60], states["ShiftStop"]["geometry"])
    v.near(raw_effect, expected_effect, 2e-12)
    v.near(raw_radius, expected_radius, 2e-14)
    expected_fraction = min(1., radius / expected_radius if expected_radius else 1.,
                            max_effect * old_norm / expected_effect if expected_effect else 1.)
    v.near(fraction, expected_fraction, 3e-12)
    assert expected_fraction > 0.
    out.update({"step_fraction": fraction, "shift_equivalent_MPa": fraction * expected_effect,
                "linearized_equation_error_MPa": expected_closure})
    if not valid:
        return out
    candidate = sections_sample(states["ShiftTrial"], stations["ShiftTrial"], p, k, target)
    dq = v.diff(candidate["field"], stop["field"])
    assert v.peak(v.diff(dq, [fraction*x for x in ray[:60]])) < 5e-15
    v.near(candidate["Qy_parameter_kN"] - stop["Qy_parameter_kN"], fraction * ray[60], 2e-13)
    v.near(candidate["norm_MPa"], raw_norm, STATE_RESOLUTION)
    v.near(candidate["tolerance_MPa"], tolerance, 4e-14)
    v.near(candidate["arc_plane_MPa"], raw_plane, 4e-11)
    assert abs(candidate["arc_plane_MPa"]) <= tolerance and v.peak(candidate["gauges4_MPa"]) <= tolerance
    physical = v.strain_extent(dq, states["ShiftStop"]["geometry"])
    assert physical <= radius + 5e-15
    if accepted:
        assert candidate["norm_MPa"] <= tolerance + STATE_RESOLUTION
        assert states["Shifted"] == states["ShiftTrial"] and stations["Shifted"] == stations["ShiftTrial"]
    else:
        assert candidate["norm_MPa"] > tolerance - STATE_RESOLUTION
    changes = [key for key, station in stations["ShiftStop"].items() if key[0] <= 25
               and (station[3:6] != stations["ShiftTrial"][key][3:6]
                    or station[6] * stations["ShiftTrial"][key][6] < 0.)]
    out.update({"candidate": candidate, "observed_tensor_strain": physical,
                "actual_stop_row53_change_MPa": candidate["weak56_MPa"][52] - stop["weak56_MPa"][52],
                "linear_stop_row53_change_MPa": fraction * v.dot(matrix[52], ray),
                "true_norm_ratio": candidate["norm_MPa"] / stop["norm_MPa"],
                "concrete_branch_changes": changes})
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Compare"])
    args = parser.parse_args()
    base = baseline_functions()
    frozen = base["prepare"]()
    if args.inputs_only:
        print("FROZEN_INPUTS", v.digest(HERE / "Preparation.json"))
        return
    assert args.phase == "Compare"
    result = base["verify"](*frozen)
    result["shift_probe"] = check_probe(result, frozen, v.read_native(NATIVE / "MVT2.csv"))
    output = HERE / "VerificationShift.json"
    output.write_bytes((json.dumps(result, indent=2) + "\n").encode("utf-8"))
    print(output, v.digest(output))


if __name__ == "__main__":
    main()
