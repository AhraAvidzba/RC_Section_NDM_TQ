"""Reproduce the exact recorded shift evidence without any workbook or Office process."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
import subprocess
import sys
import tempfile
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
ARCHIVES = {"pseudo_arc": "20F807CD70BDBA3797FE2709B7BDBA9131BF128B25FFBD38C8236F42D5B69229",
            "jet": "6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33"}
BOOK_PATH = "workbook/output/RC_Section_NDM.xlsm"
BOOK_SHA = "8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF"
REPORT_SHA = "A6BE7C71F36D66C21E12BACB3F66D041B86C4DE2AE16DFED109642A7BFBEB47E"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def contained(path, root):
    return (root / path).resolve().relative_to(root.resolve())


def offline_verification(stage, station_sha):
    prep_path = stage / "Preparation.json"
    prep = json.loads(prep_path.read_bytes())
    assert prep["inputs"][BOOK_PATH] == prep["book_sha256"] == BOOK_SHA
    assert not (stage / BOOK_PATH).exists()
    assert digest((stage / "VerificationShift.json").read_bytes()) == REPORT_SHA
    assert digest((stage / "StationAttribution.json").read_bytes()) == station_sha
    source = stage / "VerifyShift.py"
    script = source.read_text(encoding="utf-8")
    # The native verifier keeps its exact input seal. Only the absent workbook
    # byte check is replaced by the compile, pre-open and closure identity checks.
    anchor = '    substitutions = {\n'
    added = '''        'for name, expected in prep["inputs"].items())':
            'for name, expected in prep["inputs"].items() if name != "workbook/output/RC_Section_NDM.xlsm")',
        '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]':
            '    assert prep["book_sha256"] == "BOOK_SHA"',
'''.replace("BOOK_SHA", BOOK_SHA)
    assert script.count(anchor) == 1
    script = script.replace(anchor, anchor + added)
    previous_argv, previous_path = sys.argv, sys.path[:]
    try:
        sys.argv = [str(source), "--phase", "Compare"]
        sys.path.insert(0, str(stage))
        exec(compile(script, str(source), "exec"), {"__file__": str(source), "__name__": "__main__"})
    finally:
        sys.argv = previous_argv
        sys.path[:] = previous_path
    assert digest((stage / "VerificationShift.json").read_bytes()) == REPORT_SHA
    subprocess.run((sys.executable, "-B", "-X", "utf8", "VerifyStationAttribution.py"), cwd=stage, check=True)
    assert digest((stage / "StationAttribution.json").read_bytes()) == station_sha
    print("VERIFIED NATIVE SHIFT AND STATION ATTRIBUTION", REPORT_SHA, station_sha)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pseudo_arc", type=Path)
    parser.add_argument("jet", type=Path)
    args = parser.parse_args()
    manifest = json.loads((HERE / "PortableManifest.json").read_bytes())
    for key, value in ARCHIVES.items():
        assert digest(getattr(args, key).read_bytes()) == value
    assert manifest["omitted_workbook"] == {"path": BOOK_PATH, "sha256": BOOK_SHA}
    assert set(manifest["local"]).isdisjoint(manifest["dependencies"])
    with tempfile.TemporaryDirectory() as folder, ZipFile(args.pseudo_arc) as arc, ZipFile(args.jet) as jet:
        stage = Path(folder).resolve()
        sources = {"pseudo_arc": arc, "jet": jet}
        for name, expected in manifest["local"].items():
            path = HERE / contained(name, HERE)
            assert digest(path.read_bytes()) == expected
            target = stage / contained(name, stage)
            target.parent.mkdir(parents=True, exist_ok=True)
            copyfile(path, target)
        for name, (archive, archived, expected) in manifest["dependencies"].items():
            raw = sources[archive].read(archived)
            assert digest(raw) == expected
            target = stage / contained(name, stage)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        offline_verification(stage, manifest["local"]["StationAttribution.json"])


if __name__ == "__main__":
    main()
