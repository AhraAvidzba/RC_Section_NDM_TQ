"""Stage a private shift probe on the hash-verified MVT2 H24 comparison."""
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
BASE = HERE.parent / "mvt-next" / "arc-ab"
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
TEST_MODULE = "tests/modTestCoupledExperiment.bas"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
RUNNER = "Run-MVT2ShearControlled.ps1"
VERIFIER = "Verify-MVT2ShearControlled.py"
PINNED_VERIFIER = "B545EECC04E1515038A396E2BA32A4020B41A39954BF8F8B2146295EC2C78D6E"
PINNED_ARCHIVE = "docs/regression/Coupled6D/MVT2PseudoArclengthNativeComparison20261116.zip"
PINNED_ARCHIVE_SHA = "20F807CD70BDBA3797FE2709B7BDBA9131BF128B25FFBD38C8236F42D5B69229"
PARENT_PREPARATION_SHA = "1582BE948DA703EEA2376EAE03330EA6EC8E2870C10515D59E95D2370EBF2503"


def digest(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def substitute(content, original, replacement):
    assert content.count(original) == 1, original
    return content.replace(original, replacement)


def write(name, raw):
    path = HERE / name
    path.parent.mkdir(exist_ok=True, parents=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def text(raw):
    return raw.decode("utf-8").replace("\r\n", "\n")


def vba(source):
    return source.replace("\n", "\r\n").encode("utf-8")


def solver(source):
    declarations = '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Приватный протокол одной защищённой поправки без фиксации истории.
Private mShiftTraceTest As Integer, mShiftAttemptedTest As Boolean, mShiftTrialValidTest As Boolean
Private mShiftBaseTest() As Double, mShiftTrialTest() As Double
Private mShiftBaseLambdaTest As Double, mShiftTrialLambdaTest As Double
'''
    start = source.index("\nFriend Sub ")
    start = source.rindex("\n'", 0, start)
    # Insert on a known global declaration boundary before any methods.
    anchor = "Private mReferenceModulus As Double, mLastNorm As Double, mMinimumPivot As Double\n"
    assert source.index(anchor) < start
    source = substitute(source, anchor, anchor + declarations)
    hook = '''            If mShiftTraceTest > 0 And Not mShiftAttemptedTest And mUseSpatialHistory And _
                    mControlActive And mControlLoadProjection <> 0# And hasValidTrial Then
                If TryShiftProbeTest(current, currentLambda, load, norm, tolerance, bestTrialNorm, _
                        absoluteTolerance, relativeTolerance) Then
                    PublishCandidate mShiftTrialLambdaTest
                    SolveStep = True
                End If
            End If
'''
    boundary = "            End If\n            Exit Function\n        End If\n        mIterations = mIterations + 1\n"
    source = substitute(source, boundary, boundary[:len("            End If\n")] + hook + boundary[len("            End If\n"):])
    return source.rstrip() + "\n" + (HERE / "ShiftSolver.txt").read_text(encoding="utf-8")


def macro(source):
    source = substitute(source, 'For Each mode In Array("Force", "PseudoArc")',
                        'For Each mode In Array("Force", "PseudoArc", "Shifted")')
    source = substitute(source, '        lambda = qTrial: started = Timer',
                        '        If mode = "Shifted" Then solver.EnableShiftProbeTest output\n'
                        '        lambda = qTrial: started = Timer')
    added = '''        If mode = "Shifted" Then
            Dim stopField() As Double, probeField() As Double, stopFactor As Double, probeFactor As Double, validProbe As Boolean
            solver.CopyShiftProbeTest stopField, stopFactor, probeField, probeFactor, validProbe
            norm = RecordWangTangentStateTest(output, "ShiftStop", 24, stopFactor, solver, operators, materials, responses, stopField, actual, weak)
            If norm < 0# Then Err.Raise 5, , "Не подтверждена точка остановки MVT2."
            If validProbe Then
                norm = RecordWangTangentStateTest(output, "ShiftTrial", 24, probeFactor, solver, operators, materials, responses, probeField, actual, weak)
                If norm < 0# Then Err.Raise 5, , "Не подтверждено истинное поле пробы стабилизации MVT2."
            End If
            CaptureWangArcHistoryTest output, "AfterShiftReadback", operators, materials, afterProbe
            RequireWangArcHistoryTest committed, afterProbe
            solver.EnableShiftProbeTest 0
        End If
'''
    anchor = '    Next mode\n    RestoreWangShearBaselineTest solver, history, base\n'
    return substitute(source, anchor, added + anchor)


def main():
    previous = (BASE / "Preparation.json").read_bytes()
    assert digest(previous) == PARENT_PREPARATION_SHA
    assert digest((ROOT / PINNED_ARCHIVE).read_bytes()) == PINNED_ARCHIVE_SHA
    preparation = json.loads(previous)
    inputs = {}
    for name, expected in preparation["inputs"].items():
        raw = (BASE / name).read_bytes()
        assert digest(raw) == expected, name
        if name in {"Stage.py", "Probe.bas", "Control.bas"}:
            continue
        if name == NEWTON:
            raw = vba(solver(text(raw)))
        elif name == TEST_MODULE:
            raw = vba(macro(text(raw)))
        elif name == RUNNER:
            raw = text(raw).replace(VERIFIER, "VerifyShift.py").encode("utf-8")
        elif name == VERIFIER:
            assert expected == PINNED_VERIFIER
        inputs[name] = write(name, raw)
    book = (ROOT / BOOK).read_bytes()
    assert digest(book) == preparation["book_sha256"]
    inputs[BOOK] = write(BOOK, book)
    write("docs/regression/Diagnostic.xlsm", book)
    for folder in ("NativeCompare", "Temp"):
        (HERE / folder).mkdir(exist_ok=True)
    for name in ("Stage.py", "ShiftSolver.txt", "VerifyShift.py", "README.txt"):
        inputs[name] = digest((HERE / name).read_bytes())
    result = {**preparation, "inputs": inputs, "original_solver_sha256": preparation["inputs"][NEWTON],
              "original_verifier_sha256": PINNED_VERIFIER,
              "parent_preparation_sha256": PARENT_PREPARATION_SHA, "pinned_archive_sha256": PINNED_ARCHIVE_SHA}
    print("STAGED", write("Preparation.json", (json.dumps(result, indent=2) + "\n").encode("utf-8")))


if __name__ == "__main__":
    main()
