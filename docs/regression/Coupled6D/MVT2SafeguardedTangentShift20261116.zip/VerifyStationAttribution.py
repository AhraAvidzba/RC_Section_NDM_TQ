"""Independently decompose the signed change of MVT2's weak row 53."""
import json
from math import fsum
from pathlib import Path

import VerifyBase as v


HERE = Path(__file__).resolve().parent


def main():
    trace = HERE / "NativeCompare/MVT2.csv"
    checks = v.read(HERE / "VerificationShift.json")["shift_probe"]
    assert v.digest(trace) == checks["trace_sha256"]
    raw = v.read_native(trace)
    states, stations = v.verified_states(raw)
    old, new = stations["ShiftStop"], stations["ShiftTrial"]
    assert states["ShiftStop"]["geometry"] == states["ShiftTrial"]["geometry"]
    points = []
    for point in range(1, 46):
        xm, ym, area = old[point, 0][:3]
        changes = {side: new[point, side][15] - old[point, side][15] for side in (-1, 1)}
        axial_gradient = (changes[1] - changes[-1]) / (2 * .001)
        points.append({"point": point, "x_mm": xm, "y_mm": ym, "area_mm2": area,
                       "delta_minus_sigma_zz_MPa": changes[-1], "delta_plus_sigma_zz_MPa": changes[1],
                       "delta_weak_53_MPa": axial_gradient * area / v.AREA})
    total = fsum(item["delta_weak_53_MPa"] for item in points)
    assert abs(total - checks["actual_stop_row53_change_MPa"]) < 5e-13
    delta_steel = {}
    for label, point, side, axis, _, _, sigma in raw["B_BOUND_STEEL"]:
        if label in ("ShiftStop", "ShiftTrial") and int(axis) == 3 and int(side) != 0:
            delta_steel[label, int(point), int(side)] = float(sigma)
    assert set(delta_steel) == {(label, p, side) for label in ("ShiftStop", "ShiftTrial")
                               for p in range(26, 30) for side in (-1, 1)}
    direct = fsum(item["delta_weak_53_MPa"] for item in points[:25])
    composite = fsum(item["delta_weak_53_MPa"] for item in points[25:])
    longitudinal = fsum(((delta_steel["ShiftTrial", p, 1] - delta_steel["ShiftStop", p, 1]) -
                         (delta_steel["ShiftTrial", p, -1] - delta_steel["ShiftStop", p, -1])) / .002
                        * old[p, 0][2] / v.AREA for p in range(26, 30))
    report = {"trace_sha256": v.digest(trace), "axial_stress_index": 3, "weak_equilibrium_row": 53,
              "half_step_z_over_L": .001, "section_area_mm2": v.AREA, "total_MPa": total,
              "direct_concrete_MPa": direct, "composite_steel_replacements_MPa": composite,
              "longitudinal_steel_part_of_composite_MPa": longitudinal,
              "displaced_concrete_part_of_composite_MPa": composite - longitudinal,
              "concrete_branch_flags_changed": checks["concrete_branch_changes"],
              "points_sorted_by_abs_contribution": sorted(points, key=lambda item: -abs(item["delta_weak_53_MPa"]))}
    output = HERE / "StationAttribution.json"
    output.write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    print(output, v.digest(output))


if __name__ == "__main__":
    main()
