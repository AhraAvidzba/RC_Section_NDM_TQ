MVT2 H24 native single safeguarded tangent shift

From the extracted directory run with Python 3.10 or later
    python -B -X utf8 ReplayPortable.py PATH/MVT2PseudoArclengthNativeComparison20261116.zip PATH/MVT2HalfJointJetNative20261116.zip

Both dependencies are existing repository archives under docs/regression/Coupled6D.
The verifier checks reference hashes, exact native receipts, the correction, all
original equilibrium equations, and exact accepted-field and material rollback.
It recreates VerificationShift.json and the independent StationAttribution.json.
Workbook bytes are omitted. The recorded compiler, owned pre-open workbook hash
and independent process closure receipts verify source identity for this offline
replay. The replay does not recompile or rerun the workbook.

The test replays H24 and repeats its archived force and pseudo-arc controls.
One positive diagonal shift in 56 physical coordinates is tried exactly at the
ordinary arc stop. Four gauge coordinates, the arc equation, and the load
column are unchanged. The trial uses the same original material history and
the same force-relative tolerance. It attains the linearized equations to
roundoff and uses a physical tensor strain increment of 5.16511e-9.

The original-law norm increases from 7.22225735e-5 to 8.16073840e-5 MPa.
The worst row is the axial-force gradient. Linear analysis predicts an increase
of 7.25783892e-5 MPa in this signed row, versus a measured decrease of
9.38481052e-6 MPa. The trial stays on the original arc plane within the
measured numerical resolution and remains 72.75 times over the tolerance.
It changes the unaccepted Qy parameter by about 0.0173 N. All 135 accepted
concrete station stress/energy fingerprints are preserved exactly and each
owned process was verified closed. No new equilibrium or capacity was accepted.
