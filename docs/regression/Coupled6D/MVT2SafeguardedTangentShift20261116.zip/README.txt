Private MVT2 predictor only. No material viscosity or new concrete law.

From repo root, first verify the sealed inputs
    python -B -X utf8 tmp/mvts/VerifyShift.py --inputs-only

With the confirmed exclusive Excel slot and sufficient memory, run
    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mvts/Run-MVT2ShearControlled.ps1

Once the owned process is confirmed closed, independently replay
    python -B -X utf8 tmp/mvts/VerifyShift.py --phase Compare

Stage.py reconstructs the private inputs from the unchanged arc-ab preparation
and installed 8EAD3E67… workbook. The prior experiment's native evidence stays
in its own directory and in MVT2PseudoArclengthNativeComparison20261116.zip.
Do not reuse a private directory containing a completed native run.

All three arms share exact H24, the same predicted field and original material
response. Force and PseudoArc rerun the prior reference first. Shifted uses
one shifted-Jacobian correction at the original pseudoarc line-search stop.
The shift affects only 56 weak rows. The gauge equations, arc row and load
column are copied exactly. The strain metric uses a unit axial lever to keep
slope coordinates comparable with other strain coordinates. The real bound
uses the actual ±0.001 stations and tensor Frobenius norm. The probe never
advances the committed history. A numerical improvement outside the original
tolerance is just a measured predictor, with no equilibrium or capacity claim.
