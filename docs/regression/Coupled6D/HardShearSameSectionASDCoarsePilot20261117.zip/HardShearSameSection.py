"""Virgin coarse HardShear signed-six equilibrium in matched ASDConcrete3D."""
from argparse import ArgumentParser
from hashlib import sha256
from math import fsum
from pathlib import Path
from time import perf_counter
from types import ModuleType, SimpleNamespace, FunctionType
from zipfile import ZipFile
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
H68=('HardShearH68PseudoArcNativePortable.zip','E1140D78FFD51715B73009D27E425E7F441E13CD65571E43A2EB28E9E10D6EF4')
MVT=('MVT2GaussReequilibratedASD20261117.zip','FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E')
MATERIAL='17CAD60D1E55F84F62CFCFE49EDDE9FD6F3D7CF29761E3252A37975047812106'
RAY=(28000.,510000.,180000.,1500000.,17000.,-7100.)
HALF=.001
E=30000.
ES=200000.
TARGETS=(.03125,.0625,.125,.25,.375,.5)


def sha(b):
    return sha256(b).hexdigest().upper()


def packed(payload):
    return json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def archived(repo,pins):
    name,seal=pins
    p=repo/'docs/regression/Coupled6D'/name
    assert sha(p.read_bytes())==seal
    return ZipFile(p)


def csv(raw):
    return [line.split(';') for line in raw.decode('cp1251').splitlines()]


def fixture(repo):
    with archived(repo,H68) as z:
        geo=z.read('HardShear-Geometry.csv'); native=z.read('Native/HardArcPair.csv')
    lines=csv(geo); assert lines[0][:5]==['POINTS','43','25','2','16']
    area,length=map(float,lines[0][5:]); assert area==21600.
    geometry=[]; directions=[]; family=[]
    for point,(i,kind,x,y,w) in enumerate(lines[1:],1):
        assert point==int(i)
        x,y,w=map(float,(x,y,w))
        geometry.append((x,y,w)); family.append(kind)
        axis=[0.]*6
        if kind=='longitudinal': axis[2]=1.
        if kind=='transverse':
            assert (abs(x)==76.)!=(abs(y)==46.)
            axis[0 if abs(y)==46. else 1]=1.
        directions.append(axis)
    assert family==['concrete']*25+['longitudinal']*2+['transverse']*16
    assert fsum(v[2] for v in geometry[:25])==area
    records=csv(native)
    lookup={line[0]:line[1:] for line in records if line[0] in ('DIM','LAW','OPTIONS','OFFSET','DIRECTION','EXTERNAL_ROWS')}
    assert tuple(map(float,lookup['DIRECTION']))==RAY and all(float(v)==0. for v in lookup['OFFSET'])
    assert tuple(map(float,lookup['DIM'][:7]))==(60.,56.,4.,43.,25.,3.,area)
    assert abs(float(lookup['DIM'][7])-length)<5e-13
    assert tuple(map(float,lookup['LAW']))==(E,.2,30.,3.,16.,.002,.12,80.,125.)
    assert tuple(map(float,lookup['OPTIONS'][1:3]))==(5e-7,5e-7)
    p=[line for line in records if line[:2]==['POINT','Arc']]; assert len(p)==43
    assert all(max(abs(a-b) for a,b in zip(geometry[int(line[2])-1],map(float,line[3:6]),strict=True))<3e-12 for line in p)
    lam=float(next(line[2] for line in records if line[:2]==['BALANCE','Arc']))
    signed=integrate(geometry,[list(map(float,line[6:12])) for line in p]); expected=[lam*d for d in RAY]
    scales=(area,area*length,area*length,area*length,area,area)
    norm=max(abs(a-b)/s for a,b,s in zip(signed,expected,scales,strict=True))
    assert norm<1.2e-6
    return geometry,directions,area,length,lookup,{'geometry_sha256':sha(geo),'native_trace_sha256':sha(native),
                 'archived_H69_arc_signed_norm_MPa':norm,'geometry_archive':H68}


def bernstein(x,span,length):
    t=(x+span/2.)/span
    q=1.-t
    return (q**3,3.*t*q*q,3.*t*t*q,t**3),tuple(v*3.*length/span for v in (-q*q,q*q-2.*t*q,2.*t*q-t*t,t*t))


def zeros(n,m):
    return [[0.]*m for _ in range(n)]


def operators(geometry,area,length):
    BigB,BigZ,S,R=[],[],[],[]
    G=zeros(60,60); L=zeros(6,60)
    for k,j in enumerate((0,1,2,3,54,53)):
        L[k][j]=1./(area*(length if k in (1,2,3) else 1.))
    for i,(x,y,a) in enumerate(geometry):
        w=a/area
        b,z,r=(zeros(6,60) for _ in range(3))
        x0,y0=x/length,y/length
        b[2][:3]=1.,y0,x0
        b[4][3],b[5][3]=-y0,x0
        for k in range(6):
            z[k][52:56]=b[k][:4]
            r[k][52:56]=[w*v for v in b[k][:4]]
        vx,dx=bernstein(x,180.,length)
        vy,dy=bernstein(y,120.,length)
        for iy in range(4):
            for ix in range(4):
                j=4+3*(4*iy+ix); v=j+1; warp=j+2
                phi=vx[ix]*vy[iy]; gx=dx[ix]*vy[iy]; gy=vx[ix]*dy[iy]
                b[0][j],b[3][j]=gx,gy
                b[1][v],b[3][v]=gy,gx
                b[4][warp],b[5][warp]=gx,gy
                r[4][j]=r[5][v]=r[2][warp]=-w*phi
                if i<25:
                    for row,g,value in ((j,56,w*phi),(v,57,w*phi),(warp,58,w*phi),
                                        (j,59,-y0*w*phi),(v,59,x0*w*phi)):
                        G[row][g]+=value; G[g][row]+=value
        BigB.append(b); BigZ.append(z)
        S.append([[w*v for v in row] for row in b]); R.append(r)
    return {'B':BigB,'Z':BigZ,'G':G,'L':L,'S':S,'R':R}


def integrate(geometry,stress):
    q=[]
    for (x,y,a),sigma in zip(geometry,stress,strict=True):
        _,_,zz,_,xz,yz=sigma
        q.append((a*zz,a*y*zz,a*x*zz,a*(x*yz-y*xz),a*xz,a*yz))
    return [fsum(v) for v in zip(*q,strict=True)]


def verify_rows(geo,dirs,area,length,op,field,net,factor,steel):
    load=[factor*v for v in RAY]
    applied=[fsum(q*row[j] for q,row in zip(load,op['L'],strict=True)) for j in range(60)]
    center,plus,minus=net
    derivative=[[500.*(a-b) for a,b in zip(p,m,strict=True)] for p,m in zip(plus,minus,strict=True)]
    weak=[]
    for j in range(60):
        stress=(coeff[j]*s for row,p in zip(op['S'],center,strict=True) for coeff,s in zip(row,p,strict=True))
        grade=(coeff[j]*s for row,p in zip(op['R'],derivative,strict=True) for coeff,s in zip(row,p,strict=True))
        gauge=(v*q for v,q in zip(op['G'][j],field,strict=True))
        weak.append(fsum((*stress,*grade,*gauge))-applied[j])
    actual=integrate(geo,center)
    scales=(area,area*length,area*length,area*length,area,area)
    maxforce=max(abs(a-b)/s for a,b,s in zip(actual,load,scales,strict=True))
    maxweak=max(map(abs,weak[:56])); maxgauge=E*max(map(abs,weak[56:]))
    norm=max(maxforce,maxweak,maxgauge); tolerance=5e-7*(1.+max(map(abs,applied[:56])))
    assert norm<=tolerance
    max_steel_error=0.
    for side,side_steel in zip((0.,HALF,-HALF),steel,strict=True):
        assert len(side_steel)==18
        for i,measured in enumerate(side_steel,25):
            eps=[fsum((v+side*z)*q for v,z,q in zip(b,d,field,strict=True))
                 for b,d in zip(op['B'][i],op['Z'][i],strict=True)]
            stress=ES*fsum(v*d for v,d in zip(eps,dirs[i],strict=True))
            assert (-350.<stress<400.) if i<27 else (-240.<stress<240.)
            max_steel_error=max(max_steel_error,abs(stress-measured))
    assert max_steel_error<3e-11
    return {'weak':weak,'signed_six':actual,'original_tolerance_MPa':tolerance,'combined_norm_MPa':norm,
            'weak_56_norm_MPa':maxweak,'scaled_4_gauge_norm_MPa':maxgauge,'signed_force_norm_MPa':maxforce,
            'maximum_steel_reconstruction_error_MPa':max_steel_error}


def source_model(repo):
    with archived(repo,MVT) as holder:
        deps={f:holder.read(f+'.py') for f in ('Operators','Reequilibrate')}
    mods={}
    for name,raw in deps.items():
        module=ModuleType(name); module.__file__=str(HERE/(name+'.py')); sys.modules[name]=module
        exec(compile(raw,module.__file__,'exec'),module.__dict__)
        mods[name]=module
    return mods['Reequilibrate'],{name:sha(raw) for name,raw in deps.items()}


def material_command(repo):
    path=repo/'tools/validate_opensees_hardshear.py'
    assert sha(path.read_bytes())==MATERIAL
    symbol=runpy.run_path(str(path))['concrete']
    seen=[]; fake=SimpleNamespace(nDMaterial=lambda *args:seen.append(args))
    copied=FunctionType(symbol.__code__,symbol.__globals__|{'ops':fake})
    tables=copied('matched')
    material,=seen
    assert material[:4]==('ASDConcrete3D',1,E,.2)
    return (material[0],*material[2:]),tuple(rows[-1][0] for rows in tables)


def compute(repo,out):
    start=perf_counter()
    sys.path.insert(0,'D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython')
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=='3.8.0' and np.__version__=='2.3.5'
    geo,dirs,area,length,logged,identity=fixture(repo)
    op=operators(geo,area,length)
    load=np.array(RAY); matrix=np.array(op['L']); ext=load@matrix
    assert np.max(np.abs(ext-np.array(logged['EXTERNAL_ROWS'],dtype=float)))<2e-14
    identity['exact_built_operator_sha256']=sha(packed(op))
    cls,identity['solver_source_sha256']=source_model(repo)
    cls.P=43
    cls.loads=lambda arrays,t,q:q*load
    command,last_ordinate=material_command(repo); assert not out.exists()
    class CoarseSection(cls.Section):
        def __init__(self):
            super().__init__(np,ops,command,geo,dirs,area,length,op,start+40.)
            self.steel_stress=None

        def components(self,field):
            strain=self.strain@field
            if np.max(np.abs(strain))>.01:
                raise ArithmeticError('diagnostic numerical strain range')
            elastic=ES*np.einsum('spi,pi->sp',strain[:,25:,:],self.dirs[25:])
            if np.any(elastic[:,:2]>=400.) or np.any(elastic[:,:2]<=-350.) or np.any(np.abs(elastic[:,2:])>=240.):
                raise ArithmeticError('pilot left exact elastic-steel scope')
            self.steel_stress=elastic.copy()
            return strain,elastic

    section=CoarseSection(); field=np.zeros(60); accepted=[]; premature=None
    assert section.committed==0
    zero=section.equations(field,np.zeros(6),False)
    assert zero[4]<1e-12
    for factor in TARGETS:
        correction,arm=cls.try_correct(section,field,float(load[3]),factor)
        if correction is None:
            premature={'lambda':factor,'diagnostic':arm}
            break
        field=correction
        steel=section.steel_stress.tolist(); state=section.accepted_stresses[-1]
        verified=verify_rows(geo,dirs,area,length,op,field.tolist(),state,factor,steel)
        assert np.max(np.abs(np.array(verified['signed_six'])-np.array(arm['resultants_N_Nmm'])))<3e-8
        assert abs(verified['combined_norm_MPa']-arm['all_weak_and_force_max_MPa'])<3e-12
        accepted.append({'lambda':factor,'field':field.tolist(),'steel_stress_MPa':steel,
                         'net_stress_MPa':state,'independent':verified,'iterations':arm['newton_iterations']})
    assert section.committed==len(accepted)
    eval_count=section.eval_count; matrix_count=section.full_matrices
    # Reproduce the accepted stress history from a fresh virgin engine,
    # interleaving a rejected excursion before each exact repeated field.
    verify=CoarseSection()
    assert verify.committed==0
    for item in accepted:
        q=np.array(item['field']); target=item['lambda']*load
        alt=q.copy(); alt[0]+=1e-6
        verify.equations(alt,target,False)
        exact=verify.equations(q,target,False)
        assert np.array_equal(exact[2],item['net_stress_MPa']) and np.array_equal(verify.steel_stress,item['steel_stress_MPa'])
        verify.commit()
    assert verify.committed==len(accepted)
    ops.wipe()
    brief={'identity':identity,'runtime':ops.version(),'numpy':np.__version__,'ray_N_Nmm':RAY,
           'match_to_archived_material_source_sha256':MATERIAL,'material_command':command,'curve_end_ordinates':last_ordinate,
           'started_from_virgin':True,'cold_replay_with_uncommitted_excursions':len(accepted),
           'weak_rows':56,'gauge_rows':4,'signed_force_rows':6,'accepted_targets':accepted,
           'native_evaluations':eval_count,'native_jacobians':matrix_count,'premature_stop':premature,'physical_limit_established':False}
    wire=gzip.compress(packed(brief),compresslevel=9,mtime=0)
    with out.open('xb') as stream: stream.write(wire)
    print('HARDSHEAR_MATCHED_ASD_SAME_SECTION_WIRE',sha(wire),len(wire),'accepted',len(accepted),'seconds',perf_counter()-start)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd()); p.add_argument('--out',type=Path,default=HERE/'CoarsePilot.json.gz')
    args=p.parse_args()
    compute(args.repo.resolve(),args.out)
