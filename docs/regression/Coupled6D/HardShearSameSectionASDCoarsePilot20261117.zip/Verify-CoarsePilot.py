"""Offline audit of the matched ASD virgin HardShear section pilot."""
from argparse import ArgumentParser
from hashlib import sha256
from math import fsum
from pathlib import Path
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WIRE='6AF40BA9D209A244C376449470DB5055328005105D1B0E9075F43F4A1FD9607D'


def sha(data):
    return sha256(data).hexdigest().upper()


def main(repo):
    source=runpy.run_path(str(HERE/'HardShearSameSection.py'))
    wire=(HERE/'CoarsePilot.json.gz').read_bytes(); assert sha(wire)==WIRE
    p=json.loads(gzip.decompress(wire))
    with source['archived'](repo,source['H68']) as old:
        native_rows=source['csv'](old.read('HardShear-H68.csv'))
    geo,dirs,area,length,logged,identity=source['fixture'](repo)
    model=source['operators'](geo,area,length)
    assert sha(source['packed'](model))==p['identity']['exact_built_operator_sha256']
    assert all(p['identity'][key]==value for key,value in identity.items() if key!='geometry_archive')
    assert p['identity']['geometry_archive']==list(identity['geometry_archive'])
    with source['archived'](repo,source['MVT']) as z:
        assert {name:sha(z.read(name+'.py')) for name in ('Operators','Reequilibrate')}==p['identity']['solver_source_sha256']
    ray=p['ray_N_Nmm']
    reconstructed=[fsum(v*b[j] for v,b in zip(ray,model['L'],strict=True)) for j in range(60)]
    assert max(abs(a-float(b)) for a,b in zip(reconstructed,logged['EXTERNAL_ROWS'],strict=True))<2e-14
    assert p['started_from_virgin'] and p['premature_stop'] is None and not p['physical_limit_established']
    ar=p['accepted_targets']; assert len(ar)==p['cold_replay_with_uncommitted_excursions']==6
    assert [s['lambda'] for s in ar]==list(source['TARGETS'])
    assert p['runtime']=='3.8.0' and p['numpy']=='2.3.5'
    assert p['weak_rows']==56 and p['gauge_rows']==4 and p['signed_force_rows']==6
    assert len(geo)==43 and tuple(ray)==source['RAY']
    material_path=repo/'tools/validate_opensees_hardshear.py'
    assert sha(material_path.read_bytes())==p['match_to_archived_material_source_sha256']==source['MATERIAL']
    material=p['material_command']; assert material[:3]==['ASDConcrete3D',30000.,.2] and material[-1]=='-tangent'
    indices=[material.index(leaf) for leaf in ('-Te','-Ts','-Td','-Ce','-Cs','-Cd','-tangent')]
    tables=[material[a+1:b] for a,b in zip(indices,indices[1:])]
    te,ts,td,ce,cs,cd=tables
    assert len(te)==len(ts)==len(td) and len(ce)==len(cs)==len(cd)
    assert te[-1]==p['curve_end_ordinates'][0] and ce[-1]==p['curve_end_ordinates'][1]
    assert all(a<b for e in (te,ce) for a,b in zip(e,e[1:]))
    assert max(ts)==3. and max(cs)==30.
    compared={float(row[2]):1000.*float(row[6])/length for row in native_rows[1:3]}
    details=[]
    for item in ar:
        lam=item['lambda'];field=item['field']; net=item['net_stress_MPa']; steel=item['steel_stress_MPa']
        assert len(field)==60 and len(net)==3 and all(len(s)==43 and all(len(row)==6 for row in s) for s in net)
        independently=source['verify_rows'](geo,dirs,area,length,model,field,net,lam,steel)
        assert independently==item['independent']
        ns=independently['combined_norm_MPa']; tau=independently['original_tolerance_MPa']
        assert ns<1e-9<tau
        twist=1000.*field[3]/length
        result={'lambda':lam,'twist_rad_per_m':twist,'all60_plus_six_max_MPa':ns,'original_tolerance_MPa':tau,
                'maximum_steel_stress_MPa':max(abs(s) for side in steel for s in side),
                'signed_six_N_Nmm':independently['signed_six']}
        if lam in compared:
            assert abs(compared[lam]-twist)<2e-10
            result.update({'archived_NDM_twist_rad_per_m':compared[lam], 'twist_difference_rad_per_m':twist-compared[lam]})
        details.append(result)
    return {'status':'PASS','virgin_matched_ASDConcrete3D_coarse':[25,2,16],
            'no_historical_field_used_as_seed':True,'verified_material_history_again_on_virgin_replay':len(ar),
            'operator_sha256':p['identity']['exact_built_operator_sha256'],'native_stress_wire_sha256':WIRE,
            'matched_curve_parameter_vector_sha256':sha(source['packed'](material)),
            'accepted_targets':details,'weak_equations':56,'kinematic_gauges':4,'signed_force_equations':6,
            'validated_up_to_lambda':details[-1]['lambda'],'nonlinear_section_peak_or_physical_limit_established':False}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd()); parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    result=main(args.repo)
    payload=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if args.report:
        with args.report.open('xb') as f: f.write(payload)
    print('HARDSHEAR_MATCHED_ASD_SAME_SECTION_OFFLINE_PASS',sha(payload),result['validated_up_to_lambda'])
