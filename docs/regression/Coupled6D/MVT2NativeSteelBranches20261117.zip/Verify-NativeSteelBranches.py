"""Проверяет нативные варианты пересчёта ветвей стали MVT2 без доверия к статусу Excel."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from tempfile import TemporaryDirectory
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
EARLIER = ('MVT2TabulatedActiveSteel20261117.zip', '12AC8259874E45568C5B04BB110F4C17D18FDEBD617532A30DE34C262B999792')
BOOK = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'
NATIVE = 'Native/MVTGaussMixed.txt'


def digest(raw):
    """Возвращает контрольную сумму отчётных и исходных файлов."""
    return sha256(raw).hexdigest().upper()


def read(file):
    """Читает UTF-8 квитанцию с необязательной отметкой начала."""
    return json.loads(file.read_text('utf-8-sig'))


def bundled(z, name):
    """Подключает скалярное вычисление из закреплённого пакета."""
    env = {'__name__':'__pinned__','__file__':name}
    exec(compile(z.read(name),name,'exec'),env)
    return env


def ownership(path):
    """Сверяет изолированность сборки, проверку ресурсов и выход обоих своих процессов."""
    stage=read(path/'Preparation.json')
    assert stage['source_book_sha256']==BOOK
    assert stage['active_branch_correction'] and stage['private_commit_reserve_GiB']==6
    for file,expected in stage['inputs'].items():
        if (path/file).exists(): assert digest((path/file).read_bytes())==expected, file
    compiler=read(path/'CodeUpdate.json')
    modules={'CCoupledSectionQuadrature','CCoupledElasticState','modTestMVT2GaussSpan','CCoupledConcreteResponse',
             'CTestConcreteBackbone','CTestTabulatedConcreteFlow','CCoupledNewtonSolver','CCoupledReinforcedResponse',
             'CCoupledSteelCorrection'}
    assert compiler['Compiled'] and not compiler['ProductionChanged'] and compiler['ProductionSHA256']==BOOK
    assert set(compiler['Modules'])==modules
    log=(path/NATIVE).read_text('utf-8-sig')
    assert 'RUNTIME ERROR:' not in log and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
    owner=read(path/(NATIVE+'.Ownership.json'))
    assert compiler['WorkbookSHA256']==owner['SourceSHA256'] and owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    trust=read(path/(NATIVE+'.ProcessClosure.json'))
    assert trust['Passed'] and trust['RunnerCleanupValid'] and trust['Stage']=='AFTER_CHILD_EXIT'
    identity=trust['Closure']['Identity']
    assert identity['Valid'] and identity['PID']==owner['PID'] and identity['Ticks']==int(owner['StartTicksUTC'])
    assert trust['Closure']['FinalState']['State']=='Absent'
    earlier=read(path/'CompileClosure.json')
    assert earlier['State']=='Absent' and earlier['PID']!=owner['PID']
    reserves=read(path/(NATIVE+'.memory.json'))
    assert reserves['Ready'] and reserves['FreeCommitGiB']>=reserves['RequiredCommitGiB']==6
    stages=[json.loads(line) for line in (path/'Run.ndjson').read_text('utf-8-sig').splitlines()]
    assert len(stages)==2 and all(x['freeCommitGiB']>=6 and x['ramMiB']>=6500 for x in stages)
    assert all(e['ProtectedUser'] and e['Id'] not in (owner['PID'],earlier['PID']) for x in stages for e in x['excel'])
    return stage


def variant(path, keys, reference):
    """Проверяет вход, все фактически принятые поля и исход отклонённой силовой пробы."""
    meta=ownership(path)
    assert (meta.get('concrete_field_difference',False),meta.get('deep_damping',False),
            meta.get('hybrid_tangent',False))==keys
    evidence,tools,old,old_frames,mesh,support,eq=reference
    native=path/'Native'
    tables=tools['read_operators']((native/'Operators.csv').read_bytes())
    frames=tools['read_tensor_frames']((native/'MVTGaussMixed.Tensor.csv').read_bytes(),45)
    assert all(old[key]==tables[key] for key in 'GLBSR')
    early=[label for label,(_,q,_) in old_frames.items() if q<=72500.]
    assert all(old_frames[label]==frames[label] and old['F'][label]==tables['F'][label] for label in early)
    trace=(native/'MVTGaussMixed.csv').read_text('cp1251')
    seed_path=path/'ActiveSteel.Seeds.csv'
    offered=re.findall(r'^MVT2_ACTIVE_STEEL_SEED;([^\n]+)$',trace,re.M)
    if keys[-1]:
        assert meta['last_seed_Qy_N'] is None and not seed_path.is_file() and not offered
        script=(path/'tests/modTestMVT2GaussSpan.bas').read_text('utf-8-sig')
        assert 'ReadActiveSteelSeedTest' not in script and 'initialField:=' not in script
    else:
        seed=seed_path.read_bytes().decode('ascii').splitlines()
        assert meta['last_seed_Qy_N']==72812.5 and len(seed)==1
        assert tuple(map(float,seed[0].split(';')))==(72812.5,*old['F']['S32A72812.5'])
        assert offered==['S32;72812.5;True']
    result,seconds=re.findall(r'^CASE_FINISHED;MVTGaussMixed;(True|False);([^\n]+)',trace,re.M)[0]
    trials=[]
    for row in trace.splitlines():
        if row.startswith('MVT2_CUT_TRIAL;'):
            label,t,q,m,solved,internal,code,detail=row.split(';',8)[1:]
            q=float(q)
            assert q>0. and (float(t),float(m))==(10510000.,-396.*q)
            m=re.match(r'Итерации: (\d+); пробы: (\d+); невязка, МПа: ([0-9.Ee+-]+);',detail)
            assert m and (internal,code)==(('4','0') if solved=='True' else ('6','10'))
            rebuilt=re.search(r'пересборок ветвей стали: (\d+)',detail)
            full=re.search(r'разностных бетонных касательных по полю: (\d+)',detail)
            trials.append({'label':label,'Qy_N':q,'success':solved=='True','iterations':int(m[1]),
                           'probes':int(m[2]),'norm_MPa':float(m[3]),'rebuilt':int(rebuilt[1]) if rebuilt else 0,
                           'field_tangents':int(full[1]) if full else 0})
    assert [x['Qy_N'] for x in trials]==meta['requested_Qy_N'][:len(trials)]
    assert [x['success'] for x in trials[:-1]]==[True]*(len(trials)-1)
    assert (result=='True')==trials[-1]['success'] and (result=='True')==(len(trials)==len(meta['requested_Qy_N']) and all(x['success'] for x in trials))
    assert [frames[x['label']][1] for x in trials if x['success']]==[x['Qy_N'] for x in trials if x['success']]
    assert len(frames)==sum(x['success'] for x in trials)+9
    original_first=dict.fromkeys([(s,p) for s in (0,1,-1) for p in mesh[1]],((0.,)*6,(0.,)*6,(0.,0.),0.))
    history=original_first
    balance=[]
    tensor_error=0.
    for phase,frame in frames.items():
        field=tables['F'][phase]
        history,net,_=evidence['material'](field,tables,mesh[1],support,history)
        if phase.startswith('R'): continue
        tensor_error=max(tensor_error,*(abs(a-b) for (s,p),tensor in net.items() for a,b in
                         zip(tensor,tables['H'][phase,s,p],strict=True)))
        checked=eq(phase,frame,tables,mesh)
        balance.append((frame[1],max(checked[k] for k in ('weak_MPa','gauge_MPa','resultant_MPa')),
                        checked['tolerance_MPa'],1e3*field[3]/mesh[0][3]))
    assert tensor_error<8e-7
    return {'macro_seconds':float(seconds),'late_trials':[x for x in trials if x['Qy_N']>=72812.5],
            'mixed':len(balance),'last_balance':balance[-1],'max_net_tensor_error_MPa':tensor_error}


def verify(repo, root, temp):
    """Воспроизводит все варианты с одной геометрией и общим префиксом состояний."""
    d=repo/'docs/regression/Coupled6D'/EARLIER[0]
    assert digest(d.read_bytes())==EARLIER[1]
    with ZipFile(d) as z: evidence=bundled(z,'Verify-MVT2TabulatedContinuation.py')
    old,frames,mesh,support,eq=evidence['load'](repo,temp)
    with evidence['archive'](repo,evidence['OPERATORS']) as source:
        tools=bundled(source,'Verify-NativeFollow.py')['read_references'](repo)[0]
    reference=evidence,tools,old,frames,mesh,support,eq
    cases={'Local': (False,False,False), 'Field':(True,False,False), 'DeepField':(True,True,False),
           'DeepLocal':(False,True,False), 'ColdHybrid':(True,True,True)}
    proof={name:variant(root/name,flags,reference) for name,flags in cases.items()}
    expected={'Local':72812.5, 'Field':72812.5, 'DeepField':77625., 'DeepLocal':75312.5, 'ColdHybrid':77625.}
    assert {name:data['last_balance'][0] for name,data in proof.items()}==expected
    late=proof['ColdHybrid']['late_trials'][1:]
    assert [row['Qy_N'] for row in late if row['field_tangents']]==[76000.]
    assert sum(row['probes'] for row in late)==244
    return proof


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    with TemporaryDirectory(dir=args.out.resolve().parent) as tmp:
        proof=verify(args.repo,args.root,Path(tmp))
    args.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode('utf-8'))
    print('MVT2 NATIVE STEEL BRANCHES PASS',len(proof),*(r['last_balance'][0] for r in proof.values()))
