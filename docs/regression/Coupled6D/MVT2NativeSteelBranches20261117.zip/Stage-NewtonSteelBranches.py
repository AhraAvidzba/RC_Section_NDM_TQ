"""Готовит нативную проверку поправки Ньютона на переходе арматуры в текучесть."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent
NEWTON = 'src/Solver/CCoupledNewtonSolver.cls'
CORRECTION = 'src/Solver/CCoupledSteelCorrection.cls'
RESPONSE = 'src/Materials/CCoupledReinforcedResponse.cls'

READ_TRIAL = '''    For j = 1 To COMPONENT_COUNT
        axialStrain = axialStrain + mDirection(j, point) * strain(j)
    Next j
    mSteel(point).EvaluateTrial axialStrain, mPlastic(point, mAcceptedBuffer), mBackstress(point, mAcceptedBuffer), _
        axialStress, axialTangent, plastic, backstress'''

NEWTON_SUPPORT = '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Включает опытную поправку только в заданной части силового маршрута.
Friend Sub TestEnableSteelBranchCorrection()
    mTestSteelBranchCorrection = True
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Пересматривает участки стали при наличии трёх армированных откликов.
Private Sub RefineSteelBranchesTest(ByRef field() As Double, ByRef correction() As Double)
    If Not mUseSpatialHistory Then Exit Sub
    If Not TypeOf mResponse Is CCoupledReinforcedResponse Then Exit Sub
    If Not TypeOf mPlusResponse Is CCoupledReinforcedResponse Then Exit Sub
    If Not TypeOf mMinusResponse Is CCoupledReinforcedResponse Then Exit Sub
    Dim center As CCoupledReinforcedResponse, plus As CCoupledReinforcedResponse, minus As CCoupledReinforcedResponse
    Dim optimizer As New CCoupledSteelCorrection
    Set center = mResponse: Set plus = mPlusResponse: Set minus = mMinusResponse
    mTestSteelBranchBuilds = mTestSteelBranchBuilds + optimizer.Refine(mSection, center, plus, minus, _
        SPATIAL_HALF_STEP, field, mMatrix, mResidual, correction)
End Sub
'''

CONCRETE_TANGENT = '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Дифференцирует вклад бетона по всему полю, читая три принятые истории.
Private Function BuildConcreteFieldTangentTest(ByRef field() As Double, ByVal center As CCoupledReinforcedResponse, _
        ByVal plus As CCoupledReinforcedResponse, ByVal minus As CCoupledReinforcedResponse, _
        ByRef matrix() As Double) As Boolean
    Const h As Double = 0.000000002
    Dim oldResidual() As Double, oldResultants() As Double, oldFailure As ESolverFailureCode, oldPoint As Long
    Dim candidate() As Double, right() As Double, col As Long, row As Long
    Dim testError As Long, testSource As String, testMessage As String
    oldResidual = mResidual: oldResultants = mTrialResultants: oldFailure = mFailureCode: oldPoint = mMaterialPoint
    candidate = field
    ReDim matrix(1 To mDegreeCount, 1 To mDegreeCount)
    center.TestConcreteOnly True: plus.TestConcreteOnly True: minus.TestConcreteOnly True
    On Error GoTo Failed
    For col = 1 To mDegreeCount
        candidate(col) = field(col) + h
        If Not Evaluate(candidate, False, recordTrial:=False) Then GoTo Restore
        right = mResidual
        candidate(col) = field(col) - h
        If Not Evaluate(candidate, False, recordTrial:=False) Then GoTo Restore
        For row = 1 To mDegreeCount: matrix(col, row) = (right(row) - mResidual(row)) / (2# * h): Next row
        candidate(col) = field(col)
    Next col
    BuildConcreteFieldTangentTest = True
Restore:
    center.TestConcreteOnly False: plus.TestConcreteOnly False: minus.TestConcreteOnly False
    mResidual = oldResidual: mTrialResultants = oldResultants: mFailureCode = oldFailure: mMaterialPoint = oldPoint
    If testError <> 0 Then Err.Raise testError, testSource, testMessage
    Exit Function
Failed:
    testError = Err.Number: testSource = Err.Source: testMessage = Err.Description
    Resume Restore
End Function
'''

RESPONSE_SUPPORT = '''

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выделяет вклад бетона для полной разностной касательной. Проба только читающая.
Friend Sub TestConcreteOnly(ByVal concreteOnly As Boolean)
    mTestConcreteOnly = concreteOnly
End Sub
'''


def apply_newton(stock, once, concrete_difference, deep_damping, hybrid):
    """Добавляет только инструментированное уточнение на силовом шаге."""
    tag='Private mCandidateReady As Boolean'
    code=once(stock,tag,tag+'\nPrivate mTestSteelBranchCorrection As Boolean\nPrivate mTestSteelBranchBuilds As Long')
    tag='    mIterations = 0: mEvaluations = 0: mMaterialPoint = 0: mGradientBuilds = 0'
    code=once(code,tag,tag+'\n    mTestSteelBranchBuilds = 0')
    tag='        mMinimumPivot = mSystem.MinimumPivot\n        If mControlActive And (useGradientTangent Or mUseSpatialHistory) Then'
    code=once(code,tag,'''        mMinimumPivot = mSystem.MinimumPivot
        If mTestSteelBranchCorrection And Not mControlActive Then RefineSteelBranchesTest current, correction
        If mControlActive And (useGradientTangent Or mUseSpatialHistory) Then''')
    tag='    If mSameControlRecoveryTried Then DiagnosticSummary'
    code=once(code,tag,'''    If mTestSteelBranchBuilds > 0 Then DiagnosticSummary = DiagnosticSummary & _
        "; пересборок ветвей стали: " & CStr(mTestSteelBranchBuilds)
'''+tag)
    if deep_damping:
        tag='        Do While fraction >= MIN_FRACTION'
        code=once(code,tag,'''        Dim lowerFraction As Double
        lowerFraction = MIN_FRACTION
        If mTestSteelBranchCorrection And Not mControlActive Then lowerFraction = 0.000244140625
        Do While fraction >= lowerFraction''')
    extra=NEWTON_SUPPORT
    if concrete_difference:
        tag='Private mTestSteelBranchBuilds As Long'
        code=once(code,tag,tag+'\nPrivate mTestConcreteFieldBuilds As Long')
        tag='    mTestSteelBranchBuilds = 0'
        code=once(code,tag,tag+'\n    mTestConcreteFieldBuilds = 0')
        tag='    If mTestSteelBranchBuilds > 0 Then DiagnosticSummary'
        code=once(code,tag,'''    If mTestConcreteFieldBuilds > 0 Then DiagnosticSummary = DiagnosticSummary & _
        "; разностных бетонных касательных по полю: " & CStr(mTestConcreteFieldBuilds)
'''+tag)
        tag='    mTestSteelBranchBuilds = mTestSteelBranchBuilds + optimizer.Refine(mSection, center, plus, minus, _\n        SPATIAL_HALF_STEP, field, mMatrix, mResidual, correction)'
        extra=once(extra,tag,'''    Dim concrete() As Double
    If Not BuildConcreteFieldTangentTest(field, center, plus, minus, concrete) Then Exit Sub
    mTestConcreteFieldBuilds = mTestConcreteFieldBuilds + 1
    mTestSteelBranchBuilds = mTestSteelBranchBuilds + optimizer.Refine(mSection, center, plus, minus, _
        SPATIAL_HALF_STEP, field, concrete, mResidual, correction, concreteMatrix:=True)''')
        extra+=CONCRETE_TANGENT
    if hybrid:
        assert concrete_difference
        code=once(code,'    Do\nRecomputeTangent:', '    Dim testFullBranchTangent As Boolean\n    Do\nRecomputeTangent:')
        tag='Then RefineSteelBranchesTest current, correction'
        code=once(code,tag,tag+', testFullBranchTangent')
        tag='        If Not accepted Then\n            If Not mUseSpatialHistory'
        code=once(code,tag,'''        If Not accepted Then
            If mTestSteelBranchCorrection And Not mControlActive And Not testFullBranchTangent Then
                testFullBranchTangent = True
                GoTo RecomputeTangent
            End If
            If Not mUseSpatialHistory''')
        tag='        current = mCandidate\n        currentLambda = candidateLambda'
        code=once(code,tag,'        testFullBranchTangent = False\n'+tag)
        tag='Private Sub RefineSteelBranchesTest(ByRef field() As Double, ByRef correction() As Double)'
        extra=once(extra,tag,'Private Sub RefineSteelBranchesTest(ByRef field() As Double, ByRef correction() As Double, _\n        ByVal fullTangent As Boolean)')
        tag='    Dim concrete() As Double\n    If Not BuildConcreteFieldTangentTest'
        extra=once(extra,tag,'''    If Not fullTangent Then
        mTestSteelBranchBuilds = mTestSteelBranchBuilds + optimizer.Refine(mSection, center, plus, minus, _
            SPATIAL_HALF_STEP, field, mMatrix, mResidual, correction)
        Exit Sub
    End If
'''+tag)
    return code+extra


def stage(repo, root, pid, ticks, enabled, concrete_difference, deep_damping, cold, hybrid):
    """Строит одну копию маршрута с начальным полем только при 72,8125 кН."""
    prior=run_path(str(HERE/'Stage-ActiveSteelMVT2.py'))
    prior['prepare'](repo,root,pid,ticks)
    base=run_path(str(HERE/'Stage-TabulatedFlowNative.py'))
    test=root/base['TEST']
    code=test.read_text('utf-8-sig')
    seed_file=root/prior['SEEDS']
    if cold:
        start=code.index('        Dim guess As Variant, hasSeed As Boolean\n')
        stop=code.index('        Set meta = solver.ResultMeta\n',start)
        probe='        solved = solver.TryStep(0#, expected(2), 0#, TORQUE, 0#, qy, atol, rtol, MAX_ITERATIONS)\n'
        if enabled:
            probe='        If qy > 72812.5 Then solver.TestEnableSteelBranchCorrection\n'+probe
        assert code.endswith(prior['READ_SEED'])
        code=code[:start]+probe+code[stop:-len(prior['READ_SEED'])]
        seed_file.unlink()
    else:
        code=base['once'](code,'        If qy > 72500# Then\n            hasSeed = ReadActiveSteelSeedTest(qy, guess)',
                          '        If qy = 72812.5 Then\n            hasSeed = ReadActiveSteelSeedTest(qy, guess)')
        if enabled:
            tag='        hasSeed = False'
            code=base['once'](code,tag,tag+'\n        If qy > 72812.5 Then solver.TestEnableSteelBranchCorrection')
        seed_file.write_bytes(seed_file.read_bytes().split(b'\r\n')[0]+b'\r\n')
    tag='        If Not hasSeed And Not solved And meta.InternalStatus = rsNumericalFailure Then'
    code=base['once'](code,tag,'        If qy <= 72500# And Not solved And meta.InternalStatus = rsNumericalFailure Then')
    base['writes'](test,code,bom=True)
    added=[]
    if enabled:
        for name in (NEWTON,CORRECTION,RESPONSE):
            path=root/name
            path.parent.mkdir(exist_ok=True)
            if name==CORRECTION:
                code=(HERE/path.name).read_text('utf-8')
            elif name==NEWTON:
                code=apply_newton((repo/name).read_text('utf-8-sig'),base['once'],concrete_difference,deep_damping,hybrid)
            else:
                code=base['once']((repo/name).read_text('utf-8-sig'),READ_TRIAL,
                                  '    ReadSteelTrial point, strain, axialStrain, axialStress, axialTangent, plastic, backstress')
                code+=(HERE/'ActiveSteelResponse.cls.txt').read_text('utf-8')
                if concrete_difference:
                    code=base['once'](code,'Option Explicit','Option Explicit\n\nPrivate mTestConcreteOnly As Boolean')
                    marker='    Dim j As Long, k As Long, axialStrain As Double, axialStress As Double, axialTangent As Double'
                    code=base['once'](code,marker,'''    If mTestConcreteOnly Then
        Dim component As Long
        For component = 1 To COMPONENT_COUNT: stress(component) = -stress(component): Next component
        Exit Function
    End If
'''+marker)+RESPONSE_SUPPORT
            base['writes'](path,code,bom=True)
            added.append(name)
        driver=root/'Run-Native.ps1'
        code=driver.read_text('utf-8')
        marker="'CTestTabulatedConcreteFlow')"
        names=','.join("'"+Path(name).stem+"'" for name in added)
        code=base['once'](code,marker,marker[:-1]+','+names+')')
        driver.write_bytes(code.encode('utf-8'))
    manifest=root/'Preparation.json'
    prep=json.loads(manifest.read_bytes())
    prep['force_schedule']='ActiveSteelNativeSolver'
    prep['active_branch_correction']=enabled
    prep['concrete_field_difference']=concrete_difference
    prep['deep_damping']=deep_damping
    prep['hybrid_tangent']=hybrid
    prep['last_seed_Qy_N']=None if cold else 72812.5
    names=(base['TEST'],'Run-Native.ps1',*added)
    if cold:
        prep['inputs'].pop(prior['SEEDS'])
    else:
        names+=(prior['SEEDS'],)
    prep['inputs'].update({name:base['digest']((root/name).read_bytes()) for name in names})
    manifest.write_bytes((json.dumps(prep,indent=2)+'\n').encode())


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=Path.cwd())
    p.add_argument('--stage', type=Path, required=True)
    p.add_argument('--guard-pid', type=int, required=True)
    p.add_argument('--guard-ticks', type=int, required=True)
    p.add_argument('--control',action='store_true')
    p.add_argument('--concrete-field-difference',action='store_true')
    p.add_argument('--deep-damping',action='store_true')
    p.add_argument('--cold',action='store_true')
    p.add_argument('--hybrid',action='store_true')
    args=p.parse_args()
    stage(args.repo.resolve(),args.stage.resolve(),args.guard_pid,args.guard_ticks,not args.control,args.concrete_field_difference,
          args.deep_damping,args.cold,args.hybrid)
