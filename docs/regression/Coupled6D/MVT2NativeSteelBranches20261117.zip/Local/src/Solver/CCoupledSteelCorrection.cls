﻿VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CCoupledSteelCorrection"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' ==========================================================================
' Поправка Ньютона при смене ветвей стали на продольных станциях
' ==========================================================================
' Действует для силового шага с тремя независимыми историями. Бетонная
' касательная фиксирована, арматура пересматривается от принятой истории.

Private Const COMPONENT_COUNT As Long = 6
Private Const BRANCH_ATTEMPTS As Long = 8

Private Type TSteelStation
    AxialStrain As Double
    Stress As Double
    Tangent As Double
    Branch As Long
End Type

' Уточняет направление на силовом шаге. При отсутствии смены ветвей
' сохраняет штатную поправку. Сходимость уточнённого направления проверяет
' вызывающий по полному отклику бетона и стали и по всем шести усилиям.
Friend Function Refine(ByVal section As CCoupledElasticState, ByVal center As CCoupledReinforcedResponse, _
        ByVal positive As CCoupledReinforcedResponse, ByVal negative As CCoupledReinforcedResponse, _
        ByVal halfStep As Double, ByRef field() As Double, ByRef matrix() As Double, ByRef residual() As Double, _
        ByRef correction() As Double) As Long
    Dim first As Long, last As Long, size As Long
    first = section.ConcretePointCount + 1: last = section.PointCount: size = UBound(residual)
    If first > last Then Exit Function
    Dim response(-1 To 1) As CCoupledReinforcedResponse, base() As TSteelStation, priorMask() As Long
    Set response(0) = center: Set response(1) = positive: Set response(-1) = negative
    ReDim base(first To last, -1 To 1), priorMask(first To last, -1 To 1)
    Dim point As Long, side As Long, i As Long, j As Long, iteration As Long
    Dim direction(1 To COMPONENT_COUNT) As Double, strain(1 To COMPONENT_COUNT) As Double
    Dim gradient(1 To COMPONENT_COUNT) As Double, stationStrain(1 To COMPONENT_COUNT) As Double
    For point = first To last
        section.PointStrain point, field, strain
        section.AxialGradientAtPoint point, field, gradient
        For side = -1 To 1
            For i = 1 To COMPONENT_COUNT: stationStrain(i) = strain(i) + side * halfStep * gradient(i): Next i
            ReadBranch response(side), point, stationStrain, base(point, side)
            priorMask(point, side) = base(point, side).Branch
        Next side
    Next point

    Dim candidate() As Double, adjusted() As Double, linearized() As Double, linear As CCoupledLinearSystem
    Dim changed As Boolean, maskChanged As Boolean, pointChanged As Boolean, predicted As TSteelStation
    Dim intercept(-1 To 1) As Double, slope(-1 To 1) As Double, projection As Double
    Dim stress(1 To COMPONENT_COUNT) As Double, stressGradient(1 To COMPONENT_COUNT) As Double
    Dim tangent(1 To COMPONENT_COUNT, 1 To COMPONENT_COUNT) As Double
    Dim strainTangent(1 To COMPONENT_COUNT, 1 To COMPONENT_COUNT) As Double
    Dim slopeTangent(1 To COMPONENT_COUNT, 1 To COMPONENT_COUNT) As Double
    Dim unusedResultants(1 To COMPONENT_COUNT) As Double
    ReDim candidate(1 To size)
    For iteration = 1 To BRANCH_ATTEMPTS
        For i = 1 To size: candidate(i) = field(i) + correction(i): Next i
        changed = False: maskChanged = False
        For point = first To last
            section.PointStrain point, candidate, strain
            section.AxialGradientAtPoint point, candidate, gradient
            pointChanged = False
            For side = -1 To 1
                For i = 1 To COMPONENT_COUNT: stationStrain(i) = strain(i) + side * halfStep * gradient(i): Next i
                ReadBranch response(side), point, stationStrain, predicted
                If priorMask(point, side) <> predicted.Branch Then maskChanged = True
                priorMask(point, side) = predicted.Branch
                intercept(side) = 0#: slope(side) = 0#
                If base(point, side).Branch <> predicted.Branch Then
                    slope(side) = predicted.Tangent - base(point, side).Tangent
                    intercept(side) = predicted.Stress - base(point, side).Stress - _
                        predicted.Tangent * (predicted.AxialStrain - base(point, side).AxialStrain)
                    pointChanged = True ' Сдвигает свободный член к выбранному участку диаграммы.
                End If
            Next side
            If pointChanged Then
                If Not changed Then
                    adjusted = residual: linearized = matrix
                    changed = True
                End If
                section.SteelProjection point, direction
                For j = 1 To COMPONENT_COUNT
                    stress(j) = intercept(0) * direction(j)
                    stressGradient(j) = (intercept(1) - intercept(-1)) * direction(j) / (2# * halfStep)
                    For i = 1 To COMPONENT_COUNT
                        projection = direction(i) * direction(j)
                        tangent(i, j) = projection * slope(0)
                        strainTangent(i, j) = projection * (slope(1) - slope(-1)) / (2# * halfStep)
                        slopeTangent(i, j) = projection * 0.5 * (slope(1) + slope(-1))
                    Next i
                Next j
                section.AddSpatialPointEquilibrium point, stress, tangent, stressGradient, strainTangent, _
                    slopeTangent, adjusted, linearized, True, unusedResultants
            End If
        Next point
        If Not changed Or Not maskChanged Then Exit Function
        If linear Is Nothing Then Set linear = New CCoupledLinearSystem
        For i = 1 To size: adjusted(i) = -adjusted(i): Next i
        If Not linear.Solve(linearized, adjusted, size) Then Exit Function
        correction = adjusted
        Refine = Refine + 1
    Next iteration
End Function

' Заполняет копию скалярного отклика и знаковый номер участка диаграммы.
Private Sub ReadBranch(ByVal response As CCoupledReinforcedResponse, ByVal point As Long, _
        ByRef strain() As Double, ByRef station As TSteelStation)
    station.Branch = response.ReadSteelBranch(point, strain, station.AxialStrain, station.Stress, station.Tangent)
End Sub
