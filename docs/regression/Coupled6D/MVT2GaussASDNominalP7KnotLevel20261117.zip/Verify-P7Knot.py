"""Offline replay of the exact p7 tensile equivalent strain constraint."""
from argparse import ArgumentParser
from hashlib import sha256
from math import ulp
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WIRE='013E60B81278A070AAED99D6661FB0652E168CED98F7DEE8CEFDF8110C1D6F1C'
OLD=('MVT2GaussASDNominalP7Adjacent20261117','7DB48539D21CF598DC15FE1A6BB996479B6375DDA9EE658662C8B8AACA6B2EB8')


def sha(b):
    return sha256(b).hexdigest().upper()


def open_archive(repo,identity):
    name,pin=identity
    path=repo/'docs/regression/Coupled6D'/(name+'.zip')
    assert sha(path.read_bytes())==pin
    return ZipFile(path)


def independent(data,old,anchor,shape,adjacent,watch,past,guard,op,geo,area,length):
    assert data['exact_H53']==data['accepted_history_after']==anchor['history_after']==53
    before=anchor['candidate']; target=data['target']; used=data['candidate']; plan=data['plan']
    assert data['start_field']==before['field'] and data['start_section']==before['section']
    assert data['start_all66']==before['all66'] and data['start_markers']==before['markers']
    assert data['same_material']==anchor['same_material'] and target==[0.,-33140625.,0.,10510000.,0.,55234.375]
    assert data['status']=='reduced_uncommitted_original_residual' and used['signed_check_and_trust']
    x=data['start_field']; y=used['field']; m=data['start_markers']
    d=plan['delta']; n=plan['minimum_norm_retraction_per_equivalent_strain']
    eq=watch['check_whole']; signed=guard['signed_forces']; tensor=past['tensor']
    delta=adjacent['delta']; err=adjacent['error']; signs=adjacent['signature']; norm=adjacent['norm']
    start=eq(data['start_section'],x,target,op,geo,area,length,signed)
    actual=eq(used['section'],y,target,op,geo,area,length,signed)
    assert abs(start-norm(data['start_all66']))<3e-12 and abs(actual-norm(used['all66']))<3e-12
    assert abs(actual-used['actual_MPa'])<3e-12
    tau=used['section']['tolerance_MPa']
    assert tau==data['start_section']['tolerance_MPa']<actual<start and 4.13<actual/tau<4.14
    predicted,marks,one=adjacent['measured_prediction'](data['finite_difference']['columns'],data['start_all66'],m,d,op)
    assert one==45 and abs(norm(predicted)-plan['predicted_residual'])<5e-15
    assert err(marks,plan['predicted_markers'])<2e-18 and abs(marks[-1]-m[-1])<2e-20
    assert abs(plan['p7_linear_error'])<2e-20
    lock=data['p7_exact_locked_equivalent_strain']; threshold=data['p7_threshold']
    assert threshold==shape['stations'][-1]['events'][0]['threshold']<lock
    assert lock==before['three_p7_states'][-1]['equivalentTotalStrain'][0]
    assert signs(marks)==signs(m)==signs(used['markers'])==[-1.,1.,1.,-1.,-1.,1.]
    assert used['markers'][-1]+threshold==m[-1]+threshold==lock
    assert used['section']['steel_active_flags']==data['start_section']['steel_active_flags']
    for frame,markers in ((data['start_section'],m),(used['section'],used['markers'])):
        for (point,side),f in zip(((20,1),(20,-1),(10,-1)),markers[:3],strict=True):
            value=watch['eigen'](frame['net_stresses_MPa'][(0,1,-1).index(side)][point-1])[1]
            assert abs(value-f)<2e-13 and signs([value])==signs([f])
    retraction=data['same_step_retraction']; beta=retraction['retracted_beta']
    assert retraction['two_ulp_epsilon_verification']==2.*ulp(lock) and retraction['anchor_equivalent_strain']==lock
    samples=retraction['normal_projections']
    assert len(samples)==3 and samples[0][0]==0. and samples[0][1]<0.<samples[1][1]
    assert samples[2][0]==beta and samples[2][1]==0.
    assert y==[a+step+beta*b for a,step,b in zip(x,d,n,strict=True)]
    def movement(d):
        return max(abs(value) for p in range(45) for side in (0,1,-1) for value in tensor(op,d,p,side))
    r=data['physical_reserve_for_same_step_retraction']; cap=data['local_total_cap']; absolute=data['cap_from_rejected_center']
    assert r==1e-10 and plan['local_radius_without_retraction']+r==cap==anchor['combined_step_cap']
    assert movement([beta*v for v in n])<r and movement(d)<plan['local_radius_without_retraction']
    actual_move=movement(delta(y,x)); total_move=movement(delta(y,old['first_rejected_trial']))
    assert abs(actual_move-used['local_strain'])<4e-18 and actual_move<cap
    assert abs(total_move-used['cumulative_strain_about_rejected_center'])<4e-18 and total_move<absolute
    assert 0.<start-actual<1e-9 and actual_move/cap<2e-5
    return {'status':'PASS','attempted_Qy_N':target[5],'last_accepted_Qy_N':55156.25,'accepted_history_preserved':53,
            'initial_MPa':start,'predicted_held_knot_MPa':norm(predicted),'actual_held_knot_MPa':actual,
            'original_tolerance_MPa':tau,'multiple_of_tolerance':actual/tau,'true_reduction_MPa':start-actual,
            'exact_p7_equivalent_tensile_strain':lock,'p7_knot':threshold,'p7_knot_offset':lock-threshold,
            'local_engineering_step':actual_move,'local_cap':cap,'total_engineering_step':total_move,
            'actual_signed_six_N_Nmm':used['section']['signed_6'],'branch_indicators':used['markers'],
            'physical_limit_established':False}


def main(repo):
    payload=(HERE/'P7KnotLevelWire.json.gz').read_bytes()
    assert sha(payload)==WIRE
    data=json.loads(gzip.decompress(payload))
    with tempfile.TemporaryDirectory(prefix='P7KnotOffline_') as folder, open_archive(repo,OLD) as p:
        root=Path(folder)
        def extract(z,name):
            f=root/name; f.write_bytes(z.read(name)); return runpy.run_path(str(f))
        adj=extract(p,'Verify-P7Adjacent.py')
        raw=p.read('P7AdjacentWire.json.gz'); shape=p.read('P7AllStationsWire.json.gz')
        assert sha(raw)==adj['CORRECTION']==data['source_anchor_sha256'] and sha(shape)==adj['STATION']
        anchor=json.loads(gzip.decompress(raw)); ray=json.loads(gzip.decompress(shape))
        with open_archive(repo,adj['P7']) as z:
            p7=extract(z,'Verify-P7.py')
        with open_archive(repo,p7['EXPANDED']) as z:
            ex=extract(z,'Verify-Expanded.py')
        with open_archive(repo,ex['PREVIOUS']) as z:
            prior=extract(z,'Verify-Cone.py'); old=z.read('ConeWire.json.gz'); assert sha(old)==prior['WIRE']
        with open_archive(repo,prior['STATION']) as z:
            watch=extract(z,'Verify-Stations.py')
        with open_archive(repo,watch['BASE']) as z:
            history=extract(z,'Verify-VectorEvidence.py')
        accepted,residual,_,_,_=history['history'](repo)
        assert accepted['Q_target_N']==55156.25 and residual<accepted['tolerance_MPa']
        with open_archive(repo,history['POST']) as z:
            past=extract(z,'Verify-Postyield.py')
        with open_archive(repo,past['AUTH']) as z:
            for name in ('Verify-Authoritative.py','Operators.py','Reequilibrate.py'):
                (root/name).write_bytes(z.read(name))
        sys.path.insert(0,str(root))
        guard=runpy.run_path(str(root/'Verify-Authoritative.py')); operator,source=guard['unpack'](root,repo)
        program=runpy.run_path(str(root/'Reequilibrate.py'))
        _,_,geo,_,area,length,op,_,_,identity=program['read_inputs'](operator,root,source)
    assert data['operator_source']==identity==anchor['operator_source']
    return independent(data,json.loads(gzip.decompress(old)),anchor,ray,adj,watch,past,guard,op,geo,area,length)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--report',type=Path)
    options=parser.parse_args()
    result=main(options.repo)
    report=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if options.report:
        with options.report.open('xb') as out: out.write(report)
    print('MVT2 EXACT TENSILE KNOT LEVEL OFFLINE PASS',sha(report),result['actual_held_knot_MPa'])
