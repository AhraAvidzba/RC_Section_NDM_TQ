"""One p7 tensile-knot level-set correction with an exact material retraction."""
from math import ulp
from pathlib import Path
from time import perf_counter
import gzip
import importlib.util
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('adjacent',HERE/'Correct-P7Adjacent.py')
adjacent=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(adjacent)
study=adjacent.study
cone=adjacent.cone
expand=adjacent.expand
ANCHOR='3D52877A7D642262B49B65C3A1B604DB5FFC42B7B4745CC9CF29D36B4CB1FFD6'
MAX_RETRACTION=24


def proposal(np,section,start,j,k,radius,physical):
    from scipy.optimize import linprog

    _,r,_,m=start
    rn=float(np.max(np.abs(r)))
    scale=np.divide(radius,physical,out=np.zeros(60),where=physical>0.)
    null=physical==0.
    scale[null]=rn/np.max(np.abs(j[:,null]),axis=0)
    op=j*scale/rn
    u=(section.strain*scale/radius).reshape((-1,60))
    signed=np.sign(m[:5])[:,None]*k[:5]*scale
    mscale=np.maximum(np.abs(m[:5]),np.max(np.abs(signed),axis=1))
    direction=k[-1]*scale
    knot_scale=float(np.max(np.abs(direction)))
    assert knot_scale>0.
    aa=np.vstack((np.c_[op,-np.ones(66)],np.c_[-op,-np.ones(66)],np.c_[u,np.zeros(len(u))],
                  np.c_[-u,np.zeros(len(u))],np.c_[-signed/mscale[:,None],np.zeros(5)]))
    bb=np.r_[-r/rn,r/rn,np.ones(2*len(u)),.5*np.abs(m[:5])/mscale]
    eq=[np.r_[direction/knot_scale,0.]]
    opt=linprog(np.r_[np.zeros(60),1.],A_ub=aa,b_ub=bb,A_eq=eq,b_eq=[0.],
                bounds=[(None,None)]*60+[(0.,None)],method='highs',
                options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    proof={'linear_status':int(opt.status),'local_radius_without_retraction':radius}
    if not opt.success:
        return None,None,proof
    d=opt.x[:60]*scale
    n=scale*direction/(direction@direction)
    assert abs(k[-1]@n-1.)<5e-14
    proof.update({'delta':d.tolist(),'minimum_norm_retraction_per_equivalent_strain':n.tolist(),
                  'predicted_residual':float(np.max(np.abs(r+j@d))),
                  'predicted_markers':(m+k@d).tolist(),'p7_linear_error':float(k[-1]@d),
                  'local_movement':expand.physical(np,section,d)})
    return d,n,proof


def exact_equivalent(section,field):
    tag=1+2*45+6
    section.trial(tag,section.strain[2,6]@field)
    return float(section.ops.NDTest('GetResponse',tag,'equivalentTotalStrain')[0])


def retract(np,section,y,n,target,reserve):
    eps0=exact_equivalent(section,y)
    observed=eps0-target
    numerical=2.*ulp(target)
    result={'anchor_equivalent_strain':target,'initial_proposal_equivalent_strain':eps0,
            'two_ulp_epsilon_verification':numerical,'normal_projections':[]}
    if abs(observed)<=numerical:
        result['retracted_beta']=0.
        return y,result
    # Two times the measured mismatch bounds the Newton normal correction.
    # Verify its signs before using it as a bracket in the true material.
    end=-2.*observed
    if expand.physical(np,section,end*n)>reserve:
        return None,result
    left,right=sorted((0.,end))
    def sample(beta):
        value=exact_equivalent(section,y+beta*n)-target
        result['normal_projections'].append([beta,value])
        return value
    a,b=sample(left),sample(right)
    if not a<=0.<=b:
        return None,result
    for _ in range(MAX_RETRACTION):
        mid=.5*(left+right)
        got=sample(mid)
        if abs(got)<=numerical:
            result['retracted_beta']=mid
            return y+mid*n,result
        if got>=0.:
            right=mid
        else:
            left=mid
    return None,result


def main():
    began=perf_counter()
    old=expand.read_wire('P7AdjacentWire.json.gz',ANCHOR)
    ray=expand.read_wire('P7AllStationsWire.json.gz',adjacent.PIN)
    original,probe,vector,receipt,np,ops,section,material,identity,load=study.exact_fixture()
    assert old['status']=='checked_adjacent_descent_uncommitted' and old['history_after']==53 and identity==old['operator_source']
    threshold=ray['stations'][-1]['events'][0]['threshold']
    before=old['candidate']; x=np.array(before['field']); target=before['three_p7_states'][-1]['equivalentTotalStrain'][0]
    old_cone=expand.read_wire('ConeWire.json.gz',study.follow.PRIOR)
    origin=np.array(old_cone['first_rejected_trial'])
    cap=old['combined_step_cap']; total=old['total_cap_about_rejected_center']
    assert expand.physical(np,section,x-origin)+cap<total
    base=adjacent.current(np,section,x,load,vector,threshold)
    assert probe.raw_section(section,x,load)==before['section'] and base[1].tolist()==before['all66']
    assert base[3].tolist()==before['markers'] and exact_equivalent(section,x)==target>threshold
    mesh=np.max(np.abs(section.strain),axis=(0,1,2))
    j,k,fd=adjacent.finite(np,section,x,load,base,vector,threshold,mesh)
    result={'source_anchor_sha256':ANCHOR,'operator_source':identity,'target':load.tolist(),'cap_from_rejected_center':total,
            'start_field':x.tolist(),'start_markers':base[3].tolist(),'start_all66':base[1].tolist(),
            'start_section':before['section'],'same_material':material,'exact_H53':section.committed,
            'p7_threshold':threshold,'p7_exact_locked_equivalent_strain':target,'local_total_cap':cap,
            'finite_difference':fd,'status':'no_predicted_admissible_improvement'}
    reserve=2.*cone.NORMAL_STATION_STEP
    assert reserve<cap
    result['physical_reserve_for_same_step_retraction']=reserve
    if j is not None:
        d,n,plan=proposal(np,section,base,j,k,cap-reserve,mesh)
        result['plan']=plan
        if d is not None and plan['predicted_residual']<base[0][4]:
            candidate,detail=retract(np,section,x+d,n,target,reserve)
            result['same_step_retraction']=detail
            result['status']='nonlinear_knot_retraction_unavailable'
            if candidate is not None:
                state,rows,steel,marks=adjacent.current(np,section,candidate,load,vector,threshold)
                watch=runpy.run_path(str(cone.PRIOR/'station/Verify-Stations.py'))
                frame=probe.raw_section(section,candidate,load)
                norm=adjacent.follow_norm(section,watch,frame,candidate,load)
                step=expand.physical(np,section,candidate-x); beyond=expand.physical(np,section,candidate-origin)
                acceptable=bool(np.array_equal(np.sign(marks),np.sign(base[3])) and np.array_equal(steel,base[2]) and
                                abs(float(marks[-1])+threshold-target)<=2.*ulp(target) and step<=cap and beyond<=total and norm<base[0][4])
                result['candidate']={'field':candidate.tolist(),'section':frame,'all66':rows.tolist(),'markers':marks.tolist(),
                                     'signed_check_and_trust':acceptable,'actual_MPa':norm,'local_strain':step,
                                     'cumulative_strain_about_rejected_center':beyond}
                result['status']='rejected_true_trial' if not acceptable else (
                    'balanced_uncommitted_original_equilibrium' if max(norm,state[4])<=state[5] else 'reduced_uncommitted_original_residual')
    assert probe.raw_section(section,x,load)==before['section'] and section.committed==53
    result['accepted_history_after']=section.committed
    ops.wipe()
    wire=gzip.compress(vector.raw_json(result),compresslevel=9,mtime=0)
    with (HERE/'P7KnotLevelWire.json.gz').open('xb') as out: out.write(wire)
    print('MVT2 ASD EXACT KNOT LEVEL WIRE',cone.digest(wire),len(wire),'seconds',perf_counter()-began,result['status'])


if __name__=='__main__':
    main()
