"""Проверяет принятую историю и исходные уравнения ограниченной поправки."""

import argparse
import json
from math import fsum, sqrt
from pathlib import Path

import VerifyBase as v


here = Path(__file__).resolve().parent
native = here / "NativeHalf"


def vector(path, size=61):
    [line] = path.read_text(encoding="ascii").splitlines()
    values = tuple(map(float, line.split(";")))
    assert len(values) == size
    return values


def prepare():
    prep = v.read(here / "Preparation.json")
    assert all(v.digest(here / name) == value for name, value in prep["inputs"].items())
    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]
    assert v.digest(here / "Replay.csv") == prep["replay_sha256"]
    previous, stations = v.verified_states(v.read_native(here / "SameRayNative.csv"))
    normal = vector(here / "MVTNormal.csv", 62)
    assert normal[56:60] == (0.,) * 4
    stop = vector(here / "RayStop.csv")
    assert v.peak(v.diff(stop[:60], previous["RayZero"]["field"])) < 5e-16 and abs(stop[60] - previous["RayZero"]["q"]) < 5e-14
    candidate = vector(here / "CorrectionDelta.csv")
    metadata = v.read(here / "CorrectionInput.json")
    assert metadata["candidate_delta_sha256"] == v.digest(here / "CorrectionDelta.csv")
    assert metadata["stop_csv_sha256"] == v.digest(here / "RayStop.csv")
    assert metadata["normal_csv_sha256"] == v.digest(here / "MVTNormal.csv")
    assert metadata["H24_replay_sha256"] == prep["replay_sha256"] and metadata["workbook_sha256"] == prep["book_sha256"]
    assert 0 < metadata["station_frobenius_radius"] <= 1.3e-9
    assert abs(v.dot(normal[:61], candidate)) * v.MODULUS < 5e-12
    return prep, previous, stations, normal, stop, candidate, metadata


def verify(prep, previous, archived_stations, normal, stop, candidate, metadata):
    build = v.read(here / "docs/regression/CodeUpdate.json")
    compiler = v.read(here / "CompileClosure.json")
    owner = v.read(native / "MVT2.txt.Ownership.json")
    watch = v.read(native / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(native / "RunReceipt.json")
    final = watch["Closure"]["FinalState"]
    assert build["Compiled"] and build["Modules"] == ["modTestCoupledExperiment"] and not build["ProductionChanged"]
    assert build["ProductionSHA256"] == prep["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == build["WorkbookSHA256"]
    assert watch["Passed"] and watch["ChildExitCode"] == receipt["native_exit"] == 0 and watch["ChildHasExited"]
    assert final["State"] == "Absent" and final["PID"] == owner["PID"] and final["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    raw = native / "MVT2.csv"
    tags = v.read_native(raw)
    assert tags["B_FRESH_PHASE"] == [["Half"]]
    states, stations = v.verified_states(tags)
    assert set(states) == {"Base24", "Restored24", "RayZero", "Ray50", "Ray100"}
    accepted = {name: tuple(vals) for name, *vals in tags["B_ARC_HISTORY"]}
    assert set(accepted) == {"RayBefore", "Ray50", "Ray100", "RayFinal"}
    assert all(vals == accepted["RayBefore"] and len(vals) == 1080 for vals in accepted.values())
    for name in ("Base24", "Restored24", "RayZero"):
        assert states[name] == previous[name] and stations[name] == archived_stations[name], name

    old = states["RayZero"]
    active = stations["RayZero"]
    target_plane = v.dot(normal[:60], states["Base24"]["field"]) + normal[60] * states["Base24"]["q"] + normal[61] / 64
    base_plane = v.dot(normal[:60], old["field"]) + normal[60] * old["q"] - target_plane
    results = {}
    for fraction, name in ((.5, "Ray50"), (1., "Ray100")):
        state = states[name]
        goal = tuple(base + fraction * delta for base, delta in zip(stop, candidate, strict=True))
        assert v.peak(v.diff(goal[:60], state["field"])) < 5e-15 and abs(goal[60] - state["q"]) < 5e-14
        apparent = v.diff(state["field"], old["field"])
        radius = max(sqrt(fsum(x*x/(1 if i < 3 else 2) for i, x in enumerate(v.strain_at(apparent, v.operators(x, y), s))))
                     for (_, s), (x, y, _) in old["geometry"].items())
        assert radius <= (fraction * metadata["station_frobenius_radius"] + 4e-14)
        rows, forces, _ = v.reconstruct(state["field"], state["q"], stations[name])
        gauge = v.peak(rows[-4:]) * v.MODULUS
        plane = (v.dot(normal[:60], state["field"]) + normal[60] * state["q"] - target_plane) * v.MODULUS
        signed = state["signed_force_N_Nmm"]
        force = max(abs(error) / scale for error, scale in zip(signed, v.SCALES, strict=True))
        weak = v.peak(rows[:56])
        total = max(gauge, abs(plane), force, weak)
        changes = [list(key) for key in active if key[0] <= 25 and
                   (stations[name][key][3:6] != active[key][3:6] or stations[name][key][6] * active[key][6] <= 0)]
        results[name] = {"fraction": fraction, "Qy_kN": state["q"], "force_actual_N_Nmm": forces,
                         "forces_max_MPa": force, "weak_max_MPa": weak, "governing_weak_row": max(range(56), key=lambda i: abs(rows[i]))+1,
                         "weak_row10_MPa": rows[9], "weak_row53_MPa": rows[52],
                         "gauge_max_MPa": gauge, "plane_error_MPa": plane, "actual_norm_MPa": total,
                         "tolerance_MPa": state["tol_MPa"], "correction_radius": radius,
                         "concrete_branch_changes": changes, "equilibrium_at_original_tolerance": total <= state["tol_MPa"]}
    return {"workbook_sha256": prep["book_sha256"], "trace_sha256": v.digest(raw), "frozen_exact_H24": True, "history_published": False,
            "base_norm_MPa": max(old["norm_MPa"], old["gauge_MPa"], abs(base_plane) * v.MODULUS),
            "base_Qy_kN": old["q"], "prediction": metadata, "outcomes": results, "closed": final, "native_seconds": receipt["wall_seconds"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Half"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS", v.digest(here / "Preparation.json"))
    else:
        report = here / "VerificationCorrection.json"
        report.write_bytes((json.dumps(verify(*frozen), indent=2) + "\n").encode())
        print(report, v.digest(report))
