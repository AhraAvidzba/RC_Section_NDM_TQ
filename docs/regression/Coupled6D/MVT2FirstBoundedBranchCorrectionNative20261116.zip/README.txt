First bounded native correction of the MVT2 B stop

From this extracted ZIP run

    python -B -X utf8 ReplayCorrectionPortable.py PATH/MVT2HalfJointJetNative20261116.zip PATH/MVT2SameRayDerivativeNative20261116.zip

The two referenced archives are tracked in docs/regression/Coupled6D.
PortableManifest.json verifies all shared inputs. It uses CandidateReceipt.json
as the identical binary source for CorrectionInput.json, and CorrectionDelta.csv
is copied from the exact 61-value CandidateDelta.csv. The frozen conditioned
candidate report is also included. No workbook binary is in this archive.

The half and full candidate were evaluated from the exact same accepted
H24 history with the original material law, gauges and active pseudo-arc
plane. The maximum full residual dropped from 7.2222573563e-5 to
6.4053920526e-6 MPa. The prediction differs from the observed full value by
4.6611e-12 MPa. The six force residuals, gauges and plane passed their
limits, and none of the checked material branches changed.

Weak row 10 governed the full evaluation at 5.71 times the original
tolerance. Neither fraction is an accepted equilibrium. The accepted H24
history was restored exactly. The last accepted Qy remains 18.55811 kN.
No physical capacity was determined.
