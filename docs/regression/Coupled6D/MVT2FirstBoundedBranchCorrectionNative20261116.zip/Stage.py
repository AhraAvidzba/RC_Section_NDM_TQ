"""Готовит исходную проверку внешней ограниченной поправки MVT2."""

from hashlib import sha256
import json
from pathlib import Path

here = Path(__file__).resolve().parent
repo = here.parents[1]
reference = here.parent / "mvbc"
book = "workbook/output/RC_Section_NDM.xlsm"
test = "tests/modTestCoupledExperiment.bas"
runner = "Run-MVT2ShearControlled.ps1"


def digest(data):
    return sha256(data).hexdigest().upper()


def put(name, raw):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def replace(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


old_raw = (reference / "Preparation.json").read_bytes()
assert digest(old_raw) == "5B7321D7D780840199F52F36450FC1986559AE0D3417D8E08E2525C9B91FE73D"
old = json.loads(old_raw)
base = (repo / book).read_bytes()
assert digest(base) == old["book_sha256"]
put(book, base)
put("docs/regression/Diagnostic.xlsm", base)
for folder in ("src", "Temp", "NativeHalf"):
    (here / folder).mkdir(exist_ok=True)

inputs = {}
for name in ("Replay.csv", "VerifyBase.py", "Guard-IsolatedOffice.ps1", "RayStop.csv", "MVTNormal.csv",
             "SameRayNative.csv", runner, *(name for name in old["inputs"] if name.startswith("tools/"))):
    raw = (reference / name).read_bytes()
    assert digest(raw) == old["inputs"][name]
    inputs[name] = put(name, raw)

source = (reference / test).read_bytes()
assert digest(source) == old["inputs"][test]
module = source.decode("utf-8-sig").replace("\r\n", "\n")
module = replace(module, '    ReadWangRayVectorTest folder & "RayDirection.csv", ray, qray',
                         '    ReadWangRayVectorTest folder & "CorrectionDelta.csv", ray, qray')
module = replace(module, '    ReadWangBranchActionTest output, operators, materials, responses, origin, ray\n', '')
module = replace(module, '    For Each ratio In Array(-0.25, 0.25)', '    For Each ratio In Array(0.5, 1#)')
boundary = "' -------------------- ДЛЯ ТЕСТОВ --------------------"
start = module.rindex(boundary, 0, module.index("Private Sub ReadWangBranchActionTest"))
end = module.rindex(boundary, 0, module.index("Private Sub CaptureWangArcHistoryTest"))
module = module[:start] + module[end:]
inputs[test] = put(test, module.replace("\n", "\r\n").encode("utf-8"))

for name in ("CorrectionDelta.csv", "CorrectionInput.json", "Stage.py", "Verify-MVT2ShearControlled.py"):
    inputs[name] = digest((here / name).read_bytes())
settings = {"inputs": inputs, "book_sha256": digest(base), "replay_sha256": old["replay_sha256"], "watchdog_seconds": 95}
print(put("Preparation.json", (json.dumps(settings, indent=2) + "\n").encode()))
