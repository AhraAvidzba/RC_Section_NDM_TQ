"""Replay exact native bounded correction and its independent constrained input."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import tempfile
from zipfile import ZipFile


root = Path(__file__).resolve().parent
anchors = {
    "jet":"6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33",
    "ray":"E6FCD67D16C2637EF7992AB67CE6DB71AA7E63EE41F15CD33E8CB198A586304D",
}
report_sha = "D0E1E82AF4072FE0A1E402B65B45493FECBB340B937710D912A0E115B210D4A7"
book_sha = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in anchors:
        parser.add_argument(name,type=Path)
    args = parser.parse_args()
    for name, expected in anchors.items():
        assert digest(getattr(args,name).read_bytes()) == expected, name
    catalog = json.loads((root/"PortableManifest.json").read_bytes())
    with (tempfile.TemporaryDirectory() as folder, ZipFile(args.jet) as jet, ZipFile(args.ray) as ray):
        stage = Path(folder)
        archives = {"jet":jet,"ray":ray}
        for name, item in catalog.items():
            source = item.get("archive")
            raw = ((root/item.get("member",name)).read_bytes() if source is None else archives[source].read(item["member"]))
            assert digest(raw) == item["sha256"], name
            dest = stage/name
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(raw)
        receipt = (stage/"CandidateReceipt.json").read_bytes()
        assert receipt == (stage/"CorrectionInput.json").read_bytes()
        metadata = json.loads(receipt)
        assert digest((stage/"CorrectionDelta.csv").read_bytes()) == metadata["candidate_delta_sha256"]
        assert digest((stage/"ConditionedNative.json").read_bytes()) == metadata["conditioned_full_plan_sha256"]
        verifier = stage/"Verify-MVT2ShearControlled.py"
        src = verifier.read_text(encoding="utf-8")
        guard = '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]'
        assert src.count(guard)==1
        src = src.replace(guard,f'    assert prep["book_sha256"] == "{book_sha}"')
        ns = {"__file__":str(verifier),"__name__":"portable_correction"}
        sys.path.insert(0,str(stage))
        try:
            exec(compile(src,str(verifier),"exec"),ns)
            checked = ns["verify"](*ns["prepare"]())
        finally:
            sys.path.pop(0)
        wire = (json.dumps(checked,indent=2)+"\n").encode()
        assert digest(wire) == report_sha and wire == (stage/"VerificationCorrection.json").read_bytes()
        start, outcome = checked["base_norm_MPa"], checked["outcomes"]["Ray100"]
        assert not checked["history_published"] and checked["frozen_exact_H24"]
        assert not any(value["equilibrium_at_original_tolerance"] for value in checked["outcomes"].values())
        assert outcome["concrete_branch_changes"] == []
        assert outcome["forces_max_MPa"] < metadata["force_cap_share_of_tau"] * outcome["tolerance_MPa"]
        print("CANONICAL NATIVE BOUNDED CORRECTION",report_sha)
        print("FULL ORIGINAL RESIDUAL RATIO",outcome["actual_norm_MPa"]/outcome["tolerance_MPa"])
        print("RELATIVE REDUCTION",1-outcome["actual_norm_MPa"]/start)


if __name__ == "__main__":
    main()
