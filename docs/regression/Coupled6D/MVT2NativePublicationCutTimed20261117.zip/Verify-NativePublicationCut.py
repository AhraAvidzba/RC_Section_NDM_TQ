"""Проверяет тензоры Excel MVT2 на плече 396 мм по операторам сечения."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum
from pathlib import Path
from zipfile import ZipFile


ARCHIVE = 'MVT2GaussSpatialOperatorsNative20261117.zip'
ARCHIVE_SHA = '8807822311947EDB91EB483B6FDC8F359F95BCE10F9B36286E12DE7F37932D5A'
ARM = 396.
T = 10510000.
EXTERNAL_SHA = '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD'
BOOK_SHA = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'


def digest(raw):
    return sha256(raw).hexdigest().upper()


def read_operators(raw):
    """Читает независимые действия операторов и принятые тензоры."""
    header, *body = raw.decode('ascii').splitlines()
    assert header == 'SIZE;60;45;0.001'
    tables = {name: {} for name in 'GBLSRFH'}
    for record in body:
        kind, *parts = record.split(';')
        if kind in 'GLF':
            key = parts[0] if kind == 'F' else int(parts[0])
            width, first = 60, 1
        elif kind == 'H':
            key = parts[0], int(parts[1]), int(parts[2])
            width, first = 6, 3
        else:
            assert kind in 'BSR'
            key = int(parts[0]), int(parts[1])
            width, first = (12 if kind == 'B' else 60), 2
        coeffs = tuple(map(float, parts[first:]))
        assert key not in tables[kind] and len(coeffs) == width
        tables[kind][key] = coeffs
    return tables


def read_tensor_frames(raw, points):
    """Разбирает центральные деформации и напряжения по принятым шагам."""
    rows = [line.split(';') for line in raw.decode('ascii').splitlines()]
    frames = {}
    for offset, row in enumerate(rows):
        if row[0] != 'FRAME':
            continue
        phase, torque, shear = row[1:]
        assert phase not in frames
        tensors = rows[offset+1:offset+1+points]
        state = {}
        for point, line in enumerate(tensors, 1):
            assert line[:2] == ['POINT', str(point)] and len(line) == 14
            state[point] = tuple(map(float, line[2:]))
        frames[phase] = float(torque), float(shear), state
    return frames


def verify(root, repo, external):
    """Подтверждает равновесие принятых полей и физическую нагрузочную траекторию."""
    reference = repo / 'docs/regression/Coupled6D' / ARCHIVE
    assert digest(reference.read_bytes()) == ARCHIVE_SHA
    native = root / 'Native'
    trace = (native / 'MVTGaussMixed.csv').read_bytes()
    raw_ops = (native / 'Operators.csv').read_bytes()
    raw_tensors = (native / 'MVTGaussMixed.Tensor.csv').read_bytes()
    tables = read_operators(raw_ops)
    marker = b'MVT_PRELOAD_END;8;10.51'
    assert marker in trace and trace.startswith((native / 'ColdPreload.csv').read_bytes())
    with ZipFile(reference) as bundle:
        base = bundle.read('Native/MVTGaussMixed.csv')
        old_ops = read_operators(bundle.read('Native/Operators.csv'))
        old_tensors = read_tensor_frames(bundle.read('Native/MVTGaussMixed.Tensor.csv'), 45)
    assert trace.split(marker)[0] == base.split(marker)[0]
    assert all(tables[k] == old_ops[k] for k in 'GLBSR')
    rows = [line.split(';') for line in trace.decode('cp1251').splitlines()]
    geom, = [row for row in rows if row[0] == 'MVT_GEOM']
    assert geom[1:4] == ['25', '45', '60']
    ox, oy, area, length = map(float, geom[4:])
    points = {int(row[1]): tuple(map(float, row[2:])) for row in rows if row[0] == 'MVT_POINT'}
    assert len(points) == 45
    tensor_frames = read_tensor_frames(raw_tensors, len(points))
    assert set(tensor_frames) == set(tables['F'])
    torsion = [f'R{i}' for i in range(1, 9)]
    assert list(tensor_frames)[:8] == torsion
    assert all(tables['F'][k] == old_ops['F'][k] and tensor_frames[k] == old_tensors[k] for k in torsion)
    paths = [(row[1], float(row[3]), row[5] == 'True') for row in rows if row[0] == 'MVT2_CUT_TRIAL']
    assert paths and [load for _, load, _ in paths] == [i * 2500. for i in range(1, len(paths)+1)]
    for row in rows:
        if row[0] == 'MVT2_CUT_TRIAL':
            assert float(row[2]) == T and float(row[4]) == -ARM * float(row[3])
    helpers = [(row[1], row[2]) for row in rows if row[0] == 'MVT2_CUT_INSERTED']
    expected_phases = {phase for phase, _, ok in paths if ok} | {phase + 'A' + raw for phase, raw in helpers}
    assert expected_phases == set(tensor_frames) - set(torsion)
    assert set(tables['H']) == {(phase, side, p) for phase in expected_phases for side in (-1, 0, 1) for p in points}
    checkpoints = []
    for phase, (torque, shear, state) in tensor_frames.items():
        if phase in torsion:
            continue
        field = tables['F'][phase]
        load = (0., -ARM * shear, 0., T, 0., shear)
        assert torque == T and shear > (checkpoints[-1]['Qy_N'] if checkpoints else 0)
        ext = [fsum(tables['L'][i][row] * force for i, force in enumerate(load, 1)) for row in range(60)]
        residual = [fsum(a*b for a, b in zip(field, tables['G'][row+1], strict=True)) - ext[row] for row in range(60)]
        signed = []
        strain_error = 0.
        for p, (x, y, weight, *direction) in points.items():
            center = tables['H'][phase, 0, p]
            plus, minus = tables['H'][phase, 1, p], tables['H'][phase, -1, p]
            strains = [fsum(coefficient * tables['B'][p, j][k] for j, coefficient in enumerate(field, 1)) for k in range(6)]
            strain_error = max(strain_error, *(abs(a-b) for a, b in zip(strains, state[p][:6], strict=True)))
            zz, xz, yz = center[2], center[4], center[5]
            signed.append((weight*zz, weight*(y-oy)*zz, weight*(x-ox)*zz,
                           weight*((x-ox)*yz-(y-oy)*xz), weight*xz, weight*yz))
            if p <= 25:
                assert center == state[p][6:]
            else:
                rebar = fsum((a+b)*d for a, b, d in zip(center, state[p][6:], direction, strict=True)) / fsum(d*d for d in direction)
                assert max(abs(a+b-rebar*d) for a, b, d in zip(center, state[p][6:], direction, strict=True)) < 2e-12
            for k, (sp, sm, sc) in enumerate(zip(plus, minus, center, strict=True), 1):
                dz = (sp-sm) / .002
                residual = [old + sc*s + dz*r for old, s, r in zip(residual, tables['S'][p,k], tables['R'][p,k], strict=True)]
        actions = tuple(map(fsum, zip(*signed, strict=True)))
        force_residual = max(abs(a-b) / (area*length if 1 <= i <= 3 else area)
                             for i, (a,b) in enumerate(zip(actions, load, strict=True)))
        metric = max(max(map(abs, residual[:56])), 30000. * max(map(abs, residual[56:])), force_residual)
        tolerance = 5e-7 + 5e-7 * max(map(abs, ext[:56]))
        assert metric <= tolerance and strain_error < 3e-16
        checkpoints.append({'phase': phase, 'Qy_N': shear, 'Mx_Nmm': load[1], 'twist_rad_per_m': field[3]*1000./length,
                            'kappaX_per_m': field[1]*1000./length,
                            'resultants_N_Nmm': actions, 'max_norm_MPa': metric, 'tolerance_MPa': tolerance})
    assert not any(row[0] == 'CASE_FINISHED' for row in rows)
    assert paths[-1][1:] == (20000., True) and checkpoints[-1]['Qy_N'] == 21875.
    log = (native / 'MVTGaussMixed.txt').read_text(encoding='utf-8-sig')
    assert 'WATCHDOG_FAILURE: timeout=165 sec;' in log and 'ownExcelState=Absent' in log
    assert 'TOTAL_MVT2_GAUSS_SPAN:' not in log
    report_base = native / 'MVTGaussMixed.txt'
    owner, closure = (json.loads(report_base.with_suffix('.txt.' + name + '.json').read_text(encoding='utf-8-sig'))
                      for name in ('Ownership', 'ProcessClosure'))
    assert closure['Stage'] == 'TIMEOUT' and not closure['Passed']
    assert owner['VerifiedNewOwner'] and closure['Identity']['PID'] == owner['PID'] and closure['After']['State'] == 'Absent'
    assert int(owner['StartTicksUTC']) == closure['Identity']['Ticks'] == int(closure['After']['StartTicksUTC'])
    compile_info = json.loads((root / 'CodeUpdate.json').read_text(encoding='utf-8-sig'))
    assert compile_info['Compiled'] and not compile_info['ProductionChanged']
    assert compile_info['ProductionSHA256'] == BOOK_SHA and owner['SourceSHA256'] == compile_info['WorkbookSHA256']
    assert set(compile_info['Modules']) == {'CCoupledElasticState', 'CCoupledSectionQuadrature', 'modTestMVT2GaussSpan'}
    assert digest(external.read_bytes()) == EXTERNAL_SHA
    with ZipFile(external) as bundle:
        asd = json.loads(bundle.read('Cut396.json'))
    assert asd['arm_mm'] == ARM
    data = {item['Q_target_N']: item for item in asd['result']['accepted'] if item['Q_target_N'] > 0.}
    pairs = []
    for item in checkpoints:
        load = item['Qy_N']
        if load not in data:
            continue
        other = data[load]
        assert other['T_target_Nmm'] == T and abs(other['resultants_N_Nmm'][1] + ARM*load) < 40.
        asd_twist = other['twist_rad_per_m']
        asd_curvature = other['field'][1]*1000./length
        pairs.append({'Qy_N': load, 'Mx_Nmm': -ARM*load, 'T_Nmm': T,
                      'NDM_twist_rad_per_m': item['twist_rad_per_m'], 'ASD_twist_rad_per_m': asd_twist,
                      'NDM_kappaX_per_m': item['kappaX_per_m'], 'ASD_kappaX_per_m': asd_curvature})
    assert [item['Qy_N'] for item in pairs] == list(range(2500, 20001, 2500))
    return {'arm_mm': ARM, 'matching_pure_torsion_count': len(torsion), 'accepted': checkpoints,
            'last_completed_target_Qy_N': paths[-1][1], 'last_verified_substep_Qy_N': checkpoints[-1]['Qy_N'],
            'last_completed_target_accepted': paths[-1][2], 'fixture_sha256': ARCHIVE_SHA,
            'termination': 'isolated_excel_watchdog_timeout', 'pending_requested_Qy_N': 22500.,
            'compared_same_six_force_states': pairs, 'ASD_reference_archive_sha256': EXTERNAL_SHA,
            'wire_sha256': {'trace': digest(trace), 'operators': digest(raw_ops), 'tensors': digest(raw_tensors)}}


if __name__ == '__main__':
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('--repo', type=Path, default=Path.cwd())
    cli.add_argument('--root', type=Path, required=True)
    cli.add_argument('--external', type=Path, required=True)
    cli.add_argument('--report', type=Path, required=True)
    args = cli.parse_args()
    proof = verify(args.root, args.repo, args.external)
    with args.report.open('xb') as output:
        output.write((json.dumps(proof, indent=2, sort_keys=True) + '\n').encode())
    print('MVT2 NATIVE PUBLICATION CUT TIMED PREFIX OFFLINE PASS', len(proof['accepted']))
