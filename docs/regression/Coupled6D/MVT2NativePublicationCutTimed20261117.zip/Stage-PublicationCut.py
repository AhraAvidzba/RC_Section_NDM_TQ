"""Готовит отдельную нативную проверку MVT2 на плече 396 мм."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


ARCHIVE = 'MVT2GaussSpatialOperatorsNative20261117.zip'
ARCHIVE_SHA = '8807822311947EDB91EB483B6FDC8F359F95BCE10F9B36286E12DE7F37932D5A'
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'
TEST = 'tests/modTestMVT2GaussSpan.bas'
DRIVER = 'Run-Native.ps1'
SCRATCH = Path('D:/CodexScratch/RC_Section_NDM_TQ')


def digest(raw):
    return sha256(raw).hexdigest().upper()


def replace_once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def proposed_test(raw):
    """Сохраняет исходное кручение и снимает принятые состояния каждой станции."""
    text = raw.decode('utf-8-sig').replace('\r\n', '\n')
    text = replace_once(text, 'ARM As Double = 330#', 'ARM As Double = 396#')
    text = replace_once(text, 'goals = Array(5000#, 6250#, 7500#, 8750#, 10000#, 11250#, 11562.5, 11875#, 12187.5, 12500#, _\n'
                        '        12812.5, 13125#, 13437.5, 13750#, 14062.5, 14375#, 14687.5, 15000#)',
                        'ReDim goals(1 To 32)\n'
                        '    For i = 1 To 32: goals(i) = 2500# * i: Next i\n'
                        '    Dim stations As New Collection\n'
                        '    stations.Add minusConcrete: stations.Add minusSide\n'
                        '    stations.Add concrete: stations.Add response\n'
                        '    stations.Add plusConcrete: stations.Add plusSide')
    text = replace_once(text, 'phase, report, tracePath)\n            Set meta = solver.ResultMeta',
                        'phase, report, tracePath, stations)\n            Set meta = solver.ResultMeta')
    text = replace_once(text, '        WriteMVT2ShearTensorsTest operators, concrete, field, phase, TORQUE, qy, tracePath\n'
                        '        WriteMVT2OperatorFieldTest tracePath, phase, field\n'
                        '        If phase = "S1" Or phase = "S18" Then\n'
                        '            WriteMVT2OperatorAnchorTest operators, tracePath, phase, -1, minusConcrete, minusSide\n'
                        '            WriteMVT2OperatorAnchorTest operators, tracePath, phase, 0, concrete, response\n'
                        '            WriteMVT2OperatorAnchorTest operators, tracePath, phase, 1, plusConcrete, plusSide\n'
                        '        End If',
                        '        WriteMVT2FullFrameTest operators, field, phase, TORQUE, qy, tracePath, stations')
    text = replace_once(text, 'ByRef report As String, ByVal tracePath As String) As Boolean\n    Dim midQ',
                        'ByRef report As String, ByVal tracePath As String, ByVal stations As Collection) As Boolean\n    Dim midQ')
    text = replace_once(text, 'phase, report, tracePath) Then Exit Function',
                        'phase, report, tracePath, stations) Then Exit Function')
    text = replace_once(text, 'phase, report, tracePath)\n        End If\n    End If\n    BisectWangCutTest',
                        'phase, report, tracePath, stations)\n        End If\n    End If\n    BisectWangCutTest')
    text = replace_once(text, '        ";" & ExperimentNumberTest(residual) & wire\n    solved = solver.TryStep',
                        '        ";" & ExperimentNumberTest(residual) & wire\n'
                        '    WriteMVT2FullFrameTest operators, field, phase & "A" & ExperimentNumberTest(midQ), _\n'
                        '        torque, midQ, tracePath, stations\n'
                        '    solved = solver.TryStep')
    text += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет центральные тензоры, поле и узловой отклик трёх станций.
Private Sub WriteMVT2FullFrameTest(ByVal operators As CCoupledElasticState, _
        ByRef field() As Double, ByVal phase As String, ByVal torque As Double, _
        ByVal shear As Double, ByVal tracePath As String, ByVal stations As Collection)
    Dim concrete As CCoupledConcreteResponse, steel As CCoupledReinforcedResponse, side As Long
    Set concrete = stations.Item(3)
    WriteMVT2ShearTensorsTest operators, concrete, field, phase, torque, shear, tracePath
    WriteMVT2OperatorFieldTest tracePath, phase, field
    For side = -1 To 1
        Set concrete = stations.Item(2 * side + 3)
        Set steel = stations.Item(2 * side + 4)
        WriteMVT2OperatorAnchorTest operators, tracePath, phase, side, concrete, steel
    Next side
End Sub
'''
    text.encode('cp1251')
    return text.replace('\n', '\r\n').encode('utf-8-sig')


def stage(repo, root):
    """Копирует проверенные исходники и книгу без изменения рабочей версии."""
    root = root.resolve()
    assert root.parent == SCRATCH.resolve() and not root.exists()
    archive = repo / 'docs/regression/Coupled6D' / ARCHIVE
    assert digest(archive.read_bytes()) == ARCHIVE_SHA
    book = (repo / BOOK).read_bytes()
    assert digest(book) == BOOK_SHA
    with ZipFile(archive) as bundle:
        prior = json.loads(bundle.read('Preparation.json'))
        files = {name: bundle.read(name) for name in prior['inputs'] if name != BOOK}
        assert all(digest(raw) == prior['inputs'][name] for name, raw in files.items())
        files['Verify-Operators.py'] = bundle.read('Verify-Operators.py')
        files['ReferenceMixed.csv'] = bundle.read('Native/MVTGaussMixed.csv')
        files['ReferenceOperators.csv'] = bundle.read('Native/Operators.csv')
        files['ReferenceTensor.csv'] = bundle.read('Native/MVTGaussMixed.Tensor.csv')
    files[BOOK] = book
    files[TEST] = proposed_test(files[TEST])
    run = files[DRIVER].decode('utf-8').replace('\r\n', '\n')
    run = replace_once(run, "$timeout='285'", "$timeout='165'")
    verify = run.index("    python './Verify-Mixed.py'")
    terminal = run.index('\n}\nfinally', verify)
    run = run[:verify] + run[terminal:]
    files[DRIVER] = run.encode('utf-8')
    manifest = {'source_book_sha256': BOOK_SHA, 'native_archive_sha256': ARCHIVE_SHA,
                'inputs': {name: digest(raw) for name, raw in sorted(files.items())}}
    files['Preparation.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    files['docs/regression/Diagnostic.xlsm'] = book
    root.mkdir()
    (root / 'Temp').mkdir()
    for name, raw in files.items():
        file = root / name
        file.parent.mkdir(parents=True, exist_ok=True)
        with file.open('xb') as sink:
            sink.write(raw)
    print('PREPARED', root, BOOK_SHA, manifest['inputs'][TEST], flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--stage', required=True, type=Path)
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve())
