"""Готовит сравнение штатного и уточнённого локальных допусков в PV25."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


HERE=Path(__file__).resolve().parent
CLASS='src/Materials/CCoupledConcreteResponse.cls'


def change_precision(raw):
    """Делает локальный допуск настраиваемым только в контрольной копии."""
    text=raw.decode('utf-8').replace('\r\n','\n')
    anchor='Private Const YIELD_TOLERANCE_RATIO As Double = 0.00000001'
    assert text.count(anchor)==1
    text=text.replace(anchor,'Private mTestYieldPrecision As Double')
    text=text.replace('YIELD_TOLERANCE_RATIO','mTestYieldPrecision')
    anchor='    mPointCount = pointCount\n'
    assert text.count(anchor)==1
    text=text.replace(anchor,'    mTestYieldPrecision = 0.00000001\n'+anchor)
    text+='''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Назначает точность поверхности после восстановления одинаковой истории.
Friend Sub TestSetYieldPrecision(ByVal relativeTolerance As Double)
    If relativeTolerance <= 0# Then Err.Raise 5, , "Точность поверхности должна быть положительной."
    mTestYieldPrecision = relativeTolerance
End Sub
'''
    return text.replace('\n','\r\n').encode('utf-8')


def stage(repo,root,guard_pid,guard_ticks):
    base=run_path(str(HERE/'Stage-PanelChart.py'))
    base['stage'](repo,root)
    source=root/CLASS
    source.write_bytes(change_precision(source.read_bytes()))
    test=root/'tests/modTestMVT2GaussSpan.bas'
    body=test.read_text(encoding='utf-8-sig')
    assert body.count('completed = TestPanelCharts(report, tracePath)')==1
    body=body.replace('completed = TestPanelCharts(report, tracePath)','completed = TestPanelPrecision(report, tracePath)')
    body+=(HERE/'PanelPrecision.bas.txt').read_text(encoding='utf-8')
    body.encode('cp1251')
    test.write_bytes(body.replace('\n','\r\n').encode('utf-8-sig'))
    items=[test,source]
    if guard_pid:
        guard=root/'Guard-IsolatedOffice.ps1'
        text=guard.read_text('utf-8')
        guard.write_bytes(text.replace('$protected=@{',f'$protected=@{{{guard_pid}=[long]{guard_ticks};',1).encode())
        items.append(guard)
    meta=root/'Preparation.json'
    data=json.loads(meta.read_bytes())
    data['local_yield_precision']=[1e-8,1e-10]
    for path in items:
        data['inputs'][path.relative_to(root).as_posix()]=sha256(path.read_bytes()).hexdigest().upper()
    meta.write_bytes((json.dumps(data,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',type=Path,required=True)
    parser.add_argument('--guard-pid',type=int)
    parser.add_argument('--guard-ticks',type=int)
    args=parser.parse_args()
    if bool(args.guard_pid)!=bool(args.guard_ticks):
        parser.error('Нужны оба значения идентификатора процесса.')
    stage(args.repo.resolve(),args.stage.resolve(),args.guard_pid,args.guard_ticks)
