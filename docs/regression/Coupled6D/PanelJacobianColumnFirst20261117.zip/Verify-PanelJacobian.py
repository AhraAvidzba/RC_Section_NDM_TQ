"""Сверяет исправление касательной, нативные истории панелей и рабочую книгу."""

from argparse import ArgumentParser
import json
from pathlib import Path
from re import findall
from runpy import run_path
from zipfile import ZipFile


def verify(repo, root):
    """Воспроизводит проверку исходников, панельных полей и квитанций Excel."""
    tools = run_path(str(root / 'Verify-MixedPanels.py'))
    digest = tools['digest']
    material_class = tools['CLASS']
    panel_module = tools['TEST']
    archived = repo / 'docs/regression/Coupled6D'
    pinned = archived / tools['PIN']
    assert digest(pinned.read_bytes()) == tools['PIN_SHA']
    utility = {'__name__': '__pinned__'}
    with ZipFile(pinned) as source:
        exec(compile(source.read('Verify-NativeMaterialHistory.py'), str(pinned), 'exec'), utility)
        base = source.read(material_class)
    read = utility['read']
    published, pixels = tools['load_sources'](repo, root)
    stage = run_path(str(root / 'Stage-MixedPanelWeight.py'))
    corrected = root / 'Corrected'
    precision = root / 'Precision'
    for folder in (corrected, precision):
        prep = read(folder / 'Preparation.json')
        assert prep['source_book_sha256'] == utility['BOOK']
        for name in (panel_module, material_class, 'Guard-IsolatedOffice.ps1', 'Replay.Fields.csv', 'Run-Native.ps1'):
            assert digest((folder / name).read_bytes()) == prep['inputs'][name]

    reference = archived / 'MixedPanelDilationWeights20261117.zip'
    assert digest(reference.read_bytes()) == '9287C5B83CB3EDF71E91C715229DA1B25A9BC9A1E7D283BD82D9A7FB48514335'
    with ZipFile(reference) as source:
        before = source.read(f'NormalContinuation/{panel_module}')
        prior_rows = source.read('NormalContinuation/Native/PanelWeights.csv').decode('ascii').splitlines()
    expected = b'normal(i, j) = ('
    assert before.count(expected) == 3
    assert (corrected / panel_module).read_bytes() == before.replace(expected, b'normal(j, i) = (')
    assert read(corrected / 'Preparation.json')['normal_jacobian_column_first']
    result = tools['verify_run'](repo, corrected, published['panels'], (published, pixels), utility, base, stage, False)
    assert result['termination'] == 'completed' and result['verified_states'] == 1740
    for case in result['cases'].values():
        assert case['explicit_status']['target_achieved']
        assert case['explicit_status']['attempts'] == case['metrics']['states']
        assert case['metrics']['observed_descending_points'] > 0

    assert read(precision / 'Preparation.json')['local_yield_precision'] == [1e-8, 1e-10]
    change_precision = run_path(str(root / 'Stage-PanelPrecision.py'))['change_precision']
    assert (precision / material_class).read_bytes() == change_precision(stage['material_test_wire'](base))
    replay = (precision / 'Replay.Fields.csv').read_text('ascii').splitlines()
    assert replay == [row for row in prior_rows if row.startswith(('STATE;PV25;20;', 'STATE;PV25;5;'))]
    termination, precision_pid = tools['validate_owner'](precision, read, False, utility['BOOK'])
    assert termination == 'completed'
    trace = (precision / 'Native/MVTGaussMixed.csv').read_text('ascii')
    replay_check = findall(r'PRECISION_REPLAY;(\w+);70;([^;\n]+);([^\n]+)', trace)
    assert [(name, float(tol)) for name, _, tol in replay_check] == [('Stock', 1e-8), ('Tight', 1e-10)]
    replay_residual = max(float(value) for _, value, _ in replay_check)
    assert replay_residual < 2e-14
    end = findall(r'PRECISION_END;(\w+);False;1;9;([^;\n]+);([^\n]+)', trace)
    last_gamma = 0.00100233154296875
    assert [(name, float(gamma), float(target)) for name, gamma, target in end] == [
        (name, last_gamma, 0.0011) for name in ('Stock', 'Tight')]
    witnesses = [line.split(';') for line in (precision / 'Native/PanelWeights.csv').read_text('ascii').splitlines()]
    assert [row[:4] for row in witnesses] == [
        ['STATE', 'PV25', 'Stock', '1'], ['STATE', 'PV25', 'Tight', '1']]
    assert witnesses[0][4:] == witnesses[1][4:]
    history = [tuple(map(float, row.split(';')[4:])) for row in replay[:70]]
    model = next(tuple(map(float, row.split(';')[3:])) for row in prior_rows if row.startswith('MODEL;PV25;20;'))
    values = history + [tuple(map(float, witnesses[0][4:]))]
    assert values[-1][3] == last_gamma
    precision_check = tools['check_curve'](values, published['panels']['PV25'], model, 20, utility['principal'])

    receipt = root / 'InstalledMatrix/InstalledCoupledMatrix.txt'
    log = receipt.read_text('utf-8-sig')
    owner = read(receipt.with_name(receipt.name + '.Ownership.json'))
    closure = read(receipt.with_name(receipt.name + '.ProcessClosure.json'))
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and owner['SourceSHA256'] == utility['BOOK']
    assert f'SOURCE_SHA256: {utility["BOOK"]}' in log
    assert f'TEST_EXCEL_PROCESS: id={owner["PID"]}; startTicks={owner["StartTicksUTC"]}' in log
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
    counts = findall(r'TOTAL_COUPLED_(\w+): passed=(\d+); failed=(\d+)', log)
    assert counts == [('FACTORIZATION', '6', '0'), ('EQUATIONS', '10', '0'), ('GRADIENT_LINEARIZATION', '3', '0')]
    assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['RunnerCleanupValid']
    identity = closure['Closure']['Identity']
    assert identity['Valid'] and identity['PID'] == owner['PID'] and identity['Ticks'] == int(owner['StartTicksUTC'])
    assert closure['Closure']['FinalState']['State'] == 'Absent'
    return {
        'verified_jacobian_assignments': 3,
        'corrected': result,
        'precision': {
            'excel_pid': precision_pid, 'relative_tolerances': [1e-8, 1e-10], 'common_history': 70,
            'accepted_after_replay': 1, 'attempts_per_tolerance': 9, 'last_gamma': last_gamma,
            'next_target': 0.0011, 'same_new_state': True, 'replay_residual_MPa': replay_residual,
            'state_check': precision_check,
        },
        'installed': {'book_sha256': utility['BOOK'], 'excel_pid': owner['PID'],
                      'checks': {name: int(passed) for name, passed, _ in counts}},
    }


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--root', default=Path(__file__).resolve().parent, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    proof = verify(args.repo.resolve(), args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, indent=2, sort_keys=True, allow_nan=False)
        output.write('\n')
    print('PANEL JACOBIAN OFFLINE PASS', proof['corrected']['verified_states'], sum(proof['installed']['checks'].values()))
