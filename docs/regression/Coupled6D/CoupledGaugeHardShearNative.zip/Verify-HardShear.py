"""Verify the installed-book HardShear timing and the native output contract."""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
BOOK_SHA = "52E2CB3A1AB371B323B8B4E3DD4FF64B572A7A438AEF478C981F09EB9FCA7BA3"

def read(name):
    return (HERE / name).read_text(encoding="utf-8-sig")

def main():
    trace = read("HardShear.txt")
    tally = dict((name, (int(ok),int(bad))) for name,ok,bad in re.findall(r"^(TOTAL_\w+): passed=(\d+); failed=(\d+)$", trace, re.M))
    assert tally == {"TOTAL_COUPLED_WORKBOOK_TIMING": (28,0), "TOTAL_HARD_SHEAR_YIELD_RECOVERY": (1,0)}
    assert f"SOURCE_SHA256: {BOOK_SHA}" in trace
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in trace
    assert "TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10290889219737; limit=; code=NUMERICAL_FAILURE" in trace
    clock = re.findall(r"^TIMING_SECONDS: ([0-9.]+) \| Both \| Excel$", trace, re.M)
    assert len(clock)==1 and float(clock[0])==77.55859375
    owner = json.loads(read("HardShear.txt.Ownership.json"))
    closure = json.loads(read("HardShear.txt.ProcessClosure.json"))
    memory = json.loads(read("HardShear.txt.memory.json"))
    final = closure["Closure"]["FinalState"]
    assert owner["SourceSHA256"] == BOOK_SHA and owner["BeforeWorkbookOpen"] and owner["VerifiedNewOwner"]
    assert closure["Passed"] and closure["RunnerCleanupValid"] and closure["ChildExitCode"]==0
    assert final["State"] == "Absent" and final["PID"]==owner["PID"] and final["StartTicksUTC"]==owner["StartTicksUTC"]
    assert memory["Ready"] and memory["FreeCommitGiB"]>=8 and memory["FreePhysicalGiB"]>=4
    hashes = {name: hashlib.sha256((HERE/name).read_bytes()).hexdigest().upper()
              for name in ["HardShear.txt","HardShear.txt.Ownership.json","HardShear.txt.ProcessClosure.json","HardShear.txt.memory.json"]}
    output = {"workbook_sha256":BOOK_SHA,"source_revision":"7606436","stationary_load":"HardShear", "macro_count":len(tally),
              "assertions":29,"elapsed_seconds":float(clock[0]),"direct":"OK","capacity":"NumFail","lower_bound":1.10290889219737,
              "physical_limit_confirmed":False,"own_closure":final,"input_sha256":hashes}
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()