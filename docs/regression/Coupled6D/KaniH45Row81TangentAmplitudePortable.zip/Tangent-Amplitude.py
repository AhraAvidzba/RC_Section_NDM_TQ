"""Discriminate the installed coordinate differencing scale on two fixed Kani stations."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import runpy

import numpy as np

FIXED_TRACE_SHA='742A063E044EA739BF528623A187B64116CE6D6C105809C9194FAEEF4C4829A9'
TARGETS=((8,1),(137,-1))
AMPLITUDES=(1.,1/16,1/64,1/256)


def f64(x):
    return float(x)


def analyze(repo,witness):
    req=witness/'KaniRowVerification.json'
    assert sha256(req.read_bytes()).hexdigest().upper()==FIXED_TRACE_SHA
    native=json.loads(req.read_text(encoding='utf8'))
    assert native['matrixMaterialMode']==3 and native['fraction']==1/128
    ap=runpy.run_path(witness/'Replay-Row.py')['row_api'](portable=True)
    model,_=runpy.run_path(witness/'Classify-Row.py')['inputs'](repo)
    context=runpy.run_path(witness/'AltVerifier.py')
    history,accepted,build,_=context['archived_inputs'](repo)
    raw,stress,cols,_,_,stations,_=ap['parse']()
    i=list(history['names']).index('Committed45')
    h0=history['stations'][history['station_index'][i]]
    energy=np.array(accepted['energiesByStation_minus0plus']['Committed45'])
    ops=build(history['geometry'],float(history['length']))
    h,_,_,_,a,_=ops
    d=raw['CORRECTION'][:87]
    de_point=h@d[:79]
    dslope=h[:,:,:4]@d[79:83]
    result=[]
    for j1,side in TARGETS:
        s,j=side+1,j1-1
        seed=model['matrix'](h0[s,j,6:])
        kt,kc=energy[s,j]
        local=stations['Base'][s,j,4:10]
        inc=local-h0[s,j,:6]
        stress0,detail=model['return_apex'](seed,kt,kc,inc)
        assert np.max(abs(np.array(model['vector'](stress0))-stress['BASE_STRESS'][s,j]))<2e-12
        assert stations['Base'][s,j,:3].tolist()==[1,1,1]
        v=de_point[j]+side*.001*dslope[j]
        t0,t0_kind=model['apex_jvp'](seed,kt,kc,inc,v)
        analytic_columns=np.array([model['apex_jvp'](seed,kt,kc,inc,e)[0][2,2] for e in np.eye(6)])
        weight=side*(history['geometry'][j,1]/float(history['length']))*a[j]/.002
        expected=weight*t0[2,2]
        assert abs(expected-weight*(analytic_columns@v))<1e-12
        readings=[]
        for scale in AMPLITUDES:
            analytic=np.zeros(6)
            mode=[]
            for k in range(6):
                hstep=2e-9*(1+abs(local[k]))*scale
                perturb=np.eye(6)[k]*hstep
                sp,dp=model['return_apex'](seed,kt,kc,inc+perturb)
                sm,dm=model['return_apex'](seed,kt,kc,inc-perturb)
                # These two stations remain plastic with positive principal stress on both coordinate signs.
                assert dp['kind']!='Elastic' and dm['kind']!='Elastic'
                assert np.linalg.eigvalsh(sp)[-1]>0 and np.linalg.eigvalsh(sm)[-1]>0
                analytic[k]=(sp[2,2]-sm[2,2])/(2*hstep)
                mode.append([dp['kind'],dm['kind']])
            action=weight*f64(analytic@v)
            readings.append({'amplitudeFraction':scale,'nominalAmplitudeStrain':2e-9*scale,
                             'coordinateReturnModesPlusMinus':mode,'coordinateDerivativesMPa':analytic.tolist(),
                             'maxColumnErrorToAnalyticMPa':f64(np.max(abs(analytic-analytic_columns))),
                             'row81DirectionalActionMPa':action,'row81ActionErrorToAnalyticMPa':action-f64(expected)})
        actual=weight*f64(cols[s,j]@v)
        q_accept=model['invariant'](seed)[2]
        assert abs(readings[0]['row81DirectionalActionMPa']-actual)<2e-11
        assert readings[1]['maxColumnErrorToAnalyticMPa']>readings[2]['maxColumnErrorToAnalyticMPa']>readings[3]['maxColumnErrorToAnalyticMPa']
        result.append({'point':j1,'side':side,'returnKindAtExactBase':t0_kind,'trialQAtBaseEffectiveMPa':detail['q_trial'],
                       'acceptedNominalQ_MPa':q_accept,'returnedQAtBaseEffectiveMPa':detail['q_return'],
                       'installedTangentColumnsMPa':cols[s,j].tolist(),'installedRow81ActionMPa':actual,
                       'analyticTangentColumnsMPa':analytic_columns.tolist(),'analyticRow81ActionMPa':f64(expected),
                       'stockDirectionalDifferenceReproductionMPa':readings[0]['row81DirectionalActionMPa']-actual,
                       'readings':readings})
    return {'constantSource':'CCoupledConcreteResponse.NonLinearTangent, STRAIN_PERTURBATION = 2e-9; refined divides by 64.',
            'traceSHA256':FIXED_TRACE_SHA,'stations':result}


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    p.add_argument('--witness-root',type=Path,required=True)
    p.add_argument('--out',type=Path)
    a=p.parse_args()
    out=analyze(a.repo_root.resolve(),a.witness_root.resolve())
    data=json.dumps(out,indent=2,allow_nan=False)+'\n'
    if a.out:
        a.out.write_text(data,encoding='utf8')
    print(data,end='')
