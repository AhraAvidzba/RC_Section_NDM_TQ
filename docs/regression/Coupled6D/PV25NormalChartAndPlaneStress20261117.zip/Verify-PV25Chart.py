"""Сверяет продолжения PV25 и независимо решает плоскую ветвь до 10 промилле."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile

from PV25PlaneStressOracle import E, advance, seed_from_state


REFERENCE='MixedPanelDilationWeights20261117.zip'
REFERENCE_SHA='9287C5B83CB3EDF71E91C715229DA1B25A9BC9A1E7D283BD82D9A7FB48514335'
MATERIAL='MVT2NativePublicationCutMaterialHistory20261117.zip'
MATERIAL_SHA='6920EB24A5D01585E510FDBC1064513C0C83AA62583AEB0C2553D6F0D495EE55'
CLASS='src/Materials/CCoupledConcreteResponse.cls'
TEST='tests/modTestMVT2GaussSpan.bas'
AXES=((20,3),(20,1),(5,3),(5,1))


def digest(data):
    return sha256(data).hexdigest().upper()


def read_reference(repo,root):
    """Привязывает повтор к исходным 130 полям и сохраняет панельные нагрузки."""
    path=repo/'docs/regression/Coupled6D'/REFERENCE
    assert digest(path.read_bytes())==REFERENCE_SHA
    with ZipFile(path) as z:
        source=z.read('NormalContinuation/Native/PanelWeights.csv').decode('ascii').splitlines()
        base_class=z.read('NormalContinuation/'+CLASS)
        published=json.loads(z.read('PublishedPanels.json'))
    history=[line for line in source if line.startswith(('STATE;PV25;20;','STATE;PV25;5;'))]
    wire=(root/'Replay.Fields.csv').read_bytes()
    assert wire==('\r\n'.join(history)+'\r\n').encode('ascii') and len(history)==130
    rows={20:[],5:[]}
    for line in history:
        _,name,weight,index,*state=line.split(';')
        assert name=='PV25' and int(index)==len(rows[int(weight)])+1
        rows[int(weight)].append(tuple(map(float,state)))
    assert (root/CLASS).read_bytes()==base_class
    return rows,published


def charts(root,replay):
    """Пересчитывает принятие, рост, деление шага и условия остановки четырёх маршрутов."""
    lines=(root/'Native/MVTGaussMixed.csv').read_text('cp1251').splitlines()
    summaries={tuple(map(int,row.split(';')[1:3])):row.split(';')[3:]
               for row in lines if row.startswith('CHART_END;')}
    repeated={tuple(map(int,row.split(';')[1:3])):row.split(';')[3:]
              for row in lines if row.startswith('CHART_REPLAY;')}
    finish,=[row for row in lines if row.startswith('CASE_FINISHED;')]
    assert finish.startswith('CASE_FINISHED;MVTGaussMixed;True;')
    assert tuple(summaries)==tuple(repeated)==AXES
    wire=(root/'Native/PanelWeights.csv').read_text('ascii').splitlines()
    output={}
    for weight,axis in AXES:
        old,current=replay[weight][-2:]
        idx=axis-1
        number,delta,*recovered=repeated[weight,axis]
        assert int(number)==len(replay[weight]) and 0.<=float(delta)<2e-8
        assert tuple(map(float,recovered))==current[:6]
        selected=[line.split(';') for line in wire if line.split(';')[1:3]==[str(weight),str(axis)]]
        probes={int(row[3]):row[4:] for row in selected if row[0]=='PROBE'}
        states={int(row[3]):tuple(map(float,row[4:])) for row in selected if row[0]=='STATE'}
        assert len(states)+len(probes)==len(selected) and list(probes)==list(range(1,len(probes)+1))
        initial=current[idx]-old[idx]
        width=4.*initial
        for i,(goal,ok,residual) in probes.items():
            assert abs(float(goal)-(current[idx]+width)) < 1e-15 and width>=initial/32.
            assert current[3]<.00551 and float(residual)>=0.
            if ok=='True':
                assert i in states and abs(states[i][idx]-float(goal))<1e-16
                assert states[i][3]>current[3] and float(residual)<2.00005e-7
                current=states[i]
                width=min(2.*width,128.*initial)
            else:
                assert ok=='False' and i not in states
                width/=2.
        count,tries,final_width,*final_state=summaries[weight,axis]
        assert len(states)==int(count) and len(probes)==int(tries)
        assert tuple(map(float,final_state))==current[:6] and abs(float(final_width)-width)<1e-15
        reason='budget' if len(probes)==96 else ('desired_gamma' if current[3]>=.00551 else 'minimum_step')
        assert reason!='minimum_step' or width<initial/32.
        output[weight,axis]={'reason':reason,'accepted':list(states.values()),'attempts':len(probes),
                             'replay_stress_difference_MPa':float(delta)}
    assert sum(len(x['accepted'])+x['attempts'] for x in output.values())==len(wire)
    return output,float(finish.split(';')[3])


def run_oracle(history,weight,step):
    """Продолжает фиксируя сдвиг и включает точные точки измерения в расписание."""
    accepted=[]
    prior=seed_from_state(history[-1])
    for checkpoint in (.0016,.00551,.0065,.008,.010):
        while prior['gamma'] < checkpoint-1e-12:
            wanted=min(checkpoint,prior['gamma']+step)
            solved=advance(prior,wanted,weight)
            assert solved is not None, (weight,step,wanted)
            assert abs(solved['gamma']-wanted)<1e-12 and solved['gamma']>prior['gamma']
            assert solved['t']>=prior['t'] and solved['c']>=prior['c'] and solved['multiplier']>0.
            assert max(map(abs,solved['residuals_MPa']))<2.e-10
            prior=solved
            accepted.append(solved)
    assert abs(accepted[-1]['gamma']-.01)<1e-12
    top=max(range(len(accepted)),key=lambda i:accepted[i]['tau'])
    assert 0<top<len(accepted)-1 and accepted[-1]['tau']<accepted[top]['tau']
    return {'states':accepted,'maximum':accepted[top], 'step':step,
            'at_5_51':next(row for row in accepted if abs(row['gamma']-.00551)<1e-12),
            'first_negative_in_plane_plus':next(row for row in accepted if row['q'][0]<0.)}


def verify(repo,root):
    replay,published=read_reference(repo,root)
    helper=run_path(str(root/'Verify-MixedPanels.py'))
    path=repo/'docs/regression/Coupled6D'/MATERIAL
    assert digest(path.read_bytes())==MATERIAL_SHA
    utility={'__name__':'__pinned__'}
    with ZipFile(path) as z:
        exec(compile(z.read('Verify-NativeMaterialHistory.py'),MATERIAL,'exec'),utility)
    owner,pid=helper['validate_owner'](root,utility['read'],False,utility['BOOK'])
    assert owner=='completed'
    prep=utility['read'](root/'Preparation.json')
    assert prep['chart_replay_archive_sha256']==REFERENCE_SHA and prep['chart_axes']==[3,1]
    for name in (CLASS,TEST,'Replay.Fields.csv','Run-Native.ps1'):
        assert digest((root/name).read_bytes())==prep['inputs'][name]
    routes,timing=charts(root,replay)
    observed={}
    for (weight,axis),route in routes.items():
        rows=replay[weight]+route['accepted']
        check=helper['check_curve'](rows,published['panels']['PV25'],(E,),weight,utility['principal'])
        if axis==3:
            previous=replay[weight][-1]
            residual=[]
            for now in route['accepted']:
                check_state=advance(seed_from_state(previous),now[2],weight,'thickness')
                assert check_state is not None and 0.<check_state['q'][0]
                residual.append((abs(check_state['tau']-now[9]),abs(check_state['gamma']-now[3])))
                previous=now
            check['independent_step_tau_difference_MPa']=max(a for a,_ in residual)
            check['independent_step_gamma_difference']=max(b for _,b in residual)
        observed[f'{weight}-{axis}']={'summary':helper['metrics']('PV25',rows,published,{}),
                                      'check':check,'ending':route['reason'],'new_fields':len(route['accepted']),
                                      'attempts':route['attempts'],'replay_stress_difference_MPa':route['replay_stress_difference_MPa']}
    standalone={str(weight):[run_oracle(history,weight,step) for step in (5e-5,2.5e-5)]
                for weight,history in replay.items()}
    return {'charts':observed,'macro_seconds':timing,'excel_pid':pid,'independent':standalone,
            'no_specimen_failure_mode_verified':True}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args()
    proof=verify(args.repo.resolve(),args.root.resolve())
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(proof,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('PV25 CHART AND INDEPENDENT PLANE STRESS PASS',sum(x['new_fields'] for x in proof['charts'].values()))
