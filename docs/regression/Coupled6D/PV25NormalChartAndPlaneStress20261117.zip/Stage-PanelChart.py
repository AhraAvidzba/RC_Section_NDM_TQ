"""Готовит повтор панели PV25 с управлением двумя нормальными деформациями."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


HERE=Path(__file__).resolve().parent
REFERENCE='MixedPanelDilationWeights20261117.zip'
REFERENCE_SHA='9287C5B83CB3EDF71E91C715229DA1B25A9BC9A1E7D283BD82D9A7FB48514335'


def digest(data):
    return sha256(data).hexdigest().upper()


def stage(repo,root):
    source=repo/'docs/regression/Coupled6D'/REFERENCE
    assert digest(source.read_bytes())==REFERENCE_SHA
    with ZipFile(source) as z:
        raw=z.read('NormalContinuation/Native/PanelWeights.csv').decode('ascii').splitlines()
    rows=[line for line in raw if line.startswith(('STATE;PV25;20;','STATE;PV25;5;'))]
    assert len(rows)==130 and rows[69].startswith('STATE;PV25;20;70;') and rows[-1].startswith('STATE;PV25;5;60;')
    base=run_path(str(HERE/'Stage-MixedPanelContinuation.py'))
    base['stage'](repo,root)
    replay=root/'Replay.Fields.csv'
    replay.write_bytes(('\r\n'.join(rows)+'\r\n').encode())
    test=root/'tests/modTestMVT2GaussSpan.bas'
    code=test.read_text(encoding='utf-8-sig')
    save='completed = TestMixedPanelWeight(report, tracePath)'
    assert code.count(save)==1
    code=code.replace(save,'completed = TestPanelCharts(report, tracePath)')
    code+=(HERE/'PanelChart.bas.txt').read_text(encoding='utf-8')
    code.encode('cp1251')
    test.write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    meta=root/'Preparation.json'
    data=json.loads(meta.read_bytes())
    data['panels']=['PV25']
    data['mixed_weights']=[20,5]
    data['chart_axes']=[3,1]
    data['chart_replay_archive_sha256']=REFERENCE_SHA
    for item in (test,replay):
        data['inputs'][item.relative_to(root).as_posix()]=digest(item.read_bytes())
    meta.write_bytes((json.dumps(data,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',required=True,type=Path)
    args=parser.parse_args()
    stage(args.repo.resolve(),args.stage.resolve())
