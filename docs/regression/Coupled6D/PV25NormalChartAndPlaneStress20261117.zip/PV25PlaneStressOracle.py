"""Решает плоское состояние симметричной PV25 без пространственного возврата VBA."""

from math import exp, fsum, radians, sin, sqrt, tan

from H35ScalarOracle import concrete_envelope, stresses


FC, PEAK, NU, LENGTH = 19.2, .0018, .2, 140.
RHO, FY, ES, LOAD_RATIO = .0179, 466., 200000., -.69
E = 10000.*(.8+.2*(FC+8.)/88.)*(FC+8.)**(1./3.)
FT = .302*FC**(2./3.)
GT = .073*FC**.18
GC = (FC/FT)**2*GT
COMPRESSION = concrete_envelope((32.,E,NU,LENGTH,0.,FC,PEAK,FT,GT,GC))
TOLERANCE = 2e-10


def seed_from_state(state):
    """Переносит состояние из инженерных координат в главные направления панели."""
    ea,_,ez,gamma=state[:4]
    pa,_,pz,gp=state[16:20]
    p=(pa+gp/2.,pa-gp/2.,pz)
    exx=ea-pa; ezz=ez-pz; shear=gamma-gp
    mu,lam=E/(2.*(1.+NU)),E*NU/((1.+NU)*(1.-2.*NU))
    normal=2.*mu*exx+lam*(2.*exx+ezz)
    q=(normal+mu*shear,normal-mu*shear)
    return {'plastic':p,'t':state[22],'c':state[23],'ep_steel':state[14],
            'q':q,'gamma':gamma,'epsilon_x':ea,'epsilon_z':ez,'tau':state[9]}


def angle(tension_energy, compression_energy, r, trace, q, weight):
    """Вычисляет закон дилатансии на ненулевом девиаторе плоского напряжения."""
    k=min(1.,max(0.,1.-(1.-(1.+weight*r)*tension_energy)*(1.-(1.-r)*compression_energy)))
    confinement=exp(min(0.,-(1.+trace/q)*trace/FC))
    sf=sin(radians(65.)*confinement)
    sp=sin(radians(32.)*confinement)
    sv=(sf-sp)/(1.-sf*sp)
    sf_current=2.*sqrt(k)*sf/(1.+k)
    if sf_current<=sv:
        return 0.
    s=(sf_current-sv)/(1.-sf_current*sv)
    return s/sqrt(1.-s*s)


def constitutive(unknown, prior, target, weight, axis):
    """Пишет пластический потенциал и равновесие в главных осях 45 градусов."""
    plus,minus,multiplier_scaled=unknown
    if not (-200.<minus<min(plus,0.) and -200.<plus<FT*1.2 and 0.<multiplier_scaled<300.):
        raise ValueError('Точка вне рассматриваемой активной ветви')
    lam=multiplier_scaled/E
    trace=plus+minus
    principal=(plus,minus,0.)
    dev=tuple(x-trace/3. for x in principal)
    deviator_square=fsum(x*x for x in dev)
    q=sqrt(1.5*deviator_square)
    r=max(0.,plus)/(abs(plus)-minus)
    tension_rate=FT*LENGTH/GT

    def state(alpha):
        radius=sqrt((.1*alpha*FT)**2+deviator_square)
        increment=tuple(lam*(alpha+x/radius) for x in dev)
        t=prior['t']+max(increment)*r
        c=prior['c']-min(0.,min(increment))*(1.-r)
        _,cc,kc=stresses(c,COMPRESSION)
        kt=1.-exp(-tension_rate*t)
        return increment,t,c,cc,kt,kc

    lo,hi=0.,tan(radians(32.))
    for _ in range(48):
        alpha=.5*(lo+hi)
        inc,t,c,cc,kt,kc=state(alpha)
        if alpha<angle(kt,kc,r,trace,q,weight):
            lo=alpha
        else:
            hi=alpha
    p=tuple(a+b for a,b in zip(prior['plastic'],inc,strict=True))
    eps=tuple(a+((1.+NU)*b-NU*trace)/E for a,b in zip(p,principal,strict=True))
    ex=.5*(eps[0]+eps[1]); gamma=eps[0]-eps[1]
    dc=1.-exp(-COMPRESSION[-1]*c)
    factor=(1.-r*kt)*(1.-dc)
    beta=(.88*cc/FT)-1.12
    tau=.5*(plus-minus)*factor
    steel=max(-FY,min(FY,ES*(ex-prior['ep_steel'])))
    residual=((.12*trace+q+beta*max(0.,plus))/.88-cc,
              .5*trace*factor+RHO*steel-LOAD_RATIO*tau,
              (gamma-target)*E if axis=='gamma' else (eps[2]-target)*E)
    data={'plastic':p,'t':t,'c':c,'ep_steel':ex-steel/ES,'q':(plus,minus),'gamma':gamma,
          'epsilon_x':ex,'epsilon_z':eps[2],'tau':tau,'steel_MPa':steel,'alpha':alpha,
          'compression_energy':kc,'tension_energy':kt,'residuals_MPa':residual,'multiplier':lam}
    return residual,data


def solve_three(columns, rhs):
    """Решает малую систему методом Гаусса с выбором ведущего элемента."""
    a=[list(row)+[value] for row,value in zip(zip(*columns,strict=True),rhs,strict=True)]
    for i in range(3):
        p=max(range(i,3),key=lambda j:abs(a[j][i]))
        a[i],a[p]=a[p],a[i]
        d=a[i][i]
        if abs(d)<1.e-12:
            raise ArithmeticError('Вырождённая производная')
        a[i]=[v/d for v in a[i]]
        for j in range(3):
            if j!=i:
                f=a[j][i]
                a[j]=[v-f*u for v,u in zip(a[j],a[i],strict=True)]
    return [row[-1] for row in a]


def advance(prior,target,weight,axis='gamma'):
    """Решает локальные уравнения и принимает одну положительную пластическую поправку."""
    span=target-prior['gamma' if axis=='gamma' else 'epsilon_z']
    unknown=(*prior['q'],max(1e-8,E*span))
    try:
        for _ in range(22):
            residual,data=constitutive(unknown,prior,target,weight,axis)
            norm=max(map(abs,residual))
            if norm<TOLERANCE:
                return data
            columns=[]
            for i in range(3):
                gap=min(1e-5,.1*unknown[2]) if i==2 else 1e-5
                positive=list(unknown); negative=list(unknown)
                positive[i]+=gap; negative[i]-=gap
                high=constitutive(positive,prior,target,weight,axis)[0]
                low=constitutive(negative,prior,target,weight,axis)[0]
                columns.append(tuple((a-b)/(2.*gap) for a,b in zip(high,low,strict=True)))
            direction=solve_three(columns,tuple(-v for v in residual))
            for j in range(14):
                candidate=tuple(a+b/2.**j for a,b in zip(unknown,direction,strict=True))
                try:
                    next_residual=constitutive(candidate,prior,target,weight,axis)[0]
                except ValueError:
                    continue
                if max(map(abs,next_residual))<norm:
                    unknown=candidate
                    break
            else:
                return None
    except (ValueError,ArithmeticError):
        return None
    return None
