"""Compare Wang and Huang published traces with the archived NDM MVT2 preload."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

PDF_EXPECTED = "6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E"
NATIVE_EXPECTED = "2E362A0EDC31616253D79A15F9B81AC93197A02C6673246028B2F20CE07D3AA5"
TURN_EXPECTED = "59835E1D58AF19F5FA958C28621717AE62B45FE7D0FD2AF9577C4C2F19352B71"
X_BOUND_PX = 4.0

# Pixel centers are in the raw embedded PDF figure images, origin at upper left.
# For the close-packed triangles, take their horizontal center at the target row.
# The final MVT2 point is a reading of the last marker, not a force interpolation.
AXES = {
    "T1": {"fig": 4, "x0": 82.0, "xspan": 392.5, "dx": 6, "y0": 468, "ytop": 19.5, "dy": 30},
    "T2": {"fig": 4, "x0": 630.5, "xspan": 370.5, "dx": 6, "y0": 468, "ytop": 19.5, "dy": 30},
    "MV1": {"fig": 5, "x0": 105.0, "xspan": 405.0, "dx": 25, "y0": 468, "ytop": 19.5, "dy": 200},
    "MV2": {"fig": 5, "x0": 697.5, "xspan": 323.5, "dx": 20, "y0": 467.5, "ytop": 19.5, "dy": 200},
    "MVT2": {"fig": 5, "x0": 105.0, "xspan": 358.5, "dx": 40, "y0": 1059, "ytop": 611.5, "dy": 200},
}
RAW_T = {
    ("T1", 6.5): (85.8, 371),
    ("T2", 6.5): (637.3, 371),
    ("T1", 10.51): (94.5, 311),
    ("T2", 10.51): (646.4, 311),
}
RAW_P = {
    ("MV1", "elastic_control"): (112.1, 401),
    ("MV2", "elastic_control"): (704.8, 400),
    ("MVT2", "elastic_control"): (114.5, 992),
    ("MV1", "matched_peak"): (118.3, 344),
    ("MV2", "matched_peak"): (713.3, 344),
    ("MVT2", "matched_peak"): (124.5, 935),
    ("MVT2", "yield_marker"): (171.1, 757),
    ("MVT2", "last_marker"): (476.5, 701.0),
}


def provenance(path: Path, expected: str) -> str:
    digest = hashlib.sha256(path.read_bytes()).hexdigest().upper()
    if digest != expected:
        raise ValueError(f"Unexpected SHA-256 for {path.name}: {digest}")
    return digest


def read_samples(trace: Path) -> tuple[dict[str, float], list[dict[str, float]]]:
    rows = csv.reader(trace.read_text(encoding="cp1251").splitlines(), delimiter=";")
    headers, torque, final = [], [], None
    for row in rows:
        if row[0] == "MVT2_STATE_COLUMNS":
            headers = row[1:]
        if row[0] == "MVT2_STATE" and row[1] in {"Offset", "TorsionReplayTarget"}:
            values = {key: float(value) for key, value in zip(headers[1:], row[2:], strict=True)}
            if row[1] == "Offset":
                final = values
            else:
                torque.append(values)
    assert final is not None and len(torque) == 8
    return final, torque


def digitize(name: str, point: tuple[float, float]) -> dict[str, float | list[float]]:
    x, y = point
    axis = AXES[name]
    xper = axis["dx"] / axis["xspan"]
    converted = (x - axis["x0"]) * xper
    y_value = axis["dy"] * (axis["y0"] - y) / (axis["y0"] - axis["ytop"])
    return {
        "center_px": [x, y], "ordinate_from_selected_raster_row": y_value,
        "horizontal_coordinate": converted,
        "horizontal_interval": [max(0, converted - X_BOUND_PX * xper), converted + X_BOUND_PX * xper],
    }


def interpolate_twist(rows: list[dict[str, float]], target: float) -> float:
    for left, right in zip(rows, rows[1:]):
        if left["T_kNm"] <= target <= right["T_kNm"]:
            ratio = (target - left["T_kNm"]) / (right["T_kNm"] - left["T_kNm"])
            return math.degrees(left["twist_rad_m"] + ratio * (right["twist_rad_m"] - left["twist_rad_m"]))
    raise ValueError(f"Missing torque bracket for {target}")


def gross_deflection(p_kN: float) -> dict[str, float]:
    # Unit load and real centered point load on identical symmetric supports.
    # The two halves give PL^3/(48 EI) and PL/(4 k GA), respectively.
    b = h = 240.
    length, modulus, poisson = 1200., 30000., 0.20
    shear_modulus = modulus / (2 * (1 + poisson))
    inertia, area = b * h**3 / 12, b * h
    shear_coefficient = 5 / 6
    bend = 1000 * p_kN * length**3 / (48 * modulus * inertia)
    shear = 1000 * p_kN * length / (4 * shear_coefficient * shear_modulus * area)
    return {"bending_mm": bend, "shear_mm": shear, "total_mm": bend + shear}


def compare(pdf: Path, trace: Path, turn_file: Path) -> dict:
    source = {
        "doi": "10.1371/journal.pone.0175834", "pdf_sha256": provenance(pdf, PDF_EXPECTED),
        "native_trace_sha256": provenance(trace, NATIVE_EXPECTED), "turn_result_sha256": provenance(turn_file, TURN_EXPECTED),
        "raster_images": {"4": {"xref": 125, "size_px": [1660, 547]}, "5": {"xref": 140, "size_px": [1727, 2321]}},
    }
    offset, replay = read_samples(trace)
    assert abs(offset["T_kNm"] - 10.51) < 1e-6 and abs(offset["Qy_kN"]) < 1e-9
    assert replay[-2]["tension_energy"] == 0 and replay[-1]["tension_energy"] > 0
    exact_mvt2 = json.loads(turn_file.read_text(encoding="utf-8"))["discrete_peak"]["q_kN"]
    p_targets = {"elastic_control": 30, "matched_peak": 2 * exact_mvt2, "yield_marker": 135, "last_marker": 160}
    preloads = {}
    for torque in (6.5, 10.51):
        ndm = math.degrees(offset["twist_rad_m"]) if torque == 10.51 else interpolate_twist(replay, torque)
        readings = {member: digitize(member, RAW_T[member, torque]) for member in ("T1", "T2")}
        preloads[f"{torque:g}"] = {
            "ndm_mvt2_twist_deg_per_m": ndm,
            "ndm_mvt2_is_elastic_by_saved_energy": torque < 9.19625,
            "published_control_members_deg_per_m": readings,
        }
    vertical = {}
    for name, p in p_targets.items():
        # Force balance on the two supports with a centered vertical load.
        q = p / 2
        readings = {member: digitize(member, point) for (member, key), point in RAW_P.items() if key == name}
        for reading in readings.values():
            assert abs(reading["ordinate_from_selected_raster_row"] - p) <= 0.65
        vertical[name] = {"P_kN": p, "V_kN": q, "Mx_near_midspan_kNm": .60 * q,
                          "publication_displacement_mm": readings, "gross_elastic_displacement_mm": gross_deflection(p)}
    return {
        "source": source, "raster_axes": AXES, "horizontal_reading_bound_px": X_BOUND_PX,
        "preload": preloads, "vertical": vertical,
        "damage_onset_bracket_kNm": [replay[-2]["T_kNm"], replay[-1]["T_kNm"]],
        "MVT2_observed_first_crack_kNm": 6.5,
        "ndm_torque_at_zero_first_energy_kNm": replay[-2]["T_kNm"],
        "ndm_torsional_preload_tension_energy_final": offset["tension_energy"],
        "limitations": [
            "Figure 4 contains separate nominally matched pure-torsion members T1 and T2, no measured MVT2 twist.",
            "The bounds represent a horizontal reading window on the journal raster only.",
            "Figure 5 is a full-beam midpoint displacement. NDM archive contains one section per stated wrench.",
            "The gross elastic calculation assumes a uniform, uncracked beam and is used as scale control.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("trace", type=Path)
    parser.add_argument("turn_json", type=Path)
    parser.add_argument("result", type=Path)
    args = parser.parse_args()
    content = compare(args.pdf, args.trace, args.turn_json)
    args.result.write_text(json.dumps(content, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
