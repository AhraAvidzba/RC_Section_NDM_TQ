from pathlib import Path
from PIL import Image,ImageDraw
path=Path(__file__).parent
for name, fig, box, xstep, ystep, scale in [
    ('T1','fig4',(65,265,135,475),5,10,4),
    ('T2','fig4',(615,265,680,475),5,10,4),
    ('MVT2','fig5',(38,600,486,1105),20,20,1),
    ('MV1','fig5',(38,0,490,520),20,20,1),
    ('MV2','fig5',(560,0,1050,520),20,20,1),
]:
    orig=Image.open(path/f'{fig}.jpeg').convert('RGB')
    l,t,r,b=box
    c=orig.crop(box).resize(((r-l)*scale,(b-t)*scale))
    d=ImageDraw.Draw(c)
    for x in range(l,r):
        if x % xstep == 0:
            xp=(x-l)*scale
            d.line((xp,0,xp,c.height),fill=(240,218,218),width=1)
            d.text((xp+1,0),str(x),fill=(139,29,29))
    for y in range(t,b):
        if y % ystep == 0:
            yp=(y-t)*scale
            d.line((0,yp,c.width,yp),fill=(197,218,229),width=1)
            d.text((0,yp+2),str(y),fill=(24,81,111))
    c.save(path/f'{name}_grid.png')
