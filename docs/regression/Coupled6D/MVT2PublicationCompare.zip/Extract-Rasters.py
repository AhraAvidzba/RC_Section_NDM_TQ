"""Extract the raw journal rasters used for graphical readings."""
import argparse
from pathlib import Path

import fitz

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("pdf", type=Path)
parser.add_argument("out", type=Path)
args = parser.parse_args()
out = args.out
with fitz.open(args.pdf) as article:
    for figure, page_id, xref, dimensions in ((4, 7, 125, (1660, 547)), (5, 8, 140, (1727, 2321))):
        page = article[page_id - 1]
        assert any(row[0] == xref for row in page.get_images())
        image = article.extract_image(xref)
        assert (image["width"], image["height"]) == dimensions and image["ext"] == "jpeg"
        dest = out / f"fig{figure}.jpeg"
        dest.write_bytes(image["image"])
        print(f"{dest.name} {dimensions[0]} x {dimensions[1]}")
