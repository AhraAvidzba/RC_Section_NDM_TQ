"""Сверяет состояние сжатого бетона MVT2 на траектории с плечом 396 мм."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha256
from io import BytesIO
import json
from os import devnull
from pathlib import Path
from zipfile import ZipFile


BASE_SHA = '5C53523A297D6A4827292AE62F09478BB14DCA4AF2A86BD0F08C97E5291A7669'
CUT_SHA = '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD'
LEVELS = (55000., 67500., 75312.5)
WIRE = 'MVT2Cut396CompressionWire.json.gz'


def digest(raw):
    return sha256(raw).hexdigest().upper()


def read_inputs(repo, base_zip, cut_zip):
    """Сверяет архивы, данные траектории и общий набор операторов."""
    raw = base_zip.read_bytes()
    assert digest(raw) == BASE_SHA
    with ZipFile(BytesIO(raw)) as archive:
        code = archive.read('Verify-MVT2Compression.py')
        reference = json.loads(archive.read('MVT2CompressionProof.json'))
    base = {'__name__':'__pinned__','__file__':str(Path(__file__).with_name('Verify-MVT2Compression.py'))}
    exec(compile(code,base['__file__'],'exec'),base)
    local, _, command, _ = base['read_inputs'](repo)
    raw = cut_zip.read_bytes()
    assert digest(raw) == CUT_SHA
    with ZipFile(BytesIO(raw)) as archive:
        proof=json.loads(archive.read('Cut396.json'))
        encoded=archive.read('Cut396.stress.json.gz')
    assert proof['stress_sha256']==digest(encoded) and proof['arm_mm']==396.
    assert proof['result']['terminal']['reason']=='bounded_numerical_stop'
    tensors=json.loads(decompress(encoded))
    history=list(zip(proof['result']['accepted'],tensors['stress'],tensors['steel'],strict=True))
    assert len(history)==41 and history[-1][0]['Q_target_N']==LEVELS[-1]
    assert command==reference['material_command']
    return base, local, command, reference, proof, history


def capture(repo, base_zip, cut_zip, output):
    """Повторяет принятую историю OpenSees и считывает три материальных ответа."""
    import numpy as np
    import openseespy.opensees as ops

    assert ops.version()=='3.8.0' and np.__version__=='2.3.5'
    base, local, command, reference, _, history=read_inputs(repo,base_zip,cut_zip)
    stations=base['STATIONS']
    _, directions, _, _, _ = local['geometry'](repo)
    with local['archive'](repo,'operators') as archive:
        operator=archive.read('Native/Operators.csv')
    rows = [row.split(';') for row in operator.decode('ascii').splitlines() if row.startswith('B;')]
    active={(int(p),int(j)):[float(v) for v in vals] for _,p,j,*vals in rows}
    b, g = (np.array([[[active[p,j][i] for j in range(1,61)] for i in components]
                      for p in range(1,46)]) for components in (range(6),range(6,12)))
    field_operator=np.stack([b+z*g for z in stations])
    ops.wipe()
    ops.logFile(devnull,'-noEcho')
    ops.model('basic','-ndm',3,'-ndf',3)
    try:
        for tag in range(1,136):
            ops.nDMaterial(command[0],tag,*command[1:])
        curves={key:[list(ops.NDTest('GetResponse',1,key+letter)) for letter in 'esq'] for key in 'TC'}
        assert curves==reference['curve_columns_e_s_q']
        maximum_error=0.
        readings={}
        for step, stored, steel in history:
            q=step['Q_target_N']
            components=field_operator@np.asarray(step['field'])
            concrete=np.empty((3,45,6))
            measures=[[],[],[]]
            for sid, layer in enumerate(components):
                for index,(xx,yy,zz,xy,xz,yz) in enumerate(layer):
                    tag=1+45*sid+index
                    ops.NDTest('SetStrain',tag,xx,yy,zz,xy,yz,xz)
                    x,y,z,xy,yz,xz=ops.NDTest('GetStress',tag)
                    concrete[sid,index]=(x,y,z,xy,xz,yz)
                    if q in LEVELS and index<25:
                        measures[sid].append([list(ops.NDTest('GetResponse',tag,key)) for key in base['RESPONSES']])
            steel_stress=np.asarray(steel[local['STEEL_COLUMN']])[:,:,1]
            concrete[:,25:]=-concrete[:,25:]+steel_stress[:,:,None]*np.asarray(directions)[None,:,:]
            maximum_error=max(maximum_error,float(np.max(np.abs(concrete-stored))))
            assert maximum_error < 1e-12
            for tag in range(1,136):
                ops.NDTest('CommitState',tag)
            if q in LEVELS:
                readings[str(float(q))]=measures
    finally:
        ops.wipe()
    raw={'ASD_engine':ops.version(),'numpy':np.__version__,'replayed_states':len(history),
         'stress_maximum_error_MPa':maximum_error,'compression_responses':readings,
         'operator_sha256':digest(operator)}
    with output.open('xb') as fp:
        fp.write(compress(json.dumps(raw,sort_keys=True,separators=(',',':'),allow_nan=False).encode(),mtime=0))


def verify(repo, base_zip, cut_zip, source):
    """Собирает шесть усилий и проверяет положение на восходящей ветви сжатия."""
    base, local, command, reference, proof, history=read_inputs(repo,base_zip,cut_zip)
    points, _, area, length, _=local['geometry'](repo)
    raw=source.read_bytes()
    wire=json.loads(decompress(raw))
    assert wire['ASD_engine']=='3.8.0' and wire['numpy']=='2.3.5'
    assert wire['replayed_states']==len(history) and wire['stress_maximum_error_MPa']<1e-12
    assert tuple(sorted(map(float,wire['compression_responses'])))==LEVELS
    peaks={'C':reference['compression_peak_equivalent_measure'],'T':reference['tensile_peak_equivalent_measure']}
    curves=reference['curve_columns_e_s_q']
    prior=[[[[0.,0.],[0.,0.],[0.,0.]] for _ in range(25)] for _ in base['STATIONS']]
    snapshots=[]
    worst=0.
    table_error=[0.,0.]
    for step, net, _ in history:
        q,t=step['Q_target_N'],step['T_target_Nmm']
        demand=(0.,-396.*q,0.,t,0.,q)
        actual=local['signed_forces'](net[0],points)
        bounds=(area,area*length,area*length,area*length,area,area)
        current=max(abs(a-b)/bound for a,b,bound in zip(actual,demand,bounds,strict=True))
        assert current<=step['tolerance_MPa']
        worst=max(current,worst)
        if q in LEVELS:
            markers=wire['compression_responses'][str(float(q))]
            base['check_tabulated_response'](curves,markers,command[1],table_error)
            state=base['describe'](markers,net,points,peaks,prior)
            snapshots.append({'Qy_N':q,**state})
            prior=markers
    assert all(0<=e<1e-12 for e in table_error)
    assert snapshots[-1]['Qy_N']==LEVELS[-1] and len(snapshots)==len(LEVELS)
    return {'status':'PASS','base_archive_sha256':BASE_SHA,'section_archive_sha256':CUT_SHA,
            'wire_sha256':digest(raw),'replayed_states':len(history),'max_action_residual_MPa':worst,
            'model_curve_peak_equivalent_compression':peaks['C'],
            'max_table_errors':table_error,'observations':snapshots,
            'stress_maximum_error_MPa':wire['stress_maximum_error_MPa'],
            'terminal_output':proof['result']['terminal'],'terminal_probe_full_tensor_available':False,
            'comparison_model_600mm_at_last_state':reference['selected_accepted_states'][-1],
            'physical_capacity_established':False}


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--base',type=Path,required=True)
    parser.add_argument('--cut',type=Path,required=True)
    parser.add_argument('--capture',type=Path)
    parser.add_argument('--report',type=Path)
    parser.add_argument('--wire',type=Path,default=Path(__file__).with_name(WIRE))
    args=parser.parse_args()
    if args.capture:
        capture(args.repo,args.base,args.cut,args.capture)
        print('MVT2 CUT396 COMPRESSION CAPTURE PASS',digest(args.capture.read_bytes()))
        return
    result=verify(args.repo,args.base,args.cut,args.wire)
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(result,output,ensure_ascii=False,sort_keys=True,indent=2)
        output.write('\n')
    print('MVT2 CUT396 COMPRESSION OFFLINE PASS',result['replayed_states'])


if __name__=='__main__':
    main()
