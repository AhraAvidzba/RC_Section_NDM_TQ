"""Разлагает номинальные тензоры бетона на положительную и отрицательную части."""

from argparse import ArgumentParser
from gzip import decompress
from hashlib import sha256
from io import BytesIO
from math import copysign, fsum, hypot
from pathlib import Path
from zipfile import ZipFile
import json


DIRECTORY = Path('docs/regression/Coupled6D')
ARCHIVE = 'MVT2Cut396FixedStrainASD20261117.zip'
ARCHIVE_SHA = '66B681EF09F92BAD0F238CB838D5BCFD8DACDDB36D7041C454F76C49606B30F4'
WIRE_SHA = '34418735E7087DAAC5400408ECF8F5E7F7BA1CA0C251FBAB379D4EB93D384127'


def read_replay(repo):
    """Загружает прежнюю геометрию и проверенный отклик OpenSees."""
    raw = (repo / DIRECTORY / ARCHIVE).read_bytes()
    assert sha256(raw).hexdigest().upper() == ARCHIVE_SHA
    with ZipFile(BytesIO(raw)) as source:
        concrete = source.read('Cut396FixedStrain.json.gz')
        module = source.read('Replay-Cut396FixedStrain.py')
    reference = {'__name__': '__pinned__', '__file__': str(Path(__file__).with_name('Replay-Cut396FixedStrain.py'))}
    exec(compile(module, reference['__file__'], 'exec'), reference)
    assert sha256(concrete).hexdigest().upper() == WIRE_SHA
    return reference, json.loads(decompress(concrete))


def rotate(matrix, vectors):
    """Диагонализует симметричный тензор вращениями Якоби."""
    for _ in range(32):
        p, q = max(((0,1), (0,2), (1,2)), key=lambda a: abs(matrix[a[0]][a[1]]))
        off = matrix[p][q]
        if abs(off) < 1e-15:
            return [matrix[i][i] for i in range(3)]
        z = (matrix[q][q] - matrix[p][p]) / (2 * off)
        tangent = copysign(1. / (abs(z) + hypot(1., z)), z)
        cosine = 1. / hypot(1., tangent)
        sine = cosine * tangent
        k = 3 - p - q
        a, b = matrix[k][p], matrix[k][q]
        matrix[k][p] = matrix[p][k] = cosine*a - sine*b
        matrix[k][q] = matrix[q][k] = sine*a + cosine*b
        matrix[p][p] -= tangent * off
        matrix[q][q] += tangent * off
        matrix[p][q] = matrix[q][p] = 0.
        for row in vectors:
            a, b = row[p], row[q]
            row[p], row[q] = cosine*a - sine*b, sine*a + cosine*b
    raise ArithmeticError('Не достигнута точность диагонализации тензора')


def split(row):
    """Возвращает две части одного симметричного номинального тензора."""
    xx, yy, zz, xy, xz, yz = row
    tensor = [[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]]
    axes = [[1. if i == j else 0. for j in range(3)] for i in range(3)]
    principal = rotate([line.copy() for line in tensor], axes)
    entries = ((0,0), (1,1), (2,2), (0,1), (0,2), (1,2))
    pos = [fsum(axes[i][k] * axes[j][k] * max(v,0.) for k,v in enumerate(principal)) for i,j in entries]
    neg = [fsum(axes[i][k] * axes[j][k] * min(v,0.) for k,v in enumerate(principal)) for i,j in entries]
    reconstruction = max(abs(a+b-c) for a,b,c in zip(pos,neg,row,strict=True))
    axes_residual = max(abs(fsum(tensor[i][k]*axes[k][j] for k in range(3)) - axes[i][j]*principal[j])
                        for i in range(3) for j in range(3))
    orthogonality = max(abs(fsum(axes[i][k] * axes[j][k] for k in range(3)) - (i==j))
                        for i in range(3) for j in range(3))
    assert reconstruction < 2e-13 and axes_residual < 2e-13 and orthogonality < 4e-15
    assert fsum(pos[:3]) >= -1e-13 and fsum(neg[:3]) <= 1e-13
    return pos, neg, reconstruction


def verify(repo):
    """Интегрирует три разложения для двух совместных состояний и чистого кручения."""
    replay, wire = read_replay(repo)
    _, path, positions, *_ = replay['read_data'](repo)
    calculate = replay['strip_resultants']
    no_steel = dict.fromkeys(range(26,46), 0.)
    checkpoints = {}
    worst_tensor = 0.
    worst_action = 0.
    for index, (phase, torque, shear, native) in enumerate(path):
        if phase != 'R8' and shear not in (20000., 21875.):
            continue
        states = {'ndm': [row[6:] for row in native.values()]}
        states.update({key: data[index][0] for key, data in wire['stress'].items()})
        decomposition = {}
        for model, stress in states.items():
            parts = [split(row) for row in stress]
            positive, negative, errors = zip(*parts, strict=True)
            worst_tensor = max(worst_tensor, *errors)
            direct, direct_net = calculate(positions, stress, no_steel)
            plus, plus_net = calculate(positions, positive, no_steel)
            minus, minus_net = calculate(positions, negative, no_steel)
            for branch in ('gross_concrete', 'replaced_concrete'):
                err = max(abs(x+y-z) for x,y,z in zip(plus[branch], minus[branch], direct[branch], strict=True))
                worst_action = max(worst_action, err)
                assert err < 2e-7
            err = max(abs(a+b-c) for a,b,c in zip(plus_net, minus_net, direct_net, strict=True))
            worst_action = max(worst_action, err)
            assert err < 2e-7
            decomposition[model] = dict(positive=plus, negative=minus, concrete=direct,
                                        positive_net=plus_net, negative_net=minus_net, concrete_net=direct_net)
        checkpoints[phase] = dict(applied_T_Nmm=torque, applied_Qy_N=shear, models=decomposition)
    assert list(checkpoints) == ['R8', 'S9', 'S10A21875']
    return dict(worst_tensor_reconstruction_MPa=worst_tensor, worst_action_reconstruction_N_Nmm=worst_action,
                input_wire_sha256=WIRE_SHA, cases=checkpoints)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    proof = verify(args.repo)
    with args.report.open('x', encoding='utf-8', newline='\n') as file:
        json.dump(proof, file, indent=2, sort_keys=True, allow_nan=False)
        file.write('\n')
    print('MVT2 CUT396 PRINCIPAL SIGN OFFLINE PASS 3')
