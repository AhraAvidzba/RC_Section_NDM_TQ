"""Упаковывает только новые исходники и протокол HardGrowthSplit."""
from argparse import ArgumentParser
from pathlib import Path
from runpy import run_path
from subprocess import PIPE, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
ARCHIVES=REPO/'docs/regression/Coupled6D'
DEFAULT_GROWTH=ARCHIVES/'HardShearCoarseGrowthWorkbookNative20261117.zip'
DEFAULT_STOCK=ARCHIVES/'HardShearInstalledStockTiming20261117.zip'
NAME='HardShearCoarseGrowthSplitNative20261117'
portable=run_path(str(HERE/'Verify-Portable.py'))


def collect(source,baseline_growth,baseline_stock,native_sha):
    code=portable
    plan=code['spec']((source/code['PLAN']).read_bytes())
    shared=dict(code['inherited'](plan,baseline_growth,baseline_stock))
    paths=['ABManifest.json','Compile.log','CompileClosure.json',code['CODE'],'Run.ndjson']
    paths.extend(n for n in plan['inputs'] if n!=code['BOOK'] and n not in shared)
    paths.extend(path.relative_to(source).as_posix() for path in sorted((source/'Native/B').iterdir()) if path.is_file())
    assert len(paths)==len(set(paths))
    data={p:(source/p).read_bytes() for p in paths}
    for filename,digest in plan['inputs'].items():
        if filename==code['BOOK']:
            continue
        raw=shared[filename] if filename in shared else data[filename]
        assert code['digest'](raw)==digest and raw==(source/filename).read_bytes()
    native='Native/B/Both.txt'
    assert code['digest'](data[native])==native_sha.upper()
    owner_fixture=next(row[len('RESULTS_SAVE_REOPEN: '):].split('; file=',1)[1]
                       for row in data[native].decode('utf-8-sig').splitlines()
                       if row.startswith('RESULTS_SAVE_REOPEN: '))
    saved=Path(owner_fixture).resolve()
    assert saved.is_relative_to(source.resolve()/'Temp') and saved.name=='RC_Section_NDM_saved.xlsm'
    reader=run_path(str(REPO/'tmp/hs-growth-probe/ReadWorkbookCurve.py'))['read_curve']
    data[code['CURVE_NEW']]=code['bytes_json'](reader(saved))
    for name in (code['FAILURE'],'SplitProofReplay.py'):
        data[name]=(HERE/name).read_bytes()
    expanded=code['reconstruct'](data,baseline_growth,baseline_stock)
    with TemporaryDirectory(prefix='native-detached-',dir=HERE) as work:
        root=Path(work)
        for name,raw in expanded.items():
            target=root/code['safe'](name)
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(raw)
        data[code['OFFLINE']]=code['bytes_json'](code['replay'](root))
    for path in ('Pack.py','Verify-Portable.py','README-Portable.md'):
        data[path]=(HERE/path).read_bytes()
    for path in data:
        code['safe'](path)
    data[code['SUMS']]=code['bytes_json'](dict(sorted((n,code['digest'](v)) for n,v in data.items())))
    return data


def seal(out,raw):
    if out.exists():
        assert out.read_bytes()==raw
    else:
        out.write_bytes(raw)


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('source',type=Path)
    cli.add_argument('report_sha')
    cli.add_argument('--growth',type=Path,default=DEFAULT_GROWTH)
    cli.add_argument('--stock',type=Path,default=DEFAULT_STOCK)
    args=cli.parse_args()
    stock,growth=args.stock.resolve(),args.growth.resolve()
    code=portable
    data=collect(args.source,code['members'](growth,code['GROWTH']),code['members'](stock,code['STOCK']),args.report_sha)
    out=HERE/'proof'
    out.mkdir(exist_ok=True)
    with TemporaryDirectory(prefix='portable-',dir=out) as directory:
        root=Path(directory)
        temp=root/'candidate.zip'
        with ZipFile(temp,'w',compression=ZIP_DEFLATED,compresslevel=9) as archive:
            for n,raw in sorted(data.items()):
                entry=ZipInfo(n,date_time=(2026,11,17,0,0,0))
                entry.create_system=3
                entry.external_attr=0o100644 << 16
                archive.writestr(entry,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
        detached=root/'unpacked'
        with ZipFile(temp) as archive:
            archive.extractall(detached)
        replay=run([sys.executable,'-B','-X','utf8','Verify-Portable.py',str(growth),str(stock)],cwd=detached,stdout=PIPE,check=True).stdout
        zipped=temp.read_bytes()
        sha=code['digest'](zipped)
        seal(out/(NAME+'.zip'),zipped)
        seal(out/(NAME+'.zip.sha256'),f'{sha} *{NAME}.zip\n'.encode())
        seal(out/(NAME+'.replay.txt'),replay)
    print(out/(NAME+'.zip'),sha,len(zipped))
    print(replay.decode().splitlines()[-1])


if __name__=='__main__':
    main()
