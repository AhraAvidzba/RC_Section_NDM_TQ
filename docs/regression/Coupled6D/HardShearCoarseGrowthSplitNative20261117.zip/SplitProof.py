"""Independently checks paired force balances, split history and unchanged full B path."""
from collections import defaultdict
from hashlib import sha256
import json
from math import fsum, isclose, isfinite, sqrt
from pathlib import Path
import struct

TARGET=(28000.,510000.,180000.,1500000.,17000.,-7100.)
PREVIOUS='976DB81C6B049808D2D19C57322E5353A2C2D745C7E3C8E89697BDF278BF7365'


def nums(rows):
    values=list(map(float,rows))
    assert all(map(isfinite,values))
    return values


def decoded(rows):
    return [struct.unpack('>d',bytes.fromhex(word))[0] for word in rows]


def maximum(rows):
    return max(map(abs,rows))


def dot(first,second):
    return fsum(a*b for a,b in zip(first,second,strict=True))


def grouped(lines,key,size):
    data={}
    for row in lines[key]:
        idx=tuple(map(int,row[:size]))
        assert idx not in data
        data[idx]=row[size:]
    return data


def verify(root,b_result,growth):
    old=(root/'PreviousB.json').read_bytes()
    assert sha256(old).hexdigest().upper()==PREVIOUS
    previous=json.loads(old)
    comparison_keys=('results_reopened_sha256','probes','assertions','capacity_status','result_code',
                     'lower_lambda','limit_lambda','direct_N_Nmm')
    assert all(b_result[k]==previous['B'][k] for k in comparison_keys)
    assert growth==previous['continuation']
    raw=(root/'Native/B/Both.txt').read_text(encoding='utf-8-sig')
    lines=defaultdict(list)
    for line in raw.splitlines():
        key,*record=line.split(';')
        if key.startswith('GR') or key=='RNB':
            lines[key].append(record)
    interval,=lines['GRH']
    assert interval[0]=='1' and len(interval)==10
    a,c,count=map(int,interval[1:4])
    nominal,width,left_coord,right_coord,left_lambda,right_lambda=nums(interval[4:])
    assert c==a+1 and count<=94 and nominal>0. and 3.5<=width/nominal<=4.+1e-9
    assert isclose(right_coord-left_coord,width,rel_tol=1e-9)
    replays=grouped(lines,'GRR',2)
    fields=grouped(lines,'GRF',3)
    balances=grouped(lines,'GRA',3)
    weak=grouped(lines,'GRW',3)
    ext=grouped(lines,'GRE',3)
    bounds=grouped(lines,'GRU',3)
    assert fields.keys()==balances.keys()==bounds.keys()==weak.keys()==ext.keys()
    assert set(fields)<={(1,1,1),(1,2,1),(1,2,2)} and (1,1,1) in fields
    expected_replays={(1,0),(1,1)}
    if (1,2,2) in fields:
        expected_replays.add((1,2))
    assert set(replays)==expected_replays
    for (case,route),row in replays.items():
        assert row==[str({0:a,1:c,2:c+1}[route]),'1223','exact']
    restored,=lines['GRZ']
    assert restored==['1',str(c),str(count)]
    histories=grouped(lines,'GRS',3)
    for case,route in expected_replays:
        for side in (-1,0,1):
            actual=histories[case,route,side]
            assert len(actual)==1223 and actual==histories[case,route+10,side]
            assert all(isfinite(v) for v in decoded(actual))
    assert len(histories)==6*len(expected_replays)
    projection=[nums(row[1:]) for row in lines['GRP']]
    anchor=[nums(row[1:]) for row in lines['GRX']]
    assert len(anchor)==len(projection)==1 and len(anchor[0])==len(projection[0])==60
    assert isclose(dot(projection[0],anchor[0]),left_coord,abs_tol=2e-17)
    previous_path=[int(row[1]) for row in lines['GRT']]
    assert previous_path==list(range(1,c+1))
    out={}
    for key,record in sorted(balances.items()):
        _,route,k=key
        prev,lam,coord,coord_by_field,maximum_lambda,steel,n,g,tau,E,A,L=nums(record[:12])
        assert record[12]=='True' and len(record)==33
        absolute,relative=nums(record[13:15])
        initial,target,actual=[nums(record[i:i+6]) for i in (15,21,27)]
        controls=nums(fields[key])
        weak_rows=nums(weak[key]); external=nums(ext[key])
        assert len(weak_rows)==len(external)==len(controls)==60
        residual=[(a-b)/scale for a,b,scale in zip(actual,target,(A,A*L,A*L,A*L,A,A),strict=True)]
        forward=dot(projection[0],controls)
        assert isclose(forward,coord_by_field,abs_tol=2e-17)
        common_target=(left_coord+width*k/route)
        assert abs(forward-common_target)*E<=tau
        assert all(isclose(a,b*lam,rel_tol=2e-14,abs_tol=2e-10) for a,b in zip(target,TARGET,strict=True))
        assert all(isclose(a,b*prev,rel_tol=2e-14,abs_tol=2e-10) for a,b in zip(initial,TARGET,strict=True))
        assert isclose(tau,absolute+relative*maximum(external[:56]),abs_tol=2e-19)
        assert isclose(g,E*maximum(weak_rows[56:]),abs_tol=2e-15)
        assert max(g,maximum(residual),maximum(weak_rows[:56]),abs(forward-common_target)*E)<=tau+2e-15
        assert 0<lam<=maximum_lambda and 0<=steel<=1 and maximum(residual)<=n+2e-12
        assert n<=tau
        assert forward>(left_coord if k==1 else out['2.1']['coordinate'])
        uncertainty,=nums(bounds[key])
        assert uncertainty>0
        out[f'{route}.{k}']=dict(lambda_value=lam,control_error_from_common_target_MPa=E*(forward-common_target),
                                 coordinate=forward,tolerance_MPa=tau,steel_utilization=steel,
                                 max_weak_MPa=maximum(weak_rows[:56]),max_gauge_MPa=g,
                                 signed_force_residuals_MPa=residual,lambda_uncertainty=uncertainty)
    result=dict(nominal=nominal,actual_width=width,width_to_nominal=width/nominal,anchor_index=a,coarse_index=c,
                probes_at_coarse=count,full_B_unchanged=True,exact_replay_for_all_present_routes=True,
                history_words_per_station=1223,route_measurements=out,physical_limit_certified=False)
    if '2.2' not in out:
        refusal,=lines['GRQ']
        assert int(refusal[0]) in (1,2)
        result['targeted_outcome']='HALF_REFUSED'
        result['refusal']=refusal
        return result
    assert not lines['GRQ']
    delta=out['2.2']['lambda_value']-out['1.1']['lambda_value']
    bound=out['2.2']['lambda_uncertainty']+out['1.1']['lambda_uncertainty']
    result['half_minus_full_lambda_interval']=[delta-bound,delta+bound]
    result['lambda_uncertainty_relative_to_progress']=bound/abs(right_lambda-left_lambda)
    caps={}
    for side in (-1,0,1):
        a,b=(decoded(histories[1,r,side]) for r in (1,2))
        indices={'concrete_strain':(1,7),'concrete_stress':(7,13),'concrete_plastic':(13,19),'concrete_hardening':(19,21),
                 'tangent_flag':(21,22),'concrete_cohesion':(22,24),'concrete_damage':(24,26),'concrete_energy':(26,28)}
        maxima={kind:maximum((b[idx+j*27]-a[idx+j*27]) for j in range(43) for idx in range(*span))
                for kind,span in indices.items()}
        for i,name in enumerate(('steel_plastic','steel_backstress','steel_stress')):
            maxima[name]=maximum(b[1169+i+3*j]-a[1169+i+3*j] for j in range(18))
        maxima['steel_utilization_max_difference']=maximum(b[j]-a[j] for j in (1164,1166,1168))
        maxima['steel_point_index_changes']=sum(a[j]!=b[j] for j in (1163,1165,1167))
        caps[str(side)]=maxima
    signatures=grouped(lines,'RNB',4)
    left={(side,point):value[1:] for (route,k,side,point),value in signatures.items() if (route,k)==(11,1)}
    right={(side,point):value[1:] for (route,k,side,point),value in signatures.items() if (route,k)==(12,2)}
    assert len(left)==len(right)==129 and left.keys()==right.keys()
    result['terminal_branch_signature_changes']=sum(left[k]!=right[k] for k in left)
    result['accepted_history_maxima_by_station']=caps
    result['targeted_outcome']='BOTH_ROUTES_CONFIRMED'
    return result
