"""Готовит один прямой широкий шаг B и два полушага от того же состояния."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re


HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
B=Path('D:/CodexScratch/RC_Section_NDM_TQ/HardGrowthAB1')
B_SHA='976DB81C6B049808D2D19C57322E5353A2C2D745C7E3C8E89697BDF278BF7365'
OLD=ROOT/'docs/regression/Audit03/LocalGradientDerivative20261115/ProductionYieldRecovery/PostPeakWideStepRefinement/Source'
AUTO=ROOT/'tmp/hs-p31-auto/ready'
CONT='src/Solver/CCoupledDeformationContinuation.cls'
NEWTON='src/Solver/CCoupledNewtonSolver.cls'
CONCRETE='src/Materials/CCoupledConcreteResponse.cls'
STEEL='src/Materials/CCoupledReinforcedResponse.cls'
MACRO='tests/modTestCoupledElasticState.bas'
IMPORTS=[Path(name).stem for name in (CONT,NEWTON,CONCRETE,STEEL,MACRO)]


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def read(path):
    return text(path.read_bytes())


def line(source,a,b):
    assert source.count(a)==1,a
    return source.replace(a,b)


def method(source,kind,name):
    decl=re.search(r'^(?:Private|Friend|Public) '+kind+' '+name+r'\(',source,re.M)
    assert decl
    begin=source.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,decl.start())
    end=source.index('\nEnd '+kind,decl.start())+len('\nEnd '+kind)
    return source[begin:end]


def bytes_vba(src):
    assert max(map(len,src.splitlines()))<1024
    return (src.rstrip()+'\n').replace('\n','\r\n').encode()


def continuation(src):
    old=read(OLD/Path(CONT).name)
    members=old[old.index("' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Берёт только фактически"):]
    start=members.index('    If Not mFollowingLocalPeak')
    end=members.index('\nEnd Function',start)
    members=members[:start]+'''    If Not mFollowingLocalPeak Or Len(mPostPeakControlName) = 0 Or mTestGrowthCaseCount <> 0 Then Exit Function
    If nominal <= 0# Or trial.Coordinate - current.Coordinate < 3.5 * nominal Then Exit Function
    TestPickGrowthInterval = 1'''+members[end:]
    members=line(members,'If Not TrialMovesForward(child, child.Count) Then',
                 'If Not UpdateTrialCoordinate(halfPoint, last.Coordinate) Then')
    members=line(members,'    beforeProbes = mProbeCount: beforeDetails = mProbeDetails',
                 '''    beforeProbes = mProbeCount: beforeDetails = mProbeDetails
    Dim priorYieldProbes As Long, priorFixedProbes As Long
    priorYieldProbes = mYieldRecoveryProbes: priorFixedProbes = mFixedYieldRecoveryProbes''')
    members=line(members,'    mProbeCount = beforeProbes: mProbeDetails = beforeDetails',
                 '''    mProbeCount = beforeProbes: mProbeDetails = beforeDetails
    mYieldRecoveryProbes = priorYieldProbes: mFixedYieldRecoveryProbes = priorFixedProbes''')
    members=line(members,'CStr(UBound(c)) & ";exact")','CStr(UBound(c)) & ";exact")\n    TestLogGrowthStates trialCase, route + 10, c, p, m')
    members=line(members,'    TestGrowthReplay trialCase, 0, child, seedCenter, seedPlus, seedMinus',
                 '    TestLogGrowthStates trialCase, 0, seedCenter, seedPlus, seedMinus\n'
                 '    TestGrowthReplay trialCase, 0, child, seedCenter, seedPlus, seedMinus')
    members=line(members,'    mSolver.TestReadRefinementBranches 10 * trialCase + route, k, field',
                 '''    mSolver.TestReadGrowthWeakRows trialCase, route, k
    mSolver.TestReadRefinementBranches 10 * trialCase + route, k, field''')
    vba_vector='    Call TestRechartLog(key & "0" & TestRechartVector(c))'
    members=line(members,vba_vector,vba_vector.replace('TestRechartVector','TestWideSplitBitsVector'))
    for side,array in (('1','p'),('-1','m')):
        vba_vector='    Call TestRechartLog(key & "'+side+'" & TestRechartVector('+array+'))'
        members=line(members,vba_vector,vba_vector.replace('TestRechartVector','TestWideSplitBitsVector'))
    members=line(members,'If left(i) <> right(i) Then Exit Function',
                 'If HardRankBitsTest(left(i)) <> HardRankBitsTest(right(i)) Then Exit Function')
    # Probe is diagnostic here. Any refused half still restores main history and counters.
    start=members.index('    Dim last As TBranchPoint')
    end=members.index('    TestGrowthReplay trialCase, 1, history',start)
    section=members[start:end]
    section=line(section,'''        If Not Probe(halfPoint, last.Lambda, False) Then _
            Err.Raise 5, "TestRunGrowthComparison", "Обычная половинная проба не решена. " & mProbeDetails''',
        '''        If Not Probe(halfPoint, last.Lambda, False) Then
            Call TestRechartLog("GRQ;" & CStr(k) & ";NUMERICAL;" & Replace(mProbeDetails, ";", "|"))
            GoTo RestoreMain
        End If''')
    section=line(section,'''        If halfPoint.Lambda <= 0# Or halfPoint.Lambda > mMaximumLambda Or BeyondSteelLimit() Then _
            Err.Raise 5, "TestRunGrowthComparison", "Половинная проба вышла за физические границы."''',
        '''        If halfPoint.Lambda <= 0# Or halfPoint.Lambda > mMaximumLambda Or BeyondSteelLimit() Then
            Call TestRechartLog("GRQ;" & CStr(k) & ";LIMIT_GATE")
            GoTo RestoreMain
        End If''')
    section=line(section,'''        If Not UpdateTrialCoordinate(halfPoint, last.Coordinate) Then _
            Err.Raise 5, "TestRunGrowthComparison", "Половинная проба не продвинулась по принятой мере."''',
        '''        If Not UpdateTrialCoordinate(halfPoint, last.Coordinate) Then
            Call TestRechartLog("GRQ;" & CStr(k) & ";CONTROL_STALL")
            GoTo RestoreMain
        End If''')
    section=section+'RestoreMain:\n'
    members=members[:start]+section+members[end:]
    v=line(src,'Private mPostPeakWidePoints As Long\n','Private mPostPeakWidePoints As Long\nPrivate mTestGrowthCaseCount As Long\n')
    v=line(v,'    mPostPeakWidePoints = 0\n','    mPostPeakWidePoints = 0\n    mTestGrowthCaseCount = 0\n')
    marker='            AcceptPoint history, trial\n'
    insert='''            Dim testGrowthCase As Long, testSeedCenter() As Double, testSeedPlus() As Double, testSeedMinus() As Double
            testGrowthCase = TestPickGrowthInterval(increment, nominal, current, trial)
            If testGrowthCase > 0 Then
                mSolver.TestCopyRefinementHistory testSeedCenter, testSeedPlus, testSeedMinus
                TestLogGrowthProbe testGrowthCase, 1, 1, current, trial
            End If
'''+marker+'''            If testGrowthCase > 0 Then TestRunGrowthComparison testGrowthCase, history, current, trial, nominal, _
                trial.Coordinate - current.Coordinate, testSeedCenter, testSeedPlus, testSeedMinus
'''
    return bytes_vba(line(v,marker,insert).rstrip()+'\n\n'+members)


def material(src,name):
    preserved=read(AUTO/name)
    if name==CONCRETE:
        methods=[method(preserved,'Sub','CopyHardF19ConcreteHistoryTest')]
    else:
        methods=[method(preserved,kind,f) for kind,f in (('Sub','CopyHardF19SteelHistoryTest'),('Function','HardF19ConcreteTest'))]
    return bytes_vba(src.rstrip()+'\n\n'+'\n\n'.join(methods))


def newton(src):
    old=read(OLD/Path(NEWTON).name)
    criteria=method(old,'Function','TestReadRechartCriteria')
    start=criteria.index('    Dim initialEquations')
    stop=criteria.index('    For i = mGaugeStart',start)
    criteria=criteria[:start]+'''    Dim gauge As Double, i As Long, area As Double, length As Double
    Dim tolerance As Double: tolerance = EquilibriumTolerance(absoluteTolerance, relativeTolerance)
'''+criteria[stop:]
    branch=method(old,'Sub','TestReadRefinementBranches')
    return bytes_vba(src.rstrip()+'\n\n'+criteria+'\n\n'+branch+'\n\n'+read(HERE/'NewtonHooks.bas').rstrip())


def runner(src):
    s=src.replace('HardGrowthAB1','HardGrowthSplit').replace('HardGrowthAB','HardGrowthSplit')
    s=line(s,'-ModuleNames CCoupledDeformationContinuation','-ModuleNames '+','.join(IMPORTS))
    s=line(s,'modTestCoupledElasticState.RunTestCoupledWorkbookTiming','modTestCoupledElasticState.RunTestWideSplit')
    return s.encode()


def verify_src(src,solver_hash):
    src=line(src,'27099C1E3F2CB0514C18AD3804039D784B91015D83366A200ADC49BACEE923B8',solver_hash)
    src=line(src,'plan["modules"] == ["CCoupledDeformationContinuation"]','plan["modules"] == '+repr(IMPORTS))
    src=line(src,'receipt["Modules"] == plan["modules"]','sorted(receipt["Modules"]) == sorted(plan["modules"])')
    src=line(src,'    out = HERE / "ABVerification.json"','''    import SplitProof
    comparison["wide_split"] = SplitProof.verify(HERE, b, comparison["continuation"])
    out = HERE / "ABVerification.json"''')
    return src.encode()


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--destination',type=Path,default=HERE/'ready')
    parser.add_argument('--with-workbook',action='store_true')
    args=parser.parse_args()
    dest=args.destination.resolve()
    assert dest.is_relative_to(HERE) or dest==B.parent/'HardGrowthSplit'
    previous=B/'ABVerification.json'
    assert sha(previous.read_bytes())==B_SHA
    old_plan=json.loads((B/'ABManifest.json').read_bytes())
    assert sha((B/CONT).read_bytes())==old_plan['inputs'][CONT]=='27099C1E3F2CB0514C18AD3804039D784B91015D83366A200ADC49BACEE923B8'
    files={}
    for name,digest in old_plan['inputs'].items():
        if name.startswith('workbook/') or name in (CONT,'Run-FullAB.ps1','Verify-FullAB.py','Stage.py'):
            continue
        raw=(B/name).read_bytes()
        assert sha(raw)==digest,name
        files[name]=raw
    files[CONT]=continuation(read(B/CONT))
    files[NEWTON]=newton(read(ROOT/NEWTON))
    for name in (CONCRETE,STEEL):
        files[name]=material(read(ROOT/name),name)
    extra=read(OLD/'modTestCoupledElasticState.vba')
    extra=extra[extra.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------",0,extra.index('Public Function TestRechartLog')):]
    macro=read(ROOT/MACRO)
    from_auto=read(AUTO/MACRO)
    if 'Public Function HardRankBitsTest(' not in macro:
        types='\n'.join(re.search(r'^Private Type '+typename+r'\n.*?^End Type',from_auto,re.M|re.S).group()
                        for typename in ('THardRankNumberTest','THardRankWordsTest'))
        macro=line(macro,'Option Explicit\n','Option Explicit\n\n'+types+'\n')
        macro=macro.rstrip()+'\n\n'+method(from_auto,'Function','HardRankBitsTest')
    files[MACRO]=bytes_vba(macro.rstrip()+'\n\n'+read(HERE/'Macro.bas').rstrip()+'\n\n'+extra)
    files['Run-FullAB.ps1']=runner(read(B/'Run-FullAB.ps1'))
    files['Verify-FullAB.py']=verify_src(read(B/'Verify-FullAB.py'),sha(files[CONT]))
    files['PreviousB.json']=previous.read_bytes()
    for name in ('Stage.py','SplitProof.py','Macro.bas','NewtonHooks.bas'):
        files[name]=(HERE/name).read_bytes()
    book='workbook/output/RC_Section_NDM.xlsm'
    report={**old_plan,'modules':IMPORTS,'inputs':{name:sha(raw) for name,raw in files.items()}|{book:old_plan['book_sha256']}}
    if args.with_workbook:
        raw=(ROOT/book).read_bytes()
        assert sha(raw)==old_plan['book_sha256']
        files[book]=raw
        files[old_plan['draft']]=raw
        for name in ('Temp','Native/B'):
            (dest/name).mkdir(parents=True,exist_ok=True)
    files['ABManifest.json']=(json.dumps(report,indent=2)+'\n').encode()
    for name,raw in files.items():
        target=dest/name
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.is_file():
            assert target.read_bytes()==raw,name
        else:
            target.write_bytes(raw)
    print('WIDE SPLIT INPUTS',dest,sha(files['ABManifest.json']),sha(files[CONT]))


if __name__=='__main__':
    main()
