' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает шесть подписанных результирующих через имеющуюся парную запись,
' все слабые уравнения и четыре связи из фактически принятой численной пробы.
Friend Sub TestReadGrowthWeakRows(ByVal trialCase As Long, ByVal route As Long, ByVal k As Long)
    RequireCandidate
    Call TestRechartLog("GRW;" & CStr(trialCase) & ";" & CStr(route) & ";" & CStr(k) & TestRechartVector(mResidual))
    Call TestRechartLog("GRE;" & CStr(trialCase) & ";" & CStr(route) & ";" & CStr(k) & TestRechartVector(mExternal))
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Копирует весь принятый закон бетона и стали в каждой из трёх станций.
Friend Sub TestCopyRefinementHistory(ByRef centerState() As Double, ByRef plusState() As Double, ByRef minusState() As Double)
    centerState = TestReadWideStationHistory(0)
    plusState = TestReadWideStationHistory(1)
    minusState = TestReadWideStationHistory(-1)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Буферы, внутренние переменные бетона и продольной/поперечной стали.
Private Function TestReadWideStationHistory(ByVal side As Long) As Double()
    Dim material As CCoupledReinforcedResponse: Set material = YieldResponse(side)
    Dim concrete As CCoupledConcreteResponse: Set concrete = material.HardF19ConcreteTest
    Dim state() As Double, steel() As Double, i As Long, first As Long
    concrete.CopyHardF19ConcreteHistoryTest state
    material.CopyHardF19SteelHistoryTest steel
    first = UBound(state)
    ReDim Preserve state(1 To first + UBound(steel))
    For i = 1 To UBound(steel): state(first + i) = steel(i): Next i
    TestReadWideStationHistory = state
End Function
