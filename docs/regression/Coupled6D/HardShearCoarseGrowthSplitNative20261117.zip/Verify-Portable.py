"""Проверяет отчёт двух полушагов без рабочей книги и без Excel."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path, PureWindowsPath
import re
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
SPLIT='0A2228943D99E6359C589C4443BE83FBB5534AE211C196FFC836FC3717899439'
GROWTH='40B29680E2E73033519883545091BD201DC109430D405151D8EC5EBF97B99302'
STOCK='C452D2A59077C5DA5F6667DDD5ADF33778A0681F1B955A0E091FB08D8D2EE24F'
REPORT='ABVerification.json'
PLAN='ABManifest.json'
SCORE='PreviousB.json'
CURVE_PREVIOUS='ReferenceBWorkbookCurve.json'
CURVE_NEW='InstrumentedWorkbookCurve.json'
OFFLINE='SplitOfflineVerification.json'
FAILURE='OriginalVerifierFailure.txt'
SAVED_NEW='35206570'

SUMS='SHA256SUMS.json'
CODE='docs/regression/CodeUpdate.json'
CONT='src/Solver/CCoupledDeformationContinuation.cls'
BASE='245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
BOOK='workbook/output/RC_Section_NDM.xlsm'
EXPECTED_REPORT='976DB81C6B049808D2D19C57322E5353A2C2D745C7E3C8E89697BDF278BF7365'


def digest(raw):
    return sha256(raw).hexdigest().upper()


def bytes_json(value):
    return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()


def members(path,expected):
    assert digest(path.read_bytes())==expected,path
    with ZipFile(path) as ref:
        return {name:ref.read(name) for name in ref.namelist()}


def spec(data):
    assert digest(data)==SPLIT
    plan=json.loads(data)
    assert plan['book_sha256']==plan['inputs'][BOOK]==BASE and len(plan['modules'])==5
    return plan


def inherited(plan,growth,stock):
    assert digest(growth[REPORT])==EXPECTED_REPORT
    for name,value in plan['inputs'].items():
        if name==BOOK:
            continue
        if name==SCORE:
            raw=growth[REPORT]
        elif name.startswith('StockPrior/'):
            raw=stock.get(name.removeprefix('StockPrior/'))
        else:
            raw=stock.get(name) or growth.get(name)
        if raw is not None and digest(raw)==value:
            yield name,raw


def reconstruct(archive,growth,stock):
    previous=dict(inherited(spec(archive[PLAN]),growth,stock))
    assert archive.keys().isdisjoint(previous)
    assert CURVE_PREVIOUS not in archive
    result={**previous,**archive,CURVE_PREVIOUS:growth['CandidateWorkbookCurve.json']}
    for key,d in spec(archive[PLAN])['inputs'].items():
        if key!=BOOK:
            assert digest(result[key])==d,key
    return result


def safe(name):
    p=Path(name)
    assert not p.is_absolute() and ':' not in name and '\\' not in name and '..' not in p.parts
    assert p.suffix.lower()!='.xlsm'
    return p


def replay(tmp):
    p=Path(tmp)
    cfg=json.loads((p/PLAN).read_bytes())
    code=json.loads((p/CODE).read_bytes())
    compile_closure=json.loads((p/'CompileClosure.json').read_bytes())
    log=(p/'Compile.log').read_text(encoding='utf-8-sig')
    assert code['Compiled'] and not code['ProductionChanged'] and code['ProductionSHA256']==BASE
    assert sorted(code['Modules'])==sorted(cfg['modules']) and len(code['Modules'])==5
    assert compile_closure['State']=='Absent'
    assert log.count(f"OWNED_EXCEL: id={compile_closure['PID']}; utcStartTicks={compile_closure['StartTicksUTC']}")==1
    assert PureWindowsPath(code['Workbook'])==PureWindowsPath(
        r'D:\CodexScratch\RC_Section_NDM_TQ\HardGrowthSplit\docs\regression\Diagnostic.xlsm'
    )
    temporal=(p/'Run.ndjson').read_text(encoding='utf-8-sig').splitlines()
    phases=[json.loads(row) for row in temporal]
    assert len(phases)==2 and [x['phase'] for x in phases]==['CompileHardGrowthSplit','RunHardGrowthSplit']
    for phase in phases:
        assert all(entry['ProtectedUser'] for entry in phase['excel'])
    verify=run_path(str(p/'Verify-FullAB.py'))
    a=verify['stock'](p,False)
    b=verify['native'](p/'Native/B',code['WorkbookSHA256'])
    native_owner=json.loads((p/'Native/B/Both.txt.Ownership.json').read_bytes())
    born={compile_closure['PID'],native_owner['PID']}
    assert all(entry['Id'] not in born for phase in phases for entry in phase['excel'])
    text=(p/'Native/B/Both.Execution.txt').read_text(encoding='utf-16')
    record,=set(re.findall(r'GrowthTestAcceptedBeyondDouble=(\d+); GrowthTestFinalLambda=([\d.,Ee+-]+)',text))
    observed={'accepted_beyond_double':int(record[0]),'last_positive_lambda':verify['number'](record[1])}
    original=p/'SplitProof.py'
    repaired=p/'SplitProofReplay.py'
    old=original.read_text(encoding='utf-8-sig')
    before="comparison_keys=('results_reopened_sha256','probes','assertions','capacity_status','result_code',"
    after="comparison_keys=('probes','assertions','capacity_status','result_code',"
    assert old.count(before)==1
    assert repaired.read_text(encoding='utf-8-sig')==old.replace(before,after)
    old_receipt=json.loads((p/SCORE).read_bytes())
    new_results=b['results_reopened_sha256']
    old_results=old_receipt['B']['results_reopened_sha256']
    assert new_results!=old_results
    try:
        run_path(str(original))['verify'](p,b,observed)
    except AssertionError as err:
        assert err.__traceback__.tb_next.tb_frame.f_code.co_name=='verify'
        line=old.splitlines()[err.__traceback__.tb_next.tb_lineno-1]
        assert 'assert all(b_result[k]==previous' in line
    else:
        raise AssertionError('Expected named source verifier discrepancy was not reproduced')
    failure=(p/FAILURE).read_text(encoding='utf-8-sig')
    assert 'assert all(b_result[k]==previous' in failure and 'AssertionError' in failure
    summary=run_path(str(repaired))['verify'](p,b,observed)
    reference=json.loads((p/CURVE_PREVIOUS).read_bytes())
    actual=json.loads((p/CURVE_NEW).read_bytes())
    assert actual['saved_workbook_sha256'].startswith(SAVED_NEW)
    assert actual['named_anchor']==reference['named_anchor']
    assert actual['worksheet']==reference['worksheet']
    assert actual['entries']==reference['entries'] and len(actual['entries'])==136
    lambdas=[float(e[-1]) for e in actual['entries'] if e[1]=='Lambda']
    assert len(lambdas)==68
    assert abs(lambdas[summary['coarse_index']-1]-summary['route_measurements']['1.1']['lambda_value'])<1e-13
    summary['exact_saved_curve_factor_and_offset_rows']=136
    summary['saved_B_workbook_sha256']=[reference['saved_workbook_sha256'],actual['saved_workbook_sha256']]
    summary['separate_run_reopen_hashes']=[old_results,new_results]
    summary['original_offline_verifier_failed_cross_run_full_Results_hash']=True
    ownership=json.loads((p/'Native/B/Both.txt.ProcessClosure.json').read_bytes())
    summary['compiled_workbook_sha256']=code['WorkbookSHA256']
    summary['owned_native_process_closed']=ownership['Closure']['FinalState']
    expected={'stock_source':'archive §490','A':a,'B':b,'matched_runtime_delta_s':None,
              'continuation':observed,'wide_split':summary}
    assert summary['full_B_unchanged'] and summary['exact_replay_for_all_present_routes']
    assert not summary['physical_limit_certified']
    return expected


def verify(root,growth,stock):
    checks=json.loads((root/SUMS).read_bytes())
    archive={path.relative_to(root).as_posix():path.read_bytes() for path in root.rglob('*') if path.is_file()}
    assert archive.keys()==checks.keys()|{SUMS}
    for name,expected in checks.items():
        safe(name)
        assert digest(archive[name])==expected,name
    all_files=reconstruct(archive,members(growth,GROWTH),members(stock,STOCK))
    with TemporaryDirectory(prefix='split-expanded-',dir=root.parent) as directory:
        folder=Path(directory)
        for n,data in all_files.items():
            file=folder/safe(n)
            file.parent.mkdir(parents=True,exist_ok=True)
            file.write_bytes(data)
        checked=replay(folder)
    assert json.loads(all_files[OFFLINE])==checked
    summary=checked["wide_split"]
    print(bytes_json(summary).decode().strip())
    print(f'HARDSHEAR_WIDE_SPLIT_PORTABLE: VERIFIED_EVIDENCE; {summary["targeted_outcome"]}; physical_limit_certified=False')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('growth',type=Path)
    parser.add_argument('stock',type=Path)
    args=parser.parse_args()
    verify(HERE,args.growth,args.stock)
