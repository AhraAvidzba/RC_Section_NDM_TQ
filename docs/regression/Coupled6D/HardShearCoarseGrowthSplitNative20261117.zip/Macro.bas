' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вызывает штатную проверку HardShear и прилагает точные пробы широкого шага.
Public Function RunTestWideSplit(ByVal operation As String, ByVal storage As String) As String
    Call TestRechartLog(clearLog:=True)
    RunTestWideSplit = RunTestCoupledWorkbookTiming(operation, storage) & vbCrLf & TestRechartLog()
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает принятые буферы материалов шестнадцатеричными словами Double.
Public Function TestWideSplitBitsVector(ByRef values() As Double) As String
    Dim i As Long
    For i = 1 To UBound(values)
        TestWideSplitBitsVector = TestWideSplitBitsVector & ";" & HardRankBitsTest(values(i))
    Next i
End Function
