"""Подготавливает три истории деформаций сечения для повтора материалом НДМ."""

from argparse import ArgumentParser
from gzip import decompress
from hashlib import sha256
import json
from math import fsum
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
ARTIFACTS = Path('docs/regression/Coupled6D')
FIXED = ('MVT2Cut396FixedStrainASD20261117.zip',
         '66B681EF09F92BAD0F238CB838D5BCFD8DACDDB36D7041C454F76C49606B30F4')
MATCHED = ('MVT2MatchedNativeHistoryASD20261117.zip',
           'BBE66E1B4D599DD5F50196F01083488C612AD6415441C3F7E539FF98BF4BB427')
CUT = ('MVT2PublicationCut20261117.zip',
       '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD')
TEST = 'tests/modTestMVT2GaussSpan.bas'
VBA = 'ReverseMaterial.bas.txt'
PATHS = ('NDM', 'MatchedASD', 'LongASD')


def digest(raw):
    return sha256(raw).hexdigest().upper()


def open_checked(repo, entry):
    """Открывает сравниваемую историю по закреплённым байтам архива."""
    filename, expected = entry
    path = repo / ARTIFACTS / filename
    assert digest(path.read_bytes()) == expected
    return ZipFile(path)


def load(repo):
    """Собирает одинаковые операторы и принятые поля обоих решателей."""
    with open_checked(repo, FIXED) as source:
        code = source.read('Replay-Cut396FixedStrain.py')
        fixed = {'__name__': '__pinned__', '__file__': str(HERE / 'Replay-Cut396FixedStrain.py')}
        exec(compile(code, fixed['__file__'], 'exec'), fixed)
        external_on_ndm = json.loads(decompress(source.read('Cut396FixedStrain.json.gz')))['stress']['default']
    tables, path, points, area, radius, _, model, _, _, _ = fixed['read_data'](repo)
    with open_checked(repo, MATCHED) as source:
        matched = json.loads(source.read('MatchedHistory.json'))
        trace = source.read('MatchedHistory.stress.json.gz')
        assert digest(trace) == matched['stress_sha256']
        loaded_matched = json.loads(decompress(trace))
    with open_checked(repo, CUT) as source:
        cut = json.loads(source.read('Cut396.json'))
        trace = source.read('Cut396.stress.json.gz')
        assert digest(trace) == cut['stress_sha256']
        loaded_cut = json.loads(decompress(trace))
    assert matched['arm_mm'] == cut['arm_mm'] == 396.
    assert matched['operator_identity'] == cut['operators']
    sections = {
        'NDM': [(name, torque, shear, tables['F'][name]) for name, torque, shear, _ in path],
        'MatchedASD': [(p['phase'], p['T_target_Nmm'], p['Q_target_N'], tuple(p['field']))
                       for p in matched['solution']['accepted']],
        'LongASD': [(p['phase'], p['T_target_Nmm'], p['Q_target_N'], tuple(p['field']))
                    for p in cut['result']['accepted']],
    }
    assert len(sections['NDM']) == len(sections['MatchedASD']) == 22 and len(sections['LongASD']) == 41
    assert [p[1:3] for p in sections['NDM']] == [p[1:3] for p in sections['MatchedASD']]
    assert sections['MatchedASD'][:8] == sections['LongASD'][:8]
    assert sections['LongASD'][-1][2] == 75312.5
    return sections, (tables, path, points, area, radius, model), (fixed, external_on_ndm, loaded_matched, loaded_cut)


def strains(tables, field):
    """Вычисляет шесть инженерных деформаций в центре и на станциях производной."""
    for side in (0, 1, -1):
        for point in range(1, 46):
            b = [tables['B'][point, i] for i in range(1, 61)]
            if side == 0:
                yield tuple(fsum(v[k] * x for v, x in zip(b, field, strict=True)) for k in range(6))
            else:
                yield tuple(fsum((v[k] + side * .001 * v[k + 6]) * x
                                 for v, x in zip(b, field, strict=True)) for k in range(6))


def input_wire(sections, tables):
    """Сериализует точные двоичные числа в переносимом десятичном виде."""
    wire = []
    for label, fields in sections.items():
        wire.append(f'PATH;{label};{len(fields)}')
        for step, (_, _, _, field) in enumerate(fields, 1):
            for point, value in enumerate(strains(tables, field), 1):
                wire.append(f'{step};{point};' + ';'.join(map(repr, value)))
    return ('\r\n'.join(wire) + '\r\n').encode('ascii')


def stage(repo, root, guard_pid, guard_ticks):
    """Готовит отдельную книгу и добавляет только сценарий записи материалов."""
    sections, (tables, *_), _ = load(repo)
    prepare = run_path(str(HERE / 'Stage-CorrectPanelJacobian.py'))
    prepare['stage'](repo, root, guard_pid, guard_ticks)
    test = root / TEST
    module = test.read_text(encoding='utf-8-sig')
    anchor = 'completed = TestMixedPanelWeight(report, tracePath)'
    assert module.count(anchor) == 1
    module = module.replace(anchor, 'completed = TestReversedMVT2Material(report, tracePath)')
    module += (HERE / VBA).read_text(encoding='utf-8')
    module.encode('cp1251')
    test.write_bytes(module.replace('\n', '\r\n').encode('utf-8-sig'))
    replay = root / 'Replay.Fields.csv'
    replay.write_bytes(input_wire(sections, tables))
    driver = root / 'Run-Native.ps1'
    content = driver.read_text('utf-8')
    assert content.count("($trace+'.Dilation.csv') -Destination \"Native/PanelWeights.csv\"") == 1
    content = content.replace("($trace+'.Dilation.csv') -Destination \"Native/PanelWeights.csv\"",
                              "($trace+'.Replay.csv') -Destination \"Native/MaterialReplay.csv\"")
    driver.write_bytes(content.encode())
    meta = root / 'Preparation.json'
    data = json.loads(meta.read_bytes())
    data['strain_histories'] = {name: len(fields) for name, fields in sections.items()}
    data['field_archives'] = dict((FIXED, MATCHED, CUT))
    for path in (test, replay, driver):
        data['inputs'][path.relative_to(root).as_posix()] = digest(path.read_bytes())
    meta.write_bytes((json.dumps(data, indent=2) + '\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--guard-pid', type=int, required=True)
    parser.add_argument('--guard-ticks', type=int, required=True)
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve(), args.guard_pid, args.guard_ticks)
