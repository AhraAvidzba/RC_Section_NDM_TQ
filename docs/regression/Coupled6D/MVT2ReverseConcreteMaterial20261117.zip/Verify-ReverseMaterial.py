"""Сверяет обратную подстановку бетона НДМ на полях OpenSees."""

from argparse import ArgumentParser
from itertools import groupby
import json
from math import fsum, isfinite
from pathlib import Path
from re import findall
from runpy import run_path
from zipfile import ZipFile


def read_native(root, helpers, prep, histories, stages, spectra):
    """Проверяет протокол Excel и независимо восстанавливает номинальные напряжения."""
    read, digest = helpers['read'], helpers['digest']
    artifacts = root / 'Native'
    receipt = (artifacts / 'MVTGaussMixed.txt').read_text(encoding='utf-8-sig')
    compile_result = read(root / 'CodeUpdate.json')
    owner = read(artifacts / 'MVTGaussMixed.txt.Ownership.json')
    closure = read(artifacts / 'MVTGaussMixed.txt.ProcessClosure.json')
    identity = closure['Closure']['Identity']
    assert compile_result['Compiled'] and not compile_result['ProductionChanged']
    assert compile_result['ProductionSHA256'] == helpers['BOOK'] == prep['source_book_sha256']
    assert compile_result['WorkbookSHA256'] == owner['SourceSHA256']
    assert set(compile_result['Modules']) == {'CCoupledConcreteResponse','CCoupledElasticState',
                                              'CCoupledSectionQuadrature','modTestMVT2GaussSpan'}
    assert read(root / 'CompileClosure.json')['State'] == 'Absent'
    assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen']
    assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['RunnerCleanupValid']
    assert identity['Valid'] and identity['PID'] == owner['PID'] and identity['Ticks'] == int(owner['StartTicksUTC'])
    assert closure['Closure']['FinalState']['State'] == 'Absent'
    assert f'TEST_EXCEL_PROCESS: id={owner["PID"]}; startTicks={owner["StartTicksUTC"]}' in receipt
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in receipt
    assert 'RUNTIME ERROR:' not in receipt
    report = (artifacts / 'MVTGaussMixed.csv').read_text('ascii')
    records = findall(r'MVT2_REVERSE_MATERIAL;(\w+);(\d+);(\d+)', report)
    assert [n for n, _, _ in records] == list(histories)
    expected = {n: (int(count), int(point)) for n, count, point in records}
    for name, (count, point) in expected.items():
        assert 0 <= count <= len(histories[name])
        assert (point == 0) == (count == len(histories[name]))
    elapsed, = findall(r'CASE_FINISHED;MVTGaussMixed;(?:True|False);([^\n]+)', report)
    for filename in ('Guard-IsolatedOffice.ps1', 'Replay.Fields.csv', stages['TEST'], helpers['SOURCE'], 'Run-Native.ps1'):
        assert digest((root / filename).read_bytes()) == prep['inputs'][filename]
    original = (root / 'Replay.Fields.csv').read_text('ascii').splitlines()
    inputs = {}
    for raw in original:
        line = raw.split(';')
        if line[0] == 'PATH':
            label = line[1]
            continue
        inputs[label, int(line[0]), int(line[1])] = raw

    native = {label: [] for label in histories}
    maximum_nominal_error = 0.
    max_volume = dict.fromkeys(histories, 0.)
    raw = (artifacts / 'MaterialReplay.csv').read_text('ascii').splitlines()
    groups = groupby((row.split(';') for row in raw), key=lambda row: (row[0], int(row[1])))
    previous = {}
    for (label, step), rows in groups:
        assert step == len(native[label]) + 1
        states = []
        for row in rows:
            point = int(row[2])
            assert point == len(states) + 1 and len(row) == 29
            assert ';'.join(row[1:9]) == inputs[label, step, point]
            data = tuple(map(float, row[3:]))
            assert all(map(isfinite, data))
            strain, sigma, plastic = data[:6], data[6:12], data[12:18]
            dt, dc, kt, kc = data[-4:]
            assert all(0. <= v < 1. for v in (dt, dc, kt, kc))
            past = previous.get((label, point), (0., 0., 0., 0.))
            assert all(a >= b - 5e-15 for a, b in zip((dt, dc, kt, kc), past, strict=True))
            previous[label, point] = (dt, dc, kt, kc)
            elastic = tuple(a - b for a,b in zip(strain, plastic, strict=True))
            trace = fsum(elastic[:3])
            effective = (*[25000. * value + (25000. / 3.) * trace for value in elastic[:3]],
                         *[12500. * value for value in elastic[3:]])
            principal = spectra(effective)
            norm = fsum(map(abs, principal))
            r = fsum(v for v in principal if v > 0.) / norm if norm else 0.
            factor = (1. - r * dt) * (1. - dc)
            stress_error = max(abs(a - b * factor) for a, b in zip(sigma, effective, strict=True))
            assert stress_error < 2e-9
            maximum_nominal_error = max(maximum_nominal_error, stress_error)
            max_volume[label] = max(max_volume[label], abs(fsum(plastic[:3])))
            states.append((sigma, plastic, dt, dc, kt, kc))
        assert len(states) == 135
        native[label].append([states[i:i+45] for i in (0,45,90)])
    assert len(raw) == 135 * sum(len(states) for states in native.values())
    assert {name: len(values) for name, values in native.items()} == {n: c for n, (c, _) in expected.items()}
    assert {name: len(values) for name, values in native.items()} == {name: len(fields) for name, fields in histories.items()}
    return native, {'replay_count': len(raw), 'excel_pid': owner['PID'], 'status': expected,
                    'nominal_tensor_error_MPa': maximum_nominal_error,
                    'max_absolute_plastic_volume': max_volume, 'macro_seconds': float(elapsed)}


def integrate(operator, tables, points, scale, field, layers, bars, wanted):
    """Собирает усилия и проверяет согласованность правых частей."""
    parts, six = operator['strip_resultants'](points, layers[0], bars[0])
    net = [operator['assemble_net'](v, steel, points) for v, steel in zip(layers, bars, strict=True)]
    assert max(abs(a-b) for a,b in zip(six, operator['resultant'](points, net[0]), strict=True)) < 1e-6
    weak, _ = operator['weak_action'](tables, net)
    residual = [a + fsum(x*y for x,y in zip(tables['G'][i+1], field, strict=True))
                  - fsum(tables['L'][j][i] * value for j, value in enumerate(wanted, 1))
                for i, a in enumerate(weak)]
    strength = max(abs(a - b) / s for a,b,s in zip(six, wanted, scale, strict=True))
    return {'internal_N_Nmm': six, 'parts_N_Nmm': parts,
            'norm_MPa': max(strength, max(map(abs, residual[:56])), 30000. * max(map(abs, residual[56:])))}


def spectral_parts(raw, spectra):
    """Разлагает напряжения по знаку главных величин через спектральный проектор."""
    eig = spectra(raw)
    zero = (0.,) * 6
    if eig[-1] <= 0.:
        return raw, zero
    if eig[0] >= 0.:
        return zero, raw
    x,y,z,xy,xz,yz = raw
    matrix = ((x,xy,xz),(xy,y,yz),(xz,yz,z))
    single_negative = eig[1] >= 0.
    one, a, b = eig if single_negative else reversed(eig)
    denominator = (one-a) * (one-b)
    first = tuple(tuple(v - (a if i==j else 0.) for j,v in enumerate(row)) for i,row in enumerate(matrix))
    second = tuple(tuple(v - (b if i==j else 0.) for j,v in enumerate(row)) for i,row in enumerate(matrix))
    isolated = tuple(one * fsum(first[i][k]*second[k][j] for k in range(3)) / denominator
                     for i,j in ((0,0),(1,1),(2,2),(0,1),(0,2),(1,2)))
    rest = tuple(full-part for full,part in zip(raw, isolated, strict=True))
    check = spectra(isolated)
    assert abs(fsum(isolated[:3]) - one) < 5e-9 and min(abs(one-v) for v in check) < 5e-8
    return (isolated, rest) if single_negative else (rest, isolated)


def spectral_integrals(operator, points, centre, spectra):
    """Интегрирует обе части бетона вместе с вычетом замещённого объёма."""
    concrete = [spectral_parts(row, spectra) for row in centre]
    parts = {}
    for k, label in enumerate(('compressive', 'tensile')):
        net = [p[k] if i < 25 else tuple(-v for v in p[k]) for i,p in enumerate(concrete)]
        parts[label] = operator['resultant'](points, net)
    return parts


def verify(repo, root):
    """Разделяет историю деформаций, бетонную модель и работу арматуры на трёх путях."""
    stage = run_path(str(root / 'Stage-ReverseMaterial.py'))
    histories, (tables, path, points, area, radius, _), references = stage['load'](repo)
    operator, asd_on_ndm, matched, extended = references
    archive = repo / 'docs/regression/Coupled6D/MVT2NativePublicationCutMaterialHistory20261117.zip'
    assert stage['digest'](archive.read_bytes()) == '6920EB24A5D01585E510FDBC1064513C0C83AA62583AEB0C2553D6F0D495EE55'
    with ZipFile(archive) as source:
        utility = {'__name__': '__pinned__'}
        exec(compile(source.read('Verify-NativeMaterialHistory.py'), str(archive), 'exec'), utility)
    prep = utility['read'](root / 'Preparation.json')
    assert prep['strain_histories'] == {name: len(fields) for name, fields in histories.items()}
    assert (root / 'Replay.Fields.csv').read_bytes() == stage['input_wire'](histories, tables)
    spectra = utility['principal']
    native, checked = read_native(root, utility, prep, histories, stage, spectra)
    scale = (area, area*radius, area*radius, area*radius, area, area)
    comparison, maximum_ndm_stress_delta, steel_max = {}, 0., {}
    expected_stress = {'NDM': asd_on_ndm, 'MatchedASD': matched['stress'], 'LongASD': extended['stress']}
    for label, fields in histories.items():
        comparison[label] = []
        steel_max[label] = [0., 0.]
        for i, (phase, torque, shear, field) in enumerate(fields):
            states = native[label][i]
            strain = list(stage['strains'](tables, field))
            wanted = (0., -396.*shear, 0., torque, 0., shear)
            ndm = [[p[0] for p in band] for band in states]
            if label == 'NDM':
                _, _, _, tensors = path[i]
                max_delta = max(abs(a-b) for p in points for a,b in zip(ndm[0][p-1], tensors[p][6:], strict=True))
                maximum_ndm_stress_delta = max(maximum_ndm_stress_delta, max_delta)
                assert max_delta < 2e-7
            bars = []
            for layer in range(3):
                bar_stresses = {}
                for p in range(26,46):
                    direction = points[p][3:]
                    projected = fsum(a*b for a,b in zip(direction, strain[layer*45+p-1], strict=True))
                    if label == 'NDM':
                        sigma = 200000. * projected
                        assert abs(sigma) < (498. if p <= 29 else 450.)
                    else:
                        wire = matched if label == 'MatchedASD' else extended
                        archived = wire['steel'][i]['columns_strain_stress_tangent_plastic_backstress_increment'][layer][p-26]
                        eps, sigma = archived[:2]
                        assert abs(projected - eps) < 6e-16
                    bar_stresses[p] = sigma
                    family = int(p > 29)
                    steel_max[label][family] = max(steel_max[label][family], abs(sigma))
                bars.append(bar_stresses)
            asd = expected_stress[label][i]
            if label != 'NDM':
                # Архив равновесного OpenSees содержит результирующие напряжения в точках стали.
                # Для общего интегратора восстанавливаем бетон из разности стали и результирующего тензора.
                asd = [operator['assemble_net'](layer, steel, points)
                       for layer, steel in zip(asd, bars, strict=True)]
            new_ndm = integrate(operator, tables, points, scale, field, ndm, bars, wanted)
            old_asd = integrate(operator, tables, points, scale, field, asd, bars, wanted)
            tolerance = 5e-7 + 5e-7*max(abs(fsum(tables['L'][p][j]*value
                                       for p, value in enumerate(wanted, 1))) for j in range(56))
            asserted = new_ndm if label == 'NDM' else old_asd
            assert asserted['norm_MPa'] <= tolerance, (label, phase, asserted['norm_MPa'], tolerance, asserted['internal_N_Nmm'])
            pressure = [fsum(p[1][:3]) for p in states[0][:25]]
            row = {
                'phase': phase, 'Qy_N': shear, 'T_target_Nmm': torque, 'ndm': new_ndm, 'asd': old_asd,
                'max_center_primary_tensile_damage': max(p[2] for p in states[0][:25]),
                'max_center_primary_compressive_damage': max(p[3] for p in states[0][:25]),
                'max_center_primary_compression_energy': max(p[5] for p in states[0][:25]),
                'minimum_center_primary_nominal_principal_MPa': min(spectra(p[0])[0] for p in states[0][:25]),
                'centred_primary_plastic_volume_min_max': [min(pressure), max(pressure)],
            }
            if i in (7, len(fields)-1) or shear in (20000., 40000., 67500.):
                row['concrete_spectral_N_Nmm'] = {}
                for material, centre, result in (('ndm', ndm[0], new_ndm), ('asd', asd[0], old_asd)):
                    parts = spectral_integrals(operator, points, centre, spectra)
                    assert all(abs(lo+hi-gross-replaced) < 3e-8 for lo,hi,gross,replaced in zip(
                        *parts.values(), result['parts_N_Nmm']['gross_concrete'],
                        result['parts_N_Nmm']['replaced_concrete'], strict=True))
                    row['concrete_spectral_N_Nmm'][material] = parts
            comparison[label].append(row)
    assert native['MatchedASD'][:8] == native['LongASD'][:8]
    checked['replayed_native_tensors_error_MPa'] = maximum_ndm_stress_delta
    checked['max_steel_abs_MPa_longitudinal_and_transverse'] = steel_max
    return {'verification': checked, 'paths': comparison}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    proof = verify(args.repo.resolve(), args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, indent=2, sort_keys=True, allow_nan=False)
        output.write('\n')
    print('MVT2 REVERSE MATERIAL OFFLINE PASS', proof['verification']['replay_count'])
