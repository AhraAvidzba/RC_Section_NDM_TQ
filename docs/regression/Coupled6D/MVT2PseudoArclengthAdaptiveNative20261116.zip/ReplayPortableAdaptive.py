"""Restore shared Jet and native-comparison inputs and replay the adaptive outcome."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile


here = Path(__file__).resolve().parent
jet_sha = "6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33"
comparison_sha = "20F807CD70BDBA3797FE2709B7BDBA9131BF128B25FFBD38C8236F42D5B69229"
report_sha = "B8F43A7B4298A3147D64A2B0741C59F5844A1CE2F3F3332DE85EDEC10F101EE7"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jet_archive", type=Path)
    parser.add_argument("comparison_archive", type=Path)
    args = parser.parse_args()
    assert digest(args.jet_archive.read_bytes()) == jet_sha
    assert digest(args.comparison_archive.read_bytes()) == comparison_sha
    assert digest((here / "VerificationAdaptivePrecision.json").read_bytes()) == report_sha
    manifest = json.loads((here / "PortableManifest.json").read_bytes())
    with (tempfile.TemporaryDirectory() as folder, ZipFile(args.jet_archive) as jet,
          ZipFile(args.comparison_archive) as comparison):
        stage = Path(folder)
        sources = {"jet": jet, "comparison": comparison}
        for name, item in manifest.items():
            archive = item.get("archive")
            raw = ((here / name).read_bytes() if archive is None
                   else sources[archive].read(item["member"]))
            assert digest(raw) == item["sha256"], name
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        subprocess.run((sys.executable, "-B", "-X", "utf8", "ReplayAdaptivePrecision.py", "--offline"),
                       cwd=stage, check=True)
        canonical = stage / "VerificationAdaptivePrecision.json"
        assert digest(canonical.read_bytes()) == report_sha
        print("CANONICAL ADAPTIVE MVT2", report_sha)


if __name__ == "__main__":
    main()
