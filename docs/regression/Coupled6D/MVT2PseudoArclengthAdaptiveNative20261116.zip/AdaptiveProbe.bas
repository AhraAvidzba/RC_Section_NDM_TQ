
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет два меньших положительных шага одной псевдодуги. Каждый начинается
' из H24. Только первый независимо подтверждённый шаг повторяется для фиксации.
Private Sub ProbeWangAdaptiveArcTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef base() As Double, ByVal qBase As Double, ByVal deltaLoad As Double)
    Dim projection() As Double, previous() As Double, loadProjection As Double, originalArc As Double
    Dim file As Integer, i As Long, raw As String, data As Variant
    ReDim projection(1 To 60)
    file = FreeFile: Open folder & "MVTNormal.csv" For Input As #file
    Line Input #file, raw
    If Not EOF(file) Then Err.Raise 5, , "Лишняя строка нормали MVT2."
    Close #file
    data = Split(raw, ";")
    If UBound(data) <> 61 Or solver.PhysicalDegreeCount <> 56 Then Err.Raise 5, , "Неверная нормаль псевдодуги MVT2."
    For i = 1 To 60
        projection(i) = Val(data(i - 1))
        If i > 56 And projection(i) <> 0# Then Err.Raise 5, , "Реакции не участвуют в размере псевдодуги MVT2."
    Next i
    loadProjection = Val(data(60)): originalArc = Val(data(61))
    If loadProjection <= 0# Or originalArc <= 0# Then Err.Raise 5, , "Неверный шаг псевдодуги MVT2."
    EmitWangTangentVectorTest output, "B_ARC_PROJECTION;Normal", projection
    previous = history(23)
    Dim acceptedHistory() As Double, checkedHistory() As Double
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "Before", operators, materials, acceptedHistory
    Dim stage As Variant, stageName As String, selected As Long, selectedLambda As Double
    Dim trial() As Double, trialAction() As Double, selectedField() As Double, selectedAction() As Double
    Dim lambda As Double, isAdmissible As Boolean, candidateFound As Boolean
    Dim weak() As Double, actual() As Double, norm As Double
    For Each stage In Array(128&, 256&)
        stageName = "Arc" & CStr(stage)
        RestoreWangShearBaselineTest solver, history, base
        CaptureWangArcHistoryTest output, "Replay" & stageName, operators, materials, checkedHistory
        RequireWangArcHistoryTest acceptedHistory, checkedHistory
        candidateFound = TryWangAdaptiveArcTest(output, stageName, CLng(stage), solver, operators, materials, _
            responses, response, base, previous, qBase, deltaLoad, projection, loadProjection, originalArc, trial, trialAction, lambda, isAdmissible)
        solver.DiscardStep
        RequireWangAcceptedFieldTest solver, base
        CaptureWangArcHistoryTest output, "After" & stageName, operators, materials, checkedHistory
        RequireWangArcHistoryTest acceptedHistory, checkedHistory
        If candidateFound And isAdmissible And selected = 0 Then
            selected = CLng(stage): selectedLambda = lambda
            selectedField = trial: selectedAction = trialAction
        End If
    Next stage
    Print #output, "B_ADAPT_SELECTION;" & CStr(selected)
    If selected > 0 Then
        RestoreWangShearBaselineTest solver, history, base
        If Not TryWangAdaptiveArcTest(output, "Confirm", selected, solver, operators, materials, responses, response, _
            base, previous, qBase, deltaLoad, projection, loadProjection, originalArc, trial, trialAction, lambda, isAdmissible) Then _
            Err.Raise 5, , "Выбранное равновесие не воспроизведено перед фиксацией."
        If Not isAdmissible Or lambda <> selectedLambda Then Err.Raise 5, , "Изменилась выбранная ветвь."
        For i = 1 To 60
            If trial(i) <> selectedField(i) Then Err.Raise 5, , "Изменилось выбранное поле."
        Next i
        For i = 1 To 6
            If trialAction(i) <> selectedAction(i) Then Err.Raise 5, , "Изменилось усилие выбранного поля."
        Next i
        solver.AcceptStep
        RequireWangAcceptedFieldTest solver, selectedField
        CaptureWangArcHistoryTest output, "PrivateAccepted", operators, materials, checkedHistory
        norm = RecordWangTangentStateTest(output, "PrivateAccepted", 24, lambda, solver, operators, materials, responses, selectedField, actual, weak)
        If norm < 0# Then Err.Raise 5, , "Не подтверждён сохранённый отклик нового поля."
        Print #output, "B_ADAPT_COMMIT;25;" & CStr(selected) & ";" & ExperimentNumberTest(lambda)
    End If
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "Final", operators, materials, checkedHistory
    RequireWangArcHistoryTest acceptedHistory, checkedHistory
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Принимает только исходную невязку, положительный направленный размер,
' ограниченную длину полевого шага и допустимый фактический отклик арматуры.
Private Function TryWangAdaptiveArcTest(ByVal output As Integer, ByVal label As String, ByVal divisor As Long, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByVal response As CCoupledReinforcedResponse, ByRef base() As Double, ByRef previous() As Double, _
        ByVal qBase As Double, ByVal deltaLoad As Double, ByRef projection() As Double, ByVal loadProjection As Double, _
        ByVal originalArc As Double, ByRef trial() As Double, ByRef trialAction() As Double, ByRef lambda As Double, _
        ByRef isAdmissible As Boolean) As Boolean
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005, MAX_ITERATIONS As Long = 26
    Const REFERENCE_MODULUS As Double = 30000#
    Dim prediction() As Double, qTrial As Double, arcStep As Double, planeTarget As Double
    Dim measured As Double, i As Long, seed As Variant
    qTrial = qBase + deltaLoad / divisor: arcStep = originalArc / divisor
    prediction = base
    planeTarget = loadProjection * qBase + arcStep
    measured = loadProjection * (qTrial - qBase)
    For i = 1 To 56
        prediction(i) = base(i) + (base(i) - previous(i)) / divisor
        planeTarget = planeTarget + projection(i) * base(i)
        measured = measured + projection(i) * (prediction(i) - base(i))
    Next i
    If Abs(measured - arcStep) > 0.00000000000000001 Then Err.Raise 5, , "Прогноз не лежит на плоскости псевдодуги."
    EmitWangTangentVectorTest output, "B_ADAPT_PREDICTOR;" & label, prediction
    Print #output, "B_ADAPT_PLANE;" & label & ";" & CStr(divisor) & ";" & ExperimentNumberTest(qTrial) & ";" & _
        ExperimentNumberTest(arcStep) & ";" & ExperimentNumberTest(planeTarget) & ";" & _
        ExperimentNumberTest(loadProjection) & ";" & ExperimentNumberTest(ABS_TOL) & ";" & ExperimentNumberTest(REL_TOL) & ";" & CStr(MAX_ITERATIONS)
    Dim baseLoad(1 To 6) As Double, direction(1 To 6) As Double
    baseLoad(4) = 10510000#: direction(2) = 600000#: direction(6) = 1000#
    seed = prediction
    Dim started As Double, elapsed As Double, status As CResultMeta, lambdaText As String, solved As Boolean
    isAdmissible = False: lambdaText = "-": lambda = qTrial
    started = Timer
    solved = solver.TryDeformationStep(baseLoad, direction, projection, planeTarget, qTrial, lambda, _
        ABS_TOL, REL_TOL, MAX_ITERATIONS, consistentControl:=False, initialField:=seed, loadProjection:=loadProjection)
    elapsed = Timer - started: If elapsed < 0# Then elapsed = elapsed + 86400#
    Set status = solver.ResultMeta
    If solved Then
        Dim actual() As Double, weak() As Double, applied() As Double, delta(1 To 60) As Double
        Dim norm As Double, tolerance As Double, directed As Double, physicalStep As Double, steel As Double
        lambdaText = ExperimentNumberTest(lambda)
        solver.CopyTrial trial, trialAction
        steel = response.TrialSteelUtilization
        EmitWangTangentVectorTest output, "B_ADAPT_SOLVER_ACTUAL;" & label, trialAction
        norm = RecordWangTangentStateTest(output, label, 24, lambda, solver, operators, materials, responses, trial, actual, weak)
        If norm < 0# Then Err.Raise 5, , "Не восстановлена невязка решённого шага псевдодуги."
        operators.LoadEquations 0#, 600000# * lambda, 0#, 10510000#, 0#, 1000# * lambda, applied
        For i = 1 To 56: tolerance = GeomMax(tolerance, Abs(applied(i))): Next i
        tolerance = ABS_TOL + REL_TOL * tolerance
        directed = loadProjection * (lambda - qBase)
        For i = 1 To 56
            delta(i) = trial(i) - base(i)
            directed = directed + projection(i) * delta(i)
        Next i
        physicalStep = WangArcPhysicalLengthTest(operators, delta, loadProjection * Sqr(2#) * (lambda - qBase))
        isAdmissible = (norm <= tolerance And Abs(directed - arcStep) * REFERENCE_MODULUS <= tolerance And _
                        directed > 0# And physicalStep <= 3# * arcStep And lambda > 0# And steel <= 1#)
        Print #output, "B_ADAPT_GUARD;" & label & ";" & ExperimentNumberTest(norm) & ";" & ExperimentNumberTest(tolerance) & ";" & _
            ExperimentNumberTest(directed) & ";" & ExperimentNumberTest(physicalStep) & ";" & ExperimentNumberTest(steel) & ";" & _
            CStr(Abs(CLng(isAdmissible)))
    End If
    Print #output, "B_ADAPT_STATUS;" & label & ";" & CStr(Abs(CLng(solved))) & ";" & _
        lambdaText & ";" & CStr(status.InternalStatus) & ";" & CStr(status.ResultCode) & ";" & ExperimentNumberTest(elapsed)
    Print #output, "B_ADAPT_DIAG;" & label & ";" & Replace(Replace(status.DiagnosticDetails, vbCr, " "), vbLf, " ")
    TryWangAdaptiveArcTest = solved
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Считает фактическую длину в том же взвешенном тензорном пространстве, что
' архивная нормаль, с равными весами трёх станций каждой точки квадратуры.
Private Function WangArcPhysicalLengthTest(ByVal operators As CCoupledElasticState, _
        ByRef delta() As Double, ByVal scaledLoad As Double) As Double
    Dim point As Long, side As Long, i As Long
    Dim x As Double, y As Double, area As Double, completeArea As Double, total As Double, value As Double, coeff As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double
    For point = 1 To operators.PointCount
        operators.Point point, x, y, area
        operators.PointStrain point, delta, strain
        operators.AxialGradientAtPoint point, delta, slope
        For side = -1 To 1
            completeArea = completeArea + area
            For i = 1 To 6
                coeff = area: If i > 3 Then coeff = coeff / 2#
                value = strain(i) + side * 0.001 * slope(i)
                total = total + coeff * value ^ 2
            Next i
        Next side
    Next point
    WangArcPhysicalLengthTest = Sqr(total / completeArea + scaledLoad ^ 2)
End Function
