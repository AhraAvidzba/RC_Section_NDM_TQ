"""Seal the two smaller fixed-normal MVT2 pseudo-arc trials at H24."""
from hashlib import sha256
import json
from pathlib import Path


here = Path(__file__).resolve().parent
source = here.parent / "arc-ab"
book = "workbook/output/RC_Section_NDM.xlsm"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, raw):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def main():
    raw = (source / "Preparation.json").read_bytes()
    assert digest(raw) == "1582BE948DA703EEA2376EAE03330EA6EC8E2870C10515D59E95D2370EBF2503"
    prior = json.loads(raw)
    inputs = {}
    exclude = {"Control.bas", "Probe.bas", "Stage.py", "Run-MVT2ShearControlled.ps1",
               "tests/modTestCoupledExperiment.bas", "Verify-MVT2ShearControlled.py"}
    for name, expected in prior["inputs"].items():
        if name not in exclude:
            raw = (source / name).read_bytes()
            assert digest(raw) == expected, name
            inputs[name] = save(name, raw)
    raw = (source / "VerificationComparePrecision.json").read_bytes()
    assert digest(raw) == "5E37145AB506167B149152328EF940AEE296D045B20C5FDE9C3E9C4E357AF02E"
    inputs["PriorCompare.json"] = save("PriorCompare.json", raw)
    raw = (source / "ReplayPrecision.py").read_bytes()
    assert digest(raw) == "E2553D552F4050B54485035876F87B14A2E3B877806ADFED3C9226D8856310DB"
    inputs["ReplayPrecision.py"] = save("ReplayPrecision.py", raw)
    raw = (source / book).read_bytes()
    assert digest(raw) == prior["book_sha256"]
    save(book, raw)
    save("docs/regression/Diagnostic.xlsm", raw)
    for folder in ("NativeAdaptive", "Temp"):
        (here / folder).mkdir(exist_ok=True)
    raw = (source / "Control.bas").read_bytes()
    assert digest(raw) == prior["inputs"]["Control.bas"]
    control = raw.decode("utf-8")
    old = '''    If phase <> "Compare" Then Err.Raise 5, , "Неизвестная фаза сравнения MVT2."
    ProbeWangArcComparisonTest output, folder, history, solver, operators, materials, responses, base, qBase, qTrial'''
    assert control.count(old) == 1
    control = control.replace(old, '''    If phase <> "Adaptive" Then Err.Raise 5, , "Неизвестная фаза псевдодуги MVT2."
    ProbeWangAdaptiveArcTest output, folder, history, solver, operators, materials, responses, response, base, qBase, qBase - factors(23)''')
    boundary = "' -------------------- ДЛЯ ТЕСТОВ --------------------"
    start = control.rindex(boundary, 0, control.index("Private Sub ProbeWangArcComparisonTest"))
    end = control.rindex(boundary, 0, control.index("Private Sub CaptureWangArcHistoryTest"))
    control = control[:start] + (here / "AdaptiveProbe.bas").read_text(encoding="utf-8") + "\n" + control[end:]
    control = control.replace("' Сравнивает усилие и плоскость псевдодуги при одной истории MVT2 B.",
                              "' Проверяет два коротких шага псевдодуги на единой истории MVT2 B.")
    inputs["Control.bas"] = save("Control.bas", control.encode("utf-8"))
    test = "tests/modTestCoupledExperiment.bas"
    raw = (source / test).read_bytes()
    assert digest(raw) == prior["inputs"][test]
    prelude = raw.decode("utf-8").replace("\r\n", "\n")
    start = prelude.rindex(boundary, 0, prelude.index("Public Function RunTestWangShearControlled("))
    inputs[test] = save(test, (prelude[:start] + control).replace("\n", "\r\n").encode("utf-8"))
    name = "Run-MVT2ShearControlled.ps1"
    raw = (source / name).read_bytes()
    assert digest(raw) == prior["inputs"][name]
    runner = raw.decode("utf-8")
    assert runner.count("'Compare'") == 2
    inputs[name] = save(name, runner.replace("'Compare'", "'Adaptive'").encode("utf-8"))
    for name in ("AdaptiveProbe.bas", "Stage.py", "Verify-MVT2ShearControlled.py"):
        inputs[name] = digest((here / name).read_bytes())
    report = {"inputs": inputs, "book_sha256": prior["book_sha256"], "replay_sha256": prior["replay_sha256"],
              "watchdog_seconds": 150}
    print(save("Preparation.json", (json.dumps(report, indent=2) + "\n").encode("utf-8")))


if __name__ == "__main__":
    main()
