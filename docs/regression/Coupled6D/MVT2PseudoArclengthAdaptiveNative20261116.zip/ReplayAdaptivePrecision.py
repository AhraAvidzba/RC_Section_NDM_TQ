"""Check the native adaptive trials against exact Str$ seed and arc-size output."""
import argparse
from decimal import Decimal, localcontext
from hashlib import sha256
import json
from pathlib import Path


here = Path(__file__).resolve().parent
original_sha = "96747D76F4547F1A85E92310FA56C5256549EF8525DA7244A5EA73DC3F575EB6"
trace_sha = "94B6762FDEE25449127EC0B838E7DF00F23A926A97287A88215E15D8730BFED5"
book_sha = "8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF"


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def confirmed_plan_scale(tags, name, seed, step):
    [[_, _, exported_seed, exported_step, *_]] = [row for row in tags["B_ADAPT_PLANE"] if row[0] == name]
    record = {}
    with localcontext() as arithmetic:
        arithmetic.prec = 100
        for label, token, computed in (("qseed_kN", exported_seed, seed), ("arc_step", exported_step, step)):
            exact = Decimal.from_float(computed)
            emitted = Decimal(token)
            assert exact > 0 and emitted > 0
            # The last printed digit is at exponent e-14 for 15 significant digits.
            quantum = Decimal(1).scaleb(exact.copy_abs().adjusted() - 14)
            bound = quantum / 2
            discrepancy = abs(exact - emitted)
            assert exact.quantize(quantum) == emitted and discrepancy <= bound, (name, label, exact, token)
            record[label] = {"computed_double": computed, "native_token": token,
                             "decimal_output_absolute_error": str(discrepancy), "half_unit_of_last_digit": str(bound)}
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true", help="omit workbook bytes; verify original native ownership")
    args = parser.parse_args()
    verifier = here / "Verify-MVT2ShearControlled.py"
    raw = here / "NativeAdaptive/MVT2.csv"
    assert digest(verifier) == original_sha and digest(raw) == trace_sha
    source = verifier.read_text(encoding="utf-8")
    too_narrow = '        assert abs(qseed - (base["q"] + dlam/div)) < 4e-14 and abs(step - original_arc/div) < 3e-17'
    assert source.count(too_narrow) == 1
    source = source.replace(too_narrow, '        confirmed_plan_scale(tags, name, base["q"] + dlam/div, original_arc/div)')
    if args.offline:
        guard = '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]'
        assert source.count(guard) == 1
        source = source.replace(guard, f'    assert prep["book_sha256"] == "{book_sha}"')
    env = {"__name__": "adaptive_precision_replay", "__file__": str(verifier), "confirmed_plan_scale": confirmed_plan_scale}
    exec(compile(source, str(verifier), "exec"), env)
    frozen = env["prepare"]()
    result = env["verify"](*frozen)
    tags = env["v"].read_native(raw)
    qbase, original_arc, dlam = frozen[2]["q"], frozen[6], frozen[8]
    result["plan_wire_precision"] = {
        name: confirmed_plan_scale(tags, name, qbase+dlam/float(div), original_arc/float(div))
        for name, div, *_ in tags["B_ADAPT_PLANE"]
    }
    result["archived_verifier_sha256"] = original_sha
    report = here / "VerificationAdaptivePrecision.json"
    report.write_bytes((json.dumps(result, indent=2) + "\n").encode("utf-8"))
    print(report, digest(report))


if __name__ == "__main__":
    main()
