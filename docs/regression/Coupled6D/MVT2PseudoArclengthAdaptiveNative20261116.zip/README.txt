Adaptive fixed-normal native MVT2 probes from accepted H24

Run in an extracted directory with Python 3.10 or later

    python -B -X utf8 ReplayPortableAdaptive.py PATH/MVT2HalfJointJetNative20261116.zip PATH/MVT2PseudoArclengthNativeComparison20261116.zip

Both referenced archives are tracked in docs/regression/Coupled6D and their
whole-file SHA256 identities are checked during replay. PortableManifest.json
pins all local and shared staging inputs. No installed workbook is needed to
replay the original compiled and native process receipts.

The two arms use 1/128 and 1/256 of the identical physical normal secant.
The concrete and steel laws, H24 initial field, load path, positive arc sign,
and original weak, six resultant and four gauge tolerances are unchanged.
Neither trial returned equilibrium or a solved lambda. The final logged
diagnostic residuals were 5.43962669468645e-4 and 2.24489915109055e-4 MPa.
The first admissible lane and private H25 diagnostic are both absent. The
last accepted point remains Qy=18.558110 kN with exactly restored H24 field
and the recorded stress/energy history fingerprints at 135 material stations.
The failed trials do not support a material or physical capacity claim.

The original verifier and its rejection are archived along with unmodified
raw data. The 1/128 seed prints 18.5650594335937 although its computed binary
Double is near 18.56505943359375. The exact discrepancy is 4.91053e-14 kN,
within the 5e-14 half-unit for 15 decimal significant digits. Replay checks
exact nearest decimal for both printed seeds and both printed arc steps.
The equilibrium and history checks then run without alteration.
