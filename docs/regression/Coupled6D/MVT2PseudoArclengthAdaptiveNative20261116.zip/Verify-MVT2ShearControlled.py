"""Verify adaptive fixed-normal trials and any private history advance from exact H24."""
import argparse
import json
from math import fsum, hypot, sqrt
from pathlib import Path

from ReplayPrecision import normal_wire_precision
import VerifyBase as v


here = Path(__file__).resolve().parent
native = here / "NativeAdaptive"
arm_names = ("Arc128", "Arc256")


def rows(name):
    return [line.split(";") for line in (here / name).read_text(encoding="ascii").splitlines()]


def metric_field(field, geometry):
    total = fsum(area for _, _, area in geometry.values())
    return tuple(sqrt(area / total) * strain / (1. if i < 3 else sqrt(2.))
                 for (_, side), (x, y, area) in geometry.items()
                 for i, strain in enumerate(v.strain_at(field, v.operators(x, y), side)))


def prepare():
    prep = v.read(here / "Preparation.json")
    assert all(v.digest(here / name) == expected for name, expected in prep["inputs"].items())
    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]
    arc = v.read(here / "ArcFixture.json")
    assert arc["workbook_sha256"] == prep["book_sha256"]
    assert arc["frozen"]["src/Solver/CCoupledNewtonSolver.cls"] == prep["inputs"]["src/Solver/CCoupledNewtonSolver.cls"]
    prior = v.read(here / "PriorCompare.json")
    assert prior["book_sha256"] == prep["book_sha256"] and prior["H24_replay_sha256"] == prep["replay_sha256"]
    assert not prior["outcomes"]["PseudoArc"]["newton_equilibrium_returned"] and prior["accepted_field_exact"]
    assert v.digest(here / "Replay.csv") == prep["replay_sha256"]
    evidence = v.read(here / "MVTHistory.json")
    assert evidence["history_sha256"] == prep["replay_sha256"] and evidence["native_sha256"] == v.digest(here / "JetNative.csv")
    [normal] = rows("MVTNormal.csv")
    vals = tuple(map(float, normal))
    p, k, original_arc = vals[:60], vals[60], vals[61]
    assert p == tuple(evidence["normal_q"]) and p[-4:] == (0.,)*4
    assert k == evidence["normal_Qy_per_kN"] and original_arc == evidence["last_secant_metric_norm"]
    dl_scale = evidence["strains_normalized_to_last_Qy_increment_per_kN"]
    assert abs(k * sqrt(2.) - dl_scale) < 3e-20
    prefix = rows("Replay.csv")[1:]
    assert len(prefix) == 24
    history = [tuple(map(float, line[9:])) for line in prefix]
    qbase = float(prefix[-1][2])
    dlam = qbase - float(prefix[-2][2])
    assert qbase == 18.55811 and qbase + dlam / 64. == prior["arc_predictor_Qy_kN"]
    previous, stations = v.verified_states(v.read_native(here / "JetNative.csv"))
    assert previous["Restored24"] == previous["Base24"] and stations["Restored24"] == stations["Base24"]
    assert previous["Base24"]["field"] == history[-1]
    return prep, history, previous["Base24"], stations["Base24"], p, k, original_arc, dl_scale, dlam


def verify(prep, history_input, archived, old_stations, p, k, original_arc, load_scale, dlam):
    build = v.read(here / "docs/regression/CodeUpdate.json")
    compiler = v.read(here / "CompileClosure.json")
    owner = v.read(native / "MVT2.txt.Ownership.json")
    watch = v.read(native / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(native / "RunReceipt.json")
    final = watch["Closure"]["FinalState"]
    assert build["Compiled"] and sorted(build["Modules"]) == ["CCoupledNewtonSolver", "modTestCoupledExperiment"]
    assert not build["ProductionChanged"] and build["ProductionSHA256"] == prep["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == build["WorkbookSHA256"]
    assert watch["Passed"] and watch["ChildExitCode"] == receipt["native_exit"] == 0 and watch["ChildHasExited"]
    assert final["State"] == "Absent" and final["PID"] == owner["PID"] and final["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    path = native / "MVT2.csv"
    tags = v.read_native(path)
    assert tags["B_FRESH_PHASE"] == [["Adaptive"]]
    states, stations = v.verified_states(tags)
    history = v.vec(tags, "MVT2_CONTROL_FIELD")
    assert len(history) == 24
    for i, q in enumerate(history_input, 1):
        assert v.peak(v.diff(q, history[f"Replay{i}"])) < 1e-15
    base = states["Base24"]
    assert base == states["Restored24"] == archived
    assert stations["Base24"] == stations["Restored24"] == old_stations
    projection_precision = normal_wire_precision(tags, p)
    saved = {name: tuple(map(float, points)) for name, *points in tags["B_ARC_HISTORY"]}
    expected_histories = {"Before", "ReplayArc128", "ReplayArc256", "AfterArc128", "AfterArc256", "Final"}
    assert set(saved) - {"PrivateAccepted"} == expected_histories
    assert len(saved["Before"]) == 1080 and all(saved[name] == saved["Before"] for name in expected_histories)
    for side in (-1, 0, 1):
        for point in range(1, 26):
            index = 8 * ((side + 1) * 45 + point - 1)
            assert v.peak(v.diff(saved["Before"][index:index+6], old_stations[(point, side)][13:19])) < 4e-10
    quadrature = {}
    for name, point, side, axis, strain, concrete, steel in tags["B_BOUND_STEEL"]:
        point, side, axis = int(point), int(side), int(axis) - 1
        strain, concrete, steel = map(float, (strain, concrete, steel))
        expected_limit = 498. if point <= 29 else 450.
        x, y, *_ = stations[name][(point, side)]
        assert axis == (2 if point <= 29 else (1 if abs(x) > abs(y) else 0))
        raw = stations[name][(point, side)]
        assert abs(strain - raw[7 + axis]) < 4e-16 and abs(raw[13 + axis] + concrete - steel) < 4e-10
        assert abs(steel - min(expected_limit, max(-expected_limit, 200000. * strain))) < 4e-8
        quadrature.setdefault(name, {})[(point, side)] = (abs(strain) / .05, abs(steel))
    assert set(quadrature) == set(states) and all(len(points) == 60 for points in quadrature.values())

    selectors = {name: data for name, *data in tags["B_ADAPT_STATUS"]}
    plans = {name: tuple(map(float, data)) for name, *data in tags["B_ADAPT_PLANE"]}
    measurements = {name: tuple(map(float, data)) for name, *data in tags["B_ADAPT_GUARD"]}
    returned = {name: tuple(map(float, data)) for name, *data in tags["B_ADAPT_SOLVER_ACTUAL"]}
    predictors = v.vec(tags, "B_ADAPT_PREDICTOR")
    assert tuple(selectors) in (arm_names, (*arm_names, "Confirm")) and len(selectors) == len(tags["B_ADAPT_STATUS"])
    assert list(selectors) == list(plans) == list(predictors)
    approved = []
    results = {}
    for name in selectors:
        div, qseed, step, target, kout, atol, rtol, limit = plans[name]
        assert div in (128., 256.) and (name == "Confirm" or name == f"Arc{int(div)}")
        ep = tuple(a + (a - b) / div if i < 56 else a for i, (a, b) in
                   enumerate(zip(history_input[-1], history_input[-2], strict=True)))
        assert v.peak(v.diff(predictors[name], ep)) < 3e-15
        assert abs(qseed - (base["q"] + dlam/div)) < 4e-14 and abs(step - original_arc/div) < 3e-17
        assert abs(target - (v.dot(base["field"], p) + k*base["q"] + original_arc/div)) < 3e-17
        assert abs(kout - k) < 3e-17 and atol == rtol == 5e-7 and limit == 26
        flag, factor, internal, code, duration = selectors[name]
        [diagnostic] = [";".join(row[1:]) for row in tags["B_ADAPT_DIAG"] if row[0] == name]
        trial = {"qseed_kN": qseed, "arc_step": step, "observable_status": int(internal),
                 "result_code": int(code), "solver_seconds": float(duration), "diagnostic": diagnostic,
                 "numerical_equilibrium_returned": flag == "1", "admissible": False}
        if flag == "0":
            assert factor == "-" and name not in states and name not in returned and name not in measurements
        else:
            assert flag == "1" and float(factor) == states[name]["q"]
            sample = states[name]
            lam = sample["q"]
            R, actual, _ = v.reconstruct(sample["field"], lam, stations[name])
            assert max(abs(a-b)/s for a,b,s in zip(actual, returned[name], v.SCALES, strict=True)) < 4e-12
            norm, tol, directed, physical, steel, gate = measurements[name]
            assert abs(norm - max(sample["norm_MPa"], sample["gauge_MPa"])) < 4e-10
            assert abs(tol - sample["tol_MPa"]) < 4e-15
            dq = v.diff(sample["field"], base["field"])
            qp = v.dot(p, dq) + k*(lam-base["q"])
            qlength = hypot(*metric_field(dq, base["geometry"]), load_scale * (lam-base["q"]))
            steel_bound = max(values[0] for (_,side),values in quadrature[name].items() if side == 0)
            assert abs(qp - directed) < 3e-15 and abs(qlength - physical) < 3e-15
            assert abs(steel_bound - steel) < 4e-13
            assert abs(qp - step) * v.MODULUS <= tol + 4e-10
            assert max(sample["norm_MPa"], sample["gauge_MPa"]) <= tol + 4e-10
            assert bool(gate) == (norm <= tol and abs(directed-step)*v.MODULUS <= tol and
                                  directed > 0 and physical <= 3*step and lam > 0 and steel <= 1)
            changed_branches = [list(key) for key, row in stations[name].items() if key[0] <= 25 and
                                (row[3:6] != old_stations[key][3:6] or row[6]*old_stations[key][6] < 0.)]
            trial.update({"admissible": bool(gate), "solved_Qy_kN": lam, "directed_progress": directed,
                          "physical_arc_length_over_requested": physical / step,
                          "applied_six_N_Nmm": v.force(lam), "actual_six_N_Nmm": actual, "weak56_MPa": R[:56],
                          "gauges4_MPa": tuple(x * v.MODULUS for x in R[-4:]),
                          "norm_MPa": norm, "tolerance_MPa": tol, "steel_utilization": steel,
                          "station_branch_changes_from_H24": changed_branches})
            if gate and name != "Confirm":
                approved.append(name)
        results[name] = trial

    chosen = approved[0] if approved else None
    [[selection]] = tags["B_ADAPT_SELECTION"]
    commit = None
    if chosen:
        assert int(selection) == int(chosen[3:])
        [[last_index, actual_div, actual_lambda]] = tags["B_ADAPT_COMMIT"]
        assert int(last_index) == 25 and int(actual_div) == int(selection)
        assert plans["Confirm"] == plans[chosen] and results["Confirm"]["admissible"]
        assert states["Confirm"] == states[chosen] and stations["Confirm"] == stations[chosen]
        observed = states["PrivateAccepted"]
        assert observed["field"] == states[chosen]["field"] and observed["q"] == states[chosen]["q"] == float(actual_lambda)
        original, load, _ = v.reconstruct(observed["field"], observed["q"], stations["PrivateAccepted"])
        assert max(observed["norm_MPa"], observed["gauge_MPa"]) <= observed["tol_MPa"] + 4e-10
        commit = {"privately_accepted_index": int(last_index), "Qy_kN": observed["q"], "actual_six_N_Nmm": load,
                  "weak56_MPa": original[:56], "gauges4_MPa": tuple(x*v.MODULUS for x in original[-4:]),
                  "original_equilibrium_norm_MPa": max(observed["norm_MPa"], observed["gauge_MPa"]),
                  "changed_recorded_stress_energy_entries": sum(a != b for a,b in zip(saved["Before"], saved["PrivateAccepted"], strict=True))}
    else:
        assert selection == "0" and not tags["B_ADAPT_COMMIT"] and "PrivateAccepted" not in states and "PrivateAccepted" not in saved
    return {"source_workbook_sha256": prep["book_sha256"], "H24_sha256": prep["replay_sha256"],
            "native_trace_sha256": v.digest(path), "last_published_Qy_kN": base["q"],
            "first_admissible_arm": chosen, "private_history_diagnostic": commit, "exact_H24_restore": True,
            "history_published_outside_fixture": False, "physical_capacity_claimed": False,
            "projection_wire_precision": projection_precision, "outcomes": results,
            "compiler": compiler, "owner_closed": final, "wall_seconds": receipt["wall_seconds"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Adaptive"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS", v.digest(here / "Preparation.json"))
    else:
        assert args.phase == "Adaptive"
        output = here / "VerificationAdaptive.json"
        output.write_bytes((json.dumps(verify(*frozen), indent=2) + "\n").encode("utf-8"))
        print(output, v.digest(output))
