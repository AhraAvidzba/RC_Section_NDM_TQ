"""Сохраняет исходную книгу с единственной заменой скомпилированного VBA."""

import json
from copy import copy
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
base = root / "workbook/output/RC_Section_NDM.xlsm"
compiled = root / "docs/regression/Diagnostic.xlsm"
output = root / "docs/regression/Audit03/RC_Section_NDM.xlsm"
receipt = json.loads((compiled.parent / "CodeUpdate.json").read_text(encoding="utf-8-sig"))


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


assert digest(base) == receipt["ProductionSHA256"] and digest(compiled) == receipt["WorkbookSHA256"]
assert receipt["Compiled"] and not receipt["ProductionChanged"]
module = "xl/vbaProject.bin"
with ZipFile(base) as original, ZipFile(compiled) as project:
    updated = project.read(module)
    assert updated != original.read(module)
    with ZipFile(output, "x") as result:
        result.comment = original.comment
        for entry in original.infolist():
            result.writestr(copy(entry), updated if entry.filename == module else original.read(entry))
    with ZipFile(output) as result:
        assert original.namelist() == result.namelist() and original.comment == result.comment
        assert [name for name in original.namelist() if original.read(name) != result.read(name)] == [module]
        parts = len(original.namelist())
report = {"base_sha256": digest(base), "compiled_sha256": digest(compiled), "candidate_sha256": digest(output),
          "vba_sha256": sha256(updated).hexdigest().upper(), "unchanged_package_parts": parts - 1}
(root / "PackageChecks.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print("PACKAGE", report["candidate_sha256"])
