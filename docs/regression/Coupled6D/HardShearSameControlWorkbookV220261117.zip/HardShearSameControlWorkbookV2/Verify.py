"""Сверяет точный состав сборки, статусы, усилия и закрытие сеансов."""

import argparse
from decimal import Decimal as D
from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_output

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
CASES = {
    "Both": ("WORKBOOK_TIMING", 28),
    "Direct": ("WORKBOOK_TIMING", 19),
    "HoopCapacity": ("HOOP_CAPACITY", 228),
    "SteelAtDesign": ("STEEL_AT_DESIGN", 10),
    "DeformationControl": ("DEFORMATION_CONTROL", 35),
}


def hash_bytes(raw):
    return sha256(raw).hexdigest().upper()


def hash_file(path):
    return hash_bytes(path.read_bytes())


def read(name):
    return json.loads((HERE / name).read_text(encoding="utf-8-sig"))


def inputs(config):
    assert all(hash_file(HERE / name) == expected for name, expected in config["inputs"].items())
    assert hash_file(HERE / "Production.json") == config["production_definition_sha256"]
    book = config["workbook"]
    assert hash_file(HERE / book) == hash_file(REPO / book) == config["source_workbook_sha256"]
    file_set = read("Production.json")
    assert sorted(Path(name).stem for name in file_set["production"]) == config["import_modules"]
    assert all(config["inputs"][name] == expected for name, expected in file_set["production"].items())
    for name, expected in file_set["base"].items():
        archive = check_output(["git", "show", f"{file_set['revision']}:{name}"], cwd=REPO)
        assert hash_bytes(archive) == expected


def decimal(value):
    return D(value.replace(",", "."))


def check_result(case, log):
    tag, count = CASES[case]
    assert f"TOTAL_COUPLED_{tag}: passed={count}; failed=0" in log
    results = {"assertions": count}
    if case in ("Both", "Direct"):
        state = "NumFail" if case == "Both" else "N/A"
        assert f"TIMING_STATES: direct=OK; capacity={state};" in log
        wall = re.search(rf"^TIMING_SECONDS: ([0-9.,]+) \| {case} \| Excel$", log, re.M)
        saved = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", log, re.M)
        assert wall and saved
        reopened = Path(saved[2]).resolve(strict=True)
        assert reopened.is_relative_to(HERE / "Temp")
        values = re.findall(r"^OK: direct (\S+) actual=(\S+) expected=(\S+)$", log, re.M)
        assert [name for name, _, _ in values] == ["N", "Mx", "My", "T", "Qx", "Qy"]
        assert all(abs(decimal(a)-decimal(b)) < D("1e-8") for _, a, b in values)
        assert decimal(wall[1]) > 0
        results.update(direct="OK", capacity=state, seconds=float(decimal(wall[1])), six_resultants=values,
                       results_reopened_sha256=saved[1], reopened_workbook_sha256=hash_file(reopened))
        if case == "Both":
            lower = re.search(r"^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([^;]+); limit=; code=NUMERICAL_FAILURE$", log, re.M)
            assert lower and abs(decimal(lower[1])-D("1.10290889219566")) < D("5e-10")
            assert all(f"OK: no unconfirmed limit component {name}\n" in log for name, _, _ in values)
            assert "OK: native marker does not claim a limit for NumFail" in log
            results["confirmed_lower_lambda"] = str(decimal(lower[1]))
    if case == "HoopCapacity":
        assert "OK: confirmed hoop failure governs even if the requested direct state is unresolved" in log
        assert "OK: confirmed direct hoop failure governs even if overall capacity is unresolved" in log
        for mode in ("Excel", "File"):
            expected = f"OK: {mode} documents the same governing point and FAIL in the structured properties"
            assert expected in log
            matches = re.search(rf"^OK: {mode} keeps multiplier Coupled.Transverse.Limit.Lambda actual=(\S+) expected=(\S+)$", log, re.M)
            assert matches and abs(decimal(matches[1])-decimal(matches[2])) < D("5e-10")
            results[f"{mode}_governing_hoop_lambda"] = str(decimal(matches[1]))
    return results


def native(config, case):
    code = read("docs/regression/CodeUpdate.json")
    compiler = read("CompileClosure.json")
    assert code["Compiled"] and not code["ProductionChanged"] and code["ProductionSHA256"] == config["source_workbook_sha256"]
    assert sorted(code["Modules"]) == config["import_modules"]
    assert code["WorkbookSHA256"] == hash_file(HERE / "docs/regression/Diagnostic.xlsm")
    assert compiler["State"] == "Absent"
    report = f"Native/{case}.txt"
    owner = read(report + ".Ownership.json")
    wait = read(report + ".ProcessClosure.json")
    final = wait["Closure"]["FinalState"]
    assert wait["Passed"] and wait["ChildExitCode"] == 0 and final["State"] == "Absent"
    assert (owner["PID"], owner["StartTicksUTC"]) == (final["PID"], final["StartTicksUTC"])
    assert owner["SourceSHA256"] == code["WorkbookSHA256"]
    log = (HERE / report).read_text(encoding="utf-8-sig")
    assert f"SOURCE_SHA256: {code['WorkbookSHA256']}" in log
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    result = check_result(case, log)
    result.update(case=case, workbook_sha256=code["WorkbookSHA256"], native_report_sha256=hash_file(HERE / report))
    target = HERE / f"Native/{case}.Verification.json"
    target.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print("HSR PRODUCTION", case, hash_file(target))


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    group = cli.add_mutually_exclusive_group(required=True)
    group.add_argument("--inputs", action="store_true")
    group.add_argument("--case", choices=CASES)
    args = cli.parse_args()
    fixture = read("Fixture.json")
    inputs(fixture)
    if args.inputs:
        print("INPUTS OK", hash_file(HERE / "Fixture.json"))
    else:
        native(fixture, args.case)


if __name__ == "__main__":
    main()
