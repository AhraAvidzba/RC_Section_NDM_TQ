"""Подготавливает книгу только с двумя рабочими модулями восстановления."""

from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
HSR = HERE.parent / "hsr2"
PREVIOUS = HERE.parent / "hs-next"
MANIFEST = "CA8E252FC4BE1B3ED67948C613445AA3FC052767C934A3667BD0DAFB0CC69061"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw
    else:
        path.write_bytes(raw)
    return digest(raw)


def main():
    source = (HSR / "Production.json").read_bytes()
    assert digest(source) == MANIFEST
    production = json.loads(source)
    baseline = json.loads((PREVIOUS / "Fixture.json").read_bytes())
    book = (REPO / baseline["workbook"]).read_bytes()
    assert digest(book) == baseline["source_workbook_sha256"]
    save(baseline["workbook"], book)
    save("docs/regression/Diagnostic.xlsm", book)
    for directory in ("Temp", "Native"):
        (HERE / directory).mkdir(exist_ok=True)
    inputs = {"Production.json": save("Production.json", source)}
    for name, sha in production["production"].items():
        raw = (HSR / name).read_bytes()
        assert digest(raw) == sha
        inputs[name] = save(name, raw)
    for name, sha in baseline["inputs"].items():
        if name.startswith("tools/build_workbook/") or name == "Guard-IsolatedOffice.ps1":
            raw = (PREVIOUS / name).read_bytes()
            assert digest(raw) == sha
            inputs[name] = save(name, raw)
    for name in ("Stage.py", "Run.ps1", "Verify.py"):
        inputs[name] = digest((HERE / name).read_bytes())
    receipt = {"source_workbook_sha256": baseline["source_workbook_sha256"], "workbook": baseline["workbook"],
               "production_definition_sha256": MANIFEST, "source_revision": production["revision"],
               "import_modules": sorted(Path(name).stem for name in production["production"]), "inputs": inputs}
    print(save("Fixture.json", (json.dumps(receipt, indent=2)+"\n").encode("utf-8")))


if __name__ == "__main__":
    main()
