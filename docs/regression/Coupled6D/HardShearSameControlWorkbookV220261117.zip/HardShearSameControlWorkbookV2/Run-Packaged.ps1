# Проверяет штатную книгу с двумя рабочими модулями.
param(
    [ValidateSet('Inputs','Compile','Both','Direct','HoopCapacity','SteelAtDesign','DeformationControl')]
    [string]$Phase='Inputs'
)

$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
Push-Location -LiteralPath $root
try {
    python -B -X utf8 'Verify.py' --inputs
    if ($LASTEXITCODE) {throw 'Входы проверки не подтверждены.'}
    if ($Phase -eq 'Inputs') {return}
    $f=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    $modules=@($f.import_modules | ForEach-Object {[string]$_})
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Превышена длина пути фикстуры Excel.'
    }
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    if ($Phase -eq 'Compile') {
        if (Test-Path -LiteralPath 'Compile.log') {throw 'Компиляция уже начата.'}
        if ((Get-FileHash -LiteralPath $draft).Hash -cne $f.source_workbook_sha256) {throw 'Неверная исходная книга.'}
        Assert-IsolatedOfficeReady 'CompileHardShearProductionSmoke'
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft `
            -ModuleNames $modules | Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
        return
    }
    $code=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $owner=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    $compileLog=@(Get-Content -LiteralPath 'Compile.log' -Encoding utf8)
    if (!$code.Compiled -or $code.ProductionChanged -or $code.ProductionSHA256 -cne $f.source_workbook_sha256 -or
        $code.Workbook -ine (Resolve-Path -LiteralPath $draft).Path -or
        $code.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or
        (($code.Modules | Sort-Object) -join ',') -cne ($modules -join ',') -or
        $code.RetiredModules.Count -or $code.EntryPointNames.Count -or $code.TraceGeometry -or $owner.State -cne 'Absent' -or
        @($compileLog | Where-Object {$_ -ceq "OWNED_EXCEL: id=$($owner.PID); utcStartTicks=$($owner.StartTicksUTC)"}).Count -ne 1) {
        throw 'Протокол компиляции не соответствует подготовленной книге.'
    }
    if (Get-Process -Id $owner.PID -ErrorAction SilentlyContinue) {throw 'Процесс компиляции ещё видим.'}
    $tested='docs/regression/Audit03/RC_Section_NDM.xlsm'
    $package=Get-Content -LiteralPath 'PackageChecks.json' -Raw | ConvertFrom-Json
    if ($package.base_sha256 -cne $f.source_workbook_sha256 -or $package.compiled_sha256 -cne $code.WorkbookSHA256 -or
        $package.candidate_sha256 -cne (Get-FileHash -LiteralPath $tested).Hash) {
        throw 'Книга для нативной проверки изменилась.'
    }
    $report="Native/$Phase.txt"
    if (Test-Path -LiteralPath $report) {throw 'У этапа уже есть сохранённый протокол.'}
    $macro="modTestCoupledElasticState.RunTestCoupled$Phase"
    $extra=@()
    $timeout=110
    if ($Phase -in 'Direct','Both') {
        $macro='modTestCoupledElasticState.RunTestCoupledWorkbookTiming'
        $extra=@('-MacroArgument1',$Phase,'-MacroArgument2','Excel','-VerifyResultsReopen')
        if ($Phase -eq 'Both') {$timeout=150}
    }
    Assert-IsolatedOfficeReady "RunHardShearProduction$Phase"
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $tested -ReportPath $report -Macro $macro -Mode No -TimeoutSeconds $timeout -FailFast @extra
    if ($LASTEXITCODE) {throw "Нативная проверка $Phase завершилась с кодом $LASTEXITCODE."}
    python -B -X utf8 'VerifyPackaged.py' --case $Phase
    if ($LASTEXITCODE) {throw 'Независимая сверка не пройдена.'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
