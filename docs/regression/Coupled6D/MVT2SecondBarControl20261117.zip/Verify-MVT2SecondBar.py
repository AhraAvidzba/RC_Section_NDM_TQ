"""Проверяет поздние деформационные ветви MVT2 скалярным повторением материала."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum, isclose
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


REFERENCE = ('MVT2TabulatedActiveSteel20261117.zip', '12AC8259874E45568C5B04BB110F4C17D18FDEBD617532A30DE34C262B999792')
WITNESS = ('MVT2TabulatedActiveSteelVBA20261117.zip', '87CECC42511E773F37611E4749AFD4947C299F5853893715F284FA9F498789FB')
CAPTURE = 'MVT2SecondBarControl.json'


def archive(repo, entry):
    """Открывает архив после сверки его исторической контрольной суммы."""
    path=repo/'docs/regression/Coupled6D'/entry[0]
    assert sha256(path.read_bytes()).hexdigest().upper()==entry[1]
    return ZipFile(path)


def script(z, name):
    """Подключает независимую скалярную реализацию из закреплённого пакета."""
    functions={'__name__':'__pinned__','__file__':name}
    exec(compile(z.read(name),name,'exec'),functions)
    return functions


def recover(repo, folder):
    """Восстанавливает последнюю силовую историю до 77,625 кН, включая текучесть первого стержня."""
    with archive(repo,REFERENCE) as z:
        utils=script(z,'Verify-MVT2TabulatedContinuation.py')
        continuation=json.loads(z.read('MVT2TabulatedContinuation.json'))
    with archive(repo,WITNESS) as z:
        measure=script(z,'Verify-ActiveSteelWitness.py')['measure']
    tables,frames,mesh,support,equation=utils['load'](repo,folder)
    states=utils['replay_native'](tables,frames,mesh[1],support)
    later=continuation['routes']['active;2e-09;72812.5'][:-1]+continuation['tail']['none;125'][:1]
    history,confirmed=utils['replay_route'](states[72812.5],later,tables,mesh,support,equation)
    assert confirmed==[73750.,75000.,75312.5,76000.,77500.,77625.]
    return history,tables,mesh,support,utils['material'],measure


def check_route(key, rows, source, adaptive):
    """Принимает обновление истории только после проверки исходных уравнений равновесия."""
    history,tables,mesh,support,material,measure=source
    tag,side,increment,_=key.split(';')
    assert tag=='26'
    side,increment=int(side),float(increment)
    last_force=77625.
    reached=[]
    norms=[]
    controls=[]
    rejected=0
    x_old=None
    step=increment
    for i,row in enumerate(rows):
        field=row['field']
        proposal,net,_=material(field,tables,mesh[1],support,history)
        assert len(field)==60
        norm,tol=measure(field,row['Qy_N'],net,tables,mesh)
        assert isclose(tol,row['tol_MPa'],rel_tol=0.,abs_tol=1e-16) and abs(norm-row['norm_MPa'])<3e-9
        direction=mesh[1][26][3:]
        eps=fsum(a*b for a,b in zip(proposal[side,26][0],direction,strict=True))
        assert abs(eps-row['target_steel_strain'])<2e-17
        current=history[side,26][0]
        previous_control=fsum(a*b for a,b in zip(current,direction,strict=True))
        if adaptive:
            assert isclose(row['step'],step,rel_tol=0.,abs_tol=1e-22)
            expected=previous_control+step
        else:
            x_old=previous_control if x_old is None else x_old
            expected=x_old+(i+1)*increment
        assert abs(expected-eps)<2e-17
        if row['accepted']:
            assert norm<=tol
            for station,saved in zip((0,1,-1),row['steel_strain'],strict=True):
                for p,v in enumerate(saved,26):
                    axial=fsum(a*b for a,b in zip(proposal[station,p][0],mesh[1][p][3:],strict=True))
                    assert abs(axial-v)<2e-17
            history=proposal
            last_force=row['Qy_N']
            reached.append(last_force)
            controls.append(eps)
            norms.append(norm)
            if adaptive:step=min(increment,step*2.)
        else:
            assert norm>tol
            rejected+=1
            if adaptive:step*=.5
            else:assert i==len(rows)-1
    assert reached and all(b>a for a,b in zip(controls,controls[1:]))
    return {'accepted':len(reached),'rejected':rejected,'Qy_N':reached,
            'max_Qy_N':max(reached),'last_Qy_N':last_force,'max_norm_MPa':max(norms)}


def verify(repo, root, folder):
    """Сверяет шесть фиксированных и две адаптивные последовательности."""
    source=recover(repo,folder)
    data=json.loads((root/CAPTURE).read_bytes())
    assert not data['physical_limit_established']
    assert len(data['histories'])==6 and len(data['adaptive'])==2
    proof={}
    for label in ('histories','adaptive'):
        proof[label]={key:check_route(key,rows,source,label=='adaptive') for key,rows in data[label].items()}
    nominal=proof['histories']['26;0;5e-07;2e-09']
    refined=proof['histories']['26;0;5e-07;5e-10']
    assert nominal['accepted']==refined['accepted']==4
    assert max(abs(a-b) for a,b in zip(nominal['Qy_N'],refined['Qy_N'],strict=True))<1e-4
    assert 79269.<nominal['max_Qy_N']<79270.
    proof['physical_limit_established']=False
    return proof


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    with TemporaryDirectory(dir=a.out.resolve().parent) as folder:
        result=verify(a.repo,a.root,Path(folder))
    a.out.write_bytes((json.dumps(result,indent=2,sort_keys=True)+'\n').encode())
    print('MVT2 SECOND BAR CONTROL VERIFIED',sum(x['accepted'] for table in ('histories','adaptive') for x in result[table].values()))
