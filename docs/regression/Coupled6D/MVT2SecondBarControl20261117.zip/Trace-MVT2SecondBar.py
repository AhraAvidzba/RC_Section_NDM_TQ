"""Продолжает позднюю ветвь MVT2 с управлением продольной деформацией стержня."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from time import perf_counter

import numpy as np
from scipy.optimize import least_squares


HERE = Path(__file__).resolve().parent
FIELD_SCALE = 1e-5
FORCE_SCALE = 200.
ES = 200000.


def solve(section, field, history, q, projection, strain, previous, relative_step):
    """Исключает заданную деформацию из неизвестных, проверяя все уравнения сечения."""
    selected=int(np.argmax(np.abs(projection[:56])))
    retained=np.delete(np.arange(60),selected)
    ratio=(strain-projection@field)/(projection@(field-previous[0]))
    guess=field+ratio*(field-previous[0])
    q_guess=q+ratio*(q-previous[1])
    x=np.r_[(guess[retained]-field[retained])/FIELD_SCALE,(q_guess-q)/FORCE_SCALE]

    def unpack(x):
        trial=field.copy()
        trial[retained]+=FIELD_SCALE*x[:-1]
        trial[selected]=(strain-projection[retained]@trial[retained])/projection[selected]
        return trial,q+FORCE_SCALE*x[-1]

    def target(force):
        return np.array([0.,-396.*force,0.,10510000.,0.,force])

    def residual(x):
        trial,force=unpack(x)
        load=target(force)
        result=section.evaluate(trial,history,load)
        return np.r_[result[0]*section.gauge_scale,(result[2]-load)/section.force_scale]

    widths=np.r_[np.full(59,relative_step/FIELD_SCALE),.01/FORCE_SCALE]

    def jac(x):
        return np.stack([(residual(x+v)-residual(x-v))/(2.*h) for h,v in
                         zip(widths,np.diag(widths),strict=True)],axis=1)

    solution=least_squares(residual,x,jac=jac,method='trf',ftol=1e-13,xtol=1e-13,gtol=1e-13,max_nfev=60)
    trial,force=unpack(solution.x)
    load=target(force)
    answer=section.evaluate(trial,history,load)
    tol=5e-7+5e-7*np.max(np.abs((load@section.l)[:56]))
    report={'accepted':bool(answer[1]<=tol),'Qy_N':float(force),'target_steel_strain':float(strain),
            'field':trial.tolist(),'norm_MPa':float(answer[1]),'tol_MPa':float(tol),'iterations':solution.nfev,
            'steel_strain':(section.a@trial).reshape(3,20)[:,:4].tolist(),'steel_stress':answer[-2][:,:4].tolist(),
            'twist_rad_per_m':float(1000.*trial[3]/section.radius)}
    return trial,answer[4],report


def trace(section, states, point, side, increment, steps, difference):
    """Ведёт одну независимую историю, подтверждая каждое изменение нагрузки."""
    field,history=states[77625.]
    previous=states[77500.][0],77500.
    force=77625.
    projection=section.a[((0,1,-1).index(side))*20+point-26]
    start=projection@field
    result=[]
    for i in range(1,steps+1):
        next_field,next_history,row=solve(section,field,history,force,projection,start+i*increment,previous,difference)
        result.append(row)
        if not row['accepted']:
            break
        next_force=row['Qy_N']
        previous=field,force
        field,history,force=next_field,next_history,next_force
    return result


def subdivided(section, states, side, initial_step, minimum_step, difference):
    """Уточняет отклонённое приращение деформации, сохраняя последний принятый буфер."""
    field,history=states[77625.]
    previous=states[77500.][0],77500.
    force=77625.
    projection=section.a[((0,1,-1).index(side))*20]
    control=float(projection@field)
    increment=initial_step
    attempts=[]
    for i in range(70):
        target=control+increment
        f,h,row=solve(section,field,history,force,projection,target,previous,difference)
        row['step']=increment
        attempts.append(row)
        if row['accepted']:
            previous=field,force
            control,field,history,force=target,f,h,row['Qy_N']
            increment=min(initial_step,increment*2.)
        else:
            increment*=.5
            if increment<minimum_step:break
    return attempts


def run(repo,out):
    """Сопоставляет выбор станции и шаг по стали без изменения диаграмм и допуска."""
    load=run_path(str(HERE/'Trace-MVT2TwistControl.py'))['load']
    section,states,_=load(repo)
    start=perf_counter()
    proofs={}
    for side,step,difference in ((0,5e-7,2e-9),(-1,5e-7,2e-9),(1,5e-7,2e-9),(0,1e-7,2e-9),
                                 (-1,1e-7,2e-9),(0,5e-7,5e-10)):
        key=f'26;{side};{step:g};{difference:g}'
        rows=trace(section,states,26,side,step,12,difference)
        proofs[key]=rows
        print(key,'accepted',sum(x['accepted'] for x in rows),'last',rows[-1]['Qy_N'],rows[-1]['norm_MPa'],flush=True)
    continuation={}
    for side in (-1,0):
        key=f'26;{side};1e-07;2e-09'
        rows=subdivided(section,states,side,1e-7,3.125e-9,2e-9)
        continuation[key]=rows
        good=[row for row in rows if row['accepted']]
        print('adaptive',key,'accepted',len(good),'attempts',len(rows),'last',good[-1]['Qy_N'],flush=True)
    out.write_bytes((json.dumps({'histories':proofs,'adaptive':continuation,'elapsed':perf_counter()-start,
                                 'physical_limit_established':False},indent=2)+'\n').encode())


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    run(a.repo,a.out)
