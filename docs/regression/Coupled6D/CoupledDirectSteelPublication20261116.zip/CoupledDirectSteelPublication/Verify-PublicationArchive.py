"""Replay the production-only publication checks from the sealed records."""

import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from subprocess import check_call
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
spec = spec_from_file_location("production_release", HERE / "Verify-Release.py")
release = module_from_spec(spec)
spec.loader.exec_module(release)
release.REPO = HERE / "Baseline"
PUBLISHED_SHA = "7D5052B4A305D2D27EA4B4C2BF0B43D69B2ECBCBEDA16DFD36017C85A40146DF"
PROOF_SHA = "1A87A0B34C9B4B7A101BB2D565694EE3E673E4091E14BE470C5705C1F3C3C7A5"
STALE_SHA = "38BE984CC8DCC3F1C9E6A4228E18EE1F97DC7E34AE33A62507C47BB038163141"
CHECKPOINT = "c9e7268fe8b7c3c40edca958d137eb0531a53c19"


def workbook_parts(path):
    with ZipFile(path) as book:
        assert book.testzip() is None
        names = book.namelist()
        assert len(names) == len(set(names))
        return {
            "workbook_sha256": release.path_digest(path),
            "comment_sha256": release.digest(book.comment),
            "parts": {name: release.digest(book.read(name)) for name in names},
        }


def paths(name):
    old = HERE / "Baseline" / name
    latest = release.release_paths().get(name, HERE / name)
    return old, latest


def normalize(data):
    return data.replace(b"\r\n", b"\n")


def verify_installation(installed_repo):
    publication = HERE / "Publication.json"
    proof = HERE / "ProductionVerification.json"
    assert release.path_digest(publication) == PUBLISHED_SHA
    assert release.path_digest(proof) == PROOF_SHA
    installed, verified = release.read(publication), release.read(proof)
    assert installed["status"] == verified["status"] == "PASS" and not verified["pending_native"]
    assert installed["source_git_revision"] == verified["source_git_revision"]
    assert installed["verification_sha256"] == PROOF_SHA and installed["installed"] == verified["installable"]
    assert installed["previous"] == verified["previous"] and len(installed["installed"]) == 15
    observation = release.read(HERE / "GitCheckpoint.json")
    assert observation["previous"]["revision"] == installed["source_git_revision"]
    assert observation["installed"]["revision"] == CHECKPOINT
    for name, expected in installed["installed"].items():
        if installed_repo:
            assert release.path_digest(installed_repo / name) == expected, name
        if name == release.BOOK:
            continue
        for group, path, expected in zip(("previous", "installed"), paths(name),
                (installed["previous"][name], expected), strict=True):
            contents = path.read_bytes()
            assert release.digest(contents) == expected, name
            git_record = observation[group]["paths"][name]
            if git_record["exact_bytes"]:
                assert git_record["blob_sha256"] == expected
            else:
                assert git_record["blob_sha256"] == release.digest(normalize(contents))
    pack = release.read(HERE / "PackageChecks.json")
    assert pack == verified["package"]
    assert release.path_digest(HERE / "PackageChecks.json") == verified["package_report_sha256"]
    parts = release.read(HERE / "WorkbookPackageParts.json")
    old, latest = parts["previous"], parts["installed"]
    assert pack["base_sha256"] == old["workbook_sha256"] == installed["previous"][release.BOOK]
    assert pack["candidate_sha256"] == latest["workbook_sha256"] == installed["installed"][release.BOOK]
    for group, record in (("previous", old), ("installed", latest)):
        assert observation[group]["paths"][release.BOOK] == {"blob_sha256": record["workbook_sha256"], "exact_bytes": True}
    assert old["comment_sha256"] == latest["comment_sha256"]
    assert list(old["parts"]) == list(latest["parts"]) and len(old["parts"]) == 122
    assert {part for part in old["parts"] if latest["parts"][part] != old["parts"][part]} == {"xl/vbaProject.bin"}
    assert latest["parts"]["xl/vbaProject.bin"] == pack["vba_sha256"]
    if installed_repo:
        assert latest == workbook_parts(installed_repo / release.BOOK)
    return verified


def verify_evidence(verified):
    path = HERE / "Preparation.json"
    assert release.path_digest(path) == verified["preparation_sha256"] == release.PREPARATION_SHA
    preparation = release.read(path)
    for name, expected in preparation["frozen"].items():
        if name != release.BOOK:
            assert release.path_digest(HERE / name) == expected, name
    assert release.path_digest(HERE / "SourceAgreement.json") == verified["source_agreement_sha256"]
    assert release.verify_sources(preparation) == (verified["source_agreement"], verified["raw_vbe_comparison"])
    assert release.verify_structure() == verified["structure"]
    compiled = release.read(HERE / "docs/regression/CodeUpdate.json")
    assert compiled["Compiled"] and not compiled["ProductionChanged"] and not compiled["RetiredModules"]
    assert compiled["WorkbookSHA256"] == verified["package"]["compiled_sha256"]
    assert compiled["ProductionSHA256"] == verified["package"]["base_sha256"]
    assert sorted(compiled["Modules"]) == preparation["modules"]
    assert release.owner_log("Compile", "PRIVATE_CODE_READY: modules=13; production unchanged=True") == verified["compile"]
    message = "VBA_READ_ONLY_EXPORT: components=225; sourceSHA256=" + release.RELEASE_SHA + "; sourceUnchanged=True"
    assert release.owner_log("Export", message) == verified["export"]
    for label, (macro, heading, count) in release.NATIVE_CASES.items():
        path = HERE / "Native" / f"{label}.txt"
        raw, data = release.native_identity(path, release.RELEASE_SHA, 0)
        assert f"===== modTestCoupledElasticState.{macro} =====" in raw
        assert f"TOTAL_COUPLED_{heading}: passed={count}; failed=0" in raw
        if label in ("Direct", "Both"):
            facts = release.verify_timing(raw, label, path)
        else:
            facts = {"SteelAtDesign": release.verify_steel_at_design, "DeformationControl": release.verify_deformation,
                     "HoopCapacity": release.verify_hoop}[label](raw)
        replay = json.loads(release.stable_json({**data, "assertions": count, "details": facts}))
        assert replay == verified["native"][label]
    stale = HERE / "DirectSteelStaleTangent20261116.zip"
    assert release.path_digest(stale) == STALE_SHA
    with TemporaryDirectory(prefix="ndm-native-pair-") as directory:
        root = Path(directory)
        with ZipFile(stale) as pair:
            pair.extractall(root)
        proof_root = root / "DirectSteelStaleTangent"
        check_call([sys.executable, "-B", "-X", "utf8", str(proof_root / "Verify-Archive.py")])
        for lane, record in verified["stale_screen_comparison"].items():
            native = proof_root / lane / "Native"
            assert release.path_digest(native / "Stale.txt") == record["native"]["report_sha256"]
            assert release.path_digest(native / "Stale.Verification.json") == record["independent_report_sha256"]


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--installed", type=Path, help="also compare all installed bytes against this worktree")
    args = parser.parse_args()
    for name, expected in release.read(HERE / "SHA256SUMS.json").items():
        assert release.path_digest(HERE / name) == expected, name
    verified = verify_installation(args.installed)
    verify_evidence(verified)
    print("PASS DIRECTED RELEASE ARCHIVE", PUBLISHED_SHA, CHECKPOINT, release.RELEASE_SHA)


if __name__ == "__main__":
    main()
