"""Verify the production-only DSI release using saved native evidence."""

import argparse
from decimal import Decimal as D
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re
from shutil import copyfile
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
STAGING = HERE.parent / "dstale"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
EXPORT = "workbook/output/VBA_All_Code.txt"
RELEASE = Path("docs/regression/Audit03")
DRAFT = Path("docs/regression/Diagnostic.xlsm")
PROOF = HERE / "ProductionVerification.json"
PREPARATION_SHA = "633F52AEC40D10E2D9D9F0931228A97BFC665F5F7AE91A60B6C2D684EBB05C4D"
RELEASE_SHA = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
RELEASE_EXPORT_SHA = "F852DFA2A1F94FF70425783634ABB4AAB0C688FC6DF393A225F9E7E80927B737"
STALE_FIXTURES = {
    "Old": "69A2CDFD24BDF75C6CD0D22C6D3A5DF30425C4B545BE79C4B7D9A7EE39CB7070",
    "Corrected": "D2A2DDA5C21D5C65BE21CDE9D89806D3D3A325ADAF72D86457EB8F1344488328",
}
NATIVE_CASES = {
    "SteelAtDesign": ("RunTestCoupledSteelAtDesign", "STEEL_AT_DESIGN", 10),
    "DeformationControl": ("RunTestCoupledDeformationControl", "DEFORMATION_CONTROL", 35),
    "HoopCapacity": ("RunTestCoupledHoopCapacity", "HOOP_CAPACITY", 228),
    "Direct": ("RunTestCoupledWorkbookTiming", "WORKBOOK_TIMING", 19),
    "Both": ("RunTestCoupledWorkbookTiming", "WORKBOOK_TIMING", 28),
}


def digest(data):
    return sha256(data).hexdigest().upper()


def path_digest(path):
    return digest(path.read_bytes())


def read(path):
    return json.loads(path.read_bytes())


def line(path):
    return path.read_text(encoding="utf-8-sig")


def stable_json(record):
    return (json.dumps(record, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def module(path, name):
    spec = spec_from_file_location(name, path)
    loaded = module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def git(*args):
    return check_output(["git", *args], cwd=REPO)


def release_paths():
    return {BOOK: HERE / RELEASE / Path(BOOK).name, EXPORT: HERE / RELEASE / Path(EXPORT).name}


def verify_baseline(preparation):
    revision = git("rev-parse", "HEAD").decode("ascii").strip()
    assert git("rev-parse", "--show-toplevel").decode("utf-8").strip().replace("\\", "/").casefold() == REPO.as_posix().casefold()
    baseline = dict(preparation["baseline_sources"])
    baseline.update((name, preparation["frozen"][name]) for name in (BOOK, EXPORT))
    assert len(baseline) == 15
    assert not git("status", "--porcelain", "--", "src", "tests", "workbook/output").strip()
    for name, expected in baseline.items():
        assert path_digest(REPO / name) == expected, name
    for name in (BOOK, EXPORT):
        assert digest(git("show", f"{revision}:{name}")) == baseline[name], name
    return revision, baseline


def verify_package(preparation):
    pack = read(HERE / "PackageChecks.json")
    compiled = read(HERE / "docs/regression/CodeUpdate.json")
    published = release_paths()
    assert pack["base_sha256"] == preparation["frozen"][BOOK] == compiled["ProductionSHA256"]
    assert pack["compiled_sha256"] == path_digest(HERE / DRAFT) == compiled["WorkbookSHA256"]
    assert pack["candidate_sha256"] == path_digest(published[BOOK]) == RELEASE_SHA
    assert path_digest(published[EXPORT]) == RELEASE_EXPORT_SHA
    assert compiled["Compiled"] and not compiled["ProductionChanged"] and not compiled["RetiredModules"]
    assert sorted(compiled["Modules"]) == preparation["modules"]
    part = "xl/vbaProject.bin"
    with ZipFile(HERE / BOOK) as old, ZipFile(HERE / DRAFT) as source, ZipFile(published[BOOK]) as candidate:
        assert candidate.testzip() is None
        assert old.namelist() == candidate.namelist() and old.comment == candidate.comment
        contents = {name for name in old.namelist() if old.read(name) != candidate.read(name)}
        assert contents == {part}
        data = candidate.read(part)
        assert data == source.read(part) and digest(data) == pack["vba_sha256"]
        assert len(candidate.namelist()) - len(contents) == pack["unchanged_package_parts"] == 121
    return pack


def verify_sources(preparation):
    parser = module(HERE / "Verify-ExportDifference.py", "export_difference")
    old = parser.modules(HERE / EXPORT)
    new = parser.modules(release_paths()[EXPORT])
    assert old.keys() == new.keys() and len(new) == 225
    assert all(old[name][0] == new[name][0] for name in old)

    def canon(text):
        return [parser.code_case(row) for row in "\n".join(text).rstrip().splitlines()]

    def source(path):
        body = line(path)
        match = re.search(r"^Option Explicit.*", body, re.M | re.S)
        assert match is not None
        return canon(match[0].splitlines())

    number = re.compile(r'''"(?:""|[^"])*"|'[^\n]*|(?<![\w.])(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?[#%!&@^]?(?![\w.])''')

    def numeric_spelling(row):
        def value(token):
            text = token[0]
            if text.startswith(('"', "'")):
                return text
            suffix = text[-1] if text[-1] in "#%!&@^" else ""
            digits = text[:-1] if suffix else text
            return str(D(digits).normalize()) + suffix
        return number.sub(value, row)

    changed = sorted(key for key in old if canon(old[key][1]) != canon(new[key][1]))
    assert changed == preparation["modules"]
    raw_changed = {key for key in old if old[key] != new[key]}
    diff = read(HERE / "ExportDifference.json")
    assert diff == {"components": 225, "changes": changed, "expected": changed,
                    "case_only_changes": sorted(raw_changed.difference(changed))}
    records = {}
    for name in preparation["baseline_sources"]:
        key = Path(name).stem
        baseline_pairs = set(zip(source(REPO / name), canon(old[key][1]), strict=True))
        current_source = source(HERE / name)
        current_export = canon(new[key][1])
        inherited, decimal = [], []
        for row, (expected, observed) in enumerate(zip(current_source, current_export, strict=True), 1):
            if expected == observed:
                continue
            if (expected, observed) in baseline_pairs:
                inherited.append(row)
            elif numeric_spelling(expected) == numeric_spelling(observed):
                decimal.append(row)
            else:
                raise AssertionError((key, row, expected, observed))
        records[key] = {
            "lines": len(current_source), "matches_existing_vbe_line": inherited,
            "equal_decimal_spelling": decimal, "source_sha256": preparation["frozen"][name],
        }
    assert len(records) == 13
    result = {
        "status": "PASS", "actual_components": 225,
        "unchanged_components": 212, "changed_components": records,
    }
    assert result == read(HERE / "SourceAgreement.json")
    loose = read(HERE / "SourceEquality.json")
    assert loose["ActualComponents"] == 225
    return result, {"source_equality_all_passed": loose["AllPassed"],
                    "vbe_case_only_components": diff["case_only_changes"]}


def owner_log(name, assertion):
    logfile = HERE / (name + ".log")
    body = line(logfile)
    values = re.findall(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", body, re.M)
    assert len(values) == 1 and assertion in body
    pid, ticks = int(values[0][0]), values[0][1]
    report = HERE / (name + "Closure.json")
    assert read(report) == {"State": "Absent", "PID": pid, "StartTicksUTC": ticks}
    return {"pid": pid, "start_ticks_utc": ticks, "log_sha256": path_digest(logfile),
            "closure_sha256": path_digest(report)}


def verify_structure():
    path = HERE / "Native/WorkbookStructure.json"
    records = read(path)
    checks = {record["Check"]: record for record in records}
    assert len(records) == len(checks) == 27 and all(record["Passed"] is True for record in records)
    assert "T, tf*m | Qx, tf | Qy, tf" in checks["Load combinations table headers"]["Details"]
    assert checks["Source workbook unchanged"]["Details"] == f"Before={RELEASE_SHA}; After={RELEASE_SHA}"
    records = [json.loads(record) for record in line(HERE / "Run.ndjson").splitlines()]
    start = next(i for i, row in enumerate(records) if row["phase"] == "StructureDirectRelease")
    pending = [process for process in records[start + 1]["excel"] if not process["ProtectedUser"]]
    assert len(pending) == 1
    owner = pending[0]
    assert any(all(process["Id"] != owner["Id"] for process in row["excel"]) for row in records[start + 2:])
    return {"checks": 27, "sha256": path_digest(path), "workbook_sha256": RELEASE_SHA,
            "observed_validation_process": owner,
            "closure_observation": "absent in a later successful guarded native launch"}


def native_identity(path, workbook, expected_exit):
    raw = line(path)
    assert re.search(r"^SOURCE_SHA256: " + workbook + r"$", raw, re.M)
    assert f"WATCHDOG_COMPLETED: exit={expected_exit}; source unchanged=True" in raw
    assert "SOURCE_UNCHANGED: True" in raw
    owner = read(path.with_suffix(".txt.Ownership.json"))
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == workbook
    pid, ticks = re.search(r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$", raw, re.M).groups()
    assert (str(owner["PID"]), owner["StartTicksUTC"]) == (pid, ticks)
    closure_path = path.with_suffix(".txt.ProcessClosure.json")
    closure = read(closure_path)
    assert closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"] == expected_exit
    assert closure["RunnerCleanupValid"] and not closure["OrdinaryPathKilledAnything"]
    final = closure["Closure"]["FinalState"]
    assert (str(final["PID"]), final["StartTicksUTC"], final["State"]) == (pid, ticks, "Absent")
    return raw, {"pid": int(pid), "start_ticks_utc": ticks, "exit": expected_exit,
                 "report_sha256": path_digest(path), "closure_sha256": path_digest(closure_path),
                 "source_workbook_sha256": workbook}


def verify_steel_at_design(raw):
    pattern = (r"^STEEL_NEAR: exact=([^;]+); initial=([^;]+); directU-1=([^;]+); "
               r"event=(True|False); lo=([^;]+); hi=([^;]+); accepted=([^;]+); code=(\d+)$")
    cases = re.findall(pattern, raw, re.M)
    assert len(cases) == 10
    expected = {D("0.98"): 6, D("0.999999"): 10, D(1): 10, D("1.00000002"): 9, D("1.02"): 9}
    assert {(D(case[0]), D(case[1])) for case in cases} == {(key, step) for key in expected for step in (D(1), D(".5"))}
    for exact, initial, ratio, event, low, high, accepted, code in cases:
        factor, lo, hi, equilibrated = D(exact), D(low), D(high), D(accepted)
        assert int(code) == expected[factor]
        if factor <= 1:
            assert event == "True" and equilibrated <= lo < hi and lo <= factor <= hi and D(ratio) > 0
            assert (hi < 1) == (factor == D(".98"))
        else:
            assert event == "False" and equilibrated == 1 and lo == hi == 0 and D(ratio) < 0
    return {"cases": len(cases), "code_below_design": 6,
            "near_design_interval_code": 10, "search_bound_above_design_code": 9}


def verify_deformation(raw):
    peak = re.search(r"^OK: first peak agrees with independent closed form actual=([^ ]+) expected=([^ ]+)$", raw, re.M)
    assert peak is not None and D(peak[2]) == D(".8") and D(0) < D(".8") - D(peak[1]) < D(".0001")
    assert raw.count("OK: branch descends after peak") == 3
    for caption in ("replay restores the prepeak material history", "saved peak history replays",
                    "uncertain peak near design remains explicit without definitive reserve"):
        assert "OK: " + caption in raw
    return {"first_peak_factor": peak[1], "independent_factor": peak[2]}


def verify_hoop(raw):
    limit = re.search(r"^OK: reserve near independent elastic Poisson estimate of 0.60, lambda=([^\s]+)$", raw, re.M)
    assert limit and D(".55") < D(limit[1]) < D(".65")
    component = ("N", "Mx", "My", "T", "Qx", "Qy")
    for medium in ("Excel", "File"):
        for caption in ("leaves the global ultimate plane, vector and reserve unpublished",
                        "preserves separate machine and hoop event statuses",
                        "has no global CapacityState for the unresolved steel event",
                        "CapacityState has a small integrated residual"):
            assert f"OK: {medium} {caption}" in raw
        for name in component:
            assert f"OK: {medium} keeps the signed steel event component {name} " in raw
    return {"confirmed_hoop_factor": limit[1], "separate_event_fields": list(component)}


def verify_timing(raw, label, path):
    timing = re.search(r"^TIMING_SECONDS: ([0-9.]+) \| " + label + r" \| Excel$", raw, re.M)
    assert timing and D(timing[1]) > 0
    state = re.search(r"^TIMING_STATES: direct=([^;]+); capacity=([^;]+); confirmed lower=([^;]*); limit=([^;]*); code=([^\n]*)$", raw, re.M)
    assert state and state[1] == "OK"
    reopen = re.search(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=([0-9A-F]{64}); equal=True;", raw, re.M)
    assert reopen and reopen[1] == reopen[2]
    components = re.findall(r"^OK: direct (\S+) actual=(\S+) expected=(\S+)$", raw, re.M)
    assert [name for name, _, _ in components] == ["N", "Mx", "My", "T", "Qx", "Qy"]
    assert all(abs(D(actual) - D(expected)) < D("1e-8") for _, actual, expected in components)
    result = {"seconds": timing[1], "met_ten_second_goal": D(timing[1]) <= 10,
              "direct_status": state[1], "capacity_status": state[2],
              "results_reopen_sha256": reopen[1], "signed_resultants": components}
    if label == "Direct":
        assert state.groups()[1:] == ("N/A", "", "", "") and D(timing[1]) <= 10
        direct_receipt = read(path.with_suffix(".Verification.json"))
        assert direct_receipt == {"report_sha256": path_digest(path), "direct_seconds": timing[1],
                                  "met_time_goal": True, "reopen_sha256": reopen[1],
                                  "resultant_pairs": [list(group) for group in components]}
    else:
        assert state[2] == "NumFail" and state[4] == "" and state[5] == "NUMERICAL_FAILURE"
        assert abs(D(state[3]) - D("1.10290889219566")) <= D("1e-9")
        reason = re.search(r"^TIMING_LIMIT_REASON: (.+)$", raw, re.M)
        assert reason and "локальн" in reason[1].lower() and "предел" in reason[1].lower()
        assert re.findall(r"^OK: no unconfirmed limit component (\S+)$", raw, re.M) == [x[0] for x in components]
        result.update({"confirmed_lower": state[3], "limit": None, "capacity_code": state[5], "limit_reason": reason[1]})
    return result


def verify_stale(lane, preparation):
    root = STAGING / lane
    fixture_path = root / "Fixture.json"
    assert path_digest(fixture_path) == STALE_FIXTURES[lane]
    fixture = read(fixture_path)
    assert fixture["lane"] == lane and fixture["workbook_sha256"] == preparation["frozen"][BOOK]
    if lane == "Corrected":
        assert fixture["tested_production_solver_sha256"] == preparation["frozen"]["src/Solver/CCoupledNewtonSolver.cls"]
    for name, expected in fixture["frozen"].items():
        assert path_digest(root / name) == expected
    code = read(root / "docs/regression/CodeUpdate.json")
    assert sorted(code["Modules"]) == fixture["modules"] and len(code["Modules"]) == 14
    assert code["Compiled"] and not code["ProductionChanged"] and code["ProductionSHA256"] == fixture["workbook_sha256"]
    assert code["WorkbookSHA256"] == path_digest(root / DRAFT)
    compiler = read(root / "CompileClosure.json")
    owners = re.findall(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", line(root / "Compile.log"), re.M)
    assert owners == [(str(compiler["PID"]), compiler["StartTicksUTC"])] and compiler["State"] == "Absent"
    raw, identity = native_identity(root / "Native/Stale.txt", code["WorkbookSHA256"], 1 if lane == "Old" else 0)
    assert f"===== modTestCoupledElasticState.RunTestCoupledStaleSteelFactor =====" in raw
    with TemporaryDirectory(prefix="ndm-stale-release-") as directory:
        target = Path(directory)
        for name in ("Stale.txt", "Stale.txt.ProcessClosure.json", "Exit.json"):
            copyfile(root / "Native" / name, target / name)
        check_output([sys.executable, "-B", "-X", "utf8", str(root / "Verify.py"), lane, str(target / "Stale.txt")])
        independent = read(target / "Stale.Verification.json")
    expected = root / "Native/Stale.Verification.json"
    assert independent == read(expected)
    return {"fixture_sha256": path_digest(fixture_path), "runtime_solver_sha256": fixture["tested_production_solver_sha256"],
            "compiler": compiler, "native": identity, "independent_report_sha256": path_digest(expected),
            "analytical_capacity_factor": independent["analytic_fixed_torque_capacity_factor"]}


def completed_native(path):
    return path.exists() and path.with_suffix(".txt.ProcessClosure.json").exists()


def verify_release(allow_pending=False):
    preparation_path = HERE / "Preparation.json"
    assert path_digest(preparation_path) == PREPARATION_SHA
    preparation = read(preparation_path)
    for name, expected in preparation["frozen"].items():
        assert path_digest(HERE / name) == expected, name
    assert set(preparation["baseline_sources"]) == set(preparation["frozen"]) - {BOOK, EXPORT}
    assert sorted(Path(name).stem for name in preparation["baseline_sources"]) == preparation["modules"]
    revision, baseline = verify_baseline(preparation)
    pack = verify_package(preparation)
    agreement, formatting = verify_sources(preparation)
    compiler = owner_log("Compile", "PRIVATE_CODE_READY: modules=13; production unchanged=True")
    exporter = owner_log("Export", "VBA_READ_ONLY_EXPORT: components=225; sourceSHA256=" + RELEASE_SHA + "; sourceUnchanged=True")
    structure = verify_structure()
    native, stale, pending = {}, {}, []
    owners = {(compiler["pid"], compiler["start_ticks_utc"]), (exporter["pid"], exporter["start_ticks_utc"])}
    assert len(owners) == 2
    for label, (macro, heading, count) in NATIVE_CASES.items():
        path = HERE / "Native" / f"{label}.txt"
        if not completed_native(path):
            pending.append(label)
            continue
        raw, data = native_identity(path, RELEASE_SHA, 0)
        assert f"===== modTestCoupledElasticState.{macro} =====" in raw
        assert f"TOTAL_COUPLED_{heading}: passed={count}; failed=0" in raw
        assert not re.search(r"^(?:FAIL|RUNTIME ERROR):", raw, re.M)
        if label in ("Direct", "Both"):
            facts = verify_timing(raw, label, path)
        else:
            facts = {"SteelAtDesign": verify_steel_at_design, "DeformationControl": verify_deformation,
                     "HoopCapacity": verify_hoop}[label](raw)
        owner = data["pid"], data["start_ticks_utc"]
        assert owner not in owners
        owners.add(owner)
        native[label] = {**data, "assertions": count, "details": facts}
    for lane in STALE_FIXTURES:
        if not completed_native(STAGING / lane / "Native/Stale.txt"):
            pending.append("Stale/" + lane)
        else:
            data = verify_stale(lane, preparation)
            owner = data["native"]["pid"], data["native"]["start_ticks_utc"]
            assert owner not in owners
            owners.add(owner)
            stale[lane] = data
    assert allow_pending or not pending, "Missing native validation: " + ", ".join(pending)
    fields = {name: path_digest(path) for name, path in release_paths().items()}
    fields.update((name, preparation["frozen"][name]) for name in preparation["baseline_sources"])
    return {
        "status": "PENDING" if pending else "PASS",
        "scope": "production-only candidate, released workbook and directed checks",
        "full_acceptance": "not established by these directed checks",
        "pending_native": pending,
        "source_git_revision": revision,
        "preparation_sha256": PREPARATION_SHA,
        "package": pack,
        "package_report_sha256": path_digest(HERE / "PackageChecks.json"),
        "source_agreement": agreement,
        "source_agreement_sha256": path_digest(HERE / "SourceAgreement.json"),
        "raw_vbe_comparison": formatting,
        "structure": structure,
        "compile": compiler,
        "export": exporter,
        "previous": baseline,
        "installable": fields,
        "native": native,
        "stale_screen_comparison": stale,
    }


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions for release verification")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allow-pending", action="store_true", help="report only completed checks and require no output receipt")
    args = parser.parse_args()
    result = verify_release(args.allow_pending)
    if result["status"] == "PASS" and not args.allow_pending:
        PROOF.write_bytes(stable_json(result))
        print("PRODUCTION DIRECTED PASS", path_digest(PROOF), RELEASE_SHA)
    else:
        print(result["status"], "verified", ",".join(result["native"]), "pending", ",".join(result["pending_native"]))


if __name__ == "__main__":
    main()
