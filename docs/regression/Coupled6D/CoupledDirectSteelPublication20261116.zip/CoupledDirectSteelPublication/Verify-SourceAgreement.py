"""Сверяет рабочий исходник с повторной выгрузкой VBE и исходной книгой."""

import json
import re
from decimal import Decimal
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[1]
spec = spec_from_file_location("export_comparison", root / "Verify-ExportDifference.py")
parser = module_from_spec(spec)
spec.loader.exec_module(parser)
source_data = json.loads((root / "Preparation.json").read_bytes())
old = parser.modules(root / "workbook/output/VBA_All_Code.txt")
new = parser.modules(root / "docs/regression/Audit03/VBA_All_Code.txt")
tokens = re.compile(r'''"(?:""|[^"])*"|'[^\n]*|(?<![\w.])(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?[#%!&@^]?(?![\w.])''')


def normalized_numbers(line):
    def convert(token):
        value = token[0]
        if value.startswith(('"', "'")):
            return value
        suffix = value[-1] if value[-1] in "#%!&@^" else ""
        digits = value[:-1] if suffix else value
        return str(Decimal(digits).normalize()) + suffix

    return tokens.sub(convert, line)


def canon(lines):
    return [parser.code_case(line) for line in "\n".join(lines).rstrip().splitlines()]


def source(path):
    text = path.read_text(encoding="utf-8-sig")
    return canon(re.search(r"^Option Explicit.*", text, re.MULTILINE | re.DOTALL)[0].splitlines())


assert old.keys() == new.keys()
assert all(old[name][0] == new[name][0] for name in old)
actual_changes = {name for name in old if canon(old[name][1]) != canon(new[name][1])}
assert actual_changes == set(source_data["modules"])
proof = {}
for name in source_data["baseline_sources"]:
    module = Path(name).stem
    historical_source = source(repo / name)
    historical_export = canon(old[module][1])
    current_source = source(root / name)
    current_export = canon(new[module][1])
    assert len(historical_source) == len(historical_export), module
    assert len(current_source) == len(current_export), module
    historical_pairs = set(zip(historical_source, historical_export, strict=True))
    inherited = []
    exact_decimals = []
    for i, (line, exported) in enumerate(zip(current_source, current_export, strict=True), start=1):
        if line == exported:
            continue
        if (line, exported) in historical_pairs:
            inherited.append(i)
        elif normalized_numbers(line) == normalized_numbers(exported):
            exact_decimals.append(i)
        else:
            raise AssertionError((module, i, line, exported))
    proof[module] = {"lines": len(current_source), "matches_existing_vbe_line": inherited,
                     "equal_decimal_spelling": exact_decimals, "source_sha256": source_data["frozen"][name]}

report = {"status": "PASS", "actual_components": len(new), "unchanged_components": len(new) - len(proof),
          "changed_components": proof}
(root / "SourceAgreement.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(f"SOURCE AGREEMENT: {len(proof)} changed and {report['unchanged_components']} unchanged components")
