"""ДЛЯ ТЕСТОВ. Разрешает поворот монотонной материальной ветви только после независимого половинного шага."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(root, parent, count, ratio, maximum):
    """Силовые и материальные допуски сохраняет; сравнение двух размеров заменяет лишь эвристический запрет поворота старой секущей."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestMaterialBranchEnergy.py'))['TestStage'](root, parent, count, ratio)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    anchor = '        If verified And unchanged And forward And steel <= 1# And energy - baseline > 2# * tolerance / rowScale Then'
    assert code.count(anchor) == 1
    replacement = '''        Dim materialOrientation As Boolean: materialOrientation = forward
        If verified And unchanged And Not forward And steel <= 1# Then
            mReverseSolverTest.DiscardStep
            materialOrientation = TestMaterialHalfCoordinate(accepted, currentFactor, field, factor, projection, _
                baseline, target, rowScale, tolerance, handle, attempt)
            verified = False: unchanged = False
            If materialOrientation Then
                seed = field
                verified = mReverseSolverTest.TryStep(load(1), load(2), load(3), load(4), load(5), load(6), _
                    mReverseOptionsTest(3), mReverseOptionsTest(4), 1, initialField:=seed)
                If verified Then
                    unchanged = True: mReverseSolverTest.CopyTrial checked, actual
                    For degree = 1 To UBound(field): If checked(degree) <> field(degree) Then unchanged = False
                    Next degree
                    steel = mReverseReinforcedTest.TrialSteelUtilization
                End If
            End If
            Print #handle, "ORIENTATION_RESOLVED" & TestHardPreparedVector(Array(attempt, materialOrientation, verified, unchanged, steel))
        End If
        If verified And unchanged And materialOrientation And steel <= 1# And energy - baseline > 2# * tolerance / rowScale Then'''
    code = code.replace(anchor, replacement, 1)
    code += '\n' + (here / 'TestMaterialHalfCoordinate.bas.txt').read_text('utf-8-sig')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    vector = run_path(str(here / 'Stage-TestMaterialBranchEnergy.py'))['TestVector']
    name = 'Input/MaterialProbeRatio.bin'
    (root / name).write_bytes(vector([ratio, maximum]))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for name in (Path(__file__).name, 'TestMaterialHalfCoordinate.bas.txt'):
        (root / name).write_bytes((here / name).read_bytes())
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='MaterialEnvelopeHalfStepOrientation',
        maximum_accepted_steps=maximum, mechanical_reversal_requires_halfstep_convergence=True,
        mechanical_halfstep_relative_tolerance=.005, original_native_force_verification_for_full_and_half=True,
        half_step_does_not_commit_material_history=True, physical_capacity_certified=False,
        actual_import_this_pass=['modTestCoupledElasticState'])
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('MATERIAL HALF-STEP ORIENTATION READY', count, ratio, maximum)


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    p.add_argument('--count', type=int, default=184)
    p.add_argument('--ratio', type=float, default=1.)
    p.add_argument('--maximum', type=int, default=20)
    a = p.parse_args()
    TestStage(a.root.resolve(), a.parent.resolve(), a.count, a.ratio, a.maximum)
