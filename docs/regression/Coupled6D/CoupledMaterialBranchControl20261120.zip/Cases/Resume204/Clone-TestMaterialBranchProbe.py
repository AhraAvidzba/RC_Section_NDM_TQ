"""ДЛЯ ТЕСТОВ. Повторно использует точный собранный код материальной пробы с другой принятой историей или шагом."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import struct
import numpy as np


def TestClone(root, parent, count, ratio, maximum, native_source=False):
    """Меняет только тестовые данные; нативная сессия восстанавливает историю заново без переносимых состояний материала."""
    assert 150 <= count <= 1000 and ratio in (.5, 1., 2.) and 1 <= maximum <= 20
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestEnergyNumerics.py'))['TestClone'](root, parent, 1e-6, 1, 1e-6, 0)
    helper = run_path(str(here / 'Stage-TestMaterialBranchEnergy.py'))
    vector = helper['TestVector']
    original = run_path(str(here / 'Check-TestActualReverseCapture.py'))['TestReadBinary'](parent / 'Input/Original147.bin')
    source = parent / ('Native/IntegratedEvent.Sequence.csv' if native_source else 'Input/OriginalSequence.csv')
    rows = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestRows'](source)
    frames = [r for r in rows if r[0] == 'F'][:count]
    fields = np.asarray([r[4:] for r in frames], float)
    fractions = np.asarray([r[2] for r in frames], float)
    factors = np.asarray([r[3] for r in frames], float)
    assert fields.shape == (count, 60)
    np.testing.assert_allclose(fields[:147], original['fields'], rtol=1e-14, atol=1e-300)
    fields[:147], fractions[:147], factors[:147] = original['fields'], original['fractions'], original['lambdas']
    snapshot = b'NDMREVTEST000001' + struct.pack('<i', 60)
    for key in ('calibration', 'options', 'offset', 'direction'):
        snapshot += vector(original[key])
    snapshot += struct.pack('<i', count)
    for fraction, factor, field in zip(fractions, factors, fields):
        snapshot += struct.pack('<dd', fraction, factor) + vector(field)
    for values in (fields[-2], fields[-1], fields[-1], original['offset'] + factors[-1] * original['direction'],
        original['projection'], [factors[-1], 0., factors[-1], 0.], np.zeros(4)):
        snapshot += vector(values)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for name, raw in {'Input/Reverse1.bin': snapshot, 'Input/MaterialProbeRatio.bin': vector([ratio, maximum]),
        'Input/OriginalSequence.csv': source.read_bytes(), Path(__file__).name: Path(__file__).read_bytes()}.items():
        (root / name).write_bytes(raw)
        prep['inputs'][name] = sha256(raw).hexdigest().upper()
    prep['directed_scope'].update(case='MaterialEnvelopeBranchDataRepeat', initial_history_states=count,
        material_increment_ratio=ratio, maximum_accepted_steps=maximum,
        fresh_compilation_claimed=False, actual_import_this_pass=[],
        input_sequence_is_parent_native_output=native_source,
        compiled_parent_source_reused_exactly=True, current_compiled_working_classes_unchanged=True,
        actual_working_Trace_API=False, total_thermodynamic_dissipation_claimed=False,
        numerical_reference_is_SciPy=False, original_force_and_material_precision=True,
        physical_capacity_certified=False, actual_full_stock_claimed=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('MATERIAL BRANCH DATA REPEAT READY', count, ratio, maximum, 'NO NEW COMPILATION')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    p.add_argument('--count', type=int, required=True)
    p.add_argument('--ratio', type=float, default=1.)
    p.add_argument('--maximum', type=int, default=8)
    p.add_argument('--native-source', action='store_true')
    a = p.parse_args()
    TestClone(a.root.resolve(), a.parent.resolve(), a.count, a.ratio, a.maximum, a.native_source)
