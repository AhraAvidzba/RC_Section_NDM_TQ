"""ДЛЯ ТЕСТОВ. Продолжает принятую материальную ветвь и сохраняет точные двоичные контрольные состояния после каждого шага."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(root, parent, maximum):
    """Добавляет только вывод контрольного снимка; численный алгоритм, силы, материальная модель и допуски сохраняются."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Clone-TestMaterialBranchProbe.py'))['TestClone'](root, parent, 204, 1., maximum, True)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    for before, after in [('docs/regression/CodeUpdate.json', 'ParentCodeUpdate.json'), ('CompileClosure.json', 'ParentCompileClosure.json')]:
        (root / after).write_bytes((root / before).read_bytes())
        prep['inputs'][after] = sha256((root / after).read_bytes()).hexdigest().upper()
    ancestor = root / ('SnapshotBuildAncestor_' + root.name)
    ancestor.mkdir()
    for name in ('CompilePoint.log', 'CompilePointClosure.json'):
        if (root / name).exists():
            (root / name).replace(ancestor / name)
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    anchor = '            priorEnergy = baseline: baseline = energy: previousFactor = currentFactor: currentFactor = factor'
    assert code.count(anchor) == 1
    code = code.replace(anchor, '            TestWriteSpatialSequenceSnapshot fields, trace, projection, target, actual, attempt\n' + anchor, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Compile-TestExternalPoint.ps1'
    (root / name).write_bytes((here / name).read_text('utf-8-sig').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = Path(__file__).name
    (root / name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='MaterialEnvelopeBranchWithExactCheckpoints', actual_import_this_pass=['modTestCoupledElasticState'],
        fresh_compilation_claimed=True, native_binary_checkpoint_after_each_accepted_step=True,
        only_added_test_snapshot_output=True, physical_capacity_certified=False)
    (root / 'Preparation.json').write_bytes((json.dumps(prep, indent=2, sort_keys=True) + '\n').encode())
    print('NATIVE MATERIAL BRANCH CONTINUATION READY; 204 INPUT STATES; EXACT CHECKPOINTS AFTER ACCEPTANCE')


if __name__ == '__main__':
    p = ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    p.add_argument('--maximum', type=int, default=8)
    a = p.parse_args()
    TestStage(a.root.resolve(), a.parent.resolve(), a.maximum)
