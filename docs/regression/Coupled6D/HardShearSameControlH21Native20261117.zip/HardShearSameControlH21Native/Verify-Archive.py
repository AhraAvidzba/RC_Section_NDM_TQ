"""Независимо воспроизводит нативную сверку рабочего повтора H21."""

import argparse
from pathlib import Path

from RankVerify import digest, obj, val
import Verify
import VerifyDetached

HERE = Path(__file__).resolve().parent
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
CONTINUATION = "src/Solver/CCoupledDeformationContinuation.cls"


def source(name):
    return (HERE / name).read_text(encoding="utf-8-sig")


def audit_source():
    old = source(f"Candidate/{CONTINUATION}")
    desired = """    If HardRankRequestedTest Then
        HardRankFinishedTest = ReplayHardNextTest(mSolver, mOffset, mDirection, mMaximumLambda, mAbsTol, mRelTol, mMaxIterations)
        StopSearch "Диагностическая остановка после повторения одной пробы HardShear."
        Exit Sub
    End If
"""
    assert source(CONTINUATION).replace(desired, "", 1) == old
    runtime = source(f"Candidate/{NEWTON}").rstrip()
    full = source(NEWTON)
    tap = """    If Len(mHardNextLaneTest) > 0 Then
        WriteHardRankRowTest "CROSS;" & mHardNextLaneTest & ";" & CStr(station.Point) & ";" & CStr(station.Side) & ";" & _
            HardRankBitsTest(station.FromValue) & ";" & HardRankBitsTest(station.ToValue)
    End If
"""
    assert full.count(tap) == 1 and full.count("Private mHardNextLaneTest As String\n") == 1
    full = full.replace(tap, "", 1).replace("Private mHardNextLaneTest As String\n", "", 1)
    assert full.startswith(runtime + "\n\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n")
    assert full.rstrip().endswith(source("Proof.bas").rstrip())


def main():
    options = argparse.ArgumentParser(description=__doc__)
    options.add_argument("--saved-workbook", type=Path)
    user = options.parse_args()
    manifest = obj("SHA256SUMS.json")
    complete = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file() and p.name != "SHA256SUMS.json"}
    assert complete == set(manifest) and all(digest(HERE/name) == expected for name, expected in manifest.items())
    fixture = obj("Fixture.json")
    for name, expected in fixture["inputs"].items():
        assert manifest[name] == expected
    for name, expected in fixture["production"].items():
        assert manifest[f"Baseline/{name}"] == expected
    production = obj("Candidate/Production.json")
    assert production["production"] == fixture["candidate_source"]
    for name, expected in production["production"].items():
        assert manifest[f"Candidate/{name}"] == expected
        assert production["base"][name] == fixture["production"][name]
    assert manifest["Parent/Fixture.json"] == fixture["parent_fixture_sha256"]
    assert manifest["Parent/ShoulderVerification.json"] == fixture["source_shoulder_report_sha256"]
    assert obj("Parent/Fixture.json")["source_workbook_sha256"] == fixture["source_workbook_sha256"]
    audit_source()
    prior = obj("Parent/ShoulderVerification.json")
    short, = [arm for arm in prior["arms"] if arm["id"][0] == "Short8"]
    expected = obj("Expected.json")
    assert expected["history"] == short["prefix_bits"] + [p["field_bits"] for p in short["points"]]
    assert expected["previous"] == short["points"][-1] and expected["projection"] == short["guide"]
    start, end = map(val, short["common"][1:3])
    assert expected["target"] == start+(end-start)*6/8
    assert expected["seed_lambda"] == expected["previous"]["lambda"]
    compile_info = obj("docs/regression/CodeUpdate.json")
    compiler = obj("CompileClosure.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    receipt = obj("Native/HardShear.txt.ProcessClosure.json")
    ending = receipt["Closure"]["FinalState"]
    assert compiler["State"] == ending["State"] == "Absent"
    assert f"OWNED_EXCEL: id={compiler['PID']}; utcStartTicks={compiler['StartTicksUTC']}" in source("Compile.log")
    assert compile_info["Compiled"] and not compile_info["ProductionChanged"]
    assert compile_info["ProductionSHA256"] == fixture["source_workbook_sha256"]
    assert compile_info["Modules"] == ["CCoupledDeformationContinuation", "CCoupledNewtonSolver", "modTestCoupledElasticState"]
    assert owner["SourceSHA256"] == compile_info["WorkbookSHA256"]
    assert receipt["Passed"] and receipt["ChildExitCode"] == 0
    assert (owner["PID"], owner["StartTicksUTC"]) == (ending["PID"], ending["StartTicksUTC"])
    audit = obj("Audit.json")
    assert audit["original_checker_exit_code"] == 1
    assert audit["original_checker_false_failure"] == "pre-recovery diagnostics expected at prefix rather than exact suffix"
    assert 'assert contexts["E"]["diagnostics"].startswith(contexts["A"]["diagnostics"])' in source("OriginalChecker.stderr.txt")
    raw = HERE / "Native/HardNext.csv"
    try:
        Verify.parse(raw, expected)
    except AssertionError:
        pass
    else:
        raise RuntimeError("Original format assertion was expected to fail")
    cases, skipped = VerifyDetached.parse(raw, expected)
    report = obj("Native/Verification.json")
    assert cases == report["cases"] and skipped == report["skipped"] == {}
    assert report["stock_failure_reproduced"] and not report["capacity_or_failure_certified"]
    previous = obj("Parent/ManualH21Verification.json")
    assert cases["A"] == previous["cases"]["A"] and cases["B"] == previous["cases"]["B"]
    assert cases["C"] == previous["cases"]["C"]
    assert report["source_trace_sha256"] == manifest["Native/HardNext.csv"]
    assert report["native_log_sha256"] == manifest["Native/HardShear.txt"]
    assert audit["native_report_sha256"] == manifest["Native/Verification.json"]
    assert cases["D"]["used_current_step_iterations"] == 9 and cases["D"]["certified_at_original_target"]
    assert cases["E"]["used_current_step_iterations"] == 6 and not cases["E"]["certified_balanced_this_control"]
    assert cases["F"] == cases["G"] and cases["F"]["used_current_step_iterations"] == 0
    log = source("Native/HardShear.txt")
    assert "TOTAL_HARD_SHEAR_NEXT: passed=1; failed=0" in log
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    assert f"RESULTS_SAVE_REOPEN: before={audit['reopen_sha256']}; after={audit['reopen_sha256']}; equal=True" in log
    if user.saved_workbook:
        assert digest(user.saved_workbook) == audit["saved_workbook_sha256"]
    print("HARDSHEAR SAME CONTROL H21 PORTABLE VERIFIED")


if __name__ == "__main__":
    main()
