
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет возврат на исходную меру и недостаток общего лимита итераций.
Private Sub RunHardSameControlLaneTest(ByVal history As Collection, ByRef projection() As Double, _
        ByRef offset() As Double, ByRef direction() As Double, ByVal target As Double, ByVal seedLambda As Double, _
        ByVal maxLambda As Double, ByVal absoluteTolerance As Double, ByVal relativeTolerance As Double, _
        ByVal iterations As Long, ByVal lane As String, Optional ByVal allowRecovery As Boolean = True)
    If Not PrepareHardNextLaneTest(history, lane) Then Err.Raise 5, , "История H20 не восстановлена."
    Dim factor As Double, solved As Boolean, projectionReadback() As Double, restored() As Double, original() As Double
    Dim meansChanged As Boolean, i As Long
    solved = TryDeformationStep(offset, direction, projection, target, seedLambda, factor, _
        absoluteTolerance, relativeTolerance, iterations, consistentControl:=True, recoverSameControl:=allowRecovery)
    meansChanged = CopyRecoveredControl(projectionReadback)
    CopyAccepted restored: original = history.Item(history.Count)
    For i = 1 To UBound(original)
        If HardRankBitsTest(restored(i)) <> HardRankBitsTest(original(i)) Then Err.Raise 5, , "Проба изменила принятое поле H20."
    Next i
    WriteHardRankRowTest "BUDGET;" & lane & ";" & CStr(iterations) & ";" & CStr(mIterations) & ";" & _
        CStr(SameControlRecoveryTried) & ";" & CStr(meansChanged) & ";" & CStr(mCandidateReady) & ";" & _
        HardRankBitsTest(mTargetControl) & ";" & HardRankVectorTest(mControlProjection)
    WriteHardNextOutcomeTest solved, maxLambda, absoluteTolerance, relativeTolerance
End Sub
