"""Готовит кандидат восстановления пробы в той же мере деформации."""

from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
REVISION = "5f476b84f4662d92c07301ee4e2ec91be4998141"
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
CONTINUATION = "src/Solver/CCoupledDeformationContinuation.cls"


def digest(data):
    return sha256(data).hexdigest().upper()


def install(name, content):
    dest = HERE / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        assert dest.read_bytes() == content, dest
    else:
        dest.write_bytes(content)
    return digest(content)


def once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def compose_newton(src):
    src = once(src, """Private mYieldRecoveryTried As Boolean
Private mRecoveredProjection() As Double""", """Private mYieldRecoveryTried As Boolean, mSameControlRecoveryTried As Boolean
Private mRecoveredControlReady As Boolean
Private mSameControlInitialFailure As String
Private mRecoveredProjection() As Double""")
    src = once(src, """        Optional ByVal consistentControl As Boolean = False) As Boolean
    If LBound(baseLoad)""", """        Optional ByVal consistentControl As Boolean = False, Optional ByVal recoverSameControl As Boolean = False) As Boolean
    If LBound(baseLoad)""")
    src = once(src, """    TryDeformationStep = SolveStep(load, initialLambda, absoluteTolerance, relativeTolerance, maxIterations, recoverYieldControl)""",
               """    TryDeformationStep = SolveStep(load, initialLambda, absoluteTolerance, relativeTolerance, maxIterations, _
        recoverYieldControl, recoverSameControl:=recoverSameControl)""")
    src = once(src, "    If Not mCandidateReady Or Not mYieldRecoveryTried Then Exit Function",
               "    If Not mCandidateReady Or Not mRecoveredControlReady Then Exit Function")
    src = once(src, """    YieldRecoveryTried = mYieldRecoveryTried
End Property""", """    YieldRecoveryTried = mYieldRecoveryTried
End Property

' Сообщает о проверке перехода для повтора в той же мере. Эта проверка
' расходует отдельный бюджет, даже если пересечение не найдено.
Friend Property Get SameControlRecoveryTried() As Boolean
    SameControlRecoveryTried = mSameControlRecoveryTried
End Property""")
    src = once(src, """        Optional ByVal retainDirectProof As Boolean = False) As Boolean
    mDirectProofMatrix = False""", """        Optional ByVal retainDirectProof As Boolean = False, Optional ByVal recoverSameControl As Boolean = False) As Boolean
    mDirectProofMatrix = False""")
    src = once(src, """    mYieldRecoveryTried = False: Erase mRecoveredProjection""", """    mYieldRecoveryTried = False: mSameControlRecoveryTried = False
    mSameControlInitialFailure = vbNullString
    mRecoveredControlReady = False: Erase mRecoveredProjection""")
    src = once(src, """            If recoverYieldControl And Len(mismatch) > 0 And mUseSpatialHistory Then
                SolveStep = RecoverYieldStep(current, currentLambda, correction, trialFraction, tolerance, _
                    absoluteTolerance, relativeTolerance)
            End If""", """            If Len(mismatch) > 0 And mUseSpatialHistory Then
                If recoverYieldControl Then
                    SolveStep = RecoverYieldStep(current, currentLambda, correction, trialFraction, tolerance, _
                        absoluteTolerance, relativeTolerance)
                ElseIf recoverSameControl And mControlActive And mConsistentControl And Not mSameControlRecoveryTried Then
                    If mIterations + 1 < maxIterations Then
                        mSameControlRecoveryTried = True
                        mSameControlInitialFailure = details
                        If TrySameControlSeed(current, currentLambda, correction, trialFraction, tolerance, _
                                absoluteTolerance, relativeTolerance, maxIterations - 1) Then
                            mIterations = mIterations + 1 ' Заблокированное направление расходует одну итерацию этого шага.
                            SetControlledLoad currentLambda, load
                            tolerance = EquilibriumTolerance(absoluteTolerance, relativeTolerance)
                            GoTo RecomputeTangent
                        End If
                        mMeta.DiagnosticDetails = mMeta.DiagnosticDetails & "; проверка перехода в исходной мере не дала прогноза"
                    End If
                End If
            End If""")
    src = once(src, """                mRecoveredProjection = newProjection
                mCandidate = result""", """                mRecoveredProjection = newProjection: mRecoveredControlReady = True
                mCandidate = result""")
    src = once(src, """' Ищет соседнюю траекторию только после наблюдаемой смены ветви на""", """' Использует равновесие у перехода только как первое приближение той же
' пробы. Контроль и история исходные, промежуточное поле не принимается.
Private Function TrySameControlSeed(ByRef field() As Double, ByRef lambda As Double, ByRef correction() As Double, _
        ByVal fraction As Double, ByVal tolerance As Double, ByVal absoluteTolerance As Double, _
        ByVal relativeTolerance As Double, ByVal iterationLimit As Long) As Boolean
    Dim originalProjection() As Double, originalTarget As Double
    originalProjection = mControlProjection: originalTarget = mTargetControl
    If Not RecoverYieldStep(field, lambda, correction, fraction, tolerance, absoluteTolerance, relativeTolerance, iterationLimit) Then Exit Function
    field = mCandidate: lambda = mTrialLambda
    mControlProjection = originalProjection: mTargetControl = originalTarget
    DiscardStep
    mRecoveredControlReady = False: Erase mRecoveredProjection
    TrySameControlSeed = True
End Function

' Ищет соседнюю траекторию только после наблюдаемой смены ветви на""")
    src = once(src, """        ByVal relativeTolerance As Double) As Boolean
    If Not (TypeOf mResponse Is CCoupledReinforcedResponse""",
               """        ByVal relativeTolerance As Double, Optional ByVal iterationLimit As Long = 0) As Boolean
    If Not (TypeOf mResponse Is CCoupledReinforcedResponse""")
    src = once(src, """            tolerance, absoluteTolerance, relativeTolerance, True, result, trialLambda, newProjection) Then""",
               """            tolerance, absoluteTolerance, relativeTolerance, True, result, trialLambda, newProjection, iterationLimit) Then""")
    src = once(src, """        ByRef result() As Double, ByRef lambda As Double, ByRef projection() As Double) As Boolean
    Dim target As Double""",
               """        ByRef result() As Double, ByRef lambda As Double, ByRef projection() As Double, _
        Optional ByVal iterationLimit As Long = 0) As Boolean
    Dim target As Double""")
    src = once(src, """    For trial = 1 To 2
        If LocateYieldCoordinate""", """    For trial = 1 To 2
        If iterationLimit > 0 And mIterations >= iterationLimit Then Exit Function
        If LocateYieldCoordinate""")
    src = once(src, """                    target, absoluteTolerance, relativeTolerance, allowSuccessor, result, lambda, projection) Then""",
               """                    target, absoluteTolerance, relativeTolerance, allowSuccessor, result, lambda, projection, iterationLimit) Then""")
    src = once(src, """        ByRef result() As Double, ByRef resultLambda As Double, ByRef projection() As Double) As Boolean
    Dim field() As Double""",
               """        ByRef result() As Double, ByRef resultLambda As Double, ByRef projection() As Double, _
        Optional ByVal iterationLimit As Long = 0) As Boolean
    Dim field() As Double""")
    src = once(src, """    For iteration = 1 To YIELD_TRACE_ITERATIONS
        SetControlledLoad""", """    For iteration = 1 To YIELD_TRACE_ITERATIONS
        If iterationLimit > 0 Then
            If mIterations >= iterationLimit Then Exit Function
            mIterations = mIterations + 1 ' Направляющая итерация расходует общий остаток, даже при отказе.
        End If
        SetControlledLoad""")
    src = once(src, """                                    absoluteTolerance, relativeTolerance, False, result, resultLambda, projection) Then""",
               """                                    absoluteTolerance, relativeTolerance, False, result, resultLambda, projection, iterationLimit) Then""")
    src = once(src, """        field = trial: lambda = trialLambda
        mIterations = mIterations + 1""",
               """        field = trial: lambda = trialLambda
        If iterationLimit = 0 Then mIterations = mIterations + 1""")
    src = once(src, """    mMeta.SetSolverFailure code, rkDirectState, reason, (mEvaluations > 0)
    mMeta.DiagnosticDetails = DiagnosticSummary()""", """    mMeta.SetSolverFailure code, rkDirectState, reason, (mEvaluations > 0)
    mMeta.DiagnosticDetails = DiagnosticSummary()
    If Len(mSameControlInitialFailure) > 0 Then _
        mMeta.DiagnosticDetails = mMeta.DiagnosticDetails & " | До восстанавливающей пробы: " & mSameControlInitialFailure""")
    src = once(src, """    If mLocalGradientBuilds > 0 Then DiagnosticSummary = DiagnosticSummary &""",
               """    If mSameControlRecoveryTried Then DiagnosticSummary = DiagnosticSummary & "; проверен переход для исходной меры"
    If mLocalGradientBuilds > 0 Then DiagnosticSummary = DiagnosticSummary &""")
    return src


def compose_continuation(src):
    src = once(src, """Private Const YIELD_RECOVERY_LIMIT As Long = 4""",
               """Private Const FIXED_YIELD_RECOVERY_LIMIT As Long = 4 ' Проверки перехода без смены меры за одно продолжение.
Private Const YIELD_RECOVERY_LIMIT As Long = 4""")
    src = once(src, "Private mYieldRecoveryProbes As Long, mYieldRecoveredPoints As Long",
               "Private mYieldRecoveryProbes As Long, mYieldRecoveredPoints As Long\nPrivate mFixedYieldRecoveryProbes As Long")
    src = once(src, "    mYieldRecoveryProbes = 0: mYieldRecoveredPoints = 0",
               "    mYieldRecoveryProbes = 0: mYieldRecoveredPoints = 0: mFixedYieldRecoveryProbes = 0")
    src = once(src, """        Optional ByVal recoverYieldControl As Boolean = False) As Boolean
    If mProbeCount""", """        Optional ByVal recoverYieldControl As Boolean = False, Optional ByVal keepYieldControl As Boolean = False) As Boolean
    If mProbeCount""")
    src = once(src, """    Dim solved As Boolean
    solved = mSolver.TryDeformationStep(mOffset, mDirection, mProjection, point.Coordinate, initialLambda, _
        point.Lambda, mAbsTol, mRelTol, mMaxIterations, recoverYieldControl, mUsesYieldControl)
    If mSolver.YieldRecoveryTried Then mYieldRecoveryProbes = mYieldRecoveryProbes + 1""", """    Dim solved As Boolean, recoverSameControl As Boolean
    recoverSameControl = keepYieldControl And mUsesYieldControl And mFixedYieldRecoveryProbes < FIXED_YIELD_RECOVERY_LIMIT
    solved = mSolver.TryDeformationStep(mOffset, mDirection, mProjection, point.Coordinate, initialLambda, _
        point.Lambda, mAbsTol, mRelTol, mMaxIterations, recoverYieldControl, mUsesYieldControl, recoverSameControl)
    If mSolver.SameControlRecoveryTried Then
        mFixedYieldRecoveryProbes = mFixedYieldRecoveryProbes + 1
    ElseIf mSolver.YieldRecoveryTried Then
        mYieldRecoveryProbes = mYieldRecoveryProbes + 1
    End If""")
    src = once(src, "    If Not Probe(trial, current.Lambda) Then\n        StopSearch",
               "    If Not Probe(trial, current.Lambda, keepYieldControl:=True) Then\n        StopSearch")
    src = once(src, "            If Not Probe(point, previousLambda) Then Exit Function",
               "            If Not Probe(point, previousLambda, keepYieldControl:=keepRight) Then Exit Function")
    src = once(src, "        If Not Probe(point, low.Lambda) Then Exit Function",
               "        If Not Probe(point, low.Lambda, keepYieldControl:=True) Then Exit Function")
    src = once(src, "            If Not Probe(high, low.Lambda) Then Exit Function",
               "            If Not Probe(high, low.Lambda, keepYieldControl:=True) Then Exit Function")
    src = once(src, "    If mPostPeakWidePoints > 0 Then Details = Details &",
               """    If mFixedYieldRecoveryProbes > 0 Then Details = Details & _
        "; проверок перехода в исходной мере: " & CStr(mFixedYieldRecoveryProbes)
    If mPostPeakWidePoints > 0 Then Details = Details &""")
    return src


def main():
    raw = {}
    modified = {}
    for path, compose in ((NEWTON, compose_newton), (CONTINUATION, compose_continuation)):
        base = check_output(["git", "show", f"{REVISION}:{path}"], cwd=REPO)
        text = base.decode("utf-8-sig").replace("\r\n", "\n")
        assert (REPO / path).read_text(encoding="utf-8-sig") == text
        cooked = compose(text).rstrip().replace("\n", "\r\n").encode("utf-8") + b"\r\n"
        raw[path] = digest(base)
        modified[path] = install(path, cooked)
    fixture = {"revision": REVISION, "base": raw, "production": modified}
    print(install("Production.json", (json.dumps(fixture, indent=2)+"\n").encode("utf-8")))


if __name__ == "__main__":
    main()
