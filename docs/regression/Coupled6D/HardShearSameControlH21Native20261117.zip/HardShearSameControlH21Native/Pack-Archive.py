"""Упаковывает рабочий кандидат, нативные квитанции и перепроверку H21."""

from hashlib import sha256
import json
from pathlib import Path
import re
from subprocess import check_call, check_output, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from RankVerify import inputs, obj

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
PREFIX = "HardShearSameControlH21Native"
ARCHIVE = HERE / f"{PREFIX}20261117.zip"
PRODUCTION = "C1798392AA3A892F87FEF31E00C36A18FE63500E0E6240DA5D585F02B3179B53"
REPORT = "FCF1ACA04492C8634BA7000FA92A3BC6F51E2D77A6D6D38998CC106F96C1BD3F"
CORRECTED = "7FE2959379A93A264EF0442D5A25E77C393E2477F1ED0150389B612B9A27D37D"


def digest(value):
    return sha256(value).hexdigest().upper()


def serialized(value):
    return (json.dumps(value, indent=2, ensure_ascii=False)+"\n").encode("utf-8")


def main():
    fixture = obj("Fixture.json")
    inputs(fixture)
    paths = {*fixture["inputs"], "Fixture.json", "Compile.log", "CompileClosure.json", "Run.ndjson",
             "docs/regression/CodeUpdate.json", "VerifyDetached.py", "Verify-Archive.py", "Pack-Archive.py", "README-Archive.md"}
    paths.update(p.relative_to(HERE).as_posix() for p in (HERE / "Native").iterdir() if p.is_file() and p.suffix.lower() != ".xlsm")
    data = {name: (HERE/name).read_bytes() for name in paths}
    assert digest(data["Native/Verification.json"]) == REPORT and digest(data["VerifyDetached.py"]) == CORRECTED
    for name, expected in fixture["production"].items():
        raw = check_output(["git", "show", f"{fixture['source_revision']}:{name}"], cwd=REPO)
        assert digest(raw) == expected
        data[f"Baseline/{name}"] = raw
    definitions = (HERE.parent/"hsr/Production.json").read_bytes()
    assert digest(definitions) == PRODUCTION
    data["Candidate/Production.json"] = definitions
    data["Candidate/Compose.py"] = (HERE.parent/"hsr/Compose.py").read_bytes()
    for name, expected in fixture["candidate_source"].items():
        raw = (HERE/"Candidate"/name).read_bytes()
        assert digest(raw) == expected
        data[f"Candidate/{name}"] = raw
    for name, from_file, expected in (
        ("Fixture.json", "hs-next/Fixture.json", fixture["parent_fixture_sha256"]),
        ("ShoulderVerification.json", "hs-fold/Native/Verification.json", fixture["source_shoulder_report_sha256"]),
        ("ManualH21Verification.json", "hs-next/Native/Verification.json", "EF61B67898422436F13381FBBD3235DF673C9F7A2C85B998479D3E6D225E6100"),
    ):
        raw = (HERE.parent/from_file).read_bytes()
        assert digest(raw) == expected
        data[f"Parent/{name}"] = raw
    run_result = run([sys.executable, "-B", "-X", "utf8", "Verify.py"], cwd=HERE, capture_output=True, check=False)
    assert run_result.returncode == 1 and b'.startswith(contexts["A"]["diagnostics"])' in run_result.stderr
    data["OriginalChecker.stdout.txt"] = run_result.stdout
    data["OriginalChecker.stderr.txt"] = run_result.stderr
    log = (HERE/"Native/HardShear.txt").read_text(encoding="utf-8-sig")
    saved = re.search(r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$", log, re.M)
    assert saved
    workbook = Path(saved[2]).resolve(strict=True)
    assert workbook.is_relative_to(HERE/"Temp")
    data["Audit.json"] = serialized({"reopen_sha256": saved[1], "saved_workbook_sha256": digest(workbook.read_bytes()),
                                    "native_report_sha256": REPORT, "original_checker_exit_code": run_result.returncode,
                                    "original_checker_false_failure":
                                        "pre-recovery diagnostics expected at prefix rather than exact suffix"})
    data["SHA256SUMS.json"] = serialized({name: digest(raw) for name, raw in sorted(data.items())})
    with TemporaryDirectory(prefix="hsr-directed-proof-", dir=HERE) as directory:
        root = Path(directory)
        archive = root/ARCHIVE.name
        with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=9) as bundle:
            for name, raw in sorted(data.items()):
                entry = ZipInfo(f"{PREFIX}/{name}", date_time=(2026, 11, 17, 0, 0, 0))
                bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(archive) as bundle:
            assert bundle.testzip() is None and not any(n.lower().endswith(".xlsm") for n in bundle.namelist())
            bundle.extractall(root/"detached")
        cmd = [sys.executable, "-B", "-X", "utf8", "Verify-Archive.py"]
        cwd = root/"detached"/PREFIX
        check_call(cmd, cwd=cwd)
        check_call([*cmd, "--saved-workbook", str(workbook)], cwd=cwd)
        ARCHIVE.write_bytes(archive.read_bytes())
    checksum = digest(ARCHIVE.read_bytes())
    ARCHIVE.with_suffix(".zip.sha256").write_bytes(f"{checksum}  {ARCHIVE.name}\n".encode("ascii"))
    print("PORTABLE HARDSHEAR SAME CONTROL H21 VERIFIED", checksum, ARCHIVE.stat().st_size)


if __name__ == "__main__":
    main()
