"""Сверяет изолированный шаг Short8 на исходной проекции и ветви материала."""

import argparse
from pathlib import Path
import json
import math
import re

from RankVerify import digest, dot, inputs, obj, val

HERE = Path(__file__).resolve().parent
SCALES = (21600., 2219577.365175632, 2219577.365175632, 2219577.365175632, 21600., 21600.)
FORCES = (28000., 510000., 180000., 1500000., 17000., -7100.)
VECTORS = {"P": 60, "TARGET": 6, "ACTUAL": 6, "FIELD": 60, "RESIDUAL": 60}


def numbers(tokens):
    return list(map(val, tokens))


def check_lane(lane, glob, expected, data):
    assert data["SOLVER"][0] in ("True", "False")
    assert data["SOLVER"][1] in ("True", "False")
    assert data["START"] == ["20", *expected["history"][-1]]
    summary = {"solved": data["SOLVER"][0] == "True", "yield_recovery_attempted": data["SOLVER"][1] == "True",
               "result_code": data["SOLVER"][2], "diagnostics": data["SOLVER"][3], "crossings": []}
    for row in data.get("CROSS", []):
        old_yield, new_yield = numbers(row[2:])
        assert lane in ("B", "D", "E") and old_yield*new_yield < 0 and int(row[1]) in (-1, 0, 1)
        summary["crossings"].append({"fixture_point": int(row[0]), "axial_side": int(row[1]),
                                     "from_yield_MPa": old_yield, "to_yield_MPa": new_yield})
    summary["certified_balanced_this_control"] = False
    summary["certified_at_original_target"] = False
    if "BALANCE" not in data:
        assert not summary["solved"] or data["UNVERIFIED"] == ["lambda-uncertainty"]
        return summary
    assert summary["solved"]
    factor, uncert, tolerance, reported, steel, target, control = numbers(data["BALANCE"][:-1])
    assert data["BALANCE"][-1] in ("True", "False")
    p, wanted, actual, field, residual = (numbers(data[label]) for label in VECTORS)
    assert all(len(data[label]) == count for label, count in VECTORS.items())
    force = max(abs(a-b)/s for a, b, s in zip(actual, wanted, SCALES, strict=True))
    assert all(math.isclose(t, f*factor, rel_tol=8e-13, abs_tol=2e-13) for f, t in zip(FORCES, wanted, strict=True))
    assert uncert > 0 and tolerance > 0 and steel >= 0
    weak = max(map(abs, residual[:56]))
    gauge = 30000*max(map(abs, residual[56:]))
    assert math.isclose(max(weak, force, abs(control)), reported, abs_tol=3e-13)
    assert math.isclose(30000*(dot(p[:56], field[:56])-target), control, abs_tol=2e-11)
    original = numbers(glob["ORIGINAL-P"])
    original_coordinate = dot(original[:56], field[:56])
    proposal = (max(weak, gauge, force, abs(control)) <= tolerance and
                data["BALANCE"][-1] == "True" and steel <= 1 and 0 < factor <= val(glob["PROBLEM"][2]))
    exact_target = p == original and target == expected["target"]
    if lane in ("A", "C", "D", "E"):
        assert exact_target
    summary.update(six_force_residual_MPa=force, weak_residual_MPa=weak, gauge_residual_MPa=gauge,
                   control_residual_MPa=control, tolerance_MPa=tolerance, steel_usage=steel, factor=factor,
                   factor_uncertainty=uncert, original_projection_coordinate=original_coordinate,
                   original_projection_advance=original_coordinate-expected["previous"]["coordinate"],
                   original_projection_target_gap_MPa=30000*(original_coordinate-expected["target"]),
                   certified_balanced_this_control=proposal,
                   certified_at_original_target=proposal and exact_target and original_coordinate > expected["previous"]["coordinate"])
    return summary


def parse(path, expected):
    text = path.read_text(encoding="cp1251", errors="replace").splitlines()
    assert text[0] == "HARDSHEAR-NEXT;1"
    glob, records, skipped = {}, {}, {}
    for line in text[1:]:
        key, *values = line.split(";")
        if key in ("PROBLEM", "LOAD-OFFSET", "LOAD-DIRECTION", "ORIGINAL-P"):
            assert key not in glob
            glob[key] = values
        else:
            lane, *data = values
            assert lane in ("A", "B", "C", "D", "E", "F", "G")
            if key == "SKIP":
                assert lane not in records and lane == "C" and data == ["no-certified-guide"]
                skipped[lane] = data
                continue
            loc = records.setdefault(lane, {})
            if key == "CROSS":
                loc.setdefault(key, []).append(data)
            else:
                assert key not in loc
                loc[key] = data
    assert set(records) | set(skipped) == {"A", "B", "C", "D", "E", "F", "G"}
    assert numbers(glob["PROBLEM"][:2]) == [expected["seed_lambda"], expected["target"]]
    assert len(glob["PROBLEM"]) == 6 and int(glob["PROBLEM"][-1]) == 30
    assert val(glob["PROBLEM"][2]) == 4.
    assert numbers(glob["LOAD-OFFSET"]) == [0.]*6
    assert all(math.isclose(a,b,rel_tol=4e-15) for a,b in zip(numbers(glob["LOAD-DIRECTION"]), FORCES, strict=True))
    assert glob["ORIGINAL-P"] == expected["projection"]
    contexts = {lane: check_lane(lane, glob, expected, data) for lane, data in records.items()}
    for lane in "DEFG":
        cap, used, tried, changed, ready, target_word, *projection = records[lane]["BUDGET"]
        cap, used = int(cap), int(used)
        assert 0 <= used <= cap and projection == expected["projection"]
        assert changed == "False" and ready == str(contexts[lane]["solved"])
        assert val(target_word) == (expected["target"] if lane in "DE" else expected["previous"]["coordinate"])
        assert tried == str(lane in "DE")
        contexts[lane].update(current_step_cap=cap, used_current_step_iterations=used,
                              recovery_examined=tried=="True", original_control_retained=True)
    assert contexts["D"]["certified_at_original_target"]
    assert contexts["D"]["crossings"] == contexts["B"]["crossings"]
    assert abs(contexts["D"]["factor"]-contexts["C"]["factor"]) <= 1e-12
    assert all(records["D"][marker] == records["C"][marker] for marker in ("P", "TARGET", "ACTUAL", "FIELD", "RESIDUAL", "BALANCE"))
    assert not contexts["E"]["solved"] and contexts["E"]["result_code"] == contexts["A"]["result_code"] == "10"
    assert contexts["E"]["diagnostics"].startswith(contexts["A"]["diagnostics"])
    assert contexts["F"]["solved"] and records["F"] == records["G"]
    return contexts, skipped


def main():
    arg = argparse.ArgumentParser(description=__doc__)
    arg.add_argument("--inputs", action="store_true")
    args = arg.parse_args()
    fixture = obj("Fixture.json")
    inputs(fixture)
    if args.inputs:
        print("INPUTS OK", digest(HERE / "Fixture.json"))
        return
    report = HERE / "Native/HardShear.txt"
    info = obj("docs/regression/CodeUpdate.json")
    compiler = obj("CompileClosure.json")
    owner = obj("Native/HardShear.txt.Ownership.json")
    closure = obj("Native/HardShear.txt.ProcessClosure.json")
    ending = closure["Closure"]["FinalState"]
    assert info["Compiled"] and not info["ProductionChanged"] and info["ProductionSHA256"] == fixture["source_workbook_sha256"]
    assert compiler["State"] == ending["State"] == "Absent"
    assert closure["Passed"] and closure["ChildExitCode"] == 0
    assert owner["SourceSHA256"] == info["WorkbookSHA256"]
    assert (owner["PID"], owner["StartTicksUTC"]) == (ending["PID"], ending["StartTicksUTC"])
    log = report.read_text(encoding="utf-8-sig")
    elapsed = re.search(r"^RANK_TIME: ([0-9.,]+)$",log,re.M)
    assert elapsed and "TOTAL_HARD_SHEAR_NEXT: passed=1; failed=0" in log
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    data = HERE / "Native/HardNext.csv"
    cases, skipped = parse(data, obj("Expected.json"))
    result = {"source_trace_sha256": digest(data), "native_log_sha256": digest(report),
              "native_elapsed_seconds": float(elapsed[1].replace(",", ".")),
              "stock_failure_reproduced": not cases["A"]["solved"], "cases": cases, "skipped": skipped,
              "capacity_or_failure_certified": False}
    output = HERE / "Native/Verification.json"
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    print("HARDSHEAR NEXT", digest(output), "retarget:", cases.get("C", {}).get("certified_at_original_target", False))


if __name__ == "__main__":
    main()
