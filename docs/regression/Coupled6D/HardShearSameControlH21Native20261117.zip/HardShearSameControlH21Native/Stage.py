"""Проверяет кандидат одного шага HardShear вместе со штатным полным вызовом Both."""
import argparse
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "hs-next"
OLD = "6E36B21D754CF9C08508730A50ED6113E8050BA1341CA091597A5EB8CE40F2D2"
CONT = "src/Solver/CCoupledDeformationContinuation.cls"
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
TEST = "tests/modTestCoupledElasticState.bas"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def text(raw):
    return raw.decode("utf-8-sig").replace("\r\n", "\n")


def vba(code):
    assert max(map(len, code.splitlines())) < 1023
    return (code.rstrip().replace("\n", "\r\n") + "\r\n").encode()


def once(code, pattern, replacement):
    assert code.count(pattern) == 1, pattern
    return code.replace(pattern, replacement)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate", type=Path)
    opts = parser.parse_args()
    candidate = opts.candidate.resolve()
    parent_receipt = (PARENT / "Fixture.json").read_bytes()
    assert digest(parent_receipt) == OLD
    data = json.loads(parent_receipt)
    product = {}
    inputs = {}
    for name, expected in data["inputs"].items():
        original = (PARENT / name).read_bytes()
        assert digest(original) == expected, name
        if name in ("Verify.py", "Stage.py", "Run.ps1"):
            continue
        if name in (NEWTON, CONT):
            frozen = (candidate / name).read_bytes()
            product[name] = put(f"Candidate/{name}", frozen)
            source = text(frozen)
            if name == NEWTON:
                source = once(source, "Private mConsistentControl As Boolean",
                    "Private mHardNextLaneTest As String\nPrivate mConsistentControl As Boolean")
                source = once(source, "    If Not FirstYieldCrossing(field, ends, station) Then Exit Function\n",
                    "    If Not FirstYieldCrossing(field, ends, station) Then Exit Function\n"
                    "    If Len(mHardNextLaneTest) > 0 Then\n"
                    "        WriteHardRankRowTest \"CROSS;\" & mHardNextLaneTest & \";\" & CStr(station.Point) & \";\" & CStr(station.Side) & \";\" & _\n"
                    "            HardRankBitsTest(station.FromValue) & \";\" & HardRankBitsTest(station.ToValue)\n"
                    "    End If\n")
                probe = text((PARENT / "Newton.bas").read_bytes())
                probe = once(probe, "    mHardNextLaneTest = vbNullString\n", """    RunHardSameControlLaneTest history, originalProjection, offset, direction, target, seedLambda, _
        maxLambda, absoluteTolerance, relativeTolerance, iterations, "D"
    RunHardSameControlLaneTest history, originalProjection, offset, direction, target, seedLambda, _
        maxLambda, absoluteTolerance, relativeTolerance, 6, "E"
    Dim acceptedField() As Double, acceptedControl As Double, position As Long
    acceptedField = history.Item(history.Count)
    For position = 1 To mGaugeStart - 1
        acceptedControl = acceptedControl + originalProjection(position) * acceptedField(position)
    Next position
    RunHardSameControlLaneTest history, originalProjection, offset, direction, acceptedControl, seedLambda, _
        maxLambda, absoluteTolerance, relativeTolerance, iterations, "F", False
    RunHardSameControlLaneTest history, originalProjection, offset, direction, acceptedControl, seedLambda, _
        maxLambda, absoluteTolerance, relativeTolerance, iterations, "G"
    mHardNextLaneTest = vbNullString
""")
                source = source.rstrip()+"\n\n"+probe+"\n"+text((HERE/"Proof.bas").read_bytes())
            else:
                source = once(source, "    mDesignHistoryIndex = InitialDesignHistoryIndex(history.Count, previousLambda, currentLambda)",
                    """    If HardRankRequestedTest Then
        HardRankFinishedTest = ReplayHardNextTest(mSolver, mOffset, mDirection, mMaximumLambda, mAbsTol, mRelTol, mMaxIterations)
        StopSearch "Диагностическая остановка после повторения одной пробы HardShear."
        Exit Sub
    End If
    mDesignHistoryIndex = InitialDesignHistoryIndex(history.Count, previousLambda, currentLambda)""")
            original = vba(source)
        inputs[name] = put(name, original)
    installed = (HERE.parents[1] / data["workbook"]).read_bytes()
    assert digest(installed) == data["source_workbook_sha256"]
    put(data["workbook"], installed)
    put("docs/regression/Diagnostic.xlsm", installed)
    for folder in ("Temp", "Native"):
        (HERE / folder).mkdir(exist_ok=True)
    for name in ("Stage.py", "Verify.py", "Proof.bas", "Run.ps1"):
        inputs[name] = digest((HERE / name).read_bytes())
    manifest = {**data, "inputs": inputs, "candidate_source": product, "parent_fixture_sha256": OLD}
    print(put("Fixture.json", (json.dumps(manifest, indent=2) + "\n").encode()))


if __name__ == "__main__":
    main()
