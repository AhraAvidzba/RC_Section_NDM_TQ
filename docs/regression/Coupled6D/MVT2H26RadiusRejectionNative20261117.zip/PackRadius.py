"""Package complete H26 radius witness and independently replay it."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import Mechanism
import ReplayRadiusPortable as replay

HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[1]/"docs/regression/Coupled6D"
RESULT = HERE/"MVT2H26RadiusRejectionNative20261117.zip"


def main():
    prep = json.loads((HERE/"Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK] == prep["book_sha256"] == replay.WORKBOOK
    published = {}
    for filename, expected in replay.DEPENDENCIES.items():
        path = REGRESSION/filename
        assert replay.digest(path.read_bytes()) == expected
        with ZipFile(path) as z:
            for member in z.namelist():
                if not member.casefold().endswith(".xlsm"):
                    published.setdefault(replay.digest(z.read(member)),(filename,member))
    native = tuple(f"NativeResume/{p.name}" for p in (HERE/"NativeResume").iterdir() if p.is_file())
    report = json.loads((HERE/"VerificationRadius.json").read_bytes())
    (HERE/"Mechanism.json").write_bytes((json.dumps(Mechanism.analyze(HERE/"NativeResume/MVT2.csv",report),indent=2)+"\n").encode())
    attachments = ("Preparation.json","Run.ndjson","Compile.log","CompileClosure.json","docs/regression/CodeUpdate.json",
                   "VerificationRadius.json","Mechanism.py","Mechanism.json","PackRadius.py","ReplayRadiusPortable.py","PortableREADME.txt")
    items,manifest = {},{}
    for member in sorted(set(prep["inputs"]) | set(attachments) | set(native)):
        if member == replay.BOOK:
            continue
        raw = (HERE/member).read_bytes()
        digest = replay.digest(raw)
        if member in prep["inputs"]:
            assert digest == prep["inputs"][member]
        inherited = published.get(digest) if member in prep["inputs"] else None
        if inherited:
            name, source = inherited
            manifest[member] = {"archive":name,"member":source,"sha256":digest}
        else:
            manifest[member] = {"sha256":digest}
            items[member] = raw
    payload = {"workbook":{"path":replay.BOOK,"sha256":replay.WORKBOOK},"archives":replay.DEPENDENCIES,"inputs":manifest}
    items["PortableManifest.json"] = (json.dumps(payload,indent=2)+"\n").encode()
    assert all(not name.casefold().endswith(".xlsm") for name in items)
    with ZipFile(RESULT,"w",compresslevel=9) as out:
        for member,raw in sorted(items.items()):
            info = ZipInfo(member)
            info.compress_type = ZIP_DEFLATED
            out.writestr(info,raw)
    with TemporaryDirectory(dir=HERE/"Temp") as tmp, ZipFile(RESULT) as z:
        assert z.testzip() is None
        z.extractall(tmp)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayRadiusPortable.py","--archives",str(REGRESSION)),cwd=tmp,check=True)
    print(RESULT.name,RESULT.stat().st_size,replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
