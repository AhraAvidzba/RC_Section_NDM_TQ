"""Seal a fixed H26 radius-rejection probe without changing its numerical guard."""
import csv
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mv26b"
ARCHIVE = HERE.parent / "mvext" / "NativeContinue/MVT2.csv"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MACRO = "tests/modTestCoupledExperiment.bas"
SOLVER = "src/Solver/CCoupledNewtonSolver.cls"
PREP_SHA = "CA3794B9C647488B2A8EF7108EEC7018F3AAE1BDD9828ADE81A7C4B68F42F1B0"
OLDER_TRACE_SHA = "244065BBF02C27B45EBBBE7D0CD7BAAB6CBB2C0F9483607D9F337C07BD6BD5EF"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name, raw):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def once(value, old, new):
    assert value.count(old) == 1, old
    return value.replace(old, new)


def source(raw):
    return raw.decode("utf-8-sig").replace("\r\n","\n")


def vba(text):
    assert max(map(len,text.splitlines())) < 1023
    return text.replace("\n","\r\n").encode()


def archived_witness(raw):
    assert digest(raw) == OLDER_TRACE_SHA
    rows = csv.reader(raw.decode("cp1251").splitlines(),delimiter=";")
    evidence = {}
    active = False
    for tag,*rest in rows:
        if tag == "B_EXT_PROJECTION" and rest[0] == "Attempt6":
            evidence[tag] = rest
        if tag == "B_EXT_TRY":
            active = rest[0] == "Attempt6"
        if active and (tag.startswith("B_FB_") or tag in ("B_EXT_TRY","B_EXT_SOLVER","B_EXT_DECISION")):
            assert tag not in evidence
            evidence[tag] = rest
        if tag == "B_EXT_DECISION":
            active = False
    assert evidence["B_FB_OPT"] == ["1","1","84"] and evidence["B_FB_STOP"] == ["1","Radius"]
    assert evidence["B_EXT_TRY"][4] == "2.63894309345674E-07" and evidence["B_EXT_DECISION"] == ["Attempt6","Newton"]
    assert float(evidence["B_FB_RADIUS"][1]) > float(evidence["B_FB_RADIUS"][3])
    return (json.dumps(evidence,indent=2,ensure_ascii=False)+"\n").encode()


def overlay_solver(raw):
    text = source(raw)
    anchor = "Private mBoundedTraceTest As Integer ' Ненулевой канал только в изолированной пробе.\n"
    text = once(text,anchor,anchor+'''Private mRadiusWitnessTest As Boolean ' Снимок отсечённой поправки для отдельной проверки.
Private mStallFieldTest() As Double, mRejectedFieldTest() As Double
Private mStallLambdaTest As Double, mRejectedLambdaTest As Double, mRejectedRadiusTest As Double, mRejectedCapTest As Double
''')
    anchor = "    mBoundedTraceTest = traceNumber\n"
    text = once(text,anchor,anchor+"    If traceNumber > 0 Then mRadiusWitnessTest = False\n")
    anchor = "        If incremental > radiusCap Or radius > radiusCap Then GoTo RestoreFailure\n"
    text = once(text,anchor,'''        If incremental > radiusCap Or radius > radiusCap Then
            If attempt = 1 Then
                mStallFieldTest = field: mStallLambdaTest = lambda
                mRejectedFieldTest = trial: mRejectedLambdaTest = trialLambda
                mRejectedRadiusTest = radius: mRejectedCapTest = radiusCap
                mRadiusWitnessTest = True
            End If
            GoTo RestoreFailure ' Снимок не снимает действующее ограничение поправки.
        End If
''')
    extra = '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт отсечённое поле без смены принятого состояния и исходного статуса.
Friend Function CopyRadiusRejectionTest(ByRef stall() As Double, ByRef proposal() As Double, _
        ByRef stallLambda As Double, ByRef proposalLambda As Double, ByRef radius As Double, ByRef cap As Double) As Boolean
    If Not mRadiusWitnessTest Then Exit Function
    stall = mStallFieldTest: proposal = mRejectedFieldTest
    stallLambda = mStallLambdaTest: proposalLambda = mRejectedLambdaTest
    radius = mRejectedRadiusTest: cap = mRejectedCapTest
    CopyRadiusRejectionTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Даёт тензорную длину вручную проверяемой доли исходной поправки.
Friend Function RadiusDistanceTest(ByRef trial() As Double, ByRef center() As Double) As Double
    RadiusDistanceTest = RecoveryTensorRadiusTest(trial, center)
End Function
'''
    return vba(text.rstrip()+"\n"+extra)


def overlay_macro(raw):
    text = source(raw)
    text = once(text,"    For attempt = 1 To 4\n","    For attempt = 1 To 3\n")
    text = once(text,'''        If attempt = 3 Then nominal = Val(resumeWire(62))
        If attempt = 4 Then nominal = nominal / 2#
''','''        If attempt = 3 Then ' Размер последней неудавшейся пробы, до внешнего деления пополам.
            nominal = initialStep * 1.5 / 8#
            If ExperimentNumberTest(nominal) <> "2.63894309345674E-07" Then Err.Raise 5, , "Неверный размер архивного шага H26."
        End If
''')
    insertion = '''            If attempt = 3 Then
                If solved Then Err.Raise 5, , "Архивный метод неожиданно принял пробу до повторного контроля."
                RunWangRadiusWitnessTest output, solver, operators, materials, responses, baseField, baseFactor, _
                    projection, normalLoad, metric, loadMetric, nominal, committed
            End If
'''
    anchor = '''            CaptureWangArcHistoryTest output, "Discarded" & label, operators, materials, snapshot
            RequireWangArcHistoryTest committed, snapshot
'''
    text = once(text,anchor,anchor+insertion)
    return vba(text.rstrip()+"\n\n"+(HERE/"RadiusTest.txt").read_text(encoding="utf-8"))


def main():
    parent = (PARENT/"Preparation.json").read_bytes()
    assert digest(parent) == PREP_SHA
    metadata = json.loads(parent)
    inputs = {"ArchivedRadius.json":put("ArchivedRadius.json",archived_witness(ARCHIVE.read_bytes()))}
    for name,expected in metadata["inputs"].items():
        raw = (PARENT/name).read_bytes()
        assert digest(raw) == expected
        if name == "Verify-MVT2ShearControlled.py":
            inputs["ResumeBase.py"] = put("ResumeBase.py",raw)
            continue
        if name in ("Stage.py","README.txt"):
            continue
        if name == MACRO:
            raw = overlay_macro(raw)
        elif name == SOLVER:
            raw = overlay_solver(raw)
        inputs[name] = put(name,raw)
    for name in ("Stage.py","README.txt","RadiusTest.txt","Verify-MVT2ShearControlled.py"):
        inputs[name] = digest((HERE/name).read_bytes())
    assert put("docs/regression/Diagnostic.xlsm",(HERE/BOOK).read_bytes()) == metadata["book_sha256"]
    for directory in ("NativeResume","Temp"):
        (HERE/directory).mkdir(exist_ok=True)
    prep = {**metadata,"inputs": inputs,"base_H26_preparation_sha256":PREP_SHA}
    print(put("Preparation.json",(json.dumps(prep,indent=2)+"\n").encode()))


if __name__ == "__main__":
    main()
