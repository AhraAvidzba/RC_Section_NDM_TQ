A stress-only test of the optimizer correction rejected at the original H26 plane.

    python -B -X utf8 ReplayRadiusPortable.py --archives <repository>/docs/regression/Coupled6D

All source overlays, native closure receipts, original archive witnesses and assessment
inputs are checked. The manifest uses tracked dependencies and includes no workbook.
The valid original radius guard returned the same numerical rejection as its source run.
Separately evaluating precisely the stalled field and candidate showed that full, half, and
quarter proposed corrections each worsen equilibrium at unchanged original tolerance.
Mechanism.json independently rebuilds row 53 from the paired point stresses and records
every station branch transition, to distinguish point concentration from arbitrary radius tuning.
The reported yield crossing fractions are interpolation estimates used to direct a future test.
Every diagnostic field was discarded and the original H24 history was restored exactly.
