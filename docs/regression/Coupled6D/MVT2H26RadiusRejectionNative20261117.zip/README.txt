Private MVT2 B diagnostic: preserve the H26 plane and compare the original radius rejection
with a stress-only check of exactly the optimizer's rejected candidate.

    python -B -X utf8 tmp/mv26r/Stage.py
    python -B -X utf8 tmp/mv26r/Verify-MVT2ShearControlled.py --inputs-only

After allocating the isolated Office slot and passing the resource guard, launch once.

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mv26r/Run-MVT2ShearControlled.ps1

Repeat exact H25 and H26 natively using the sealed witnesses and short CRLF records.
Use archived attempt 6 normal, target and size 2.63894309345674e-7. The mechanism and
its radius rejection are preserved. A private readback captures the Newton stall field and
the full candidate before failure. Evaluate the same stall/proposal and halves at 1/2 and
1/4 with original stress law and unchanged H26. The closure uses all 56 weak rows, six
signed resultant errors, four gauges, the original plane and forward physical arc radius
3ds, each checked independently from the station archive. The optimizer's local tensor
radius is reported separately. Even a qualifying diagnostic field is never committed.
Exact H24 restoration, owner and compiler closure are verified. Watchdog 105 s.
