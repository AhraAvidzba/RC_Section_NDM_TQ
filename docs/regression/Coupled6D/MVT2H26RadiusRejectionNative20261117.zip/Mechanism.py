"""Reconstruct the H26 rejection experiment's changed point actions."""
from collections import defaultdict
from math import fsum

import VerifyBase as v


def analyze(raw_path, proof):
    raw = v.read_native(raw_path)
    st = defaultdict(dict)
    for label,point,side,*record in raw["B_TANGENT_STATION"]:
        st[label][int(point),int(side)] = tuple(map(float,record))
    measures = {row["label"]:row for row in proof["measurements"]}
    reference = st["Stall"]
    assert len(reference) == 135
    data = v.vec(raw,"B_RADIUS_FIELD")
    trial_fields = {label:tuple(map(float,field)) for label,_,_,*field in raw["B_TANGENT_FIELD"] if label in measures}
    baseline = measures["Stall"]["weak56_MPa"][52]
    report = []
    for label in ("Full","Half","Quarter"):
        measured = measures[label]
        if label not in st or "weak56_MPa" not in measured:
            report.append({"label":label,"status":measured["status"]})
            continue
        stations = st[label]
        assert len(stations) == 135
        qdiff = v.diff(trial_fields[label],data["Stall"])
        local_radii = [((point,side), v.frobenius(v.strain_at(qdiff,v.operators(*values[:2]),side)))
                       for (point,side),values in stations.items()]
        site,max_radius = max(local_radii,key=lambda item:item[1])
        changed = [key for key,b in stations.items() if key[0]<=25 and
                   (b[3:6]!=reference[key][3:6] or b[6]*reference[key][6]<0.)]
        point_parts = []
        for point in range(1,46):
            area = stations[point,0][2]
            for side in (-1,1):
                stress_delta = stations[point,side][15]-reference[point,side][15]
                point_parts.append(((point,side),side*stress_delta*area/(0.002*v.AREA)))
        actual = measured["weak56_MPa"][52]
        v.near(fsum(x for _,x in point_parts),actual-baseline,4e-10)
        v.near(max_radius,measured["local_correction_tensor_radius"],4e-15)
        point_net = [(point,fsum(value for (ip,_),value in point_parts if ip == point)) for point in range(1,46)]
        event_estimates = []
        for key in changed:
            old_yield, trial_yield = reference[key][6],stations[key][6]
            if old_yield * trial_yield < 0.:
                estimate = -measured["correction_fraction"]*old_yield/(trial_yield-old_yield)
                event_estimates.append({"station":key,"linear_estimate_of_fraction_at_zero_yield":estimate,
                                        "stall_yield_value":old_yield,"trial_yield_value":trial_yield})
        row = {"label":label,"status":measured["status"],"recorded_norm_ratio_to_stall":measured["full_residual_over_tau"]*
               measured["original_tolerance_MPa"]/(measures["Stall"]["full_residual_over_tau"]*measures["Stall"]["original_tolerance_MPa"]),
               "last_norm_within_old_second_correction_trigger":bool(measured["full_residual_over_tau"]*
               measured["original_tolerance_MPa"]<0.25*measures["Stall"]["full_residual_over_tau"]*measures["Stall"]["original_tolerance_MPa"]),
               "full_residual_over_tau":measured["full_residual_over_tau"],"force_error_over_tau":measured["force_error_over_tau"],
               "local_radius_over_original_bound":measured["local_radius_over_original_bound"],
               "physical_arc_length_over_nominal":measured["physical_arc_length_over_nominal"],
               "Qy_delta_from_H26_N":1000*measured["Qy_delta_from_H26_kN"],"maximum_radius_site":site,
               "concrete_branch_or_surface_changes":changed,"row53_action_MPa": actual-baseline,
               "row53_action_summed_MPa":fsum(x for _,x in point_parts),
               "largest_row53_site_actions_MPa":sorted(point_parts,key=lambda item:-abs(item[1]))[:8],
               "largest_row53_net_actions_by_point_MPa":sorted(point_net,key=lambda item:-abs(item[1]))[:8],
               "observed_yield_sign_changes":event_estimates}
        report.append(row)
    return {"same_original_failure":proof["same_original_failure"],"stall_row53_MPa":baseline,
            "original_radius_bound_as_fraction_of_full":1/proof["original_optimizer_radius_ratio"],"trials":report}
