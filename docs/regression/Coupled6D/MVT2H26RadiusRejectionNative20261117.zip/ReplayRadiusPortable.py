"""Replay sealed VBA generation, original-law residuals and station actions in private temp."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import ModuleType
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
REPORT = "5EEEBC4AB45369232CCB0430C9A94AD42221DB3432077BEDF4C7AB051BF05326"
H26 = "MVT2ExactH26SmallerArcNative20261116.zip"
ADAPTIVE = "MVT2AdaptiveBoundedContinuationNative20261116.zip"
DEPENDENCIES = {
    H26: "B775E3D70EED7CC8239F905AC4E3779AA65CE8994BA1F045BED899B6235B4F07",
    ADAPTIVE: "A5F4EABFE14F46544D6BA36934B050AED5C5F3655DC91D32D6E8C6408562E699",
    "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
    "MVT2StockBranchArcNative20261116.zip": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def local(root, name):
    return root / (root / name).resolve().relative_to(root.resolve())


def materialize(work, manifest, archives):
    assert manifest["archives"] == DEPENDENCIES
    assert manifest["workbook"] == {"path":BOOK,"sha256":WORKBOOK}
    for name, expected in DEPENDENCIES.items():
        assert digest((archives/name).read_bytes()) == expected
    for name, record in manifest["inputs"].items():
        archive = record.get("archive")
        member = record.get("member",name)
        if archive:
            with ZipFile(archives/archive) as upstream:
                raw = upstream.read(member)
        else:
            raw = local(HERE,member).read_bytes()
        assert digest(raw) == record["sha256"], name
        target = local(work,name)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)


def generate(work, archives):
    stage = work/"Stage.py"
    scope = {"__name__":"replay_stage","__file__":str(stage)}
    exec(compile(stage.read_text(encoding="utf-8"),str(stage),"exec"),scope)
    with ZipFile(archives/ADAPTIVE) as adaptive, ZipFile(archives/H26) as h26:
        assert digest(h26.read("Preparation.json")) == scope["PREP_SHA"]
        assert scope["archived_witness"](adaptive.read("NativeContinue/MVT2.csv")) == (work/"ArchivedRadius.json").read_bytes()
        h26_inputs = json.loads(h26.read("PortableManifest.json"))["inputs"]
        for path, overlay in ((scope["SOLVER"],"overlay_solver"),(scope["MACRO"],"overlay_macro")):
            rec = h26_inputs[path]
            if "archive" in rec:
                with ZipFile(archives/rec["archive"]) as older:
                    source = older.read(rec["member"])
            else:
                source = h26.read(path)
            assert digest(source) == rec["sha256"]
            assert scope[overlay](source) == (work/path).read_bytes()


def check(work):
    sys.path.insert(0,str(work))
    path = work/"ResumeBase.py"
    text = path.read_text(encoding="utf-8")
    line = '    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items())'
    assert not (work/BOOK).exists() and text.count(line) == 1
    replacement = (f'    assert prep["inputs"]["{BOOK}"] == prep["book_sha256"] == "{WORKBOOK}"\n'
                   f'    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items() if path != "{BOOK}")')
    base = ModuleType("ResumeBase")
    base.__file__ = str(path)
    sys.modules["ResumeBase"] = base
    exec(compile(text.replace(line,replacement),str(path),"exec"),base.__dict__)
    verifier = work/"Verify-MVT2ShearControlled.py"
    scope = {"__file__":str(verifier),"__name__":"archived_native"}
    exec(compile(verifier.read_text(encoding="utf-8"),str(verifier),"exec"),scope)
    report = scope["verify"](*scope["prepare"]())
    raw = (work/"VerificationRadius.json").read_bytes()
    assert digest(raw) == REPORT and (json.dumps(report,indent=2)+"\n").encode() == raw
    import Mechanism
    analyzed = Mechanism.analyze(work/"NativeResume/MVT2.csv",report)
    proof = (work/"Mechanism.json").read_bytes()
    assert proof == (json.dumps(analyzed,indent=2)+"\n").encode()
    return report,digest(proof)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives",type=Path,required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE/"PortableManifest.json").read_bytes())
    with TemporaryDirectory() as tmp:
        work = Path(tmp)
        materialize(work,manifest,args.archives)
        generate(work,args.archives)
        report, mechanism = check(work)
    print("RADIUS WITNESS",REPORT,"MECHANISM",mechanism)
    print("ORIGINAL RESIDUAL RATIOS",[round(item["full_residual_over_tau"],5) for item in report["measurements"]])


if __name__ == "__main__":
    main()
