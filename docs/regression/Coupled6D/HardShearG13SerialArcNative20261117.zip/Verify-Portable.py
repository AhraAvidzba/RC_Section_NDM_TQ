"""Проверяет нативное доказательство без установки Excel, книги и истории Git."""

import json
from pathlib import Path
from subprocess import PIPE, run
import sys

import PriorVerify as prior


HERE = Path(__file__).resolve().parent


def main():
    sums = prior.read(HERE/'SHA256SUMS.json')
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}
    assert actual == set(sums)|{'SHA256SUMS.json'}
    for name,expected in sums.items():
        assert prior.file_hash(HERE/name) == expected and not name.lower().endswith('.xlsm'), name
    plan = prior.read(HERE/'Fixture.json')
    for name,expected in plan['production'].items():
        assert prior.file_hash(HERE/'Production'/name) == expected
    replay = run([sys.executable,'-B','-X','utf8','Verify.py','--order','10'],cwd=HERE,stdout=PIPE,check=True)
    print(replay.stdout.decode('utf-8').strip())
    native = prior.read(HERE/'Native/Order10/Verification.json')
    assert not native['physical_limit_certified']
    print(json.dumps(native,indent=2,ensure_ascii=False))
    print(f'HARDSHEAR_G13_SERIAL_ARC_PORTABLE: VERIFIED_EVIDENCE; {native["status"]}; physical_limit_certified=False')


if __name__ == '__main__':
    main()
