from argparse import ArgumentParser
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json

H=Path(__file__).resolve().parent
D=Path('D:/CodexScratch/RC_Section_NDM_TQ/KaniCommitNear48')
ART=Path('docs/regression/Coupled6D')
BOOK=Path('workbook/output/RC_Section_NDM.xlsm'); PRIVATE=Path('docs/regression/Diagnostic.xlsm')
SOLVER=Path('src/Solver/CCoupledNewtonSolver.cls'); ELASTIC=Path('src/Solver/CCoupledElasticState.cls'); CONCRETE=Path('src/Materials/CCoupledConcreteResponse.cls')
MAIN=Path('tests/modTestKaniStage38.bas')
EXPECTED={BOOK:'A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A',
          SOLVER:'9E33A100858D4181123244A0A54F98DF23258B9ABD87CF0E6293C122E371176F',
          ELASTIC:'A6BF256F42610AE7A353AD4AE1CCC9275DC247B398C3FA429CACD83840C97F94',
          CONCRETE:'92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C'}
ARCHIVES={'KaniCommitNear48Portable.zip':'EA0A80006AF81D99799B53FDCB75B18CDDE7B7DF730AB16039902F12C6431488',
          'KaniH45Plus18Portable.zip':'D34B8511FA133F1D4F146199F66C2A406DE9E790AB0F19E9B5D7B2AE099B975F',
          'KaniPracticalProbe45Portable.zip':'4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113'}


def sha(v):
    return sha256(v.read_bytes() if isinstance(v,Path) else v).hexdigest().upper()

def edit(s,b,a):
    assert s.count(b)==1,b
    return s.replace(b,a,1)

def frozen_archive(repo,file):
    zip_path=repo/ART/file; assert sha(zip_path)==ARCHIVES[file],file
    return ZipFile(zip_path)

def live(repo):
    assert H.is_relative_to((repo/'tmp').resolve()),H
    assert all(sha(repo/path)==want for path,want in EXPECTED.items())
    assert all(sha(repo/ART/name)==want for name,want in ARCHIVES.items())

def prepare(repo):
    live(repo)
    if (H/'Preparation.json').exists(): return check(repo)
    with frozen_archive(repo,'KaniCommitNear48Portable.zip') as z, frozen_archive(repo,'KaniH45Plus18Portable.zip') as probes:
        prior=json.loads(z.read('Preparation.json')); old=z.read('KaniGaugeInput.csv').decode('ascii').splitlines()
        h44=next(l.replace(';Accepted19of512;',';History44;') for l in old if l.startswith('KANI_B_FIELD;Accepted19of512;'))
        h45=z.read('History45Verified.csv').decode('ascii').strip()
        assert sha(z.read('History45Verified.csv'))=='97FF3089BA40A3B7349B1A0588B21FAFB3689E33DB7BA95892163C80B83CA9EE'
        hx=[l for l in old if l.startswith('KANI_B_FIELD;History')]+[h44,h45]
        x=probes.read('H45Plus18DirectionalFields.csv'); plan=probes.read('H45Plus18DirectionalPlan.json')
        assert sha(x)=='079D30EA01977DCC605A55E0066E20DA7B6CD05A6DCBBDE0AE7E753B3E09441E'
        assert sha(plan)=='07E441948E40B055C410B1E4B4A5E2506156BCB0E96F7388862CCC2F5D5B4A3D'
        trials=x.decode('ascii').splitlines()
        assert len(hx)==8 and len(trials)==3 and all(len(x.split(';'))==92 for x in hx+trials)
        assert [l.split(';')[1] for l in trials]==['Plus18Center','Plus18TargetMinus','Plus18TargetPlus']
        assert all(trials[0].split(';')[i]==l.split(';')[i] for i in (3,91) for l in trials)
    reusable={}
    for k,value in prior['frozen'].items():
        if k.startswith('tools/') or k in ('KaniV4Input.csv','KaniChartInput.csv',MAIN.as_posix(),SOLVER.as_posix(),ELASTIC.as_posix()):
            p=D/k
            assert sha(p)==value,k
            reusable[Path(k)]=p.read_bytes()
    src=reusable[MAIN].decode('utf8').replace('\r\n','\n'); a=src.index('    Dim rootPath As String'); b=src.index('    Close #tangents:',a)
    src=src[:a]+(H/'Plus18Main.bas.txt').read_text(encoding='utf8').rstrip()+'\n'+src[b:]
    src=edit(src,'If entries.Count <> 3 Or history.Count <> 43','If entries.Count <> 3 Or history.Count <> 45')
    reusable.update({MAIN:src.encode('utf8'),Path('KaniGaugeInput.csv'):('\r\n'.join(hx+trials)+'\r\n').encode('ascii'),
        Path('Plus18Fields.csv'):x,Path('Plus18Plan.json'):plan,BOOK:(repo/BOOK).read_bytes(),PRIVATE:(repo/BOOK).read_bytes()})
    for p,data in reusable.items():
        destination=H/p; destination.parent.mkdir(parents=True,exist_ok=True); destination.write_bytes(data)
    (H/'Native').mkdir(exist_ok=True); (H/'Temp').mkdir(exist_ok=True)
    files=(set(reusable)-{PRIVATE})|{Path(k) for k in ('Plus18Main.bas.txt','Run-Plus18.ps1','Prepare-Plus18.py','Verify-Plus18.py')}
    frozen={'bookSHA256':EXPECTED[BOOK],'productionSHA256':{k.as_posix():v for k,v in EXPECTED.items()},
      'archiveSHA256':ARCHIVES,'privateWorkbookPath':PRIVATE.as_posix(),'frozen':{p.as_posix():sha(H/p) for p in sorted(files)}}
    (H/'Preparation.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf8')
    return check(repo)

def check(repo):
    live(repo)
    x=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert x['bookSHA256']==EXPECTED[BOOK]==sha(H/BOOK) and all(sha(H/k)==v for k,v in x['frozen'].items())
    return x

if __name__=='__main__':
    p=ArgumentParser(); p.add_argument('--repo-root',type=Path,required=True); p.add_argument('--check',action='store_true'); a=p.parse_args(); r=a.repo_root.resolve()
    print((check(r) if a.check else prepare(r))['bookSHA256'],sha(H/'Preparation.json'))
