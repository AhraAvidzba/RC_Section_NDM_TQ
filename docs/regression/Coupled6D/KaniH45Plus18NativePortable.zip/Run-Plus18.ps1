﻿# Выполняет только три замороженные пробы Kani в частной копии книги.
param([string]$RepoRoot=(Get-Location).Path)
$ErrorActionPreference='Stop'
$repo=(Resolve-Path -LiteralPath $RepoRoot).Path
& python -B -X utf8 (Join-Path $PSScriptRoot 'Prepare-Plus18.py') --repo-root $repo --check
if ($LASTEXITCODE) { throw 'Хеши рабочей книги и входов не подтверждены.' }
$oldTemp=$env:TEMP
$oldTmp=$env:TMP
Push-Location -LiteralPath $PSScriptRoot
try {
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Путь к приватной книге слишком длинный для Excel.'
    }
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    $draft='docs/regression/Diagnostic.xlsm'
    $report='Native/KaniV4.txt'
    $tool='tools/build_workbook/Update-IsolatedOptimizerCode.ps1'
    $watch='tools/build_workbook/Run-Audit03Watchdog.ps1'
    $legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
    if ((Get-FileHash -LiteralPath $tool).Hash -cne 'D4CA349FF9859F76DD0FFF867C984C02EB5F8F715AADC2223635507502B365B9' -or
        (Get-FileHash -LiteralPath $watch).Hash -cne '526804E8B3923E76F5DB7CDBA33C639F6F4280C79086033314A81C453DDF5F00') {throw 'Изменился защищённый запуск.'}
    if ((Get-FileHash -LiteralPath $draft).Hash -cne $prep.bookSHA256 -or (Test-Path -LiteralPath $report) -or
        (Test-Path -LiteralPath 'Native/Compile.log')) {throw 'Для повторного прогона требуется новая частная копия.'}
    $protected=@{25900=[long]639301894503450644}
    function Assert-PrivateOfficeReserve([string]$phase) {
        $apps=@(Get-Process Excel -ErrorAction SilentlyContinue)
        $states=@(foreach ($app in $apps) {
            $ticks=$app.StartTime.ToUniversalTime().Ticks
            $confirmed=$protected.ContainsKey($app.Id) -and $protected[$app.Id] -eq $ticks
            if (!$confirmed) {
                $owner=Get-CimInstance Win32_Process -Filter ('ProcessId='+$app.Id)
                if ($owner -and $app.MainWindowHandle -and [Math]::Abs(($owner.CreationDate-$app.StartTime).TotalMilliseconds) -lt 100) {
                    $launcher=Get-Process -Id $owner.ParentProcessId -ErrorAction SilentlyContinue
                    if ($launcher -and $launcher.ProcessName -ieq 'explorer' -and $owner.SessionId -eq $app.SessionId -and
                        $launcher.SessionId -eq $app.SessionId -and $launcher.StartTime -lt $app.StartTime -and
                        $owner.CommandLine -notmatch '[/\-]embedding(?:\s|$)') {
                        $protected[$app.Id]=$ticks
                        $confirmed=$true
                    }
                }
            }
            [ordered]@{PID=$app.Id;StartTicksUTC=[string]$ticks;ProtectedUser=[bool]$confirmed}
        })
        $m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
        $log=[ordered]@{phase=$phase;UTC=[DateTimeOffset]::UtcNow.ToString('o');RAMMiB=$m.AvailableMBytes;
            FreeCommitGiB=($m.CommitLimit-$m.CommittedBytes)/1GB;FreeCMiB=(Get-PSDrive -Name C).Free/1MB;Excel=$states}
        $log|ConvertTo-Json -Depth 5 -Compress|Add-Content -LiteralPath 'Native/Preflight.ndjson' -Encoding utf8
        if (@($states | Where-Object {!$_.ProtectedUser}).Count -or $log.RAMMiB -lt 6500 -or $log.FreeCommitGiB -lt 8 -or $log.FreeCMiB -lt 80) {
            throw "Нет безопасного окна для $phase."
        }
    }
    Assert-PrivateOfficeReserve 'PreCompile'
    & (Join-Path $PSScriptRoot $tool) -WorkbookPath $draft -ModuleNames @('modTestKaniStage38','CCoupledNewtonSolver','CCoupledElasticState') |
        Tee-Object -FilePath 'Native/Compile.log'
    $lines=@(Get-Content -LiteralPath 'Native/Compile.log' | Where-Object {$_ -match '^OWNED_EXCEL: id=\d+; utcStartTicks=\d+$'})
    if ($lines.Count -ne 1 -or $lines[0] -notmatch '^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$') {throw 'Не подтверждён владелец компиляции.'}
    $ownerId=[int]$Matches[1]
    $ownerTime=[long]$Matches[2]
    if ($protected.ContainsKey($ownerId)) {throw 'Компилятор использовал защищённый Excel.'}
    $seen=$null
    try { $seen=Get-Process -Id $ownerId -ErrorAction Stop } catch {
        if ($_.FullyQualifiedErrorId -notmatch '^NoProcessFoundForGivenId(,|$)') {throw}
    }
    if ($null -ne $seen) {throw 'Не удалось подтвердить выход Excel компиляции.'}
    [ordered]@{State='Absent';PID=$ownerId;StartTicksUTC=[string]$ownerTime} | ConvertTo-Json |
        Set-Content -LiteralPath 'Native/CompileClosure.json' -Encoding utf8
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $compiled.ProductionSHA256 -cne $prep.bookSHA256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or
        (($compiled.Modules | Sort-Object) -join ',') -cne 'CCoupledElasticState,CCoupledNewtonSolver,modTestKaniStage38') {
        throw 'Частная сборка не прошла проверку.'
    }
    Assert-PrivateOfficeReserve 'PreNative'
    $commands=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$watch,'-SourceWorkbook',$draft,'-ReportPath',$report,
              '-Macro','modTestKaniStage38.RunTestKaniStage38','-MacroArgument1',(Join-Path $PSScriptRoot 'KaniV4Input.csv'),
              '-TimeoutSeconds',110,'-FailFast')
    & $legacy @commands
    $rc=$LASTEXITCODE
    $fixture=@(Get-Content -LiteralPath $report | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixture.Count -ne 1) {throw 'В протоколе нет однозначного пути к частной книге.'}
    $folder=[IO.Path]::GetFullPath((Split-Path -Parent $fixture[0].Substring(9)))
    if (!$folder.StartsWith($env:TEMP+'\RC_NDM_ModeSuite_',[StringComparison]::OrdinalIgnoreCase)){throw 'Протокол вышел за пределы частной копии.'}
    foreach ($f in ('KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv')) {
        $p=Join-Path $folder $f
        if (Test-Path -LiteralPath $p) {Copy-Item -LiteralPath $p -Destination (Join-Path 'Native' $f)}
    }
    if ($rc) {throw "Нативный запуск прерван с кодом $rc."}
    & python -B -X utf8 (Join-Path $PSScriptRoot 'Verify-Plus18.py') --repo-root $repo
    if ($LASTEXITCODE) {throw 'Независимая проверка §327 завершилась ошибкой.'}
}
finally {
    $env:TEMP=$oldTemp
    $env:TMP=$oldTmp
    Pop-Location
}
