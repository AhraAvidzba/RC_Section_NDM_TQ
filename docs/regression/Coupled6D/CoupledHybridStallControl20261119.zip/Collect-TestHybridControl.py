"""ДЛЯ ТЕСТОВ. Сохраняет нативные пробы и независимое решение одной удержанной задачи равновесия."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestCollect(repo, root):
    """Копирует исходные байты; успешный отдельный узел явно отделяет от незавершённого поиска предела."""
    here = Path(__file__).resolve().parent
    shared = run_path(str(here / 'Collect-TestFieldRecovery.py'))
    collect = shared['TestCollect']
    collect.__globals__['TestCases'] = {'Diagnostic': 'HardStallTangent20261119',
        'Fine': 'HardDeepFine20261119', 'Final': 'HardDeepStock20261119', 'Hybrid': 'HardHybridStall0220261119'}
    collect(repo, root)
    for folder in (root / 'Cases').iterdir():
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            destination = folder / relative
            if not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(destination.read_bytes()).hexdigest().upper()
        assert len(sources) == 30
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    names = ('Collect-TestHybridControl.py', 'Check-TestHybridControl.py', 'Analyze-TestHardStallTangent.py',
        'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py', 'Canonical-TestCoreVBA.py',
        'Stage-TestHardStallTangent.py', 'TestNativeHardStallTangent.bas.txt', 'Stage-TestHardDeepDamping.py',
        'Stage-TestStoredStall.py', 'TestNativeStoredStall.bas.txt', 'TestHybridOptimizer.py',
        'Stage-TestHardFineTangent.py', 'Stage-TestHardPrepared.py', 'TestNativeHardPrepared.bas.txt',
        'Save-TestHybridReferences.py', 'Fetch-TestMinpackSources.py', 'Complete-TestMinpackSources.py')
    for name in names:
        target = root / name
        if target.exists():
            assert target.read_bytes() == (here / name).read_bytes()
        else:
            target.write_bytes((here / name).read_bytes())
    failed = Path('D:/CodexScratch/RC_Section_NDM_TQ/HardHybridStall20261119')
    for name in ('Compile.log', 'CompileFailureClosure.json', 'Preparation.json', 'tests/modTestCoupledElasticState.bas'):
        shared['TestCopy'](failed / name, root / 'CompileFailure' / name)
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': 'af67a34',
        'installed_workbook_changed': False, 'physical_capacity_certified': False,
        'external_optimizer_only_for_tests': True, 'full_acceptance_completed': False}, indent=2) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('HYBRID CONTROL EVIDENCE COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
