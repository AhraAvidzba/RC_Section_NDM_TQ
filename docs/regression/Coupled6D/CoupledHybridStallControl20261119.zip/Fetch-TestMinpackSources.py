"""ДЛЯ ТЕСТОВ. Сохраняет первичные исходники гибридного метода и документацию для проверяемого переноса в VBA."""

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
from urllib.request import Request, urlopen


def TestFetch(url):
    """Читает открытый первичный источник без передачи данных проекта."""
    with urlopen(Request(url, headers={'User-Agent': 'NDM numerical verification source archive'}), timeout=90) as response:
        return response.read()


def TestMain():
    """Закрепляет конкретную ревизию; лицензии сохраняются вместе с кодом, без изменения оригиналов."""
    folder = Path('literature/Coupled6D/NumericalControl/Minpack')
    folder.mkdir(parents=True, exist_ok=True)
    commit_raw = TestFetch('https://api.github.com/repos/devernay/cminpack/commits/master')
    commit = json.loads(commit_raw)['sha']
    tree_raw = TestFetch('https://api.github.com/repos/devernay/cminpack/git/trees/' + commit + '?recursive=1')
    tree = json.loads(tree_raw)['tree']
    wanted = {'hybrj.c', 'dogleg.c', 'enorm.c', 'qrfac.c', 'qform.c', 'r1updt.c', 'r1mpyq.c', 'dpmpar.c',
        'CopyrightMINPACK.txt', 'CopyrightCMinpack.txt', 'LICENSE', 'LICENSE.txt'}
    records = []
    for item in tree:
        relative = Path(item['path'])
        if relative.name not in wanted or item['type'] != 'blob':
            continue
        if relative.suffix == '.c' and relative.parts[0] != 'src':
            continue
        url = 'https://raw.githubusercontent.com/devernay/cminpack/' + commit + '/' + item['path']
        raw = TestFetch(url)
        destination = folder / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists(): raise FileExistsError(destination)
        destination.write_bytes(raw)
        records.append({'file': relative.as_posix(), 'url': url, 'bytes': len(raw), 'sha256': sha256(raw).hexdigest().upper()})
    assert {Path(row['file']).name for row in records} >= {'hybrj.c', 'dogleg.c', 'qrfac.c', 'qform.c', 'r1updt.c', 'r1mpyq.c', 'enorm.c', 'CopyrightMINPACK.txt'}
    (folder / 'Commit.json').write_bytes(commit_raw)
    (folder / 'SourceTree.json').write_bytes(tree_raw)
    report_url = 'https://www.mcs.anl.gov/~more/ANL8074b.pdf'
    report = TestFetch(report_url)
    assert report.startswith(b'%PDF')
    report_name = 'More-Garbow-Hillstrom-1980-MINPACK-documentation.pdf'
    (folder / report_name).write_bytes(report)
    records.append({'file': report_name, 'url': report_url, 'bytes': len(report), 'sha256': sha256(report).hexdigest().upper()})
    (folder / 'Sources.json').write_text(json.dumps({'commit': commit, 'repository': 'https://github.com/devernay/cminpack',
        'retrieved_utc': datetime.now(timezone.utc).isoformat(), 'sources': records}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PRIMARY MINPACK SOURCES SAVED', commit, len(records), flush=True)


if __name__ == '__main__':
    TestMain()
