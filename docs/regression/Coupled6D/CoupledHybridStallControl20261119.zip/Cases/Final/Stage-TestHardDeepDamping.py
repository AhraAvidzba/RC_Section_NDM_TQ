"""ДЛЯ ТЕСТОВ. Проверяет дополнительные доли демпфирования в том же пространственном CDP-шаге."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, scope):
    """Использует существующий нижний предел 1/4096; уравнения, материал и допуск принятия не меняет."""
    here = Path(__file__).resolve().parent
    if scope == 'fine':
        run_path(str(here / 'Stage-TestHardFineTangent.py'))['TestStage'](repo, root, .001 / 128)
    else:
        run_path(str(here / 'Stage-TestClosedBranchPeak.py'))['TestStage'](repo, root, False)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    raw = (root / name).read_bytes()
    baseline = root / 'BaselineDeepDamping' / name
    baseline.parent.mkdir(parents=True, exist_ok=True)
    baseline.write_bytes(raw)
    code = raw.decode('utf-8-sig').replace('\r\n', '\n')
    old = '        If mSteelBranchBuilds > 0 Then minimumFraction = STEEL_MIN_FRACTION'
    assert code.count(old) == 1
    code = code.replace(old, '''        If mSteelBranchBuilds > 0 Or (mControlActive And mUseSpatialHistory And Not HasPrincipalBoundaries) Then _
            minimumFraction = STEEL_MIN_FRACTION''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    for name in ('src/Solver/CCoupledNewtonSolver.cls', 'BaselineDeepDamping/src/Solver/CCoupledNewtonSolver.cls', script.name):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'deep_CDP_control_damping': True, 'minimum_fraction': 1 / 4096,
        'maximum_iterations_unchanged': True, 'global_probe_limit_unchanged': True,
        'equilibrium_tolerances_unchanged': True, 'working_source_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRIVATE DEEP CDP CONTROL DAMPING READY', scope, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('fine', 'stock'), required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.scope)
