"""ДЛЯ ТЕСТОВ. Сохраняет первичную техническую документацию независимых численных алгоритмов."""

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
from urllib.request import Request, urlopen


def TestMain():
    """Не добавляет физических формул: источники относятся только к проверочному численному инструменту."""
    folder = Path('literature/Coupled6D/NumericalControl')
    folder.mkdir(parents=True, exist_ok=True)
    records = []
    for name, title, url, purpose in (
        ('SciPy-root-hybr.html', 'SciPy root(method=hybr)', 'https://docs.scipy.org/doc/scipy/reference/optimize.root-hybr.html', 'Independent MINPACK hybrid numerical control'),
        ('SciPy-least-squares.html', 'SciPy least_squares', 'https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.least_squares.html', 'Independent trust-region numerical control'),
        ('OpenSees-NewtonLineSearch.html', 'OpenSees Newton Line Search', 'https://opensees.github.io/OpenSeesDocumentation/user/manual/analysis/algorithm/NewtonLineSearch.html', 'Background numerical reference; no copied runtime code')):
        destination = folder / name
        if destination.exists():
            raise FileExistsError(destination)
        request = Request(url, headers={'User-Agent': 'NDM numerical verification source archive'})
        with urlopen(request, timeout=40) as response:
            data = response.read()
            resolved = response.url
        destination.write_bytes(data)
        records.append({'file': name, 'title': title, 'url': url, 'resolved_url': resolved,
            'purpose': purpose, 'bytes': len(data), 'sha256': sha256(data).hexdigest().upper()})
    (folder / 'Sources.json').write_text(json.dumps({'retrieved_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Software documentation for independent tests; no physical material parameters',
        'installed_scipy_version': '1.18.1', 'sources': records}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PRIMARY NUMERICAL SOFTWARE REFERENCES SAVED', len(records))


if __name__ == '__main__':
    TestMain()
