"""ДЛЯ ТЕСТОВ. Закрепляет уже полученную ревизию первичных исходников без подмены оригиналов."""

from datetime import datetime, timezone
from hashlib import sha1, sha256
import json
from pathlib import Path
from urllib.request import Request, urlopen


def TestMain():
    """Проверяет Git blob каждого файла; сохраняет лицензию, авторское описание и документацию HYBRJ."""
    folder = Path('literature/Coupled6D/NumericalControl/Minpack')
    commit = json.loads((folder / 'Commit.json').read_bytes())['sha']
    tree = json.loads((folder / 'SourceTree.json').read_bytes())['tree']
    items = {item['path']: item for item in tree if item['type'] == 'blob'}
    for name in ('README.md', 'readme.txt', 'doc/hybrj_.html'):
        if name not in items:
            continue
        target = folder / name
        if not target.exists():
            url = 'https://raw.githubusercontent.com/devernay/cminpack/' + commit + '/' + name
            with urlopen(Request(url, headers={'User-Agent': 'NDM numerical source archive'}), timeout=45) as response:
                raw = response.read()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
    records = []
    for name, item in sorted(items.items()):
        target = folder / name
        if not target.is_file():
            continue
        raw = target.read_bytes()
        assert sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == item['sha'], name
        records.append({'file': name, 'bytes': len(raw), 'sha256': sha256(raw).hexdigest().upper(),
            'git_blob': item['sha'], 'url': 'https://raw.githubusercontent.com/devernay/cminpack/' + commit + '/' + name})
    assert len(records) >= 9
    record = {'commit': commit, 'repository': 'https://github.com/devernay/cminpack',
        'retrieved_utc': datetime.now(timezone.utc).isoformat(), 'sources': records,
        'full_original_report_downloaded': False,
        'report_download_failure': {'url': 'https://www.mcs.anl.gov/~more/ANL8074b.pdf', 'http_status': 403},
        'runtime_code_ported': False, 'license_file': 'CopyrightMINPACK.txt'}
    (folder / 'Sources.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PINNED MINPACK SOURCES VERIFIED', commit, len(records), flush=True)


if __name__ == '__main__':
    TestMain()
