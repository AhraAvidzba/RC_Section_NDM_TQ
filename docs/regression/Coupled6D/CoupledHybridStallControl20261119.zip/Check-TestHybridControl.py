"""ДЛЯ ТЕСТОВ. Проверяет действительные книги, удержанную материальную историю и отдельное гибридное равновесие."""

from argparse import ArgumentParser
from collections import Counter
from contextlib import redirect_stdout
from hashlib import sha256
from io import BytesIO, StringIO
import json
from pathlib import Path
import re
from runpy import run_path
import numpy as np


def TestRead(path):
    """Читает исходные JSON без округления или нормализации ожидаемых значений."""
    return json.loads(path.read_text('utf-8-sig'))


def TestWrite(path, value):
    """Сохраняет воспроизводимый итог; наличие равновесия не объявляет несущую способность."""
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def TestFiles(root):
    """Проверяет закреплённые байты всех данных и действительную общую базу четырёх книг."""
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    assert TestRead(root / 'SourceCheckpoint.json')['base'] == 'af67a34'
    for case in TestRead(root / 'Cases.json'):
        assert TestRead(root / 'Cases' / case / 'Preparation.json')['base_stage_commit'].startswith('af67a34')


def TestNative(repo, root, output):
    """Сверяет все компоненты CFB и завершение только собственных процессов каждой нативной фазы."""
    TestFiles(root)
    shared = run_path(str(root / 'Check-TestMaterialRoundoff.py'))
    source, _ = run_path(str(root / 'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root / 'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    canonical = run_path(str(root / 'Canonical-TestCoreVBA.py'))
    normal = lambda code: canonical['TestCanonical'](code)[0]
    ordinary = canonical['TestWrap'](body)
    def TestBody(code, name):
        """Учитывает только точную числовую запись VBE, сохраняя тип литерала и строки времени выполнения."""
        value = ordinary(code, name)
        return (normal(value[0]), *value[1:]) if name == 'CCoupledNewtonSolver' else value
    phases = {'Diagnostic': ('StallTangent', 1), 'Fine': ('FineTangent', 1),
        'Final': ('Stock', 28), 'Hybrid': ('HybridStall', 2)}
    cases = {}
    for case, (phase, count) in phases.items():
        folder = root / 'Cases' / case
        result = shared['TestSourceComparison'](repo, root, folder, source, original, helper, TestBody, reader)
        assert (result['components'], result['imported'], result['unchanged']) == (239, 25, 214)
        _, actual = reader(helper['TestContainer']((folder / 'CompiledVBA.bin').read_bytes()))
        coupled = []
        for relative in TestRead(folder / 'AllCoupledSources.json'):
            file = folder / relative
            expected, _ = helper['TestMVTCompilerBody'](body, file.read_text('utf-8-sig'), file.stem)
            observed = body(actual[file.stem], file.stem)[0]
            if file.stem == 'CCoupledConcreteReturn':
                def TestSpacing(code):
                    """Разрешает только известное выравнивание одной константы перед тем же комментарием VBE."""
                    rows = code.splitlines(keepends=True)
                    for index, row in enumerate(rows):
                        if row.startswith('private const rounding_limit as double = '):
                            value, comment = row.split("'", 1)
                            rows[index] = value.rstrip() + " '" + comment
                    return ''.join(rows)
                expected, observed = TestSpacing(expected), TestSpacing(observed)
            assert normal(expected) == normal(observed), (case, file.stem)
            coupled.append(file.stem)
        assert len(coupled) == 30
        assert {p.stem for p in (folder / 'Native').glob('*.txt')} == {phase}
        file = folder / 'Native' / (phase + '.txt')
        log = file.read_text('utf-8-sig')
        owner = TestRead(file.with_name(file.name + '.Ownership.json'))
        closure = TestRead(file.with_name(file.name + '.ProcessClosure.json'))
        compiler = TestRead(folder / 'docs/regression/CodeUpdate.json')
        identity = closure['Closure']['Identity']
        assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
        assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
        assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
        assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['Closure']['FinalState']['State'] == 'Absent'
        assert 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
        totals = [tuple(map(int, pair)) for pair in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', log, re.M)]
        assert sum(a for a, _ in totals) == count and all(b == 0 for _, b in totals)
        if case == 'Final':
            assert 'TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10812394211665; limit=;' in log
            assert re.search(r'^RESULTS_SAVE_REOPEN: before=([A-F0-9]+); after=\1; equal=True;', log, re.M)
            result['stock_seconds'] = float(re.search(r'^TIMING_SECONDS: ([\d.]+)', log, re.M)[1])
        safety = [json.loads(line) for line in (folder / 'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in safety)
        assert all(all(p['ProtectedUser'] for p in row['excel']) for row in safety)
        result.update({'all_coupled_sources_match': coupled, 'phase': phase, 'native_assertions': count})
        cases[case] = result
    failure = TestRead(root / 'CompileFailure/CompileFailureClosure.json')
    assert failure['State'] == 'Absent' and failure['PID'] == 10696
    assert 'COMPILE_LOCATION:' in (root / 'CompileFailure/Compile.log').read_text('utf-8-sig')
    TestWrite(output, {'cases': cases, 'first_private_compile_failed': True, 'first_compile_owner_absent': True,
        'installed_workbook_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False})
    print('HYBRID CONTROL ACTUAL VBA AND OWNED PROCESS CLOSURE VERIFIED')


def TestMechanics(repo, root, output):
    """Независимо собирает все уравнения из напряжений VBA; отдельно проверяет собственный префикс гибридной точки."""
    TestFiles(root)
    validate = run_path(str(root / 'Validate-TestHardPrepared.py'))['TestValidate']
    cases, arrays = {}, {}
    for case, count in (('Diagnostic', 22), ('Fine', 13), ('Hybrid', 22)):
        proof, fields = validate(root / 'Cases' / case, 'HardEarlyField')
        assert len(fields) == count and not proof['reversed_fields']
        assert proof['meta'][0] == '6'
        cases[case], arrays[case] = proof, fields
    assert np.array_equal(arrays['Diagnostic'], arrays['Hybrid'])
    proof, candidate = validate(root / 'Cases/Hybrid', 'HardEarlyField.HybridCandidate')
    assert len(candidate) == 22 and np.array_equal(candidate[:21], arrays['Hybrid'][:21])
    assert proof['meta'][:2] == ['4', '0'] and not proof['reversed_fields']
    assert abs(proof['maximum_lambda'] - 1.09499180860435) < 1e-14
    assert proof['states'][-1]['residual_MPa'] < proof['states'][-1]['bound_MPa']
    cases['HybridCandidate'] = proof
    TestWrite(output, {'cases': cases, 'hybrid_main_fields_exact': 22, 'candidate_own_prefix_exact': 21,
        'candidate_not_in_main_trajectory': True, 'independent_material_reintegration': False,
        'physical_capacity_certified': False})
    print('HYBRID CONTROL ALL EQUATIONS SIX FORCES AND OWN HISTORY VERIFIED; CAPACITY OPEN')


def TestTangent(repo, root, output):
    """Повторяет независимую сборку направленных проб и отрицательный контроль транспонирования."""
    TestFiles(root)
    with redirect_stdout(StringIO()):
        run_path(str(root / 'Analyze-TestHardStallTangent.py'))['TestAnalyze'](repo, root / 'Cases/Diagnostic', output)
    record = TestRead(output)
    assert record['matrix_csv_vectors_are_rows']
    assert record['recorded_linear_error_MPa'] < 1e-9 and record['wrong_transpose_linear_error_MPa'] > 1
    assert not record['physical_capacity_certified'] and not record['below_floor_descent']['trial_is_an_equilibrium']
    print('HYBRID CONTROL DIRECTIONAL TANGENT AND TRANSPOSE NEGATIVE CONTROL VERIFIED')


def TestProtocol(repo, root, output):
    """Сверяет каждый двоичный ответ внешнего численного контроля с журналом и нативным подтверждением кандидата."""
    TestFiles(root)
    bridge = root / 'Cases/Hybrid/Native/HybridBridge'
    result = TestRead(bridge / 'Result.json')
    owner = TestRead(bridge / 'PythonOwner.json')
    closure = TestRead(bridge / 'PythonProcessClosure.json')
    assert owner['pid'] == closure['PID'] == 19780 and owner['start_ticks'] == closure['StartTicksUTC']
    assert owner['script_sha256'] == closure['ScriptSHA256'] == sha256((root / 'Cases/Hybrid/TestHybridOptimizer.py').read_bytes()).hexdigest().upper()
    assert owner['scipy'] == '1.18.1' and not owner['created_excel'] and closure['State'] == 'Absent'
    requests = [json.loads(row) for row in (bridge / 'Requests.ndjson').read_text('utf-8').splitlines()]
    assert [row['sequence'] for row in requests] == list(range(1, 96))
    counts = Counter(row['operation'] for row in requests)
    assert counts == {'S': 1, 'C': 1, 'R': 78, 'J': 14, 'V': 1}
    best = np.frombuffer((bridge / 'BestCandidate.bin').read_bytes(), dtype='<f8')
    nearest_residual = None
    for row in requests:
        operation, sequence = row['operation'], row['sequence']
        raw = (bridge / ('response-' + str(sequence) + '.bin')).read_bytes()
        values = np.frombuffer(raw, dtype='<f8')
        assert len(values) == {'S': 61, 'C': 61, 'R': 61, 'J': 3721, 'V': 8}[operation]
        assert np.all(np.isfinite(values))
        if operation == 'C':
            assert np.all(values > 0)
        elif operation in ('R', 'J', 'V'):
            field = np.asarray(row['values'], float)
            assert field.shape == (61,) and np.all(np.isfinite(field))
            if operation == 'R' and np.array_equal(field, best):
                nearest_residual = float(np.max(np.abs(values)))
            elif operation == 'V':
                assert np.array_equal(field, best) and values.tolist() == result['native_validation']
    assert nearest_residual == result['best_residual_MPa'] < 1e-8
    assert result['native_equilibrium_found'] and result['native_validation_required']
    assert len(result['methods']) == 1 and result['methods'][0]['method'] == 'hybr' and result['methods'][0]['success']
    valid, unchanged, bound, residual, steel, advance, factor, origin = result['native_validation']
    assert valid == unchanged == 1 and residual <= bound and steel <= 1 and advance > 0 and factor > origin
    assert not result['physical_capacity_certified'] and not result['independent_material_reintegration']
    assert (bridge / 'done.txt').read_text('ascii') == 'NATIVE_EQUILIBRIUM_FOUND\n'
    TestWrite(output, {'requests': dict(counts), 'total_requests': 95, 'scipy': owner['scipy'],
        'external_numerical_method': 'MINPACK Powell hybrid', 'result': result,
        'material_law_and_history_supplied_by_native_VBA': True, 'exact_binary_responses_verified': True,
        'Python_owner_absent': True, 'runtime_external_dependency_added': False})
    print('HYBRID CONTROL BINARY PROTOCOL AND NATIVE CANDIDATE ACCEPTANCE VERIFIED')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics', 'tangent', 'protocol'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics, 'tangent': TestTangent, 'protocol': TestProtocol}[args.scope](
        args.repo.resolve(), args.root.resolve(), args.out.resolve())
