"""ДЛЯ ТЕСТОВ. Независимо собирает направленные пробы последнего отказа и сравнивает действия касательных."""

from argparse import ArgumentParser
from hashlib import sha256
import csv
from io import StringIO
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile
import numpy as np


def TestAnalyze(repo, root, output):
    """Использует нативные напряжения, но независимо проверяет все уравнения, шесть сил и направленные разности."""
    here = Path(__file__).resolve().parent
    helpers = run_path(str(here / 'Check-TestHardHalfSteps.py'))
    rows = helpers['TestRows'](root / 'Native/HardEarlyField.Stall.csv')
    headers = {row[0]: row[1:] for row in rows if row[0] in (
        'MODE', 'CONTEXT', 'FIELD', 'CORRECTION', 'ORIGIN', 'PROJECTION', 'BASE', 'DIRECTION', 'EXTERNAL', 'RESIDUAL')}
    assert headers['MODE'] == ['DirectionalTangentStudy', 'NotAnEquilibriumSearch']
    main, fields = run_path(str(here / 'Validate-TestHardPrepared.py'))['TestValidate'](root, 'HardEarlyField')
    assert len(fields) == 22 and not main['reversed_fields']
    archive = repo / 'docs/regression/Coupled6D/CoupledDesignLoadWorking20261119.zip'
    assert sha256(archive.read_bytes()).hexdigest().upper() == 'A041180F70DBD0E1F7A6A32BAC4256DACF89484A2EA44325E87481F863D82A30'
    with ZipFile(archive) as baseline:
        source = baseline.read('Cases/Witness/Native/HardEarlyField.csv').decode('cp1251')
        original = [row for row in csv.reader(StringIO(source), delimiter=';') if row and row[0] == 'F']
        original_fields = np.asarray([row[4:] for row in original], float)
        assert np.array_equal(fields, original_fields)
        assert (root / 'Native/HardEarlyField.Operators.csv').read_bytes() == baseline.read('Cases/Witness/Native/HardEarlyField.Operators.csv')
    prefix = int(headers['CONTEXT'][0])
    factor, target, arc = map(float, headers['CONTEXT'][2:5])
    vectors = {key: np.asarray(headers[key], float) for key in ('FIELD', 'CORRECTION', 'ORIGIN',
        'PROJECTION', 'BASE', 'DIRECTION', 'EXTERNAL', 'RESIDUAL')}
    assert np.array_equal(fields[prefix - 1], vectors['ORIGIN'])
    size = len(vectors['FIELD'])
    assert size == 60 and vectors['CORRECTION'].shape == (size + 1,)
    g, load, w, v, coordinate, axis, b, slope = helpers['TestOperators'](root / 'Native/HardEarlyField.Operators.csv', size, 43)
    main_rows = helpers['TestRows'](root / 'Native/HardEarlyField.csv')
    dim = next(row[1:] for row in main_rows if row[0] == 'DIM')
    physical, points, concrete, half = int(dim[1]), int(dim[2]), int(dim[3]), float(dim[4])
    modulus = main['material'][0]
    weights = np.ones(size)
    weights[physical:] = modulus
    norm = lambda value: float(np.max(np.abs(value) * weights))
    direction = vectors['CORRECTION'][:size]
    factor_direction = vectors['CORRECTION'][size]
    external = load @ (vectors['BASE'] + factor * vectors['DIRECTION'])
    external_direction = load @ vectors['DIRECTION'] * factor_direction
    assert norm(external - vectors['EXTERNAL']) <= 1e-9
    matrices, native, stresses = {}, {}, {}
    for row in rows:
        if row[0] == 'J':
            # Механическая матрица VBA имеет первый индекс столбца; сохранённый вектор matrix(i, k) является строкой k.
            matrices.setdefault(row[1], np.empty((size, size)))[int(row[2]) - 1, :] = np.asarray(row[3:], float)
        elif row[0] == 'D': native[float(row[1])] = (float(row[2]), np.asarray(row[3:], float))
        elif row[0] == 'S':
            fraction, side, point = float(row[1]), int(row[2]) + 1, int(row[3]) - 1
            stresses.setdefault(fraction, np.full((3, points, 6), np.nan))[side, point] = np.asarray(row[4:], float)
    assert 0.0 in native and set(native) == set(stresses) and all(np.all(np.isfinite(value)) for value in stresses.values())
    points_area = coordinate[:, 2]
    center = np.average(coordinate[:concrete, :2], axis=0, weights=points_area[:concrete])
    x, y = (coordinate[:, :2] - center).T
    area, moment_scale = 1 / load[0, 0], 1 / load[1, 1]
    resultant_scale = np.asarray((area, moment_scale, moment_scale, moment_scale, area, area))
    residuals, contributions, assembly = {}, {}, []
    for fraction, (trial_factor, weak) in native.items():
        assert abs(trial_factor - (factor + fraction * factor_direction)) < 2e-14
        field = vectors['FIELD'] + fraction * direction
        stress = stresses[fraction]
        derivative = (stress[2] - stress[0]) / (2 * half)
        point_terms = np.einsum('pcd,pc->pd', w, stress[1]) + np.einsum('pcd,pc->pd', v, derivative)
        recovered = g @ field + point_terms.sum(axis=0)
        rounding = 2 * (1e-14 * (np.abs(g) @ np.abs(field) + np.abs(weak))
            + np.einsum('pcd,pc->d', np.abs(w), 1e-14 * np.abs(stress[1]))
            + np.einsum('pcd,pc->d', np.abs(v), 1e-14 * (np.abs(stress[2]) + np.abs(stress[0])) / (2 * half)))
        allowance = max(1e-9, norm(rounding))
        error = norm(recovered - weak)
        assert error <= allowance, (fraction, error, allowance)
        target_load = vectors['BASE'] + trial_factor * vectors['DIRECTION']
        residual = recovered - load @ target_load
        sigma = stress[1]
        resultants = np.asarray((np.dot(points_area, sigma[:, 2]), np.dot(points_area * y, sigma[:, 2]),
            np.dot(points_area * x, sigma[:, 2]), np.dot(points_area, x * sigma[:, 5] - y * sigma[:, 4]),
            np.dot(points_area, sigma[:, 4]), np.dot(points_area, sigma[:, 5])))
        assembly.append({'fraction': fraction, 'assembly_error_MPa': error, 'CSV_allowance_MPa': allowance,
            'residual_MPa': norm(residual), 'force_residual_MPa': float(np.max(np.abs((resultants - target_load) / resultant_scale)))})
        residuals[fraction], contributions[fraction] = residual, point_terms
    base_residual = residuals[0.0]
    assert norm(base_residual - vectors['RESIDUAL']) < 5e-9
    actions = {key: matrix @ direction - external_direction for key, matrix in matrices.items()}
    linear_error = norm(actions['Recorded'] + vectors['RESIDUAL'])
    transposed_linear_error = norm(matrices['Recorded'].T @ direction - external_direction + vectors['RESIDUAL'])
    assert linear_error < 1e-9 and transposed_linear_error > 1
    assert np.array_equal(matrices['Recorded'], matrices['Fine64'])
    control_residual = float(vectors['PROJECTION'] @ vectors['FIELD'] + arc * factor - target)
    control_linear_error = float(vectors['PROJECTION'] @ direction + arc * factor_direction + control_residual)
    derivatives = []
    for fraction in sorted(value for value in native if value):
        actual = (residuals[fraction] - base_residual) / fraction
        row = int(np.argmax(np.abs(actual - actions['Recorded'])[:physical]))
        point_values = (contributions[fraction] - contributions[0.0])[:, row] / fraction
        largest = np.argsort(-np.abs(point_values))[:5]
        derivatives.append({'fraction': fraction, 'derivative_norm_MPa': norm(actual),
            'row53_derivative_MPa': float(actual[52]), 'maximum_recorded_error_row': row + 1,
            'matrix_action_error_MPa': {key: norm(action - actual) for key, action in actions.items()},
            'top_actual_point_contributions': [{'point': int(point + 1), 'value_MPa': float(point_values[point])} for point in largest]})
    winning = next(row for row in assembly if row['fraction'] == 1 / 256)
    bound = main['options'][3] + main['options'][4] * np.max(np.abs(external[:physical]))
    assert winning['residual_MPa'] < norm(base_residual) * (1 - .0001 / 256)
    assert winning['residual_MPa'] > bound
    report = {'context': headers['CONTEXT'], 'main_fields_exact': len(fields), 'main_equilibria': main,
        'directional_probes_are_equilibria': False, 'physical_capacity_certified': False,
        'independent_material_reintegration': False, 'assembly': assembly,
        'recorded_linear_error_MPa': linear_error, 'control_residual': control_residual,
        'matrix_csv_vectors_are_rows': True, 'wrong_transpose_linear_error_MPa': transposed_linear_error,
        'below_floor_descent': {'original_minimum_fraction': 1 / 128, 'actual_descent_fraction': 1 / 256,
            'base_residual_MPa': norm(base_residual), 'trial_residual_MPa': winning['residual_MPa'],
            'unchanged_equilibrium_bound_MPa': float(bound), 'trial_is_an_equilibrium': False},
        'control_linear_error': control_linear_error, 'recorded_residual_MPa': norm(vectors['RESIDUAL']),
        'matrix_action_MPa': {key: {'norm': norm(action), 'row53': float(action[52])} for key, action in actions.items()},
        'fresh_matrix_maximum_difference': {key: float(np.max(np.abs(matrix - matrices['Recorded']))) for key, matrix in matrices.items()},
        'derivatives': derivatives}
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('STALLED ITERATION ALL DIRECTIONAL EQUATIONS AND FORCES REASSEMBLED; NOT A CAPACITY RESULT')
    print('CONTEXT', headers['CONTEXT'], 'linear_error', linear_error, 'control_error', control_linear_error)
    print('ACTIONS', report['matrix_action_MPa'])
    for row in derivatives:
        if abs(row['fraction']) in (1 / 64, 1 / 1024, 1 / 16384):
            print('DERIVATIVE', row['fraction'], row['row53_derivative_MPa'], row['matrix_action_error_MPa'])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.repo.resolve(), args.root.resolve(), args.out.resolve())
