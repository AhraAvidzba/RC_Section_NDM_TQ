"""Replay the A2 open-crack membrane traction screen from exact native fields."""

import argparse
from collections import Counter
from dataclasses import dataclass
from hashlib import sha256
import json
from math import atan2, cos, degrees, fsum, hypot, isclose, pi, sin
from pathlib import Path
from zipfile import ZipFile


ARCHIVE = 'A2LaneABExactNative20261116.zip'
ARCHIVE_HASH = 'CA2C750095DBB1F3DB62D5CC2EE046638E86D79D8CADCD3EF821EFF8DD31AF53'
WORKBOOK_HASH = '8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF'
SOURCE_HASHES = {
    'Vecchio-Collins-1986-Primary-Panels.pdf': '0DBA6D0865906C7F998BB2C5CD2392A11F7D794BE5644C6F0833E3C66C34F567',
    'Kagermanov-Ceresa-2018.pdf': '7D9B0FD7D0BC62E5D77FA7A7727733BC109EF8C3AD33149E2F50B7F4C64F08B7',
    'Lopes-Bernardo-2009-PureTorsion.pdf': 'E1A825DE9F4099A2E8CDF355696DA22BBC75F2A6AE0582A76BD844E4B1E9A6B6',
    'Lopes-Bernardo-2014-TorsionFailure.pdf': 'C5ACB30732F7EBA9300798173B94CA0AE47FF60F569935A2D7F1C55F707313A1',
}
TARGETS = (239.4, 247.1, 254.8)
FY_Z, FY_T, ES = 672., 696., 200000.
CELL_PITCH = 600. / 9
HOOP_PER_LENGTH = pi * 8**2 / (4 * 80)


@dataclass(frozen=True)
class Point:
    index: int
    family: str
    xy: tuple
    weight: float
    steel: float
    strain: float
    concrete: tuple
    direction_tensor: tuple

    @classmethod
    def from_row(cls, row):
        assert len(row) == 23
        return cls(int(row[2]), row[3], tuple(map(float, row[4:6])),
                   *map(float, row[6:9]), tuple(map(float, row[11:17])),
                   tuple(map(float, row[17:23])))


def digest(data):
    return sha256(data).hexdigest().upper()


def exact_states(data):
    rows = [line.split(';') for line in data.decode('utf-8-sig').splitlines()]
    assert tuple(rows[0]) == ('GRID', '9', '56', rows[0][3])
    assert rows[1] == ['SCALES', '216004', '407.293505963451']
    for index, target in enumerate(TARGETS, 1):
        anchor, = [r for r in rows if r[:2] == ['ANCHOR', str(index)]]
        assert float(anchor[2]) == target
        points = [Point.from_row(r) for r in rows if r[:2] == ['POINT', str(index)]]
        assert [p.index for p in points] == list(range(1, 89))
        assert Counter(p.family for p in points) == {
            'Concrete': 56, 'LongitudinalCorner': 4, 'LongitudinalSide': 12, 'Hoop': 16,
        }
        yield anchor, points


def verify_wrench(anchor, points):
    contributions = []
    for p in points:
        sign = 1 if p.family == 'Concrete' else -1
        fy = FY_T if p.family == 'Hoop' else FY_Z
        assert abs(p.steel - min(fy, max(-fy, ES * p.strain))) < 2.e-8
        _, _, zz, _, xz, yz = [sign*c + p.steel*d for c, d in zip(p.concrete, p.direction_tensor)]
        x, y = p.xy
        contributions.append(tuple(p.weight * v for v in (zz, y*zz, x*zz, x*yz-y*xz, xz, yz)))
    measured = tuple(map(fsum, zip(*contributions)))
    native = tuple(map(float, anchor[7:13]))
    area, radius = 216004., 407.293505963451
    scales = (area, area*radius, area*radius, area*radius, area, area)
    computed_native_delta = max(abs(a-b)/s for a, b, s in zip(measured, native, scales))
    target = float(anchor[2]) * 1.e6
    target_delta = max(abs(a-b)/s for a, b, s in zip(measured, (0., 0., 0., target, 0., 0.), scales))
    assert computed_native_delta < 1.e-12 and target_delta < 5.5e-7
    return {'target_T_kNm': target/1.e6, 'integrated_efforts_N_or_Nmm': measured,
            'native_normalized_residual_MPa': float(anchor[5]),
            'delta_to_native_MPa': computed_native_delta, 'delta_to_target_MPa': target_delta,
            'gauge_comparison_microstrain': {
                 'native_longitudinal_corner_max': 1.e6 * max(p.strain for p in points if p.family == 'LongitudinalCorner'),
                 'native_hoop_gauss_max': 1.e6 * max(p.strain for p in points if p.family == 'Hoop'),
                 'experimental_longitudinal_band_at_254_8': [5049, 5208] if target == 254.8e6 else None,
                 'experimental_hoop_band_at_247_1': [4588, 5297] if target == 247.1e6 else None,
            }}


def plane(p, axis):
    xx, yy, zz, _, xz, yz = p.concrete
    return (zz, yy, yz) if axis == 0 else (zz, xx, xz)


def wall_partition(p, axis, side):
    x, y = p.xy
    if side * p.xy[axis] < 0:
        return 0.
    if p.family == 'LongitudinalCorner' or abs(abs(x)-abs(y)) < 1.e-7:
        return .5
    return float(abs(p.xy[axis]) > abs(p.xy[1-axis]))


def weighted_membrane(concrete, bars, gross):
    c = [fsum(v)/gross for v in zip(*(tuple(w*s for s in stress) for w, stress in concrete))]
    wz, wt = (fsum(w for w, _ in layer) for layer in bars)
    sz, st = (fsum(w*s for w, s in layer)/w_total for layer, w_total in zip(bars, (wz, wt)))
    return membrane(gross, wz, wt, sz, st, c)


def full_wall(points, axis, side):
    partitioned = [(p, p.weight*wall_partition(p, axis, side)) for p in points]
    gross = fsum(w for p, w in partitioned if p.family == 'Concrete')
    assert isclose(gross, 54001., abs_tol=1.e-7)
    concrete = [(w if p.family == 'Concrete' else -w, plane(p, axis)) for p, w in partitioned]
    bars = ([(w, p.steel) for p, w in partitioned if p.family.startswith('Longitudinal')],
            [(w, p.steel) for p, w in partitioned if p.family == 'Hoop'])
    return weighted_membrane(concrete, bars, gross)


def mean_basis_on_panel(abscissae, half_width):
    """Exact integral means of cubic Lagrange basis over symmetric strip."""
    means = []
    for idx, x in enumerate(abscissae):
        a, b, c = [val for j, val in enumerate(abscissae) if j != idx]
        means.append((-(a+b+c)*half_width**2/3-a*b*c)/((x-a)*(x-b)*(x-c)))
    assert abs(fsum(means)-1) < 1.e-12
    return means


def central_panel(points, axis, side, width_factor, subtract_hoop_concrete):
    tangent = 1 - axis
    longitudinal = [p for p in points if p.family == 'LongitudinalSide' and side*p.xy[axis] > 250]
    assert len(longitudinal) == 3
    centre, = [p for p in longitudinal if abs(p.xy[tangent]) < 1.e-10]
    pitches = [abs(p.xy[tangent]) for p in longitudinal if p != centre]
    assert len(pitches) == 2 and abs(pitches[0]-pitches[1]) < 1.e-9
    half_width = width_factor * pitches[0]/2
    selected_concrete = [p for p in points if p.family == 'Concrete' and
                         side*p.xy[axis] > 195 and abs(p.xy[tangent]) < 90]
    assert len(selected_concrete) == 6
    concrete, gross = [], 0.
    for p in selected_concrete:
        u = p.xy[tangent]
        overlap = max(0., min(half_width, u+CELL_PITCH/2)-max(-half_width, u-CELL_PITCH/2))
        weight = p.weight * overlap/CELL_PITCH
        gross += weight
        concrete.append((weight, plane(p, axis)))
    assert isclose(gross, 107.*2*half_width, abs_tol=1.e-7)
    concrete.append((-centre.weight, plane(centre, axis)))
    hoop = [p for p in points if p.family == 'Hoop' and side*p.xy[axis] > 250]
    assert len(hoop) == 4 and all(abs(p.xy[tangent]) > half_width for p in hoop)
    hoop_basis = mean_basis_on_panel([p.xy[tangent] for p in hoop], half_width)
    mean_hoop = fsum(p.steel*k for p, k in zip(hoop, hoop_basis))
    mean_hoop_strain = fsum(p.strain*k for p, k in zip(hoop, hoop_basis))
    assert abs(mean_hoop - ES*mean_hoop_strain) < 2.e-8
    hoop_area = 2*half_width*HOOP_PER_LENGTH
    if subtract_hoop_concrete:
        concrete.extend((-hoop_area*k, plane(p, axis)) for p, k in zip(hoop, hoop_basis))
    result = weighted_membrane(concrete, ([(centre.weight, centre.steel)], [(hoop_area, mean_hoop)]), gross)
    return {'width_mm': 2*half_width, 'central_bar_id': centre.index, **result}


def membrane(gross, wz, wt, steel_z, steel_t, c):
    czz, ctt, czt = c
    f1 = (czz + ctt + hypot(czz-ctt, 2*czt))/2
    alpha = abs(atan2(2*czt, czz-ctt)/2)
    nz, nt = cos(alpha), sin(alpha)
    rho_z, rho_t = wz/gross, wt/gross
    margin_z, margin_t = rho_z*(FY_Z-steel_z), rho_t*(FY_T-steel_t)
    carry = nz*nz*margin_z + nt*nt*margin_t
    yield_normal = nz*nz*rho_z*FY_Z + nt*nt*rho_t*FY_T
    best_u = 1 + (f1-carry)/yield_normal
    lo, hi = (f1-margin_t)*nt/nz, (margin_z-f1)*nz/nt
    assert (lo > hi) == (best_u > 1.)
    tau_at_best = (rho_z*(best_u*FY_Z-steel_z)-f1)*nz/nt
    post_z = steel_z + (f1+tau_at_best*nt/nz)/rho_z
    post_t = steel_t + (f1-tau_at_best*nz/nt)/rho_t
    assert abs(post_z/FY_Z-post_t/FY_T) < 2.e-15
    return {'area_gross_mm2': gross, 'steel_area_z_t_mm2': [wz, wt],
            'average_steel_z_t_MPa': [steel_z, steel_t], 'concrete_zz_tt_zt_MPa': c,
            'tensile_traction_MPa': f1, 'crack_normal_to_axis_deg': degrees(alpha),
            'available_steel_normal_traction_MPa': carry, 'best_maximum_steel_utilization': best_u,
            'elastic_tau_lower_upper_MPa': [lo, hi], 'tau_at_best_MPa': tau_at_best,
            'steel_z_t_if_zero_tau_MPa': [steel_z+f1/rho_z, steel_t+f1/rho_t]}


def replay(archive):
    assert digest(archive.read_bytes()) == ARCHIVE_HASH
    output = {'archive_sha256': ARCHIVE_HASH, 'workbook_sha256_in_fixture': WORKBOOK_HASH,
              'primary_source_sha256': SOURCE_HASHES, 'lanes': {}}
    with ZipFile(archive) as z:
        assert json.loads(z.read('Fixture.json'))['workbook_sha256'] == WORKBOOK_HASH
        for lane in ('A', 'B'):
            data = z.read(f'Native/{lane}-1-Exact.csv')
            rows = []
            for anchor, points in exact_states(data):
                row = verify_wrench(anchor, points)
                row['walls'] = {}
                for axis, letter in enumerate('xy'):
                    for side, key in ((-1, '-'), (1, '+')):
                        row['walls'][key+letter] = {
                            'full_wall': full_wall(points, axis, side),
                            'central_with_hoop_replacement_sensitivity': central_panel(points, axis, side, 1., True),
                            'central_width_sensitivity_no_hoop_replacement': {
                                str(factor): central_panel(points, axis, side, factor, False)
                                for factor in (0.75, 1., 1.25)},
                        }
                rows.append(row)
            output['lanes'][lane] = {'native_csv_sha256': digest(data), 'anchors': rows}
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path, metavar='EXACT_ZIP')
    parser.add_argument('--literature', type=Path, help='Optional check of source PDFs by SHA256')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.literature:
        for name, sha in SOURCE_HASHES.items():
            assert digest((args.literature/name).read_bytes()) == sha, name
    result = replay(args.archive)
    for lane in result['lanes'].values():
        for index, row in enumerate(lane['anchors']):
            for wall in row['walls'].values():
                assert wall['full_wall']['best_maximum_steel_utilization'] < 1
                central = wall['central_width_sensitivity_no_hoop_replacement']
                nominal_util = central['1.0']['best_maximum_steel_utilization']
                with_hoop = wall['central_with_hoop_replacement_sensitivity']['best_maximum_steel_utilization']
                assert (nominal_util > 1.) == (index > 0) == (with_hoop > 1.)
                assert abs(nominal_util - with_hoop) <= .0032
                assert central['1.25']['best_maximum_steel_utilization'] > 1.
    payload = json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False)
    if args.report:
        with args.report.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(payload + '\n')
        print('A2 LOCAL CRACK TRACTION OFFLINE PASS')
    else:
        print(payload)
