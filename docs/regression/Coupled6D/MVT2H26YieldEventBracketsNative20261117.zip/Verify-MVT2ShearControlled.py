"""Verify the same-law residuals and measured yield-crossing brackets on the H26 ray."""
import argparse
from collections import defaultdict
from decimal import Decimal
import json
from math import hypot
from pathlib import Path

import PriorReplay as prior
import ResumeBase as base
import VerifyBase as v

HERE = Path(__file__).resolve().parent


def prepare():
    original = base.prepare()
    before = v.read(HERE / "ArchivedRadius.json")
    pinned = original[6]
    assert float(before["B_EXT_TRY"][4]) == 2.63894309345674e-7 == 2*pinned[62]
    assert prior.numbers(before["B_EXT_PROJECTION"][1:]) == pinned[:60]
    assert prior.numbers(before["B_EXT_TRY"][5:7]) == pinned[61:59:-1]
    assert before["B_FB_OPT"] == ["1","1","84"] and before["B_FB_STOP"] == ["1","Radius"]
    plan = v.read(HERE / "FrozenEventPlan.json")
    assert len(plan["event_brackets"]) == 3 and plan["point"] > 0
    return *original, before, plan


def history_and_stations(tags, prefix, old, old_stations, witnesses):
    actual_fields = prior.by_name(tags,"B_TANGENT_FIELD")
    actual_forces = prior.by_name(tags,"B_EXT_SOLVER_ACTUAL")
    accepted = prior.by_name(tags,"B_EXT_COMMITTED")
    snapshots = prior.by_name(tags,"B_ARC_HISTORY")
    assert snapshots["Base24"] == snapshots["Restored24"]
    assert all(len(row) == 1080 and all(Decimal(x).is_finite() for x in row) for row in snapshots.values())
    pieces = defaultdict(list)
    anchor_labels = {"Base24","Restored24","Attempt1","Attempt2"}
    for marker in ("B_TANGENT_FIELD","B_TANGENT_STATION","B_TANGENT_RESIDUAL","B_BOUND_ACTUAL","B_BOUND_NORM","B_BOUND_STEEL"):
        for label,*values in tags[marker]:
            if label in anchor_labels:
                if marker == "B_TANGENT_FIELD":
                    values[0] = "24"
                pieces[marker].append([label,*values])
    anchor_states, anchor_stations = v.verified_states(pieces)
    assert old == anchor_states["Base24"] == anchor_states["Restored24"]
    assert old_stations == anchor_stations["Base24"] == anchor_stations["Restored24"]
    replay = v.vec(tags,"MVT2_CONTROL_FIELD")
    assert len(replay) == 24
    for i,(field, _) in enumerate(prefix,1):
        assert v.peak(v.diff(replay[f"Replay{i}"],field)) < 1e-15
    v.verify_steel(pieces,anchor_states,anchor_stations,replay)
    current = snapshots["Base24"]
    assert set(accepted) == {"Attempt1","Attempt2"}
    decisions = prior.by_name(tags,"B_EXT_DECISION")
    assert decisions == {"Attempt1":["Accepted"],"Attempt2":["Accepted"],"Attempt3":["Newton"]}
    for number,witness in enumerate(witnesses,1):
        label = f"Attempt{number}"
        assert actual_fields[label] == [str(23+number),*witness[:61]]
        assert accepted[label] == witness[1:61] and actual_forces[label] == witness[61:67]
        assert snapshots["BeforeSolve"+label] == snapshots["BeforeDecision"+label] == current
        fresh = snapshots["Committed"+label]
        assert fresh == snapshots["Replayed"+label] == witness[67:]
        assert all(Decimal(fresh[i]) >= Decimal(current[i]) for i in range(1080) if i % 8 in (6,7))
        current = fresh
    derived = ["Radius"+r[0] for r in tags["B_RADIUS_TRIAL"]]
    for label in ("BeforeSolveAttempt3","BeforeDecisionAttempt3","DiscardedAttempt3",*derived):
        assert snapshots[label] == current
    return anchor_states["Attempt2"]


def verify(prep, prefix, old, old_stations, witnesses, original, pinned, load_scale, archived, plan):
    compiler, office, wall = base.verified_receipts(prep)
    path = base.NATIVE / "MVT2.csv"
    tags = v.read_native(path)
    assert tags["B_FRESH_PHASE"] == [["Resume"]]
    assert by_numeric(tags,"B_RESUME_PLAN")[0][2:] == (5e-7,5e-7,26.)
    h26 = history_and_stations(tags,prefix,old,old_stations,witnesses)
    order = prior.by_name(tags,"B_EXT_TRY")
    assert tuple(order) == ("Attempt1","Attempt2","Attempt3")
    assert order["Attempt3"] == archived["B_EXT_TRY"][1:]
    native_solver = prior.by_name(tags,"B_EXT_SOLVER")
    actual_attempt = native_solver["Attempt3"]
    assert actual_attempt[:3] == archived["B_EXT_SOLVER"][1:4] == ["0","6","10"]
    assert actual_attempt[4:] == archived["B_EXT_SOLVER"][5:]
    grouped = base.fallback_by_probe(path)["Attempt3"]
    assert grouped == [[key,*value] for key,value in archived.items() if key.startswith("B_FB_")]
    _, prev_lambda, current_lambda, ds, len_secant, k, plane_target, _ = prior.numbers(order["Attempt3"])
    p = v.vec(tags,"B_EXT_PROJECTION")["Attempt3"]
    assert p == pinned[:60]
    current = (h26["field"],h26["q"])
    previous = (prior.numbers(witnesses[0][1:61]),float(witnesses[0][0]))
    independent_p, independent_k, independent_length = prior.determine_normal(current,previous,h26["geometry"],load_scale)
    assert (prev_lambda,current_lambda) == (previous[1],current[1])
    assert v.peak(v.diff(independent_p,p)) < 2e-12
    v.near(k,independent_k,2e-15)
    v.near(len_secant,independent_length,2e-17)
    v.near(plane_target,v.dot(p,current[0])+k*current[1]+ds,4e-15)
    assert tags["B_RADIUS_REJECT"] == [plan["reference_raw_fields"]["Rejected"]]
    [(stall_factor,proposal_factor,local_radius,local_limit)] = by_numeric(tags,"B_RADIUS_REJECT")
    assert stall_factor == float(archived["B_FB_START"][3])
    assert (local_radius,local_limit) == (float(archived["B_FB_RADIUS"][2]),float(archived["B_FB_RADIUS"][3]))
    assert local_radius > local_limit > 0.
    fields = v.vec(tags,"B_RADIUS_FIELD")
    assert set(fields) == {"Stall","Full"}
    assert prior.by_name(tags,"B_RADIUS_FIELD") == {name: plan["reference_raw_fields"][name] for name in ("Stall","Full")}
    tangential = prior.by_name(tags,"B_TANGENT_FIELD")
    raw_rows = v.vec(tags,"B_TANGENT_RESIDUAL")
    raw_forces = prior.by_name(tags,"B_BOUND_ACTUAL")
    stations = defaultdict(dict)
    for label,point,side,*record in tags["B_TANGENT_STATION"]:
        key = int(point),int(side)
        assert key not in stations[label] and len(record) == 19
        stations[label][key] = prior.numbers(record)
    outcomes = []
    diag = prior.by_name(tags,"B_RADIUS_TRIAL")
    brackets = []
    expected = {"Stall":0.,"OldCap":local_limit/local_radius}
    checked = prior.by_name(tags,"B_YIELD_BRACKET")
    assert list(checked) == [item[0] for item in plan["event_brackets"]]
    for tag,side,initial_lo,initial_hi in plan["event_brackets"]:
        *terms,result = checked[tag]
        point,z,lo,flow,branch_lo,hi,fhigh,branch_hi = prior.numbers(terms)
        assert (int(point),int(z)) == (plan["point"],side) and branch_lo in (0,1) and branch_hi in (0,1)
        assert initial_lo <= lo < hi <= initial_hi
        if result == "Bracketed":
            assert flow <= 0 < fhigh and hi-lo <= (initial_hi-initial_lo)/4096.+4e-16
        else:
            assert result == "NoBracket" and (lo,hi) == (initial_lo,initial_hi)
            assert flow >= 0 or fhigh <= 0
        expected[tag+"Before"] = lo
        expected[tag+"After"] = hi
        key = int(point),int(z)
        for label,f,branch in ((tag+"Before",flow,branch_lo),(tag+"After",fhigh,branch_hi)):
            if label in stations:
                raw = stations[label][key]
                assert raw[3] == branch
                v.near(raw[6],f,2e-12)
        brackets.append({"label":tag,"point":int(point),"side":int(z),"initial_interval":[initial_lo,initial_hi],
                         "measured_alpha_interval":[lo,hi],"measured_signed_yield":[flow,fhigh],
                         "measured_return_branch":[int(branch_lo),int(branch_hi)],"result":result})
    expected["Quarter"] = .25
    assert tuple(diag) == tuple(expected) and diag["Quarter"] == plan["reference_raw_fields"]["Quarter"]
    for label,raw in diag.items():
        amount = expected[label]
        *numbers, status = raw
        fraction, factor, norm, tau, forward, overall_radius, strain_radius = prior.numbers(numbers)
        v.near(fraction,amount,2e-15)
        history, saved_lambda, *saved_field = tangential[label]
        trial = prior.numbers(saved_field)
        assert int(history) == 26 and float(saved_lambda) == factor
        expected_factor = stall_factor+amount*(proposal_factor-stall_factor)
        expected_field = tuple(a+amount*(b-a) for a,b in zip(fields["Stall"],fields["Full"],strict=True))
        v.near(factor,expected_factor,2e-13)
        assert v.peak(v.diff(trial,expected_field)) < 2e-15
        if amount == 0.:
            assert trial == fields[label]
        v.near(tau,5e-7*(1+v.peak(v.loading(factor))),2e-18)
        delta_q, delta_lambda = v.diff(trial,current[0]),factor-current[1]
        arc = v.dot(p,delta_q)+k*delta_lambda
        length = hypot(*prior.station_metric(delta_q,h26["geometry"]),load_scale*delta_lambda)
        physical_local = v.strain_extent(v.diff(trial,fields["Stall"]),h26["geometry"])
        v.near(forward,arc,4e-15)
        v.near(overall_radius,length,4e-15)
        v.near(strain_radius,physical_local,4e-15)
        v.near(local_radius*amount,physical_local,4e-15)
        trial_summary = {"label":label,"correction_fraction":fraction,"status":status,"Qy_kN":factor,
                         "Qy_delta_from_H26_kN":delta_lambda,"target_six_N_Nmm":v.force(factor),
                         "signed_arc":arc,"plane_error_MPa":(arc-ds)*v.MODULUS,"physical_arc_length_over_nominal":length/ds,
                         "local_correction_tensor_radius":physical_local,"local_radius_over_original_bound":physical_local/local_limit,
                         "original_tolerance_MPa":tau}
        if status == "MaterialUnavailable":
            assert norm == -1. and [label,"Residual"] in tags["B_TANGENT_UNAVAILABLE"] and label not in raw_rows
        else:
            rows, force, strain_err = v.reconstruct(trial,factor,stations[label])
            assert h26["geometry"] == {key: row[:3] for key,row in stations[label].items()}
            assert strain_err < 4e-15 and v.peak(v.diff(rows,raw_rows[label])) < 3e-10
            assert v.peak(x/s for x,s in zip(v.diff(force,prior.numbers(raw_forces[label])),v.SCALES,strict=True)) < 4e-12
            error = v.diff(force,v.force(factor))
            gauges = tuple(x*v.MODULUS for x in rows[56:])
            force_norm = v.peak(x/s for x,s in zip(error,v.SCALES,strict=True))
            measured = max(v.peak(rows[:56]),v.peak(gauges),force_norm)
            v.near(norm,measured,4e-10)
            if label == "Stall":
                v.near(float(archived["B_FB_START"][1]),measured,4e-10)
                assert abs(rows[52]) == v.peak(rows[:56])
            admissible = measured <= tau and arc > 0. and abs(arc-ds)*v.MODULUS <= tau and length <= 3*ds
            if status == "EquilibriumOnArc":
                assert admissible
            elif status == "Residual":
                assert measured > tau
            elif status == "OutsideArc":
                assert measured <= tau and not admissible
            else:
                raise AssertionError(status)
            trial_summary.update({"actual_six_N_Nmm":force,"signed_six_errors_N_Nmm":error,"weak56_MPa":rows[:56],
                                  "gauge4_MPa":gauges,"full_residual_over_tau":measured/tau,
                                  "force_error_over_tau":force_norm/tau,
                                  "concrete_changes_from_stall":[list(key) for key,value in stations[label].items() if key[0] <= 25 and
                                     (value[3:6] != stations["Stall"][key][3:6] or value[6]*stations["Stall"][key][6] < 0.)]})
        outcomes.append(trial_summary)
    [[count, end_lambda, elapsed]] = tags["B_RESUME_END"]
    assert count == "26" and float(end_lambda) == current[1] and float(elapsed) <= prep["watchdog_seconds"]
    assert tags["B_TANGENT_END"] == [["24","18.55811"]]
    return {"native_trace_sha256":v.digest(path),"original_H26_Qy_kN":current[1],"same_original_failure":True,
            "physical_limit_established":False,"forward_fields_committed":False,"H24_exact_restored":True,
            "original_optimizer_radius_cap":local_limit,"original_optimizer_attempt_radius":local_radius,
            "original_optimizer_radius_ratio":local_radius/local_limit,"measurements":outcomes,"yield_events":brackets,
            "compiler_closed":compiler,"office_closed":office,"native_wall_seconds":wall}


def by_numeric(tags,label):
    return [prior.numbers(row) for row in tags[label]]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--phase",choices=["Resume"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert args.phase == "Resume"
        output = HERE/"VerificationYieldEvents.json"
        output.write_bytes((json.dumps(verify(*frozen),indent=2)+"\n").encode())
        print(output,v.digest(output))
