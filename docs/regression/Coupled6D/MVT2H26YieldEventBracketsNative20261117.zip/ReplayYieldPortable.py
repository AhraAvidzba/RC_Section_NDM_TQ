"""Reproduce native H26 yield brackets and pairwise equilibrium analysis."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import ModuleType
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
WORKBOOK = "2ACFC02576861DB076FDBDBF12471FE630DA95D738A60D4A48A0D9EAF02937EF"
REPORT = "60B732E6E2B20676B06C23A52E4E5A335761408BA6A2BC133DE29B42C0335830"
PARENT = "MVT2H26RadiusRejectionNative20261117.zip"
DEPENDENCIES = {
    PARENT: "72D5A584147EB019F811EAA92E439F81504E88218FF499899A1BE17152FD1788",
    "MVT2ExactH26SmallerArcNative20261116.zip": "B775E3D70EED7CC8239F905AC4E3779AA65CE8994BA1F045BED899B6235B4F07",
    "MVT2AdaptiveBoundedContinuationNative20261116.zip": "A5F4EABFE14F46544D6BA36934B050AED5C5F3655DC91D32D6E8C6408562E699",
    "MVT2AutomaticBoundedBranchRecoveryNative20261116.zip": "C115A4F6C4B7A986229D05F9E279D1E132B86BF00BCAE9D133611809B94AE28F",
    "MVT2StockBranchArcNative20261116.zip": "F6C9A1F7276320EA91F70022E171FAD35A61D457584BDE3242821C90328CA422",
}


def digest(raw):
    return sha256(raw).hexdigest().upper()


def local(root,name):
    return root / (root / name).resolve().relative_to(root.resolve())


def materialize(work, manifest, archives):
    assert manifest["archives"] == DEPENDENCIES and manifest["workbook"] == {"path":BOOK,"sha256":WORKBOOK}
    for name,expected in DEPENDENCIES.items():
        assert digest((archives/name).read_bytes()) == expected
    for name,rec in manifest["inputs"].items():
        source = rec.get("archive")
        member = rec.get("member",name)
        if source:
            with ZipFile(archives/source) as z:
                raw = z.read(member)
        else:
            raw = local(HERE,member).read_bytes()
        assert digest(raw) == rec["sha256"], name
        dst = local(work,name)
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(raw)


def replay(work,archives):
    stage = work/"Stage.py"
    scope = {"__name__":"archived_stage","__file__":str(stage)}
    exec(compile(stage.read_text(encoding="utf-8"),str(stage),"exec"),scope)
    with ZipFile(archives/PARENT) as parent:
        assert digest(parent.read("Preparation.json")) == scope["PREP"]
        plan = scope["witness"](parent.read("Mechanism.json"),parent.read("NativeResume/MVT2.csv"))
        assert (json.dumps(plan,indent=2)+"\n").encode() == (work/"FrozenEventPlan.json").read_bytes()
        macro = scope["MACRO"]
        assert scope["overlay_macro"](parent.read(macro),plan) == (work/macro).read_bytes()
    sys.path.insert(0,str(work))
    file = work/"ResumeBase.py"
    text = file.read_text(encoding="utf-8")
    old = '    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items())'
    assert text.count(old) == 1 and not (work/BOOK).exists()
    pinned = (f'    assert prep["inputs"]["{BOOK}"] == prep["book_sha256"] == "{WORKBOOK}"\n'
              f'    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items() if path != "{BOOK}")')
    base = ModuleType("ResumeBase")
    base.__file__ = str(file)
    sys.modules["ResumeBase"] = base
    exec(compile(text.replace(old,pinned),str(file),"exec"),base.__dict__)
    file = work/"Verify-MVT2ShearControlled.py"
    scope = {"__name__":"archived_native","__file__":str(file)}
    exec(compile(file.read_text(encoding="utf-8"),str(file),"exec"),scope)
    actual = scope["verify"](*scope["prepare"]())
    raw = (work/"VerificationYieldEvents.json").read_bytes()
    assert digest(raw) == REPORT and (json.dumps(actual,indent=2)+"\n").encode() == raw
    from AnalyzeEvents import summarize
    summary = summarize(actual,work/"NativeResume/MVT2.csv")
    raw_summary = (work/"YieldEventAnalysis.json").read_bytes()
    assert (json.dumps(summary,indent=2)+"\n").encode() == raw_summary
    return summary,digest(raw_summary)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives",type=Path,required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE/"PortableManifest.json").read_bytes())
    with TemporaryDirectory() as tmp:
        work = Path(tmp)
        materialize(work,manifest,args.archives)
        result,summary = replay(work,args.archives)
    print("NATIVE YIELD EVENT BRACKETS",REPORT,"ANALYSIS",summary)
    print("INDEPENDENT EVENTS",len(result["events"]),"EQUILIBRIA",result["qualifying_equilibria"])


if __name__ == "__main__":
    main()
