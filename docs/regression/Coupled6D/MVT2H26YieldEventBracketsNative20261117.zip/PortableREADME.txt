H26 original Newton ray: independently measured yield crossings at three stations.

    python -B -X utf8 ReplayYieldPortable.py --archives <repository>/docs/regression/Coupled6D

Read the manifest for pinned archives. The detached replay reconstructs the frozen diagnostic
case and exact VBA driver, verifies all signed load and equilibrium rows and exact histories,
and recomputes both result files byte for byte. An unchanged private run first reproduces
the original failed H26 step, then evaluates the same ray at the old radius cap and both sides
of each tightly measured material yield crossing. Each diagnostic uses original tolerances
and never updates the accepted history. Native cleanup and H24 restoration are verified.
YieldEventAnalysis tracks signed residual changes across each finite bracket and the larger
changes over the intervals. The scan still contains no qualifying equilibrium and establishes
no physical limit. It separates the tested small brackets from changes along the finite ray.
