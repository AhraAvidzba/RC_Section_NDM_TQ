"""Seal a focused H26 line scan across measured yield events."""
import csv
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "mv26r"
PREP = "A6D4267E9EBB7B25936883D12B8EA43FC63E2B7BF611B8001CF85032F56B554D"
MECHANISM = "C8EB959F0B39430E864689767F2C5F6585EC05DEBA210F91294F70DD5F282597"
TRACE = "7E2544B1FAB49BA32B125C7B0A319BA74170DF8E6AA68FD5883230DD3B4A0376"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MACRO = "tests/modTestCoupledExperiment.bas"
VERIFY = "Verify-MVT2ShearControlled.py"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name, data):
    dest = HERE / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        assert dest.read_bytes() == data, dest
    else:
        dest.write_bytes(data)
    return digest(data)


def switch(value, old, new):
    assert value.count(old) == 1, old
    return value.replace(old, new)


def witness(mechanism, trace):
    assert digest(mechanism) == MECHANISM and digest(trace) == TRACE
    diagnostics = json.loads(mechanism)
    affected = {tuple(site) for item in diagnostics["trials"] for site in item["concrete_branch_or_surface_changes"]}
    assert len({point for point, _ in affected}) == 1 and {side for _, side in affected} == {-1,0,1}
    point = next(iter(affected))[0]
    plan = (("Minus",-1,.0443,.0450),("Center",0,.0715,.0722),("Plus",1,.09865,.09935))
    estimates = diagnostics["trials"][-1]["observed_yield_sign_changes"]
    for (_tag,side,lo,hi), estimate in zip(plan,estimates,strict=True):
        assert estimate["station"] == [point,side] and lo < estimate["linear_estimate_of_fraction_at_zero_yield"] < hi
    found = {}
    for tag,*row in csv.reader(trace.decode("cp1251").splitlines(),delimiter=";"):
        if tag == "B_RADIUS_FIELD":
            label,*coordinates = row
            assert label not in found
            found[label] = coordinates
        if tag == "B_RADIUS_REJECT":
            assert "Rejected" not in found
            found["Rejected"] = row
        if tag == "B_RADIUS_TRIAL" and row[0] == "Quarter":
            found["Quarter"] = row[1:]
    assert set(found) == {"Stall","Full","Rejected","Quarter"}
    assert len(found["Stall"]) == len(found["Full"]) == 60
    return {"point":point,"event_brackets":plan,"reference_raw_fields":found}


def overlay_macro(raw, plan):
    source = raw.decode("utf-8-sig").replace("\r\n","\n")
    src = '''    For Each label In Array("Stall", "Full", "Half", "Quarter")
        Select Case CStr(label)
        Case "Stall": alpha = 0#
        Case "Full": alpha = 1#
        Case "Half": alpha = 0.5
        Case "Quarter": alpha = 0.25
        End Select
'''
    dst = f'''    Const POINT_WITH_EVENTS As Long = {plan["point"]} ' Точка определена независимым разложением исходной невязки.
    Dim testNames As Variant, fractions(0 To 8) As Double, stageNumber As Long
    testNames = Array("Stall", "OldCap", "MinusBefore", "MinusAfter", "CenterBefore", "CenterAfter", "PlusBefore", "PlusAfter", "Quarter")
    fractions(1) = localCap / proposedRadius: fractions(8) = 0.25
'''
    for idx,(tag,side,lo,hi) in enumerate(plan["event_brackets"]):
        dst += f'''    TraceWangYieldEventTest output, "{tag}", operators, materials({side}), POINT_WITH_EVENTS, {side}, stall, proposal, _
        {lo}, {hi}, fractions({2+2*idx}), fractions({3+2*idx})
'''
    dst += '''    For stageNumber = 0 To UBound(testNames)
        label = testNames(stageNumber): alpha = fractions(stageNumber)
'''
    source = switch(source,src,dst)
    source = switch(source,"    Next label\nEnd Sub\n","    Next stageNumber\nEnd Sub\n")
    source = source.rstrip()+"\n\n"+(HERE/"YieldEvents.txt").read_text(encoding="utf-8")
    assert max(map(len,source.splitlines())) < 1023
    return source.replace("\n","\r\n").encode()


def main():
    original = (BASE/"Preparation.json").read_bytes()
    assert digest(original) == PREP
    meta = json.loads(original)
    plan = witness((BASE/"Mechanism.json").read_bytes(),(BASE/"NativeResume/MVT2.csv").read_bytes())
    files = {"FrozenEventPlan.json":put("FrozenEventPlan.json",(json.dumps(plan,indent=2)+"\n").encode())}
    for name,expected in meta["inputs"].items():
        raw = (BASE/name).read_bytes()
        assert digest(raw) == expected
        if name in ("Stage.py","README.txt",VERIFY):
            continue
        if name == MACRO:
            raw = overlay_macro(raw,plan)
        files[name] = put(name,raw)
    for name in ("Stage.py","YieldEvents.txt","README.txt",VERIFY):
        files[name] = digest((HERE/name).read_bytes())
    for folder in ("NativeResume","Temp"):
        (HERE/folder).mkdir(exist_ok=True)
    assert put("docs/regression/Diagnostic.xlsm",(HERE/BOOK).read_bytes()) == meta["book_sha256"]
    meta = {**meta,"inputs":files,"prior_H26_radius_preparation_sha256":PREP,"prior_H26_radius_trace_sha256":TRACE}
    print(put("Preparation.json",(json.dumps(meta,indent=2)+"\n").encode()))


if __name__ == "__main__":
    main()
