"""Assemble and dry replay portable native H26 yield-event receipts."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import AnalyzeEvents
import ReplayYieldPortable as replay

HERE = Path(__file__).resolve().parent
REGRESSION = HERE.parents[1]/"docs/regression/Coupled6D"
RESULT = HERE/"MVT2H26YieldEventBracketsNative20261117.zip"


def main():
    prep = json.loads((HERE/"Preparation.json").read_bytes())
    assert prep["inputs"][replay.BOOK] == prep["book_sha256"] == replay.WORKBOOK
    indexed = {}
    for name,expected in replay.DEPENDENCIES.items():
        path = REGRESSION/name
        assert replay.digest(path.read_bytes()) == expected
        with ZipFile(path) as z:
            for member in z.namelist():
                if not member.casefold().endswith(".xlsm"):
                    indexed.setdefault(replay.digest(z.read(member)),(name,member))
    report = json.loads((HERE/"VerificationYieldEvents.json").read_bytes())
    summary = AnalyzeEvents.summarize(report,HERE/"NativeResume/MVT2.csv")
    (HERE/"YieldEventAnalysis.json").write_bytes((json.dumps(summary,indent=2)+"\n").encode())
    native = tuple(f"NativeResume/{item.name}" for item in (HERE/"NativeResume").iterdir() if item.is_file())
    extra = ("Preparation.json","Compile.log","CompileClosure.json","Run.ndjson","docs/regression/CodeUpdate.json",
             "VerificationYieldEvents.json","AnalyzeEvents.py","YieldEventAnalysis.json","PackYield.py","ReplayYieldPortable.py","PortableREADME.txt")
    items,entries = {},{}
    for member in sorted(set(prep["inputs"]) | set(native) | set(extra)):
        if member == replay.BOOK:
            continue
        raw = (HERE/member).read_bytes()
        digest = replay.digest(raw)
        if member in prep["inputs"]:
            assert digest == prep["inputs"][member]
        prior = indexed.get(digest) if member in prep["inputs"] else None
        if prior:
            name,path = prior
            entries[member] = {"archive":name,"member":path,"sha256":digest}
        else:
            entries[member] = {"sha256":digest}
            items[member] = raw
    manifest = {"workbook":{"path":replay.BOOK,"sha256":replay.WORKBOOK},"archives":replay.DEPENDENCIES,"inputs":entries}
    items["PortableManifest.json"] = (json.dumps(manifest,indent=2)+"\n").encode()
    assert all(not name.casefold().endswith(".xlsm") for name in items)
    with ZipFile(RESULT,"w",compresslevel=9) as z:
        for name,raw in sorted(items.items()):
            info = ZipInfo(name)
            info.compress_type = ZIP_DEFLATED
            z.writestr(info,raw)
    with TemporaryDirectory(dir=HERE/"Temp") as tmp, ZipFile(RESULT) as z:
        assert z.testzip() is None
        z.extractall(tmp)
        subprocess.run((sys.executable,"-B","-X","utf8","ReplayYieldPortable.py","--archives",str(REGRESSION)),cwd=tmp,check=True)
    print(RESULT.name,RESULT.stat().st_size,replay.digest(RESULT.read_bytes()))


if __name__ == "__main__":
    main()
