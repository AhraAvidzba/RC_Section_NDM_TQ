Localize the H26 trial-ray yield events without changing the original stop or committing fields.

    python -B -X utf8 tmp/mv26s/Stage.py
    python -B -X utf8 tmp/mv26s/Verify-MVT2ShearControlled.py --inputs-only

After allocating the isolated Office slot and passing the resource guard, launch once.

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mv26s/Run-MVT2ShearControlled.ps1

Reproduce H26 and the exact optimizer stall/proposal. Use the same archived radius rejection.
Record fraction zero, the old cap, both nearest signed endpoints of each of three candidate
events, and the already measured quarter anchor. The point is selected from the sealed
independent row-53 stress action evidence. Bisect each initial interval up to twelve times
using the original-law signed test yield and read the observed branch on both sides.
Every reported endpoint separately verifies the six efforts, 56 weak rows, four gauges,
physical arc metric and original tolerances. The result explicitly distinguishes a signed
crossing from an unresolved return branch. No solver or material parameters change. The
original optimizer is left intact. Uncommitted probes leave H26 exact, then H24 is restored.
