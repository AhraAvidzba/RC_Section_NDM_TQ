"""Compare near-surface residual changes to the measured inter-event slope."""
from math import fsum

import VerifyBase as v


def summarize(report, native):
    metadata = {r["label"]:r for r in report["measurements"]}
    tags = v.read_native(native)
    raw_rows = v.vec(tags,"B_TANGENT_RESIDUAL")
    native_norm = {name:float(norm) for name,norm in tags["B_BOUND_NORM"]}
    stations = {}
    for label,point,side,*record in tags["B_TANGENT_STATION"]:
        if label in metadata:
            stations[label,int(point),int(side)] = tuple(map(float,record))
    result = []
    for event in report["yield_events"]:
        tag, point = event["label"], event["point"]
        before,after = tag+"Before",tag+"After"
        row_jump = metadata[after]["weak56_MPa"][52]-metadata[before]["weak56_MPa"][52]
        local = [side*(stations[after,point,side][15]-stations[before,point,side][15])*
                 stations[before,point,side][2]/(0.002*v.AREA) for side in (-1,1)]
        result.append({"label":tag,"point":point,"side":event["side"],"return_branch":event["measured_return_branch"],
                       "alpha_interval":event["measured_alpha_interval"],"original_norm_before_over_tau":metadata[before]["full_residual_over_tau"],
                       "original_norm_after_over_tau":metadata[after]["full_residual_over_tau"],
                       "signed_norm_difference_native_MPa":native_norm[after]-native_norm[before],
                       "signed_row53_difference_native_MPa":raw_rows[after][52]-raw_rows[before][52],
                       "signed_row53_difference_reconstructed_MPa":row_jump,
                       "net_point_action_to_row53_difference_MPa":fsum(local),
                       "whole_force_after_over_tau":metadata[after]["force_error_over_tau"]})
    pairs = (("Stall","MinusBefore"),("MinusAfter","CenterBefore"),("CenterAfter","PlusBefore"),("PlusAfter","Quarter"))
    slopes = []
    for a,b in pairs:
        alpha = metadata[b]["correction_fraction"]-metadata[a]["correction_fraction"]
        assert alpha > 0.
        slopes.append({"between":[a,b],"delta_alpha":alpha,
                       "signed_row53_change_MPa":raw_rows[b][52]-raw_rows[a][52],
                       "signed_row53_secant_MPa_per_alpha":(raw_rows[b][52]-raw_rows[a][52])/alpha})
    old_cap = metadata["OldCap"]
    return {"exact_native_trace_sha256": v.digest(native), "original_tolerance_MPa":metadata["Stall"]["original_tolerance_MPa"],
            "old_cap_alpha":old_cap["correction_fraction"],"old_cap_norm_over_tau":old_cap["full_residual_over_tau"],
            "old_cap_six_over_tau":old_cap["force_error_over_tau"],
            "old_cap_relative_norm_reduction":1-native_norm["OldCap"]/native_norm["Stall"],
            "events":result,"whole_row53_slopes":slopes,"qualifying_equilibria":sum(x["status"]=="EquilibriumOnArc" for x in metadata.values())}
