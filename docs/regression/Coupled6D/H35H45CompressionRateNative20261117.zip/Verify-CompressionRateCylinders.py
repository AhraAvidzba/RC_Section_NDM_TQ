"""Сверяет нативные цилиндры с калибровкой и проверяет насыщение в MVT2."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum
from pathlib import Path
from zipfile import ZipFile

from H35CompressionRate import axial_history, predict, solve_rate


MVT2=('MVT2H35CompressionRateNative20261117.zip','994A773813B2A2144B5A2F74DB5BED8115AD387C94730627854B05E0F8B8F0D2')
H35=('H35UnconfinedNative20261117.zip','04D75B624D33A9CBD52FE58538C3C36CB03E1F0947AB2ED7BB94115E53E39C75')
MATERIAL=('MVT2NativePublicationCutMaterialHistory20261117.zip','6920EB24A5D01585E510FDBC1064513C0C83AA62583AEB0C2553D6F0D495EE55')
SWEEP=('MVT2NativePublicationCutDilationSweep20261117.zip','6D10C25C82A02D9C6A25BB568D08C84E3CA808B2D9CF96D9757D47E1928B6355')
CLASS='src/Materials/CCoupledConcreteResponse.cls'


def digest(data):
    return sha256(data).hexdigest().upper()


def open_pinned(evidence,pin):
    path=evidence/pin[0]
    assert digest(path.read_bytes())==pin[1]
    return ZipFile(path)


def elastic(strain,modulus,poisson):
    mu=modulus/(2.*(1.+poisson))
    lam=modulus*poisson/((1.+poisson)*(1.-2.*poisson))
    trace=fsum(strain[:3])
    return (*[2.*mu*x+lam*trace for x in strain[:3]],*[mu*x for x in strain[3:]])


def saturation(model,log,history):
    """Численно отделяет влияние вклада сжатия до и после ограничения меры K."""
    records={}
    for row in log.splitlines():
        if not row.startswith('MVT2_NATIVE_MATERIAL;'):
            continue
        _,tag,point,*raw=row.split(';')
        values=tuple(map(float,raw))
        assert len(values)==26
        phase=history[int(tag[8:])-1]
        e=elastic(tuple(a-b for a,b in zip(values[:6],values[12:18],strict=True)),30000.,.2)
        principal=model['principal'](e)
        r=fsum(s for s in principal if s>0.)/fsum(map(abs,principal))
        kt,kc=values[-2:]
        ku=kc/(kc+.241*(1.-kc))
        tension=(1.+20.*r)*kt
        compact=lambda comp:1.-(1.-tension)*(1.-(1.-r)*comp)
        old,new=compact(kc),compact(ku)
        records.setdefault(phase,{})[int(point)]={'r':r,'kt':kt,'kc':kc,'unclamped_stock':old,
                                                 'unclamped_adjusted':new,'clamped_difference':min(1.,new)-min(1.,old)}
    assert len(records)==6 and all(len(points)==3 for points in records.values())
    assert all(r['unclamped_stock']>1. and r['unclamped_adjusted']>1. and r['clamped_difference']==0.
               for phase,points in records.items() if phase!='R8' for r in points.values())
    assert all(abs(r['clamped_difference']) < .002 for r in records['R8'].values())
    return records


def first_run(root,read):
    """Проверяет отказ без дробления и завершение принадлежащего книге процесса."""
    folder=root/'WithoutSubdivision'
    owner=read(folder/'MVTGaussMixed.txt.Ownership.json')
    closure=read(folder/'MVTGaussMixed.txt.ProcessClosure.json')
    identity=closure['Closure']['Identity']
    assert owner['VerifiedNewOwner'] and closure['Passed'] and closure['ChildExitCode']==1
    assert identity['Valid'] and identity['PID']==owner['PID'] and identity['Ticks']==int(owner['StartTicksUTC'])
    assert closure['Closure']['FinalState']['State']=='Absent'
    transcript=(folder/'MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'COMPRESSION_RATE_FREE_LATERAL;H35;1100' in transcript
    offending,=[row for row in transcript.splitlines() if row.startswith('RUNTIME ERROR:')]
    assert 'путь H45, шаг 801.' in offending
    tail=offending.split('Ширина скобки ')[1]
    width,residuals=tail.split(', невязки ')
    lo,hi=map(float,residuals.removesuffix(' МПа.').split(' и '))
    assert lo<-1e-7 and hi>1e-7 and float(width)<2e-19
    return {'lower_residual_MPa':lo,'upper_residual_MPa':hi,'strain_bracket':float(width),'excel_pid':owner['PID']}


def verify(repo,root):
    evidence=repo/'docs/regression/Coupled6D'
    hist,sweep={'__name__':'__pinned__'},{'__name__':'__pinned__'}
    with open_pinned(evidence,MATERIAL) as z:
        exec(compile(z.read('Verify-NativeMaterialHistory.py'),MATERIAL[0],'exec'),hist)
        base=z.read(CLASS)
        snapshot=z.read('Native/MVTGaussMixed.txt').decode('utf-8-sig')
        history=[row.split(';')[0] for row in z.read('Replay.Fields.csv').decode('ascii').splitlines()]
    with open_pinned(evidence,SWEEP) as z:
        exec(compile(z.read('Verify-DilationSweep.py'),SWEEP[0],'exec'),sweep)
    with open_pinned(evidence,H35) as z:
        h35=json.loads(z.read('H35Targets.json'))
    with open_pinned(evidence,MVT2) as z:
        h45=json.loads(z.read('H45RateTargets.json'))
        candidate=z.read(CLASS).decode('utf-8')
    added,=[line for line in candidate.splitlines() if line.startswith('    kc = kc / ')]
    assert (root/CLASS).read_bytes()==base.replace(b'    mixed = ',added.encode('utf-8')+b'\r\n    mixed = ',1)
    prep=hist['read'](root/'Preparation.json')
    for name in (CLASS,'tests/modTestMVT2GaussSpan.bas','Run-Native.ps1'):
        assert digest((root/name).read_bytes())==prep['inputs'][name]
    assert prep['compression_dilation_rate']=='0.241' and prep['specimen']==['H35_01','H45_08']
    pid,log=sweep['check_process'](root,hist['BOOK'],hist)
    reference=solve_rate(repo,h45)
    assert reference['compression_rate']==.241
    models,rows={},{}
    for row in (root/'Native/UnconfinedH35.csv').read_text('ascii').splitlines():
        kind,key,*data=row.split(';')
        if kind=='MODEL':
            assert key not in models and len(data)==10
            models[key]=tuple(map(float,data))
            rows[key]=[]
        else:
            assert kind=='STEP' and len(data)==27 and int(data[0])==len(rows[key])+1
            rows[key].append(tuple(map(float,data[1:])))
    assert tuple(models)==('H35','H45')
    proof={}
    for key,physical in (('H35',h35),('H45',h45)):
        exact,history_rows=axial_history(physical)
        assert max(abs(a-b) for a,b in zip(models[key],exact,strict=True))<1e-11
        control=[{'lateral_expansion':0.,'axial_compression':row[0]} for row in history_rows]
        expected=predict(exact,history_rows,.241,control)['sample'][1:]
        assert len(rows[key])==len(expected)
        count,sub=next(slice.split(';')[2:] for slice in log.splitlines()
                       if slice.startswith('COMPRESSION_RATE_FREE_LATERAL;'+key+';'))
        assert int(count)==len(expected) and int(sub)>=int(count)
        diff_x,diff_y,res=0.,0.,0.
        for i,(state,oracle) in enumerate(zip(rows[key],expected,strict=True),1):
            sx,sy,sz=state[6:9]
            res=max(res,abs(sx),abs(sy))
            assert abs(state[2]+oracle['axial_compression'])<5e-16 and state[0]==state[1]
            diff_x=max(diff_x,abs(-sz-oracle['predicted_stress_MPa']))
            diff_y=max(diff_y,abs(state[0]-oracle['predicted_lateral']))
        assert res<1e-7 and diff_x<1e-5 and diff_y<2e-7
        proof[key]={'written_steps':int(count),'accepted_steps':int(sub),
                    'maximum_axial_stress_difference_MPa':diff_x,'maximum_lateral_strain_difference':diff_y,
                    'maximum_normal_residual_MPa':res}
    return {'native':proof,'excel_pid':pid,'without_subdivision':first_run(root,hist['read']),
            'MVT2_saturation':saturation(hist,snapshot,history)}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args()
    result=verify(args.repo.resolve(),args.root.resolve())
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(result,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('H35 H45 COMPRESSION RATE NATIVE OFFLINE PASS',sum(row['written_steps'] for row in result['native'].values()))
