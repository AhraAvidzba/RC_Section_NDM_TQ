"""Проверяет перенос ускоренной дилатансии со свободного H35 на H45."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import sqrt
from pathlib import Path
from statistics import fmean
from zipfile import ZipFile

from H35ScalarOracle import concrete_envelope, lateral_ratio, stresses


H35_ARCHIVE = 'H35UnconfinedNative20261117.zip'
H35_SHA = '04D75B624D33A9CBD52FE58538C3C36CB03E1F0947AB2ED7BB94115E53E39C75'
H45_AXIAL = (.00025,.0005,.00075,.001,.00125,.0015,.00175,.002,.0021,.0022,.0023,.0025,.00275,.003,.00325,.0035,.0037)
LENGTH = 116.24473515096261
STEP = 2.5e-6


def calculate_targets(repo):
    """Извлекает H45_08 из тех же экспериментальных графиков, что H35_01."""
    import fitz
    from runpy import run_path

    digitizer = run_path(str(Path(__file__).resolve().parent/'Digitize-OsorioH35.py'))
    thesis = repo / digitizer['SOURCE']
    assert sha256(thesis.read_bytes()).hexdigest().upper() == digitizer['SOURCE_SHA']
    line_at = digitizer['ordinate']
    with fitz.open(thesis) as doc:
        overview,stress,volume=(doc[i].get_drawings() for i in (55,67,68))
    sx, sy = stress[10]['items'], stress[8]['items']
    sv, vx = volume[38]['items'], volume[40]['items']
    x0, x_scale = sx[12][1].x, .012/(sx[24][1].x-sx[0][1].x)
    y0, y_scale = sy[0][1].y, 80./(sy[0][1].y-sy[16][1].y)
    vx0, vx_scale = vx[0][1].x, .004/(vx[20][1].x-vx[0][1].x)
    vy0, vy_scale = sv[10][1].y, .004/(sv[20][1].y-sv[0][1].y)
    sigma = [((p.x-x0)*x_scale,(y0-p.y)*y_scale) for p in digitizer['trace'](stress,(14,15))]
    assert volume[43]['dashes'] == volume[50]['dashes'] and len(volume[43]['items']) == 600
    h45_volume=volume[43]|{'dashes':'[] 0'}
    vline=[((p.x-vx0)*vx_scale,(vy0-p.y)*vy_scale) for p in digitizer['trace']([h45_volume],(0,))]
    ox,oy=overview[10]['items'],overview[8]['items']
    o_x0,o_xs=ox[20][1].x,.02/(ox[20][1].x-ox[0][1].x)
    o_y0,o_ys=oy[0][1].y,100./(oy[0][1].y-oy[20][1].y)
    plot_paths=overview[14:16]
    assert all(len(p['items'])>500 and p['dashes'].startswith('[ 1.') for p in plot_paths)
    other=[((p.x-o_x0)*o_xs,(o_y0-p.y)*o_ys)
           for p in digitizer['trace']([row|{'dashes':'[] 0'} for row in plot_paths],(0,1))]
    other_lat=[(s,-x) for x,s in other if x<0.]
    other_summit=max(range(len(other_lat)),key=lambda i:other_lat[i][0])
    # Фильтруем обратные шумовые пересечения по ветви относительно пика.
    ep, fc = max((row for row in sigma if row[0] > 0.), key=lambda row:row[1])
    lateral = [(s,-axial) for axial,s in sigma if axial < 0.]
    summit = max(range(len(lateral)),key=lambda i:lateral[i][0])
    stressline = [(x,s) for x,s in sigma if x > 0.]
    assert .0018 < ep < .0022 and 46. < fc < 48.
    table = []
    for x in H45_AXIAL:
        s, spread = line_at(stressline,x)
        branch = lateral[:summit+1] if x > ep else lateral[summit:]
        y, spread_y = line_at(branch,min(s,max(s for s,_ in branch)-1e-8))
        crosscheck = None
        if x <= .0023:
            v, spread_v = line_at(vline,x)
            crosscheck = {'lateral_expansion':(v+x)/2.,'graphic_spread':spread_v/2.}
            assert abs(crosscheck['lateral_expansion']-y) < 5e-5
        alt_branch=other_lat[:other_summit+1] if x>ep else other_lat[other_summit:]
        alt_y,alt_spread=line_at(alt_branch,min(s,max(s for s,_ in alt_branch)-1e-8))
        assert abs(alt_y-y) < 5e-5
        table.append({'axial_compression':x,'compressive_stress_MPa':s, 'lateral_expansion':y,
                      'axial_graphic_spread_MPa':spread,'lateral_graphic_spread':spread_y, 'volume_plot_check':crosscheck,
                      'figure_3_4_lateral_expansion':alt_y,'figure_3_4_graphic_spread':alt_spread})
    return {'specimen':'H45_08','approximate_peak_MPa':fc,'approximate_peak_axial_compression':ep,
            'source_sha256':digitizer['SOURCE_SHA'],'checkpoints':table}


def axial_history(specimen):
    """Фиксирует одноосное сжатие до сравнения законов объёмного течения."""
    fc = round(specimen['approximate_peak_MPa'],2)
    peak = round(specimen['approximate_peak_axial_compression'],6)
    early=specimen['checkpoints'][:2]
    norm=sum(a['axial_compression']**2 for a in early)
    slope=sum(a['axial_compression']*a['compressive_stress_MPa'] for a in early)/norm
    lateral=sum(a['axial_compression']*a['lateral_expansion'] for a in early)/norm
    modulus,nu=round(slope),round(lateral,2)
    ft=.302*fc**(2./3.); gt=.073*fc**.18; gc=(fc/ft)**2*gt
    model=(32.,modulus,nu,LENGTH,STEP,fc,peak,ft,gt,gc)
    envelope=concrete_envelope(model)
    history=[(0.,0.,0.,0.,0.)]
    p_old=0.
    for i in range(1,round(specimen['checkpoints'][-1]['axial_compression']/STEP)+1):
        x=i*STEP
        if x*modulus <= envelope[0]:
            history.append((x,x*modulus,x*modulus,0.,0.))
            continue
        low,high=p_old,x
        for _ in range(54):
            p=.5*(low+high)
            if p+stresses(p,envelope)[1]/modulus < x:
                low=p
            else:
                high=p
        stress,eff,energy=stresses(p,envelope)
        history.append((x,stress,eff,energy,p-p_old))
        p_old=p
    return model,history


def predict(model, history, rate, measured):
    """Вводит степень развития потока с сохранением концов исходной меры энергии."""
    angle, modulus, nu, _, step, _, _, ft, _, _ = model
    lateral_p=0.
    selected={round(r['axial_compression']/step):r for r in measured}
    metrics=[]
    zero=None
    prev=(0.,0.)
    for i,(x,sigma,eff,kc,increment) in enumerate(history):
        if increment:
            mapped=kc/(kc+rate*(1.-kc))
            lateral_p+=increment*lateral_ratio(eff,mapped,ft,angle)
        lateral=nu*eff/modulus+lateral_p
        volume=2.*lateral-x
        if zero is None and prev[1]<0.<=volume:
            zero=prev[0]+(x-prev[0])*(-prev[1])/(volume-prev[1])
        prev=(x,volume)
        if i in selected:
            metrics.append(selected[i] | {'predicted_lateral':lateral,'predicted_volume':volume,'predicted_stress_MPa':sigma})
    rms=sqrt(fmean((p['lateral_expansion']-p['predicted_lateral'])**2 for p in metrics))
    return {'lateral_RMS':rms,'zero_volume_axial':zero,'sample':metrics}


def solve_rate(repo, held):
    """Калибрует коэффициент по H35 и оценивает перенос на отдельный H45."""
    pinned=repo/'docs/regression/Coupled6D'/H35_ARCHIVE
    assert sha256(pinned.read_bytes()).hexdigest().upper()==H35_SHA
    with ZipFile(pinned) as package:
        base=json.loads(package.read('H35Targets.json'))
    m35,h35=axial_history(base)
    m45,h45=axial_history(held)
    errors={j:predict(m35,h35,j/1000.,base['checkpoints'])['lateral_RMS'] for j in range(100,1001)}
    index=min(errors,key=errors.get)
    assert 100<index<1000
    rate=index/1000.
    results={name:{'stock':predict(model,hist,1.,specimen['checkpoints']),
                   'modified':predict(model,hist,rate,specimen['checkpoints']), 'model':model}
             for name,model,hist,specimen in (('H35',m35,h35,base),('H45',m45,h45,held))}
    return {'compression_rate':rate,'rate_grid':[.1,1.,.001], 'results':results}


def dump(path,data):
    with path.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(data,output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--targets', required=True, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args=parser.parse_args()
    if args.targets.exists():
        data=json.loads(args.targets.read_bytes())
    else:
        data=calculate_targets(args.repo.resolve())
        dump(args.targets,data)
    dump(args.report,solve_rate(args.repo.resolve(),data))
    print('H35 COMPRESSION RATE AND H45 HOLDOUT PASS')
