"""Вычисляет два свободных цилиндра при коэффициенте дилатансии 0,241 в VBA."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent


def stage(repo, root):
    base = run_path(str(HERE/'Stage-UnconfinedH35.py'))
    base['stage'](repo,root,False)
    candidate = run_path(str(HERE/'Stage-CompressionRateMVT2.py'))
    material = root / candidate['CLASS']
    material.write_bytes(candidate['material_wire'](material.read_bytes()))
    test = root / candidate['TEST']
    text = test.read_text(encoding='utf-8-sig')
    start = text.index('    Const FC As Double = 36.24, PEAK As Double = 0.001663')
    finish = text.index('    Dim path As Variant, material As CCoupledConcreteResponse',start)
    text = text[:start] + '''    Const CYLINDER_LENGTH As Double = 116.244735150963
    Dim fc As Double, peak As Double, ft As Double, gt As Double, gc As Double
    Dim paths As Variant
    paths = Array(Array("H35", 32#, 35195#, 0.3, CYLINDER_LENGTH, 0.0000025, 36.24, 0.001663, 0.00275), _
                  Array("H45", 32#, 38255#, 0.3, CYLINDER_LENGTH, 0.0000025, 47.07, 0.001965, 0.0037))
''' + text[finish:]
    old = '    For Each path In paths\n        Set material = New CCoupledConcreteResponse'
    assert text.count(old)==1
    new = '''    For Each path In paths
        fc = CDbl(path(6)): peak = CDbl(path(7))
        ft = 0.302 * fc ^ (2# / 3#): gt = 0.073 * fc ^ 0.18: gc = (fc / ft) ^ 2 * gt
        Set material = New CCoupledConcreteResponse'''
    text=text.replace(old,new).replace('CLng(0.00275 / stepSize)','CLng(CDbl(path(8)) / stepSize)')
    text=text.replace('H35_FREE_LATERAL;','COMPRESSION_RATE_FREE_LATERAL;')
    node = text.index('Private Function TestUnconfinedH35(')
    prefix, text = text[:node], text[node:]
    text=text.replace('lateral = 0#\n        For stepIndex',
                      'lateral = 0#\n        Dim acceptedSteps As Long: acceptedSteps = 0\n        For stepIndex')
    call = ('            strain(3) = -axial\n'
            '            If Not TestFindFreeLateralH35(material, strain, stress, lateral, stepSize, diagnostic) Then _')
    assert text.count(call)==1 and text.count('            material.AcceptOutputPoints\n')==1
    text=text.replace(call,
        '            If Not TestAdvanceFreeLateral(material, strain, stress, lateral, (stepIndex - 1) * stepSize, axial, _\n'
        '                    0, acceptedSteps, diagnostic) Then _')
    text=text.replace('            material.AcceptOutputPoints\n','')
    text=text.replace('CStr(path(0)) & ";" & CStr(stepCount)\n',
                      'CStr(path(0)) & ";" & CStr(stepCount) & ";" & CStr(acceptedSteps)\n')
    text=prefix+text+(HERE/'CylinderSubdivision.bas.txt').read_text(encoding='utf-8')
    text.encode('cp1251')
    test.write_bytes(text.replace('\n','\r\n').encode('utf-8-sig'))
    meta = root/'Preparation.json'
    prep=json.loads(meta.read_bytes())
    prep['specimen']=['H35_01','H45_08']
    prep['compression_dilation_rate']=candidate['RATE']
    for path in (test,material):
        prep['inputs'][path.relative_to(root).as_posix()]=candidate['digest'](path.read_bytes())
    meta.write_bytes((json.dumps(prep,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',required=True,type=Path)
    args=parser.parse_args()
    stage(args.repo.resolve(),args.stage.resolve())
