"""Проверяет на MVT2 закон дилатансии, калиброванный на свободном цилиндре H35."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent
CLASS = 'src/Materials/CCoupledConcreteResponse.cls'
TEST = 'tests/modTestMVT2GaussSpan.bas'
RATE = '0.241'


def digest(data):
    return sha256(data).hexdigest().upper()


def material_wire(raw):
    """Ускоряет только вклад энергии сжатия в угол дилатансии."""
    source = raw.decode('utf-8').replace('\r\n','\n')
    anchor = '    mixed = 1# - (1# - (1# + MIXED_DAMAGE_WEIGHT * r) * kt) * (1# - (1# - r) * kc)'
    assert source.count(anchor) == 1
    source = source.replace(anchor, '    kc = kc / (kc + 0.241 * (1# - kc)) ' +
                            "' Коэффициент сжатия по отдельному опыту H35.\n" + anchor)
    return source.replace('\n','\r\n').encode('utf-8')


def stage(repo,root):
    prescript=run_path(str(HERE/'Stage-DilationEquilibrium.py'))
    prescript['stage'](repo,root,26)
    test = root / TEST
    text = test.read_text(encoding='utf-8-sig')
    assert text.count(', dilation:=26#') == 4
    text=text.replace(', dilation:=26#','')
    old='If branch.SavedFieldCount <> 8 Or twist <= 0# Then _'
    assert text.count(old)==1
    text=text.replace(old,'If branch.SavedFieldCount < 7 Or twist <= 0# Then _')
    old='"MVT_PRELOAD_END;8;10.51"'
    assert text.count(old)==1
    text=text.replace(old,'"MVT_PRELOAD_END;" & CStr(branch.SavedFieldCount) & ";10.51"')
    test.write_bytes(text.replace('\n','\r\n').encode('utf-8-sig'))
    material=root/CLASS
    original=(repo/CLASS).read_bytes()
    assert digest(original)=='92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C'
    material.parent.mkdir(parents=True,exist_ok=True)
    material.write_bytes(material_wire(original))
    driver = root / 'Run-Native.ps1'
    body=driver.read_text(encoding='utf-8')
    list_anchor="'CCoupledElasticState','modTestMVT2GaussSpan'"
    assert body.count(list_anchor)==1
    driver.write_bytes(body.replace(list_anchor,list_anchor+",'CCoupledConcreteResponse'").encode())
    prep_path=root/'Preparation.json'
    data=json.loads(prep_path.read_bytes())
    data['dilation_max_degrees']=32
    data['compression_dilation_rate']=RATE
    data['material_base_sha256']=digest(original)
    for path in (test,material,driver):
        data['inputs'][path.relative_to(root).as_posix()]=digest(path.read_bytes())
    prep_path.write_bytes((json.dumps(data,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',required=True,type=Path)
    args=parser.parse_args()
    stage(args.repo.resolve(),args.stage.resolve())
