"""Независимое осесимметричное решение свободного сжатия для модели НДМ."""

from math import exp, log1p, radians, sin, sqrt


def concrete_envelope(model):
    """Вычисляет параметры экспоненциальной ветви и энергию до пика."""
    modulus, _, length, _, fc, peak, _, _, gc = model[1:]
    fc0 = .6 * fc
    peak_damage = .423 * (1. - fc / (modulus * peak))
    p_peak = peak - fc / ((1. - peak_damage) * modulus)
    energy = gc / length
    hardening = (fc - fc0) / p_peak
    prepeak = .5 * (fc0 + fc) * p_peak
    softening = fc / (energy - prepeak)
    damage_rate = -log1p(-peak_damage) / p_peak
    return fc0, fc, p_peak, energy, hardening, prepeak, softening, damage_rate


def stresses(p, envelope):
    """Возвращает номинальное напряжение, сцепление и меру энергии сжатия."""
    fc0, fc, p_peak, energy, hardening, prepeak, softening, damage_rate = envelope
    if p <= p_peak:
        sigma = fc0 + hardening * p
        used = .5 * (fc0 + sigma) * p
    else:
        nominal_ratio = exp(-softening * (p-p_peak))
        sigma = fc * nominal_ratio
        used = prepeak + fc * (1. - nominal_ratio) / softening
    return sigma, sigma * exp(damage_rate * p), used / energy


def lateral_ratio(effective, ratio, ft, angle):
    """Вычисляет приращение поперечной пластики на единицу осевого сжатия."""
    friction = sin(radians(65.))
    dilation_peak = sin(radians(angle))
    constant_volume = (friction-dilation_peak) / (1.-friction*dilation_peak)
    current = 2.*sqrt(ratio)*friction/(1.+ratio)
    alpha = 0.
    if current > constant_volume:
        dilation = (current-constant_volume)/(1.-constant_volume*current)
        alpha = dilation/sqrt(1.-dilation*dilation)
    h = sqrt((.1*alpha*ft)**2+2.*effective*effective/3.)
    dif = effective/(3.*h)
    assert 2.*dif > alpha
    return (dif+alpha)/(2.*dif-alpha)


def curve(model):
    """Решает скалярное уравнение осевой деформации на каждом точном шаге."""
    angle, modulus, nu, _, step, _, _, ft, _, _ = model
    envelope = concrete_envelope(model)
    p_old = lateral_plastic = 0.
    rows = [(0., 0., 0.)]
    for i in range(1, round(.00275/step) + 1):
        axial = i*step
        if axial*modulus <= envelope[0]:
            rows.append((axial, axial*modulus, axial*nu))
            continue
        low, high = p_old, axial
        for _ in range(58):
            p = .5*(low+high)
            _, effective, _ = stresses(p, envelope)
            if p+effective/modulus < axial:
                low = p
            else:
                high = p
        nominal, effective, ratio = stresses(p, envelope)
        lateral_plastic += lateral_ratio(effective, ratio, ft, angle)*(p-p_old)
        rows.append((axial, nominal, nu*effective/modulus+lateral_plastic))
        p_old = p
    return rows
