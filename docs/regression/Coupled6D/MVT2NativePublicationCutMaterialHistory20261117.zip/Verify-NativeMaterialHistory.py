"""Сверяет историю НДМ и отделяет объёмный вклад пластической деформации."""

from argparse import ArgumentParser
from hashlib import sha256
from math import acos, cos, fsum, pi, sqrt
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile
import json


REFERENCE = 'MVT2NativePublicationCutTimed20261117.zip'
REFERENCE_SHA = 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A'
ASD = 'MVT2Cut396MaterialPredictor20261117.zip'
ASD_SHA = '9371CDC9B169CEDDE05776280399C2676F776033DC12F01F0F7C572C1031EF55'
SOURCE = 'src/Materials/CCoupledConcreteResponse.cls'
SOURCE_SHA = '92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C'
SOURCE_REVISION = '8a1e81fbc657cb135eb9e8776fbd5a026dd91079'
BOOK = '97F184A3FAF2419A083F4370CF374C45631CA387B2E5AC77426AF3E7A1ACB9A5'
CANDIDATE = '800AAB47AFDCD5E5DC4C27BDBA3D336DE17D2B466B5EF558D427C5EFC2743C32'


def digest(wire):
    return sha256(wire).hexdigest().upper()


def pinned(directory, label, hash_value):
    file = directory / label
    assert digest(file.read_bytes()) == hash_value
    return ZipFile(file)


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def principal(raw):
    """Решает кубическое характеристическое уравнение симметричного тензора."""
    x, y, z, xy, xz, yz = raw
    mean = fsum((x,y,z)) / 3.
    a,b,c = x-mean,y-mean,z-mean
    scale = sqrt(fsum((a*a,b*b,c*c,2*xy*xy,2*xz*xz,2*yz*yz))/6.)
    if scale == 0.:
        return mean,mean,mean
    det = (a*(b*c-yz*yz)-xy*(xy*c-yz*xz)+xz*(xy*yz-b*xz)) / scale**3
    phase = acos(max(-1.,min(1.,det/2.)))/3.
    top = mean+2.*scale*cos(phase)
    low = mean+2.*scale*cos(phase+2.*pi/3.)
    return low,3.*mean-top-low,top


def accepted_wire(frame, point, data, elastic, previous):
    """Повторяет упругий прогноз, поправку объёма и связь с номинальным тензором."""
    total, nominal, plastic = data[:6], data[6:12], data[12:18]
    tension, compression, tension_cohesion, compression_cohesion, dt, dc, kt, kc = data[18:]
    ref = frame[point]
    strain_error = max(abs(a-b) for a,b in zip(total,ref[:6],strict=True))
    stress_error = max(abs(a-b) for a,b in zip(nominal,ref[6:],strict=True))
    assert strain_error < 3e-16 and stress_error < 5e-12
    assert tension >= 0. and compression >= 0.
    assert all(0. <= value < 1. for value in (dt,dc,kt,kc))
    stock = elastic(total, 30000., .2)
    effective = elastic(tuple(a-b for a,b in zip(total,plastic,strict=True)), 30000., .2)
    high_low = principal(effective)
    denominator = fsum(map(abs, high_low))
    positive = fsum(x for x in high_low if x > 0.)/denominator if denominator else 0.
    damage = (1.-positive*dt)*(1.-dc)
    nominal_error = max(abs(a-b*damage) for a,b in zip(nominal,effective,strict=True))
    assert nominal_error < 7e-11
    eps_volume = fsum(plastic[:3])
    mean_change = -30000./(3.*(1.-2.*.2))*eps_volume
    raw_min, effective_min = principal(stock)[0], high_low[0]
    result = {'E_total_min_principal_MPa':raw_min,'effective_min_principal_MPa':effective_min,
              'nominal_min_principal_MPa':principal(nominal)[0],'plastic_volume':eps_volume,
              'hydrostatic_translation_MPa':mean_change,'deviator_minimum_translation_MPa':
                  effective_min-raw_min-mean_change,'tensile_damage':dt,'compression_damage':dc,
              'archived_strain_error':strain_error,'archived_stress_error_MPa':stress_error,
              'nominal_recovery_error_MPa':nominal_error}
    if previous is not None:
        pre = elastic(tuple(a-b for a,b in zip(total,previous[12:18],strict=True)), 30000., .2)
        result['effective_predictor_min_MPa'] = principal(pre)[0]
    return result


def verify(repo, root):
    artifacts = repo / 'docs/regression/Coupled6D'
    utility, asd = {'__name__':'__pinned__'}, {'__name__':'__pinned__'}
    with pinned(artifacts, REFERENCE, REFERENCE_SHA) as old:
        exec(compile(old.read('Verify-NativePublicationCut.py'),REFERENCE,'exec'),utility)
        frames = utility['read_tensor_frames'](old.read('Native/MVTGaussMixed.Tensor.csv'),45)
        operators = utility['read_operators'](old.read('Native/Operators.csv'))
    with pinned(artifacts, ASD, ASD_SHA) as material:
        exec(compile(material.read('Check-Cut396Material.py'),ASD,'exec'),asd)
        published = json.loads(material.read('Cut396MaterialProof.json'))['comparisons_at_Qy_20_kN']['default']
    prep = read(root/'Preparation.json')
    assert prep['material_base_sha256'] == SOURCE_SHA
    baseline = (repo/SOURCE).read_bytes()
    if digest(baseline) != SOURCE_SHA:
        baseline = check_output(['git','cat-file','blob',f'{SOURCE_REVISION}:{SOURCE}'],cwd=repo).replace(b'\n',b'\r\n')
    assert digest(baseline) == SOURCE_SHA
    expected = baseline.decode('utf-8').replace('\r\n','\n') + (root/'MaterialHistoryMethod.cls.txt').read_text(encoding='utf-8')
    assert expected == (root/SOURCE).read_text(encoding='utf-8')
    for file in (SOURCE,'tests/modTestMVT2GaussSpan.bas','Replay.Fields.csv'):
        assert digest((root/file).read_bytes()) == prep['inputs'][file]
    history = [row.split(';') for row in (root/'Replay.Fields.csv').read_text('ascii').splitlines()]
    assert len(history) == 22 and [row[0] for row in history] == list(operators['F'])
    for phase,q,t,*values in history:
        assert tuple(map(float,values)) == operators['F'][phase] and (float(t),float(q)) == frames[phase][:2]

    native = root/'Native'
    compiler = read(root/'CodeUpdate.json')
    owner = read(native/'MVTGaussMixed.txt.Ownership.json')
    closure = read(native/'MVTGaussMixed.txt.ProcessClosure.json')
    identity = closure['Closure']['Identity']
    assert compiler['Compiled'] and compiler['ProductionSHA256'] == BOOK and not compiler['ProductionChanged']
    assert compiler['WorkbookSHA256'] == owner['SourceSHA256'] == CANDIDATE
    assert set(compiler['Modules']) == {'CCoupledConcreteResponse','CCoupledElasticState','CCoupledSectionQuadrature','modTestMVT2GaussSpan'}
    assert read(root/'CompileClosure.json')['State'] == 'Absent'
    assert owner['VerifiedNewOwner'] and identity['Valid'] and identity['PID'] == owner['PID']
    assert int(owner['StartTicksUTC']) == identity['Ticks']
    assert closure['Passed'] and closure['RunnerCleanupValid'] and closure['ChildExitCode'] == 0
    assert closure['Closure']['FinalState']['State'] == 'Absent'
    transcript = (native/'MVTGaussMixed.txt').read_text('utf-8-sig')
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in transcript
    rows = [line.split(';') for line in transcript.splitlines() if line.startswith('MVT2_NATIVE_MATERIAL;')]
    expected_keys = [(i,p) for i in (8,18,19,20,21,22) for p in (11,14,15)]
    assert [(int(row[1][8:]),int(row[2])) for row in rows] == expected_keys
    history_data = {(int(row[1][8:]),int(row[2])):tuple(map(float,row[3:])) for row in rows}
    assert all(len(data) == 26 for data in history_data.values())
    proof = {}
    for (index,point), values in history_data.items():
        base_tag = history[index-1][0]
        proof.setdefault(base_tag,{})[point] = accepted_wire(frames[base_tag][2],point,values,asd['elastic'],
                                                             history_data.get((index-1,point)))
    for point in (14,15):
        row = proof['S9'][point]
        assert row['E_total_min_principal_MPa'] > 0. > row['effective_predictor_min_MPa']
        assert row['effective_min_principal_MPa'] < row['effective_predictor_min_MPa']
        assert row['hydrostatic_translation_MPa'] < 0. < row['deviator_minimum_translation_MPa']
        assert row['compression_damage'] < .04
        assert published[str(point)]['history']['effective_predictor_principal_MPa'][0] > 0.
    return {'NDM':proof,'ASD_reference_Q20':published,'excel_closed_pid':owner['PID'],
            'distinguishes_hydrostatic_and_deviatoric_terms':True,'physical_limit_established':False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',type=Path,required=True)
    args = parser.parse_args()
    result = verify(args.repo.resolve(),args.root.resolve())
    with args.report.open('x',encoding='utf-8',newline='\n') as out:
        json.dump(result,out,indent=2,sort_keys=True,allow_nan=False)
        out.write('\n')
    print('MVT2 NATIVE MATERIAL HISTORY OFFLINE PASS 18')
