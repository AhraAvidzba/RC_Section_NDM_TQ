"""Replay the saturated tensile-apex material return on native Kani station tensors."""
from pathlib import Path
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
import csv,json,math,sys
import numpy as np

H=Path(__file__).resolve().parent
E, NU, FC, FT, EPS0, L = 25600., .2, 28.2, 1.75, .0022, 125.
G2=E/(1.+NU)
P=E/(1.-2.*NU)
alpha=.12
dilation_limit=math.radians(32.)
offset_per_dilation=.1*FT
band=1.e-12*FC
ft_energy=.073*FC**.18/L
fc_energy=(FC/FT)**2*ft_energy
dc_at_peak=.423*(1.-FC/(E*EPS0))
p_at_peak=EPS0-FC/((1.-dc_at_peak)*E)
fc0=.6*FC
ascending=.5*(fc0+FC)*p_at_peak
hardening=(FC-fc0)/p_at_peak
tension_rate=FT/ft_energy
eye=np.eye(3)

def norm(x):return float(np.max(abs(x)))

def matrix(values):
    x,y,z,xy,xz,yz=values
    return np.array([[x,xy,xz],[xy,y,yz],[xz,yz,z]])

def vector(m):return m[0,0],m[1,1],m[2,2],m[0,1],m[0,2],m[1,2]

def elastic(delta):
    x,y,z,xy,xz,yz=delta
    d=matrix((x,y,z,.5*xy,.5*xz,.5*yz))
    return G2*d+eye*(P-G2)*(x+y+z)/3.

def invariant(s):
    t=np.trace(s)
    d=s-eye*t/3.
    vals=np.linalg.eigvalsh(d)
    return float(t),d,float(math.sqrt(1.5*np.sum(d*d))),float(vals[-1]),float(vals[0])

def compression_history(kc):
    energy=kc*fc_energy
    if energy<=ascending:
        p=2.*energy/(fc0+math.sqrt(fc0**2+2.*hardening*energy))
        sigma=fc0+hardening*p
    else:
        remaining=(fc_energy-energy)/(fc_energy-ascending)
        p=p_at_peak-math.log(remaining)*(fc_energy-ascending)/FC
        sigma=FC*remaining
    one_minus_dc=math.exp(math.log(1.-dc_at_peak)*p/p_at_peak)
    return sigma/one_minus_dc,one_minus_dc

def parameters(base_nominal,kt,kc):
    if not (1.<=21.*kt and kt<1.):raise ValueError("TensionEnergyNotInSaturatedDilationRegime")
    cc,one_minus_dc=compression_history(kc)
    beta=(1.-alpha)*cc/FT-(1.+alpha)
    slope=alpha+beta/3.
    apex=(1.-alpha)*cc/slope
    a=(1.-kt)*one_minus_dc
    base=base_nominal/a
    if np.linalg.eigvalsh(base)[0]<=0.:raise ValueError("NotAllTension")
    return base,cc,beta,slope,apex,a

def return_apex(base_nominal,kt,kc,deps):
    base,cc,beta,slope,apex,a=parameters(base_nominal,kt,kc)
    trial=base+elastic(deps)
    tr,d,q,high,low=invariant(trial)
    if tr/3.+low<=0.:raise ValueError("TrialMixed")
    predictor=(slope*tr+q+beta*high)/(1.-alpha)-cc
    base_tr,base_dev,base_q,base_hi,_=invariant(base)
    if predictor<=1.e-8*cc:
        return a*trial,dict(kind="Elastic",Ftrial=predictor,base_q=base_q,trace_excess=tr-apex,
                            q_trial=q,q_return=q,base_F=(slope*base_tr+base_q+beta*base_hi)/(1.-alpha)-cc)
    if q<=band:raise ValueError("TrialBelowBand")
    u=tr-apex
    Ld=(q+beta*high)/slope
    f_max=band/q
    if min(apex-Ld*f_max,tr)<=FC*math.sqrt(746.e-12):raise ValueError("DirectionalConfineNotZero")
    if u+Ld*f_max<=0.:
        f=-u/Ld
        assert f_max<=f<1.
        if (746.-tr/FC)*(f*q/FC)>(tr/FC)**2:
            raise ValueError("ExteriorDirectionalConfinePotentiallyNonzero")
        v=0.
        returned=eye*(tr/3.)+f*d
        kind="DeviatoricReturnOutsideBand"
        shaft=None
    else:
        # Solve in reduced q, x=q_return/band. At x=1 the angular window closes;
        # x is below 1. The implicit dimensional multiplier never has to be formed.
        left=max(0.,-u/(Ld*f_max))
        right=1.
        if not left<right:raise ValueError("MissingBandBracket")
        for _ in range(90):
            x=left+(right-left)/2.
            if x==left or x==right:break
            f=x*f_max
            v=(u+Ld*f)/(3.*P)
            weight=(1.-x)**3*(1.+3.*x+6.*x*x)
            dil=math.tan(dilation_limit*weight)
            lhs=v*f*G2
            rhs=(1.-f)*dil*math.hypot(offset_per_dilation*dil,math.sqrt(2./3.)*band*x)
            if lhs>rhs:right=x
            else:left=x
        x=left+(right-left)/2.
        f=x*f_max
        v=(u+Ld*f)/(3.*P)
        assert 0.<f<f_max and v>0.
        returned=eye*((apex-Ld*f)/3.)+f*d
        kind="ApexTransition"
        shaft=x
    dk=v+(1.-f)*high/G2
    assert dk>=0. and aplastic(ret=returned)
    returned_q=f*q
    stress=a*math.exp(-tension_rate*dk)*returned
    return stress,dict(kind=kind,Ftrial=predictor,q_trial=q,q_return=returned_q,trace_excess=u,
                       factor=f, band_fraction=shaft, base_q=base_q, tension_coordinate_increment=dk,
                       base_F=(slope*base_tr+base_q+beta*base_hi)/(1.-alpha)-cc,
                       return_F=(slope*np.trace(returned)+f*(q+beta*high))/(1.-alpha)-cc)


def apex_jvp(base_nominal,kt,kc,deps,direction):
    """Material tangent action on one smooth, selected branch of the finite return."""
    nominal, row = return_apex(base_nominal,kt,kc,deps)
    ds=elastic(direction)
    base,_,beta,slope,apex,a=parameters(base_nominal,kt,kc)
    if row["kind"]=="Elastic":
        return a*ds,row["kind"]
    tr,d,q,hi,_=invariant(base+elastic(deps))
    eigs,axes=np.linalg.eigh(d)
    if eigs[-1]-eigs[-2]<=32.*np.finfo(float).eps*max(q,1.):
        raise ValueError("TopPrincipalNonsimple")
    f=row["factor"]
    Ld=(q+beta*hi)/slope
    dt=float(np.trace(ds))
    D=ds-eye*dt/3.
    dq=1.5*float(np.sum(d*D))/q
    dhi=float(axes[:,-1]@D@axes[:,-1])
    dLd=(dq+beta*dhi)/slope
    if row["kind"]=="DeviatoricReturnOutsideBand":
        df=(-dt-f*dLd)/Ld
        dv=0.
        dr=dt
    else:
        # Differentiate the implicit residual at fixed returned q / band first,
        # then include that ratio's own derivative using the implicit equation.
        x=row["band_fraction"]
        fx=band/q
        v=(tr-apex+Ld*f)/(3.*P)
        vx=Ld*fx/(3.*P)
        weight=(1.-x)**3*(1.+3.*x+6.*x*x)
        dil=math.tan(dilation_limit*weight)
        dx=-dilation_limit*30.*x*x*(1.-x)**2*(1.+dil*dil)
        dev_coeff=math.sqrt(2./3.)*band
        R=math.hypot(offset_per_dilation*dil,dev_coeff*x)
        Rx=((offset_per_dilation**2)*dil*dx+dev_coeff**2*x)/R
        phi_x=G2*(vx*f+v*fx)+fx*dil*R-(1.-f)*(dx*R+dil*Rx)
        fixed_f=-f*dq/q
        fixed_v=(dt+dLd*f+Ld*fixed_f)/(3.*P)
        fixed_phi=G2*(fixed_v*f+v*fixed_f)+fixed_f*dil*R
        df=fixed_f-fx*fixed_phi/phi_x
        dv=(dt+dLd*f+Ld*df)/(3.*P)
        dr=-dLd*f-Ld*df
    dk=dv+((1.-f)*dhi-df*hi)/G2
    eff_der=eye*dr/3.+df*d+f*D
    return a*math.exp(-tension_rate*row["tension_coordinate_increment"])*eff_der-nominal*tension_rate*dk,row["kind"]

def aplastic(ret):
    return np.linalg.eigvalsh(ret)[0]>0.

def apex_direction(base_nominal,kt,kc,deps):
    # Strict apex limit: inside the angular band near origin the mathematical
    # infinitesimal also sees its nonzero width. This is an outer asymptote valid
    # only where the probe stress scale greatly exceeds the fixed band.
    base,cc,beta,slope,apex,a=parameters(base_nominal,kt,kc)
    shift=elastic(deps)
    tr,d,q,hi,_=invariant(shift)
    if q==0.:raise ValueError("AxialShapeDegenerate")
    load=slope*tr+q+beta*hi
    if load<=0.:
        return a*shift,"ElasticDirectional"
    if tr<0.:
        f=-tr*slope/(q+beta*hi)
        effective=eye*tr/3.+f*d
        dk=(1.-f)*hi/G2
        label="DeviatoricDirectional"
    else:
        effective=np.zeros((3,3))
        dk=tr/(3.*P)+hi/G2
        label="ApexDirectional"
    return a*effective-base_nominal*tension_rate*dk,label

def data(path):
    with ZipFile(path) as archive:
        arr=dict(np.load(BytesIO(archive.read("MeasuredSamples.npz")),allow_pickle=False))
        meta=json.loads(archive.read("RankOneNativeVerification.json")) if "RankOneNativeVerification.json" in archive.namelist() else None
        branches=archive.read("KaniV4Tangents.csv").decode("cp1251") if "KaniV4Tangents.csv" in archive.namelist() else ""
    names={name:i for i,name in enumerate(arr["names"])}
    out={name:arr["stations"][arr["station_index"][i]] for name,i in names.items()}
    meta_branches={}
    if "branches" in arr:
        meta_branches={name:arr["branches"][i] for name,i in names.items()}
    else:
        for kind,name,point,side,*values in csv.reader(branches.splitlines(),delimiter=";"):
            if kind=="BRANCH":
                target=meta_branches.setdefault(name,np.full((3,184,3),-1))
                target[int(side)+1,int(point)-1]=list(map(int,values))
    return out,meta_branches,meta,arr['geometry'],float(arr['length'])

def verify(p308,p313,p315):
    sha=lambda p:sha256(p.read_bytes()).hexdigest().upper()
    inputs={p308.name:sha(p308),p313.name:sha(p313),p315.name:sha(p315)}
    assert inputs[p308.name]=="4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113"
    assert inputs[p313.name]=="80EB566222C15907EEA8C72E866102B268642B1CD2E4B353EAF1CC76AF107C14"
    assert inputs[p315.name]=="B920F591EA6436DB65914CEF8582EA8EB42301679A15311A924253942FEAAEA5"
    a308,b308,_,geom308,length308=data(p308)
    a313,b313,meta,geom313,length=data(p313)
    energy=np.array(meta["acceptedEnergies_byStation_SidesMinusCenterPlus"]["BaseAccepted"])
    native_predictors=meta["trialYield_MPa_byStation_SidesMinusCenterPlus"]
    with ZipFile(p315) as z:
        coordinate_bytes=z.read("GeometryAndDirections.csv")
        directions=np.loadtxt(BytesIO(coordinate_bytes),delimiter=";")
        published=json.loads(z.read("HydrostaticApexDecomposition.json"))
    assert np.array_equal(geom308,geom313) and np.array_equal(geom313,directions[:,:3]) and length308==length
    steel=np.zeros((40,6))
    steel[:,:4]=directions[144:,3:]
    assert np.all(steel.sum(axis=1)==1.)
    def concrete_maps(data):
        out={}
        for tag,field in data.items():
            row=field.copy()
            axial=2e5*np.einsum("spi,pi->sp",field[:,144:,:6],steel)
            assert np.all(abs(axial)<np.r_[np.full(8,442.),np.full(32,400.)])
            row[:,144:,6:]=axial[:,:,None]*steel[None,:,:]-field[:,144:,6:]
            out[tag]=row
        return out
    c308=concrete_maps(a308)
    c313=concrete_maps(a313)
    baseline=c313["BaseAccepted"]
    assert np.max(np.abs(c308["BaseAccepted"]-baseline))<2e-10
    subjects=[]
    for side in range(3):
        for point in range(184):
            loc=(side,point)
            base=matrix(baseline[loc][6:])
            if np.linalg.eigvalsh(base)[0]<=0.:continue
            t,d,q,hi,lo=invariant(base)
            if q>2e-10 or energy[loc][0]<1./21.:continue
            subjects.append(loc)
    assert (2,7) in subjects
    result={}
    for name,archive,branches in ((p308.name,c308,b308),(p313.name,c313,b313)):
        by_point={}
        result[name]=by_point
        for label,field in archive.items():
            if label in ("BaseAccepted","ReferenceBefore","Original43","EndAccepted","Restore43"):continue
            records=[]
            by_point[label]=records
            for loc in subjects:
                base_row=baseline[loc]
                deps=field[loc][:6]-base_row[:6]
                base_nominal=matrix(base_row[6:])
                kt,kc=energy[loc]
                upper=branches[label][loc]
                expected=matrix(field[loc][6:])
                try:
                    validated,detail=return_apex(base_nominal,kt,kc,deps)
                    approximation,label_direction=apex_direction(base_nominal,kt,kc,deps)
                except (ValueError,AssertionError) as exc:
                    records.append(dict(sidePoint=(loc[0]-1,loc[1]+1),status="OutsideCandidate",reason=str(exc),native=upper.tolist()))
                    continue
                error=norm(validated-expected)
                directional_error=norm(approximation-(expected-base_nominal))
                row=dict(sidePoint=(loc[0]-1,loc[1]+1),status="Compared",
                     kind=detail["kind"],native_branch=upper.tolist(),
                     native_increment_MPa=vector(expected-base_nominal),
                     computed_increment_MPa=vector(validated-base_nominal),
                     max_stress_error_MPa=error, expected_strength=norm(expected-base_nominal),
                     direction_kind=label_direction, directional_stress_error_MPa=directional_error,
                     detail=detail)
                if label in native_predictors:
                    val=native_predictors[label][loc[0]][loc[1]]
                    row["native_Ftrial_MPa"]=val
                    row["abs_trial_F_error_MPa"]=abs(val-detail["Ftrial"])
                records.append(row)
    rows=[r for data in result.values() for records in data.values() for r in records]
    compared=[r for r in rows if r["status"]=="Compared"]
    b0=next(r for r in result[p313.name]["LoadShape00Minus"] if r["sidePoint"]==(1,8))
    b1=next(r for r in result[p313.name]["LoadShape00Plus"] if r["sidePoint"]==(1,8))
    print("subjects",len(subjects), "compared",len(compared))
    for r in (b0,b1):
        print(r["sidePoint"],r["kind"],r["max_stress_error_MPa"],r["detail"]["Ftrial"],r["detail"]["q_return"],r["directional_stress_error_MPa"])
    print("max errors",max(r["max_stress_error_MPa"] for r in compared),
          max(r["directional_stress_error_MPa"] for r in compared),
          max((r.get("abs_trial_F_error_MPa",0.) for r in compared)))
    qn={label: {tuple(row["sidePoint"]):row for row in result[p313.name][label]}
          for label in ("LoadShape00Minus","LoadShape00Plus")}
    weights=np.array([-1,0,1])[:,None]*(geom313[:,2]*geom313[:,1]/(305.*610.*length*.002))[None,:]
    both=(b313["LoadShape00Plus"][:,:,0]==1)&(b313["LoadShape00Minus"][:,:,0]==1)
    assert int(np.sum(both))==published["bothPlastic"]==59
    assembled=[]
    for side,point in zip(*np.where(both),strict=True):
        site=(int(side)-1,int(point)+1)
        rowm,rowp=(qn[tag][site] for tag in ("LoadShape00Minus","LoadShape00Plus"))
        assert rowm["status"]==rowp["status"]=="Compared"
        k=weights[side,point]*(1. if point<144 else -1.)
        actual=k*(rowm["native_increment_MPa"][2]+rowp["native_increment_MPa"][2])
        estimated=k*(rowm["computed_increment_MPa"][2]+rowp["computed_increment_MPa"][2])
        assembled.append(dict(sidePoint=site,weight=float(k),native_row81_contribution=float(actual),
                              computed_row81_contribution=float(estimated)))
    as_test=sum(r["computed_row81_contribution"] for r in assembled)
    as_native=sum(r["native_row81_contribution"] for r in assembled)
    assert abs(as_native-published["row81EvenBothPlastic_MPa"])<1e-11
    print("row81",as_test,as_native)
    tangent_checks=[]
    held_directions=(
        ("LoadShape00Plus","PriorSecant01Plus"),("LoadShape00Minus","PriorSecant01Minus"),
        ("LoadShape00Plus","TangentContrast01Plus"),("LoadShape00Minus","TangentContrast01Minus"),
        ("FreshUncorrectedNear","LoadShape00Plus"),("SignedRankOneSignal","PriorSecant01Plus"),
    )
    all_raw={**c308,**c313}
    selected=(2,7)
    for name_near,name_dir in held_directions:
        base_row=baseline[selected]
        delta=all_raw[name_near][selected][:6]-base_row[:6]
        test_direction=all_raw[name_dir][selected][:6]-base_row[:6]
        direction=test_direction/norm(test_direction)
        nom0=matrix(base_row[6:])
        kt,kc=energy[selected]
        tangent,kind=apex_jvp(nom0,kt,kc,delta,direction)
        approximations=[]
        for h in (2.5e-13,5.e-13,1.e-12):
            plus,dplus=return_apex(nom0,kt,kc,delta+h*direction)
            minus,dminus=return_apex(nom0,kt,kc,delta-h*direction)
            assert dplus["kind"]==dminus["kind"]==kind
            secant=(plus-minus)/(2.*h)
            approximations.append(dict(h=h, centered=vector(secant), error_MPa_per_strain=norm(tangent-secant),
                                       error_as_stress_MPa=norm(tangent-secant)*h))
        assert min(r["error_as_stress_MPa"] for r in approximations)<1e-13
        tangent_checks.append(dict(target=name_near,direction_name=name_dir,kind=kind,
                              normalized_direction=direction.tolist(),
                              differential=vector(tangent),central_controls=approximations))
    groups={}
    for archive,fields in result.items():
        for tag,rows in fields.items():
            key=(archive,tag)
            n=len(rows)
            valid=[r for r in rows if r["status"]=="Compared"]
            assert len(valid)==n
            assert max(r["max_stress_error_MPa"] for r in valid)<1e-11
            assert all(r["native_branch"][0]==(r["kind"]!="Elastic") for r in valid)
            for v in valid:
                state=v["kind"]
                groups[state]=groups.get(state,0)+1
    return dict(inputs_sha256=inputs, E=E,fc=FC,ft=FT,nu=NU,band_MPa=band,
                compared_count=len(compared),return_branches=groups,
                smooth_tangent_actions_at_point8_side1=tangent_checks,
                target_stations=[(i-1,j+1) for i,j in subjects],
                station_probes=result,
                row81_both_plastic=dict(computed_MPa=as_test,native_MPa=as_native,
                  reference315_MPa=published["row81EvenBothPlastic_MPa"],
                  station_contributions=assembled))

if __name__=="__main__":
    p308,p313,p315=map(Path,sys.argv[1:4])
    res=verify(p308,p313,p315)
    dest=Path(sys.argv[4]) if len(sys.argv)>4 else H/"KaniApexReturnChecks.json"
    dest.write_text(json.dumps(res,indent=2,allow_nan=False)+"\n","utf-8")
    print(sha256(dest.read_bytes()).hexdigest().upper())

