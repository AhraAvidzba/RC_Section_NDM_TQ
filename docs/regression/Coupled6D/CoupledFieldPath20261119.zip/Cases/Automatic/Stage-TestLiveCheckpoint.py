"""ДЛЯ ТЕСТОВ. Записывает принятую ветвь и исходы проб автоматического восстановления до возможного таймаута."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Использует неизменный проверенный решатель; автоматическое включение производится только в частной копии контроллера."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestLiveDifference.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    prototype = root.parent / 'LiveDifference06202611119'
    name = 'src/Solver/CCoupledDeformationContinuation.cls'
    digest = json.loads((prototype / 'Preparation.json').read_bytes())['inputs'][name]
    raw = (prototype / name).read_bytes()
    assert sha256(raw).hexdigest().upper() == digest
    code = raw.decode('utf-8-sig').replace('\r\n','\n')
    anchor = '    solved = mSolver.TryDeformationStep(mOffset, mDirection, mProjection, point.Coordinate, initialLambda, _'
    assert code.count(anchor) == 1
    hook = '    modTestCoupledElasticState.TestWriteLiveContinuationProbe "BEGIN", mProbeCount, initialLambda, referenceLambda, point.Coordinate, 0#, False, mProjection, mSolver\n'
    code = code.replace(anchor, hook+anchor, 1)
    anchor = '    If mSolver.SameControlRecoveryTried Then'
    assert code.count(anchor) == 1
    hook = '    modTestCoupledElasticState.TestWriteLiveContinuationProbe "SOLVER", mProbeCount, initialLambda, referenceLambda, point.Coordinate, point.Lambda, solved, mProjection, mSolver\n'
    code = code.replace(anchor, hook+anchor, 1)
    anchor = '                changedControl = probed'
    assert code.count(anchor) == 1
    hook = '                modTestCoupledElasticState.TestWriteLiveContinuationProbe "ADOPT", mProbeCount, seedLambda, current.Lambda, trial.Coordinate, trial.Lambda, probed, mProjection, mSolver\n'
    code = code.replace(anchor, hook+anchor, 1)
    anchor = '            lastNoProgress = Not probed'
    assert code.count(anchor) == 1
    hook = '            modTestCoupledElasticState.TestWriteLiveContinuationProbe "DIRECTION", mProbeCount, seedLambda, current.Lambda, trial.Coordinate, trial.Lambda, probed, mProjection, mSolver\n'
    code = code.replace(anchor, hook+anchor, 1)
    (root / name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'src/Solver/CCoupledLoadContinuation.cls'
    code = (repo / name).read_text('utf-8-sig')
    anchor = '    Dim controlled As New CCoupledDeformationContinuation'
    assert code.count(anchor) == 1
    hook = '''
    Dim observerTest As CCoupledProgressObserverTest
    If Len(Environ$("NDM_MVT_FLOW_FOLDER")) > 0 Then
        Set observerTest = New CCoupledProgressObserverTest
        observerTest.TestInitialize Environ$("NDM_MVT_FLOW_FOLDER") & "\\Native\\Stock.Checkpoint.csv"
    End If'''
    code = code.replace(anchor, anchor+hook, 1)
    anchor = 'mMaxIterations, mAbsoluteTolerance, mRelativeTolerance, mAcceptedTrace\n'
    assert code.count(anchor) == 1
    code = code.replace(anchor, 'mMaxIterations, mAbsoluteTolerance, mRelativeTolerance, mAcceptedTrace, observerTest\n', 1)
    (root / name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    if Path(name).stem not in prep['modules']:
        prep['modules'].append(Path(name).stem)
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет завершённую строку начала или исхода реальной пробы, не меняя поля и материальную историю.
Public Sub TestWriteLiveContinuationProbe(ByVal phase As String, ByVal probe As Long, ByVal initial As Double, _
        ByVal reference As Double, ByVal target As Double, ByVal factor As Double, ByVal solved As Boolean, _
        ByRef projection() As Double, ByVal solver As CCoupledNewtonSolver)
    Dim root As String: root = Environ$("NDM_MVT_FLOW_FOLDER")
    If Len(root) = 0 Then Exit Sub
    Dim handle As Integer: handle = FreeFile
    Open root & "\\Native\\Stock.Probes.csv" For Append As #handle
    Print #handle, "PROBE;" & phase & ";" & CStr(probe) & ";" & TestOnsetNumber(initial) & ";" & TestOnsetNumber(reference) & ";" & _
        TestOnsetNumber(target) & ";" & TestOnsetNumber(factor) & ";" & CStr(solved) & TestHardPreparedVector(solver.ReadPolishEffortTest)
    Print #handle, "PROJECTION;" & phase & ";" & CStr(probe) & TestHardPreparedVector(projection)
    If phase <> "BEGIN" Then Print #handle, "DETAILS;" & phase & ";" & CStr(probe) & ";" & solver.ResultMeta.DiagnosticDetails
    Close #handle
End Sub
'''
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    anchor = "        Assert-IsolatedOfficeReady ('VerifyWorkingASD'+$Phase)"
    assert code.count(anchor) == 1
    code = code.replace(anchor, "        if ($Phase -eq 'Stock') {$env:NDM_MVT_FLOW_FOLDER=$PSScriptRoot}\n"+anchor, 1)
    (root / name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = Path(__file__).name
    (root / name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='AutomaticMaterialRecoveryProgressBeforeEachProbe',
        private_enabled_controller_origin_sha256=digest, working_automatic_material_recovery_enabled=False,
        own_test_automatic_material_recovery_enabled=True, accepted_checkpoints_before_each_probe=True,
        probe_begin_and_outcome_saved=True, timeout_seconds=240, physical_capacity_certified=False)
    (root / 'Preparation.json').write_text(json.dumps(prep,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('AUTOMATIC MATERIAL CONTINUATION CHECKPOINTS AND REAL PROBE OUTCOMES READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(),args.root.resolve(),args.source.resolve())
