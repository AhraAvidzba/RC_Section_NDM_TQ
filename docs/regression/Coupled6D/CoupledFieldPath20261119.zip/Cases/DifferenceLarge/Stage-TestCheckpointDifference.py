"""ДЛЯ ТЕСТОВ. Проверяет чувствительность дочерней разностной касательной при неизменном материальном переходе."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source, checkpoint, step):
    """Меняет только шаг производных дочернего адаптера; исходная матрица выбора и силовая приёмка не меняются."""
    assert 0 < step <= .001
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestCheckpointResume.py'))['TestStage'](repo,root,source,checkpoint)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    anchor = '        relativeDifferenceStep:=HYBRID_DIFFERENCE_STEP, automaticScaling:=True, freshJacobian:=True)'
    assert code.count(anchor) == 1
    code = code.replace(anchor,'        relativeDifferenceStep:='+format(step,'.17g')+', automaticScaling:=True, freshJacobian:=True)',1)
    (root / name).write_bytes(code.replace('\n','\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = Path(__file__).name
    (root / name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update(case='SameCheckpointChildDifferenceStep',
        child_difference_step=step, primary_difference_step=1e-6, child_complete_Newton_enabled=False,
        material_and_force_tolerances_unchanged=True, total_iteration_budget_unchanged=True,
        working_sources_changed=False, installed_workbook_changed=False, physical_capacity_certified=False)
    (root / 'Preparation.json').write_text(json.dumps(prep,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('SAME MATERIAL TARGET CHILD DIFFERENCE STEP READY',step)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--step', type=float, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(),args.root.resolve(),args.source.resolve(),args.checkpoint.resolve(),args.step)
