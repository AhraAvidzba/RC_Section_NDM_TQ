"""Recheck the native HardShear receipt for the installed workbook."""
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
HASH = '9A99BF072D67536CBCCA525A75E049F510C5242D46CB4EA3ADA7BC4C726088F8'


def read(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8-sig'))


def main():
    report = (ROOT / 'HardShear.txt').read_text(encoding='utf-8-sig')
    ownership = read('HardShear.txt.Ownership.json')
    closure = read('HardShear.txt.ProcessClosure.json')['Closure']['FinalState']
    receipt = read('HardShear.txt.Receipt.json')
    assert ownership['VerifiedNewOwner'] and ownership['SourceSHA256'] == HASH
    assert f'SOURCE_SHA256: {HASH}' in report and 'SOURCE_UNCHANGED: True' in report
    for field in ('State', 'PID', 'StartTicksUTC', 'Reason'):
        assert str(closure[field]) == str(receipt['closed'][field])
    assert datetime.fromisoformat(closure['ObservedUTC']) == datetime.fromisoformat(receipt['closed']['ObservedUTC'])
    assert closure['State'] == 'Absent'
    assert tuple(map(str, (ownership['PID'], ownership['StartTicksUTC']))) == tuple(map(str, (closure['PID'], closure['StartTicksUTC'])))
    assert receipt['exit'] == 0 and 'RUNTIME ERROR:' not in report
    totals = re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)$', report, re.M)
    assert totals == [('28', '0'), ('1', '0')]
    states = re.search(r'^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([\d.,]+); limit=; code=NUMERICAL_FAILURE$', report, re.M)
    lower = float(states[1].replace(',', '.'))
    previous = 1.10290889219737
    assert lower >= 1.1029
    seconds = float(re.search(r'^TIMING_SECONDS: ([\d.,]+) \| Both \| Excel$', report, re.M)[1].replace(',', '.'))
    result = {
        'workbook_sha256': HASH, 'passed': 29, 'direct': 'OK', 'capacity': 'NumFail',
        'confirmed_lower': lower, 'previous_confirmed_lower': previous, 'difference': lower - previous,
        'time_to_results_seconds': seconds, 'timing_target_seconds': 10,
        'physical_limit_confirmed': False, 'native_process_closed': True,
    }
    path = ROOT / 'Replay.json'
    path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(sha256(path.read_bytes()).hexdigest().upper(), lower, seconds)


if __name__ == '__main__':
    main()
