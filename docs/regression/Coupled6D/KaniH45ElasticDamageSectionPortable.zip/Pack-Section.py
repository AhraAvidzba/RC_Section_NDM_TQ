"""Seal the paired full-section result without Excel binaries."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import json
import runpy

H=Path(__file__).resolve().parent
OUTS=('Compile.log','CompileClosure.json','Preflight.ndjson','KaniV4.txt','KaniV4.txt.Ownership.json',
      'KaniV4.txt.ProcessClosure.json','KaniV4.txt.RunnerCleanup.json','KaniV4.txt.memory.json','KaniV4.txt.stdout.log',
      'KaniV4.txt.stderr.log','KaniV4Trace.csv','KaniV4Stations.csv','KaniV4Tangents.csv')


def sha(p):
    return sha256(p.read_bytes()).hexdigest().upper()


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def pack(repo):
    receipt=H/'SectionComparison.json'
    before=sha(receipt)
    result=runpy.run_path(H/'Verify.py')['verify'](repo,'Both')
    assert sha(receipt)==before and result['initialZeroAndRollbackExactAcrossVariants']
    prep=read(H/'Preparation.json')
    files={n for n in prep['frozen'] if '/tools/' not in n and not n.endswith('.xlsm')}
    files.update(('Preparation.json','SectionComparison.json','Pack-Section.py','Replay-Section.py','Portable-README.md'))
    for arm in ('A','D'):
        files.add(f'{arm}/docs/regression/CodeUpdate.json')
        files.update(f'{arm}/Native/{n}' for n in OUTS)
    assert all((H/n).is_file() for n in files) and not any(n.lower().endswith(('.xlsm','.xlsx')) for n in files)
    m={'schema':'KaniH45ElasticDamageSection/v1','sourceGit':prep['sourceGit'],'bookSHA256':prep['bookSHA256'],
       'candidateMaterialSHA256':prep['candidateMaterialSHA256'],
       'compiledPrivateBookSHA256':{arm:read(H/arm/'docs/regression/CodeUpdate.json')['WorkbookSHA256'] for arm in ('A','D')},
       'files':{n:sha(H/n) for n in sorted(files)}}
    folder=H/'Portable'
    folder.mkdir(exist_ok=True)
    dest=folder/'KaniH45ElasticDamageSectionPortable.zip'
    fixed=(2026,11,16,0,0,0)
    with ZipFile(dest,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
        for n in sorted(files):
            z.writestr(ZipInfo(n,fixed),(H/n).read_bytes(),compress_type=ZIP_DEFLATED,compresslevel=9)
        z.writestr(ZipInfo('Manifest.json',fixed),(json.dumps(m,indent=2)+'\n').encode(),compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(dest) as z:
        assert z.testzip() is None and set(z.namelist())==files|{'Manifest.json'}
    print(dest,sha(dest),dest.stat().st_size,sha(receipt))
    return dest


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    pack(a.repo_root.resolve())
