"""Independently verify the full section A/D continuation replay."""
from argparse import ArgumentParser
from datetime import datetime
from pathlib import Path
import csv
import json
import re
import runpy

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')
COMMON_STATES=('Base45','Zero45','End45','Restore45')


def arm_verifier(arm):
    source=H/'Verify-Alt.py'
    text=source.read_text(encoding='utf-8-sig')
    line="assert book['Modules'] == ['modTestKaniStage38']"
    assert text.count(line)==1
    text=text.replace(line,f"assert sorted(book['Modules']) == {sorted(P['MODS'][arm])!r}")
    glob={'__name__':'private_kani_section_verifier','__file__':str(source)}
    exec(compile(text,str(source),'exec'),glob)
    glob['H']=H/arm
    glob['Z']=H/arm/'Native'
    glob['P']['check']=P['check']
    return glob


def macro_seconds(text):
    start=re.findall(r'^SUITE_STARTED: modTestKaniStage38\.RunTestKaniStage38; ([^\r\n]+)',text,re.M)
    finish=re.findall(r'^SUITE_FINISHED: modTestKaniStage38\.RunTestKaniStage38; ([^\r\n]+)',text,re.M)
    assert len(start)==len(finish)==1
    seconds=(datetime.fromisoformat(finish[0])-datetime.fromisoformat(start[0])).total_seconds()
    assert seconds>=0
    return seconds


def numbers(detail):
    # VBA CStr uses the local decimal separator and the diagnostic replaces semicolons with pipes.
    sections={
        'iterations':r'Итерации: (\d+)',
        'evaluations':r'пробы: (\d+)',
        'lastNormMPa':r'невязка, МПа: ([+-]?\d[^ |]*)',
        'beforeDampingMPa':r'невязка перед демпфированием, МПа: ([+-]?\d[^ |]*)',
        'bestDampedTrialMPa':r'лучшая невязка проб, МПа: ([+-]?\d[^ |]*)',
        'governingRow':r'уравнение (\d+) \(',
        'tangentPredictedMPa':r'действие касательной, МПа: ([+-]?\d[^ |]*)',
        'actualPerUnitDampingMPa':r'фактическое изменение на единицу доли поправки, МПа: ([+-]?\d[^ |]*)',
    }
    measured={}
    for k,p in sections.items():
        m=re.search(p,detail)
        if m:
            val=m[1].replace(',','.')
            measured[k]=int(val) if k in ('iterations','evaluations','governingRow') else float(val)
    assert 'iterations' in measured and 'evaluations' in measured
    return measured


def actual_right(arm,r):
    verified=r['comparison89PlusFive']
    right=r['rightShoulder']
    native_dir=H/arm/'Native'
    record={'status':right,'newtonDiagnostics':numbers(right['diagnostic']),
            'nativeMacroSeconds':macro_seconds((native_dir/'KaniV4.txt').read_text(encoding='utf-8-sig')),
            'rightConverged':right['converged']}
    if right['converged']:
        s=verified['Right']
        assert s['withinOriginalToleranceRule'] and len(s['all89ForceRows_MPa'])==89 and len(s['allFiveControls_MPa'])==5
        actual=s['sixWrenches_N_Nmm'][-1]
        target=s['Qy_N']
        record.update({'QyResultant_N':actual,'QyAtReturnedMultiplier_N':target,'QyResidual_N':actual-target,
                       'trialSteelUltimateUtilization':s['trialSteelUltimateUtilization'],
                       'norm89PlusFiveMPa':s['maximum89PlusFive_MPa'],'rightState':s})
    else:
        assert 'Right' not in verified
        record.update({'QyResultant_N':None,'QyAtReturnedMultiplier_N':None,'QyResidual_N':None,'rightState':None})
    return record


def verify(repo,variant):
    prep=P['check'](repo)
    arms=('A','D') if variant=='Both' else (variant,)
    plan=json.loads((H/'A/DiscriminatingH45Measurement.json').read_text(encoding='utf-8'))
    assert plan['incrementAlpha']==prep['incrementAlpha']==1.5e-8
    assert plan['targetAlpha']==prep['targetAlpha'] and plan['currentAlpha']==prep['baseAlpha']
    results={}
    for arm in arms:
        one=arm_verifier(arm)['verify'](repo)
        assert one['unchangedReplay'] and one['finiteProbesExecuted']==1
        assert one['originalH45Tau_MPa']==prep['originalTauMPa']
        results[arm]={'fullEvidence':one,'rightResult':actual_right(arm,one)}
    section={'sourceGit':prep['sourceGit'],'bookSHA256':prep['bookSHA256'],
             'candidateMaterialSHA256':prep['candidateMaterialSHA256'],'baseAlpha':prep['baseAlpha'],
             'targetAlpha':prep['targetAlpha'],'fixedOtherLoads_N_Nmm':plan['otherPrescribedEfforts_N_Nmm'],'variants':results}
    if len(arms)==2:
        a,b=(results[k]['fullEvidence'] for k in arms)
        for label in COMMON_STATES:
            assert a['comparison89PlusFive'][label]==b['comparison89PlusFive'][label],label
        section['initialZeroAndRollbackExactAcrossVariants']=True
        section['rightQyDifferenceDMinusA_N']=(results['D']['rightResult']['QyResultant_N']-results['A']['rightResult']['QyResultant_N']
                                              if results['D']['rightResult']['rightConverged'] and results['A']['rightResult']['rightConverged'] else None)
    path=H/('SectionComparison'+('' if variant=='Both' else variant)+'.json')
    path.write_text(json.dumps(section,indent=2,allow_nan=False)+'\n',encoding='utf8')
    for arm,v in results.items():
        detail=v['rightResult'].copy()
        detail.pop('rightState')
        print(arm,detail)
    print('PASS',path,P['sha'](path))
    return section


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    p.add_argument('--variant',choices=('A','D','Both'),default='Both')
    a=p.parse_args()
    verify(a.repo_root.resolve(),a.variant)
