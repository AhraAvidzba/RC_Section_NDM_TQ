"""Freeze the section-only A/D continuation comparison against the new workbook."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import subprocess

H=Path(__file__).resolve().parent
TIP='6d42af5'
DRAFT='docs/regression/Diagnostic.xlsm'
BOOK='workbook/output/RC_Section_NDM.xlsm'
MACRO='tests/modTestKaniStage38.bas'
CONCRETE='src/Materials/CCoupledConcreteResponse.cls'
ART='docs/regression/Coupled6D'
A_D='KaniH45ElasticDamageNativePortable.zip'
A_D_SHA='751CC8385ADDA61CFBC422B2F93C7EB4150A70964A4F294DD1CBE06B4F98F0FA'
DONOR='KaniH45AlternateControlPortable.zip'
DONOR_SHA='4A9CADBD73726D133E99B5EA1D58F1DB8DB574C45BC189470F8EEC856C911BD4'
ROW='KaniH45Row81DirectionPortable.zip'
ROW_SHA='4B65725C0977E6855720BFBD0F9CA7D5D3FCF0AD3F4C1C0A8FA68F73DECDA701'
BOOK_SHA='475E57DE58848B3F83DA8C79B1A10EC05B3726CC52B0C904E5B975F4CFBDFB18'
DAMAGE_SHA='A8C4F9664F300A344C6047553D55FD9E589F3BB0ECEA3371BE1EAA4EDC22837B'
STOCK_SHA='A66098447E4A7203D5E5088C609976228C728F78E671E0AB7AC06DB3D0ED8A03'
MACRO_SHA='76F6EC18088AD5D4DC1CBF43C3E1F81D2EF6BA2A528FB18A7BE94E301C2B500E'
SOURCES=(CONCRETE,'src/Solver/CCoupledNewtonSolver.cls','src/Solver/CCoupledDeformationContinuation.cls',
         'src/Solver/CCoupledElasticState.cls','src/Materials/CCoupledReinforcedResponse.cls')
MODS={'A':['modTestKaniStage38'],'D':['CCoupledConcreteResponse','modTestKaniStage38']}
COMMON=('KaniV4Input.csv','KaniGaugeInput.csv','H45DiscriminatingControl.csv','DiscriminatingH45Measurement.json',MACRO)


def sha(x):
    return sha256(x.read_bytes() if isinstance(x,Path) else x).hexdigest().upper()


def git(repo,*args):
    return subprocess.check_output(['git','-C',str(repo),*args])


def blob(repo,name,tip=TIP):
    return git(repo,'cat-file','blob',f'{tip}:{name}')


def normalize(b):
    return b.replace(b'\r\n',b'\n')


def save(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(b)
    return sha(b)


def check(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    m=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert m['sourceGit']==git(repo,'rev-parse',TIP).decode().strip()
    assert sha(blob(repo,BOOK))==sha(repo/BOOK)==m['bookSHA256']==BOOK_SHA
    assert m['variants']==MODS and m['candidateMaterialSHA256']==DAMAGE_SHA
    assert all(sha(repo/ART/n)==value for n,value in m['supportArchives'].items())
    for n,val in m['production'].items():
        k=blob(repo,n)
        assert sha(k)==val and normalize(k)==normalize((repo/n).read_bytes())
    assert m['production'][CONCRETE]==STOCK_SHA
    for n,val in m['frozen'].items():
        assert sha(H/n)==val,n
    for arm,expected in MODS.items():
        loc=H/arm
        assert all((loc/d).is_dir() and not (loc/d).is_symlink() for d in ('src','tests','Native','Temp'))
        present={f.stem for d in ('src','tests') for f in (loc/d).rglob('*') if f.is_file()}
        assert present==set(expected)
        assert sha(loc/BOOK)==BOOK_SHA and sha(loc/MACRO)==MACRO_SHA
    assert not (H/'A'/CONCRETE).exists() and sha(H/'D'/CONCRETE)==DAMAGE_SHA
    assert all((H/'A'/n).read_bytes()==(H/'D'/n).read_bytes() for n in COMMON)
    return m


def stage(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    assert not (H/'Preparation.json').exists() and not any((H/k).exists() for k in MODS)
    raw=blob(repo,BOOK)
    assert sha(raw)==BOOK_SHA and raw==(repo/BOOK).read_bytes()
    assert sha(blob(repo,CONCRETE))==STOCK_SHA==sha(blob(repo,CONCRETE,'77043b5'))
    assert sha(repo/ART/A_D)==A_D_SHA and sha(repo/ART/ROW)==ROW_SHA and sha(repo/ART/DONOR)==DONOR_SHA
    freeze={}
    with ZipFile(repo/ART/A_D) as ad,ZipFile(repo/ART/ROW) as rw,ZipFile(repo/ART/DONOR) as donor:
        manifest=json.loads(ad.read('Manifest.json'))['files']
        prior=json.loads(ad.read('Preparation.json'))
        verified=json.loads(ad.read('Verification-Points.json'))
        assert len(verified['stockToCandidate'])==6 and verified['candidateMaterialSHA256']==DAMAGE_SHA
        assert all(x['exactH45'] and x['unchangedHistoryAfterStations'] for x in verified['variants'].values())
        data={}
        for n in COMMON:
            k=f'A/{n}'
            value=ad.read(k)
            assert sha(value)==manifest[k] and value==ad.read(f'D/{n}')
            assert n==MACRO or value==rw.read(n)==donor.read(n)
            data[n]=value
        cand=ad.read('D/'+CONCRETE)
        assert sha(cand)==manifest['D/'+CONCRETE]==DAMAGE_SHA
        assert sha(data[MACRO])==MACRO_SHA and b'RunTestKaniStage38' in data[MACRO]
        pd=json.loads(data['DiscriminatingH45Measurement.json'])
        assert pd['incrementAlpha']==1.5e-8 and abs(pd['targetAlpha']-0.0040818899173296333)<1e-16
        assert pd['otherPrescribedEfforts_N_Nmm']==[0.,0.,0.,0.,0.]
        for n in ('Verify-Alt.py','Prepare-Alt.py'):
            b=ad.read(n)
            assert sha(b)==manifest[n]
            freeze[n]=save(H/n,b)
        names=[n[2:] for n in prior['frozen'] if n.startswith('A/tools/')]
        for n in names:
            b=(repo/n).read_bytes()
            assert normalize(blob(repo,n))==normalize(b),n
            data[n]=b
        assert 'tools/build_workbook/Update-PrivateWorkbookCode.ps1' in data
        assert 'tools/build_workbook/Run-Audit03Watchdog.ps1' in data
        support={A_D:A_D_SHA,ROW:ROW_SHA,DONOR:DONOR_SHA,**prior['supportArchives']}
    for arm in MODS:
        root=H/arm
        for n in ('src','tests','Native','Temp','docs/regression'):
            (root/n).mkdir(parents=True,exist_ok=True)
        files={**data,BOOK:raw}
        if arm=='D':
            files[CONCRETE]=cand
        for n,b in files.items():
            freeze[f'{arm}/{n}']=save(root/n,b)
        save(root/DRAFT,raw)
    for n in ('Prepare.py','Run.ps1','Verify.py','README.md'):
        freeze[n]=sha(H/n)
    m={'sourceGit':git(repo,'rev-parse',TIP).decode().strip(),'bookSHA256':BOOK_SHA,
       'candidateMaterialSHA256':DAMAGE_SHA,'stockMaterialSHA256':STOCK_SHA,
       'targetAlpha':pd['targetAlpha'],'baseAlpha':pd['currentAlpha'],'incrementAlpha':pd['incrementAlpha'],
       'originalTauMPa':5.59190995944018e-7,'sectionTimeoutSeconds':180,'maxIterations':12,
       'variants':MODS,'supportArchives':support,'production':{n:sha(blob(repo,n)) for n in SOURCES},
       'frozen':dict(sorted(freeze.items()))}
    save(H/'Preparation.json',(json.dumps(m,indent=2)+'\n').encode())
    return check(repo)


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    p.add_argument('--check',action='store_true')
    a=p.parse_args()
    (check if a.check else stage)(a.repo_root.resolve())
    print('SEALED_SECTION',sha(H/'Preparation.json'))
