"""Reassemble paired full-section evidence with historical Git workbook identity."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from math import isclose
import json
import runpy

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(b):
    return sha256(b.read_bytes() if isinstance(b,Path) else b).hexdigest().upper()


def validate_preparation(repo):
    m=read(H/'Manifest.json')
    assert m['schema']=='KaniH45ElasticDamageSection/v1'
    assert all(digest(H/n)==expected for n,expected in m['files'].items())
    prep=read(H/'Preparation.json')
    assert prep['sourceGit']==P['git'](repo,'rev-parse',P['TIP']).decode().strip()==m['sourceGit']
    assert prep['bookSHA256']==P['BOOK_SHA']==digest(P['blob'](repo,P['BOOK']))==m['bookSHA256']
    assert prep['candidateMaterialSHA256']==P['DAMAGE_SHA']==m['candidateMaterialSHA256']
    for n,expected in prep['production'].items():
        assert digest(P['blob'](repo,n))==expected
    for n,expected in prep['supportArchives'].items():
        assert digest(repo/P['ART']/n)==expected
    for n,expected in prep['frozen'].items():
        if n in m['files']:
            assert m['files'][n]==expected
        elif n.endswith('/'+P['BOOK']):
            assert prep['bookSHA256']==expected
        else:
            arm,tool=n.split('/',1)
            assert arm in ('A','D') and tool.startswith('tools/')
            raw=P['blob'](repo,tool)
            lf=raw.replace(b'\r\n',b'\n')
            assert expected in {digest(raw),digest(lf),digest(lf.replace(b'\n',b'\r\n'))},n
    # The baseline has no class overlay; the only candidate production overlay is frozen.
    assert not (H/'A'/P['CONCRETE']).exists()
    assert digest(H/'D'/P['CONCRETE'])==P['DAMAGE_SHA']
    for n in P['COMMON']:
        assert (H/'A'/n).read_bytes()==(H/'D'/n).read_bytes(),n
    for arm in ('A','D'):
        compiled=read(H/arm/'docs/regression/CodeUpdate.json')
        owned=read(H/arm/'Native/KaniV4.txt.Ownership.json')
        assert compiled['WorkbookSHA256']==owned['SourceSHA256']==m['compiledPrivateBookSHA256'][arm]
    return prep


def once(s,old,new):
    assert s.count(old)==1,old
    return s.replace(old,new)


def private_receipt(text):
    where="    assert book['WorkbookSHA256'] == P['sha'](H / P['draft']) == own['SourceSHA256']"
    replacement="""    assert book['WorkbookSHA256'] == own['SourceSHA256']
    if (H / P['draft']).exists():
        assert book['WorkbookSHA256'] == P['sha'](H / P['draft'])"""
    s=once(text,where,replacement)
    return once(s,"'AlternateVerification.json'","'Replay-AlternateVerification.json'")


def compare(a,b,path='section'):
    if isinstance(a,dict):
        assert a.keys()==b.keys(),path
        for k,v in a.items():
            compare(v,b[k],path+'.'+k)
    elif isinstance(a,list):
        assert len(a)==len(b),path
        for k,(u,v) in enumerate(zip(a,b)):
            compare(u,v,f'{path}[{k}]')
    elif isinstance(a,float):
        assert isclose(a,b,rel_tol=2e-10,abs_tol=2e-12),(path,a,b)
    else:
        assert a==b,(path,a,b)


def replay(repo):
    prep=validate_preparation(repo)
    f=H/'Verify.py'
    s=f.read_text(encoding='utf-8-sig')
    at="    glob={'__name__':'private_kani_section_verifier','__file__':str(source)}"
    s=once(s,at,'    text=private_receipt(text)\n'+at)
    s=once(s,"'SectionComparison'+","'Replay-SectionComparison'+")
    ns={'__name__':'section_replay','__file__':str(f),'private_receipt':private_receipt}
    exec(compile(s,str(f),'exec'),ns)
    ns['P']['check']=lambda _:prep
    result=ns['verify'](repo,'Both')
    compare(read(H/'SectionComparison.json'),result)
    print('DETACHED_SECTION_PASS',digest(H/'Replay-SectionComparison.json'))
    return result


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    replay(a.repo_root.resolve())
