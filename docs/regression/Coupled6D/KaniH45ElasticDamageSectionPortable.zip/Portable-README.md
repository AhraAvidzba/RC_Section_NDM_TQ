# Нативная правосторонняя проба Kani H45 на полной секции

Архив хранит нативные A и D с одним точным полем, историей, допуском
и управляемой мерой §351. В D импортирован только класс бетона,
прошедший нативную проверку аналитической упругой касательной.
Сохраняются 89 силовых уравнений, пять условий, нагрузки, состояния
материала, точное восстановление H45 и протоколы Excel.

Из корня репозитория:

```powershell
$env:PYTHONPATH='D:/CodexScratch/RC_Section_NDM_TQ/FocusedVerifierDeps'
$replay=(New-Item -ItemType Directory -Path 'tmp/ksec/PortableReplay').FullName
Expand-Archive -LiteralPath 'tmp/ksec/Portable/KaniH45ElasticDamageSectionPortable.zip' -DestinationPath $replay
python -B -X utf8 (Join-Path $replay 'Replay-Section.py') --repo-root (Get-Location).Path
```

Нужны NumPy, SciPy, Git с 6d42af5 и архивы из docs/regression/Coupled6D.
Исходная книга проверяется как Git blob. Хеши частных скомпилированных
книг сверяются между протоколом компиляции и подтверждённым открытием.
Исполняемые книги в архив не вложены. Офлайн-повтор не использует
текущую установленную книгу и не открывает Excel.

Результат SectionComparison.json содержит разбор исходного и конечного
демпфирования. При численном отказе Qy правой точки отсутствует.
Подтверждённая левая точка и сохранность истории проверяются независимо.
