"""Сверяет две истории OpenSees и НДМ на совпадающих силовых ступенях MVT2."""

from argparse import ArgumentParser
from contextlib import contextmanager
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import runpy
import sys


HERE = Path(__file__).resolve().parent
ASD = 'MVT2GaussReequilibratedASD20261117.zip'
STEEL = 'MVT2GaussASDNominalPostyield20261117.zip'
CUT = 'MVT2PublicationCut20261117.zip'
NATIVE = 'MVT2NativePublicationCutTimed20261117.zip'
SHA = {
    ASD: 'FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E',
    STEEL: '06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED',
    CUT: '6835F02B3D2ED944823DA808E3CC3BC24CCFBF87CDE9D615AB283954B46E8DAD',
    NATIVE: 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A',
}
ARM = 396.
TORQUE = 10510000.


def digest(blob):
    return sha256(blob).hexdigest().upper()


def write_json(path, data):
    with path.open('x', encoding='utf-8', newline='\n') as file:
        json.dump(data, file, indent=2, sort_keys=True, allow_nan=False)
        file.write('\n')


@contextmanager
def inputs(repo):
    """Распаковывает закреплённые операторы, модель и обе исходные истории."""
    evidence = repo / 'docs/regression/Coupled6D'
    for name, expected in SHA.items():
        assert digest((evidence / name).read_bytes()) == expected, name
    with TemporaryDirectory(dir=HERE, prefix='MatchedHistory_') as work:
        path = Path(work)
        with ZipFile(evidence / ASD) as asd, ZipFile(evidence / CUT) as cut, \
             ZipFile(evidence / STEEL) as steel, ZipFile(evidence / NATIVE) as native:
            for name in ('Operators.py', 'Verify-Authoritative.py', 'Reequilibrate.py'):
                (path / name).write_bytes(asd.read(name))
            for name in ('Verify-Postyield.py', 'Postyield.py'):
                (path / name).write_bytes(steel.read(name))
            (path / 'Verify-PublicationCut.py').write_bytes(cut.read('Verify-PublicationCut.py'))
            cut_report = json.loads(cut.read('Cut396.json'))
            cut_data = json.loads(gzip.decompress(cut.read('Cut396.stress.json.gz')))
            native_report = json.loads(native.read('NativePublicationCutProof.json'))
        assert cut_report['arm_mm'] == native_report['arm_mm'] == ARM
        assert native_report['ASD_reference_archive_sha256'] == SHA[CUT]
        assert native_report['matching_pure_torsion_count'] == cut_report['original_torsion_prefix_bit_exact'] == 8
        sys.path.insert(0, str(path))
        try:
            auth = runpy.run_path(str(path / 'Verify-Authoritative.py'))
            operators, helper = auth['unpack'](path, repo)
            cut_verify = runpy.run_path(str(path / 'Verify-PublicationCut.py'))
            assert digest(operators.read_bytes()) == cut_verify['INPUTS']['operators']
            program = runpy.run_path(str(path / 'Reequilibrate.py'))
            context = program['read_inputs'](operators, path, helper)
            assert context[-1] == cut_report['operators']
            production_steel = runpy.run_path(str(path / 'Postyield.py'))
            verify_steel = runpy.run_path(str(path / 'Verify-Postyield.py'))
            yield (auth, program, context, production_steel, verify_steel,
                   cut_verify, cut_report, cut_data, native_report)
        finally:
            sys.path.pop(0)


def force_schedule(native_report):
    """Восстанавливает возрастающую последовательность по принятым полям НДМ."""
    selected = native_report['accepted']
    loads = [row['Qy_N'] for row in selected]
    assert len(loads) == 14 and loads[0] == 2500. and loads[-1] == 21875.
    assert all(a < b for a, b in zip(loads, loads[1:]))
    assert all(row['Mx_Nmm'] == -ARM * row['Qy_N'] for row in selected)
    return loads


def simulate(repo, report_file, stress_file):
    """Решает те же уравнения сечения на силовых ступенях, принятых в НДМ."""
    import numpy as np
    import openseespy.opensees as ops

    assert (np.__version__, ops.version()) == ('2.3.5', '3.8.0')
    with inputs(repo) as loaded:
        _, program, context, steel_module, _, _, baseline, baseline_stress, native_report = loaded
        shared, native, geom, dirs, area, length, op, seeds, _, identity = context
        schedule = force_schedule(native_report)
        solve = program['simulate']
        model = solve.__globals__
        discard = model['test_discard']
        model['test_discard'] = lambda kit, command, trial, _: discard(kit, command, trial, native['frames'])
        model['loads'] = lambda arrays, t, q: arrays.array((0., -ARM * q, 0., t, 0., q))
        steel = []
        model['Section'] = steel_module['steel_section'](model['Section'], np, steel)
        requested = [{'phase': f'MatchedQ{q / 1000:g}', 'T_Nmm': TORQUE, 'Qy_N': q} for q in schedule]
        case = {**native, 'frames': [*native['frames'][:8], *requested]}
        args = program['commands'](shared, native, ('default',))['default']
        try:
            solution, stresses = solve(np, ops, shared, case, geom, dirs, area, length, op,
                                       seeds, 'default', args, perf_counter() + 95., len(case['frames']))
        finally:
            ops.wipe()
        assert solution['accepted'][:8] == baseline['result']['accepted'][:8]
        assert stresses[:8] == baseline_stress['stress'][:8] and steel[:8] == baseline_stress['steel'][:8]
        wire = gzip.compress(steel_module['record_bytes']({'stress': stresses, 'steel': steel}), mtime=0)
        with stress_file.open('xb') as output:
            output.write(wire)
        write_json(report_file, {
            'ASD': ops.version(), 'numpy': np.__version__, 'archives': SHA, 'arm_mm': ARM,
            'operator_identity': identity, 'requested_Qy_N': schedule,
            'stress_sha256': digest(wire), 'solution': solution,
        })
        print('MVT2 MATCHED HISTORY RUNTIME', len(solution['accepted']), solution['last_confirmed'],
              solution['terminal'], flush=True)


def response(row, length):
    return row['twist_rad_per_m'], row['field'][1] * 1000. / length


def comparison(q, original, matched, native, length):
    """Измеряет относительный эффект размера шагов при совпадающем винте."""
    old_twist, old_curvature = response(original, length)
    new_twist, new_curvature = response(matched, length)
    assert native['Qy_N'] == original['Q_target_N'] == matched['Q_target_N'] == q
    assert original['T_target_Nmm'] == matched['T_target_Nmm'] == TORQUE
    native_twist, native_curvature = native['twist_rad_per_m'], native['kappaX_per_m']
    return {
        'Qy_N': q, 'Mx_Nmm': native['Mx_Nmm'],
        'old_ASD_twist_rad_per_m': old_twist, 'matched_ASD_twist_rad_per_m': new_twist,
        'NDM_twist_rad_per_m': native_twist,
        'ASD_schedule_twist_relative_change': new_twist / old_twist - 1.,
        'NDM_twist_relative_to_matched_ASD': native_twist / new_twist - 1.,
        'old_ASD_kappaX_per_m': old_curvature, 'matched_ASD_kappaX_per_m': new_curvature,
        'NDM_kappaX_per_m': native_curvature,
        'ASD_schedule_curvature_relative_change': new_curvature / old_curvature - 1.,
        'NDM_curvature_relative_to_matched_ASD': native_curvature / new_curvature - 1.,
    }


def verify(repo, report_file, stress_file):
    """Проверяет слабые уравнения, все усилия, обновления стали и сравнение."""
    with inputs(repo) as loaded:
        auth, _, context, _, steel, cut_verify, cut, cut_stress, native = loaded
        _, _, geom, dirs, area, length, operators, _, _, identity = context
        data = json.loads(report_file.read_bytes())
        wire = stress_file.read_bytes()
        assert data['archives'] == SHA and data['operator_identity'] == identity
        assert digest(wire) == data['stress_sha256']
        assert data['arm_mm'] == ARM and (data['ASD'], data['numpy']) == ('3.8.0', '2.3.5')
        tensors = json.loads(gzip.decompress(wire))
        schedule = force_schedule(native)
        assert data['requested_Qy_N'] == schedule
        solution = data['solution']
        states = solution['accepted']
        assert solution['terminal'] is None and solution['complete_nominal_targets']
        assert solution['rejected_trial_interleaving_max_MPa'] == 0.
        assert len(states) == len(tensors['stress']) == len(tensors['steel']) == 8 + len(schedule)
        assert states[:8] == cut['result']['accepted'][:8]
        assert [row['Q_target_N'] for row in states[8:]] == schedule
        assert all(row['T_target_Nmm'] == TORQUE for row in states[8:])
        assert all(payload[:8] == cut_stress[key][:8] for key, payload in tensors.items())
        norms = [cut_verify['equilibrium'](row, stress, ARM, operators, geom, area, length, auth['signed_forces'])
                 for row, stress in zip(states, tensors['stress'], strict=True)]
        history = cut_verify['steel_history'](states, tensors['stress'], tensors['steel'], operators, dirs, steel)
        old_asd = {row['Q_target_N']: row for row in cut['result']['accepted'][8:]}
        matched = {row['Q_target_N']: row for row in states[8:]}
        ndm = {row['Qy_N']: row for row in native['accepted']}
        common = sorted(old_asd.keys() & matched.keys() & ndm.keys())
        pairs = [comparison(q, old_asd[q], matched[q], ndm[q], length) for q in common]
        assert len(pairs) == 8 and common[0] == 2500. and common[-1] == 20000.
        early = common[:5]
        assert early[-1] == 12500.
        assert all(old_asd[q]['field'] == matched[q]['field'] for q in early)
        assert cut_stress['stress'][8:13] == tensors['stress'][8:13]
        assert cut_stress['steel'][8:13] == tensors['steel'][8:13]
        final_q = schedule[-1]
        final_asd, final_curvature = response(matched[final_q], length)
        return {
            'arm_mm': ARM, 'original_torsion_prefix_bit_exact': 8,
            'matched_mixed_fields': len(schedule), 'extra_OpenSees_substeps': 0,
            'maximum_equilibrium_MPa': max(norms), 'maximum_mixed_equilibrium_MPa': max(norms[8:]),
            'steel': history, 'common_points': pairs, 'identical_early_mixed_fields': len(early),
            'last_Qy_N': final_q, 'last_ASD_twist_rad_per_m': final_asd,
            'last_ASD_kappaX_per_m': final_curvature,
            'last_NDM_twist_rad_per_m': ndm[final_q]['twist_rad_per_m'],
            'last_NDM_kappaX_per_m': ndm[final_q]['kappaX_per_m'],
            'physical_limit_established': False,
        }


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    parser.add_argument('--state', type=Path, default=HERE / 'MatchedHistory.json')
    parser.add_argument('--stress', type=Path, default=HERE / 'MatchedHistory.stress.json.gz')
    parser.add_argument('--simulate', action='store_true')
    args = parser.parse_args()
    if args.simulate:
        simulate(args.repo.resolve(), args.state, args.stress)
    write_json(args.report, verify(args.repo.resolve(), args.state, args.stress))
    print('MVT2 MATCHED HISTORY OFFLINE PASS')
