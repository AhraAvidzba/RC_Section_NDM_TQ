"""Replay the archived HardShear B evidence against the pinned installed-book result."""
from argparse import ArgumentParser
from hashlib import sha256
from json import loads
from pathlib import Path, PureWindowsPath
from runpy import run_path
from zipfile import Path as ZipPath, ZipFile

HERE = Path(__file__).resolve().parent
BASE_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
VARIANT_SHA = "375F826A3ECD152807593B0A6B7A688F5FB82C7A5DE7DAD458A66F61AFC276FD"
PATCH_SHA = "9A2F7D6947835650427339F7B2AC3A80DD87AE570B5EC3A6CE049B4DA1CF8BB7"
STOCK_REL = "docs/regression/Coupled6D/HardShearInstalledStockTiming20261117.zip"
STOCK_SHA = "C452D2A59077C5DA5F6667DDD5ADF33778A0681F1B955A0E091FB08D8D2EE24F"
CLASS = "src/Solver/CCoupledNewtonSolver.cls"
MOD = "CCoupledNewtonSolver"


def json_file(path):
    return loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def check(root, repo):
    manifest = json_file(root / "SHA256SUMS.json")
    actual_files = {file.relative_to(root).as_posix() for file in root.rglob("*") if file.is_file()}
    assert actual_files == set(manifest) | {"SHA256SUMS.json"}
    for name, expected in manifest.items():
        path = (root / name).resolve()
        assert path.is_relative_to(root) and digest(path) == expected, name
    assert manifest[CLASS] == VARIANT_SHA and manifest["DiagnosticTextOnly.patch"] == PATCH_SHA

    staging = json_file(root / "ABManifest.json")
    assert staging["inputs"][CLASS] == VARIANT_SHA and staging["inputs"]["DiagnosticTextOnly.patch"] == PATCH_SHA
    assert staging["book_sha256"] == BASE_SHA and staging["modules"] == [MOD]
    for name in ("Run-FullAB.ps1", "Verify-FullAB.py"):
        assert staging["inputs"][name] == manifest[name]
    compiled = json_file(root / "docs/regression/CodeUpdate.json")
    closure = json_file(root / "CompileClosure.json")
    assert compiled["Compiled"] and not compiled["ProductionChanged"]
    assert compiled["ProductionSHA256"] == BASE_SHA and compiled["Modules"] == [MOD]
    assert PureWindowsPath(compiled["Workbook"]) == PureWindowsPath(
        r"D:\CodexScratch\RC_Section_NDM_TQ\HardBranchGenericAB1\docs\regression\Diagnostic.xlsm"
    )
    assert closure["State"] == "Absent"
    compile_log = (root / "Compile.log").read_text(encoding="utf-8-sig")
    assert compile_log.count(f"OWNED_EXCEL: id={closure['PID']}; utcStartTicks={closure['StartTicksUTC']}") == 1

    verify_ab = run_path(str(root / "Verify-FullAB.py"))
    original = repo / STOCK_REL
    assert digest(original) == STOCK_SHA
    with ZipFile(original) as stock:
        a = verify_ab["native"](ZipPath(stock, at="Native/"), BASE_SHA)
        reference = loads(stock.read("StockProof.json"))
        assert a["report_sha256"] == reference["report_sha256"] and a["trace_sha256"] == reference["trace_sha256"]
        assert a["results_reopened_sha256"] == reference["reopened_results_sha256"]
    b = verify_ab["native"](root / "Native/B", compiled["WorkbookSHA256"])
    assert max(abs(x - y) for x, y in zip(a["direct_N_Nmm"], b["direct_N_Nmm"], strict=True)) < 0.001
    result = json_file(root / "ABVerification.json")
    assert result == {"stock_source": "archive §490", "A": a, "B": b, "matched_runtime_delta_s": None}
    return result


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    result = check(HERE, parser.parse_args().repo.resolve())
    print("HARDSHEAR WORKBOOK B PORTABLE VERIFIED")
    for arm in ("A", "B"):
        result_row = result[arm]
        print(arm, result_row["capacity_status"], result_row["lower_lambda"],
              result_row["limit_lambda"], result_row["probes"], result_row["timing_s"]["results"])
