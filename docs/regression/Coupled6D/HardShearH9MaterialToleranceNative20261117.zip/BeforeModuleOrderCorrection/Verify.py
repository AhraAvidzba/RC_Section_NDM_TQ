"""Отделяет влияние численного допуска бетона от смены истории и меры HardShear."""

import argparse
import json
from math import isclose
from pathlib import Path
import re
from tempfile import TemporaryDirectory

import FrozenVerify as native


HERE = Path(__file__).resolve().parent
ARMS = ("Stock", "Tight")
BASE_TERMINAL = "D84FFD33C26BF9A6E4F66D931BC2FD38168DC996E6BA5DCD6DF7315944039FFA"


def parse_trace(path):
    rows = path.read_text(encoding="cp1251").splitlines()
    header = rows[0]
    assert header == "HARDSHEAR-YIELD-GATE;1"
    tag, *anchor = rows[1].split(";")
    assert tag == "ACCEPTED-H8" and len(anchor) > 3500
    names = {}
    current = active = None
    for row in rows[2:]:
        key, *details = row.split(";")
        if key == "ARM":
            assert current is None and len(details) == 2 and details[0] not in names
            current = {"name": details[0], "fraction": native.number(details[1]), "buffer_checks": 0,
                       "rows": [header], "material": {}}
        elif key == "ARM-END":
            assert current["name"] == details[0] and active is None and current["buffer_checks"] == 12
            assert tuple(current["material"]) == native.STEPS
            names[current["name"]] = current
            current = None
        elif key == "BEGIN":
            assert active is None
            active = native.number(details[0])
            current["rows"].append(row)
        elif key == "END":
            assert active == native.number(details[0])
            active = None
            current["rows"].append(row)
        elif key in ("HISTORY-BEFORE", "HISTORY-AFTER"):
            assert active is not None and details == anchor
            assert current["buffer_checks"] % 2 == int(key.endswith("AFTER"))
            current["buffer_checks"] += 1
        elif key == "MATERIAL-TOL":
            assert active is not None and active not in current["material"] and len(details) == 4
            current["material"][active] = native.numbers(details)
        else:
            assert current is not None
            current["rows"].append(row)
    assert tuple(names) == ARMS and current is None
    assert [names[arm]["fraction"] for arm in ARMS] == [1., 0.1]
    return names, len(anchor)


def closed(prep):
    code, comp = native.read("docs/regression/CodeUpdate.json"), native.read("CompileClosure.json")
    assert code["Compiled"] and not code["ProductionChanged"] and code["ProductionSHA256"] == prep["source_workbook_sha256"]
    assert code["Modules"] == prep["diagnostic_modules"] and not code["EntryPointNames"] and not code["RetiredModules"]
    log = (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    assert comp["State"] == "Absent" and f"OWNED_EXCEL: id={comp['PID']}; utcStartTicks={comp['StartTicksUTC']}" in log
    assert "PRIVATE_CODE_READY: modules=5; production unchanged=True" in log
    owner = native.read("Native/HardShear.txt.Ownership.json")
    process = native.read("Native/HardShear.txt.ProcessClosure.json")
    cleanup = native.read("Native/HardShear.txt.RunnerCleanup.json")
    final = process["Closure"]["FinalState"]
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == code["WorkbookSHA256"]
    assert process["Passed"] and process["ChildHasExited"] and final["State"] == "Absent" and process["ChildExitCode"] == 0
    assert (owner["PID"], owner["StartTicksUTC"]) == (final["PID"], final["StartTicksUTC"])
    assert process["RunnerCleanupValid"] and process["RunnerCleanup"] == cleanup
    assert cleanup["QuitRequested"] and cleanup["QuitSucceeded"] and not cleanup["Failed"]
    assert not process["OrdinaryPathKilledAnything"]
    text = (HERE / "Native/HardShear.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_HARD_SHEAR_YIELD_GATE: passed=1; failed=0" in text
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in text
    reopened = re.search(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=\1; equal=True;", text, re.M)
    clock = re.search(r"^RANK_TIME: ([^\n\r]+)", text, re.M)
    return {"reopened_sha256": reopened[1], "elapsed_seconds": float(clock[1].replace(",", ".")),
            "compiled_workbook_sha256": code["WorkbookSHA256"], "owner_closed": True, "compiler_closed": True}


def trial_arms(path, prep):
    traces, values_per_state = parse_trace(path)
    resolved = {}
    prior_meta, prior_samples = native.discover(HERE / "Prior/HardYieldGate.csv")
    prior_result = native.read("Prior/Verification.json")
    expected = native.read("Expected.json")
    medley = []
    with TemporaryDirectory(prefix="hardtol-", dir=HERE / "Native") as folder:
        for label in ARMS:
            lane = traces[label]
            tsv = Path(folder) / (label + ".csv")
            tsv.write_text("\n".join(lane["rows"]) + "\n", encoding="cp1251", newline="\n")
            meta, probes = native.discover(tsv)
            assert meta == prior_meta, label
            assert [probe["plan"] for probe in probes] == [probe["plan"] for probe in prior_samples]
            tolerance_rows = lane["material"]
            ratios = [tuple(values[:3]) for values in tolerance_rows.values()]
            assert all(all(isclose(x, prep["arms"][label], rel_tol=1e-15) for x in row) for row in ratios)
            floors = [values[3] for values in tolerance_rows.values()]
            assert min(floors) == max(floors) and min(floors) > 0.
            if not medley:
                medley.append(floors[0])
            else:
                assert isclose(floors[0], medley[0] * 0.1, rel_tol=2e-15)
            outcomes = native.verify_samples(meta, probes, expected)
            intervals = native.intervals(outcomes, probes)
            resolved[label] = {"material_return_ratio": prep["arms"][label], "station_22_minus_return_tolerance_MPa": floors[0],
                               "native_H8_buffer_checks": lane["buffer_checks"], "samples": outcomes, **intervals}
            if label == "Stock":
                raw_same = probes == prior_samples
                archived_shape = json.loads(json.dumps(outcomes))
                outcome_same = archived_shape == prior_result["samples"] and all(prior_result[k] == v for k,v in intervals.items())
                resolved[label]["identical_to_prior_native_raw_probes"] = raw_same
                resolved[label]["identical_to_prior_native_classification"] = outcome_same
    return values_per_state, resolved


def compare(arms):
    a, b = (arms[name] for name in ARMS)
    exactly_same = a["identical_to_prior_native_raw_probes"] and a["identical_to_prior_native_classification"]
    paired = []
    for p, q in zip(a["samples"], b["samples"], strict=True):
        assert p["target_control"] == q["target_control"] and p["h"] == q["h"]
        same = None
        displacement = margin = None
        if p.get("original_equilibrium_certified") and q.get("original_equilibrium_certified"):
            displacement = q["factor"] - p["factor"]
            same = p["material_side"] == q["material_side"]
            if p["factor_uncertainty"] is not None and q["factor_uncertainty"] is not None:
                margin = p["factor_uncertainty"] + q["factor_uncertainty"] - abs(displacement)
        paired.append({"h": p["h"], "both_certified": displacement is not None,
                       "tight_minus_stock_lambda": displacement, "same_material_side": same,
                       "lambda_interval_overlap_margin": margin})
    target_scope = "same_history_equilibrium_bracket_and_signed_secants"
    preserved = a["conclusion_scope"] == b["conclusion_scope"] == target_scope
    if not exactly_same:
        verdict = "stock_control_arm_drift_report_only"
    elif not preserved:
        verdict = "tight_bracket_or_signs_open"
    elif a["chosen_h_pair"] != b["chosen_h_pair"]:
        verdict = "both_signed_same_history_brackets_with_relocated_switch"
    elif all(row["both_certified"] and row["same_material_side"] and
             row["lambda_interval_overlap_margin"] is not None and row["lambda_interval_overlap_margin"] >= 0. for row in paired):
        verdict = "same_signed_bracket_and_overlapping_load_intervals_at_tenfold_tighter_return"
    else:
        verdict = "same_signed_bracket_with_material_or_load_sensitivity"
    return {"outcome": verdict, "stock_agreed_with_prior": exactly_same, "paired_samples": paired,
            "physical_limit_certified": False}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--inputs", action="store_true")
    scope = cli.parse_args()
    prep = native.read("Fixture.json")
    assert all(native.file_sha(HERE / name) == sha for name, sha in prep["inputs"].items())
    assert native.file_sha(HERE / "Prior/Verification.json") == BASE_TERMINAL == prep["prior_H9_report_sha256"]
    assert prep["arms"] == {"Stock": 1e-8, "Tight": 1e-9}
    workbook = HERE / prep["workbook"]
    if workbook.is_file():
        assert native.file_sha(workbook) == prep["source_workbook_sha256"]
    if scope.inputs:
        print("HARDSHEAR TOLERANCE INPUTS", native.file_sha(HERE / "Fixture.json"), "workbook-present=" + str(workbook.is_file()))
        return
    proof = closed(prep)
    path = HERE / "Native/HardYieldGate.csv"
    size, arms = trial_arms(path, prep)
    result = {"current_book_sha256": prep["source_workbook_sha256"], "native_trace_sha256": native.file_sha(path),
              "same_committed_values_per_snapshot": size, "proof": proof, "arms": arms, **compare(arms)}
    out = HERE / "Native/Verification.json"
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("HARDSHEAR MATERIAL TOLERANCE AUDITED", result["outcome"], native.file_sha(out))


if __name__ == "__main__":
    if not __debug__:
        raise SystemExit("Use Python without -O")
    main()
