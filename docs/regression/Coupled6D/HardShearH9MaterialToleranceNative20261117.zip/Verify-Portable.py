"""Повторяет сверку чувствительности HardShear и исправления порядка модулей."""

import argparse
from difflib import unified_diff
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import Verify as experiment
from FrozenVerify import file_sha, read


HERE = Path(__file__).resolve().parent
FIXTURE = "5C82DE6C984FD3799EAF9AF8C6A83DFEC62EB0E97C7750E3DE88FE0EB6174255"
OLD_FIXTURE = "0F0DD68010DAAA73DC5EB339CB53203D7F3A18A2E9805BB02AE09B2AAC13095F"
BOOK = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
DIAGNOSTIC = "3717AD06C8A327B04ACC10A7969967280F58C0FB1C9FE39D615C5E04CFF50FA0"
TERMINAL = "57745E4D9B7A562E856A97B3844DA0FA5989528F325D507AA76C2A02A048D1D9"
RAW = "F46656CF533F1E5E54C0A3D90CB7D8375354B0006DD6A6894438F45C8B7CFE21"
CORRECTION = "BeforeModuleOrderCorrection"


def verify_inputs(args):
    files = read("SHA256SUMS.json")
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file()
              and p.name != "SHA256SUMS.json" and "__pycache__" not in p.parts}
    assert actual == set(files)
    for name, expected in files.items():
        assert Path(name).suffix.lower() not in {".xlsm", ".xlsx", ".xls", ".ndm"}
        assert Path(name).name.lower() != "vba_all_code.txt"
        assert file_sha(HERE / name) == expected, name
    fixture = read("Fixture.json")
    assert file_sha(HERE / "Fixture.json") == FIXTURE
    assert fixture["source_workbook_sha256"] == BOOK and fixture["arms"] == {"Stock": 1e-8, "Tight": 1e-9}
    assert all(file_sha(HERE / name) == expected for name, expected in fixture["inputs"].items())
    assert fixture["prior_H9_report_sha256"] == file_sha(HERE / "Prior/Verification.json")
    if args.workbook:
        assert file_sha(args.workbook) == BOOK
    if args.diagnostic_workbook:
        assert file_sha(args.diagnostic_workbook) == DIAGNOSTIC
    return fixture


def verify_change(fixture):
    source = HERE / CORRECTION
    assert file_sha(source / "Fixture.json") == OLD_FIXTURE
    before = read(f"{CORRECTION}/Fixture.json")
    assert before["inputs"].keys() == fixture["inputs"].keys()
    changed = {name for name, value in before["inputs"].items() if value != fixture["inputs"][name]}
    assert changed == {"Run.ps1", "Verify.py"}
    assert before | {"inputs": fixture["inputs"]} == fixture
    replacements = {
        "Run.ps1": ("($code.Modules -join ',') -cne ($modules -join ',')",
                    "(($code.Modules | Sort-Object) -join ',') -cne (($modules | Sort-Object) -join ',')"),
        "Verify.py": ('code["Modules"] == prep["diagnostic_modules"]',
                      'sorted(code["Modules"]) == sorted(prep["diagnostic_modules"])'),
    }
    for name, (old, new) in replacements.items():
        assert file_sha(source / name) == before["inputs"][name]
        old_source = (source / name).read_text(encoding="utf-8")
        new_source = (HERE / name).read_text(encoding="utf-8")
        assert old_source.count(old) == 1 and old_source.replace(old, new) == new_source
    expected_diff = []
    for name in ("Run.ps1", "Verify.py", "Fixture.json"):
        old = (source / name).read_text(encoding="utf-8").splitlines(keepends=True)
        new = (HERE / name).read_text(encoding="utf-8").splitlines(keepends=True)
        expected_diff.extend(unified_diff(old, new, fromfile=f"{CORRECTION}/{name}", tofile=name))
    assert "".join(expected_diff) == (HERE / "ModuleOrderCorrection.diff").read_text(encoding="utf-8")
    code = read("docs/regression/CodeUpdate.json")
    assert code["WorkbookSHA256"] == DIAGNOSTIC and code["ProductionSHA256"] == BOOK
    observed, expected = code["Modules"], fixture["diagnostic_modules"]
    assert observed != expected and len(observed) == len(expected) == 5 and sorted(observed) == sorted(expected)
    assert code["Compiled"] and not code["ProductionChanged"] and not code["TraceGeometry"]


def verify_sources(fixture):
    for name, expected in fixture["production"].items():
        baseline = HERE / "ProductionSource" / name
        assert file_sha(baseline) == expected
        stock = baseline.read_text(encoding="utf-8-sig").rstrip()
        overlay = (HERE / name).read_text(encoding="utf-8").rstrip()
        if name.endswith("CCoupledConcreteResponse.cls"):
            section = "' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Меняет только численный допуск"
            runtime = overlay.split(section, 1)[0].rstrip()
            assert runtime.count("mHardYieldRatioTest * cc") == 7
            runtime = runtime.replace("Private mHardYieldRatioTest As Double\n", "")
            runtime = runtime.replace("    mHardYieldRatioTest = YIELD_TOLERANCE_RATIO\n", "")
            assert runtime.replace("mHardYieldRatioTest * cc", "YIELD_TOLERANCE_RATIO * cc") == stock
            assert "mCachedEpoch(point) = 0" in overlay and "mHardYieldRatioTest = chosen" in overlay
        elif name.endswith(("CCoupledReinforcedResponse.cls", "CCoupledNewtonSolver.cls")):
            assert overlay.startswith(stock + "\n\n' -------------------- ДЛЯ ТЕСТОВ --------------------")
    runner = experiment.closed(fixture)
    assert runner["compiled_workbook_sha256"] == DIAGNOSTIC
    clean = read("Native/HardShear.txt.RunnerCleanup.json")
    assert clean["OwnerVerified"] and clean["Errors"] == []
    assert runner["reopened_sha256"] == "1A4A422F3123751B1292C131D5EBBC5AD54A5461CF907A65649D0A94B381A7D7"
    staging = read("CompileClosure.json")
    owner = read("Native/HardShear.txt.Ownership.json")
    assert (staging["PID"], staging["StartTicksUTC"]) != (owner["PID"], owner["StartTicksUTC"])
    return runner


def main():
    if not __debug__:
        raise SystemExit("Use Python without -O")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook", type=Path)
    parser.add_argument("--diagnostic-workbook", type=Path)
    args = parser.parse_args()
    fixture = verify_inputs(args)
    verify_change(fixture)
    proof = verify_sources(fixture)
    path = HERE / "Native/HardYieldGate.csv"
    assert file_sha(path) == RAW
    lines, buffers = experiment.parse_trace(path)
    a, b = (lines[label] for label in ("Stock", "Tight"))
    assert a["rows"] == b["rows"] and len(a["rows"]) == 1209
    size, arms = experiment.trial_arms(path, fixture)
    assert buffers == size == 3672
    result = {"current_book_sha256": BOOK, "native_trace_sha256": RAW, "same_committed_values_per_snapshot": size,
              "proof": proof, "arms": arms, **experiment.compare(arms)}
    assert file_sha(HERE / "Native/Verification.json") == TERMINAL
    assert json.loads(json.dumps(result)) == read("Native/Verification.json")
    assert result["outcome"] == "same_signed_bracket_and_overlapping_load_intervals_at_tenfold_tighter_return"
    assert result["stock_agreed_with_prior"] and not result["physical_limit_certified"]
    assert all(pair["both_certified"] and pair["same_material_side"] and pair["tight_minus_stock_lambda"] == 0.
               for pair in result["paired_samples"])
    print("129 STATIONS, 12 EQUILIBRIA, 24 IDENTICAL H8 SNAPSHOTS, 1209 EXACT CALCULATION LINES PER ARM")
    print("LOCAL F TOLERANCE 1.6e-7 -> 1.6e-8 MPa, MAX DELTA LAMBDA 0, NO RECOMPILE")
    print("HARDSHEAR H9 MATERIAL TOLERANCE PORTABLE VERIFIED", TERMINAL)


if __name__ == "__main__":
    main()
