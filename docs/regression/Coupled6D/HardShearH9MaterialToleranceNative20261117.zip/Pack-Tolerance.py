"""Собирает автономный архив парной нативной проверки HardShear."""

from difflib import unified_diff
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from tempfile import TemporaryDirectory


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
SOURCE = Path("D:/CodexScratch/RC_Section_NDM_TQ/HardH9TolFinal")
BOOK = "workbook/output/RC_Section_NDM.xlsm"
CORRECTION = "BeforeModuleOrderCorrection"
DIAGNOSTIC = "3717AD06C8A327B04ACC10A7969967280F58C0FB1C9FE39D615C5E04CFF50FA0"


def main():
    spec = spec_from_file_location("pack", HERE.parent / "mvbridge-proof/Pack.py")
    pack = module_from_spec(spec)
    spec.loader.exec_module(pack)
    pack.HERE, pack.CURRENT = HERE, SOURCE
    pack.OUT = HERE / "HardShearH9MaterialToleranceNative20261117.zip"
    prep = json.loads((SOURCE / "Fixture.json").read_bytes())
    assert pack.digest(REPO / BOOK) == prep["source_workbook_sha256"] == pack.digest(SOURCE / BOOK)
    assert pack.digest(SOURCE / "docs/regression/Diagnostic.xlsm") == DIAGNOSTIC
    prior = REPO / "docs/regression/Coupled6D/HardShearH9EquilibriumNative20261117.zip"
    assert pack.digest(prior) == prep["prior_H9_archive_sha256"]
    actual = {"Fixture.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json", *prep["inputs"]}
    actual.update(path.relative_to(SOURCE).as_posix() for path in (SOURCE / "Native").iterdir() if path.is_file())
    original = ("Run.ps1", "Verify.py", "Fixture.json")
    with TemporaryDirectory(prefix="diff-", dir=HERE) as temp:
        diff_file = Path(temp) / "ModuleOrderCorrection.diff"
        diff = []
        for name in original:
            a = (SOURCE / CORRECTION / name).read_text(encoding="utf-8").splitlines(keepends=True)
            b = (SOURCE / name).read_text(encoding="utf-8").splitlines(keepends=True)
            diff.extend(unified_diff(a, b, fromfile=f"{CORRECTION}/{name}", tofile=name))
        diff_file.write_text("".join(diff), encoding="utf-8", newline="\n")

        def inputs():
            for name in sorted(actual):
                yield SOURCE / name, name
            for name in original:
                yield SOURCE / CORRECTION / name, CORRECTION + "/" + name
            for name, sha in prep["production"].items():
                source = REPO / name
                assert pack.digest(source) == sha
                yield source, "ProductionSource/" + name
            yield diff_file, diff_file.name
            for name in ("Verify-Portable.py", "Pack-Tolerance.py", "README-Portable.md"):
                yield HERE / name, name

        pack.locate_files = inputs
        pack.main()


if __name__ == "__main__":
    main()
