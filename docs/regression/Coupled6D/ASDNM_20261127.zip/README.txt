ASD NM 2026-11-27. Exact native evidence, not a production workbook release.
Primary/ExecutedWorkbook.xlsm is the actual workbook used by native Excel.
Primary/tests contains the two diagnostic modules. Original methods are unchanged.
Primary/Replay-TestNM.py replays final and longest paths using OpenSees 3.8.0.
After extraction run: python Primary/Replay-TestNM.py --root Primary/Case01
For the longest followed history add --longest. Repeat for Case01..Case12.
The script requires NumPy and openseespy/openseespywin 3.8.0; two existing local
package locations are tried before normal imports. No network dependency is used.
The section fields are prescribed to OpenSees material points. The external
library does not independently solve the global section equilibrium.
Repeat/ColdRepeatProof.json records exact comparisons except elapsed time.
Some staging/audit scripts keep original absolute investigation paths; the
executed workbook, binary inputs, final replay and accepted fields are included.
Source public workbook was captured from bdeebf7 before concurrent worktree
updates. Those external updates and all uncommitted user files are excluded.
All entries except Manifest.json are checked against its bytes and SHA256.
