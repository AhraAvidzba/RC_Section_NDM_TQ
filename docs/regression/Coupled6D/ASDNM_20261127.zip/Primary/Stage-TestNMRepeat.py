"""ДЛЯ ТЕСТОВ. Повторяет три характерных NM на той же сохранённой книге с новыми объектами и историей."""
from pathlib import Path
import struct,shutil,json,hashlib
parent=Path(__file__).resolve().parent
root=parent.parent/'Cold1131ASDNMRepeat_20261127'
assert not root.exists()
for folder in ('Native','Temp','Input','docs/regression'):(root/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(parent/'tools',root/'tools')
for name in ('Guard-IsolatedOffice.ps1','Run-TestNM.ps1'):
    shutil.copyfile(parent/name,root/name)
for name in ('Diagnostic.xlsm','CodeUpdate.json'):
    shutil.copyfile(parent/'docs/regression'/name,root/'docs/regression'/name)
raw=(parent/'Input/Loads.bin').read_bytes()
indices=[3,10,11]
(root/'Input/Loads.bin').write_bytes(struct.pack('<i',len(indices))+b''.join(raw[4+48*(i-1):4+48*i] for i in indices))
for i in range(1,len(indices)+1):(root/f'Case{i:02}/Native').mkdir(parents=True)
(root/'RepeatMap.json').write_text(json.dumps(dict(parent=str(parent),indices=indices,same_compiled_workbook=True),indent=2)+'\n')
shutil.copyfile(Path(__file__),root/Path(__file__).name)
prep=dict(scope='Directed cold repeat of tension, compression/biaxial and steel overload NM',inputs={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in root.rglob('*') if p.is_file() and p.relative_to(root).as_posix()!='docs/regression/Diagnostic.xlsm'})
(root/'Preparation.json').write_text(json.dumps(prep,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('THREE COLD NM REPEATS PREPARED',root)
