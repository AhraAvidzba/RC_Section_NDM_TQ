"""ДЛЯ ТЕСТОВ. Сверяет фактический VBA и неизменность исходных численных методов."""
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile
import sys,json
sys.path.insert(0,'D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython')
r=Path(__file__).resolve().parent
scope=run_path('D:/CodexScratch/RC_Section_NDM_TQ/RestoredASDScaleRobustness_20261127/Helpers/Inspect-TestResolutionVBA.py')
helper,body,reader=scope['TestHelpers'](Path.cwd())
def TestLoad(p):
    """Читает исходный текст из фактически сохранённого бинарного проекта."""
    with ZipFile(p) as z:return reader(helper['TestContainer'](z.read('xl/vbaProject.bin')))[1]
def TestCanonical(txt,name):
    """Учитывает пустые документные модули; исполняемый текст сверяется штатным декодером."""
    try:return body(txt,name)[0].strip()
    except IndexError:
        code=[s for s in txt.splitlines() if s.strip() and not s.lstrip().startswith(("'",'Attribute '))]
        assert not code
        return ''
a=TestLoad(r/'Before/RC_Section_NDM.xlsm');b=TestLoad(r/'docs/regression/Diagnostic.xlsm')
changed=[name for name in a if TestCanonical(a[name],name)!=TestCanonical(b[name],name)]
added=sorted(set(b)-set(a))
assert changed==['CCoupledSectionAnalysis']
assert added==['CTestASDNMProgress','modTestASDNMCheck']
trimmed=b['CCoupledSectionAnalysis'].rsplit("' --------------------",1)[0]
assert TestCanonical(trimmed,'CCoupledSectionAnalysis')==TestCanonical(a['CCoupledSectionAnalysis'],'CCoupledSectionAnalysis')
for name in added:
    source=next((r/'tests').glob(name+'.*')).read_text('utf-8-sig')
    expected,_=helper['TestMVTCompilerBody'](body,source,name)
    assert expected.strip()==TestCanonical(b[name],name),name
proof=dict(before_count=len(a),after_count=len(b),changed_components=changed,added_components=added,
           all_original_methods_unchanged=True,other_256_components_unchanged=True,new_test_modules_match_sources=True)
fixture_line=next(s for s in (r/'Native/RealColdReplay.txt').read_text('utf-8-sig').splitlines() if s.startswith('FIXTURE: '))
fixture=Path(fixture_line.removeprefix('FIXTURE: '))
actual=TestLoad(fixture)
assert set(actual)==set(b)
assert all(TestCanonical(actual[name],name)==TestCanonical(b[name],name) for name in actual)
proof['executed_fixture_all259_component_sources_match_compiled']=True
with ZipFile(fixture) as z: executed_binary=z.read('xl/vbaProject.bin')
with ZipFile(r/'docs/regression/Diagnostic.xlsm') as z: compiled_binary=z.read('xl/vbaProject.bin')
proof['executed_fixture_vba_binary_bitexact_compiled']=executed_binary==compiled_binary
(r/'Native/VBAComparison.json').write_text(json.dumps(proof,indent=2)+'\n')
print('FACTUAL VBA VERIFIED',proof)
