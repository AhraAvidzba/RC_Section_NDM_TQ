"""ДЛЯ ТЕСТОВ. Создаёт отдельную книгу и холодные сочетания NM без изменения выдачи."""
from pathlib import Path
import hashlib, json, shutil, struct

repo = Path.cwd()
base = Path('D:/CodexScratch/RC_Section_NDM_TQ')
parent = base / 'Cold1126ASDCoordinates_20261127'
old = base / 'Cold1116WorkingASDRetryNoObserver_20261127'
root = base / 'Cold1130ASDNM_20261127'
assert not root.exists()
for folder in ('src/Solver', 'tests', 'Native', 'Temp', 'docs/regression', 'Before', 'workbook/output', 'Input'):
    (root / folder).mkdir(parents=True, exist_ok=True)
shutil.copytree(parent / 'tools', root / 'tools')
shutil.copyfile(parent / 'Guard-IsolatedOffice.ps1', root / 'Guard-IsolatedOffice.ps1')
book = (repo / 'workbook/output/RC_Section_NDM.xlsm').read_bytes()
assert hashlib.sha256(book).hexdigest().upper() == '458801DDC43378DB7BCDD1AA8F93AF583D09B629459E271CD1187ECE2EEA5CD6'
for path in ('Before/RC_Section_NDM.xlsm', 'docs/regression/Diagnostic.xlsm', 'workbook/output/RC_Section_NDM.xlsm'):
    (root / path).write_bytes(book)
(root / 'ParentCodeUpdate.json').write_text(json.dumps(dict(WorkbookSHA256=hashlib.sha256(book).hexdigest().upper()))+'\n')

source = (repo / 'src/Solver/CCoupledSectionAnalysis.cls').read_text('utf-8-sig')
source += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает подготовленные операторы только для экспорта в частной контрольной книге.
Friend Function TestNMPreparedOperators() As CCoupledElasticState
    Set TestNMPreparedOperators = mOperators
End Function
'''
(root / 'src/Solver/CCoupledSectionAnalysis.cls').write_text(source, encoding='utf-8-sig')
observer = (old / 'tests/CCoupledProgressObserverTest.cls').read_text('utf-8-sig').replace('CCoupledProgressObserverTest', 'CTestASDNMProgress')
(root / 'tests/CTestASDNMProgress.cls').write_text(observer, encoding='utf-8-sig')
original = (old / 'tests/modTestSelectableMaterialCore.bas').read_text('utf-8-sig')
build = original.split('Private Sub TestRunASDDirectPureNCase',1)[1].split('    Dim geometry',1)[1].split('    loads.Initialize',1)[0]
helpers = original.split('Private Sub TestWriteHardPreparedOperators',1)[1].split('Public Sub TestCapturePeakRefinement',1)[0]
# Ограничиваем помощники тремя процедурами, без исходного диагностического состояния.
helpers = 'Private Sub TestWriteHardPreparedOperators' + helpers
helpers = helpers.split('End Function',2)[0] + 'End Function\n'
vector = original.split('Private Sub TestWriteVector',1)[1].split('End Sub',1)[0]
vector = 'Private Sub TestWriteVector' + vector + 'End Sub\n'
module = '''Attribute VB_Name = "modTestASDNMCheck"
Option Explicit
' ==========================================================================
' ДЛЯ ТЕСТОВ: холодные NM и независимый экспорт фактических операторов.
' ==========================================================================

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выполняет все заданные сочетания с отдельной нулевой материальной историей.
Public Function TestRunASDNMCases(ByVal folder As String) As String
    On Error GoTo Failed
    Dim handle As Integer: handle = FreeFile
    Open folder & "\\Input\\Loads.bin" For Binary Access Read As #handle
    Dim count As Long, index As Long, component As Long, target(1 To 6) As Double, report As String
    Get #handle, , count
    If count < 1 Or LOF(handle) <> 4 + 48 * count Then Err.Raise 5, , "Неверная матрица шести усилий NM."
    For index = 1 To count
        For component = 1 To 6: Get #handle, , target(component): Next component
        TestRunASDNMCase folder & "\\Case" & Format$(index, "00"), target, report
    Next index
    Close #handle: handle = 0
    TestRunASDNMCases = report & "TOTAL_NM_EXECUTION: passed=" & CStr(count) & "; failed=0"
    Exit Function
Failed:
    Dim reason As String: reason = Err.Source & " " & Err.Description
    If handle <> 0 Then Close #handle
    TestRunASDNMCases = "RUNTIME ERROR: " & reason
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет поля, историю, точные результирующие и действительную диагностику.
Private Sub TestRunASDNMCase(ByVal folder As String, ByRef target() As Double, ByRef report As String)
    Dim geometry''' + build + '''    loads.Initialize target(1), target(2), target(3), 0#, 0#
    loads.SetSpatialComponents target(4), target(5), target(6)
    Dim field() As Double, resultants() As Double, state As CSectionStateResult, trace As CCoupledLoadTrace, meta As CResultMeta
    Dim observer As New CTestASDNMProgress: observer.TestInitializeBinary folder & "\\Native"
    Dim started As Double: started = Timer
    Set meta = analysis.SolveTarget(loads, ChrW$(&H3BB) & "*NMxy", spec, field, resultants, True, state, trace, observer)
    Dim elapsed As Double: elapsed = Timer - started
    If elapsed < 0# Then elapsed = elapsed + 86400#
    TestWriteHardPreparedOperators analysis.TestNMPreparedOperators, folder & "\\Native\\Operators.csv"
    Dim fieldCount As Long, resultantCount As Long
    On Error Resume Next
    fieldCount = UBound(field) - LBound(field) + 1: Err.Clear
    resultantCount = UBound(resultants) - LBound(resultants) + 1: Err.Clear
    On Error GoTo 0
    Dim traceCount As Long, hasState As Long
    If Not trace Is Nothing Then traceCount = trace.Count
    If Not state Is Nothing Then hasState = 1
    Dim handle As Integer: handle = FreeFile
    Open folder & "\\Native\\State.bin" For Binary Access Write As #handle
    Dim magic As String * 16: magic = "NDMNMSTATE000001": Put #handle, , magic
    TestWriteVector handle, target
    TestWriteVector handle, Array(elapsed, meta.InternalStatus, meta.ResultCode, fieldCount, resultantCount, traceCount, hasState)
    Dim emptyCount As Long
    If fieldCount > 0 Then TestWriteVector handle, field Else Put #handle, , emptyCount
    If resultantCount > 0 Then TestWriteVector handle, resultants Else Put #handle, , emptyCount
    Close #handle
    Dim diagnostic As String, policy As New CResultStatusPolicy, status As String
    status = policy.ExternalStatus(meta)
    diagnostic = "Status=" & status & "; returned_state=" & CStr(hasState) & vbCrLf & _
        "Comment=" & meta.ResultComment & vbCrLf & "Details=" & meta.DiagnosticDetails
    Dim stream As Object: Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2: stream.Charset = "utf-8": stream.Open
    stream.WriteText diagnostic: stream.SaveToFile folder & "\\Native\\State.txt", 2: stream.Close
    report = report & "ASD_NM: N=" & CStr(target(1)) & "; Mx=" & CStr(target(2)) & "; My=" & CStr(target(3)) & _
        "; seconds=" & CStr(elapsed) & "; status=" & status & "; returned_state=" & CStr(hasState) & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает двоичный массив без округления.
''' + vector + '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает линейные кинематические и равновесные операторы частной книги.
''' + helpers
(root / 'tests/modTestASDNMCheck.bas').write_text(module, encoding='utf-8-sig')

cases = [
    (28000, 510000, 180000), (-28000,510000,180000),
    (28000,2000000,0), (-100000,2000000,0),
    (28000,-2000000,0), (-100000,-2000000,0),
    (28000,0,1000000), (-100000,0,1000000),
    (28000,2000000,500000), (-100000,2000000,500000),
    (28000,5000000,0), (-100000,8000000,0),
]
(root/'Input/Loads.bin').write_bytes(struct.pack('<i',len(cases))+b''.join(struct.pack('<6d',*row,0,0,0) for row in cases))
for i in range(1,len(cases)+1): (root/f'Case{i:02}/Native').mkdir(parents=True)
shutil.copyfile(base/'Cold1113ASDFreshRetryBendingScales_20261127/Input/MaterialContract.json',root/'Input/MaterialContract.json')
compiler=(parent/'Compile-TestASDCoordinates.ps1').read_text('utf-8-sig').replace("@('CCoupledConcreteResponse','modTestCoupledASDCoordinates')", "@('CCoupledSectionAnalysis','CTestASDNMProgress','modTestASDNMCheck')")
(root/'Compile-TestNM.ps1').write_text(compiler, encoding='utf-8-sig')
runner=(parent/'Run-TestASDCoordinates.ps1').read_text('utf-8-sig').replace('modTestCoupledASDCoordinates.RunTestCoupledASDCoordinates','modTestASDNMCheck.TestRunASDNMCases').replace("-MacroArgument1 (Join-Path $Root 'Input')", '-MacroArgument1 $Root').replace('-TimeoutSeconds 600','-TimeoutSeconds 900')
(root/'Run-TestNM.ps1').write_text(runner,encoding='utf-8-sig')
shutil.copyfile(Path(__file__), root/Path(__file__).name)
prep=dict(scope='Directed cold NM; T=Qx=Qy=0; proportional NMxy path; not full acceptance',cases=cases,baseline_commit='bdeebf7',
    inputs={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in root.rglob('*') if p.is_file() and p.relative_to(root).as_posix() != 'docs/regression/Diagnostic.xlsm'})
(root/'Preparation.json').write_text(json.dumps(prep,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print('NM PREPARED',root,'CASES',len(cases))
