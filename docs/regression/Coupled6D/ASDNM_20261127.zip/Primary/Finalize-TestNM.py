"""ДЛЯ ТЕСТОВ. Сводит NM, холодный повтор и переносимые доказательства в отдельной ветке от main."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile,ZIP_DEFLATED
from io import BytesIO
import json,struct,re,subprocess

root=Path(__file__).resolve().parent
repeat=root.parent/'Cold1131ASDNMRepeat_20261127'
review=root.parent/'NMReviewBranch_20261127'
evidence=review/'docs/reports/evidence/Coupled6DASDNM_2026-11-27'
evidence.mkdir(parents=True,exist_ok=True)
def TestVectors(path):
    """Читает полные двоичные выходы, включая явное отсутствие заданного НДС."""
    raw=path.read_bytes();position=16;result=[]
    while position<len(raw):
        n=struct.unpack_from('<i',raw,position)[0];position+=4
        assert 0<=n<=10000
        result.append(list(struct.unpack_from('<'+str(n)+'d',raw,position)));position+=8*n
    assert position==len(raw)
    return result
def TestNative(folder,count):
    """Проверяет завершение нативного запуска; количество исполнений не считается физической приёмкой."""
    text=(folder/'Native/RealColdReplay.txt').read_text('utf-8-sig')
    assert f'TOTAL_NM_EXECUTION: passed={count}; failed=0' in text
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in text
    assert text.count('SUITE_STARTED:')==text.count('SUITE_FINISHED:')==1
    return json.loads((folder/'Native/RealColdReplay.txt.Ownership.json').read_text('utf-8-sig'))
owners=[TestNative(root,12),TestNative(repeat,3)]
assert json.loads((root/'Native/OfficeClosure.json').read_text('utf-8-sig'))['OwnedExcelProcessesAbsent']
cases=[];all_records=[]
for i in range(1,13):
    folder=root/f'Case{i:02}/Native'
    loads,header,field,resultants=TestVectors(folder/'State.bin')
    status=(folder/'State.txt').read_text('utf-8-sig').split(';')[0].removeprefix('Status=')
    assert status==('FAIL' if i==11 else 'OK')
    assert header[6]==(0 if i==11 else 1) and len(field)==(0 if i==11 else 60)
    assert len(resultants)==(0 if i==11 else 6)
    final=json.loads((folder/'OpenSeesNMEquilibrium.json').read_text())
    longest=json.loads((folder/'OpenSeesNMLongest.json').read_text())
    for check in (final,longest):
        assert check['all56plus4_equations_and_six_resultants_verified']
        assert check['reference_tolerance_violated_states']==0
        all_records.extend(check['records'])
    cases.append(dict(index=i,N_N=loads[0],Mx_Nmm=loads[1],My_Nmm=loads[2],T_Qx_Qy=loads[3:],
        status=status,returned_target_state=bool(header[6]),elapsed_seconds=header[0],
        final_path_states=final['accepted_states'],longest_path_states=longest['accepted_states'],
        last_lambda=final['records'][-1]['lambda_value'],
        last_steel_utilization=final['records'][-1]['steel_strain_utilization']))
repeat_proof=json.loads((repeat/'ColdRepeatProof.json').read_text())
assert len(repeat_proof)==3
maximum_force=max(x['maximum_force_error_N'] for x in all_records)
maximum_moment=max(x['maximum_moment_error_Nmm'] for x in all_records)
summary=dict(scope='Directed ASD NM target equilibrium; not complete physical or normative acceptance',
    source_commit='bdeebf7',source_public_book_sha256='458801DDC43378DB7BCDD1AA8F93AF583D09B629459E271CD1187ECE2EEA5CD6',
    compiled_book_sha256=sha256((root/'docs/regression/Diagnostic.xlsm').read_bytes()).hexdigest().upper(),
    load_path='lambda*NMxy',internal_units='N, Nmm, MPa, mm; positive N=tension',cases=cases,
    statuses=dict(OK=11,FAIL=1,NumFail=0),native_macro_invocations=2,independent_cold_cases=15,
    final_path_states=sum(c['final_path_states'] for c in cases),longest_path_states=sum(c['longest_path_states'] for c in cases),
    path_counts_overlap=True,all56plus4_equations_and_six_resultants_verified=True,
    actual_OpenSees_material_replay=True,external_global_section_solution=False,
    independent_OpenSees_version='3.8.0',independent_binary_sha256='25BA42E1672526137D765D9C3631D1403E091F54F5AFCDB9242F9243C63C3A96',
    maximum_force_error_N=maximum_force,maximum_moment_error_Nmm=maximum_moment,
    maximum_residual_to_original_bound_ratio=max(max(x['physical_residual_MPa'],x['gauge_residual_MPa'],x['six_force_residual_MPa'])/x['original_bound_MPa'] for x in all_records),
    original_absolute_tolerance_MPa=5e-7,original_relative_tolerance=5e-7,
    original_tolerance_violations=0,cold_repeat=repeat_proof,
    bending_reflection=dict(tension_max_strain_delta=2.3852447794681098e-18,compression_max_strain_delta=1.9971004017182992e-16),
    original_numerical_methods_unchanged=True,production_book_not_edited_by_this_task=True,
    other_worktree_changes_excluded=True,main_not_modified=True,
    general_concrete_ASD_criterion_pending=True,whole_search_performance_target_met=False,
    fixed_component_capacity_paths_and_planar_NM_comparison_not_tested=True,
    NM_stage_fully_accepted=False,full_ON_OFF_UI_Focused_AutoCAD_acceptance_run=False,
    owned_processes=owners)
(root/'Summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(evidence/'Summary.json').write_bytes((root/'Summary.json').read_bytes())
files={}
for base,label in ((root,'Primary'),(repeat,'Repeat')):
    for p in base.glob('Case*/Native/*'):
        if p.is_file():files[label+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
    for p in (base/'Native').glob('*'):
        if p.is_file():files[label+'/Native/'+p.name]=p.read_bytes()
    for name in ('Preparation.json','Run.ndjson','RepeatMap.json','ColdRepeatProof.json'):
        p=base/name
        if p.exists():files[label+'/'+name]=p.read_bytes()
    for p in (base/'Input').glob('*'):
        if p.is_file():files[label+'/Input/'+p.name]=p.read_bytes()
for p in root.glob('*.py'):files['Primary/'+p.name]=p.read_bytes()
for p in root.glob('*.ps1'):files['Primary/'+p.name]=p.read_bytes()
for p in (root/'tests').glob('*'):files['Primary/tests/'+p.name]=p.read_bytes()
files['Primary/src/CCoupledSectionAnalysis.cls']=(root/'src/Solver/CCoupledSectionAnalysis.cls').read_bytes()
files['Primary/CodeUpdate.json']=(root/'docs/regression/CodeUpdate.json').read_bytes()
with ZipFile(root/'Before/RC_Section_NDM.xlsm') as z:
    files['Primary/OriginalVBA.bin']=z.read('xl/vbaProject.bin')
with ZipFile(root/'docs/regression/Diagnostic.xlsm') as z:
    files['Primary/CompiledVBA.bin']=z.read('xl/vbaProject.bin')
fixture_line=next(s for s in (root/'Native/RealColdReplay.txt').read_text('utf-8-sig').splitlines() if s.startswith('FIXTURE: '))
fixture=Path(fixture_line.removeprefix('FIXTURE: '));executed=fixture.read_bytes()
with ZipFile(BytesIO(executed)) as z:
    assert z.testzip() is None
    files['Primary/ExecutedVBA.bin']=z.read('xl/vbaProject.bin')
assert json.loads((root/'Native/VBAComparison.json').read_text())['executed_fixture_all259_component_sources_match_compiled']
files['Primary/ExecutedWorkbook.xlsm']=executed
files['Primary/Summary.json']=(root/'Summary.json').read_bytes()
files['README.txt']='''ASD NM 2026-11-27. Exact native evidence, not a production workbook release.
Primary/ExecutedWorkbook.xlsm is the actual workbook used by native Excel.
Primary/tests contains the two diagnostic modules. Original methods are unchanged.
Primary/Replay-TestNM.py replays final and longest paths using OpenSees 3.8.0.
After extraction run: python Primary/Replay-TestNM.py --root Primary/Case01
For the longest followed history add --longest. Repeat for Case01..Case12.
The script requires NumPy and openseespy/openseespywin 3.8.0; two existing local
package locations are tried before normal imports. No network dependency is used.
The section fields are prescribed to OpenSees material points. The external
library does not independently solve the global section equilibrium.
Repeat/ColdRepeatProof.json records exact comparisons except elapsed time.
Some staging/audit scripts keep original absolute investigation paths; the
executed workbook, binary inputs, final replay and accepted fields are included.
Source public workbook was captured from bdeebf7 before concurrent worktree
updates. Those external updates and all uncommitted user files are excluded.
All entries except Manifest.json are checked against its bytes and SHA256.
'''.encode('utf-8')
manifest={name:dict(bytes=len(raw),sha256=sha256(raw).hexdigest().upper()) for name,raw in sorted(files.items())}
files['Manifest.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
archive=review/'docs/regression/Coupled6D/ASDNM_20261127.zip'
archive.parent.mkdir(parents=True,exist_ok=True)
assert not archive.exists()
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
with ZipFile(archive) as z:
    assert z.testzip() is None
    for name,item in manifest.items():
        raw=z.read(name);assert len(raw)==item['bytes'] and sha256(raw).hexdigest().upper()==item['sha256']
archive_proof=dict(archive='docs/regression/Coupled6D/ASDNM_20261127.zip',bytes=archive.stat().st_size,
    sha256=sha256(archive.read_bytes()).hexdigest().upper(),files=len(manifest),all_entries_read_and_sha256_verified=True,
    executed_workbook_sha256=sha256(executed).hexdigest().upper(),executed_workbook_CRC_verified=True)
(evidence/'ArchiveProof.json').write_text(json.dumps(archive_proof,indent=2)+'\n',encoding='utf-8')
rows=[]
for c in cases:
    rows.append(f"| {c['index']} | {c['N_N']/1000:g} | {c['Mx_Nmm']/1e6:g} | {c['My_Nmm']/1e6:g} | {c['status']} | {c['final_path_states']} | {c['elapsed_seconds']:.2f} |")
report='''# Контроль ASD NM перед NMT

По запросу пользователя NM выделен в отдельную проверку перед NMT: N + Mx + My при T = Qx = Qy = 0. На зафиксированной копии рабочего ядра 11 из 12 сочетаний дали НДС заданной нагрузки. В одном случае заданная нагрузка превышает найденный предел деформации продольной стали: получен FAIL, целевое НДС не возвращено. NumFail в этой матрице нет. Это подтверждение перечисленных численных состояний и арматурного отказа; весь этап NM и общая физическая прочность ещё не приняты.

## Модель и границы проверки

Исходный снимок — `bdeebf7`, публичная книга SHA256 `458801DDC43378DB7BCDD1AA8F93AF583D09B629459E271CD1187ECE2EEA5CD6`. Сечение 180×120 мм, два продольных стержня φ12 при x=0, y=±30 мм, замкнутый хомут φ8/100 A240. ASD калибруется действующим ядром: E=30000 МПа, ν=0,2, Gt=0,12 Н/мм, Gc=80 Н/мм, характерная длина 125 мм. Продольная сталь: E=200000 МПа, сопротивления растяжению/сжатию 400/350 МПа, пределы деформации 0,025/0,018; у хомута 240 МПа и 0,02.

Внутренние единицы — Н, Н·мм, мм, МПа; **положительное N означает растяжение**. В таблице усилия переведены в кН и кН·м без изменения знака. Каждое сочетание создаёт собственные объекты и нулевую материальную историю. Применён явный пропорциональный путь λ*NMxy; при λ=1 получается заданное сочетание.

Использованы 60 неизвестных, 25 бетонных и 18 точек замещения бетона арматурой, три продольные станции с безразмерным полушагом 0,001. Исходные допуски 5·10⁻⁷ МПа + 5·10⁻⁷ от масштаба нагрузки и 30 итераций равновесия сохранены. Многоосный закон ASD не заменялся плоским материалом.

## Результаты

| № | N, кН | Mx, кН·м | My, кН·м | Статус прямого НДС | Узлов итогового пути | Время вызова, с |
| --- | ---: | ---: | ---: | --- | ---: | ---: |
'''+ '\n'.join(rows)+f'''

OK означает подтверждённое НДС заданной нагрузки и выполненные применимые арматурные проверки прямого вызова. Он не закрывает незавершённый общий бетонный критерий ASD. В частности, N=−100 кН с Mx=8 кН·м сохранил численное равновесие; повышенная нагрузка сама по себе не обязывает ожидать FAIL.

Для №11 предел стали локализован в интервале λ=[0,734095303536644; 0,734183386716408], то есть около N=20,55 кН и Mx=3,671 кН·м на этой пропорциональной траектории. На последнем сохранённом допустимом узле использование предела стали — 0,999631. При FAIL отсутствуют поле целевой нагрузки, её результирующие и объект целевого НДС; промежуточное состояние не подменяет результат при λ=1.

## Независимая проверка и повторяемость

Настоящий ASDConcrete3D OpenSees 3.8.0 заново повторил материальные истории на сохранённых полях. Сталь независимо восстановлена с пластической историей; заново собраны 56 физических уравнений, четыре условия однозначности и шесть результирующих. Это материальный повтор и независимая сборка, а не независимое глобальное решение сечения библиотекой OpenSees.

Проверены 172 узла итоговых путей и 259 узлов наиболее длинных пройденных ветвей. Эти наборы пересекаются, их числа не складываются в число разных состояний. Нарушений исходных допусков нет; наибольшие абсолютные ошибки сил — {maximum_force:.6g} Н, моментов — {maximum_moment:.6g} Н·мм. Изменение знака Mx в симметричном сечении дало зеркальные поля: максимальные различия компонентов деформации 2,39·10⁻¹⁸ при растяжении и 2,00·10⁻¹⁶ при сжатии.

Холодный повтор №3, №10 и №11 на той же сохранённой книге побитово воспроизвёл численные выходы, все принятые поля, обе трассы, операторы и диагностику; различается только измеренное время. Повтор №9 отдельно не выполнялся.

Фактический VBA прочитан из бинарного проекта: 257 исходных компонентов, 259 в частной книге. В существующий класс добавлен только тестовый читающий метод; все исходные численные методы и остальные 256 компонентов сохранены. Два новых тестовых компонента совпали с исходниками. Исходный текст всех 259 компонентов фактически исполнявшейся книги совпал со скомпилированной копией; бинарные контейнеры VBA различаются и сохранены оба. Штатная выдача этим контролем не редактировалась; параллельные изменения рабочего каталога исключены. Собственные Excel закрыты, их точные личности сохранены в протоколах.

## Что остаётся до принятия NM

Прямые состояния этой матрицы и воспроизводимость трёх характерных случаев подтверждены. Для полного этапа остаются поиск NM-пределов при фиксированной части нагрузки, остальные нужные LoadPath и знаки My, сравнение с плоской НДМ с явным учётом отличающихся материалов и общий бетонный критерий. К NMT следует переходить после этих проверок NM и необходимых отдельных проверок T.

Время №9 — 270,60 с, №3 и №5 — около 22 с. На восстановительных ветвях №3/5/9 решатель проходил дальше λ=1, затем отдельно решал точную заданную нагрузку от принятого левого состояния. Это объясняет избыточную работу, но ускорение здесь не реализовано. Время таблицы относится к вызову SolveTarget с тестовым наблюдением, без штатной записи Results и схемы; целевые ≤10 с полного запуска не подтверждены. Долгие полные ON/OFF, UI, Focused и AutoCAD наборы не запускались.

Отчёт и изменение плана находятся в отдельной ветке `codex/nm-validation-before-nmt`, созданной от актуальной main. main не изменялась. [Сводка](evidence/Coupled6DASDNM_2026-11-27/Summary.json), [проверка архива](evidence/Coupled6DASDNM_2026-11-27/ArchiveProof.json), [точные входы, книга, поля и проверяющий код](../regression/Coupled6D/ASDNM_20261127.zip). Архив содержит {len(manifest)} файлов; все записи повторно прочитаны и сверены по SHA256, CRC фактически исполнявшейся книги проверен.
'''
(review/'docs/reports/Coupled6DASDNM_2026-11-27.md').write_text(report,encoding='utf-8')
print('NM REVIEW READY',json.dumps(dict(statuses=summary['statuses'],archive=archive_proof,states=[172,259]),ensure_ascii=False))
