﻿Attribute VB_Name = "modTestASDNMCheck"
Option Explicit
' ==========================================================================
' ДЛЯ ТЕСТОВ: холодные NM и независимый экспорт фактических операторов.
' ==========================================================================

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выполняет все заданные сочетания с отдельной нулевой материальной историей.
Public Function TestRunASDNMCases(ByVal folder As String) As String
    On Error GoTo Failed
    Dim handle As Integer: handle = FreeFile
    Open folder & "\Input\Loads.bin" For Binary Access Read As #handle
    Dim count As Long, index As Long, component As Long, target(1 To 6) As Double, report As String
    Get #handle, , count
    If count < 1 Or LOF(handle) <> 4 + 48 * count Then Err.Raise 5, , "Неверная матрица шести усилий NM."
    For index = 1 To count
        For component = 1 To 6: Get #handle, , target(component): Next component
        TestRunASDNMCase folder & "\Case" & Format$(index, "00"), target, report
    Next index
    Close #handle: handle = 0
    TestRunASDNMCases = report & "TOTAL_NM_EXECUTION: passed=" & CStr(count) & "; failed=0"
    Exit Function
Failed:
    Dim reason As String: reason = Err.Source & " " & Err.Description
    If handle <> 0 Then Close #handle
    TestRunASDNMCases = "RUNTIME ERROR: " & reason
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет поля, историю, точные результирующие и действительную диагностику.
Private Sub TestRunASDNMCase(ByVal folder As String, ByRef target() As Double, ByRef report As String)
    Dim geometry As CGeometryRegion, mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    Set geometry = TestFixtureBox(180#, 120#): mesh.BuildMesh geometry, 18#, 12#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing): geometry.BuildContours section.Contours
    section.AddRebarElement 0#, -30#, 12#, GEOM_PI * 36#, "A400"
    section.AddRebarElement 0#, 30#, 12#, GEOM_PI * 36#, "A400"
    Dim layout As New CTransverseRebarLayout: layout.AddContourGroup section, "TestASDCapacityHoop", "", 8#, 100#, 10#, "A240"
    Dim c As New CConcreteMaterialParameters, s As New CSteelMaterialParameters, provider As New CMaterialModelProvider
    c.Initialize 30#, 3#, 30#, 3#, 30000#, 30000#, rbMc2:=15#
    s.Initialize 350#, 400#, 350#, 400#, 200000#, 200000#, 0.018, 0.025
    provider.TestInitializeFromParameters c, s, "ThreeLine", "UseDiagram", "TwoLine", diagramExtensionEnabled:=False, plateauSlopeFactor:=0.0075
    Dim hoop As New CCoupledSteelModel, grades As Object, supplementary As Object
    hoop.Initialize 200000#, 240#, 240#, 1500#, 1500#, 0.02, 0.02
    Set grades = CreateObject("Scripting.Dictionary"): grades.Add "A240", hoop
    Set supplementary = CreateObject("Scripting.Dictionary"): supplementary.Add "ULS(I)", grades
    Dim analysis As New CCoupledSectionAnalysis, spec As New CMaterialModelSpec, loads As New CSectionLoadState
    analysis.Initialize section, layout, provider, 0.2, 0.12, 80#, 125#, 16# / 30#, 0.002, "A400", 30, supplementary, concreteLaw:="ASD"
    spec.Initialize "ULS(I)", "ThreeLine", "UseDiagram", "TwoLine"
    loads.Initialize target(1), target(2), target(3), 0#, 0#
    loads.SetSpatialComponents target(4), target(5), target(6)
    Dim field() As Double, resultants() As Double, state As CSectionStateResult, trace As CCoupledLoadTrace, meta As CResultMeta
    Dim observer As New CTestASDNMProgress: observer.TestInitializeBinary folder & "\Native"
    Dim started As Double: started = Timer
    Set meta = analysis.SolveTarget(loads, ChrW$(&H3BB) & "*NMxy", spec, field, resultants, True, state, trace, observer)
    Dim elapsed As Double: elapsed = Timer - started
    If elapsed < 0# Then elapsed = elapsed + 86400#
    TestWriteHardPreparedOperators analysis.TestNMPreparedOperators, folder & "\Native\Operators.csv"
    Dim fieldCount As Long, resultantCount As Long
    On Error Resume Next
    fieldCount = UBound(field) - LBound(field) + 1: Err.Clear
    resultantCount = UBound(resultants) - LBound(resultants) + 1: Err.Clear
    On Error GoTo 0
    Dim traceCount As Long, hasState As Long
    If Not trace Is Nothing Then traceCount = trace.Count
    If Not state Is Nothing Then hasState = 1
    Dim handle As Integer: handle = FreeFile
    Open folder & "\Native\State.bin" For Binary Access Write As #handle
    Dim magic As String * 16: magic = "NDMNMSTATE000001": Put #handle, , magic
    TestWriteVector handle, target
    TestWriteVector handle, Array(elapsed, meta.InternalStatus, meta.ResultCode, fieldCount, resultantCount, traceCount, hasState)
    Dim emptyCount As Long
    If fieldCount > 0 Then TestWriteVector handle, field Else Put #handle, , emptyCount
    If resultantCount > 0 Then TestWriteVector handle, resultants Else Put #handle, , emptyCount
    Close #handle
    Dim diagnostic As String, policy As New CResultStatusPolicy, status As String
    status = policy.ExternalStatus(meta)
    diagnostic = "Status=" & status & "; returned_state=" & CStr(hasState) & vbCrLf & _
        "Comment=" & meta.ResultComment & vbCrLf & "Details=" & meta.DiagnosticDetails
    Dim stream As Object: Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2: stream.Charset = "utf-8": stream.Open
    stream.WriteText diagnostic: stream.SaveToFile folder & "\Native\State.txt", 2: stream.Close
    report = report & "ASD_NM: N=" & CStr(target(1)) & "; Mx=" & CStr(target(2)) & "; My=" & CStr(target(3)) & _
        "; seconds=" & CStr(elapsed) & "; status=" & status & "; returned_state=" & CStr(hasState) & vbCrLf
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Записывает двоичный массив без округления.
Private Sub TestWriteVector(ByVal handle As Integer, ByVal values As Variant)
    Dim count As Long: count = UBound(values) - LBound(values) + 1
    Put #handle, , count
    Dim i As Long, value As Double
    For i = LBound(values) To UBound(values)
        value = CDbl(values(i)): Put #handle, , value
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает линейные кинематические и равновесные операторы частной книги.
Private Sub TestWriteHardPreparedOperators(ByVal operators As CCoupledElasticState, ByVal path As String)
    Dim handle As Integer: handle = FreeFile
    Open path For Output As #handle
    Dim size As Long: size = operators.DegreeCount
    Dim field() As Double, zeroLoad() As Double, residual() As Double, matrix() As Double, vector() As Double
    Dim strain(1 To 6) As Double, gradient(1 To 6) As Double, projection(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, resultants(1 To 6) As Double
    Dim point As Long, degree As Long, component As Long, x As Double, y As Double, weight As Double
    ReDim field(1 To size): ReDim zeroLoad(1 To size)
    For degree = 1 To size
        field(degree) = 1#: operators.StartEquations field, zeroLoad, residual, matrix, False
        Print #handle, "G;" & CStr(degree) & TestHardPreparedVector(residual)
        For point = 1 To operators.PointCount
            operators.PointStrain point, field, strain: operators.AxialGradientAtPoint point, field, gradient
            Print #handle, "B;" & CStr(point) & ";" & CStr(degree) & TestHardPreparedVector(strain) & TestHardPreparedVector(gradient)
        Next point
        field(degree) = 0#
    Next degree
    For component = 1 To 6
        ReDim vector(1 To 6): vector(component) = 1#
        operators.LoadEquations vector(1), vector(2), vector(3), vector(4), vector(5), vector(6), residual
        Print #handle, "L;" & CStr(component) & TestHardPreparedVector(residual)
    Next component
    For point = 1 To operators.PointCount
        operators.Point point, x, y, weight
        Print #handle, "P;" & CStr(point) & ";" & TestOnsetNumber(x) & ";" & TestOnsetNumber(y) & ";" & TestOnsetNumber(weight)
        If point > operators.ConcretePointCount Then
            operators.SteelProjection point, projection
            Print #handle, "A;" & CStr(point) & TestHardPreparedVector(projection)
        End If
        For component = 1 To 6: gradient(component) = 0#: Next component
        For component = 1 To 6
            ReDim residual(1 To size): stress(component) = 1#
            operators.AddSpatialPointEquilibrium point, stress, tangent, gradient, tangent, tangent, residual, matrix, False, resultants
            Print #handle, "W;" & CStr(point) & ";" & CStr(component) & TestHardPreparedVector(residual)
            stress(component) = 0#: gradient(component) = 1#: ReDim residual(1 To size)
            operators.AddSpatialPointEquilibrium point, stress, tangent, gradient, tangent, tangent, residual, matrix, False, resultants
            Print #handle, "V;" & CStr(point) & ";" & CStr(component) & TestHardPreparedVector(residual)
            gradient(component) = 0#
        Next component
    Next point
    Close #handle
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
Private Function TestHardPreparedVector(ByVal values As Variant) As String
    Dim i As Long
    For i = LBound(values) To UBound(values): TestHardPreparedVector = TestHardPreparedVector & ";" & TestOnsetNumber(CDbl(values(i))): Next i
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Форматирует число с точкой для независимого чтения операторов.
Private Function TestOnsetNumber(ByVal value As Double) As String
    TestOnsetNumber = Trim$(Str$(value))
End Function
