"""ДЛЯ ТЕСТОВ. Приспосабливает проверенный материальный повтор к двоичному формату наблюдателя NM."""
from pathlib import Path
import shutil
root=Path(__file__).resolve().parent
helpers=Path('D:/CodexScratch/RC_Section_NDM_TQ/RestoredASDScaleRobustness_20261127/Helpers')
for name in ('Read-TestColdRawCapture.py','Check-TestHardHalfSteps.py'):
    shutil.copyfile(helpers/name,root/name)
s=(helpers/'Replay-TestMainCapacityEquilibrium.py').read_text('utf-8-sig')
s=s.replace('import json,numpy as np',"import sys\nsys.path[:0]=['D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython','D:/CodexScratch/RC_Section_NDM_TQ/OpenSeesCoupled/Lib/site-packages']\nimport json,numpy as np")
a=s.index('source=json.loads')
b=s.index('op=np.array')
s=s[:a]+'''contract_raw=(root.parent/'Input/MaterialContract.json').read_bytes();contract=json.loads(contract_raw)
assert contract['integration_mode']=='native_single_update_working' and contract['concrete_E_MPa']==30000 and contract['poisson']==.2
assert ops.version()=='3.8.0' and ops.NDTest is native.NDTest
R=run_path(str(here/'Read-TestColdRawCapture.py'))['TestReader']
state_raw=(root/'Native/State.bin').read_bytes();sr=R(state_raw)
assert state_raw[:16]==b'NDMNMSTATE000001'
direction=sr.VectorTest();state_header=sr.VectorTest();native_field=sr.VectorTest();native_resultants=sr.VectorTest()
assert sr.position==len(state_raw) and len(direction)==6 and np.all(direction[3:]==0)
offset=np.zeros(6);component=0;base_Mx=0.;dof=60;points=43;concrete=25;half=.001;absolute=relative=5e-7
raw=(root/'Native/ProgressLast.bin').read_bytes();r=R(raw)
assert raw[:16]==b'NDMFULLTRACE0001'
count,=r.VectorTest();assert int(count)==count and count>=1
history=[];factors=[];fractions=[]
for _ in range(int(count)):
    fraction,factor=r.VectorTest();assert fraction==1 and factor>=0
    field=r.VectorTest();assert len(field)==dof and np.all(np.isfinite(field))
    history.append(field);factors.append(factor);fractions.append(fraction)
assert r.position==len(raw)
g,L,w,v,coords,axis,B,gradient=run_path(str(here/'Check-TestHardHalfSteps.py'))['TestOperators'](root/'Native/Operators.csv',dof,points)
area_scale=1/L[0,0];length=L[0,0]/L[1,1]
assert abs(area_scale-21600)<1e-8 and abs(length-180)<1e-8
''' + s[b:]
s=s.replace("(root/'Native/OpenSeesMainCapacityEquilibrium.json')", "(root/'Native/OpenSeesNMEquilibrium.json')")
s=s.replace("print('MAIN CAPACITY EXTERNAL EQUILIBRIUM VERIFIED'", "print('NM EXTERNAL EQUILIBRIUM VERIFIED'")
s+='''
if len(native_field):
    assert state_header[6]==1 and factors[-1]==1 and len(native_resultants)==6
    np.testing.assert_array_equal(native_field,history[-1])
    bound=records[-1]['original_bound_MPa']
    assert max(abs((native_resultants-direction)/force_scales))<=bound+1e-10
    assert max(abs((native_resultants-np.array(records[-1]['actual_resultants_N_Nmm']))/force_scales))<1e-9
else:
    assert state_header[6]==0 and len(native_resultants)==0
'''
(root/'Replay-TestNM.py').write_text(s,encoding='utf-8')
print('REPLAY STAGED; SAME MATERIAL, STEEL HISTORY AND EQUILIBRIUM CHECKS')
