"""Independent replay of the exact ASD ray tensors, event and section projections."""
from argparse import ArgumentParser
from hashlib import sha256
from math import acos, cos, fsum, pi, sqrt
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = ('MVT2GaussASDNominalVectorBundle20261117', '24464DB3DCC38635B06DF165D5CB79C31DEF76BF2B50240795FAD8C5D18CCC6B')
WIRE = '161F44FB10F42D72BE420C740BE3E66A1E397CAB0FEBDA88E89648F8CDFFFB85'
HARD = '5F483C35C11C403B5D60F519F4E4A55D8DC5A641B5D47985FD3E84257EBE5763'
ORDER = (0, 1, -1)


def sha(raw):
    return sha256(raw).hexdigest().upper()


def read(path, pin, compressed=False):
    raw = path.read_bytes()
    assert sha(raw) == pin
    return json.loads(gzip.decompress(raw) if compressed else raw)


def maxdifference(a, b):
    return max(abs(x-y) for x,y in zip(a, b, strict=True))


def eigen(stress):
    """Principal stresses by the invariant cubic, independent of LAPACK."""
    a, b, c, d, e, f = stress
    p = (a+b+c) / 3.
    u, v, w = a-p, b-p, c-p
    h = sqrt((u*u + v*v + w*w + 2*(d*d+e*e+f*f))/6)
    det = (u*(v*w-f*f) - d*(d*w-e*f) + e*(d*f-e*v)) / h**3
    phase = acos(max(-1., min(1., det / 2.))) / 3.
    largest, smallest = (p+2.*h*cos(phase+angle) for angle in (0., 2.*pi/3.))
    return smallest, a+b+c-largest-smallest, largest


def stress_action(weights, left, right, width=1.):
    return fsum(c*(b-a) for c,a,b in zip(weights,left,right,strict=True))/width


def check_whole(snapshot, field, target, op, geo, area, length, signed):
    net = snapshot['net_stresses_MPa']
    assert len(net) == 3 and all(len(station)==45 and all(len(p)==6 for p in station) for station in net)
    applied = [fsum(c[i]*v for c,v in zip(op['L'],target,strict=True)) for i in range(60)]
    slopes = [[500.*(a-b) for a,b in zip(p,m,strict=True)] for p,m in zip(net[1],net[2],strict=True)]
    residuals = []
    for k in range(60):
        center = (w[k]*v for vectors,sigma in zip(op['S'],net[0],strict=True) for w,v in zip(vectors,sigma,strict=True))
        grade = (w[k]*v for vectors,sigma in zip(op['R'],slopes,strict=True) for w,v in zip(vectors,sigma,strict=True))
        gauge = (g*q for g,q in zip(op['G'][k],field,strict=True))
        residuals.append((fsum((*center,*grade,*gauge))-applied[k])*(30000. if k>=56 else 1.))
    forces = signed(net[0],geo)
    force_error = [abs(a-b)/scale for a,b,scale in zip(forces,target,(area,area*length,area*length,area*length,area,area),strict=True)]
    result = max(max(map(abs,residuals)),max(force_error))
    assert maxdifference(residuals,snapshot['normalized_60'])<3e-12
    assert maxdifference(forces,snapshot['signed_6'])<3e-8
    assert abs(result-snapshot['norm_MPa'])<3e-12
    assert abs(snapshot['tolerance_MPa']-(5e-7+5e-7*max(map(abs,applied))))<4e-20
    return result


def check_station(station, case, old, curves, tensor, op, geometry, raw_n, scales):
    p, side = station['point'], station['side']
    n = p-1
    assert station['geometry_x_y_weight'] == list(geometry[n])
    sample = {a:(strain,stress) for a,strain,stress in station['samples']}
    weights = [side*c[55]/.002 for c in op['R'][n]]
    assert station['row56_projection'] == weights
    assert maxdifference(tensor(op,case['newton_direction'],n,side),station['unit_newton_strain'])<2e-21
    for a,(seen,_) in sample.items():
        field = [b+a*d for b,d in zip(case['field'],case['newton_direction'],strict=True)]
        assert maxdifference(seen,tensor(op,field,n,side))<4e-18
    for a in (0.,-.25,.25):
        observed = case['whole_section_triplet'][str(a)]['net_stresses_MPa'][ORDER.index(side)][n]
        assert maxdifference(sample[a][1],observed)<2e-13
    prior = next(row for row in old['largest_material_side_gaps_at_governing_row'] if row['point']==p and row['side']==side)
    assert abs(stress_action(weights,sample[0.][1],sample[.25][1])-prior['plus_contribution_MPa'])<6e-13
    assert abs(stress_action(weights,sample[-.25][1],sample[0.][1])-prior['minus_contribution_MPa'])<6e-13
    near = [[a,stress_action(weights,sample[0.][1],sample[a][1],a),
            stress_action(weights,sample[-a][1],sample[0.][1],a)] for a in scales]
    assert maxdifference(near[8][1:],near[10][1:])<5e-8 and abs(near[8][1]-near[8][2])<5e-8
    assert abs(near[0][1]-near[0][2])>1e-3
    span = station['refined_largest_tangent_change']['brackets']
    assert len(span)==21
    for (a,b,*_),(l,u,*_) in zip(span[:-1],span[1:],strict=True):
        cut=(a+b)/2.
        assert (l,u) in ((a,cut),(cut,b))
    l,u,*_ = span[-1]
    max_strain_width = maxdifference(sample[l][0],sample[u][0])
    jump = maxdifference(sample[l][1],sample[u][1])
    h = 64.*(u-l)
    left = stress_action(weights,sample[l-h][1],sample[l][1],h)
    right = stress_action(weights,sample[u][1],sample[u+h][1],h)
    assert abs(left-right)>2e-3 and max_strain_width<3e-14
    assert min(raw_n[l],raw_n[u])>old['norm_MPa']
    responses = {r['alpha']:r for r in station['ASD_NDTest_response']}
    eig = [eigen(sample[a][1]) for a in (l,u)]
    out = {'point':p,'side':side,'alpha':[l,u],'global_max_strain_to_event':min(abs(l),abs(u))*case['max_unit_newton_strain'],
           'event_max_local_engineering_strain_width':max_strain_width,
           'row56_slope_near_zero_plus_minus_MPa':near[8][1:], 'row56_slope_at_kink_left_right_MPa':[left,right],
           'full_norm_at_bracket_MPa':[raw_n[l],raw_n[u]],'endpoint_stress_delta_MPa':jump}
    if p==7:
        assert all(values[0]>.02 for values in eig)
        assert 1.48e-8<jump<1.49e-8
        assert [r['alpha'] for r in curves]==[l,u]
        te=curves[0]['Te']
        knot=te[3]
        tol=1e-6*min(v-a for a,v in zip(te,te[1:]))
        threshold=knot+tol
        assert responses[l]['equivalentTotalStrain'][0]<threshold<responses[u]['equivalentTotalStrain'][0]
        increment=[responses[u][item][0]-responses[l][item][0] for item in ('equivalentPlasticStrain','damage')]
        assert -6.1e-12<increment[0]<-5.9e-12 and -1.15e-9<increment[1]<-1.13e-9
        out.update({'event':'tensile_tabular_interpolation_threshold','tensile_knot':knot,'selection_tolerance':tol,
                    'tensile_threshold':threshold,'tensile_equivalent_strains':[responses[l]['equivalentTotalStrain'][0],
                                                                             responses[u]['equivalentTotalStrain'][0]],
                    'plastic_strain_and_damage_deltas':increment})
    else:
        assert eig[0][1]*eig[1][1]<0. and max(abs(values[1]) for values in eig)<5e-11
        assert jump<4e-11 and all(responses[a]['damage'][1]==0. for a in (l,u))
        out.update({'event':'middle_principal_stress_sign_switch','middle_principal_stress_MPa':[e[1] for e in eig]})
    return out


def main(repo):
    wire=read(HERE/'StationFlagWire.json.gz',WIRE,True)
    hard=read(HERE/'StationHardening.json',HARD)
    assert wire['exact_H53_replayed'] and hard['history_before_and_after']==[53,53]
    assert hard['depends_on_station_wire_sha256']==WIRE
    assert wire['committed_history_before']==wire['committed_history_after']==53
    assert wire['target_N_Nmm']==[0.,-33140625.,0.,10510000.,0.,55234.375] and wire['native_runtime']=='3.8.0'
    path=repo/'docs/regression/Coupled6D'/(BASE[0]+'.zip')
    assert sha(path.read_bytes())==BASE[1]
    with tempfile.TemporaryDirectory(prefix='MVTStationOffline_') as folder, ZipFile(path) as base:
        root=Path(folder)
        leaf='bundle24-output/VectorNominal.json'
        prior=base.read(leaf)
        assert sha(prior)==wire['source_vector_report']
        old=json.loads(prior)
        (root/'Verify-VectorEvidence.py').write_bytes(base.read('Verify-VectorEvidence.py'))
        controls=runpy.run_path(str(root/'Verify-VectorEvidence.py'))
        accepted,n,_,_,_=controls['history'](repo)
        assert accepted['Q_target_N']==55156.25 and n<accepted['tolerance_MPa']
        with controls['archive'](repo,controls['POST']) as p:
            (root/'Verify-Postyield.py').write_bytes(p.read('Verify-Postyield.py'))
        past=runpy.run_path(str(root/'Verify-Postyield.py'))
        with past['archive'](repo,past['AUTH']) as p:
            for leaf in ('Verify-Authoritative.py','Operators.py','Reequilibrate.py'):
                (root/leaf).write_bytes(p.read(leaf))
        sys.path.insert(0,str(root))
        guard=runpy.run_path(str(root/'Verify-Authoritative.py'))
        operator,source=guard['unpack'](root,repo)
        model=runpy.run_path(str(root/'Reequilibrate.py'))
        _,_,geo,dirs,area,length,op,_,_,identity=model['read_inputs'](operator,root,source)
    assert wire['operator_source']==identity
    report={'probed_Qy_N':55234.375,'last_accepted_Qy_N':55156.25,'material_history_commit_count':53,
            'physical_limit_established':False,'independent_section_checks':0,'anchors':{}}
    for label, case in wire['anchors'].items():
        norms={}
        reference=old['first_rejection_two_distinct_fields'][label]
        for subset in ('whole_section_triplet','whole_section_kink_brackets'):
            for k,snapshot in case[subset].items():
                a=float(k)
                field=[b+a*d for b,d in zip(case['field'],case['newton_direction'],strict=True)]
                norms[a]=check_whole(snapshot,field,wire['target_N_Nmm'],op,geo,area,length,guard['signed_forces'])
                assert norms[a]>snapshot['tolerance_MPa']
                report['independent_section_checks']+=1
        assert abs(norms[0.]-reference['norm_MPa'])<3e-12
        assert case['whole_section_triplet']['-0.25']['steel_active_flags']==case['whole_section_triplet']['0.25']['steel_active_flags']
        report['anchors'][label]=[check_station(s,case,reference,hard['response_at_p7_side_minus'][label],past['tensor'],op,geo,norms,wire['one_sided_positive_scales'])
                                  for s in case['stations']]
    return report


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=Path.cwd())
    cli.add_argument('--report',type=Path)
    options=cli.parse_args()
    result=main(options.repo)
    raw=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if options.report:
        with options.report.open('xb') as sink:
            sink.write(raw)
    print('MVT2 EXACT ASD MATERIAL EVENT OFFLINE PASS',sha(raw),result['independent_section_checks'])
