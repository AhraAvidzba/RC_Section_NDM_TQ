"""Extract the actual ASD uniaxial hardening ordinates for the station test."""
from pathlib import Path
import gzip
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
FILE = 'StationFlagWire.json.gz'
PIN = '161F44FB10F42D72BE420C740BE3E66A1E397CAB0FEBDA88E89648F8CDFFFB85'
spec = importlib.util.spec_from_file_location('station_probe', HERE / 'Probe-Stations.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


def main():
    raw = (HERE / FILE).read_bytes()
    assert probe.digest(raw) == PIN
    proof = json.loads(gzip.decompress(raw))
    vector, old = probe.exact_reference()
    np, ops, section, material, identity, loads, fields = probe.exact_replay(vector, old)
    assert proof['operator_source'] == identity and proof['model_command'] == material
    tag = 1 + 2 * 45 + 6
    results = {'response_at_p7_side_minus': {}, 'history_before_and_after': [section.committed, section.committed],
               'depends_on_station_wire_sha256': PIN}
    for label, field in fields.items():
        sec = proof['anchors'][label]
        assert field.tolist() == sec['field']
        at = next(r for r in sec['stations'] if r['point']==7 and r['side']==-1)
        samples = {x: (strain, stress) for x, strain, stress in at['samples']}
        l, u = at['refined_largest_tangent_change']['brackets'][-1][:2]
        left, right = [(alpha, *samples[alpha]) for alpha in (l, u)]
        data = []
        for a, strain, stress in (left, right):
            assert tuple(stress) == section.trial(tag, np.array(strain))
            data.append({'alpha': a, **{key: list(ops.NDTest('GetResponse', tag, key)) for key in ('Te', 'Ts', 'Tq')}})
            assert tuple(stress) == section.trial(tag, np.array(strain))
        assert all(data[0][k] == data[1][k] for k in ('Te', 'Ts', 'Tq'))
        results['response_at_p7_side_minus'][label] = data
    assert section.committed == 53
    ops.wipe()
    raw = (json.dumps(results, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    with (HERE / 'StationHardening.json').open('xb') as fp:
        fp.write(raw)
    print('MVT2 ASD HARDENING WIRE',probe.digest(raw),len(raw))


if __name__ == '__main__':
    main()
