"""Exact committed H53 external ASD station observability test."""
from hashlib import sha256
from itertools import product
from pathlib import Path
from time import perf_counter
import gzip
import importlib.util
import json
import runpy
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent
BUNDLE = 'D3A5081B05ABAB4C1B744922BA5EB3CE992B233B1671BA96A14F07111B350602'
VECTORS = '4102467FBDC2AF70FB67308CC0228E4BFE6C25746D8FDF08F1C1FCBAB8AD0E93'
STATIONS = ((20, 1), (20, -1), (7, -1), (10, -1))
SIDES = (0, 1, -1)
SCALES = (0.25, *(2. ** -i for i in range(3, 23)))
GRID = tuple(i / 256. for i in range(-64, 65))
REFINE = 20


def digest(payload):
    return sha256(payload).hexdigest().upper()


def exact_reference():
    source = PRIOR / 'Recover-Vector.py'
    assert digest(source.read_bytes()) == VECTORS
    module = importlib.util.spec_from_file_location('frozen_vector', source)
    vector = importlib.util.module_from_spec(module)
    module.loader.exec_module(vector)
    canonical = (PRIOR / 'bundle24-output/VectorNominal.json').read_bytes()
    assert digest(canonical) == BUNDLE
    return vector, json.loads(canonical)


def exact_replay(vector, proof):
    fixture = runpy.run_path(str(PRIOR / 'Postyield.py'))
    fields, tensors, steel_reference, prior = vector.read_seed()
    src = fixture['SRC']
    sys.path.insert(0, str(fixture['NUMPY']))
    sys.path.insert(0, str(src))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version() == '3.8.0' and np.__version__ == '2.3.5'
    program = runpy.run_path(str(src / 'Reequilibrate.py'))
    shared, report, geo, dirs, area, length, op, _, _, identity = program['read_inputs'](fixture['OPS'], fixture['NATIVE_ROOT'])
    assert identity == prior['source_operator_identity']
    steel = []
    model = fixture['steel_section'](program['Section'], np, steel)
    material = program['commands'](shared, report, ('default',))['default']
    section = model(np, ops, material, geo, dirs, area, length, op, perf_counter() + 90.)
    stock = program['try_correct']
    stock.__globals__['loads'] = lambda arrays, t, q: arrays.array((0., -600. * q, 0., t, 0., q))
    for field, tensor in zip(fields, tensors, strict=True):
        loads = stock.__globals__['loads'](np, field['T_target_Nmm'], field['Q_target_N'])
        result = section.equations(np.array(field['field']), loads, False)
        assert result[4] <= result[5] and np.array_equal(result[2], tensor)
        section.accepted_stresses.append(result[2].tolist())
        section.commit()
    assert section.committed == 53 and vector.raw_json(steel) == vector.raw_json(steel_reference)
    last = np.array(fields[-1]['field'])
    predictor = last + .5 * (last - np.array(fields[-2]['field']))
    loads = stock.__globals__['loads'](np, 10510000., vector.FIRST)
    equations = section.equations
    calls = []

    def capture(x, demand, matrix=False):
        value = equations(x, demand, matrix)
        calls.append((x.copy(), matrix))
        return value

    section.equations = capture
    try:
        accepted, stopping = stock(section, predictor, 10510000., vector.FIRST)
    finally:
        section.equations = equations
    assert accepted is None and stopping == proof['all_attempts'][0]['stock'] and section.committed == 53
    iterate = next(field for field, matrix in reversed(calls) if matrix)
    rejected = calls[-1][0]
    return np, ops, section, material, identity, loads, {'stock_iterate': iterate, 'rejected_line_trial': rejected}


def raw_section(section, field, loads):
    r, _, sigma, forces, n, tau = section.equations(field, loads, False)
    return {'normalized_60': (r * section.scale).tolist(), 'signed_6': forces.tolist(),
            'net_stresses_MPa': sigma.tolist(), 'norm_MPa': n, 'tolerance_MPa': tau,
            'steel_active_flags': (section.next_steel[2] == 0.).tolist()}


def refine_switch(np, sigma, grid_pair):
    lo, hi = grid_pair
    levels = []
    for _ in range(REFINE + 1):
        left, right = np.array(sigma(lo)[1]), np.array(sigma(hi)[1])
        mid = .5 * (lo + hi)
        middle = np.array(sigma(mid)[1])
        levels.append([lo, hi])
        # Follow the half carrying more of the stress change. For a genuine
        # stress jump, the change persists as this bracket shrinks.
        if np.max(np.abs(middle - left)) >= np.max(np.abs(right - middle)):
            hi = mid
        else:
            lo = mid
    return levels


def refine_kink(np, get):
    values = {a: np.asarray(get(a)[1]) for a in GRID}
    h = GRID[1] - GRID[0]
    scan = [(float(np.max(np.abs((values[a] + values[c] - 2 * values[b]) / h))), b)
            for a, b, c in zip(GRID, GRID[1:], GRID[2:])]
    ranked = sorted(scan, reverse=True)
    initial = ranked[0][1]
    left, right = initial - h, initial + h

    def chord(a, b):
        return (np.asarray(get(b)[1]) - np.asarray(get(a)[1])) / (b - a)

    left_ref = chord(left - h, left)
    right_ref = chord(right, right + h)
    levels = []
    for _ in range(REFINE + 1):
        mid = .5 * (left + right)
        left_side_difference = float(np.max(np.abs(chord(left, mid) - left_ref)))
        right_side_difference = float(np.max(np.abs(chord(mid, right) - right_ref)))
        levels.append([left, right, left_side_difference, right_side_difference])
        # A smooth half of the bracket has its own side's slope. At the
        # observed kink the other half contains the considerably larger gap.
        if left_side_difference >= right_side_difference:
            right = mid
        else:
            left = mid
    left, right = levels[-1][:2]
    for mult in (1, 8, 64):
        separation = mult * (right - left)
        get(left - separation)
        get(right + separation)
    return {'initial_center': initial, 'ranked_grid_scores_first_three': ranked[:3], 'brackets': levels}


def station_response(np, section, field, direction, point, side):
    s, p = SIDES.index(side), point - 1
    exact = section.strain[s, p]
    v = exact @ direction
    stresses = {}

    def get(alpha):
        if alpha not in stresses:
            eps = exact @ (field + alpha * direction)
            stress = section.trial(1 + s * 45 + p, eps)
            stresses[alpha] = (eps.tolist(), list(stress))
        return stresses[alpha]

    for x in set(GRID) | {0.} | {sign * scale for sign, scale in product((-1, 1), SCALES)}:
        get(x)
    kink = refine_kink(np, get)
    kink_lo, kink_hi = kink['brackets'][-1][:2]
    h = 64. * (kink_hi - kink_lo)
    responses = []
    tag = 1 + s * 45 + p
    # Numerical indicators supplied by the material. No trial history update
    # is committed and no directional response requiring string arguments is used.
    for alpha in sorted({-.25, 0., .25, kink_lo-h, kink_lo, kink_hi, kink_hi+h}):
        eps, expected = get(alpha)
        assert section.trial(tag, np.asarray(eps)) == tuple(expected)
        value = {'alpha': alpha}
        for response in ('equivalentTotalStrain', 'equivalentPlasticStrain', 'damage'):
            value[response] = list(section.ops.NDTest('GetResponse', tag, response))
            value[response+'_avg'] = list(section.ops.NDTest('GetResponse', tag, response, '-avg'))
        assert all(len(v)==2 and np.all(np.isfinite(v)) for key,v in value.items() if key!='alpha')
        assert section.trial(tag, np.asarray(eps)) == tuple(expected)
        responses.append(value)
    brackets = []
    for sign in (-1., 1.):
        grid = [x for x in GRID if x * sign >= 0.]
        pairs = list(zip(grid[:-1], grid[1:], strict=True))
        first = max(pairs, key=lambda pair: max(abs(a - b) for a, b in zip(get(pair[0])[1], get(pair[1])[1], strict=True)))
        path = refine_switch(np, get, first)
        # Record neighboring one-sided chords of the final interval, too.
        lo, hi = path[-1]
        span = hi - lo
        for alpha in (lo - span, hi + span, lo - 8. * span, hi + 8. * span):
            get(alpha)
        brackets.append({'sign': sign, 'coarse_pair': first, 'brackets': path})
    # Revisit the exact field after every signed/regime refinement, without
    # relying on the memoized sample to prove trial rollback.
    assert tuple(get(0.)[1]) == section.trial(1 + s * 45 + p, np.array(get(0.)[0]))
    geom = [float(x) for x in section.geo[p]]
    return {'point': point, 'side': side, 'geometry_x_y_weight': geom,
            'unit_newton_strain': v.tolist(), 'row56_projection': section.project[s, p, :, 55].tolist(),
            'refined_largest_tangent_change': kink,
            'ASD_NDTest_response': responses,
            'largest_grid_variation_brackets': brackets,
            'samples': [[a, *stresses[a]] for a in sorted(stresses)]}


def main():
    started = perf_counter()
    vector, proof = exact_reference()
    np, ops, section, material, identity, loads, fields = exact_replay(vector, proof)
    payload = {'model_command': material, 'operator_source': identity, 'exact_H53_replayed': True,
              'native_runtime': ops.version(), 'target_N_Nmm': loads.tolist(), 'committed_history_before': section.committed,
              'original_archive_identities': proof['first_frozen_H53_sha256'], 'source_vector_report': BUNDLE,
              'one_sided_positive_scales': SCALES, 'grid': GRID, 'anchors': {}}
    for label, field in fields.items():
        base = section.equations(field, loads, True)
        j = base[1] * section.scale[:, None]
        direction = np.linalg.solve(j, -base[0] * section.scale)
        anchor = {'field': field.tolist(), 'newton_direction': direction.tolist(),
                  'max_unit_newton_strain': float(np.max(np.abs(section.strain @ direction))),
                  'whole_section_triplet': {str(a): raw_section(section, field + a * direction, loads) for a in (0., -.25, .25)},
                  'stations': [station_response(np, section, field, direction, p, s) for p, s in STATIONS]}
        span = {a for station in anchor['stations'] for a in station['refined_largest_tangent_change']['brackets'][-1][:2]}
        anchor['whole_section_kink_brackets'] = {str(a): raw_section(section, field + a * direction, loads) for a in sorted(span)}
        assert raw_section(section, field, loads) == anchor['whole_section_triplet']['0.0']
        payload['anchors'][label] = anchor
    payload['committed_history_after'] = section.committed
    assert section.committed == 53 and len(section.accepted_stresses) == 53
    ops.wipe()
    raw = gzip.compress(vector.raw_json(payload), compresslevel=9, mtime=0)
    with (HERE / 'StationFlagWire.json.gz').open('xb') as sink:
        sink.write(raw)
    print('MVT2 ASD STATION WIRE', digest(raw), len(raw), 'seconds', perf_counter() - started)


if __name__ == '__main__':
    main()
