"""Проверяет нативное доказательство без установки Excel, книги и истории Git."""

import json
from pathlib import Path
from subprocess import PIPE, run
import sys

import PriorVerify as prior


HERE = Path(__file__).resolve().parent


def main():
    sums = prior.read(HERE/'SHA256SUMS.json')
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}
    assert actual == set(sums)|{'SHA256SUMS.json'}
    for name,expected in sums.items():
        assert prior.file_hash(HERE/name) == expected and not name.lower().endswith('.xlsm'), name
    plan = prior.read(HERE/'Fixture.json')
    for name,expected in plan['production'].items():
        assert prior.file_hash(HERE/'Production'/name) == expected
    replay = run([sys.executable,'-B','-X','utf8','Verify.py','--order','10'],cwd=HERE,stdout=PIPE,check=True)
    print(replay.stdout.decode('utf-8').strip())
    native = prior.read(HERE/'Native/Order10/Verification.json')
    assert prior.file_hash(HERE/'Native/Order10/Verification.json') == 'BD3549286ED22226484C942513DFA52D1B5BD3B9145B69C2D8317168B94D8AAD'
    assert not native['physical_limit_certified']
    assert native['exact_prefix'] == 25 and native['restored_state_words'] == 9744
    assert native['previous_eight_steps_bit_identical'] == 8 and native['accepted_count'] == 9 and len(native['trials']) == 14
    assert native['terminal'] == 'MINIMUM_RADIUS' and native['trials'][-1]['decision'] == 'REFUSED'
    assert native['first_xz_at_or_beyond_old_G14'] is None and native['first_certified_signed_lambda_rise_from_G13'] is None
    raw = (HERE/'Native/Order10/HardG14Direction.csv').read_text(encoding='cp1251').splitlines()
    _, accepted_cap, attempt_cap, initial, usual, min_radius = next(r.split(';') for r in raw if r.startswith('TRACE-BUDGET;'))
    last = native['trials'][-1]['requested_distance']
    assert (accepted_cap, attempt_cap) == ('32', '64')
    assert last == prior.number(min_radius) and last/2 < prior.number(min_radius)
    native['last_requested_distance'] = last
    native['next_bisected_distance_below_minimum'] = last/2
    native['fraction_of_original_G14_coordinate_gap_traversed'] = ((native['farthest_old_xz_sample']['xz']-native['initial_xz'])/(native['old_G14_target']-native['initial_xz']))
    print(json.dumps(native,indent=2,ensure_ascii=False))
    print(f'HARDSHEAR_G13_SERIAL_EXTENDED_PORTABLE: VERIFIED_EVIDENCE; {native["terminal"]}; physical_limit_certified=False')


if __name__ == '__main__':
    main()
