"""Готовит длинный диагностический повтор принятой механической дуги G13."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
DOC = HERE.parents[1]/'docs/regression/Coupled6D'
REPO = HERE.parents[1]
BASE = DOC/'HardShearG13SerialArcNative20261117.zip'
BASE_SHA = '9BBFF5A2536A5C82E87C78999131E85A9A3618904B23879E479B1F1BF4DC824B'
REPORT = '2B3AB8E51A91E540042DAC6483F6E02BE88723B09B0BB89F450DDDDC43E03ECF'
ANCHOR = DOC/'HardShearF19ContinuationNative20261117.zip'
ANCHOR_SHA = 'E6E987A86DE0191A649B123F3F1B629CD5821C24E71AF946FC1B010CFB25F131'
BOOK = '245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012'
SOLVER = 'src/Solver/CCoupledNewtonSolver.cls'


def sha(raw):
    return sha256(raw).hexdigest().upper()


def text(raw):
    return raw.decode('utf-8-sig').replace('\r\n','\n')


def exactly(body,a,b):
    assert body.count(a)==1,a
    return body.replace(a,b)


def seal(folder,path,raw):
    target=folder/path
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_bytes()==raw,path
    else:
        target.write_bytes(raw)
    return sha(raw)


def change_budget(raw):
    before=text(raw)
    after=exactly(before,'Const MAX_STEPS As Long = 8, MAX_ATTEMPTS As Long = 16',
                  'Const MAX_STEPS As Long = 32, MAX_ATTEMPTS As Long = 64')
    after=exactly(after,'If Timer - started > 96# Then outcome = "TIME_LIMIT": Exit For',
                   'If Timer - started > 210# Then outcome = "TIME_LIMIT": Exit For')
    return after.replace('\n','\r\n').encode('utf-8')


def verify_source(raw):
    source=text(raw)
    source=exactly(source,'import ArcVerify as arc\n','import ArcVerify as arc\nimport ExtendedProof as extra\n')
    source=exactly(source,"    return fixture,expected,original,old,weights,op,row\n",
                   "    extra.inputs(fixture, extract)\n    return fixture,expected,original,old,weights,op,row\n")
    source=exactly(source,"    assert budget[:2]==['8','16'] and len(steps)<=16 and final[-1]=='9744'\n",
                   "    assert budget[:2]==['32','64'] and len(steps)<=64 and final[-1]=='9744'\n"
                   "    prefix_size=extra.require_bit_identical_prefix(extract, weights, op, steps, budget)\n")
    source=exactly(source,"    output=folder/'Verification.json'\n",
                   "    result.update(extra.summarize(prefix_size, accepted, initial_lambda, initial_coord, original['control']))\n"
                   "    output=folder/'Verification.json'\n")
    return source.encode('utf-8')


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--destination',type=Path,default=HERE/'ready')
    cli.add_argument('--with-workbook',action='store_true')
    args=cli.parse_args()
    stage=args.destination.resolve()
    assert stage.is_relative_to(HERE) or stage.is_relative_to(Path('D:/CodexScratch/RC_Section_NDM_TQ').resolve())
    assert sha(BASE.read_bytes())==BASE_SHA and sha(ANCHOR.read_bytes())==ANCHOR_SHA
    files={}
    with ZipFile(BASE) as archive:
        original=json.loads(archive.read('Fixture.json'))
        workbook=(REPO/original['workbook']).read_bytes()
        assert sha(workbook)==original['source_workbook_sha256']==BOOK
        report=archive.read('Native/Order10/Verification.json')
        trace=archive.read('Native/Order10/HardG14Direction.csv')
        assert sha(report)==REPORT and json.loads(report)['native_trace_sha256']==sha(trace)
        for name,data in (('SerialPrior/Verification.json',report),('SerialPrior/HardG14Direction.csv',trace)):
            files[name]=seal(stage,name,data)
        for path,digest in original['inputs'].items():
            raw=archive.read(path)
            assert sha(raw)==digest,path
            if path=='Stage.py':
                continue
            if path in (SOLVER,'Restart.bas'):
                raw=change_budget(raw)
            elif path=='Verify.py':
                raw=verify_source(raw)
            elif path=='Run.ps1':
                raw=text(raw).replace('CompileHardG14Direction','CompileHardSerialLong').replace('RunHardG14Direction','RunHardSerialLong').encode('utf-8')
            files[path]=seal(stage,path,raw)
    with ZipFile(ANCHOR) as archive:
        raw=archive.read('Native/Order10/Verification.json')
        files['Anchor/Verification.json']=seal(stage,'Anchor/Verification.json',raw)
    for p in ('Stage.py','ExtendedProof.py'):
        files[p]=seal(stage,p,(HERE/p).read_bytes())
    if args.with_workbook:
        seal(stage,original['workbook'],workbook)
        seal(stage,'docs/regression/Diagnostic.xlsm',workbook)
        for path in ('Temp','Native/Order10'):
            (stage/path).mkdir(parents=True,exist_ok=True)
    fixture={**original,'inputs':files,'watchdog_seconds':260,'serial_reference_archive_sha256':BASE_SHA,
              'serial_reference_report_sha256':REPORT,'anchor_archive_sha256':ANCHOR_SHA,
              'scope':'serial mechanical continuation with identical previous accepted eight, budget extension only; no capacity claim'}
    print(stage,seal(stage,'Fixture.json',(json.dumps(fixture,indent=2)+'\n').encode('utf-8')))


if __name__=='__main__':
    main()
