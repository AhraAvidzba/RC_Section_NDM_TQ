"""Replay the sealed native quadrature results without launching Excel."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path, PurePosixPath
import json
import runpy
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
BOOK_COMMIT = "709e7dfa16c192748fc2c6d999925bdbf9948a4c"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
NATIVE_PROOFS = {
    "Geometry": "D9B2EC35AE9D5F1AB72B8A89B729DA7A91CA606B72E85A461A7F335588BE53EF",
    "MVTStock": "8C90A9EBABDA72B6A28C949E8804D7016291E634C3862BD909FD9C6189DAB190",
    "MVTGauss": "5B8A4FE665B191D87B5B4C4A81F9F81C13316CD922054102C1399936BACAA845",
}


def digest(data):
    return sha256(data).hexdigest().upper()


def copy_manifest(to):
    seen = set()
    for line in (HERE / "SHA256SUMS").read_text(encoding="ascii").splitlines():
        expected, name = line.split("  ", 1)
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts
        assert name not in seen and not name.lower().endswith(".xlsm")
        data = (HERE / name).read_bytes()
        assert digest(data) == expected, name
        target = to / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        seen.add(name)
    assert seen == {p.relative_to(HERE).as_posix() for p in HERE.rglob("*")
                    if p.is_file() and p.name != "SHA256SUMS"}


def exact_book(path, repo):
    if path is not None:
        data = path.read_bytes()
    else:
        current = repo / BOOK
        data = current.read_bytes() if current.is_file() else b""
        if digest(data) != BOOK_SHA:
            data = subprocess.check_output(["git", "-C", str(repo), "show", f"{BOOK_COMMIT}:{BOOK}"])
    assert digest(data) == BOOK_SHA
    return data


def replay(book, repo):
    with tempfile.TemporaryDirectory(prefix="MVGLReplay_") as name:
        work = Path(name)
        copy_manifest(work)
        path = work / BOOK
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(exact_book(book, repo))
        verify = runpy.run_path(str(work / "Verify-Native.py"))["main"]
        for case, pinned in NATIVE_PROOFS.items():
            proof = work / f"Verification{case}.json"
            assert digest(proof.read_bytes()) == pinned
            verify(case)
        analytic = json.loads((work / "Analytic/Proof.json").read_bytes())
        reconstructed = runpy.run_path(str(work / "Analytic/Compare.py"))["run"]()
        assert json.loads(json.dumps(reconstructed)) == analytic
        print("PASS native closures, source bytes, independent six-resultant sums and analytical checks")


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--book", type=Path)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    opts = parser.parse_args()
    replay(opts.book, opts.repo)
