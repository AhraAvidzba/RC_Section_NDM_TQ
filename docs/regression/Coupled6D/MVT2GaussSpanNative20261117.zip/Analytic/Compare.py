"""Offline section quadrature check in unit coordinates, with no VBA dependencies."""
from math import cos, sin, tanh, pi, sqrt, fsum, hypot
import json


def gauss(n, low=-1.0, high=1.0):
    """Legendre nodes and positive weights, optionally mapped to an interval."""
    for k in range(n):
        x = cos(pi * (k + 0.75) / (n + 0.5))
        for _ in range(12):
            p, before = x, 1.0
            for i in range(2, n + 1):
                p, before = ((2 * i - 1) * x * p - (i - 1) * before) / i, p
            derivative = n * (before - x * p) / (1.0 - x*x)
            change = p / derivative
            x -= change
            if abs(change) < 2e-16:
                break
        weight = (high - low) / ((1.0 - x*x) * derivative**2)
        yield 0.5 * ((high + low) + x * (high - low)), weight


def rectangle_gauss(xmin, xmax, ymin, ymax, n):
    return [(x, y, a*b) for x, a in gauss(n, xmin, xmax) for y, b in gauss(n, ymin, ymax)]


def midpoint_square(n):
    return [(-1 + (2*i+1)/n, -1 + (2*j+1)/n, (2/n)**2) for i in range(n) for j in range(n)]


def rectangle_hole_split(x0, x1, y0, y1):
    """Positive tensor cubature fitted to an eccentric straight hole."""
    boxes = ((-1, x0, -1, 1), (x1, 1, -1, 1), (x0, x1, -1, y0), (x0, x1, y1, 1))
    return [point for box in boxes for point in rectangle_gauss(*box, 4)]


def annular_polar(outer, inner, rings, angular):
    """Positive equal-angle rule and Gauss rule in radius squared."""
    return [(sqrt(u)*cos(2*pi*k/angular), sqrt(u)*sin(2*pi*k/angular), pi*w/angular)
            for u, w in gauss(rings, inner**2, outer**2) for k in range(angular)]


def circle_y(radius, x):
    return sqrt(max(0.0, radius**2 - x**2))


def section_intervals(x, ya, yb, outer, inner):
    if abs(x) >= outer:
        return
    chord = circle_y(outer, x)
    ymin, ymax = max(-chord, ya), min(chord, yb)
    if ymax <= ymin:
        return
    if abs(x) >= inner:
        yield ymin, ymax
        return
    hole = circle_y(inner, x)
    if min(ymax, -hole) > ymin:
        yield ymin, min(ymax, -hole)
    if ymax > max(ymin, hole):
        yield max(ymin, hole), ymax


def annular_cut_rule(xa, xb, ya, yb, outer, inner, n):
    """Independent positive clipped-annulus rule with endpoints at critical x."""
    cuts = {xa, xb}
    for r in (outer, inner):
        candidates = {r, -r}
        for y in (ya, yb):
            if abs(y) < r:
                candidates.update((circle_y(r, y), -circle_y(r, y)))
        cuts.update(x for x in candidates if xa < x < xb)
    ordered = sorted(cuts)
    for lo, hi in zip(ordered, ordered[1:]):
        for t, w in gauss(n, 0.0, pi):
            # The endpoint cosine mapping smooths the circular square-root term.
            x = lo + 0.5*(hi - lo)*(1.0 - cos(t))
            dx = 0.5*(hi - lo)*sin(t)*w
            for ymin, ymax in section_intervals(x, ya, yb, outer, inner):
                for y, dy in gauss(4, ymin, ymax):
                    yield x, y, dx*dy


def annular_centroids(n, outer, inner):
    """Mirror area/centroid integration on this non-disconnected clipped grid."""
    points = []
    d = 2 * outer / n
    for i in range(n):
        for j in range(n):
            x, y = -outer+i*d, -outer+j*d
            local = list(annular_cut_rule(x, x+d, y, y+d, outer, inner, 24))
            area = fsum(w for a,b,w in local)
            if area:
                cx = fsum(a*w for a,b,w in local)/area
                cy = fsum(b*w for a,b,w in local)/area
                assert inner < hypot(cx, cy) < outer
                points.append((cx, cy, area))
    return points


def bernstein(x):
    t = 0.5 * (x + 1.0)
    u = 1.0 - t
    return ((u**3, 3*t*u*u, 3*t*t*u, t**3),
            (-1.5*u*u, 1.5*(u*u - 2*t*u), 1.5*(2*t*u - t*t), 1.5*t*t))


def operators(x, y):
    bx, dx = bernstein(x)
    by, dy = bernstein(y)
    return (tuple(a*b for a in by for b in bx),
            tuple(a*b for a in by for b in dx),
            tuple(a*b for a in dy for b in bx))


def matrices(points):
    rows = [(w, x, y, *operators(x, y)) for x,y,w in points]
    stiffness = [[fsum(w*(dx[i]*dx[j]+dy[i]*dy[j]) for w,x,y,p,dx,dy in rows)
                  for j in range(16)] for i in range(16)]
    gauge = [fsum(w*p[i] for w,x,y,p,dx,dy in rows) for i in range(16)]
    coupling = [fsum(w*(y*dx[i]-x*dy[i]) for w,x,y,p,dx,dy in rows) for i in range(16)]
    return stiffness, gauge, coupling


def solve(matrix, rhs):
    """Small pivoted dense KKT system for zero-mean cubic warping."""
    aug = [row.copy()+[b] for row,b in zip(matrix, rhs, strict=True)]
    n = len(aug)
    for i in range(n):
        pivot = max(range(i,n), key=lambda j: abs(aug[j][i]))
        aug[i], aug[pivot] = aug[pivot], aug[i]
        assert abs(aug[i][i]) > 1e-14
        for j in range(i+1,n):
            coef = aug[j][i] / aug[i][i]
            for k in range(i+1,n+1):
                aug[j][k] -= coef * aug[i][k]
    result = [0.0]*n
    for i in reversed(range(n)):
        result[i] = (aug[i][-1] - fsum(aug[i][j]*result[j] for j in range(i+1,n))) / aug[i][i]
    return result


def integrate(points, field):
    stress = []
    for x,y,w in points:
        phi, dx, dy = operators(x,y)
        sx = fsum(a*b for a,b in zip(dx,field)) - y
        sy = fsum(a*b for a,b in zip(dy,field)) + x
        stress.append((w, x, y, sx, sy))
    return {
        "T_per_G_theta": fsum(w*(x*sy-y*sx) for w,x,y,sx,sy in stress),
        "Qx_per_G_theta": fsum(w*sx for w,x,y,sx,sy in stress),
        "Qy_per_G_theta": fsum(w*sy for w,x,y,sx,sy in stress),
        "energy_per_G_theta_squared": fsum(w*(sx*sx+sy*sy) for w,x,y,sx,sy in stress),
        "max_point_shear_per_G_theta": max(hypot(sx,sy) for w,x,y,sx,sy in stress),
    }


def measure(points, fine, analytic_j):
    matrix, gauge, rhs = matrices(points)
    field = solve([r+[g] for r,g in zip(matrix,gauge)] + [gauge+[0.0]], rhs+[0.0])[:-1]
    fitted = integrate(points, field)
    exact_domain = integrate(fine, field)
    j = fitted["T_per_G_theta"]
    assert abs(j-fitted["energy_per_G_theta_squared"]) < 2e-13
    return {"station_count": len(points),
            "area": fsum(w for x,y,w in points),
            "numerical_J": j,
            "twist_relative_error": analytic_j/j - 1.0,
            "six_resultants_unit_twist": [0.0, 0.0, 0.0, j, fitted["Qx_per_G_theta"], fitted["Qy_per_G_theta"]],
            "independently_reintegrated_same_field": exact_domain}


def full_moment_difference(a, b):
    return max(abs(fsum(w*x**i*y**j for x,y,w in a) - fsum(w*x**i*y**j for x,y,w in b))
               for i in range(7) for j in range(7) if i+j <= 10)


def run():
    square_j = 16.0 * (1.0/3 - 64/pi**5*fsum(tanh(n*pi/2)/n**5 for n in range(1, 512, 2)))
    sq4 = rectangle_gauss(-1,1,-1,1,4)
    sq5 = rectangle_gauss(-1,1,-1,1,5)
    sqref = rectangle_gauss(-1,1,-1,1,12)
    outer, inner = 1.0, 0.42
    annj = pi/2.0*(outer**4-inner**4)
    annfine = list(annular_cut_rule(-1,1,-1,1,outer,inner,24))
    annpolar = annular_polar(outer,inner,3,12)
    annold = annular_centroids(5,outer,inner)
    assert abs(fsum(w for x,y,w in annold)-pi*(outer**2-inner**2)) < 1e-14

    hole = (-0.16,0.19,-0.46,0.12)
    hole_positive = rectangle_hole_split(*hole)
    hole_signed = sq4 + [(x,y,-w) for x,y,w in rectangle_gauss(*hole,4)]
    hole_diff = full_moment_difference(hole_positive, hole_signed)
    sq_diff = full_moment_difference(sq4,sqref)
    ann_diff = full_moment_difference(annpolar,annfine)
    assert max(hole_diff, sq_diff, ann_diff) < 1e-12
    sqmid = measure(midpoint_square(5),sqref,square_j)
    sqgauss4 = measure(sq4,sqref,square_j)
    assert 0.101 < sqmid["twist_relative_error"] < 0.102
    assert abs(sqgauss4["twist_relative_error"]) < 0.004
    return {"status": "PASS", "units": "coordinates scaled to a=2 or outer radius=1; G*theta=1",
            "square": {"reference_J": square_j, "midpoint5": sqmid, "Gauss4": sqgauss4,
                       "Gauss5": measure(sq5,sqref,square_j), "moment_max_error": sq_diff},
            "concentric_annulus": {"radii": [outer,inner], "reference_J": annj,
                                    "centroid5": measure(annold,annfine,annj),
                                    "polar3x12": measure(annpolar,annfine,annj),
                                    "moment_max_error": ann_diff},
            "eccentric_rectangular_hole": {"hole": hole, "positive_split_points": len(hole_positive),
                                           "moment_max_error_vs_signed_exact": hole_diff}}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
