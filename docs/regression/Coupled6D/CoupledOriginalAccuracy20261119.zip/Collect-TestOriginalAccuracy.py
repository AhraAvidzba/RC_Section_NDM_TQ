"""ДЛЯ ТЕСТОВ. Сохраняет точную исходную точность материалов, разрешение нагрузки и явные неудачи продолжения."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestCollect(repo, root):
    """Фиксирует реальные CFB и все входы четырёх направленных опытов; основная книга не заменяется тестовой."""
    here = Path(__file__).resolve().parent
    cases = {'Original': 'OriginalAccuracy20261119', 'Resolved': 'ResolvedBridge20261119',
             'Adaptive': 'AdaptiveBridge20261119', 'Automatic': 'AutomaticConstraint20261119'}
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for key in cases:
        folder = root / 'Cases' / key
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(sources) == 36
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    helpers = ('Collect-TestOriginalAccuracy.py', 'Check-TestOriginalAccuracy.py', 'Audit-TestGenericConstraintBook.py',
        'Audit-TestPrivateCoupledBook.py', 'Canonical-TestCoreVBA.py', 'Analyze-TestNewtonLine.py',
        'Analyze-TestYieldProjection.py', 'Analyze-TestYieldSequence.py', 'Analyze-TestGenericBridge.py',
        'Stage-TestOriginalAccuracy.py', 'Stage-TestResolvedBridge.py', 'Stage-TestAdaptiveBridge.py',
        'Stage-TestAutomaticConstraint.py', 'Stage-TestGenericConstraint.py', 'Stage-TestGenericSequence.py',
        'Stage-TestYieldProjectedSequence.py', 'CProjectedEquationsTest.cls', 'TestNativeGenericHybrid.bas.txt',
        'TestNativeOrdinaryBridge.bas.txt', 'TestNativeYieldProjection.bas.txt', 'TestNativeNewtonLine.bas.txt',
        'TestNativeNewtonYieldEvent.bas.txt', 'Stage-TestNewtonYieldPrecision.py', 'Stage-TestNewtonYieldEvent.py',
        'Stage-TestNewtonLine.py', 'Guard-TestExistingOffice.py', 'Check-TestActualReverseCapture.py',
        'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py', 'Pack-TestCompiledProjects.py')
    for name in helpers:
        (root / name).write_bytes((here / name).read_bytes())
    for name in ('CCoupledConcreteResponse.cls', 'CCoupledConcreteReturn.cls'):
        target = root / 'WorkingMaterials' / name
        target.parent.mkdir(exist_ok=True)
        target.write_bytes((repo / 'src/Materials' / name).read_bytes())
    run_path(str(here / 'Pack-TestCompiledProjects.py'))['TestPack'](root, cases)
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '32ffcc49c6440cbc6b4c65ec1d39124857a922d9',
        'working_sources_changed': False, 'ordinary_solver_recovery_enabled': False,
        'installed_workbook_changed': False, 'physical_capacity_certified': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name not in ('Files.json', 'CompiledVBA.bin')}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('ORIGINAL MATERIAL ACCURACY EVIDENCE COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
