"""Replay the historic HardShear exit and exact production chart comparison."""

import argparse
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import json
import re
import runpy
import sys
from xml.etree import ElementTree
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
spec = spec_from_file_location("terminal_analysis", HERE / "Verify-HardShearTerminal.py")
audit = module_from_spec(spec)
spec.loader.exec_module(audit)
audit.DEPTH = HERE / "Historical"
audit.REPO = HERE
BOOKS = {"Historical": "Historical/Endpoint/chart4.xml", "Current": "Current/chart4.xml"}
PROOF_SHA = "024D3AE67455294188FC2E10500B3D889E5AC50C9F57EEBAC2A87878C1394F2B"


def read_chart(path):
    source = runpy.run_path(str(HERE / "VerifySavedHardShearChart.py"))
    chart = ElementTree.parse(path)
    ns = source["CHART_NS"]
    data = {}
    for item in chart.findall(".//c:ser", ns):
        title = item.findtext("./c:tx//c:v", namespaces=ns)
        data[title] = tuple(source["cached_coordinates"](item, name) for name in ("xVal", "yVal"))
    assert {"Заданные усилия", "Заданная точка", "Поиск предела", "Последняя точка поиска"} <= data.keys()
    return "xl/charts/chart4.xml", data


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions")
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--publication", type=Path, help="also compare dependencies against the sealed release archive")
    args = cli.parse_args()
    for name, expected in audit.read(HERE / "SHA256SUMS.json").items():
        assert audit.digest(HERE / name) == expected
    records = audit.read(HERE / "WorkbookObservations.json")
    for role, part in BOOKS.items():
        assert audit.digest(HERE / part) == records[role]["part_sha256"]
    assert records["Current"]["workbook_sha256"] == audit.CURRENT_REOPEN_SHA
    metadata = audit.read(HERE / "PublicationDependency.json")
    for file, expected in metadata["files"].items():
        assert audit.digest(HERE / "Current" / Path(file).name) == expected
    if args.publication:
        assert audit.digest(args.publication) == metadata["sha256"]
        with ZipFile(args.publication) as publication:
            for file in metadata["files"]:
                data = publication.read("CoupledDirectSteelPublication/" + file)
                assert data == (HERE / "Current" / Path(file).name).read_bytes()
    receipt = audit.read(HERE / "Current/ProductionVerification.json")
    native = HERE / "Current/Both.txt"
    assert audit.digest(native) == receipt["native"]["Both"]["report_sha256"]
    assert audit.digest(HERE / "Current/Both.txt.ProcessClosure.json") == receipt["native"]["Both"]["closure_sha256"]
    raw = native.read_text(encoding="utf-8-sig")
    identity = re.search(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=\1; equal=True;", raw, re.M)
    assert identity and identity[1] == receipt["native"]["Both"]["details"]["results_reopen_sha256"]

    audit.getcontext().prec = 42
    historical, result = audit.archived_data(lambda _: read_chart(HERE / BOOKS["Historical"]))
    chart, data = read_chart(HERE / BOOKS["Current"])
    workflow = (HERE / "Current/RC_Section_NDM_execution_report.txt").read_text(encoding="utf-16")
    current = audit.compare_current_prefix(historical, chart, data, receipt, workflow, audit.CURRENT_REOPEN_SHA)
    proof = HERE / "HardShearTerminalAudit.json"
    closed = json.loads(json.dumps({"historical": result, "production": current}, ensure_ascii=False, default=str))
    assert audit.read(proof) == closed and audit.digest(proof) == PROOF_SHA
    print("PASS HARD SHEAR TERMINAL ARCHIVE", PROOF_SHA)


if __name__ == "__main__":
    main()
