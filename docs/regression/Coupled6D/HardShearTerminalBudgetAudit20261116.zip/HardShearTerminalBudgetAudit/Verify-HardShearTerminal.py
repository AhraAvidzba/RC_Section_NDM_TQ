"""Check archived HardShear branch termination and compare the saved current prefix."""

from collections import Counter
import csv
from decimal import Decimal as D, getcontext
from hashlib import sha256
import json
from pathlib import Path
import re
import runpy


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
AUDIT = REPO / "docs/regression/Audit03/LocalGradientDerivative20261115"
DEPTH = AUDIT / "HardShearDepth20261116"
HISTORICAL_TRACE_SHA = "2F751459B4DE4AEF1670A84E131A9054E080A42FD308082C0D8D05AA32CF87E8"
CURRENT_REOPEN_SHA = "22A15992E3DBD77C277B5B63862383FC2963759A426612EFDBC9C67CF212265E"
ARCHIVED_SOURCES = {
    96: "A5A82FAB7C5E06C29B2414B966E804B01F1145FB7920138C5F300D09E67469D4",
    240: "47FC82B50BBAE8EAF1D2C729A1EA1A3C7016DC2C1FF9A8D84F04D7F12EF9D1F2",
    640: HISTORICAL_TRACE_SHA,
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_bytes())


def row_interval(point, direction, scales):
    value = D(point[4])
    target = [D(x) for x in point[9:15]]
    stored = [D(x) for x in point[15:21]]
    for got, component in zip(target, direction, strict=True):
        assert abs(got - component * value) <= D("5e-13") * (1 + abs(got))
    normalized_direction = [abs(component / scale) for component, scale in zip(direction, scales, strict=True)]
    residual = max(abs(got - wanted) / scale for got, wanted, scale in zip(stored, target, scales, strict=True))
    budget = D("5e-7") * (1 + abs(value) * max(normalized_direction))
    assert residual < budget
    intervals = []
    for got, scale, component in zip(stored, scales, direction, strict=True):
        # Bound the wrench projection with the declared absolute comparison budget.
        limits = ((got - budget * scale) / component, (got + budget * scale) / component)
        intervals.append((min(limits), max(limits)))
    low = max(pair[0] for pair in intervals)
    high = min(pair[1] for pair in intervals)
    assert low <= value <= high
    return {"field": int(point[2]), "probe": int(point[1]), "control": D(point[3]), "lambda": value,
            "wrench_comparison_interval": (low, high), "maximum_residual_MPa": residual,
            "comparison_budget_MPa": budget, "steel_use": D(point[5]), "kind": point[0]}


def archived_data(read_series):
    records = {
        budget: (DEPTH / ("Endpoint/Native" if budget == 640 else "Native") / f"HardShear-{budget}.csv")
        for budget in ARCHIVED_SOURCES
    }
    for budget, path in records.items():
        assert digest(path) == ARCHIVED_SOURCES[budget]
    raw = {budget: path.read_bytes().splitlines() for budget, path in records.items()}
    assert raw[96] == raw[240][:len(raw[96])] == raw[640][:len(raw[96])]
    assert raw[240] == raw[640][:len(raw[240])]
    with records[640].open(encoding="cp1251", newline="") as stream:
        rows = list(csv.reader(stream, delimiter=";"))
    attempts = {int(row[1]): row for row in rows if row[0] == "Probe"}
    assert list(attempts) == list(range(1, 630))
    assert attempts[629][5] == "True"
    assert sum(attempts[i][5] == "True" for i in range(97, 630)) == 533
    geometry = read(REPO / "tmp/hard-audit/HardShear-HistoryReceipt.json")
    assert geometry["sourceSHA256"] and geometry["geometryArea_mm2"] == 21600
    direction = [D(str(x)) for x in geometry["forceDirection_N_Nmm"]]
    scale = [D(str(x)) for x in geometry["forceScales_N_or_Nmm_per_MPa"]]
    points = [row_interval(row, direction, scale) for row in rows if row[0] in ("Accept", "Boundary")]
    assert len(points) == 571 and points[-1]["kind"] == "Boundary"
    assert max(point["steel_use"] for point in points) < D(".00427")
    leaves = points[-2:]
    assert [point["field"] for point in leaves] == [577, 578]
    assert leaves[0]["wrench_comparison_interval"][0] > 0 > leaves[1]["wrench_comparison_interval"][1]
    assert leaves[1]["control"] > leaves[0]["control"] and leaves[1]["probe"] == leaves[0]["probe"] + 1
    endpoint_workbook = records[640].with_suffix(".xlsm")
    _, series = read_series(endpoint_workbook)
    positions, samples = series["Поиск предела"]
    assert positions == list(range(1, 578)) and samples.index(max(samples)) == 8
    descending = samples[8:]
    assert all(right < left for left, right in zip(descending, descending[1:]))
    # Adjacent intervals for the fully recorded one-sided tail remain disjoint at that budget.
    tail = [point for point in points if point["field"] >= 13]
    gaps = [left["wrench_comparison_interval"][0] - right["wrench_comparison_interval"][1]
            for left, right in zip(tail, tail[1:])]
    assert min(gaps) > 0
    archive = read(DEPTH / "HardShearDepthChecks.json")
    endpoint = read(DEPTH / "HardShearEndpointChecks.json")["endpoint"]
    times = (D(str(archive["standard"]["seconds"])), D(str(archive["extended"]["seconds"])), D(str(endpoint["seconds"])))
    return samples, {
        "raw_record_counts": Counter(row[0] for row in rows),
        "post_peak_monotone_accepted_steps": len(descending) - 1,
        "maximum_archived_steel_use": max(point["steel_use"] for point in points),
        "largest_raw_six_force_residual_MPa": max(point["maximum_residual_MPa"] for point in points),
        "smallest_wrench_interval_gap_for_consecutive_recharted_points": min(gaps),
        "terminal_accepted_and_uncommitted_fields": leaves,
        "probes_97_through_629": 533,
        "successful_97_through_629": 533,
        "wall_seconds_for_historical_96_240_640_budgets": times,
        "seconds_for_533_later_attempts": times[-1] - times[0],
        "mean_increment_seconds_for_those_attempts": (times[-1] - times[0]) / D(533),
        "terminal_scope": "Exit from positive lambda of this sampled branch, with the last trial uncommitted",
        "physical_capacity_certified": False,
    }


def current_prefix(read_series, old):
    proof = read(REPO / "tmp/dsl/ProductionVerification.json")
    raw_native = REPO / "tmp/dsl/Native/Both.txt"
    assert digest(raw_native) == proof["native"]["Both"]["report_sha256"]
    text = raw_native.read_text(encoding="utf-8-sig")
    record = re.search(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=\1; equal=True; file=(.+)$", text, re.M)
    assert record and record[1] == proof["native"]["Both"]["details"]["results_reopen_sha256"]
    workbook = Path(record[2])
    assert digest(workbook) == CURRENT_REOPEN_SHA
    chart, series = read_series(workbook)
    workflow = (workbook.parent / "RC_Section_NDM_execution_report.txt").read_text(encoding="utf-16")
    return compare_current_prefix(old, chart, series, proof, workflow, digest(workbook))


def compare_current_prefix(old, chart, series, proof, workflow, workbook_hash):
    index, values = series["Поиск предела"]
    assert index == list(range(1, 69)) and len(values) == 68 and values.index(max(values)) == 8
    assert series["Последняя точка поиска"] == ([index[-1]], [values[-1]])
    assert series["Заданная точка"][1] == [1.]
    assert abs(D(str(max(values))) - D(proof["native"]["Both"]["details"]["confirmed_lower"])) < D("1e-13")
    delta = [abs(a - b) for a, b in zip(old, values)]
    for phase in ("Direct", "Both"):
        assert proof["native"][phase]["details"]["direct_status"] == "OK"
    assert proof["native"]["Both"]["details"]["capacity_code"] == "NUMERICAL_FAILURE"
    assert proof["native"]["Both"]["details"]["limit"] is None
    pattern = r"^\[([\d.]+) с\] Доля постоянной части: 1; lambda: 1; принято: 4; отклонено: 0; проб: 4\s*$"
    direct = re.search(pattern, workflow, re.M)
    terminal_time = re.search(r"^\[([\d.]+) с\] Подтверждён локальный максимум", workflow, re.M)
    accounting = {"total_deformation_probes": 96, "total_refined_shoulder_probes": 19, "yield_switch_probes": 4,
                  "accepted_yield_switch": 1, "accepted_postpeak_new_coordinate": 55, "accepted_expanded_steps": 51}
    for phrase in ("проб: 96; проб смены меры: 4; принято после смены меры: 1",
                   "принято полей после максимума в новой мере: 55; принято увеличенных шагов: 51",
                   "проб при проверке плеч: 19"):
        assert phrase in workflow
    assert direct and terminal_time and D(terminal_time[1]) - D(direct[1]) > 75
    return {
        "saved_workbook_sha256": workbook_hash,
        "saved_chart": chart,
        "current_accepted_prefix_count": len(values),
        "current_sampled_peak": max(values), "historical_sampled_peak": max(old),
        "current_last_factor": values[-1], "historical_factor_at_same_index": old[len(values)-1],
        "max_absolute_factor_difference_over_common_index": max(delta),
        "index_of_max_difference": delta.index(max(delta)) + 1,
        "current_capacity_interval_in_workflow_seconds": [direct[1], terminal_time[1]],
        "current_capacity_accounting": accounting,
        "direct_seconds": proof["native"]["Direct"]["details"]["seconds"],
        "both_seconds": proof["native"]["Both"]["details"]["seconds"],
        "capacity": "NumFail",
        "code": "NUMERICAL_FAILURE",
    }


def main():
    getcontext().prec = 42
    chart_helper = AUDIT / "ProductionYieldRecovery/VerifySavedHardShearChart.py"
    read_series = runpy.run_path(str(chart_helper))["read_series"]
    values, archive = archived_data(read_series)
    proof = {"historical": archive, "production": current_prefix(read_series, values)}
    target = HERE / "HardShearTerminalAudit.json"
    target.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2, default=str) + "\n").encode("utf-8"))
    print("PASS HARD SHEAR TERMINAL", digest(target), "termination brackets", archive["terminal_accepted_and_uncommitted_fields"])


if __name__ == "__main__":
    main()
