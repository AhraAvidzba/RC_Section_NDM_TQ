"""Независимо сверяет график сохранённой книги и число секунд в протоколах HardShear."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
from xml.etree import ElementTree
from zipfile import ZipFile


CHART_NS = {'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart'}


def cached_coordinates(series, axis):
    """Возвращает последовательность координат из сохранённого кэша Excel."""
    points = series.findall(f'./c:{axis}//c:pt', CHART_NS)
    indices = [int(point.attrib['idx']) for point in points]
    assert indices == list(range(len(points)))
    return [float(point.findtext('c:v', namespaces=CHART_NS)) for point in points]


def read_series(workbook):
    """Находит единственный график поиска по именам его рядов."""
    matches = []
    with ZipFile(workbook) as package:
        for name in package.namelist():
            if not re.fullmatch(r'xl/charts/chart\d+\.xml', name):
                continue
            chart = ElementTree.fromstring(package.read(name))
            series = {}
            for entry in chart.findall('.//c:ser', CHART_NS):
                title = entry.findtext('./c:tx//c:v', namespaces=CHART_NS)
                series[title] = entry
            if {'Заданные усилия', 'Заданная точка', 'Поиск предела', 'Последняя точка поиска'} <= series.keys():
                matches.append((name, series))
    assert len(matches) == 1
    path, series = matches[0]
    return path, {title: (cached_coordinates(entry, 'xVal'), cached_coordinates(entry, 'yVal'))
                  for title, entry in series.items()}


def verify(workbook, native, external):
    """Сверяет состояние прямого расчёта, максимум и реальные точки после него."""
    chart, series = read_series(workbook)
    log = native.read_text(encoding='utf-8-sig')
    peak_summary = re.search(r'^TIMING_STATES: direct=OK; capacity=(\w+); confirmed lower=([^;]+); limit=([^;]*);', log, re.M)
    seconds = re.search(r'^TIMING_SECONDS: ([\d.,]+) \| Both \| (Excel|File)', log, re.M)
    assert peak_summary and seconds
    for label in ('RESULTS_SAVE_REOPEN', 'STATUS_STYLE_SAVE_REOPEN'):
        assert re.search(rf'^{label}: before=([A-F0-9]{{64}}); after=\1; equal=True', log, re.M)

    direct_steps, direct_loads = series['Заданные усилия']
    steps, loads = series['Поиск предела']
    assert len(direct_steps) == len(direct_loads) and direct_loads[-1] == 1.0
    assert series['Заданная точка'] == ([direct_steps[-1]], [1.0])
    assert steps == list(range(1, len(loads) + 1))
    assert loads[:len(direct_loads)] == direct_loads
    assert series['Последняя точка поиска'] == ([steps[-1]], [loads[-1]])
    peak = max(loads)
    assert math.isclose(peak, float(peak_summary[2].replace(',', '.')), rel_tol=1e-13)
    peak_index = loads.index(peak)
    if peak_summary[1] == 'NumFail':
        assert peak_summary[3] == ''

    external_runs = {}
    for path in external:
        data = json.loads(path.read_text(encoding='utf-8-sig'))
        external_runs[path.stem] = dict(seconds=data['elapsed_s'], variant=data['variant'],
                                       mesh=data['mesh'], termination=data['termination'],
                                       largest_load=max(state['factor'] for state in data['states']))
    return dict(workbook=str(workbook), sha256=hashlib.sha256(workbook.read_bytes()).hexdigest(), chart=chart,
                workbook_mode=seconds[2], workbook_seconds=float(seconds[1].replace(',', '.')),
                capacity=peak_summary[1], peak_step=peak_index + 1, loads=loads,
                after_peak=loads[peak_index + 1:], external_runs=external_runs)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('workbook', type=Path)
    parser.add_argument('native', type=Path)
    parser.add_argument('external', type=Path, nargs='*')
    args = parser.parse_args()
    print(json.dumps(verify(args.workbook, args.native, args.external), indent=2, ensure_ascii=False))
