from argparse import ArgumentParser
import json
from pathlib import Path
import runpy

H=Path(__file__).resolve().parent; PARENT=H.parent/'KaniRefitNear47'; P=runpy.run_path(PARENT/'Prepare-Near47.py')
BOOK,SHADOW,SOLVER,ELASTIC,MODULE,CAPTURED=(P[k] for k in ('BOOK','SHADOW','SOLVER','ELASTIC','MODULE','CAPTURED'))
sha,one=P['sha'],P['one']
FIX='1B55333C02D93FB6F3C2D6219F0018BD6AD14735F2DE6A172EDF9DFE5363840F'
PLAN='B5FBD90537AC96363FFD644773BA67897E3F0C5C392A1C44667197CDFB64D5DC'
CONCRETE=Path('src/Materials/CCoupledConcreteResponse.cls'); CONCRETE_SHA='92B9BA4BE63F42DD0600C205DF71E38DFCFDBBF0C69BE249A5AFBC8BC230336C'
HELPER=H.parent/'KaniPracticalProbe45'

def prepare(repo):
    assert not (H/'Preparation.json').exists()
    past=P['check']()
    assert sha(repo/BOOK)==past['workbook_sha256'] and all(sha(repo/k)==v for k,v in past['production_source_sha256'].items())
    assert sha(repo/CONCRETE)==CONCRETE_SHA
    assert sha(H/'CommitInputs.csv')==FIX and sha(H/'CommitPlan.json')==PLAN
    history=[x for x in (PARENT/'KaniGaugeInput.csv').read_text(encoding='ascii').splitlines() if x.startswith('KANI_B_FIELD;History')]
    trials=(H/'CommitInputs.csv').read_text(encoding='ascii').splitlines()
    assert len(history)==6 and len(trials)==3 and all(len(x.split(';'))==92 for x in history+trials)
    src=(PARENT/MODULE).read_text(encoding='utf8'); a=src.index('    Dim rootPath As String'); b=src.index('    Close #tangents:',a)
    src=src[:a]+(H/'CommitMain.bas.txt').read_text(encoding='utf8').rstrip()+'\n'+src[b:]
    src=one(src,'If entries.Count <> 4 Or history.Count <> 43','If entries.Count <> 3 Or history.Count <> 43')
    runner=(PARENT/'Run-Near47.ps1').read_text(encoding='utf-8-sig')
    for k,v in (('Prepare-Near47.py','Prepare-Commit48.py'),('Verify-Near47.py','Verify-Commit48.py'),
                ("'-TimeoutSeconds',95","'-TimeoutSeconds',125"),
                ('# Изолированная проверка связанных строк Kani при приращении 0,10 Н.','# Изолированное закрепление пробы Kani 0,10 Н и проверка штатного восстановления.'),
                ('Сверка уточнённого поля Kani не пройдена.','Сверка закреплённой истории Kani не пройдена.')): runner=one(runner,k,v)
    (H/'Native').mkdir(exist_ok=True); (H/'Temp').mkdir(exist_ok=True)
    by={Path(k):PARENT/k for k in past['frozen'] if k.startswith('tools/') or k in
        ('KaniV4Input.csv','KaniChartInput.csv',CAPTURED.as_posix(),ELASTIC.as_posix())}
    by[BOOK]=repo/BOOK; by[SHADOW]=repo/BOOK; by[Path('ConcreteProduction.cls.txt')]=repo/CONCRETE
    inputs={key:path.read_bytes() for key,path in by.items()}
    inputs.update({MODULE:src.encode('utf8'),Path('Run-Commit48.ps1'):runner.encode('utf-8-sig'),
        SOLVER:(HELPER/SOLVER).read_bytes(),Path('KaniGaugeInput.csv'):('\r\n'.join(history+trials)+'\r\n').encode('ascii')})
    for name,data in inputs.items():
        path=H/name; path.parent.mkdir(exist_ok=True,parents=True); path.write_bytes(data)
    frozen=(set(inputs)-{SHADOW})|{Path(k) for k in ('CommitInputs.csv','CommitPlan.json','CommitMain.bas.txt',
                    'Freeze-Commit48.py','Prepare-Commit48.py','Verify-Commit48.py')}
    record={'workbook_sha256':past['workbook_sha256'],'production_source_sha256':{**past['production_source_sha256'],CONCRETE.as_posix():CONCRETE_SHA},
            'frozen':{k.as_posix():sha(H/k) for k in sorted(frozen)}}
    (H/'Preparation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
    return check()

def check():
    r=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert r['workbook_sha256']==P['check']()['workbook_sha256']==sha(H/BOOK)
    assert r['production_source_sha256'][CONCRETE.as_posix()]==CONCRETE_SHA==sha(H/'ConcreteProduction.cls.txt')
    assert all(sha(H/k)==v for k,v in r['frozen'].items())
    assert (H/SOLVER).read_bytes()==(HELPER/SOLVER).read_bytes()
    assert sha(H/CAPTURED)==r['production_source_sha256'][SOLVER.as_posix()]
    assert sha(H/ELASTIC)==r['production_source_sha256'][ELASTIC.as_posix()]
    assert r['frozen']['CommitInputs.csv']==FIX and r['frozen']['CommitPlan.json']==PLAN
    return r

if __name__=='__main__':
    a=ArgumentParser(); a.add_argument('--repo',type=Path); a.add_argument('--check',action='store_true'); z=a.parse_args()
    print((check() if z.check else prepare(z.repo))['workbook_sha256'],sha(H/'Preparation.json'))
