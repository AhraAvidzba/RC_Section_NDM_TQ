from pathlib import Path
from hashlib import sha256
import csv,json
import numpy as np

p=Path(__file__).resolve().parent; report=json.loads((p/'Commit48Verification.json').read_text(encoding='utf8')); mats={}
for line in csv.reader((p/'Native/KaniV4Tangents.csv').open(encoding='cp1251',newline=''),delimiter=';'):
    if line[0]!='MATRIX': continue
    _,k,i,*v=line; mats.setdefault(k,np.zeros((88,88)))[int(i)-1]=list(map(float,v))
force=np.r_[np.zeros(87),1.]; e={}; F={}
for k,M in mats.items():
    scale=np.maximum(np.max(abs(M),axis=0),1e-30); cond=float(np.linalg.cond(M/scale))
    x=np.linalg.solve(M.T,force); eta=float(np.linalg.norm(x,1)); e[k]={'columnScaledCond2':cond,'loadCovectorL1_unscaled':eta,'adjointResidual':float(max(abs(M.T@x-force))),'conditionedGaugeLoadColMax':float(scale[-1])}
for label,raw in report['acceptedPredictorF_MPa'].items():
    data=np.array(raw); F[label]={'min_F_MPa':float(data.min()), 'max_F_MPa':float(data.max()),'numAbsBelow1e-12':int((abs(data)<1e-12).sum()),'numPositive':int((data>0).sum()),'numNegative':int((data<0).sum())}
ref=report['adjointUncertainty_N']['FromHistory45']; d=report['increaseQy_N']; last=8.87340672528102
rho={'beforeCommitVsAfterCommitSameFieldMatrixRelativeMax':float(np.max(abs(mats['H44TrialStock']-mats['H45Stock']))/np.max(abs(mats['H45Stock']))),
     'postCommitStockVsRefinedAdjointL1RelativeDiff':float(e['H45Refined']['loadCovectorL1_unscaled']/e['H45Stock']['loadCovectorL1_unscaled']-1),
     'crossHistoryDisjointLoadIntervalsNeedMoreThan_N':ref+last,'increaseAsFractionOfFreshAdjoint':d/ref,
     'estimatesAreLocalSensitivityNotValidatedConfidenceIntervals':True,'tangentCondition':e,'predictorIndicators':F}
path=p/'Commit48Conditioning.json'; path.write_text(json.dumps(rho,indent=2)+'\n',encoding='utf8'); print(path,sha256(path.read_bytes()).hexdigest().upper()); print(json.dumps(rho,indent=2))
