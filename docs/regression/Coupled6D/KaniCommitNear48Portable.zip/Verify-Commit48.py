"""Verify fixed and controlled recovery, committed H45, and the native adjoint."""
from pathlib import Path
import csv,json,runpy

H=Path(__file__).resolve().parent; ROOT=H.parent
P=runpy.run_path(H/'Prepare-Commit48.py'); O=runpy.run_path(ROOT/'KaniWarpBeyond43/Check-KaniBeyond43.py')
np=O['np']; pk=O['peak']; sha=P['sha']; sec=O['section']


def verify():
    prep=P['check'](); native=H/'Native'; here=O['trs'](H); a,f,p,st,hashes=here
    prev=O['trs'](ROOT/'KaniRefitNear47'); plan=json.loads((H/'CommitPlan.json').read_text(encoding='utf8'))
    proc=json.loads((native/'KaniV4.txt.ProcessClosure.json').read_text(encoding='utf-8-sig'))
    owner=json.loads((native/'KaniV4.txt.Ownership.json').read_text(encoding='utf-8-sig'))
    comp=json.loads((H/'docs/regression/CodeUpdate.json').read_text(encoding='utf-8-sig'))
    closed=json.loads((native/'CompileClosure.json').read_text(encoding='utf-8-sig')); end=proc['Closure']['FinalState']
    assert proc['Passed'] and proc['ChildExitCode']==0 and closed['State']==end['State']=='Absent'
    assert end['PID']==owner['PID'] and end['StartTicksUTC']==owner['StartTicksUTC'] and owner['VerifiedNewOwner']
    assert comp['Compiled'] and not comp['ProductionChanged'] and comp['ProductionSHA256']==prep['workbook_sha256']
    assert comp['WorkbookSHA256']==sha(H/P['SHADOW']) and sorted(comp['Modules'])==['CCoupledElasticState','CCoupledNewtonSolver','modTestKaniStage38']
    report=(native/'KaniV4.txt').read_text(encoding='utf-8-sig')
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    assert np.array_equal(p,prev[2]); E={}; F={}; B={}; A={}
    for kind,tag,first,*data in csv.reader((native/'KaniV4Tangents.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        if kind=='MATRIX':
            i=int(first)-1; assert 0<=i<88 and len(data)==88
            out=A.setdefault(tag,np.full((88,88),np.nan)); assert np.isnan(out[i]).all(); out[i]=list(map(float,data)); continue
        i,j=int(data[0])+1,int(first)-1
        assert 0<=i<3 and 0<=j<184
        if kind=='ENERGY':
            out=E.setdefault(tag,np.full((3,184,2),np.nan)); assert np.isnan(out[i,j]).all(); out[i,j]=list(map(float,data[1:]))
        elif kind=='YIELD':
            out=F.setdefault(tag,np.full((3,184),np.nan)); assert np.isnan(out[i,j]); out[i,j]=float(data[1])
        else:
            assert kind=='BRANCH'; out=B.setdefault(tag,np.full((3,184,3),-99)); assert out[i,j,0]==-99
            out[i,j]=list(map(int,data[1:]))
    assert set(A)=={'H44TrialStock','H45Stock','H45Refined'}
    assert all(np.isfinite(v).all() for v in list(E.values())+list(F.values())+list(A.values())) and all((v[:,:,0]>=0).all() for v in B.values())
    assert set(B)==set(a)
    for start,endtag in (('Base43','Restore43'),('Base44','Restore44'),('Base44','AfterAuto44')):
        assert np.array_equal(E[start],E[endtag]) and np.array_equal(B[start],B[endtag])
        assert np.array_equal(f[start],f[endtag]) and np.array_equal(st[start],st[endtag])
    assert np.array_equal(F['Base44'],F['Restore44'])
    for now,past in (('Base43','Original43'),('Base44','BaseAccepted'),('NearOriginal','NearOriginal'),('Exact45','NearFull')):
        assert np.array_equal(f[now],prev[1][past]) and pk(st[now]-prev[3][past])<2e-10
    for tag in ('Committed45','ZeroFrom45'):
        assert np.array_equal(f[tag],f['Exact45']) and np.array_equal(st[tag],st['Exact45'])
    ed=E['Committed45']-E['Base44']; assert ed.min()>-1e-10
    auto={}; diag={}; adjoints={}; adj_auto={}
    for l in csv.reader((native/'KaniV4Trace.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        if l[0]=='AUTO': auto[l[1]]=list(map(float,l[2:]))
        if l[0]=='DIAGNOSTIC': diag[l[1]]=l[2]
        if l[0]=='ADJOINT': adjoints[l[1]]=float(l[2])
        if l[0]=='AUTO_ADJOINT': adj_auto[l[1]]=float(l[2])
    assert set(adjoints)=={'BeforeCommit45','FromHistory45'} and all(x>0 for x in adjoints.values())
    assert auto.keys()==diag.keys()=={'AutoFixedForce','AutoControlled'}
    residuals={}; gauges={}
    for k in f:
        rr=O['independent'](here,k); q=f[k]; g=np.r_[25600*sec.gauges@q[2:81],25600*(p@q[2:]-q[1])]
        assert len(rr)==89 and len(g)==5 and pk(g)<float(a[k][3])+1e-12
        residuals[k]=rr; gauges[k]=g
    anchor=f['Exact45']; assert abs(anchor[0]*1e5-plan['commonQy_N'])<1e-8 and abs(anchor[1]-plan['commonGamma'])<2e-16
    assert pk(residuals['Exact45'])<=a['Exact45'][3] and pk(residuals['Committed45'])<=a['Committed45'][3]
    auto_out={}
    for mode,(ok,mul,delta_gamma,raw) in auto.items():
        info={'solverSaidConverged':bool(ok),'diagnostic':diag[mode]}
        if ok:
            assert mode in f and mul==f[mode][0] and abs(f[mode][1]-anchor[1]-delta_gamma)<2e-16
            norm=pk(residuals[mode]); tol=float(a[mode][3]); assert abs(raw-norm)<2e-10 and norm<=tol+2e-10
            qerror=float((f[mode][0]-anchor[0])*1e5); gerror=float(delta_gamma*25600)
            info.update(obtainedQy_N=float(f[mode][0]*1e5),loadDifferenceFromPrescribed_N=qerror,meanShearError=delta_gamma,
                 controlEquivalentErrorMPa=gerror,independentNormMPa=norm,exactPrescribedQy=abs(qerror)<1e-9,
                 sameGammaWithinOriginalTolerance=abs(gerror)<=tol,actualAdjointN=adj_auto.get(mode,0)*1e5)
        else: assert mode not in f
        auto_out[mode]=info
    native_at={}; independent_at={}
    for where,m,tag in (('BeforeCommit45','H44TrialStock','Exact45'),('FromHistory45','H45Stock','ZeroFrom45')):
        q=f[tag]; T=A[m]; i0=np.r_[np.zeros(87),1.]
        weights=np.linalg.solve(T.T,i0); assert pk(T.T@weights-i0)<1e-6
        eq=max(float(a[tag][3]),pk(residuals[tag][:83]),pk(gauges[tag]))
        inverse=float(np.sum(abs(weights))*eq+2e-12*(1+abs(q[0])))
        assert abs(inverse-adjoints[where])/adjoints[where]<2e-5,(where,inverse,adjoints[where],eq)
        native_at[where]=float(adjoints[where]*1e5); independent_at[where]=inverse*1e5
    dlam=float((f['Committed45'][0]-f['Base44'][0])*1e5)
    trial=f['Committed45']; stage=(H/'CommitInputs.csv').read_text(encoding='ascii').splitlines()[-1].replace(';NearFull;',';History45;')
    witness=H/'History45Verified.csv'; witness.write_bytes((stage+'\r\n').encode('ascii'))
    answer={'workbookSHA256':prep['workbook_sha256'],'fixedFieldActuallyCommitted':True,'committedQy_N':float(trial[0]*1e5),'increaseQy_N':dlam,
            'committedGamma':float(trial[1]),'exactZeroStepReproduced':True,'h43H44RollbackExact':True,'normAfterCommit_MPa':pk(residuals['Committed45']),
            'adjointUncertainty_N':native_at,'independentlyRepeatedAdjoint_N':independent_at,'automaticRecovery':auto_out,
            'energiesByStation_minus0plus':{k:v.tolist() for k,v in E.items()},'acceptedPredictorF_MPa':{k:v.tolist() for k,v in F.items()},
            'maxPositiveEnergyChangeTensionCompression':np.max(ed.reshape(-1,2),axis=0).tolist(),
            'killedOwnedProcesses':{'compile':closed,'native':end},'History45FixtureSHA':sha(witness),
            'sourceCSV_SHA256':{**{p.name:v for p,v in hashes},'KaniV4Tangents.csv':sha(native/'KaniV4Tangents.csv')}}
    out=H/'Commit48Verification.json'; out.write_text(json.dumps(answer,indent=2)+'\n',encoding='utf8')
    print(out,sha(out),native_at,auto_out,sha(witness))

if __name__=='__main__': verify()
