from pathlib import Path
from hashlib import sha256
import json
H=Path(__file__).resolve().parent; P=H.parent/'KaniRefitNear47'
one=('Accepted19of512','NearOriginal','NearFull')
records={x.split(';')[1]:x for x in (P/'NearRefitFields.csv').read_text(encoding='ascii').splitlines()}
proof=json.loads((P/'NearRefitVerification.json').read_text(encoding='utf8'))
assert proof['outcome']=='ADMITTED_EXACT_SAME_BRANCH'
assert proof['probes']['NearFull']['fullNorm_MPa']<=proof['probes']['NearFull']['tau_MPa']
for required in one: assert len(records[required].split(';'))==92
out=H/'CommitInputs.csv'; out.write_bytes(('\r\n'.join(records[k] for k in one)+'\r\n').encode('ascii'))
sha=lambda p:sha256(p.read_bytes()).hexdigest().upper()
pro={'fixtureSha256':sha(out),'priorVerificationSha256':sha(P/'NearRefitVerification.json'),'priorBookSHA256':proof['workbook'],
     'nearUpstreamNormMPa':proof['probes']['NearOriginal']['fullNorm_MPa'],'nearAdmittedNormMPa':proof['probes']['NearFull']['fullNorm_MPa'],
     'commonGamma':proof['commonGamma'],'commonQy_N':proof['commonQy_N'],
     'protocol':['automatic fixed-load from original, discard','automatic deformation-control from original, discard',
                 'exact field zero-iteration+adjoint, commit','fresh derivatives and zero increment, discard','restore H44 and H43']}
p=H/'CommitPlan.json'; p.write_text(json.dumps(pro,indent=2)+'\n',encoding='utf8')
print(sha(out),sha(p))
