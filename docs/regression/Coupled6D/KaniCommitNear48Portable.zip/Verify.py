from pathlib import Path
from hashlib import sha256
import json, numpy as np
from scipy.interpolate import BSpline

def operators(geometry, L):
    x,y,area=geometry.T
    normalized=area/(305.*610.)
    gx_knots=np.array([-152.5]*4+[0.]+[152.5]*4)
    gy_knots=np.array([-305.]*4+[0.]+[305.]*4)
    basis=np.eye(5)
    spline_x=BSpline(gx_knots,basis,3,extrapolate=False)
    spline_y=BSpline(gy_knots,basis,3,extrapolate=False)
    nx,ny=spline_x(x),spline_y(y)
    dx,dy=spline_x.derivative()(x),spline_y.derivative()(y)
    def pair(a,b):
        return (a[:,:,None]*b[:,None,:]).reshape((len(x),25))
    shape=pair(ny,nx)
    slope_x=L*pair(ny,dx)
    slope_y=L*pair(dy,nx)
    h=np.zeros((184,6,79))
    u=slice(4,79,3)
    v=slice(5,79,3)
    w=slice(6,79,3)
    h[:,2,0]=1.
    h[:,2,1]=y/L
    h[:,2,2]=x/L
    h[:,4,3]=-y/L
    h[:,5,3]=x/L
    h[:,0,u]=slope_x
    h[:,1,v]=slope_y
    h[:,3,u]=slope_y
    h[:,3,v]=slope_x
    h[:,4,w]=slope_x
    h[:,5,w]=slope_y
    c=np.zeros((4,79))
    concrete=slice(144)
    shape_weight=shape[concrete]*normalized[concrete,None]
    c[0,u]=c[1,v]=c[2,w]=shape_weight.sum(axis=0)
    c[3,u]=(-y[concrete,None]/L*shape_weight).sum(axis=0)
    c[3,v]=(x[concrete,None]/L*shape_weight).sum(axis=0)
    resultants=np.zeros((184,6,6))
    resultants[:,0,2]=1.
    resultants[:,1,2]=y
    resultants[:,2,2]=x
    resultants[:,3,4]=-y
    resultants[:,3,5]=x
    resultants[:,4,4]=1.
    resultants[:,5,5]=1.
    scales=305.*610.*np.array([1.,L,L,L,1.,1.])
    return h, shape, c, resultants, normalized, scales

ROOT=Path(__file__).resolve().parent
def read(name): return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def digest(name): return sha256((ROOT/name).read_bytes()).hexdigest().upper()
def peak(a): return float(np.max(np.abs(a)))
def near(a,b,tol): assert abs(a-b)<=tol,(a,b,tol)

def control_certificate(residual,weights,tau):
    coeff=weights[2]
    pos=coeff>0.
    lo=float(np.max((-tau-residual[:79][pos])/coeff[pos]))
    hi=float(np.min((tau-residual[:79][pos])/coeff[pos]))
    involved=np.r_[pos,np.zeros(10,dtype=bool)]
    feasible=lo<=hi and peak(residual[~involved])<=tau
    return lo,hi,bool(feasible)

def computed(d, original):
    g,L=d["geometry"],float(d["length"])
    h,shape,c,qmat,weights,scales=operators(g,L)
    states={}
    for name,field,native,index in zip(d["names"],d["fields"],d["states"],d["station_index"],strict=True):
        tag=str(name)
        stations=d["stations"][int(index)]
        lam,target=field[:2]
        q=field[2:]
        coord=q[:79]
        depth=q[79:83]
        mu=q[83:]
        assert lam==native[1] and target==native[0]
        strains=h@coord
        slope=h[:,:,:4]@depth
        eps3=np.array([strains+i*.001*slope for i in (-1,0,1)])
        assert peak(eps3-stations[:,:,:6])<2e-12
        stresses=stations[1,:,6:]
        gradient=(stations[2,:,6:]-stations[0,:,6:])/.002
        eq=np.einsum("nij,ni,n->j",h,stresses,weights)
        eq[4:]-=np.einsum("nk,na,n->ka",shape,gradient[:,[4,5,2]],weights).ravel()
        eq+=c.T@mu
        long_eq=np.einsum("nij,ni,n->j",h[:,:,:4],gradient,weights)
        long_eq[1]-=1e5*lam/scales[0]
        gauge=c@coord
        force=np.einsum("nij,nj,n->i",qmat,stresses,g[:,2])
        assert peak(np.r_[eq,long_eq,gauge]-native[12:])<2e-10
        assert peak((force-native[6:12])/scales)<2e-10
        r=np.r_[eq,long_eq,(force-np.r_[np.zeros(5),1e5*lam])/scales]
        gamma=float(weights[:144]@strains[:144,5])
        tau=float(native[3])
        assert abs(gamma-target)*25600. <=tau and peak(gauge)*25600.<=tau
        norm=max(peak(r),abs(gamma-target)*25600.)
        near(norm,native[2],2e-10)
        states[tag]={"r":r,"tau":tau,"norm":norm,"field":field,"idx":int(index),"resultants":native[6:12]}
    return states,c

import csv

def verify():
    manifest=read('Manifest.json'); v=read('Commit48Verification.json'); p=read('CommitPlan.json'); prep=read('Preparation.json')
    for k,h in manifest['files'].items(): assert digest(k)==h,k
    assert v['workbookSHA256']==prep['workbook_sha256']==read('CodeUpdate.json')['ProductionSHA256']
    assert digest('CommitInputs.csv')==p['fixtureSha256']==prep['frozen']['CommitInputs.csv']
    assert digest('History45Verified.csv')==v['History45FixtureSHA']
    txt=(ROOT/'KaniV4.txt').read_text(encoding='utf-8-sig'); assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in txt and 'SOURCE_UNCHANGED: True' in txt
    closure=read('KaniV4.txt.ProcessClosure.json'); owner=read('KaniV4.txt.Ownership.json'); stop=closure['Closure']['FinalState']
    assert closure['Passed'] and closure['ChildExitCode']==0 and stop==v['killedOwnedProcesses']['native']
    assert stop['PID']==owner['PID'] and stop['StartTicksUTC']==owner['StartTicksUTC'] and stop['State']==read('CompileClosure.json')['State']=='Absent'
    with np.load(ROOT/'MeasuredSamples.npz',allow_pickle=False) as d:
        states,c=computed(d,v); tags=list(d['names']); proj=d['projection'];
    E={l:np.full((3,184,2),np.nan) for l in v['energiesByStation_minus0plus']}
    F={l:np.full((3,184),np.nan) for l in v['acceptedPredictorF_MPa']}
    B={l:np.full((3,184,3),-99) for l in tags}; A={}
    for kind,l,pt,*row in csv.reader((ROOT/'KaniV4Tangents.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        j=int(pt)-1
        if kind=='MATRIX': A.setdefault(l,np.full((88,88),np.nan))[j]=list(map(float,row)); continue
        i=int(row[0])+1; tail=row[1:]
        if kind=='BRANCH': B[l][i,j]=list(map(int,tail))
        elif kind=='ENERGY': E[l][i,j]=list(map(float,tail))
        else:
            assert kind=='YIELD'; F[l][i,j]=float(tail[0])
    assert len(A)==3 and all(np.isfinite(d).all() for d in A.values())
    for group,reference in ((E,v['energiesByStation_minus0plus']),(F,v['acceptedPredictorF_MPa'])):
        assert all(np.array_equal(x,np.array(reference[tag])) for tag,x in group.items())
    for before,after in (('Base43','Restore43'),('Base44','Restore44'),('Base44','AfterAuto44')):
        assert np.array_equal(E[before],E[after]) and np.array_equal(B[before],B[after])
        assert states[before]['idx']==states[after]['idx'] and np.array_equal(states[before]['field'],states[after]['field'])
    exact=states['Exact45']; post=states['Committed45']; zero=states['ZeroFrom45'];
    assert exact['idx']==post['idx']==zero['idx'] and np.array_equal(exact['field'],post['field']) and np.array_equal(post['field'],zero['field'])
    assert all(x['norm']<=x['tau'] for x in (exact,post,zero))
    near(post['norm'],v['normAfterCommit_MPa'],2e-10)
    q=post['field']; f=(ROOT/'History45Verified.csv').read_text(encoding='ascii').strip().split(';')
    assert f[1]=='History45' and peak(q[2:]-np.array(list(map(float,f[4:-1]))))<3e-16
    near(q[0]*1e5,v['committedQy_N'],1e-8)
    near((q[0]-states['Base44']['field'][0])*1e5,v['increaseQy_N'],1e-8)
    uncertainty={}
    for where,method,case in (('BeforeCommit45','H44TrialStock',exact),('FromHistory45','H45Stock',zero)):
        e=np.r_[np.zeros(87),1.]; shape=A[method]; weights=np.linalg.solve(shape.T,e); assert peak(shape.T@weights-e)<1e-6
        d=case['field'][2:]; kinematic=peak(np.r_[c@d[:79],proj@d-case['field'][1]])*25600
        tol=max(case['tau'],peak(case['r'][:83]),kinematic)
        nn=(np.sum(abs(weights))*tol+2e-12*(1+abs(case['field'][0])))*1e5
        near(nn,v['adjointUncertainty_N'][where],2e-5*nn); uncertainty[where]=float(nn)
    auto={}
    for mode,info in v['automaticRecovery'].items():
        if info['solverSaidConverged']:
            test=states[mode]; assert test['norm']<=test['tau']+2e-10
            near(test['field'][0]*1e5,info['obtainedQy_N'],1e-8)
            near(test['norm'],info['independentNormMPa'],2e-10)
            near(test['field'][1]-q[1],info['meanShearError'],2e-16)
        else: assert mode not in states
        auto[mode]=info
    print(json.dumps({'book':v['workbookSHA256'],'89rows5controls':len(states),'H45Qy_N':q[0]*1e5,
        'H45Norm_MPa':post['norm'],'adjoint_N':uncertainty,'automatic':auto,'rollback':True},indent=2))

if __name__=='__main__': verify()
