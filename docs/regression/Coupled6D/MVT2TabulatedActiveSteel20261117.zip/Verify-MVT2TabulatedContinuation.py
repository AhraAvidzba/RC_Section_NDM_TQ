"""Повторяет принятие силовых полей MVT2 без NumPy и без решателя, создавшего поля."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import fsum, isclose
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


NATIVE = ('MVT2TabulatedFlowNative20261117.zip', '0DDB248B0B2F61AF814F1E70EAE55CABE46CC07C261E8E8043A8D8A960850F49')
MATERIAL = ('MVT2EffectivePlasticFlow20261117.zip', '42D0340DACD7FE6E3A9BE3592DD6464219A6F58832F43061EC59999553E12220')
OPERATORS = ('MVT2NativePublicationCutFollow20261117.zip', '9F55DE3FC0B1B652DD1ED9683507423ADE4DF6AB3B008D9590EE1D9327F9864E')
REPLAY = 'MVT2TabulatedContinuation.json'


def archive(repo, entry):
    """Открывает проверенный архив исходных операторов или материала."""
    path = repo / 'docs/regression/Coupled6D' / entry[0]
    assert sha256(path.read_bytes()).hexdigest().upper() == entry[1]
    return ZipFile(path)


def load(repo, temp):
    """Читает эталонные скалярные функции, наборы таблиц и нативные поля."""
    ns = {'__name__': '__pinned__'}
    with archive(repo, OPERATORS) as z:
        exec(compile(z.read('Verify-NativeFollow.py'), OPERATORS[0], 'exec'),ns)
    utilities, recovery, _, _, _, mesh = ns['read_references'](repo)
    prefix = 'Matched/Native/'
    with archive(repo,NATIVE) as z:
        tables = utilities['read_operators'](z.read(prefix+'Operators.csv'))
        frames = utilities['read_tensor_frames'](z.read(prefix+'MVTGaussMixed.Tensor.csv'),45)
        rows = [line.split(';') for line in z.read(prefix+'MVTGaussMixed.csv').decode('cp1251').splitlines()]
    assert recovery['geometry'](rows)==mesh
    with archive(repo,MATERIAL) as z:
        for name in ('Compare-MVT2EffectiveFlow.py','Verify-MVT2BackboneReplay.py'):
            (temp/name).write_bytes(z.read(name))
        raw = json.loads(z.read('MVT2ASDBackboneTables.json'))['default']
        initial = json.loads(z.read('MVT2EffectiveInitial.json'))['default']
    utility = run_path(str(temp/'Compare-MVT2EffectiveFlow.py'))
    backbone = run_path(str(temp/'Verify-MVT2BackboneReplay.py'))
    rotate = utility['read_inputs'](repo,temp)[3][1]
    curves = [backbone['Backbone'](raw[k],-30000.*p) for k,p in zip(('T','C'),initial[3],strict=True)]
    return tables,frames,mesh,(utility,backbone,rotate,curves),recovery['equations']


def material(field, tables, points, support, history):
    """Решает скалярный закон на каждой станции, сохраняя принятую историю как вход."""
    utility,backbone,rotate,curves = support
    ratio = max(5., max(curves[1].nominal)/max(curves[0].nominal))
    spectral,tensor,elastic,minus = (utility[k] for k in ('spectral','tensor','elastic','minus'))
    updated, net, center = {}, {}, {}
    for s in (0,1,-1):
        for p,(_,_,_,*direction) in points.items():
            b = [tables['B'][p,j] for j in range(1,61)]
            e = tuple(fsum((v[k]+s*.001*v[k+6])*x for v,x in zip(b,field,strict=True)) for k in range(6))
            old_e, old_effective, old_coord, old_p = history[s,p]
            trial = tuple(a+b for a,b in zip(old_effective,elastic(minus(e,old_e)),strict=True))
            values,axes = spectral(trial,rotate)
            state = [curve.step(old,backbone['equivalent'](values,ratio,k==0,curves[0].floor))
                     for k,(curve,old) in enumerate(zip(curves,old_coord,strict=True))]
            stress = tensor([v*state[int(v<0.)][1] for v in values],axes)
            effective = tensor([v*state[int(v<0.)][2] for v in values],axes)
            new_p = 0.
            net[s,p] = stress
            if p>25:
                fy = 498. if p<=29 else 450.
                axial = fsum(a*b for a,b in zip(direction,e,strict=True))
                steel = min(fy,max(-fy,200000.*(axial-old_p)))
                new_p = axial - steel/200000.
                net[s,p] = tuple(steel*d-v for d,v in zip(direction,stress,strict=True))
            updated[s,p] = e,effective,tuple(x[0] for x in state),new_p
            if s==0:
                center[p] = (*e,*stress)
    return updated,net,center


def replay_native(tables,frames,points,support):
    """Повторяет зафиксированные VBA шаги и собирает исходные состояния для независимых ветвей."""
    zero = (0.,)*6
    history = {(s,p):(zero,zero,(0.,0.),0.) for s in (0,1,-1) for p in points}
    states,error={},0.
    for phase,(_,q,_) in frames.items():
        history,net,_ = material(tables['F'][phase],tables,points,support,history)
        if phase.startswith('S'):
            error=max(error,*(abs(a-b) for (s,p),tensor in net.items() for a,b in zip(
                tensor,tables['H'][phase,s,p],strict=True)))
            states[q]=history
    assert error<8e-7 and len(states)==32
    return states


def replay_route(history, states, tables, mesh, support, equation):
    """Принимает только поля с подтверждёнными шестью усилиями и всеми связями."""
    confirmations = []
    for row in states:
        if not row['accepted']:
            assert row is states[-1] and row['norms_MPa'][-1] > row['tolerance_MPa']
            break
        q,field = row['Qy_N'], row['field']
        history,net,center = material(field,tables,mesh[1],support,history)
        phase = 'Independent'
        tables['F'][phase] = field
        tables['H'].update({(phase,s,p): values for (s,p),values in net.items()})
        eq = equation(phase,(10510000.,q,center),tables,mesh)
        norm = max(eq[key] for key in ('weak_MPa','gauge_MPa','resultant_MPa'))
        assert abs(norm-row['norms_MPa'][-1])<2e-9
        assert isclose(eq['tolerance_MPa'],row['tolerance_MPa'],abs_tol=1e-16)
        assert max(abs(a-b) for a,b in zip(eq['actions_N_Nmm'],row['forces'],strict=True))<2e-7
        assert all(abs(history[s,28][3]-p)<3e-16 for s,p in zip((0,1,-1),row['point28_plastic'],strict=True))
        confirmations.append(q)
    return history,confirmations


def verify(repo, source, temporary):
    """Сверяет итог всех вариантов и численные ограничения без вывода о разрушении."""
    tables,frames,mesh,support,equation = load(repo,temporary)
    starts = replay_native(tables,frames,mesh[1],support)
    data = json.loads(source.read_bytes())
    assert not data['physical_limit_established'] and data['source_fields']==32
    accepted={}
    for key,rows in data['routes'].items():
        _,_,q = key.split(';')
        _,accepted[key] = replay_route(starts[float(q)],rows,tables,mesh,support,equation)
    assert len(accepted)==12
    late = 'active;2e-09;72812.5'
    assert accepted[late]==[73750.,75000.,75312.5,76000.,77500.]
    assert accepted['active;8e-09;72812.5']==[73750.,75000.]
    assert not any(q for key,q in accepted.items() if key.endswith(';72812.5') and not key.startswith('active;'))
    after, _ = replay_route(starts[72812.5],data['routes'][late],tables,mesh,support,equation)
    for method,rows in data['tail'].items():
        _,accepted[method]=replay_route(after,rows,tables,mesh,support,equation)
    _,accepted['external_seed_diagnostic']=replay_route(starts[72812.5],data['external_seed_diagnostic'],tables,mesh,support,equation)
    assert accepted['none;125']==accepted['secant;125']==[77625.]
    assert not accepted['secant;250'] and accepted['external_seed_diagnostic']==[73750.,75000.,75312.5]
    expected = {'accepted_Qy_N':accepted,'physical_limit_established':False}
    return expected


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--source',type=Path,default=Path(__file__).with_name(REPLAY))
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    with TemporaryDirectory(dir=args.out.resolve().parent) as folder:
        proof=verify(args.repo,args.source,Path(folder))
    args.out.write_bytes((json.dumps(proof,indent=2,sort_keys=True)+'\n').encode())
    print('MVT2 TABULATED CONTINUATION PASS',sum(map(len,proof['accepted_Qy_N'].values())))
