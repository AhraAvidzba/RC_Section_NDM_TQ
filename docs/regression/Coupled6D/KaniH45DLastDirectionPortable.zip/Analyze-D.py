"""Resolve D's final Newton row mismatch and test the already measured shorter step."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import runpy
import numpy as np

H=Path(__file__).resolve().parent


def analyze(repo, report):
    tools=runpy.run_path(H/'Verify-Row.py')
    original=runpy.run_path(H/'AltVerifier.py')
    history,_,operator,_=original['archived_inputs'](repo)
    native,stress,tangents,fields,fractions,stations,errors=tools['parse']()
    assert not errors
    geo=history['geometry']; length=float(history['length'])
    h,sh,g,physical,area,scale=operator(geo,length)
    source=(H/'H45DiscriminatingControl.csv').read_text(encoding='ascii').strip().split(';')
    measure=np.array(source[5:],float)
    target=float(source[3])
    weight=np.array([-1.,0.,1.])[:,None]*area[None,:]*geo[None,:,1]/(length*.002)
    f=fractions['Last']; short=fractions['Plus16']
    current=stress['BASE_STRESS'][:,:,2]
    last=weight*(stress['LAST_STRESS'][:,:,2]-current)/f
    near=(stations['Plus16'][:,:,12]-stations['Minus16'][:,:,12])*weight/(2*short)
    d=native['CORRECTION'][:87]
    engineering=h@d[:79]+np.array([-.001,0.,.001])[:,None,None]*(h[:,:,:4]@d[79:83])[None]
    pred=np.zeros_like(weight)
    for i in (0,2):
        pred[i]=weight[i]*np.einsum('ni,ni->n',tangents[i],engineering[i])
    load=float(native['ROW_ACTION'][-1]*native['CORRECTION'][-1])
    near_total=float(near.sum())+load
    finite_total=float(last.sum())+load
    assert abs(finite_total-report['trueLastSecantMPa'])<2e-9
    assert abs(float(pred.sum())+load-report['tangentJvMPa'])<3e-11
    switches={}
    for key,value in stations.items():
        base=stations['Base']
        switches[key]=[(int(i),int(j)) for i,j in zip(*np.where(np.any(base[:,:,:3]!=value[:,:,:3],axis=2)))]
    assert switches['Last']==[(0,135),(2,8)] and switches['Plus4']==[(2,8)]
    assert all(not switches[k] for k in ('Base','Plus16','Minus16','Minus4'))
    ixs=switches['Last']

    def contribution(k):
        i,j=k; vals=stations['Base'][i,j]
        return {'point':j+1,'side':i-1,'baseBranch':vals[:3].astype(int).tolist(),
                'lastBranch':stations['Last'][i,j,:3].astype(int).tolist(),
                'signedLocalJvMPa':float(pred[i,j]),'shortSymmetricSecantMPa':float(near[i,j]),
                'lastFiniteSecantMPa':float(last[i,j]),'finiteMinusShortMPa':float(last[i,j]-near[i,j]),
                'effectivePredictorMPa':{n:float(s[i,j,3]) for n,s in stations.items()}}

    def full_section(key):
        q=fields[key]; s=stations[key][:,:,10:]
        lam=float(native['FAIL'][5]+fractions[key]*native['CORRECTION'][-1])
        delta=(s[2]-s[0])/.002
        weak=np.einsum('nij,ni,n->j',h,s[1],area)+g.T@q[83:]
        weak[4:]-=np.einsum('nk,na,n->ka',sh,delta[:,[4,5,2]],area).ravel()
        long=np.einsum('nij,ni,n->j',h[:,:,:4],delta,area)
        long[1]-=lam*1e5/scale[0]
        real=np.einsum('nij,nj,n->i',physical,s[1],geo[:,2])
        r=np.r_[weak,long,(real-np.r_[np.zeros(5),lam*1e5])/scale]
        q5=25600*np.r_[g@q[:79],measure@q-target]
        assert r.size==89 and q5.size==5
        j=int(np.argmax(abs(np.r_[r,q5])))
        return {'q':q.tolist(),'lambda':lam,'prescribedQy_N':lam*1e5,'integratedQy_N':float(real[-1]),
                'allSixNominalWrenches_N_Nmm':real.tolist(),'all89ForceRowsMPa':r.tolist(),'allFiveControlsMPa':q5.tolist(),
                'normMPa':float(max(max(abs(r)),max(abs(q5)))),'governingAmong89Plus5':j+1,'row81MPa':float(r[80])}

    states={k:full_section(k) for k in stations}
    before=states['Base']['normMPa']
    after=states['Plus16']['normMPa']
    lastnorm=states['Last']['normMPa']
    gate=before*(1-1e-4*short)
    assert after<gate<before and short==1/2048
    assert abs(before-7.50970458613335e-5)<2e-10 and abs(lastnorm-8.54070691728986e-5)<2e-10
    assert states['Base']['governingAmong89Plus5']==states['Plus16']['governingAmong89Plus5']==94
    assert states['Last']['governingAmong89Plus5']==81
    tolerance=report['toleranceProof']['originalH45TauMPa']
    assert after>tolerance
    finite_growth=finite_total-near_total
    switched_sum=float(sum(last[k]-near[k] for k in ixs))
    out={'originalReferenceToleranceMPa':tolerance,'shortFraction':short,'stockMinimumFraction':f,
         'installedJvMPa':report['tangentJvMPa'],'signedSmallSecantsMPa':[report['pairSecants'][k]['signedSecantMPa'] for k in ('Plus16','Minus16')],
         'nearSymmetricSecantMPa':near_total,'localTangentErrorMPa':near_total-report['tangentJvMPa'],
         'finiteLastSecantMPa':finite_total,'finiteMinusSmallSecantMPa':finite_growth,
         'actualSwitches':{k:[(int(i-1),int(j+1)) for i,j in rows] for k,rows in switches.items()},
         'actualSwitchStationContributions':list(map(contribution,ixs)),
         'actualSwitchesFractionOfFiniteGrowth':switched_sum/finite_growth,
         'otherStationsFiniteGrowthMPa':finite_growth-switched_sum,
         'independentSectionStates':states,
         'shortMeritDecreaseMPa':before-after,'stockProgressRequiredAtShortFractionMPa':before-gate,
         'shortQyMultiplierIncrease_N':states['Plus16']['prescribedQy_N']-states['Base']['prescribedQy_N'],
         'shortStillAboveOriginalTolerance':True}
    saved=H/'D-DampingAssessment.json'
    saved.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n',encoding='utf8')
    data=states['Plus16']
    fields_out=H/'ShortDampingWitness.csv'
    fields_out.write_bytes(('KANI_D_DAMPING;Plus16;'+ ';'.join(format(f,'.17g') for f in [short,data['lambda'],*data['q']])+'\r\n').encode('ascii'))
    print(saved,sha256(saved.read_bytes()).hexdigest().upper(),fields_out,sha256(fields_out.read_bytes()).hexdigest().upper())
    return out


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    analyze(a.repo_root.resolve(),json.loads((H/'D-RowVerification.json').read_text(encoding='utf8')))
