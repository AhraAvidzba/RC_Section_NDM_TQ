"""Rebuild the D diagnostic on the exact new Newton direction."""
from argparse import ArgumentParser
from pathlib import Path
import json
import runpy

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')


def once(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)


def verify(repo):
    P['check'](repo)
    x=json.loads((H/'Expected-SectionComparison.json').read_text())
    expected=x['variants']['D']['rightResult']
    e=expected['newtonDiagnostics']
    f=H/'Verify-Row.py'
    s=f.read_text(encoding='utf-8-sig')
    s=once(s,"['CCoupledNewtonSolver','modTestKaniStage38']",
           "['CCoupledConcreteResponse','CCoupledNewtonSolver','modTestKaniStage38']")
    s=once(s,"and its==5 and evals==32 ","and its==E['iterations'] and evals==E['evaluations'] ")
    s=once(s,"assert 8.44e-5<best<8.45e-5 and 8.24e-5<norm<8.25e-5",
           "assert abs(best-E['bestDampedTrialMPa'])<1e-13 and abs(norm-E['beforeDampingMPa'])<1e-13")
    s=once(s,"assert abs(jv+8.24294736431007e-5)<2e-12 and abs(delta_f-2.52677511992814e-4)<2e-10",
           "assert abs(jv-E['tangentPredictedMPa'])<2e-12 and abs(delta_f-E['actualPerUnitDampingMPa'])<2e-10")
    s=once(s,"assert tau==base_receipt['originalH45Tau_MPa']",
        "assert abs(tau-(5e-7+2e-8*abs(base_lambda)*1e5/build(history['geometry'],float(history['length']))[-1][0]))<2e-20")
    n={'__name__':'D_direction_verifier','__file__':str(f),'E':e}
    exec(compile(s,str(f),'exec'),n)
    n['P']['check']=P['check']
    report=n['verify'](repo)
    assert report['fraction']==1/128 and report['exactH45Restored']
    a=json.loads((H/'AlternateVerification.json').read_text(encoding='utf8'))
    assert a['rightShoulder']==expected['status'],(a['rightShoulder'],expected['status'])
    previous=x['variants']['D']['fullEvidence']['comparison89PlusFive']
    assert previous==a['comparison89PlusFive']
    fail=n['parse']()[0]['FAIL']
    history,_,build,_=runpy.run_path(H/'AltVerifier.py')['archived_inputs'](repo)
    area=float(build(history['geometry'],float(history['length']))[-1][0])
    formula=lambda lam:5e-7+2e-8*abs(lam)*1e5/area
    h=a['comparison89PlusFive']['Base45']
    assert abs(formula(h['lambda'])-x['variants']['D']['fullEvidence']['originalH45Tau_MPa'])<2e-20
    post={**report,'toleranceProof':{'committedH45Lambda':h['lambda'],'originalH45TauMPa':h['originalToleranceRule_MPa'],
          'newtonBaseLambda':float(fail[5]),'nativeNewtonBaseTauMPa':float(fail[3]),
          'replayNewtonBaseTauMPa':formula(fail[5]),'lastTrialLambda':float(fail[6]),
          'replayLastTrialTauMPa':formula(fail[6]),'configuredAbsoluteMPa':5e-7,'configuredRelative':2e-8,
          'fixedAreaMM2':area,'reclassifiesRejectedTrial':False}}
    for tag,expected_norm in (('Base',e['beforeDampingMPa']),('Last',e['lastNormMPa'])):
        r=post['all89ForceRowsMPa'][tag]; k=post['all5ControlsMPa'][tag]
        norm=max(max(map(abs,r)),max(map(abs,k)))
        assert abs(norm-expected_norm)<2e-10 and norm>h['originalToleranceRule_MPa']
    saved=H/'D-RowVerification.json'
    saved.write_text(json.dumps(post,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(saved,P['sha'](saved))
    return post


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    verify(a.repo_root.resolve())
