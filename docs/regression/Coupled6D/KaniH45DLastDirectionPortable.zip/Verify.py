"""Rebuild the D diagnostic on the exact new Newton direction."""
from argparse import ArgumentParser
from pathlib import Path
import json
import runpy

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')


def once(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)


def verify(repo):
    P['check'](repo)
    x=json.loads((H/'Expected-SectionComparison.json').read_text())
    expected=x['variants']['D']['rightResult']
    e=expected['newtonDiagnostics']
    f=H/'Verify-Row.py'
    s=f.read_text(encoding='utf-8-sig')
    s=once(s,"['CCoupledNewtonSolver','modTestKaniStage38']",
           "['CCoupledConcreteResponse','CCoupledNewtonSolver','modTestKaniStage38']")
    s=once(s,"and its==5 and evals==32 ","and its==E['iterations'] and evals==E['evaluations'] ")
    s=once(s,"assert 8.44e-5<best<8.45e-5 and 8.24e-5<norm<8.25e-5",
           "assert abs(best-E['bestDampedTrialMPa'])<1e-13 and abs(norm-E['beforeDampingMPa'])<1e-13")
    s=once(s,"assert abs(jv+8.24294736431007e-5)<2e-12 and abs(delta_f-2.52677511992814e-4)<2e-10",
           "assert abs(jv-E['tangentPredictedMPa'])<2e-12 and abs(delta_f-E['actualPerUnitDampingMPa'])<2e-10")
    n={'__name__':'D_direction_verifier','__file__':str(f),'E':e}
    exec(compile(s,str(f),'exec'),n)
    n['P']['check']=P['check']
    report=n['verify'](repo)
    assert report['fraction']==1/128 and report['exactH45Restored']
    a=json.loads((H/'AlternateVerification.json').read_text(encoding='utf8'))
    assert a['rightShoulder']==expected['status'],(a['rightShoulder'],expected['status'])
    previous=x['variants']['D']['fullEvidence']['comparison89PlusFive']
    assert previous==a['comparison89PlusFive']
    return report


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    verify(a.repo_root.resolve())
