"""Seal one D-arm native capture using the now established section D and the existing §359 probes."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import runpy
import subprocess

H=Path(__file__).resolve().parent
ART='docs/regression/Coupled6D'
TIP='6d42af5'
BOOK='workbook/output/RC_Section_NDM.xlsm'
DRAFT='docs/regression/Diagnostic.xlsm'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'
MATERIAL='src/Materials/CCoupledConcreteResponse.cls'
MACRO='tests/modTestKaniStage38.bas'
DAMAGE='A8C4F9664F300A344C6047553D55FD9E589F3BB0ECEA3371BE1EAA4EDC22837B'
INSTALLED='475E57DE58848B3F83DA8C79B1A10EC05B3726CC52B0C904E5B975F4CFBDFB18'
ROW='KaniH45Row81DirectionPortable.zip'
ROW_SHA='4B65725C0977E6855720BFBD0F9CA7D5D3FCF0AD3F4C1C0A8FA68F73DECDA701'
OLD='KaniH45AlternateControlPortable.zip'
OLD_SHA='4A9CADBD73726D133E99B5EA1D58F1DB8DB574C45BC189470F8EEC856C911BD4'
PAIR='KaniH45ElasticDamageSectionPortable.zip'
PAIR_SHA='E4F57928BA1FEAA08E737642FB340F2B9A547B7A938A9D59FD60013B52911C51'
EXPECTED='E8CEBDDDAABD5437CF386FE5A4024A57E8A736C400C4A94CB2E2179EC87A26BC'


def sha(x):
    b=x.read_bytes() if isinstance(x,Path) else x
    return sha256(b).hexdigest().upper()


def blob(repo,n):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',f'{TIP}:{n}'])


def put(n,data):
    path=H/n
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
    return sha(data)


def check(repo):
    m=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert m['bookSHA256']==INSTALLED==sha(blob(repo,BOOK))==sha(H/BOOK)
    assert m['candidateMaterialSHA256']==sha(H/MATERIAL)==DAMAGE
    assert sha(H/'Expected-SectionComparison.json')==EXPECTED
    assert all(sha(repo/ART/n)==v for n,v in m['inputZIP_SHA256'].items())
    assert all(sha(H/n)==v for n,v in m['frozen'].items())
    assert {x.stem for d in ('src','tests') for x in (H/d).rglob('*') if x.is_file()}==set(m['modules'])
    return m


def stage(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    assert not (H/'Preparation.json').exists()
    freeze={}
    pair=repo/ART/PAIR
    if not pair.exists():
        pair=H.parent/'ksec'/'Portable'/PAIR
    assert sha(pair)==PAIR_SHA
    assert sha(repo/ART/ROW)==ROW_SHA and sha(repo/ART/OLD)==OLD_SHA
    with ZipFile(pair) as p,ZipFile(repo/ART/ROW) as r,ZipFile(repo/ART/OLD) as a:
        section=p.read('SectionComparison.json')
        assert sha(section)==EXPECTED
        arms=json.loads(section)['variants']
        assert arms['D']['rightResult']['newtonDiagnostics']['evaluations']==41
        assert not arms['D']['rightResult']['rightConverged']
        freeze['Expected-SectionComparison.json']=put('Expected-SectionComparison.json',section)
        native_inputs=json.loads(p.read('Preparation.json'))['frozen']
        support=json.loads(a.read('Preparation.json'))['inputZIP_SHA256']
        for f in ('Prepare-Row.py','SolverRowProbe.bas.txt','MacroRowProbe.bas.txt','Verify-Row.py'):
            freeze[f]=put(f,r.read(f))
        api=runpy.run_path(H/'Prepare-Row.py')
        data={n:a.read(n) for n in ('KaniV4Input.csv','KaniGaugeInput.csv','H45DiscriminatingControl.csv',
                                   'DiscriminatingH45Measurement.json','Prepare-Alt.py')}
        data['AltVerifier.py']=a.read('Verify-Alt.py')
        for n in list(data)[:4]:
            assert data[n]==p.read('D/'+n)==r.read(n)
        for n in native_inputs:
            if n.startswith('D/tools/'):
                sub=n[2:]
                raw=(repo/sub).read_bytes()
                assert sha(raw)==native_inputs[n] and raw.replace(b'\r\n',b'\n')==blob(repo,sub).replace(b'\r\n',b'\n')
                data[sub]=raw
        data[MATERIAL]=p.read('D/'+MATERIAL)
        assert sha(data[MATERIAL])==DAMAGE
        data[SOLVER]=api['instrument_solver'](blob(repo,SOLVER))
        data[MACRO]=api['instrument_macro'](a.read(MACRO))
        workbook=blob(repo,BOOK)
        assert sha(workbook)==INSTALLED
        data[BOOK]=workbook
        for n,value in data.items():
            freeze[n]=put(n,value)
        put(DRAFT,workbook)
    for n in ('Native','Temp'):
        (H/n).mkdir(exist_ok=True)
    for n in ('Prepare.py','Run.ps1','Verify.py','README.md'):
        freeze[n]=sha(H/n)
    m={'sourceGit':TIP,'bookSHA256':INSTALLED,'candidateMaterialSHA256':DAMAGE,'pairedResultSHA256':EXPECTED,
       'pairedArchiveSHA256':PAIR_SHA,'originalTauMPa':5.59190995944018e-7,
       'inputZIP_SHA256':{ROW:ROW_SHA,OLD:OLD_SHA,**support},
       'modules':['CCoupledConcreteResponse','CCoupledNewtonSolver','modTestKaniStage38'],
       'frozen':dict(sorted(freeze.items()))}
    put('Preparation.json',(json.dumps(m,indent=2)+'\n').encode())
    return check(repo)


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    p.add_argument('--check',action='store_true')
    a=p.parse_args()
    (check if a.check else stage)(a.repo_root.resolve())
    print('D_DIRECTION_SEALED',sha(H/'Preparation.json'))
