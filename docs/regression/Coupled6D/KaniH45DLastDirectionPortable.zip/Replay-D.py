"""Detached independent D-direction replay from immutable artifacts and historical Git."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import runpy

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')


def digest(x):
    return sha256(x.read_bytes() if isinstance(x,Path) else x).hexdigest().upper()


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def once(s,p,t):
    assert s.count(p)==1,p
    return s.replace(p,t)


def validator(repo):
    prep=read(H/'Preparation.json')
    m=read(H/'Manifest.json')
    assert m['schema']=='KaniH45FinalDirectionD/v1'
    assert all(digest(H/n)==d for n,d in m['files'].items())
    assert prep['bookSHA256']==digest(P['blob'](repo,P['BOOK']))==m['bookSHA256']
    assert prep['candidateMaterialSHA256']==m['candidateMaterialSHA256']==digest(H/P['MATERIAL'])
    assert prep['pairedResultSHA256']==digest(H/'Expected-SectionComparison.json')
    for n,d in prep['frozen'].items():
        assert (prep['bookSHA256'] if n==P['BOOK'] else m['files'][n])==d
    for n,d in prep['inputZIP_SHA256'].items():
        assert digest(repo/P['ART']/n)==d
    compiled=read(H/'docs/regression/CodeUpdate.json')
    opened=read(H/'Native/KaniV4.txt.Ownership.json')
    assert compiled['WorkbookSHA256']==opened['SourceSHA256']==m['compiledPrivateBookSHA256']
    return prep


def portable_nested(g):
    locate="    exec(compile(source,str(f),'exec'),ns)"
    return once(g,locate,"    source=receipt_without_workbook(source)\n"+locate)


def receipt_without_workbook(s):
    at="    assert book['WorkbookSHA256'] == P['sha'](H / P['draft']) == own['SourceSHA256']"
    replace="""    assert book['WorkbookSHA256'] == own['SourceSHA256']
    if (H / P['draft']).exists():
        assert book['WorkbookSHA256'] == P['sha'](H / P['draft'])"""
    return once(s,at,replace)


def replay(repo):
    m=validator(repo)
    outputs=('D-RowVerification.json','D-DampingAssessment.json','ShortDampingWitness.csv')
    expected={n:digest(H/n) for n in outputs}
    f=H/'Verify-Checked.py'
    script=f.read_text(encoding='utf-8-sig')
    at="    n={'__name__':'D_direction_verifier','__file__':str(f),'E':e}"
    script=once(script,at,"    s=portable_nested(s)\n"+at[:-1]+",'receipt_without_workbook':receipt_without_workbook}")
    g={'__file__':str(f),'__name__':'portable_D','portable_nested':portable_nested,
       'receipt_without_workbook':receipt_without_workbook}
    exec(compile(script,str(f),'exec'),g)
    g['P']['check']=lambda _:m
    result=g['verify'](repo)
    stats=runpy.run_path(H/'Analyze-D.py')['analyze'](repo,result)
    assert all(digest(H/n)==value for n,value in expected.items())
    print('D_DIRECTION_REPLAY_PASS',digest(H/'D-RowVerification.json'),digest(H/'D-DampingAssessment.json'))
    return stats


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    replay(a.repo_root.resolve())
