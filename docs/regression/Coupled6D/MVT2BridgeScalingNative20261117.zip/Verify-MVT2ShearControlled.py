"""Check the two history-derived metric rules and the same original fixed residual."""
import argparse
from collections import defaultdict
from math import hypot
import json
from pathlib import Path
from statistics import median

import OwnBase as own
from OwnBase import prior, v

HERE=Path(__file__).resolve().parent


def prepare():
    setup=own.prepare()
    frozen,_stock,p_fixed,target=setup
    _,prefix,base24,_,witnesses,*_=frozen
    endpoints=prefix[-2:]+[(prior.numbers(row[1:61]),float(row[0])) for row in witnesses]
    geometry=base24["geometry"]
    slopes=[]
    for prev,new in zip(endpoints[:-1],endpoints[1:],strict=True):
        assert new[1]>prev[1]
        slopes.append(hypot(*prior.station_metric(v.diff(new[0],prev[0]),geometry))/(new[1]-prev[1]))
    h25,h26=endpoints[-2:]
    span=v.dot(p_fixed,v.diff(h26[0],h25[0]))
    ratio=.5*min(1.,(target-v.dot(p_fixed,h26[0]))/span)
    assert span>0 and ratio>0
    return setup,slopes,span,ratio,h25,h26,geometry


def verify(setup,slopes,span,ratio,h25,h26,geometry):
    stock=own.verify(*setup)
    assert len(stock["trials"])==1 and not stock["trials"][0]["returned_trial"]
    raw=v.read_native(own.NATIVE)
    snapshots=prior.by_name(raw,"B_ARC_HISTORY")
    [[*rule,reported_span,reported_ratio]]=map(prior.numbers,raw["B_SCALE_RULE"])
    assert v.peak(v.diff(rule,slopes))<3e-17
    v.near(reported_span,span,2e-15)
    v.near(reported_ratio,ratio,2e-8)
    plans=prior.by_name(raw,"B_SCALE_PLAN")
    assert tuple(plans)==("Local","Median")
    normals=v.vec(raw,"B_SCALE_VECTOR")
    statuses=prior.by_name(raw,"B_BRIDGE_SOLVER")
    gates=prior.by_name(raw,"B_BRIDGE_GATE")
    forces=prior.by_name(raw,"B_BRIDGE_ACTUAL")
    rows=v.vec(raw,"B_TANGENT_RESIDUAL")
    points=defaultdict(dict)
    for tag,ip,side,*station in raw["B_TANGENT_STATION"]:
        if tag.startswith("Bridge"):
            points[tag][int(ip),int(side)]=prior.numbers(station)
    fields=prior.by_name(raw,"B_TANGENT_FIELD")
    mark=prior.by_name(raw,"B_SCALE_END")
    reference=v.read(HERE/"BranchWitness.json")["fixed"]["fingerprint"]
    _frozen,_stock,p_fixed,target=setup
    arms=[]
    for mode,planned_scale in zip(plans,(slopes[-1],median(slopes)),strict=True):
        for stage in ("Before","AfterArc","AfterFixed"):
            assert snapshots["Scale"+stage+mode]==snapshots["CommittedAttempt2"]
        scale,ds,k,ell,c0,forecast,used,remaining=prior.numbers(plans[mode])
        assert used==stock["trials"][0]["iterations"]==15 and used+remaining==26
        v.near(scale,planned_scale,3e-17)
        p,k_ref,length=prior.determine_normal(h26,h25,geometry,scale)
        v.near(k,k_ref,2e-15)
        v.near(ell,length,2e-17)
        v.near(ds,reported_ratio*length,2e-17)
        v.near(c0,v.dot(p,h26[0])+k*h26[1]+ds,4e-15)
        v.near(forecast,h26[1]+reported_ratio*(h26[1]-h25[1]),2e-12)
        assert normals[mode+"Normal"][-4:]==(0.,)*4 and v.peak(v.diff(normals[mode+"Normal"],p))<2e-12
        expected=tuple(a+reported_ratio*(a-b) if i<56 else a for i,(a,b) in enumerate(zip(h26[0],h25[0],strict=True)))
        assert v.peak(v.diff(expected,normals[mode+"Prediction"]))<2e-15
        branch=[]
        eligible=False
        for kind in ("Arc","Fixed"):
            slot=mode+kind
            if kind=="Fixed" and not eligible:
                assert slot not in statuses
                continue
            solved,status,code,iterations,cap,seconds,*diagnostic=statuses[slot]
            assert solved in ("0","1") and int(cap)==remaining and 0<=int(iterations)<=remaining
            remaining-=int(iterations)
            item={"mode":kind,"returned_trial":solved=="1","internal_status":int(status),"result_code":int(code),
                  "iterations":int(iterations),"allowed":int(cap),"seconds":float(seconds),"diagnostic":";".join(diagnostic)}
            if solved=="0":
                assert slot not in gates and slot not in forces
                branch.append(item)
                continue
            assert [status,code]==["4","0"]
            factor,solver_norm,tol,direction,extent,control=prior.numbers(gates[slot])
            key="Bridge"+slot
            count,stored,*q_field=fields[key]
            field=prior.numbers(q_field)
            assert count=="26" and float(stored)==factor
            assert geometry=={loc:data[:3] for loc,data in points[key].items()}
            diff=v.diff(field,h26[0]);dlam=factor-h26[1]
            length_total=hypot(*prior.station_metric(diff,geometry),scale*dlam)
            signed=v.dot(p,diff)+k*dlam
            v.near(length_total,extent,4e-15)
            v.near(signed,direction,4e-15)
            residual,actual,strain_error=v.reconstruct(field,factor,points[key])
            assert strain_error<4e-15 and v.peak(v.diff(residual,rows[key]))<3e-10
            assert len(forces[slot])==6 and v.peak(f/s for f,s in zip(v.diff(actual,prior.numbers(forces[slot])),v.SCALES,strict=True))<4e-12
            effort=v.diff(actual,v.force(factor))
            gauges=tuple(x*v.MODULUS for x in residual[56:])
            norm=max(v.peak(residual[:56]),v.peak(gauges),v.peak(x/s for x,s in zip(effort,v.SCALES,strict=True)))
            v.near(solver_norm,norm,4e-10)
            v.near(tol,5e-7*(1+v.peak(v.loading(factor))),2e-18)
            if kind=="Arc":
                v.near(control,(signed-ds)*v.MODULUS,3e-10)
                eligible=norm<=tol and abs((signed-ds)*v.MODULUS)<=tol and signed>0. and length_total<=3.*ds and remaining>0
            else:
                v.near(control,(v.dot(p_fixed,field)-target)*v.MODULUS,3e-10)
                assert abs(control)<=tol and norm<=tol
            fingerprint=[[ip,side,*map(int,state[3:6]),state[6]>=0.] for (ip,side),state in points[key].items() if ip<=25]
            differences=[current[:2] for current,before in zip(fingerprint,reference,strict=True) if current!=before]
            item.update({"Qy_kN":factor,"signed_resultant_errors_N_Nmm":effort,"weak56_MPa":residual[:56],"gauges4_MPa":gauges,
                         "original_residual_over_tau":norm/tol,"control_error_MPa":control,"signed_physical_advance":signed,
                         "physical_arc_length_over_nominal":length_total/ds,"concrete_fingerprint_differences_to_reference_fixed":differences})
            branch.append(item)
        assert mark[mode]==[str(int(eligible))]
        arms.append({"rule":mode,"load_metric_scale":scale,"projected_step":ds,"remaining_iterations":int(remaining),"trials":branch})
    return {"native_trace_sha256":stock["native_trace_sha256"],"same_original_fixed_failure":True,"original_fixed_target":stock["fixed_target"],
            "previous_accepted_scale_ratios":slopes,"relative_arc_length":reported_ratio,"max_iterations_each":26,
            "H26_exact_rollback":True,"H24_exact_restore":True,"physical_capacity_established":False,"tests":arms,
            "compiler_closed":stock["compiler_closed"],"office_closed":stock["office_closed"]}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--phase",choices=["Resume"])
    args=parser.parse_args()
    inputs=prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
        print("PREVIOUS SCALES",inputs[1],"STEP RATIO",inputs[3])
    else:
        assert args.phase=="Resume"
        out=HERE/"VerificationBridgeScaling.json"
        out.write_bytes((json.dumps(verify(*inputs),indent=2)+"\n").encode())
        print(out,v.digest(out))
