# MVT2 fixed-control bridge metric comparison

The native fixture replayed accepted H24, H25 and H26 in the isolated `2ACFC025…` workbook, then compared two choices of the load coordinate in a short uncommitted pseudo-arclength guide. The original fixed-control check used the original physical law, target and tolerance. Each arm had 26 iterations, including the original 15-iteration failing attempt. The four gauge coordinates had no weight in the normalization. This packet preserves the native stream, original verifier and failure, compiler ownership, closure receipts and all frozen sources. Workbook bytes are omitted. This is a numerical method comparison on the stated historical workbook.

```powershell
python -B -X utf8 ReplayBridgeScaling.py MVT2BridgeScalingNative20261117.zip
```

The replay first verifies the manifest and compile/run ownership. It recalculates both scaled normals and every equilibrium criterion, then checks the resulting report against the packet's report byte for byte. For Local, the original fixed `3e-17` comparison of scales was narrower than the uncertainty from subtracting serialized 15-significant-digit H26 and H25 fields and factors. The detached reproduction bounds that uncertainty through the physical tensor operator and the positive denominator, independently reconstructs the common unrounded strain and load increments from both actual affine planes, and retains the original tolerance on their actual intercept when computed with the emitted normals. The structural residual and original fixed control thresholds retain their initial values. Python uses only its standard library.

Local returned `NumFail`. Median returned a verified affine-plane field and then reached the original fixed target. Both arms restored the exact accepted H26 field and station history, and the fixture restored H24. The result does not estimate a physical capacity or certify the current installed workbook.
