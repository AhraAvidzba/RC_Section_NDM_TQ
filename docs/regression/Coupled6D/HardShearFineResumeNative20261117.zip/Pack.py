"""Собирает архив нативного продолжения HardShear и проверяет его после распаковки."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from subprocess import PIPE, run
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1] / "docs/regression/Coupled6D/HardShearNestedQuadratureNative20261117.zip"
BASE_HASH = "51EDBA769818A13DFF49853471B51904BC834D2D1F15EBE011807D4DAF6F88FC"
NAME = "HardShearFineResumeNative20261117"


def sha(raw):
    return sha256(raw).hexdigest().upper()


def collect(source, earlier):
    primary = ["Fixture.json", "Compile.log", "CompileClosure.json", "docs/regression/CodeUpdate.json", "Run.ndjson"]
    plan = json.loads((source / "Fixture.json").read_bytes())
    primary += list(plan["inputs"])
    primary += ["Native/Order10/" + p for p in ("Verification.json", "HardFineResume.csv", "HardShear.txt",
                  "HardShear.txt.Ownership.json", "HardShear.txt.ProcessClosure.json", "HardShear.txt.RunnerCleanup.json",
                  "HardShear.txt.memory.json", "HardShear.txt.stderr.log", "HardShear.txt.stdout.log")]
    assert len(primary) == len(set(primary))
    files = {p: (source / p).read_bytes() for p in primary}
    assert all(sha(files[p]) == value for p,value in plan["inputs"].items())
    for path in ("Compile.log", "Run.ndjson", "Fixture.json", "tests/modTestCoupledElasticState.bas"):
        files["BeforeSyntaxCorrection/" + path] = (earlier / path).read_bytes()
    for path in ("Analyze.py", "Verify-Portable.py", "README-Portable.md", "Pack.py"):
        files[path] = (HERE / path).read_bytes()
    assert sha(BASE.read_bytes()) == BASE_HASH
    with ZipFile(BASE) as archive:
        for path, expected in plan["production"].items():
            name = "Production/" + path
            files[name] = archive.read(name)
            assert sha(files[name]) == expected
    manifest = {path: sha(raw) for path, raw in files.items()}
    files["SHA256SUMS.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")
    return files


def zip_write(path, data):
    with ZipFile(path, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(data.items()):
            entry = ZipInfo(name, date_time=(2026, 11, 17, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)


def seal(path, data):
    if path.exists():
        assert path.read_bytes() == data
    else:
        path.write_bytes(data)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("final", type=Path)
    cli.add_argument("earlier", type=Path)
    args = cli.parse_args()
    data = collect(args.final.resolve(), args.earlier.resolve())
    target = HERE / "proof"
    target.mkdir(exist_ok=True)
    output = target / (NAME + ".zip")
    with TemporaryDirectory(prefix="replay-", dir=target) as temporary:
        staging = Path(temporary)
        compressed = staging / "candidate.zip"
        zip_write(compressed, data)
        with ZipFile(compressed) as archive:
            archive.extractall(staging / "extracted")
        report = run([sys.executable, "-B", "-X", "utf8", "Verify-Portable.py"], cwd=staging / "extracted", stdout=PIPE, check=True).stdout
        fingerprint = sha(compressed.read_bytes())
        seal(output, compressed.read_bytes())
        seal(target / (NAME + ".replay.txt"), report)
        seal(target / (NAME + ".zip.sha256"), f"{fingerprint} *{output.name}\n".encode("ascii"))
    print(output, fingerprint)
    print(report.decode("utf-8").splitlines()[-1])


if __name__ == "__main__":
    main()
