"""Повторяет приёмку переносимого нативного отчёта без Excel и Git."""

import json
from pathlib import Path
from subprocess import PIPE, run
import sys

import Analyze as analysis
import PriorVerify as io


HERE = Path(__file__).resolve().parent
REPORT = "94A3EAD5FDF54784BF7915BB7A16040A5A8A671681CB1E379FCDA5AF138E6BC0"
COMPILED = "DDBC26F2400F6A0996C8BB82B41717266190087C19233C3D81F50A22D0B0F5E3"


def verify_initial_failure(plan):
    earlier = HERE / "BeforeSyntaxCorrection"
    try_plan = io.read(earlier / "Fixture.json")
    report = (earlier / "Compile.log").read_text(encoding="utf-8-sig")
    assert "COMPILE_LOCATION: module=modTestCoupledElasticState; line=5059; column=1" in report
    assert "offset, direction\nEnd Function" in report
    assert try_plan["source_workbook_sha256"] == plan["source_workbook_sha256"]
    old_test = earlier / "tests/modTestCoupledElasticState.bas"
    assert io.file_hash(old_test) == try_plan["inputs"]["tests/modTestCoupledElasticState.bas"]
    assert try_plan["inputs"]["src/Solver/CCoupledNewtonSolver.cls"] == plan["inputs"]["src/Solver/CCoupledNewtonSolver.cls"]


def main():
    sums = io.read(HERE / "SHA256SUMS.json")
    files = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file()}
    assert files == set(sums) | {"SHA256SUMS.json"}
    for path, expected in sums.items():
        assert not path.lower().endswith(".xlsm") and io.file_hash(HERE / path) == expected, path
    plan = io.read(HERE / "Fixture.json")
    for path, expected in plan["production"].items():
        assert io.file_hash(HERE / "Production" / path) == expected
    verify_initial_failure(plan)
    lane = HERE / "Native/Order10"
    assert io.file_hash(lane / "Verification.json") == REPORT
    terminal = io.read(lane / "HardShear.txt.ProcessClosure.json")
    assert terminal["Passed"] and terminal["ChildExitCode"] == 0 and not terminal["OrdinaryPathKilledAnything"]
    assert terminal["Closure"]["FinalState"]["State"] == "Absent"
    assert io.read(lane / "Verification.json")["proof"]["compiled_workbook_sha256"] == COMPILED
    replay = run([sys.executable, "-B", "-X", "utf8", "Verify.py", "--order", "10"], cwd=HERE, stdout=PIPE, check=True)
    print(replay.stdout.decode("utf-8").strip())
    print(json.dumps(analysis.summarize(), indent=2, ensure_ascii=False))
    print("HARDSHEAR_FINE_RESUME_PORTABLE: VERIFIED_EVIDENCE; PROBE_LIMIT; physical_limit_certified=False")


if __name__ == "__main__":
    main()
