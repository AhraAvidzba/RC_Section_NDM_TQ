# Компилирует и запускает проверку в разных процессах оператора.
param(
    [ValidateSet('Inputs','Compile','Native')]
    [string]$Phase='Inputs',
    [ValidateSet(10)][int]$Order=10
)

$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../..')).Path
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$nativeDir="Native/Order$Order"
$report="$nativeDir/HardShear.txt"
$modules=@('CCoupledSectionAnalysis','CCoupledNewtonSolver','CCoupledReinforcedResponse','modTestCoupledElasticState')
Push-Location -LiteralPath $root
try {
    python -B -X utf8 'Verify.py' --inputs
    if ($LASTEXITCODE) {throw 'Входы проверки не подтверждены.'}
    if ($Phase -eq 'Inputs') {return}
    $data=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Превышена длина пути фикстуры Excel.'
    }
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    if ($Phase -eq 'Compile') {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Test-Path -LiteralPath $report) -or
            (Get-FileHash -LiteralPath $draft).Hash -cne $data.source_workbook_sha256) {
            throw 'Для компиляции нужна новая изолированная книга.'
        }
        Assert-IsolatedOfficeReady 'CompileHardFineResume'
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft `
            -ModuleNames $modules | Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
        return
    }
    $code=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closed=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    $compileLog=@(Get-Content -LiteralPath 'Compile.log' -Encoding utf8)
    if (!$code.Compiled -or $code.ProductionChanged -or $code.ProductionSHA256 -cne $data.source_workbook_sha256 -or
        $code.Workbook -ine (Resolve-Path -LiteralPath $draft).Path -or
        $code.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash -or
        @($code.Modules).Count -ne $modules.Count -or
        ((@($code.Modules) | Sort-Object -CaseSensitive) -join ',') -cne (($modules | Sort-Object -CaseSensitive) -join ',') -or $code.RetiredModules.Count -or $code.EntryPointNames.Count -or
        $code.TraceGeometry -or $closed.State -cne 'Absent' -or
        @($compileLog | Where-Object {$_ -ceq "OWNED_EXCEL: id=$($closed.PID); utcStartTicks=$($closed.StartTicksUTC)"}).Count -ne 1 -or
        $compileLog[-1] -cne 'PRIVATE_CODE_READY: modules=4; production unchanged=True') {
        throw 'Протокол компиляции не соответствует подготовленной книге.'
    }
    $worker=Get-Process -Id $closed.PID -ErrorAction SilentlyContinue
    if ($worker -and $worker.StartTime.ToUniversalTime().Ticks -eq [long]$closed.StartTicksUTC) {throw 'Процесс компиляции ещё видим.'}
    if (@(Get-ChildItem -LiteralPath $nativeDir -Force).Count) {
        throw 'Есть результаты предыдущего нативного запуска.'
    }
    Assert-IsolatedOfficeReady 'RunHardFineResume'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $draft -ReportPath $report -Macro 'modTestCoupledElasticState.RunTestHardShearYieldGate' `
        -MacroArgument1 ([string]$Order) -Mode No -TimeoutSeconds $data.watchdog_seconds -FailFast -VerifyResultsReopen
    $nativeExit=$LASTEXITCODE
    if (Test-Path -LiteralPath $report) {
        $origin=@(Get-Content -LiteralPath $report -Encoding utf8 | Where-Object {$_ -like 'FIXTURE: *'})
        if ($origin.Count -eq 1) {
            $folder=Split-Path -Parent $origin[0].Substring('FIXTURE: '.Length)
            if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Нативная фикстура за рабочим каталогом.'}
            $trace=Join-Path $folder 'HardFineResume.csv'
            if (Test-Path -LiteralPath $trace) {Copy-Item -LiteralPath $trace -Destination (Join-Path $nativeDir "HardFineResume.csv")}
        }
    }
    if ($nativeExit) {throw "Нативная проверка переключения завершилась с кодом $nativeExit."}
    python -B -X utf8 'Verify.py' --order $Order
    if ($LASTEXITCODE) {throw 'Независимая сверка не пройдена.'}
} finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}
