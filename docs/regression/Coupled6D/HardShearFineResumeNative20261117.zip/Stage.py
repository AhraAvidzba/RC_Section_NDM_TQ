"""Собирает диагностическое продолжение HardShear от принятого поля I6."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ARCHIVE = REPO / "docs/regression/Coupled6D/HardShearNestedQuadratureNative20261117.zip"
ARCHIVE_HASH = "51EDBA769818A13DFF49853471B51904BC834D2D1F15EBE011807D4DAF6F88FC"
WORKBOOK_HASH = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
NATIVE_HASH = "6034B23C90FD8736860EB84643061177E940A25E4E668599F98CE31AE975F2D3"
MESH_COMPILED_HASH = "4F428EA58D1C62D31B07A6C112EF12D626F76D51475E742413BA343638AF7E9E"
SOLVER = "src/Solver/CCoupledNewtonSolver.cls"
TESTS = "tests/modTestCoupledElasticState.bas"
PREFIX = ("P1", "P2", "P3", "P4", "P5", "I6")
FIELDS = ("FIELD", "TARGET", "ACTUAL", "RESIDUAL", "BALANCE")


def digest(raw):
    return sha256(raw).hexdigest().upper()


def code(raw):
    return raw.decode("utf-8-sig").replace("\r\n", "\n")


def vba(source):
    assert max(map(len, source.splitlines())) < 1024
    return (source.rstrip().replace("\n", "\r\n") + "\r\n").encode("utf-8")


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def seal(destination, path, raw):
    target = destination / path
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, path
    else:
        target.write_bytes(raw)
    return digest(raw)


def history(raw):
    data, found = {}, []
    active = None
    lines = raw.decode("cp1251").splitlines()
    assert lines[0] == "HARDSHEAR-MESH-GATE;1;10"
    for line in lines[1:]:
        key, *tokens = line.split(";")
        if key in ("OFFSET", "DIRECTION", "PROJECTION"):
            assert key not in data
            data[key] = tokens
        elif key == "BEGIN":
            active = {"label": tokens[0], "control": tokens[1]}
            assert tokens[3] == "True"
        elif key == "END":
            assert active is not None and active["label"] == tokens[0]
            if tokens[1] == "True":
                assert set(active) - {"label", "control"} == set(FIELDS)
                assert active["BALANCE"][-1] == "True"
                found.append(active)
            active = None
        elif active is not None and key in FIELDS:
            assert key not in active
            active[key] = tokens
    assert tuple(row["label"] for row in found) == PREFIX
    return data, found


def vector_literal(tokens, names):
    packed = ''.join(tokens)
    assert len(packed) == 960 and all(c in "0123456789ABCDEF" for c in packed)
    chunks = [packed[i:i+192] for i in range(0, len(packed), 192)]
    lines = [f'    packed = "{chunks[0]}"', *(f'    packed = packed & "{chunk}"' for chunk in chunks[1:]),
             f'    HardRankUnpackTest packed, {names}']
    assert all(len(line) < 220 for line in lines)
    return '\n'.join(lines) + '\n'


def diagnostic_test(original, definition):
    source = code(original).replace('"HARDSHEAR-MESH-GATE;1;" & CStr(HardMeshOrderTest)', '"HARDSHEAR-FINE-RESUME;1"')
    source = once(source, 'If requestedOrder <> "5" And requestedOrder <> "10"', 'If requestedOrder <> "10"')
    source = once(source, 'Требуется 5 или 10.', 'Для повтора требуется 100 точек.')
    source = once(source, '\\HardYieldGate.csv', '\\HardFineResume.csv')
    signature_start = source.index('Public Function ReplayHardYieldGateTest(')
    start = source.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0, signature_start)
    end = source.index("\nEnd Function", signature_start) + len("\nEnd Function")
    new = '''' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет префикс P1-P5,I6 той же 100-точечной квадратуры и продолжает его.
Public Function ReplayHardYieldGateTest(ByVal solver As CCoupledNewtonSolver, ByRef offset() As Double, _
        ByRef direction() As Double) As Boolean
    Dim history As New Collection, field() As Double, projection() As Double
    Dim controls(1 To 6) As Double, factors(1 To 6) As Double
    Dim packed As String
'''
    for index, row in enumerate(definition["fields"], 1):
        new += vector_literal(row["FIELD"], "field")
        new += '    history.Add field\n'
        new += f'    controls({index}) = HardRankValueTest("{row["control"]}")\n'
        new += f'    factors({index}) = HardRankValueTest("{row["BALANCE"][0]}")\n'
    new += vector_literal(definition["geometry"]["PROJECTION"], "projection")
    new += '    ReplayHardYieldGateTest = solver.TraceHardFineResumeTest(history, controls, factors, projection, _\n'
    new += f'        {definition["max_control"]:.17g}#, offset, direction)\nEnd Function'
    new.encode("cp1251")
    return vba(source[:start] + new + source[end:])


def diagnostic_solver(stock, inherited):
    production = code(stock).rstrip()
    prior = code(inherited)
    assert prior.startswith(production + "\n\n")
    addition = code((HERE / "Resume.bas").read_bytes())
    addition.encode("cp1251")
    return vba(production + "\n\n" + addition)


def diagnostic_runner(original):
    source = code(original)
    source = once(source, '[ValidateSet(5,10)][int]$Order=10', '[ValidateSet(10)][int]$Order=10')
    source = source.replace('HardYieldGate.csv', 'HardFineResume.csv')
    source = source.replace('CompileHardShearMeshGate', 'CompileHardFineResume').replace('RunHardShearMeshGate', 'RunHardFineResume')
    return source.encode("utf-8")


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--destination", type=Path, default=HERE / "ready-v2")
    cli.add_argument("--with-workbook", action="store_true")
    args = cli.parse_args()
    destination = args.destination.resolve()
    assert destination.is_relative_to(HERE) or destination.is_relative_to(Path("D:/CodexScratch/RC_Section_NDM_TQ").resolve())
    assert digest(ARCHIVE.read_bytes()) == ARCHIVE_HASH
    inputs = {}
    with ZipFile(ARCHIVE) as archive:
        frozen = json.loads(archive.read("Fixture.json"))
        source = (REPO / frozen["workbook"]).read_bytes()
        assert digest(source) == frozen["source_workbook_sha256"] == WORKBOOK_HASH
        raw_trace = archive.read("Native/Order10/HardYieldGate.csv")
        native = archive.read("Native/Order10/Verification.json")
        assert digest(native) == NATIVE_HASH
        report = json.loads(native)
        assert report["native_trace_sha256"] == digest(raw_trace) and report["proof"]["compiled_workbook_sha256"] == MESH_COMPILED_HASH
        metadata, fields = history(raw_trace)
        expected = {"geometry": metadata, "fields": fields, "max_control": frozen["probes"][-1],
                    "max_probes": 20, "relative_tolerance": 5e-7, "absolute_tolerance_MPa": 5e-7,
                    "stock_solver_sha256": frozen["production"][SOLVER], "local_predictor_deviation_factor": 3.}
        plan = (json.dumps(expected, indent=2) + "\n").encode("utf-8")
        inputs["Expected.json"] = seal(destination, "Expected.json", plan)
        inputs["Prior/HardYieldGate.csv"] = seal(destination, "Prior/HardYieldGate.csv", raw_trace)
        inputs["Prior/Verification.json"] = seal(destination, "Prior/Verification.json", native)
        prior_verifier = archive.read("Verify.py")
        assert digest(prior_verifier) == frozen["inputs"]["Verify.py"]
        inputs["PriorVerify.py"] = seal(destination, "PriorVerify.py", prior_verifier)
        for path, expected_hash in frozen["inputs"].items():
            raw = archive.read(path)
            assert digest(raw) == expected_hash, path
            if path.startswith("tools/") or path.startswith("src/") or path in (TESTS, "Guard-IsolatedOffice.ps1", "Run.ps1"):
                if path == SOLVER:
                    stock = archive.read("Production/" + path)
                    assert digest(stock) == frozen["production"][path]
                    raw = diagnostic_solver(stock, raw)
                elif path == TESTS:
                    raw = diagnostic_test(raw, expected)
                elif path == "Run.ps1":
                    raw = diagnostic_runner(raw)
                inputs[path] = seal(destination, path, raw)
    for path in ("Stage.py", "Verify.py", "Resume.bas"):
        inputs[path] = seal(destination, path, (HERE / path).read_bytes())
    if args.with_workbook:
        seal(destination, frozen["workbook"], source)
        seal(destination, "docs/regression/Diagnostic.xlsm", source)
        for path in ("Temp", "Native/Order10"):
            (destination / path).mkdir(parents=True, exist_ok=True)
    result = {**frozen, "inputs": inputs, "prior_archive_sha256": ARCHIVE_HASH,
              "prior_report_sha256": NATIVE_HASH, "prior_compiled_workbook_sha256": MESH_COMPILED_HASH,
              "orders": [10], "watchdog_seconds": 220,
              "scope": "a new locally continued 100-point equilibrium sequence; no physical limit verdict"}
    print(destination, seal(destination, "Fixture.json", (json.dumps(result, indent=2) + "\n").encode("utf-8")))


if __name__ == "__main__":
    main()
