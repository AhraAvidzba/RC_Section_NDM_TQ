"""Сопоставляет новое продолжение с отказавшей целью P6 той же квадратуры."""

from math import isclose
from pathlib import Path

import PriorVerify as prior
import Verify as check


HERE = Path(__file__).resolve().parent


def summarize():
    plan = prior.read(HERE / "Fixture.json")
    lane = HERE / "Native/Order10"
    result = prior.read(lane / "Verification.json")
    native = lane / "HardFineResume.csv"
    assert prior.file_hash(native) == result["native_trace_sha256"]
    tags, points, rows = check.parse(native)
    area, length, modulus, _ = prior.verify_geometry(plan, 10, tags, points)
    projection, direction = prior.numbers(tags["PROJECTION"]), prior.numbers(tags["DIRECTION"])
    for sample in rows:
        check.verify_row(sample, projection, direction, area, length, modulus)
    _, _, previous = prior.parse(HERE / "Prior/HardYieldGate.csv", 10)
    target = [r for r in previous if r["label"] in ("P6", "R6")]
    assert len(target) == 2 and all(not r["ready"] for r in target)
    old_coordinate = target[0]["control"]
    assert old_coordinate == target[1]["control"]
    accepted = [r for r in rows if r["ready"]]
    past = next(r for r in accepted if r["coordinate"] > old_coordinate)
    near = accepted[accepted.index(past)-1]
    assert near["coordinate"] <= old_coordinate
    best = max(accepted, key=lambda r: r["factor"])
    assert best["label"] == result["max_confirmed"]["label"] and best["factor"] == result["max_confirmed"]["factor"]
    target_forces, actual_forces, residual = map(prior.numbers, (best["TARGET"], best["ACTUAL"], best["RESIDUAL"]))
    scales = (area, area*length, area*length, area*length, area, area)
    differences = [computed-requested for computed, requested in zip(actual_forces, target_forces, strict=True)]
    max_six = max(abs(error)/scale for error, scale in zip(differences, scales, strict=True))
    max_weak = max(map(abs, residual[:56]))
    max_gauge = max(map(abs, residual[56:]))
    assert isclose(best["norm"], max(max_six, max_weak, abs(prior.number(best["BALANCE"][3]))), rel_tol=3e-9, abs_tol=1e-15)
    assert max_gauge * modulus <= best["tau"]
    unresolved = [item for item in result["secants"] if item is None or item["sign"] == 0]
    # Обе стороны от точки старого отказа относятся к одной направленной истории.
    sign_intervals = {f"{item['left']}:{item['right']}": item["slope_interval"] for item in result["secants"] if item}
    assert sign_intervals[f"{near['label']}:{past['label']}"][0] > 0.
    assert result["prefix_bit_identical_count"] == result["prefix_exact_residual_count"] == 6
    assert result["outcome"] == "PROBE_LIMIT" and len(result["attempts"]) == 20
    assert sum(row["ready"] for row in rows if row["label"].startswith("F")) == 13
    assert result["positive_intervals"] == 12 and result["negative_intervals"] == 0 and len(unresolved) == 1
    assert best["uncertainty"] > 0.
    return {"old_P6_control": old_coordinate,
            "old_P6_retested_at_exact_control": any(row["control"] == old_coordinate for row in rows),
            "last_before_old_P6": check.record(near), "first_beyond_old_P6": check.record(past),
            "slope_interval_across_old_P6": sign_intervals[f"{near['label']}:{past['label']}"],
            "largest_sample": check.record(best),
            "largest_sample_lambda_interval": [best["factor"] - best["uncertainty"], best["factor"] + best["uncertainty"]],
            "target_signed_six_N_and_Nmm": target_forces, "actual_signed_six_N_and_Nmm": actual_forces,
            "signed_differences_N_and_Nmm": differences, "resultant_residual_max_MPa": max_six,
            "weak_residual_max_MPa": max_weak, "gauge_residual_max": max_gauge,
            "positive_intervals": result["positive_intervals"], "negative_intervals": result["negative_intervals"],
            "uncertainty_includes_zero": unresolved, "outcome": result["outcome"],
            "installed_capacity_status_changed": False, "physical_limit_certified": False}
