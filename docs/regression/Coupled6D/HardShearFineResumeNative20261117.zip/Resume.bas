' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет принятый префикс 100-точечной траектории и продолжает по исходной мере.
' Уменьшает шаг после численного отказа, не меняя нагрузки и материальный закон.
Friend Function TraceHardFineResumeTest(ByVal history As Collection, ByRef controls() As Double, _
        ByRef factors() As Double, ByRef projection() As Double, ByVal maxControl As Double, _
        ByRef offset() As Double, ByRef direction() As Double) As Boolean
    Const MAX_PROBES As Long = 20
    If Not mUseSpatialHistory Or mDegreeCount <> 60 Or mSection.ConcretePointCount <> 100 Or history.Count <> 6 Then Exit Function
    Dim area As Double, lengthScale As Double, point As Long, x As Double, y As Double
    mSection.CopyResultantResidualScales area, lengthScale
    WriteHardRankRowTest "MESH;10;100;" & CStr(mPointCount) & ";" & HardRankBitsTest(area) & ";" & _
        HardRankBitsTest(lengthScale) & ";" & HardRankBitsTest(mReferenceModulus)
    WriteHardRankRowTest "OFFSET;" & HardRankVectorTest(offset)
    WriteHardRankRowTest "DIRECTION;" & HardRankVectorTest(direction)
    WriteHardRankRowTest "PROJECTION;" & HardRankVectorTest(projection)
    For point = 1 To 100
        mSection.Point point, x, y, area
        WriteHardRankRowTest "QUAD;" & CStr(point) & ";" & HardRankBitsTest(x) & ";" & HardRankBitsTest(y) & ";" & HardRankBitsTest(area)
    Next point
    ResetHistory
    Dim current() As Double, prior() As Double, expected() As Double
    CopyAccepted current
    WriteHardRankRowTest "VIRGIN;" & HardRankVectorTest(current)

    Dim index As Long, lambda As Double, acceptedControl As Double, priorControl As Double
    Dim acceptedLambda As Double, priorLambda As Double, label As String, seed As Variant, verified As Boolean
    For index = 1 To history.Count
        expected = history(index): seed = expected
        If index < history.Count Then label = "P" & CStr(index) Else label = "I6"
        verified = TryHardFinePointTest(label, controls(index), factors(index), offset, direction, projection, _
            seed, acceptedControl, lambda, True, index >= 5)
        If Not verified Then
            WriteHardRankRowTest "FINISH;PREFIX_REFUSED;" & CStr(index - 1) & ";0"
            TraceHardFineResumeTest = True
            Exit Function
        End If
        If index = 5 Then
            CopyAccepted prior
            priorControl = acceptedControl: priorLambda = lambda
        End If
    Next index
    CopyAccepted current
    acceptedLambda = lambda
    If acceptedControl <= priorControl Then Exit Function

    Dim nominal As Double, increment As Double, minimum As Double, maximum As Double, target As Double
    Dim probe As Long, success As Long, stride As Double, control As Double, i As Long, prediction() As Double
    nominal = (acceptedControl - priorControl) / 16#: minimum = nominal / 64#: maximum = nominal * 4#
    increment = nominal
    WriteHardRankRowTest "ADAPT;" & HardRankBitsTest(nominal) & ";" & HardRankBitsTest(minimum) & ";" & _
        HardRankBitsTest(maximum) & ";" & HardRankBitsTest(maxControl) & ";" & CStr(MAX_PROBES)
    Dim launched As Long, reason As String, consecutive As Long
    reason = "PROBE_LIMIT"
    For probe = 1 To MAX_PROBES
        target = GeomMin(maxControl, acceptedControl + increment)
        If target <= acceptedControl Then
            reason = "CONTROL_BOUND": Exit For
        End If
        stride = (target - acceptedControl) / (acceptedControl - priorControl)
        prediction = current
        For i = 1 To mDegreeCount: prediction(i) = current(i) + stride * (current(i) - prior(i)): Next i
        seed = prediction
        launched = launched + 1
        If TryHardFinePointTest("F" & CStr(probe), target, acceptedLambda + stride * (acceptedLambda - priorLambda), _
                offset, direction, projection, seed, control, lambda, False, True) Then
            prior = current: priorControl = acceptedControl: priorLambda = acceptedLambda
            CopyAccepted current: acceptedControl = control: acceptedLambda = lambda
            success = success + 1: consecutive = consecutive + 1
            If consecutive >= 2 Then increment = GeomMin(maximum, increment * 1.4)
            If target = maxControl Then
                reason = "CONTROL_BOUND": Exit For
            End If
        Else
            consecutive = 0
            increment = increment * 0.5
            If increment < minimum Then
                reason = "MINIMUM_STEP": Exit For
            End If
        End If
    Next probe
    WriteHardRankRowTest "FINISH;" & reason & ";6;" & CStr(launched) & ";" & CStr(success)
    TraceHardFineResumeTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Публикует только уравновешенное поле и полную историю своего разбиения.
' Проверяет точный повтор только для уже принятых полей, затем следит за направлением.
Private Function TryHardFinePointTest(ByVal label As String, ByVal target As Double, ByVal estimate As Double, _
        ByRef offset() As Double, ByRef direction() As Double, ByRef projection() As Double, ByRef seed As Variant, _
        ByRef control As Double, ByRef trialFactor As Double, ByVal replay As Boolean, ByVal wantBound As Boolean) As Boolean
    Const ABS_TOLERANCE As Double = 0.0000005, REL_TOLERANCE As Double = 0.0000005, ITERATIONS As Long = 12
    Dim prior() As Double, current() As Double, expected() As Double, actual() As Double, after() As Double
    Dim load(1 To COMPONENT_COUNT) As Double, i As Long
    CopyAccepted prior: expected = seed
    WriteHardRankRowTest "BEGIN;" & label & ";" & HardRankBitsTest(target) & ";" & HardRankBitsTest(estimate) & ";True"
    WriteHardRankRowTest "SEED;" & HardRankVectorTest(expected)
    WriteHardRankRowTest "START-FIELD;" & HardRankVectorTest(prior)
    Dim solved As Boolean, status As CResultMeta, result As String
    solved = TryDeformationStep(offset, direction, projection, target, estimate, trialFactor, _
        ABS_TOLERANCE, REL_TOLERANCE, ITERATIONS, consistentControl:=True, initialField:=seed)
    Set status = ResultMeta
    WriteHardRankRowTest "SOLVER;" & CStr(solved) & ";" & CStr(status.InternalStatus) & ";" & CStr(status.ResultCode) & ";" & _
        CStr(mIterations) & ";" & CStr(mEvaluations) & ";" & Replace(status.DiagnosticDetails, ";", "|")
    result = "SOLVER_REFUSED"
    If solved Then
        CopyTrial current, actual
        For i = 1 To COMPONENT_COUNT: load(i) = offset(i) + trialFactor * direction(i): Next i
        Dim tolerance As Double, norm As Double, verified As Boolean, fieldAgrees As Boolean
        tolerance = EquilibriumTolerance(ABS_TOLERANCE, REL_TOLERANCE): norm = EquilibriumNorm(load, current)
        control = HardFineControlTest(projection, current)
        verified = trialFactor > 0# And norm <= tolerance And GaugesVerified(tolerance) And _
            Abs(ControlResidual(current)) <= tolerance
        Dim response As CCoupledReinforcedResponse, longitudinal As Double, transverse As Double
        Set response = YieldResponse(0)
        response.ReadHardMeshSteelTest longitudinal, transverse
        WriteHardRankRowTest "FIELD;" & HardRankVectorTest(current)
        WriteHardRankRowTest "TARGET;" & HardRankVectorTest(load)
        WriteHardRankRowTest "ACTUAL;" & HardRankVectorTest(actual)
        WriteHardRankRowTest "RESIDUAL;" & HardRankVectorTest(mResidual)
        WriteHardRankRowTest "CONTROL;" & HardRankBitsTest(control)
        WriteHardRankRowTest "BALANCE;" & HardRankBitsTest(trialFactor) & ";" & HardRankBitsTest(norm) & ";" & _
            HardRankBitsTest(tolerance) & ";" & HardRankBitsTest(ControlResidual(current)) & ";" & _
            HardRankBitsTest(longitudinal) & ";" & HardRankBitsTest(transverse) & ";" & CStr(verified)
        fieldAgrees = True
        If replay Then
            fieldAgrees = (HardRankBitsTest(trialFactor) = HardRankBitsTest(estimate))
            For i = 1 To mDegreeCount
                If HardRankBitsTest(current(i)) <> HardRankBitsTest(expected(i)) Then fieldAgrees = False
            Next i
        End If
        If Not verified Then
            result = "BALANCE_REFUSED"
        ElseIf Not fieldAgrees Then
            result = "PREFIX_FIELD_CHANGED"
        ElseIf control <= HardFineControlTest(projection, prior) Then
            result = "NO_FORWARD_PROGRESS"
        ElseIf Not replay And Not HardFineProgressTest(prior, expected, current) Then
            result = "BRANCH_JUMP_REFUSED"
        ElseIf response.TrialSteelUtilization > 1# Then
            result = "STEEL_EVENT_NOT_COMMITTED"
        Else
            result = "ACCEPTED"
            If wantBound Then
                Dim uncertainty As Double, bounded As Boolean
                bounded = TrialLambdaUncertainty(ABS_TOLERANCE, REL_TOLERANCE, uncertainty)
                WriteHardRankRowTest "BOUND;" & CStr(bounded) & ";" & HardRankBitsTest(uncertainty)
                If bounded Then RecordHardFineTangentTest
                If Not mCandidateReady Then
                    If Not RestoreHardFineCandidateTest(current, load, actual, trialFactor, tolerance) Then result = "RECHECK_REFUSED"
                End If
            End If
        End If
    End If
    TryHardFinePointTest = (result = "ACCEPTED")
    If TryHardFinePointTest Then AcceptStep Else DiscardStep
    CopyAccepted after
    WriteHardRankRowTest "STOP-FIELD;" & HardRankVectorTest(after)
    WriteHardRankRowTest "DECISION;" & result
    WriteHardRankRowTest "END;" & label & ";" & CStr(TryHardFinePointTest)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Передаёт исходную касательную для автономной оценки интервала множителя.
Private Sub RecordHardFineTangentTest()
    Dim lines() As String, row() As Double, i As Long, j As Long
    ReDim lines(0 To mDegreeCount + 1): ReDim row(1 To mDegreeCount)
    lines(0) = "DIRECTION-EQ;" & HardRankVectorTest(mDirectionEquations)
    lines(1) = "BOUND-RES;" & HardRankVectorTest(mResidual)
    For i = 1 To mDegreeCount
        For j = 1 To mDegreeCount: row(j) = mMatrix(j, i): Next j
        lines(i + 1) = "K;" & CStr(i) & ";" & HardRankVectorTest(row)
    Next i
    WriteHardRankRowTest Join(lines, vbCrLf)
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' После неудачной оценки чувствительности повторно получает то же пробное поле без касательной.
Private Function RestoreHardFineCandidateTest(ByRef field() As Double, ByRef load() As Double, _
        ByRef actual() As Double, ByVal trialFactor As Double, ByVal tolerance As Double) As Boolean
    If Not Evaluate(field, False) Then Exit Function
    If EquilibriumNorm(load, field) > tolerance Or Not GaugesVerified(tolerance) Then Exit Function
    Dim i As Long
    For i = 1 To COMPONENT_COUNT
        If HardRankBitsTest(mTrialResultants(i)) <> HardRankBitsTest(actual(i)) Then Exit Function
    Next i
    Dim response As CCoupledReinforcedResponse: Set response = YieldResponse(0)
    If response.TrialSteelUtilization > 1# Then Exit Function
    mCandidate = field
    PublishCandidate trialFactor
    RestoreHardFineCandidateTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Ограничивает отклонение от локальной секущей для механических переменных.
Private Function HardFineProgressTest(ByRef prior() As Double, ByRef predicted() As Double, ByRef field() As Double) As Boolean
    Dim i As Long, expected As Double, difference As Double
    For i = 1 To mGaugeStart - 1
        expected = GeomMax(expected, Abs(predicted(i) - prior(i)))
        difference = GeomMax(difference, Abs(field(i) - predicted(i)))
    Next i
    HardFineProgressTest = (expected > 0# And difference <= 3# * expected)
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вычисляет фактическую меру в сохранённом физическом базисе.
Private Function HardFineControlTest(ByRef projection() As Double, ByRef field() As Double) As Double
    Dim i As Long
    For i = 1 To mGaugeStart - 1
        HardFineControlTest = HardFineControlTest + projection(i) * field(i)
    Next i
End Function
