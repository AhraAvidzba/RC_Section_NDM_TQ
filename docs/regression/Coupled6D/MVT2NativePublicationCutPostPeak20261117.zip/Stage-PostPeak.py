"""Формирует отдельную копию Excel для продолжения от 36 подтверждённых полей."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile
import json


HERE = Path(__file__).resolve().parent
ARCHIVE = 'MVT2NativePublicationCutSequentialTwist20261117.zip'
ARCHIVE_SHA = '5958DB1E43D9FDFD6129A0CAA1DFDBD777A9EC67D74DBDE46E22E9E5C402E8ED'
PARENT_SHA = 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A'


def stage(repo, target):
    archived = repo / 'docs/regression/Coupled6D'
    workbook = archived / ARCHIVE
    assert sha256(workbook.read_bytes()).hexdigest().upper() == ARCHIVE_SHA
    prepare = run_path(str(HERE / 'Stage-Follow.py'))
    utilities = {'__name__':'__pinned__'}
    with ZipFile(archived / 'MVT2NativePublicationCutTimed20261117.zip') as original:
        assert sha256(Path(original.filename).read_bytes()).hexdigest().upper() == PARENT_SHA
        text = original.read('Verify-NativePublicationCut.py')
        exec(compile(text, 'Verify-NativePublicationCut.py', 'exec'), utilities)
    with ZipFile(workbook) as pinned:
        stem = 'RefinedTwist'
        history = pinned.read(f'{stem}/Replay.Fields.csv')
        operator_wire = pinned.read(f'{stem}/Native/Operators.csv')
        source_fields = utilities['read_operators'](operator_wire)['F']
        frames = utilities['read_tensor_frames'](pinned.read(f'{stem}/Native/MVTGaussMixed.Tensor.csv'), 45)
        old = history.decode('ascii').splitlines()
        assert len(old) == 28
        assert list(source_fields) == list(frames) == ['Replay', *(f'TwistStep{i}' for i in range(1,9))]
        for raw in operator_wire.decode('ascii').splitlines():
            if raw.startswith('F;TwistStep'):
                _, label, *field = raw.split(';')
                t, q, _ = frames[label]
                old.append(';'.join([label, f'{q:.15g}', f'{t:.15g}', *field]))
        assert len(old) == 36 and old[-1].split(';')[:3] == ['TwistStep8', '22377.4648255896', '10510000']
        assert old[-2].split(';')[:3] == ['TwistStep7', '22382.470120887', '10510000']
    empty_path = HERE / 'Replay-Pinned28.csv'
    if empty_path.exists():
        assert empty_path.read_bytes() == history
    else:
        empty_path.write_bytes(history)
    prepare['stage'](repo, target, empty_path, 'RefinedTwist')
    replay = target / 'Replay.Fields.csv'
    replay.write_bytes(('\r\n'.join(old) + '\r\n').encode('ascii'))
    index = target / 'Preparation.json'
    records = json.loads(index.read_bytes())
    test = target / 'tests/modTestMVT2GaussSpan.bas'
    source = test.read_text(encoding='utf-8-sig')
    replace = prepare['replace_once']
    source = replace(source,'Q_ACCEPTED As Double = 22392.578125','Q_ACCEPTED As Double = 22377.4648255896')
    source = replace(source,'If history.Count <> 28 Or','If history.Count <> 36 Or')
    source = replace(source,'Val(parts(1)) <> Q_ACCEPTED','Abs(Val(parts(1)) - Q_ACCEPTED) > 0.00000001')
    source = replace(source,'MVT2_FOLLOW_REPLAY;28;22392.578125','MVT2_POST_PEAK_REPLAY;36;22377.4648255896')
    source = replace(source,'leftField = history.Item(27): rightField = history.Item(28)',
                     'leftField = history.Item(35): rightField = history.Item(36)')
    source = replace(source,
                     'TestPublicationFollowSequentialTwist(solver, operators, stations, history, report, tracePath, True)',
                     'TestPublicationPostPeak(solver, operators, stations, history, report, tracePath)')
    source += (HERE / 'ContinuePostPeak.bas.txt').read_text(encoding='utf-8-sig')
    source.encode('cp1251')
    test.write_bytes(source.replace('\n','\r\n').encode('utf-8-sig'))
    for leaf in (replay, test):
        records['inputs'][leaf.relative_to(target).as_posix()] = sha256(leaf.read_bytes()).hexdigest().upper()
    records['follow_mode'] = 'PostPeak'
    records['follow_history_archive'] = ARCHIVE_SHA
    index.write_bytes((json.dumps(records, indent=2) + '\n').encode())
    print('POST PEAK PREPARED', records['inputs']['Replay.Fields.csv'], flush=True)


if __name__ == '__main__':
    options = ArgumentParser(description=__doc__)
    options.add_argument('--repo', type=Path, default=Path.cwd())
    options.add_argument('--stage', type=Path, required=True)
    args = options.parse_args()
    stage(args.repo.resolve(), args.stage.resolve())
