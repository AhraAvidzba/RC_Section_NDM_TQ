"""Проверяет 20 новых равновесий на траектории закручивания MVT2."""

from argparse import ArgumentParser
from hashlib import sha256
from itertools import product
from math import isclose
from pathlib import Path
from zipfile import ZipFile
import json


ARCHIVE = 'MVT2NativePublicationCutSequentialTwist20261117.zip'
ARCHIVE_SHA = '5958DB1E43D9FDFD6129A0CAA1DFDBD777A9EC67D74DBDE46E22E9E5C402E8ED'
FOLLOW = 'MVT2NativePublicationCutFollow20261117.zip'
FOLLOW_SHA = '9F55DE3FC0B1B652DD1ED9683507423ADE4DF6AB3B008D9590EE1D9327F9864E'
TARGET_BOOK_SHA = '39CF2D47068A2B763E5DBBFA995BDF92B1C76453067D4AD647AC1A1F4D7C3261'
HISTORY_SHA = '17140620F0D6F4803769A8E432381233A7C79EC653BDEC4CF88646C006DDA73E'
LAST_FIELD = 'TwistStep8'


def digest(data):
    return sha256(data).hexdigest().upper()


def close(a, b, limit):
    return isclose(a, b, rel_tol=0., abs_tol=limit)


def verify(repo, root):
    evidence = repo / 'docs/regression/Coupled6D'
    follow, utility, recovery = {'__name__': '__pinned__'}, {'__name__': '__pinned__'}, {'__name__': '__pinned__'}
    assert digest((evidence / FOLLOW).read_bytes()) == FOLLOW_SHA
    assert digest((evidence / ARCHIVE).read_bytes()) == ARCHIVE_SHA
    with ZipFile(evidence / FOLLOW) as pinned:
        exec(compile(pinned.read('Verify-NativeFollow.py'), FOLLOW, 'exec'), follow)
    utility, recovery, _, _, _, mesh = follow['read_references'](repo)
    with ZipFile(evidence / ARCHIVE) as pinned:
        old = utility['read_operators'](pinned.read('RefinedTwist/Native/Operators.csv'))
        old_frames = utility['read_tensor_frames'](pinned.read('RefinedTwist/Native/MVTGaussMixed.Tensor.csv'), 45)
        old_wire = pinned.read('RefinedTwist/Replay.Fields.csv')
        earlier_max = json.loads(pinned.read('SequentialTwistProof.json'))['path_results']['RefinedTwist']['maximum']['Qy_N']

    native = root / 'Native'
    log = (native / 'MVTGaussMixed.txt').read_text(encoding='utf-8-sig')
    termination, pid, ticks = follow['owner_check'](root, log, recovery)
    assert termination == 'completed'
    assert follow['read_json'](root / 'CodeUpdate.json')['WorkbookSHA256'] == TARGET_BOOK_SHA
    prep = follow['read_json'](root / 'Preparation.json')
    assert prep['follow_mode'] == 'PostPeak' and prep['follow_history_archive'] == ARCHIVE_SHA
    assert prep['source_book_sha256'] == recovery['BOOK_SHA']
    for name in ('Run-Native.ps1', 'Replay.Fields.csv', 'tests/modTestMVT2GaussSpan.bas'):
        assert digest((root / name).read_bytes()) == prep['inputs'][name]
    history = (root / 'Replay.Fields.csv').read_bytes()
    assert digest(history) == HISTORY_SHA
    assert history.startswith(old_wire)
    tail = [row.split(';') for row in history[len(old_wire):].decode('ascii').splitlines()]
    assert [row[0] for row in tail] == [f'TwistStep{i}' for i in range(1,9)]
    for name, q, t, *field in tail:
        assert tuple(map(float, field)) == old['F'][name]
        assert (float(t), float(q)) == old_frames[name][:2]

    operators = utility['read_operators']((native / 'Operators.csv').read_bytes())
    frames = utility['read_tensor_frames']((native / 'MVTGaussMixed.Tensor.csv').read_bytes(), 45)
    rows = [line.split(';') for line in (native / 'MVTGaussMixed.csv').read_text(encoding='cp1251').splitlines()]
    assert recovery['geometry'](rows) == mesh and all(operators[k] == old[k] for k in 'GLBSR')
    assert operators['F']['Replay'] == old['F'][LAST_FIELD]
    assert frames['Replay'][:2] == old_frames[LAST_FIELD][:2]
    delta = max(abs(a-b) for side,p in product((-1,0,1), mesh[1])
                for a,b in zip(operators['H']['Replay',side,p], old['H'][LAST_FIELD,side,p], strict=True))
    assert delta < 5e-12 and 'MVT2_POST_PEAK_REPLAY;36;22377.4648255896' in log
    physical_scale = 1000. / mesh[0][3]

    previous_axis = old['F']['TwistStep7'][3]
    theta = old['F'][LAST_FIELD][3]
    initial = theta - previous_axis
    width, limit = initial, theta + 256. * initial
    previous_q, q = old_frames['TwistStep7'][1] / 1000., old_frames[LAST_FIELD][1] / 1000.
    records = [{'Qy_N':1000.*q,'twist_rad_per_m':physical_scale*theta,'phase':'Replay',
                'equilibrium':recovery['equations']('Replay',frames['Replay'],operators,mesh)}]
    trials = [row for row in rows if row[0] == 'MVT2_POST_PEAK']
    assert len(trials) == 20
    for i,row in enumerate(trials, 1):
        _, tag, base, target, old_q, estimate, actual, ok, internal, code, *rest = row
        assert tag == f'PostPeak{i}' and ';'.join(row) in log
        wanted = min(theta + width, limit)
        predictor = q + (wanted - theta) / (theta - previous_axis) * (q - previous_q)
        assert close(float(base), theta, 3e-17) and close(float(target), wanted, 3e-17)
        assert close(float(old_q), q, 2e-12) and close(float(estimate), predictor, 1e-10)
        work = follow['trial_work'](rest, ok, internal, code)
        assert work['accepted']
        new = operators['F'][tag][3]
        assert new > theta and close(new, wanted, 3e-17)
        assert frames[tag][0] == follow['TORQUE'] and close(frames[tag][1], float(actual)*1000., 2e-8)
        eq = recovery['equations'](tag, frames[tag], operators, mesh)
        records.append({'Qy_N':frames[tag][1], 'twist_rad_per_m':physical_scale*new,'phase':tag,
                        'equilibrium':eq,'iterations':work['iterations'],'evaluations':work['evaluations']})
        previous_axis, theta = theta, new
        previous_q, q = q, float(actual)
        width = min(width * 2., 16. * initial)
    assert close(theta, limit, 3e-17)
    names = [item['phase'] for item in records]
    assert list(frames) == list(operators['F']) == names
    assert set(operators['H']) == set(product(names, (-1,0,1), mesh[1]))
    finish, = [row for row in rows if row[0] == 'CASE_FINISHED']
    assert finish[2] == 'True' and 0 < float(finish[3]) < 165
    turning = min(records, key=lambda row:row['Qy_N'])
    assert turning['phase'] == 'PostPeak5'
    assert turning['Qy_N'] < records[-1]['Qy_N'] < earlier_max
    return {'fields':records,'local_valley':turning,'prior_maximum_N':earlier_max,'end':records[-1],
            'max_net_stress_replay_delta_MPa':delta,'macro_seconds':float(finish[3]),
            'excel_closed_pid':pid,'excel_closed_ticks':ticks,'physical_limit_established':False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    result = verify(args.repo.resolve(), args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as out:
        json.dump(result, out, indent=2, sort_keys=True, allow_nan=False)
        out.write('\n')
    print('MVT2 POST PEAK OFFLINE PASS 20')
