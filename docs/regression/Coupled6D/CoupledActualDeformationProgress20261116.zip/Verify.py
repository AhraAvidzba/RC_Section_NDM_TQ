"""Replay the bracket, native Results assertions and compiled provenance."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
REVISION = '6db0c93dc10e921ae6c0fdeea0f1549c4d63f18a'
SOURCES = ('src/Solver/CCoupledDeformationContinuation.cls', 'tests/CTestCoupledPointResponse.cls',
           'tests/modTestCoupledElasticState.bas')
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
EXPORT = 'workbook/output/VBA_All_Code.txt'
CASES = {
    'Base': ('RunTestCoupledControlProgress',),
    'Candidate': ('RunTestCoupledControlProgress', 'RunTestCoupledDeformationControl',
                  'RunTestCoupledDeformationSteelCrossing', 'RunTestCoupledRetainedShoulders',
                  'RunTestCoupledDesignWitness', 'RunTestCoupledDiscardedShoulder',
                  'RunTestCoupledKinematicGauge', 'RunTestCoupledFinalLoadTolerance', 'RunTestCoupledWorkbookInput'),
}


def sha(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, values):
    path.write_text(json.dumps(values, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def selected_log(role, name):
    return ROOT / role / 'Native' / f'{name}.txt'


def native(role, name, expected_hash):
    log = selected_log(role, name)
    report = log.read_text(encoding='utf-8-sig')
    receipt = read(log.with_suffix('.txt.Receipt.json'))
    owner = read(log.with_suffix('.txt.Ownership.json'))
    assert owner['VerifiedNewOwner'] and owner['SourceSHA256'] == expected_hash
    assert (owner['PID'], owner['StartTicksUTC']) == (receipt['closed']['PID'], receipt['closed']['StartTicksUTC'])
    assert receipt['closed']['State'] == 'Absent'
    assert f'SOURCE_SHA256: {expected_hash}' in report
    match = re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)$', report, re.M)
    assert len(match) == 1 and tuple(map(int, match[0])) == (receipt['pass'], receipt['fail'])
    assert 'RUNTIME ERROR:' not in report and 'SOURCE_UNCHANGED: True' in report
    failures = re.findall(r'^FAIL: (.*)$', report, re.M)
    assert len(failures) == receipt['fail']
    assert receipt['exit'] == int(bool(failures))
    return receipt, failures


def check_behavior(base_hash, new_hash):
    totals = {role: {} for role in CASES}
    coordinates = tuple(map(Fraction, ('0.0004', '0.0005', '0.0006', '0.00065', '0.0007')))
    t = [(e - coordinates[0]) * 10_000 for e in coordinates]
    exact = [((((-218 * x + 1309) * x - 2428) * x + 1379) * x + 450) / 600 for x in t]
    assert exact == list(map(Fraction, ('0.75', '0.82', '0.8', '1.1', '0.7')))
    nominal = (coordinates[2] - coordinates[0]) / 4 / 64
    strain_residual = 30_000 * nominal
    tolerance = Fraction('0.03') + Fraction('1e-8') * 410_000 * exact[-1] / 21_600
    assert nominal == Fraction('7.8125e-7') and strain_residual < tolerance < 2 * strain_residual
    exact_design = Fraction('1e-4')
    left = exact_design - Fraction('1e-5')
    right_before = exact_design + Fraction('1e-11')
    right_replayed = exact_design - Fraction('1e-12')
    replayed_lambda = 1 + Fraction('1e-9')
    replayed_residual = 30_000 * (right_before - right_replayed)
    assert 0 < replayed_residual < Fraction('5e-7')
    assert left < right_replayed < exact_design < right_before and replayed_lambda >= 1
    for role, names in CASES.items():
        for name in names:
            receipt, failures = native(role, name, base_hash if role == 'Base' else new_hash)
            if role == 'Candidate':
                assert not failures
                if name == 'RunTestCoupledControlProgress':
                    assert receipt['pass'] == 20
            else:
                assert (receipt['pass'], receipt['fail']) == (17, 3)
                assert failures == [
                    'стационарные повторы не добавлены к пяти принятым состояниям',
                    'стационарные повторы не записаны в материал',
                    'фактические координаты всех закреплённых шагов строго возрастают',
                ]
            totals[role][name] = receipt
    return totals, dict(coordinates=list(map(float, coordinates)), exact_lambdas=list(map(float, exact)),
                        stationary_target_increment=float(nominal), its_control_residual_MPa=float(strain_residual),
                        tolerance_MPa=float(tolerance),
                        design_bracket_counterexample=dict(left=float(left), exact=float(exact_design),
                            right_before=float(right_before), right_replayed=float(right_replayed),
                            replayed_lambda=float(replayed_lambda), replayed_residual_MPa=float(replayed_residual)))


def verify_export(proof, equality, comparison):
    assert equality['Passed'] and all(equality['VerifierSelfChecks'].values())
    assert equality['SourceComponents'] == len(SOURCES)
    assert equality['ExportComponents'] == comparison['components'] == 225
    assert equality['ExportSHA256'] == proof['installed_export_sha256']
    assert {record['Name']: record['SourceSHA256'] for record in equality['Components']} == {
        Path(name).stem: value for name, value in proof['sources'].items()
    }
    assert sorted(Path(name).stem for name in SOURCES) == comparison['changes']


def attest():
    base = ROOT / 'Base'
    candidate = ROOT / 'Candidate'
    result = candidate / 'docs/regression/Audit03/DesignWitness'
    package = read(candidate / 'PackageChecks.json')
    assert package['base_sha256'] == sha(candidate / BOOK)
    assert package['candidate_sha256'] == sha(result / Path(BOOK).name)
    with ZipFile(candidate / BOOK) as original, ZipFile(result / Path(BOOK).name) as built:
        assert built.testzip() is None and original.namelist() == built.namelist()
        assert [entry for entry in original.namelist() if original.read(entry) != built.read(entry)] == ['xl/vbaProject.bin']
        assert package['unchanged_package_parts'] == len(original.infolist()) - 1 == 121
        assert package['vba_sha256'] == sha256(built.read('xl/vbaProject.bin')).hexdigest().upper()

    base_compile = read(base / 'docs/regression/CodeUpdate.json')
    assert base_compile['Compiled'] and not base_compile['ProductionChanged']
    assert base_compile['ProductionSHA256'] == package['base_sha256']
    assert base_compile['WorkbookSHA256'] == sha(base / 'docs/regression/Diagnostic.xlsm')
    totals, analytical = check_behavior(base_compile['WorkbookSHA256'], package['candidate_sha256'])
    closure = read(candidate / 'ExportClosure.json')
    assert closure['State'] == 'Absent'
    assert f"sourceSHA256={package['candidate_sha256']}; sourceUnchanged=True" in (candidate / 'Export.log').read_text(encoding='utf-8-sig')
    proof = {
        'status': 'PASS', 'source_git_revision': REVISION, 'package': package,
        'installed_export_sha256': sha(result / Path(EXPORT).name), 'previous_export_sha256': sha(candidate / EXPORT),
        'sources': {name: sha(candidate / name) for name in SOURCES}, 'native': totals, 'analytical': analytical,
        'baseline_diagnostic_sha256': base_compile['WorkbookSHA256'], 'export_closure': closure,
    }
    verify_export(proof, read(candidate / 'docs/regression/SourceEquality.json'), read(candidate / 'ExportDifference.json'))
    write(ROOT / 'Verification.json', proof)
    print('PASS', sha(ROOT / 'Verification.json'), [sum(r['pass'] for r in layer.values()) for layer in totals.values()])


def replay():
    proof = read(ROOT / 'Verification.json')
    publication = read(ROOT / 'Publication.json')
    assert publication['verification_sha256'] == sha(ROOT / 'Verification.json')
    assert publication['status'] == proof['status'] == 'PASS' and proof['source_git_revision'] == REVISION
    workbook = proof['package']['candidate_sha256']
    assert publication['installed'] == {BOOK: workbook, EXPORT: proof['installed_export_sha256'], **proof['sources']}
    assert proof['package']['unchanged_package_parts'] == 121 and proof['export_closure']['State'] == 'Absent'
    for path in SOURCES:
        assert sha(ROOT / 'compiled' / path) == proof['sources'][path]
    verify_export(proof, read(ROOT / 'SourceEquality.json'), read(ROOT / 'ExportDifference.json'))
    totals, analytical = check_behavior(proof['baseline_diagnostic_sha256'], workbook)
    assert proof['native'] == totals and proof['analytical'] == analytical
    results = {
        'native_assertions': sum(row['pass'] for row in totals['Candidate'].values()),
        'baseline_expected_failures': sum(row['fail'] for row in totals['Base'].values()),
        'analytical': analytical, 'build_verification_sha256': sha(ROOT / 'Verification.json'),
        'workbook_sha256': workbook, 'export_sha256': proof['installed_export_sha256'],
    }
    write(ROOT / 'Replay.json', results)
    print('PASS', sha(ROOT / 'Replay.json'), results['native_assertions'])


if __name__ == '__main__':
    if sys.argv[1:] == ['--build']:
        attest()
    else:
        assert not sys.argv[1:]
        replay()
