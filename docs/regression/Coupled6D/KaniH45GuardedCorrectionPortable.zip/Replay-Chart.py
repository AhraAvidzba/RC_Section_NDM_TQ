"""Recompute the fixed-field Kani comparison from archived native evidence."""
from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json
import math
import re
import subprocess

HERE = Path(__file__).resolve().parent
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
DRAFT = 'docs/regression/Diagnostic.xlsm'
ARTIFACT_ROOT = 'docs/regression/Coupled6D'
SCHEMA = 'KaniH45GuardedCorrection/v1'


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(value):
    data = value.read_bytes() if isinstance(value, Path) else value
    return sha256(data).hexdigest().upper()


def git_blob(repo, ref, name):
    return subprocess.check_output(['git', '-C', str(repo), 'cat-file', 'blob', f'{ref}:{name}'])


def checked_preparation(repo, manifest):
    receipt = read_json(HERE / 'Preparation.json')
    module = HERE / 'src/Materials/CCoupledConcreteResponse.cls'
    assert receipt['sourceGit'] == manifest['historicalGit']
    assert receipt['bookSHA256'] == manifest['sourceWorkbookSHA256'] == receipt['frozen'][BOOK]
    assert digest(git_blob(repo, receipt['sourceGit'], BOOK)) == receipt['bookSHA256']
    if (HERE / BOOK).exists():
        assert digest(HERE / BOOK) == receipt['bookSHA256']
    assert receipt['candidateMaterialSHA256'] == digest(module)
    for name, expected in receipt['frozen'].items():
        if name != BOOK:
            assert manifest['files'][name] == expected, name
    for name in ('src/Solver/CCoupledNewtonSolver.cls', 'src/Solver/CCoupledElasticState.cls',
                 'src/Materials/CCoupledConcreteResponse.cls', 'src/Materials/CCoupledReinforcedResponse.cls'):
        assert git_blob(repo, receipt['sourceGit'], name) == git_blob(repo, '6d42af5', name), name
    assert receipt['modules'] == ['CCoupledConcreteResponse', 'modTestKaniStage38']
    assert receipt['compileRetry'] == read_json(HERE / 'FailedCompile/RetryReceipt.json')
    failed = receipt['compileRetry']
    fail_log = (HERE / 'FailedCompile/Native/Compile.log').read_text(encoding='utf-8-sig')
    assert re.findall(r'^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$', fail_log, re.M) == [
        (str(failed['failedCompilationPID']), failed['failedCompilationTicksUTC'])]
    assert 'COMPILE_LOCATION: module=modTestKaniStage38; line=464; column=65' in fail_log
    assert not failed['macroOpened'] and failed['failedOwnerObservedState'] == 'Absent'
    assert failed['attemptedDraftSHA256'] == receipt['bookSHA256']
    assert failed['initialMacroSHA256'] == digest(HERE / 'FailedCompile/modTestKaniStage38.Original.bas')
    assert failed['initialPreparationSHA256'] == digest(HERE / 'FailedCompile/Preparation.Original.json')
    return receipt


def compare(expected, actual, label='result'):
    if isinstance(expected, dict):
        assert set(expected) == set(actual), label
        for key, value in expected.items():
            compare(value, actual[key], f'{label}.{key}')
    elif isinstance(expected, list):
        assert len(expected) == len(actual), label
        for index, (left, right) in enumerate(zip(expected, actual)):
            compare(left, right, f'{label}[{index}]')
    elif isinstance(expected, float):
        assert math.isclose(expected, actual, rel_tol=2e-11, abs_tol=5e-13), (label, expected, actual)
    else:
        assert expected == actual, (label, expected, actual)


def verifier_namespace(receipt, manifest):
    def read_support(repo, name):
        data = git_blob(repo, receipt['sourceGit'], f'{ARTIFACT_ROOT}/{name}')
        assert digest(data) == receipt['supportArchives'][name]
        return ZipFile(BytesIO(data))

    def read_private_sha():
        compiled = manifest['compiledPrivateWorkbookSHA256']
        result = (HERE / 'Native/KaniV4.txt').read_text(encoding='utf-8-sig')
        assert re.findall(r'^SOURCE_SHA256: ([0-9A-F]{64})$', result, re.M) == [compiled]
        if (HERE / DRAFT).exists():
            assert digest(HERE / DRAFT) == compiled
        return compiled

    def detached_alternate(source, namespace):
        # The original numerical reconstruction remains literal. Only resolve
        # historical blobs and the independently recorded private-book identity.
        before = "assert book['WorkbookSHA256'] == P['sha'](H / P['draft']) == own['SourceSHA256']"
        assert source.count(before) == 1
        source = source.replace(before, "assert book['WorkbookSHA256'] == _read_private_sha() == own['SourceSHA256']")
        before = "P = runpy.run_path(H / 'Prepare-Alt.py')"
        assert source.count(before) == 1
        source = source.replace(before, "P = {'open_art': _read_support}")
        namespace.update(_read_private_sha=read_private_sha, _read_support=read_support)
        file = namespace['__file__']
        exec(compile(source, file, 'exec'), namespace)

    file = HERE / 'Verify.py'
    source = file.read_text(encoding='utf-8-sig')
    before = "    exec(compile(source,str(f),'exec'),ns)"
    assert source.count(before) == 1
    source = source.replace(before, '    _detached_alternate(source, ns)')
    before = "H/'ChartComparison.json'"
    assert source.count(before) == 1
    source = source.replace(before, "H/'Replay-ChartComparison.json'")
    namespace = {'__file__': str(file), '__name__': 'portable_chart', '_detached_alternate': detached_alternate}
    exec(compile(source, str(file), 'exec'), namespace)
    namespace['P']['check'] = lambda repo: receipt
    return namespace


def replay(repo):
    manifest = read_json(HERE / 'Manifest.json')
    assert manifest['schema'] == SCHEMA
    for name, expected in manifest['files'].items():
        assert digest(HERE / name) == expected, name
    receipt = checked_preparation(repo, manifest)
    for name, expected in receipt['supportArchives'].items():
        assert digest(git_blob(repo, receipt['sourceGit'], f'{ARTIFACT_ROOT}/{name}')) == expected
    result = verifier_namespace(receipt, manifest)['verify'](repo)
    compare(read_json(HERE / 'ChartComparison.json'), result)
    failed = {}
    for name in ('NewtonD', 'TinyOnAxis', 'OffAxis'):
        state = result['independentStates'][name]
        failed[name] = {unit: value for unit, value in zip(
            ('N', 'Mx', 'My', 'T', 'Qx', 'Qy'), state['forceCapOvershootMPa']) if value > 2e-10}
        assert not state['withinOriginalRule']
    assert not failed['NewtonD'] and not failed['TinyOnAxis'] and set(failed['OffAxis']) == {'Qx', 'Qy'}
    assert result['exactAcceptedHistoryRestored']
    print(json.dumps({'equilibriumAtAllThreeTrials': False, 'forceCapOvershoot_MPa': failed,
                      'exactH45Restored': True, 'ownedExcelClosure': result['closedExcel']}, indent=2))


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--repo-root', type=Path, required=True)
    replay(parser.parse_args().repo_root.resolve())
