"""Rebuild 89+5 for all measured fixed fields and compare six separate force caps."""
from argparse import ArgumentParser
from pathlib import Path
import json
import runpy
import numpy as np

H=Path(__file__).resolve().parent
P=runpy.run_path(H/'Prepare.py')
ACTIVE=('NewtonD','TinyOnAxis','OffAxis')
COMMITTED=('Base45','End45','Restore45')
GROUPS={'K59C_VECTOR':89,'K59C_STATE':99,'CHECK':4}


def independent(q,T,measure,geo,ops):
    h,sh,g,projection,w,scale=ops
    x=q[2:]
    lam,alpha=q[:2]
    strain=h@x[:79]+np.array([-.001,0.,.001])[:,None,None]*(h[:,:,:4]@x[79:83])[None]
    assert max(abs(strain-T[:,:,:6]).ravel())<2e-12
    sigma=T[:,:,6:]
    ds=(sigma[2]-sigma[0])/.002
    weak=np.einsum('nij,ni,n->j',h,sigma[1],w)+g.T@x[83:]
    weak[4:]-=np.einsum('nk,na,n->ka',sh,ds[:,[4,5,2]],w).ravel()
    along=np.einsum('nij,ni,n->j',h[:,:,:4],ds,w)
    along[1]-=lam*1e5/scale[0]
    forces=np.einsum('nij,nj,n->i',projection,sigma[1],geo[:,2])
    force=np.r_[weak,along,(forces-np.r_[np.zeros(5),lam*1e5])/scale]
    c=25600*np.r_[g@x[:79],measure@x-alpha]
    assert force.size==89 and c.size==5
    return force,c,forces


def verify(repo):
    prep=P['check'](repo)
    f=H/'Verify-Alt.py'
    source=f.read_text(encoding='utf-8-sig')
    source=source.replace("assert book['Modules'] == ['modTestKaniStage38']",
                          "assert sorted(book['Modules']) == ['CCoupledConcreteResponse','modTestKaniStage38']")
    source=source.replace('TOTAL_KANI_V4_STAGE38: passed=1; failed=0','TOTAL_KANI_CHART_FIELDS: passed=3; failed=0')
    ns={'__file__':str(f),'__name__':'kani_chart_verifier'}
    exec(compile(source,str(f),'exec'),ns)
    closure=ns['verify_closure'](prep)
    data={k:{} for k in GROUPS}
    for kind,tag,*row in ns['csv_rows'](H/'Native/KaniV4Trace.csv'):
        assert len(row)==GROUPS[kind] and tag not in data[kind]
        data[kind][tag]=np.array(row,float)
    assert all(set(a)==set(ACTIVE+COMMITTED) for a in data.values())
    q,state,checks=(data[k] for k in GROUPS)
    tens,branches,F,energy=ns['read_material'](q)
    for stream in (q,state,checks,tens,branches,F,energy):
        assert all(np.array_equal(stream['Base45'],stream[k]) for k in COMMITTED)
    history,old,build,_=ns['archived_inputs'](repo)
    i=list(history['names']).index('Committed45')
    assert q['Base45'][0]==history['fields'][i,0] and np.array_equal(q['Base45'][2:],history['fields'][i,2:])
    assert np.array_equal(tens['Base45'],history['stations'][history['station_index'][i]])
    assert np.array_equal(energy['Base45'],np.array(old['energiesByStation_minus0plus']['Committed45']))
    geo=history['geometry']
    ops=build(geo,float(history['length']))
    measure=np.array((H/'H45DiscriminatingControl.csv').read_text().strip().split(';')[5:],float)
    src={}
    for _,tag,lam,alpha,*field in ns['csv_rows'](H/'KaniChartFields.csv'):
        src[tag]=np.array([lam,alpha,*field],float)
    assert set(src)==set(ACTIVE)
    archived=json.loads((H/'D-DampingAssessment.json').read_text(encoding='utf8'))
    forecast=json.loads((H/'SemismoothFeasibility.json').read_text(encoding='utf8'))['candidates']['sameRadiusHybridGuarded']
    tests={}
    for k in q:
        r,c,w=independent(q[k],tens[k],measure,geo,ops)
        s=state[k]
        norm=float(max(max(abs(r)),max(abs(c))))
        tau=5e-7+2e-8*abs(q[k][0])*1e5/ops[-1][0]
        assert abs(tau-s[3])<2e-20 and abs(s[2]-norm)<2e-10 and s[5]==1
        assert max(abs(r[:83]-s[12:95]))<2e-10 and abs(c[-1]-s[4])<2e-10
        assert max(abs((w-s[6:12])/ops[-1]))<2e-10
        if k in ACTIVE:
            assert max(abs(q[k][2:]-src[k][2:]))<8e-16 and abs(q[k][0]-src[k][0])<3e-14
            assert abs(q[k][1]-src[k][1])<2e-16
        else:
            assert norm<=prep['originalTauMPa']
        if k in ('NewtonD','TinyOnAxis'):
            ref=archived['independentSectionStates']['Base' if k=='NewtonD' else 'Plus16']
            assert max(abs(r-ref['all89ForceRowsMPa']))<2e-10 and max(abs(c-ref['allFiveControlsMPa']))<2e-10
        tests[k]={'all89ForceRowsMPa':r.tolist(),'allFiveControlsMPa':c.tolist(),'integratedSixWrenches_N_Nmm':w.tolist(),
                  'normMPa':norm,'QyResultant_N':float(w[-1]),'QyApplied_N':float(q[k][0]*1e5),
                  'row81MPa':float(r[80]),'gaugeMaximumMPa':float(max(abs(c[:4]))),
                  'actualYieldSignChangesFromD':int(np.count_nonzero((F[k]>0)!=(F['NewtonD']>0))),
                  'actualMaterialBranchChangesFromD':int(np.count_nonzero(np.any(branches[k]!=branches['NewtonD'],axis=2))),
                  'withinOriginalRule':bool(norm<=tau)}
    caps=np.abs(tests['NewtonD']['all89ForceRowsMPa'][83:])
    for k in ACTIVE:
        vals=np.abs(tests[k]['all89ForceRowsMPa'][83:])
        tests[k]['capsFromAbsoluteD_N_Mx_My_T_Qx_Qy_MPa']=caps.tolist()
        tests[k]['actualForceResidualAbsoluteMPa']=vals.tolist()
        tests[k]['allSixCapsVerified']=bool(np.all(vals<=caps+2e-10))
        tests[k]['forceCapOvershootMPa']=(vals-caps).tolist()
    base=tests['NewtonD']['normMPa']
    result={'workbookSHA256':prep['bookSHA256'],'exactAcceptedHistoryRestored':True,'closedExcel':closure,
            'frozenCommitTauMPa':prep['originalTauMPa'],'planApproximateNormMPa':forecast['predictedNormMPa'],
            'planApproximateRow81ActionMPa':forecast['hybridRow81_MPAdelta']['estimatedTotalMPa'],
            'deltaNormFromD_MPa': {k:tests[k]['normMPa']-base for k in ACTIVE},
            'independentStates':tests}
    saved=H/'ChartComparison.json'
    saved.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print('CHART_PASS',P['sha'](saved),{k:(tests[k]['normMPa'],tests[k]['allSixCapsVerified']) for k in ACTIVE})
    return result


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    a=p.parse_args()
    verify(a.repo_root.resolve())
