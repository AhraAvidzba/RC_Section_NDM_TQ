Attribute VB_Name = "modTestKaniStage38"
Option Explicit

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет одну меру управления от точной принятой истории Kani H45.
Private Const KaniEcTest As Double = 25600#
Private Const KaniForceTest As Double = 100000#
Private Const KaniAbsTest As Double = 0.0000005
Private Const KaniRelTest As Double = 0.00000002
Private Const KaniSizeTest As Long = 87
Private Const KaniPhysicalTest As Long = 83
Private Const KaniPointsTest As Long = 184

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит H45, проверяет нулевой шаг, выполняет одну конечную пробу и восстанавливает H45.
Public Function RunTestKaniStage38(ByVal historyPath As String) As String
    Dim trace As Integer, stations As Integer, tangents As Integer
    Dim status As String, label As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга Kani V4."

    Dim history As New Collection, gamma() As Double, factors() As Double, target As Double
    ReadKaniStage38InputTest historyPath, history, gamma, factors, target
    Dim section As CSectionModel, layout As CTransverseRebarLayout, steel As Object
    Set section = BuildKaniStage38SectionTest(layout, steel)
    Dim operators As New CCoupledElasticState, solver As New CCoupledNewtonSolver
    Dim concrete(-1 To 1) As CCoupledConcreteResponse, materials(-1 To 1) As CCoupledReinforcedResponse
    operators.PrepareModel section, KaniEcTest, 0.2, 2, 2, 6, layout, steelModels:=steel
    If operators.DegreeCount <> KaniSizeTest Or operators.PointCount <> KaniPointsTest Or operators.ConcretePointCount <> 144 Then _
        Err.Raise 5, , "Квадратура Kani V4 не совпадает с контрольной."
    Dim side As Long, gt As Double
    gt = 0.073 * 28.2 ^ 0.18
    For side = -1 To 1
        Set concrete(side) = New CCoupledConcreteResponse
        concrete(side).Initialize KaniPointsTest, KaniEcTest, 0.2, 0.6 * 28.2, 28.2, 1.75, 0.0022, gt, (28.2 / 1.75) ^ 2 * gt, 125#
        Set materials(side) = New CCoupledReinforcedResponse
        materials(side).Initialize operators, concrete(side), steel
    Next side
    solver.Initialize operators, materials(0), KaniEcTest, materials(1), materials(-1)
    Dim projectionX() As Double, projection() As Double
    operators.MeanShearProjections projectionX, projection

    trace = FreeFile: Open ThisWorkbook.Path & "\KaniV4Trace.csv" For Output As #trace
    stations = FreeFile: Open ThisWorkbook.Path & "\KaniV4Stations.csv" For Output As #stations
    tangents = FreeFile: Open ThisWorkbook.Path & "\KaniV4Tangents.csv" For Output As #tangents
    Dim rootPath As String: rootPath = Left$(historyPath, InStrRev(historyPath, "\"))
    Dim entries As New Collection, historyFactors(38 To 45) As Double
    ReadKaniGaugeInputTest rootPath & "KaniGaugeInput.csv", entries, history, historyFactors
    If solver.PhysicalDegreeCount <> KaniPhysicalTest Then Err.Raise 5, , "Не совпало число механических координат."
    Dim actual(1 To 6) As Double, offset(1 To 6) As Double, direction(1 To 6) As Double
    direction(6) = KaniForceTest
    Dim alt() As Double, base() As Double, trial() As Double, forces() As Double
    Dim seedAlpha As Double, targetAlpha As Double, stepAlpha As Double, measuredAlpha As Double, baseLambda As Double
    Dim returned As Double, rawNorm As Double, errLambda As Double, steelUse As Double, idx As Long
    Dim solved As Boolean, adjoint As Boolean, diag As String, resultCode As Long, internalCode As Long
    ReadKaniAlternativeControlTest rootPath & "H45DiscriminatingControl.csv", alt, seedAlpha, targetAlpha, stepAlpha
    WriteKaniChartVectorTest trace, "PROJECTION;Mean", projection
    WriteKaniChartVectorTest trace, "PROJECTION;Alternative", alt
    If Not solver.ReplayAcceptedFields(history, 45) Then Err.Raise 5, , "Не восстановлена история 45."
    base = history(45): baseLambda = historyFactors(45): measuredAlpha = KaniChartCoordinateTest(alt, base)
    If Abs(measuredAlpha - seedAlpha) > 0.0000000000000001 Then Err.Raise 5, , "Исходная координата H45 изменилась."
    RequireKaniStage38FieldTest solver, base
    rawNorm = SnapshotKaniStage38Test("Base45", operators, solver, materials, alt, base, _
              measuredAlpha, baseLambda, 0#, False, trace, stations, tangents, actual)
    If rawNorm > KaniStage38ToleranceTest(operators, baseLambda) Then Err.Raise 5, , "Нарушено равновесие исходного поля."
    WriteKaniAcceptedDamageTest "Base45", concrete, tangents
    WriteKaniTrialYieldTest "Base45", operators, concrete, base, tangents
    ' Нулевая проба повторяет запас по нагрузке при той же принятой истории и новой мере.
    If Not solver.TryDeformationStep(offset, direction, alt, measuredAlpha, baseLambda, returned, _
             KaniAbsTest, KaniRelTest, 1, consistentControl:=True) Then Err.Raise 5, , "Нулевая проба по новой мере не сходится."
    solver.CopyTrial trial, forces
    diag = solver.ResultMeta.DiagnosticDetails
    If Not MechanicsExactFieldTest(trial, base, returned, baseLambda, diag) Then Err.Raise 5, , "Нулевая проба изменила поле."
    If Not solver.TrialLambdaUncertainty(KaniAbsTest, KaniRelTest, errLambda) Then _
        Err.Raise 5, , "Недоступна исходная сопряжённая оценка для новой меры."
    Print #trace, "ADJOINT;Zero45;1;" & Str$(errLambda)
    Print #trace, "DIAGNOSTIC;Zero45;" & Replace(Replace(Replace(diag, ";", "|"), vbCr, " "), vbLf, " ")
    rawNorm = SnapshotKaniStage38Test("Zero45", operators, solver, materials, alt, trial, _
              measuredAlpha, returned, 0#, False, trace, stations, tangents, actual)
    solver.DiscardStep
    RequireKaniStage38FieldTest solver, base
    Print #trace, "MEASUREMENT;Control;" & Str$(measuredAlpha) & ";" & Str$(targetAlpha) & ";" & Str$(stepAlpha) & ";" & Str$(baseLambda)
    ' Единственное ненулевое продолжение. Исходное поле берётся из точной принятой истории.
    solved = solver.TryDeformationStep(offset, direction, alt, targetAlpha, baseLambda, returned, _
                   KaniAbsTest, KaniRelTest, 12, consistentControl:=True)
    diag = solver.ResultMeta.DiagnosticDetails: resultCode = solver.ResultMeta.ResultCode: internalCode = solver.ResultMeta.InternalStatus
    Print #trace, "STATUS;Right;" & CStr(Abs(CLng(solved))) & ";" & CStr(internalCode) & ";" & CStr(resultCode)
    Print #trace, "DIAGNOSTIC;Right;" & Replace(Replace(Replace(diag, ";", "|"), vbCr, " "), vbLf, " ")
    If solved Then
        solver.CopyTrial trial, forces
        For idx = -1 To 1
            If materials(idx).TrialSteelUtilization > steelUse Then steelUse = materials(idx).TrialSteelUtilization
        Next idx
        rawNorm = SnapshotKaniStage38Test("Right", operators, solver, materials, alt, trial, _
                  targetAlpha, returned, 0#, False, trace, stations, tangents, actual)
        If rawNorm > KaniStage38ToleranceTest(operators, returned) Then Err.Raise 5, , "Конечная проба не прошла независимый допуск."
        WriteKaniTrialYieldTest "Right", operators, concrete, trial, tangents
        Print #trace, "RIGHT;Values;" & Str$(returned) & ";" & Str$(KaniChartCoordinateTest(alt, trial)) & ";" & _
                      Str$(KaniChartCoordinateTest(projection, trial)) & ";" & Str$(steelUse)
        errLambda = 0#
        adjoint = solver.TrialLambdaUncertainty(KaniAbsTest, KaniRelTest, errLambda)
        Print #trace, "ADJOINT;Right;" & CStr(Abs(CLng(adjoint))) & ";" & Str$(errLambda)
    End If
    solver.DiscardStep
    RequireKaniStage38FieldTest solver, base
    rawNorm = SnapshotKaniStage38Test("End45", operators, solver, materials, alt, base, _
              measuredAlpha, baseLambda, 0#, False, trace, stations, tangents, actual)
    If rawNorm > KaniStage38ToleranceTest(operators, baseLambda) Then Err.Raise 5, , "Проба изменила принятое равновесие."
    WriteKaniAcceptedDamageTest "End45", concrete, tangents
    WriteKaniTrialYieldTest "End45", operators, concrete, base, tangents
    If Not solver.ReplayAcceptedFields(history, 45) Then Err.Raise 5, , "Не восстановлена история H45 после пробы."
    RequireKaniStage38FieldTest solver, base
    rawNorm = SnapshotKaniStage38Test("Restore45", operators, solver, materials, alt, base, _
              measuredAlpha, baseLambda, 0#, False, trace, stations, tangents, actual)
    If rawNorm > KaniStage38ToleranceTest(operators, baseLambda) Then Err.Raise 5, , "После восстановления нарушено равновесие."
    WriteKaniAcceptedDamageTest "Restore45", concrete, tangents
    WriteKaniTrialYieldTest "Restore45", operators, concrete, base, tangents
    Close #tangents: tangents = 0
    Close #stations: stations = 0
    Close #trace: trace = 0
    RunTestKaniStage38 = "TOTAL_KANI_V4_STAGE38: passed=1; failed=0"
    Exit Function
Failed:
    status = Err.Source & " " & Err.Description
    On Error Resume Next
    If tangents > 0 Then Close #tangents
    If stations > 0 Then Close #stations
    If trace > 0 Then Close #trace
    RunTestKaniStage38 = "RUNTIME ERROR: " & status
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает последовательность исходных полей с точными контрольными деформациями.
Private Sub ReadKaniStage38InputTest(ByVal path As String, ByVal history As Collection, ByRef gamma() As Double, _
        ByRef factors() As Double, ByRef target As Double)
    Dim file As Integer, line As String, parts() As String, index As Long, i As Long
    Dim errorNumber As Long, errorText As String
    On Error GoTo Failed
    ReDim gamma(1 To 37): ReDim factors(1 To 37)
    file = FreeFile: Open path For Input As #file
    Line Input #file, line
    parts = Split(line, ";")
    If UBound(parts) <> 2 Or parts(0) <> "KANI_V4" Or parts(1) <> "37" Then Err.Raise 5, , "Неверная шапка истории Kani."
    target = Val(parts(2))
    For index = 1 To 37
        Line Input #file, line
        parts = Split(line, ";")
        If UBound(parts) <> KaniSizeTest + 3 Or parts(0) <> "FIELD" Or CLng(parts(1)) <> index Then _
            Err.Raise 5, , "Неверный порядок полей Kani."
        gamma(index) = Val(parts(2)): factors(index) = Val(parts(3))
        If gamma(index) <= 0# Or factors(index) <= 0# Then Err.Raise 5, , "Неверная контрольная нагрузка Kani."
        If index > 1 Then
            If gamma(index) <= gamma(index - 1) Then Err.Raise 5, , "Сдвиг Kani перестал возрастать."
        End If
        Dim field() As Double, item As Variant
        ReDim field(1 To KaniSizeTest)
        For i = 1 To KaniSizeTest: field(i) = Val(parts(i + 3)): Next i
        item = field
        history.Add item
    Next index
    If Not EOF(file) Or target <= gamma(37) Then Err.Raise 5, , "Неполный маршрут Kani."
    Close #file
    Exit Sub
Failed:
    errorNumber = Err.Number: errorText = Err.Description
    If file > 0 Then Close #file
    Err.Raise errorNumber, "ReadKaniStage38InputTest", errorText
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет, что исходное принятое поле сохранилось после повтора или сброса.
Private Sub RequireKaniStage38FieldTest(ByVal solver As CCoupledNewtonSolver, ByRef expected() As Double)
    Dim actual() As Double, i As Long
    solver.CopyAccepted actual
    For i = 1 To KaniSizeTest
        If actual(i) <> expected(i) Then Err.Raise 5, , "Принятое поле Kani изменилось."
    Next i
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Повторяет слабые уравнения и интегралы. Для сопряжённой сверки сохраняет штатную диагностическую матрицу до принятия.
Private Function SnapshotKaniStage38Test(ByVal label As String, ByVal operators As CCoupledElasticState, _
        ByVal solver As CCoupledNewtonSolver, ByRef materials() As CCoupledReinforcedResponse, _
        ByRef projection() As Double, ByRef field() As Double, ByVal target As Double, ByVal lambda As Double, _
        ByVal bound As Double, ByVal bounded As Boolean, ByVal trace As Integer, ByVal stations As Integer, _
        ByVal tangents As Integer, ByRef forces() As Double, Optional ByRef equations As Variant) As Double
    Dim residual() As Double, matrix() As Double, applied() As Double, expected(1 To 6) As Double
    Dim recordMatrix As Boolean: recordMatrix = Right$(label, 6) = "/Trial"
    If Not solver.TestEquilibriumLinearization(field, recordMatrix, False, residual, matrix) Then _
        Err.Raise 5, , "Не вычислено повторное равновесие " & label
    If recordMatrix Then WriteKaniStage38MatrixTest label, matrix, projection, operators, tangents

    Dim material As ICoupledPointResponse, strain(1 To 6) As Double, gradient(1 To 6) As Double, stationStrain(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double, row As String
    Dim plasticIncrement As Boolean, principalSign As Long, substeps As Long
    For i = 1 To 6: forces(i) = 0#: Next i
    For point = 1 To KaniPointsTest
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, gradient
        For side = -1 To 1
            Set material = materials(side)
            For i = 1 To 6: stationStrain(i) = strain(i) + CDbl(side) * 0.001 * gradient(i): Next i
            If material.EvaluatePoint(point, stationStrain, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Недоступна материальная точка Kani " & CStr(point)
            row = "K59C_STATION;" & label & ";" & CStr(point) & ";" & CStr(side)
            For i = 1 To 6: row = row & ";" & Str$(stationStrain(i)): Next i
            For i = 1 To 6: row = row & ";" & Str$(stress(i)): Next i
            Print #stations, row
            If Not materials(side).TryReadConcreteBranch(point, stationStrain, plasticIncrement, principalSign, substeps) Then _
                Err.Raise 5, , "Не определена ветвь бетона в материальной станции " & CStr(point)
            Print #tangents, "BRANCH;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                             CStr(Abs(CLng(plasticIncrement))) & ";" & CStr(principalSign) & ";" & CStr(substeps)
            If side = 0 Then
                forces(1) = forces(1) + area * stress(3)
                forces(2) = forces(2) + area * y * stress(3)
                forces(3) = forces(3) + area * x * stress(3)
                forces(4) = forces(4) + area * (x * stress(6) - y * stress(5))
                forces(5) = forces(5) + area * stress(5)
                forces(6) = forces(6) + area * stress(6)
            End If
        Next side
    Next point
    expected(6) = KaniForceTest * lambda
    operators.LoadEquations 0#, 0#, 0#, 0#, 0#, expected(6), applied
    Dim control As Double, tolerance As Double, norm As Double, gauges As Boolean, value As Double
    tolerance = KaniStage38ToleranceTest(operators, lambda)
    norm = operators.ResultantResidualNorm(forces, expected): gauges = True
    control = -target
    For i = 1 To KaniSizeTest
        residual(i) = residual(i) - applied(i)
        value = Abs(residual(i))
        If i <= KaniPhysicalTest Then
            control = control + projection(i) * field(i)
            If value > norm Then norm = value
        ElseIf value > tolerance / KaniEcTest Then
            gauges = False
        End If
    Next i
    control = control * KaniEcTest
    If Abs(control) > norm Then norm = Abs(control)
    If Not gauges Then Err.Raise 5, , "Нарушены кинематические связи " & label

    row = "K59C_STATE;" & label & ";" & Str$(target) & ";" & Str$(lambda) & ";" & Str$(norm) & _
        ";" & Str$(tolerance) & ";" & Str$(control) & ";" & CStr(Abs(CLng(gauges)))
    For i = 1 To 6: row = row & ";" & Str$(forces(i)): Next i
    For i = 1 To KaniSizeTest: row = row & ";" & Str$(residual(i)): Next i
    Print #trace, row
    row = "K59C_VECTOR;" & label & ";" & Str$(lambda) & ";" & Str$(target)
    For i = 1 To KaniSizeTest: row = row & ";" & Str$(field(i)): Next i
    Print #trace, row
    Dim center As CCoupledReinforcedResponse, hoop As Long, hoopStress As Double
    Set center = materials(0): hoop = center.AcceptedTransverseCriticalPoint
    If hoop > 0 Then hoopStress = center.AcceptedSteelStress(hoop)
    Print #trace, "CHECK;" & label & ";" & CStr(Abs(CLng(bounded))) & ";" & Str$(bound) & ";" & _
        Str$(hoopStress) & ";" & Str$(center.AcceptedSteelUtilization)
    If Not IsMissing(equations) Then equations = residual
    SnapshotKaniStage38Test = norm
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Добавляет к касательной столбец нагрузки и строку среднего сдвига.
Private Sub WriteKaniStage38MatrixTest(ByVal label As String, ByRef matrix() As Double, _
        ByRef projection() As Double, ByVal operators As CCoupledElasticState, ByVal file As Integer)
    Dim direction() As Double: operators.LoadEquations 0#, 0#, 0#, 0#, 0#, KaniForceTest, direction
    Dim row As String, i As Long, j As Long, rowScale As Double
    For i = 1 To KaniSizeTest
        rowScale = 1#
        If i > KaniPhysicalTest Then rowScale = KaniEcTest
        row = "MATRIX;" & label & ";" & CStr(i)
        For j = 1 To KaniSizeTest: row = row & ";" & Str$(rowScale * matrix(j, i)): Next j
        Print #file, row & ";" & Str$(-rowScale * direction(i))
    Next i
    row = "MATRIX;" & label & ";" & CStr(KaniSizeTest + 1)
    For j = 1 To KaniSizeTest: row = row & ";" & Str$(KaniEcTest * projection(j)): Next j
    Print #file, row & ";0"
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Вычисляет допуск возле подтверждённой силы для данной квадратуры.
Private Function KaniStage38ToleranceTest(ByVal operators As CCoupledElasticState, ByVal lambda As Double) As Double
    Dim area As Double, lengthScale As Double
    operators.CopyResultantResidualScales area, lengthScale
    KaniStage38ToleranceTest = KaniAbsTest + KaniRelTest * Abs(lambda) * KaniForceTest / area
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Воспроизводит геометрию Kani из исходного контрольного расчёта.
Private Function BuildKaniStage38SectionTest(ByRef layout As CTransverseRebarLayout, ByRef steel As Object) As CSectionModel
    Dim query As New CSectionGeometryQuery, region As New CGeometryRegion
    region.Initialize query.RegionFromPath(query.AdjacentRectangles("Kani_Outer", Array(Array(-152.5, -305#, 305#, 610#))))
    Dim mesh As New CFiberMeshBuilder, builder As New CSectionModelBuilder, section As CSectionModel
    mesh.BuildMesh region, 20#, 20#, cellGeometry:="Contour"
    Set section = builder.BuildFromGenerated(mesh, Nothing)
    region.BuildContours section.Contours
    Dim i As Long, x As Double
    For i = 0 To 3
        x = -105# + 70# * i
        section.AddRebarElement x, -254#, 25#, GEOM_PI * 156.25, "KANI_LONG"
        section.AddRebarElement x, 254#, 25#, GEOM_PI * 156.25, "KANI_LONG"
    Next i
    Set layout = New CTransverseRebarLayout
    layout.AddContourGroup section, "KANI_HOOP", vbNullString, 10#, 100#, 25#, "KANI_HOOP"
    Set steel = CreateObject("Scripting.Dictionary")
    Dim longitudinal As New CCoupledSteelModel, hoop As New CCoupledSteelModel
    longitudinal.Initialize 200000#, 442#, 442#, 0#, 0#, 0.05, 0.05
    hoop.Initialize 200000#, 400#, 400#, 0#, 0#, 0.05, 0.05
    steel.Add "KANI_LONG", longitudinal
    steel.Add "KANI_HOOP", hoop
    Set BuildKaniStage38SectionTest = section
End Function





' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает выбранную линейную координату по физическим компонентам поля.
Private Function KaniChartCoordinateTest(ByRef control() As Double, ByRef field() As Double) As Double
    Dim i As Long
    For i = 1 To KaniPhysicalTest: KaniChartCoordinateTest = KaniChartCoordinateTest + control(i) * field(i): Next i
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет фактический переданный вектор в инвариантной записи.
Private Sub WriteKaniChartVectorTest(ByVal file As Integer, ByVal label As String, ByRef values() As Double)
    Dim i As Long, rowText As String: rowText = label
    For i = LBound(values) To UBound(values): rowText = rowText & ";" & Str$(values(i)): Next i
    Print #file, rowText
End Sub



' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает локальные испытываемые поля, множители и точное новое состояние истории.
Private Sub ReadKaniGaugeInputTest(ByVal path As String, ByVal entries As Collection, _
        ByVal history As Collection, ByRef historyFactors() As Double)
    Dim number As Integer: number = FreeFile
    Dim rowText As String, terms As Variant, i As Long
    Dim field() As Double, levels() As Double, state As Long, entry As Variant
    Open path For Input As #number
    Do Until EOF(number)
        Line Input #number, rowText
        terms = Split(rowText, ";")
        If UBound(terms) <> 91 Or terms(0) <> "KANI_B_FIELD" Then
            Close #number
            Err.Raise 5, , "Некорректная строка входа испытания."
        End If
        ReDim field(1 To KaniSizeTest)
        ReDim levels(0 To 1)
        levels(0) = Val(terms(3)): levels(1) = Val(terms(91))
        For i = 1 To KaniSizeTest
            field(i) = Val(terms(i + 3))
        Next i
        If Left$(terms(1), 7) = "History" Then
            state = CLng(Mid$(terms(1), 8))
            If state <> history.Count + 1 Then Err.Raise 5, , "Нарушен порядок принятых состояний."
            entry = field: history.Add entry: historyFactors(state) = levels(1)
        Else
            entries.Add Array(field, levels)
        End If
    Loop
    Close #number
    If entries.Count <> 0 Or history.Count <> 45 Then Err.Raise 5, , "Не совпадает число контрольных полей."
End Sub
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Подтверждает совпадение всех заданных координат и множителя после допуска без итераций.
Private Function MechanicsExactFieldTest(ByRef trial() As Double, ByRef field() As Double, ByVal trialLambda As Double, _
        ByVal suppliedLambda As Double, ByVal diagnostic As String) As Boolean
    Dim index As Long
    If trialLambda <> suppliedLambda Or InStr(1, diagnostic, "Итерации: 0;", vbBinaryCompare) <> 1 Then Exit Function
    For index = 1 To KaniSizeTest
        If trial(index) <> field(index) Then Exit Function
    Next index
    MechanicsExactFieldTest = True
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает две нормированные энергии принятой точки, включая бетон, вытесненный сталью.
Private Sub WriteKaniAcceptedDamageTest(ByVal label As String, ByRef concrete() As CCoupledConcreteResponse, ByVal file As Integer)
    Dim point As Long, side As Long, tensionEnergy As Double, compressionEnergy As Double
    For side = -1 To 1
        For point = 1 To KaniPointsTest
            concrete(side).AcceptedPointDamage point, tensionEnergy, compressionEnergy
            Print #file, "ENERGY;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                         Str$(tensionEnergy) & ";" & Str$(compressionEnergy)
        Next point
    Next side
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает критерий по упругому предиктору от той же принятой истории, без вычисления градиента.
Private Sub WriteKaniTrialYieldTest(ByVal label As String, ByVal operators As CCoupledElasticState, _
        ByRef concrete() As CCoupledConcreteResponse, ByRef field() As Double, ByVal file As Integer)
    Dim point As Long, side As Long, i As Long, yieldValue As Double, unused() As Double
    Dim strain(1 To 6) As Double, gradient(1 To 6) As Double, localStrain(1 To 6) As Double
    For point = 1 To KaniPointsTest
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, gradient
        For side = -1 To 1
            For i = 1 To 6: localStrain(i) = strain(i) + CDbl(side) * 0.001 * gradient(i): Next i
            If Not concrete(side).TryReadTrialYield(point, localStrain, yieldValue, unused, needGradient:=False) Then _
                Err.Raise 5, , "Не записан критерий упругого предиктора " & CStr(point)
            Print #file, "YIELD;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & Str$(yieldValue)
        Next side
    Next point
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает замороженную физическую проекцию; реакции связей и траектории нагрузки в неё не входят.
Private Sub ReadKaniAlternativeControlTest(ByVal path As String, ByRef projection() As Double, _
        ByRef baseAlpha As Double, ByRef targetAlpha As Double, ByRef stepAlpha As Double)
    Dim f As Integer: f = FreeFile
    Dim row As String, x As Variant, j As Long
    Open path For Input As #f
    Line Input #f, row
    If Not EOF(f) Then
        Close #f
        Err.Raise 5, , "В файле меры больше одной строки."
    End If
    Close #f
    x = Split(row, ";")
    If UBound(x) <> 91 Or x(0) <> "KANI_ALT_CONTROL_H45" Or x(1) <> "StationProjectionFromLastAcceptedIncrement" Then _
        Err.Raise 5, , "Нарушена запись альтернативной меры."
    baseAlpha = Val(x(2)): targetAlpha = Val(x(3)): stepAlpha = Val(x(4))
    If stepAlpha <= 0# Or Abs((targetAlpha - baseAlpha) - stepAlpha) > 0.0000000000000001 Then _
        Err.Raise 5, , "Некорректен заданный шаг по альтернативной мере."
    ReDim projection(1 To KaniSizeTest)
    For j = 1 To KaniSizeTest
        projection(j) = Val(x(j + 4))
        If j > KaniPhysicalTest And projection(j) <> 0# Then Err.Raise 5, , "Мера затрагивает служебные множители."
    Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Снимает три заданных поля по одной точной принятой истории без новых итераций.
Public Function RunTestKaniChartFields(ByVal historyPath As String) As String
    Dim trace As Integer, stations As Integer, tangents As Integer, ingress As Integer
    Dim failure As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Требуется изолированная книга Kani."
    Dim history As New Collection, gamma() As Double, factors() As Double, target As Double
    ReadKaniStage38InputTest historyPath, history, gamma, factors, target
    Dim section As CSectionModel, layout As CTransverseRebarLayout, steel As Object
    Set section = BuildKaniStage38SectionTest(layout, steel)
    Dim operators As New CCoupledElasticState, solver As New CCoupledNewtonSolver
    Dim concrete(-1 To 1) As CCoupledConcreteResponse, materials(-1 To 1) As CCoupledReinforcedResponse
    operators.PrepareModel section, KaniEcTest, 0.2, 2, 2, 6, layout, steelModels:=steel
    If operators.DegreeCount <> KaniSizeTest Or operators.PointCount <> KaniPointsTest Or operators.ConcretePointCount <> 144 Then _
        Err.Raise 5, , "Квадратура Kani V4 не совпадает с контрольной."
    Dim side As Long, gt As Double
    gt = 0.073 * 28.2 ^ 0.18
    For side = -1 To 1
        Set concrete(side) = New CCoupledConcreteResponse
        concrete(side).Initialize KaniPointsTest, KaniEcTest, 0.2, 0.6 * 28.2, 28.2, 1.75, 0.0022, gt, (28.2 / 1.75) ^ 2 * gt, 125#
        Set materials(side) = New CCoupledReinforcedResponse
        materials(side).Initialize operators, concrete(side), steel
    Next side
    solver.Initialize operators, materials(0), KaniEcTest, materials(1), materials(-1)
    Dim rootPath As String: rootPath = Left$(historyPath, InStrRev(historyPath, "\"))
    Dim entries As New Collection, historyFactors(38 To 45) As Double
    Dim state() As Double, measure() As Double, alpha0 As Double, chartTarget As Double, alphaStep As Double
    Dim actual(1 To 6) As Double, q() As Double, loadFactor As Double, norm As Double, j As Long
    Dim names As Variant, fields As Variant, lineText As String, idx As Long, label As String
    ReadKaniGaugeInputTest rootPath & "KaniGaugeInput.csv", entries, history, historyFactors
    ReadKaniAlternativeControlTest rootPath & "H45DiscriminatingControl.csv", measure, alpha0, chartTarget, alphaStep
    If Not solver.ReplayAcceptedFields(history, 45) Then Err.Raise 5, , "Не восстановлена история H45."
    state = history(45): alpha0 = KaniChartCoordinateTest(measure, state)
    RequireKaniStage38FieldTest solver, state
    trace = FreeFile: Open ThisWorkbook.Path & "\KaniV4Trace.csv" For Output As #trace
    stations = FreeFile: Open ThisWorkbook.Path & "\KaniV4Stations.csv" For Output As #stations
    tangents = FreeFile: Open ThisWorkbook.Path & "\KaniV4Tangents.csv" For Output As #tangents
    norm = SnapshotKaniStage38Test("Base45", operators, solver, materials, measure, state, _
           alpha0, historyFactors(45), 0#, False, trace, stations, tangents, actual)
    If norm > KaniStage38ToleranceTest(operators, historyFactors(45)) Then Err.Raise 5, , "Нарушено исходное равновесие H45."
    WriteKaniAcceptedDamageTest "Base45", concrete, tangents
    WriteKaniTrialYieldTest "Base45", operators, concrete, state, tangents
    names = Array("NewtonD", "TinyOnAxis", "OffAxis")
    ingress = FreeFile: Open rootPath & "KaniChartFields.csv" For Input As #ingress
    For idx = LBound(names) To UBound(names)
        Line Input #ingress, lineText: fields = Split(lineText, ";")
        label = CStr(names(idx))
        If UBound(fields) <> 90 Or fields(0) <> "KANI_CHART" Or fields(1) <> label Then _
            Err.Raise 5, , "Неверная строка поля контрольной поправки."
        loadFactor = Val(fields(2))
        If loadFactor <= 0# Or Abs(Val(fields(3)) - chartTarget) > 0.0000000000000002 Then _
            Err.Raise 5, , "Изменилась заданная мера или нагрузка."
        ReDim q(1 To KaniSizeTest)
        For j = 1 To KaniSizeTest: q(j) = Val(fields(j + 3)): Next j
        norm = SnapshotKaniStage38Test(label, operators, solver, materials, measure, q, _
               chartTarget, loadFactor, 0#, False, trace, stations, tangents, actual)
        WriteKaniTrialYieldTest label, operators, concrete, q, tangents
        RequireKaniStage38FieldTest solver, state
    Next idx
    If Not EOF(ingress) Then Err.Raise 5, , "В контрольном вводе остались поля."
    Close #ingress: ingress = 0
    norm = SnapshotKaniStage38Test("End45", operators, solver, materials, measure, state, _
           alpha0, historyFactors(45), 0#, False, trace, stations, tangents, actual)
    If norm > KaniStage38ToleranceTest(operators, historyFactors(45)) Then Err.Raise 5, , "Чтение поля нарушило H45."
    WriteKaniAcceptedDamageTest "End45", concrete, tangents
    WriteKaniTrialYieldTest "End45", operators, concrete, state, tangents
    If Not solver.ReplayAcceptedFields(history, 45) Then Err.Raise 5, , "Не восстановлена история после проб."
    RequireKaniStage38FieldTest solver, state
    norm = SnapshotKaniStage38Test("Restore45", operators, solver, materials, measure, state, _
           alpha0, historyFactors(45), 0#, False, trace, stations, tangents, actual)
    If norm > KaniStage38ToleranceTest(operators, historyFactors(45)) Then Err.Raise 5, , "Откат нарушил H45."
    WriteKaniAcceptedDamageTest "Restore45", concrete, tangents
    WriteKaniTrialYieldTest "Restore45", operators, concrete, state, tangents
    Close #tangents: tangents = 0
    Close #stations: stations = 0
    Close #trace: trace = 0
    RunTestKaniChartFields = "TOTAL_KANI_CHART_FIELDS: passed=3; failed=0"
    Exit Function
Failed:
    failure = Err.Source & " " & Err.Description
    On Error Resume Next
    If ingress > 0 Then Close #ingress
    If tangents > 0 Then Close #tangents
    If stations > 0 Then Close #stations
    If trace > 0 Then Close #trace
    RunTestKaniChartFields = "RUNTIME ERROR: " & failure
End Function
