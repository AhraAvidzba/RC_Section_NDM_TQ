"""Seal raw native Kani measurements, inputs and the detached verifier."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import json

HERE = Path(__file__).resolve().parent
BOOK = 'workbook/output/RC_Section_NDM.xlsm'
RAW = ('KaniV4Trace.csv', 'KaniV4Stations.csv', 'KaniV4Tangents.csv', 'KaniV4.txt',
       'KaniV4.txt.memory.json', 'KaniV4.txt.Ownership.json', 'KaniV4.txt.ProcessClosure.json',
       'KaniV4.txt.RunnerCleanup.json', 'KaniV4.txt.stdout.log', 'KaniV4.txt.stderr.log',
       'Compile.log', 'CompileClosure.json', 'Preflight.ndjson')


def digest(data):
    return sha256(data).hexdigest().upper()


def load(name):
    return json.loads((HERE / name).read_text(encoding='utf-8-sig'))


def pack():
    prep = load('Preparation.json')
    files = set(prep['frozen']) - {BOOK}
    files.update('Native/' + name for name in RAW)
    files.update(('Preparation.json', 'ChartComparison.json', 'docs/regression/CodeUpdate.json',
                  'Replay-Chart.py', 'Pack-Chart.py', 'Portable-README.md'))
    data = {name: (HERE / name).read_bytes() for name in sorted(files)}
    assert all(digest(data[name]) == expected for name, expected in prep['frozen'].items() if name != BOOK)
    assert digest(data['ChartComparison.json']) == 'A00ACB604757A6D1B4BC9F76B6DA3CFC1DE76F3C3270A8DF78CFB29F74E58441'
    assert not any(name.lower().endswith(('.xlsm', '.xlsx')) for name in data)
    native = load('docs/regression/CodeUpdate.json')
    assert native['ProductionSHA256'] == prep['bookSHA256']
    manifest = {'schema': 'KaniH45GuardedCorrection/v1', 'historicalGit': prep['sourceGit'],
                'sourceWorkbookSHA256': prep['bookSHA256'], 'compiledPrivateWorkbookSHA256': native['WorkbookSHA256'],
                'files': {name: digest(content) for name, content in data.items()}}
    data['Manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
    dest = HERE / 'Portable'
    dest.mkdir(exist_ok=True)
    archive = dest / 'KaniH45GuardedCorrectionPortable.zip'
    with ZipFile(archive, 'w', compression=ZIP_DEFLATED, compresslevel=9) as out:
        for name, content in data.items():
            out.writestr(ZipInfo(name, (2026, 11, 16, 0, 0, 0)), content,
                         compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist()) == set(data)
    print(archive, digest(archive.read_bytes()), archive.stat().st_size)


if __name__ == '__main__':
    pack()
