"""Prepare the single native fixed-H45 off-axis comparison, without Office."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import subprocess

H=Path(__file__).resolve().parent
TIP='f4741ae'
ART='docs/regression/Coupled6D'
BOOK='workbook/output/RC_Section_NDM.xlsm'
BOOK_SHA='8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF'
DRAFT='docs/regression/Diagnostic.xlsm'
CONCRETE='src/Materials/CCoupledConcreteResponse.cls'
SOLVER='src/Solver/CCoupledNewtonSolver.cls'
MACRO='tests/modTestKaniStage38.bas'
MODS=['CCoupledConcreteResponse','modTestKaniStage38']
D_SHA='648CEB7D037BD9E95D86BFF222EB9CEEB68BE914A61F085FACFBD67B96A9250B'
HIGH_SHA='4C53E92AA39250BCF9A35E7CAE08E57424DCB5FF0D9763EC6AA77C96BBBBDD56'
MAT_SHA='A8C4F9664F300A344C6047553D55FD9E589F3BB0ECEA3371BE1EAA4EDC22837B'
SOURCE_FILES=(SOLVER,CONCRETE,'src/Solver/CCoupledElasticState.cls','src/Materials/CCoupledReinforcedResponse.cls')


def sha(x):
    return sha256(x.read_bytes() if isinstance(x,Path) else x).hexdigest().upper()


def blob(repo,name,tip=TIP):
    return subprocess.check_output(['git','-C',str(repo),'cat-file','blob',tip+':'+name])


def put(n,b):
    dest=H/n
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(b)
    return sha(b)


def check(repo):
    x=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert sha(blob(repo,BOOK))==sha(repo/BOOK)==sha(H/BOOK)==x['bookSHA256']==BOOK_SHA
    for f in SOURCE_FILES:
        assert sha(blob(repo,f))==sha(blob(repo,f,'6d42af5'))
    assert x['modules']==MODS and sha(H/CONCRETE)==MAT_SHA
    assert {p.stem for loc in ('src','tests') for p in (H/loc).rglob('*') if p.is_file()}==set(MODS)
    assert all(sha(H/n)==d for n,d in x['frozen'].items())
    assert all(sha(repo/ART/n)==d for n,d in x['supportArchives'].items())
    return x


def stage(repo):
    assert H.is_relative_to((repo/'tmp').resolve())
    side=repo/ART/'KaniH45DLastDirectionPortable.zip'
    if not side.exists():
        side=H.parent/'kdr'/'Portable'/side.name
    chart=H.parent/'ksm'/'KaniDGuardedDirectionPortable.zip'
    assert sha(side)==D_SHA and sha(chart)==HIGH_SHA
    with ZipFile(side) as d, ZipFile(chart) as c:
        # Use the untouched §351 module donor, with the only additional entry being a read-only test.
        donor=repo/ART/'KaniH45AlternateControlPortable.zip'
        assert sha(donor)=='4A9CADBD73726D133E99B5EA1D58F1DB8DB574C45BC189470F8EEC856C911BD4'
        with ZipFile(donor) as main:
            base=main.read(MACRO).decode('utf-8-sig').replace('\r\n','\n')
        a=base.index('    Dim history As New Collection,'); b=base.index('    Dim projectionX() As Double,',a)
        helper=(H/'ChartEntry.bas.txt').read_text(encoding='utf-8-sig').replace('@@SETUP@@\n',base[a:b])
        data={k:d.read(k) for k in ('KaniV4Input.csv','KaniGaugeInput.csv','H45DiscriminatingControl.csv','Prepare-Alt.py',
                                 'D-DampingAssessment.json','Expected-SectionComparison.json',CONCRETE)}
        data['Verify-Alt.py']=d.read('AltVerifier.py')
        for name in ('SemismoothFeasibility.json','BoundedDField.csv'):
            data[name]=c.read(name)
        data[MACRO]=(base.rstrip()+'\n\n'+helper.rstrip()+'\n').replace('\n','\r\n').encode('utf8')
        frozen=json.loads(d.read('Preparation.json'))['frozen']
        for name in frozen:
            if name.startswith('tools/'):
                val=(repo/name).read_bytes()
                assert val.replace(b'\r\n',b'\n')==blob(repo,name).replace(b'\r\n',b'\n')
                data[name]=val
        # The supplied exact trial uses target α and signed λ for each 87-coordinate field.
        chart_base,chart_trial=data['BoundedDField.csv'].decode('ascii').splitlines()
        c0=chart_base.split(';')
        ctr=chart_trial.split(';')
        tiny=d.read('ShortDampingWitness.csv').decode('ascii').strip().split(';')
        assert len(c0)==len(ctr)==len(tiny)==91
        target=c0[3]
        data['KaniChartFields.csv']=(
            ';'.join(['KANI_CHART','NewtonD',c0[2],target,*c0[4:]])+'\r\n'+
            ';'.join(['KANI_CHART','TinyOnAxis',tiny[3],target,*tiny[4:]])+'\r\n'+
            ';'.join(['KANI_CHART','OffAxis',ctr[2],target,*ctr[4:]])+'\r\n').encode('ascii')
    data[BOOK]=blob(repo,BOOK)
    assert sha(data[BOOK])==BOOK_SHA
    assert sha(data[CONCRETE])==MAT_SHA
    m={name:put(name,res) for name,res in data.items()}
    put(DRAFT,data[BOOK])
    for sub in ('Native','Temp'):
        (H/sub).mkdir(exist_ok=True)
    for name in ('Prepare.py','Verify.py','Run.ps1','ChartEntry.bas.txt','README.md'):
        m[name]=sha(H/name)
    p={'sourceGit':TIP,'bookSHA256':BOOK_SHA,'candidateMaterialSHA256':MAT_SHA,
       'directionArchiveSHA256':D_SHA,'guardedChartArchiveSHA256':HIGH_SHA,
       'sectionTimeoutSeconds':110,'modules':MODS,'originalTauMPa':5.59190995944018e-7,
       'supportArchives':{'KaniCommitNear48Portable.zip':'EA0A80006AF81D99799B53FDCB75B18CDDE7B7DF730AB16039902F12C6431488',
                         'KaniPracticalProbe45Portable.zip':'4AC1F4D0256849A40E67192D7DBA77C1FAD0F58E4BB2773455B273B25069F113'},
       'frozen':dict(sorted(m.items()))}
    put('Preparation.json',(json.dumps(p,indent=2)+'\n').encode('utf8'))
    return check(repo)


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',required=True,type=Path)
    p.add_argument('--check',action='store_true')
    a=p.parse_args()
    (check if a.check else stage)(a.repo_root.resolve())
    print('SEALED_OFF_AXIS',sha(H/'Preparation.json'))
