"""Seal the diagnostic p23 event guide on the fixed target's own full Newton ray."""
import csv
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent/"mv26o"
PREP = "C69C67BCFF97D4273B8906D88549A0963CFFAAFEE58A8E39F96562F0B24423AC"
RAW = "0110D0BE67FC2A3D9A08881A3DE2CF08578C66C1AC4622529524EAF919BD1903"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MACRO = "tests/modTestCoupledExperiment.bas"
SOLVER = "src/Solver/CCoupledNewtonSolver.cls"
VERIFY = "Verify-MVT2ShearControlled.py"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name,raw):
    path = HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, name
    else:
        path.write_bytes(raw)
    return digest(raw)


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old,new)


def decoded(raw):
    return raw.decode("utf-8-sig").replace("\r\n","\n")


def encoded(raw):
    assert max(map(len,raw.splitlines())) < 1023
    return raw.replace("\n","\r\n").encode()


def witness(raw):
    assert digest(raw) == RAW
    rows = {}
    selected = ("B_OWN_VECTOR","B_OWN_CROSSING","B_OWN_STALL","B_OWN_STALL_META")
    for tag,*items in csv.reader(raw.decode("cp1251").splitlines(),delimiter=";"):
        if tag in selected:
            rows.setdefault(tag,[]).append(items)
    assert list(rows["B_OWN_CROSSING"][1][:4]) == ["Full","1","23","0"]
    return (json.dumps(rows,indent=2,ensure_ascii=False)+"\n").encode()


def overlay_solver(raw):
    src = decoded(raw)
    anchor = "Private mOwnYieldTraceTest As Integer ' Протокол штатной отклонённой поправки.\n"
    src = once(src,anchor,anchor+'''
Private mOwnFullReadyTest As Boolean, mOwnFullBudgetTest As Long ' Снимок и предел только для полной диагностической пробы.
Private mOwnFullStationTest As TYieldStation
Private mOwnFullFromTest() As Double, mOwnFullToTest() As Double
Private mOwnFullLambdaFromTest As Double, mOwnFullLambdaToTest As Double
''')
    anchor = '    mOwnYieldTraceTest = traceNumber\n'
    src = once(src,anchor,anchor+'    If traceNumber > 0 Then mOwnFullReadyTest = False\n')
    anchor = '            PrintOwnYieldCrossingTest "Full", fullCrossed, fullStation\n'
    src = once(src,anchor,anchor+'''            If fullCrossed Then
                mOwnFullReadyTest = True: mOwnFullStationTest = fullStation
                mOwnFullFromTest = field: mOwnFullToTest = fullTrial
                mOwnFullLambdaFromTest = lambda: mOwnFullLambdaToTest = lambda + correction(mDegreeCount + 1)
            End If
''')
    anchor = '    For iteration = 1 To YIELD_TRACE_ITERATIONS\n'
    src = once(src,anchor,anchor+'''        If mOwnFullBudgetTest > 0 And mIterations >= mOwnFullBudgetTest Then Exit Function
''')
    return encoded(src.rstrip()+"\n\n"+(HERE/"FullSolver.txt").read_text(encoding="utf-8"))


def overlay_macro(raw):
    src = decoded(raw)
    anchor = '    CaptureWangArcHistoryTest output, "OwnAfterExact", operators, materials, snapshot\n    RequireWangArcHistoryTest hSnapshot, snapshot\n'
    src = once(src,anchor,anchor+'''    RunWangOwnFullTest output, solver, operators, materials, responses, history, historyField, hFactor, _
        hSnapshot, projection, target, baseLoad, direction, ATOL, RTOL, MAX_ITERATIONS
''')
    return encoded(src.rstrip()+"\n\n"+(HERE/"FullTest.txt").read_text(encoding="utf-8"))


def main():
    raw = (BASE/"Preparation.json").read_bytes()
    assert digest(raw) == PREP
    parent = json.loads(raw)
    files = {"FullRayWitness.json":put("FullRayWitness.json",witness((BASE/"NativeResume/MVT2.csv").read_bytes()))}
    for name,expected in parent["inputs"].items():
        data = (BASE/name).read_bytes()
        assert digest(data) == expected
        if name == VERIFY:
            files["OwnBase.py"] = put("OwnBase.py",data)
            continue
        if name in ("Stage.py","README.txt"):
            continue
        if name == SOLVER:
            data = overlay_solver(data)
        if name == MACRO:
            data = overlay_macro(data)
        files[name] = put(name,data)
    for path in ("Stage.py","README.txt","FullTest.txt","FullSolver.txt",VERIFY):
        files[path] = digest((HERE/path).read_bytes())
    assert put("docs/regression/Diagnostic.xlsm",(HERE/BOOK).read_bytes()) == parent["book_sha256"]
    for folder in ("NativeResume","Temp"):
        (HERE/folder).mkdir(exist_ok=True)
    data = {**parent,"inputs":files,"base_own_preparation_sha256":PREP,"base_own_native_sha256":RAW}
    print(put("Preparation.json",(json.dumps(data,indent=2)+"\n").encode()))


if __name__ == "__main__":
    main()
