H26 diagnostic guide from the full version of its own fixed-control rejected Newton ray.

    python -B -X utf8 ReplayFullRayPortable.py --archives <repository>/docs/regression/Coupled6D

The fixture reconstructs the independently pinned stock rejected ray and preserves legacy
failure on its accepted damping fractions. The verified first uncut event gives a local
equilibrium guide, with its phase and physical direction independently checked. The guide
and exact original-curvature solve share the original iteration budget, including stock work.
The exact stiffness solve still fails. Accepted H26 material history is untouched and H24
is restored. Original workbook bytes are identified but deliberately omitted from the archive.
