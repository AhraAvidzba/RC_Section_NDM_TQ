H26 original fixed control. Diagnostic of the qualified p23 center event on its own full ray.

    python -B -X utf8 tmp/mv26p/Stage.py
    python -B -X utf8 tmp/mv26p/Verify-MVT2ShearControlled.py --inputs-only

After allocating an isolated Office slot and passing resource preflight:

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mv26p/Run-MVT2ShearControlled.ps1

Replay the exact stock directional failure at the ordinary fixed target. The original last-ray
path runs unchanged, with no qualified event and NumFail. Retain that status. Independently try
the production TraceYieldCrossing at the verified first event on the whole of that SAME original
Newton correction. Only an equilibrium guide with original six+56+4 checks, positive physical
advance, and distance from H26 no more than 1.5 times the last accepted secant can seed a retry.
The guide may lie outside the desired fixed control. A qualifying guide is used for one solve
at the unchanged fixed target. The 26-iteration allowance includes the original 15, the guide
and any final solve. Exact H26 and H24 histories are preserved; no diagnostic point is committed.
