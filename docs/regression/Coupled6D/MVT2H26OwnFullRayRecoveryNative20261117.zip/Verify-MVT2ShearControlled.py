"""Verify the actual full-ray yield guide, original fixed target, and iteration caps."""
import argparse
from collections import defaultdict
import json
from math import hypot
from pathlib import Path

import OwnBase as own
from OwnBase import prior, v

HERE = Path(__file__).resolve().parent


def prepare():
    inputs = own.prepare()
    frozen = v.read(HERE/"FullRayWitness.json")
    assert frozen["B_OWN_CROSSING"][0] == ["Last","0"]
    assert frozen["B_OWN_CROSSING"][1][:4] == ["Full","1","23","0"]
    return inputs,frozen


def verify(inputs,witness):
    result = own.verify(*inputs)
    assert len(result["trials"]) == 1 and not result["trials"][0]["returned_trial"]
    raw = v.read_native(own.NATIVE)
    for key,rows in witness.items():
        assert raw[key] == rows
    snapshots = prior.by_name(raw,"B_ARC_HISTORY")
    assert snapshots["FullGuideAfter"] == snapshots["FullExactAfter"] == snapshots["CommittedAttempt2"]
    frozen,stock,p,target = inputs
    prep,prefix,base24,old_stations,witnesses,_,_,load_scale,_ = frozen
    h25,h26 = [(prior.numbers(row[1:61]),float(row[0])) for row in witnesses]
    geometry = base24["geometry"]
    arc_normal,k,secant = prior.determine_normal(h26,h25,geometry,load_scale)
    measurements = prior.by_name(raw,"B_FULL_GATES")
    meta = prior.by_name(raw,"B_FULL_SOLVER")
    assert tuple(meta) in (("Guide",),("Guide","Exact"))
    success,before,extra,remain,time = meta["Guide"]
    assert success in ("0","1") and int(before)==result["trials"][0]["iterations"]==15
    assert int(extra)>=0 and int(remain)>=0 and int(before)+int(extra)+int(remain)==26
    panels = [{"mode":"Guide","legacy_locator_returned":success=="1","trace_iterations":int(extra),
               "iterations_remaining":int(remain),"seconds":float(time)}]
    if "Exact" in meta:
        solved,iterations,status,code,wall,*trace = meta["Exact"]
        assert solved in ("0","1") and 0<=int(iterations)<=int(remain)
        panels.append({"mode":"Exact","returned_on_original_target":solved=="1","iterations":int(iterations),
                       "internal_status":int(status),"result_code":int(code),"seconds":float(wall),"diagnostic":";".join(trace)})
    assert ("Guide" in measurements) == (success=="1")
    if len(panels)==2:
        assert ("Exact" in measurements) == panels[1]["returned_on_original_target"]
    raw_fields = prior.by_name(raw,"B_TANGENT_FIELD")
    residuals = v.vec(raw,"B_TANGENT_RESIDUAL")
    actuals = prior.by_name(raw,"B_BOUND_ACTUAL")
    native_forces = prior.by_name(raw,"B_FULL_ACTUAL")
    stations = defaultdict(dict)
    for label,point,side,*record in raw["B_TANGENT_STATION"]:
        stations[label][int(point),int(side)] = prior.numbers(record)
    chosen = v.vec(raw,"B_OWN_PROJECTION")["Original"]
    eligible = False
    for panel in panels:
        mode = panel["mode"]
        if mode not in measurements:
            continue
        factor,native_norm,tol,fixed_advance,signed_arc,arc_distance,source_length,decision = prior.numbers(measurements[mode])
        label = "Full"+mode
        hcount, qy,*q = raw_fields[label]
        assert hcount=="26" and float(qy)==factor
        q = prior.numbers(q)
        difference = v.diff(q,h26[0])
        load_advance = factor-h26[1]
        assert geometry=={key:row[:3] for key,row in stations[label].items()}
        d = hypot(*prior.station_metric(difference,geometry),load_scale*load_advance)
        signed = v.dot(difference,arc_normal)+k*load_advance
        v.near(arc_distance,d,4e-15)
        v.near(signed_arc,signed,4e-15)
        v.near(fixed_advance,v.dot(difference,chosen),4e-15)
        v.near(source_length,secant,4e-15)
        rows,forces,strain_err = v.reconstruct(q,factor,stations[label])
        assert strain_err<4e-15 and v.peak(v.diff(rows,residuals[label]))<3e-10
        assert len(actuals[label])==6
        assert v.peak(x/s for x,s in zip(v.diff(forces,prior.numbers(actuals[label])),v.SCALES,strict=True))<4e-12
        signed_error = v.diff(forces,v.force(factor))
        force_norm = v.peak(x/s for x,s in zip(signed_error,v.SCALES,strict=True))
        gauge = tuple(x*v.MODULUS for x in rows[56:])
        norm = max(v.peak(rows[:56]),force_norm,v.peak(gauge))
        v.near(native_norm,norm,4e-10)
        v.near(tol,5e-7*(1+v.peak(v.loading(factor))),2e-18)
        control = (v.dot(chosen,q)-result["fixed_target"])*v.MODULUS
        local = signed>0. and d<=1.5*secant
        if mode=="Guide":
            assert decision in (0.,1.)
            eligible = norm<=tol and local and int(remain)>0
            assert bool(decision)==eligible
        else:
            assert panel["internal_status"]==4 and panel["result_code"]==0
            v.near(control,decision,3e-10)
            assert norm<=tol and abs(control)<=tol and len(native_forces["Exact"])==6
            assert v.peak(x/s for x,s in zip(v.diff(forces,prior.numbers(native_forces["Exact"])),v.SCALES,strict=True))<4e-12
        panel.update({"Qy_kN":factor,"delta_Qy_from_H26_N":1000*load_advance,"fixed_control_increase":fixed_advance,
                      "signed_physical_advance":signed,"physical_length_over_H25_H26_distance":d/secant,
                      "local_forward":local,"residual_to_original_control_MPa":control,"norm_over_original_tau":norm/tol,
                      "original_force_errors_N_Nmm":signed_error,"actual_six_N_Nmm":forces,"weak56_MPa":rows[:56],"gauges4_MPa":gauge})
    assert eligible == (len(panels)==2)
    return {"native_trace_sha256":result["native_trace_sha256"],"preserved_original_NumFail":True,"same_authenticated_full_ray":True,
            "H26_rollback_exact":True,"H24_restored_exactly":True,"maximum_total_iterations":26,
            "original_fixed_target":result["fixed_target"],"guide_local_and_eligible":eligible,"tests":panels,
            "physical_limit_established":False,"compiler_closed":result["compiler_closed"],"office_closed":result["office_closed"]}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--phase",choices=["Resume"])
    args=parser.parse_args()
    data=prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert args.phase=="Resume"
        path=HERE/"VerificationOwnFullRay.json"
        path.write_bytes((json.dumps(verify(*data),indent=2)+"\n").encode())
        print(path,v.digest(path))
