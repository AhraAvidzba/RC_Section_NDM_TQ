"""ДЛЯ ТЕСТОВ. Согласует точность скалярного возврата с внешним локальным циклом повреждения и дилатансии."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Меняются только численные условия остановки новых проб; история всегда восстанавливается с исходными условиями."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestReturnPrecision.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Materials/CCoupledConcreteResponse.cls'
    code = (root / name).read_text('utf-8-sig')
    block, = re.findall(r'(?ms)^Private Function UpdatePoint\(.*?^End Function', code)
    replacement = block.replace('YIELD_TOLERANCE_RATIO', 'yieldToleranceTest').replace('STATE_TOLERANCE', 'stateToleranceTest')
    marker = '    Dim elastic(1 To N_COMPONENTS) As Double, effective(1 To N_COMPONENTS) As Double'
    assert replacement.count(marker) == 1
    replacement = replacement.replace(marker, '''    Dim yieldToleranceTest As Double, stateToleranceTest As Double
    yieldToleranceTest = TestPrecisionYieldTolerance: stateToleranceTest = STATE_TOLERANCE
    If modTestCoupledElasticState.ReturnPrecisionFactorTest > 0# Then _
        stateToleranceTest = stateToleranceTest * modTestCoupledElasticState.ReturnPrecisionFactorTest
''' + marker, 1)
    assert code.count(block) == 1
    code = code.replace(block, replacement, 1)
    old = '> YIELD_TOLERANCE_RATIO * cc / mPressureModulus Then Exit Function'
    assert code.count(old) == 1
    code = code.replace(old, '> TestPrecisionYieldTolerance * cc / mPressureModulus Then Exit Function', 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Возвращает исходный допуск при восстановлении истории и выбранный допуск только для нового локального шага.
Private Function TestPrecisionYieldTolerance() As Double
    TestPrecisionYieldTolerance = YIELD_TOLERANCE_RATIO
    If modTestCoupledElasticState.ReturnPrecisionFactorTest > 0# Then _
        TestPrecisionYieldTolerance = TestPrecisionYieldTolerance * modTestCoupledElasticState.ReturnPrecisionFactorTest
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'CoupledLocalReturnPrecisionSameHistory',
        'scalar_yield_relative_tolerances': [1e-10, 1e-12, 1e-14],
        'coupled_yield_relative_tolerances': [1e-8, 1e-10, 1e-12],
        'coupled_state_relative_tolerances': [5e-10, 5e-12, 5e-14],
        'precision_only_for_new_trials': True, 'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('SCALAR AND COUPLED LOCAL RETURN PRECISION STUDY READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
