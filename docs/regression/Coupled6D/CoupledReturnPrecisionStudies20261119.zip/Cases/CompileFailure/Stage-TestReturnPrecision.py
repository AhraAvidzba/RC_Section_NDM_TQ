"""ДЛЯ ТЕСТОВ. Проверяет влияние точности локального возврата на одинаковой принятой истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Принятый префикс всегда восстанавливается с исходным допуском; изменяется только точность новых проб."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingConditioned.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Materials/CCoupledConcreteReturn.cls'
    code = (repo / name).read_text('utf-8-sig')
    old = '    tolerance = RELATIVE_YIELD_TOLERANCE * cc'
    assert code.count(old) == 1
    code = code.replace(old, old + '''
    If modTestCoupledElasticState.ReturnPrecisionFactorTest > 0# Then _
        tolerance = tolerance * modTestCoupledElasticState.ReturnPrecisionFactorTest ' ДЛЯ ТЕСТОВ: только численная точность нового локального возврата.
''', 1)
    (root / name).parent.mkdir(parents=True, exist_ok=True)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    if Path(name).stem not in prep['modules']:
        prep['modules'].append(Path(name).stem)
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '''    If EquilibriumNorm(load, field) > tolerance Or Not GaugesVerified(tolerance) Then GoTo RestoreFailure
    mCandidate = field: PublishCandidate lambda'''
    assert code.count(old) == 1
    code = code.replace(old, '''    modTestCoupledElasticState.TestObserveReturnPrecisionBest field, lambda, EquilibriumNorm(load, field)
''' + old, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    assert code.count('Option Explicit\n') == 1
    code = code.replace('Option Explicit\n', '''Option Explicit
Public ReturnPrecisionFactorTest As Double
Private mReturnPrecisionFileTest As Integer, mReturnPrecisionVariantTest As Long
Private mReturnPrecisionExportFactorTest As Double
''', 1)
    body = (here / 'TestNativeReturnPrecision.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', lambda _: body, code)
    assert count == 1
    exporter, = re.findall(r'(?ms)^Private Sub TestExportReverseCandidate\(.*?^End Sub', code)
    exporter = exporter.replace('TestExportReverseCandidate(', 'TestExportPrecisionCandidate(', 1)
    old = '    For index = 1 To mReverseFieldsTest.Count'
    assert exporter.count(old) == 1
    exporter = exporter.replace(old, old + '''
        ReturnPrecisionFactorTest = 1#
        If index = mReverseFieldsTest.Count Then ReturnPrecisionFactorTest = mReturnPrecisionExportFactorTest
''', 1)
    code += "\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Воспроизводит исходный префикс с исходной точностью и только последнее поле с выбранной точностью.\n" + exporter + '\n'
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeReturnPrecision.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'LocalReturnPrecisionSameHistory',
        'local_yield_relative_tolerances': [1e-10, 1e-12, 1e-14],
        'global_tolerances': ['Original', 'Strict1e-10'], 'iteration_budget': 30,
        'accepted_prefix_always_original_precision': True,
        'best_numerical_outcomes_recorded_even_if_not_accepted': True,
        'stress_law_and_material_parameters_unchanged': True, 'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('LOCAL RETURN PRECISION SAME COMMITTED HISTORY STUDY READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
