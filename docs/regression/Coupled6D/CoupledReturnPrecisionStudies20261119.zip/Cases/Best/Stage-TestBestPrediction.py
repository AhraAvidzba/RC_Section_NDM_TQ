"""ДЛЯ ТЕСТОВ. Проверяет повтор одной цели с сохранением лучшего начального приближения."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Каждый вызов ограничен исходными 30 поправками; суммарные усилия и неизменность принятой истории записываются отдельно."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingConditioned.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    old = '''    If EquilibriumNorm(load, field) > tolerance Or Not GaugesVerified(tolerance) Then GoTo RestoreFailure
    mCandidate = field: PublishCandidate lambda'''
    assert code.count(old) == 1
    code = code.replace(old, '    modTestCoupledElasticState.TestObserveBestPrediction field, lambda, EquilibriumNorm(load, field)\n' + old, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    assert code.count('Option Explicit\n') == 1
    code = code.replace('Option Explicit\n', '''Option Explicit
Private mBestPredictionReadyTest As Boolean, mBestPredictionCaseTest As Long
Private mBestPredictionFieldTest() As Double, mBestPredictionLambdaTest As Double, mBestPredictionNormTest As Double
''', 1)
    body = (here / 'TestNativeBestPrediction.bas.txt').read_text('utf-8-sig')
    code, count = re.subn(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', lambda _: body, code)
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    for file in (Path(__file__), here / 'TestNativeBestPrediction.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'BestFieldPredictionSameTarget', 'local_material_tolerances_original': True,
        'per_try_steps': 30, 'max_tries': 4, 'shared_max_steps': 120, 'same_accepted_revision': True,
        'strict_absolute_and_relative_tolerances': 1e-10, 'prediction_is_not_cached_solution': True,
        'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('BEST FIELD PREDICTION ON SAME EXACT CONTEXT READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
