"""ДЛЯ ТЕСТОВ. Сравнивает три шага полной разностной касательной на одной точной истории."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Изменяется только численный шаг производной; материалы, принятый префикс, мера и бюджеты одинаковы."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestWorkingConditioned.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    code = (root / name).read_text('utf-8-sig')
    old = 'relativeDifferenceStep:=HYBRID_DIFFERENCE_STEP, _'
    assert code.count(old) == 1
    code = code.replace(old, 'relativeDifferenceStep:=modTestCoupledElasticState.HybridDifferenceStepTest, _', 1)
    old = '''    If EquilibriumNorm(load, field) > tolerance Or Not GaugesVerified(tolerance) Then GoTo RestoreFailure
    mCandidate = field: PublishCandidate lambda'''
    assert code.count(old) == 1
    code = code.replace(old, '    modTestCoupledElasticState.TestObserveReturnPrecisionBest field, lambda, EquilibriumNorm(load, field)\n' + old, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    assert code.count('Option Explicit\n') == 1
    code = code.replace('Option Explicit\n', '''Option Explicit
Public HybridDifferenceStepTest As Double, ReturnPrecisionFactorTest As Double
Private mReturnPrecisionFileTest As Integer, mReturnPrecisionVariantTest As Long
Private mReturnPrecisionExportFactorTest As Double
''', 1)
    body = (here / 'TestNativeReturnPrecision.bas.txt').read_text('utf-8-sig')
    body = body.replace('LocalReturnAccuracyOnlyOnNewTrials', 'FullDifferenceStepOnly')
    body = body.replace('factors = Array(1#, 0.01, 0.0001)', 'factors = Array(0.000001, 0.0000001, 0.00000001)')
    old = '        ReturnPrecisionFactorTest = factors(probeCase Mod 3): mReturnPrecisionVariantTest = probeCase'
    assert body.count(old) == 1
    body = body.replace(old, '        HybridDifferenceStepTest = factors(probeCase Mod 3): mReturnPrecisionVariantTest = probeCase', 1)
    body = body.replace('TestExportPrecisionCandidate 10 + probeCase', 'TestExportReverseCandidate 10 + probeCase', 1)
    body = body.replace('TestOnsetNumber(ReturnPrecisionFactorTest) & ";" & TestOnsetNumber(absTol)',
                        'TestOnsetNumber(HybridDifferenceStepTest) & ";" & TestOnsetNumber(absTol)', 1)
    body = body.replace('TestOnsetNumber(ReturnPrecisionFactorTest) & _', 'TestOnsetNumber(HybridDifferenceStepTest) & _', 1)
    code, count = re.subn(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', lambda _: body, code)
    assert count == 1 and max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'FullDifferenceScaleSameHistory',
        'relative_coordinate_steps': [1e-6, 1e-7, 1e-8], 'local_material_tolerances_original': True,
        'global_tolerances': ['Original', 'Strict1e-10'], 'iteration_budget': 30,
        'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('FULL DIFFERENCE SCALE SAME EXACT HISTORY STUDY READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
