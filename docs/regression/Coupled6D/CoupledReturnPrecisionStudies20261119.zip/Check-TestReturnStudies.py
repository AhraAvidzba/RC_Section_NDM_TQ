"""ДЛЯ ТЕСТОВ. Проверяет точную историю и сохраняет неудачные исходы численных исследований."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestFiles(root):
    """Все сохранённые источники и отрицательные исходы должны быть неизменны."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == '22fde275d9f4a01e2d31b57a00eb7643aaee50f3'


def TestNative(repo, root, output):
    """Положительный итог подготовки не означает успех строгих численных проб."""
    TestFiles(root)
    audit = run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit']
    cases = {}
    for case in ('Scalar', 'Coupled', 'Best', 'Difference'):
        folder = root / 'Cases' / case
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Code.json'
            audit(repo, folder, proof)
            record = json.loads(proof.read_bytes())
        imported = 31 if case in ('Scalar', 'Coupled') else 30
        assert (record['components'], record['imported'], record['unchanged']) == (244, imported, 244-imported)
        assert len(record['checked_coupled_sources']) == 33
        path = folder / 'Native/ReversePolish.txt'
        log = path.read_text('utf-8-sig')
        assert 'TOTAL_REVERSE_POLISH_STUDY_TEST: passed=1; failed=0; numerical_outcomes_recorded_not_asserted; capacity_certified=False' in log
        assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log and 'RUNTIME ERROR:' not in log
        source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
        assert source == record['compiled_workbook_sha256']
        closure = json.loads(path.with_name(path.name+'.ProcessClosure.json').read_bytes())
        assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
        assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
        record['owned_excel_absent'] = True
        cases[case] = record
    failure = root / 'Cases/CompileFailure'
    raw = (failure / 'Compile.log').read_bytes()
    assert raw.startswith(b'\xff\xfe') and 'Dim variant As Long' in raw.decode('utf-16')
    assert 'COMPILE_LOCATION:' in raw.decode('utf-16') and not (failure / 'CompileClosure.json').exists()
    assert not list((failure / 'Native').glob('*.txt'))
    closure = json.loads((failure / 'CompileFailureClosure.json').read_bytes())
    assert closure['State'] == 'Absent' and closure['PID'] == 28428
    assert closure['ExpectedStartTicks'] == '639306632975894741'
    assert (failure / 'ImportedUncompiledVBA.bin').exists() and not (failure / 'CompiledVBA.bin').exists()
    result = {'cases': cases, 'failed_preparation_not_executed': True, 'failed_compile_UTF16_BOM_preserved': True,
              'working_runtime_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('RETURN STUDIES FOUR NATIVE BOOKS AND EXPECTED TEST PREPARATION FAILURE VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Ни один неудачный способ не становится рабочим исправлением или доказательством разрушения."""
    TestFiles(root)
    helpers = run_path(str(root / 'Validate-TestHardPrepared.py'))
    rows, validate = helpers['TestRows'], helpers['TestValidate']
    reference, reference_fields = validate(root / 'Baseline', 'Reference')
    read_binary = run_path(str(root / 'Check-TestActualReverseCapture.py'))['TestReadBinary']
    cases = {}
    for case in ('Scalar', 'Coupled', 'Difference'):
        folder = root / 'Cases' / case
        snapshot = read_binary(folder / 'Input/Reverse1.bin')
        records = rows(folder / 'Native/ReturnPrecision.csv')
        probes = [row for row in records if row[0] == 'PROBE']
        precision = [row for row in records if row[0] == 'PRECISION']
        best = [row for row in rows(folder / 'Native/ReturnPrecision.Best.csv') if row[0] == 'BEST']
        assert len(probes) == len(precision) == len(best) == 6
        solved = (0,) if case == 'Difference' else (0, 1, 2)
        field_proofs = {}
        for index, row in enumerate(probes):
            assert int(row[2]) == index and float(row[6]) <= 30
            assert (row[3] == 'True') == (index in solved)
            assert float(row[4]) == 0 if index not in solved else float(row[4]) > snapshot['lambdas'][-1]
            if index in solved:
                proof, fields = validate(folder, 'ReturnPrecision.Reverse' + str(10+index))
                assert len(fields) == 27 and not proof['reversed_fields']
                np.testing.assert_allclose(fields[:26], snapshot['fields'], rtol=1e-14, atol=1e-300)
                if index == 0:
                    assert np.array_equal(fields, reference_fields)
                field_proofs[str(index)] = proof
        for index in range(3):
            assert np.array_equal(np.asarray(best[index][3:], float), np.asarray(best[index+3][3:], float))
        cases[case] = {'probes': probes, 'precision': precision, 'best': best, 'equilibrium_witnesses': field_proofs,
                       'strict_equilibrium_found': False, 'baseline_field_exact': True}
    folder = root / 'Cases/Best'
    records = rows(folder / 'Native/BestPrediction.csv')
    probes = [row for row in records if row[0] == 'PROBE']
    best = [row for row in records if row[0] == 'BEST']
    seeds = [row for row in records if row[0] == 'SEED']
    budgets = [row for row in records if row[0] == 'BUDGET']
    assert len(probes) == len(best) == len(seeds) == len(budgets) == 4
    assert all(row[3] == 'False' and float(row[4]) == 0 for row in probes)
    assert [int(row[2]) for row in budgets] == [30, 60, 81, 101]
    assert all(row[4] == 'revision=28' for row in budgets)
    for index in range(1, 4):
        assert float(seeds[index][2]) == float(best[index-1][2])
        assert np.array_equal(np.asarray(seeds[index][3:], float), np.asarray(best[index-1][4:], float))
    assert all(float(best[i+1][3]) < float(best[i][3]) for i in range(3))
    cases['Best'] = {'probes': probes, 'best': best, 'budgets': budgets, 'same_accepted_revision': 28,
                     'all_four_strict_attempts_unresolved': True, 'shared_steps_used': 101}
    result = {'reference_equilibrium': reference, 'cases': cases, 'working_runtime_changed': False,
              'independent_material_reintegration': False, 'physical_capacity_certified': False,
              'full_acceptance_completed': False, 'CSV_rounding_allowance_MPa': 1e-9}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('RETURN STUDIES COMMON HISTORY EQUILIBRIA AND NEGATIVE STRICT OUTCOMES VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
