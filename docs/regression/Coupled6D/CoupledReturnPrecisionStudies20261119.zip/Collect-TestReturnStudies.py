"""ДЛЯ ТЕСТОВ. Сохраняет отрицательные проверки точности, повторов и шага производной."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestCollect(repo, root):
    """Разделяет исполненные книги и не скомпилированную подготовку; исходы не подменяет."""
    here = Path(__file__).resolve().parent
    cases = {'Scalar': 'LocalReturnPrecision0220261119', 'Coupled': 'CoupledReturnPrecision20261119',
             'Best': 'BestPrediction20261119', 'Difference': 'FullDifferenceScale20261119',
             'CompileFailure': 'LocalReturnPrecision20261119'}
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for key in cases:
        folder = root / 'Cases' / key
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(sources) == 33
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True)+'\n', encoding='utf-8')
        if key == 'CompileFailure':
            for suffix in ('.bin', '.json'):
                (folder / ('CompiledVBA' + suffix)).rename(folder / ('ImportedUncompiledVBA' + suffix))
    reference = Path('D:/CodexScratch/RC_Section_NDM_TQ/ConditionedWorking20261119/Native')
    target = root / 'Baseline/Native'
    target.mkdir(parents=True)
    for suffix in ('.csv', '.Operators.csv'):
        (target / ('Reference' + suffix)).write_bytes((reference / ('ReversePolish.Reverse13' + suffix)).read_bytes())
    (root / 'Baseline/Source.json').write_text(json.dumps({'archive': 'CoupledConditionedSecant20261119',
        'sha256': '699B697E5366E34D851E003321CED4B51D334814E857E6B88FC7FE6083A5798C',
        'phase': 'Cases/Working/Native/ReversePolish.Reverse13'}, indent=2)+'\n', encoding='utf-8')
    names = ('Collect-TestReturnStudies.py', 'Check-TestReturnStudies.py', 'Audit-TestPrivateCoupledBook.py',
             'Canonical-TestCoreVBA.py', 'Validate-TestHardPrepared.py', 'Check-TestActualReverseCapture.py',
             'Check-TestHardHalfSteps.py', 'Stage-TestReturnPrecision.py', 'Stage-TestCoupledReturnPrecision.py',
             'Stage-TestBestPrediction.py', 'Stage-TestFullDifferenceScale.py', 'TestNativeReturnPrecision.bas.txt',
             'TestNativeBestPrediction.bas.txt')
    for name in names:
        (root / name).write_bytes((here / name).read_bytes())
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': '22fde275d9f4a01e2d31b57a00eb7643aaee50f3',
        'working_runtime_changed': False, 'installed_workbook_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2)+'\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
             for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('RETURN PRECISION PREDICTION AND DIFFERENCE NEGATIVE STUDIES COLLECTED', len(files))


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
