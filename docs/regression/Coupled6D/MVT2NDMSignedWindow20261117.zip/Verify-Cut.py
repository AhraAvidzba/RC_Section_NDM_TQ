"""Compare independent OpenSees forces with three signed MVT2 cuts in Excel."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json


HERE = Path(__file__).resolve().parent
BASE = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
SOURCE = "2F7A8A5F21C91FA0122CCC24817069B8369D7654EC19271A5BA223742F7F6005"
EXTENDED_SOURCE = "0CF1E1AD6A6FC0F2DB821A0F49A871DBAD03FED4D5EA11EA2A262EA01AC2E745"
ARMS = (300, 330, 360)
Q_STEPS = [0.] * 7 + [5., 6.25, 7.5, 8.75, 10., 11.25, 11.5625]
T_STEPS = [10.51 * factor for factor in (.025, .05, .1, .2, .4, .65, 1.)] + [10.51] * 7
Q_CONTINUATION = [11.5625 + .3125 * i for i in range(1, 12)]
FORCE_DIFF_LIMIT = 0.00015  # kN
MOMENT_DIFF_LIMIT = 0.00010  # kNm


def digest(raw):
    return sha256(raw).hexdigest().upper()


def read(root, name):
    return json.loads((root / name).read_text(encoding="utf-8-sig"))


def verify_closures(root, candidates):
    compiled = read(root, "docs/regression/CodeUpdate.json")
    compiler = read(root, "CompileClosure.json")
    prep = read(root, "Preparation.json")
    inputs = prep["inputs"]
    for item in inputs:
        if item.endswith(".xlsm"):
            continue
        assert digest((root / item).read_bytes()) == inputs[item], item
    assert prep["workbook_sha256"] == inputs["workbook/output/RC_Section_NDM.xlsm"] == BASE
    assert compiled["ProductionSHA256"] == BASE and compiled["Compiled"] and not compiled["ProductionChanged"]
    assert compiled["Modules"] == ["modTestMVT2CutComparison"] and compiler["State"] == "Absent"
    assert f"OWNED_EXCEL: id={compiler['PID']}; utcStartTicks={compiler['StartTicksUTC']}" in (
        root / "Compile.log").read_text(encoding="utf-8-sig")
    for arm in candidates:
        name = f"Native/Right{arm}.txt"
        book = read(root, name + ".Ownership.json")
        closure = read(root, name + ".ProcessClosure.json")
        final = closure["Closure"]["FinalState"]
        assert book["SourceSHA256"] == compiled["WorkbookSHA256"] and book["VerifiedNewOwner"]
        assert closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"] == 0
        assert (final["PID"], final["StartTicksUTC"], final["State"]) == (book["PID"], book["StartTicksUTC"], "Absent")
        report = (root / name).read_text(encoding="utf-8-sig")
        assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in report
        assert "TOTAL_MVT2_CUT_COMPARISON: passed=1; failed=0;" in report


def parse_section(root, arm, external, q_steps, t_steps):
    raw = (root / f"Native/Right{arm}.csv").read_bytes()
    table = [line.split(";") for line in raw.decode("cp1251").splitlines()]
    setup, *rows = table
    names = "fc_MPa", "ft_MPa", "explicit_Gt_N_per_mm", "explicit_Gc_N_per_mm"
    assert setup[:2] == ["MVT2_CUT_SETUP", str(arm)]
    assert all(abs(float(v) - external[k]) < 1e-12 for v, k in zip(setup[2:], names, strict=True))
    accepted, subdivided, rejected = [], [], None
    for stage, (torque, q) in enumerate(zip(t_steps, q_steps, strict=True), 1):
        phase = f"R{stage}"
        if rows[0][0] == "MVT2_CUT_DIRECT_STOP":
            stopped, *rows = rows
            assert stopped[1] == phase and stage > 7
            subdivision_q = q_steps[stage - 2]
            while rows[0][0] == "MVT2_CUT_INSERTED":
                inserted, *rows = rows
                assert inserted[1] == phase and len(inserted) == 10
                internal_q, first_norm, *six = (float(x) for x in inserted[2:])
                current_q = internal_q / 1000
                assert subdivision_q < current_q < q and 0 <= first_norm <= 5e-6
                expected = (0., -arm * internal_q, 0., torque * 1e6, 0., internal_q)
                assert all(abs(x-y) < limit for x, y, limit in zip(six, expected, (.15, 100., 100., 100., .15, .15), strict=True))
                subdivided.append({"stage": stage, "accepted_intermediate_Qy_kN": current_q,
                                    "component_errors_N_Nmm": [x-y for x, y in zip(six, expected, strict=True)],
                                    "normalized_resultant_error_MPa": first_norm})
                subdivision_q = current_q
        trial, *rows = rows
        target_mx = -arm * q / 1000
        assert trial[:2] == ["MVT2_CUT_TRIAL", phase]
        assert all(abs(float(v) - value) < 5e-8 for v, value in zip(trial[2:5],
                   (torque * 1e6, q * 1000, target_mx * 1e6), strict=True))
        if trial[5] == "False":
            assert trial[6:8] == ["6", "10"] and not rows
            rejected = {"stage": stage, "requested_Qy_kN": q, "requested_T_kNm": torque, "diagnostic": ";".join(trial[8:])}
            break
        assert trial[5:8] == ["True", "4", "0"]
        record, *rows = rows
        assert record[:2] == ["MVT2_STATE", trial[1]] and list(map(float, record[2:4])) == [q, q]
        values = [float(x) for x in record[4:]]
        assert len(values) == 20
        physical = values[:6]
        applied = (0., target_mx, 0., torque, 0., q)
        errors = [a - b for a, b in zip(physical, applied, strict=True)]
        assert all(abs(errors[j]) <= tol for j, tol in enumerate(
            (FORCE_DIFF_LIMIT, MOMENT_DIFF_LIMIT, MOMENT_DIFF_LIMIT, MOMENT_DIFF_LIMIT, FORCE_DIFF_LIMIT, FORCE_DIFF_LIMIT)))
        assert 0. <= values[-1] <= 5e-6
        accepted.append({"stage": stage, "applied_signed_wrench_kN_kNm": applied, "actual_wrench_kN_kNm": physical,
                         "component_errors_kN_kNm": errors, "twist_rad_per_m": values[9],
                         "max_longitudinal_steel_abs_MPa": values[11], "max_hoop_abs_MPa": values[12],
                         "normalized_resultant_error_MPa": values[-1]})
    assert not rows
    return {"arm_mm": arm, "raw_sha256": digest(raw), "accepted": accepted, "rejected": rejected,
            "subdivided": subdivided}


def compare(root, opens, arms, refined):
    fingerprint = digest(opens.read_bytes())
    assert fingerprint in (SOURCE, EXTENDED_SOURCE)
    extended = fingerprint == EXTENDED_SOURCE
    q_steps = Q_STEPS + Q_CONTINUATION if extended else Q_STEPS
    t_steps = T_STEPS + [10.51] * len(Q_CONTINUATION) if extended else T_STEPS
    with ZipFile(opens) as archive:
        member = "HeldTQ15Native.json" if extended else "Newton24HeldTNative.json"
        external = json.loads(archive.read(member))
    assert external["newton24_activated"] and external["prefix_exact"] and not external["physical_limit_established"]
    ext_states = external["replay_states"] + [external["base_Q5_state"]] + external["shear_confirmed_states"]
    assert len(ext_states) == len(q_steps)
    verify_closures(root, arms)
    ndm = {arm: parse_section(root, arm, external, q_steps, t_steps) for arm in arms}
    original_endpoint = None
    if refined is not None:
        assert 360 in ndm and ndm[360]["rejected"] is not None and not ndm[360]["subdivided"]
        original_endpoint = ndm[360]
        verify_closures(refined, (360,))
        ndm[360] = parse_section(refined, 360, external, q_steps, t_steps)
        assert ndm[360]["accepted"][:len(original_endpoint["accepted"])] == original_endpoint["accepted"]
    records = []
    for stage in range(len(ext_states)):
        if any(len(ndm[arm]["accepted"]) <= stage for arm in arms):
            break
        state = ext_states[stage]
        geometry = {int(cut["z_mm"]): cut["low_and_high_face"] for cut in state["rig_balance"]["cuts"]}
        for arm in arms:
            # Растворы срезов знаковые. В промежуточной точке усилия линейны
            # по длине на участке без распределённой нагрузки.
            near, far = geometry[1340], geometry[1400]
            fraction = (360 - arm) / 60
            for face in range(2):
                ext_load = [(a + fraction * (b - a)) / (1e3 if j in (0, 4, 5) else 1e6)
                            for j, (a, b) in enumerate(zip(near[face], far[face], strict=True))]
                applied = ndm[arm]["accepted"][stage]["applied_signed_wrench_kN_kNm"]
                assert all(abs(x-y) < 2e-9 for x, y in zip(ext_load, applied, strict=True))
        local = {arm: ndm[arm]["accepted"][stage]["twist_rad_per_m"] for arm in arms}
        window = (local[300] + 4*local[330] + local[360])/6 if tuple(arms) == ARMS else None
        ext = state["displacement"]["clear_twist_rad_per_m"]["right"]
        assert ext > 0
        records.append({"stage": stage + 1, "Qy_kN": q_steps[stage], "T_kNm": t_steps[stage],
                        "NDM_twist_by_arm_rad_per_m": local, "NDM_Simpson_estimate_rad_per_m": window,
                        "OpenSees_right_window_rad_per_m": ext,
                        "NDM_center_to_OpenSees_ratio": local[330] / ext if 330 in local else None,
                        "NDM_window_to_OpenSees_ratio": window / ext if window is not None else None})
    assert records
    return {"status": "PASS", "installed_book_sha256": BASE, "external_reference_sha256": fingerprint,
            "NDM": ndm, "original_360_mm_endpoint": original_endpoint,
            "right_window_mm": [1340, 1400], "comparison": records,
            "first_early_elastic_ratio": records[0]["NDM_center_to_OpenSees_ratio"],
            "constitutive_laws_equated": False, "physical_limit_established": False}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=HERE)
    parser.add_argument("--refined", type=Path)
    parser.add_argument("--opens", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--arms", nargs="+", type=int, choices=ARMS, default=ARMS)
    options = parser.parse_args()
    proof = compare(options.root, options.opens, tuple(options.arms), options.refined)
    data = (json.dumps(proof, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    with options.out.open("xb") as file:
        file.write(data)
    print("MVT2 SIGNED CUT PROOF PASS", len(proof["comparison"]), digest(data))
