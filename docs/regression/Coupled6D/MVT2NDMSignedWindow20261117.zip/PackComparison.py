"""Pack portable evidence for the signed MVT2 cut comparison."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
SCRATCH = Path("D:/CodexScratch/RC_Section_NDM_TQ")
PROOF_NAMES = ("Exact11", "OneSplit11", "Fine11", "Fine15")
WINDOW_PATHS = ("MVT2CutMatch", "MVT2CutRefine", "MVT2CutFine", "MVT2Cut15")


def packed_files():
    for name in ("Verify-Cut.py", "Stage.py", "CutTest.txt", "Run.ps1", "PackComparison.py", "README.md"):
        yield name, (HERE / name).read_bytes()
    for name in ("VerifiedFineCuts.json", "VerifiedRefinedCuts.json", "VerifiedFine15.json"):
        yield name, (HERE / name).read_bytes()
    for label, name in zip(PROOF_NAMES, WINDOW_PATHS, strict=True):
        root = SCRATCH / name
        prep = json.loads((root / "Preparation.json").read_bytes())
        files = ({p for p in prep["inputs"] if not p.endswith(".xlsm")}
                 | {"Preparation.json", "CompileClosure.json", "Compile.log", "docs/regression/CodeUpdate.json"}
                 | {f"Native/{p.name}" for p in (root / "Native").iterdir() if p.is_file()})
        for member in sorted(files):
            raw = (root / member).read_bytes()
            if member in prep["inputs"]:
                assert sha256(raw).hexdigest().upper() == prep["inputs"][member]
            yield f"{label}/{member}", raw


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    options = parser.parse_args()
    with ZipFile(options.archive, "x", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for entry, data in packed_files():
            archive.writestr(ZipInfo(entry), data, compress_type=ZIP_DEFLATED, compresslevel=9)
    print(options.archive.name, sha256(options.archive.read_bytes()).hexdigest().upper())
