"""Recompute HardShear timing and check the recorded native workbook receipts."""

import argparse
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import re
from statistics import mean


HERE = Path(__file__).resolve().parent
CURRENT = "8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF"
TRIAL = "00F58C289C37CC51382D804C38CC405B88FE3E259900C0F854FE11C9FFDE9D8F"
COMPONENTS = ("N", "Mx", "My", "T", "Qx", "Qy")
IDENTITY = r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$"
SAVED = r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=([0-9A-F]{64}); equal=True; file="
ACTUAL = r"^OK: direct (\w+) actual=([-+0-9.E,]+) expected=([-+0-9.E,]+)$"


def digest(file):
    return sha256(file.read_bytes()).hexdigest().upper()


def read_json(file):
    return json.loads(file.read_text(encoding="utf-8-sig"))


def number(token):
    return float(token.replace(",", "."))


def replay(native, reference, proof):
    logged = read_json(native / "Benchmark.json")
    assert len(logged["Samples"]) == 4 and logged["TargetSeconds"] == 10
    draft = (reference / "Native/Direct.txt").read_text(encoding="utf-8-sig")
    assert f"SOURCE_SHA256: {TRIAL}" in draft
    assert "TOTAL_DIRECT_STEEL_VERIFICATION: passed=23; failed=0" in draft
    times = {"Baseline": [], "Trial": []}
    states, owners, source_hashes = [], [], []
    for index, (name, sample) in enumerate(zip(("Baseline", "Trial", "Trial", "Baseline"), logged["Samples"], strict=True), 1):
        suffix = f"{index:02}-{name}.txt"
        report = native / suffix
        trace = report.read_text(encoding="utf-8-sig")
        closed = read_json(native / (suffix + ".ProcessClosure.json"))
        system = read_json(native / (suffix + ".memory.json"))
        assert system["Ready"] and system["FreeCommitGiB"] >= 8 and system["FreePhysicalGiB"] >= 4
        assert closed["Passed"] and closed["ChildHasExited"] and closed["ChildExitCode"] == 0
        assert closed["Closure"]["Identity"]["Valid"] and not closed["Closure"]["OrdinaryPathKilledAnything"]
        owned = closed["Closure"]["FinalState"]
        recorded = sample["ExcelOwner"]
        fields = ("State", "PID", "StartTicksUTC", "Reason")
        assert all(owned[key] == recorded[key] for key in fields) and owned["State"] == "Absent"
        assert datetime.fromisoformat(owned["ObservedUTC"]) == datetime.fromisoformat(recorded["ObservedUTC"])
        assert re.findall(IDENTITY, trace, re.M) == [(str(owned["PID"]), owned["StartTicksUTC"])]
        owners.append((owned["PID"], owned["StartTicksUTC"]))
        fingerprints = re.findall(r"^SOURCE_SHA256: ([0-9A-F]{64})$", trace, re.M)
        assert fingerprints == [sample["BookSHA256"]] == [CURRENT if name == "Baseline" else TRIAL]
        assert sample["Variant"] == name and sample["Assertions"] == 19
        source_hashes.append(digest(report))
        assert source_hashes[-1] == sample["SourceReportSHA256"]
        assert "SOURCE_UNCHANGED: True" in trace and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in trace
        assert "TIMING_STATES: direct=OK; capacity=N/A; confirmed lower=; limit=; code=" in trace
        assert "TOTAL_COUPLED_WORKBOOK_TIMING: passed=19; failed=0" in trace
        assert len(re.findall(r"^OK: ", trace, re.M)) == 19
        values = re.findall(ACTUAL, trace, re.M)
        assert tuple(row[0] for row in values) == COMPONENTS
        pairs = [(number(actual), number(expected)) for _, actual, expected in values]
        assert all(abs(actual - expected) < 1e-9 * max(1., abs(expected)) for actual, expected in pairs)
        states.append(pairs)
        (before, after), = re.findall(SAVED, trace, re.M)
        assert before == after
        elapsed, = re.findall(r"^TIMING_SECONDS: ([0-9.,]+) \| Direct \| Excel$", trace, re.M)
        times[name].append(number(elapsed))
        assert times[name][-1] == sample["CalculationSeconds"] < sample["WallSeconds"]
    assert len(set(owners)) == 4 and all(pairs == states[0] for pairs in states)
    baseline, trial = (mean(times[name]) for name in ("Baseline", "Trial"))
    assert (baseline, trial, trial - baseline) == (logged["BaselineSeconds"], logged["TrialSeconds"], logged["ChangeSeconds"])
    result = {
        "scope": "HardShear direct, Excel Results, four fresh isolated instances",
        "six_resultants_identical": True,
        "results_saved_reopened": True,
        "search_capacity_included": False,
        "same_calculation_path_assertions_per_run": 19,
        "calculation_seconds": times,
        "average_seconds": {"Baseline": baseline, "Trial": trial},
        "actual_expected_in_configured_output_units": dict(zip(COMPONENTS, states[0], strict=True)),
        "native_reports_sha256": source_hashes,
    }
    proof.write_bytes((json.dumps(result, indent=2) + "\n").encode())
    print("HARDSHEAR DIRECT BENCHMARK PASS", digest(proof))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--native", type=Path, default=HERE / "Native")
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=HERE / "Replay.json")
    args = parser.parse_args()
    replay(args.native, args.reference, args.output)
