# Измеряет штатный прямой расчёт HardShear в исходной и кандидатной книгах.
# Все четыре пробы открывают независимую копию и проверяют Results после сохранения.
param([string]$TrialReceipt = (Join-Path $PSScriptRoot 'docs/regression/CodeUpdate.json'), [switch]$Preflight)

$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
$installed = Join-Path $repo 'workbook/output/RC_Section_NDM.xlsm'
$receipt = Get-Content -LiteralPath $TrialReceipt -Encoding UTF8 -Raw | ConvertFrom-Json
$baselineHash = '8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF'
if (!$receipt.Compiled -or $receipt.ProductionChanged -or $receipt.ProductionSHA256 -cne $baselineHash -or
    (Get-FileHash -LiteralPath $installed).Hash -cne $baselineHash) { throw 'Исходная сборка не подтверждена.' }
$trial = (Resolve-Path -LiteralPath $receipt.Workbook).Path
$tmpRoot = (Resolve-Path -LiteralPath (Join-Path $repo 'tmp')).Path + '\'
if (!$trial.StartsWith($tmpRoot, [StringComparison]::OrdinalIgnoreCase) -or
    (Get-FileHash -LiteralPath $trial).Hash -cne $receipt.WorkbookSHA256 -or $receipt.WorkbookSHA256 -ceq $baselineHash) {
    throw 'Кандидат должен быть отличной от базовой проверенной частной книгой.'
}
if ($Preflight) {
    Write-Output "DIRECT_BENCH_PREFLIGHT: baseline=$baselineHash; trial=$($receipt.WorkbookSHA256)"
    return
}

$benchPath = Join-Path $PSScriptRoot ('Bench-' + $receipt.WorkbookSHA256.Substring(0, 12))
if (Test-Path -LiteralPath $benchPath) { throw 'Предыдущие протоколы сохраняются.' }
New-Item -ItemType Directory -Path $benchPath | Out-Null
$oldTemp = $env:TEMP
$oldTmp = $env:TMP
$legacy = Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$watchdog = Join-Path $PSScriptRoot 'tools/build_workbook/Run-Audit03Watchdog.ps1'
$nativeArgs = @('-Macro','modTestCoupledElasticState.RunTestCoupledWorkbookTiming',
    '-MacroArgument1','Direct','-MacroArgument2','Excel','-Mode','No','-TimeoutSeconds','120',
    '-VerifyResultsReopen','-FailFast')

Push-Location -LiteralPath $benchPath
try {
    . (Join-Path $PSScriptRoot 'Guard-IsolatedOffice.ps1')
    $env:TEMP = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot 'Temp')).Path
    $env:TMP = $env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Слишком длинный путь пробной книги.'
    }
    $entries = @(
        @{ Label = '01-Baseline'; Variant = 'Baseline'; Book = $installed; SHA256 = $baselineHash },
        @{ Label = '02-Trial'; Variant = 'Trial'; Book = $trial; SHA256 = $receipt.WorkbookSHA256 },
        @{ Label = '03-Trial'; Variant = 'Trial'; Book = $trial; SHA256 = $receipt.WorkbookSHA256 },
        @{ Label = '04-Baseline'; Variant = 'Baseline'; Book = $installed; SHA256 = $baselineHash }
    )
    $samples = @(
        foreach ($entry in $entries) {
            Assert-IsolatedOfficeReady $entry.Label
            if ((Get-FileHash -LiteralPath $entry.Book).Hash -cne $entry.SHA256) { throw 'Изменилась книга замера.' }
            $file = $entry.Label + '.txt'
            $report = (Split-Path -Leaf $benchPath) + '/' + $file
            $timer = [Diagnostics.Stopwatch]::StartNew()
            & $legacy -NoProfile -ExecutionPolicy Bypass -File $watchdog -SourceWorkbook $entry.Book -ReportPath $report @nativeArgs |
                ForEach-Object { Write-Host $_ }
            $timer.Stop()
            $exit = $LASTEXITCODE
            $path = Join-Path $benchPath $file
            if ($exit -ne 0) { throw "Нативный замер $file завершился ошибкой." }
            $closed = Get-Content -LiteralPath ($path + '.ProcessClosure.json') -Encoding UTF8 -Raw | ConvertFrom-Json
            $trace = Get-Content -LiteralPath $path -Encoding UTF8 -Raw
            $elapsed = [regex]::Match($trace, '(?m)^TIMING_SECONDS: ([0-9]+(?:[.,][0-9]+)?) \| Direct \| Excel\r?$')
            $test = [regex]::Match($trace, '(?m)^TOTAL_COUPLED_WORKBOOK_TIMING: passed=(\d+); failed=0\r?$')
            if (!$closed.Passed -or $closed.Closure.FinalState.State -cne 'Absent' -or !$elapsed.Success -or
                !$test.Success -or [int]$test.Groups[1].Value -lt 8 -or
                $trace -notmatch '(?m)^TIMING_STATES: direct=OK; capacity=N/A;' -or
                $trace -notmatch '(?m)^RESULTS_SAVE_REOPEN: .*; equal=True;' -or
                $trace -notmatch '(?m)^WATCHDOG_COMPLETED: exit=0; source unchanged=True\r?$') {
                throw "Не подтверждены проверка Results или условия пробы $file."
            }
            [pscustomobject][ordered]@{
                Variant = $entry.Variant
                BookSHA256 = $entry.SHA256
                SourceReportSHA256 = (Get-FileHash -LiteralPath $path).Hash
                ExcelOwner = $closed.Closure.FinalState
                Assertions = [int]$test.Groups[1].Value
                CalculationSeconds = [double]::Parse($elapsed.Groups[1].Value.Replace(',', '.'), [Globalization.CultureInfo]::InvariantCulture)
                WallSeconds = $timer.Elapsed.TotalSeconds
            }
        }
    )
    if (@($samples.Assertions | Sort-Object -Unique).Count -ne 1) { throw 'Покрытие сравниваемых проб различается.' }
    $baseline = ($samples | Where-Object Variant -eq 'Baseline' | Measure-Object CalculationSeconds -Average).Average
    $candidate = ($samples | Where-Object Variant -eq 'Trial' | Measure-Object CalculationSeconds -Average).Average
    [ordered]@{
        Calculation = 'HardShear Direct / Excel'
        TargetSeconds = 10
        BaselineSeconds = $baseline
        TrialSeconds = $candidate
        ChangeSeconds = $candidate - $baseline
        Samples = $samples
    } | ConvertTo-Json -Depth 6 | Tee-Object -FilePath (Join-Path $benchPath 'Benchmark.json')
} finally {
    $env:TEMP = $oldTemp
    $env:TMP = $oldTmp
    Pop-Location
}
