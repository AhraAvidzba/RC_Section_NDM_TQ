"""Готовит отдельную книгу для проверки двух прогнозов на одной истории."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json


HERE = Path(__file__).resolve().parent
EVIDENCE = 'MVT2NativePublicationCutTimed20261117.zip'
EVIDENCE_SHA = 'EBAB47A1CDA340FAFD23604939D8A88CF9DC3CCC4B9535CB155FF104739C054A'


def stage(repo, target, branch_test, split_test):
    assert not (branch_test and split_test)
    archive = repo / 'docs/regression/Coupled6D' / EVIDENCE
    assert sha256(archive.read_bytes()).hexdigest().upper() == EVIDENCE_SHA
    with ZipFile(archive) as bundle:
        environment = {'__name__': '__pinned__'}
        exec(compile(bundle.read('Stage-PublicationCut.py'), 'Stage-PublicationCut.py', 'exec'), environment)
        verifier = {'__name__': '__pinned__'}
        exec(compile(bundle.read('Verify-NativePublicationCut.py'), 'Verify-NativePublicationCut.py', 'exec'), verifier)
        all_fields = bundle.read('Native/Operators.csv')
        native = verifier['read_tensor_frames'](bundle.read('Native/MVTGaussMixed.Tensor.csv'), 45)
        rows = []
        for line in all_fields.decode('ascii').splitlines():
            if line.startswith('F;'):
                _, phase, *values = line.split(';')
                t, q, _ = native[phase]
                rows.append(';'.join((phase, f'{q:.15g}', f'{t:.15g}', *values)))
        assert len(rows) == 22 and rows[-1].split(';')[:3] == ['S10A21875', '21875', '10510000']
        environment['stage'](repo, target)

    inputs = target / 'Preparation.json'
    index = json.loads(inputs.read_bytes())
    test = target / environment['TEST']
    source = test.read_text(encoding='utf-8-sig')
    anchor = '    Dim targets As Variant, target As Variant, stage As Long, reached As Double, previousCount As Long, item As Long'
    assert source.count(anchor) == 1
    insert = (
        '    If followMixed Then\n'
        '        RunMVT2TorqueContinuationTest = TestPublicationRecovery(solver, operators, concrete, response, _\n'
        '            minusConcrete, minusSide, plusConcrete, plusSide, report, tracePath)\n'
        '        Exit Function\n'
        '    End If\n'
    )
    source = source.replace(anchor, insert + anchor)
    probe = (HERE / 'PublicationRecovery.bas.txt').read_text(encoding='utf-8-sig')
    if branch_test:
        probe = probe.replace('ATOL, RTOL, MAX_ITERATIONS)', 'ATOL, RTOL, MAX_ITERATIONS, branchConsistentForTest:=True)')
        probe = probe.replace('ATOL, RTOL, MAX_ITERATIONS, seed)', 'ATOL, RTOL, MAX_ITERATIONS, seed, branchConsistentForTest:=True)')
    if split_test:
        anchor = '    ReDim seedValues(1 To 60)'
        assert probe.count(anchor) == 1
        probe = probe.replace(anchor, '    TestPublicationRecovery = TestPublicationSplit(solver, operators, stations, report, tracePath)\n'
                                      '    Exit Function\n' + anchor)
        probe += (HERE / 'PublicationRecoverySplit.bas.txt').read_text(encoding='utf-8-sig')
    source += probe
    source.encode('cp1251')
    test.write_bytes(source.replace('\n', '\r\n').encode('utf-8-sig'))

    replay = target / 'Replay.Fields.csv'
    assert all(len(row.split(';')) == 63 for row in rows)
    replay.write_bytes(('\r\n'.join(rows) + '\r\n').encode('ascii'))
    driver = target / environment['DRIVER']
    text = driver.read_text(encoding='utf-8-sig')
    text = text.replace(
        "    $env:TMP=$env:TEMP", "    $env:TMP=$env:TEMP\n    $env:NDM_MVT_REPLAY=(Resolve-Path -LiteralPath 'Replay.Fields.csv').Path"
    )
    touched = [test, driver, replay]
    if branch_test:
        text = text.replace("'CCoupledElasticState','modTestMVT2GaussSpan'",
                            "'CCoupledElasticState','modTestMVT2GaussSpan','CCoupledNewtonSolver'")
        solver_path = 'src/Solver/CCoupledNewtonSolver.cls'
        solver = (repo / solver_path).read_text(encoding='utf-8')
        key = 'Optional ByRef initialField As Variant, Optional ByVal retainDirectProof As Boolean = False) As Boolean'
        assert solver.count(key) == 1
        solver = solver.replace(key, 'Optional ByRef initialField As Variant, Optional ByVal retainDirectProof As Boolean = False, _\n'
                                     '        Optional ByVal branchConsistentForTest As Boolean = False) As Boolean')
        solver = solver.replace('    mControlActive = False\n    mConsistentControl = False',
                                '    mControlActive = False\n    mConsistentControl = branchConsistentForTest And mUseSpatialHistory', 1)
        solver = solver.replace('If mConsistentControl And norm > tolerance And norm <= SMALL_STRAIN_MAX_NORM * tolerance Then',
                                'If mControlActive And mConsistentControl And norm > tolerance And norm <= SMALL_STRAIN_MAX_NORM * tolerance Then', 1)
        branch = target / solver_path
        branch.write_bytes(solver.replace('\n', '\r\n').encode('utf-8'))
        touched.append(branch)
    driver.write_bytes(text.encode('utf-8'))
    for written in touched:
        index['inputs'][written.relative_to(target).as_posix()] = sha256(written.read_bytes()).hexdigest().upper()
    index['replayed_native_archive'] = EVIDENCE_SHA
    index['branch_consistent_fixed_force_test'] = branch_test
    index['adaptive_substeps_fixed_force_test'] = split_test
    inputs.write_bytes((json.dumps(index, indent=2) + '\n').encode())
    print('REPLAY PREPARED', len(rows), index['inputs'][environment['TEST']])


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', default=Path.cwd(), type=Path)
    parser.add_argument('--stage', required=True, type=Path)
    parser.add_argument('--branch-test', action='store_true')
    parser.add_argument('--split-test', action='store_true')
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve(), args.branch_test, args.split_test)
