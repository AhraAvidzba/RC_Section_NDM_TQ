"""Проверяет восстановление истории MVT2 и принятие малых силовых шагов."""

from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import re


CONTROL = 'MVT2NativePublicationCutRecovery20261117.zip'
CONTROL_SHA = '3ADDC2837E6D63A8B31C6CD2314CB47387AC437C1C786DE7A304AC18C9F19309'
BOOK_SHA = '1937BA79C0E032EFC8FE08FC18B300EA6E322E0267352487CB1ACA760CC1115F'


def pinned_archive(directory, name, fingerprint):
    path = directory / name
    assert sha256(path.read_bytes()).hexdigest().upper() == fingerprint
    return ZipFile(path)


def verify(repo, root):
    archives = repo / 'docs/regression/Coupled6D'
    proof = {'__name__': '__pinned__'}
    with pinned_archive(archives, CONTROL, CONTROL_SHA) as bundle:
        exec(compile(bundle.read('Verify-NativeRecovery.py'), 'Verify-NativeRecovery.py', 'exec'), proof)
    declaration = json.loads((root / 'Preparation.json').read_bytes())
    assert declaration['adaptive_substeps_fixed_force_test']
    assert not declaration['branch_consistent_fixed_force_test']
    assert declaration['source_book_sha256'] == proof['BOOK_SHA']
    assert declaration['replayed_native_archive'] == proof['PRIOR_SHA']
    for name in ('Replay.Fields.csv', 'Run-Native.ps1', 'tests/modTestMVT2GaussSpan.bas'):
        assert proof['digest']((root / name).read_bytes()) == declaration['inputs'][name]

    base = {'__name__': '__pinned__'}
    with pinned_archive(archives, proof['PRIOR'], proof['PRIOR_SHA']) as prior:
        exec(compile(prior.read('Verify-NativePublicationCut.py'), 'Verify-NativePublicationCut.py', 'exec'), base)
        reference = base['read_operators'](prior.read('Native/Operators.csv'))
        reference_tensors = base['read_tensor_frames'](prior.read('Native/MVTGaussMixed.Tensor.csv'), 45)
        reference_rows = [line.split(';') for line in prior.read('Native/MVTGaussMixed.csv').decode('cp1251').splitlines()]
    native = root / 'Native'
    report = (native / 'MVTGaussMixed.txt').read_text(encoding='utf-8-sig')
    proof['DIAGNOSTIC_SHA'][False] = BOOK_SHA
    owner, ticks = proof['checks_of_owner'](root, report, False)
    table = base['read_operators']((native / 'Operators.csv').read_bytes())
    tensor = base['read_tensor_frames']((native / 'MVTGaussMixed.Tensor.csv').read_bytes(), 45)
    rows = [line.split(';') for line in (native / 'MVTGaussMixed.csv').read_bytes().decode('cp1251').splitlines()]
    mesh = proof['geometry'](rows)
    assert all(table[key] == reference[key] for key in 'GLBSR') and mesh == proof['geometry'](reference_rows)

    history = [line.split(';') for line in (root / 'Replay.Fields.csv').read_text(encoding='ascii').splitlines()]
    assert len(history) == 22 and [row[0] for row in history] == list(reference['F'])
    for phase, q, t, *values in history:
        assert (float(t), float(q)) == reference_tensors[phase][:2]
        assert tuple(map(float, values)) == reference['F'][phase]
    start = proof['LAST_PHASE']
    assert table['F']['Replay'] == reference['F'][start]
    net_delta = max(abs(a-b) for side in (-1,0,1) for p in mesh[1]
                    for a,b in zip(table['H']['Replay',side,p], reference['H'][start,side,p], strict=True))
    assert net_delta < 5e-12 and 'MVT2_RECOVERY_REPLAY;22;21875' in report
    verified = [proof['equations']('Replay', tensor['Replay'], table, mesh) | {'Qy_N': 21875.}]
    count = [row for row in rows if row[0] == 'MVT2_SPLIT_TRIAL']
    q, increment, attempts, phases = 21875., 78.125, [], ['Replay']
    for index, row in enumerate(count, 1):
        _, number, previous, goal, ok, internal, code, *details = row
        assert ';'.join(row) in report
        assert int(number) == index and float(previous) == q
        assert increment >= 9.765625
        assert float(goal) == min(22500., q + increment)
        assert ok in ('True', 'False')
        stats = re.match(r'Итерации: (\d+); пробы: (\d+); невязка, МПа: ([0-9.Ee+-]+)', ';'.join(details))
        assert stats and int(stats[1]) <= 26
        attempts.append({'q_N': float(goal), 'accepted': ok == 'True', 'iterations': int(stats[1]),
                         'evaluations': int(stats[2]), 'reported_norm_MPa': float(stats[3])})
        if ok == 'True':
            assert (internal, code) == ('4','0')
            q = float(goal)
            phase = f'Split{index}'
            assert tensor[phase][:2] == (10510000., q)
            verified.append(proof['equations'](phase, tensor[phase], table, mesh) | {'Qy_N': q})
            phases.append(phase)
            increment = min(312.5, increment * 2.)
        else:
            assert (internal, code) == ('6','10')
            increment *= .5
    assert list(table['F']) == list(tensor) == phases
    assert set(table['H']) == {(phase, side, p) for phase in phases for side in (-1,0,1) for p in mesh[1]}
    assert 1 <= len(count) <= 16 and q > 21875.
    reached = q == 22500.
    assert f'TOTAL_MVT2_GAUSS_SPAN: passed=1; failed=0; target_reached={reached}' in report
    season, = [row for row in rows if row[0] == 'CASE_FINISHED']
    assert season[2] == str(reached) and 0 < float(season[3]) < 165
    assert reached or len(count) == 16 or increment < 9.765625
    return {'last_Qy_N':q, 'exact_target_reached':reached, 'target_N':22500.,
            'new_fields':len(verified)-1, 'fields':verified,'attempts':attempts,
            'replay_component_delta_MPa':net_delta, 'reported_macro_elapsed_s':float(season[3]),
            'closed_excel_pid':owner, 'closed_excel_ticks':ticks,
            'physical_limit_established':False}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    proof = verify(args.repo.resolve(), args.root.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, indent=2, sort_keys=True, allow_nan=False)
        output.write('\n')
    print('MVT2 NATIVE SPLIT OFFLINE PASS', proof['new_fields'], proof['last_Qy_N'])
