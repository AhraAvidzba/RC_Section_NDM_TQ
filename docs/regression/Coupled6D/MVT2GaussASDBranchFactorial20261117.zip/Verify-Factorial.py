"""Verify the stored branch factorial with an independent signed equation check."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
AUTH="MVT2GaussReequilibratedASD20261117"
AUTH_SHA="FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E"
REPORT_SHA="2EFB8356ADC6EB57D77CBEE2FF609DCD8F7CE4C0A2E9D3C63B393591111E3BC5"
STRESS_SHA="7D21B150A056C69C54125750CC8D58FEE18F57DACB4358CDC57D4CD9C55996D9"
STOCK_SHA="0210281C8593BAE1C5209F789BE5074885635F0E3FE6E9B0DD71FF9CCBCA5CB1"
SOURCE_SHA="3B1BD228F147770CBADA9C67FE9AE899C9FD9CB622BA423E6F5D0D388778573C"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def read(name,expected):
    data=(HERE/name).read_bytes()
    assert digest(data)==expected,name
    return data


def check_manifest():
    expected={}
    for line in (HERE/"SHA256SUMS").read_text(encoding="ascii").splitlines():
        sha,name=line.split("  ",1)
        path=PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts and name not in expected
        expected[name]=sha
        read(name,sha)
    assert set(expected)=={p.relative_to(HERE).as_posix() for p in HERE.rglob("*")
                           if p.is_file() and p.name!="SHA256SUMS"}


def verify(repo):
    check_manifest()
    read("CurveFactor.py",SOURCE_SHA)
    data=json.loads(read("CurveFactor.json",REPORT_SHA))
    stresses=json.loads(gzip.decompress(read("CurveFactor.stress.json.gz",STRESS_SHA)))
    stock=json.loads(read("StockTables.json",STOCK_SHA))
    assert data["status"]=="PASS" and data["engine"]=="3.8.0" and data["numpy"]=="2.3.5"
    assert data["stock_tables_SHA256"]==STOCK_SHA and data["raw_accepted_stress_sha256"]==STRESS_SHA
    assert data["physical_limit_established"] is False and data["tables"]["stock"]==stock
    assert data["stock_from_tables_fixed_kinematics_max_stress_diff_MPa"]==0.
    assert data["stock_from_tables_equilibrium_crosscheck"]=={
        "rebuilt_stock_full_curve_matches_target_sequence":True,
        "rebuilt_stock_max_twist_difference_rad_per_m":0.}
    pin=repo/"docs/regression/Coupled6D"/(AUTH+".zip")
    assert digest(pin.read_bytes())==AUTH_SHA
    with tempfile.TemporaryDirectory(prefix="MVTASDTableFactor_") as folder:
        work=Path(folder)
        with ZipFile(pin) as archive:
            for name in ("Operators.py","Reequilibrate.py","Verify-Authoritative.py","Authoritative.json",
                         "Authoritative.stress.json.gz"):
                (work/name).write_bytes(archive.read(name))
        sys.path.insert(0,str(work))
        guard=runpy.run_path(str(work/"Verify-Authoritative.py"))
        op_path,fixed_source=guard["unpack"](work,repo)
        run=runpy.run_path(str(work/"Reequilibrate.py"))
        shared,native,geom,dirs,area,length,op,seeds,observed,ident=run["read_inputs"](op_path,work,fixed_source)
        assert data["native_operators"]==ident
        original=(work/"Authoritative.json").read_bytes()
        assert digest(original)==data["common_equilibrium_SHA256"]==guard["REPORT_SHA"]
        baseline=json.loads(original)
        baseline_raw=(work/"Authoritative.stress.json.gz").read_bytes()
        assert digest(baseline_raw)==guard["STRESSES_SHA"]
        assert stresses["stock_from_tables"]==json.loads(gzip.decompress(baseline_raw))["default"]
        assert data["runs"]["stock_from_tables"]==baseline["modes"]["default"]
        expected={"stock_from_tables":26,"replace_compression":26,"replace_tension":8}
        assert set(stresses)==set(data["runs"])==set(expected)
        outcome={}
        for name,n in expected.items():
            item=data["runs"][name]
            results=item["accepted"]
            assert len(results)==len(stresses[name])==n
            assert item["physical_limit_established"] is False and item["rejected_trial_interleaving_max_MPa"]==0.
            assert [r["phase"] for r in results]==[f["phase"] for f in native["frames"][:n]]
            measurements=[guard["check"](net,rec,geom,dirs,area,length,op)
                          for net,rec in zip(stresses[name],results,strict=True)]
            anchors={r["phase"]:r["twist_rad_per_m"] for r in results}
            assert data["twist_anchors_rad_per_m"][name]=={k:anchors.get(k) for k in ("R8","S1","S18")}
            outcome[name]={"frames":n,"max_equilibrium_norm_MPa":max(m[0] for m in measurements),
                           "max_steel_utilization":max(m[1] for m in measurements),
                           "last_Qy_N":results[-1]["Q_target_N"]}
        stop=data["runs"]["replace_tension"]["terminal"]
        assert stop["reason"]=="bounded_numerical_stop" and stop["last_reached_Q_N"]==0. and stop["Q_requested_N"]==5000.
        assert data["runs"]["replace_tension"]["attempts"][-1]["Q_N"]==156.25
        assert all(data["runs"][name]["complete_nominal_targets"] for name in ("stock_from_tables","replace_compression"))
    print("MVT2 ASD BRANCH FACTORIAL OFFLINE PASS",REPORT_SHA,STRESS_SHA,outcome)


if __name__=="__main__":
    p=ArgumentParser()
    p.add_argument("--repo",type=Path,default=Path.cwd())
    verify(p.parse_args().repo)
