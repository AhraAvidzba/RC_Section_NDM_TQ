"""Compare the separate effects of substituting each ASD uniaxial branch."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from types import SimpleNamespace
import gzip
import json
import runpy
import sys
import faulthandler

sys.dont_write_bytecode=True
from Reequilibrate import HERE,NUMPY,commands,read_inputs,simulate

OPS_FILE=Path("D:/CodexScratch/RC_Section_NDM_TQ/MVTGauss25Operators/Native/Operators.csv")
DATA_SHA="393EA5BED46723E5AA37544B6E8334D982ED15545D1E31F88D1A5716D506C463"


def digest(data):
    return sha256(data).hexdigest().upper()


def extract_stock(shared, report, ops):
    envelope=runpy.run_path(str(shared["D"]/shared["ENVELOPE"]))
    point_brick=runpy.run_path(str(shared["D"]/shared["BRICK"]))["brick"]
    default=commands(shared,report,("default",))["default"]
    point_brick(lambda tag:ops.nDMaterial(default[0],tag,*default[1:]),
        [tuple(report["frames"][0]["points"][2][:6])],SimpleNamespace(components=shared["voigt"]),125.)
    return {name:tuple(envelope["read_installed_branch"](1,1,name.lower())) for name in ("TENSION","COMPRESSION")}


def descriptions(shared, report, stock):
    envelope=runpy.run_path(str(shared["D"]/shared["ENVELOPE"]))
    ndm,knot_error=shared["exact_tables"](report)

    def installable(tension,compression):
        args=["ASDConcrete3D",*report["model"][:2]]
        for tag,rows in (("T",tension),("C",compression)):
            envelope["validate_branch"](rows,report["model"][0],tag)
            for i,field in enumerate("esd"):
                args.extend([f"-{tag}{field}",*(r[i] for r in rows)])
        return [*args,"-tangent"]

    variants={"stock_from_tables":installable(*stock.values()),
              "replace_tension":installable(ndm["TENSION"],stock["COMPRESSION"]),
              "replace_compression":installable(stock["TENSION"],ndm["COMPRESSION"])}
    return variants,{"stock":stock,"NDM":ndm,"native_export_anchor_error":knot_error}


def main():
    cli=ArgumentParser(description=__doc__)
    cli.add_argument("--operators",type=Path,default=OPS_FILE)
    cli.add_argument("--out",type=Path,default=HERE/"CurveFactor.json")
    cli.add_argument("--numpy",type=Path,default=NUMPY)
    cli.add_argument("--only",choices=("stock_from_tables","replace_tension","replace_compression","all"),default="all")
    cli.add_argument("--extract-stock",action="store_true")
    cli.add_argument("--stock",type=Path,default=HERE/"StockTables.json")
    args=cli.parse_args()
    sys.path.insert(0,str(args.numpy))
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=="3.8.0"
    sh,data,geo,dirs,area,length,op,seeds,observed,verification=read_inputs(args.operators)
    frozen=(HERE/"Authoritative.json").read_bytes()
    assert digest(frozen)==DATA_SHA
    anchor=json.loads(frozen)
    if args.extract_stock:
        tables=extract_stock(sh,data,ops)
        encoded=(json.dumps(tables,indent=2,allow_nan=False)+"\n").encode()
        with args.stock.open("xb") as f:
            f.write(encoded)
        print("STOCK CURVES",digest(encoded))
        return
    faulthandler.dump_traceback_later(18,exit=True)
    stock_wire=args.stock.read_bytes()
    stock=json.loads(stock_wire)
    variants,tables=descriptions(sh,data,stock)
    prescribed=[[p[:6] for p in f["points"]] for f in data["frames"]]
    raw_reference=(HERE.parent/"mvt-fixed-history/FixedHistory.stress.json.gz").read_bytes()
    assert digest(raw_reference)=="D0B49CF7F92FF496AB641B70EC80021F9D563EF35297DFEEE2D6E12556534787"
    target=json.loads(gzip.decompress(raw_reference))["ASD_default"]
    print("COMPARE STOCK REIMPORTED",flush=True)
    assigned=sh["response"](ops,variants["stock_from_tables"],prescribed)
    delta=max(abs(x-y) for f,g in zip(target,assigned,strict=True) for a,b in zip(f,g,strict=True) for x,y in zip(a,b,strict=True))
    assert delta<1e-9,delta
    faulthandler.cancel_dump_traceback_later()
    result={};raw={}
    deadline=perf_counter()+110.
    for name,command in variants.items():
        if args.only != "all" and args.only != name:
            continue
        print("START",name,flush=True)
        try:
            result[name],raw[name]=simulate(np,ops,sh,data,geo,dirs,area,length,op,seeds,name,command,deadline,26)
        finally:
            ops.wipe()
        print("FINISH",name,result[name]["last_confirmed"],flush=True)
    check_early={}
    rebuilt=result.get("stock_from_tables",{}).get("accepted",[])
    stock=anchor["modes"]["default"]["accepted"]
    station_match=[(a,b) for a,b in zip(rebuilt,stock,strict=False)
                   if a["phase"]==b["phase"] and a["subdivision"]==b["subdivision"]]
    check_early["rebuilt_stock_full_curve_matches_target_sequence"]=len(station_match)==len(stock)==26
    check_early["rebuilt_stock_max_twist_difference_rad_per_m"]=max((abs(a["twist_rad_per_m"]-b["twist_rad_per_m"]) for a,b in station_match),default=None)
    if check_early["rebuilt_stock_full_curve_matches_target_sequence"]:
        assert check_early["rebuilt_stock_max_twist_difference_rad_per_m"] < 1e-8
    anchor_theta={}
    for name,batch in {**anchor["modes"],**result}.items():
        tags={r["phase"]:r["twist_rad_per_m"] for r in batch["accepted"]}
        anchor_theta[name]={p:tags.get(p) for p in ("R8","S1","S18")}
    interaction={}
    for phase in ("R8","S1","S18"):
        x=[anchor_theta.get(name,{}).get(phase) for name in ("explicit","replace_tension","replace_compression","default")]
        if None not in x:
            interaction[phase]=x[0]-x[1]-x[2]+x[3]
    sha_rows=gzip.compress(json.dumps(raw,sort_keys=True,separators=(",",":"),allow_nan=False).encode(),mtime=0,compresslevel=9)
    with args.out.with_suffix(".stress.json.gz").open("xb") as f:
        f.write(sha_rows)
    proof={"status":"PASS","engine":ops.version(),"numpy":np.__version__,"common_equilibrium_SHA256":DATA_SHA,
           "stock_tables_SHA256":digest(stock_wire),
           "native_operators":verification,"stock_from_tables_fixed_kinematics_max_stress_diff_MPa":delta,
           "stock_from_tables_equilibrium_crosscheck":check_early,"tables":tables,
           "twist_anchors_rad_per_m":anchor_theta,"table_factor_interaction_rad_per_m":interaction,
           "raw_accepted_stress_sha256":digest(sha_rows),"runs":result,"physical_limit_established":False}
    content=(json.dumps(proof,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
    with args.out.open("xb") as f:
        f.write(content)
    print("PASS",digest(content))


if __name__=="__main__":
    main()
