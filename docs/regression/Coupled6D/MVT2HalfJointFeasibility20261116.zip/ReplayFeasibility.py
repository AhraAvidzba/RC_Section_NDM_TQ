"""Materialize only the required tracked A2-free MVT archives for a portable replay."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
ARCHIVES={
    "MVT2JointCenterGradientNative20261116.zip":("joint2","47B975208823EF5563F76CB759F4FAED557529D0BCEA90CE4F503BCC1BE2029C"),
    "MVT2MeasuredNormalsNative20261116.zip":("forceN","84DAF40599AD0FE9A0AE1C2EBA2CF2F72DED306F0F47B222F1A0528216D50A86"),
    "MVT2Force15Native20261116.zip":("force15","AAF97ABED8510F390488F2A5C515E57431BED7ED56694181D2CD763F35A8900F"),
    "MVT2ReactedFreshNative20261116.zip":("force-lock","5DCAB88E25FD13C1DB6C43A8898243D2AF03E906ADA2F87C31A17638E84ABA3E"),
}
OUTPUTS={
    "Study.json":"086DB01D62EB263A0565266292220301E55247CA53F14AFFD02E8ECDC2F31ACD",
    "ComplementScreen.json":"AE301B673E2B2C5ADCF311A89018DF75D0F247C2F418A75469FBB0352010BF2F",
}


def digest(data):
    return sha256(data).hexdigest().upper()


def main(location):
    assert all(digest((location/name).read_bytes())==check for name,(_,check) in ARCHIVES.items())
    with TemporaryDirectory(prefix="mvt-halfjoint-replay-",dir=HERE) as private:
        root=Path(private)
        for name,(subpath,_) in ARCHIVES.items():
            directory=root/subpath
            directory.mkdir(parents=True,exist_ok=True)
            if subpath!="force-lock":
                shutil.copyfile(location/name,directory/name)
        with ZipFile(location/"MVT2JointCenterGradientNative20261116.zip") as joint:
            (root/"joint2/PlanJoint.py").write_bytes(joint.read("PlanJoint.py"))
        with ZipFile(location/"MVT2ReactedFreshNative20261116.zip") as fresh:
            for selected in ("PlanFresh.py","NativeA/MVT2.csv"):
                dst=root/"force-lock/Run"/selected
                dst.parent.mkdir(parents=True,exist_ok=True)
                dst.write_bytes(fresh.read(selected))
        scratch=root/"Computed"
        for script in ("Study.py","Screen.py"):
            subprocess.run([sys.executable,"-B","-X","utf8",str(HERE/script),str(root),str(scratch)],check=True)
        for name,expected in OUTPUTS.items():
            data=(scratch/name).read_bytes()
            raw=data.replace(b"\r\n",b"\n")
            normalized=raw.replace(b"\n",b"\r\n")
            rendered=data if digest(data)==expected else normalized
            assert digest(rendered)==expected==(digest((HERE/"Run"/name).read_bytes())),name
            (HERE/("Replay"+name)).write_bytes(rendered)
    result={"archive_dependencies_sha256":{name:value for name,(_,value) in ARCHIVES.items()},
            "reproduced_reports_sha256":OUTPUTS,"mode":"offline_halfjoint_measured_actions_and_linear_algebra_only"}
    output=HERE/"ReplayEvidence.json"
    data=(json.dumps(result,indent=2)+"\n").encode("utf8")
    output.write_bytes(data)
    print("PASS HalfJoint decision replay",output.name,digest(data))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive-dir",type=Path,required=True)
    main(p.parse_args().archive_dir.resolve(strict=True))
