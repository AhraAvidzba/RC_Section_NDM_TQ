"""Test the possible benefit of a fresh tangent outside the measured four-axis span."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np

from Study import actions,decode,strain,sources


def main(root,out):
    files=sources(root,out)
    sys.path[:0]=[str(files),str(root/"force-lock/Run"),str(root/"joint2")]
    import VerifyBase as v
    import PlanFresh as model
    import PlanJoint as prior
    raw=decode(v,files)
    key,calc=actions(v,raw)
    q,r,station,base=raw["Joint:HalfJoint"]
    S,G=strain(v,base["geometry"])
    tags=v.read_native(root/"force-lock/Run/NativeA/MVT2.csv")
    states,ss=v.verified_states(tags)
    close=states["Reacted"]
    older=prior.physical(v,close,ss["Reacted"])
    previous,_,_=model.assembled(tags,older,close,base["geometry"],base["q"])
    recipe=("CenterFromGradient","GradientFromCenter","PreviousNormals","PreviousForce")
    D=np.array([calc[k][0] for k in recipe]).T
    Y=np.array([calc[k][1] for k in recipe]).T
    Yields=np.array([calc[k][2] for k in recipe]).T
    weighted=S@D
    weighted_center=S[:,:52]@D[:52]
    partial_pinv=np.linalg.pinv(weighted,rcond=1e-11)
    geometric=partial_pinv@S
    geometric_center=np.linalg.pinv(weighted_center,rcond=1e-11)@S[:,:52]
    modes={}
    for label in ("Consistent","Refined"):
        J=previous[label].copy()
        modes[label]=J
        C=J+(Y-J@D)@geometric
        C[56:62,:52]=J[56:62,:52]+(Y[56:62]-J[56:62,:52]@D[:52])@geometric_center
        C[56:62,52:]=0.
        assert np.max(abs(C@D-Y))<2e-12
        modes[label+"Measured"]=C
    known=v.read(files/"NormalReport.json")
    index={st:i for i,st in enumerate(base["geometry"])}
    known_normals={}
    for row in known["station_branch_gradients"]:
        point=row["point"],row["side"]
        sx=S[6*index[point]:6*(index[point]+1)].copy()
        sx[3:]*=np.sqrt(2.)
        known_normals[point]=np.array(row["gradient_after"])@sx
    flags=[]
    for i,point in enumerate(key):
        observed=Yields[i]
        slopes=observed@geometric
        if point in known_normals:
            exact=known_normals[point]
            slopes=exact+(observed-exact@D)@geometric
        assert max(abs(slopes@D-observed))<2e-10
        flags.append((point,station[point][6],slopes))
    initial=v.read(files/"JointPlan.json")
    caps=np.asarray(initial["original_caps_MPa"])
    # Reserve the largest latest difference on either measured edge and the
    # originally guarded error. Orthogonal derivative accuracy remains unmeasured.
    edge=max(np.max(abs(calc["CenterFromGradient"][1]-calc["CenterFromBase"][1])),
             np.max(abs(calc["GradientFromCenter"][1]-calc["GradientFromBase"][1])))
    errors=np.maximum(edge,np.array(initial["last_full_vector_actual_defect_MPa"]))
    data=v,modes,r,G,S,flags,caps,errors,base["tol_MPa"]
    finalists=[]
    for radius in (1e-8,2e-8,4e-8,8e-8):
        trial=prior.solve(data,radius,False)
        if "predicted" in trial:
            dof=np.asarray(trial["predicted"]["joint"]["dq"])
            physical=S@dof
            complement=physical-weighted@(partial_pinv@physical)
            trial.update(independent_physical_fraction=float(np.linalg.norm(complement)/np.linalg.norm(physical)),
                         minimum_branch_fraction_unmeasured_prediction=float(min((F+n@dof)/F for _,F,n in flags)))
        finalists.append(trial)
    report={"A_archive_trace_sha256":v.digest(root/"force-lock/Run/NativeA/MVT2.csv"),
        "old_tangent_is_not_at_HalfJoint":True,"full_fresh_section_tangent_available":False,
        "only_9_fresh_branch_normals_while_other_66_surface_components_are_measured_directional_predictions":True,
        "relative_direct_action_curvature_uncertainty_MPa":float(edge),
        "screens_broad_only":finalists,
        "actual_pose_equilibrium_certified":False,
        "next_experiment_if_headroom": "One exact HalfJoint freeze with whole-section branch-sensitive material derivatives and all 75 surface normals, followed by a bounded joint correction only if frozen-response validation succeeds."}
    output=out/"ComplementScreen.json"
    output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
    print(output,v.digest(output))
    for t in finalists:
        print(t["radius"],t.get("gain_over_tau"),t.get("independent_physical_fraction"),t.get("status"))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("workspace",type=Path)
    p.add_argument("out",type=Path)
    a=p.parse_args()
    main(a.workspace.resolve(),a.out.resolve())
