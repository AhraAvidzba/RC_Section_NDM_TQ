"""Audit stock, globally refined, and tensile-band-local finite differences on the captured row81 field."""
from argparse import ArgumentParser
from pathlib import Path
from hashlib import sha256
from collections import Counter
from zipfile import ZipFile
import json
import runpy

import numpy as np

WITNESS_ARCHIVE='4B65725C0977E6855720BFBD0F9CA7D5D3FCF0AD3F4C1C0A8FA68F73DECDA701'
TRACE='742A063E044EA739BF528623A187B64116CE6D6C105809C9194FAEEF4C4829A9'
MODE_EXTERIOR='DeviatoricReturnOutsideBand'
MODE_APEX='ApexTransition'
MODE_ELASTIC='Elastic'


def analyze(repo, root):
    witness=repo/'docs/regression/Coupled6D/KaniH45Row81DirectionPortable.zip'
    assert sha256(witness.read_bytes()).hexdigest().upper()==WITNESS_ARCHIVE
    with ZipFile(witness) as z:
        anchored=z.read('Manifest.json')
    assert (root/'Manifest.json').read_bytes()==anchored
    assert all(sha256((root/n).read_bytes()).hexdigest().upper()==d for n,d in json.loads(anchored)['files'].items())
    path=root/'KaniRowVerification.json'
    assert sha256(path.read_bytes()).hexdigest().upper()==TRACE
    measured=json.loads(path.read_text(encoding='utf8'))
    assert measured['matrixMaterialMode']==3
    api=runpy.run_path(root/'Replay-Row.py')['row_api'](portable=True)
    model,geometry=runpy.run_path(root/'Classify-Row.py')['inputs'](repo)
    context=runpy.run_path(root/'AltVerifier.py')
    archive,cert,operators,_=context['archived_inputs'](repo)
    native,stresses,tangents,_,_,stations,_=api['parse']()
    a_ix=list(archive['names']).index('Committed45')
    p=archive['stations'][archive['station_index'][a_ix]]
    energy=np.array(cert['energiesByStation_minus0plus']['Committed45'])
    h,_,_,_,area,_=operators(archive['geometry'],float(archive['length']))
    d=native['CORRECTION'][:87]
    eps_action=h@d[:79]+np.array([-.001,0.,.001])[:,None,None]*(h[:,:,:4]@d[79:83])[None]
    ops_width=2e-9
    directions=np.zeros((184,6))
    directions[144:,:4]=geometry[144:,3:]
    output=[]
    skipped=Counter()
    eta=np.eye(6)

    for side in (-1,1):
        i=side+1
        for j in range(184):
            g=directions[j]
            accepted_nominal=p[i,j,6:].copy()
            if j>=144:
                accepted_nominal=200000.*np.dot(g,p[i,j,:6])*g-accepted_nominal
            nominal=model['matrix'](accepted_nominal)
            kt,kc=energy[i,j]
            row=stations['Base'][i,j]
            local=row[4:10]
            inc=local-p[i,j,:6]

            def response(change):
                s,detail=model['return_apex'](nominal,kt,kc,inc+change)
                ss=np.array(model['vector'](s))
                if j>=144:
                    eps=local+change
                    axial=200000.*np.dot(g,eps)
                    if abs(axial)>=min(400.,442.):
                        raise ValueError('SteelOutsideVerifiedElasticRange')
                    ss=axial*g-ss
                return ss,detail

            try:
                s0,detail=response(np.zeros(6))
                if max(abs(s0-stresses['BASE_STRESS'][i,j]))>2e-10 or abs(detail['Ftrial']-row[3])>2e-9:
                    raise ValueError('UnsupportedBaseNativeReplay')
                if row[2]!=1:
                    raise ValueError('UnsupportedMultipleSubsteps')
                true=np.column_stack([np.array(model['vector'](model['apex_jvp'](nominal,kt,kc,inc,e)[0])) for e in eta])
                if j>=144:
                    true=200000.*np.outer(g,g)-true
                mode0=detail['kind']
                is_plastic=bool(row[0])
                weight=side*geometry[j,1]*area[j]/(float(archive['length'])*.002)
                u=eps_action[i,j]

                def fd(col,scale):
                    for tr in range(3):
                        dh=ops_width*(1+abs(local[col]))*scale/(4**tr)
                        plus,dplus=response(eta[col]*dh)
                        minus,dminus=response(-eta[col]*dh)
                        good_plus=(dplus['kind']!=MODE_ELASTIC)==is_plastic
                        good_minus=(dminus['kind']!=MODE_ELASTIC)==is_plastic
                        if good_plus and good_minus:
                            return (plus-minus)/(2*dh),[dplus['kind'],dminus['kind']],tr
                        if good_plus:
                            return (plus-s0)/dh,[dplus['kind'],dminus['kind']],tr
                        if good_minus:
                            return (s0-minus)/dh,[dplus['kind'],dminus['kind']],tr
                    raise ValueError('NoBranchConsistentSign')

                stock=[]; refined=[]; local_fd=[]; paired_fd=[]; adaptive_fd=[]; trigger=[]; all_trigger=[]; divisions={}; rotations=[]
                for c in range(6):
                    b,branches,cut=fd(c,1.)
                    f,refined_branches,_=fd(c,1/64.)
                    crossed=(mode0==MODE_EXTERIOR and MODE_APEX in branches)
                    if crossed:
                        if refined_branches!=[MODE_EXTERIOR,MODE_EXTERIOR]:
                            raise ValueError('RefineStillCrossesExteriorBand')
                        trigger.append(c+1)
                    stable_pair=(mode0!=MODE_ELASTIC and branches!=[mode0,mode0] and refined_branches==[mode0,mode0])
                    if stable_pair:
                        all_trigger.append(c+1)
                    usable=b
                    if mode0!=MODE_ELASTIC and branches!=[mode0,mode0]:
                        for denom in (4,16,64):
                            size=ops_width*(1+abs(local[c]))/denom
                            pos,ip=response(eta[c]*size)
                            neg,im=response(-eta[c]*size)
                            if [ip['kind'],im['kind']]==[mode0,mode0]:
                                usable=(pos-neg)/(2*size)
                                divisions[c+1]=denom
                                break
                    stock.append(b); refined.append(f); local_fd.append(f if crossed else b)
                    paired_fd.append(f if stable_pair else b)
                    adaptive_fd.append(usable)
                    rotations.append({'large':branches,'small':refined_branches,'stockCuts':cut})
                mats={k:np.column_stack(m) for k,m in (('Stock',stock),('Global64',refined),('TensileExteriorGuard64',local_fd),('TensileSameRegionPairGuard64',paired_fd),('TensileSameRegionPairAdaptive',adaptive_fd))}
                # Reconstruct exact native stock tangent as a cross-check, allowing
                # external-script and VBA arithmetic to differ at the last digits.
                native_diff=abs(mats['Stock'][2]-tangents[i,j])
                if max(native_diff)>5e-3:
                    raise ValueError('StockColumnsDoNotReproduceNative')
                expected=float(weight*(true[2]@u))
                deviations={k:{'actionErrorMPa':float(weight*(m[2]@u))-expected,
                               'maxTensorErrorMPa':float(np.max(abs(m-true)))}
                            for k,m in mats.items()}
                output.append({'point':j+1,'side':side,'baseRegion':mode0,'columnsWithTensileBandCrossing':trigger,
                               'columnsWithRestoredSameRegionPair':all_trigger,'adaptiveColumnDenominators':divisions,'branchProbesByColumn':rotations,'nativeJzzColumnMismatchMPa':float(max(native_diff)),
                               'analyticRow81ActionMPa':expected,'error':deviations,
                               'predictedStressMPa':s0.tolist(),'predictedF_MPa':float(detail['Ftrial']),
                               'historicalCoarseFlags':row[:3].astype(int).tolist(),
                               'predictedTangentMPa':{k:m.tolist() for k,m in mats.items()}})
            except ValueError as e:
                skipped[str(e)]+=1
            except (AssertionError,ZeroDivisionError,np.linalg.LinAlgError):
                skipped['UnsupportedAnalyticBracket']+=1

    def summary(k):
        rows=[x['error'][k] for x in output]
        return {'signedActionErrorMPa':sum(r['actionErrorMPa'] for r in rows),
                'sumAbsoluteActionErrorMPa':sum(abs(r['actionErrorMPa']) for r in rows),
                'maxFullTensorErrorMPa':max(r['maxTensorErrorMPa'] for r in rows)}

    def harm(x):
        e=x['error']
        return abs(e['Global64']['actionErrorMPa'])-abs(e['Stock']['actionErrorMPa'])

    unchanged=[x for x in output if not x['columnsWithTensileBandCrossing']]
    counterexamples=sorted(unchanged,key=harm,reverse=True)[:5]
    trigger=[x for x in output if x['columnsWithTensileBandCrossing']]
    paired=[x for x in output if x['columnsWithRestoredSameRegionPair']]
    adapted=[x for x in output if x['adaptiveColumnDenominators']]
    return {'traceSHA256':TRACE,'qualifiedSideStations':len(output),'unknownSideStations':368-len(output),
            'exclusionsCount':dict(skipped),'replayedBaseModes':dict(Counter(x['baseRegion'] for x in output)),
            'summary':{k:summary(k) for k in ('Stock','Global64','TensileExteriorGuard64','TensileSameRegionPairGuard64','TensileSameRegionPairAdaptive')},
            'tensileBandTrigger':{'stationCount':len(trigger),'columnCount':sum(len(x['columnsWithTensileBandCrossing']) for x in trigger),
                                  'stations':[([x['point'],x['side']],x['columnsWithTensileBandCrossing']) for x in trigger]},
            'tensileSameRegionPairTrigger':{'stationCount':len(paired),'columnCount':sum(len(x['columnsWithRestoredSameRegionPair']) for x in paired),
                                      'stations':[([x['point'],x['side']],x['columnsWithRestoredSameRegionPair']) for x in paired]},
            'adaptiveSameRegionPairTrigger':{'stationCount':len(adapted),'columnCount':sum(len(x['adaptiveColumnDenominators']) for x in adapted),
                        'denominatorHistogram':dict(Counter(i for x in adapted for i in x['adaptiveColumnDenominators'].values())),
                        'stations':[([x['point'],x['side']],x['adaptiveColumnDenominators']) for x in adapted]},
            'globalRefinementIncreaseAtUntriggeredStations':{
               'beyond1eMinus12MPa':sum(harm(x)>1e-12 for x in unchanged),
               'beyond1eMinus10MPa':sum(harm(x)>1e-10 for x in unchanged),
               'worstStationAction':max((harm(x) for x in unchanged),default=None),
               'topFive':counterexamples},
            'qualifiers':output}


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--repo-root',type=Path,required=True)
    p.add_argument('--witness-root',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    results=analyze(a.repo_root.resolve(),a.witness_root.resolve())
    data=json.dumps(results,indent=2,allow_nan=False)+'\n'
    a.out.write_text(data,encoding='utf8')
    print(sha256(a.out.read_bytes()).hexdigest().upper())
    print(json.dumps({k:v for k,v in results.items() if k in ('qualifiedSideStations','replayedBaseModes','summary','tensileBandTrigger')},indent=2))
