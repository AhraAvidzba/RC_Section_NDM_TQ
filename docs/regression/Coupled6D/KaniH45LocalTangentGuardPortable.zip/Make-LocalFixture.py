"""Extract ten already measured station strains for a read-only native column check."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import runpy

SLOTS=((8,1),(137,-1),(9,1),(136,-1),(161,1),(161,-1),(177,1),(177,-1),(8,-1),(137,1))
REFERENCE='742A063E044EA739BF528623A187B64116CE6D6C105809C9194FAEEF4C4829A9'


def build(root, output):
    assert sha256((root/'KaniRowVerification.json').read_bytes()).hexdigest().upper()==REFERENCE
    a=runpy.run_path(root/'Replay-Row.py')['row_api'](portable=True)
    *_,stations,errors=a['parse']()
    assert not errors
    fields=stations['Base']
    lines=[f'KANI_LOCAL_COLUMNS;{len(SLOTS)}']
    for point,side in SLOTS:
        eps=fields[side+1,point-1,4:10]
        lines.append(';'.join([str(point),str(side),*(format(float(s),'.17g') for s in eps)]))
    output.write_bytes(('\r\n'.join(lines)+'\r\n').encode('ascii'))
    print(output,sha256(output.read_bytes()).hexdigest().upper())


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--witness-root',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    build(a.witness_root.resolve(),a.out)
