"""Compare captured stock/B/C station columns with independent H45 station predictions."""
from argparse import ArgumentParser
from pathlib import Path
import csv
import json
import numpy as np

SLOTS={(8,1),(137,-1),(9,1),(136,-1),(161,1),(161,-1),(177,1),(177,-1),(8,-1),(137,1)}
VARIANTS={'A':'Stock','B':'Global64','C':'TensileSameRegionPairAdaptive'}
H=Path(__file__).resolve().parent


def history(path):
    out={}
    with path.open(encoding='cp1251',newline='') as stream:
        for tag,p,s,*row in csv.reader(stream,delimiter=';'):
            key=(int(p),int(s))
            assert tag=='TANGENT' and key not in out and len(row)==46
            out[key]=np.array(row,float)
    assert set(out)==SLOTS
    return out


def compare(value, mode, stock=None):
    variant=VARIANTS[mode]
    audit=json.loads((H/'LocalTangentAudit.json').read_text(encoding='utf8'))
    expected={(x['point'],x['side']):x for x in audit['qualifiers']}
    report=[]
    for key, r in value.items():
        p=expected[key]
        assert r[:3].astype(int).tolist()==p['historicalCoarseFlags']
        assert abs(r[3]-p['predictedF_MPa'])<2e-9
        assert max(abs(r[4:10]-p['predictedStressMPa']))<2e-10
        native=r[10:].reshape(6,6)
        target=np.array(p['predictedTangentMPa'][variant])
        error=abs(native-target)
        assert np.max(error)<8e-3,(variant,key,float(np.max(error)))
        if stock is not None:
            origin=stock[key]
            assert np.array_equal(r[:10],origin[:10]),key
            if mode=='C':
                mask={int(c) for c in p['adaptiveColumnDenominators']}
                for c in range(1,7):
                    if c not in mask:
                        assert np.array_equal(native[:,c-1],origin[10:].reshape(6,6)[:,c-1]),(key,c)
        report.append({'point':key[0],'side':key[1],'variant':mode,'fullTangentMismatchMPa':float(np.max(error)),
                       'expectedLocalDivisors':p['adaptiveColumnDenominators'] if mode=='C' else None})
    return report


if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('--native',type=Path,required=True)
    p.add_argument('--mode',choices=tuple(VARIANTS),required=True)
    p.add_argument('--stock',type=Path)
    a=p.parse_args()
    print(json.dumps(compare(history(a.native),a.mode,history(a.stock) if a.stock else None),indent=2))
