"""Verify the plain geometric bridge, remaining budget and exact fixed target."""
import argparse
from collections import defaultdict
from math import hypot
import json
from pathlib import Path

import OwnBase as own
from OwnBase import prior, v

HERE=Path(__file__).resolve().parent


def prepare():
    data=own.prepare()
    witness=v.read(HERE/"BranchWitness.json")
    assert witness["role"]=="readback only" and witness["arc"]["fingerprint"]==witness["fixed"]["fingerprint"]
    assert [float(witness[item]["wire_q_and_lambda"][1]) for item in ("arc","fixed")]==[18.5803206785171,18.5807648320799]
    return data,witness


def verify(data,witness):
    previous=own.verify(*data)
    assert len(previous["trials"])==1 and not previous["trials"][0]["returned_trial"]
    raw=v.read_native(own.NATIVE)
    snapshots=prior.by_name(raw,"B_ARC_HISTORY")
    for name in ("BridgeBefore","BridgeAfterArc","BridgeAfterFixed"):
        assert snapshots[name]==snapshots["CommittedAttempt2"]
    frozen,_stock,p_fixed,fixed_target=data
    prep,_,base24,_,witnesses,_,pinned,load_scale,_=frozen
    h25,h26=[(prior.numbers(row[1:61]),float(row[0])) for row in witnesses]
    p,k,length=prior.determine_normal(h26,h25,base24["geometry"],load_scale)
    vectors=v.vec(raw,"B_BRIDGE_VECTOR")
    [[ds,k_native,len_native,target,forecast,used,remaining]]=map(prior.numbers,raw["B_BRIDGE_PLAN"])
    assert used==previous["trials"][0]["iterations"]==15 and used+remaining==26
    assert ds==pinned[62]
    v.near(k,k_native,2e-15); v.near(length,len_native,2e-17)
    assert vectors["Normal"][-4:]==(0.,)*4 and v.peak(v.diff(vectors["Normal"],p))<2e-12
    ratio=ds/length
    seed=tuple(a+ratio*(a-b) if i<56 else a for i,(a,b) in enumerate(zip(h26[0],h25[0],strict=True)))
    assert v.peak(v.diff(seed,vectors["Prediction"]))<2e-15
    v.near(forecast,h26[1]+ratio*(h26[1]-h25[1]),2e-12)
    v.near(target,v.dot(p,h26[0])+k*h26[1]+ds,4e-15)
    panels=prior.by_name(raw,"B_BRIDGE_SOLVER")
    gates=prior.by_name(raw,"B_BRIDGE_GATE")
    actual=prior.by_name(raw,"B_BRIDGE_ACTUAL")
    residuals=v.vec(raw,"B_TANGENT_RESIDUAL")
    fields=prior.by_name(raw,"B_TANGENT_FIELD")
    stations=defaultdict(dict)
    for tag,point,side,*info in raw["B_TANGENT_STATION"]:
        if tag in ("BridgeArc","BridgeFixed"):
            stations[tag][int(point),int(side)]=prior.numbers(info)
    assert tuple(panels) in (("Arc",),("Arc","Fixed"))
    eligible=False
    output=[]
    for mode,(ok,status,code,iterations,cap,seconds,*diag) in panels.items():
        assert ok in ("0","1") and int(cap)==remaining and 0<=int(iterations)<=remaining
        remaining-=int(iterations)
        was_solved=ok=="1"
        row={"mode":mode,"returned_trial":was_solved,"status":int(status),"code":int(code),"iterations":int(iterations),
             "allowed_iterations":int(cap),"solver_seconds":float(seconds),"diagnostic":";".join(diag)}
        if was_solved:
            assert [status,code]==["4","0"]
            factor,native_norm,tau,signed_arc,physical,control=prior.numbers(gates[mode])
            key="Bridge"+mode
            history,qy,*q=fields[key]
            assert history=="26" and float(qy)==factor
            q=prior.numbers(q)
            geometry={site:line[:3] for site,line in stations[key].items()}
            assert geometry==base24["geometry"]
            advance=v.diff(q,h26[0]); dlam=factor-h26[1]
            length_trial=hypot(*prior.station_metric(advance,geometry),load_scale*dlam)
            arc=v.dot(p,advance)+k*dlam
            v.near(signed_arc,arc,4e-15);v.near(physical,length_trial,4e-15)
            rows,six,strain_error=v.reconstruct(q,factor,stations[key])
            assert strain_error<4e-15 and v.peak(v.diff(rows,residuals[key]))<3e-10
            assert len(actual[mode])==6
            assert v.peak(e/s for e,s in zip(v.diff(six,prior.numbers(actual[mode])),v.SCALES,strict=True))<4e-12
            force_error=v.diff(six,v.force(factor))
            gauges=tuple(x*v.MODULUS for x in rows[56:])
            norm=max(v.peak(rows[:56]),v.peak(gauges),v.peak(x/s for x,s in zip(force_error,v.SCALES,strict=True)))
            v.near(native_norm,norm,4e-10)
            v.near(tau,5e-7*(1+v.peak(v.loading(factor))),2e-18)
            if mode=="Arc":
                v.near(control,(arc-ds)*v.MODULUS,3e-10)
                eligible=norm<=tau and arc>0. and length_trial<=3.*ds and abs((arc-ds)*v.MODULUS)<=tau and remaining>0
            else:
                assert abs(control)<=tau and norm<=tau
                v.near(control,(v.dot(p_fixed,q)-fixed_target)*v.MODULUS,3e-10)
            fingerprint=[[point,side,*map(int,r[3:6]),r[6]>=0.] for (point,side),r in stations[key].items() if point<=25]
            assert len(fingerprint)==75
            ref=qkey=witness["arc" if mode=="Arc" else "fixed"]
            refq=prior.numbers(qkey["wire_q_and_lambda"][2:])
            ref_lam=float(qkey["wire_q_and_lambda"][1])
            differences=[item[:2] for item,old in zip(fingerprint,ref["fingerprint"],strict=True) if item!=old]
            distance_to_reference=hypot(*prior.station_metric(v.diff(q,refq),geometry),load_scale*(factor-ref_lam))
            row.update({"Qy_kN":factor,"delta_Qy_from_H26_N":1000*dlam,"actual_resultants_N_Nmm":six,
                        "signed_errors_N_Nmm":force_error,"weak56_MPa":rows[:56],"gauge4_MPa":gauges,
                        "norm_over_tau":norm/tau,"control_error_MPa":control,"physical_projection":arc,
                        "physical_distance_from_H26":length_trial,"material_fingerprint_differences":differences,
                        "physical_distance_from_archived_same_kind":distance_to_reference})
        else:
            assert mode not in gates and mode not in actual
        output.append(row)
    assert eligible==("Fixed" in panels) and raw["B_BRIDGE_END"]==[[str(int(eligible))]]
    return {"native_trace_sha256":previous["native_trace_sha256"],"original_fixed_stall_reproduced":True,
            "original_fixed_target":fixed_target,"accepted_history_never_changed":True,"H24_exactly_restored":True,
            "branches":output,"stock_iterations":int(used),"max_combined_iterations":26,"remaining_iterations":int(remaining),
            "physical_capacity_established":False,"compiler_closed":previous["compiler_closed"],"office_closed":previous["office_closed"]}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--phase",choices=["Resume"])
    cli=parser.parse_args()
    setup=prepare()
    if cli.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert cli.phase=="Resume"
        path=HERE/"VerificationPlainArcBridge.json"
        path.write_bytes((json.dumps(verify(*setup),indent=2)+"\n").encode())
        print(path,v.digest(path))
