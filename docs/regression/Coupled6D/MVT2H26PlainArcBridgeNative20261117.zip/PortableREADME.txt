H26 original fixed traction path rescued using an uncommitted short pseudo-arc predictor.

    python -B -X utf8 ReplayBridgePortable.py --archives <repository>/docs/regression/Coupled6D

The replay reconstructs the exact VBA test overlay, original accepted input history and both
independent station fingerprints from the prior evidence. The prior converged branch fields
are verification references only. Neither is used to seed the native solve. The fixed attempt
initially reproduces its own stock failure, then solves a short arc from the accepted two-point
physical secant, and finally returns to its unchanged original control using only the verified
arc candidate as a seed. All six resultants, 56 weak residuals, four gauges and exact readback
are verified. Shared limit of 26 including stock; 6 remain. Neither field is committed and the
test closes the owned application and restores H24 exactly. There is no new physical limit.
