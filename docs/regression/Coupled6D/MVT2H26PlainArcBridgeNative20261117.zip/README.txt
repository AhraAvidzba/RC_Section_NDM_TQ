Small plain pseudo-arc benchmark against the original fixed H26 target.

    python -B -X utf8 tmp/mv26c/Stage.py
    python -B -X utf8 tmp/mv26c/Verify-MVT2ShearControlled.py --inputs-only

After allocating the isolated Office slot and passing resource preflight:

    powershell -NoProfile -ExecutionPolicy Bypass -File tmp/mv26c/Run-MVT2ShearControlled.ps1

The original stock fixed failure and exact accepted history are reproduced. No downstream
field is used as input. Recompute the short normal and predictor from native H25 and H26 and
solve the verified short pseudo-arc with the ordinary material law and remaining budget.
A positive, physically local, verified equilibrium can seed one solve on the original fixed
target. The guide and target use one original 26-iteration allowance including stock. The
archived station fingerprints, fields and loads are used for independent readback only.
Both probes are discarded. Verify exact H26 before each solve and H24 at the end.
