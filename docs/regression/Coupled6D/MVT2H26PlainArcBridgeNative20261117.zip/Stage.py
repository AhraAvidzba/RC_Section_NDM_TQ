"""Seal a plain small pseudo-arc bridge to the original fixed H26 target."""
import csv
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent/"mv26o"
PREP = "C69C67BCFF97D4273B8906D88549A0963CFFAAFEE58A8E39F96562F0B24423AC"
ARC = "709156358439696C3DCA9ACB6F85BC2F172C22B8DE7E351363909DB485837476"
FIX = "9C6476B9AC8E0A48EA268E57722BFC4CEDAFF70BF1C455479E8327B50EF02428"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MACRO = "tests/modTestCoupledExperiment.bas"
VERIFY = "Verify-MVT2ShearControlled.py"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def put(name, raw):
    path = HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==raw, name
    else:
        path.write_bytes(raw)
    return digest(raw)


def once(source, old, new):
    assert source.count(old)==1, old
    return source.replace(old,new)


def fingerprint(raw, expected, label):
    assert digest(raw)==expected
    fingerprints,wire = [],None
    for tag,*row in csv.reader(raw.decode("cp1251").splitlines(),delimiter=";"):
        if not row or row[0]!=label:
            continue
        if tag=="B_TANGENT_STATION" and int(row[1])<=25:
            point,side,*station=row[1:]
            fingerprints.append([int(point),int(side),*map(int,station[3:6]), float(station[6]) >= 0.])
        elif tag=="B_TANGENT_FIELD":
            assert wire is None and len(row)==63
            wire=row[1:]
    assert len(fingerprints)==75 and len(wire)==62 and wire[0]=="26"
    return {"fingerprint":fingerprints,"wire_q_and_lambda":wire}


def overlay_macro(raw):
    source=raw.decode("utf-8-sig").replace("\r\n","\n")
    source=once(source,'    RunWangOwnFixedTest output, solver, operators, materials, responses, workingHistory, baseField, baseFactor, committed\n',
                '''    RunWangOwnFixedTest output, solver, operators, materials, responses, workingHistory, baseField, baseFactor, committed, _
        previousFactor, loadMetric, Val(resumeWire(62))
''')
    body=source.index('Private Sub RunWangOwnFixedTest(')
    head=source[:body]
    source=source[body:]
    source=once(source,'        ByVal hFactor As Double, ByRef hSnapshot() As Double)\n',
                  '''        ByVal hFactor As Double, ByRef hSnapshot() As Double, ByVal hPrevious As Double, _
        ByVal loadMetric As Double, ByVal stepSize As Double)
''')
    anchor='    CaptureWangArcHistoryTest output, "OwnAfterExact", operators, materials, snapshot\n    RequireWangArcHistoryTest hSnapshot, snapshot\n'
    source=once(source,anchor,anchor+'''    RunWangSmallArcBridgeTest output, solver, operators, materials, responses, history, historyField, previous, hFactor, hPrevious, _
        hSnapshot, projection, target, loadMetric, stepSize, baseLoad, direction, MAX_ITERATIONS
''')
    result=(head+source).rstrip()+"\n\n"+(HERE/"BridgeTest.txt").read_text(encoding="utf-8")
    assert max(map(len,result.splitlines()))<1023
    return result.replace("\n","\r\n").encode()


def main():
    raw=(BASE/"Preparation.json").read_bytes()
    assert digest(raw)==PREP
    context=json.loads(raw)
    arc=fingerprint((HERE.parent/"mv26b/NativeResume/MVT2.csv").read_bytes(),ARC,"Attempt3")
    fixed=fingerprint((HERE.parent/"mv26f/NativeResume/MVT2.csv").read_bytes(),FIX,"FixedSeed")
    assert arc["fingerprint"]==fixed["fingerprint"]
    witness={"arc":arc,"fixed":fixed,"role":"readback only"}
    files={"BranchWitness.json":put("BranchWitness.json",(json.dumps(witness,indent=2)+"\n").encode())}
    for name,expected in context["inputs"].items():
        data=(BASE/name).read_bytes()
        assert digest(data)==expected,name
        if name==VERIFY:
            files["OwnBase.py"]=put("OwnBase.py",data)
            continue
        if name in ("README.txt","Stage.py"):
            continue
        if name==MACRO:
            data=overlay_macro(data)
        files[name]=put(name,data)
    for name in ("README.txt","Stage.py",VERIFY,"BridgeTest.txt"):
        files[name]=digest((HERE/name).read_bytes())
    assert put("docs/regression/Diagnostic.xlsm",(HERE/BOOK).read_bytes())==context["book_sha256"]
    for name in ("NativeResume","Temp"):
        (HERE/name).mkdir(exist_ok=True)
    result={**context,"inputs":files,"own_ray_preparation_sha256":PREP,"reference_arc_native_sha256":ARC,"reference_fixed_native_sha256":FIX}
    print(put("Preparation.json",(json.dumps(result,indent=2)+"\n").encode()))


if __name__=="__main__":
    main()
