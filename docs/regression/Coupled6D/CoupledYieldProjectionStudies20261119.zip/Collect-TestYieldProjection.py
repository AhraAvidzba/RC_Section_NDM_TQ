"""ДЛЯ ТЕСТОВ. Сохраняет точные проекты исследований исключения нелинейного материального события."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestCollect(repo, root):
    """Рабочие источники сверяются отдельно от тестовых изменений; полные CFB сохраняются без потерь."""
    here = Path(__file__).resolve().parent
    cases = {'Precision': 'NewtonYieldPrecision20261119', 'Projection': 'YieldProjection20261119',
             'Outer': 'YieldProjectionOuterPrecision20261119', 'Departure': 'YieldProjectedDeparture20261119'}
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for key in cases:
        folder = root / 'Cases' / key
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            target = folder / relative
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(target.read_bytes()).hexdigest().upper()
        assert len(sources) == 33
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    names = ('Collect-TestYieldProjection.py', 'Check-TestYieldProjection.py', 'Analyze-TestNewtonLine.py',
        'Analyze-TestYieldProjection.py', 'Analyze-TestYieldEventRank.py', 'Stage-TestNewtonYieldPrecision.py',
        'Stage-TestNewtonYieldEvent.py', 'Stage-TestNewtonLine.py', 'TestNativeNewtonLine.bas.txt',
        'TestNativeNewtonYieldEvent.bas.txt', 'Stage-TestYieldProjection.py', 'TestNativeYieldProjection.bas.txt',
        'Stage-TestYieldProjectionOuterPrecision.py', 'Stage-TestYieldProjectedDeparture.py', 'Guard-TestExistingOffice.py',
        'Check-TestActualReverseCapture.py', 'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py',
        'Audit-TestPrivateCoupledBook.py', 'Canonical-TestCoreVBA.py', 'Pack-TestCompiledProjects.py')
    for name in names:
        (root / name).write_bytes((here / name).read_bytes())
    run_path(str(here / 'Pack-TestCompiledProjects.py'))['TestPack'](root, cases)
    (root / 'SourceCheckpoint.json').write_text(json.dumps({'base': 'febcb34',
        'runtime_sources': {name: sha256((repo / name).read_bytes()).hexdigest().upper() for name in
            ('src/Solver/CCoupledNewtonSolver.cls', 'src/Materials/CCoupledConcreteResponse.cls', 'src/Materials/CCoupledConcreteReturn.cls')},
        'installed_workbook_changed': False, 'working_runtime_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name not in ('Files.json', 'CompiledVBA.bin')}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('YIELD PROJECTION EVIDENCE COLLECTED', len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve())
