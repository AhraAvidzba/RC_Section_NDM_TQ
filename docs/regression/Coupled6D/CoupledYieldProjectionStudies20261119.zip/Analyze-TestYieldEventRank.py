"""ДЛЯ ТЕСТОВ. Локализует остаток и линейную обусловленность в сохранённых терминальных системах."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
import numpy as np


def TestAnalyze(root, output):
    """Работает с исходными Double; анализ ранга не считается доказательством существования или отсутствия корня."""
    read = run_path(str(Path(__file__).resolve().parent / 'Analyze-TestNewtonLine.py'))['TestRead']
    result = {}
    for case in (0, 1):
        files = sorted((root / 'Native').glob(f'NewtonLine.C{case}I*.bin'), key=lambda p: int(p.stem.split('I')[-1]))
        data = read(files[-1])
        matrix, residual, direction = (data[key] for key in ('jacobian', 'residual', 'correction'))
        u, s, vt = np.linalg.svd(matrix, full_matrices=False)
        row_norms = np.linalg.norm(matrix, axis=1)
        assert np.all(row_norms > 0)
        su = np.linalg.svd(matrix / row_norms[:, None], compute_uv=False)
        order = np.argsort(np.abs(residual))[::-1][:8]
        trial = data['trials'][-1]
        alpha = trial['alpha']
        slope = (trial['residual'] - residual) / alpha
        item = {'terminal_file': files[-1].name, 'terminal_sha256': data['sha256'],
            'singular_values': s.tolist(), 'condition_2': float(s[0] / s[-1]),
            'row_scaled_condition_2': float(su[0] / su[-1]),
            'relative_residual_projection_on_smallest_left_vector': float(abs(u[:, -1] @ residual) / np.linalg.norm(residual)),
            'largest_residual_rows': [{'row_1_based': int(i + 1), 'value_MPa': float(residual[i]),
                'jacobian_row_norm': float(row_norms[i])} for i in order],
            'direction_norm': float(np.linalg.norm(direction)), 'smallest_line_alpha': alpha,
            'smallest_line_max_field_increment': float(np.max(np.abs(data['scales'][:60] * direction[:60] * alpha))),
            'smallest_line_direction_relative_error': float(np.linalg.norm(slope - matrix @ direction) / np.linalg.norm(residual)),
            'smallest_line_normalized_merit_slope': float(residual @ slope / (residual @ residual)),
            'root_existence_or_physical_capacity_proved': False}
        result[str(case)] = item
        print('CASE', case, 'COND', item['condition_2'], 'SCALED_COND', item['row_scaled_condition_2'],
            'TOP_ROWS', item['largest_residual_rows'][:3], 'LINE_SLOPE', item['smallest_line_normalized_merit_slope'])
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    TestAnalyze(args.root.resolve(), args.out.resolve())
