"""ДЛЯ ТЕСТОВ. Ищет полное равновесие на двух исходящих пластических координатах после исключения события."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, source):
    """Положительные значения пробной поверхности — координаты ветви, а не критерии разрушения или приёмки."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestYieldProjection.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    block, = re.findall(r'(?ms)^Public Sub TestRunReversePolishModel\(.*?^End Sub', code)
    old = '        revision = solver.AcceptedRevision'
    assert block.count(old) == 1
    body = block.replace(old, old + '''
        If probeCase = 0 Then target = 0.001 Else target = 0.01
        Print #handle, "EVENT_TARGET;" & CStr(probeCase) & ";" & TestOnsetNumber(target)
''', 1)
    old = '    Print #handle, "CONTROL;" & TestOnsetNumber(target) & TestHardPreparedVector(projection)'
    assert body.count(old) == 1
    body = body.replace(old, '    Print #handle, "CONTROL_EVENT;ProjectedActualTrialYieldMPa;TargetsRecordedPerCase"', 1)
    code = code.replace(block, body, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'CompleteNewtonProjectedYieldDeparture',
        'event_target_MPa': None, 'event_targets_by_case_MPa': {'0': .001, '1': .01},
        'same_accepted_history_before_each_target': True,
        'two_different_targets_and_seeds_not_a_paired_algorithm_benchmark': True,
        'global_tolerance_and_Newton_budget_unchanged': True, 'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    run_path(str(here / 'Guard-TestExistingOffice.py'))['TestGuard'](root)
    print('PROJECTED POSITIVE YIELD DEPARTURE STUDY READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
