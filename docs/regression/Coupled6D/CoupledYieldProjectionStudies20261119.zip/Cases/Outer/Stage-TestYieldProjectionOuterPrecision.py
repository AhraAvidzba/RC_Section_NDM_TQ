"""ДЛЯ ТЕСТОВ. Проверяет точность согласования повреждения после исключения координаты материального события."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, source):
    """Скалярный возврат остаётся 1e-14; меняются только внешние локальные условия новых материальных проб."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestYieldProjection.py'))['TestStage'](repo, root, source)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Materials/CCoupledConcreteResponse.cls'
    code = (root / name).read_text('utf-8-sig')
    for old in ('stateToleranceTest = stateToleranceTest * modTestCoupledElasticState.ReturnPrecisionFactorTest',
                'TestPrecisionYieldTolerance = TestPrecisionYieldTolerance * modTestCoupledElasticState.ReturnPrecisionFactorTest'):
        assert code.count(old) == 1
        code = code.replace(old, old + ' * 0.01', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    snapshot = Path('D:/CodexScratch/RC_Section_NDM_TQ/YieldProjection20261119/ExternalExcelProtection.json')
    identity = json.loads(snapshot.read_text('utf-8-sig'))
    assert identity['Ownership'] == 'External COM Excel, not owned by this study' and identity['NeverClosed']
    assert identity['PID'] > 0 and int(identity['StartTicksUTC']) > 0
    name = 'ExternalExcelProtection.json'
    (root / name).write_bytes(snapshot.read_bytes())
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    name = 'Guard-IsolatedOffice.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = '$protected=@{16688='
    assert code.count(old) == 1
    code = code.replace(old, '$protected=@{' + str(identity['PID']) + '=[long]' + identity['StartTicksUTC'] + ';16688=', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    (root / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
    prep['inputs'][Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'CompleteNewtonYieldEliminationOuterPrecision',
        'scalar_yield_relative_tolerance': 1e-14, 'coupled_yield_relative_tolerance': 1e-14,
        'coupled_state_relative_tolerance': 5e-16, 'accepted_prefix_always_original_precision': True,
        'global_tolerance_and_Newton_budget_unchanged': True, 'working_runtime_changed': False})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('YIELD ELIMINATION OUTER LOCAL PRECISION STUDY READY')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.source.resolve())
