"""ДЛЯ ТЕСТОВ. Проверяет действительные VBA-проекты и независимую арифметику исключения события."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


def TestFiles(root):
    """Проверяет точные входы, включая единый поток исходных CFB-проектов."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == 'febcb34'


def TestNative(repo, root, output):
    """PASS нативной оснастки означает сохранность истории и завершение запуска, а не найденную несущую способность."""
    TestFiles(root)
    results = {}
    for key in ('Precision', 'Projection', 'Outer', 'Departure'):
        folder = root / 'Cases' / key
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Code.json'
            run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit'](repo, folder, proof)
            record = json.loads(proof.read_bytes())
        assert (record['components'], record['imported'], record['unchanged']) == (244, 31, 213)
        assert len(record['checked_coupled_sources']) == 33 and record['compiled_project_storage'] == 'solid-exact-CFB'
        path = folder / 'Native/ReversePolish.txt'
        log = path.read_text('utf-8-sig')
        assert 'RUNTIME ERROR:' not in log and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
        assert 'TOTAL_REVERSE_POLISH_STUDY_TEST: passed=1; failed=0; numerical_outcomes_recorded_not_asserted; capacity_certified=False' in log
        source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
        assert source == record['compiled_workbook_sha256']
        closure = json.loads(path.with_name(path.name + '.ProcessClosure.json').read_bytes())
        assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
        assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
        record.update(native_setup_passed=True, owned_excel_absent=True)
        results[key] = record
    output.write_text(json.dumps({'cases': results, 'working_runtime_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('FOUR ACTUAL YIELD PROJECTION VBA PROJECTS AND OWNED PROCESS CLOSURES VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Сравнивает точность и параметризацию на точном общем префиксе; успех Newton не предопределяется."""
    TestFiles(root)
    results = {}
    original = (root / 'Cases/Precision/Input/Reverse1.bin').read_bytes()
    for key in ('Precision', 'Projection', 'Outer', 'Departure'):
        folder = root / 'Cases' / key
        assert (folder / 'Input/Reverse1.bin').read_bytes() == original
        script = 'Analyze-TestNewtonLine.py' if key == 'Precision' else 'Analyze-TestYieldProjection.py'
        with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
            proof = Path(temporary) / 'Analysis.json'
            run_path(str(root / script))['TestAnalyze'](folder, proof)
            results[key] = json.loads(proof.read_bytes())
        for case in results[key]['cases'].values():
            assert case['strict_root_found'] == (case['final_residual_max_MPa'] <= 1e-10)
    output.write_text(json.dumps({'studies': results, 'common_accepted_history_binary_exact': True,
        'independent_material_reintegration': False, 'working_runtime_changed': False,
        'physical_capacity_certified': False, 'full_acceptance_completed': False}, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('YIELD PRECISION NONLINEAR ELIMINATION AND OUTGOING EQUATIONS INDEPENDENTLY VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
