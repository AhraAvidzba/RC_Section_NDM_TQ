"""Compare one and two HardShear ASD increments from bit-identical H8."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from time import perf_counter
from zipfile import ZipFile
import gzip
import json
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PILOT=('HardShearSameSectionASDCoarsePilot20261117.zip','67DE39B8362615DC3045BF8F0DF18D9859B75478EA8386F8751C4E2B78CAB904')
FOLLOW=('HardShearSameSectionASDCoarseFollow20261117.zip','F89FFBD0F47E05CBAC62CDF07F3318BC4AFB4DEDB86366FFEA9E70B93FCFFA50')
FOLLOW_WIRE='5220D142B5A0EA8F87DDA0E358AC46320B76E20EC0C02B360B6A01F8133F39AF'


def old_input(repo,source):
    data=[]; seals=[]
    for ident,name,pin in ((PILOT,'CoarsePilot.json.gz',source['PILOT']),
                           (FOLLOW,'CoarseFollowDetailed.json.gz',FOLLOW_WIRE)):
        with source['archived'](repo,ident) as z:
            raw=z.read(name)
        assert source['sha'](raw)==pin
        data.append(json.loads(gzip.decompress(raw)))
        seals.append(pin)
    pilot,follow=data
    assert pilot['identity']==follow['identity'] and pilot['material_command']==follow['material_command']
    assert follow['exact_replayed_accepted_fields']==6 and follow['total_exact_cold_history_with_rejected_excursions']==9
    fields=pilot['accepted_targets']+follow['accepted_targets'][:2]
    assert [r['lambda'] for r in fields]==list(source['TARGETS'])+[.625,.75]
    assert follow['accepted_targets'][-1]['lambda']==.875
    return fields,follow,seals


def kernel(np,ops,cls,geo,dirs,area,length,op,command,deadline,es):
    class SameSection(cls.Section):
        def __init__(self):
            super().__init__(np,ops,command,geo,dirs,area,length,op,deadline)
            self.steel_stress=None

        def components(self,field):
            strain=self.strain@field
            if np.max(np.abs(strain))>.01:
                raise ArithmeticError('diagnostic numerical strain range')
            elastic=es*np.einsum('spi,pi->sp',strain[:,25:,:],self.dirs[25:])
            if np.any(elastic[:,:2]>=400.) or np.any(elastic[:,:2]<=-350.) or np.any(np.abs(elastic[:,2:])>=240.):
                raise ArithmeticError('pilot left exact elastic-steel scope')
            self.steel_stress=elastic.copy()
            return strain,elastic
    return SameSection


def replay(np,section,fields,load,excursions=False):
    assert section.committed==0
    for frame in fields:
        field=np.array(frame['field']); force=frame['lambda']*load
        if excursions:
            probe=field.copy(); probe[0]+=1e-6
            section.equations(probe,force,False)
        latest=section.equations(field,force,False)
        assert np.array_equal(latest[2],frame['net_stress_MPa'])
        assert np.array_equal(section.steel_stress,frame['steel_stress_MPa'])
        assert latest[4]<=latest[5]
        section.accepted_stresses.append(latest[2].tolist())
        section.commit()
    assert section.committed==len(fields)
    return field


def material_readback(np,ops,source,section,cmd,field,factor,load,accepted,steel,geo,dirs,area,length,op):
    stress=source['committed_stress'](np,ops,steel,dirs)
    assert np.array_equal(stress,accepted)
    measures=source['material_states'](np,ops,cmd)
    # Same kinematics is a new evaluation from the just committed history.
    # No second Accept/Commit is issued.
    shape_before=section.committed
    virgin=section.equations(field,load*factor,False)
    assert section.committed==shape_before
    raw=virgin[2].tolist(); q=field.tolist()
    report=source['verify_rows'](geo,dirs,area,length,op,q,raw,factor,steel,False)
    assert abs(virgin[4]-report['combined_norm_MPa'])<3e-12
    return {'immediate_committed_stress_identical':True, 'concrete_measures':measures,
            'zero_increment_trial':{'net_stress_MPa':raw,'independent':report,'committed':False}}


def main(repo,output):
    started=perf_counter(); assert not output.exists()
    sys.path.insert(0,'D:/CodexScratch/RC_Section_NDM_TQ/CoupledEvidencePython')
    import numpy as np
    import openseespy.opensees as ops
    assert ops.version()=='3.8.0' and np.__version__=='2.3.5'
    archive=repo/'docs/regression/Coupled6D'/FOLLOW[0]
    assert sha256(archive.read_bytes()).hexdigest().upper()==FOLLOW[1]
    with ZipFile(archive) as z:
        src=z.read('HardShearSameSection.py')
    source={ '__name__':'__frozen__','__file__':str(HERE/'HardShearSameSection.py') }
    exec(compile(src,source['__file__'],'exec'),source)
    prefix,prior,seals=old_input(repo,source)
    geo,dirs,area,length,_,_=source['fixture'](repo)
    op=source['operators'](geo,area,length)
    assert source['sha'](source['packed'](op))==prior['identity']['exact_built_operator_sha256']
    cls,sealed_solver=source['source_model'](repo)
    assert sealed_solver==prior['identity']['solver_source_sha256']
    command,_=source['material_command'](repo); assert list(command)==prior['material_command']
    load=np.array(source['RAY']); cls.P=43; cls.loads=lambda arrays,t,q:q*load
    new=kernel(np,ops,cls,geo,dirs,area,length,op,command,started+40.,source['ES'])
    proof={'fixed_operator_sha256':prior['identity']['exact_built_operator_sha256'], 'frozen_source_sha256':source['sha'](src),
           'source_archives':(PILOT,FOLLOW), 'source_wire_sha256':seals,'ray_N_Nmm':load.tolist(),
           'material_command_sha256':source['sha'](source['packed'](list(command))),
           'material_options':[x for x in command if isinstance(x,str)],'history_prefix':len(prefix),
           'retained_equilibrium_definition':'accepted transition versus separate uncommitted re-evaluation',
           'arms':{},'physical_limit_established':False}
    for key,schedule in (('single',(.875,)),('split',(.8125,.875))):
        section=new(); field=replay(np,section,prefix,load)
        # The old .75 end-of-step state already recorded its discarded trial.
        # Repeating that observation here must not change either arm's prefix.
        anchor_trial=section.equations(field,.75*load,False)
        assert np.array_equal(anchor_trial[2],prefix[-1]['post_commit_new_zero_increment']['net_stress_MPa'])
        assert section.committed==8
        arm={'schedule':schedule,'qualified_steps':[],'initial_committed_count':section.committed,'first_failure':None}
        solver_init=section.eval_count
        for factor in schedule:
            selected,transition=cls.try_correct(section,field,float(load[3]),factor)
            if selected is None:
                arm['first_failure']={'lambda':factor,'numerical':transition}
                break
            field=selected; net=section.accepted_stresses[-1]; steel=section.steel_stress.tolist()
            checked=source['verify_rows'](geo,dirs,area,length,op,field.tolist(),net,factor,steel)
            assert abs(checked['combined_norm_MPa']-transition['all_weak_and_force_max_MPa'])<3e-12
            frame={'lambda':factor,'field':field.tolist(),'net_stress_MPa':net,'steel_stress_MPa':steel,'independent':checked,
                   'newton_iterations':transition['newton_iterations']}
            frame.update(material_readback(np,ops,source,section,command,field,factor,load,net,steel,geo,dirs,area,length,op))
            arm['qualified_steps'].append(frame)
        arm['direct_evaluations_after_prefix']=section.eval_count-solver_init
        arm['direct_jacobians']=section.full_matrices
        arm['final_committed_count']=section.committed
        cold=new()
        replay(np,cold,prefix+arm['qualified_steps'],load,excursions=True)
        assert cold.committed==arm['final_committed_count']
        arm['exact_virgin_replay_with_uncommitted_excursions']=cold.committed
        proof['arms'][key]=arm
    old=prior['accepted_targets'][-1]; one=proof['arms']['single']['qualified_steps'][0]
    keys=('lambda','field','net_stress_MPa','steel_stress_MPa','independent')
    assert all(old[v]==one[v] for v in keys)
    assert old['post_commit_new_zero_increment']['net_stress_MPa']==one['zero_increment_trial']['net_stress_MPa']
    proof['single_endpoint_and_discarded_probe_match_section_529_exactly']=True
    ops.wipe()
    wire=gzip.compress(source['packed'](proof),compresslevel=9,mtime=0)
    with output.open('xb') as sink: sink.write(wire)
    print('HARDSHEAR ASD STEP SPLIT WIRE',source['sha'](wire),len(wire),'seconds',perf_counter()-started,
          [(key,len(arm['qualified_steps'])) for key,arm in proof['arms'].items()])


if __name__=='__main__':
    cli=ArgumentParser(description=__doc__)
    cli.add_argument('--repo',type=Path,default=Path.cwd()); cli.add_argument('--out',type=Path,default=HERE/'ASDStepSplitWire.json.gz')
    args=cli.parse_args(); main(args.repo.resolve(),args.out)
