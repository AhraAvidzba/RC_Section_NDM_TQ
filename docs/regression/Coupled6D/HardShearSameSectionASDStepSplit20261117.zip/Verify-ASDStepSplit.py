"""Independent evidence check for the HardShear same-endpoint step split."""
from argparse import ArgumentParser
from hashlib import sha256
from math import fsum
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WIRE='5FF85BEB3D8B841855CCDE96B3C2C54CB7DD5313C4C00C1A5D5368757AD90C74'


def sha(b):
    return sha256(b).hexdigest().upper()


def outcome(source,rows,zero,lam,area,length,theta,material):
    assert zero['original_tolerance_MPa']==rows['original_tolerance_MPa']
    applied=[lam*v for v in source['RAY']]
    scales=(area,area*length,area*length,area*length,area,area)
    def summary(item):
        delta=[(a-b)/s for a,b,s in zip(item['signed_six'],applied,scales,strict=True)]
        return {'true_max_MPa':item['combined_norm_MPa'],'resultants_N_Nmm':item['signed_six'],
                'force_difference_MPa':delta,'max_weak_MPa':item['weak_56_norm_MPa'],
                'max_kinematic_scaled_MPa':item['scaled_4_gauge_norm_MPa']}
    return {'lambda':lam,'tolerance_MPa':rows['original_tolerance_MPa'],'twist_rad_per_m':theta,
            'accepted_transition':summary(rows),'discarded_zero_increment':summary(zero),'material':material}


def checked_material(raw):
    data=raw['raw_indicators']
    assert len(data)==75 and all(len(v)==6 for v in data)
    value=list(map(max,zip(*data,strict=True)))
    assert raw['native_max_indicator_each_T_C']==[value[i:i+2] for i in (0,2,4)]
    peak=raw['table_peak_T_C_ordinates']; assert peak==[.0001,.002]
    hits=[sum(row[i]>v for row in data) for i,v in enumerate(peak)]
    assert hits==raw['number_above_tension_compression_table_peak']
    return {'number_above_tension_compression_peak':hits,'equivalent_T_C_max':value[:2],
            'plastic_T_C_max':value[2:4],'damage_T_C_max':value[4:]}


def rows_and_six(source,geo,dirs,area,length,op,frame):
    field=frame['field']; assert len(field)==60
    expected=source['verify_rows'](geo,dirs,area,length,op,field,frame['net_stress_MPa'],frame['lambda'],frame['steel_stress_MPa'])
    assert expected==frame['independent']
    return expected


def comparison(geo,op,one,two):
    d=[b-a for a,b in zip(one['field'],two['field'],strict=True)]
    samples=[]
    for point,(B,Z) in enumerate(zip(op['B'],op['Z'],strict=True),1):
        for side in (0,1,-1):
            v=[fsum((p+side*.001*q)*x for p,q,x in zip(b,z,d,strict=True)) for b,z in zip(B,Z,strict=True)]
            samples.extend((value,point,side,i+1) for i,value in enumerate(v))
    largest=max(samples,key=lambda x:abs(x[0]))
    a=one['net_stress_MPa']; b=two['net_stress_MPa']
    stresses=[]
    for index,side in enumerate((0,1,-1)):
        for i in range(43):
            stresses.extend((right-left,i+1,side,j+1) for j,(left,right) in enumerate(zip(a[index][i],b[index][i],strict=True)))
    steel=[(right-left,i+26,side) for k,side in enumerate((0,1,-1))
           for i,(left,right) in enumerate(zip(one['steel_stress_MPa'][k],two['steel_stress_MPa'][k],strict=True))]
    assert len(stresses)==774 and len(steel)==54
    def tagged(values):
        return max(values,key=lambda x:abs(x[0]))
    concrete=tagged(v for v in stresses if v[1]<=25)
    replacement=tagged(v for v in stresses if v[1]>25)
    assert len(geo)==43
    return {'end_delta_plane_four':d[:4], 'end_delta_full_sixty':d,
            'largest_endpoint_strain_delta_value_point_side_component':largest,
            'largest_concrete_stress_delta_MPa_point_side_component':concrete,
            'largest_net_replacement_delta_MPa_point_side_component':replacement,
            'largest_elastic_steel_delta_MPa_point_side':tagged(steel), 'voigt_order':['xx','yy','zz','xy','xz','yz']}


def main(repo):
    compare=runpy.run_path(str(HERE/'Compare-ASDStepSplit.py'))
    archive=repo/'docs/regression/Coupled6D'/compare['FOLLOW'][0]
    assert sha(archive.read_bytes())==compare['FOLLOW'][1]
    with ZipFile(archive) as z:
        src=z.read('HardShearSameSection.py')
    source={'__name__':'__frozen__','__file__':str(HERE/'HardShearSameSection.py')}
    exec(compile(src,source['__file__'],'exec'),source)
    first,prior,seals=compare['old_input'](repo,source)
    raw=(HERE/'ASDStepSplitWire.json.gz').read_bytes(); assert sha(raw)==WIRE
    proof=json.loads(gzip.decompress(raw))
    assert proof['source_wire_sha256']==seals and proof['frozen_source_sha256']==sha(src)
    assert proof['fixed_operator_sha256']==prior['identity']['exact_built_operator_sha256']
    assert proof['material_command_sha256']==source['sha'](source['packed'](prior['material_command']))
    assert proof['material_options']==['ASDConcrete3D','-Te','-Ts','-Td','-Ce','-Cs','-Cd','-tangent']
    assert proof['history_prefix']==len(first)==8 and proof['ray_N_Nmm']==list(source['RAY'])
    assert proof['single_endpoint_and_discarded_probe_match_section_529_exactly'] and not proof['physical_limit_established']
    geo,dirs,area,length,_,_=source['fixture'](repo)
    op=source['operators'](geo,area,length)
    assert source['sha'](source['packed'](op))==proof['fixed_operator_sha256']
    for frame in first:
        rows_and_six(source,geo,dirs,area,length,op,frame)
    arms={}; terminal=[]
    for key,schedule in (('single',[.875]),('split',[.8125,.875])):
        record=proof['arms'][key]; qualified=record['qualified_steps']
        assert record['schedule']==schedule==[s['lambda'] for s in qualified] and record['first_failure'] is None
        assert record['initial_committed_count']==8 and record['final_committed_count']==len(qualified)+8
        assert record['exact_virgin_replay_with_uncommitted_excursions']==record['final_committed_count']
        steps=[]
        for frame in qualified:
            accepted=rows_and_six(source,geo,dirs,area,length,op,frame)
            assert frame['immediate_committed_stress_identical']
            zero=frame['zero_increment_trial']; assert not zero['committed']
            initial=source['verify_rows'](geo,dirs,area,length,op,frame['field'],zero['net_stress_MPa'],frame['lambda'],frame['steel_stress_MPa'],False)
            assert initial==zero['independent']
            assert accepted['combined_norm_MPa']<accepted['original_tolerance_MPa']<initial['combined_norm_MPa']
            material=checked_material(frame['concrete_measures'])
            steps.append(outcome(source,accepted,initial,frame['lambda'],area,length,1000.*frame['field'][3]/length,material))
        arms[key]=steps
        terminal.append(qualified[-1])
    witness=prior['accepted_targets'][-1]
    assert all(terminal[0][key]==witness[key] for key in ('lambda','field','net_stress_MPa','steel_stress_MPa','independent'))
    assert terminal[0]['zero_increment_trial']['net_stress_MPa']==witness['post_commit_new_zero_increment']['net_stress_MPa']
    a,b=(arm[-1] for arm in arms.values())
    first_norm=a['discarded_zero_increment']['true_max_MPa']; second=b['discarded_zero_increment']['true_max_MPa']
    assert .04<1.-second/first_norm<.05 and second/a['tolerance_MPa']>2500.
    return {'status':'PASS','same_virgin_history_until_lambda':.75,'exact_replayed_prefix_steps':8,
            'old_single_endpoint_same_as_section_529':True,'all_material_options':proof['material_options'],
            'endpoint_zero_increment_relative_reduction':1.-second/first_norm,'endpoint_two_step_zero_norm_over_tolerance':second/a['tolerance_MPa'],
            'endpoint_twist_split_minus_single_rad_per_m':b['twist_rad_per_m']-a['twist_rad_per_m'],
            'end_step_comparison':comparison(geo,op,*terminal),'arms':arms,'physical_limit_established':False}


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd()); p.add_argument('--report',type=Path)
    opts=p.parse_args(); result=main(opts.repo)
    raw=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if opts.report:
        with opts.report.open('xb') as out:out.write(raw)
    print('HARDSHEAR_ASD_STEP_SPLIT_OFFLINE_PASS',sha(raw),result['endpoint_zero_increment_relative_reduction'])
