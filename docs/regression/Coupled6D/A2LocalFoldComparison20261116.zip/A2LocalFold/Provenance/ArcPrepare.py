"""Freeze an isolated Excel experiment for the pseudo-arclength corrector."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
PRIOR = HERE.parent / "dsf2"
WORKBOOK = Path("workbook/output/RC_Section_NDM.xlsm")
NEWTON = Path("src/Solver/CCoupledNewtonSolver.cls")
TEST = Path("tests/modTestCoupledElasticState.bas")


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def once(source, old, new):
    if source.count(old) != 1:
        raise ValueError(f"Expected one occurrence of {old!r}.")
    return source.replace(old, new)


def compose_newton():
    text = (REPO / NEWTON).read_text(encoding="utf-8-sig")
    text = once(text, "Private mControlProjection() As Double, mTargetControl As Double",
                "Private mControlProjection() As Double, mTargetControl As Double\n"
                "Private mControlLoadProjection As Double, mControlCurrentLambda As Double ' Слагаемое множителя для псевдодуги.")
    text = once(text, "        Optional ByVal consistentControl As Boolean = False) As Boolean\n    If LBound(baseLoad)",
                "        Optional ByVal consistentControl As Boolean = False, Optional ByRef initialField As Variant, _\n"
                "        Optional ByVal loadProjection As Double = 0#) As Boolean\n    If LBound(baseLoad)")
    text = once(text, "    mControlProjection = controlProjection: mTargetControl = targetControl",
                "    If recoverYieldControl And loadProjection <> 0# Then _\n"
                "        Err.Raise 5, \"CCoupledNewtonSolver\", \"Смена меры несовместима с фиксированной плоскостью псевдодуги.\"\n"
                "    mControlProjection = controlProjection: mTargetControl = targetControl\n"
                "    mControlLoadProjection = loadProjection")
    text = once(text, "TryDeformationStep = SolveStep(load, initialLambda, absoluteTolerance, relativeTolerance, maxIterations, recoverYieldControl)",
                "TryDeformationStep = SolveStep(load, initialLambda, absoluteTolerance, relativeTolerance, maxIterations, _\n"
                "        recoverYieldControl, initialField:=initialField)")
    marker = "' Возвращает новую линейную меру только для подтверждённой пробы восстановления."
    text = once(text, marker, (HERE / "ArcMethod.txt").read_text(encoding="utf-8").rstrip() + "\n\n" + marker)
    text = once(text, "Private Sub SetControlledLoad(ByVal lambda As Double, ByRef load() As Double)\n    Dim i As Long",
                "Private Sub SetControlledLoad(ByVal lambda As Double, ByRef load() As Double)\n"
                "    mControlCurrentLambda = lambda\n    Dim i As Long")
    text = once(text, "        If i < mGaugeStart Then augmented(i, size) = mControlProjection(i) * mReferenceModulus\n    Next i\nEnd Sub",
                "        If i < mGaugeStart Then augmented(i, size) = mControlProjection(i) * mReferenceModulus\n"
                "    Next i\n    augmented(size, size) = mControlLoadProjection * mReferenceModulus\nEnd Sub")
    text = once(text, "    value = -mTargetControl\n    For i = 1 To mGaugeStart - 1",
                "    value = -mTargetControl + mControlLoadProjection * mControlCurrentLambda\n    For i = 1 To mGaugeStart - 1")
    return text


def copy(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    copyfile(src, dst)


def prepare():
    receipt = json.loads((PRIOR / "Fixture.json").read_bytes())
    assert digest(REPO / WORKBOOK) == receipt["workbook_sha256"]
    path = HERE / "Fixture.json"
    if path.exists():
        raise FileExistsError(path)
    keys = [key for key in receipt["frozen"] if key.startswith("tools/build_workbook/")
            or key == "Guard-IsolatedOffice.ps1"]
    for key in keys:
        assert digest(PRIOR / key) == receipt["frozen"][key]
        copy(PRIOR / key, HERE / key)
    copy(REPO / WORKBOOK, HERE / WORKBOOK)
    copy(REPO / WORKBOOK, HERE / "docs/regression/Diagnostic.xlsm")
    (HERE / "Temp").mkdir(exist_ok=True)
    (HERE / "Native").mkdir(exist_ok=True)
    for name, text in ((NEWTON, compose_newton()), (TEST, (REPO / TEST).read_text(encoding="utf-8-sig").rstrip()
                         + "\n\n" + (HERE / "ArcTest.txt").read_text(encoding="utf-8"))):
        source = HERE / name
        source.parent.mkdir(parents=True, exist_ok=True)
        source.write_bytes(text.strip().replace("\n", "\r\n").encode("utf-8") + b"\r\n")
    keys += [str(p.as_posix()) for p in (WORKBOOK, NEWTON, TEST)]
    keys += ["Prepare.py", "ArcMethod.txt", "ArcTest.txt", "Verify.py", "Run.ps1"]
    report = {"workbook_sha256": receipt["workbook_sha256"], "solver_base_sha256": digest(REPO / NEWTON),
              "test_base_sha256": digest(REPO / TEST), "frozen": {key: digest(HERE / key) for key in keys}}
    path.write_bytes((json.dumps(report, indent=2) + "\n").encode())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if not args.check:
        prepare()
    fixture = json.loads((HERE / "Fixture.json").read_bytes())
    assert all(digest(HERE / key) == value for key, value in fixture["frozen"].items())
    print("PSEUDO ARC INPUTS", digest(HERE / "Fixture.json"), fixture["frozen"][NEWTON.as_posix()])
