"""Freeze an A2 branch-local prescribed-twist/pseudoarc comparison."""

from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import csv
import json
from pathlib import Path
from shutil import copyfile
from subprocess import check_output


HERE=Path(__file__).resolve().parent
TMP=HERE.parent
REPO=HERE.parents[1]
POST=TMP/'a2post'
ARC=TMP/'arcv'
BOOK='workbook/output/RC_Section_NDM.xlsm'
MODULE='tests/modTestCoupledExperiment.bas'
NEWTON='src/Solver/CCoupledNewtonSolver.cls'
POST_SHA='3D7AA04C2222391452B6F1C1D933923317FAA4D22ADA559FFEE666B644B7D6E1'
POST_RESULT_SHA='6BFA97F4CC2144129DB9038FF54C274A0D361B3BD3CE9470D7095104EAA74666'
POST_TRACE_SHA='FDDAABCC8B2C396DD56FBA2E982D60C281F300EB5377DF70A4FAFA8AC562ED4E'
ARC_SHA='3C398127BE4DE537E24F8F84ABA9B356EE2DD940589BED27D2EE462FAC1549E0'


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def copy(source,target):
    target.parent.mkdir(exist_ok=True,parents=True)
    copyfile(source,target)


def once(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)


def freeze_history():
    proof=read_json(POST/'B-Post-Verification.json')
    assert proof['closure']['terminal']=='completed' and proof['newBalancedAcceptedFields']==30
    assert proof['sampledTurningTriples'][0]['neighbors'][0]['index']==50
    with (POST/'B43.csv').open(encoding='ascii',newline='') as file:
        prefix=list(csv.reader(file,delimiter=';'))
    assert prefix[0]==['43','0.001','B'] and len(prefix)==44
    with (POST/'Native/B-Post.csv').open(encoding='cp1251',newline='') as file:
        native=[row for row in csv.reader(file,delimiter=';') if row]
    assert native[0]==['RESUME','9','43','56']
    assert native[1][0:2]==['RESUME_LAW','B']
    native_fields=[row for row in native if row[0]=='FIELD']
    assert [int(row[1]) for row in native_fields]==list(range(44,74))
    rows=prefix[1:]+[[row[1],row[4],*row[10:]] for row in native_fields[:7]]
    assert [int(row[0]) for row in rows]==list(range(1,51)) and all(len(row)==68 for row in rows)
    area,length=216004.,407.293505963451
    twist_error=max(abs(float(row[1])-float(row[11])*1000/length) for row in rows)
    assert twist_error<1.e-14
    terminal=proof['sampledTurningTriples'][0]['neighbors'][0]
    assert abs(float(rows[-1][1])-terminal['twist_rad_m'])<1.e-14
    assert abs(float(rows[-1][5])/1.e6-terminal['T_kNm'])<1.e-10
    outfile=HERE/'B50.csv'
    with outfile.open('x',encoding='ascii',newline='') as stream:
        out=csv.writer(stream,delimiter=';',lineterminator='\r\n')
        out.writerow([50,'0.00025','B']); out.writerows(rows)
    return {'input_sha256':digest(outfile),'last_twist_rad_m':float(rows[-1][1]),'last_T_kNm':float(rows[-1][5])/1.e6,
            'previous_twist_rad_m':float(rows[-2][1]),'previous_T_kNm':float(rows[-2][5])/1.e6,
            'base_twist_affine_error_rad_m':twist_error,'supports_old_peak_samples':proof['sampledTurningTriples'][0]['neighbors']}


def archive_solver():
    old=HERE/'Historical'/NEWTON
    old.parent.mkdir(exist_ok=True,parents=True)
    old.write_bytes(check_output(['git','show',f'f4741ae:{NEWTON}'],cwd=REPO))
    asserts=read_json(POST/'Fixture.json')['sectionSources']
    assert digest(old)==asserts[NEWTON]
    spec=spec_from_file_location('production_arc',ARC/'Prepare.py')
    module=module_from_spec(spec);spec.loader.exec_module(module)
    module.REPO=HERE/'Historical'
    code=module.compose_newton().strip().replace('\n','\r\n').encode('utf-8')+b'\r\n'
    assert sha256(code).hexdigest().upper()==digest(ARC/NEWTON)==ARC_SHA
    return code


def fold_module(lane):
    source=(POST/MODULE).read_text(encoding='utf-8-sig')
    marker="' -------------------- ДЛЯ ТЕСТОВ --------------------\n' Продолжает послетрещинную ветвь A2"
    public_start=source.index('Public Function RunTestA2PostAnchor(')
    start=source.rindex(marker,0,public_start)
    stop=source.index('End Function',public_start)+len('End Function')
    entry=source[start:stop].replace('RunTestA2PostAnchor','RunTestA2Fold')
    entry=once(entry,'n <> 43','n <> 50').replace('до поля 43','до поля 50')
    entry=once(entry,'ContinueA2PostAnchorTest(', 'ContinueA2FoldTest(')
    entry=once(entry,'\\A2PostAnchor.csv','\\A2Fold.csv')
    source=once(source,'ByVal lambda As Double, ByVal index As Long, ByVal attempt As Long, ByVal role As String, ByVal trace As String) As Double',
                'ByVal lambda As Double, ByVal index As Long, ByVal attempt As Long, ByVal role As String, ByVal trace As String, _\n'
                '        Optional ByVal controlErrorOverride As Variant) As Double')
    source=once(source,'    controlError = (field(4) - measure) * EC',
                '    If IsMissing(controlErrorOverride) Then\n        controlError = (field(4) - measure) * EC\n'
                '    Else\n        controlError = CDbl(controlErrorOverride)\n    End If')
    control={
        'Twist':'''Dim initialLambda As Double: initialLambda = lambda + stepRatio * (lambda - previousLambda)
    TryA2FoldLaneTest = TryA2PostStepTest(solver, measure, initialLambda, trialLambda)''',
        'Arc':'''Dim offset(1 To 6) As Double, direction(1 To 6) As Double
    direction(4) = 100000000#
    TryA2FoldLaneTest = solver.TryPseudoArcStep(offset, direction, previous, previousLambda, lambda, lambdaMetric, stepRatio, _
        trialLambda, 0.0000005, 0.00000002, 24, consistentControl:=True)'''}[lane]
    body=(HERE/'FoldEntry.txt').read_text(encoding='utf-8').replace('@LANE@',lane).replace('@CONTROL@',control)
    return (source.rstrip()+'\n\n'+entry+'\n\n'+body).replace('\n','\r\n').encode('utf-8-sig')


def stage():
    assert all(not (HERE/lane/'Fixture.json').exists() for lane in ('Twist','Arc'))
    assert digest(POST/'Fixture.json')==POST_SHA and digest(POST/'B-Post-Verification.json')==POST_RESULT_SHA
    assert digest(POST/'Native/B-Post.csv')==POST_TRACE_SHA
    source=read_json(POST/'Fixture.json')
    assert digest(REPO/BOOK)==source['workbookSHA256']==digest(POST/BOOK)
    assert digest(POST/MODULE)==source['frozen'][MODULE] and digest(POST/'B43.csv')==source['frozen']['B43.csv']
    history=freeze_history()
    optional_solver=archive_solver()
    portable=HERE/'PairSource.json'
    pair={'original_sources':source['sectionSources'],'workbook_sha256':source['workbookSHA256'],
          'post_fixture_sha256':POST_SHA,'post_trace_sha256':POST_TRACE_SHA,'post_result_sha256':POST_RESULT_SHA,
          'optional_newton_sha256':ARC_SHA,'history':history}
    portable.write_text(json.dumps(pair,indent=2)+'\n',encoding='utf-8')
    for lane in ('Twist','Arc'):
        target=HERE/lane
        files=[name for name in source['frozen'] if name.startswith('tools/') or name in (BOOK,'Guard-IsolatedOffice.ps1')]
        for name in files:
            assert digest(POST/name)==source['frozen'][name]
            copy(POST/name,target/name)
        copy(target/BOOK,target/'docs/regression/Diagnostic.xlsm')
        for name in ('src','tests','Native','Temp'):
            (target/name).mkdir(exist_ok=True,parents=True)
        (target/MODULE).write_bytes(fold_module(lane)); files.append(MODULE)
        if lane=='Arc':
            (target/NEWTON).parent.mkdir(exist_ok=True,parents=True)
            (target/NEWTON).write_bytes(optional_solver); files.append(NEWTON)
        for name in ('B50.csv','PairSource.json','Run.ps1','Verify.py'):
            copy(HERE/name,target/name); files.append(name)
        record={'lane':lane,'workbook_sha256':source['workbookSHA256'],'frozen':{name:digest(target/name) for name in files},
                'modules':sorted(Path(name).stem for name in files if name in (NEWTON,MODULE)),
                'watchdog_seconds':490,'accepted_prefix_fields':50}
        (target/'Fixture.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
        print(lane,digest(target/'Fixture.json'))
    print('B50',history['input_sha256'],history['last_twist_rad_m'],history['last_T_kNm'])


if __name__=='__main__':
    stage()
