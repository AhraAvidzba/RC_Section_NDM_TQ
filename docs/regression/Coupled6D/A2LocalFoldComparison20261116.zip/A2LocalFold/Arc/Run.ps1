# Проверяет одну меру продолжения A2 в изолированной книге.
param([switch]$Preflight)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$repo=(Resolve-Path -LiteralPath (Join-Path $root '../../..')).Path
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$book='workbook/output/RC_Section_NDM.xlsm'
$draft='docs/regression/Diagnostic.xlsm'
$report='Native/Fold.txt'
$oldTemp=$env:TEMP
$oldTmp=$env:TMP
Push-Location -LiteralPath $root
try {
    $data=Get-Content -LiteralPath 'Fixture.json' -Raw | ConvertFrom-Json
    foreach ($item in $data.frozen.PSObject.Properties) {
        if ((Get-FileHash -LiteralPath $item.Name).Hash -cne $item.Value) {throw ('Изменён файл '+$item.Name)}
    }
    if ((Get-FileHash -LiteralPath (Join-Path $repo $book)).Hash -cne $data.workbook_sha256) {throw 'Изменилась установленная книга.'}
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {throw 'Путь пробной книги слишком длинный.'}
    Assert-IsolatedOfficeReady ("A2Fold"+$data.lane)
    if ($Preflight) {return}
    if (Test-Path -LiteralPath $report) {throw 'Предыдущая проверка сохранена.'}
    if (!(Test-Path -LiteralPath 'docs/regression/CodeUpdate.json')) {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Get-FileHash -LiteralPath $draft).Hash -cne $data.workbook_sha256) {throw 'Найдена непроверенная компиляция.'}
        $moduleNames=@($data.modules | ForEach-Object {[string]$_})
        & (Join-Path $root 'tools/build_workbook/Update-PrivateWorkbookCode.ps1') -WorkbookPath $draft -ModuleNames $moduleNames |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $closure.State -cne 'Absent' -or
        (($compiled.Modules | Sort-Object) -join ',') -cne ($data.modules -join ',') -or
        $compiled.ProductionSHA256 -cne $data.workbook_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash) {throw 'Экземпляр тестовой книги не подтвердился.'}
    Assert-IsolatedOfficeReady ("BeforeA2Fold"+$data.lane)
    $inputPath=(Resolve-Path -LiteralPath 'B50.csv').Path
    $clock=[Diagnostics.Stopwatch]::StartNew()
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $draft -ReportPath $report -Macro 'modTestCoupledExperiment.RunTestA2Fold' -MacroArgument1 $inputPath `
        -MacroArgument2 'B' -Mode No -TimeoutSeconds $data.watchdog_seconds -FailFast
    $code=$LASTEXITCODE
    $clock.Stop()
    [ordered]@{seconds=$clock.Elapsed.TotalSeconds;exit_code=$code} | ConvertTo-Json | Set-Content -LiteralPath 'Native/Timing.json' -Encoding UTF8
    $identity=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($identity.Count -ne 1) {throw 'Путь к исходной пробной книге не записан.'}
    $folder=Split-Path -Parent $identity[0].Substring('FIXTURE: '.Length)
    if (!(Split-Path -Leaf $folder).StartsWith('RC_NDM_ModeSuite_',[StringComparison]::Ordinal) -or
        !$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь следа вне частной копии.'}
    $trace=Join-Path $folder 'A2Fold.csv'
    if (Test-Path -LiteralPath $trace) {Copy-Item -LiteralPath $trace -Destination 'Native/Fold.csv'}
    if ($code -ne 0) {throw 'Нативная проверка завершилась ошибкой; частичный след сохранён, если он появился.'}
    & python -B -X utf8 'Verify.py'
    if ($LASTEXITCODE -ne 0) {throw 'Независимая проверка завершилась ошибкой.'}
} finally {
    $env:TEMP=$oldTemp
    $env:TMP=$oldTmp
    Pop-Location
}
