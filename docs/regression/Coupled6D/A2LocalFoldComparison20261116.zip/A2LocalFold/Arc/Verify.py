"""Independently verify original A2 equations and the observed local turning samples."""

import argparse
import csv
from hashlib import sha256
import json
from math import fsum, sqrt
from pathlib import Path
import re


HERE=Path(__file__).resolve().parent


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def rows(path):
    with path.open(encoding='cp1251',newline='') as source:
        return [r for r in csv.reader(source,delimiter=';') if r]


def norm(wrench,expected,area,length):
    factors=(area,area*length,area*length,area*length,area,area)
    return max(abs(a-b)/s for a,b,s in zip(wrench,expected,factors,strict=True))


def integrate(points):
    contributions=[[] for _ in range(6)]
    steel_long,steel_hoop=[],[]
    assert len(points)==88
    for j,row in enumerate(points,1):
        _,role,index,attempt,point,x,y,area,rod,xx,yy,zz,xy,xz,yz=row
        assert int(point)==j
        x,y,area,rod,zz,xz,yz=map(float,(x,y,area,rod,zz,xz,yz))
        local=(zz,y*zz,x*zz,x*yz-y*xz,xz,yz)
        for group,value in zip(contributions,local,strict=True):
            group.append(area*value)  # Native trial tensor at rods already includes the displaced-concrete correction.
        if 57<=j<=72:
            steel_long.append(rod)
        elif j>=73:
            steel_hoop.append(rod)
    assert len(steel_long)==len(steel_hoop)==16
    return list(map(fsum,contributions)), [min(steel_long),max(steel_long)], [min(steel_hoop),max(steel_hoop)]


def native(lane_root):
    lane=lane_root.name
    assert lane in ('Twist','Arc')
    report=lane_root/'Native/Fold.txt'
    receipt=json.loads((lane_root/'Native/Fold.txt.ProcessClosure.json').read_text(encoding='utf-8-sig'))
    assert receipt['Passed'] and receipt['ChildExitCode']==0 and receipt['Closure']['FinalState']['State']=='Absent'
    complete=report.read_text(encoding='utf-8-sig')
    assert 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in complete
    trace=lane_root/'Native/Fold.csv'
    log=rows(trace)
    assert log[0]==['RESUME','9','50','56'] and log[1][:2]==['RESUME_LAW','B']
    assert abs(float(log[1][2])-.1194033324156538)<1e-12 and abs(float(log[1][3])-26.692180820749954)<1e-11
    assert log[2][0]=='REPLAY' and max(map(float,log[2][1:3]))<5e-6
    head=next(r for r in log if r[0]=='FOLD')
    _,actual_lane,index,theta_str,factor_str,prev_theta,prev_factor,metric,step,end,area,length,physical=head
    assert lane==actual_lane and index=='50' and physical=='56'
    previous,list_current=[list(map(float,r[2:])) for r in log if r[0]=='INITIAL_FIELD']
    current=list_current
    theta,factor,prev_lambda,metric,area,length=map(float,(theta_str,factor_str,prev_factor,metric,area,length))
    assert len(previous)==len(current)==60 and area==216004.
    assert abs(metric-sqrt(fsum((a-b)**2 for a,b in zip(previous[:56],current[:56],strict=True)))/abs(factor-prev_lambda))<1e-12
    initial_history=next(r for r in log if r[0]=='INITIAL_OBSERVED_HISTORY')
    assert len(initial_history)==1+3*(9*88+2)
    history_hash=sha256(';'.join(initial_history[1:]).encode('ascii')).hexdigest().upper()
    initial_field_hash=sha256('\n'.join(';'.join(r) for r in log if r[0]=='INITIAL_FIELD').encode('ascii')).hexdigest().upper()
    history=[{'index':50,'theta_rad_m':theta,'T_kNm':factor*100,'accepted_seed':True}]
    used=[]
    for field_meta in (r for r in log if r[0]=='FOLDSTEP'):
        _,idx,attempt,ratio,target,trial_lambda=field_meta
        helpers=[r for r in log if len(r)>3 and r[1:4]==['Current',idx,attempt]]
        by_kind={r[0]:r for r in helpers if r[0]!='POINT'}
        trial=list(map(float,by_kind['TRIALFIELD'][4:]))
        resultants=list(map(float,by_kind['WRENCH'][4:]))
        weak_vector=list(map(float,by_kind['WEAK'][4:]))
        native_lambda,measure,tau,weak,recomputed,gauge,recorded_control,utilization=map(float,by_kind['BALANCE'][4:12])
        assert len(trial)==len(weak_vector)==60 and len(resultants)==6
        assert native_lambda==float(trial_lambda) and native_lambda>0
        delta=factor-prev_lambda
        ratio=float(ratio)
        if lane=='Arc':
            steps=[c-p for c,p in zip(current[:56],previous[:56],strict=True)]
            metric_squared=fsum([*(x*x for x in steps),(metric*delta)**2])
            distance=fsum([*(d*(t-c) for d,t,c in zip(steps,trial[:56],current[:56],strict=True)),
                           metric**2*delta*(native_lambda-factor)])
            residual=(distance-ratio*metric_squared)/sqrt(metric_squared)*36100.
        else:
            residual=(trial[3]-float(target)*length/1000)*36100.
        assert abs(residual-recorded_control)<1e-8
        assert abs(max(map(abs,weak_vector[:56]))-weak)<1e-12
        assert abs(max(map(abs,weak_vector[56:]))*36100-gauge)<1e-12
        integrated,longitudinal,hoop=integrate([r for r in helpers if r[0]=='POINT'])
        expected=[0.,0.,0.,native_lambda*100000000.,0.,0.]
        normalized=norm(integrated,expected,area,length)
        assert norm(integrated,resultants,area,length)<=1.e-10
        assert max(normalized,weak,gauge,abs(residual))<=tau+1e-8
        assert abs(recomputed-norm(resultants,expected,area,length))<1e-10
        theta=trial[3]*1000/length
        assert theta>history[-1]['theta_rad_m'] and native_lambda>0 and utilization<1
        field_record=next(r for r in log if r[:3]==['FIELD',idx,attempt])
        history.append({'index':int(idx),'theta_rad_m':theta,'T_kNm':native_lambda*100.,
                        'slopes_to_previous_kNm_per_rad_m':(native_lambda*100.-history[-1]['T_kNm'])/(theta-history[-1]['theta_rad_m']),
                        'strength_ratio':utilization,'longitudinal_strain_range':longitudinal,'hoop_strain_range':hoop,
                        'original_six_residual_MPa':normalized,'weak_residual_MPa':weak,'gauge_residual_MPa':gauge,
                        'constraint_residual_MPa':residual,'seconds_including_first_replay':float(field_record[9])})
        used.append(int(attempt))
        previous,current=current,trial
        prev_lambda,factor=factor,native_lambda
    stop=next(r for r in log if r[0]=='FOLDSTOP')
    assert len(history)>1 and int(stop[2])==len(history)-1
    assert f'TOTAL_A2_FOLD: passed={len(history)}; failed=0' in complete
    rollback=[r[1:] for r in log if r[0]=='ROLLBACK']
    assert sum(r[0]=='Rejected' for r in rollback)==int(stop[3])
    assert len([r for r in rollback if r[0]=='FirstBalancedTrial'])==1
    assert ['REPEAT','SameFieldAndFactor',str(used[0])] in log
    turns=[]
    for left,point,right in zip(history,history[1:],history[2:]):
        if min(point['T_kNm']-left['T_kNm'],point['T_kNm']-right['T_kNm'])>0:
            turns.append([left['index'],point['index'],right['index']])
    timer=json.loads((lane_root/'Native/Timing.json').read_text(encoding='utf-8-sig'))
    proof={'lane':lane,'native_report_sha256':digest(report),'native_trace_sha256':digest(trace),'initial_history_sha256':history_hash,
           'initial_fields_sha256':initial_field_hash,'stop':stop[1],'field_count':len(history)-1,'max_sample':max(history,key=lambda x:x['T_kNm']),
           'sampled_turning_brackets':turns,'fields':history,'rollback_checks':rollback,'wall_seconds':timer['seconds'],
           'comparison_window_covered':stop[1]=='ComparisonWindow','physical_capacity_certified':False}
    path=lane_root/'Fold.Verification.json'
    path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
    print(lane,digest(path),proof['max_sample'],turns,proof['wall_seconds'])


def compare(root):
    reports={lane:json.loads((root/lane/'Fold.Verification.json').read_text(encoding='utf-8')) for lane in ('Twist','Arc')}
    left,right=reports.values()
    assert left['initial_history_sha256']==right['initial_history_sha256'] and left['initial_fields_sha256']==right['initial_fields_sha256']
    values=[]
    for point in left['fields'][1:]:
        theta=point['theta_rad_m']
        for a,b in zip(right['fields'],right['fields'][1:]):
            if a['theta_rad_m']<theta<=b['theta_rad_m']:
                ratio=(theta-a['theta_rad_m'])/(b['theta_rad_m']-a['theta_rad_m'])
                interpolated=a['T_kNm']+ratio*(b['T_kNm']-a['T_kNm'])
                values.append({'twist_rad_m':theta,'Twist_T_kNm':point['T_kNm'],'Arc_T_kNm_linear_between_accepted':interpolated,
                               'Arc_fields':[a['index'],b['index']]})
                break
    result={'report_hashes':{key:digest(root/key/'Fold.Verification.json') for key in reports},
            'same_replayed_history':True,'both_cover_window':all(data['comparison_window_covered'] for data in reports.values()),
            'max_samples':{key:data['max_sample'] for key,data in reports.items()},
            'sampled_brackets':{key:data['sampled_turning_brackets'] for key,data in reports.items()},
            'same_twist_interpolation':values,'physical_capacity_certified':False}
    path=root/'Pair.Verification.json'
    path.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(digest(path),json.dumps(result,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pair',action='store_true')
    args=parser.parse_args()
    compare(HERE) if args.pair else native(HERE)
