"""Replay the frozen A2 fold comparison offline from the native records."""

import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import isclose
from pathlib import Path
import re
from shutil import copytree
from subprocess import check_output
import sys
from tempfile import TemporaryDirectory


HERE = Path(__file__).resolve().parent
LANES = ("Twist", "Arc")
NEWTON = "src/Solver/CCoupledNewtonSolver.cls"
MODULE = "tests/modTestCoupledExperiment.bas"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
COMMIT = "f4741ae638f3c17bc19b39e02d177698c247bd86"
PAIR_HASH = "910DC52F5004C1E5FF51AB0055E2E2C4A317360056CD95C14229CF74270267A8"


def load_module(path, name):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(data):
    return sha256(data).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_bytes())


def match(actual, expected):
    if isinstance(expected, dict):
        assert actual.keys() == expected.keys()
        for key in expected:
            match(actual[key], expected[key])
    elif isinstance(expected, list):
        assert len(actual) == len(expected)
        for item, reference in zip(actual, expected, strict=True):
            match(item, reference)
    elif isinstance(expected, float):
        assert isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-13), (actual, expected)
    else:
        assert actual == expected, (actual, expected)


def verify_source(staged, repository):
    expected = read_json(HERE / "PairSource.json")
    post = HERE / "Provenance/BPost"
    for path, key in (
        ("Fixture.json", "post_fixture_sha256"),
        ("Native/B-Post.csv", "post_trace_sha256"),
        ("B-Post-Verification.json", "post_result_sha256"),
    ):
        assert digest((post / path).read_bytes()) == expected[key]
    prior = read_json(post / "Fixture.json")
    assert prior["historicalGit"] == COMMIT[:7]
    assert prior["sectionSources"] == expected["original_sources"]
    assert prior["workbookSHA256"] == expected["workbook_sha256"]
    for name in ("B43.csv", "B-Cold.csv", "B-FirstResume.csv", MODULE):
        assert digest((post / name).read_bytes()) == prior["frozen"][name]
    prefix = load_module(post / "Replay-Post.py", "verify_b_prefix")
    assert prefix.exact_b_prefix() == 43

    preparer = load_module(HERE / "Prepare.py", "prepare_fold")
    preparer.POST = post
    preparer.HERE = staged
    assert preparer.freeze_history() == expected["history"]
    assert (staged / "B50.csv").read_bytes() == (HERE / "B50.csv").read_bytes()
    preparer.HERE = HERE
    for lane in LANES:
        assert preparer.fold_module(lane) == (HERE / lane / MODULE).read_bytes()

    for name, expected_hash in expected["original_sources"].items():
        value = (HERE / "Historical" / name).read_bytes()
        assert digest(value) == expected_hash
        if repository is not None:
            assert check_output(["git", "show", f"{COMMIT}:{name}"], cwd=repository) == value
    arc = load_module(HERE / "Provenance/ArcPrepare.py", "prepare_arc")
    arc.REPO = HERE / "Historical"
    rebuilt = arc.compose_newton().strip().replace("\n", "\r\n").encode("utf-8") + b"\r\n"
    assert digest(rebuilt) == expected["optional_newton_sha256"]
    assert rebuilt == (HERE / "Arc" / NEWTON).read_bytes()
    return expected["workbook_sha256"]


def verify_receipts(lane, book_hash):
    root = HERE / lane
    fixture = read_json(root / "Fixture.json")
    assert fixture["lane"] == lane and fixture["workbook_sha256"] == book_hash
    assert fixture["accepted_prefix_fields"] == 50
    for name, expected in fixture["frozen"].items():
        if name == BOOK:
            assert expected == book_hash
            continue
        path = root / name
        if not path.exists():
            path = HERE / name
        assert digest(path.read_bytes()) == expected, name
    compiled = read_json(root / "CodeUpdate.json")
    assert compiled["Compiled"] and not compiled["ProductionChanged"]
    assert compiled["ProductionSHA256"] == book_hash and compiled["Modules"] == fixture["modules"]
    close = read_json(root / "CompileClosure.json")
    owner_line = (root / "Compile.log").read_text(encoding="utf-8-sig")
    owner_id, owner_ticks = re.search(r"OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)", owner_line).groups()
    assert close["State"] == "Absent" and str(close["PID"]) == owner_id and close["StartTicksUTC"] == owner_ticks
    owner = read_json(root / "Native/Fold.txt.Ownership.json")
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"]
    assert owner["SourceSHA256"] == compiled["WorkbookSHA256"]
    exit_record = read_json(root / "Native/Fold.txt.ProcessClosure.json")
    assert exit_record["ChildHasExited"] and exit_record["ChildExitCode"] == 0 and exit_record["Passed"]
    assert not exit_record["OrdinaryPathKilledAnything"]
    state = exit_record["Closure"]["FinalState"]
    assert state["State"] == "Absent" and state["PID"] == owner["PID"]
    assert state["StartTicksUTC"] == owner["StartTicksUTC"]
    timer = read_json(root / "Native/Timing.json")
    assert timer["exit_code"] == 0 and timer["seconds"] > 0


def verify_numeric(staged):
    runner = load_module(HERE / "Verify.py", "verify_fold")
    variants = {}
    for lane in LANES:
        canonical = HERE / lane
        target = staged / lane
        copytree(canonical / "Native", target / "Native")
        runner.native(target)
        generated_path = target / "Fold.Verification.json"
        expected_path = canonical / "Fold.Verification.json"
        report = read_json(generated_path)
        match(report, read_json(expected_path))
        generated_path.write_bytes(expected_path.read_bytes())  # Preserve receipt hashes during pair replay.
        variants[lane] = report
    runner.compare(staged)
    result = read_json(staged / "Pair.Verification.json")
    golden_path = HERE / "Pair.Verification.json"
    assert digest(golden_path.read_bytes()) == PAIR_HASH
    match(result, read_json(golden_path))
    assert result["same_replayed_history"] and result["both_cover_window"]
    assert not result["physical_capacity_certified"]
    return variants, result


def summarize(variants, pair):
    fields = {lane: data["fields"] for lane, data in variants.items()}
    low = max(lane[0]["theta_rad_m"] for lane in fields.values())
    high = min(lane[-1]["theta_rad_m"] for lane in fields.values())
    peaks = {
        lane: max((point for point in data if low <= point["theta_rad_m"] <= high), key=lambda p: p["T_kNm"])
        for lane, data in fields.items()
    }
    match(peaks, pair["max_samples"])
    assert low < high
    assert pair["sampled_brackets"] == {lane: [[52, 53, 54]] for lane in LANES}
    matches = pair["same_twist_interpolation"]
    assert len(matches) == len(fields["Twist"]) - 1
    comparisons = []
    for point in matches:
        index0, index1 = point["Arc_fields"]
        a, b = [f for f in fields["Arc"] if f["index"] in (index0, index1)]
        assert a["theta_rad_m"] < point["twist_rad_m"] <= b["theta_rad_m"]
        comparisons.append({
            **point,
            "arc_minus_twist_kNm": point["Arc_T_kNm_linear_between_accepted"] - point["Twist_T_kNm"],
        })
    timings = {lane: variants[lane]["wall_seconds"] for lane in LANES}
    maxima = {lane: max(p.get("original_six_residual_MPa", 0) for p in data) for lane, data in fields.items()}
    return {
        "common_measured_twist_range_rad_m": [low, high],
        "sample_maximum": peaks,
        "arc_minus_twist_at_sample_maxima_kNm": peaks["Arc"]["T_kNm"] - peaks["Twist"]["T_kNm"],
        "same_twist_comparisons": len(comparisons),
        "greatest_abs_difference_at_same_theta": max(comparisons, key=lambda p: abs(p["arc_minus_twist_kNm"])),
        "difference_at_twist_sample_peak": next(p for p in comparisons if p["twist_rad_m"] == peaks["Twist"]["theta_rad_m"]),
        "native_runner_seconds": timings,
        "native_arc_reduction_percent": (1 - timings["Arc"] / timings["Twist"]) * 100,
        "native_accepted_step_seconds_including_replay": {
            lane: sum(p.get("seconds_including_first_replay", 0) for p in data) for lane, data in fields.items()
        },
        "accepted_fields_after_seed": {lane: variants[lane]["field_count"] for lane in LANES},
        "rejected_trials_with_rollback": {
            lane: sum(p[0] == "Rejected" for p in variants[lane]["rollback_checks"]) for lane in LANES
        },
        "max_original_six_residual_MPa": maxima,
        "physical_capacity_certified": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--git", type=Path, help="also compare the historical sources with this Git repository")
    parser.add_argument("--write-summary", type=Path, help="export replayed numerical comparison")
    args = parser.parse_args()
    manifest = read_json(HERE / "SHA256SUMS.json")
    for name, expected in manifest.items():
        assert digest((HERE / name).read_bytes()) == expected, name
    with TemporaryDirectory(prefix="a2-fold-replay-") as directory:
        work = Path(directory)
        book_hash = verify_source(work, args.git)
        for lane in LANES:
            verify_receipts(lane, book_hash)
        variants, pair = verify_numeric(work)
        summary = summarize(variants, pair)
    if args.write_summary is not None:
        text = json.dumps(summary, indent=2) + "\n"
        args.write_summary.write_bytes(text.encode("utf-8"))
    else:
        match(summary, read_json(HERE / "Comparison.json"))
    print("PASS A2 FOLD OFFLINE", PAIR_HASH)


if __name__ == "__main__":
    assert not sys.flags.optimize
    main()
