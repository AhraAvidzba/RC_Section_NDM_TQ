Physical scaling sensitivity for a short uncommitted pseudo-arc and the original fixed target.

    python -B -X utf8 tmp/mv26g/Stage.py --materialize-d
    python -B -X utf8 D:/CodexScratch/RC_Section_NDM_TQ/MVT2BridgeScaling/Verify-MVT2ShearControlled.py --inputs-only

Only after assigning the isolated Office slot and verifying available physical memory, commit
memory and disk reserve, launch the native driver located on D.

    powershell -NoProfile -ExecutionPolicy Bypass -File D:/CodexScratch/RC_Section_NDM_TQ/MVT2BridgeScaling/Run-MVT2ShearControlled.ps1

Two rules derive the load-axis scale from original accepted fields. The first uses the latest
physical station-strain increment divided by its accepted load increment. The second uses the
median of the last three such ratios. Both use the same dimensionless step: half the ratio of
requested to preceding accepted fixed-control increments, capped at one half, times the last
secant length in the corresponding physical metric. The preset H26 archive fixes the initial
state only. No specimen-specific scale, target step, active station, or downstream field is
provided to the native routines. The archived result serves only as an independent control.
Only eligible arc fields seed the original p·q=c; same 26-iteration allowance for each arm,
including the reproduced 15-iteration stock failure. Each arm ends restoring H26 exactly.
No workbook is duplicated on C in this source-only directory. Native fixture uses D.
