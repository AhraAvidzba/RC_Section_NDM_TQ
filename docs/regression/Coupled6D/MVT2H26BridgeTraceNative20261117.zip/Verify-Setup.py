"""Сверяет применение исторической касательной только для построения префикса H26."""


def verify_setup(raw):
    begins = raw["B_FB_START"]
    assert len(begins) == 1 and begins[0][0] == "53"
    trials = raw["B_FB_TRIAL"]
    assert [row[0] for row in trials] == ["1", "2"]
    first = tuple(map(float, begins[0][1:]))
    values = [tuple(map(float, row[1:])) for row in trials]
    assert values[0][0] == first[0] and values[1][0] == values[0][1]
    assert values[1][1] < values[1][3] < values[0][1] < first[0]
    assert all(value[2] <= value[3] for value in values)
    assert raw["B_EXT_DECISION"] == [["Attempt1", "Accepted"], ["Attempt2", "Accepted"]]
    order = [tag for tag, row in raw.items() if tag in ("B_FB_START", "B_EXT_SOLVER", "A_STOCK", "X_STOCK")]
    assert order[0] == "B_FB_START"
    return {"attempt": "H24 to H25", "initial_weak_residual_MPa": first[0],
            "first_correction_MPa": values[0][1], "second_correction_MPa": values[1][1],
            "two_bounded_corrections": True, "H25_to_H26_without_bounded_recovery": True}
