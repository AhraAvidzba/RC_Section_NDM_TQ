"""Сверяет опубликованное штатным продолжением равновесное поле H27."""

import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
from ArchiveInputs import prepare
from ProcessReceipts import verify_run
from ResumeBase import v


HERE = Path(__file__).resolve().parent
TERMINAL = "78B6BCD984EB24C8AB94A2F1E99E7CE6693ECEAF87A1F66DC7E6CB1C6AE35C09"
API_TERMINAL = "3D1DDCABACCE72EC2940CE3E6B531D9F10F7653D1BDA53D9D6FBE326F6870656"
TRACE = "5732CC9AA74D070117137A2C0139E9412CE9620EB747E2C827FA0B24679D21A5"


def verify_sources(prep):
    for item in prep["arc_sources"]["modules"]:
        name = item["path"]
        original = HERE / "SourceEvidence" / name
        diagnostic = HERE / name
        assert v.digest(original) == item["candidate_sha256"]
        if name.endswith("CCoupledNewtonSolver.cls"):
            block = rb"^Friend Function TryRecoverDeformationByArc\(.*?^End Function"
            body = [re.search(block, f.read_bytes(), re.M | re.S)[0] for f in (original, diagnostic)]
            assert body[0] == body[1]
            continue
        normal = original.read_text(encoding="utf-8")
        observed = diagnostic.read_text(encoding="utf-8")
        marker = "Private mStopAfterArcFirstPointTest As Boolean\n"
        break_line = "            If mStopAfterArcFirstPointTest Then Exit For\n"
        assert observed.count(marker) == observed.count(break_line) == 1
        assert observed.count("            AcceptPoint history, trial\n") == 1
        fixed = observed.index("            AcceptPoint history, trial\n")
        assert fixed < observed.index(break_line)
        trailer = """
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Завершает направленную пробу только после принятия первого поля штатным алгоритмом.
Friend Sub StopAfterArcFirstPointTest()
    mStopAfterArcFirstPointTest = True
End Sub
"""
        assert observed.endswith(trailer)
        assert normal == observed.removesuffix(trailer).replace(marker, "").replace(break_line, "")


def main():
    if not __debug__:
        raise SystemExit("Use Python without -O")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook", type=Path)
    parser.add_argument("--diagnostic-workbook", type=Path)
    args = parser.parse_args()
    inputs = prepare(args)
    assert inputs[0]["trace_first_accepted_point_test_only"] is True
    assert inputs[0]["exact_reference_Qy_kN"] == 15
    verify_sources(inputs[0])
    verify_run(HERE, 0, inputs[0])
    spec = spec_from_file_location("native_verify", HERE / "Verify-MVT2ShearControlled.py")
    native = module_from_spec(spec)
    spec.loader.exec_module(native)
    result = native.verify(inputs)
    terminal = HERE / "VerificationArcTrace.json"
    assert v.digest(terminal) == TERMINAL and result["trace_sha256"] == TRACE
    assert json.loads(json.dumps(result)) == v.read(terminal)
    witness = HERE / "SourceEvidence/VerificationArcApi.json"
    assert v.digest(witness) == API_TERMINAL
    direct = v.read(witness)
    assert direct["solver_source"] == inputs[0]["arc_sources"] and direct["replayed_branch_matches"] is True
    assert abs(direct["Qy_kN"] - result["Qy_kN"]) <= 5e-13
    assert result["test_ended_after_first_acceptance"] and not result["physical_limit_established"]
    print(f"TRACE λ={result['lambda']:.14f} Qy={result['Qy_kN']:.13f} kN "
          f"residual={result['normalized_equilibrium_MPa']:.9g} MPa")
    print(f"DESIGN H{result['valid_design_witness']['history_index']} λ=1, "
          f"PROBES {result['solver_probes']} AUXILIARY {result['auxiliary_probes']} "
          f"PUBLISHED {result['published_points']}")
    print("MVT2 H26 BRIDGE TRACE PORTABLE VERIFIED", TERMINAL)


if __name__ == "__main__":
    main()
