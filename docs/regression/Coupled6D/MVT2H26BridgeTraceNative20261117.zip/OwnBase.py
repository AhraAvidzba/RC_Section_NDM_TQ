"""Verify original fixed target and legacy recovery from its own Newton trajectory."""
import argparse
from collections import defaultdict
from decimal import Decimal
import json
from pathlib import Path

import FixedBase as fixed
from FixedBase import radius, prior, v

HERE=Path(__file__).resolve().parent
NATIVE=HERE/"NativeResume/MVT2.csv"


def prepare():
    frozen,_guide,_chosen,projection,_span,target=fixed.prepare()
    stock=v.read(HERE/"FixedTargetWitness.json")
    assert stock["trials"][0]["mode"]=="FixedStock" and not stock["trials"][0]["met_original_target"]
    assert stock["trials"][1]["met_original_target"]
    assert v.peak(v.diff(stock["selected_projection"],projection))<2e-13
    v.near(stock["target_coordinate"],target,3e-15)
    return frozen,stock,projection,target


def verify(frozen,stock,projection,target):
    prep,prefix,base24,old_stations,witnesses,*_=frozen
    compiler,owner,wall=radius.base.verified_receipts(prep)
    raw=v.read_native(NATIVE)
    assert raw["B_FRESH_PHASE"]==[["Resume"]] and raw["B_TANGENT_END"]==[["24","18.55811"]]
    assert raw["B_EXT_DECISION"]==[["Attempt1","Accepted"],["Attempt2","Accepted"]]
    assert not raw["B_Y_SEED_EVENT"] and not raw["B_RADIUS_REJECT"] and not raw["B_FIX_SOLVER"]
    assert tuple(prior.by_name(raw,"B_EXT_TRY"))==("Attempt1","Attempt2")
    fields=prior.by_name(raw,"B_TANGENT_FIELD")
    forces=prior.by_name(raw,"B_EXT_SOLVER_ACTUAL")
    committed=prior.by_name(raw,"B_EXT_COMMITTED")
    snapshot=prior.by_name(raw,"B_ARC_HISTORY")
    assert snapshot["Base24"]==snapshot["Restored24"]
    assert all(len(values)==1080 and all(Decimal(x).is_finite() for x in values) for values in snapshot.values())
    replay=v.vec(raw,"MVT2_CONTROL_FIELD")
    assert len(replay)==24
    for i,(field,_q) in enumerate(prefix,1):
        assert v.peak(v.diff(replay[f"Replay{i}"],field))<1e-15
    previous=snapshot["Base24"]
    for i,state in enumerate(witnesses,1):
        label=f"Attempt{i}"
        assert fields[label]==[str(23+i),*state[:61]] and forces[label]==state[61:67] and committed[label]==state[1:61]
        assert snapshot["BeforeSolve"+label]==snapshot["BeforeDecision"+label]==previous
        previous=snapshot["Committed"+label]
        assert snapshot["Replayed"+label]==previous==state[67:]
    for key in ("OwnBefore","OwnAfterLegacy","OwnAfterExact"):
        assert snapshot[key]==previous
    [[count,h26_q,_elapsed]]=raw["B_RESUME_END"]
    assert count=="26" and float(h26_q)==float(witnesses[1][0])==18.5785550208131
    [[name,*numbers]]=raw["B_OWN_CONTROL"]
    requested,atol,rtol,cap=prior.numbers(numbers)
    assert name==stock["control_name"] and (atol,rtol,cap)==(5e-7,5e-7,26.)
    v.near(requested,target,3e-15)
    ctrl=v.vec(raw,"B_OWN_PROJECTION")
    assert ctrl["Original"][-4:]==(0.,)*4 and v.peak(v.diff(ctrl["Original"],projection))<2e-13
    [(row,norm,tolerance,stall_lambda,start_eq,last_eq,last_fraction)]=map(prior.numbers,raw["B_OWN_STALL"])
    assert row==46 and last_fraction in tuple(2.**(-i) for i in range(8)) and norm>tolerance
    assert [";".join(item) for item in raw["B_OWN_STALL_META"]]==[stock["trials"][0]["diagnostic"]]
    assert start_eq*(last_eq-start_eq)>0.
    directions={name:prior.numbers(record) for name,record in prior.by_name(raw,"B_OWN_VECTOR").items()}
    assert len(directions["Direction"])==61 and all(len(x)==60 for key,x in directions.items() if key!="Direction")
    for key,frac in (("Last",last_fraction),("Full",1.)):
        if key in directions:
            expected=tuple(start+d*frac for start,d in zip(directions["Stall"],directions["Direction"][:60],strict=True))
            assert v.peak(v.diff(expected,directions[key]))<3e-15
    crossings=prior.by_name(raw,"B_OWN_CROSSING")
    assert tuple(crossings) in (("Last",),("Last","Full"))
    points=[]
    for tag,values in crossings.items():
        exists,*extra=values
        assert exists in ("0","1")
        if exists=="1":
            point,side,f0,f1=prior.numbers(extra)
            assert 1<=point<=45 and side in (-1,0,1) and f0*f1<0
            points.append({"newton_ray_part":tag,"point":int(point),"side":int(side),"signed_yields":[f0,f1]})
        else:
            assert not extra
            points.append({"newton_ray_part":tag,"point":None})
    assert (crossings["Last"]==["0"]) == ("Full" in crossings)
    station=defaultdict(dict)
    for tag,point,side,*state in raw["B_TANGENT_STATION"]:
        station[tag][int(point),int(side)]=prior.numbers(state)
    assert station["Base24"]==station["Restored24"]==old_stations
    native_rows=v.vec(raw,"B_TANGENT_RESIDUAL")
    solutions=prior.by_name(raw,"B_OWN_SOLVER")
    gates=prior.by_name(raw,"B_OWN_GATE")
    actuals=prior.by_name(raw,"B_OWN_ACTUAL")
    assert tuple(solutions) in (("Legacy",),("Legacy","Exact"))
    result=[]
    legacy_iterations=0
    for label,(solved,status,code,tried,iterations,elapsed,*details) in solutions.items():
        assert solved in ("0","1") and tried in ("0","1")
        used=int(iterations)
        if label=="Legacy":
            legacy_iterations=used
            assert (tried=="1")== (crossings["Last"][0]=="1")
        else:
            assert tried=="0" and 0<=used<=cap-legacy_iterations
        branch={"mode":label,"returned_trial":solved=="1","internal_status":int(status),"result_code":int(code),
                "legacy_recovery_tried":tried=="1","iterations":used,"seconds":float(elapsed),"detail":";".join(details)}
        if solved=="1":
            assert (status,code)==("4","0")
            factor,native_norm,control_error=prior.numbers(gates[label])
            wire="Own"+label
            history,q,*field=fields[wire]
            assert history=="26" and float(q)==factor
            q=prior.numbers(field)
            assert base24["geometry"]=={point:state[:3] for point,state in station[wire].items()}
            rows,force,roundoff=v.reconstruct(q,factor,station[wire])
            assert roundoff<4e-15 and v.peak(v.diff(rows,native_rows[wire]))<3e-10
            assert len(actuals[label])==6
            assert v.peak(x/s for x,s in zip(v.diff(force,prior.numbers(actuals[label])),v.SCALES,strict=True))<4e-12
            error=v.diff(force,v.force(factor))
            gauges=[x*v.MODULUS for x in rows[56:]]
            residual=max(v.peak(rows[:56]),v.peak(gauges),v.peak(x/s for x,s in zip(error,v.SCALES,strict=True)))
            tau=5e-7*(1+v.peak(v.loading(factor)))
            assert residual<=tau
            v.near(native_norm,residual,4e-10)
            v.near(control_error,v.MODULUS*(v.dot(ctrl["Original"],q)-requested),3e-10)
            if label=="Exact":
                assert abs(control_error)<=tau
            else:
                assert "Legacy" in ctrl and ctrl["Legacy"][-4:]==(0.,)*4
            branch.update({"Qy_kN":factor,"original_control_residual_MPa":control_error,"actual_six_N_Nmm":force,
                           "signed_six_errors_N_Nmm":error,"weak56_MPa":rows[:56],"gauge4_MPa":gauges,
                           "original_force_weak_norm_over_tau":residual/tau})
        else:
            assert label not in gates and label not in actuals
        result.append(branch)
    if result[0]["returned_trial"] and legacy_iterations < cap:
        assert "Exact" in solutions and not raw["B_OWN_SKIP"]
    else:
        assert "Exact" not in solutions
        assert raw["B_OWN_SKIP"]==[["IterationBudget" if result[0]["returned_trial"] else "NoGuide"]]
    return {"native_trace_sha256":v.digest(NATIVE),"fixed_target":requested,"H26_restored_exactly":True,"H24_restored_exactly":True,
            "no_external_arc_guide":True,"same_stock_stall_row":int(row),"stock_norm_over_tau":norm/tolerance,
            "last_newton_fraction":last_fraction,"first_yield_crossings":points,"trials":result,
            "physical_limit_established":False,"compiler_closed":compiler,"office_closed":owner,"native_wall_seconds":wall}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--phase",choices=["Resume"])
    args=parser.parse_args()
    inputs=prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert args.phase=="Resume"
        out=HERE/"VerificationOwnRecovery.json"
        out.write_bytes((json.dumps(verify(*inputs),indent=2)+"\n").encode())
        print(out,v.digest(out))
