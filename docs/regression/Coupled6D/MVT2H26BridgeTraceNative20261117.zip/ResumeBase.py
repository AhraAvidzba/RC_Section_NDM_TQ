"""Check two separate H26 pseudo-arclength probes and their committed prefix."""
import argparse
import csv
from decimal import Decimal
import json
from math import hypot, isfinite
from pathlib import Path

import PriorReplay as prior
import VerifyBase as v

HERE = Path(__file__).resolve().parent
NATIVE = HERE / "NativeResume"


def wire_chunks(name, widths):
    data = (HERE / name).read_bytes()
    assert data.endswith(b"\r\n") and data.count(b"\r\n") == data.count(b"\n") == data.count(b"\r")
    rows = list(csv.reader(data.decode("ascii").splitlines(),delimiter=";"))
    assert [len(row) for row in rows] == list(widths)
    assert max(map(len,data.split(b"\r\n"))) < 500
    return [item for row in rows for item in row]


def prepare():
    prep = v.read(HERE / "Preparation.json")
    assert all(v.digest(HERE / path) == sha for path, sha in prep["inputs"].items())
    assert prep["inputs"]["Replay.csv"] == prep["replay_sha256"] and prep["watchdog_seconds"] == 105
    archive, stations = v.verified_states(v.read_native(HERE / "JetNative.csv"))
    base24 = archive["Base24"]
    assert base24 == archive["Restored24"] and stations["Base24"] == stations["Restored24"]
    history = (HERE / "Replay.csv").read_text().splitlines()[1:]
    assert len(history) == 24
    prefix = [(tuple(map(float, row[9:])), float(row[2])) for row in (line.split(";") for line in history)]
    assert prefix[-1] == (base24["field"], base24["q"])
    accepted = wire_chunks("AcceptedWire.csv",(1,15,15,15,15,6,*(8,)*135)*2)
    witnesses = [accepted[:1147],accepted[1147:]]
    assert len(witnesses) == 2 and all(len(row) == 1147 for row in witnesses)
    assert [float(row[0]) for row in witnesses] == [18.5708039839326,18.5785550208131]
    endpoints = [(tuple(map(float,row[1:61])),float(row[0])) for row in witnesses]
    original_normal = prior.numbers((HERE / "MVTNormal.csv").read_text().strip().split(";"))
    pinned = prior.numbers(wire_chunks("H26Normal.csv",(15,15,15,15,3)))
    load_scale = v.read(HERE / "MVTHistory.json")["strains_normalized_to_last_Qy_increment_per_kN"]
    direct, normal_load, length = prior.determine_normal(endpoints[1],endpoints[0],base24["geometry"],load_scale)
    assert len(pinned) == 63 and pinned[56:60] == (0.,)*4 and pinned[62] == 1.31947154672837e-7
    assert v.peak(v.diff(direct,pinned[:60])) < 2e-12
    v.near(pinned[60],normal_load,2e-15)
    v.near(pinned[61],length,2e-17)
    return prep, prefix, base24, stations["Base24"], witnesses, original_normal, pinned, load_scale


def verified_receipts(prep):
    build = v.read(HERE / "docs/regression/CodeUpdate.json")
    compiler = v.read(HERE / "CompileClosure.json")
    owner = v.read(NATIVE / "MVT2.txt.Ownership.json")
    watch = v.read(NATIVE / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(NATIVE / "RunReceipt.json")
    office = watch["Closure"]["FinalState"]
    assert build["Compiled"] and sorted(build["Modules"]) == prior.MODULES and not build["ProductionChanged"]
    assert build["ProductionSHA256"] == prep["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == build["WorkbookSHA256"]
    assert watch["Passed"] and watch["ChildExitCode"] == receipt["native_exit"] == 0 and watch["ChildHasExited"]
    assert office["State"] == "Absent" and office["PID"] == owner["PID"] and office["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (NATIVE / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    return compiler, office, receipt["wall_seconds"]


def fallback_by_probe(path):
    measures, active = {}, None
    for marker, *row in csv.reader(path.read_text(encoding="cp1251").splitlines(), delimiter=";"):
        if marker == "B_EXT_TRY":
            assert active is None
            active = row[0]
            measures[active] = []
        elif marker.startswith("B_FB_"):
            assert active is not None
            measures[active].append([marker,*row])
        elif marker == "B_EXT_DECISION":
            assert active == row[0]
            active = None
    assert active is None
    return measures


def lambda_interval(q, tags):
    if tags == ["Unavailable"]:
        return None
    uncertainty, lo, hi = prior.numbers(tags)
    assert uncertainty > 0. and lo <= q <= hi
    v.near(lo,q-uncertainty,2e-13)
    v.near(hi,q+uncertainty,2e-13)
    return lo,hi


def verify(prep, prefix, base24, old_stations, witnesses, original, pinned, load_scale):
    compiler, office, wall = verified_receipts(prep)
    path = NATIVE / "MVT2.csv"
    tags = v.read_native(path)
    grouped_fallback = fallback_by_probe(path)
    snapshots = prior.by_name(tags,"B_ARC_HISTORY")
    assert all(len(values) == 1080 and all(Decimal(x).is_finite() for x in values) for values in snapshots.values())
    assert snapshots["Base24"] == snapshots["Restored24"]
    assert tags["B_FRESH_PHASE"] == [["Resume"]]
    assert len(tags["B_RESUME_PLAN"]) == 1
    scale, first_ds, atol, rtol, iterations = prior.numbers(tags["B_RESUME_PLAN"][0])
    v.near(scale,load_scale,2e-19)
    v.near(first_ds,original[61]/64.,3e-20)
    assert (atol,rtol,iterations) == (5e-7,5e-7,26)
    counts = prior.by_name(tags,"B_TANGENT_FIELD")
    recreated = dict(tags)
    recreated["B_TANGENT_FIELD"] = [[name,"24",*data] for name,_,*data in tags["B_TANGENT_FIELD"]]
    recreated.setdefault("B_TANGENT_UNAVAILABLE",[])
    states, stations = v.verified_states(recreated)
    assert states["Base24"] == states["Restored24"] == base24 and stations["Base24"] == stations["Restored24"] == old_stations
    source_fields = v.vec(tags,"MVT2_CONTROL_FIELD")
    for i,(field,_q) in enumerate(prefix,1):
        assert v.peak(v.diff(source_fields[f"Replay{i}"],field)) < 1e-15
    assert len(source_fields) == 24
    candidates = prior.by_name(tags,"B_EXT_SOLVER_ACTUAL")
    gates = prior.by_name(tags,"B_EXT_GATES")
    parameters = prior.by_name(tags,"B_EXT_TRY")
    projections = prior.by_name(tags,"B_EXT_PROJECTION")
    predictions = v.vec(tags,"B_EXT_SEED")
    outcomes = prior.by_name(tags,"B_EXT_SOLVER")
    decisions = prior.by_name(tags,"B_EXT_DECISION")
    uncertainty = prior.by_name(tags,"B_RESUME_UNCERTAINTY")
    committed = prior.by_name(tags,"B_EXT_COMMITTED")
    steel = v.verify_steel(tags,states,stations,source_fields)
    assert tuple(parameters) == tuple(outcomes) == tuple(decisions) == tuple(grouped_fallback) == tuple(f"Attempt{i}" for i in range(1,5))
    assert set(committed) == {"Attempt1","Attempt2"}
    assert set(states) - {"Base24","Restored24"} == set(candidates) == set(gates)
    previous, current = prefix[-2:]
    current_snapshot = snapshots["Base24"]
    base_interval = None
    results = []
    for i,(label,conditions) in enumerate(parameters.items(),1):
        h, old_factor, factor, ds, native_length, native_k, plane, predicted = prior.numbers(conditions)
        assert h == min(26,23+i) and (old_factor,factor) == (previous[1],current[1])
        p,k,length = prior.determine_normal(current,previous,base24["geometry"],load_scale)
        if i == 1:
            p,k,length = original[:60],*original[60:]
        elif i >= 3:
            assert tuple(map(float,projections[label])) == pinned[:60]
            assert (native_k,native_length) == pinned[60:62]
        assert v.peak(v.diff(p,prior.numbers(projections[label]))) < 2e-12
        v.near(length,native_length,2e-17)
        v.near(k,native_k,2e-15)
        declared_steps = (first_ds,first_ds*1.5/8.,pinned[62],pinned[62]/2.)
        v.near(ds,declared_steps[i-1],5e-20)
        ratio = ds/length
        target_q = tuple(q + ratio*(q-old) if j<56 else q for j,(q,old) in enumerate(zip(current[0],previous[0],strict=True)))
        assert v.peak(v.diff(target_q,predictions[label])) < 2e-15
        v.near(predicted,factor+ratio*(factor-old_factor),2e-12)
        v.near(plane,v.dot(p,current[0])+k*factor+ds,4e-15)
        assert snapshots["BeforeSolve"+label] == snapshots["BeforeDecision"+label] == current_snapshot
        solved, status, code, seconds, *diagnostic = outcomes[label]
        assert solved in ("0","1") and isfinite(float(seconds)) and 0. <= float(seconds) <= 105.
        reason, = decisions[label]
        row = {"attempt": i, "history_count": int(h), "decision": reason, "nominal_arc": ds, "solver_status": int(status),
               "solver_code": int(code), "solver_wall_seconds": float(seconds), "diagnostic": ";".join(diagnostic),
               "fallback_diagnostics": grouped_fallback[label]}
        if solved == "0":
            assert i >= 3 and label not in gates and reason == "Newton" and label not in uncertainty
        else:
            sample = states[label]
            q, native_norm, tol, native_progress, actual_length = prior.numbers(gates[label])
            assert q == sample["q"] and int(counts[label][0]) == h and sample["geometry"] == base24["geometry"]
            v.near(tol,sample["tol_MPa"],2e-18)
            rows, actual, _ = v.reconstruct(sample["field"],q,stations[label])
            norm = max(sample["norm_MPa"], sample["gauge_MPa"])
            v.near(native_norm,norm,4e-10)
            assert v.peak(d/s for d,s in zip(v.diff(actual,prior.numbers(candidates[label])),v.SCALES,strict=True)) < 4e-12
            change = v.diff(sample["field"],current[0])
            progress = v.dot(p,change)+k*(q-factor)
            radius = hypot(*prior.station_metric(change,base24["geometry"]),load_scale*(q-factor))
            v.near(native_progress,progress,4e-15)
            v.near(actual_length,radius,4e-15)
            if reason in ("Accepted","VerifiedProbe"):
                assert norm <= tol and progress > 0. and abs(progress-ds)*v.MODULUS <= tol and radius <= 3*ds
            else:
                assert i >= 3 and reason in ("Equilibrium","Direction","Radius")
                assert norm > tol or progress <= 0. or abs(progress-ds)*v.MODULUS >= tol-1e-11 or radius >= 3.*ds-4e-15
            row.update({"Qy_kN": q, "delta_Qy_kN": q-factor, "demand_N_Nmm": v.force(q), "computed_N_Nmm": actual,
                        "signed_errors_N_Nmm": sample["signed_force_N_Nmm"], "weak56_MPa": rows[:56],
                        "gauges4_MPa": [x*v.MODULUS for x in rows[56:]], "original_tolerance_MPa": tol,
                        "residual_over_original_tolerance": norm/tol, "arc_plane_error_MPa": (progress-ds)*v.MODULUS,
                        "directed_projection": progress,"actual_physical_step_over_nominal": radius/ds,
                        "maximum_steel_MPa": steel[label]})
            if i >= 2 and reason in ("Accepted","VerifiedProbe"):
                interval = lambda_interval(q,uncertainty[label])
                if i == 2:
                    base_interval = interval
                row["local_lambda_interval_kN"] = interval
                row["directional_load_intervals_N_Nmm"] = None if interval is None else tuple(zip(v.force(interval[0]),v.force(interval[1]),strict=True))
                if i >= 3:
                    delta = None if base_interval is None or interval is None else (interval[0]-base_interval[1],interval[1]-base_interval[0])
                    row["delta_lambda_interval_vs_H26_kN"] = delta
                    row["load_progression_sign_resolved"] = ("Unavailable" if delta is None else
                                                               "Positive" if delta[0]>0. else "Negative" if delta[1]<0. else "OverlapsZero")
        if i < 3:
            assert reason == "Accepted" and solved == "1"
            known = witnesses[i-1]
            assert counts[label][1:] == known[:61] and committed[label] == known[1:61] and candidates[label] == known[61:67]
            saved = snapshots["Committed"+label]
            assert snapshots["Replayed"+label] == saved == known[67:]
            assert all(Decimal(new)>=Decimal(old) for index,(new,old) in enumerate(zip(saved,current_snapshot,strict=True)) if index%8 in (6,7))
            current_snapshot = saved
            previous, current = current, (sample["field"],q)
            row["exact_archived_accepted_readback"] = True
        else:
            assert snapshots["Discarded"+label] == current_snapshot
            row["exact_H26_before_and_after"] = True
        results.append(row)
    [[count,start_q,elapsed]] = tags["B_RESUME_END"]
    assert count == "26" and float(start_q) == current[1] == 18.5785550208131
    assert sum(row["solver_wall_seconds"] for row in results) <= float(elapsed)+.05
    return {"book_sha256":prep["book_sha256"],"native_trace_sha256":v.digest(path),"exact_H26_replayed":True,
            "H24_restored_exactly":True,"private_probes_never_committed":True,"physical_capacity_established":False,
            "H26_base_Qy_kN":current[1],"H26_local_lambda_interval_kN":base_interval,"attempts":results,
            "compiler_closed":compiler,"office_closed":office,"native_wall_seconds":wall}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--phase",choices=["Resume"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
    else:
        assert args.phase == "Resume"
        output = HERE/"VerificationResume.json"
        output.write_bytes((json.dumps(verify(*frozen),indent=2)+"\n").encode())
        print(output,v.digest(output))
