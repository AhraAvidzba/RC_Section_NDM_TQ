"""Check identical fixed-coordinate H26 targets and original-law resultant closure."""
import argparse
from collections import defaultdict
import json
from math import fsum, isfinite
from pathlib import Path

import RadiusBase as radius
from RadiusBase import prior, v

HERE = Path(__file__).resolve().parent
NATIVE = HERE/"NativeResume/MVT2.csv"


def control(q0,q1,geometry):
    candidates = []
    for field in range(4):
        candidates.append(tuple(float(j == field) for j in range(60)))
    center = [record for (point,side),record in geometry.items() if point<=25 and side==0]
    assert len(center) == 25 and fsum(record[2] for record in center) == v.AREA
    for component in (4,5):
        candidates.append(tuple(fsum(area/v.AREA*v.strain_at(tuple(float(index==j) for index in range(60)),v.operators(x,y),0)[component]
                                     for x,y,area in center) for j in range(60)))
    values = [v.dot(p,v.diff(q1,q0)) for p in candidates]
    chosen = max(range(6),key=lambda index:abs(values[index]))
    assert values[chosen]
    sign = -1. if values[chosen]<0. else 1.
    return chosen,tuple(sign*x for x in candidates[chosen]),abs(values[chosen])


def prepare():
    frozen = radius.prepare()
    _prep,_prefix,base24,_old,witnesses,*_ = frozen
    guide = v.read(HERE/"GuideWitness.json")
    start = prior.numbers(witnesses[0][1:61])
    accepted = prior.numbers(witnesses[1][1:61])
    chosen,p,span = control(start,accepted,base24["geometry"])
    target = v.dot(p,accepted)+.5*span
    return frozen,guide,chosen,p,span,target


def verify(frozen,guide,chosen,p,span,target):
    reference = radius.verify(*frozen)
    raw = v.read_native(NATIVE)
    assert raw["B_Y_SEED_EVENT"] == [guide["B_Y_SEED_EVENT"]]
    guides = prior.by_name(raw,"B_TANGENT_FIELD")
    assert guides["FixedGuide"] == guide["B_TANGENT_FIELD"][1:]
    guide_factor,guide_wall = prior.numbers(raw["B_FIX_GUIDE"][0])
    assert guide_factor == float(guide["B_TANGENT_FIELD"][2])
    snapshots = prior.by_name(raw,"B_ARC_HISTORY")
    for item in ("FixedGuideDiscarded","FixedStockBefore","FixedStockAfter","FixedSeedBefore","FixedSeedAfter"):
        assert snapshots[item] == snapshots["CommittedAttempt2"]
    discovered = v.vec(raw,"B_FIX_PROJECTION")["Control"]
    assert discovered[-4:] == (0.,)*4 and v.peak(v.diff(discovered,p)) < 2e-13
    [[name,*params]] = raw["B_FIX_CONTROL"]
    names = ("продольная деформация","кривизна изгиба вокруг X","кривизна изгиба вокруг Y","закручивание",
             "средний инженерный сдвиг xz","средний инженерный сдвиг yz")
    assert name == names[chosen]
    coordinate,prior_coordinate,api_span,native_target,atol,rtol,limit = prior.numbers(params)
    assert (atol,rtol,limit) == (5e-7,5e-7,26.)
    v.near(api_span,span,3e-15)
    v.near(coordinate-prior_coordinate,span,3e-15)
    v.near(native_target,coordinate+.5*(coordinate-prior_coordinate),3e-15)
    v.near(native_target,target,3e-15)
    station = defaultdict(dict)
    for label,point,side,*values in raw["B_TANGENT_STATION"]:
        station[label][int(point),int(side)] = prior.numbers(values)
    scans = prior.by_name(raw,"B_FIX_SOLVER")
    gates = prior.by_name(raw,"B_FIX_GATES")
    actual = prior.by_name(raw,"B_FIX_ACTUAL")
    original_rows = v.vec(raw,"B_TANGENT_RESIDUAL")
    assert list(scans) == ["FixedStock","FixedSeed"]
    verified = []
    base_factor = reference["original_H26_Qy_kN"]
    for label, data in scans.items():
        success,status,code,initial,seconds,extra,*trace = data
        assert success in ("0","1") and extra == "0"
        assert float(initial) == (base_factor if label == "FixedStock" else guide_factor)
        assert isfinite(float(seconds)) and float(seconds)>=0
        result = {"mode":label,"met_original_target":success=="1","internal_status":int(status),"result_code":int(code),
                  "initial_Qy_kN":float(initial),"solver_seconds":float(seconds),"diagnostic":";".join(trace)}
        if success == "1":
            assert [status,code] == ["4","0"]
            factor,norm,tol,measured_coordinate,control_error = prior.numbers(gates[label])
            count,q,*qfield = guides[label]
            assert count=="26" and float(q)==factor
            field = prior.numbers(qfield)
            v.near(v.dot(p,field),measured_coordinate,3e-15)
            assert abs(control_error) <= tol
            v.near((v.dot(p,field)-native_target)*v.MODULUS,control_error,3e-10)
            rows,force,field_error = v.reconstruct(field,factor,station[label])
            assert field_error<4e-15 and v.peak(v.diff(rows,original_rows[label]))<3e-10
            assert len(actual[label]) == 6
            assert v.peak(x/s for x,s in zip(v.diff(force,prior.numbers(actual[label])),v.SCALES,strict=True))<4e-12
            errors = v.diff(force,v.force(factor))
            normalized_force = v.peak(x/s for x,s in zip(errors,v.SCALES,strict=True))
            gauges = tuple(x*v.MODULUS for x in rows[56:])
            measured = max(v.peak(rows[:56]),normalized_force,v.peak(gauges))
            v.near(norm,measured,4e-10)
            v.near(tol,5e-7*(1+v.peak(v.loading(factor))),2e-18)
            assert measured <= tol
            result.update({"Qy_kN":factor,"delta_Qy_from_H26_kN":factor-base_factor,"control_error_MPa":control_error,
                           "global_residual_over_original_tolerance":measured/tol,"target_six_N_Nmm":v.force(factor),
                           "actual_six_N_Nmm":force,"signed_effort_errors_N_Nmm":errors,"weak56_MPa":rows[:56],"gauge4_MPa":gauges})
        else:
            assert label not in gates and label not in actual and label not in station
        verified.append(result)
    return {"native_trace_sha256":reference["native_trace_sha256"],"H26_exact_rollback":True,
            "H24_exact_restored":reference["H24_exact_restored"],"control_name":name,"selected_projection":discovered,
            "H25_coordinate":prior_coordinate,"H26_coordinate":coordinate,"controlled_span":coordinate-prior_coordinate,
            "target_coordinate":native_target,"same_newton_iteration_cap":int(limit),"guide_Qy_kN":guide_factor,
            "guide_construction_seconds":guide_wall,"trials":verified,
            "scope_gain_at_this_target":not verified[0]["met_original_target"] and verified[1]["met_original_target"],
            "physical_capacity_established":False,"compiler_closed":reference["compiler_closed"],"office_closed":reference["office_closed"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only",action="store_true")
    parser.add_argument("--phase",choices=["Resume"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS",v.digest(HERE/"Preparation.json"))
        print("INDEPENDENT_CONTROL",frozen[2]+1,"SPAN",frozen[4],"TARGET",frozen[5])
    else:
        assert args.phase == "Resume"
        output = HERE/"VerificationFixedControl.json"
        output.write_bytes((json.dumps(verify(*frozen),indent=2)+"\n").encode())
        print(output,v.digest(output))
