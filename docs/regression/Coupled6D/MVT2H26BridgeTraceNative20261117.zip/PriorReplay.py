"""Independently replay the directed adaptive MVT2 physical pseudo-arclength."""
import argparse
from decimal import Decimal
import json
from math import fsum, hypot, isfinite, sqrt
from pathlib import Path

import VerifyBase as v

HERE = Path(__file__).resolve().parent
NATIVE = HERE / "NativeContinue"
MODULES = ["CCoupledConcreteResponse", "CCoupledNewtonSolver", "CCoupledReinforcedResponse",
           "modCoupledConcreteTensor", "modTestCoupledExperiment"]


def station_metric(field, geometry):
    total = fsum(area for _, _, area in geometry.values())
    return tuple(sqrt(area / total) * value / (1. if i < 3 else sqrt(2.))
                 for (_, side), (x, y, area) in geometry.items()
                 for i, value in enumerate(v.strain_at(field, v.operators(x, y), side)))


def determine_normal(current, previous, geometry, load_scale):
    q, factor = current
    old_q, old_factor = previous
    delta_lambda = factor - old_factor
    strain_vector = station_metric(v.diff(q, old_q), geometry)
    norm = hypot(*strain_vector, load_scale * delta_lambda)
    p = tuple(v.dot(strain_vector, station_metric(tuple(float(i == j) for j in range(60)), geometry)) / norm
              for i in range(56)) + (0.,) * 4
    return p, load_scale ** 2 * delta_lambda / norm, norm


def by_name(tags, name):
    result = {label: row for label, *row in tags[name]}
    assert len(result) == len(tags[name]), name
    return result


def numbers(tokens):
    result = tuple(map(float, tokens))
    assert all(map(isfinite, result)), tokens
    return result


def prepare():
    prep = v.read(HERE / "Preparation.json")
    assert all(v.digest(HERE / name) == sha for name,sha in prep["inputs"].items())
    assert v.digest(HERE / "Replay.csv") == prep["replay_sha256"]
    assert prep["watchdog_seconds"] == 245
    for name, sha in prep["unchanged_fallback_source"].items():
        assert name.startswith("src/") and prep["inputs"][name] == sha
    evidence = v.read(HERE / "MVTHistory.json")
    assert evidence["history_sha256"] == prep["replay_sha256"] and evidence["native_sha256"] == v.digest(HERE / "JetNative.csv")
    prior, old = v.verified_states(v.read_native(HERE / "JetNative.csv"))
    assert prior["Restored24"] == prior["Base24"] and old["Restored24"] == old["Base24"]
    states = []
    for label, offset, factor, *data in (line.split(";") for line in (HERE / "Replay.csv").read_text().splitlines()[1:]):
        assert int(label) == len(states) + 1 and len(data) == 66
        demand = list(v.force(float(factor)))
        demand[3] *= float(offset)
        assert v.peak(error/scale for error,scale in zip(v.diff(numbers(data[:6]),demand),v.SCALES,strict=True)) < 2e-14
        states.append((numbers(data[6:]), float(factor)))
    assert len(states) == 24 and states[-1] == (prior["Base24"]["field"], prior["Base24"]["q"])
    wire = numbers((HERE / "MVTNormal.csv").read_text().strip().split(";"))
    load_scale = evidence["strains_normalized_to_last_Qy_increment_per_kN"]
    p, k, length = determine_normal(states[-1], states[-2], prior["Base24"]["geometry"], load_scale)
    assert v.peak(v.diff(p, wire[:60])) < 2e-15 and abs(k-wire[60]) < 2e-19 and abs(length-wire[61]) < 2e-18
    return prep, states, prior["Base24"], old["Base24"], wire, load_scale


def verify_run(prep):
    build = v.read(HERE / "docs/regression/CodeUpdate.json")
    compiler = v.read(HERE / "CompileClosure.json")
    owner = v.read(NATIVE / "MVT2.txt.Ownership.json")
    watch = v.read(NATIVE / "MVT2.txt.ProcessClosure.json")
    receipt = v.read(NATIVE / "RunReceipt.json")
    final = watch["Closure"]["FinalState"]
    assert build["Compiled"] and sorted(build["Modules"]) == MODULES and not build["ProductionChanged"]
    assert build["ProductionSHA256"] == prep["book_sha256"] and compiler["State"] == "Absent"
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == build["WorkbookSHA256"]
    assert watch["Passed"] and watch["ChildExitCode"] == receipt["native_exit"] == 0 and watch["ChildHasExited"]
    assert final["State"] == "Absent" and final["PID"] == owner["PID"] and final["StartTicksUTC"] == owner["StartTicksUTC"]
    log = (NATIVE / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log
    return compiler, final, receipt["wall_seconds"]


def verify(prep, inputs, archived, old_stations, wire, load_scale):
    compiler, closed, wall = verify_run(prep)
    path = NATIVE / "MVT2.csv"
    tags = v.read_native(path)
    tagged_counts = {name: int(count) for name, count, *_ in tags["B_TANGENT_FIELD"]}
    # Preserve the independent original-law checker. Its archive contract pins the reference field count to 24;
    # the actual per-attempt count is recorded above and matched to this continuation's committed sequence below.
    tagged_states = dict(tags)
    tagged_states["B_TANGENT_FIELD"] = [[name, "24", *rest] for name, _, *rest in tags["B_TANGENT_FIELD"]]
    tagged_states.setdefault("B_TANGENT_UNAVAILABLE", [])
    states, stations = v.verified_states(tagged_states)
    assert tags["B_FRESH_PHASE"] == [["Continue"]]
    assert not tags["B_TANGENT_UNAVAILABLE"]
    assert states["Base24"] == states["Restored24"] == archived
    assert stations["Base24"] == stations["Restored24"] == old_stations
    assert tagged_counts["Base24"] == tagged_counts["Restored24"] == 24
    history = v.vec(tags, "MVT2_CONTROL_FIELD")
    for i, (q, _) in enumerate(inputs, 1):
        assert v.peak(v.diff(q, history[f"Replay{i}"])) < 1e-15
    assert len(history) == 24
    steel = v.verify_steel(tags, states, stations, history)
    [[native_scale, initial_step, target_count, attempt_cap, budget, atol, rtol, iterations]] = tags["B_EXT_PLAN"]
    assert (int(target_count), int(attempt_cap), float(budget), float(atol), float(rtol), int(iterations)) == (6, 10, 175., 5e-7, 5e-7, 26)
    v.near(float(native_scale), load_scale, 2e-19)
    nominal = wire[61] / 64.
    v.near(float(initial_step), nominal, 3e-20)
    target_count, attempt_cap, budget = int(target_count), int(attempt_cap), float(budget)
    previous, current = inputs[-2:]
    progress = []
    snapshots = {label: tuple(map(Decimal, row)) for label, row in by_name(tags, "B_ARC_HISTORY").items()}
    assert all(len(row) == 1080 and all(x.is_finite() for x in row) for row in snapshots.values())
    assert snapshots["Base24"] == snapshots["Restored24"]
    used = {"Base24", "Restored24"}
    committed = snapshots["Base24"]
    old_side = old_stations
    normals = v.vec(tags, "B_EXT_PROJECTION")
    seeds = v.vec(tags, "B_EXT_SEED")
    exact_fields = v.vec(tags, "B_EXT_COMMITTED")
    gates = by_name(tags, "B_EXT_GATES")
    native_res = by_name(tags, "B_EXT_SOLVER_ACTUAL")
    outcomes = by_name(tags, "B_EXT_SOLVER")
    decisions = by_name(tags, "B_EXT_DECISION")
    attempts = by_name(tags, "B_EXT_TRY")
    assert tuple(attempts) == tuple(decisions) == tuple(outcomes) == tuple(normals) == tuple(seeds)
    assert 1 <= len(attempts) <= attempt_cap
    assert set(native_res) == set(gates) == set(states) - {"Base24", "Restored24"}
    accepted = 0
    for index, (label, attempt) in enumerate(attempts.items(), 1):
        assert label == f"Attempt{index}"
        history_count, old_factor, factor, ds, native_norm, native_k, plane, predicted_factor = numbers(attempt)
        assert history_count == 24 + accepted and (old_factor, factor) == (previous[1], current[1])
        v.near(ds, nominal, 4e-19)
        p, k, secant_norm = determine_normal(current, previous, archived["geometry"], load_scale)
        if accepted == 0:
            p, k, secant_norm = wire[:60], *wire[60:]
        assert v.peak(v.diff(p, normals[label])) < 2e-12 and normals[label][-4:] == (0.,) * 4
        v.near(secant_norm, native_norm, 4e-16)
        v.near(k, native_k, 2e-13)
        step_ratio = ds / secant_norm
        v.near(predicted_factor, current[1] + step_ratio * (current[1] - previous[1]), 2e-12)
        predicted_q = tuple(q + step_ratio * (q - old) if i < 56 else q
                            for i, (q,old) in enumerate(zip(current[0],previous[0],strict=True)))
        assert v.peak(v.diff(seeds[label], predicted_q)) < 2e-15
        v.near(plane, v.dot(p, current[0]) + k * current[1] + ds, 4e-12)
        v.near(v.dot(p, v.diff(seeds[label],current[0])) + k * (predicted_factor-current[1]), ds, 4e-15)
        before = "BeforeDecision" + label
        assert snapshots[before] == committed
        used.add(before)
        solved, internal, code, seconds, *diagnostic = outcomes[label]
        assert solved in ("0", "1") and isfinite(float(seconds)) and 0. <= float(seconds) <= 245.
        reason, = decisions[label]
        row = {"attempt": index, "history_count_before": int(history_count), "decision": reason,
               "target_step": ds, "newton_returned": solved == "1", "code": int(code), "internal_status": int(internal),
               "seconds": float(seconds), "diagnostic": ";".join(diagnostic)}
        if solved == "0":
            assert reason == "Newton" and label not in gates
        else:
            assert label in gates and tagged_counts[label] == history_count
            sample = states[label]
            solved_factor, norm, tolerance, directed, length = numbers(gates[label])
            assert sample["q"] == solved_factor and sample["geometry"] == archived["geometry"]
            v.near(tolerance, sample["tol_MPa"], 2e-18)
            v.near(norm, max(sample["norm_MPa"], sample["gauge_MPa"]), 4e-10)
            delta_q = v.diff(sample["field"], current[0]); delta_load = solved_factor - factor
            actual_direction = v.dot(p, delta_q) + k * delta_load
            actual_length = hypot(*station_metric(delta_q, archived["geometry"]), load_scale * delta_load)
            v.near(directed, actual_direction, 4e-15)
            v.near(length, actual_length, 4e-15)
            weak_and_gauge, actual, _ = v.reconstruct(sample["field"], solved_factor, stations[label])
            archived_solver = numbers(native_res[label])
            assert len(archived_solver) == 6
            assert v.peak((a-b)/scale for a,b,scale in zip(actual, archived_solver, v.SCALES, strict=True)) < 4e-12
            assert reason in ("Equilibrium", "Direction", "Radius", "Accepted")
            if reason == "Accepted":
                assert max(sample["norm_MPa"], sample["gauge_MPa"]) <= tolerance
                assert actual_direction > 0. and abs(actual_direction - ds) * v.MODULUS <= tolerance
                assert actual_length <= 3. * ds
            elif reason == "Equilibrium":
                assert norm > tolerance or v.peak(e/scale for e,scale in zip(v.diff(archived_solver,v.force(solved_factor)), v.SCALES, strict=True)) > tolerance
            elif reason == "Direction":
                assert directed <= 0. or abs(directed - ds) * v.MODULUS >= tolerance - 1e-11
            else:
                assert length >= 3. * ds - 4e-15
            changed = [list(key) for key,val in stations[label].items() if key[0] <= 25 and
                       (val[3:6] != old_side[key][3:6] or val[6]*old_side[key][6] < 0.)]
            row.update({"Qy_kN": solved_factor, "delta_Qy_kN": delta_load, "signed_arc_direction": actual_direction,
                        "actual_step_to_nominal": actual_length/ds, "weak56_MPa": weak_and_gauge[:56],
                        "gauges4_MPa": [e*v.MODULUS for e in weak_and_gauge[56:]], "resultants_N_Nmm": actual,
                        "signed_resultant_errors_N_Nmm": sample["signed_force_N_Nmm"],
                        "residual_to_tolerance": max(sample["norm_MPa"],sample["gauge_MPa"])/tolerance,
                        "changed_concrete_sites_relative_to_preceding_candidate": changed, "maximum_steel_MPa": steel[label]})
        if reason == "Accepted":
            accepted += 1
            assert exact_fields[label] == sample["field"] and solved == "1"
            commit, replay = "Committed" + label, "Replayed" + label
            after = snapshots[commit]
            assert snapshots[replay] == after
            used.update((commit, replay))
            assert all(after[i] >= committed[i] for i in range(1080) if i%8 in (6,7))
            row["higher_station_energies_tension_compression"] = [sum(after[i] > committed[i] for i in range(offset,1080,8))
                                                                  for offset in (6,7)]
            committed = after
            old_side = stations[label]
            previous, current = current, (sample["field"], solved_factor)
            if length <= 1.5 * ds:
                nominal = min(wire[61]/32., 1.5*ds)
        else:
            discarded = "Discarded" + label
            assert snapshots[discarded] == committed and label not in exact_fields
            used.add(discarded)
            nominal = ds/2.
        progress.append(row)
    assert used == set(snapshots) and len(exact_fields) == accepted
    [[terminal, count, committed_count, last_load, next_ds, elapsed]] = tags["B_EXT_END"]
    assert int(count) == len(attempts) and int(committed_count) == accepted and float(last_load) == current[1]
    v.near(float(next_ds), nominal, 4e-19)
    assert sum(row["seconds"] for row in progress) <= float(elapsed) + .05
    if accepted == target_count:
        assert terminal == "AcceptedTarget"
    elif len(attempts) == attempt_cap:
        assert terminal == "Attempts"
    elif nominal < wire[61]/512. - 4e-19:
        assert terminal == "MinimumStep"
    elif terminal == "MinimumStep":
        assert abs(nominal - wire[61]/512.) <= 4e-19
    else:
        assert terminal == "TimeBudget" and float(elapsed) >= budget
    return {"book_sha256": prep["book_sha256"], "original_history_sha256": prep["replay_sha256"],
            "native_trace_sha256": v.digest(path), "compiler_closed": compiler, "office_closed": closed,
            "private_history_restored_H24": True, "physical_capacity_established": False,
            "accepted_points": accepted, "terminal": terminal, "last_accepted_Qy_kN": current[1],
            "native_wall_seconds": wall, "attempts": progress}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Continue"])
    args = parser.parse_args()
    frozen = prepare()
    if args.inputs_only:
        print("FROZEN_INPUTS", v.digest(HERE / "Preparation.json"))
    else:
        assert args.phase == "Continue"
        output = HERE / "VerificationContinue.json"
        output.write_bytes((json.dumps(verify(*frozen), indent=2) + "\n").encode("utf-8"))
        print(output, v.digest(output))
