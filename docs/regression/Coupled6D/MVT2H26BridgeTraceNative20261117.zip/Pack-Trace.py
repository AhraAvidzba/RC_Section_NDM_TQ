"""Собирает автономный архив штатного продолжения до первого принятого поля."""

from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from tempfile import TemporaryDirectory


HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parent / "mvbridge-proof"
NEGATIVE = HERE.parent / "mvbridge-neg-proof"
SCRATCH = Path("D:/CodexScratch/RC_Section_NDM_TQ")
CURRENT = SCRATCH / "MVTArcTrace"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MANIFEST = "D747995663A9CA6A85D4297F60A2FB0CB8760B1074DB30C3D945DE91557094E2"


def main():
    specification = spec_from_file_location("pack", PREVIOUS / "Pack.py")
    pack = module_from_spec(specification)
    specification.loader.exec_module(pack)
    pack.HERE, pack.CURRENT = HERE, CURRENT
    pack.OUT = HERE / "MVT2H26BridgeTraceNative20261117.zip"
    current = json.loads((CURRENT / "Preparation.json").read_bytes())
    evidence = {name for name in current["inputs"] if name != BOOK}
    evidence.update(("VerificationArcTrace.json", *pack.STATE, *("NativeResume/" + name for name in pack.RAW)))
    assert pack.digest(CURRENT / "Preparation.json") == MANIFEST
    with TemporaryDirectory(prefix="source-", dir=HERE) as path:
        temp = Path(path)
        from_prior = (PREVIOUS / "Verify-Portable.py").read_text(encoding="utf-8")
        prelude = from_prior[from_prior.index("HERE = "):from_prior.index("TERMINAL = ")]
        function = from_prior[from_prior.index("def prepare("):from_prior.index("def verify_sources(")]
        (temp / "ArchiveInputs.py").write_text(
            '"""Сверяет исходные файлы и нативную последовательность подготовки H26."""\n\n'
            "from pathlib import Path\nfrom ResumeBase import prior, v\nimport ResumeBase as history\n\n"
            + prelude + f'MANIFEST = "{MANIFEST}"\n\n\n' + function, encoding="utf-8", newline="\n")
        from_negative = (NEGATIVE / "Verify-Portable.py").read_text(encoding="utf-8")
        closed = from_negative[from_negative.index("def verify_run("):from_negative.index("def verify_first_and_correction(")]
        (temp / "ProcessReceipts.py").write_text(
            '"""Сверяет нативные квитанции компиляции, выполнения и закрытия Excel."""\n\n'
            "import re\nfrom ResumeBase import v\n\n\n"
            + closed, encoding="utf-8", newline="\n")

        def inputs():
            for name in sorted(evidence):
                yield CURRENT / name, name
            for entry in current["arc_sources"]["modules"]:
                name = entry["path"]
                yield HERE.parent / "mvbridge" / name, "SourceEvidence/" + name
            yield SCRATCH / "MVTArcAccept/VerificationArcApi.json", "SourceEvidence/VerificationArcApi.json"
            for name in ("ArchiveInputs.py", "ProcessReceipts.py"):
                yield temp / name, name
            for name in ("Verify-Portable.py", "Pack-Trace.py", "README-Portable.md"):
                yield HERE / name, name

        pack.locate_files = inputs
        pack.main()


if __name__ == "__main__":
    main()
