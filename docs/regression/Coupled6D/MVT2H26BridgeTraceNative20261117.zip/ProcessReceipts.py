"""Сверяет нативные квитанции компиляции, выполнения и закрытия Excel."""

import re
from ResumeBase import v


def verify_run(root, expected, prep):
    code = v.read(root / "docs/regression/CodeUpdate.json")
    compiler = v.read(root / "CompileClosure.json")
    log = (root / "Compile.log").read_text(encoding="utf-8-sig")
    owned = re.search(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", log, re.M)
    assert compiler["State"] == "Absent"
    assert (compiler["PID"], int(compiler["StartTicksUTC"])) == tuple(map(int, owned.groups()))
    assert "PRIVATE_CODE_READY: modules=6; production unchanged=True" in log
    assert code["Compiled"] is True and code["ProductionChanged"] is False
    assert code["ProductionSHA256"] == prep["book_sha256"] and sorted(code["Modules"]) == prep["arc_modules"]
    native = root / "NativeResume"
    owner = v.read(native / "MVT2.txt.Ownership.json")
    closure = v.read(native / "MVT2.txt.ProcessClosure.json")
    cleanup = v.read(native / "MVT2.txt.RunnerCleanup.json")
    receipt = v.read(native / "RunReceipt.json")
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == code["WorkbookSHA256"]
    assert closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"] == receipt["native_exit"] == expected
    assert closure["RunnerCleanupValid"] and closure["RunnerCleanup"] == cleanup
    assert cleanup["OwnerVerified"] and cleanup["QuitRequested"] and cleanup["QuitSucceeded"] and cleanup["Errors"] == []
    assert cleanup["Failed"] is bool(expected)
    assert not closure["OrdinaryPathKilledAnything"]
    final = closure["Closure"]["FinalState"]
    assert final["State"] == "Absent" and (final["PID"], final["StartTicksUTC"]) == (owner["PID"], owner["StartTicksUTC"])
    report = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert f"WATCHDOG_COMPLETED: exit={expected}; source unchanged=True" in report
    return report


