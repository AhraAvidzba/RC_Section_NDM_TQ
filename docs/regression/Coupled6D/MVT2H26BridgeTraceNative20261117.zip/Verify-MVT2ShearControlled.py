"""Сверяет одну опубликованную точку штатного управляемого продолжения H26."""

import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re

import ResumeBase as history
from ResumeBase import prior, v


HERE = Path(__file__).resolve().parent


def verify(frozen):
    prep, prefix, h24, _, witnesses, *_ = frozen
    prior.MODULES = prep["arc_modules"]
    assert prep["trace_first_accepted_point_test_only"] is True
    compiler, owner, wall = history.verified_receipts(prep)
    path = HERE / "NativeResume/MVT2.csv"
    raw = v.read_native(path)
    spec = spec_from_file_location("setup_check", HERE / "Verify-Setup.py")
    preparation_verifier = module_from_spec(spec)
    spec.loader.exec_module(preparation_verifier)
    setup = preparation_verifier.verify_setup(raw)
    snapshots = prior.by_name(raw, "B_ARC_HISTORY")
    assert snapshots["Base24"] == snapshots["Restored24"]
    assert snapshots["TraceBefore"] == snapshots["CommittedAttempt2"] == witnesses[1][67:]
    accepted_prefix = v.vec(raw, "MVT2_CONTROL_FIELD")
    for i, (field, _) in enumerate(prefix, 1):
        assert v.peak(v.diff(accepted_prefix[f"Replay{i}"], field)) < 1e-15
    replay = (HERE / "Replay.csv").read_text().splitlines()[20].split(";")
    assert [float(v) for v in replay[:3]] == [20., 1., 15.]
    assert [float(v) for v in replay[3:9]] == [0., 9e6, 0., 10510000., 0., 15000.]
    assert raw["T_DESIGN"] == [["20", "1", "1", "15"]]

    [[status, code, fields, points, *details]] = raw["T_META"]
    assert (status, code, fields, points) == ("6", "10", "27", "27")
    note = ";".join(details)
    assert "равновесие при lambda = 1 подтверждено: True" in note
    assert "; проб: 3; вспомогательных проб псевдодуги и повтора: 2" in note
    [[status, code, *details]] = raw["T_SOLVER"]
    assert (status, code) == ("4", "0")
    entry = re.search(r"итерации исходной пробы / дуги / повтора: (\d+) / (\d+) / (\d+); общий лимит: (\d+)", ";".join(details))
    stock, arc, fixed, cap = map(int, entry.groups())
    assert stock > 0 and arc >= 0 and fixed >= 0 and stock + arc + fixed <= cap == 26
    assert "Исходный отказ" in ";".join(details)

    [[_, target]] = raw["T_TARGET"]
    target = float(target)
    expected = v.read(HERE / "FixedTargetWitness.json")["target_coordinate"]
    v.near(target, expected, 3e-15)
    p = v.vec(raw, "T_PROJECTION")["Original"]
    assert p == (0., 1.) + (0.,) * 58
    [[multiplier, qy, reported, control, tolerance, steel]] = (prior.numbers(row) for row in raw["T_FINAL"])
    v.near(multiplier * 15., qy, 5e-13)
    assert abs(qy - 18.5807648298282) <= 5e-6
    assert 0. <= steel <= 1.
    label = "TraceH27"
    count, factor, *field = prior.by_name(raw, "B_TANGENT_FIELD")[label]
    assert count == "27" and float(factor) == qy
    field = prior.numbers(field)
    stations = {(int(i), int(side)): prior.numbers(values)
                for name, i, side, *values in raw["B_TANGENT_STATION"] if name == label}
    assert h24["geometry"] == {loc: data[:3] for loc, data in stations.items()}
    residual, forces, strain_error = v.reconstruct(field, qy, stations)
    signed = v.diff(forces, v.force(qy))
    scaled = tuple(error / scale for error, scale in zip(signed, v.SCALES, strict=True))
    norm = max(v.peak(residual[:56]), v.peak(v.MODULUS * value for value in residual[56:]), v.peak(scaled))
    assert strain_error < 4e-15 and v.peak(v.diff(residual, v.vec(raw, "B_TANGENT_RESIDUAL")[label])) < 3e-10
    v.near(reported, norm, 4e-10)
    v.near(control, v.MODULUS * (v.dot(p, field) - target), 3e-10)
    v.near(tolerance, 5e-7 * (1. + v.peak(v.loading(qy))), 2e-18)
    assert norm <= tolerance and abs(control) <= tolerance
    return {"trace_sha256": v.digest(path), "historical_setup": setup, "valid_design_witness": {"history_index": 20, "Qy_kN": 15},
            "published_points": 1, "solver_probes": 3, "auxiliary_probes": 2, "iterations": [stock, arc, fixed],
            "maximum_iterations": cap, "Qy_kN": qy, "lambda": multiplier, "normalized_equilibrium_MPa": norm,
            "origin_control_error_MPa": control, "signed_resultant_errors_N_Nmm": signed, "steel_utilization": steel,
            "physical_limit_established": False, "test_ended_after_first_acceptance": True, "H24_exact_restore": True,
            "compiler_closed": compiler["State"] == "Absent", "owner_pid": owner["PID"], "wall_seconds": wall}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Resume"])
    request = parser.parse_args()
    prep = history.prepare()
    if request.inputs_only:
        print("FROZEN TRACE INPUTS", v.digest(HERE / "Preparation.json"))
    else:
        assert request.phase == "Resume"
        output = HERE / "VerificationArcTrace.json"
        output.write_text(json.dumps(verify(prep), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("TRACE VERIFIED", v.digest(output))
