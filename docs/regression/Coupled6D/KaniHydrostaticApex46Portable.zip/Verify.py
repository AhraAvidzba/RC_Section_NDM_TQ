"""Verify the apparent hydrostatic apex and the line of force row 81."""
from pathlib import Path
from hashlib import sha256
import csv,json,runpy
import numpy as np

from argparse import ArgumentParser
from io import BytesIO
from zipfile import ZipFile

H=Path(__file__).resolve().parent
arg=ArgumentParser(); arg.add_argument("archive308",type=Path); arg.add_argument("archive313",type=Path); arg.add_argument("--output",type=Path)
a=arg.parse_args()
receipt=json.loads((H/'SourceReceipts.json').read_text(encoding='utf8'))
digest=lambda path: sha256(path.read_bytes()).hexdigest().upper()
assert digest(a.archive308)==receipt['article308_archive_sha256']
assert digest(a.archive313)==receipt['article313_archive_sha256']
assert digest(H/'KaniV4Input.csv')==receipt['replay37_sha256']
with ZipFile(a.archive308) as u, ZipFile(a.archive313) as v:
    proof=json.loads(v.read('RankOneNativeVerification.json'))
    r2=v.read('RankOneNativeVerification.json'); assert sha256(r2).hexdigest().upper()==receipt['article313_native_verification_sha256']
    D=dict(np.load(BytesIO(v.read('MeasuredSamples.npz')),allow_pickle=False)); ids={n:i for i,n in enumerate(D['names'])}
    ref=dict(np.load(BytesIO(u.read('MeasuredSamples.npz')),allow_pickle=False)); refids={n:i for i,n in enumerate(ref['names'])}
    branch_table=v.read('KaniV4Tangents.csv').decode('cp1251').splitlines()
    history_input=v.read('KaniGaugeInput.csv').decode('ascii').splitlines()
    trace_table=v.read('KaniV4Trace.csv').decode('cp1251').splitlines()
    ops=u.read('Verify.py').decode('utf8').replace(chr(13)+chr(10),chr(10))
assert np.array_equal(D['geometry'],ref['geometry']) and D['length']==ref['length']
for label in ('BaseAccepted','LoadShape00Plus','LoadShape00Minus'):
    assert np.array_equal(D['fields'][ids[label]],ref['fields'][refids[label]])
    assert np.max(abs(D['stations'][D['station_index'][ids[label]]]-ref['stations'][ref['station_index'][refids[label]]]))<2e-10
from BuildOperators import operators
assert ops[ops.index('def operators('):ops.index('ROOT=')].rstrip() in (H/'BuildOperators.py').read_text(encoding='utf8')
pts=np.loadtxt(H/'GeometryAndDirections.csv',delimiter=';')
assert np.array_equal(pts[:,:3],D['geometry']) and digest(H/'GeometryAndDirections.csv')==receipt['geometry_and_directions_sha256']
assert np.all(pts[144:152,5]==1.) and np.all(pts[152:,5]==0.)
assert np.allclose(pts[152:,3],np.isclose(abs(pts[152:,1]),275.))
assert np.allclose(pts[152:,4],np.isclose(abs(pts[152:,0]),122.5))
length=float(D['length']); basis,*_=operators(D['geometry'],length)
def shape(q):
    e0=basis@q[:79]; step=basis[:,:,:4]@q[79:83]
    return np.array([e0+i*.001*step for i in (-1,0,1)])
pk=lambda x:float(np.max(abs(x)))
labels=('BaseAccepted','LoadShape00Plus','LoadShape00Minus')
B={tag:np.full((3,184,3),-1) for tag in labels}
for name,tag,pt,side,*rest in csv.reader(branch_table,delimiter=';'):
    if name=='BRANCH' and tag in B: B[tag][int(side)+1,int(pt)-1]=list(map(int,rest))
assert all((v>=0).all() for v in B.values())
mask=(B[labels[1]][:,:,0]==1)&(B[labels[2]][:,:,0]==1)
assert mask.sum()==59 and mask[:,:144].sum()==8
b0,bp,bm=[np.array(proof['trialYield_MPa_byStation_SidesMinusCenterPlus'][l]) for l in labels]

# Replay exactly the accepted steel path for each spatial station.
# Tests initialize a perfectly plastic law with limits ±442 MPa longitudinally, ±400 MPa transversely.
A=np.zeros((40,6)); A[:,:4]=pts[144:,3:]; assert np.allclose(A[:,0]+A[:,1]+A[:,2],1.)
yields=np.r_[np.full(8,442.),np.full(32,400.)]
fields=[]
for row in (H/'KaniV4Input.csv').read_text(encoding='ascii').splitlines()[1:]:
    kind,i,gamma,factor,*q=row.split(';'); assert kind=='FIELD' and int(i)==len(fields)+1
    fields.append(np.array(q,float))
for row in history_input:
    _,label,_,_,*q,mult=row.split(';')
    if label.startswith('History') or label=='Accepted19of512': fields.append(np.array(q,float))
assert len(fields)==44
elastic=np.zeros((3,40)); steel_max=0.
def axial(e): return np.einsum('sij,ij->si',e[:,144:,:],A)
def steel(e):
    trial=2e5*(axial(e)-elastic)
    return np.minimum(np.maximum(trial,-yields),yields)
for q in fields:
    e=shape(q); s=steel(e); elastic=axial(e)-s/2e5; steel_max=max(steel_max,pk(s))
for tag in (labels[0],):
    zz=D['stations'][D['station_index'][ids[tag]],:,:,:6]; hoop=steel(zz)[1,8:]; closest=np.argmax(abs(axial(zz)[1,8:]));
    records={p[1]:p for p in csv.reader(trace_table,delimiter=';') if p[0]=='CHECK'}
    assert abs(float(records[tag][-2])-hoop[closest])<1e-8

def apparent(tag):
    row=D['stations'][D['station_index'][ids[tag]]]; work=row[:,:,6:].copy()
    work[:,144:,:]=steel(row[:,:,:6])[:,:,None]*A[None,:,:]-work[:,144:,:]
    return work

def eigen(st):
    x,y,z,xy,xz,yz=np.moveaxis(st,-1,0)
    return np.linalg.eigvalsh(np.stack([x,xy,xz,xy,y,yz,xz,yz,z],axis=-1).reshape(st.shape[:-1]+(3,3)))

ap=[apparent(k) for k in labels]; stress=np.array(ap); eig=np.array([eigen(x) for x in stress]); p=eig[0]; q=np.sqrt(1.5*np.sum((p-p.mean(axis=-1)[:,:,None])**2,axis=-1))
even=stress[1]+stress[2]-2*stress[0]; norms=np.max(abs(even),axis=2)
net_raw=np.array([D['stations'][D['station_index'][ids[k]],:,:,6:] for k in labels]); net=net_raw[1]+net_raw[2]-2*net_raw[0]
rowweights=np.array([-1,0,1])[:,None]*(pts[:,2]*pts[:,1]/(305.*610.*length*.002))[None,:]
signed=rowweights*net[:,:,2]; t=np.unravel_index(int(np.argmax(abs(signed*mask))),shape=signed.shape); t_all=np.unravel_index(int(np.argmax(abs(signed))),shape=signed.shape)

def bounds(z): return [float(z.min()),float(np.median(z)),float(z.max())]
def loc(i): return [int(i[0]-1),int(i[1]+1)]
res={'acceptedAndProbeConcreteStressDecomposed':True,'elasticReplayVerifiedAgainstCriticalHoop':True,'maximumReplayedSteelStress_MPa':steel_max,
     'bothPlastic':int(mask.sum()),'direct':int(mask[:,:144].sum()),'concreteMeanAccepted_MPa':bounds(p.mean(axis=-1)[mask]),
     'baseQInvariant_MPa':bounds(q[mask]),'baseEigenSpan_MPa':bounds(np.ptp(p,axis=-1)[mask]),
     'baseTopDegeneracy_MPa':bounds((p[:,:,2]-p[:,:,1])[mask]),'allDirectQRange_MPa':bounds(q[:,:144][mask[:,:144]]),
     'concreteEvenStressMax_MPa':bounds(norms[mask]),'trialF0_MPa':bounds(b0[mask]),'trialFPlus_MPa':bounds(bp[mask]),'trialFMinus_MPa':bounds(bm[mask]),
     'trialFEven_MPa':bounds((bp+bm-2*b0)[mask]), 'row81TotalEven_MPa':float(signed.sum()),'row81EvenBothPlastic_MPa':float(signed[mask].sum()),
     'row81DirectOnlyOfBothPlastic_MPa':float(signed[:,:144][mask[:,:144]].sum()),'row81DisplacedConcreteOfBothPlastic_MPa':float(signed[:,144:][mask[:,144:]].sum()),
     'largestWeightedStationInBothPlastic':{'sidePoint':loc(t),'coefficient':float(rowweights[t]),'actedNominalEvenZZ_MPa':float(even[t][2]),
                     'actedNetEvenZZ_MPa':float(net[t][2]),'weightedRow81_MPa':float(signed[t])},
     'largestWeightedStationAll':{'sidePoint':loc(t_all),'coefficient':float(rowweights[t_all]),'weightedRow81_MPa':float(signed[t_all])}}
assert res['baseQInvariant_MPa'][-1]<2e-10
# At the hydrostatic limit, the trace derivative is linear and both q and the largest
# eigenvalue are taken from the signed elastic stress increment. Fit beta in only
# the stronger of the two eigenvalue directions and predict the other archived sign.
alpha=0.12; E=25600.; nu=.2; mu=E/(2*(1+nu)); lame=2*mu*nu/(1-2*nu)
C=np.diag([2*mu]*3+[mu]*3); C[:3,:3]+=lame
strain=np.array([D['stations'][D['station_index'][ids[l]],:,:,:6] for l in labels]); ds=(strain[1:]-strain[0])@C
plus,minus=[eigen(x)[mask] for x in ds]; sign_eigs=np.stack((plus,minus))
tr=sign_eigs.sum(axis=2); dep=sign_eigs-tr[:,:,None]/3.
qinc=np.sqrt(1.5*np.sum(dep**2,axis=2)); xmax=sign_eigs[:,:,2]
xy=np.r_[np.array([bp[mask]-b0[mask],bm[mask]-b0[mask]])]
s0=np.argmax(abs(xmax),axis=0); s1=1-s0; idx=np.arange(len(s0))
beta=((1-alpha)*xy-alpha*tr-qinc)[s0,idx]/xmax[s0,idx]
pred=(alpha*tr+qinc+beta*xmax)/(1-alpha); e=(pred-xy)[s1,idx]
res['apexPredictorAtWithheldOppositeSign']={'alpha':alpha,'freshFitBetaRange':bounds(beta),'withheldErrorAbs_MPa':bounds(abs(e)),
    'maxRawWithheldAction_MPa':pk(xy[s1,idx]), 'fractionMaximumError':pk(e)/pk(xy[s1,idx]),
    'comparison':'Fit only one sign per station, using the larger absolute directional upper eigenvalue. Compare other sign at h=1e-10.'}
expected=json.loads((H/'HydrostaticApexDecomposition.json').read_text(encoding='utf8'))
def compare(now,previous):
    if isinstance(now,dict):
        assert now.keys()==previous.keys()
        for key in now: compare(now[key],previous[key])
    elif isinstance(now,list):
        for first,second in zip(now,previous,strict=True): compare(first,second)
    elif isinstance(now,float): assert abs(now-previous)<=max(1e-13,3e-5*abs(previous)),(now,previous)
    else: assert now==previous
compare(res,expected)
if a.output: a.output.write_text(json.dumps(res,indent=2)+'\n',encoding='utf8')
print(json.dumps(res,indent=2))
