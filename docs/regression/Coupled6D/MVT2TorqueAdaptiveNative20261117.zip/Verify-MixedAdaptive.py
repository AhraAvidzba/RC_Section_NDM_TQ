"""Rebuild the local Q path following the independently certified refined torsion prefix."""

from argparse import ArgumentParser
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
SIGNED_SHA = "F33926B1BC77BCD2E736DC39520CF66DCCA98CF630A51110D7C293FFE1861C25"
PURE_OK = "1D883B569DE600B97F9C717E45546CB2B92E1F3892CA6FE52114FAC013797E89"
TORQUE = 10.51
SORTED_Q = [5., 6.25, 7.5, 8.75, 10., 11.25, 11.5625] + [11.5625 + .3125*i for i in range(1, 12)]


def digest(data):
    return sha256(data).hexdigest().upper()


def full_data(archive, hash_value, record):
    assert digest(archive.read_bytes()) == hash_value
    with ZipFile(archive) as source:
        return json.loads(source.read(record))


def checked_force(record, q):
    values = list(record)
    assert len(values) == 6
    expected = (0., -.330*q, 0., TORQUE, 0., q)
    errors = [a-b for a, b in zip(values, expected, strict=True)]
    assert all(abs(a) < limit for a, limit in zip(errors, (.00015,.00010,.00010,.00010,.00015,.00015), strict=True))
    return errors


def verify(root, pure, pure_wire, signed):
    raw_pure = pure.read_bytes()
    prefix = json.loads(raw_pure)
    assert digest(raw_pure) == PURE_OK and prefix["exact_10_51"]
    assert digest(pure_wire.read_bytes()) == prefix["trace_sha256"]
    external = full_data(signed, SIGNED_SHA, "VerifiedFine15.json")["comparison"][7:]
    assert [item["Qy_kN"] for item in external] == SORTED_Q
    spec = spec_from_file_location("native_grid", HERE / "Verify-Grid.py")
    guard = module_from_spec(spec)
    spec.loader.exec_module(guard)
    mode = "AdaptiveMixed10"
    guard.verify_root(root, [(mode, "TOTAL_MVT2_ADAPTIVE: passed=1; failed=0;")])
    rows, trace_sha = guard.read_wire(root / f"Native/Right{mode}.csv")
    before, _ = guard.read_wire(pure_wire)
    assert rows[:len(before)] == before
    rows = rows[len(before):]
    outcomes, extra, terminal = [], [], None
    previous = 0.
    for stage, q in enumerate(SORTED_Q, 1):
        phase = f"S{stage}"
        if rows[0][0] == "MVT2_CUT_DIRECT_STOP":
            stop, *rows = rows
            assert stop[1] == phase
            while rows[0][0] == "MVT2_CUT_INSERTED":
                raw, *rows = rows
                assert raw[1] == phase
                intermediate, norm, *forces = list(map(float, raw[2:]))
                value = intermediate / 1000
                assert previous < value < q and 0 <= norm <= 5e-6
                checked_force((v / (1000 if i in (0, 4, 5) else 1e6) for i, v in enumerate(forces)), value)
                previous = value
                extra.append({"stage": stage, "Qy_kN": value, "normalized_force_error_MPa": norm})
        trial, *rows = rows
        assert trial[:2] == ["MVT2_CUT_TRIAL", phase]
        target = list(map(float, trial[2:5]))
        assert target == [TORQUE * 1e6, q * 1000, -330 * q * 1000]
        if trial[5:8] == ["False", "6", "10"]:
            terminal = {"requested_Qy_kN": q, "last_accepted_Qy_kN": previous, "details": ";".join(trial[8:])}
            break
        assert trial[5:8] == ["True", "4", "0"]
        state, *rows = rows
        assert state[:2] == ["MVT2_STATE", phase] and list(map(float, state[2:4])) == [q,q]
        vals = list(map(float, state[4:]))
        assert len(vals) == 20 and 0. <= vals[-1] <= 5e-6
        errors = checked_force(vals[:6], q)
        reference = external[stage-1]
        outcomes.append({"Qy_kN": q, "Mx_kNm": -.330*q, "T_kNm": TORQUE,
                         "component_errors_kN_kNm": errors, "force_norm_MPa": vals[-1],
                         "NDM_refined_center_twist_rad_per_m": vals[9],
                         "NDM_original_center_twist_rad_per_m": reference["NDM_twist_by_arm_rad_per_m"]["330"],
                         "OpenSees_right_window_twist_rad_per_m": reference["OpenSees_right_window_rad_per_m"]})
        previous = q
    assert not rows and (terminal is not None or len(outcomes) == len(SORTED_Q))
    return {"status": "PASS", "trace_sha256": trace_sha, "pure_torsion_prefix_checked_bytewise": True,
            "applied_Q_targets": SORTED_Q, "states": outcomes, "accepted_substeps": extra, "terminal": terminal,
            "exact_Q15": terminal is None, "physical_limit_established": False}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--pure", type=Path, required=True)
    parser.add_argument("--pure-wire", type=Path, required=True)
    parser.add_argument("--signed", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    proof = verify(args.root, args.pure, args.pure_wire, args.signed)
    data = (json.dumps(proof, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()
    with args.out.open("xb") as out:
        out.write(data)
    print("MVT2 REFINED MIXED PROOF PASS", len(proof["states"]), digest(data))
