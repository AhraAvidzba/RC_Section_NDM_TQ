"""Rebuild the exact-target torsion test with the workbench's standard continuation."""

from argparse import ArgumentParser
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
GRID_SHA = "4940EEBF2C1B0BB5C5133C8A0EDBABFF845F1655BD19F4E96A554569E082D8C4"
SIGNED_SHA = "F33926B1BC77BCD2E736DC39520CF66DCCA98CF630A51110D7C293FFE1861C25"


def import_grid_checker():
    spec = spec_from_file_location("grid", HERE / "Verify-Grid.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_report(archive, checksum, file):
    assert sha256(archive.read_bytes()).hexdigest().upper() == checksum
    with ZipFile(archive) as data:
        return json.loads(data.read(file))


def verify_timeout(root, mode, guard):
    path = f"Native/Right{mode}.txt"
    receipt = guard.read(root, path + ".ProcessClosure.json")
    owner = guard.read(root, path + ".Ownership.json")
    compiled = guard.read(root, "docs/regression/CodeUpdate.json")
    assert receipt["Stage"] == "TIMEOUT" and not receipt["Passed"]
    assert receipt["Identity"]["Valid"] and receipt["ExactOwnExcelStopRequestedOnlyByExplicitTimeout"]
    assert receipt["After"]["State"] == "Absent" and receipt["Before"]["State"] == "Live"
    exact = owner["PID"], owner["StartTicksUTC"]
    assert owner["VerifiedNewOwner"] and owner["SourceSHA256"] == compiled["WorkbookSHA256"]
    assert all((receipt[key]["PID"], receipt[key]["StartTicksUTC"]) == exact for key in ("Before", "After"))
    return exact


def verify(root, grid, signed, points, timed_out=False):
    guard = import_grid_checker()
    prior = load_report(grid, GRID_SHA, "VerifiedGrid.json")["nonlinear"][str(points)]
    benchmark = load_report(signed, SIGNED_SHA, "VerifiedFine15.json")["comparison"]
    mode = f"Adaptive{points}"
    marker = "TOTAL_MVT2_ADAPTIVE: passed=1; failed=0;"
    guard.verify_root(root, [] if timed_out else [(mode, marker)])
    log = (root / f"Native/Right{mode}.txt").read_text(encoding="utf-8-sig")
    planned = guard.T_STEPS
    rows, trace_sha = guard.read_wire(root / f"Native/Right{mode}.csv")
    setup, *rows = rows
    assert setup[:2] == ["MVT2_ADAPT_SETUP", str(points)]
    predicted = (34.02777777777778, 2.10667357864589, .13773772513881968, 15.85847463852011)
    assert all(abs(float(a)-b) < 1e-12 for a, b in zip(setup[2:], predicted, strict=True))
    prior_torque, position, terminal = 0., 0, None
    outcomes = []
    for stage, request in enumerate(planned, 1):
        if not rows and timed_out:
            break
        trial, *rows = rows
        assert trial[:2] == ["MVT2_ADAPT_TRIAL", f"R{stage}"] and abs(float(trial[2])-request) < 1e-13
        reached = float(trial[3])
        succeeded = trial[4] == "True"
        assert trial[4] in ("True", "False") and 0. < reached <= request + 1e-13
        assert trial[5:7] == (["4", "0"] if succeeded else ["6", "10"])
        times = re.search(r"проб: (\d+)", ";".join(trial[7:]))
        assert times and int(times[1]) <= 44
        accepted = []
        while rows and rows[0][0] == "MVT2_ADAPT_HISTORY":
            item, *rows = rows
            position += 1
            assert item[:3] == ["MVT2_ADAPT_HISTORY", trial[1], str(position)]
            torque = float(item[3])
            assert prior_torque < torque <= request + 1e-13
            prior_torque = torque
            accepted.append(torque)
        assert prior_torque == reached
        state, *rows = rows
        assert state[:2] == ["MVT2_STATE", trial[1]]
        assert list(map(float, state[2:4])) == [float(trial[2]), reached]
        vals = list(map(float, state[4:]))
        assert len(vals) == 20 and 0 <= vals[-1] <= 5e-6
        expected = (0., 0., 0., reached, 0., 0.)
        assert max(abs(a-b) for a, b in zip(vals[:6], expected, strict=True)) < 1.5e-4
        if stage <= len(prior["states"]):
            reference = prior["states"][stage-1]
            assert succeeded and len(accepted) == 1 and abs(reference["torque_kNm"]-reached) < 1e-13
            assert abs(reference["twist_rad_per_m"]-vals[9]) < 2e-12
        outcome = {"requested_T_kNm": request, "accepted_T_kNm": reached, "exact": succeeded,
                   "attempts": int(times[1]), "accepted_subtargets_T_kNm": accepted, "wrench_kN_kNm": vals[:6],
                   "twist_rad_per_m": vals[9], "max_tensile_damage": vals[15], "force_norm_MPa": vals[-1]}
        if not succeeded:
            terminal = ";".join(trial[7:])
        outcomes.append(outcome)
        if not succeeded:
            break
    assert not rows and outcomes
    last = outcomes[-1]
    closure = {}
    if timed_out:
        assert "WATCHDOG_FAILURE: timeout=280 sec;" in log and marker not in log
        assert len(outcomes) == 6 and terminal is None
        pid, start_ticks = verify_timeout(root, mode, guard)
        terminal = "The owned Excel instance expired at the 280 s watchdog without a logged terminal solve."
        closure = {"timeout_seconds": 280, "expired_owned_excel_pid": pid, "start_ticks": start_ticks}
    else:
        assert len(outcomes) == 7 or terminal is not None
        assert f"{marker} exact_target={last['exact'] and len(outcomes)==7}" in log
    qualifies = last["exact"] and len(outcomes) == 7 and last["accepted_T_kNm"] == 10.51
    reference = benchmark[6]
    comparison = None if not qualifies else {
        "T_kNm": 10.51, "NDM_original_25_twist": reference["NDM_twist_by_arm_rad_per_m"]["330"],
        "OpenSees_right_twist": reference["OpenSees_right_window_rad_per_m"],
        "NDM_refined_twist": last["twist_rad_per_m"],
        "NDM_to_OpenSees_twist_ratio": last["twist_rad_per_m"] / reference["OpenSees_right_window_rad_per_m"],
    }
    return {"status": "PASS", "trace_sha256": trace_sha, "concrete_points": points**2,
            "exact_10_51": qualifies, "outcomes": outcomes, "total_material_states_accepted": position,
            "terminal_stop": terminal, "comparison_10_51": comparison, "physical_limit_established": False, **closure}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=HERE)
    parser.add_argument("--grid", type=Path, required=True)
    parser.add_argument("--signed", type=Path, required=True)
    parser.add_argument("--points", type=int, choices=(10, 20), required=True)
    parser.add_argument("--timed-out", action="store_true")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    proof = verify(args.root, args.grid, args.signed, args.points, args.timed_out)
    data = (json.dumps(proof, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()
    with args.out.open("xb") as writer:
        writer.write(data)
    print("MVT2 ADAPTIVE TORSION PROOF PASS", proof["outcomes"][-1]["accepted_T_kNm"], sha256(data).hexdigest().upper())
