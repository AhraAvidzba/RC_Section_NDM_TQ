"""Package native torque histories with their frozen code and process receipts."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


HERE = Path(__file__).resolve().parent
CASES = Path("D:/CodexScratch/RC_Section_NDM_TQ")
LABELS = {"10": "MVT2TorqueAdaptive", "20": "MVT2TorqueAdaptiveFine", "mixed": "MVT2MixedAdaptive10"}


def contents(tags):
    for name in ("Verify-Adaptive.py", "Verify-MixedAdaptive.py", "Verify-Grid.py", "PackAdaptive.py"):
        yield name, (HERE / name).read_bytes()
    for tag in tags:
        root = CASES / LABELS[tag]
        prep = json.loads((root / "Preparation.json").read_bytes())
        files = ({name for name in prep["inputs"] if not name.endswith(".xlsm")} |
                 {"Preparation.json", "CompileClosure.json", "Compile.log", "docs/regression/CodeUpdate.json"} |
                 {f"Native/{path.name}" for path in (root / "Native").iterdir() if path.is_file()})
        for name in sorted(files):
            data = (root / name).read_bytes()
            if name in prep["inputs"]:
                assert sha256(data).hexdigest().upper() == prep["inputs"][name]
            yield f"Case{tag}/{name}", data
        proof = HERE / (f"Adaptive{tag}.json" if tag != "mixed" else "AdaptiveMixed10.json")
        yield f"Case{tag}/Verification.json", proof.read_bytes()


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    parser.add_argument("tags", nargs="+", choices=tuple(LABELS))
    args = parser.parse_args()
    with ZipFile(args.destination, "x", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in contents(args.tags):
            archive.writestr(ZipInfo(name), raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    print(args.destination.name, sha256(args.destination.read_bytes()).hexdigest().upper())
