# Компилирует и выполняет пробу псевдодуги в отдельной книге.
param([switch]$Preflight)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$repo = (Resolve-Path -LiteralPath (Join-Path $root '../..')).Path
$book = 'workbook/output/RC_Section_NDM.xlsm'
$draft = 'docs/regression/Diagnostic.xlsm'
$report = 'Native/Arc.txt'
$oldTemp = $env:TEMP
$oldTmp = $env:TMP
$legacy = Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
Push-Location -LiteralPath $root
try {
    & python -B -X utf8 'Prepare.py' --check
    if ($LASTEXITCODE) { throw 'Исходники пробы не совпали.' }
    $frozen = Get-Content -LiteralPath 'Fixture.json' -Encoding UTF8 -Raw | ConvertFrom-Json
    if ((Get-FileHash -LiteralPath (Join-Path $repo $book)).Hash -cne $frozen.workbook_sha256) {
        throw 'Изменилась установленная книга.'
    }
    if ($Preflight) { return }
    if (Test-Path -LiteralPath $report) { throw 'Предыдущий протокол сохраняется.' }
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP = (Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP = $env:TEMP
    if ((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210) {
        throw 'Путь пробной книги слишком длинный для Excel.'
    }
    if (!(Test-Path -LiteralPath 'docs/regression/CodeUpdate.json')) {
        if ((Test-Path -LiteralPath 'Compile.log') -or (Get-FileHash -LiteralPath $draft).Hash -cne $frozen.workbook_sha256) {
            throw 'Найдена непроверенная компиляция частной книги.'
        }
        Assert-IsolatedOfficeReady 'BeforeArcCompile'
        & './tools/build_workbook/Update-PrivateWorkbookCode.ps1' -WorkbookPath $draft `
            -ModuleNames @('CCoupledNewtonSolver','modTestCoupledElasticState') | Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $compiled = Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure = Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or $closure.State -cne 'Absent' -or
        (($compiled.Modules | Sort-Object) -join ',') -cne 'CCoupledNewtonSolver,modTestCoupledElasticState' -or
        $compiled.ProductionSHA256 -cne $frozen.workbook_sha256 -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash) { throw 'Компиляция не подтверждена.' }
    Assert-IsolatedOfficeReady 'BeforeArcNative'
    & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-Audit03Watchdog.ps1' `
        -SourceWorkbook $draft -ReportPath $report -Macro 'modTestCoupledElasticState.RunTestCoupledPseudoArc' `
        -Mode No -TimeoutSeconds 90 -FailFast
    if ($LASTEXITCODE) { throw 'Нативная проба псевдодуги завершилась ошибкой.' }
    & python -B -X utf8 'Verify.py'
    if ($LASTEXITCODE) { throw 'Независимая проверка пробных полей не пройдена.' }
} finally {
    $env:TEMP = $oldTemp
    $env:TMP = $oldTmp
    Pop-Location
}
