"""Verify the pinned native pseudo-arclength import and repeat the numerical audit."""

import json
from pathlib import Path
import re

import Prepare
import Verify


HERE = Path(__file__).resolve().parent


def main():
    files = json.loads((HERE / "Archive.json").read_bytes())
    assert all(Prepare.digest(HERE / path) == checksum for path, checksum in files.items())
    fixture = Verify.load("Fixture.json")
    for path in ("ArcMethod.txt", "ArcTest.txt", "Run.ps1", "Prepare.py", "Verify.py",
                 "src/Solver/CCoupledNewtonSolver.cls", "tests/modTestCoupledElasticState.bas"):
        assert fixture["frozen"][path] == files[path]
    code = Verify.load("CodeUpdate.json")
    assert code["Compiled"] and not code["ProductionChanged"]
    assert code["ProductionSHA256"] == fixture["workbook_sha256"]
    assert sorted(code["Modules"]) == ["CCoupledNewtonSolver", "modTestCoupledElasticState"]
    closed = Verify.load("CompileClosure.json")
    build = (HERE / "Compile.log").read_text(encoding="utf-8-sig")
    assert re.findall(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", build, re.M) == [
        (str(closed["PID"]), closed["StartTicksUTC"])] and closed["State"] == "Absent"
    run = Verify.load("Native/Arc.txt.Ownership.json")
    assert run["VerifiedNewOwner"] and run["BeforeWorkbookOpen"]
    assert run["SourceSHA256"] == code["WorkbookSHA256"]
    assert int(run["PID"]) != int(closed["PID"])
    Verify.main()


if __name__ == "__main__":
    main()
