"""Check original force equilibrium and branch progression from native Excel records."""

from hashlib import sha256
import json
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent


def load(path):
    return json.loads((HERE / path).read_text(encoding="utf-8-sig"))


def analytic_multiplier(strain):
    return (30_000. * strain - 1.e10 * strain ** 3 - 4.) / 20.


def main():
    native = HERE / "Native/Arc.txt"
    trace = native.read_text(encoding="utf-8-sig")
    close = load("Native/Arc.txt.ProcessClosure.json")
    owner = close["Closure"]["FinalState"]
    assert close["Passed"] and owner["State"] == "Absent" and close["ChildExitCode"] == 0
    assert re.findall(r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$", trace, re.M) == [
        (str(owner["PID"]), owner["StartTicksUTC"])
    ]
    assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in trace
    assert "TOTAL_COUPLED_PSEUDO_ARC: passed=29; failed=0" in trace
    chosen = [row.split(";") for row in trace.splitlines() if row.startswith("ARC_")]
    seed, force, *fields = chosen
    assert seed[0] == "ARC_SEED" and force[0] == "ARC_FORCE" and len(fields) == 5
    previous, low, current, high = map(float, seed[1:])
    assert previous < current < .001 and low < high < .8
    assert abs(analytic_multiplier(previous) - low) < 2.e-8
    assert abs(analytic_multiplier(current) - high) < 2.e-8
    baseline_factor, baseline_strain = map(float, force[1:])
    assert abs(analytic_multiplier(baseline_strain) - baseline_factor) < 2.e-8
    assert baseline_strain < current
    samples = []
    for idx, row in enumerate(fields, 1):
        assert row[:2] == ["ARC_FIELD", str(idx)]
        strain, factor, norm, plane, axial, torque = map(float, row[2:])
        assert strain > current and norm < 1.e-7 and abs(plane) < 1.e-10
        assert abs(analytic_multiplier(strain) - factor) < 2.e-8
        assert abs(axial / 21_600. - (4. + 20. * factor)) < 1.e-7
        assert abs(torque - (30_000. + 200_000. * factor)) < 1.e-3
        samples.append({"strain": strain, "lambda": factor, "resultant_residual_MPa": norm,
                        "plane_residual_strain": plane})
        current = strain
    assert samples[-1]["strain"] > .0011 and samples[-1]["lambda"] < samples[0]["lambda"] < .8
    report = {"native_report_sha256": sha256(native.read_bytes()).hexdigest().upper(),
              "original_analytical_limit_lambda": .8, "fixed_force_ascending_strain": baseline_strain,
              "native_arc_samples": samples}
    out = HERE / "Replay.json"
    out.write_bytes((json.dumps(report, indent=2) + "\n").encode())
    print("NATIVE PSEUDO ARC PASS", sha256(out.read_bytes()).hexdigest().upper())


if __name__ == "__main__":
    main()
