"""ДЛЯ ТЕСТОВ. Проверяет фактический VBA и четыре последовательных строгих равновесия с материальной историей."""

from argparse import ArgumentParser
from contextlib import redirect_stdout
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory


def TestFiles(root):
    """Проверяет точные входы и исходную контрольную точку, не подменяя архив рабочей папкой."""
    for name, expected in json.loads((root / 'Files.json').read_bytes()).items():
        assert sha256((root / name).read_bytes()).hexdigest().upper() == expected, name
    assert json.loads((root / 'SourceCheckpoint.json').read_bytes())['base'] == 'aea6c23'


def TestNative(repo, root, output):
    """Сверяет все компоненты и закрытие только собственного Excel; физический предел остаётся открытым."""
    TestFiles(root)
    folder = root / 'Cases/Sequence'
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        proof = Path(temporary) / 'Code.json'
        run_path(str(root / 'Audit-TestPrivateCoupledBook.py'))['TestAudit'](repo, folder, proof)
        record = json.loads(proof.read_bytes())
    assert (record['components'], record['imported'], record['unchanged']) == (244, 31, 213)
    assert len(record['checked_coupled_sources']) == 33 and record['compiled_project_storage'] == 'solid-exact-CFB'
    path = folder / 'Native/ReversePolish.txt'
    log = path.read_text('utf-8-sig')
    assert 'RUNTIME ERROR:' not in log and 'WATCHDOG_COMPLETED: exit=0; source unchanged=True' in log
    assert 'TOTAL_REVERSE_POLISH_STUDY_TEST: passed=1; failed=0; numerical_outcomes_recorded_not_asserted; capacity_certified=False' in log
    source, = re.findall(r'^SOURCE_SHA256: ([A-F0-9]+)$', log, re.M)
    assert source == record['compiled_workbook_sha256']
    closure = json.loads(path.with_name(path.name + '.ProcessClosure.json').read_bytes())
    assert closure['Passed'] and closure['ChildHasExited'] and closure['ChildExitCode'] == 0
    assert closure['Closure']['FinalState']['State'] == 'Absent' and not closure['OrdinaryPathKilledAnything']
    output.write_text(json.dumps({'project': record, 'native_setup_passed': True, 'owned_excel_absent': True,
        'working_runtime_changed': False, 'physical_capacity_certified': False, 'full_acceptance_completed': False},
        indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('ACTUAL SEQUENTIAL YIELD VBA PROJECT AND OWNED EXCEL CLOSURE VERIFIED; CAPACITY OPEN')


def TestMechanics(repo, root, output):
    """Требует фактически найденные четыре строгих шага, их исходные уравнения и последовательную историю."""
    TestFiles(root)
    with TemporaryDirectory() as temporary, redirect_stdout(StringIO()):
        proof = Path(temporary) / 'Analysis.json'
        run_path(str(root / 'Analyze-TestYieldSequence.py'))['TestAnalyze'](root / 'Cases/Sequence', proof)
        result = json.loads(proof.read_bytes())
    assert result['accepted_steps'] == result['attempted_steps'] == 4 and result['full_requested_sequence_completed']
    assert result['accepted_revision_increments_verified'] and result['independent_sequence_equations']
    assert all(item['strict_root_found'] and item['final_residual_max_MPa'] <= 1e-10 for item in result['cases'].values())
    assert all(after > before for before, after in zip(result['lambda_sequence'], result['lambda_sequence'][1:]))
    output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
    print('FOUR SEQUENTIAL STRICT COUPLED EQUILIBRIA MATERIAL HISTORY AND ALL EQUATIONS VERIFIED; CAPACITY OPEN')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
