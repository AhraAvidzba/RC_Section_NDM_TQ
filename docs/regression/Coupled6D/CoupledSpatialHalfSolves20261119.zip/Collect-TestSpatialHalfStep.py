"""ДЛЯ ТЕСТОВ. Сохраняет раздельно чувствительность фиксированных полей и новые частные решения."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestCollect(repo, root, scope):
    """Закрепляет реальные CFB, исходники, закрытие Office и происхождение 25 исходных полей."""
    here = Path(__file__).resolve().parent
    collect = run_path(str(here / 'Collect-TestFieldRecovery.py'))['TestCollect']
    cases = {'Coarse4': 'HardHalfStepStudy20261118', 'Refinement8': 'HardHalfRefinement20261118',
        'Limit13': 'HardHalfLimit20261118'} if scope == 'fixed' else {
        'H128': 'HardSpatialH12820261118', 'H128FineTangent': 'HardFineTangent20261119'}
    collect.__globals__['TestCases'] = cases
    collect(repo, root)
    for folder in (root / 'Cases').iterdir():
        sources = {}
        for file in sorted((repo / 'src').rglob('*')):
            if file.suffix not in ('.bas', '.cls') or 'coupled' not in file.stem.lower():
                continue
            relative = file.relative_to(repo)
            destination = folder / relative
            if not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(file.read_bytes())
            sources[relative.as_posix()] = sha256(destination.read_bytes()).hexdigest().upper()
        assert len(sources) == 30
        (folder / 'AllCoupledSources.json').write_text(json.dumps(sources, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    for name in ('Collect-TestSpatialHalfStep.py', 'Check-TestSpatialHalfStep.py', 'Canonical-TestCoreVBA.py',
        'Validate-TestHardPrepared.py', 'Check-TestHardHalfSteps.py', 'Stage-TestHardPrepared.py',
        'Stage-TestHardHalfSteps.py', 'Stage-TestHardHalfRefinement.py', 'Stage-TestHardHalfLimit.py',
        'Stage-TestHardSpatialStep.py', 'Stage-TestHardFineTangent.py', 'TestNativeHardHalfSteps.bas.txt',
        'TestNativeHardPrepared.bas.txt', 'Stage-TestClosedBranchPeak.py', 'Stage-TestSteelHistory.py'):
        (root / name).write_bytes((here / name).read_bytes())
    baseline = repo / 'docs/regression/Coupled6D/CoupledSmallCorrectionWorking20261118.zip'
    digest = sha256(baseline.read_bytes()).hexdigest().upper()
    assert digest == '953E48EF0DD1452E3FA65AA23029CBFA1D23C639BA6D2E6DFD8CE94AD061F701'
    (root / 'Baseline').mkdir()
    entries = {}
    with ZipFile(baseline) as archive:
        for name in ('HardEarlyField.csv', 'HardEarlyField.Operators.csv'):
            entry = 'Cases/Capture/Native/' + name
            raw = archive.read(entry)
            (root / 'Baseline' / name).write_bytes(raw)
            entries[name] = {'entry': entry, 'sha256': sha256(raw).hexdigest().upper()}
    (root / 'Baseline/Origin.json').write_text(json.dumps({'archive': baseline.name,
        'sha256': digest, 'entries': entries}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    checkpoint = {'scope': scope, 'base': '827f49c', 'physical_capacity_certified': False,
        'full_acceptance_completed': False, 'installed_workbook_changed': False}
    for name in ('Scope.json', 'SourceCheckpoint.json'):
        (root / name).write_text(json.dumps(checkpoint, indent=2) + '\n', encoding='utf-8')
    files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
        for file in root.rglob('*') if file.is_file() and file.name != 'Files.json'}
    (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('SPATIAL HALF STEP EVIDENCE COLLECTED', scope, len(files), flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('fixed', 'solves'), required=True)
    args = parser.parse_args()
    TestCollect(args.repo.resolve(), args.root.resolve(), args.scope)
