"""ДЛЯ ТЕСТОВ. Уточняет предел продольной разности до h/4096 при тех же 25 полях."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Продолжает численный ряд без изменения материала, геометрии, полей и последовательности их принятия."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardHalfRefinement.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '''    halfSteps = Array(0.001, 0.0005, 0.00025, 0.000125, 0.0000625, 0.00003125, 0.000015625, 0.0000078125)
    names = Array("Base", "Half", "Quarter", "Eighth", "Sixteenth", "ThirtySecond", "SixtyFourth", "OneTwentyEighth")'''
    new = '''    halfSteps = Array(0.001, 0.0005, 0.00025, 0.000125, 0.0000625, 0.00003125, 0.000015625, 0.0000078125, _
        0.00000390625, 0.000001953125, 0.0000009765625, 0.00000048828125, 0.000000244140625)
    names = Array("Base", "Half", "Quarter", "Eighth", "Sixteenth", "ThirtySecond", "SixtyFourth", "OneTwentyEighth", _
        "TwoFiftySix", "FiveTwelve", "TenTwentyFour", "TwentyFortyEight", "FortyNinetySix")'''
    assert code.count(old) == 1
    code = code.replace(old, new, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope']['half_steps'] = [.001 / 2**index for index in range(13)]
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('FIXED FIELDS LONGITUDINAL DERIVATIVE LIMIT TO H/4096 READY', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
