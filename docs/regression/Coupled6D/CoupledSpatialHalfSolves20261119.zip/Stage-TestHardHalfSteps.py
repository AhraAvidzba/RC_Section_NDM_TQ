"""ДЛЯ ТЕСТОВ. Готовит повтор одной закреплённой истории для исследования продольного полушага без нового решения равновесия."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile


def TestStage(repo, root):
    """Подключает только читающий эксперимент к фактической подготовке модели; рабочие исходники не меняет."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardPrepared.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    archive = repo / 'docs/regression/Coupled6D/CoupledSmallCorrectionWorking20261118.zip'
    digest = sha256(archive.read_bytes()).hexdigest().upper()
    assert digest == '953E48EF0DD1452E3FA65AA23029CBFA1D23C639BA6D2E6DFD8CE94AD061F701'
    origins = {}
    with ZipFile(archive) as source:
        for name, entry in (('BaselineHard.csv', 'Cases/Capture/Native/HardEarlyField.csv'),
                            ('BaselineOperators.csv', 'Cases/Capture/Native/HardEarlyField.Operators.csv')):
            raw = source.read(entry)
            (root / name).write_bytes(raw)
            origins[name] = {'entry': entry, 'sha256': sha256(raw).hexdigest().upper()}
            prep['inputs'][name] = sha256(raw).hexdigest().upper()
    (root / 'BaselineOrigin.json').write_text(json.dumps({'archive': archive.name, 'sha256': digest,
        'entries': origins}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    needle = 'Public HardPreparedRequestedTest As Boolean, EarlyFieldRequestedTest As Boolean'
    assert code.count(needle) == 1
    code = code.replace(needle, needle + '\nPrivate HalfStepStudyRequestedTest As Boolean', 1)
    needle = '    HardPreparedRequestedTest = False\n    Dim started As Double: started = Timer'
    assert code.count(needle) == 1
    code = code.replace(needle, '''    HardPreparedRequestedTest = False
    If HalfStepStudyRequestedTest Then
        TestReplayHardHalfSteps operators, solver.PhysicalDegreeCount, concrete, reinforced, sides, path, calibration, _
            initialSteps, attempts, lambdaTolerance, maxIterations, absTol, relTol
        Exit Sub
    End If
    Dim started As Double: started = Timer''', 1)
    code += '\n' + (here / 'TestNativeHardHalfSteps.bas.txt').read_text('utf-8-sig')
    assert max(map(len, code.splitlines())) < 1024
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    runner = 'Run-TestWorkingASD.ps1'
    code = (root / runner).read_text('utf-8-sig')
    needle = "'Compile','HardBaseline','HardEarlyField'"
    assert code.count(needle) == 1
    code = code.replace(needle, "'Compile','HalfSteps','HardBaseline','HardEarlyField'", 1)
    needle = "        if ($Phase -in @('HardBaseline','HardEarlyField')) {"
    assert code.count(needle) == 1
    code = code.replace(needle, '''        if ($Phase -eq 'HalfSteps') {
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardHalfSteps','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','240')
        } elseif ($Phase -in @('HardBaseline','HardEarlyField')) {''', 1)
    (root / runner).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for file in (Path(__file__), here / 'TestNativeHardHalfSteps.bas.txt'):
        (root / file.name).write_bytes(file.read_bytes())
        prep['inputs'][file.name] = sha256(file.read_bytes()).hexdigest().upper()
    for name in ('tests/modTestCoupledElasticState.bas', runner, 'BaselineOrigin.json'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'case': 'HalfSteps', 'fixed_fields': 25,
        'half_steps': [.001, .0005, .00025, .002], 'equilibrium_solved': False,
        'baseline_equilibrium_required': True, 'capacity_searched': False,
        'working_sources_changed': False, 'full_acceptance_completed': False}
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('FIXED 25 FIELDS LONGITUDINAL HALF-STEP STUDY READY; NO CAPACITY SEARCH', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
