"""ДЛЯ ТЕСТОВ. Проверяет согласование материального возмущения с уточнённым продольным полушагом."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root, half):
    """Уменьшает только обычное численное возмущение CDP до уже используемого уточнённого масштаба; закон напряжений не меняет."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardSpatialStep.py'))['TestStage'](repo, root, half)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'src/Materials/CCoupledConcreteResponse.cls'
    raw = (root / name).read_bytes()
    before = root / 'BaselineSource' / name
    before.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes(raw)
    code = raw.decode('utf-8-sig').replace('\r\n', '\n')
    old = '''                delta = STRAIN_PERTURBATION * (1# + Abs(strain(j)))
                If mode = ctmRefinedBranchConsistent Then delta = delta / 64#'''
    new = '''                delta = STRAIN_PERTURBATION * (1# + Abs(strain(j)))
                ' -------------------- ДЛЯ ТЕСТОВ --------------------
                ' Уточнение обычной касательной при малом пространственном шаге; пробные напряжения и история исходны.
                If modTestCoupledElasticState.FineOrdinaryCDPTangentTest And mASDFlow Is Nothing And Not branchConsistent Then delta = delta / 64#
                If mode = ctmRefinedBranchConsistent Then delta = delta / 64#'''
    assert code.count(old) == 1
    code = code.replace(old, new, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = 'Public HardPreparedRequestedTest As Boolean, EarlyFieldRequestedTest As Boolean'
    assert code.count(old) == 1
    code = code.replace(old, old + '\nPublic FineOrdinaryCDPTangentTest As Boolean', 1)
    code += '''
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Включает уточнённое обычное возмущение только на время одной частной траектории.
Public Function RunTestHardFineTangent(ByVal outputRoot As String) As String
    FineOrdinaryCDPTangentTest = True
    RunTestHardFineTangent = RunTestHardPrepared(outputRoot, "EarlyField")
    FineOrdinaryCDPTangentTest = False
End Function
'''
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'Compile','HardBaseline','HardEarlyField'"
    assert code.count(old) == 1
    code = code.replace(old, "'Compile','FineTangent','HardBaseline','HardEarlyField'", 1)
    old = "        if ($Phase -in @('HardBaseline','HardEarlyField')) {"
    assert code.count(old) == 1
    code = code.replace(old, '''        if ($Phase -eq 'FineTangent') {
            $arguments+=@('-Macro','modTestCoupledElasticState.RunTestHardFineTangent','-MacroArgument1',$PSScriptRoot,'-TimeoutSeconds','360')
        } elseif ($Phase -in @('HardBaseline','HardEarlyField')) {''', 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Materials/CCoupledConcreteResponse.cls', 'tests/modTestCoupledElasticState.bas',
                 'Run-TestWorkingASD.ps1', 'BaselineSource/src/Materials/CCoupledConcreteResponse.cls'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope'].update({'case': 'FineTangent', 'ordinary_CDP_perturbation_factor': 1 / 64,
        'branch_consistent_modes_unchanged': True, 'stress_only_law_unchanged': True})
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRIVATE REFINED H AND ORDINARY CDP TANGENT PERTURBATION READY', half, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--half-step', type=float, default=.001 / 128)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.half_step)
