"""ДЛЯ ТЕСТОВ. Проверяет новое равновесное продолжение с уточнённой продольной разностью в отдельной книге."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from runpy import run_path


def TestStage(repo, root, half):
    """Меняет только численный полушаг, согласуя три станции и экспорт; материалы и допуски остаются исходными."""
    assert half in (.001 / 128, .001 / 256)
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardPrepared.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    literal = format(half, '.15g').replace('e', 'E')
    name = 'src/Solver/CCoupledNewtonSolver.cls'
    raw = (root / name).read_bytes()
    before = root / 'BaselineSource' / name
    before.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes(raw)
    code = raw.decode('utf-8-sig').replace('\r\n', '\n')
    code, count = re.subn(r'(?m)^(Private Const SPATIAL_HALF_STEP As Double = )[\d.E+#-]+',
        lambda match: match[1] + literal, code)
    assert count == 1
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    code, count = re.subn(r'(?m)^(Private Const HARD_PREPARED_HALF_TEST As Double = )[\d.E+#-]+',
        lambda match: match[1] + literal, code)
    assert count == 1
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    name = 'Run-TestWorkingASD.ps1'
    code = (root / name).read_text('utf-8-sig')
    old = "'-MacroArgument2',$caseMode,'-TimeoutSeconds','240')"
    assert code.count(old) == 1
    code = code.replace(old, "'-MacroArgument2',$caseMode,'-TimeoutSeconds','360')", 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    for name in ('src/Solver/CCoupledNewtonSolver.cls', 'tests/modTestCoupledElasticState.bas',
                 'Run-TestWorkingASD.ps1', 'BaselineSource/src/Solver/CCoupledNewtonSolver.cls'):
        prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope'] = {'case': 'HardEarlyField', 'half_step': half,
        'reference_half_step': .001, 'materials_changed': False, 'tolerances_changed': False,
        'global_probe_limit': 96, 'working_code_changed': False, 'full_acceptance_completed': False}
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('PRIVATE EQUILIBRIUM WITH REFINED LONGITUDINAL STEP READY', literal, flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--half-step', type=float, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve(), args.half_step)
