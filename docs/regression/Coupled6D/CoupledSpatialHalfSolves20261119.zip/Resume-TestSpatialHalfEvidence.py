"""ДЛЯ ТЕСТОВ. Устраняет различие только записи точного VBA-числа в проверяющем комплекте."""

from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile, ZIP_DEFLATED


def TestMain():
    """Повторяет аудит обоих комплектов; исходники, нативные результаты и их ожидания не меняет."""
    repo = Path.cwd()
    here = Path(__file__).resolve().parent
    scratch = Path('D:/CodexScratch/RC_Section_NDM_TQ')
    records = {}
    for scope, name in (('fixed', 'CoupledSpatialHalfSteps20261119'), ('solves', 'CoupledSpatialHalfSolves20261119')):
        root = scratch / name
        file = root / 'Check-TestSpatialHalfStep.py'
        previous = file.read_bytes()
        record = {'precheck_checker_sha256': sha256(previous).hexdigest().upper(),
            'uncommitted_audit_correction': True,
            'reason': 'VBE changed literal 7.8125e-06 to 0.0000078125. Exact Decimal value and Double type are equal.',
            'scientific_inputs_changed': False, 'native_results_changed': False,
            'numeric_tolerances_changed': False, 'runtime_strings_normalized': False}
        (root / 'LiteralAuditCorrection.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        file.write_bytes((here / file.name).read_bytes())
        (root / 'Resume-TestSpatialHalfEvidence.py').write_bytes(Path(__file__).read_bytes())
        files = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest().upper()
            for file in root.rglob('*') if file.is_file() and file.name not in ('Files.json', 'NativeProof.json', 'MechanicsProof.json')}
        (root / 'Files.json').write_text(json.dumps(files, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        functions = run_path(str(root / 'Check-TestSpatialHalfStep.py'))
        functions['TestNative'](repo, root, root / 'NativeProof.json')
        functions['TestMechanics'](repo, root, root / 'MechanicsProof.json')
        destination = repo / 'docs/regression/Coupled6D' / (name + '.zip')
        with ZipFile(destination, 'x', ZIP_DEFLATED, compresslevel=9) as archive:
            for file in sorted(root.rglob('*')):
                if file.is_file():
                    archive.write(file, file.relative_to(root).as_posix())
        assert destination.stat().st_size < 100_000_000
        records[name] = {'scope': scope, 'bytes': destination.stat().st_size,
            'sha256': sha256(destination.read_bytes()).hexdigest().upper(),
            'proofs': {key: sha256((root / key).read_bytes()).hexdigest().upper()
                for key in ('NativeProof.json', 'MechanicsProof.json')}}
        print(name, json.dumps(records[name]), flush=True)
    (repo / 'tmp/SpatialHalfEvidenceCatalog.json').write_text(json.dumps(records, indent=2, sort_keys=True) + '\n', encoding='utf-8')


if __name__ == '__main__':
    TestMain()
