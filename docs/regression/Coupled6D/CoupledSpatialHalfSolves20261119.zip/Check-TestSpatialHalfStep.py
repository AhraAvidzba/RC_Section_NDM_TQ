"""ДЛЯ ТЕСТОВ. Проверяет чувствительность продольной разности без объявления численной остановки пределом."""

from argparse import ArgumentParser
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from runpy import run_path
from tempfile import TemporaryDirectory
import numpy as np


def TestRead(file):
    """Читает закреплённые метаданные без изменения их чисел и статусов."""
    return json.loads(file.read_text('utf-8-sig'))


def TestCheckpoint(root):
    """Отвергает метку другой базы и несовпадение области двух записей происхождения."""
    scope = TestRead(root / 'Scope.json')
    assert scope == TestRead(root / 'SourceCheckpoint.json')
    assert scope['base'] == '827f49c' and scope['scope'] in ('fixed', 'solves')
    for key in TestRead(root / 'Cases.json'):
        assert TestRead(root / 'Cases' / key / 'Preparation.json')['base_stage_commit'].startswith('827f49c'), key
    return scope['scope']


def TestBaseline(repo, root):
    """Проверяет точный архив и байты исходной истории; не переносит состояния с другого шага."""
    record = TestRead(root / 'Baseline/Origin.json')
    assert sha256((repo / 'docs/regression/Coupled6D' / record['archive']).read_bytes()).hexdigest().upper() == record['sha256']
    for name, entry in record['entries'].items():
        assert sha256((root / 'Baseline' / name).read_bytes()).hexdigest().upper() == entry['sha256']


def TestNative(repo, root, output):
    """Сверяет все 30 реальных компонентов расчёта, тестовые импорты и закрытие собственных Excel."""
    scope = TestCheckpoint(root)
    shared = run_path(str(root / 'Check-TestMaterialRoundoff.py'))
    shared['TestFiles'](root)
    source, _ = run_path(str(root / 'Verify-TestReducedEvidence.py'))['TestSource'](repo, root)
    helper, body, reader = run_path(str(root / 'Inspect-TestResolutionVBA.py'))['TestHelpers'](repo)
    _, original = reader(BytesIO(source))
    canonical = run_path(str(root / 'Canonical-TestCoreVBA.py'))
    normal = lambda text: canonical['TestCanonical'](text)[0]
    controls = [normal('x=1e-8') == normal('x=0.00000001'), normal('x=1e-8') != normal('x=1e-7'),
        normal('x=200000#') != normal('x=200000'), normal('s="ε"') != normal('s="?"'),
        normal('s="1e-8"') != normal('s="0.00000001"'), normal("x=1 'бетон") != normal("x=1 'сталь"),
        normal("x=1 'ν") == normal("x=1 '?"), normal('x=10000000000#') != normal('x=10000000001#')]
    assert all(controls)
    core_body = canonical['TestWrap'](body)
    def TestImportedBody(text, name):
        """Учитывает только точное числовое представление Newton; строки, типы и значения остаются различимыми."""
        record = core_body(text, name)
        if name == 'CCoupledNewtonSolver':
            return (normal(record[0]), *record[1:])
        return record
    cases = {}
    expected_keys = {'Coarse4', 'Refinement8', 'Limit13'} if scope == 'fixed' else {'H128', 'H128FineTangent'}
    assert set(TestRead(root / 'Cases.json')) == expected_keys
    for key in sorted(expected_keys):
        folder = root / 'Cases' / key
        result = shared['TestSourceComparison'](repo, root, folder, source, original, helper, TestImportedBody, reader)
        assert (result['components'], result['imported'], result['unchanged']) == (239, 25, 214)
        compiler = TestRead(folder / 'docs/regression/CodeUpdate.json')
        _, actual = reader(helper['TestContainer']((folder / 'CompiledVBA.bin').read_bytes()))
        coupled = []
        for relative in TestRead(folder / 'AllCoupledSources.json'):
            file = folder / relative
            expected, _ = helper['TestMVTCompilerBody'](body, file.read_text('utf-8-sig'), file.stem)
            observed = body(actual[file.stem], file.stem)[0]
            if file.stem == 'CCoupledConcreteReturn':
                def TestSpacing(text):
                    """Учитывает выравнивание одной константы VBE перед неизменным комментарием."""
                    rows = text.splitlines(keepends=True)
                    for index, line in enumerate(rows):
                        if line.startswith('private const rounding_limit as double = '):
                            code, comment = line.split("'", 1)
                            rows[index] = code.rstrip() + " '" + comment
                    return ''.join(rows)
                expected, observed = TestSpacing(expected), TestSpacing(observed)
            assert normal(expected) == normal(observed), (key, file.stem)
            coupled.append(file.stem)
        assert len(coupled) == 30
        result['all_coupled_sources_match'] = coupled
        phase = 'HalfSteps' if scope == 'fixed' else 'HardEarlyField' if key == 'H128' else 'FineTangent'
        assert {file.stem for file in (folder / 'Native').glob('*.txt')} == {phase}
        file = folder / 'Native' / (phase + '.txt')
        log = file.read_text('utf-8-sig')
        owner = TestRead(file.with_name(file.name + '.Ownership.json'))
        closure = TestRead(file.with_name(file.name + '.ProcessClosure.json'))
        identity = closure['Closure']['Identity']
        assert owner['VerifiedNewOwner'] and owner['BeforeWorkbookOpen'] and closure['RunnerCleanupValid']
        assert owner['PID'] == identity['PID'] and int(owner['StartTicksUTC']) == identity['Ticks']
        assert owner['SourceSHA256'] == compiler['WorkbookSHA256']
        assert closure['Passed'] and closure['ChildExitCode'] == 0 and closure['Closure']['FinalState']['State'] == 'Absent'
        assert 'SOURCE_UNCHANGED: True' in log and 'RUNTIME ERROR:' not in log
        totals = [tuple(map(int, pair)) for pair in re.findall(r'^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)', log, re.M)]
        assert totals == [(1, 0)]
        if scope == 'fixed':
            count = {'Coarse4': 4, 'Refinement8': 8, 'Limit13': 13}[key]
            assert f'HARD_HALF_STEP_STUDY;fields=25;variants={count};baseline_equilibrium=True;capacity_searched=False;' in log
        else:
            assert re.search(r'^HARD_PREPARED_RESULT;\d+;[\d.E+-]+;6;', log, re.M)
        safety = [json.loads(line) for line in (folder / 'Run.ndjson').read_text('utf-8-sig').splitlines()]
        assert safety and all(row['ramMiB'] >= 6500 and row['freeCommitGiB'] >= 6 for row in safety)
        assert all(all(p['ProtectedUser'] for p in row['excel']) for row in safety)
        result['reports'] = {phase: totals}
        cases[key] = result
    output.write_text(json.dumps({'cases': cases, 'scope': scope, 'canonical_controls': controls,
        'physical_capacity_certified': False, 'installed_workbook_changed': False,
        'full_acceptance_completed': False}, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('SPATIAL STEP ACTUAL VBA NATIVE REPORTS AND OWNED PROCESS CLOSURE VERIFIED', flush=True)


def TestMechanics(repo, root, output):
    """Собирает шесть сил и все уравнения, различая фиксированные поля и вновь найденные равновесия."""
    scope = TestCheckpoint(root)
    run_path(str(root / 'Check-TestMaterialRoundoff.py'))['TestFiles'](root)
    TestBaseline(repo, root)
    cases = {}
    if scope == 'fixed':
        check = run_path(str(root / 'Check-TestHardHalfSteps.py'))['TestCheck']
        for key in ('Coarse4', 'Refinement8', 'Limit13'):
            folder = root / 'Cases' / key
            assert (folder / 'BaselineHard.csv').read_bytes() == (root / 'Baseline/HardEarlyField.csv').read_bytes()
            assert (folder / 'BaselineOperators.csv').read_bytes() == (root / 'Baseline/HardEarlyField.Operators.csv').read_bytes()
            with TemporaryDirectory() as temporary:
                result = Path(temporary) / 'proof.json'
                check(folder, result)
                cases[key] = TestRead(result)
    else:
        validate = run_path(str(root / 'Validate-TestHardPrepared.py'))['TestValidate']
        with TemporaryDirectory() as temporary:
            temporary = Path(temporary)
            (temporary / 'Native').mkdir()
            for name in ('HardEarlyField.csv', 'HardEarlyField.Operators.csv'):
                (temporary / 'Native' / name).write_bytes((root / 'Baseline' / name).read_bytes())
            baseline, _ = validate(temporary, 'HardEarlyField')
        for key, count, maximum in (('H128', 17, 1.09340307969083), ('H128FineTangent', 22, 1.09495187768134)):
            proof, fields = validate(root / 'Cases' / key, 'HardEarlyField')
            assert len(fields) == count and proof['maximum_lambda'] == maximum
            assert not proof['reversed_fields'] and proof['meta'][:2] == ['6', '10']
            assert proof['material'] == baseline['material'] and proof['options'] == baseline['options']
            assert any('равновесие при lambda = 1 подтверждено: False' in part for part in proof['details'])
            proof['design_load_verified'] = False
            cases[key] = proof
    output.write_text(json.dumps({'scope': scope, 'cases': cases, 'independent_material_reintegration': False,
        'physical_capacity_certified': False}, indent=2, sort_keys=True, ensure_ascii=False) + '\n', encoding='utf-8')
    print('SPATIAL STEP SIX FORCES AND FULL EQUATIONS VERIFIED; PHYSICAL CAPACITY OPEN', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--scope', choices=('native', 'mechanics'), required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    {'native': TestNative, 'mechanics': TestMechanics}[args.scope](args.repo.resolve(), args.root.resolve(), args.out.resolve())
