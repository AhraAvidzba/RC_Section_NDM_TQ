"""ДЛЯ ТЕСТОВ. Продолжает исследование продольной разности до h/128 на неизменных принятых полях."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def TestStage(repo, root):
    """Меняет только набор расстояний независимого повтора; рабочие уравнения и решатель не редактирует."""
    here = Path(__file__).resolve().parent
    run_path(str(here / 'Stage-TestHardHalfSteps.py'))['TestStage'](repo, root)
    prep = json.loads((root / 'Preparation.json').read_bytes())
    name = 'tests/modTestCoupledElasticState.bas'
    code = (root / name).read_text('utf-8-sig')
    old = '    halfSteps = Array(0.001, 0.0005, 0.00025, 0.002): names = Array("Base", "Half", "Quarter", "Double")'
    new = '''    halfSteps = Array(0.001, 0.0005, 0.00025, 0.000125, 0.0000625, 0.00003125, 0.000015625, 0.0000078125)
    names = Array("Base", "Half", "Quarter", "Eighth", "Sixteenth", "ThirtySecond", "SixtyFourth", "OneTwentyEighth")'''
    assert code.count(old) == 1
    code = code.replace(old, new, 1)
    old = '"HARD_HALF_STEP_STUDY;fields=25;variants=4;baseline_equilibrium=True;capacity_searched=False;seconds="'
    new = '"HARD_HALF_STEP_STUDY;fields=25;variants=" & CStr(UBound(halfSteps) + 1) & ";baseline_equilibrium=True;capacity_searched=False;seconds="'
    assert code.count(old) == 1
    code = code.replace(old, new, 1)
    (root / name).write_bytes(code.replace('\n', '\r\n').encode('utf-8-sig'))
    prep['inputs'][name] = sha256((root / name).read_bytes()).hexdigest().upper()
    script = Path(__file__)
    (root / script.name).write_bytes(script.read_bytes())
    prep['inputs'][script.name] = sha256(script.read_bytes()).hexdigest().upper()
    prep['directed_scope']['half_steps'] = [.001 / 2**index for index in range(8)]
    (root / 'Preparation.json').write_text(json.dumps(prep, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print('FIXED FIELDS HALF-STEP REFINEMENT TO H/128 READY; NO EQUILIBRIUM SEARCH', flush=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    TestStage(args.repo.resolve(), args.root.resolve())
