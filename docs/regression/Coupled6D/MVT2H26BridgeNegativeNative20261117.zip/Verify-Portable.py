"""Сверяет нативные доказательства отката псевдодуги при двух видах отказа."""

import argparse
from difflib import unified_diff
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
from ArchiveInputs import prepare
from ResumeBase import prior, v


HERE = Path(__file__).resolve().parent
TERMINAL = "F3E43BA2705CB0FC9C1295F766626C90B6939D52C6B29791DAE1AD923BCCD8B2"
EARLIER_PREP = "0F9BE6F104D91B9B0C0DB7562067497CC070E8ED8DEDCB2503CF9E77EB5DE40C"
EARLIER_TRACE = "A23814E38961F733A93C632DE1E366FD93AB44B0C3543F097497FDAEC2498A73"
RETRY_TRACE = "970B5B82027A7AB5BE2567D4311CBEDFB0BD76C1587023268FC504C131F1173D"
MACRO = "tests/modTestCoupledExperiment.bas"
VERIFIER = "Verify-MVT2ShearControlled.py"


def verify_source(prep):
    status = HERE / "SourceEvidence/CResultMeta.cls"
    assert v.digest(status) == "CB16997F094F4A11CF9FE21ADC3BF9943759823EB6928A5776E79D2A2569EF90"
    assert "Case rsBlockedByDependency, rsInvalidInput, rsInvalidConfiguration\n            mCalculated = False" in status.read_text(encoding="utf-8")
    for entry in prep["arc_sources"]["modules"]:
        name = entry["path"]
        production = HERE / "SourceEvidence" / name
        diagnostic = HERE / name
        assert v.digest(production) == entry["candidate_sha256"]
        if name.endswith("CCoupledDeformationContinuation.cls"):
            assert production.read_bytes() == diagnostic.read_bytes()
        else:
            method = rb"^Friend Function TryRecoverDeformationByArc\(.*?^End Function"
            body = [re.search(method, f.read_bytes(), re.M | re.S)[0] for f in (production, diagnostic)]
            assert body[0] == body[1]


def verify_run(root, expected, prep):
    code = v.read(root / "docs/regression/CodeUpdate.json")
    compiler = v.read(root / "CompileClosure.json")
    log = (root / "Compile.log").read_text(encoding="utf-8-sig")
    owned = re.search(r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$", log, re.M)
    assert compiler["State"] == "Absent"
    assert (compiler["PID"], int(compiler["StartTicksUTC"])) == tuple(map(int, owned.groups()))
    assert "PRIVATE_CODE_READY: modules=6; production unchanged=True" in log
    assert code["Compiled"] is True and code["ProductionChanged"] is False
    assert code["ProductionSHA256"] == prep["book_sha256"] and sorted(code["Modules"]) == prep["arc_modules"]
    native = root / "NativeResume"
    owner = v.read(native / "MVT2.txt.Ownership.json")
    closure = v.read(native / "MVT2.txt.ProcessClosure.json")
    cleanup = v.read(native / "MVT2.txt.RunnerCleanup.json")
    receipt = v.read(native / "RunReceipt.json")
    assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == code["WorkbookSHA256"]
    assert closure["Passed"] and closure["ChildHasExited"] and closure["ChildExitCode"] == receipt["native_exit"] == expected
    assert closure["RunnerCleanupValid"] and closure["RunnerCleanup"] == cleanup
    assert cleanup["OwnerVerified"] and cleanup["QuitRequested"] and cleanup["QuitSucceeded"] and cleanup["Errors"] == []
    assert cleanup["Failed"] is bool(expected)
    assert not closure["OrdinaryPathKilledAnything"]
    final = closure["Closure"]["FinalState"]
    assert final["State"] == "Absent" and (final["PID"], final["StartTicksUTC"]) == (owner["PID"], owner["StartTicksUTC"])
    report = (native / "MVT2.txt").read_text(encoding="utf-8-sig")
    assert f"WATCHDOG_COMPLETED: exit={expected}; source unchanged=True" in report
    return report


def verify_first_and_correction(prep):
    first = HERE / "FirstRun"
    assert v.digest(first / "Preparation.json") == EARLIER_PREP
    old = v.read(first / "Preparation.json")
    assert old["book_sha256"] == prep["book_sha256"] and old["arc_sources"] == prep["arc_sources"]
    assert old["inputs"].keys() == prep["inputs"].keys()
    differences = {name for name, sha in old["inputs"].items() if sha != prep["inputs"][name]}
    assert differences == {MACRO, VERIFIER}
    for file in differences:
        assert v.digest(first / file) == old["inputs"][file]
    earlier_vba = (first / MACRO).read_text(encoding="utf-8").splitlines(keepends=True)
    current_vba = (HERE / MACRO).read_text(encoding="utf-8").splitlines(keepends=True)
    diff = "".join(unified_diff(earlier_vba, current_vba, fromfile="FirstRun/" + MACRO, tofile=MACRO))
    assert diff == (HERE / "FixtureCorrection.diff").read_text(encoding="utf-8")
    assert "Or status.Calculated <> original.Calculated" in diff
    assert "And Not status.Calculated" in diff and "status.Calculated And original.Calculated" in diff
    report = verify_run(first, 1, old)
    assert "RUNTIME ERROR: VBAProject Изменилась применимость исходного расчёта." in report
    assert "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0" not in report
    earlier_trace = first / "NativeResume/MVT2.csv"
    corrected_trace = HERE / "NativeResume/MVT2.csv"
    assert v.digest(earlier_trace) == EARLIER_TRACE and v.digest(corrected_trace) == RETRY_TRACE
    a, b = v.read_native(earlier_trace), v.read_native(corrected_trace)
    assert a["X_STOCK"] == b["X_STOCK"] and len(a["X_STOCK"]) == 2
    assert a["X_DETAILS"] == b["X_DETAILS"][:1] and len(a["X_DETAILS"]) == 1
    [old_numeric] = a["X_REJECT"]
    new_numeric, config = b["X_REJECT"]
    assert old_numeric == new_numeric[:-3] + new_numeric[-1:]
    assert old_numeric[:-1] == "Numeric 1 17 17 102 6 10 0 0 -42 3923 3852".split()
    assert new_numeric[-3:-1] == ["1", "1"] and config[-3:-1] == ["1", "0"]
    assert prior.by_name(a, "B_ARC_HISTORY")["NegativeNumeric"] == prior.by_name(b, "B_ARC_HISTORY")["NegativeNumeric"]


def main():
    if not __debug__:
        raise SystemExit("Use Python without -O")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook", type=Path)
    parser.add_argument("--diagnostic-workbook", type=Path)
    args = parser.parse_args()
    inputs = prepare(args)
    verify_source(inputs[0])
    verify_first_and_correction(inputs[0])
    verify_run(HERE, 0, inputs[0])
    spec = spec_from_file_location("native_verify", HERE / VERIFIER)
    native = module_from_spec(spec)
    spec.loader.exec_module(native)
    verified = native.verify(inputs)
    assert v.digest(HERE / "VerificationArcNegative.json") == TERMINAL
    assert json.loads(json.dumps(verified)) == v.read(HERE / "VerificationArcNegative.json")
    for result in verified["cases"]:
        before, after = result["material_evaluations_before_after"]
        print(f"{result['case']} iterations={result['iterations']}/{result['max_iterations']}, "
              f"evaluations={before}->{after}, candidate unavailable, "
              f"equal solver={result['solver_values_equal']} material={result['accepted_material_values_equal']}")
    print("MVT2 H26 BRIDGE NEGATIVE PORTABLE VERIFIED", TERMINAL)


if __name__ == "__main__":
    main()
