"""Подтверждает отказ и откат обеих запущенных вспомогательных проб H26."""

import argparse
import json
from pathlib import Path
from importlib.util import module_from_spec, spec_from_file_location
import re

import ResumeBase as history
from ResumeBase import prior, v


HERE = Path(__file__).resolve().parent

_spec = spec_from_file_location("verify_setup", HERE / "Verify-Setup.py")
_setup_module = module_from_spec(_spec)
_spec.loader.exec_module(_setup_module)
setup_trial = _setup_module.verify_setup
SUBCASES = ("Numeric", "Configuration")


def verify(frozen):
    prep, prefix, _, _, witnesses, *_ = frozen
    assert prep["negative_case"] is True and prep["historical_bounded_setup_only"] is True
    prior.MODULES = prep["arc_modules"]
    compiler, owner, wall = history.verified_receipts(prep)
    path = HERE / "NativeResume/MVT2.csv"
    raw = v.read_native(path)
    setup = setup_trial(raw)
    snapshots = prior.by_name(raw, "B_ARC_HISTORY")
    assert snapshots["Base24"] == snapshots["Restored24"]
    assert snapshots["CommittedAttempt2"] == witnesses[1][67:]
    for value in SUBCASES:
        assert snapshots["Negative" + value] == snapshots["CommittedAttempt2"], value
    committed = prior.by_name(raw, "B_EXT_COMMITTED")
    for probe, row in zip(("Attempt1", "Attempt2"), witnesses, strict=True):
        assert committed[probe] == row[1:61]
        assert snapshots["Committed" + probe] == snapshots["Replayed" + probe] == row[67:]
    replay = v.vec(raw, "MVT2_CONTROL_FIELD")
    for i, (field, _) in enumerate(prefix, 1):
        assert v.peak(v.diff(replay[f"Replay{i}"], field)) < 1e-15

    [[_, target]] = raw["X_CONTROL"]
    v.near(float(target), v.read(HERE / "FixedTargetWitness.json")["target_coordinate"], 3e-15)
    stock = prior.by_name(raw, "X_STOCK")
    rejections = prior.by_name(raw, "X_REJECT")
    details = prior.by_name(raw, "X_DETAILS")
    assert tuple(stock) == tuple(rejections) == tuple(details) == SUBCASES
    assert stock["Numeric"] == stock["Configuration"]
    results = []
    for mode in SUBCASES:
        initial, evaluations, *original_diagnostics = stock[mode]
        initial = int(initial)
        evaluations = int(evaluations)
        *numbers, comment = rejections[mode]
        extra, allowed, used, total_eval, status, code, cause, injection, lambda_sentinel, equations, materials, applies, calculated = map(int, numbers)
        assert (initial, extra, lambda_sentinel, equations, materials, applies) == (15, 1, -42, 3923, 3852, 1)
        combined = ";".join(details[mode])
        assert " | Исходный отказ: " + ";".join(original_diagnostics) + " | Проверка: " in combined
        assert f"Итерации: {used}; пробы: {total_eval}; " in combined
        parts = re.search(r"итерации исходной пробы / дуги / повтора: (\d+) / (\d+) / (\d+); общий лимит: (\d+)", combined)
        start, arc, retarget, cap = map(int, parts.groups())
        assert start == initial and start + arc + retarget == used and retarget == 0 and cap == allowed
        if mode == "Numeric":
            assert (allowed, used, arc, status, code, injection, calculated) == (17, 17, 2, 6, 10, 0, 1)
            assert total_eval > evaluations
            assert "Достигнут лимит итераций" not in comment and "не снизило невязку" in comment
        else:
            assert (allowed, used, arc, status, code, cause, injection, calculated) == (26, 15, 0, 8, 13, 4, 1, 0)
            assert total_eval == evaluations + 1 and "Не удалось получить материальный отклик" in comment
        results.append({"case": mode, "material_faults_injected": injection, "extra_probes": extra, "iterations": used,
                        "max_iterations": allowed, "material_evaluations_before_after": [evaluations, total_eval],
                        "internal_status": status, "result_code": code, "source_material_code": cause, "calculated": bool(calculated),
                        "caller_lambda_untouched": True, "candidate_unavailable": True, "solver_values_equal": equations,
                        "accepted_material_values_equal": materials, "original_diagnostic_kept": True})
    return {"historical_setup": setup, "native_trace_sha256": v.digest(path), "book_sha256": prep["book_sha256"], "solver_source": prep["arc_sources"],
            "cases": results, "H24_exact_restore": True, "compiler_closed": compiler["State"] == "Absent",
            "owner_pid": owner["PID"], "wall_seconds": wall}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs-only", action="store_true")
    parser.add_argument("--phase", choices=["Resume"])
    command = parser.parse_args()
    setup = history.prepare()
    if command.inputs_only:
        print("FROZEN NEGATIVE API INPUTS", v.digest(HERE / "Preparation.json"))
    else:
        assert command.phase == "Resume"
        out = HERE / "VerificationArcNegative.json"
        out.write_text(json.dumps(verify(setup), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("NEGATIVE API VERIFIED", v.digest(out))
