"""Сверяет исходные файлы и нативную последовательность подготовки H26."""

from pathlib import Path
from ResumeBase import prior, v
import ResumeBase as history

HERE = Path(__file__).resolve().parent
BOOK = "workbook/output/RC_Section_NDM.xlsm"
CURRENT = "C603E41639484DB313C5390930BC52F1AC3CC42ED4CE01BC1946BC01ED84FA95"
MANIFEST = "CC9F56663E89134D6355E002016C9D44F32084193C6F618D55D266792673506B"
MANIFEST = "8A23F439FECF8C754CE36D89538EC295DAD7B4CEB502D7B86E6B2400EE5096B8"


def prepare(args):
    """Воспроизводит подготовку исходной сверки с явно передаваемым бинарником."""
    inventory = v.read(HERE / "SHA256SUMS.json")
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file()
              and p.name != "SHA256SUMS.json" and "__pycache__" not in p.parts}
    assert actual == set(inventory)
    for name, sha in inventory.items():
        assert Path(name).suffix.lower() not in {".xlsm", ".xlsx", ".xls", ".ndm"}
        assert Path(name).name.lower() != "vba_all_code.txt"
        assert v.digest(HERE / name) == sha, name

    assert v.digest(HERE / "Preparation.json") == MANIFEST
    prep = v.read(HERE / "Preparation.json")
    assert prep["book_sha256"] == prep["inputs"][BOOK] == CURRENT
    assert prep["historical_bounded_setup_only"] is True and prep["negative_case"] is True
    for file, sha in prep["inputs"].items():
        if file != BOOK:
            assert v.digest(HERE / file) == sha, file
    if args.workbook:
        assert v.digest(args.workbook) == CURRENT
    if args.diagnostic_workbook:
        assert v.digest(args.diagnostic_workbook) == v.read(HERE / "docs/regression/CodeUpdate.json")["WorkbookSHA256"]

    assert prep["inputs"]["Replay.csv"] == prep["replay_sha256"] and prep["watchdog_seconds"] == 105
    archive, stations = v.verified_states(v.read_native(HERE / "JetNative.csv"))
    base24 = archive["Base24"]
    assert base24 == archive["Restored24"] and stations["Base24"] == stations["Restored24"]
    replay = (HERE / "Replay.csv").read_text().splitlines()[1:]
    assert len(replay) == 24
    prefix = [(tuple(map(float, row[9:])), float(row[2])) for row in (line.split(";") for line in replay)]
    assert prefix[-1] == (base24["field"], base24["q"])
    accepted = history.wire_chunks("AcceptedWire.csv", (1, 15, 15, 15, 15, 6, *(8,) * 135) * 2)
    witnesses = [accepted[:1147], accepted[1147:]]
    assert len(witnesses) == 2 and all(len(row) == 1147 for row in witnesses)
    assert [float(row[0]) for row in witnesses] == [18.5708039839326, 18.5785550208131]
    endpoints = [(tuple(map(float, row[1:61])), float(row[0])) for row in witnesses]
    original_normal = prior.numbers((HERE / "MVTNormal.csv").read_text().strip().split(";"))
    pinned = prior.numbers(history.wire_chunks("H26Normal.csv", (15, 15, 15, 15, 3)))
    load_scale = v.read(HERE / "MVTHistory.json")["strains_normalized_to_last_Qy_increment_per_kN"]
    direct, normal_load, length = prior.determine_normal(endpoints[1], endpoints[0], base24["geometry"], load_scale)
    assert len(pinned) == 63 and pinned[56:60] == (0.,) * 4 and pinned[62] == 1.31947154672837e-7
    assert v.peak(v.diff(direct, pinned[:60])) < 2e-12
    v.near(pinned[60], normal_load, 2e-15)
    v.near(pinned[61], length, 2e-17)
    return prep, prefix, base24, stations["Base24"], witnesses, original_normal, pinned, load_scale


