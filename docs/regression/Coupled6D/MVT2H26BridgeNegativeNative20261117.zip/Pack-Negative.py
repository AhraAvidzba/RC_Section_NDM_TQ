"""Собирает автономный архив повторной проверки двух отказов H26."""

from difflib import unified_diff
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from tempfile import TemporaryDirectory


HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parent / "mvbridge-proof"
SCRATCH = Path("D:/CodexScratch/RC_Section_NDM_TQ")
CURRENT = SCRATCH / "MVTArcNegativeB"
FIRST = SCRATCH / "MVTArcNegative"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
MACRO = "tests/modTestCoupledExperiment.bas"
VERIFY = "Verify-MVT2ShearControlled.py"
MANIFEST = "8A23F439FECF8C754CE36D89538EC295DAD7B4CEB502D7B86E6B2400EE5096B8"


def main():
    specification = spec_from_file_location("pack", PREVIOUS / "Pack.py")
    pack = module_from_spec(specification)
    specification.loader.exec_module(pack)
    pack.HERE, pack.CURRENT, pack.FIRST = HERE, CURRENT, FIRST
    pack.OUT = HERE / "MVT2H26BridgeNegativeNative20261117.zip"
    current = json.loads((CURRENT / "Preparation.json").read_bytes())
    evidence = {name for name in current["inputs"] if name != BOOK}
    evidence.update(("VerificationArcNegative.json", *pack.STATE, *("NativeResume/" + name for name in pack.RAW)))
    assert pack.digest(CURRENT / "Preparation.json") == MANIFEST
    with TemporaryDirectory(prefix="source-", dir=HERE) as path:
        temp = Path(path)
        from_prior = (PREVIOUS / "Verify-Portable.py").read_text(encoding="utf-8")
        prelude = from_prior[from_prior.index("HERE = "):from_prior.index("TERMINAL = ")]
        function = from_prior[from_prior.index("def prepare("):from_prior.index("def verify_sources(")]
        assert function.count("prep[\"negative_case\"] is False") == 1
        function = function.replace("prep[\"negative_case\"] is False", "prep[\"negative_case\"] is True")
        (temp / "ArchiveInputs.py").write_text(
            '"""Сверяет исходные файлы и нативную последовательность подготовки H26."""\n\n'
            "from pathlib import Path\nfrom ResumeBase import prior, v\nimport ResumeBase as history\n\n"
            + prelude + f'MANIFEST = "{MANIFEST}"\n\n\n' + function, encoding="utf-8", newline="\n")
        earlier_vba = (FIRST / MACRO).read_text(encoding="utf-8").splitlines(keepends=True)
        current_vba = (CURRENT / MACRO).read_text(encoding="utf-8").splitlines(keepends=True)
        (temp / "FixtureCorrection.diff").write_text(
            "".join(unified_diff(earlier_vba, current_vba, fromfile="FirstRun/" + MACRO, tofile=MACRO)),
            encoding="utf-8", newline="\n")

        def inputs():
            for name in sorted(evidence):
                yield CURRENT / name, name
            for name in (*pack.STATE, MACRO, VERIFY, *("NativeResume/" + part for part in pack.RAW)):
                yield FIRST / name, "FirstRun/" + name
            for entry in current["arc_sources"]["modules"]:
                name = entry["path"]
                yield HERE.parent / "mvbridge" / name, "SourceEvidence/" + name
            yield HERE.parent.parent / "src/Common/CResultMeta.cls", "SourceEvidence/CResultMeta.cls"
            for name in ("ArchiveInputs.py", "FixtureCorrection.diff"):
                yield temp / name, name
            for name in ("Verify-Portable.py", "Pack-Negative.py", "README-Portable.md"):
                yield HERE / name, name

        pack.locate_files = inputs
        pack.main()


if __name__ == "__main__":
    main()
