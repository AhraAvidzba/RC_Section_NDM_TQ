from pathlib import Path
from hashlib import sha256
import json, numpy as np
from scipy.interpolate import BSpline

def operators(geometry, L):
    x,y,area=geometry.T
    normalized=area/(305.*610.)
    gx_knots=np.array([-152.5]*4+[0.]+[152.5]*4)
    gy_knots=np.array([-305.]*4+[0.]+[305.]*4)
    basis=np.eye(5)
    spline_x=BSpline(gx_knots,basis,3,extrapolate=False)
    spline_y=BSpline(gy_knots,basis,3,extrapolate=False)
    nx,ny=spline_x(x),spline_y(y)
    dx,dy=spline_x.derivative()(x),spline_y.derivative()(y)
    def pair(a,b):
        return (a[:,:,None]*b[:,None,:]).reshape((len(x),25))
    shape=pair(ny,nx)
    slope_x=L*pair(ny,dx)
    slope_y=L*pair(dy,nx)
    h=np.zeros((184,6,79))
    u=slice(4,79,3)
    v=slice(5,79,3)
    w=slice(6,79,3)
    h[:,2,0]=1.
    h[:,2,1]=y/L
    h[:,2,2]=x/L
    h[:,4,3]=-y/L
    h[:,5,3]=x/L
    h[:,0,u]=slope_x
    h[:,1,v]=slope_y
    h[:,3,u]=slope_y
    h[:,3,v]=slope_x
    h[:,4,w]=slope_x
    h[:,5,w]=slope_y
    c=np.zeros((4,79))
    concrete=slice(144)
    shape_weight=shape[concrete]*normalized[concrete,None]
    c[0,u]=c[1,v]=c[2,w]=shape_weight.sum(axis=0)
    c[3,u]=(-y[concrete,None]/L*shape_weight).sum(axis=0)
    c[3,v]=(x[concrete,None]/L*shape_weight).sum(axis=0)
    resultants=np.zeros((184,6,6))
    resultants[:,0,2]=1.
    resultants[:,1,2]=y
    resultants[:,2,2]=x
    resultants[:,3,4]=-y
    resultants[:,3,5]=x
    resultants[:,4,4]=1.
    resultants[:,5,5]=1.
    scales=305.*610.*np.array([1.,L,L,L,1.,1.])
    return h, shape, c, resultants, normalized, scales

ROOT=Path(__file__).resolve().parent
def read(name): return json.loads((ROOT/name).read_text(encoding="utf-8-sig"))
def digest(name): return sha256((ROOT/name).read_bytes()).hexdigest().upper()
def peak(a): return float(np.max(np.abs(a)))
def near(a,b,tol): assert abs(a-b)<=tol,(a,b,tol)

def control_certificate(residual,weights,tau):
    coeff=weights[2]
    pos=coeff>0.
    lo=float(np.max((-tau-residual[:79][pos])/coeff[pos]))
    hi=float(np.min((tau-residual[:79][pos])/coeff[pos]))
    involved=np.r_[pos,np.zeros(10,dtype=bool)]
    feasible=lo<=hi and peak(residual[~involved])<=tau
    return lo,hi,bool(feasible)

def computed(d, original):
    g,L=d["geometry"],float(d["length"])
    h,shape,c,qmat,weights,scales=operators(g,L)
    states={}
    for name,field,native,index in zip(d["names"],d["fields"],d["states"],d["station_index"],strict=True):
        tag=str(name)
        stations=d["stations"][int(index)]
        lam,target=field[:2]
        q=field[2:]
        coord=q[:79]
        depth=q[79:83]
        mu=q[83:]
        assert lam==native[1] and target==native[0]
        strains=h@coord
        slope=h[:,:,:4]@depth
        eps3=np.array([strains+i*.001*slope for i in (-1,0,1)])
        assert peak(eps3-stations[:,:,:6])<2e-12
        stresses=stations[1,:,6:]
        gradient=(stations[2,:,6:]-stations[0,:,6:])/.002
        eq=np.einsum("nij,ni,n->j",h,stresses,weights)
        eq[4:]-=np.einsum("nk,na,n->ka",shape,gradient[:,[4,5,2]],weights).ravel()
        eq+=c.T@mu
        long_eq=np.einsum("nij,ni,n->j",h[:,:,:4],gradient,weights)
        long_eq[1]-=1e5*lam/scales[0]
        gauge=c@coord
        force=np.einsum("nij,nj,n->i",qmat,stresses,g[:,2])
        assert peak(np.r_[eq,long_eq,gauge]-native[12:])<2e-10
        assert peak((force-native[6:12])/scales)<2e-10
        r=np.r_[eq,long_eq,(force-np.r_[np.zeros(5),1e5*lam])/scales]
        gamma=float(weights[:144]@strains[:144,5])
        tau=float(native[3])
        assert abs(gamma-target)*25600. <=tau and peak(gauge)*25600.<=tau
        norm=max(peak(r),abs(gamma-target)*25600.)
        near(norm,native[2],2e-10)
        states[tag]={"r":r,"tau":tau,"norm":norm,"field":field,"idx":int(index),"resultants":native[6:12]}
    return states,c

import csv

def verify():
    manifest=read('Manifest.json'); native=read('NearRefitVerification.json'); plan=read('NearRefitPlan.json'); prep=read('Preparation.json')
    for k,v in manifest['files'].items(): assert digest(k)==v,k
    assert native['workbook']==prep['workbook_sha256']==read('CodeUpdate.json')['ProductionSHA256']
    assert digest('NearRefitFields.csv')==plan['fixtureSHA256']==prep['frozen']['NearRefitFields.csv']
    assert digest('NearRefitPlan.json')==prep['frozen']['NearRefitPlan.json']
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in (ROOT/'KaniV4.txt').read_text(encoding='utf-8-sig')
    close=read('KaniV4.txt.ProcessClosure.json'); owner=read('KaniV4.txt.Ownership.json'); end=close['Closure']['FinalState']
    assert close['Passed'] and close['ChildExitCode']==0 and end==native['nativePidClosed']
    assert end['PID']==owner['PID'] and end['StartTicksUTC']==owner['StartTicksUTC'] and end['State']=='Absent'
    assert read('CompileClosure.json')['State']=='Absent'
    with np.load(ROOT/'MeasuredSamples.npz',allow_pickle=False) as d:
        st,c=computed(d,native); proj=d['projection']; stations=d['stations']; tags=d['names']
    E={l:np.full((3,184,2),np.nan) for l in ('Original43','Restore43','BaseAccepted','EndAccepted')}
    F={l:np.full((3,184),np.nan) for l in ('BaseAccepted','EndAccepted','NearOriginal','NearHalf','NearFull')}
    B={l:np.full((3,184,3),-99) for l in tags}
    for kind,l,pt,side,*row in csv.reader((ROOT/'KaniV4Tangents.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        i,j=int(side)+1,int(pt)-1
        if kind=='BRANCH': B[l][i,j]=list(map(int,row))
        elif kind=='ENERGY': E[l][i,j]=list(map(float,row))
        else:
            assert kind=='YIELD'; F[l][i,j]=float(row[0])
    for before,after in (('Original43','Restore43'),('BaseAccepted','EndAccepted')):
        assert st[before]['idx']==st[after]['idx'] and np.array_equal(st[before]['field'],st[after]['field'])
        assert np.array_equal(E[before],E[after]) and np.array_equal(B[before],B[after])
    assert np.array_equal(F['BaseAccepted'],F['EndAccepted'])
    base=st['NearOriginal']; details={}
    for tag,v in native['probes'].items():
        state=st[tag]; q=state['field']; assert np.array_equal(q[:2],base['field'][:2]);
        assert peak(np.r_[c@q[2:81],proj@q[2:]-q[1]])<1e-15
        assert peak(state['r']-base['r']-np.array(v['rowChangeFromOriginal_MPa']))<2e-10
        assert int((np.sign(F[tag])!=np.sign(F['NearOriginal'])).sum())==v['FSignChanges']
        assert int(np.any(B[tag]!=B['NearOriginal'],axis=2).sum())==v['branchOrSubstepChanges']
        assert peak(stations[state['idx']][:,7,:6]-stations[base['idx']][:,7,:6])<4e-17
        if v['exactFieldAdmitted']:
            accepted=st[tag+'/Admitted']; assert accepted['idx']==state['idx'] and np.array_equal(accepted['field'],q)
            assert peak(state['r'])<=state['tau']
        near(peak(state['r']),v['fullNorm_MPa'],2e-10)
        details[tag]={'norm_MPa':peak(state['r']),'withinTolerance':peak(state['r'])<=state['tau'],'signChanges':v['FSignChanges'],
                      'branchChanges':v['branchOrSubstepChanges']}
    print(json.dumps({'workbook':native['workbook'],'outcome':native['outcome'],'states':len(st),'rows':89,'constraints':5,'probes':details},indent=2))

if __name__=='__main__': verify()
