from argparse import ArgumentParser
import json
from pathlib import Path
import runpy

H=Path(__file__).resolve().parent; parent=H.parent/'KaniActiveSet46'; P=runpy.run_path(parent/'Prepare-RankOne46.py')
BOOK,SHADOW,SOLVER,ELASTIC,MODULE,CAPTURED=(P[k] for k in ('BOOK','SHADOW','SOLVER','ELASTIC','MODULE','CAPTURED'))
sha,one=P['sha'],P['one']
FIELD_SHA='76D31962549DB6605556572244AFEEA87E2518AA41C25E3AE8D5957FA4AF89B2'
PLAN_SHA='BDB189BF83D73E89C362D0D07E2CF98B0D93E1775A89E3950A0684C77362A50B'

def prepare(repo):
    assert not (H/'Preparation.json').exists()
    past=P['check']()
    assert sha(repo/BOOK)==past['workbook_sha256'] and all(sha(repo/k)==v for k,v in past['production_source_sha256'].items())
    assert sha(H/'NearRefitFields.csv')==FIELD_SHA and sha(H/'NearRefitPlan.json')==PLAN_SHA
    src=(parent/MODULE).read_text(encoding='utf8')
    a=src.index('    Dim rootPath As String'); b=src.index('    Close #tangents:',a)
    src=src[:a]+(H/'RefitMain.bas.txt').read_text(encoding='utf8').rstrip()+'\n'+src[b:]
    src=one(src,'If entries.Count <> 7 Or history.Count <> 43','If entries.Count <> 4 Or history.Count <> 43')
    runner=(parent/'Run-RankOne46.ps1').read_text(encoding='utf-8-sig')
    for k,v in (('Prepare-RankOne46.py','Prepare-Near47.py'),('Verify-RankOne46.py','Verify-Near47.py'),
                ('# Изолированная сверка двух поправок для Kani около 19/512.','# Изолированная проверка связанных строк Kani при приращении 0,10 Н.'),
                ('Сверка двух поправок Kani не пройдена.','Сверка уточнённого поля Kani не пройдена.')):
        runner=one(runner,k,v)
    history=[x for x in (parent/'KaniGaugeInput.csv').read_text(encoding='ascii').splitlines() if x.startswith('KANI_B_FIELD;History')]
    prob=(H/'NearRefitFields.csv').read_text(encoding='ascii').splitlines()
    assert len(history)==6 and len(prob)==4 and all(len(l.split(';'))==92 for l in history+prob)
    (H/'Native').mkdir(exist_ok=True); (H/'Temp').mkdir(exist_ok=True)
    inputs={Path(k):parent/k for k in past['frozen'] if k.startswith('tools/') or k in
            ('KaniV4Input.csv','KaniChartInput.csv',SOLVER.as_posix(),CAPTURED.as_posix(),ELASTIC.as_posix())}
    inputs[BOOK]=repo/BOOK; inputs[SHADOW]=repo/BOOK
    files={key:p.read_bytes() for key,p in inputs.items()}
    files.update({MODULE:src.encode('utf8'),Path('Run-Near47.ps1'):runner.encode('utf-8-sig'),
                  Path('KaniGaugeInput.csv'):('\r\n'.join(history+prob)+'\r\n').encode('ascii')})
    for key,data in files.items():
        path=H/key; path.parent.mkdir(exist_ok=True,parents=True); path.write_bytes(data)
    frozen=(set(files)-{SHADOW})|{Path(k) for k in ('RefitMain.bas.txt','EnergyHelper.bas.txt','NearRefitPlan.json',
            'NearRefitFields.csv','ConstrainedCorrection.json','Solve-Constrained47.py','Freeze-Near47.py','Prepare-Near47.py','Verify-Near47.py')}
    receipt={'workbook_sha256':past['workbook_sha256'],'production_source_sha256':past['production_source_sha256'],
            'frozen':{k.as_posix():sha(H/k) for k in sorted(frozen)}}
    (H/'Preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
    return check()

def check():
    rec=json.loads((H/'Preparation.json').read_text(encoding='utf8'))
    assert rec['workbook_sha256']==P['check']()['workbook_sha256']==sha(H/BOOK)
    assert all(sha(H/k)==v for k,v in rec['frozen'].items())
    assert sha(H/CAPTURED)==rec['production_source_sha256'][SOLVER.as_posix()] and sha(H/ELASTIC)==rec['production_source_sha256'][ELASTIC.as_posix()]
    assert (H/SOLVER).read_bytes()==(parent/SOLVER).read_bytes()
    assert rec['frozen']['NearRefitFields.csv']==FIELD_SHA and rec['frozen']['NearRefitPlan.json']==PLAN_SHA
    return rec

if __name__=='__main__':
    ap=ArgumentParser(); ap.add_argument('--repo',type=Path); ap.add_argument('--check',action='store_true'); a=ap.parse_args()
    print((check() if a.check else prepare(a.repo))['workbook_sha256'],sha(H/'Preparation.json'))
