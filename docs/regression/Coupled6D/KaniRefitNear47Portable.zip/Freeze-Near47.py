from pathlib import Path
from hashlib import sha256
import json,runpy
import numpy as np

H=Path(__file__).resolve().parent; ROOT=H.parent
N=ROOT/'KaniActiveSet46'; L=H/'ConstrainedCorrection.json'
plan=json.loads(L.read_text(encoding='utf8')); selected=plan['results']['branchGuarded']; assert selected['fixedPoint8']
assert selected['maxIncludedModelNorm']<plan['probeTauMPa']-2.e-8
rows=(N/'RankOneComparison.csv').read_text(encoding='ascii').splitlines()
assert rows[0].startswith('KANI_B_FIELD;Accepted19of512;')
chosen=next(x.split(';') for x in rows if x.startswith('KANI_B_FIELD;SignedRankOneNear;'))
f=np.r_[list(map(float,chosen[4:-1])),float(chosen[-1])]; chosen[1]='NearOriginal'
d=np.array(selected['physicalCorrection']); assert d[-1]==0.
with np.load(ROOT/'KaniV4Rebase3/RebasedLinearSystems.npz',allow_pickle=False) as a:
    B=a['strain_matrix']; K=a['refined_equality_matrix_MPa'];
    assert B.shape==(3,184,6,88)
frozen=[rows[0],';'.join(chosen)]; probes={}
for tag,amp in [('NearHalf',.5),('NearFull',1.)]:
    v=f+amp*d
    assert np.max(abs(B[:,7]@(v-f)))<5e-18 and np.max(abs(K@(v-f)))<3e-12
    line=chosen[:1]+[tag]+chosen[2:4]+[format(q,'.17g') for q in v[:-1]]+chosen[-1:]; assert len(line)==92
    frozen.append(';'.join(line)); probes[tag]={'amplitude':amp,'field':v.tolist(),'maxStrainChange':float(np.max(abs(B@(v-f))))}
out=H/'NearRefitFields.csv'; out.write_bytes(('\r\n'.join(frozen)+'\r\n').encode('ascii')); sha=lambda p:sha256(p.read_bytes()).hexdigest().upper()
proof={'analysisSHA256':sha(L),'fixtureSHA256':sha(out),'originalCorrectionField':f.tolist(),'nearGamma':float(chosen[3]),
    'nearLambda':float(chosen[-1]),'point8IsProtectedAtAll3Stations':True,'candidates':probes,
    'originalNorm':plan['loadedProbeNormMPa'],'tau':plan['probeTauMPa'],'conditionalMaxFullNormMPa':selected['maxIncludedModelNorm']}
j=H/'NearRefitPlan.json'; j.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(out,sha(out),j,sha(j),proof['nearLambda'],proof['nearGamma'])
