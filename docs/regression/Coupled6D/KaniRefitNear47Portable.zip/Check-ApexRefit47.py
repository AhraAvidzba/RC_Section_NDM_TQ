"""Recompute the Kani refit effect at independently reconstructed tensile apex stations."""
from pathlib import Path
from hashlib import sha256
import json,runpy
import numpy as np

H=Path(__file__).resolve().parent; root=H.parent
native=root/'KaniActiveSet46'; M=runpy.run_path(native/'Check-HydrostaticApex46.py')
model_path=root/'KaniApexReturn20261116/Verify-KaniApexReturn.py'; A=runpy.run_path(model_path)
R=M['D']; ids=M['ids']; section=M['sec']; field=M['fields']; Mask=M['mask']
link=lambda tag:R['stations'][R['station_index'][ids[tag]]]
q0=link('BaseAccepted')[:,:,:6]; qNear=link('SignedRankOneNear')[:,:,:6]
sNear=M['apparent']('SignedRankOneNear'); s0=M['apparent']('BaseAccepted'); et=M['proof']['acceptedEnergies_byStation_SidesMinusCenterPlus']['BaseAccepted']
plan=json.loads((H/'NearRefitPlan.json').read_text(encoding='utf8')); weights=M['rowweights']
row_out={}; validated={}; failures={}
for tag in ('NearHalf','NearFull'):
    shape=section.station_strains(np.array(plan['candidates'][tag]['field'])[:87]); qTrial=shape-q0; qInitial=qNear-q0
    results=[]; skipped=[]; residual=np.zeros((3,184,6)); checked=0
    for side,ip in zip(*np.where(Mask)):
        kc2=et[side][ip]; start=A['matrix'](s0[side,ip]); label=f'{side-1}/{ip+1}'
        try:
            p0,old_mode=A['return_apex'](start,*kc2,qInitial[side,ip]); p1,new_mode=A['return_apex'](start,*kc2,qTrial[side,ip]);
        except ValueError as e:
            skipped.append((label,str(e))); continue
        delta=np.array(A['vector'](p1-p0)); gap=float(np.max(abs(np.array(A['vector'](p0))-sNear[side,ip])))
        # Stress with reinforcement uses steel minus displaced concrete; the longitudinal virtual work
        # needs the correct sign, although the local apex return is computed for the positive material.
        residual[side,ip]=delta if ip<144 else -delta
        results.append((label,gap,float(np.max(abs(delta))),old_mode['kind'],new_mode['kind']))
    dR80=(residual[2,:,2]-residual[0,:,2])/.002; area=section.coordinates[:,2]/(305.*610.);
    row_out[tag]={'inDomain':len(results),'rejected':len(skipped),'oldAnchorMaxError_MPa':max(x[1] for x in results),
        'predictedContributions80_81_MPa':[float(area@dR80),float((weights*residual[:,:,2]).sum())],
        'modeChanged':[x[0] for x in results if x[3]!=x[4]],'maxPredictedStressChange':max(x[2] for x in results),
        'point8plus':[v for v in results if v[0]=='1/8'][0], 'rawNetConcreteStressDelta':residual.tolist(), 'excluded':skipped}
res={'apexModelSHA256':sha256(model_path.read_bytes()).hexdigest().upper(),'cases':row_out,
     'scope':'Only supported concrete apex states, no constitutive or section predictor for other stations. Steel linear term not included.'}
out=H/'IndependentApexRefitEffects.json'; out.write_text(json.dumps(res,indent=2)+'\n',encoding='utf8')
print(out,sha256(out.read_bytes()).hexdigest().upper())
for k,x in row_out.items(): print(k,x['inDomain'],x['rejected'],x['oldAnchorMaxError_MPa'],x['predictedContributions80_81_MPa'],x['point8plus'],x['modeChanged'])
