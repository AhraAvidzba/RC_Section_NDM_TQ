"""Verify the signed half/full correction and exact committed-state rollback."""
from pathlib import Path
import csv,json,runpy

H=Path(__file__).resolve().parent; root=H.parent; P=runpy.run_path(H/'Prepare-Near47.py'); O=runpy.run_path(root/'KaniWarpBeyond43/Check-KaniBeyond43.py')
np=O['np']; pk=O['peak']; sha=P['sha']; sec=O['section']


def verify():
    prep=P['check'](); native=H/'Native'; loaded=O['trs'](H); a,f,p,st,hashes=loaded
    archived=O['trs'](root/'KaniActiveSet46'); plan=json.loads((H/'NearRefitPlan.json').read_text(encoding='utf8'))
    proc=json.loads((native/'KaniV4.txt.ProcessClosure.json').read_text(encoding='utf-8-sig'))
    owner=json.loads((native/'KaniV4.txt.Ownership.json').read_text(encoding='utf-8-sig'))
    comp=json.loads((H/'docs/regression/CodeUpdate.json').read_text(encoding='utf-8-sig'))
    closed=json.loads((native/'CompileClosure.json').read_text(encoding='utf-8-sig')); end=proc['Closure']['FinalState']
    assert proc['Passed'] and proc['ChildExitCode']==0 and closed['State']==end['State']=='Absent'
    assert end['PID']==owner['PID'] and end['StartTicksUTC']==owner['StartTicksUTC'] and owner['VerifiedNewOwner']
    assert comp['Compiled'] and not comp['ProductionChanged'] and comp['ProductionSHA256']==prep['workbook_sha256']
    assert comp['WorkbookSHA256']==sha(H/P['SHADOW']) and sorted(comp['Modules'])==['CCoupledElasticState','CCoupledNewtonSolver','modTestKaniStage38']
    report=(native/'KaniV4.txt').read_text(encoding='utf-8-sig')
    assert 'TOTAL_KANI_V4_STAGE38: passed=1; failed=0' in report and 'SOURCE_UNCHANGED: True' in report
    assert np.array_equal(p,archived[2])
    controls=('Original43','BaseAccepted','EndAccepted','Restore43'); probes=('NearOriginal','NearHalf','NearFull')
    E={m:np.full((3,184,2),np.nan) for m in controls}; F={m:np.full((3,184),np.nan) for m in ('BaseAccepted','EndAccepted',*probes)}
    B={m:np.full((3,184,3),-99) for m in a}
    for kind,tag,ip,side,*data in csv.reader((native/'KaniV4Tangents.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        i,j=int(side)+1,int(ip)-1; assert 0<=i<3 and 0<=j<184
        if kind=='BRANCH': B[tag][i,j]=list(map(int,data))
        elif kind=='ENERGY': E[tag][i,j]=list(map(float,data))
        else:
            assert kind=='YIELD'; F[tag][i,j]=float(data[0])
    assert all(np.isfinite(v).all() for v in list(E.values())+list(F.values())) and all((v>=0).all() for v in [b[:,:,0] for b in B.values()])
    for before,after in (('Original43','Restore43'),('BaseAccepted','EndAccepted')):
        assert np.array_equal(E[before],E[after]) and np.array_equal(B[before],B[after])
        assert np.array_equal(f[before],f[after]) and np.array_equal(st[before],st[after])
        assert np.array_equal(f[before],archived[1][before]) and pk(st[before]-archived[3][before])<2e-10
    assert np.array_equal(F['BaseAccepted'],F['EndAccepted'])
    assert np.array_equal(f['NearOriginal'],archived[1]['SignedRankOneNear']) and pk(st['NearOriginal']-archived[3]['SignedRankOneNear'])<2e-10
    outcome={}
    for line in csv.reader((native/'KaniV4Trace.csv').open(encoding='cp1251',newline=''),delimiter=';'):
        if line[0]=='OUTCOME': outcome[line[1]]=list(map(int,line[2:]))
    assert set(outcome)==set(probes)
    r0=O['independent'](loaded,'NearOriginal'); st0=st['NearOriginal']; records={}; r={}
    for label in probes:
        q=f[label]; assert np.array_equal(q[:2],f['NearOriginal'][:2])
        rr=O['independent'](loaded,label); r[label]=rr; gauges=np.r_[25600*sec.gauges@q[2:81],25600*(p@q[2:]-q[1])]
        assert len(rr)==89 and len(gauges)==5 and pk(gauges)<3e-12
        err=pk(st[label][:,7,:6]-st0[:,7,:6]); st_err=pk(st[label][:,7,6:]-st0[:,7,6:])
        delta=pk(st[label][:,:,:6]-st0[:,:,:6]); assert err<4e-17 and st_err<3e-10
        if label!='NearOriginal':
            pr=plan['candidates'][label]; v=np.array(pr['field']);
            assert pk(q[2:]-v[:87])<3e-16 and abs(delta/pr['maxStrainChange']-1)<5e-5
        signChange=int(np.count_nonzero(np.sign(F[label])!=np.sign(F['NearOriginal'])))
        switch=int(np.count_nonzero(np.any(B[label]!=B['NearOriginal'],axis=2)))
        tau=float(a[label][3]); ready=bool(outcome[label][0]); exact=bool(outcome[label][1]);
        if ready:
            tag=label+'/Admitted'; assert exact and pk(rr)<=tau and np.array_equal(f[label],f[tag]) and np.array_equal(st[label],st[tag])
        records[label]={'fullNorm_MPa':pk(rr),'dominantRow':int(np.argmax(abs(rr))+1),'r70_80_81_83_MPa':rr[[69,79,80,82]].tolist(),
            'rowChangeFromOriginal_MPa':(rr-r0).tolist(),'tau_MPa':tau,'exactFieldAdmitted':ready and exact,'FSignChanges':signChange,
            'branchOrSubstepChanges':switch,'minAbsTrialYield_MPa':float(np.min(abs(F[label]))),'maxRelativeTrialYieldChange':pk((F[label]-F['NearOriginal'])/F['NearOriginal']),
            'maxStrainChange':delta,'point8MaxStrainChange':err,'point8MaxStressChange_MPa':st_err,'controlsInMPa':gauges.tolist()}
    refit=records['NearFull']; state='ADMITTED_EXACT_SAME_BRANCH' if refit['exactFieldAdmitted'] and not refit['FSignChanges'] and not refit['branchOrSubstepChanges'] else 'MEASURED'
    ans={'outcome':state,'workbook':prep['workbook_sha256'],'commonQy_N':f['NearOriginal'][0]*1e5,'commonGamma':f['NearOriginal'][1],
         'probes':records,'minimaxPredictedFullNorm_MPa':plan['conditionalMaxFullNormMPa'],
         'halfFullLinearityDefect_MPa':pk(r['NearFull']-2*r['NearHalf']+r['NearOriginal']),
         'historyRollbackExact':True,'nativePidClosed':end,'compilePidClosed':closed,
         'csvSHA256':{**{p.name:sha for p,sha in hashes},'KaniV4Tangents.csv':sha(native/'KaniV4Tangents.csv')}}
    out=H/'NearRefitVerification.json'; out.write_text(json.dumps(ans,indent=2)+'\n',encoding='utf8')
    print(out,sha(out),state,[(k,v['fullNorm_MPa'],v['branchOrSubstepChanges'],v['FSignChanges']) for k,v in records.items()])

if __name__=='__main__': verify()
