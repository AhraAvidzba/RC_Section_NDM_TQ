"""A fresh measured residual and a restrained correction around exact Kani Near +0.10 N."""
from pathlib import Path
from hashlib import sha256
import csv,json,runpy
import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent; Native=ROOT/'KaniActiveSet46'
old=runpy.run_path(ROOT/'KaniWarpBeyond43/Check-KaniBeyond43.py'); p5=ROOT/'KaniPracticalProbe45/PortableReplayed'
R=runpy.run_path(p5/'Verify.py'); pk=old['peak']; sec=old['section']
archive=old['trs'](Native)
state,fields,proj,tensors,_=archive
label='SignedRankOneNear'; qs=lambda l:np.r_[fields[l][2:],fields[l][0]]
ind=lambda l:old['independent'](archive,l)
f=qs(label); r=ind(label); tau=state[label][3]
provenance=json.loads((Native/'RankOneNativeVerification.json').read_text(encoding='utf8'))
F=np.array(provenance['trialYield_MPa_byStation_SidesMinusCenterPlus'][label]); assert F.shape==(3,184)
assert pk(r)==abs(r[69]) and r[79]<-tau and r[82]<-tau
bases={}
for item in ('KaniV4Rebase38/RebasedLinearSystems.npz','KaniV4Rebase3/RebasedLinearSystems.npz','KaniV4Jv38/KaniBHalfLinearSystems.npz'):
    with np.load(ROOT/item,allow_pickle=False) as p:
        B=p['strain_matrix'].reshape(-1,88); E=p['refined_equality_matrix_MPa']; back=p['resultant_projection'];
        bases[item.split('/')[0]]=p['refined_force_matrix_MPa']
with np.load(p5/'MeasuredSamples.npz',allow_pickle=False) as p:
    for mode in ('Stock','Refined'):
        m=p[mode+'_rows'][:83]; assert pk(p[mode+'_rows'][83:]-E)<5e-10
        bases['Exact19_512/'+mode]=np.vstack((m,back@m))
K=E[:,:87]; assert K.shape==(5,87)
# Use the two exact A/B contrasts. Their force and control are identical within either pair.
L=[('FreshUncorrectedNear','SignedRankOneNear'),('FreshUncorrectedSignal','SignedRankOneSignal')]
V=np.column_stack([qs(a)-qs(b) for a,b in L]); Y=np.column_stack([ind(a)-ind(b) for a,b in L]); v=B@V
cos=float((v[:,0]@v[:,1])/np.linalg.norm(v[:,0])/np.linalg.norm(v[:,1]))
assert pk(E@V)<3e-12 and pk(V[-1])==0.
# Replace model action on exact measured contrasts. The rank-one alternative preserves the
# independence of the earlier force/γ field carried across the step.
all_models=dict(bases)
for name in ['Exact19_512/Refined','KaniV4Rebase3','KaniV4Rebase38']:
    J=bases[name]
    for index in (0,1):
        w=(v[:,index].T@B)/(v[:,index]@v[:,index]);
        all_models[f'{name}/Actual{index+1}']=J+np.outer(Y[:,index]-J@V[:,index],w)
    # These contrasts are the same physical direction at two different trial centers.

# Explicit station strain constraint. Preserving point 8 (all 3 station positions)
# freezes that material contribution to weak rows 80/81 and every other weak row.
blocks=B.reshape(3,184,6,88)[:,7,:,:].reshape(-1,88)
scaling=np.r_[np.full(83,1e-12),np.full(4,1e-6),1.]
# Positive baseline shape compatibility error reconstructed from native vector serialization is below 1e-13 MPa.
required=np.r_[25600*sec.gauges@f[:79],25600*(proj@f[:87]-fields[label][1])]
assert pk(required)<2e-12

def solve(tag, keys, cap, preserve):
    # Minimax over all 89 rows for the selected operators, both signs of residual, and 5 exact constraints.
    constraints=E[:,:87]
    if preserve: constraints=np.vstack((constraints,blocks[:,:87]))
    scale=np.max(abs(constraints*scaling[:87]),axis=1); assert np.all(scale>0)
    Aeq=np.c_[constraints*scaling[:87]/scale[:,None],np.zeros(len(constraints))]
    rhs=-np.r_[required,np.zeros(len(constraints)-5)]/scale
    force=np.vstack([all_models[k][:,:87] for k in keys])*scaling[:87]/tau
    rr=np.tile(r/tau,len(keys)); basis=B[:,:87]*scaling[:87]/cap
    g1=np.c_[force,-np.ones(len(force))]; g2=np.c_[-force,-np.ones(len(force))]
    g3=np.c_[basis,np.zeros(len(basis))]; g4=np.c_[-basis,np.zeros(len(basis))]
    # Typical gauge shifts in this section are below 1e-5 MPa.
    eq=linprog(np.r_[np.zeros(87),1.],np.vstack([g1,g2,g3,g4]),np.r_[-rr,rr,np.ones(2*len(basis))],Aeq,rhs,
         bounds=[(-30,30)]*83+[(-8,8)]*4+[(0,None)],method='highs')
    if not eq.success: return {'success':False,'status':eq.status,'message':eq.message}
    d=np.r_[eq.x[:87]*scaling[:87],0.]
    assert pk(E@d+required)<3e-15
    if preserve: assert pk(blocks@d)<2e-20
    vals={k:r+op@d for k,op in all_models.items()}
    worst=max(pk(vals[k]) for k in keys)
    branchRadius=abs((B@d).reshape(3,184,6)).max(axis=2)
    actual={'success':True,'activeModels':list(keys),'cap':cap,'offAxisCos':cos,'stage':tag,'fixedPoint8':preserve,
      'maxStrain':pk(B@d),'point8MaxStrain':pk(blocks@d),'fixedQyN':float(f[-1]*1e5),'fixedGamma':float(fields[label][1]),
      'maxEqualityResidual':pk(E@d+required),'normObjective_MPa':float(eq.fun*tau),'maxIncludedModelNorm':worst,
      'modelNorms_MPa':{k:pk(val) for k,val in vals.items()},'row70_80_81_83_MPa':{k:val[[69,79,80,82]].tolist() for k,val in vals.items()},
      'largestModelRows':{k:int(np.argmax(abs(val))+1) for k,val in vals.items()},
      'countsFNearAtStrainCap_Heuristic':int(np.count_nonzero(abs(F)<=5e5*branchRadius)),
      'physicalCorrection':d.tolist(),'newField':(f+d).tolist()}
    print(tag,worst,pk(B@d),pk(blocks@d),actual['countsFNearAtStrainCap_Heuristic'],max(actual['modelNorms_MPa'].values()),flush=True)
    return actual
keys=tuple(all_models); refined=tuple(n for n in keys if n.startswith('Exact19_512/Refined'))
results={'preserved':solve('preserved',keys,2e-12,True),'refinedPreserved':solve('refinedPreserved',refined,2e-12,True)}
trustedRadius=0.995*pk(v[:,0])
results['stationMeasuredRadius']=solve('stationMeasuredRadius',keys,trustedRadius,True)
signedBranchGuardRadius=0.25*float(np.min(abs(F)))/5e5
results['branchGuarded']=solve('branchGuarded',keys,signedBranchGuardRadius,True)
# Compare the counterfactual in which apex motion is permitted only if the restrained charts cannot reach enough reserve.
if not results['preserved'].get('success') or results['preserved']['maxIncludedModelNorm']>tau-5e-9:
    results['free']=solve('free',keys,2e-12,False)
ans={'history':'Exact H44 after acceptance of 19/512','anchors':L,'currentResidualMPa':r.tolist(),'probeTauMPa':float(tau),
  'existingPoint8F_MPa':F[:,7].tolist(),'loadedProbeNormMPa':pk(r),'conditionalOnTransportedModels':True,'results':results}
fout=HERE/'ConstrainedCorrection.json'; fout.write_text(json.dumps(ans,indent=2)+'\n',encoding='utf8')
print(fout,sha256(fout.read_bytes()).hexdigest().upper())
