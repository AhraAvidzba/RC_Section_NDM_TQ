"""Export ordered ShearB inputs for a fresh replay without cold continuation."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def build(raw, verified, target_force):
    proof = json.loads(verified.read_text(encoding="utf-8"))
    assert proof["new_trace_sha256"] == digest(raw)
    lines = raw.read_bytes().decode("cp1251").splitlines()
    fields = [line.split(";") for line in lines if line.startswith("MVT2_CONTROL_FIELD;ShearB/Force")]
    targets = [line.split(";") for line in lines if line.startswith("MVT2_SHEAR_FORCE_TARGET;")]
    assert len(fields) == len(targets) == proof["replay_accepted_fields"] >= 2
    assert all(len(row) == 62 and row[1] == f"ShearB/Force{i}"
               for i, row in enumerate(fields, 1))
    assert all(len(row) == 10 and int(row[1]) == i
               for i, row in enumerate(targets, 1))
    assert float(targets[-2][2]) == float(targets[-1][2]) == 1.
    before, last = [float(target[3]) for target in targets[-2:]]
    assert before < last == proof["new_terminal"]["reached"]
    assert target_force > last
    previous, current = [list(map(float, field[2:])) for field in fields[-2:]]
    ratio = (target_force - last) / (last - before)
    increments = [current[i] - previous[i] for i in range(4)]
    length_mm = math.hypot(110., 110.)
    arg = {
        "source_trace_sha256": digest(raw),
        "source_verification_sha256": digest(verified),
        "field_coordinates_per_row": 60,
        "used_history_length": len(fields),
        "previous_and_last_Qy_kN": [before, last],
        "candidate_Qy_kN": target_force,
        "candidate_Mx_kNm": .6 * target_force,
        "candidate_torque_kNm": 10.51,
        "secant_ratio": ratio,
        "current_from_native_history": {
            "axial": current[0], "normalized_kx": current[1],
            "normalized_ky": current[2], "normalized_twist": current[3]
        },
        "unverified_control_targets": {
            "axial": current[0] + ratio * increments[0],
            "normalized_kx": current[1] + ratio * increments[1],
            "normalized_ky": current[2] + ratio * increments[2],
            "normalized_twist": current[3] + ratio * increments[3],
            "kappa_x_per_m": (current[1] + ratio * increments[1]) * 1000. / length_mm,
            "twist_rad_per_m": (current[3] + ratio * increments[3]) * 1000. / length_mm,
        },
        "largest_secant_increment_among_first_4": ["Axial", "Kx", "Ky", "Twist"][
            max(range(4), key=lambda i: abs(increments[i]))],
        "procedure": (
            "Read first used_history_length records and create one field (1 to 60) per accepted step. "
            "Recreate B material and geometry; ReplayAcceptedFields restores central and side histories. "
            "Before testing a new field, independently verify signed forces and weak/gauge/control "
            "residuals at the archived last load. Test force and separately control kappa/twist "
            "from the same history. The two mean shear projections have to be evaluated by the solver."
        ),
    }
    # Keep the digit strings produced by VBA. CSV units match LoadEquations.
    header = "index;offsetFraction;lambda;N_N;Mx_Nmm;My_Nmm;T_Nmm;Qx_N;Qy_N;"
    header += ";".join(f"q{i}" for i in range(1, 61))
    records = [";".join(target[1:] + field[2:]) for target, field in zip(targets, fields, strict=True)]
    return arg, "\n".join([header, *records]) + "\n"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--target-Qy", type=float, default=18.5720088671875)
    args = parser.parse_args()
    meta, table = build(args.root / "Native/ShearB.csv", args.root / "BisectionComparison.json", args.target_Qy)
    table_path = args.root / "MVT2ShearBReplay.csv"
    meta_path = args.root / "MVT2ShearBReplay.json"
    table_path.write_text(table, encoding="ascii", newline="\r\n")
    meta["replay_input_sha256"] = digest(table_path)
    meta_path.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(table_path, digest(table_path))
    print(meta_path, digest(meta_path))