"""Verify native closure and independently recompute signed six-effort equilibrium."""
from __future__ import annotations

import argparse
import csv
from hashlib import sha256
import json
from math import hypot, isclose, isfinite
from pathlib import Path

HERE = Path(__file__).resolve().parent
NATIVE = HERE / "Native"
MATERIAL = HERE / "IndependentCrackControl.json"
AREA_MM2, CHARACTERISTIC_ARM_MM = 240. ** 2, hypot(110., 110.)
ENERGY_MARKER = 1.e-6
TORQUE_GOALS = [5.2, 6.45, 6.49, 6.5, 6.51, 6.55, 7.8, 9.1, 9.45, 9.46, 9.47, 9.5, 10.4, 10.51]
SHEAR_GOALS = [0., 15., 22.11622, 25., 30.]
BASELINE = HERE.parent / "MVT2TurnV4/Native/MVT2.csv"
BASELINE_FIELDS = ["request", "reached", "N", "Mx", "My", "T", "Qx", "Qy", "eps0", "kx", "ky", "twist",
                   "gamma", "long_MPa", "hoop_MPa", "long_at_yield", "hoop_at_yield", "tension_energy",
                   "compression_energy", "min_principal", "max_principal", "residual"]

def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest().upper()

def data(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))

def read(path: Path) -> list[list[str]]:
    return list(csv.reader(path.read_text(encoding="cp1251").splitlines(), delimiter=";"))

def norm(row: dict, desired: list[float]) -> float:
    keys = ("N", "Mx", "My", "T", "Qx", "Qy")
    mom = {"Mx", "My", "T"}
    return max(abs(row[key] - value) * (1.e6 / CHARACTERISTIC_ARM_MM if key in mom else 1.e3) / AREA_MM2
               for key, value in zip(keys, desired))

def stage_result(route: str, rows: list[list[str]], physics: dict) -> dict:
    law, branch = route.split("/")
    case, = [row for row in rows if row[:2] == ["WANG_CRACK_CASE", route]]
    assert case[5] == "25"
    expected = [physics[f"{law}_ft_MPa"], physics["parameters"]["Gt_N_per_mm"], physics["parameters"]["Gc_N_per_mm"]]
    assert all(isclose(float(actual), value, abs_tol=1.e-13) for actual, value in zip(case[2:5], expected))
    endings = [row for row in rows if row[:2] == ["WANG_CRACK_END", route]]
    end, = endings
    status = [row for row in rows if row[:3] == ["WANG_PAIR_STATUS", law, branch]]
    assert status and float(end[2]) >= 0 and int(end[4]) > 0
    given_goals = TORQUE_GOALS if branch == "Torque" else SHEAR_GOALS
    assert [float(item[3]) for item in status] == given_goals[:len(status)]
    assert all(item[5] == "True" for item in status[:-1]), status
    complete = end[6] == "True"
    assert complete == (status[-1][5] == "True" and float(status[-1][3]) == given_goals[-1])
    solved = [dict(zip(BASELINE_FIELDS, map(float, row[2:]), strict=True)) for row in rows
              if row[:2] == ["MVT2_STATE", route]]
    assert int(end[3]) == len(solved) and solved
    assert len(solved) == len(status)
    damage_bracket, previous = None, 0.
    prior_tension = -1.
    nominal_offset = float(end[5])
    for index, (state, item) in enumerate(zip(solved, status, strict=True)):
        assert all(isfinite(value) for value in state.values())
        assert state["request"] == float(item[3]) and state["reached"] == float(item[4])
        accepted = state["reached"]  # The last accepted state can precede a requested failed step.
        applied = ([0., 0., 0., accepted, 0., 0.] if branch == "Torque" else
                   [0., 0.6 * accepted, 0., 10.51 * nominal_offset, 0., accepted])
        computed = norm(state, applied)
        assert abs(state["residual"] - computed) <= 5.e-12 and computed <= 5.e-6
        assert item[5] != "True" or accepted == state["request"]
        assert accepted >= previous
        assert state["tension_energy"] >= prior_tension - 1.e-10
        if branch == "Torque" and damage_bracket is None and state["tension_energy"] > ENERGY_MARKER:
            damage_bracket = [previous, accepted]
        if branch == "Torque" and state["tension_energy"] == state["compression_energy"] == 0.:
            slope = physics["native_25_point_tau_slope_MPa_per_kNm"]
            assert abs(state["max_principal"] - slope * accepted) < 1.e-5
        previous = accepted
        prior_tension = state["tension_energy"]
    if branch == "Shear" and law == "A":
        archive = [dict(zip(BASELINE_FIELDS, map(float, row[2:]), strict=True)) for row in read(BASELINE)
                   if row[:2] in (["MVT2_STATE", "Combined"], ["MVT2_STATE", "Offset"])]
        assert len(archive) == len(solved)
        for index, (actual, reference) in enumerate(zip(solved, archive, strict=True)):
            coordinates = {"request", "reached"} if index == 0 else {"request"}
            assert all(isclose(actual[key], value, abs_tol=2.e-10) for key, value in reference.items()
                       if key not in coordinates)
    return {
        "ft_MPa": float(case[2]), "elapsed_s": float(end[2]), "steps_trace": int(end[4]),
        "complete": complete, "terminal_external_status": status[-1][6], "terminal_code": int(status[-1][8]),
        "energy_marker": ENERGY_MARKER, "damage_marker_bracket_kNm": damage_bracket,
        "states": solved,
    }

def verify(mode: str) -> None:
    physics = data(MATERIAL)
    routes = {"Marker": ["A/Torque", "B/Torque"], "ShearA": ["A/Shear"], "ShearB": ["B/Shear"]}[mode]
    trace = NATIVE / f"{mode}.csv"
    report = NATIVE / f"{mode}.txt"
    process = data(NATIVE / f"{mode}.txt.ProcessClosure.json")
    assert process["Passed"] and process["Closure"]["FinalState"]["State"] == "Absent"
    receipt = data(NATIVE / f"{mode}.RunReceipt.json")
    assert receipt["native_exit"] == 0
    report_text = report.read_text(encoding="utf-8-sig")
    assert f"TOTAL_COUPLED_WANG_CRACK_SENSITIVITY: passed={len(routes)}; failed=0" in report_text
    assert "SOURCE_UNCHANGED: True" in report_text
    rows = read(trace)
    branch_reports = {route: stage_result(route, rows, physics) for route in routes}
    proof = {
        "stage": mode, "trace_sha256": digest(trace), "report_sha256": digest(report),
        "process_closed": process["Closure"]["FinalState"], "analytic_sha256": digest(MATERIAL),
        "wall_s": receipt["wall_seconds"], "routes": branch_reports,
        "limitations": "An accepted load path or a computed point-level damage marker does not establish section strength.",
    }
    result = HERE / f"{mode}.Verification.json"
    result.write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
    print(result, digest(result))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("Marker", "ShearA", "ShearB"))
    verify(parser.parse_args().mode)