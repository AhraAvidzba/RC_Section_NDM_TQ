"""Reconstruct the decisive ShearB load steps from the archived native trace."""
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
from zipfile import Path as ZipPath, ZipFile

BASELINE_CSV = "BD5523F13BDD0F5951300F0D68A3643291F755A974B14D26E5673C9CCB779B31"
BASELINE_CLOSURE = "8C01660D6D3EC1B254A3325938ACDA02EF8B6ABD39AEDAA327C6697FF733C775"
ROUNDOFF = 2.22044604925031e-16
INITIAL_STEPS = 8
MIN_STEP_RATIO = 0.015625
STEP_GROWTH = 1.5


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def statuses(path):
    rows = [line.split(";") for line in path.read_bytes().decode("cp1251").splitlines()]
    return [row for row in rows if row[0] == "WANG_PAIR_STATUS"], [
        row for row in rows if row[0] == "MVT2_STATE"
    ]


def simulate(start, target, outcomes, fixed):
    reached = start
    nominal = (target - start) / INITIAL_STEPS
    minimum = nominal * MIN_STEP_RATIO
    increment = nominal
    rows = []
    for accept in outcomes:
        remaining = target - reached
        if increment >= remaining:
            candidate = target
        else:
            candidate = reached + increment
            if candidate > reached and target - candidate <= target * ROUNDOFF:
                candidate = target
        assert candidate > reached
        scheduled = increment
        actual = candidate - reached
        attempted = (remaining if candidate == target else increment) if fixed else actual
        if accept:
            reached = candidate
            increment = increment * STEP_GROWTH if increment < nominal / STEP_GROWTH else nominal
        else:
            increment = attempted * 0.5
        rows.append({
            "accepted": accept,
            "candidate_kN": candidate,
            "scheduled_before_addition_kN": scheduled,
            "bisection_base_kN": attempted,
            "difference_of_ordinates_kN": actual,
            "scheduled_after_decision_kN": increment,
        })
        if reached == target or increment < minimum:
            break
    return nominal, minimum, increment, reached, rows


def verify(shear, turn):
    csv = shear / "Native/ShearB.csv"
    closure = shear / "Native/ShearB.txt.ProcessClosure.json"
    assert sha(csv) == BASELINE_CSV
    assert sha(closure) == BASELINE_CLOSURE
    closed = json.loads(closure.read_bytes().decode("utf-8-sig"))
    assert closed["Passed"] and closed["Closure"]["FinalState"]["State"] == "Absent"
    row, states = statuses(csv)
    assert len(row) == 3 and len(states) == 3
    assert row[-2][5:8] == ["True", "OK", "4"]
    stop = row[-1]
    assert stop[5:9] == ["False", "NumFail", "6", "10"]
    start, target, accepted = float(row[-2][4]), float(stop[3]), float(stop[4])
    diagnostics = ";".join(stop[11:])
    attempts = int(re.search(r"проб: (\d+)", diagnostics)[1])
    accepted_count = int(re.search(r"принято: (\d+)", diagnostics)[1])
    rejected_count = int(re.search(r"отклонено: (\d+)", diagnostics)[1])
    assert (attempts, accepted_count, rejected_count) == (10, 4, 6)
    assert attempts == accepted_count + rejected_count

    candidates = []
    for accepted_at in itertools.combinations(range(attempts), accepted_count):
        events = [i in accepted_at for i in range(attempts)]
        n, m, d, reached, rows = simulate(start, target, events, False)
        if reached == accepted and len(rows) == attempts and not rows[-1]["accepted"] and d < m:
            candidates.append((events, n, m, d, rows))
    assert len(candidates) == 1
    events, nominal, minimum, rounded, rows = candidates[0]
    assert events == [True] * 4 + [False] * 6
    _, _, corrected, candidate_reached, corrected_rows = simulate(start, target, events + [False], True)
    assert candidate_reached == accepted
    assert len(corrected_rows) == attempts + 1
    missing = corrected_rows[-1]["candidate_kN"]
    assert missing == accepted + minimum

    synthetic_old = simulate(18.55811, 25.67433, [False] * 8, False)
    synthetic_new = simulate(18.55811, 25.67433, [False] * 8, True)
    assert len(synthetic_old[-1]) == 6 and len(synthetic_new[-1]) == 7

    # The accepted B trace does not contain the 60-coefficient fields.
    # The A archive supplies an independent length scaling for the same section.
    lines = (turn / "Native/MVT2.csv").read_bytes().decode("cp1251").splitlines()
    base_values = next(row.split(";") for row in lines if row.startswith("MVT2_CONTROL_FIELD;Base;"))
    _, a_states = statuses(turn / "Native/MVT2.csv")
    shape = next(r for r in a_states if r[1] == "Combined" and r[3] == "27.62939453125")
    length_mm = 1000.0 * float(base_values[5]) / float(shape[13])
    assert math.isclose(length_mm, 155.56349186104, rel_tol=1e-9)

    last = states[-1]
    previous = states[-2]
    assert float(last[3]) == accepted and float(previous[3]) == start
    scale = (missing - accepted) / (accepted - start)
    twist_now = float(last[13])
    curvature_now = float(last[11])
    shear_now = float(last[14])
    twist_pred = twist_now + scale * (twist_now - float(previous[13]))
    curvature_pred = curvature_now + scale * (curvature_now - float(previous[11]))
    shear_pred = shear_now + scale * (shear_now - float(previous[14]))
    return {
        "inputs": {"shearB_csv_sha256": sha(csv), "shearB_closure_sha256": sha(closure),
                   "turnA_csv_sha256": sha(turn / "Native/MVT2.csv")},
        "native_terminal_segment": {
            "start_Qy_kN": start, "target_Qy_kN": target, "accepted_Qy_kN": accepted,
            "number_of_outcomes_checked": math.comb(attempts, accepted_count),
            "number_of_compatible_schedules": len(candidates),
            "nominal_kN": nominal, "minimum_kN": minimum,
            "original_schedule": rows, "first_skipped_candidate_Qy_kN": missing,
            "delta_rounded_minus_minimum_kN": rounded - minimum,
            "delta_rounded_minus_minimum_in_ULP": (rounded - minimum) / math.ulp(minimum),
            "last_trial_diagnostics": diagnostics,
        },
        "mock_vba_regression": {
            "start": 18.55811, "target": 25.67433, "initial_steps": INITIAL_STEPS,
            "original_rejections": len(synthetic_old[-1]), "retained_increment_rejections": len(synthetic_new[-1]),
            "last_probe": synthetic_new[-1][-1]["candidate_kN"],
        },
        "controlled_trial_seeds": {
            "scope": "Secants across archived accepted 15 and 18.55811 kN, used only as trial seeds",
            "same_section_shape_length_mm": length_mm,
            "at_Qy_kN": missing, "Mx_kNm": 0.6 * missing, "T_kNm": 10.51,
            "scale_of_observed_15_to_18_55811_secant": scale,
            "twist_rad_per_m": {"current": twist_now, "candidate": twist_pred},
            "normalized_q4": {"current": twist_now * length_mm / 1000., "candidate": twist_pred * length_mm / 1000.},
            "curvature_x_per_m": {"current": curvature_now, "candidate": curvature_pred},
            "normalized_q2": {"current": curvature_now * length_mm / 1000.,
                              "candidate": curvature_pred * length_mm / 1000.},
            "mean_gamma_y": {"current": shear_now, "candidate": shear_pred},
        },
        "limits": [
            "The skipped force trial has no archived outcome.",
            "The final rejected fixed-load probe contains no signed weak rows or per-point diagnostics.",
            "The most recent accepted ShearB fields and side histories must be exported from a new cold path.",
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("shear", nargs="?", type=Path)
    parser.add_argument("turn", nargs="?", type=Path)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.archive:
        assert args.shear is None and args.turn is None
        assert sha(args.archive) == "DEA4CCBB06ECCCECE9B076BF4D1B2ACA2DD7FCC4E84786FCE740FDFD6581FAB3"
        with ZipFile(args.archive) as packaged:
            root = ZipPath(packaged)
            proof = verify(root / "MVT2CrackSensitivity", root / "MVT2TurnV4")
    else:
        assert args.shear is not None and args.turn is not None
        proof = verify(args.shear, args.turn)
    rendered = json.dumps(proof, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8", newline="\n")
        print(args.output, sha(args.output))
    else:
        print(rendered, end="")