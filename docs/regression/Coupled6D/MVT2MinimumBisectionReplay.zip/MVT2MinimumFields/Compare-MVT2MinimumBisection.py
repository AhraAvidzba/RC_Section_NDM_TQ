"""Compare the cold ShearB route with the same archived workbook plus one class."""
import argparse
import json
import math
from pathlib import Path
import re
import runpy
from itertools import combinations

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / "MVT2CrackSensitivity"
TURN = HERE.parent / "MVT2TurnV4"
ARITHMETIC = runpy.run_path(str(HERE / "Verify-MVT2Minimum.py"))
digest = ARITHMETIC["sha"]
read_statuses = ARITHMETIC["statuses"]
simulate = ARITHMETIC["simulate"]
probe_old = ARITHMETIC["verify"]


def meta(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def schedule_at_minimum(previous, record, additional):
    """Identify the extra force trial if all compatible terminal schedules contain it."""
    diagnostics = ";".join(record[11:])
    matched = [re.search(r"\b" + key + r": (\d+)", diagnostics) for key in ("проб", "принято", "отклонено")]
    if not all(matched):
        return {"status": "No stage-level counters are available."}
    attempts, accepted, rejected = (int(item[1]) for item in matched)
    summary = {"attempts": attempts, "accepted": accepted, "rejected": rejected}
    if ("Не сошёлся минимальный подшаг" not in diagnostics or "Точная конечная проба" in diagnostics
            or "секущим прогнозом" in diagnostics or attempts != accepted + rejected):
        return {**summary, "status": "A unique ordinary bisection terminal schedule is not established."}
    size = math.comb(attempts, accepted)
    if size > 100_000:
        return {**summary, "status": "The archived counters are insufficient to bound the terminal schedule."}
    reached = float(record[4])
    target = float(record[3])
    start = float(previous[4])
    near = lambda a, b: abs(a-b) <= 8 * max(math.ulp(a), math.ulp(b))
    candidates = []
    inclusion = []
    for chosen in combinations(range(attempts), accepted):
        outputs = [j in chosen for j in range(attempts)]
        n, minimum, next_step, actual_end, rows = simulate(start, target, outputs, True)
        if (near(actual_end, reached) and len(rows) == attempts
                and not rows[-1]["accepted"] and next_step < minimum
                and target - actual_end > n):
            candidates.append(rows)
            inclusion.append([item["accepted"] for item in rows if near(item["candidate_kN"], additional)])
    return {
        **summary,
        "statuses_examined": size,
        "compatible_schedules": len(candidates),
        "scheduled_extra_force_Qy_kN": additional,
        "proven_extra_force_was_tried": bool(candidates and all(matches for matches in inclusion)),
        "proven_extra_force_was_accepted": bool(candidates and all(True in matches for matches in inclusion)),
        "schedule_if_unique": candidates[0] if len(candidates) == 1 else None,
    }


def compare(repo, portable=False):
    before_meta = meta(HERE / "Preparation.json")
    compiler = meta(HERE / "docs/regression/CodeUpdate.json")
    closure = meta(HERE / "CompileClosure.json")
    assert compiler["Compiled"] and not compiler["ProductionChanged"]
    assert set(compiler["Modules"]) == {before_meta["only_updated_module"], before_meta["only_updated_test_module"]}
    assert compiler["ProductionSHA256"] == before_meta["book_sha256"]
    if portable:
        owner = meta(HERE / "Native/ShearB.txt.Ownership.json")
        process = meta(HERE / "Native/ShearB.txt.ProcessClosure.json")["Closure"]["FinalState"]
        assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"]
        assert owner["SourceSHA256"] == compiler["WorkbookSHA256"]
        assert owner["PID"] == process["PID"] and owner["StartTicksUTC"] == process["StartTicksUTC"]
        assert process["State"] == "Absent" and closure["PID"] != process["PID"]
    else:
        assert compiler["WorkbookSHA256"] == digest(HERE / "docs/regression/Diagnostic.xlsm")
    assert closure["State"] == "Absent"
    before = meta(PRIOR / "ShearB.Verification.json")
    after = meta(HERE / "ShearB.Verification.json")
    assert before["trace_sha256"] == digest(PRIOR / "Native/ShearB.csv")
    assert after["trace_sha256"] == digest(HERE / "Native/ShearB.csv")
    assert before["process_closed"]["State"] == after["process_closed"]["State"] == "Absent"
    assert after["analytic_sha256"] == before["analytic_sha256"]
    assert before["routes"]["B/Shear"]["ft_MPa"] == after["routes"]["B/Shear"]["ft_MPa"]
    row, _ = read_statuses(HERE / "Native/ShearB.csv")
    old_data = probe_old(PRIOR, TURN)
    required_force = old_data["native_terminal_segment"]["first_skipped_candidate_Qy_kN"]
    comparison = {}
    for tag, candidate in enumerate(row):
        if float(candidate[3]) == 22.11622 and tag > 0:
            comparison = schedule_at_minimum(row[tag-1], candidate, required_force)
    bstates, astates = [item["routes"]["B/Shear"]["states"] for item in (before, after)]
    expected = ("N", "Mx", "My", "T", "Qx", "Qy")
    common = []
    for old in bstates:
        for new in astates:
            if old["reached"] == new["reached"]:
                common.append({"Qy_kN": old["reached"],
                               "signed_6_efforts_change": [new[key] - old[key] for key in expected],
                               "all_summary_fields_equal": all(new[key] == old[key] for key in old if key != "request")})
    final = {
        "class_commit": before_meta["source_commit"],
        "updated_production_component": before_meta["only_updated_module"],
        "fixture_before_compilation_sha256": before_meta["diagnostic_before_sha256"],
        "fixture_after_compilation_sha256": compiler["WorkbookSHA256"],
        "preload_and_load_segments_same_material_ft_MPa": after["routes"]["B/Shear"]["ft_MPa"],
        "new_trace_sha256": after["trace_sha256"],
        "old_trace_sha256": before["trace_sha256"],
        "head_continue_class_sha256": digest(repo / "src/Solver/CCoupledLoadContinuation.cls"),
        "old_terminal": {**bstates[-1], "code": before["routes"]["B/Shear"]["terminal_code"]},
        "new_terminal": {**astates[-1], "code": after["routes"]["B/Shear"]["terminal_code"]},
        "old_wall_s": before["wall_s"],
        "new_wall_s": after["wall_s"],
        "actual_common_equal_Qy_states": common,
        "reconstruction_of_new_terminal_segment": comparison,
        "limits": (
            "The data show solver outcomes under unchanged physical inputs. "
            "Continuation of an accepted force route or its numerical failure does not identify the physical capacity. "
            "No unarchived weak residual or material station is assigned as the cause."
        )
    }
    all_rows = (HERE / "Native/ShearB.csv").read_bytes().decode("cp1251").splitlines()
    fields = [x.split(";") for x in all_rows if x.startswith("MVT2_CONTROL_FIELD;ShearB/Force")]
    path = [x.split(";") for x in all_rows if x.startswith("MVT2_SHEAR_FORCE_TARGET;")]
    assert len(fields) == len(path) == after["routes"]["B/Shear"]["steps_trace"]
    last_offset, last_lambda = 0., 0.
    for i, (field, target) in enumerate(zip(fields, path, strict=True), 1):
        assert field[1] == f"ShearB/Force{i}" and int(target[1]) == i
        assert len(field) == 62 and len(target) == 10
        assert all(math.isfinite(float(item)) for item in field[2:] + target[2:])
        offset, load = map(float, target[2:4])
        assert last_offset <= offset <= 1. and last_lambda <= load
        assert (offset > last_offset) != (load > last_lambda)
        assert load == 0. or offset == 1.
        assert all(math.isclose(float(actual), exact, rel_tol=2e-14, abs_tol=1e-12)
                   for actual, exact in zip(target[4:], [0., 600000.*load, 0., 10510000.*offset, 0., 1000.*load], strict=True))
        last_offset, last_lambda = offset, load
    assert last_lambda == astates[-1]["reached"]
    final["replay_accepted_fields"] = len(fields)
    final["replay_last_offset_fraction"] = last_offset
    final["replay_last_lambda_kN"] = last_lambda
    result = HERE / "BisectionComparison.json"
    result.write_text(json.dumps(final, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(result, digest(result))
    print("terminal old/new:", final["old_terminal"]["reached"], final["new_terminal"]["reached"])
    print("terminal code old/new:", final["old_terminal"]["code"], final["new_terminal"]["code"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("--portable", action="store_true")
    args = parser.parse_args()
    compare(args.repo.resolve(strict=True), args.portable)