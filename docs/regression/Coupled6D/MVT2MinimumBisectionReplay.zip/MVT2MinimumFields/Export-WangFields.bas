
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает сохранённые поля и заданные усилия после завершения опытной ветви.
Private Sub ExportWangShearFieldsTest(ByVal branch As CCoupledLoadContinuation, ByVal path As CLoadPathVector, _
        ByRef report As String, ByVal tracePath As String)
    Dim trace As CCoupledLoadTrace: Set trace = branch.SavedTrace
    If trace Is Nothing Then Err.Raise 5, , "История нагрузок ShearB не записана."
    If trace.Count <> branch.SavedFieldCount Then Err.Raise 5, , "Истории ShearB имеют разную длину."
    Dim j As Long, k As Long, offsetFraction As Double, loadFactor As Double
    Dim constantValues() As Double, variableValues() As Double, values() As Double, row As String
    path.Components constantValues, variableValues
    For j = 1 To trace.Count
        trace.ReadPoint j, offsetFraction, loadFactor
        branch.CopySavedField j, values
        If UBound(values) <> 60 Then Err.Raise 5, , "Поле ShearB не содержит 60 координат."
        row = "MVT2_SHEAR_FORCE_TARGET;" & CStr(j) & ";" & ExperimentNumberTest(offsetFraction) & ";" & ExperimentNumberTest(loadFactor)
        For k = 1 To 6
            row = row & ";" & ExperimentNumberTest(constantValues(k) * offsetFraction + variableValues(k) * loadFactor)
        Next k
        AddExperimentTraceTest report, tracePath, row
        AppendWangFieldTest report, tracePath, "ShearB/Force" & CStr(j), values
    Next j
End Sub