from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

here = Path(__file__).resolve().parent
run = here / "MVT2MinimumFields"
manifest = json.loads((here / "Manifest.json").read_text(encoding="utf-8"))
def digest(p):
    return sha256(p.read_bytes()).hexdigest().upper()
for name, expected in manifest.items():
    assert digest(here / name) == expected, name
def execute(name, *args):
    subprocess.run([sys.executable, "-B", "-X", "utf8", str(run / name), *args], check=True)
execute("Verify-MVT2CrackSensitivity.py", "ShearB")
execute("Compare-MVT2MinimumBisection.py", str(run), "--portable")
execute("Build-MVT2FieldReplay.py", str(run))
for name in ("ShearB.Verification.json", "BisectionComparison.json", "MVT2ShearBReplay.csv", "MVT2ShearBReplay.json"):
    assert digest(run / name) == manifest[f"MVT2MinimumFields/{name}"], name
print("PASS native receipts and archived fields; four outputs reproduced byte-for-byte")
