"""Независимо проверяет поля, усилия и историю стали на четырёх траекториях MVT2."""

from argparse import ArgumentParser
from hashlib import sha256
from math import fsum, isfinite
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import gzip
import json
import runpy
import sys


HERE = Path(__file__).resolve().parent
ASD = 'MVT2GaussReequilibratedASD20261117.zip'
STEEL = 'MVT2GaussASDNominalPostyield20261117.zip'
INPUTS = {
    ASD: 'FB4F9F3ED9D83FE121B700E41752A16405C63123DADC46F28C5D6743CAC5D50E',
    STEEL: '06A04F304206A58E5CB1B5527B57A1AED030E017C70C7D625B0C0CA9BBDD98ED',
    'operators': '3E8C00B7AC650B9FF6BBF55C412AED9A18A258BCEE3083D58ECEA9B7A07B653A',
    'paper': '6CAACE6AE16B06F76D16549D0B1CDBC6DF12B4738FE326D0A3091B6098CBFF3E',
}
CASES = {
    'Cut388': (388., 40, 76562.5, 77500., 76640.625, False,
               '8E2F3CB0E1F831F44B59A8CDD5583E98C6201B3B59A788455B69389A2837E2D2',
               '23E83C3B86D00BBBDDDC4175B4DA2D20577D6E17BCA4084C2B845F52F8BF2CB5'),
    'Cut396': (396., 41, 75312.5, 77500., 75390.625, False,
               '49A81555895A9EF8CBE8FFB556C18E0B3787534D64472F5F6D9FD7C8819E7DD5',
               'AA9854552579E985379A7EA2589EC1A6DBF25A1BE8FD8FB4CD6097BD4DEA48A5'),
    'Cut396Fine': (396., 40, 75000., 75078.125, 75002.44140625, True,
                   'CF284CAB142465ED6ACC4F49FD1998AB4A09E79212F4BAF73AFDFAB9070ED763',
                   '64C6BF202F7CD69DE23E5F706753D42D7504DB7DCFB7E33CC6D84F2F887246BE'),
    'Cut404': (404., 39, 72500., 75000., 72578.125, False,
               '84F94F3AF078C574AB3602D31753111952E65A8D2E3375D66A3BBF0C44E361DF',
               '181DF0DBFBA8A3A5AE4841CD25BB8419F332817A857991B9EE1A238E1B784294'),
}
TORQUE = 10510000.


def pinned(path, expected):
    """Возвращает архивные байты после проверки SHA-256."""
    data = path.read_bytes()
    assert sha256(data).hexdigest().upper() == expected, path.name
    return data


def equilibrium(field, net, arm, operators, geometry, area, length, signed):
    """Восстанавливает 56 уравнений равновесия, четыре связи и силы со знаками."""
    x = field['field']
    assert len(x) == 60 and all(map(isfinite, x))
    assert len(net) == 3 and all(len(line) == 45 for line in net)
    assert all(len(tensor) == 6 and all(map(isfinite, tensor)) for side in net for tensor in side)
    q = field['Q_target_N']
    target = (0., -arm * q, 0., field['T_target_Nmm'], 0., q)
    applied = [fsum(col[j] * value for col, value in zip(operators['L'], target, strict=True))
               for j in range(60)]
    slope = [[500. * (a - b) for a, b in zip(p, m, strict=True)]
             for p, m in zip(net[1], net[2], strict=True)]
    residual = []
    for j in range(60):
        center = (row[j] * stress for block, point in zip(operators['S'], net[0], strict=True)
                  for row, stress in zip(block, point, strict=True))
        gradient = (row[j] * stress for block, point in zip(operators['R'], slope, strict=True)
                    for row, stress in zip(block, point, strict=True))
        gauge = (a * b for a, b in zip(operators['G'][j], x, strict=True))
        residual.append(fsum((*center, *gradient, *gauge)) - applied[j])
    weak = max(map(abs, residual[:56]))
    constraint = 30000. * max(map(abs, residual[56:]))
    forces = tuple(signed(net[0], geometry))
    assert all(abs(a - b) < 3e-8 for a, b in zip(forces, field['resultants_N_Nmm'], strict=True))
    measure = (area, area * length, area * length, area * length, area, area)
    force = max(abs(a - b) / r for a, b, r in zip(forces, target, measure, strict=True))
    aggregate = max(weak, constraint, force)
    tolerance = 5e-7 + 5e-7 * max(map(abs, applied))
    assert abs(tolerance - field['tolerance_MPa']) < 3e-15 and aggregate <= tolerance
    assert abs(aggregate - field['all_weak_and_force_max_MPa']) < 3e-12
    assert abs(weak - field['weak_norm_MPa']) < 3e-12 and abs(constraint - field['gauge_scaled_norm_MPa']) < 3e-12
    assert abs(field['twist_rad_per_m'] - 1000. * x[3] / length) < 1e-17
    return aggregate


def steel_history(states, stress, steel, op, dirs, base):
    """Решает одномерный возврат стали на каждой станции и контролирует бетонные экстремумы."""
    prior = [[0.] * 20 for _ in range(3)]
    max_stress_error = 0.
    first_yield = {}
    last = {}
    for state, net, snapshot in zip(states, stress, steel, strict=True):
        cement_strain, cement_stress = [], []
        maximum = {'longitudinal_MPa': 0., 'hoop_MPa': 0.}
        for station, (side, rows) in enumerate(zip((0, 1, -1),
                snapshot['columns_strain_stress_tangent_plastic_backstress_increment'], strict=True)):
            assert len(rows) == 20
            for point in range(25):
                values = base['tensor'](op, state['field'], point, side)
                cement_strain.append(base['minimum_eigen'](values, True))
                cement_stress.append(base['minimum_eigen'](net[station][point], False))
            for k, row in enumerate(rows):
                point = k + 25
                plotted, observed, tangent, plastic, backstress, increment = row
                local = base['tensor'](op, state['field'], point, side)
                eps = fsum(a * b for a, b in zip(local, dirs[point], strict=True))
                assert abs(plotted - eps) < 5e-18 and abs(eps) < .05
                limit, group = (498., 'longitudinal') if point < 29 else (450., 'hoop')
                trial = 200000. * (eps - prior[station][k])
                recovered = min(limit, max(-limit, trial))
                p_new = eps - recovered / 200000.
                assert abs(recovered - observed) < 4e-11 and abs(p_new - plastic) < 2e-17
                assert abs(increment - (p_new - prior[station][k])) < 2e-17
                assert tangent == (0. if abs(trial) > limit else 200000.) and backstress == 0.
                if tangent == 0.:
                    first_yield.setdefault(group, {'Qy_N': state['Q_target_N'], 'point': point + 1, 'side': side})
                max_stress_error = max(max_stress_error, abs(recovered - observed))
                maximum[group + '_MPa'] = max(maximum[group + '_MPa'], abs(observed))
                prior[station][k] = plastic
        assert abs(min(0., *cement_strain) - snapshot['minimum_concrete_principal_strain']) < 5e-16
        assert abs(min(cement_stress) - snapshot['minimum_concrete_principal_stress_MPa']) < 1e-10
        last = {**maximum, 'minimum_concrete_principal_strain': snapshot['minimum_concrete_principal_strain'],
                'minimum_concrete_principal_stress_MPa': snapshot['minimum_concrete_principal_stress_MPa']}
    return {'updates_checked': len(states) * 60, 'max_point_stress_error_MPa': max_stress_error,
            'first_yield': first_yield, 'last': last}


def check_batch(name, cfg, reference, operators, geometry, dirs, area, length, auth, steel, identity):
    """Проверяет закреплённую последовательность принятых и отклонённых проб."""
    arm, count, q_last, q_requested, q_failed, fine, report_sha, stress_sha = cfg
    data = json.loads(pinned(HERE / (name + '.json'), report_sha))
    tensors = json.loads(gzip.decompress(pinned(HERE / (name + '.stress.json.gz'), stress_sha)))
    assert data['inputs'] == INPUTS and data['operators'] == identity
    assert data['arm_mm'] == arm and data.get('fine_tail', False) is fine
    assert data['stress_sha256'] == stress_sha and data['original_torsion_prefix_bit_exact'] == 8
    assert (data['ASD_engine'], data['numpy']) == ('3.8.0', '2.3.5')
    assert not data['physical_limit_established']
    grid = list(range(2500, 80001, 2500))
    if fine:
        grid = [*range(2500, 75001, 2500), *(75000. + 5000. * i / 64. for i in range(1, 65))]
    assert data['requested_Qy_N'] == [*grid, 82340.]
    run = data['result']
    assert run['status'] == 'numerical_stop' and not run['physical_limit_established']
    assert not run['complete_nominal_targets'] and run['rejected_trial_interleaving_max_MPa'] == 0.
    states, stress, rows = run['accepted'], tensors['stress'], tensors['steel']
    assert len(states) == len(stress) == len(rows) == count
    equal = steel['arrays_equal']
    assert equal(states[:8], reference[0]) and equal(stress[:8], reference[1])
    assert all(s['Q_target_N'] == 0. for s in states[:8])
    assert all(s['T_target_Nmm'] == TORQUE for s in states[8:])
    assert all(a['Q_target_N'] < b['Q_target_N'] for a, b in zip(states[8:], states[9:]))
    assert run['last_confirmed'] == [TORQUE, q_last] and states[-1]['Q_target_N'] == q_last
    terminal = run['terminal']
    assert terminal['reason'] == 'bounded_numerical_stop'
    assert terminal['last_reached_Q_N'] == q_last and terminal['Q_requested_N'] == q_requested
    assert terminal['last_reached_T_Nmm'] == terminal['T_requested_Nmm'] == TORQUE
    committed = 0
    for attempt in run['attempts']:
        assert attempt['from_commits'] == committed
        if attempt.get('status') == 'balanced':
            target = states[committed]
            assert all(attempt[k] == target[k] for k in (
                'Q_target_N', 'T_target_Nmm', 'all_weak_and_force_max_MPa', 'resultants_N_Nmm'))
            committed += 1
    failed = run['attempts'][-1]
    assert committed == count and failed['Q_N'] == q_failed and q_last < q_failed <= q_requested
    assert failed['T_Nmm'] == TORQUE and failed['kind'] == 'line_search_no_decrease'
    norms = [equilibrium(s, n, arm, operators, geometry, area, length, auth['signed_forces'])
             for s, n in zip(states, stress, strict=True)]
    history = steel_history(states, stress, rows, operators, dirs, steel)
    result = {'arm_mm': arm, 'accepted_fields': count, 'requested_Qy_N': q_requested,
              'last_Qy_N': q_last, 'failed_trial_Qy_N': q_failed,
              'last_Mx_target_Nmm': -arm * q_last, 'last_twist_rad_per_m': states[-1]['twist_rad_per_m'],
              'maximum_equilibrium_MPa': max(norms), 'last_equilibrium_MPa': norms[-1],
              'rejected_trial_MPa': failed['weak_or_forces_norm_MPa'], 'steel': history}
    return result, states, tensors


def verify(repo):
    """Распаковывает закреплённые операторы и сравнивает четыре истории."""
    directory = repo / 'docs/regression/Coupled6D'
    pinned(repo / 'literature/Coupled6D/Wang-Huang-2017-MVT-NMVT.pdf', INPUTS['paper'])
    pinned(directory / ASD, INPUTS[ASD])
    pinned(directory / STEEL, INPUTS[STEEL])
    with TemporaryDirectory(prefix='MVT2_CutOffline_') as temp:
        scratch = Path(temp)
        with ZipFile(directory / ASD) as archive, ZipFile(directory / STEEL) as post:
            for source in ('Verify-Authoritative.py', 'Operators.py', 'Reequilibrate.py'):
                (scratch / source).write_bytes(archive.read(source))
            (scratch / 'Verify-Postyield.py').write_bytes(post.read('Verify-Postyield.py'))
            prefix = (json.loads(archive.read('Authoritative.json'))['modes']['default']['accepted'][:8],
                      json.loads(gzip.decompress(archive.read('Authoritative.stress.json.gz')))['default'][:8])
            metadata = json.loads(post.read('Postyield.json'))['original_steel']
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(scratch))
        auth = runpy.run_path(str(scratch / 'Verify-Authoritative.py'))
        steel = runpy.run_path(str(scratch / 'Verify-Postyield.py'))
        steel['source'](repo, 'CCoupledSteelModel', metadata['native_model_sha256'])
        steel['source'](repo, 'CCoupledReinforcedResponse', metadata['native_reinforced_response_sha256'])
        assert (metadata['Es_MPa'], metadata['longitudinal_yield_MPa_both_signs'],
                metadata['hoop_yield_MPa_both_signs'], metadata['tangent_MPa_after_yield_both_signs'],
                metadata['strain_limit_both_signs']) == (200000., 498., 450., 0., .05)
        operators, helper = auth['unpack'](scratch, repo)
        pinned(operators, INPUTS['operators'])
        engine = runpy.run_path(str(scratch / 'Reequilibrate.py'))
        _, _, geometry, dirs, area, length, op, _, _, identity = engine['read_inputs'](operators, scratch, helper)
        cases = {name: check_batch(name, cfg, prefix, op, geometry, dirs, area, length, auth, steel, identity)
                 for name, cfg in CASES.items()}
        _, nominal_states, nominal_net = cases['Cut396']
        _, fine_states, fine_net = cases['Cut396Fine']
        equal = steel['arrays_equal']
        assert len(fine_states) == 40 and fine_states[-1]['Q_target_N'] == 75000.
        assert equal(nominal_states[:40], fine_states)
        assert all(equal(nominal_net[key][:40], fine_net[key]) for key in ('steel', 'stress'))
        for _, _, net in cases.values():
            assert equal(nominal_net['steel'][:8], net['steel'][:8])
        sys.path.pop(0)
    return {'geometry_inputs': identity, 'identical_pure_torque_fields': 8,
            'nominal_fine_identical_fields': 40, 'nominal_fine_identical_through_Qy_N': 75000.,
            'physical_limit_established': False,
            'accepted_fields': sum(entry[0]['accepted_fields'] for entry in cases.values()),
            'cases': {name: entry[0] for name, entry in cases.items()}}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    checked = verify(args.repo.resolve())
    with args.report.open('x', encoding='utf-8', newline='\n') as file:
        json.dump(checked, file, indent=2, sort_keys=True, allow_nan=False)
        file.write('\n')
    print('MVT2 PUBLICATION CUT OFFLINE PASS')
