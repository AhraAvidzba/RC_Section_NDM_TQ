"""Сопоставляет смену касательной и непрерывность невязки в вершинах HardShear."""

import argparse
from collections import Counter
from hashlib import file_digest
import json
from math import fsum, hypot, isfinite
from pathlib import Path
import re
from struct import unpack
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
SWITCH = "HardShearMaterialSwitchNative20261117.zip"
RANK = "HardShearTangentRankNative20261117.zip"
SHOULDERS = "HardShearRefinedShouldersNative20261116.zip"
H21 = "HardShearSameControlH21Native20261117.zip"
RELEASE = "MVT2ArcRecoveryWorkbookRelease20261117.zip"
ARCHIVES = {
    SWITCH: "CF482DA9F7A9DCE0AE93EE4E49EAC86B021B5DBB2582D27C67C59B5BB406B48F",
    RANK: "4A979BC575689E5A42CCA0A54D3ECD521C67B9E27CA3729BC076C17A57E9E5FE",
    SHOULDERS: "BC008874E70D1D35EC6CE8DB8CD71BED41560DB49FDD936E73C175545E7282D5",
}


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest().upper()


def member(path, suffix):
    with ZipFile(path) as pack:
        name, = (name for name in pack.namelist() if name.endswith(suffix))
        return pack.read(name)


def double(raw):
    value, = unpack(">d", bytes.fromhex(raw))
    assert isfinite(value)
    return value


def dot(a, b):
    return fsum(x * y for x, y in zip(a, b, strict=True))


def diff(a, b):
    return [x - y for x, y in zip(a, b, strict=True)]


def projectors(matrix, mechanical):
    """Ортогональные направления четырёх линейных связей в механических координатах."""
    rows = []
    for row in matrix[mechanical:]:
        origin = row[:mechanical]
        current = origin
        for _ in range(2):
            for basis in rows:
                current = diff(current, [dot(current, basis) * value for value in basis])
        length = hypot(*current)
        assert length > 1e-6 * hypot(*origin)
        rows.append([value / length for value in current])
    assert all(abs(dot(row, other)) < 8e-15 for i, row in enumerate(rows) for other in rows[:i])
    return rows


def free(vector, rows):
    return [value - fsum(dot(vector, row) * row[index] for row in rows) for index, value in enumerate(vector)]


def parse(raw):
    result = {}
    active = None
    for row in raw.decode("ascii").splitlines():
        tag, *values = row.split(";")
        if tag == "HARDSHEAR-SWITCH":
            assert values == ["1"]
        elif tag == "BEGIN":
            assert active is None
            name, preceding, gauge, modulus, factor, target = values
            active = {"label": name, "history_before": int(preceding), "mechanical": int(gauge) - 1,
                      "modulus": double(modulus), "factor": double(factor), "control": double(target),
                      "matrix": [], "sample": {}, "stations": {}}
        elif tag == "END":
            name, = values
            assert active["label"] == name and name not in result
            result[name], active = active, None
        elif tag == "K":
            assert int(values[0]) == len(active["matrix"]) + 1
            active["matrix"].append(list(map(double, values[1:])))
        elif tag == "FD":
            step, *residual = map(double, values)
            active["sample"][step] = residual
        elif tag == "STATIONS":
            step, count = double(values[0]), int(values[1])
            stations = active["stations"][step] = {}
            assert count == 43
        elif tag == "STATION":
            point, side, ok, trial, plastic, principal, divisions = values
            assert ok == "ok" and (int(point), int(side)) not in stations
            stations[int(point), int(side)] = double(trial), plastic == "True", int(principal), int(divisions)
        else:
            assert tag in {"FIELD", "FORCE", "MEASURED", "BASE", "DIRECTION", "PROJECTION", "TANGENT"}
            assert tag not in active
            active[tag] = list(map(double, values))
    assert active is None and set(result) == {"Stock-2", "Short4-4"}
    return result


def assess(peak, rank):
    n = peak["mechanical"]
    assert n == 56 and len(peak["matrix"]) == 60 == len(peak["FIELD"])
    row_space = projectors(peak["matrix"], n)
    tangent = peak["TANGENT"][:-1]
    length = max(map(abs, tangent[:n]))
    direction = [coordinate / length for coordinate in tangent]
    pressure_change = [dot(row, direction) for row in peak["matrix"][:n]]
    smooth = free(pressure_change, row_space)
    all_steps = (-2.5e-11, -8e-12, -5e-12, -1.5e-12, 1.5e-12, 5e-12, 8e-12, 2.5e-11)
    assert set(peak["sample"]) == set(all_steps)
    station = (22, -1)
    for t in (0., *all_steps):
        sampled = peak["stations"][t]
        base = peak["stations"][0.]
        assert len(sampled) == len(base) == 3 * 43
        changed = [point for point, values in sampled.items() if (values[0] > 0., *values[1:]) !=
                   (base[point][0] > 0., *base[point][1:])]
        assert changed == ([station] if t >= 8e-12 else [])
        assert sampled[station][2:] == (1, 1)
        assert sampled[station][1] is (t >= 8e-12)

    def excess(step):
        held = diff(peak["sample"][step][:n], peak["BASE"][:n])
        return diff(free(held, row_space), [step * force for force in smooth])

    lo, hi, nxt = 5e-12, 8e-12, 2.5e-11
    f0, f1 = [peak["stations"][h][station][0] for h in (lo, hi)]
    trial_slope = (f1 - f0) / (hi - lo)
    material_kink = lo - f0 / trial_slope
    left, right = excess(hi), excess(nxt)
    derivative_change = [value / (nxt - hi) for value in diff(right, left)]
    joint_floor = max(hypot(*excess(t)) for t in all_steps if t <= lo)
    intersection = hi - dot(left, derivative_change) / dot(derivative_change, derivative_change)
    offset = [a + (material_kink - hi) * b for a, b in zip(left, derivative_change, strict=True)]
    contact = hypot(*offset)
    glue = hypot(*(a + (intersection - hi) * b for a, b in zip(left, derivative_change, strict=True)))
    material_fit = max(abs(peak["stations"][h][station][0] - (f0 + (h - lo) * trial_slope)) for h in (0., *all_steps))
    gain = hypot(*derivative_change) / hypot(*smooth)
    changed_vector = hypot(*left)
    assert lo < material_kink < hi and lo < intersection < hi
    assert gain > 100. and contact < changed_vector / 10000.
    assert glue <= joint_floor
    control_change = dot(peak["PROJECTION"], direction)
    assert control_change > 0.
    return {"record": peak["label"], "accepted_history_before_trial": peak["history_before"], "lambda": peak["factor"],
            "control": peak["control"], "station": list(station), "material_substeps_on_both_sides": 1,
            "observed_signed_step_bracket": [lo, hi], "trial_surface_zero_from_its_own_samples": material_kink,
            "independent_continuity_step_from_net_projected_residual": intersection,
            "difference_in_step": abs(material_kink - intersection),
            "coordinate_equivalent_test_interval_after_peak": [control_change * lo, control_change * hi],
            "coordinate_equivalent_width": control_change * (hi - lo),
            "left_projected_tangent_action_norm_MPa_per_unit_step": hypot(*smooth),
            "derivative_change_norm_MPa_per_unit_step": hypot(*derivative_change),
            "derivative_change_over_left_action": gain,
            "switched_excess_norm_at_8e_12_MPa": changed_vector,
            "extrapolated_projected_residual_gap_at_yield_MPa": contact,
            "extrapolated_gap_per_switched_excess": contact / changed_vector,
            "unexplained_orthogonal_gap_at_residual_intersection_MPa": glue,
            "largest_unswitched_observed_linearization_gap_MPa": joint_floor,
            "trial_yield_linearity_deviation_MPa": material_fit,
            "largest_trial_residual_coordinate_on_first_switched_probe_MPa": max(map(abs, peak["sample"][hi][:n])),
            "largest_base_weak_residual_coordinate_MPa": max(map(abs, peak["BASE"][:n])),
            "archive_projected_force_sigma_min_MPa": rank[peak["label"]]["projected_force_control_sigma_min"],
            "archived_bordered_dlambda_dc_before_transition": peak["TANGENT"][-1],
            "tested_direction_only": True}, derivative_change


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives", type=Path, default=REPO / "docs/regression/Coupled6D")
    parser.add_argument("--output", type=Path, default=HERE / "Verification.json")
    args = parser.parse_args()
    full_names = (*ARCHIVES, H21, RELEASE)
    hashes = {file: digest(args.archives / file) for file in full_names}
    assert all(hashes[key] == value for key, value in ARCHIVES.items())
    cases = parse(member(args.archives / SWITCH, "Native/HardSwitch.csv"))
    rank = json.loads(member(args.archives / RANK, "Native/Verification.json"))
    native_rank = {case["case"]: case for case in rank["cases"]}
    work = [assess(peak, native_rank) for peak in cases.values()]
    first, second = [vector for _, vector in work]
    cosine = dot(first, second) / (hypot(*first) * hypot(*second))
    assert cosine > 0.99
    shoulders = json.loads(member(args.archives / SHOULDERS, "Native/Verification.json"))
    arms = [{"case": arm["id"][0], "complete": arm["completed_shoulder"],
             "lambda_intervals": [row["sample_lambda_interval"] for row in arm["robust_local_samples"]],
             "signed_margins": [row["signed_margin"] for row in arm["robust_local_samples"]]} for arm in shoulders["arms"]]
    assert all(len(case["signed_margins"]) == 1 and case["signed_margins"][0] > 1e-4 for case in arms)
    recovery = json.loads(member(args.archives / H21, "Native/Verification.json"))
    h21 = recovery["cases"]["D"]
    assert h21["certified_at_original_target"] and h21["weak_residual_MPa"] < h21["tolerance_MPa"]
    native = member(args.archives / RELEASE, "Native/Both.txt").decode("utf-8-sig")
    summary, = re.findall(r"^TIMING_STATES: ([^\r\n]+)", native, flags=re.M)
    assert summary.startswith("direct=OK; capacity=NumFail; confirmed lower=1.10290889219566; limit=;")
    report = {"archive_sha256": hashes, "locally_resolved_shoulder_samples": arms,
              "same_direction_gap_tests": [case for case, _ in work], "cosine_of_slope_change_between_peaks": cosine,
              "H21": {"lambda": h21["factor"], "steel_usage": h21["steel_usage"],
                      "original_control": h21["original_projection_coordinate"],
                      "normalized_residual_MPa": h21["weak_residual_MPa"],
                      "scope": "different later right-shoulder probe"},
              "current_installed_workbook_status": summary,
              "boundary_widths_from_unequilibrated_perturbations": True,
              "orthogonal_misfit_at_response_intersection_below_same_branch_floor": True,
              "small_parallel_gap_at_trial_surface_zero_resolved_only_by_extrapolation": True,
              "rank_between_equilibria_verified": False, "physical_limit_certified": False}
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    for case, _ in work:
        print(f"{case['record']} h_yield={case['trial_surface_zero_from_its_own_samples']:.8e} "
              f"h_residual={case['independent_continuity_step_from_net_projected_residual']:.8e} "
              f"gap={case['extrapolated_projected_residual_gap_at_yield_MPa']:.3e} "
              f"floor={case['largest_unswitched_observed_linearization_gap_MPa']:.3e} MPa")
    print("HARDSHEAR ARCHIVED SWITCH AUDITED", digest(args.output))


if __name__ == "__main__":
    main()
