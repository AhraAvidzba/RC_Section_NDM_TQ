Сверка двенадцати упругих решений и двух нелинейных посекционных траекторий MVT2.
Уравнение Прандтля по L. Freddi, F. Murat, R. Paroni, (20)–(23).
https://cvgmt.sns.it/media/doc/paper/551/fmp-2010-published-version.pdf
Команда: python -B -X utf8 Verify-Grid.py --signed <repo>/docs/regression/Coupled6D/MVT2NDMSignedWindow20261117.zip --out Replayed.json
В архив не включены бинарные книги. Нативное свидетельство подтверждает точную исходную книгу и единственный импорт тестового модуля.
