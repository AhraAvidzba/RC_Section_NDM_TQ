"""Read-only replay of the MVT2 small-torque analytic comparison."""

from hashlib import sha256
from math import fsum, isclose, pi, tanh, ulp
from pathlib import Path
from zipfile import ZipFile
import json

ROOT = Path(__file__).resolve().parents[2]
GEOMETRY_SHA = "C2777D5D748972220113C54F78FD18DEDA86DB6786AE7268633E0FDB1C5CC8A7"
ARCHIVES = ROOT / "docs/regression/Coupled6D"
TORSION_SHA = "E330C5999357A5E56847488315AE25384B507AEF2ED650071672938A1A5D32FB"
ELASTIC_SHA = "807E5B0B7EAEEB11D2159C10B0EA2D07C18FFF6A6E72616FFBE2324678271E89"
NDM_SHA = "64358DD0C1A45A1BAF340744A7573A0CAAD48FA4C66A4C94FA9EBC37BD5F4E8D"


def digest(data):
    return sha256(data).hexdigest().upper()


def read_pinned(path, expected):
    data = path.read_bytes()
    if digest(data) != expected:
        raise ValueError(f"Digest differs for {path}")
    return data


def square_torsion_j(side, max_odd):
    """Bound truncation of two independent series for the homogeneous square."""
    if max_odd % 2 != 1:
        raise ValueError("Maximum odd index required")
    odds = range(1, max_odd + 1, 2)
    single = side**4 * (1.0 / 3.0 - 64.0 / pi**5 *
                        fsum(tanh(n * pi / 2.0) / n**5 for n in odds))
    # This positive double sum is 2*integral(psi), where -Laplacian(psi)=2.
    squares = tuple(n * n for n in odds)
    double = side**4 * 256.0 / pi**6 * fsum(
        1.0 / (m2 * n2 * (m2 + n2)) for m2 in squares for n2 in squares
    )
    # The single tail is negative and tanh <= 1. Bound the double tail
    # by both omitted strips, using sum(odd^-2)=pi²/8 and m²+n²>=m².
    single_tail = side**4 * 64.0 / (pi**5 * 4.0 * max_odd**4)
    double_tail = side**4 * 256.0 / pi**6 * 2.0 * (pi**2 / 8.0) / (3.0 * max_odd**3)
    cushion = 64.0 * max(ulp(single), ulp(double))
    single_range = (single - single_tail - cushion, single + cushion)
    double_range = (double - cushion, double + double_tail + cushion)
    assert max(single_range[0], double_range[0]) <= min(single_range[1], double_range[1])

    # At the face midpoint, evaluate the alternating derivative of psi.
    def midpoint_terms():
        for n in odds:
            sign = -1.0 if n % 4 == 3 else 1.0
            yield sign * tanh(n * pi / 2.0) / n**2

    tau_per_1_kNm = 1e6 * (8.0 * side / pi**2) * fsum(midpoint_terms()) / single
    return single, {
        "odd_index_max": max_odd,
        "J_over_a4": single / side**4,
        "J_single_series_mm4": single,
        "J_double_series_mm4": double,
        "J_single_truncation_range_mm4": single_range,
        "J_double_truncation_range_mm4": double_range,
        "max_tau_approx_MPa_per_kNm": tau_per_1_kNm,
    }


def load_observations():
    ndm = json.loads(read_pinned(ROOT / "tmp/mvt-cut-ndm/VerifiedCenter15.json", NDM_SHA))
    with ZipFile(ARCHIVES / "MVT2OpenSeesDistributedTorsion20261117.zip") as archive:
        read_pinned(Path(archive.filename), TORSION_SHA)
        raw = archive.read("NonlinearDistributedContinue.json")
    ext = json.loads(raw)
    with ZipFile(ARCHIVES / "MVT2OpenSeesDistributedElastic20261117.zip") as archive:
        read_pinned(Path(archive.filename), ELASTIC_SHA)
        rig = archive.read("MVT2DistributedPads.py")
        elastic = json.loads(archive.read("ElasticDistributedResult.json"))
    assert digest(rig) == ext["validated_input_sha256"]["MVT2DistributedPads.py"]
    assert elastic["rig_source_sha256"] == GEOMETRY_SHA
    read_pinned(ROOT / "tmp/mvt-external/MVT2Elastic.py", GEOMETRY_SHA)
    read_pinned(ROOT / "tmp/mvt-external/MVT2NonlinearPilot.py",
                ext["validated_input_sha256"]["MVT2NonlinearPilot.py"])
    read_pinned(ROOT / "tools/validate_opensees_hardshear.py",
                "17CAD60D1E55F84F62CFCFE49EDDE9FD6F3D7CF29761E3252A37975047812106")
    assert ext["E_MPa"] == 30000 and ext["nu"] == 0.2
    assert ext["steel_E_MPa"] == 200000
    assert ext["steel_yield_MPa"] == {"2": 498.0, "3": 450.0}
    assert ext["steel_post_yield_slope_MPa"] == 0.0
    assert ndm["right_window_mm"] == [1340.0, 1400.0]
    assert ndm["constitutive_laws_equated"] is False
    return ndm, ext, digest(raw), elastic


def evaluate():
    ndm, ext, external_raw_sha, elastic = load_observations()
    e, nu, side = ext["E_MPa"], ext["nu"], 240.0
    g = e / (2.0 * (1.0 + nu))
    j, theory = square_torsion_j(side, 1023)
    gj = g * j / 1e9  # N*mm² to kN*m²
    rows = []
    ndm_torsion = [row for row in ndm["comparison"] if row["Qy_kN"] == 0.0]
    for measured, native in zip(ndm_torsion, ext["states"], strict=True):
        torque = measured["T_kNm"]
        assert isclose(native["rig_balance"]["T_Nmm"], torque * 1e6, rel_tol=5e-16)
        assert native["rig_balance"]["P_N"] == 0 and native["nominal_milestone"] is True
        model = measured["NDM_twist_by_arm_rad_per_m"]["330"]
        right = native["displacement"]["clear_twist_rad_per_m"]["right"]
        left = native["displacement"]["clear_twist_rad_per_m"]["left"]
        assert right == measured["OpenSees_right_window_rad_per_m"]
        ratio = model / right
        assert ratio == measured["NDM_center_to_OpenSees_ratio"]
        damage = native["concrete_damage_by_station_band"]
        steel = native["steel_signed_extrema_by_band"]
        theory_twist = torque / gj

        def max_strain(label):
            return max(abs(value["axial_strain"]) for zone in steel.values()
                       for value in zone[label].values())

        rows.append({
            "T_kNm": torque,
            "SV_twist_rad_per_m": theory_twist,
            "NDM_twist_rad_per_m": model,
            "OpenSees_right_twist_rad_per_m": right,
            "OpenSees_left_twist_rad_per_m": left,
            "NDM_over_OpenSees_right": ratio,
            "NDM_secant_GJ_kNm2": torque / model,
            "OpenSees_right_secant_GJ_kNm2": torque / right,
            "NDM_twist_relative_to_SV": model / theory_twist - 1.0,
            "OpenSees_right_twist_relative_to_SV": right / theory_twist - 1.0,
            "OpenSees_max_dt": max(pair["tension"]["damage"] for pair in damage.values()),
            "OpenSees_max_dc": max(pair["compression"]["damage"] for pair in damage.values()),
            "OpenSees_max_abs_long_strain": max_strain("long"),
            "OpenSees_max_abs_hoop_strain": max_strain("hoop"),
            "OpenSees_max_abs_strain_over_yield": max(
                max_strain("long") * ext["steel_E_MPa"] / ext["steel_yield_MPa"]["2"],
                max_strain("hoop") * ext["steel_E_MPa"] / ext["steel_yield_MPa"]["3"]
            )
        })
    assert len(rows) == 7 and rows[4]["T_kNm"] == 4.204 and rows[-1]["T_kNm"] == 10.51
    ratio = rows[0]["NDM_over_OpenSees_right"]
    assert max(abs(r["NDM_over_OpenSees_right"] / ratio - 1.0) for r in rows[:5]) < 4e-6
    assert all(r["OpenSees_max_dt"] == r["OpenSees_max_dc"] == 0.0 for r in rows[:5])
    return {
        "status": "PASS",
        "NDM_receipt_sha256": NDM_SHA,
        "OpenSees_nonlinear_raw_sha256": external_raw_sha,
        "theory": {**theory, "G_MPa": g, "GJ_kNm2": gj, "E_MPa": e, "nu": nu,
                   "section_mm": [side, side]},
        "OpenSees_model_metadata": {
            "section_length_mm": [240.0, 240.0, 2200.0],
            "support_z_mm": [500.0, 1700.0],
            "long_bar_axis_mm_in_span": [[x,y] for x in (-84.0, 84.0) for y in (-84.0, 84.0)],
            "long_bar_inside_outside_span_counts": [4, 8],
            "long_bar_diameter_mm": 16.0,
            "long_bar_area_fraction_in_span": pi * 16.0**2 / side**2,
            "hoop_axis_width_height_mm": [192.0, 192.0],
            "hoop_diameter_mm": 8.0,
            "hoop_count_by_band": [len(range(20, 500, 40)), len(range(530, 1700, 60)),
                                   len(range(1720, 2200, 40))],
            "hoop_spacing_mm_by_band": [40.0, 60.0, 40.0],
            "steel_E_MPa": ext["steel_E_MPa"],
            "steel_yield_long_hoop_MPa": [ext["steel_yield_MPa"][key] for key in ("2", "3")],
            "steel_post_yield_slope_MPa": ext["steel_post_yield_slope_MPa"],
            "steel_element": "bond-shared axial truss",
            "concrete_element": "stdBrick",
            "concrete_bricks_by_section": [10, 8],
            "mesh_max_dz_mm": 60.0,
            "pad_x_z_extent_mm": elastic["pad_x_z_extent_mm"],
            "support_mode": ext["support_mode"],
            "left_window_mm": [800.0, 860.0],
            "right_window_mm": ndm["right_window_mm"]
        },
        "observations": rows,
        "last_ratio_divided_by_first_ratio": rows[-1]["NDM_over_OpenSees_right"] / ratio,
        "constitutive_laws_equated": False,
        "physical_limit_established": False
    }


if __name__ == "__main__":
    print(json.dumps(evaluate(), indent=2, sort_keys=True))
