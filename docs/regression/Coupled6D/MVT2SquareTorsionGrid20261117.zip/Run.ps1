# Запускает одну проверку подписанных усилий MVT2 в отдельной книге Excel.
param([ValidateSet('300','330','360','Elastic','Torque10','Torque20')][string]$Arm = '330',[switch]$CompiledOnly)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$tempBefore=$env:TEMP
$tmpBefore=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$report="Native/Right$Arm.txt"
Push-Location -LiteralPath $root
try {
    . './Guard-IsolatedOffice.ps1'
    $prep=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json
    foreach ($inputFile in $prep.inputs.psobject.Properties) {
        if ((Get-FileHash -LiteralPath $inputFile.Name).Hash -cne $inputFile.Value) {
            throw "Не совпали байты тестового входа $($inputFile.Name)."
        }
    }
    if (Test-Path -LiteralPath $report) {throw 'Для этой проверки уже есть протокол.'}
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if (!$CompiledOnly) {
        if ((Test-Path -LiteralPath 'Compile.log') -or
            (Get-FileHash -LiteralPath $draft).Hash -cne $prep.workbook_sha256) {throw 'Изменена исходная копия для теста.'}
        Assert-IsolatedOfficeReady 'CompileCutComparison'
        & './tools/build_workbook/Update-IsolatedOptimizerCode.ps1' -WorkbookPath $draft -ModuleNames @('modTestMVT2CutComparison') |
            Tee-Object -FilePath 'Compile.log'
        Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    }
    $compiled=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    $closure=Get-Content -LiteralPath 'CompileClosure.json' -Raw | ConvertFrom-Json
    if (!$compiled.Compiled -or $compiled.ProductionChanged -or
        $compiled.Modules.Count -ne 1 -or $compiled.Modules[0] -cne 'modTestMVT2CutComparison' -or
        $compiled.ProductionSHA256 -cne $prep.workbook_sha256 -or $closure.State -cne 'Absent' -or
        $compiled.WorkbookSHA256 -cne (Get-FileHash -LiteralPath $draft).Hash) {throw 'Не подтверждена тестовая компиляция.'}
    Assert-IsolatedOfficeReady "VerifyMVT2Cut$Arm"
    $run=@('-NoProfile','-ExecutionPolicy','Bypass','-File','tools/build_workbook/Run-FocusedKaniWatchdog.ps1',
        '-SourceWorkbook',$draft,'-ReportPath',$report,'-Macro','modTestMVT2CutComparison.RunTestMVT2CutComparison',
        '-MacroArgument1',$Arm,'-Mode','No','-TimeoutSeconds','120','-FailFast')
    & $legacy @run
    $runExit=$LASTEXITCODE
    $fixtures=@(Get-Content -LiteralPath $report -Encoding UTF8 | Where-Object {$_ -like 'FIXTURE: *'})
    if ($fixtures.Count -ne 1) {throw 'Нет однозначного пути к тестовой копии.'}
    $folder=Split-Path -Parent $fixtures[0].Substring('FIXTURE: '.Length)
    if (!$folder.StartsWith($env:TEMP+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Путь вне временного каталога.'}
    $trace=Join-Path $folder 'MVT2CutComparison.csv'
    if (Test-Path -LiteralPath $trace) {Copy-Item -LiteralPath $trace -Destination "Native/Right$Arm.csv"}
    if ($runExit -ne 0) {throw "Нативная проверка завершилась с кодом $runExit."}
}
finally {
    $env:TEMP=$tempBefore
    $env:TMP=$tmpBefore
    Pop-Location
}
