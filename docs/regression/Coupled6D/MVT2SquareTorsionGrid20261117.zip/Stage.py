"""Stage one isolated signed-cut comparison from the installed Excel book."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BOOK = "workbook/output/RC_Section_NDM.xlsm"
BOOK_SHA = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
MACRO = "tests/modTestMVT2CutComparison.bas"
SOURCE = "MVT2H26BridgeCurrentApiNative20261117"
TOOLS = {
    "tools/build_workbook/Update-IsolatedOptimizerCode.ps1",
    "tools/build_workbook/Run-FocusedKaniWatchdog.ps1",
    "Guard-IsolatedOffice.ps1",
}
HELPERS = ("BuildWangMVT2SectionTest", "InitializeExperimentSolverTest", "ExperimentBilinearSteelTest",
           "RecordWangMVT2StateTest", "ExperimentNumberTest", "AddExperimentTraceTest")


def digest(raw):
    return sha256(raw).hexdigest().upper()


def write(root, name, contents):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as output:
        output.write(contents)
    return digest(contents)


def main(root):
    allowed = Path("D:/CodexScratch/RC_Section_NDM_TQ").resolve()
    root = root.resolve()
    assert root != allowed and root.is_relative_to(allowed)
    root.mkdir()
    for folder in ("Temp", "Native", "src"):
        (root / folder).mkdir()
    manifest = json.loads((REPO / "docs/reports/Coupled6DEvidence.json").read_bytes())
    source = REPO / "docs/regression/Coupled6D" / f"{SOURCE}.zip"
    assert digest(source.read_bytes()) == manifest["archives"][SOURCE]
    book = (REPO / BOOK).read_bytes()
    assert digest(book) == BOOK_SHA
    inputs = {BOOK: write(root, BOOK, book)}
    write(root, "docs/regression/Diagnostic.xlsm", book)
    with ZipFile(source) as archive:
        old = archive.read("tests/modTestCoupledExperiment.bas").decode("utf-8-sig").replace("\r\n", "\n")
        text = (HERE / "CutTest.txt").read_text(encoding="utf-8").rstrip() + "\n"
        for method in HELPERS:
            match = re.findall(rf"^Private (Sub|Function) {method}\b.*?^End \1$", old, re.M | re.S)
            assert len(match) == 1, method
            block = re.search(rf"^Private (Sub|Function) {method}\b.*?^End \1$", old, re.M | re.S)[0]
            text += "\n' -------------------- ДЛЯ ТЕСТОВ --------------------\n"
            text += "' Вспомогательная процедура проверочного сценария MVT2 из архивной постановки.\n"
            text += block + "\n"
        text.encode("cp1251")
        inputs[MACRO] = write(root, MACRO, text.replace("\n", "\r\n").encode("utf-8-sig"))
        for name in sorted(TOOLS | {n for n in archive.namelist() if n.startswith("tools/build_workbook/")}):
            inputs[name] = write(root, name, archive.read(name))
    inputs["Run.ps1"] = write(root, "Run.ps1", (HERE / "Run.ps1").read_bytes())
    prep = {"workbook_sha256": BOOK_SHA, "source_archive_sha256": manifest["archives"][SOURCE], "inputs": inputs}
    print("SEALED CUT COMPARISON", write(root, "Preparation.json", (json.dumps(prep, indent=2) + "\n").encode()))


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    main(parser.parse_args().root)
