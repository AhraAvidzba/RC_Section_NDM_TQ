"""Reconstruct the elastic square benchmark and compare native NDM integration grids."""

import argparse
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
BASE = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
SIGNED = "F33926B1BC77BCD2E736DC39520CF66DCCA98CF630A51110D7C293FFE1861C25"
TORQUE = 262750.
GRIDS = [(1, 5), (1, 10), (1, 20), (2, 5), (2, 10), (3, 8)]
T_STEPS = [10.51 * factor for factor in (.025, .05, .1, .2, .4, .65, 1.)]


def digest(data):
    return sha256(data).hexdigest().upper()


def read(root, name):
    return json.loads((root / name).read_text(encoding="utf-8-sig"))


def verify_root(root, modes):
    prep = read(root, "Preparation.json")
    assert prep["workbook_sha256"] == BASE
    for name, expected in prep["inputs"].items():
        if not name.endswith(".xlsm"):
            assert digest((root / name).read_bytes()) == expected
    compiled = read(root, "docs/regression/CodeUpdate.json")
    compiler = read(root, "CompileClosure.json")
    assert compiled["Compiled"] and compiled["ProductionSHA256"] == BASE and not compiled["ProductionChanged"]
    assert compiled["Modules"] == ["modTestMVT2CutComparison"] and compiler["State"] == "Absent"
    assert f"OWNED_EXCEL: id={compiler['PID']}; utcStartTicks={compiler['StartTicksUTC']}" in (
        root / "Compile.log").read_text(encoding="utf-8-sig")
    for mode, total in modes:
        name = f"Native/Right{mode}.txt"
        owner, watch = [read(root, name + suffix) for suffix in (".Ownership.json", ".ProcessClosure.json")]
        end = watch["Closure"]["FinalState"]
        assert owner["VerifiedNewOwner"] and owner["SourceSHA256"] == compiled["WorkbookSHA256"]
        assert watch["Passed"] and watch["ChildHasExited"] and watch["ChildExitCode"] == 0
        assert (end["PID"], end["StartTicksUTC"], end["State"]) == (owner["PID"], owner["StartTicksUTC"], "Absent")
        log = (root / name).read_text(encoding="utf-8-sig")
        assert total in log and "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in log


def read_wire(path):
    raw = path.read_bytes()
    return [line.split(";") for line in raw.decode("cp1251").splitlines()], digest(raw)


def elastic_control(root, homogeneous_twist):
    verify_root(root, [("Elastic", "TOTAL_MVT2_ELASTIC_GRID: passed=12; failed=0")])
    rows, trace_sha = read_wire(root / "Native/RightElastic.csv")
    assert len(rows) == 12
    result = {}
    for row in rows:
        label, *values = row
        reinforced, spans, per_span, points, total = [int(item) for item in values[:5]]
        area, rate, *forces = [float(item) for item in values[5:]]
        assert label == "MVT2_GRID" and reinforced in (0, 1) and (spans, per_span) in GRIDS
        assert points == ((spans * per_span) ** 2) and abs(area - 57600.) < 1e-7
        assert total == points + (4 + 16 * spans if reinforced == 1 else 0)
        expected = [0., 0., 0., TORQUE, 0., 0.]
        assert len(forces) == 6 and max(abs(x-y) for x, y in zip(forces, expected, strict=True)) < 1e-6
        key = (reinforced, spans, per_span)
        assert key not in result and rate > 0
        result[key] = {"concrete_points": points, "reinforcement_displacements": bool(reinforced),
                       "spans_each_direction": spans, "points_per_span": per_span, "T_Nmm": forces[3],
                       "twist_rad_per_m": rate, "relative_to_homogeneous_series": rate/homogeneous_twist-1.}
    assert len(result) == 12
    for flag in (0, 1):
        assert result[flag, 1, 5]["twist_rad_per_m"] > result[flag, 1, 10]["twist_rad_per_m"] > result[flag, 1, 20]["twist_rad_per_m"]
        assert result[flag, 1, 20]["twist_rad_per_m"] == result[flag, 2, 10]["twist_rad_per_m"]
    return {"trace_sha256": trace_sha, "cases": list(result.values())}


def nonlinear_control(root):
    modes = [("Torque10", "TOTAL_MVT2_CUT_COMPARISON: passed=1; failed=0;"),
             ("Torque20", "TOTAL_MVT2_CUT_COMPARISON: passed=1; failed=0;")]
    verify_root(root, modes)
    result = {}
    for points in (10, 20):
        rows, trace_sha = read_wire(root / f"Native/RightTorque{points}.csv")
        setup, grid, *rows = rows
        assert setup[:2] == ["MVT2_CUT_SETUP", "330"]
        assert grid == ["MVT2_TORSION_GRID", str(points), str(points**2)]
        states, stopped = [], None
        for stage, torque in enumerate(T_STEPS, 1):
            trial, *rows = rows
            assert trial[:2] == ["MVT2_CUT_TRIAL", f"R{stage}"] and abs(float(trial[2]) - torque*1e6) < 1e-8
            assert trial[3:5] == ["0", "0"]
            if trial[5:8] == ["False", "6", "10"]:
                assert not rows
                stopped = {"requested_T_kNm": torque, "details": ";".join(trial[8:])}
                break
            assert trial[5:8] == ["True", "4", "0"]
            state, *rows = rows
            assert state[:4] == ["MVT2_STATE", trial[1], "0", "0"]
            vals = [float(x) for x in state[4:]]
            applied = [0., 0., 0., torque, 0., 0.]
            assert len(vals) == 20 and max(abs(x-y) for x, y in zip(vals[:6], applied, strict=True)) < .00015
            assert 0 <= vals[-1] <= 5e-6
            states.append({"torque_kNm": torque, "twist_rad_per_m": vals[9],
                           "maximum_tensile_damage": vals[15], "normalized_resultant_error_MPa": vals[-1]})
        assert not rows
        result[str(points)] = {"trace_sha256": trace_sha, "states": states, "numerical_stop": stopped}
    return result


def evaluate(elastic, nonlinear, signed):
    assert digest(signed.read_bytes()) == SIGNED
    with ZipFile(signed) as archive:
        comparison = json.loads(archive.read("VerifiedFine15.json"))
    spec = spec_from_file_location("analytic_square", HERE / "Evaluate.py")
    theory = module_from_spec(spec)
    spec.loader.exec_module(theory)
    j, series = theory.square_torsion_j(240., 1023)
    rigidity = 12500. * j / 1e9
    homogeneous_twist = (TORQUE / 1e6) / rigidity
    numeric = elastic_control(elastic, homogeneous_twist)
    assert numeric["cases"][6]["twist_rad_per_m"] == comparison["comparison"][0]["NDM_twist_by_arm_rad_per_m"]["330"]
    return {"status": "PASS", "J_series_mm4": series, "GJ_kNm2": rigidity, "homogeneous_twist_rad_per_m": homogeneous_twist,
            "verified_signed_comparison_sha": SIGNED, "elastic": numeric, "nonlinear": nonlinear_control(nonlinear),
            "physical_limit_established": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--elastic", type=Path, default=HERE / "ElasticGrid")
    parser.add_argument("--nonlinear", type=Path, default=HERE / "TorqueGrid")
    parser.add_argument("--signed", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = evaluate(args.elastic, args.nonlinear, args.signed)
    data = (json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()
    with args.out.open("xb") as output:
        output.write(data)
    print("MVT2 GRID PROOF PASS", len(result["elastic"]["cases"]), digest(data))
