# Компилирует частную книгу и проверяет расчётные тесты с учётом владельца Excel.
param([Parameter(Mandatory=$true)][ValidateSet('Base','Candidate')][string]$Role)
$ErrorActionPreference='Stop'
$root=Join-Path $PSScriptRoot $Role
$previousTemp=$env:TEMP
$previousTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
$draft='docs/regression/Diagnostic.xlsm'
$original=(Resolve-Path -LiteralPath 'workbook/output/RC_Section_NDM.xlsm').Path
if((Get-FileHash -LiteralPath $original).Hash -ne 'A0563F44794A79776E4B4915AF2B075E4C172BC332CDDDC502B6B69941E56C5A'){throw 'Изменилась рабочая книга.'}
Push-Location -LiteralPath $root
try {
    . (Join-Path $root 'Guard-IsolatedOffice.ps1')
    $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
    $env:TMP=$env:TEMP
    if((Join-Path $env:TEMP 'RC_NDM_ModeSuite_00000000000000000000000000000000/RC_Section_NDM.xlsm').Length -gt 210){throw 'Длинный путь фикстуры.'}
    $proof=Get-Content -LiteralPath 'Preparation.json' -Raw | ConvertFrom-Json -AsHashtable
    foreach($file in $proof.Keys){if((Get-FileHash -LiteralPath $file).Hash -cne $proof[$file]){throw ('Вход изменён. '+$file)}}
    if(Test-Path -LiteralPath 'Compile.log'){throw 'Предыдущая компиляция требует сверки.'}
    if((Get-FileHash -LiteralPath $draft).Hash -cne $proof['workbook\output\RC_Section_NDM.xlsm']){throw 'Неверная исходная книга.'}
    Assert-IsolatedOfficeReady ('Compile'+$Role)
    $modules=@('modTestCoupledElasticState','CTestCoupledPointResponse')
    if($Role -eq 'Candidate'){$modules+= 'CCoupledDeformationContinuation'}
    & (Join-Path $root 'tools/build_workbook/Update-IsolatedOptimizerCode.ps1') -WorkbookPath $draft -ModuleNames $modules |
        Tee-Object -FilePath 'Compile.log'
    Save-OfficeClosure 'Compile.log' 'CompileClosure.json'
    $receipt=Get-Content -LiteralPath 'docs/regression/CodeUpdate.json' -Raw | ConvertFrom-Json
    if(!$receipt.Compiled -or $receipt.ProductionChanged -or (Get-FileHash -LiteralPath $draft).Hash -cne $receipt.WorkbookSHA256){
       throw 'Частная книга не подтверждена.'
    }
    $runBook=$draft
    if($Role -eq 'Candidate'){
        python -B -X utf8 (Join-Path $root 'Package.py')
        if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
        $runBook='docs/regression/Audit03/RetainedShoulders/RC_Section_NDM.xlsm'
    }
    $suites=@('RunTestCoupledRetainedShoulders')
    if($Role -eq 'Candidate'){
        $suites+= @('RunTestCoupledDeformationControl','RunTestCoupledKinematicGauge','RunTestCoupledDeformationSteelCrossing')
    }
    foreach($suite in $suites){
        Assert-IsolatedOfficeReady $suite
        $log="Native/$suite.txt"
        $timer=[Diagnostics.Stopwatch]::StartNew()
        & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-FocusedKaniWatchdog.ps1' -SourceWorkbook $runBook -ReportPath $log -Macro ('modTestCoupledElasticState.'+$suite) -Mode No -TimeoutSeconds 120 -FailFast
        $nativeExit=$LASTEXITCODE
        $timer.Stop()
        $actual=Get-Content -LiteralPath $log -Raw -Encoding UTF8
        $total=[regex]::Match($actual,'(?m)^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)')
        $closed=(Get-Content -LiteralPath ($log+'.ProcessClosure.json') -Raw | ConvertFrom-Json).Closure.FinalState
        if(!$total.Success -or $closed.State -ne 'Absent'){throw ('Нет результата или процесс не закрыт. '+$suite)}
        $expectedFailures=0
        if($Role -eq 'Base'){$expectedFailures=2}
        [ordered]@{role=$Role;suite=$suite;pass=[int]$total.Groups[1].Value;fail=[int]$total.Groups[2].Value;exit=$nativeExit;wall_seconds=$timer.Elapsed.TotalSeconds;closed=$closed} |
            ConvertTo-Json -Depth 4 | Set-Content -LiteralPath ($log+'.Receipt.json') -Encoding UTF8
        if(($Role -eq 'Base' -and $nativeExit -eq 0) -or ($Role -eq 'Candidate' -and $nativeExit -ne 0) -or [int]$total.Groups[2].Value -ne $expectedFailures){throw ('Неожиданный исход. '+$suite)}
        Write-Output $total.Value
    }
    if($Role -eq 'Candidate'){
        Assert-IsolatedOfficeReady 'ExportCandidate'
        $export='docs/regression/Audit03/RetainedShoulders/VBA_All_Code.txt'
        & (Join-Path $root 'tools/build_workbook/Export-Audit03VbaSnapshot.ps1') -WorkbookPath $runBook -OutputPath $export |
            Tee-Object -FilePath 'Export.log'
        Save-OfficeClosure 'Export.log' 'ExportClosure.json'
        python -B -X utf8 tools/build_workbook/Verify-ExportDifference.py workbook/output/VBA_All_Code.txt $export @modules |
            Tee-Object -FilePath 'ExportDifference.json'
        if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
    }
}
finally {
    $env:TEMP=$previousTemp
    $env:TMP=$previousTmp
    Pop-Location
}

