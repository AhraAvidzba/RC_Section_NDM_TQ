"""Verify the stored native red/green comparison and source/build receipts."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import re

root=Path(__file__).resolve().parent


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def run():
    proof=read(root/"Verification.json")
    pub=read(root/"Publication.json")
    manifest=read(root/"SourceRepresentation.json")
    assert pub["verification_sha256"]==digest(root/"Verification.json")
    assert pub["status"]==proof["status"]=="PASS"
    assert pub["installed"]["workbook/output/RC_Section_NDM.xlsm"]==proof["package"]["candidate_sha256"]
    assert pub["installed"]["workbook/output/VBA_All_Code.txt"]==proof["installed_export_sha256"]
    assert proof["package"]["unchanged_package_parts"]==121
    equality=read(root/"SourceEquality.json")
    assert equality["Passed"] and all(equality["VerifierSelfChecks"].values())
    assert equality["ExportSHA256"]==proof["installed_export_sha256"]
    assert {row["Name"]:row["SourceSHA256"] for row in equality["Components"]}=={
        Path(file).stem:expected for file,expected in proof["sources"].items()
    }
    assert len(proof["production_vba_components"]["changes"])==3 and proof["export_closure"]["State"]=="Absent"
    for relative,expected in proof["sources"].items():
        compiled=root/"compiled"/relative
        installed=root/"installed"/relative
        assert digest(compiled)==expected
        assert digest(installed)==manifest[relative]["worktree_sha256"]
        assert compiled.read_text(encoding="utf-8").rstrip("\n")==installed.read_text(encoding="utf-8").rstrip("\n")

    # Exact reconstructed five-point curve, independent of the VBA and rounding.
    nodes=list(map(Fraction,("0","1","2","5/2","3")))
    factors=[(450+1379*t-2428*t**2+1309*t**3-218*t**4)/600 for t in nodes]
    assert factors==list(map(Fraction,("3/4","41/50","4/5","11/10","7/10")))
    expected_best=str(float(max(factors)))
    base=root/"Base/Native/RunTestCoupledRetainedShoulders.txt"
    text=base.read_text(encoding="utf-8-sig")
    assert "actual=0.82 expected="+expected_best in text
    assert re.findall(r"(?m)^FAIL:.*$",text)==[
        "FAIL: нижняя оценка включает все сохранённые равновесия actual=0.82 expected=1.1",
        "FAIL: в диагностике указан больший подтверждённый максимум",
    ]
    assert proof["untreated_case"]["fail"]==2 and proof["untreated_case"]["closed"]["State"]=="Absent"

    total=0
    for name,receipt in proof["native"].items():
        log=root/"Candidate/Native"/(name+".txt")
        report=log.read_text(encoding="utf-8-sig")
        actual=re.search(r"(?m)^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)$",report)
        assert actual and (int(actual[1]),int(actual[2]))==(receipt["pass"],0)
        assert f"SOURCE_SHA256: {proof['package']['candidate_sha256']}" in report
        assert receipt["closed"]["State"]=="Absent" and receipt["exit"]==0
        total+=int(actual[1])
    hard=(root/"Candidate/Native/HardShear.txt").read_text(encoding="utf-8-sig")
    totals=re.findall(r"(?m)^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)$",hard)
    assert totals==[("28","0"),("1","0")]
    assert "TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10290889219737; limit=; code=NUMERICAL_FAILURE" in hard
    assert proof["HardShear"]["closed"]["State"]=="Absent" and proof["HardShear"]["exit"]==0
    total+=sum(int(passed) for passed,_ in totals)
    assert total==131
    record={"native_assertions":total,"untreated_regression_failures":2,"retained_discrete_branch":[str(t) for t in factors],
            "independent_retained_maximum":expected_best,"installed_workbook_sha256":proof["package"]["candidate_sha256"],
            "export_sha256":proof["installed_export_sha256"],"verified_build_receipt_sha256":digest(root/"Verification.json"),
            "publication_receipt_sha256":digest(root/"Publication.json")}
    output=root/"Replay.json"
    output.write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8",newline="\n")
    print("PASS",total,digest(output))


if __name__=="__main__":
    run()

