"""Check actual Excel artifacts and the exact source of the three changed modules."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json

root=Path(__file__).resolve().parent
candidate=root/"Candidate"
report_dir=candidate/"docs/regression/Audit03/RetainedShoulders"
module_sources={
    "CCoupledDeformationContinuation":Path("src/Solver/CCoupledDeformationContinuation.cls"),
    "CTestCoupledPointResponse":Path("tests/CTestCoupledPointResponse.cls"),
    "modTestCoupledElasticState":Path("tests/modTestCoupledElasticState.bas"),
}
book="RC_Section_NDM.xlsm"
export="VBA_All_Code.txt"


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def confirm_receipts(package):
    closures={}
    cases={"RunTestCoupledRetainedShoulders": (21,0), "RunTestCoupledDeformationControl": (35,0),
           "RunTestCoupledKinematicGauge": (14,0), "RunTestCoupledDeformationSteelCrossing": (32,0)}
    for name,counts in cases.items():
        log=candidate/"Native"/(name+".txt")
        receipt=read_json(log.with_suffix(".txt.Receipt.json"))
        owner=read_json(log.with_suffix(".txt.Ownership.json"))
        assert owner["SourceSHA256"]==package["candidate_sha256"] and owner["VerifiedNewOwner"]
        assert (receipt["pass"],receipt["fail"])==counts
        assert receipt["exit"]==0 and receipt["closed"]["State"]=="Absent"
        assert (receipt["closed"]["PID"],receipt["closed"]["StartTicksUTC"])==(owner["PID"],owner["StartTicksUTC"])
        closures[name]=receipt
    base_log=root/"Base/Native/RunTestCoupledRetainedShoulders.txt"
    base=read_json(base_log.with_suffix(".txt.Receipt.json"))
    assert (base["pass"],base["fail"],base["exit"])==(19,2,1)
    assert base["closed"]["State"]=="Absent"
    assert "actual=0.82 expected=1.1" in base_log.read_text(encoding="utf-8-sig")
    log=candidate/"Native/HardShear.txt"
    hard=read_json(log.with_suffix(".txt.Receipt.json"))
    owner=read_json(log.with_suffix(".txt.Ownership.json"))
    lines=log.read_text(encoding="utf-8-sig")
    assert owner["SourceSHA256"]==package["candidate_sha256"] and owner["VerifiedNewOwner"]
    assert hard["exit"]==0 and hard["closed"]["State"]=="Absent"
    assert (hard["closed"]["PID"],hard["closed"]["StartTicksUTC"])==(owner["PID"],owner["StartTicksUTC"])
    assert all(x.endswith("failed=0") for x in hard["totals"]) and len(hard["totals"])==2
    assert "NumFail" in lines
    return base,closures,hard


def main():
    package=read_json(candidate/"PackageChecks.json")
    assert digest(report_dir/book)==package["candidate_sha256"]
    assert digest(candidate/"workbook/output"/book)==package["base_sha256"]
    with ZipFile(report_dir/book) as new,ZipFile(candidate/"workbook/output"/book) as old:
        assert new.testzip() is None and old.namelist()==new.namelist()
        assert [entry for entry in old.namelist() if old.read(entry)!=new.read(entry)]==["xl/vbaProject.bin"]
        assert sha256(new.read("xl/vbaProject.bin")).hexdigest().upper()==package["vba_sha256"]

    proof=read_json(candidate/"ExportDifference.json")
    assert proof["changes"]==sorted(module_sources) and proof["components"]==225
    closure=read_json(candidate/"ExportClosure.json")
    assert closure["State"]=="Absent"
    line=(candidate/"Export.log").read_text(encoding="utf-8-sig")
    assert f"sourceSHA256={package['candidate_sha256']}; sourceUnchanged=True" in line
    equality=read_json(candidate/"docs/regression/OpenIssues_2026-10-11/SourceEquality.json")
    assert equality["Passed"] and equality["SourceComponents"]==3 and equality["ExportComponents"]==225
    assert equality["ExportSHA256"]==digest(report_dir/export)
    assert all(equality["VerifierSelfChecks"].values())
    equal_sources={item["Name"]:item["SourceSHA256"] for item in equality["Components"] if item["Equal"]}
    assert equal_sources=={name:digest(candidate/relative) for name,relative in module_sources.items()}

    baseline,native,hard=confirm_receipts(package)
    result={"status":"PASS","source_git_revision":"aab6994d9be577564e4c8b17b4b556e6ee092d51",
            "package":package,"installed_export_sha256":digest(report_dir/export),
            "previous_export_sha256":digest(candidate/"workbook/output"/export),
            "sources":{k.as_posix():digest(candidate/k) for k in module_sources.values()},
            "production_vba_components":proof,"export_closure":closure,
            "untreated_case":baseline,"native":native,"HardShear":hard}
    (root/"Verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
    print("PASS",digest(root/"Verification.json"),package["candidate_sha256"],result["installed_export_sha256"])


if __name__=="__main__":
    main()

