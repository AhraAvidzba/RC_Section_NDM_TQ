"""One mandatory p7 tensile-knot crossing with the other three ASD signs fixed."""
from hashlib import sha256
from pathlib import Path
from time import perf_counter
import gzip
import importlib.util
import json
import runpy
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('expanded',HERE/'Expand-Cone.py')
expand=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(expand)
cone=expand.cone
follow=expand.follow
PIN='CBE12AC774EFEA4698B001918E1748DE7A1132FDF30115B78F8F3973FE7D143B'


def mandatory_crossing(np,section,start,j,k,cap,physical):
    from scipy.optimize import linprog

    _,r,_,m=start
    assert m[-1]<0.
    scale=np.divide(cap,physical,out=np.zeros(60),where=physical>0.)
    null=physical==0.
    residual_norm=float(np.max(np.abs(r)))
    scale[null]=residual_norm/np.max(np.abs(j[:,null]),axis=0)
    jac=j*scale/residual_norm
    u=np.reshape(section.strain*scale/cap,(-1,60))
    desired=np.r_[np.sign(m[:3]),1.]
    oriented=desired[:,None]*k*scale
    branch_scale=np.maximum(np.abs(m),np.max(np.abs(oriented),axis=1))
    a=np.vstack((np.c_[jac,-np.ones(66)],np.c_[-jac,-np.ones(66)],
                 np.c_[u,np.zeros(len(u))],np.c_[-u,np.zeros(len(u))],np.c_[-oriented/branch_scale[:,None],np.zeros(4)]))
    b=np.r_[-r/residual_norm,r/residual_norm,np.ones(2*len(u)),(desired*m-.5*np.abs(m))/branch_scale]
    result=linprog(np.r_[np.zeros(60),1.],A_ub=a,b_ub=b,
                   bounds=[(None,None)]*60+[(0.,None)],method='highs',
                   options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    plan={'radius':cap,'desired_cell':desired.tolist(),'lp_status':int(result.status),
          'p7_required_positive_margin':.5*abs(float(m[-1]))}
    if not result.success:
        return None,plan
    delta=result.x[:60]*scale
    plan.update({'field_delta':delta.tolist(),'predicted_indicators':(m+k@delta).tolist(),
                 'predicted_full_norm_MPa':float(np.max(np.abs(r+j@delta))),
                 'binding_linear_constraints':(np.flatnonzero(np.abs(result.ineqlin.residual)<1e-9)+1).tolist()})
    return delta,plan


def main():
    started=perf_counter()
    old=expand.read_wire('ConeWire.json.gz',follow.PRIOR)
    last=expand.read_wire('ConeExpandedWire.json.gz',PIN)
    assert last['status']=='bounded_attempts_no_new_equilibrium' and last['history_count_after']==53
    datum=last['trials'][-1]['candidate']
    probe=cone.load_pinned('station_probe',cone.PRIOR/'station/Probe-Stations.py',cone.STATION_SRC)
    vector,archived=probe.exact_reference()
    np,ops,section,material,identity,load,_=probe.exact_replay(vector,archived)
    watch=runpy.run_path(str(cone.PRIOR/'station/Verify-Stations.py'))
    assert identity==last['source_operator_identity'] and last['center']=='first_rejected_trial'
    x=np.array(datum['field']); orig=np.array(old['first_rejected_trial'])
    threshold=old['tensile_threshold']; cap=last['maximum_local_radius']; total=last['total_cap']
    base=cone.witness(np,section,x,load,vector,threshold)
    assert probe.raw_section(section,x,load)==datum['section'] and base[3].tolist()==datum['markers'] and base[1].tolist()==datum['all66']
    assert expand.physical(np,section,x-orig)+cap<total and section.committed==53
    physical=np.max(np.abs(section.strain),axis=(0,1,2))
    j,k,columns=cone.sample_columns(np,section,x,load,base,vector,threshold,physical)
    data={'previous_wire_sha256':PIN,'exact_H53_before':section.committed,'same_material':material,
          'start_field':x.tolist(),'start_snapshot':datum['section'],'target':load.tolist(),
          'start_indicators':base[3].tolist(),'start_all66':base[1].tolist(),'finite_difference':columns,
          'total_cap_same_rejected_center':total,'local_cap':cap,'status':'no_predicted_descent_in_requested_cell'}
    if j is not None:
        delta,plan=mandatory_crossing(np,section,base,j,k,cap,physical)
        data['plan']=plan
        if delta is not None and plan['predicted_full_norm_MPa']<base[0][4]:
            y=x+delta
            candidate,r,steel,ind=cone.witness(np,section,y,load,vector,threshold)
            frame=probe.raw_section(section,y,load)
            value=follow.independent(section,watch,frame,y,load)
            signs=np.sign(ind).tolist()==plan['desired_cell']
            steel_same=np.array_equal(steel,base[2])
            travel=expand.physical(np,section,y-orig); step=expand.physical(np,section,y-x)
            reduced=bool(signs and steel_same and travel<=total and step<=cap*(1.+3e-9) and value<base[0][4])
            ratio=(base[0][4]-value)/(base[0][4]-plan['predicted_full_norm_MPa'])
            data['actual']={'field':y.tolist(),'section':frame,'all66':r.tolist(),'indicators':ind.tolist(),
                            'p7_cross_and_other_signs_unchanged':bool(signs),'steel_unchanged':bool(steel_same),
                            'travel_from_rejected_center':travel,'local_strain':step,
                            'independent_norm_MPa':value,'ratio_to_predicted_decrease':ratio,'actual_decrease_admissible':reduced}
            data['status']='checked_crossed_descent_trial_uncommitted' if reduced else 'checked_candidate_rejected'
            if reduced and value<=candidate[5] and candidate[4]<=candidate[5]:
                assert probe.raw_section(section,y,load)==frame
                section.accepted_stresses.append(candidate[2].tolist()); section.commit()
                data['status']='balanced_at_original_tolerance'
    if data['status']!='balanced_at_original_tolerance':
        assert probe.raw_section(section,x,load)==datum['section'] and section.committed==53
    data['history_final']=section.committed
    ops.wipe()
    raw=gzip.compress(vector.raw_json(data),compresslevel=9,mtime=0)
    with (HERE/'ConeP7Wire.json.gz').open('xb') as stream: stream.write(raw)
    print('MVT2 ASD P7 CROSSING WIRE',sha256(raw).hexdigest().upper(),len(raw),'seconds',perf_counter()-started,
          data['status'],flush=True)


if __name__=='__main__':
    main()
