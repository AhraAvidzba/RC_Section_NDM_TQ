"""Offline verification and signed stress decomposition of the rejected p7 crossing."""
from argparse import ArgumentParser
from hashlib import sha256
from math import copysign, fsum
from pathlib import Path
from zipfile import ZipFile
import gzip
import json
import runpy
import sys
import tempfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
WIRE='EC30E478EA840A8741D229E23591401803FA1C68490B482D89267227C29FB889'
EXPANDED=('MVT2GaussASDNominalExpandedTrust20261117','B40BA00D6EC17464F587A7A6BBE0B1E6D9BE4F867BB38915FEDD1C1CE704EA28')


def digest(b):
    return sha256(b).hexdigest().upper()


def archive(repo,pins):
    name,pin=pins
    path=repo/'docs/regression/Coupled6D'/(name+'.zip')
    assert digest(path.read_bytes())==pin
    return ZipFile(path)


def subtract(a,b):
    return [x-y for x,y in zip(a,b,strict=True)]


def point_contributions(before,after,point,row,op):
    signed=[]
    for index,side in enumerate((0,1,-1)):
        factor=1. if index==0 else side/.002
        left=before['net_stresses_MPa'][index][point-1]
        right=after['net_stresses_MPa'][index][point-1]
        assembler=op['S' if index==0 else 'R'][point-1]
        signed.append(factor*fsum(coef[row-1]*delta for coef,delta in zip(assembler,subtract(right,left),strict=True)))
    return signed


def independent(data,expanded,old,prior,watch,past,guard,op,geo,area,length):
    assert data['exact_H53_before']==data['history_final']==53 and expanded['history_count_after']==53
    assert data['status']=='checked_candidate_rejected' and expanded['center']=='first_rejected_trial'
    x=data['start_field']; a=data['start_snapshot']; observed=data['actual']; y=observed['field']; b=observed['section']; p=data['plan']
    z=expanded['trials'][-1]['candidate']; tm=data['target']; hold=data['start_indicators']; new=observed['indicators']
    assert (x,a,hold,data['start_all66'])==(z['field'],z['section'],z['markers'],z['all66'])
    assert tm==expanded['initial_target']==[0.,-33140625.,0.,10510000.,0.,55234.375]
    assert y==[v+d for v,d in zip(x,p['field_delta'],strict=True)]
    eq=watch['check_whole']; signed=guard['signed_forces']
    start=eq(a,x,tm,op,geo,area,length,signed); result=eq(b,y,tm,op,geo,area,length,signed)
    assert abs(result-observed['independent_norm_MPa'])<3e-12
    assert abs(start-max(map(abs,data['start_all66'])))<3e-12
    assert abs(result-max(map(abs,observed['all66'])))<3e-12
    assert a['tolerance_MPa']==b['tolerance_MPa']<start<result
    assert observed['steel_unchanged'] and a['steel_active_flags']==b['steel_active_flags']
    assert hold[-1]<0.<new[-1] and observed['p7_cross_and_other_signs_unchanged']
    assert not observed['actual_decrease_admissible']
    for frame,marks in ((a,hold),(b,new)):
        for (point,side),mark in zip(((20,1),(20,-1),(10,-1)),marks[:3],strict=True):
            calculated=watch['eigen'](frame['net_stresses_MPa'][(0,1,-1).index(side)][point-1])[1]
            assert abs(calculated-mark)<2e-13 and copysign(1.,calculated)==copysign(1.,mark)
    assert prior['active'](new)==p['desired_cell']==[-1.,1.,1.,1.]
    pr,pm=prior['prediction'](data['finite_difference'],{'all66':data['start_all66'],'indicators':hold},p['field_delta'],op)
    assert abs(max(map(abs,pr))-p['predicted_full_norm_MPa'])<5e-15
    assert prior['error'](pm,p['predicted_indicators'])<2e-18 and pm[-1]>=p['p7_required_positive_margin']
    tensor=past['tensor']
    def strain(delta):
        return max(abs(v) for p in range(45) for side in (0,1,-1) for v in tensor(op,delta,p,side))
    step=strain(subtract(y,x)); travel=strain(subtract(y,old['first_rejected_trial']))
    assert abs(step-observed['local_strain'])<4e-18 and step<=data['local_cap']+4e-18
    assert abs(travel-observed['travel_from_rejected_center'])<4e-18 and travel<data['total_cap_same_rejected_center']==expanded['total_cap']
    assert data['local_cap']==p['radius']==expanded['maximum_local_radius']
    rows={}
    for i in range(53,57):
        by_point=[point_contributions(a,b,point,i,op) for point in range(1,46)]
        total=fsum(v for sides in by_point for v in sides)
        gauge=fsum(g*d for g,d in zip(op['G'][i-1],subtract(y,x),strict=True))
        direct=b['normalized_60'][i-1]-a['normalized_60'][i-1]
        assert abs(direct-total-gauge)<3e-12
        paired=[fsum(c) for c in by_point]
        assert max(range(45),key=lambda index:abs(paired[index]))==6
        rows[str(i)]={'actual_signed_weak_change_MPa':direct,'all_point_projection_MPa':total,
                      'point7_center_plus_minus_MPa':by_point[6],'point7_total_MPa':paired[6]}
    assert .9999<rows['53']['point7_total_MPa']/rows['53']['actual_signed_weak_change_MPa']<1.0001
    assert rows['53']['point7_center_plus_minus_MPa'][-1]>0.>rows['53']['actual_signed_weak_change_MPa']
    assert abs(b['signed_6'][0])<abs(a['signed_6'][0]) and 109.<result/start<110.
    return {'status':'PASS','result':'rejected_after_exact_trial','history_count':53,
            'Qy_attempted_N':55234.375,'Qy_last_accepted_N':55156.25,'start_norm_MPa':start,'actual_norm_MPa':result,
            'original_tau_MPa':a['tolerance_MPa'],'predicted_norm_MPa':p['predicted_full_norm_MPa'],
            'start_and_end_p7_marker':[hold[-1],new[-1]],'point7_decomposition':rows,
            'start_signed_6':a['signed_6'],'actual_signed_6':b['signed_6'],'steel_and_other_three_signs_unchanged':True,
            'no_new_equilibrium':True,'physical_limit_established':False}


def main(repo):
    raw=(HERE/'ConeP7Wire.json.gz').read_bytes()
    assert digest(raw)==WIRE
    data=json.loads(gzip.decompress(raw))
    with tempfile.TemporaryDirectory(prefix='MVTP7Offline_') as directory, archive(repo,EXPANDED) as saved:
        root=Path(directory)
        (root/'Verify-Expanded.py').write_bytes(saved.read('Verify-Expanded.py'))
        expansion=runpy.run_path(str(root/'Verify-Expanded.py'))
        staged=saved.read('ConeExpandedWire.json.gz')
        assert digest(staged)==expansion['EXPANDED']==data['previous_wire_sha256']
        expanded=json.loads(gzip.decompress(staged))
        with archive(repo,expansion['PREVIOUS']) as z:
            (root/'Verify-Cone.py').write_bytes(z.read('Verify-Cone.py'))
            prior=runpy.run_path(str(root/'Verify-Cone.py'))
            old=z.read('ConeWire.json.gz'); assert digest(old)==prior['WIRE']
            seed=json.loads(gzip.decompress(old))
        with archive(repo,prior['STATION']) as z:
            (root/'Verify-Stations.py').write_bytes(z.read('Verify-Stations.py'))
        watch=runpy.run_path(str(root/'Verify-Stations.py'))
        with archive(repo,watch['BASE']) as z:
            (root/'Verify-VectorEvidence.py').write_bytes(z.read('Verify-VectorEvidence.py'))
        history=runpy.run_path(str(root/'Verify-VectorEvidence.py'))
        accepted,n,_,_,_=history['history'](repo)
        assert accepted['Q_target_N']==55156.25 and accepted['field']==seed['last_accepted_field']
        assert n<accepted['tolerance_MPa']
        with archive(repo,history['POST']) as z:
            (root/'Verify-Postyield.py').write_bytes(z.read('Verify-Postyield.py'))
        past=runpy.run_path(str(root/'Verify-Postyield.py'))
        with archive(repo,past['AUTH']) as z:
            for leaf in ('Verify-Authoritative.py','Operators.py','Reequilibrate.py'):
                (root/leaf).write_bytes(z.read(leaf))
        sys.path.insert(0,str(root))
        guard=runpy.run_path(str(root/'Verify-Authoritative.py'))
        operator,source=guard['unpack'](root,repo)
        model=runpy.run_path(str(root/'Reequilibrate.py'))
        _,_,geo,dirs,area,length,op,_,_,identity=model['read_inputs'](operator,root,source)
    assert identity==expanded['source_operator_identity']==seed['operator_source']
    return independent(data,expanded,seed,prior,watch,past,guard,op,geo,area,length)


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--report',type=Path)
    options=parser.parse_args()
    result=main(options.repo)
    raw=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if options.report:
        with options.report.open('xb') as out: out.write(raw)
    print('MVT2 REJECTED P7 CROSSING OFFLINE PASS',digest(raw),result['actual_norm_MPa'])
