"""Проверяет точное совпадение подготовленной установки и нативных протоколов."""

from hashlib import sha256
import json
from pathlib import Path
from subprocess import check_output
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
REPO = Path('C:/Users/avidzba/Desktop/программы/В_РАБОТЕ!/RC_Section_NDM_TQ')
BOOK = "workbook/output/RC_Section_NDM.xlsm"
EXPORT = "workbook/output/VBA_All_Code.txt"
PROOF = HERE / "ProductionVerification.json"
BASE = "C603E41639484DB313C5390930BC52F1AC3CC42ED4CE01BC1946BC01ED84FA95"
OLD_EXPORT = "7C5D85EF5D7500E95541EDF1AAF1BEC9AF2177A3B65491356A6DFE16335E365E"
CANDIDATE = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
CANDIDATE_EXPORT = "815680F95BDB321D7DF5374EAC9F9B1BAD4F4D0A9E628F09EC0BA11EE70AD90D"
PRODUCTION = "B9900F03404D160F5F473D75D4FE486243032C8DD9D4A0962CAF85EFBF5B6ACE"
AGREEMENT = "5CF619BBE5558D2F55DF9F5F11B1AC9B86D15738C2A1523D531CAEE76C614AF1"
TESTS = {
    "Both": (28, "3134734BEBA1EC9C55854FE23131915A944ACCD4D70828C37DBE434912B7F36E"),
    "HoopCapacity": (228, "456966E06EEA4F0353E239A313C891BD388064F47BEFC01FA8B0EE1D828D9677"),
    "SteelAtDesign": (10, "AB8309B58ADAB96DB039C4CED488AD37249676437952FB7ED312524BFF91AAEE"),
    "DeformationControl": (35, "30654845A3D4844F68166DD2A26CB749E1A8B54B5D37A314A9E249125E54665A"),
    "Direct": (19, "81BBDB2262B953A33B06EEC6692880E9D856A8D97EFDC2B51C79000CC6C0E863"),
}


def digest(contents):
    return sha256(contents).hexdigest().upper()


def path_digest(path):
    return digest(path.read_bytes())


def stable_json(data):
    return (json.dumps(data, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def git(*arguments):
    return check_output(["git", *arguments], cwd=REPO)


def load(relative):
    return json.loads((HERE / relative).read_text(encoding="utf-8-sig"))


def release_paths():
    root = HERE / "docs/regression/Audit03"
    return {BOOK: root / Path(BOOK).name, EXPORT: root / Path(EXPORT).name}


def verify_release():
    assert __debug__
    assert git("branch", "--show-current").strip() == b"codex/coupled-6d"
    assert not git("status", "--porcelain", "-z", "--untracked-files=all", "--", "src", "tests", "workbook/output")
    assert not list((REPO / BOOK).parent.glob("~$*.xlsm")), "Рабочая книга открыта в Excel."
    assert path_digest(HERE / "Production.json") == PRODUCTION
    production = load("Production.json")
    previous = {BOOK: BASE, EXPORT: OLD_EXPORT}
    for name, checksum in production["base"].items():
        blob = git("cat-file", "blob", f"HEAD:{name}")
        assert b"\x00" not in blob
        previous[name] = digest(blob.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))
        assert previous[name] == checksum
    installable = production["production"] | {BOOK: CANDIDATE, EXPORT: CANDIDATE_EXPORT}
    assert all(path_digest(REPO / name) == checksum for name, checksum in previous.items())
    paths = release_paths()
    assert all(path_digest(paths.get(name, HERE / name)) == checksum for name, checksum in installable.items())

    package = load("PackageChecks.json")
    with ZipFile(REPO / BOOK) as old, ZipFile(paths[BOOK]) as new:
        assert old.testzip() is None and new.testzip() is None
        names = old.namelist()
        assert names == new.namelist() and len(names) == len(set(names)) == 122
        assert [name for name in names if old.read(name) != new.read(name)] == ["xl/vbaProject.bin"]
        assert digest(new.read("xl/vbaProject.bin")) == package["vba_sha256"]
    assert package["base_sha256"] == BASE and package["candidate_sha256"] == CANDIDATE
    assert package["unchanged_package_parts"] == 121

    assert path_digest(HERE / "SourceAgreement.json") == AGREEMENT
    export = load("SourceAgreement.json")
    assert export["status"] == "PASS" and export["actual_components"] == 225 and export["unchanged_components"] == 223
    assert {module: row["source_sha256"] for module, row in export["changed_components"].items()} == {
        Path(name).stem: checksum for name, checksum in production["production"].items()
    }
    for stage in ("Compile", "Export"):
        close = load(f"{stage}Closure.json")
        assert close["State"] == "Absent"
        marker = f"OWNED_EXCEL: id={close['PID']}; utcStartTicks={close['StartTicksUTC']}"
        assert (HERE / f"{stage}.log").read_text(encoding="utf-8-sig").splitlines().count(marker) == 1
    assert f"sourceSHA256={CANDIDATE}; sourceUnchanged=True;" in (HERE / "Export.log").read_text(encoding="utf-8-sig")

    measured = {}
    for case, (assertions, checksum) in TESTS.items():
        prefix = f"Native/{case}"
        assert path_digest(HERE / f"{prefix}.Verification.json") == checksum
        proof = load(f"{prefix}.Verification.json")
        assert proof["assertions"] == assertions and proof["workbook_sha256"] == CANDIDATE and proof["case"] == case
        assert path_digest(HERE / f"{prefix}.txt") == proof["native_report_sha256"]
        close = load(f"{prefix}.txt.ProcessClosure.json")
        assert close["Passed"] and close["ChildHasExited"] and close["ChildExitCode"] == 0
        assert close["Closure"]["FinalState"]["State"] == "Absent" and not close["OrdinaryPathKilledAnything"]
        input_proof = load(f"{prefix}.txt.Ownership.json")
        assert input_proof["SourceSHA256"] == CANDIDATE and input_proof["VerifiedNewOwner"]
        measured[case] = {"assertions": assertions, "proof_sha256": checksum}
        if case in {"Both", "Direct"}:
            assert proof["direct"] == "OK" and len(proof["six_resultants"]) == 6
            measured[case]["seconds"] = proof["seconds"]
        if case == "Both":
            assert proof["capacity"] == "NumFail" and proof["confirmed_lower_lambda"] == "1.10290889219566"
            measured[case]["capacity"] = proof["capacity"]
            measured[case]["confirmed_lower_lambda"] = proof["confirmed_lower_lambda"]

    return {"status": "PASS", "pending_native": [], "source_git_revision": git("rev-parse", "HEAD").decode().strip(),
            "test_results": measured, "previous": previous, "installable": installable}


if __name__ == "__main__":
    verified_bytes = stable_json(verify_release())
    with PROOF.open("xb") as report:
        report.write(verified_bytes)
    print("RELEASE VERIFIED", path_digest(PROOF))
