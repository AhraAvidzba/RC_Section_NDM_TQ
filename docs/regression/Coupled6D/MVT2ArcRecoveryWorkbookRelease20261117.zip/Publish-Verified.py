"""Install the verified production modules, saved workbook, and full VBA export."""

import argparse
from datetime import datetime
from importlib.util import module_from_spec, spec_from_file_location
import os
from pathlib import Path
from tempfile import NamedTemporaryFile


HERE = Path(__file__).resolve().parent
spec = spec_from_file_location("verified_release", HERE / "Verify-Release.py")
verification = module_from_spec(spec)
spec.loader.exec_module(verification)
REPO = verification.REPO
RECEIPT = HERE / "Publication.json"
BACKUP = HERE / "BeforePublication"
LOCK = HERE / "InstallInProgress.json"


def stage_file(destination, contents):
    with NamedTemporaryFile(dir=destination.parent, prefix=".ndm-mvt-h26-", suffix=".pending", delete=False) as stream:
        prepared = Path(stream.name)
        try:
            stream.write(contents)
            stream.flush()
            os.fsync(stream.fileno())
        except BaseException:
            stream.close()
            prepared.unlink(missing_ok=True)
            raise
    return prepared


def prepare_plan():
    raw = verification.PROOF.read_bytes()
    verified = verification.verify_release()
    assert verified["status"] == "PASS" and not verified["pending_native"]
    assert raw == verification.stable_json(verified), "Regenerate ProductionVerification.json for the current baseline"
    workbooks = verification.release_paths()
    inputs = {name: HERE / name for name in verified["installable"] if name not in workbooks}
    inputs.update((name, workbooks[name]) for name in (verification.EXPORT, verification.BOOK))
    assert len(inputs) == 4
    previous, contents = {}, {}
    for name, source in inputs.items():
        path = REPO / name
        assert path.is_file() and path.resolve(strict=True) == path, name
        assert source.is_file() and source.resolve(strict=True) == source, source
        previous[name] = path.read_bytes()
        assert verification.digest(previous[name]) == verified["previous"][name], name
        contents[name] = source.read_bytes()
        assert verification.digest(contents[name]) == verified["installable"][name], name
    assert not RECEIPT.exists() and not BACKUP.exists() and not LOCK.exists(), "Prior install evidence exists"
    return verified, verification.digest(raw), previous, contents


def install(verified, proof_hash, previous, contents):
    pending, replaced = {}, []
    installed = verified["installable"]
    prior = verified["previous"]
    status = {
        "status": "INSTALLING",
        "time": datetime.now().astimezone().isoformat(),
        "source_git_revision": verified["source_git_revision"],
        "verification_sha256": proof_hash,
        "installed": installed,
        "previous": prior,
    }
    with LOCK.open("xb") as stream:
        stream.write(verification.stable_json(status))
        stream.flush()
        os.fsync(stream.fileno())
    try:
        BACKUP.mkdir()
        for name, data in contents.items():
            saved = BACKUP / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            with saved.open("xb") as stream:
                stream.write(previous[name])
                stream.flush()
                os.fsync(stream.fileno())
            assert verification.path_digest(saved) == prior[name], name
            pending[name] = stage_file(REPO / name, data)
            assert verification.path_digest(pending[name]) == installed[name], name
        assert verification.git("rev-parse", "HEAD").decode("ascii").strip() == status["source_git_revision"]
        observed = verification.git("status", "--porcelain", "-z", "--untracked-files=all", "--", "src", "tests", "workbook/output")
        own_pending = {b"?? " + path.relative_to(REPO).as_posix().encode("utf-8") for path in pending.values()}
        assert {item for item in observed.split(b"\0") if item} <= own_pending, "Unrelated changes during staging"
        for name, prepared in pending.items():
            destination = REPO / name
            assert verification.path_digest(destination) == prior[name], f"File changed during staging: {name}"
            os.replace(prepared, destination)
            replaced.append(name)
        assert all(verification.path_digest(REPO / name) == expected for name, expected in installed.items())
        status["status"] = "PASS"
        receipt_file = stage_file(RECEIPT, verification.stable_json(status))
        try:
            if RECEIPT.exists():
                raise FileExistsError(RECEIPT)
            os.replace(receipt_file, RECEIPT)
        finally:
            receipt_file.unlink(missing_ok=True)
    except BaseException:
        for name in reversed(replaced):
            destination = REPO / name
            if verification.path_digest(destination) != installed[name]:
                raise RuntimeError(f"Concurrent edit: retained the backup for {name}")
            os.replace(stage_file(destination, previous[name]), destination)
        assert all(verification.path_digest(REPO / name) == expected for name, expected in prior.items())
        raise
    finally:
        for path in pending.values():
            path.unlink(missing_ok=True)
    LOCK.unlink()
    print("PUBLISHED", verification.path_digest(RECEIPT), installed[verification.BOOK], installed[verification.EXPORT])


def main():
    if not __debug__:
        raise RuntimeError("Enable Python assertions for installation")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--install", action="store_true", help="replace the verified files in the current worktree")
    args = parser.parse_args()
    verified, proof_hash, previous, contents = prepare_plan()
    if args.install:
        install(verified, proof_hash, previous, contents)
    else:
        print("READY", proof_hash, len(contents), verified["installable"][verification.BOOK])


if __name__ == "__main__":
    main()
