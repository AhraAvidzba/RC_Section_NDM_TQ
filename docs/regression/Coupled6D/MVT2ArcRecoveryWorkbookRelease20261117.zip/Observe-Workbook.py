"""Read source-module scope and saved Results cells from the exact native books."""

import argparse
from decimal import Decimal, InvalidOperation
from hashlib import sha256
import json
from pathlib import Path
import posixpath
import re
from zipfile import ZipFile
import xml.etree.ElementTree as ET

from ReadVbaSource import body, workbook_sources


NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
COMPONENTS = ("N", "Mx", "My", "T", "Qx", "Qy")
VBA_PART = "xl/vbaProject.bin"


def digest(data):
    return sha256(data).hexdigest().upper()


def file_hash(path):
    return digest(path.read_bytes())


def literal_safe_fold(value):
    return "\n".join("".join(part if index % 2 else part.lower() for index, part in enumerate(
        re.split(r'("(?:[^"\n]|"")*")', line))).rstrip() for line in value.splitlines()).strip("\n")


def compiler_body(source, module):
    value = literal_safe_fold(body(source))
    edits = []
    if module == "CCoupledNewtonSolver":
        for head, exponent, decimal in (("uncertainty = uncertainty * norm + ", "2e-12", "0.000000000002"),
                                         ("const check_tolerance as double = ", "1e-12", "0.000000000001")):
            assert Decimal(exponent) == Decimal(decimal)
            if head+exponent in value:
                assert value.count(head+exponent) == 1
                value = value.replace(head+exponent, head+decimal)
                edits.append([exponent, decimal])
    return value, edits


class BookXml:
    def __init__(self, archive):
        self.archive = archive
        book = ET.fromstring(archive.read("xl/workbook.xml"))
        relations = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        rels = {item.get("Id"): item.get("Target") for item in relations}
        self.names = {node.get("name"): node.text for node in book.findall(f".//{NS}definedName")
                      if node.get("localSheetId") is None}
        self.sheets = {}
        for node in book.findall(f".//{NS}sheet"):
            target = rels[node.get(REL+"id")]
            self.sheets[node.get("name")] = target.lstrip("/") if target.startswith("/") else posixpath.join("xl", target)
        shared = ET.fromstring(archive.read("xl/sharedStrings.xml"))
        self.strings = ["".join(node.text or "" for node in item.iter(NS+"t")) for item in shared]

    def cell_value(self, cell, shared_formulas):
        kind = cell.get("t", "n")
        value = cell.findtext(NS+"v")
        formula = cell.find(NS+"f")
        equation = formula.text if formula is not None else None
        if formula is not None and formula.get("t") == "shared":
            index = formula.get("si")
            if equation is not None:
                assert index not in shared_formulas
                shared_formulas[index] = equation
            else:
                equation = shared_formulas[index]
                # The smoke fixture shares named-table lookup formulas only.
                # Relative A1/R1C1 offsets would require rebasing the formula.
                assert not re.search(r"(?i)\b[A-Z]{1,3}\$?\d+\b", equation), equation
        if kind == "s" and value is not None:
            value = self.strings[int(value)]
        elif kind == "inlineStr":
            value = "".join(element.text or "" for element in cell.iter(NS+"t"))
        if value in (None, "") and equation is None:
            return None
        return kind, value, equation

    def cells(self, sheet):
        shared_formulas = {}
        with self.archive.open(self.sheets[sheet]) as data:
            for _, row in ET.iterparse(data, events=("end",)):
                if row.tag == NS+"row":
                    for cell in row.findall(NS+"c"):
                        content = self.cell_value(cell, shared_formulas)
                        if content is not None:
                            yield cell.get("r"), content
                    row.clear()


def normalized_cells(book, name):
    def canonical(cell):
        kind, value, formula = cell
        if kind == "n" and value is not None:
            return ["n", str(Decimal(value).normalize()), formula]
        if kind in ("s", "inlineStr"):
            kind = "text"
        return [kind, value, formula]
    return {address: canonical(cell) for address, cell in book.cells(name)}


def columns(start, count):
    index = 0
    for character in start:
        index = 26*index + ord(character) - 64
    values = []
    for current in range(index, index+count):
        result = ""
        while current:
            current, digit = divmod(current-1, 26)
            result = chr(65+digit)+result
        values.append(result)
    return values


def property_cells(book):
    match = re.fullmatch(r"'?Results'?!\$([A-Z]+)\$(\d+)", book.names["rngNDMSectionProperties"])
    assert match
    col, first_row = columns(match[1], 6), int(match[2])
    out = {"ALL": {}, "HardShear": {}}
    entries = dict(book.cells("Results"))
    assert [entries[f"{c}{first_row}"][1] for c in col] == ["RunID", "LoadCase", "Parameter", "Value", "Unit", "Comment"]
    for index in range(first_row+1, max(int(re.search(r"\d+", x)[0]) for x in entries)+1):
        address = [f"{c}{index}" for c in col]
        row = [entries.get(k, (None, None, None)) for k in address]
        scope, name = row[1][1], row[2][1]
        if scope not in out or not name:
            continue
        if scope == "ALL" and not name.startswith("Output."):
            continue
        if scope == "HardShear" and name not in ("DirectStateStatus", "CapacityStatus", "OverallStatus", "LambdaCapacity",
                "Coupled.Capacity.ResultCode", "Coupled.Capacity.LimitState", "Coupled.Capacity.LowerLambda") and not name.startswith(("Coupled.Internal.", "Coupled.Limit.")):
            continue
        assert name not in out[scope]
        out[scope][name] = {"value": row[3][1], "kind": row[3][0], "unit": row[4][1], "cell": address[3], "formula": row[3][2]}
    return out


def input_row(book):
    source = book.names["rngLoadCombinations"]
    match = re.fullmatch(r"'?Config'?!\$([A-Z]+)\$(\d+):\$([A-Z]+)\$(\d+)", source)
    assert match
    col, first = columns(match[1], 10), int(match[2]); assert col[-1] == match[3]
    entries = normalized_cells(book, "Config")
    head = [entries[f"{c}{first}"][1] for c in col]
    for row in range(first+1, int(match[4])+1):
        if entries.get(f"{col[0]}{row}", [None, None])[1] == "HardShear":
            return {"range": source, "row": row, "cells": {name: {"cell": f"{c}{row}", "data": entries.get(f"{c}{row}")}
                                                            for c, name in zip(col, head, strict=True)}}
    raise ValueError("HardShear source row missing")


def module_observation(root, source, compiled, config):
    avba, before = workbook_sources(source)
    bvba, after = workbook_sources(compiled)
    assert set(before) == set(after) and len(before) == 225
    byte_changes, semantic_changes, imported = [], [], {}
    hashes = {}
    for name, previous in before.items():
        current = after[name]
        canonical = [literal_safe_fold(x) for x in (previous, current)]
        if previous != current:
            byte_changes.append(name)
        if canonical[0] != canonical[1]:
            semantic_changes.append(name)
        hashes[name] = {"source": digest(canonical[0].encode()), "compiled": digest(canonical[1].encode()),
                        "raw_source": digest(previous.encode()), "raw_compiled": digest(current.encode())}
    assert sorted(semantic_changes) == config["import_modules"]
    for name in semantic_changes:
        src = root / f"src/Solver/{name}.cls"
        assert file_hash(src) == config["inputs"][f"src/Solver/{name}.cls"]
        expected, edits = compiler_body(src.read_text(encoding="utf-8-sig"), name)
        observed, observed_edits = compiler_body(after[name], name)
        assert expected == observed and not observed_edits
        imported[name] = {"input_file_sha256": file_hash(src), "canonical_body_sha256": digest(observed.encode()),
                          "equivalent_VBE_literal_normalizations": edits}
    return {"module_count": len(before), "source_vba_sha256": avba, "compiled_vba_sha256": bvba,
            "modules": hashes, "actual_semantic_change": sorted(semantic_changes),
            "actual_casing_only": sorted(set(byte_changes) - set(semantic_changes)), "imported": imported}


def observe(root, release=False):
    config = json.loads((root / "Fixture.json").read_bytes())
    build = json.loads((root / "docs/regression/CodeUpdate.json").read_bytes())
    source = root / config["workbook"]
    compiled = root / "docs/regression/Diagnostic.xlsm"
    compiled_hash = file_hash(compiled)
    assert file_hash(source) == config["source_workbook_sha256"] and compiled_hash == build["WorkbookSHA256"]
    if release:
        package = json.loads((root / "PackageChecks.json").read_bytes())
        compiled = root / "docs/regression/Audit03/RC_Section_NDM.xlsm"
        assert file_hash(compiled) == package["candidate_sha256"] and compiled_hash == package["compiled_sha256"]
    vba = module_observation(root, source, compiled, config)
    book_scope = {}
    with ZipFile(source) as origin, ZipFile(compiled) as candidate:
        a, b = BookXml(origin), BookXml(candidate)
        assert list(a.sheets) == list(b.sheets)
        for sheet in ("Config", "Сечения"):
            left, right = normalized_cells(a, sheet), normalized_cells(b, sheet)
            different = {key: [left.get(key), right.get(key)] for key in sorted(left.keys() | right.keys())
                         if left.get(key) != right.get(key)}
            book_scope[sheet] = {"source_nonempty": len(left), "compiled_nonempty": len(right), "different": different}
        left, right = set(origin.namelist()), set(candidate.namelist())
        zip_delta = {"removed": sorted(left-right), "added": sorted(right-left),
                     "common_bytes_differ": sorted(name for name in left & right if origin.read(name) != candidate.read(name))}
    result = {"fixture_sha256": file_hash(root / "Fixture.json"), "source_book_sha256": file_hash(source),
              "tested_book_sha256": file_hash(compiled), "compiled_book_sha256": compiled_hash,
              "vba": vba, "input_cell_comparison": book_scope, "zip_delta": zip_delta,
              "cases": {}}
    for case in ("Direct", "Both"):
        log = (root / f"Native/{case}.txt").read_text(encoding="utf-8-sig")
        found = re.search(r"^RESULTS_SAVE_REOPEN: before=([0-9A-F]{64}); after=\1; equal=True; file=(.+)$", log, re.M)
        assert found
        filename = Path(found[2]).resolve(strict=True)
        assert filename.is_relative_to((root / "Temp").resolve())
        with ZipFile(filename) as saved:
            book = BookXml(saved)
            result["cases"][case] = {"saved_xlsm_sha256": file_hash(filename), "after_open_results_sha256": found[1],
                                     "saved_results_xml_sha256": digest(saved.read(book.sheets["Results"])),
                                     "saved_config_xml_sha256": digest(saved.read(book.sheets["Config"])),
                                     "result_properties": property_cells(book), "load_case": input_row(book)}
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--release", action="store_true")
    options = parser.parse_args()
    evidence = (json.dumps(observe(options.root, options.release), ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    with options.out.open("xb") as report:
        report.write(evidence)
    print("OBSERVED VBA AND SAVED CELLS SHA-256", digest(evidence))
