"""Read VBA module source from plain XLSM files, using CFB and MS-OVBA records."""

from hashlib import sha256
import re
import struct
from zipfile import ZipFile


END = 0xFFFFFFFE
EMPTY = 0xFFFFFFFF


def word(data, offset):
    return struct.unpack_from("<H", data, offset)[0]


def dword(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def words32(data):
    return list(struct.unpack(f"<{len(data) // 4}I", data))


class Compound:
    def __init__(self, data):
        assert data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
        assert word(data, 28) == 0xFFFE
        self.data = data
        self.size = 1 << word(data, 30)
        self.mini_size = 1 << word(data, 32)
        self.threshold = dword(data, 56)
        fat_sectors = [sector for sector in words32(data[76:512]) if sector != EMPTY]
        difat = dword(data, 68)
        for _ in range(dword(data, 72)):
            chunk = words32(self.sector(difat))
            fat_sectors.extend(sector for sector in chunk[:-1] if sector != EMPTY)
            difat = chunk[-1]
        assert len(fat_sectors) == dword(data, 44)
        self.fat = words32(b"".join(self.sector(index) for index in fat_sectors))
        directory = self.chain(dword(data, 48), self.fat, self.sector)
        self.nodes = [directory[i:i + 128] for i in range(0, len(directory), 128)]
        assert self.nodes[0][66] == 5
        mini_fat = self.chain(dword(data, 60), self.fat, self.sector)
        assert len(mini_fat) == dword(data, 64) * self.size
        self.mini_fat = words32(mini_fat)
        self.mini = self.storage(self.nodes[0], False)

    def sector(self, index):
        start = (index + 1) * self.size
        block = self.data[start:start + self.size]
        assert len(block) == self.size, index
        return block

    def mini_sector(self, index):
        start = index * self.mini_size
        return self.mini[start:start + self.mini_size]

    @staticmethod
    def chain(index, table, reader):
        output, seen = [], set()
        while index != END:
            assert 0 <= index < len(table) and index not in seen, index
            seen.add(index)
            output.append(reader(index))
            index = table[index]
        return b"".join(output)

    def storage(self, node, allow_mini=True):
        index = dword(node, 116)
        size = struct.unpack_from("<Q" if self.size == 4096 else "<I", node, 120)[0]
        if size == 0:
            return b""
        if allow_mini and size < self.threshold:
            raw = self.chain(index, self.mini_fat, self.mini_sector)
        else:
            raw = self.chain(index, self.fat, self.sector)
        assert len(raw) >= size
        return raw[:size]

    def children(self, node_index):
        node = self.nodes[node_index]
        stack = [dword(node, 76)]
        result = {}
        visited = set()
        while stack:
            index = stack.pop()
            if index == EMPTY:
                continue
            assert index not in visited
            visited.add(index)
            entry = self.nodes[index]
            size = word(entry, 64)
            assert 2 <= size <= 64 and entry[size - 2:size] == b"\0\0"
            name = entry[:size - 2].decode("utf-16le")
            assert name not in result
            result[name] = index
            stack.extend((dword(entry, 68), dword(entry, 72)))
        return result


def decompress(data):
    assert data[0] == 1
    output = bytearray()
    cursor = 1
    while cursor < len(data):
        header = word(data, cursor)
        assert header & 0x7000 == 0x3000
        end = cursor + (header & 0xFFF) + 3
        assert end <= len(data)
        cursor += 2
        if not header & 0x8000:
            assert end - cursor == 4096
            output.extend(data[cursor:end])
            cursor = end
            continue
        start = len(output)
        while cursor < end:
            flags = data[cursor]
            cursor += 1
            for index in range(8):
                if cursor == end:
                    break
                if flags & (1 << index):
                    token = word(data, cursor)
                    cursor += 2
                    distance_bits = max(4, (len(output) - start - 1).bit_length())
                    length_mask = 0xFFFF >> distance_bits
                    offset = (token >> (16 - distance_bits)) + 1
                    assert 0 < offset <= len(output) - start
                    for _ in range((token & length_mask) + 3):
                        output.append(output[-offset])
                else:
                    output.append(data[cursor])
                    cursor += 1
        assert cursor == end and len(output) - start <= 4096
    return bytes(output)


def source_records(data):
    module_marker = struct.pack("<HI", 0x000F, 2)
    cookie = struct.pack("<HI", 0x0013, 2)
    starts = [m.start() for m in re.finditer(re.escape(module_marker), data)
              if data[m.end()+2:m.end()+8] == cookie]
    (offset,) = starts
    count = word(data, offset+6)
    codepage_marker = struct.pack("<HI", 3, 2)
    codec = "cp" + str(word(data, data.index(codepage_marker, 0, offset) + 6))
    offset += 16

    def read(kind):
        nonlocal offset
        assert word(data, offset) == kind, (offset, kind, word(data, offset))
        length = dword(data, offset+2)
        result = data[offset+6:offset+6+length]
        offset += 6+length
        return result

    modules = {}
    for _ in range(count):
        name = read(0x0019).decode(codec)
        if word(data, offset) == 0x0047:
            assert read(0x0047).decode("utf-16le") == name
        stream = read(0x001A).decode(codec)
        assert read(0x0032).decode("utf-16le") == stream
        read(0x001C)
        read(0x0048)
        (start,) = words32(read(0x0031))
        read(0x001E)
        read(0x002C)
        module_type = word(data, offset)
        assert module_type in (0x0021, 0x0022) and not read(module_type)
        while word(data, offset) in (0x0025, 0x0028):
            assert not read(word(data, offset))
        assert not read(0x002B) and name not in modules
        modules[name] = (stream, start)
    return codec, modules


def workbook_sources(workbook):
    with ZipFile(workbook) as zip_file:
        raw = zip_file.read("xl/vbaProject.bin")
    cfb = Compound(raw)
    children = cfb.children(cfb.children(0)["VBA"])
    codec, registry = source_records(decompress(cfb.storage(cfb.nodes[children["dir"]])))
    modules = {}
    for name, (stream, start) in registry.items():
        data = cfb.storage(cfb.nodes[children[stream]])
        source = decompress(data[start:]).decode(codec)
        assert source.startswith(f'Attribute VB_Name = "{name}"'), (name, source[:120])
        modules[name] = source
    return sha256(raw).hexdigest().upper(), modules


def body(source):
    normalized = source.replace("\r\n", "\n").strip("\n")
    return re.split(r"^Option Explicit\b", normalized, maxsplit=1, flags=re.M)[1].rstrip()
