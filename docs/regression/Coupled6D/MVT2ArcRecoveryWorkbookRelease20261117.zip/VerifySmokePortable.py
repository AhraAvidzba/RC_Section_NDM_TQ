"""Independently replay the uninstrumented two-class Excel smoke package."""

import argparse
from decimal import Decimal as D
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
from subprocess import check_output
from zipfile import ZipFile


CASES = {"Direct": ("WORKBOOK_TIMING", 19), "HoopCapacity": ("HOOP_CAPACITY", 228), "SteelAtDesign": ("STEEL_AT_DESIGN", 10),
         "DeformationControl": ("DEFORMATION_CONTROL", 35), "Both": ("WORKBOOK_TIMING", 28)}
COMPONENTS = ("N", "Mx", "My", "T", "Qx", "Qy")
LOCALS = (28000, 510000, 180000, 1500000, 17000, -7100)
SCALES = (D("9806.65"), D("9806650"), D("9806650"), D("9806650"), D("9806.65"), D("9806.65"))
BASE = "C603E41639484DB313C5390930BC52F1AC3CC42ED4CE01BC1946BC01ED84FA95"
SMOKE = "478CD32D80CDAC28024ABC7EC81442F1911515657CBDF3AEAF1072E40931C20F"
RELEASE = "245F3647A30ADAF86FB4ACAF135F70C7F01C730CA7E199463997453CF900E012"
GIT_PARENT = "e41a55faad85e6ac38eba67769bed0004e172759"
GIT_RELEASE = "709e7dfa16c192748fc2c6d999925bdbf9948a4c"
BOOK = "workbook/output/RC_Section_NDM.xlsm"
LOWER = D("1.10290889219566")


def digest(value):
    return sha256(value).hexdigest().upper()


def line_number(text, rule):
    (result,) = re.findall(rule, text, re.M)
    return result


def decode(raw):
    return raw.decode("utf-16" if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig").replace("\r\n", "\n")


def dwire(value):
    return D(value.replace(",", "."))


class Parts:
    def __init__(self, archive, prefix):
        self.archive = archive
        self.prefix = prefix

    def read(self, name):
        return self.archive.read(self.prefix + name)

    def open(self, name):
        return self.archive.open(self.prefix + name)


def reflect_script(archive, name):
    namespace = {"__name__": name, "__file__": name}
    if name == "Observe-Workbook.py":
        # The OOXML-only portion needs no OLE reader or XLSM in portable mode.
        text = decode(archive.read(name))
        text = text.replace("from ReadVbaSource import body, workbook_sources", "")
    else:
        text = decode(archive.read(name))
    exec(compile(text, name, "exec"), namespace)
    return namespace


def check_numeric_wire(raw, printed):
    native = dwire(printed)
    assert abs(D(raw) - native) <= D(5).scaleb(native.adjusted()-15), (raw, native)


def check_saved(raw, observational, case, log, original, archive):
    parsed = re.findall(r"^OK: direct (\S+) actual=(\S+) expected=(\S+)$", log, re.M)
    assert [row[0] for row in parsed] == list(COMPONENTS)
    expected_status = "N/A" if case == "Direct" else "NumFail"
    seconds = dwire(line_number(log, rf"^TIMING_SECONDS: ([0-9.,]+) \| {case} \| Excel$"))
    saved_hash, filename = line_number(log, r"^RESULTS_SAVE_REOPEN: before=([A-F0-9]{64}); after=\1; equal=True; file=(.+)$")
    assert filename.lower().endswith("\\rc_section_ndm_saved.xlsm") and saved_hash == observational["after_open_results_sha256"] == original["results_reopened_sha256"]
    parts = Parts(archive, f"Reopened/{case}/")
    model = raw["BookXml"](parts)
    properties, loads = raw["property_cells"](model), raw["input_row"](model)
    assert properties == observational["result_properties"] and loads == observational["load_case"]
    for name, sheet in (("saved_results_xml_sha256", "Results"), ("saved_config_xml_sha256", "Config")):
        assert digest(parts.read(model.sheets[sheet])) == observational[name]
    assert original["reopened_workbook_sha256"] == observational["saved_xlsm_sha256"]
    assert properties["HardShear"]["DirectStateStatus"]["value"] == "OK"
    assert properties["HardShear"]["CapacityStatus"]["value"] == expected_status
    assert properties["HardShear"]["OverallStatus"]["value"] == ("OK" if case == "Direct" else expected_status)
    conventions = {key: properties["ALL"][key]["value"] for key in ("Output.SignConvention.N", "Output.SignConvention.Mx", "Output.SignConvention.My")}
    assert list(conventions.values()) == ["Tension", "+Y tension", "+X tension"]
    resultants = []
    for (component, actual, expected), factor, target in zip(parsed, SCALES, LOCALS, strict=True):
        output = properties["HardShear"]["Coupled.Internal."+component]
        unit = "tf*m" if component in ("Mx", "My", "T") else "tf"
        assert output["unit"] == unit and output["kind"] == "n" and output["formula"] is None
        demand = loads["cells"][f"{component}, {unit}"]["data"]
        assert demand[0] == "n" and demand[2] is None
        check_numeric_wire(output["value"], actual)
        check_numeric_wire(demand[1], expected)
        assert abs(D(demand[1]) * factor - target) < D("1e-6")
        assert abs(dwire(actual) - dwire(expected)) < D("1e-8")
        resultants.append({"name": component, "stored_signed": output["value"], "demand_signed": demand[1], "unit": unit,
                           "value_cell": output["cell"], "internal_residual_N_or_Nmm": str((D(output["value"]) - D(demand[1])) * factor)})
    assert original["six_resultants"] == [list(row) for row in parsed]
    assert str(seconds) == str(original["seconds"]) and seconds > 0
    result = {"status": "OK", "capacity_status": expected_status, "calculation_seconds": str(seconds),
              "after_open_results_sha256": saved_hash, "reopened_xlsm_sha256": observational["saved_xlsm_sha256"], "actual_resultants": resultants}
    if case == "Both":
        upper = line_number(log, r"^TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=([^;]+); limit=; code=NUMERICAL_FAILURE$")
        assert dwire(upper) == LOWER and str(LOWER) == original["confirmed_lower_lambda"]
        p = properties["HardShear"]
        assert p["Coupled.Capacity.ResultCode"]["value"] == "NUMERICAL_FAILURE" and p["LambdaCapacity"]["value"] is None
        check_numeric_wire(p["Coupled.Capacity.LowerLambda"]["value"], upper)
        assert all(f"OK: no unconfirmed limit component {component}\n" in log for component in COMPONENTS)
        assert all(p.get("Coupled.Limit."+component, {}).get("value") is None for component in COMPONENTS)
        assert "OK: native marker does not claim a limit for NumFail" in log
        result.update(last_confirmed_lambda=str(LOWER), numerical_failure_code="NUMERICAL_FAILURE", physical_capacity_established=False)
    return result


def part_hashes(raw_book):
    with ZipFile(BytesIO(raw_book)) as source:
        assert len(source.namelist()) == len(set(source.namelist())) == 122 and source.testzip() is None
        return {name: digest(source.read(name)) for name in source.namelist()}


def check_pin(repository, revision, observation, expected):
    def git(*args):
        return check_output(["git", *args], cwd=repository)
    assert set(observation) == set(expected)
    for name, expected_hash in expected.items():
        item = observation[name]
        assert item["installed_equivalent_sha256"] == expected_hash
        if repository is not None:
            blob = git("cat-file", "blob", f"{revision}:{name}")
            assert git("rev-parse", f"{revision}:{name}").decode().strip() == item["git_blob_id"]
            assert len(blob) == item["raw_bytes"] and digest(blob) == item["raw_git_blob_sha256"]
            if item["line_ending_normalization"]:
                assert not name.endswith(".xlsm") and b"\0" not in blob
                blob = blob.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
            assert digest(blob) == expected_hash


def replay(archive, repository=None):
    def read(path):
        return json.loads(decode(archive.read(path)))

    manifest = read("SHA256SUMS.json")
    assert set(archive.namelist()) == set(manifest) | {"SHA256SUMS.json"}
    assert all(digest(archive.read(name)) == want for name, want in manifest.items())
    fixture, config, build, close = (read(name) for name in ("Fixture.json", "Production.json", "docs/regression/CodeUpdate.json", "CompileClosure.json"))
    expected_modules = sorted(Path(name).stem for name in config["production"])
    assert expected_modules == fixture["import_modules"] == build["Modules"]
    assert fixture["source_workbook_sha256"] == build["ProductionSHA256"] == BASE and build["WorkbookSHA256"] == SMOKE
    assert fixture["source_revision"] == config["revision"] == "f2f4369"
    assert manifest["Production.json"] == fixture["production_definition_sha256"]
    assert all(manifest[name] == value for name, value in fixture["inputs"].items())
    assert all(config["production"][name] == manifest[name] != config["base"][name] for name in config["base"])
    assert build["Compiled"] and not (build["ProductionChanged"] or build["EntryPointNames"] or build["RetiredModules"] or build["TraceGeometry"])
    release = "Publication.json" in manifest
    tested_book = RELEASE if release else SMOKE
    compiled_log = decode(archive.read("Compile.log"))
    pid, ticks = line_number(compiled_log, r"^OWNED_EXCEL: id=(\d+); utcStartTicks=(\d+)$")
    assert close["State"] == "Absent" and (str(close["PID"]), close["StartTicksUTC"]) == (pid, ticks)
    assert "PRIVATE_CODE_READY: modules=2; production unchanged=True" in compiled_log
    protected = [json.loads(row) for row in decode(archive.read("Run.ndjson")).splitlines() if row]
    first = "BeforePackagedMVTArcExport" if release else "CompileHardShearProductionSmoke"
    assert [row["phase"] for row in protected] == [first] + ["RunHardShearProduction"+case for case in CASES]
    for check in protected:
        assert check["ramMiB"] >= 6500 and check["freeCommitGiB"] >= 8 and check["freeC_MiB"] >= 80 and check["freeD_GiB"] >= 4
        assert all(owner["ProtectedUser"] for owner in check["excel"])

    observation = read("WorkbookCellsAndVba.json")
    assert observation["source_book_sha256"] == BASE and observation["compiled_book_sha256"] == SMOKE
    assert observation["tested_book_sha256"] == tested_book
    assert observation["fixture_sha256"] == manifest["Fixture.json"]
    spectra = observation["vba"]
    assert len(spectra["modules"]) == spectra["module_count"] == 225
    detected = sorted(name for name, comparison in spectra["modules"].items() if comparison["source"] != comparison["compiled"])
    cosmetic = sorted(name for name, comparison in spectra["modules"].items() if comparison["raw_source"] != comparison["raw_compiled"] and name not in detected)
    assert detected == spectra["actual_semantic_change"] == expected_modules and cosmetic == spectra["actual_casing_only"]
    assert len(cosmetic) == 13 and set(spectra["imported"]) == set(expected_modules)
    for name in expected_modules:
        assert spectra["imported"][name]["input_file_sha256"] == config["production"][f"src/Solver/{name}.cls"]
    for comparison in observation["input_cell_comparison"].values():
        assert comparison["source_nonempty"] == comparison["compiled_nonempty"]
        assert all(a[2] is not None and a[2] == b[2] for a, b in comparison["different"].values())

    release_details = {}
    production_proof = None
    if release:
        package, production_proof, publication, source_agreement, git_proof = (read(name) for name in (
            "PackageChecks.json", "ProductionVerification.json", "Publication.json", "SourceAgreement.json", "GitArtifacts.json"))
        assert package["base_sha256"] == BASE and package["compiled_sha256"] == SMOKE and package["candidate_sha256"] == RELEASE
        assert package["vba_sha256"] == spectra["compiled_vba_sha256"] and package["unchanged_package_parts"] == 121
        old_parts, new_parts = git_proof["old_zip_parts"], git_proof["new_zip_parts"]
        assert len(old_parts) == 122 and set(old_parts) == set(new_parts)
        assert [name for name in old_parts if old_parts[name] != new_parts[name]] == ["xl/vbaProject.bin"]
        assert observation["zip_delta"] == {"removed": [], "added": [], "common_bytes_differ": ["xl/vbaProject.bin"]}
        assert old_parts["xl/vbaProject.bin"] == spectra["source_vba_sha256"] and new_parts["xl/vbaProject.bin"] == spectra["compiled_vba_sha256"]
        assert not any(comparison["different"] for comparison in observation["input_cell_comparison"].values())
        assert source_agreement["status"] == "PASS" and source_agreement["actual_components"] == 225 and source_agreement["unchanged_components"] == 223
        assert sorted(source_agreement["changed_components"]) == expected_modules
        for module, details in source_agreement["changed_components"].items():
            assert details["source_sha256"] == config["production"][f"src/Solver/{module}.cls"]
        assert publication["status"] == production_proof["status"] == "PASS" and not production_proof["pending_native"]
        assert publication["verification_sha256"] == manifest["ProductionVerification.json"]
        assert publication["source_git_revision"] == production_proof["source_git_revision"] == git_proof["before_revision"] == GIT_PARENT
        assert git_proof["after_revision"] == GIT_RELEASE
        assert publication["installed"] == production_proof["installable"] and publication["previous"] == production_proof["previous"]
        assert publication["installed"][BOOK] == RELEASE and publication["previous"][BOOK] == BASE
        check_pin(repository, GIT_PARENT, git_proof["previous"], publication["previous"])
        check_pin(repository, GIT_RELEASE, git_proof["installed"], publication["installed"])
        if repository is not None:
            def git(*args):
                return check_output(["git", *args], cwd=repository)
            assert git("rev-parse", GIT_RELEASE+"^").decode().strip() == GIT_PARENT
            assert set(git("diff-tree", "--no-commit-id", "--name-only", "-r", GIT_RELEASE).decode().splitlines()) == set(publication["installed"])
            assert part_hashes(git("cat-file", "blob", f"{GIT_PARENT}:{BOOK}")) == old_parts
            assert part_hashes(git("cat-file", "blob", f"{GIT_RELEASE}:{BOOK}")) == new_parts
        exported = read("ExportClosure.json")
        export_log = decode(archive.read("Export.log"))
        assert exported["State"] == "Absent" and f"OWNED_EXCEL: id={exported['PID']}; utcStartTicks={exported['StartTicksUTC']}" in export_log
        assert f"components=225; sourceSHA256={RELEASE}; sourceUnchanged=True;" in export_log
        release_details = {"git_release_revision": GIT_RELEASE, "git_historical_revision": GIT_PARENT,
                           "unchanged_non_VBA_package_parts": 121, "published_vba_project_sha256": package["vba_sha256"],
                           "native_production_verification_sha256": manifest["ProductionVerification.json"],
                           "publication_sha256": manifest["Publication.json"], "exporter_pid": exported["PID"],
                           "exporter_closed": True}

    procedures = reflect_script(archive, "Observe-Workbook.py")
    states = {}
    observed_owners = {(pid, ticks)}
    for case, (tag, count) in CASES.items():
        base = f"Native/{case}.txt"
        source = archive.read(base)
        report = decode(source)
        original = read(f"Native/{case}.Verification.json")
        assert original["assertions"] == count and original["case"] == case and original["native_report_sha256"] == digest(source)
        assert original["workbook_sha256"] == tested_book and f"SOURCE_SHA256: {tested_book}\n" in report
        if production_proof:
            measured = production_proof["test_results"][case]
            assert measured["assertions"] == count and measured["proof_sha256"] == manifest[f"Native/{case}.Verification.json"]
        assert f"TOTAL_COUPLED_{tag}: passed={count}; failed=0\n" in report
        assert len(re.findall(r"^OK: ", report, re.M)) == count
        assert "WATCHDOG_COMPLETED: exit=0; source unchanged=True" in report and "SOURCE_UNCHANGED: True" in report
        owner, wait = read(base+".Ownership.json"), read(base+".ProcessClosure.json")
        final, cleanup = wait["Closure"]["FinalState"], wait["RunnerCleanup"]
        assert owner["VerifiedNewOwner"] and owner["BeforeWorkbookOpen"] and owner["SourceSHA256"] == tested_book
        assert wait["Passed"] and wait["ChildHasExited"] and wait["ChildExitCode"] == 0 and wait["RunnerCleanupValid"]
        assert final["State"] == "Absent" and not wait["OrdinaryPathKilledAnything"]
        identity = (str(owner["PID"]), owner["StartTicksUTC"])
        assert identity not in observed_owners
        observed_owners.add(identity)
        assert identity == (str(final["PID"]), final["StartTicksUTC"]) == (str(cleanup["PID"]), cleanup["StartTicksUTC"])
        assert identity == line_number(report, r"^TEST_EXCEL_PROCESS: id=(\d+); startTicks=(\d+)$")
        result = {"assertions": count, "owner": owner["PID"], "owner_start_ticks": identity[1], "owner_closed": True}
        if case in ("Direct", "Both"):
            result.update(check_saved(procedures, observation["cases"][case], case, report, original, archive))
        if case == "HoopCapacity":
            for store in ("Excel", "File"):
                actual, expected = line_number(report, rf"^OK: {store} keeps multiplier Coupled.Transverse.Limit.Lambda actual=(\S+) expected=(\S+)$")
                assert dwire(actual) == dwire(expected) == D(original[f"{store}_governing_hoop_lambda"])
                assert f"OK: {store} documents the same governing point and FAIL in the structured properties" in report
                result[f"{store}_governing_hoop_lambda"] = actual
        states[case] = result
    assert len(observed_owners) == 6
    assert [row["stored_signed"] for row in states["Direct"]["actual_resultants"]] == [row["stored_signed"] for row in states["Both"]["actual_resultants"]]
    return {"status": "PASS", "fixture_sha256": manifest["Fixture.json"], "source_book_sha256": BASE, "compiled_book_sha256": SMOKE,
            "compiled_module_count": 225, "changed_source_modules": detected, "vbe_casing_only_module_count": len(cosmetic),
            "only_calculation_cache_changes_on_input_sheets": True, "compiler_pid": int(pid), "compiler_closed": True,
            "tested_book_sha256": tested_book, "total_assertions": sum(result["assertions"] for result in states.values()),
            "cases": states, **release_details}


def serialize(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--repo", type=Path, help="Independently read historical and installed Git blobs")
    options = parser.parse_args()
    with ZipFile(options.archive) as file:
        result = serialize(replay(file, options.repo))
        if "VerificationPortable.json" in file.namelist():
            assert result == file.read("VerificationPortable.json")
    if options.out:
        with options.out.open("xb") as report:
            report.write(result)
    print("EXCEL SMOKE REPLAY PASS", digest(result))
