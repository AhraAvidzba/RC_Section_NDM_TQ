"""Seal report data and raw reopened spreadsheet parts without embedding workbooks."""

import argparse
from io import BytesIO
import json
from pathlib import Path
import re
from subprocess import check_output
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import VerifySmokePortable as v


HERE = Path(__file__).resolve().parent


def git_evidence(repo, root):
    publication = json.loads((root / "Publication.json").read_bytes())

    def git(*args):
        return check_output(["git", *args], cwd=repo)

    def pins(revision, definitions):
        outcome, book = {}, None
        for name, expected in definitions.items():
            blob = git("cat-file", "blob", f"{revision}:{name}")
            raw_hash = v.digest(blob)
            canon = blob
            if raw_hash != expected:
                assert not name.endswith(".xlsm") and b"\0" not in blob
                canon = blob.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
            assert v.digest(canon) == expected, name
            outcome[name] = {"git_blob_id": git("rev-parse", f"{revision}:{name}").decode().strip(),
                             "raw_git_blob_sha256": raw_hash, "raw_bytes": len(blob),
                             "installed_equivalent_sha256": expected, "line_ending_normalization": blob != canon}
            if name == v.BOOK:
                book = blob
        assert book is not None
        return outcome, v.part_hashes(book)

    previous, old_parts = pins(v.GIT_PARENT, publication["previous"])
    installed, new_parts = pins(v.GIT_RELEASE, publication["installed"])
    return {"before_revision": v.GIT_PARENT, "after_revision": v.GIT_RELEASE, "previous": previous,
            "installed": installed, "old_zip_parts": old_parts, "new_zip_parts": new_parts}


def collect(root, observation, release, repo):
    input_report = json.loads((root / "Fixture.json").read_bytes())
    names = set(input_report["inputs"]) | {"Fixture.json", "Compile.log", "CompileClosure.json", "Run.ndjson", "docs/regression/CodeUpdate.json"}
    if release:
        names |= {"ExportClosure.json", "Export.log", "PackageChecks.json", "ProductionVerification.json", "Publication.json", "SourceAgreement.json",
                  "Run-Packaged.ps1", "VerifyPackaged.py", "Verify-Release.py", "Verify-SourceAgreement.py", "Package.py", "Publish-Verified.py"}
    files = {name: (root / name).read_bytes() for name in names}
    files.update({f"Native/{path.name}": path.read_bytes() for path in (root / "Native").iterdir() if path.is_file()})
    for name in ("ReadVbaSource.py", "Observe-Workbook.py", "VerifySmokePortable.py", "PackStage.py", "README.md"):
        files[name] = (HERE / name).read_bytes()
    files["WorkbookCellsAndVba.json"] = observation.read_bytes()
    if release:
        files["GitArtifacts.json"] = v.serialize(git_evidence(repo, root))
    for case in ("Direct", "Both"):
        log = v.decode(files[f"Native/{case}.txt"])
        loc = Path(re.search(r"^RESULTS_SAVE_REOPEN: .+file=(.+)$", log, re.M)[1]).resolve(strict=True)
        assert loc.is_relative_to((root / "Temp").resolve())
        with ZipFile(loc) as result:
            for member in ("xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/sharedStrings.xml", "xl/worksheets/sheet1.xml", "xl/worksheets/sheet5.xml"):
                files[f"Reopened/{case}/{member}"] = result.read(member)
        execution = loc.parent / "RC_Section_NDM_execution_report.txt"
        files[f"Reopened/{case}/ExecutionReport.txt"] = execution.read_bytes()
    return files


def package(files, stream):
    with ZipFile(stream, "w") as archive:
        for name, data in sorted(files.items()):
            entry = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = ZIP_DEFLATED
            archive.writestr(entry, data, compresslevel=9)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("observation", type=Path)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--release", action="store_true")
    options = parser.parse_args()
    files = collect(options.root, options.observation, options.release, options.repo)
    provisional = BytesIO()
    files["SHA256SUMS.json"] = v.serialize({name: v.digest(data) for name, data in files.items()})
    package(files, provisional)
    with ZipFile(provisional) as archive:
        files["VerificationPortable.json"] = v.serialize(v.replay(archive, options.repo if options.release else None))
    files.pop("SHA256SUMS.json")
    files["SHA256SUMS.json"] = v.serialize({name: v.digest(data) for name, data in files.items()})
    with options.archive.open("xb") as archive:
        package(files, archive)
    print("PORTABLE", options.archive, v.digest(options.archive.read_bytes()), "REPORT", v.digest(files["VerificationPortable.json"]))


if __name__ == "__main__":
    main()
