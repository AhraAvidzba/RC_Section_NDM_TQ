"""Сверяет шаг панелей и нормальный баланс на плоскости раскрытия трещины."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import atan2, cos, fsum, hypot, pi, sin, sqrt
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


COARSE = 'PanelJacobianColumnFirst20261117.zip'
COARSE_SHA = 'C24E80C272560006B8E117CC7AF1855E40093B36A1388995478106DE40B69627'
FAILURE_COMPRESSION_OVER_CYLINDER = {'PV16': 0.16, 'PV23': 1.33, 'PV25': 1.47, 'PV28': 1.28}
ES = 200000.0


def digest(data):
    return sha256(data).hexdigest().upper()


def projected_normal(ex, ey, gamma):
    """Возвращает компоненты нормали к трещине по главной растягивающей деформации."""
    # Для инженерного сдвига внедиагональное слагаемое тензора равно gamma/2.
    angle = 0.5 * atan2(gamma, ex - ey)
    return cos(angle), sin(angle)


def screen(strain, concrete, steel, panel):
    """Проверяет необходимый баланс тяги для идеально пластичной арматуры."""
    ex, ey, gamma = strain
    xx, yy, shear = concrete
    _, _, rx, fx, ry, fy, ratio, *_ = panel
    x, y = projected_normal(ex, ey, gamma)
    assert abs(x * x + y * y - 1.0) < 5e-15
    tension = fsum((xx * x * x, yy * y * y, 2.0 * shear * x * y))
    reserve = fsum((rx * (fx - steel[0]) * x * x, ry * (fy - steel[1]) * y * y))
    # Если контакты трещины сжаты, они увеличивают требуемый вклад стали.
    gap = tension - reserve
    normal_per_shear = ratio + 2.0 * x * y
    maximum_steel_normal = rx * fx * x * x + ry * fy * y * y
    external_check = shear * normal_per_shear - maximum_steel_normal
    assert abs(gap - external_check) <= 2.00005e-7
    middle = 0.5 * (xx + yy)
    radius = hypot(0.5 * (xx - yy), shear)
    return {
        'concrete_principal_MPa': [middle + radius, middle - radius],
        'strain_plane_normal_deg': 180.0 / pi * atan2(y, x),
        'concrete_normal_MPa': tension, 'steel_normal_reserve_MPa': reserve, 'normal_deficit_MPa': gap,
        'open_crack_upper_shear_for_this_normal_MPa': (
            maximum_steel_normal / normal_per_shear if normal_per_shear > 0.0 else None),
    }


def at_failure(panel, compression_ratio):
    """Восстанавливает расчётную оценку напряжений из опубликованных деформаций."""
    _, epeak, rx, fx, ry, fy, ratio, _, _, shear, nx, ny = panel
    ex, ey = nx * fx / ES, ny * fy / ES
    emin = -compression_ratio * epeak
    gamma = 2.0 * sqrt((ex - emin) * (ey - emin))
    sx, sy = fx * min(nx, 1.0), fy * min(ny, 1.0)
    concrete = (ratio * shear - rx * sx, ratio * shear - ry * sy, shear)
    return screen((ex, ey, gamma), concrete, (sx, sy), panel) | {
        'estimated_gamma': gamma, 'shear_MPa': shear, 'steel_over_yield_strain': [nx, ny],
    }


def by_state(value, panel):
    """Проецирует принятые поля на растягивающую главную ось деформаций."""
    return screen((value[0], value[1], value[3]), (value[6], value[7], value[9]), value[12:14], panel)


def verify(repo, root, coarse):
    """Сопоставляет две сетки сдвига и восстанавливает баланс в точках опыта."""
    tools = run_path(str(coarse / 'Verify-MixedPanels.py'))
    utility = {'__name__': '__pinned__'}
    material_class, panel_module = tools['CLASS'], tools['TEST']
    archived = repo / 'docs/regression/Coupled6D'
    pinned = archived / tools['PIN']
    assert digest(pinned.read_bytes()) == tools['PIN_SHA']
    with ZipFile(pinned) as source:
        exec(compile(source.read('Verify-NativeMaterialHistory.py'), str(pinned), 'exec'), utility)
        base = source.read(material_class)
    read = utility['read']
    published, pixels = tools['load_sources'](repo, coarse)
    stage = run_path(str(coarse / 'Stage-MixedPanelWeight.py'))
    fine = root / 'Fine'
    prep = read(fine / 'Preparation.json')
    assert prep['normal_jacobian_column_first'] and prep['nominal_shear_step'] == 0.000025
    nominal = b'Const STEP_SIZE As Double = 0.0001, NU As Double'
    coarse_module = (coarse / 'Corrected' / panel_module).read_bytes()
    assert coarse_module.count(nominal) == 1
    assert (fine / panel_module).read_bytes() == coarse_module.replace(
        nominal, b'Const STEP_SIZE As Double = 0.000025, NU As Double')
    for name in ('Guard-IsolatedOffice.ps1', 'Replay.Fields.csv'):
        assert digest((fine / name).read_bytes()) == prep['inputs'][name]
        assert (fine / name).read_bytes() == (coarse / 'Corrected' / name).read_bytes()
    panels = published['panels']
    fine_proof = tools['verify_run'](repo, fine, panels, (published, pixels), utility, base, stage, False)
    assert fine_proof['termination'] == 'completed' and fine_proof['verified_states'] == 6960
    assert all(c['explicit_status']['target_achieved'] for c in fine_proof['cases'].values())
    _, curves, _ = tools['read_curves'](fine, 'completed', panels)
    _, coarse_curves, _ = tools['read_curves'](coarse / 'Corrected', 'completed', panels)
    details = {}
    for (name, weight), curve in curves.items():
        rough = coarse_curves[name, weight]
        assert len(curve) == 4 * len(rough)
        assert fine_proof['cases'][f'{name}-{weight}']['explicit_status']['attempts'] == len(curve)
        same_points = list(zip(curve[3::4], rough, strict=True))
        assert all(abs(a[3] - b[3]) < 1e-15 for a, b in same_points)
        peak = max(curve, key=lambda state: state[9])
        panel = panels[name]
        row = by_state(peak, panel) | {
            'gamma': peak[3], 'shear_MPa': peak[9], 'coarse_maximum_MPa': max(state[9] for state in rough),
            'largest_common_shear_delta_MPa': max(abs(a[9] - b[9]) for a, b in same_points),
        }
        entering_crack = next((value for value in curve if value[9] >= panel[8]), None)
        if entering_crack is not None:
            beyond = [value for value in curve if value[3] >= entering_crack[3] and by_state(value, panel)['normal_deficit_MPa'] > 2e-7]
            if beyond:
                value = beyond[0]
                row['first_normal_deficit_after_cracking_load'] = by_state(value, panel) | {
                    'gamma': value[3], 'shear_MPa': value[9],
                }
        details[f'{name}-{weight}'] = row

    experiment = {name: at_failure(panels[name], value) for name, value in FAILURE_COMPRESSION_OVER_CYLINDER.items()}
    pv25 = panels['PV25']
    stages = []
    for shear, ex, ey, gamma in published['PV25_measured_strains']:
        sx, sy = ES * ex, ES * ey
        assert abs(sx) < pv25[3] and abs(sy) < pv25[5]
        concrete = (pv25[6] * shear - pv25[2] * sx, pv25[6] * shear - pv25[4] * sy, shear)
        predicted = tools['at_gamma'](curves['PV25', 20], gamma)
        stages.append({
            'gamma': gamma, 'experimental_shear_MPa': shear, 'calculated_shear_MPa': predicted[9],
            'experimental': screen((ex, ey, gamma), concrete, (sx, sy), pv25),
            'calculated_at_measured_gamma': by_state(predicted, pv25),
        })
    # Равные направления армирования PV16 и плоскость при 45 градусах дают 1,887 МПа.
    # Обратная оценка показывает требуемый уровень местной стали, если на трещине нет сцепления.
    pv16 = panels['PV16']
    assert pv16[2] == pv16[4] and pv16[3] == pv16[5] and pv16[6] == 0.0
    return {'fine': fine_proof, 'peaks_and_crack_normal_balance': details,
            'pv16_required_mean_local_steel_MPa_on_symmetric_open_plane': pv16[9] / pv16[2],
            'published_failure_normal_balance': experiment, 'pv25_on_measured_gamma': stages}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--root', default=Path(__file__).resolve().parent, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    repo = args.repo.resolve()
    archive = repo / 'docs/regression/Coupled6D' / COARSE
    assert digest(archive.read_bytes()) == COARSE_SHA
    with TemporaryDirectory(dir=args.report.resolve().parent) as temporary:
        coarse = Path(temporary)
        with ZipFile(archive) as source:
            source.extractall(coarse)
        result = verify(repo, args.root.resolve(), coarse)
    with args.report.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(result, output, indent=2, sort_keys=True, allow_nan=False)
        output.write('\n')
    print('PANEL FINE AND CRACK TRACTION OFFLINE PASS', result['fine']['verified_states'])
