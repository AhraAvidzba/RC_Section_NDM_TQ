"""Готовит панельный контроль с шагом сдвига 0,025 промилле."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


def stage(repo, root, guard_pid, guard_ticks):
    """Заменяет только шаг в исправленной постановке контрольных панелей."""
    prepare = run_path(str(Path(__file__).with_name('Stage-CorrectPanelJacobian.py')))
    prepare['stage'](repo, root, guard_pid, guard_ticks)
    name = 'tests/modTestMVT2GaussSpan.bas'
    test = root / name
    raw = test.read_bytes()
    anchor = b'Const STEP_SIZE As Double = 0.0001, NU As Double'
    assert raw.count(anchor) == 1
    raw = raw.replace(anchor, b'Const STEP_SIZE As Double = 0.000025, NU As Double')
    test.write_bytes(raw)
    meta = root / 'Preparation.json'
    data = json.loads(meta.read_bytes())
    data['nominal_shear_step'] = 0.000025
    data['inputs'][name] = sha256(raw).hexdigest().upper()
    meta.write_bytes((json.dumps(data, indent=2) + '\n').encode())


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--guard-pid', type=int, required=True)
    parser.add_argument('--guard-ticks', type=int, required=True)
    args = parser.parse_args()
    stage(args.repo.resolve(), args.stage.resolve(), args.guard_pid, args.guard_ticks)
