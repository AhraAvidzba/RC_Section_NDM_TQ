"""Готовит повтор пяти панелей с порядком индексов, принятым в классе LU."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


HERE=Path(__file__).resolve().parent


def stage(repo,root,guard_pid,guard_ticks):
    base=run_path(str(HERE/'Stage-MixedPanelContinuation.py'))
    base['stage'](repo,root)
    test=root/'tests/modTestMVT2GaussSpan.bas'
    text=test.read_text(encoding='utf-8-sig')
    assert text.count('normal(i, j) = (')==3
    text=text.replace('normal(i, j) = (','normal(j, i) = (') # Для LU первый индекс означает столбец.
    test.write_bytes(text.replace('\n','\r\n').encode('utf-8-sig'))
    items=[test]
    if guard_pid:
        guard=root/'Guard-IsolatedOffice.ps1'
        body=guard.read_text('utf-8')
        guard.write_bytes(body.replace('$protected=@{',f'$protected=@{{{guard_pid}=[long]{guard_ticks};',1).encode())
        items.append(guard)
    meta=root/'Preparation.json'
    data=json.loads(meta.read_bytes())
    data['normal_jacobian_column_first']=True
    for path in items:
        data['inputs'][path.relative_to(root).as_posix()]=sha256(path.read_bytes()).hexdigest().upper()
    meta.write_bytes((json.dumps(data,indent=2)+'\n').encode())


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path.cwd())
    parser.add_argument('--stage',type=Path,required=True)
    parser.add_argument('--guard-pid',type=int)
    parser.add_argument('--guard-ticks',type=int)
    args=parser.parse_args()
    if bool(args.guard_pid)!=bool(args.guard_ticks):
        parser.error('Нужны оба значения идентификатора процесса.')
    stage(args.repo.resolve(),args.stage.resolve(),args.guard_pid,args.guard_ticks)
