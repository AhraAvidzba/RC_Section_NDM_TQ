"""Повторяет сравнение пластики и независимое обновление табличной истории."""

from argparse import ArgumentParser
import json
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    flow=root/'Compare-MVT2EffectiveFlow.py'
    history=run_path(str(flow))
    backbone=run_path(str(root/'Verify-MVT2BackboneReplay.py'))
    wire=root/'MVT2EffectiveFlow.json.gz'
    initial=root/'MVT2EffectiveInitial.json'
    tables=root/'MVT2ASDBackboneTables.json'
    with TemporaryDirectory(dir=args.report.resolve().parent) as temporary:
        workspace=Path(temporary)
        comparison=history['verify'](history['read_inputs'](args.repo.resolve(),workspace),wire,initial)
        separate=backbone['replay'](args.repo.resolve(),flow,wire,initial,tables,workspace)
    assert comparison['captured_tensor_count']==sum(v['checks'] for v in separate['pure_replay'].values())
    with args.report.open('x',encoding='utf-8',newline='\n') as output:
        json.dump({'flow':comparison,'independent_backbone':separate},output,indent=2,sort_keys=True,allow_nan=False)
        output.write('\n')
    print('MVT2 FULL EFFECTIVE FLOW OFFLINE PASS',comparison['captured_tensor_count'])
