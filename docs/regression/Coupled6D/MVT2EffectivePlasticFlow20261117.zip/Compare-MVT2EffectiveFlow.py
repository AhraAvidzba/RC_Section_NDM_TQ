"""Сравнивает эффективные тензоры и пластические поправки на общих полях MVT2."""

from argparse import ArgumentParser
from gzip import compress, decompress
from hashlib import sha256
import json
from math import fsum, sqrt
from pathlib import Path
from runpy import run_path
from subprocess import DEVNULL, run
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


REVERSE = ('MVT2ReverseConcreteMaterial20261117.zip',
           'E22671B7D47DAD52C911C9C38207324F95276875D50AD60901CB0CB3F980D23D')
PRINCIPAL = ('MVT2Cut396PrincipalSigns20261117.zip',
             '1588EF69B15D6398613C4F96C526792BE31AAF1D46C857ECD116109C9AE51269')
ZERO = (0.,) * 6
MODES = ('default', 'ndm_uniaxial')
TRACKED = {'NDM': (0., 7500., 20000., 21875.), 'MatchedASD': (0.,7500.,20000.,21875.),
           'LongASD': (20000., 40000., 67500., 75312.5)}
KEYS = ('equivalentTotalStrain', 'equivalentPlasticStrain', 'damage')
COORDINATES = ((0, 0), (1, 1), (2, 2), (0, 1), (0, 2), (1, 2))


def digest(raw):
    return sha256(raw).hexdigest().upper()


def archive(repo, entry):
    path = repo / 'docs/regression/Coupled6D' / entry[0]
    assert digest(path.read_bytes()) == entry[1]
    return ZipFile(path)


def read_inputs(repo, temporary):
    """Восстанавливает пути и независимую диагонализацию из проверенных источников."""
    with archive(repo, REVERSE) as old:
        stage_file = temporary / 'Stage-ReverseMaterial.py'
        stage_file.write_bytes(old.read(stage_file.name))
        setup = run_path(str(stage_file))
        sections, (tables, path, points, area, radius, _), reference_data = setup['load'](repo)
        assert setup['input_wire'](sections, tables) == old.read('Replay.Fields.csv')
        operator, prior_on_ndm, matched, long = reference_data
        rows = old.read('Native/MaterialReplay.csv').decode('ascii').splitlines()
    with setup['open_checked'](repo,setup['FIXED']) as source:
        same_curves = json.loads(decompress(source.read('Cut396FixedStrain.json.gz')))['stress']['ndm_uniaxial']
    spectral = {'__name__':'__pinned__','__file__':'Split-Cut396Principal.py'}
    with archive(repo,PRINCIPAL) as source:
        exec(compile(source.read(spectral['__file__']), spectral['__file__'], 'exec'),spectral)
    _, _, _, _, _, commands, model, *_ = operator['read_data'](repo)
    assert tuple(commands) == MODES and (model[0],model[1]) == (30000.,.2)
    strains, responses = {}, {}
    for raw in rows:
        label,step,point,*vals = raw.split(';')
        key = label,int(step),int(point)
        assert len(vals) == 26 and key not in strains
        vals = tuple(map(float,vals))
        strains[key] = vals[:6]
        responses[key] = vals[6:12],vals[12:18],vals[-4:-2]
    assert len(strains) == len(responses) == 11475
    external = {'NDM':prior_on_ndm, 'MatchedASD':matched['stress'], 'LongASD':long['stress']}
    return sections, (points,area,radius,operator,tables,path), (strains,responses), (commands,spectral['rotate']), (external,matched,long,same_curves)


def capture(loaded, target, progress):
    """Снимает номинальные напряжения, повреждения и эквивалентную пластическую историю."""
    import numpy as np

    assert np.__version__ == '2.3.5'
    sections, (_,_,_,_,tables,path), (strains,_), (commands,_), _ = loaded
    basis = np.array([[tables['B'][point,i][:6] for i in range(1,61)]
                      for point in range(1,46)]).transpose(0,2,1).copy()
    responses = {}
    for mode, args in commands.items():
        responses[mode] = {}
        for label, fields in sections.items():
            frames = []
            for step, (_, _, _, field) in enumerate(fields,1):
                if label == 'NDM':
                    frame = [path[step-1][3][tag][:6] for tag in range(1,46)]
                else:
                    frame = (basis @ np.array(field)).tolist()
                for tag, eps in enumerate(frame,1):
                    assert max(map(abs,minus(eps,strains[label,step,tag]))) < 3e-16
                frames.append(frame)
            history = [[] for _ in frames]
            with TemporaryDirectory(dir=target.parent) as directory:
                output = Path(directory) / 'NativeChunk.json'
                for start in range(0,45,2):
                    # Нарастающее форматирование ответов NDTest ограничивается временем жизни процесса.
                    # Материальные истории точек независимы и остаются целыми внутри каждого пакета.
                    wire = json.dumps([args,[frame[start:start+2] for frame in frames]]).encode()
                    proc = run([sys.executable,'-B',str(Path(__file__).resolve()),'--worker',str(output)],
                               input=wire,stdout=DEVNULL,stderr=DEVNULL,timeout=45,check=True)
                    assert proc.returncode == 0
                    data = json.loads(output.read_bytes())
                    output.unlink()
                    for row, chunk in zip(history,data,strict=True):
                        row.extend(chunk)
                    if progress:
                        progress.write(f'{mode} {label} {min(start+2,45)}\n')
            responses[mode][label] = history
    raw = json.dumps({'ASD':'3.8.0','material':responses},separators=(',',':'),allow_nan=False).encode()
    with target.open('xb') as output:
        output.write(compress(raw,mtime=0))


def worker(output):
    """Выполняет две независимые истории в свежем процессе OpenSees."""
    import openseespy.opensees as ops

    args, frames = json.load(sys.stdin)
    assert ops.version() == '3.8.0'
    ops.wipe()
    ops.model('basic','-ndm',3,'-ndf',3)
    for tag in range(1,len(frames[0])+1):
        ops.nDMaterial(args[0],tag,*args[1:])
    history = []
    for frame in frames:
        result = []
        for tag, eps in enumerate(frame,1):
            wire = (*eps[:4],eps[5],eps[4])
            ops.NDTest('SetStrain',tag,*wire)
            assert tuple(ops.NDTest('GetStrain',tag)) == wire
            a,b,c,d,f,e = ops.NDTest('GetStress',tag)
            marks = [ops.NDTest('GetResponse',tag,key) for key in KEYS]
            assert all(len(m)==2 for m in marks)
            result.append((eps,(a,b,c,d,e,f),*marks))
            ops.NDTest('CommitState',tag)
        history.append(result)
    ops.wipe()
    with output.open('x',encoding='ascii') as destination:
        json.dump(history,destination,separators=(',',':'),allow_nan=False)


def capture_initials(loaded, target):
    """Считывает историю при нулевых деформациях до первого материального шага."""
    import openseespy.opensees as ops

    assert ops.version() == '3.8.0'
    _, _, _, (commands,_), _ = loaded
    values = {}
    for mode, args in commands.items():
        ops.wipe()
        ops.model('basic','-ndm',3,'-ndf',3)
        ops.nDMaterial(args[0],1,*args[1:])
        stress = ops.NDTest('GetStress',1)
        strain = ops.NDTest('GetStrain',1)
        assert tuple(stress) == tuple(strain) == ZERO
        marks = [ops.NDTest('GetResponse',1,key) for key in KEYS]
        values[mode] = [stress,strain,*marks]
    ops.wipe()
    with target.open('x',encoding='ascii',newline='\n') as f:
        json.dump(values,f,indent=2,allow_nan=False)
        f.write('\n')


def elastic(eps):
    """Возвращает тензор из упругой деформации при E = 30 ГПа и ν = 0,2."""
    pressure = (25000./3.) * fsum(eps[:3])
    return (*[25000.*x + pressure for x in eps[:3]],*[12500.*x for x in eps[3:]])


def spectral(stress, rotate):
    """Возвращает собственные значения и ортогональные оси."""
    a,b,c,d,e,f = stress
    axes = [[float(i==j) for j in range(3)] for i in range(3)]
    return rotate([[a,d,e],[d,b,f],[e,f,c]],axes), axes


def tensor(values, axes):
    """Собирает напряжения в порядке НДМ."""
    return tuple(fsum(axes[i][k]*axes[j][k]*value for k,value in enumerate(values)) for i,j in COORDINATES)


def minus(a,b):
    return tuple(x-y for x,y in zip(a,b,strict=True))


def update_asd(stress, total, plastic, damage, eps, previous, rotate):
    """Пересчитывает явную пластическую поправку и проверяет её независимым обращением повреждения."""
    effective_old, eps_old, total_old, plastic_old = previous
    assert min(damage) >= 0. and max(damage) < 1.
    assert all(a >= b-1e-15 for a,b in zip(total,total_old,strict=True))
    trial = tuple(a+b for a,b in zip(effective_old,elastic(minus(eps,eps_old)),strict=True))
    principal,axes = spectral(trial,rotate)
    factors = [(a-b)/(a-c) if a-c>1e-14 else 1. for a,b,c in zip(total,plastic,plastic_old,strict=True)]
    reconstructed = [v*factors[int(v<0.)] for v in principal]
    nominal = tensor([v*(1.-damage[int(v<0.)]) for v in reconstructed],axes)
    actual, frame = spectral(stress,rotate)
    inverse = tensor([v/(1.-damage[int(v<0.)]) for v in actual],frame)
    approximation = tensor(reconstructed,axes)
    return (approximation,eps,total,plastic),trial,factors,(
        max(map(abs,minus(nominal,stress))),max(map(abs,minus(approximation,inverse))))


def square(x):
    return dot(x,x)


def dot(x,y):
    """Скалярное произведение симметричных физических тензоров."""
    return fsum(a*b*(1. if i<3 else 2.) for i,(a,b) in enumerate(zip(x,y,strict=True)))


def deviator(sigma):
    level=fsum(sigma[:3])/3.
    return tuple(v-level if i<3 else v for i,v in enumerate(sigma))


def best_radial_deviator(trial, target):
    """Оценивает нижнюю ошибку при любой радиальной поправке девиатора."""
    x,y = deviator(trial),deviator(target)
    norm = square(x)
    scale = max(0.,min(1.,dot(x,y)/norm)) if norm>0. else 0.
    return square(minus(y,tuple(scale*v for v in x)))


def archived_tensor(label, step, tag, external, matched, long, points):
    """Получает ранее проверенный номинальный бетон и учитывает вычет у стержней."""
    layer,j = divmod(tag-1,45)
    sig = external[label][step-1][layer][j]
    if label != 'NDM' and j >= 25:
        ref = matched if label=='MatchedASD' else long
        values = ref['steel'][step-1]['columns_strain_stress_tangent_plastic_backstress_increment'][layer][j-25]
        sig = tuple(d*values[1]-v for d,v in zip(points[j+1][3:],sig,strict=True))
    return sig


def verify(loaded, target, initial_path):
    """Сверяет локальный возврат и собирает разницу усилий до и после повреждения."""
    raw = target.read_bytes()
    recorded = json.loads(decompress(raw))
    initial = json.loads(initial_path.read_bytes())
    assert recorded['ASD'] == '3.8.0' and tuple(recorded['material']) == MODES
    sections, (points,area,radius,tools,_,_), (strains,ndm), (_,rotate), references = loaded
    external, matched, long, same_curves = references
    errors, results = {}, {}
    for mode, paths in recorded['material'].items():
        assert list(paths) == list(sections)
        s0, e0, x0, p0, d0 = initial[mode]
        assert tuple(s0)==tuple(e0)==ZERO and x0==d0==[0.,0.]
        assert all(-1e-10<v<0. for v in p0)
        zero_history = s0,e0,x0,p0
        results[mode] = {}
        max_nominal = max_eff = max_reference = max_nonlinear = max_weighted_inverse = 0.
        worst = None
        for label, frames in paths.items():
            assert len(frames) == len(sections[label])
            results[mode][label] = {}
            previous = [zero_history]*45
            old_ndm_plastic = [ZERO]*45
            for step, points_asd in enumerate(frames,1):
                phase, torque, shear, _ = sections[label][step-1]
                selected = shear in TRACKED[label] and (shear!=0. or step==8)
                assert len(points_asd) == 45
                contribution = {'nominal_difference':[], 'effective_difference':[],
                                'damage_difference':[], 'NDM_plastic_difference_to_elastic':[],
                                'ASD_plastic_difference_to_elastic':[]}
                rows = []
                for tag, (captured_strain,stress,total,plastic,damage) in enumerate(points_asd,1):
                    key = label,step,tag
                    eps = strains[key]
                    assert max(map(abs,minus(eps,captured_strain))) < 3e-16
                    history,asd_trial,factors,(a,b) = update_asd(
                        stress,total,plastic,damage,captured_strain,previous[tag-1],rotate)
                    previous[tag-1] = history
                    if a > max_nominal:
                        worst = (label,phase,tag,total,plastic,damage,factors,max(map(abs,stress)))
                        max_nominal = a
                    max_eff = max(max_eff,b)
                    max_weighted_inverse = max(max_weighted_inverse,b*(1.-max(damage)))
                    if any(damage) or any(plastic) or any(history[-1]):
                        max_nonlinear = max(max_nonlinear,a)
                    reference = None
                    if mode=='default':
                        reference = archived_tensor(label,step,tag,external,matched,long,points)
                    elif label=='NDM':
                        reference = same_curves[step-1][0][tag-1]
                    if reference is not None:
                        max_reference = max(max_reference,max(map(abs,minus(stress,reference))))
                    native, ndm_plastic, ndm_damage = ndm[key]
                    native_trial = elastic(minus(eps,old_ndm_plastic[tag-1]))
                    old_ndm_plastic[tag-1] = ndm_plastic
                    if not selected or tag>45:
                        continue
                    effective_ndm = elastic(minus(eps,ndm_plastic))
                    effective_asd = history[0]
                    # В итоговом усилии бетон в точках арматуры вычитается.
                    sign = 1. if tag<=25 else -1.
                    nominal_delta = minus(native,stress)
                    effective_delta = minus(effective_ndm,effective_asd)
                    damage_delta = minus(nominal_delta,effective_delta)
                    deform = elastic(eps)
                    for name,s in zip(contribution,(nominal_delta,effective_delta,damage_delta,
                                                    minus(effective_ndm,deform),minus(effective_asd,deform)),strict=True):
                        contribution[name].append(tuple(sign*x for x in s))
                    if tag<=25:
                        rows.append((tag,square(minus(deviator(effective_ndm),deviator(effective_asd))),
                                     best_radial_deviator(native_trial,effective_asd),
                                     best_radial_deviator(asd_trial,effective_asd),
                                     best_radial_deviator(native_trial,effective_ndm),
                                     native,stress,effective_ndm,effective_asd,factors,ndm_damage))
                if selected:
                    forces = {name:tools['resultant'](points,values) for name,values in contribution.items()}
                    rms = [sqrt(fsum(points[r[0]][2]*r[k] for r in rows)/area) for k in (1,2,3,4)]
                    assert max(map(abs,minus(forces['nominal_difference'],tuple(
                        a+b for a,b in zip(forces['effective_difference'],forces['damage_difference'],strict=True))))) < 3e-7
                    results[mode][label][phase] = {
                        'Qy_N':shear,'T_Nmm':torque,'section_delta_N_Nmm':forces,
                        'current_deviator_rms_MPa':rms[0],
                        'best_radial_NDM_predictor_rms_MPa':rms[1],
                        'best_radial_ASD_predictor_rms_MPa':rms[2],
                        'best_radial_NDM_to_own_effective_rms_MPa':rms[3],
                        'points':{str(r[0]):{'NDM_nominal':r[5],'ASD_nominal':r[6],
                                            'NDM_effective':r[7],'ASD_effective':r[8],
                                            'ASD_plastic_factors':r[9],'NDM_damage':r[10]}
                                  for r in rows if r[0] in (11,14,15)},
                    }
        assert max_nominal<2e-8 and max_weighted_inverse<3e-8, (mode,max_nominal,max_eff,max_weighted_inverse,worst)
        assert max_nonlinear<2e-8, (mode,max_nonlinear)
        assert max_reference<2e-8, (mode,max_reference)
        errors[mode] = {'nominal_MPa':max_nominal,'effective_MPa':max_eff,'archived_stress_MPa':max_reference,
                        'effective_rescaled_by_remaining_stiffness_MPa':max_weighted_inverse,
                        'nonlinear_max_MPa':max_nonlinear, 'worst_nominal_location':worst}
    return {'engine':recorded['ASD'],'captured_tensor_count':2*sum(map(len,sections.values()))*45,'wire_sha256':digest(raw),
            'initial_history':initial,
            'errors':errors,'control_fields':results}


if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='--worker':
        worker(Path(sys.argv[2]))
        sys.exit()
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--wire',type=Path)
    parser.add_argument('--initial',type=Path)
    parser.add_argument('--progress',type=Path)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--capture',action='store_true')
    group.add_argument('--capture-initials',action='store_true')
    group.add_argument('--report',type=Path)
    args=parser.parse_args()
    if (args.wire is None and not args.capture_initials) or (args.initial is None and not args.capture):
        parser.error('Для повтора нужны --wire и --initial; для получения одной записи достаточно соответствующего пути.')
    target=(args.initial if args.capture_initials else args.wire).resolve()
    with TemporaryDirectory(dir=target.parent) as temporary:
        data=read_inputs(args.repo.resolve(),Path(temporary))
        if args.capture_initials:
            capture_initials(data,target)
            print('MVT2 EFFECTIVE FLOW INITIALS',digest(target.read_bytes()))
        elif args.capture:
            if args.progress is None:
                capture(data,target,None)
            else:
                with args.progress.open('x',encoding='ascii',buffering=1) as progress:
                    capture(data,target,progress)
            print('MVT2 EFFECTIVE FLOW CAPTURE',digest(target.read_bytes()))
        else:
            proof=verify(data,target,args.initial.resolve())
            with args.report.open('x',encoding='utf-8',newline='\n') as output:
                json.dump(proof,output,indent=2,sort_keys=True,allow_nan=False)
                output.write('\n')
            print('MVT2 EFFECTIVE FLOW OFFLINE PASS',proof['captured_tensor_count'])
