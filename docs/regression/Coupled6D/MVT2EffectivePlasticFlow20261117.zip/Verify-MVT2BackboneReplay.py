"""Независимо обновляет историю ASD на полях MVT2 по одноосным таблицам."""

from argparse import ArgumentParser
from bisect import bisect_left
from gzip import decompress
from hashlib import sha256
import json
from math import fsum, sqrt
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory


E = 30000.
ALPHA = 4./33.
GAMMA = 3.


class Backbone:
    """Хранит нормированную табличную огибающую для одного знака."""

    def __init__(self, table, stress_floor):
        self.x, self.nominal, self.effective = table
        assert len(self.x)==len(self.nominal)==len(self.effective) and self.x[0]==0.
        dx = [b-a for a,b in zip(self.x,self.x[1:])]
        assert min(dx)>0. and stress_floor>0.
        self.edges = [x+min(dx)*1e-6 for x in self.x]
        self.floor = stress_floor

    def stresses(self, x):
        """Считает номинальную и эффективную ординаты с численным полом."""
        i = max(1,bisect_left(self.edges,x))
        if i==len(self.x):
            span = x-self.x[-1]
            delta = self.x[-1]-self.x[-2]
            y,q = (v[-1]+span*max(0.,(v[-1]-v[-2])/delta) for v in (self.nominal,self.effective))
        else:
            ratio = (x-self.x[i-1])/(self.x[i]-self.x[i-1])
            y,q = (v[i-1]+ratio*(v[i]-v[i-1]) for v in (self.nominal,self.effective))
        return max(self.floor,y),max(self.floor,q)

    def step(self, previous, trial):
        """Продвигает эквивалентную деформацию и возвращает оба множителя напряжений."""
        _, old_effective = self.stresses(previous)
        previous_plastic = previous-old_effective/E
        current = max(previous,trial+previous_plastic)
        y,q = self.stresses(current)
        denominator = E*(current-previous_plastic)
        assert denominator > 0.
        return current,y/denominator,q/denominator


def equivalent(values, ratio, tensile, tension_threshold):
    """Считает два скалярных критерия в эффективных напряжениях."""
    if tensile:
        if max(values)<tension_threshold:
            return 0.
    else:
        values = tuple(min(x,0.) for x in values)
    pressure = fsum(values)/3.
    dev=tuple(x-pressure for x in values)
    q=sqrt(1.5*fsum(x*x for x in dev))
    high=max(values)
    beta = (1.-ALPHA)*ratio-(1.+ALPHA)
    return (ALPHA*3.*pressure+q+beta*max(high,0.)-GAMMA*max(-high,0.)) / (
        (1.-ALPHA)*E*(ratio if tensile else 1.))


def capture_tables(loaded, target):
    """Сохраняет табличные ординаты после подготовки материала в OpenSees."""
    import openseespy.opensees as ops
    assert ops.version()=='3.8.0'
    _,_,_,(commands,_),_ = loaded
    tables = {}
    for mode,args in commands.items():
        ops.wipe()
        ops.model('basic','-ndm',3,'-ndf',3)
        ops.nDMaterial(args[0],1,*args[1:])
        tables[mode] = {side:[ops.NDTest('GetResponse',1,side+value) for value in ('e','s','q')]
                        for side in ('T','C')}
    ops.wipe()
    with target.open('x',encoding='ascii',newline='\n') as output:
        json.dump(tables,output,indent=2,allow_nan=False)
        output.write('\n')


def replay(repo, source, capture, initial_path, tables_path, workspace):
    """Проверяет расчёт без передачи эквивалентной истории и повреждения из OpenSees."""
    functions=run_path(str(source))
    ready=functions['read_inputs'](repo,workspace)
    _,_,_,(_,rotate),_=ready
    wire=json.loads(decompress(capture.read_bytes()))
    initial=json.loads(initial_path.read_bytes())
    tables=json.loads(tables_path.read_bytes())
    assert tuple(tables)==functions['MODES'] and tuple(wire['material'])==functions['MODES']
    elapsed_result={}
    for mode, paths in wire['material'].items():
        laws=[Backbone(tables[mode][side],-E*p) for side,p in zip(('T','C'),initial[mode][3],strict=True)]
        ratio=max(5.,max(laws[1].nominal)/max(laws[0].nominal))
        error_x=error_nom=0.
        seen=0
        for label,fields in paths.items():
            histories = [(functions['ZERO'],functions['ZERO'],(0.,0.)) for _ in range(45)]
            for step, states in enumerate(fields,1):
                assert len(states)==45
                for tag,(strain,nominal,measures,_,_) in enumerate(states):
                    old_strain,old_stress,old_x=histories[tag]
                    trial=tuple(a+b for a,b in zip(old_stress,functions['elastic'](
                        functions['minus'](strain,old_strain)),strict=True))
                    eig,directions=functions['spectral'](trial,rotate)
                    state=[law.step(x, equivalent(eig,ratio,j==0,laws[0].floor))
                           for j,(law,x) in enumerate(zip(laws,old_x,strict=True))]
                    x=tuple(s[0] for s in state)
                    corrected=functions['tensor']([v*state[int(v<0.)][2] for v in eig],directions)
                    stress=functions['tensor']([v*state[int(v<0.)][1] for v in eig],directions)
                    local_x=max(map(abs,functions['minus'](x,measures)))
                    local_nom=max(map(abs,functions['minus'](stress,nominal)))
                    assert local_x<5e-12 and local_nom<6e-8,(mode,label,step,tag+1,local_x,local_nom)
                    error_x=max(error_x,local_x)
                    error_nom=max(error_nom,local_nom)
                    histories[tag]=strain,corrected,x
                    seen+=1
        assert seen==3825
        elapsed_result[mode]={'checks':seen,'maximum_strain_measure_error':error_x,
                              'maximum_nominal_error_MPa':error_nom,'peak_compression_tension_ratio':ratio}
    return {'pure_replay':elapsed_result,'after_prepared_law_tables_sha256':sha256(tables_path.read_bytes()).hexdigest().upper()}


if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--source',type=Path,default=Path(__file__).with_name('Compare-MVT2EffectiveFlow.py'))
    parser.add_argument('--tables',required=True,type=Path)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--capture-tables',action='store_true')
    group.add_argument('--report',type=Path)
    parser.add_argument('--wire',type=Path)
    parser.add_argument('--initial',type=Path)
    args=parser.parse_args()
    with TemporaryDirectory(dir=args.tables.resolve().parent) as temp:
        if args.capture_tables:
            functions = run_path(str(args.source))
            capture_tables(functions['read_inputs'](args.repo.resolve(),Path(temp)),args.tables)
        else:
            result=replay(args.repo.resolve(),args.source,args.wire,args.initial,args.tables,Path(temp))
            with args.report.open('x',encoding='utf-8',newline='\n') as output:
                json.dump(result,output,indent=2,sort_keys=True,allow_nan=False)
                output.write('\n')
            print('MVT2 ASD INDEPENDENT BACKBONE REPLAY PASS 7650')
