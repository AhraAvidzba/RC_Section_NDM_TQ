"""Reconstruct the native stock-to-apex tangent update by station from tracked archives."""
from pathlib import Path
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
from collections import defaultdict, Counter
import csv, json, math, sys
import numpy as np

HERE=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve(strict=True)
archives=repo/"docs/regression/Coupled6D"
file_hashes={}
def get(name):
    path=archives/name
    file_hashes[name]=sha256(path.read_bytes()).hexdigest().upper()
    return ZipFile(path)
def decode(z,name,coding="cp1251"):
    return z.read(name).decode(coding).splitlines()
def import_source(z,name):
    namespace={"__file__":str(HERE/name),"__name__":"archive_module"}
    exec(compile(z.read(name).decode("utf-8-sig"),name,"exec"),namespace)
    return namespace
def peak(x):return float(np.max(np.abs(x)))

with get("KaniApexConstitutiveReplay20261116.zip") as ref:
    m=import_source(ref,"Verify-KaniApexReturn.py")
with get("KaniHydrostaticApex46Portable.zip") as geo:
    dirs=np.loadtxt(BytesIO(geo.read("GeometryAndDirections.csv")),delimiter=";")
with get("KaniApexSectionActions20261116.zip") as ref:
    assert file_hashes[ref.filename.rsplit("\\",1)[-1].rsplit("/",1)[-1]]=="360D22C5847F1DF3D40ECAA11689AF2B8B68CF8C94A22E7ACC2B3D19A08486A6"
    published=json.loads(ref.read("ApexSectionVerification.json"))
    a=np.loadtxt(BytesIO(ref.read("KaniApexGeometry.csv")),delimiter=";")
    h,shape,c,physical_force,weights,scales=import_source(ref,"BuildOperators.py")["operators"](
        a,float(ref.read("KaniApexLength.txt")))
    sources=[decode(ref,n) for n in ("Native/KaniV4Stations.csv","Native/KaniV4Tangents.csv","Native/KaniV4Trace.csv")]
    plans={r[0]:(float(r[1]),np.asarray(r[2:89],float),np.asarray(r[89:],float))
           for r in csv.reader(decode(ref,"ApexSectionFields.csv","ascii"),delimiter=";")}
assert np.array_equal(a,dirs[:,:3])
steel=np.zeros((40,6))
steel[:,:4]=dirs[144:,3:]
limit=np.r_[np.full(8,442.),np.full(32,400.)]
sigs=[-1,0,1]
site_shape=(3,184)
equis=(3,184,6)
stock_vectors={}
stock_modes={}
fields={}
traces={}
energies=np.zeros((3,184,2))
flags=defaultdict(lambda:np.full((3,184,3),-99,dtype=int))
full=defaultdict(lambda:np.full((3,184,12),np.nan))
for lines in sources:
    for tag,label,*items in csv.reader(lines,delimiter=";"):
        if tag=="APEX_VECTOR":stock_vectors[label]=np.asarray(items,float)
        if tag=="ACTION":stock_modes[label]=int(items[-1])
        if tag=="K59C_VECTOR":fields[label]=np.asarray(items,float)
        if tag=="K59C_STATE":traces[label]=np.asarray(items,float)
        if tag=="ENERGY" and label=="BaseAccepted":
            point,side,*new=items
            energies[int(side)+1,int(point)-1]=np.asarray(new,float)
        if tag in ("BRANCH","K59C_STATION"):
            point,side,*new=items
            ix=(int(side)+1,int(point)-1)
            if tag=="BRANCH":flags[label][ix]=np.asarray(new,int)
            else:full[label][ix]=np.asarray(new,float)

def split(raw):
    concrete=raw[:,:,6:].copy()
    s=2.e5*np.einsum("spi,pi->sp",raw[:,144:,:6],steel)
    assert np.all(abs(s)<limit)
    concrete[:,144:,:]=s[:,:,None]*steel[None,:,:]-raw[:,144:,6:]
    return concrete

origin=full["BaseAccepted"][:,:,:6]
s_concrete=split(full["BaseAccepted"])

def evaluate(offset,site,diagnostic=False):
    n=m["matrix"](s_concrete[site])
    kt,kc=energies[site]
    evaluated,metadata=m["return_apex"](n,kt,kc,offset)
    if diagnostic and 0.<metadata["Ftrial"]<=1.e-8*m["compression_history"](kc)[0]:
        raise ValueError("PositiveToleranceBand")
    return np.asarray(m["vector"](evaluated)),metadata

def conservative_material_jvp(base_shift, along, site):
    kt,kc=energies[site]
    n=m["matrix"](s_concrete[site])
    apex_params=m["parameters"](n,kt,kc)
    nominal_t,n_dev,n_q,hi,lo=m["invariant"](n)
    if n_q>8e-12*m["FC"]:
        raise ValueError("AcceptedOutsideApexBand")
    val,info=evaluate(base_shift,site,True)
    if info["kind"]=="Elastic" and abs(info["Ftrial"])<=1.e-8*apex_params[1]:
        raise ValueError("NoElasticJVPAtBoundary")
    if not info["kind"]=="Elastic":
        # Match the VBA guard on approximate equality to the return-branch interface.
        t,d,q,h,l=m["invariant"](apex_params[0]+m["elastic"](base_shift))
        beta=apex_params[2]
        slope=apex_params[3]
        end_tag=(q+beta*h)/slope * m["band"]/q+t-apex_params[4]
        if abs(end_tag)<=7.105427357601e-15*apex_params[4]:
            raise ValueError("DoubleBandInterface")
    derivative,kind=m["apex_jvp"](n,kt,kc,base_shift,along)
    return np.asarray(m["vector"](derivative)),kind,info

def stock_point_action(base_strain, along, site, mode):
    base_shift=base_strain-origin[site]
    base,base_meta=evaluate(base_shift,site)
    base_plastic=base_meta["kind"]!="Elastic"
    tangent=np.zeros((6,6))
    branches=[]
    for j in range(6):
        delta=2e-9*(1.+abs(base_strain[j]))
        applied=np.zeros(6)
        for _ in range(3):
            applied[j]=delta
            p,ip=evaluate(base_shift+applied,site)
            q,im=evaluate(base_shift-applied,site)
            pp,mp=(ip["kind"]!="Elastic"),(im["kind"]!="Elastic")
            pos=mode==0 or pp==base_plastic
            neg=mode==0 or mp==base_plastic
            if pos or neg:
                break
            delta*=.25
        if not (pos or neg):
            raise ValueError(("UnresolvedStockTangent",site,j,mode,base_meta,ip,im))
        if pos and neg:tangent[:,j]=(p-q)/(2.*delta)
        elif pos:tangent[:,j]=(p-base)/delta
        else:tangent[:,j]=(base-q)/delta
        branches.append(dict(j=j,delta=delta,used_sides=[pos,neg],plus=ip["kind"],minus=im["kind"]))
    return tangent@along,branches

def at_side(x):
    basic=h@x[:79]
    slope=h[:,:,:4]@x[79:83]
    return np.array([basic+.001*k*slope for k in sigs])

def get_eq(s,coordinates=None):
    stress=s[1]
    spatial=(s[2]-s[0])/.002
    physical=np.einsum("nij,ni,n->j",h,stress,weights)
    physical[4:]-=np.einsum("nk,na,n->ka",shape,spatial[:,[4,5,2]],weights).ravel()
    axial=np.einsum("nij,ni,n->j",h[:,:,:4],spatial,weights)
    physical_force_vector=np.einsum("nij,nj,n->i",physical_force,stress,a[:,2])
    gauge=np.zeros(4)
    if coordinates is not None:
        physical+=c.T@coordinates[83:]
        gauge=c@coordinates[:79]
    return np.r_[physical,axial,gauge],physical_force_vector

def compute():
    all_cases={}
    for key,(ref_fraction,center,direction) in plans.items():
        e0=at_side(center); d=at_side(direction)
        shift=e0-origin
        obs_raw=(full[key+"/Plus"][:,:,6:]-full[key+"/Minus"][:,:,6:])/(2.*ref_fraction)
        measured,efforts=get_eq(obs_raw,direction)
        assert peak(at_side(center+ref_fraction*direction)-full[key+"/Plus"][:,:,:6])<6e-14
        assert peak(at_side(center-ref_fraction*direction)-full[key+"/Minus"][:,:,:6])<6e-14
        obs_conc=(split(full[key+"/Plus"])-split(full[key+"/Minus"]))/(2.*ref_fraction)
        site_mask=np.zeros(site_shape,dtype=bool)
        ja=np.zeros(equis); jc=np.zeros(equis)
        records=[]
        screened_out=[]
        stock_branches=Counter()
        rowweight=np.array([-1.,0.,1.])[:,None]*(weights*h[:,2,1]/.002)[None,:]
        for site in np.ndindex(site_shape):
            sign=1. if site[1]<144 else -1.
            try:
                candidate,kind,info=conservative_material_jvp(shift[site],d[site],site)
            except ValueError as exc:
                screened_out.append(dict(site=[site[0]-1,site[1]+1],why=str(exc)))
                continue
            stock,bb=stock_point_action(e0[site],d[site],site,stock_modes[key])
            site_mask[site]=True
            ja[site]=sign*stock
            jc[site]=sign*candidate
            for col in bb:
                stock_branches[col["plus"]+"<>"+col["minus"]+" "+str(col["used_sides"])]+=1
            if site[0]!=1:
                records.append(dict(site=[site[0]-1,site[1]+1],point_family="direct" if sign>0. else "replacement",
                      kind=kind,actual_Ftrial_MPa=info["Ftrial"],stock_numerical_columns=bb,
                      row81_coefficient=float(sign*rowweight[site]),
                      row81_actual_part_MPa=float(sign*rowweight[site]*obs_conc[site][2]),
                      row81_stock_part_MPa=float(sign*rowweight[site]*stock[2]),
                      row81_candidate_part_MPa=float(sign*rowweight[site]*candidate[2]),
                      row81_stock_error_MPa=float(sign*rowweight[site]*(stock[2]-obs_conc[site][2])),
                      row81_candidate_error_MPa=float(sign*rowweight[site]*(candidate[2]-obs_conc[site][2])),
                      ))
        assert int(np.sum(site_mask))==published["tests"][key]["analyticStations"]
        native_stock=stock_vectors[key+"/Stock"]
        native_hybrid=stock_vectors[key+"/Hybrid"]
        delta,delta_efforts=get_eq(jc-ja)
        correction_error=peak(delta-(native_hybrid-native_stock))
        correction_effort_error=peak((delta_efforts-(stock_vectors[key+"/HybridEfforts"]-stock_vectors[key+"/StockEfforts"]))/scales)
        # All selected errors are signed stress errors. The complement stays exactly as archived.
        actual_conc=np.zeros(equis)
        signs=np.ones((3,184)); signs[:,144:]=-1.
        actual_conc[site_mask]=obs_conc[site_mask]*signs[site_mask,None]
        stock_sel,_=get_eq(ja-actual_conc)
        cand_sel,_=get_eq(jc-actual_conc)
        unselected=(native_stock-measured)-stock_sel
        actual_max=peak(measured[:83])
        i=80
        group_sums={}
        for family in ("direct","replacement"):
            for side in (-1,1):
                sel=[r for r in records if r["site"][0]==side and r["point_family"]==family]
                totals={name:math.fsum(x[name] for x in sel) for name in (
                    "row81_actual_part_MPa","row81_stock_part_MPa","row81_candidate_part_MPa",
                    "row81_stock_error_MPa","row81_candidate_error_MPa")}
                group_sums[f"{family}/{side}"]=dict(n=len(sel),**totals)
        ambiguous=[]
        for r in screened_out:
            if r["why"] not in ("PositiveToleranceBand","NoElasticJVPAtBoundary","DoubleBandInterface"):
                continue
            side,point=r["site"]
            site=(side+1,point-1)
            stock,_=stock_point_action(e0[site],d[site],site,stock_modes[key])
            norm_weight=rowweight[site]*(1. if point<=144 else -1.)
            contribution=float(norm_weight*(stock[2]-obs_conc[site][2]))
            ambiguous.append(dict(**r,row81_stock_error_MPa=contribution))
        ambiguity_sum=math.fsum(r["row81_stock_error_MPa"] for r in ambiguous)
        result=dict(count=int(np.sum(site_mask)),mode=stock_modes[key],direction_max_strain=peak(d),
             central_max_strain=peak(d)*ref_fraction,correction_discrepancy_MPa=correction_error,
             correction_effort_discrepancy_MPa=correction_effort_error,
             stock_central_pairs=stock_branches,row81=dict(measured_action_MPa=float(measured[i]),
                 native_stock_action_MPa=float(native_stock[i]),native_hybrid_action_MPa=float(native_hybrid[i]),
                 selected_stock_error_MPa=float(stock_sel[i]),selected_candidate_error_MPa=float(cand_sel[i]),
                 unchanged_error_MPa=float(unselected[i]),ambiguous_apex_stations=ambiguous,
                 ambiguous_apex_stock_error_MPa=ambiguity_sum,
                 regular_stock_error_MPa=float(unselected[i]-ambiguity_sum),
                 sum_stock_error_MPa=float(native_stock[i]-measured[i]),
                 sum_hybrid_error_MPa=float(native_hybrid[i]-measured[i]),
                 group_sums=group_sums,
                 stations=records), screened_out=screened_out)
        assert correction_error<5e-10 and correction_effort_error<5e-10,(key,correction_error,correction_effort_error)
        all_cases[key]=result
        print(key,"n",result["count"],"δerr",correction_error,"row81",[(x,v) for x,v in result["row81"].items() if isinstance(v,float)])
    return dict(source_sha256=file_hashes,probes=all_cases,
                held_out_full_field=held_out_correction())

def held_out_correction():
    names=("NearOriginal","NearHalf","NearFull")
    d=plans["NearRefit"][2]
    x=fields[names[0]][2:]
    assert peak(fields[names[1]][2:]-x-.5*d)<6e-16
    assert peak(fields[names[2]][2:]-x-d)<6e-16
    assert all(fields[n][0]==fields[names[0]][0] for n in names)
    def evaluate_field(n):
        field=fields[n]
        residual,efforts=get_eq(full[n][:,:,6:],field[2:])
        residual[80]-=1e5*field[0]/scales[0]
        recorded=traces[n]
        assert peak(residual-recorded[12:])<2e-10
        assert peak((efforts-recorded[6:12])/scales)<3e-10
        return residual,efforts
    r0,w0=evaluate_field(names[0])
    r_half,w_half=evaluate_field(names[1])
    r_hold,w_hold=evaluate_field(names[2])
    r_plus,w_plus=evaluate_field("NearRefit/Plus")
    r_minus,w_minus=evaluate_field("NearRefit/Minus")
    r_ref=traces["NearRefit/Plus"]
    assert peak((r_plus-r_half)[np.arange(87)!=80])<2e-10
    assert peak((w_plus-w_half)/scales)<3e-10
    methods={
        "Stock":(stock_vectors["NearRefit/Stock"],stock_vectors["NearRefit/StockEfforts"]),
        "PartialHybrid":(stock_vectors["NearRefit/Hybrid"],stock_vectors["NearRefit/HybridEfforts"]),
        "MeasuredForwardWholeSectionAtHalf":(2.*(r_half-r0),2.*(w_half-w0)),
        "MeasuredCenteredWholeSectionAtHalf":(r_plus-r_minus,w_plus-w_minus)
    }
    norm_target=float(traces[names[0]][3])
    assert abs(norm_target-traces[names[2]][3])<2e-15
    def admissible_alpha(error,action):
        lo,hi=0.,1.
        for x,y in zip(error[:83],action[:83],strict=True):
            if y==0.:
                if abs(x)>norm_target:return None
                continue
            z0,z1=sorted(((-norm_target-x)/y,(norm_target-x)/y))
            lo,hi=max(lo,z0),min(hi,z1)
            if lo>hi:return None
        return [float(lo),float(hi)]
    out={}
    for k,(a,da) in methods.items():
        r=r0+a
        w=w0+da
        e=r-r_hold
        ew=(w-w_hold)/scales
        out[k]=dict(predicted_physical_norm_MPa=peak(r[:83]),
                  predicted_row81_MPa=float(r[80]),heldout_row81_error_MPa=float(e[80]),
                  max_heldout_row_error_MPa=peak(e[:83]),
                  max_heldout_effort_error_as_MPa=peak(ew),
                  max_gauge_action_error=peak(e[83:]),effort_errors_N_Nmm=(w-w_hold).tolist(),
                  predicted_feasible_alpha_range_0_1=admissible_alpha(r0,a))
    return dict(field="NearFull",physics="stock equilibrium residual at same external load and committed H44",
                fit="NearRefit signed half pair or native NearHalf forward displacement",models=out,
                actual_max_physical_residual_MPa=peak(r_hold[:83]),
                actual_row81_residual_MPa=float(r_hold[80]),original_residual_MPa=peak(r0[:83]),
                half_residual_MPa=peak(r_half[:83]),
                measured_gauge_at_heldout=peak(r_hold[83:]),
                same_loaded_Qy=float(fields[names[0]][0]*1e5),
                original_workbook_tolerance_MPa=norm_target)

proof=compute()
out=Path(sys.argv[2]) if len(sys.argv)>2 else HERE/"SectionApexPartition.json"
out.write_text(json.dumps(proof,indent=2,allow_nan=False)+"\n","utf-8")
print(sha256(out.read_bytes()).hexdigest().upper())

