"""Recover byte-identical shared Jet inputs and replay the recorded native comparison."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
import subprocess
import sys
import tempfile
from zipfile import ZipFile


here = Path(__file__).resolve().parent
jet_sha = "6E4FBCB3E345DB0250009A458C6169888F81E09D2D91CA4EA822ADA69840AD33"
report_sha = "5E37145AB506167B149152328EF940AEE296D045B20C5FDE9C3E9C4E357AF02E"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jet_archive", type=Path)
    args = parser.parse_args()
    assert digest(args.jet_archive.read_bytes()) == jet_sha
    assert digest((here / "VerificationComparePrecision.json").read_bytes()) == report_sha
    manifest = json.loads((here / "PortableManifest.json").read_bytes())
    with tempfile.TemporaryDirectory() as folder, ZipFile(args.jet_archive) as source:
        stage = Path(folder)
        for name, value in manifest["local"].items():
            entry = here / name
            assert digest(entry.read_bytes()) == value
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            copyfile(entry, target)
        for name, (archived, expected) in manifest["jet_dependency"].items():
            raw = source.read(archived)
            assert digest(raw) == expected
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        subprocess.run((sys.executable, "-B", "-X", "utf8", "ReplayPrecision.py", "--offline"), cwd=stage, check=True)
        report = stage / "VerificationComparePrecision.json"
        assert digest(report.read_bytes()) == report_sha
        print("CANONICAL NATIVE COMPARISON", report_sha)


if __name__ == "__main__":
    main()
