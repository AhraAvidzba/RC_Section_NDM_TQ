"""Replay the frozen native comparison with the exact decimal wire-precision check."""
import argparse
from decimal import Decimal, localcontext
from hashlib import sha256
import json
from pathlib import Path


here = Path(__file__).resolve().parent
original_sha = "B545EECC04E1515038A396E2BA32A4020B41A39954BF8F8B2146295EC2C78D6E"
trace_sha = "D946DA9E912ACD7DB587CA0AF4E1FEF76D6F8463F5ADB0E9D002CCDBC520C233"
source_book_sha = "8EAD3E67257BA557426FABED92308AC5912B877F50334CB60BCE505676AC86EF"


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def normal_wire_precision(tags, normal):
    [[label, *wire]] = tags["B_ARC_PROJECTION"]
    assert label == "Normal" and len(wire) == len(normal) == 60
    records = []
    with localcontext() as arithmetic:
        arithmetic.prec = 100
        for index, (coefficient, token) in enumerate(zip(normal, wire, strict=True), 1):
            pinned = Decimal.from_float(coefficient)
            serialized = Decimal(token)
            assert pinned.is_finite() and serialized.is_finite()
            if not pinned:
                assert serialized == 0, index
                continue
            # VBA Str$ writes 15 significant decimal digits and strips trailing zeros.
            # Its half-unit at decimal exponent e is 0.5*10**(e-14).
            quantum = Decimal(1).scaleb(pinned.copy_abs().adjusted() - 14)
            defect = abs(pinned - serialized)
            bound = quantum / 2
            assert pinned.quantize(quantum) == serialized and defect <= bound, (index, pinned, token)
            records.append((index, defect, bound, defect / bound))
    worst = max(records, key=lambda row: row[1])
    closest = max(records, key=lambda row: row[3])
    return {"wire_function": "Trim$(Str$(value))", "significant_decimal_digits": 15,
            "exactly_nearest_nonzero_coefficients": len(records), "exact_zero_coefficients": len(normal)-len(records),
            "strict_original_cutoff_failures": sum(row[1] >= Decimal("3e-17") for row in records),
            "max_abs_error": str(worst[1]), "max_abs_error_index": worst[0],
            "max_abs_error_analytic_bound": str(worst[2]), "max_fraction_of_rounding_bound": float(closest[3]),
            "max_fraction_index": closest[0]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true", help="source workbook bytes omitted; require frozen native ownership receipts")
    args = parser.parse_args()
    source = here / "Verify-MVT2ShearControlled.py"
    trace = here / "NativeCompare/MVT2.csv"
    assert digest(source) == original_sha and digest(trace) == trace_sha
    script = source.read_text(encoding="utf-8")
    original = '    assert v.peak(v.diff(v.vec(tags, "B_ARC_PROJECTION")["Normal"], p)) < 3e-17'
    assert script.count(original) == 1
    script = script.replace(original, "    normal_wire_precision(tags, p)")
    if args.offline:
        book = '    assert v.digest(here / "workbook/output/RC_Section_NDM.xlsm") == prep["book_sha256"]'
        assert script.count(book) == 1
        script = script.replace(book, f'    assert prep["book_sha256"] == "{source_book_sha}"')
    scope = {"__name__": "precision_replay", "__file__": str(source), "normal_wire_precision": normal_wire_precision}
    exec(compile(script, str(source), "exec"), scope)
    frozen = scope["prepare"]()
    result = scope["verify"](*frozen)
    result["projection_wire_precision"] = normal_wire_precision(scope["v"].read_native(trace), frozen[4])
    result["projection_wire_precision"]["archived_verifier_sha256"] = original_sha
    output = here / "VerificationComparePrecision.json"
    output.write_bytes((json.dumps(result, indent=2) + "\n").encode("utf-8"))
    print(output, digest(output))


if __name__ == "__main__":
    main()
