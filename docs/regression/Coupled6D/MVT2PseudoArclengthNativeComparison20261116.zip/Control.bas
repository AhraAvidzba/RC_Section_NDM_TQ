' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает усилие и плоскость псевдодуги при одной истории MVT2 B.
Public Function RunTestWangShearControlled(ByVal replayPath As String, ByVal phase As String) As String
    Dim report As String, tracePath As String
    On Error GoTo Failed
    If Not ThisWorkbook.ReadOnly Or InStr(1, ThisWorkbook.Path, "RC_NDM_ModeSuite_", vbTextCompare) = 0 Then _
        Err.Raise 5, , "Для деформационного контроля B нужна изолированная книга."
    tracePath = ThisWorkbook.Path & "\WangShearControlled.csv"
    Dim history As New Collection, factors() As Double
    ReadWangShearArchiveTest replayPath, history, factors, report, tracePath
    Dim section As CSectionModel, transverse As CTransverseRebarLayout, steel As Object
    Dim operators As New CCoupledElasticState, concrete As New CCoupledConcreteResponse
    Dim response As New CCoupledReinforcedResponse, solver As New CCoupledNewtonSolver
    Dim plusConcrete As New CCoupledConcreteResponse, minusConcrete As New CCoupledConcreteResponse
    Dim plusSide As New CCoupledReinforcedResponse, minusSide As New CCoupledReinforcedResponse
    Set section = BuildWangMVT2SectionTest(transverse, steel)
    operators.PrepareModel section, 30000#, 0.2, 1, 1, 5, transverse, steelModels:=steel
    If operators.ConcretePointCount <> 25 Or operators.PointCount <> 45 Or operators.DegreeCount <> 60 Then _
        Err.Raise 5, , "Квадратура не совпала с архивом MVT2."
    Dim fc As Double, nominalFt As Double, gt As Double, gc As Double
    fc = 588000# / (0.3 * 240# * 240#): nominalFt = 0.302 * fc ^ (2# / 3#)
    gt = 0.073 * fc ^ 0.18: gc = (fc / nominalFt) ^ 2 * gt
    Const EC As Double = 30000#, NU As Double = 0.2, FT As Double = 2.10667357864589
    Const PEAK_STRAIN As Double = 0.0022, LOCALIZATION_LENGTH As Double = 125#
    concrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    plusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    minusConcrete.Initialize operators.PointCount, EC, NU, 0.6 * fc, fc, FT, PEAK_STRAIN, gt, gc, LOCALIZATION_LENGTH
    response.Initialize operators, concrete, steel
    plusSide.Initialize operators, plusConcrete, steel
    minusSide.Initialize operators, minusConcrete, steel
    solver.Initialize operators, response, EC, plusSide, minusSide
    Dim area As Double, sectionLength As Double
    operators.CopyResultantResidualScales area, sectionLength
    AddExperimentTraceTest report, tracePath, "B_CONTROL_SETUP;" & CStr(history.Count) & ";" & _
        ExperimentNumberTest(area) & ";" & ExperimentNumberTest(sectionLength)
    Dim materials(-1 To 1) As CCoupledConcreteResponse, responses(-1 To 1) As ICoupledPointResponse
    Set materials(0) = concrete: Set materials(1) = plusConcrete: Set materials(-1) = minusConcrete
    Set responses(0) = response: Set responses(1) = plusSide: Set responses(-1) = minusSide
    Dim base() As Double, qBase As Double, qTrial As Double, norm As Double, folder As String
    Dim actual() As Double, residual() As Double
    folder = Left$(replayPath, InStrRev(replayPath, "\"))
    base = history(24): qBase = factors(24): qTrial = qBase + (qBase - factors(23)) / 64#
    Dim output As Integer: output = FreeFile
    Open tracePath For Append As #output
    Print #output, "B_TANGENT_LOAD;" & ExperimentNumberTest(qBase) & ";" & ExperimentNumberTest(qTrial)
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Base24", 24, qBase, solver, operators, materials, responses, base, actual, residual)
    Print #output, "B_FRESH_PHASE;" & phase
    If phase <> "Compare" Then Err.Raise 5, , "Неизвестная фаза сравнения MVT2."
    ProbeWangArcComparisonTest output, folder, history, solver, operators, materials, responses, base, qBase, qTrial
    RequireWangAcceptedFieldTest solver, base
    RestoreWangShearBaselineTest solver, history, base
    norm = RecordWangTangentStateTest(output, "Restored24", 24, qBase, solver, operators, materials, responses, base, actual, residual)
    Print #output, "B_TANGENT_END;24;" & ExperimentNumberTest(qBase)
    Close #output
    RunTestWangShearControlled = report & "TOTAL_MVT2_SHEAR_CONTROL: passed=1; failed=0"
    Exit Function
Failed:
    Dim problem As String: problem = Err.Source & " " & Err.Description
    On Error Resume Next
    If output > 0 Then Close #output
    RunTestWangShearControlled = report & "RUNTIME ERROR: " & problem
End Function

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает исходные 24 состояния без изменения порядка и знаков шести нагрузок.
Private Sub ReadWangShearArchiveTest(ByVal replayPath As String, ByVal history As Collection, ByRef factors() As Double, _
        ByRef report As String, ByVal tracePath As String)
    Dim file As Integer, row As String, items As Variant, field() As Double, i As Long, k As Long
    ReDim factors(1 To 24)
    file = FreeFile
    Open replayPath For Input As #file
    Line Input #file, row
    If Left$(row, 27) <> "index;offsetFraction;lambda" Then Err.Raise 5, , "Неизвестный заголовок восстановления B."
    For i = 1 To 24
        Line Input #file, row
        items = Split(row, ";")
        If UBound(items) <> 68 Or Val(items(0)) <> i Then Err.Raise 5, , "Неполное поле истории B."
        factors(i) = Val(items(2))
        ReDim field(1 To 60)
        For k = 1 To 60: field(k) = Val(items(8 + k)): Next k
        history.Add field
        AppendWangFieldTest report, tracePath, "Replay" & CStr(i), field
    Next i
    If Not EOF(file) Then Err.Raise 5, , "Лишние состояния истории B."
    Close #file
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Удостоверяет точный откат механического поля после восстановления принятой истории.
Private Sub RestoreWangShearBaselineTest(ByVal solver As CCoupledNewtonSolver, ByVal history As Collection, ByRef saved() As Double)
    If Not solver.ReplayAcceptedFields(history, history.Count) Then Err.Raise 5, , "Не восстановлена материальная история B."
    RequireWangAcceptedFieldTest solver, saved
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сверяет все координаты предыдущего принятого поля после незаписанной пробы.
Private Sub RequireWangAcceptedFieldTest(ByVal solver As CCoupledNewtonSolver, ByRef saved() As Double)
    Dim actual() As Double, k As Long
    solver.CopyAccepted actual
    For k = 1 To 60
        If actual(k) <> saved(k) Then Err.Raise 5, , "Проба изменила принятое поле B."
    Next k
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Масштабирует одно и то же направление без изменения принятого поля решателя.
Private Sub AddWangTangentDirectionTest(ByRef base() As Double, ByRef direction() As Double, _
        ByVal amount As Double, ByRef target() As Double)
    Dim j As Long
    ReDim target(1 To UBound(base))
    For j = 1 To UBound(base): target(j) = base(j) + amount * direction(j): Next j
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Выгружает вектор в инвариантной форме для независимой проверки.
Private Sub EmitWangTangentVectorTest(ByVal output As Integer, ByVal prefix As String, ByRef values() As Double)
    Dim row As String, j As Long
    row = prefix
    For j = 1 To UBound(values): row = row & ";" & ExperimentNumberTest(values(j)): Next j
    Print #output, row
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сохраняет независимые центральные и боковые напряжения, признаки ветви и слабые строки.
Private Function RecordWangTangentStateTest(ByVal output As Integer, ByVal label As String, ByVal historyCount As Long, _
        ByVal factor As Double, ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, ByRef field() As Double, _
        ByRef actual() As Double, ByRef residual() As Double) As Double
    Dim point As Long, side As Long, i As Long, x As Double, y As Double, area As Double
    Dim strain(1 To 6) As Double, slope(1 To 6) As Double, station(1 To 6) As Double
    Dim stress(1 To 6) As Double, tangent(1 To 6, 1 To 6) As Double, grad(1 To 6) As Double
    Dim matrix() As Double, external() As Double, row As String, flag As Long
    Dim yielding As Boolean, principal As Long, substeps As Long, yieldValue As Double
    Dim concretePoint As ICoupledPointResponse, concreteStress(1 To 6) As Double, component As Long
    EmitWangTangentVectorTest output, "B_TANGENT_FIELD;" & label & ";" & CStr(historyCount) & ";" & _
        ExperimentNumberTest(factor), field
    RecordWangTangentStateTest = -1#
    If Not solver.TestEquilibriumLinearization(field, False, False, residual, matrix) Then
        Print #output, "B_TANGENT_UNAVAILABLE;" & label & ";Residual"
        Exit Function
    End If
    operators.LoadEquations 0#, 600000# * factor, 0#, 10510000#, 0#, 1000# * factor, external
    For i = 1 To UBound(residual): residual(i) = residual(i) - external(i): Next i
    EmitWangTangentVectorTest output, "B_TANGENT_RESIDUAL;" & label, residual
    Dim norm As Double, value As Double, demand(1 To 6) As Double
    ReDim actual(1 To 6)
    For i = 1 To UBound(residual)
        value = Abs(residual(i))
        If i > solver.PhysicalDegreeCount Then value = value * 30000#
        norm = GeomMax(norm, value)
    Next i
    demand(2) = 600000# * factor: demand(4) = 10510000#: demand(6) = 1000# * factor
    For point = 1 To operators.PointCount
        operators.Point point, x, y, area
        operators.PointStrain point, field, strain
        operators.AxialGradientAtPoint point, field, slope
        For side = -1 To 1
            For i = 1 To 6: station(i) = strain(i) + side * 0.001 * slope(i): Next i
            If responses(side).EvaluatePoint(point, station, stress, tangent, ctmStressOnly, False) <> sfcNone Then _
                Err.Raise 5, , "Не подтвержден станционный отклик MVT2 B. " & label
            If side = 0 Then
                actual(1) = actual(1) + area * stress(3)
                actual(2) = actual(2) + area * stress(3) * y
                actual(3) = actual(3) + area * stress(3) * x
                actual(4) = actual(4) + area * (x * stress(6) - y * stress(5))
                actual(5) = actual(5) + area * stress(5)
                actual(6) = actual(6) + area * stress(6)
            End If
            If point > operators.ConcretePointCount Then
                Set concretePoint = materials(side)
                If concretePoint.EvaluatePoint(point, station, concreteStress, tangent, ctmStressOnly, False) <> sfcNone Then _
                    Err.Raise 5, , "Не подтверждён бетон в поправке замещения арматуры MVT2 B. " & label
                component = 3 ' Продольные стержни имеют ось z.
                If point > operators.ConcretePointCount + 4 Then
                    If Abs(x) > Abs(y) Then component = 2 Else component = 1 ' Ось ветви параллельна стенке квадрата.
                End If
                Print #output, "B_BOUND_STEEL;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & CStr(component) & ";" & _
                    ExperimentNumberTest(station(component)) & ";" & ExperimentNumberTest(concreteStress(component)) & ";" & _
                    ExperimentNumberTest(stress(component) + concreteStress(component))
            End If
            flag = -1: principal = 0: substeps = -1: yieldValue = 0#
            If point <= operators.ConcretePointCount Then
                If Not materials(side).TryReadConcreteBranch(point, station, yielding, principal, substeps) Then _
                    Err.Raise 5, , "Недоступна ветвь бетона MVT2 B. " & label
                If Not materials(side).TryReadTrialYield(point, station, yieldValue, grad, needGradient:=False) Then _
                    Err.Raise 5, , "Недоступна пробная поверхность бетона MVT2 B. " & label
                flag = Abs(CLng(yielding))
            End If
            row = "B_TANGENT_STATION;" & label & ";" & CStr(point) & ";" & CStr(side) & ";" & _
                ExperimentNumberTest(x) & ";" & ExperimentNumberTest(y) & ";" & ExperimentNumberTest(area) & ";" & _
                CStr(flag) & ";" & CStr(principal) & ";" & CStr(substeps) & ";" & ExperimentNumberTest(yieldValue)
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(station(i)): Next i
            For i = 1 To 6: row = row & ";" & ExperimentNumberTest(stress(i)): Next i
            Print #output, row
        Next side
    Next point
    EmitWangTangentVectorTest output, "B_BOUND_ACTUAL;" & label, actual
    RecordWangTangentStateTest = GeomMax(norm, operators.ResultantResidualNorm(actual, demand))
    Print #output, "B_BOUND_NORM;" & label & ";" & ExperimentNumberTest(RecordWangTangentStateTest)
End Function


' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает управление усилием и плоскостью псевдодуги из одного
' принятого H24, с одним прогнозом, одними диаграммами и тем же допуском.
Private Sub ProbeWangArcComparisonTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByVal qBase As Double, ByVal qTrial As Double)
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005
    Const MAX_ITERATIONS As Long = 26
    Dim projection() As Double, prefix() As Double, prediction() As Double
    ReDim projection(1 To 60)
    Dim data As Variant, raw As String, file As Integer, i As Long
    Dim loadProjection As Double, arcStep As Double, planeTarget As Double, measured As Double
    file = FreeFile: Open folder & "MVTNormal.csv" For Input As #file
    Line Input #file, raw
    If Not EOF(file) Then Err.Raise 5, , "Лишняя строка нормали MVT2."
    Close #file
    data = Split(raw, ";")
    If UBound(data) <> 61 Or solver.PhysicalDegreeCount <> 56 Then Err.Raise 5, , "Неверная нормаль псевдодуги MVT2."
    loadProjection = Val(data(60)): arcStep = Val(data(61)) / 64#
    If loadProjection <= 0# Or arcStep <= 0# Then Err.Raise 5, , "Неверный шаг псевдодуги MVT2."
    prefix = history(23): prediction = base
    planeTarget = loadProjection * qBase + arcStep
    measured = loadProjection * (qTrial - qBase)
    For i = 1 To 60
        projection(i) = Val(data(i - 1))
        If i <= 56 Then
            prediction(i) = base(i) + (base(i) - prefix(i)) / 64#
            planeTarget = planeTarget + projection(i) * base(i)
            measured = measured + projection(i) * (prediction(i) - base(i))
        ElseIf projection(i) <> 0# Then
            Err.Raise 5, , "Нормаль псевдодуги включает служебную реакцию."
        End If
    Next i
    If Abs(measured - arcStep) > 0.00000000000000001 Then Err.Raise 5, , "Прогноз не лежит на плоскости псевдодуги."
    EmitWangTangentVectorTest output, "B_ARC_PROJECTION;Normal", projection
    EmitWangTangentVectorTest output, "B_ARC_PREDICTOR;Shared", prediction
    Print #output, "B_ARC_PLANE;" & ExperimentNumberTest(loadProjection) & ";" & _
        ExperimentNumberTest(arcStep) & ";" & ExperimentNumberTest(planeTarget) & ";" & _
        ExperimentNumberTest(ABS_TOL) & ";" & ExperimentNumberTest(REL_TOL) & ";" & CStr(MAX_ITERATIONS)

    Dim baseLoad(1 To 6) As Double, direction(1 To 6) As Double
    baseLoad(4) = 10510000#: direction(2) = 600000#: direction(6) = 1000#
    Dim seed As Variant: seed = prediction
    Dim committed() As Double, afterProbe() As Double
    Dim field() As Double, solverForces() As Double, actual() As Double, weak() As Double
    Dim mode As Variant, solved As Boolean, lambda As Double, status As CResultMeta, norm As Double, lambdaText As String
    Dim started As Double, elapsed As Double
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "Before", operators, materials, committed
    norm = RecordWangTangentStateTest(output, "SharedPredictor", 24, qTrial, solver, operators, materials, responses, prediction, actual, weak)
    For Each mode In Array("Force", "PseudoArc")
        RestoreWangShearBaselineTest solver, history, base
        CaptureWangArcHistoryTest output, "Replay" & CStr(mode), operators, materials, afterProbe
        RequireWangArcHistoryTest committed, afterProbe
        lambda = qTrial: started = Timer
        If mode = "Force" Then
            solved = solver.TryStep(0#, 600000# * qTrial, 0#, 10510000#, 0#, 1000# * qTrial, _
                ABS_TOL, REL_TOL, MAX_ITERATIONS, initialField:=seed)
        Else
            solved = solver.TryDeformationStep(baseLoad, direction, projection, planeTarget, qTrial, lambda, _
                ABS_TOL, REL_TOL, MAX_ITERATIONS, consistentControl:=False, initialField:=seed, loadProjection:=loadProjection)
        End If
        elapsed = Timer - started: If elapsed < 0# Then elapsed = elapsed + 86400#
        Set status = solver.ResultMeta
        lambdaText = "-"
        If solved Then
            lambdaText = ExperimentNumberTest(lambda)
            solver.CopyTrial field, solverForces
            EmitWangTangentVectorTest output, "B_ARC_SOLVER_ACTUAL;" & CStr(mode), solverForces
        End If
        solver.DiscardStep
        RequireWangAcceptedFieldTest solver, base
        CaptureWangArcHistoryTest output, "After" & CStr(mode), operators, materials, afterProbe
        RequireWangArcHistoryTest committed, afterProbe
        Print #output, "B_ARC_STATUS;" & CStr(mode) & ";" & CStr(Abs(CLng(solved))) & ";" & _
            lambdaText & ";" & CStr(status.InternalStatus) & ";" & CStr(status.ResultCode) & ";" & ExperimentNumberTest(elapsed)
        Print #output, "B_ARC_DIAG;" & CStr(mode) & ";" & Replace(Replace(status.DiagnosticDetails, vbCr, " "), vbLf, " ")
        If solved Then
            norm = RecordWangTangentStateTest(output, CStr(mode), 24, lambda, solver, operators, materials, responses, field, actual, weak)
            If norm < 0# Then Err.Raise 5, , "Не повторены исходные уравнения решённой пробы MVT2."
        End If
    Next mode
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "Final", operators, materials, afterProbe
    RequireWangArcHistoryTest committed, afterProbe
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает напряжения и энергии всех принятых точек бетона с трёх станций.
' Вывод снимается до явного повтора истории, чтобы обнаружить лишнюю фиксацию.
Private Sub CaptureWangArcHistoryTest(ByVal output As Integer, ByVal label As String, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef snapshot() As Double)
    Dim point As Long, side As Long, i As Long, position As Long
    Dim stress(1 To 6) As Double, tension As Double, compression As Double
    ReDim snapshot(1 To 3 * operators.PointCount * 8)
    For side = -1 To 1
        For point = 1 To operators.PointCount
            materials(side).CopyAcceptedStress point, stress
            materials(side).AcceptedPointDamage point, tension, compression
            For i = 1 To 6
                snapshot(position + i) = stress(i)
            Next i
            snapshot(position + 7) = tension: snapshot(position + 8) = compression
            position = position + 8
        Next point
    Next side
    EmitWangTangentVectorTest output, "B_ARC_HISTORY;" & label, snapshot
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет точное совпадение принятого отклика, без округления и послабления.
Private Sub RequireWangArcHistoryTest(ByRef committed() As Double, ByRef afterProbe() As Double)
    Dim i As Long
    For i = 1 To UBound(committed)
        If committed(i) <> afterProbe(i) Then Err.Raise 5, , "Принятая история изменилась во время пробы MVT2."
    Next i
End Sub
