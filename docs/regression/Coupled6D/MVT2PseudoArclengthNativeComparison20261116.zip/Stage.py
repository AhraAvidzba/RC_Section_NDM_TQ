"""Freeze the exact H24 MVT2 native force/pseudo-arc comparison."""
from hashlib import sha256
import json
from pathlib import Path


here = Path(__file__).resolve().parent
tmp = here.parent.parent
project = tmp.parent
jet = here.parent / "jetb"
prior = here.parent / "jet"
arc = tmp / "arcv"
reference = tmp / "arc-reference"


def digest(raw):
    return sha256(raw).hexdigest().upper()


def save(name, raw):
    path = here / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        path.write_bytes(raw)
    return digest(raw)


def take(folder, name, expected, rename=None):
    raw = (folder / name).read_bytes()
    assert digest(raw) == expected, name
    return save(name if rename is None else rename, raw)


def once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def main():
    arc_fixture = (arc / "Fixture.json").read_bytes()
    arc_hash = "3C3EDCCD4B777E1D5AC7C7C9ED1267DD2DE3A224F5EC4F26BF430AB0CFE41AA7"
    assert digest(arc_fixture) == arc_hash
    arc_receipt = json.loads(arc_fixture)
    jet_raw = (jet / "Preparation.json").read_bytes()
    assert digest(jet_raw) == "EAA93259CB0DA5116E8EB2E694EB5BF407154137CB50FE7FFDA94CB1DE8F54EB"
    jet_frozen = json.loads(jet_raw)
    prior_frozen = json.loads((prior / "Preparation.json").read_bytes())
    book = "workbook/output/RC_Section_NDM.xlsm"
    assert jet_frozen["book_sha256"] == arc_receipt["workbook_sha256"]
    take(project, book, jet_frozen["book_sha256"])
    take(project, book, jet_frozen["book_sha256"], "docs/regression/Diagnostic.xlsm")
    for folder in ("NativeCompare", "Temp"):
        (here / folder).mkdir(exist_ok=True)
    inputs = {}
    for name in ("Replay.csv", "VerifyBase.py", "Guard-IsolatedOffice.ps1", "JetNative.csv",
                 *(name for name in jet_frozen["inputs"] if name.startswith("tools/"))):
        inputs[name] = take(jet, name, jet_frozen["inputs"][name])
    inputs["ArcFixture.json"] = save("ArcFixture.json", arc_fixture)
    newton = "src/Solver/CCoupledNewtonSolver.cls"
    inputs[newton] = take(arc, newton, arc_receipt["frozen"][newton])
    inputs["MVTNormal.csv"] = take(reference, "MVTNormal.csv",
                                  "97626F4FC7D9F97DD0667F9388B712D6960F94AB3453F0A6DF2563611BB82A6F")
    inputs["MVTHistory.json"] = take(reference, "MVTHistory.json",
                                    "BCF342375610108EE54AB9B4E9B3BA89602D4183F4A5B7800A9F87DFEC6FA97F")

    control_name = "Control.bas"
    control_raw = (jet / control_name).read_bytes()
    assert digest(control_raw) == jet_frozen["inputs"][control_name]
    control = control_raw.decode("utf-8").replace("\r\n", "\n")
    control = once(control, "' Сравнивает одинаковые деформации с двумя наборами множителей после проверки архивных полей MVT2 B.",
                   "' Сравнивает усилие и плоскость псевдодуги при одной истории MVT2 B.")
    control = once(control, "    Dim base() As Double, anchor() As Double, qBase As Double, qTrial As Double, norm As Double, folder As String",
                   "    Dim base() As Double, qBase As Double, qTrial As Double, norm As Double, folder As String")
    control = once(control, "    Dim actual() As Double, referenceForces() As Double, residual() As Double",
                   "    Dim actual() As Double, residual() As Double")
    control = once(control, '    ReadWangFreshAnchorTest folder & "AnchorField.csv", anchor\n', "")
    start = control.index('    norm = RecordWangTangentStateTest(output, "HalfJoint"')
    end = control.index("    RequireWangAcceptedFieldTest solver, base", start)
    control = control[:start] + '''    If phase <> "Compare" Then Err.Raise 5, , "Неизвестная фаза сравнения MVT2."
    ProbeWangArcComparisonTest output, folder, history, solver, operators, materials, responses, base, qBase, qTrial
''' + control[end:]
    begin = control.index('                If label = "HalfJoint" Then')
    after = control.index("                End If", control.index("                    Print #output, gradientRow", begin))
    control = control[:begin] + control[after + len("                End If\n"):]
    control = once(control, "    Dim gradientRow As String, componentIndex As Long\n", "")
    start = control.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0,
                           control.index("Private Function WangBoundedTensorPeakTest"))
    control = control[:start] + (here / "Probe.bas").read_text(encoding="utf-8")
    assert control.count("Sub ProbeWangArcComparisonTest") == 1
    inputs["Control.bas"] = save("Control.bas", control.encode("utf-8"))

    test = "tests/modTestCoupledExperiment.bas"
    original = (jet / test).read_bytes()
    assert digest(original) == jet_frozen["inputs"][test]
    module = original.decode("utf-8").replace("\r\n", "\n")
    start = module.rindex("' -------------------- ДЛЯ ТЕСТОВ --------------------", 0,
                          module.index("Public Function RunTestWangShearControlled("))
    inputs[test] = save(test, (module[:start] + control).replace("\n", "\r\n").encode("utf-8"))

    native_runner = "Run-MVT2ShearControlled.ps1"
    runner = (prior / native_runner).read_bytes()
    assert digest(runner) == prior_frozen["inputs"][native_runner]
    runner = runner.decode("utf-8").replace("\r\n", "\n")
    runner = once(runner, "[ValidateSet('A')][string]$Phase='A'", "[ValidateSet('Compare')][string]$Phase='Compare'")
    runner = once(runner, "if($Phase -eq 'B' -and (-not $CompiledOnly)){throw 'Для фазы B требуется скомпилированная книга фазы A.'}\n", "")
    start = runner.index("    if ($Phase -eq 'B') {")
    end = runner.index("    Assert-IsolatedOfficeReady", start)
    runner = runner[:start] + runner[end:]
    inputs[native_runner] = save(native_runner, runner.encode("utf-8"))
    for name in ("Probe.bas", "Stage.py", "Verify-MVT2ShearControlled.py"):
        inputs[name] = digest((here / name).read_bytes())
    output = {"inputs": inputs, "book_sha256": jet_frozen["book_sha256"], "replay_sha256": jet_frozen["replay_sha256"],
              "watchdog_seconds": 150}
    print(save("Preparation.json", (json.dumps(output, indent=2) + "\n").encode("utf-8")))


if __name__ == "__main__":
    main()
