Native MVT2 force and pseudo-arc comparison at H24

From an extracted directory run
    python -B -X utf8 ReplayPortable.py PATH/MVT2HalfJointJetNative20261116.zip

The parameter in the frozen load path is Qy in kN. Both probes replay the same
24 accepted fields and use identical initial extrapolated coordinates, original
material laws, the same tolerances and the same iteration budget. The prescribed
force target is Qy=18.5720088671875 kN. The pseudo-arc plane has the same prediction,
with a free load parameter and one sixty-fourth of the physical secant length.
Gauge reactions carry no weight in the plane and are held at H24 in the prediction.

The native reports include both method outcomes and exact accepted stress and
tension/compression energy fingerprints at 135 stations. The same accepted
field and stress/energy snapshot was confirmed before and after both probes.
Neither arm returned equilibrium or a new load multiplier. The last accepted
Qy remains 18.55811 kN. The diagnostic ending residual in the pseudo-arc arm is
11.95 times smaller than in the force arm, but it is outside the accepted
equilibrium tolerance. There is no identified material or physical capacity.

The original independent verifier used an absolute 3e-17 comparison for the
wire representation of normal coefficients. VBA Str$ rounds to 15 decimal
significant digits. ReplayPrecision replaces this one original projection
comparison with independent exact Decimal rounding at each coefficient's
decimal scale. The original rejected check, source verifier and native raw
trace are kept. No solver tolerance, history or result was changed.

Shared exact inputs are reconstructed from the tracked Jet archive. Workbook
bytes are excluded and the workbook identity is verified via source digests
and the recorded compile, protected-run and closure receipts.
