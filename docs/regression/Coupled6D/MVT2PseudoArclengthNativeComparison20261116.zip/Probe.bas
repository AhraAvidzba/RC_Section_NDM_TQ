
' -------------------- ДЛЯ ТЕСТОВ --------------------
' Сравнивает управление усилием и плоскостью псевдодуги из одного
' принятого H24, с одним прогнозом, одними диаграммами и тем же допуском.
Private Sub ProbeWangArcComparisonTest(ByVal output As Integer, ByVal folder As String, ByVal history As Collection, _
        ByVal solver As CCoupledNewtonSolver, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef responses() As ICoupledPointResponse, _
        ByRef base() As Double, ByVal qBase As Double, ByVal qTrial As Double)
    Const ABS_TOL As Double = 0.0000005, REL_TOL As Double = 0.0000005
    Const MAX_ITERATIONS As Long = 26
    Dim projection() As Double, prefix() As Double, prediction() As Double
    ReDim projection(1 To 60)
    Dim data As Variant, raw As String, file As Integer, i As Long
    Dim loadProjection As Double, arcStep As Double, planeTarget As Double, measured As Double
    file = FreeFile: Open folder & "MVTNormal.csv" For Input As #file
    Line Input #file, raw
    If Not EOF(file) Then Err.Raise 5, , "Лишняя строка нормали MVT2."
    Close #file
    data = Split(raw, ";")
    If UBound(data) <> 61 Or solver.PhysicalDegreeCount <> 56 Then Err.Raise 5, , "Неверная нормаль псевдодуги MVT2."
    loadProjection = Val(data(60)): arcStep = Val(data(61)) / 64#
    If loadProjection <= 0# Or arcStep <= 0# Then Err.Raise 5, , "Неверный шаг псевдодуги MVT2."
    prefix = history(23): prediction = base
    planeTarget = loadProjection * qBase + arcStep
    measured = loadProjection * (qTrial - qBase)
    For i = 1 To 60
        projection(i) = Val(data(i - 1))
        If i <= 56 Then
            prediction(i) = base(i) + (base(i) - prefix(i)) / 64#
            planeTarget = planeTarget + projection(i) * base(i)
            measured = measured + projection(i) * (prediction(i) - base(i))
        ElseIf projection(i) <> 0# Then
            Err.Raise 5, , "Нормаль псевдодуги включает служебную реакцию."
        End If
    Next i
    If Abs(measured - arcStep) > 0.00000000000000001 Then Err.Raise 5, , "Прогноз не лежит на плоскости псевдодуги."
    EmitWangTangentVectorTest output, "B_ARC_PROJECTION;Normal", projection
    EmitWangTangentVectorTest output, "B_ARC_PREDICTOR;Shared", prediction
    Print #output, "B_ARC_PLANE;" & ExperimentNumberTest(loadProjection) & ";" & _
        ExperimentNumberTest(arcStep) & ";" & ExperimentNumberTest(planeTarget) & ";" & _
        ExperimentNumberTest(ABS_TOL) & ";" & ExperimentNumberTest(REL_TOL) & ";" & CStr(MAX_ITERATIONS)

    Dim baseLoad(1 To 6) As Double, direction(1 To 6) As Double
    baseLoad(4) = 10510000#: direction(2) = 600000#: direction(6) = 1000#
    Dim seed As Variant: seed = prediction
    Dim committed() As Double, afterProbe() As Double
    Dim field() As Double, solverForces() As Double, actual() As Double, weak() As Double
    Dim mode As Variant, solved As Boolean, lambda As Double, status As CResultMeta, norm As Double, lambdaText As String
    Dim started As Double, elapsed As Double
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "Before", operators, materials, committed
    norm = RecordWangTangentStateTest(output, "SharedPredictor", 24, qTrial, solver, operators, materials, responses, prediction, actual, weak)
    For Each mode In Array("Force", "PseudoArc")
        RestoreWangShearBaselineTest solver, history, base
        CaptureWangArcHistoryTest output, "Replay" & CStr(mode), operators, materials, afterProbe
        RequireWangArcHistoryTest committed, afterProbe
        lambda = qTrial: started = Timer
        If mode = "Force" Then
            solved = solver.TryStep(0#, 600000# * qTrial, 0#, 10510000#, 0#, 1000# * qTrial, _
                ABS_TOL, REL_TOL, MAX_ITERATIONS, initialField:=seed)
        Else
            solved = solver.TryDeformationStep(baseLoad, direction, projection, planeTarget, qTrial, lambda, _
                ABS_TOL, REL_TOL, MAX_ITERATIONS, consistentControl:=False, initialField:=seed, loadProjection:=loadProjection)
        End If
        elapsed = Timer - started: If elapsed < 0# Then elapsed = elapsed + 86400#
        Set status = solver.ResultMeta
        lambdaText = "-"
        If solved Then
            lambdaText = ExperimentNumberTest(lambda)
            solver.CopyTrial field, solverForces
            EmitWangTangentVectorTest output, "B_ARC_SOLVER_ACTUAL;" & CStr(mode), solverForces
        End If
        solver.DiscardStep
        RequireWangAcceptedFieldTest solver, base
        CaptureWangArcHistoryTest output, "After" & CStr(mode), operators, materials, afterProbe
        RequireWangArcHistoryTest committed, afterProbe
        Print #output, "B_ARC_STATUS;" & CStr(mode) & ";" & CStr(Abs(CLng(solved))) & ";" & _
            lambdaText & ";" & CStr(status.InternalStatus) & ";" & CStr(status.ResultCode) & ";" & ExperimentNumberTest(elapsed)
        Print #output, "B_ARC_DIAG;" & CStr(mode) & ";" & Replace(Replace(status.DiagnosticDetails, vbCr, " "), vbLf, " ")
        If solved Then
            norm = RecordWangTangentStateTest(output, CStr(mode), 24, lambda, solver, operators, materials, responses, field, actual, weak)
            If norm < 0# Then Err.Raise 5, , "Не повторены исходные уравнения решённой пробы MVT2."
        End If
    Next mode
    RestoreWangShearBaselineTest solver, history, base
    CaptureWangArcHistoryTest output, "Final", operators, materials, afterProbe
    RequireWangArcHistoryTest committed, afterProbe
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Читает напряжения и энергии всех принятых точек бетона с трёх станций.
' Вывод снимается до явного повтора истории, чтобы обнаружить лишнюю фиксацию.
Private Sub CaptureWangArcHistoryTest(ByVal output As Integer, ByVal label As String, ByVal operators As CCoupledElasticState, _
        ByRef materials() As CCoupledConcreteResponse, ByRef snapshot() As Double)
    Dim point As Long, side As Long, i As Long, position As Long
    Dim stress(1 To 6) As Double, tension As Double, compression As Double
    ReDim snapshot(1 To 3 * operators.PointCount * 8)
    For side = -1 To 1
        For point = 1 To operators.PointCount
            materials(side).CopyAcceptedStress point, stress
            materials(side).AcceptedPointDamage point, tension, compression
            For i = 1 To 6
                snapshot(position + i) = stress(i)
            Next i
            snapshot(position + 7) = tension: snapshot(position + 8) = compression
            position = position + 8
        Next point
    Next side
    EmitWangTangentVectorTest output, "B_ARC_HISTORY;" & label, snapshot
End Sub

' -------------------- ДЛЯ ТЕСТОВ --------------------
' Проверяет точное совпадение принятого отклика, без округления и послабления.
Private Sub RequireWangArcHistoryTest(ByRef committed() As Double, ByRef afterProbe() As Double)
    Dim i As Long
    For i = 1 To UBound(committed)
        If committed(i) <> afterProbe(i) Then Err.Raise 5, , "Принятая история изменилась во время пробы MVT2."
    Next i
End Sub
