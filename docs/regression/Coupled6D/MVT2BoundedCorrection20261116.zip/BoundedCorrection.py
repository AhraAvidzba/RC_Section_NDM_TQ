"""Audit physically bounded first corrections from five native MVT2 matrices."""
import csv
import json
import runpy
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import sys

import numpy as np
from scipy.optimize import linprog

archive, output = map(Path, sys.argv[1:])
trace = archive / "Native/MVT2.csv"
identity = sha256(trace.read_bytes()).hexdigest().upper()
assert identity == "66D014FF04BC13625676E41B45397B6233D511CBB12662DDD1F9190534664F47"
reader = runpy.run_path(str(archive / "Verify-MVT2ShearControlled.py"))
rows = defaultdict(list)
for tag, *row in csv.reader(trace.read_text(encoding="cp1251").splitlines(), delimiter=";"):
    rows[tag].append(row)
matrices = defaultdict(dict)
for name, idx, *data in rows["B_TANGENT_MATRIX"]:
    matrices[name][int(idx)] = np.asarray(data, float)
matrices = {name: np.stack([rows[i] for i in range(1,61)]) for name, rows in matrices.items()}
residuals = reader["vec"](rows, "B_TANGENT_RESIDUAL")
base, target = map(float, rows["B_TANGENT_LOAD"][0])
rhs = -np.asarray(residuals["Base24"]) + np.array(reader["loading"](target))-np.array(reader["loading"](base))
directions = reader["vec"](rows, "B_TANGENT_DIRECTION")
secant = np.asarray(directions["Secant"])
stations = [(int(point), int(side), float(x), float(y))
            for name, point, side, x, y, *_ in rows["B_TANGENT_STATION"] if name == "Base24"]
assert len(stations) == 135
unit = np.eye(60)
S = np.stack([np.array([reader["strain_at"](v, reader["operators"](x,y), side)
                       for v in unit]).T for _,side,x,y in stations]).reshape(-1, 60)
# The constraints use each physical tensor component, not a bound on 56 generalized coordinates.
S[3::6] /= np.sqrt(2)
S[4::6] /= np.sqrt(2)
S[5::6] /= np.sqrt(2)
strain_secant = S@secant
gauge = matrices["Stock24"][56:]
assert max(np.max(abs(v[56:]-gauge)) for v in matrices.values()) < 1e-12
force_scale, strain_scale = 1e-3, 1e-6
weak_rhs = rhs[:56]/force_scale
gauge_rhs = rhs[56:]/strain_scale
one = np.r_[np.zeros(60), 1]
B = np.c_[S,np.zeros(len(S))]
eq = np.c_[gauge, np.zeros(4)]
R = {name: mat[:56]*strain_scale/force_scale for name,mat in matrices.items()}


def optimize(names, radius):
    A = np.vstack([R[name] for name in names])
    c = np.tile(weak_rhs, len(names))
    inequalities = np.r_[np.c_[A, -np.ones(len(A))], np.c_[-A, -np.ones(len(A))], B, -B]
    right = np.r_[c,-c,np.repeat(radius/strain_scale,2*len(S))]
    result = linprog(one,A_ub=inequalities,b_ub=right,A_eq=eq,b_eq=gauge_rhs,
                     bounds=[(None,None)]*60+[(0,None)],method="highs",
                     options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
    assert result.success, result.message
    q = result.x[:60]*strain_scale
    evaluated = {name: float(np.linalg.norm(mat[:56]@q-rhs[:56],np.inf))
                 for name,mat in matrices.items()}
    maximum = max(evaluated[name] for name in names)
    assert abs(maximum-result.fun*force_scale)<1e-11
    spatial = S@q
    assert max(abs(spatial))<=radius+1e-14
    assert np.max(abs(gauge@q-rhs[56:]))<1e-13
    return dict(radius=radius,target_residual_MPa=maximum,
                modeled_residuals_MPa=evaluated,max_tensor_strain_component=float(max(abs(spatial))),
                cosine_strain_secant=float(spatial@strain_secant/(np.linalg.norm(spatial)*np.linalg.norm(strain_secant))),
                dq=q.tolist())


all_current = [name for name in matrices if name != "Consistent23"]
families = {"Stock24":["Stock24"],"BiasedPositive":[next(name for name in matrices if name.startswith("Biased24/") and float(name.split("/")[-1])>0)],
            "CurrentEnvelope":all_current}
tests = {group:[optimize(names,r) for r in (1e-8,1e-7,5e-7,1e-6,2e-6,5e-6)]
         for group,names in families.items()}
baseline = float(np.linalg.norm(rhs[:56],np.inf))
report = {"native_trace_sha256":identity,"baseline_weak_MPa":baseline,
          "tolerance_MPa":5e-7*(1+max(map(abs,reader["loading"](target)))),
          "gauge_equations":4,"linear_weak_rows":56,"load_target_Qy_kN":target,
          "tests":tests, "scope":"Linear predictions only. Full six resultant tests need actual nonlinear station evaluations."}
output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(sha256(output.read_bytes()).hexdigest().upper())
for group, vals in tests.items():
    print(group,[(x["radius"],x["target_residual_MPa"]) for x in vals])
