"""Recheck the exact design-force fixture and native Excel release evidence."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parent


def digest(path):
    return sha256(path.read_bytes()).hexdigest().upper()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    proof = read(ROOT / "Verification.json")
    publication = read(ROOT / "Publication.json")
    equality = read(ROOT / "SourceEquality.json")
    assert publication["verification_sha256"] == digest(ROOT / "Verification.json")
    assert publication["status"] == proof["status"] == "PASS"
    assert publication["installed"]["workbook/output/RC_Section_NDM.xlsm"] == proof["package"]["candidate_sha256"]
    assert publication["installed"]["workbook/output/VBA_All_Code.txt"] == proof["installed_export_sha256"]
    assert proof["package"]["unchanged_package_parts"] == 121
    assert proof["production_vba_components"]["components"] == equality["ExportComponents"] == 225
    assert equality["Passed"] and all(equality["VerifierSelfChecks"].values())
    assert equality["ExportSHA256"] == proof["installed_export_sha256"]
    assert {x["Name"]: x["SourceSHA256"] for x in equality["Components"]} == {
        Path(name).stem: expected for name, expected in proof["sources"].items()
    }
    assert proof["export_closure"]["State"] == "Absent"
    for relative, expected in proof["sources"].items():
        assert digest(ROOT / "compiled" / relative) == expected == publication["installed"][relative]

    # Independent polynomial calculations for the blocked exact design root.
    def stress(strain):
        epsilon = Fraction(strain)
        return 30000 * epsilon - 10000000000 * epsilon**3

    peak = (stress("0.000975") - 4) / 15
    barrier = [stress("0.00081135"), stress("0.00081145")]
    assert barrier[0] < 19 < barrier[1]
    assert stress("0.00080625") < barrier[0] and peak - Fraction("0.0125") > 1
    assert min(19 - barrier[0], barrier[1] - 19) > Fraction(4,10000)
    base = (ROOT / "Base/Native/RunTestCoupledDesignWitness.txt").read_text(encoding="utf-8-sig")
    assert re.findall(r"(?m)^FAIL:.*$", base) == [
        "FAIL: подтверждение сочетания относится к уточнённой истории, отказ=True",
        "FAIL: пик выше единицы без равновесия сочетания даёт NumFail",
    ]
    assert (proof["untreated_case"]["pass"], proof["untreated_case"]["fail"]) == (15, 2)
    assert proof["untreated_case"]["closed"]["State"] == "Absent"
    initial = (ROOT / "Initial/RunTestCoupledDesignWitness.txt").read_text(encoding="utf-8-sig")
    assert "RUNTIME ERROR: VBAProject Не подтверждён второй узел префикса." in initial

    total = 0
    for name, receipt in proof["native"].items():
        report = (ROOT / "Candidate" / "Native" / (name + ".txt")).read_text(encoding="utf-8-sig")
        actual = re.search(r"(?m)^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)$", report)
        assert actual and (int(actual[1]), int(actual[2])) == (receipt["pass"], 0)
        assert f"SOURCE_SHA256: {proof['package']['candidate_sha256']}" in report
        assert receipt["closed"]["State"] == "Absent" and receipt["exit"] == 0
        total += int(actual[1])
    expected = (ROOT / "Candidate/Native/RunTestCoupledDesignWitness.txt").read_text(encoding="utf-8-sig")
    assert "OK: пик выше единицы без равновесия сочетания даёт NumFail" in expected
    assert "OK: подтверждённое сочетание и больший пик дают OK" in expected
    assert "OK: точное сочетание из сохранённого префикса подтверждено" in expected
    hard = (ROOT / "Candidate/Native/HardShear.txt").read_text(encoding="utf-8-sig")
    counts = re.findall(r"(?m)^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)$", hard)
    assert counts == [("28", "0"), ("1", "0")]
    assert "TIMING_STATES: direct=OK; capacity=NumFail; confirmed lower=1.10290889219737;" in hard
    assert proof["HardShear"]["closed"]["State"] == "Absent" and proof["HardShear"]["exit"] == 0
    total += sum(int(passed) for passed, _ in counts)
    assert total == 148
    core_seconds = float(re.search(r"(?m)^TIMING_SECONDS: ([\d.,]+) \| Both \| Excel", hard)[1].replace(",", "."))
    record = {"native_assertions": total, "untreated_regression_failures": 2,
              "independent_peak_lambda": str(peak),
              "blocked_force_band_MPa": [float(x) for x in barrier],
              "native_hardshear_seconds": core_seconds,
              "installed_workbook_sha256": proof["package"]["candidate_sha256"],
              "export_sha256": proof["installed_export_sha256"],
              "build_receipt_sha256": digest(ROOT / "Verification.json"),
              "publication_sha256": digest(ROOT / "Publication.json")}
    result = ROOT / "Replay.json"
    result.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
    print("PASS", total, digest(result))


if __name__ == "__main__":
    main()

