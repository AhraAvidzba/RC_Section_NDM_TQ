$ErrorActionPreference='Stop'
$root=Join-Path $PSScriptRoot 'Candidate'
$prevTemp=$env:TEMP
$prevTmp=$env:TMP
$legacy=Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
Push-Location -LiteralPath $root
try{
   . (Join-Path $root 'Guard-IsolatedOffice.ps1')
   $receipt=Get-Content -LiteralPath 'PackageChecks.json' -Raw | ConvertFrom-Json
   $closed=(Get-Content -LiteralPath 'ExportClosure.json' -Raw | ConvertFrom-Json).State
   $book='docs/regression/Audit03/DesignWitness/RC_Section_NDM.xlsm'
   $log='Native/HardShear.txt'
   if($closed -ne 'Absent' -or (Get-FileHash -LiteralPath $book).Hash -cne $receipt.candidate_sha256 -or (Test-Path -LiteralPath $log)){throw 'Не подтверждена готовность проверенной книги.'}
   $env:TEMP=(Resolve-Path -LiteralPath 'Temp').Path
   $env:TMP=$env:TEMP
   Assert-IsolatedOfficeReady 'HardShearCandidate'
   $clock=[Diagnostics.Stopwatch]::StartNew()
   & $legacy -NoProfile -ExecutionPolicy Bypass -File 'tools/build_workbook/Run-FocusedKaniWatchdog.ps1' -SourceWorkbook $book -ReportPath $log -Macro 'modTestCoupledElasticState.RunTestHardShearYieldRecovery' -Mode No -TimeoutSeconds 170 -FailFast
   $errCode=$LASTEXITCODE
   $clock.Stop()
   $result=Get-Content -LiteralPath $log -Raw -Encoding UTF8
   $closure=Get-Content -LiteralPath ($log+'.ProcessClosure.json') -Raw | ConvertFrom-Json
   $matchesTotal=@([regex]::Matches($result,'(?m)^TOTAL_[A-Z0-9_]+: passed=(\d+); failed=(\d+)') | ForEach-Object Value)
   [ordered]@{wall_seconds=$clock.Elapsed.TotalSeconds;exit=$errCode;totals=$matchesTotal;
       closed=$closure.Closure.FinalState} | ConvertTo-Json -Depth 4 |
       Set-Content -LiteralPath ($log+'.Receipt.json') -Encoding UTF8
   if($errCode -ne 0 -or $closure.Closure.FinalState.State -ne 'Absent' -or $matchesTotal.Count -ne 2 -or
       $matchesTotal[1] -notmatch '^TOTAL_HARD_SHEAR_YIELD_RECOVERY: passed=1; failed=0$'){throw 'Направленный HardShear не подтверждён.'}
   $matchesTotal
}
finally{
   Pop-Location
   $env:TEMP=$prevTemp
   $env:TMP=$prevTmp
}

